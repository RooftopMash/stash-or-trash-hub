import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AppErrorBoundary.tsx");const Component = __vite__cjsImport0_react["Component"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { reportApplicationError } from "/src/lib/error-reporting.ts";
var _jsxFileName = "/app/applet/src/components/AppErrorBoundary.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
/**
* Global React Error Boundary that catches render and lifecycle errors
* and renders a clean, generic fallback UI without leaking raw stack traces
* or internal component names.
*/
export class AppErrorBoundary extends Component {
	constructor(props) {
		super(props);
		this.state = { hasError: false };
	}
	static getDerivedStateFromError() {
		return { hasError: true };
	}
	componentDidCatch(error, _errorInfo) {
		reportApplicationError(error, { boundary: "app_error_boundary" });
	}
	handleReset = () => {
		this.setState({ hasError: false });
		if (typeof window !== "undefined") {
			window.location.reload();
		}
	};
	render() {
		if (this.state.hasError) {
			return /* @__PURE__ */ _jsxDEV("div", {
				role: "alert",
				className: "flex min-h-screen items-center justify-center bg-background px-4 py-12",
				"data-tsd-source": "/src/components/AppErrorBoundary.tsx:46:9",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "w-full max-w-md rounded-2xl border border-border bg-card p-8 text-center shadow-sm",
					"data-tsd-source": "/src/components/AppErrorBoundary.tsx:50:11",
					children: [
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "font-display text-xl font-bold tracking-tight text-foreground",
							"data-tsd-source": "/src/components/AppErrorBoundary.tsx:51:13",
							children: this.props.fallbackTitle ?? "Something went wrong, please refresh"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "mt-2 text-sm text-muted-foreground",
							"data-tsd-source": "/src/components/AppErrorBoundary.tsx:54:13",
							children: this.props.fallbackMessage ?? "We encountered a temporary issue loading this view. Please refresh the page or return to the home screen."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 54,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-6 flex flex-wrap justify-center gap-3",
							"data-tsd-source": "/src/components/AppErrorBoundary.tsx:58:13",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: this.handleReset,
								className: "inline-flex items-center justify-center rounded-xl bg-foreground px-4 py-2.5 text-xs font-bold text-background transition hover:opacity-90",
								"data-tsd-source": "/src/components/AppErrorBoundary.tsx:59:15",
								children: "Refresh page"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 59,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("a", {
								href: "/",
								className: "inline-flex items-center justify-center rounded-xl border border-border bg-background px-4 py-2.5 text-xs font-bold text-foreground transition hover:bg-secondary",
								"data-tsd-source": "/src/components/AppErrorBoundary.tsx:66:15",
								children: "Go home"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 66,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 58,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 9
			}, this);
		}
		return this.props.children;
	}
}
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AppErrorBoundary.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/AppErrorBoundary.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/AppErrorBoundary.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTs7Ozs7Ozs7QUFpQkEsZ0RBR0E7Q0FDQTtFQUNBO0VBQ0E7Q0FDQTtDQUVBO0VBQ0E7Q0FDQTtDQUVBO0VBQ0E7Q0FDQTtDQUVBO0VBQ0E7RUFDQTtHQUNBO0VBQ0E7Q0FDQTtDQUVBO0VBQ0E7R0FDQSxPQUNBO0lBQ0E7SUFDQTtJQUNBO2NBQ0E7S0FBQTtLQUFBO2VBQUE7TUFDQTtPQUFBO09BQUE7aUJBQ0E7TUFDQTs7Ozs7TUFDQTtPQUFBO09BQUE7aUJBQ0EsOEJBQ0E7TUFDQTs7Ozs7TUFDQTtPQUFBO09BQUE7aUJBQUEsQ0FDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO2tCQUFjO09BRWQ7Ozs7aUJBQ0E7UUFDQTtRQUNBO1FBQ0E7a0JBQWM7T0FFZDs7OztlQUNBOzs7Ozs7S0FDQTs7Ozs7O0dBQ0E7Ozs7O0VBRUE7RUFFQTtDQUNBO0FBQ0EiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFwcEVycm9yQm91bmRhcnkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgdHlwZSBFcnJvckluZm8sIHR5cGUgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyByZXBvcnRBcHBsaWNhdGlvbkVycm9yIH0gZnJvbSBcIkAvbGliL2Vycm9yLXJlcG9ydGluZ1wiO1xuXG5pbnRlcmZhY2UgQXBwRXJyb3JCb3VuZGFyeVByb3BzIHtcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcbiAgZmFsbGJhY2tUaXRsZT86IHN0cmluZztcbiAgZmFsbGJhY2tNZXNzYWdlPzogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgQXBwRXJyb3JCb3VuZGFyeVN0YXRlIHtcbiAgaGFzRXJyb3I6IGJvb2xlYW47XG59XG5cbi8qKlxuICogR2xvYmFsIFJlYWN0IEVycm9yIEJvdW5kYXJ5IHRoYXQgY2F0Y2hlcyByZW5kZXIgYW5kIGxpZmVjeWNsZSBlcnJvcnNcbiAqIGFuZCByZW5kZXJzIGEgY2xlYW4sIGdlbmVyaWMgZmFsbGJhY2sgVUkgd2l0aG91dCBsZWFraW5nIHJhdyBzdGFjayB0cmFjZXNcbiAqIG9yIGludGVybmFsIGNvbXBvbmVudCBuYW1lcy5cbiAqL1xuZXhwb3J0IGNsYXNzIEFwcEVycm9yQm91bmRhcnkgZXh0ZW5kcyBDb21wb25lbnQ8XG4gIEFwcEVycm9yQm91bmRhcnlQcm9wcyxcbiAgQXBwRXJyb3JCb3VuZGFyeVN0YXRlXG4+IHtcbiAgY29uc3RydWN0b3IocHJvcHM6IEFwcEVycm9yQm91bmRhcnlQcm9wcykge1xuICAgIHN1cGVyKHByb3BzKTtcbiAgICB0aGlzLnN0YXRlID0geyBoYXNFcnJvcjogZmFsc2UgfTtcbiAgfVxuXG4gIHN0YXRpYyBnZXREZXJpdmVkU3RhdGVGcm9tRXJyb3IoKTogQXBwRXJyb3JCb3VuZGFyeVN0YXRlIHtcbiAgICByZXR1cm4geyBoYXNFcnJvcjogdHJ1ZSB9O1xuICB9XG5cbiAgY29tcG9uZW50RGlkQ2F0Y2goZXJyb3I6IEVycm9yLCBfZXJyb3JJbmZvOiBFcnJvckluZm8pOiB2b2lkIHtcbiAgICByZXBvcnRBcHBsaWNhdGlvbkVycm9yKGVycm9yLCB7IGJvdW5kYXJ5OiBcImFwcF9lcnJvcl9ib3VuZGFyeVwiIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBoYW5kbGVSZXNldCA9ICgpID0+IHtcbiAgICB0aGlzLnNldFN0YXRlKHsgaGFzRXJyb3I6IGZhbHNlIH0pO1xuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XG4gICAgfVxuICB9O1xuXG4gIHJlbmRlcigpIHtcbiAgICBpZiAodGhpcy5zdGF0ZS5oYXNFcnJvcikge1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgPGRpdlxuICAgICAgICAgIHJvbGU9XCJhbGVydFwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW4gaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJhY2tncm91bmQgcHgtNCBweS0xMlwiXG4gICAgICAgID5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1tZCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1jYXJkIHAtOCB0ZXh0LWNlbnRlciBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC14bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgIHt0aGlzLnByb3BzLmZhbGxiYWNrVGl0bGUgPz8gXCJTb21ldGhpbmcgd2VudCB3cm9uZywgcGxlYXNlIHJlZnJlc2hcIn1cbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgIHt0aGlzLnByb3BzLmZhbGxiYWNrTWVzc2FnZSA/P1xuICAgICAgICAgICAgICAgIFwiV2UgZW5jb3VudGVyZWQgYSB0ZW1wb3JhcnkgaXNzdWUgbG9hZGluZyB0aGlzIHZpZXcuIFBsZWFzZSByZWZyZXNoIHRoZSBwYWdlIG9yIHJldHVybiB0byB0aGUgaG9tZSBzY3JlZW4uXCJ9XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgZmxleCBmbGV4LXdyYXAganVzdGlmeS1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RoaXMuaGFuZGxlUmVzZXR9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYmctZm9yZWdyb3VuZCBweC00IHB5LTIuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWJhY2tncm91bmQgdHJhbnNpdGlvbiBob3ZlcjpvcGFjaXR5LTkwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIFJlZnJlc2ggcGFnZVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICBocmVmPVwiL1wiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctYmFja2dyb3VuZCBweC00IHB5LTIuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWZvcmVncm91bmQgdHJhbnNpdGlvbiBob3ZlcjpiZy1zZWNvbmRhcnlcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgR28gaG9tZVxuICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiB0aGlzLnByb3BzLmNoaWxkcmVuO1xuICB9XG59XG4iXSwiZmlsZSI6Ii9hcHAvYXBwbGV0L3NyYy9jb21wb25lbnRzL0FwcEVycm9yQm91bmRhcnkudHN4In0=