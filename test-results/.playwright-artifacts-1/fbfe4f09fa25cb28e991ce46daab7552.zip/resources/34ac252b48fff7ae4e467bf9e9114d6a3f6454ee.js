import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ProductionMonitoring.tsx");const useEffect = __vite__cjsImport0_react["useEffect"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { installSentryBridge, reportApplicationError } from "/src/lib/error-reporting.ts";
var _s = $RefreshSig$();
export function ProductionMonitoring() {
	_s();
	useEffect(() => {
		const sentry = window.Sentry;
		if (sentry?.captureException) installSentryBridge({ captureException: sentry.captureException.bind(sentry) });
		const onError = (event) => {
			// Resource-load events are plain Events with `isTrusted`, not application errors.
			// Reporting them as exceptions produces the unhelpful {"isTrusted":true} preview error.
			if (!(event.error instanceof Error) && !event.message) return;
			reportApplicationError(event.error ?? new Error(event.message), {
				mechanism: "window_error",
				filename: event.filename,
				line: event.lineno
			});
		};
		const onRejection = (event) => {
			reportApplicationError(event.reason, { mechanism: "unhandledrejection" });
		};
		window.addEventListener("error", onError);
		window.addEventListener("unhandledrejection", onRejection);
		return () => {
			window.removeEventListener("error", onError);
			window.removeEventListener("unhandledrejection", onRejection);
		};
	}, []);
	return null;
}
_s(ProductionMonitoring, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = ProductionMonitoring;
var _c;
$RefreshReg$(_c, "ProductionMonitoring");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ProductionMonitoring.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/ProductionMonitoring.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/ProductionMonitoring.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/ProductionMonitoring.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxxQkFBcUIsOEJBQThCOztBQUU1RCxPQUFPLFNBQVMsdUJBQXVCOztDQUNyQyxnQkFBZ0I7RUFDZCxNQUFNLFNBQ0osT0FHQTtFQUNGLElBQUksUUFBUSxrQkFDVixvQkFBb0IsRUFBRSxrQkFBa0IsT0FBTyxpQkFBaUIsS0FBSyxNQUFNLEVBQUUsQ0FBQztFQUVoRixNQUFNLFdBQVcsVUFBc0I7OztHQUdyQyxJQUFJLEVBQUUsTUFBTSxpQkFBaUIsVUFBVSxDQUFDLE1BQU0sU0FBUztHQUN2RCx1QkFBdUIsTUFBTSxTQUFTLElBQUksTUFBTSxNQUFNLE9BQU8sR0FBRztJQUM5RCxXQUFXO0lBQ1gsVUFBVSxNQUFNO0lBQ2hCLE1BQU0sTUFBTTtHQUNkLENBQUM7RUFDSDtFQUNBLE1BQU0sZUFBZSxVQUFpQztHQUNwRCx1QkFBdUIsTUFBTSxRQUFRLEVBQUUsV0FBVyxxQkFBcUIsQ0FBQztFQUMxRTtFQUNBLE9BQU8saUJBQWlCLFNBQVMsT0FBTztFQUN4QyxPQUFPLGlCQUFpQixzQkFBc0IsV0FBVztFQUN6RCxhQUFhO0dBQ1gsT0FBTyxvQkFBb0IsU0FBUyxPQUFPO0dBQzNDLE9BQU8sb0JBQW9CLHNCQUFzQixXQUFXO0VBQzlEO0NBQ0YsR0FBRyxDQUFDLENBQUM7Q0FFTCxPQUFPO0FBQ1QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvZHVjdGlvbk1vbml0b3JpbmcudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaW5zdGFsbFNlbnRyeUJyaWRnZSwgcmVwb3J0QXBwbGljYXRpb25FcnJvciB9IGZyb20gXCJAL2xpYi9lcnJvci1yZXBvcnRpbmdcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIFByb2R1Y3Rpb25Nb25pdG9yaW5nKCkge1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHNlbnRyeSA9IChcbiAgICAgIHdpbmRvdyBhcyBXaW5kb3cgJiB7XG4gICAgICAgIFNlbnRyeT86IHsgY2FwdHVyZUV4Y2VwdGlvbj86IChlcnJvcjogdW5rbm93biwgY29udGV4dD86IFJlY29yZDxzdHJpbmcsIHVua25vd24+KSA9PiB2b2lkIH07XG4gICAgICB9XG4gICAgKS5TZW50cnk7XG4gICAgaWYgKHNlbnRyeT8uY2FwdHVyZUV4Y2VwdGlvbilcbiAgICAgIGluc3RhbGxTZW50cnlCcmlkZ2UoeyBjYXB0dXJlRXhjZXB0aW9uOiBzZW50cnkuY2FwdHVyZUV4Y2VwdGlvbi5iaW5kKHNlbnRyeSkgfSk7XG5cbiAgICBjb25zdCBvbkVycm9yID0gKGV2ZW50OiBFcnJvckV2ZW50KSA9PiB7XG4gICAgICAvLyBSZXNvdXJjZS1sb2FkIGV2ZW50cyBhcmUgcGxhaW4gRXZlbnRzIHdpdGggYGlzVHJ1c3RlZGAsIG5vdCBhcHBsaWNhdGlvbiBlcnJvcnMuXG4gICAgICAvLyBSZXBvcnRpbmcgdGhlbSBhcyBleGNlcHRpb25zIHByb2R1Y2VzIHRoZSB1bmhlbHBmdWwge1wiaXNUcnVzdGVkXCI6dHJ1ZX0gcHJldmlldyBlcnJvci5cbiAgICAgIGlmICghKGV2ZW50LmVycm9yIGluc3RhbmNlb2YgRXJyb3IpICYmICFldmVudC5tZXNzYWdlKSByZXR1cm47XG4gICAgICByZXBvcnRBcHBsaWNhdGlvbkVycm9yKGV2ZW50LmVycm9yID8/IG5ldyBFcnJvcihldmVudC5tZXNzYWdlKSwge1xuICAgICAgICBtZWNoYW5pc206IFwid2luZG93X2Vycm9yXCIsXG4gICAgICAgIGZpbGVuYW1lOiBldmVudC5maWxlbmFtZSxcbiAgICAgICAgbGluZTogZXZlbnQubGluZW5vLFxuICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCBvblJlamVjdGlvbiA9IChldmVudDogUHJvbWlzZVJlamVjdGlvbkV2ZW50KSA9PiB7XG4gICAgICByZXBvcnRBcHBsaWNhdGlvbkVycm9yKGV2ZW50LnJlYXNvbiwgeyBtZWNoYW5pc206IFwidW5oYW5kbGVkcmVqZWN0aW9uXCIgfSk7XG4gICAgfTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImVycm9yXCIsIG9uRXJyb3IpO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwidW5oYW5kbGVkcmVqZWN0aW9uXCIsIG9uUmVqZWN0aW9uKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJlcnJvclwiLCBvbkVycm9yKTtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwidW5oYW5kbGVkcmVqZWN0aW9uXCIsIG9uUmVqZWN0aW9uKTtcbiAgICB9O1xuICB9LCBbXSk7XG5cbiAgcmV0dXJuIG51bGw7XG59XG4iXX0=