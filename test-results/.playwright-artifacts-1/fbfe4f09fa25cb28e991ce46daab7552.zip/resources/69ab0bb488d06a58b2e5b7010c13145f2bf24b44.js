/**
* Accurate Country -> 1–2+ Flagship Native Languages Directory
* Allows users & brands to pick a country and immediately switch into its authentic local language(s).
*/
export const COUNTRY_LANGUAGE_DIRECTORY = [
	{
		countryCode: "ZA",
		countryName: "South Africa",
		flag: "🇿🇦",
		languages: [
			{
				code: "zu",
				nativeName: "isiZulu",
				englishName: "Zulu"
			},
			{
				code: "xh",
				nativeName: "isiXhosa",
				englishName: "Xhosa"
			},
			{
				code: "af",
				nativeName: "Afrikaans",
				englishName: "Afrikaans"
			},
			{
				code: "st",
				nativeName: "Sesotho",
				englishName: "Sesotho"
			},
			{
				code: "tn",
				nativeName: "Setswana",
				englishName: "Setswana"
			},
			{
				code: "nso",
				nativeName: "Sepedi",
				englishName: "Sepedi"
			},
			{
				code: "en",
				nativeName: "English",
				englishName: "English"
			}
		]
	},
	{
		countryCode: "NG",
		countryName: "Nigeria",
		flag: "🇳🇬",
		languages: [
			{
				code: "ha",
				nativeName: "Hausa",
				englishName: "Hausa"
			},
			{
				code: "yo",
				nativeName: "Yorùbá",
				englishName: "Yoruba"
			},
			{
				code: "ig",
				nativeName: "Igbo",
				englishName: "Igbo"
			},
			{
				code: "en",
				nativeName: "English",
				englishName: "English"
			}
		]
	},
	{
		countryCode: "KE",
		countryName: "Kenya & Tanzania",
		flag: "🇰🇪",
		languages: [{
			code: "sw",
			nativeName: "Kiswahili",
			englishName: "Swahili"
		}, {
			code: "en",
			nativeName: "English",
			englishName: "English"
		}]
	},
	{
		countryCode: "ET",
		countryName: "Ethiopia",
		flag: "🇪🇹",
		languages: [{
			code: "am",
			nativeName: "አማርኛ",
			englishName: "Amharic"
		}, {
			code: "en",
			nativeName: "English",
			englishName: "English"
		}]
	},
	{
		countryCode: "BW",
		countryName: "Botswana & Lesotho",
		flag: "🇧🇼",
		languages: [{
			code: "tn",
			nativeName: "Setswana",
			englishName: "Setswana"
		}, {
			code: "st",
			nativeName: "Sesotho",
			englishName: "Sesotho"
		}]
	},
	{
		countryCode: "EG",
		countryName: "Egypt, UAE & Saudi Arabia",
		flag: "🇪🇬",
		languages: [{
			code: "ar",
			nativeName: "العربية",
			englishName: "Arabic"
		}, {
			code: "en",
			nativeName: "English",
			englishName: "English"
		}]
	},
	{
		countryCode: "FR",
		countryName: "France, Senegal & Côte d'Ivoire",
		flag: "🇫🇷",
		languages: [{
			code: "fr",
			nativeName: "Français",
			englishName: "French"
		}, {
			code: "en",
			nativeName: "English",
			englishName: "English"
		}]
	},
	{
		countryCode: "BR",
		countryName: "Brazil, Portugal, Angola & Mozambique",
		flag: "🇧🇷",
		languages: [{
			code: "pt",
			nativeName: "Português",
			englishName: "Portuguese"
		}, {
			code: "en",
			nativeName: "English",
			englishName: "English"
		}]
	},
	{
		countryCode: "ES",
		countryName: "Spain, Mexico & Latin America",
		flag: "🇪🇸",
		languages: [{
			code: "es",
			nativeName: "Español",
			englishName: "Spanish"
		}, {
			code: "en",
			nativeName: "English",
			englishName: "English"
		}]
	},
	{
		countryCode: "DE",
		countryName: "Germany, Austria & Switzerland",
		flag: "🇩🇪",
		languages: [{
			code: "de",
			nativeName: "Deutsch",
			englishName: "German"
		}, {
			code: "fr",
			nativeName: "Français",
			englishName: "French"
		}]
	},
	{
		countryCode: "NL",
		countryName: "Netherlands & Belgium",
		flag: "🇳🇱",
		languages: [{
			code: "nl",
			nativeName: "Nederlands",
			englishName: "Dutch"
		}, {
			code: "fr",
			nativeName: "Français",
			englishName: "French"
		}]
	},
	{
		countryCode: "IT",
		countryName: "Italy",
		flag: "🇮🇹",
		languages: [{
			code: "it",
			nativeName: "Italiano",
			englishName: "Italian"
		}, {
			code: "en",
			nativeName: "English",
			englishName: "English"
		}]
	},
	{
		countryCode: "IN",
		countryName: "India",
		flag: "🇮🇳",
		languages: [
			{
				code: "hi",
				nativeName: "हिन्दी",
				englishName: "Hindi"
			},
			{
				code: "ta",
				nativeName: "தமிழ்",
				englishName: "Tamil"
			},
			{
				code: "bn",
				nativeName: "বাংলা",
				englishName: "Bengali"
			}
		]
	},
	{
		countryCode: "CN",
		countryName: "China, Taiwan & Singapore",
		flag: "🇨🇳",
		languages: [{
			code: "zh-CN",
			nativeName: "简体中文",
			englishName: "Simplified Chinese"
		}, {
			code: "zh-TW",
			nativeName: "繁體中文",
			englishName: "Traditional Chinese"
		}]
	},
	{
		countryCode: "JP",
		countryName: "Japan",
		flag: "🇯🇵",
		languages: [{
			code: "ja",
			nativeName: "日本語",
			englishName: "Japanese"
		}, {
			code: "en",
			nativeName: "English",
			englishName: "English"
		}]
	},
	{
		countryCode: "KR",
		countryName: "South Korea",
		flag: "🇰🇷",
		languages: [{
			code: "ko",
			nativeName: "한국어",
			englishName: "Korean"
		}, {
			code: "en",
			nativeName: "English",
			englishName: "English"
		}]
	},
	{
		countryCode: "TR",
		countryName: "Turkey",
		flag: "🇹🇷",
		languages: [{
			code: "tr",
			nativeName: "Türkçe",
			englishName: "Turkish"
		}, {
			code: "en",
			nativeName: "English",
			englishName: "English"
		}]
	},
	{
		countryCode: "PL",
		countryName: "Poland & Eastern Europe",
		flag: "🇵🇱",
		languages: [{
			code: "pl",
			nativeName: "Polski",
			englishName: "Polish"
		}, {
			code: "uk",
			nativeName: "Українська",
			englishName: "Ukrainian"
		}]
	}
];
/**
* Rich Native Hero & Feed bundles for major country flagship languages
* so switching to Afrikaans, Setswana, Sepedi, Kiswahili, Hausa, Yoruba, Igbo,
* Amharic, Arabic, Hindi, Chinese, Japanese, Korean, Italian, Dutch, Turkish, etc.
* translates the entire Home Hero, Zwepe Coin, Randy Trash Can, Feed, and Navbar.
*/
export const COUNTRY_FLAGSHIP_APP_BUNDLES = {
	af: {
		nav: {
			home: "Tuis",
			feed: "Stroom",
			scan: "Skandeer",
			brands: "Handelsmerke",
			awards: "Toekennings",
			dashboard: "Beheerpaneel",
			profile: "Profiel",
			messages: "Boodskappe",
			signIn: "Meld aan",
			signUp: "Registreer",
			signOut: "Meld af"
		},
		hero: {
			badge: "Die Handelsmerk-Barometer",
			headlineBlack: "Hou wat jou dien.",
			headlineGold: "Daag uit wat nie werk nie.",
			subtitle: "Stem Bêre (Stash) of Weggooi (Trash) oor jou ware handelsmerk-ervarings — die CX- & PR-sein wat tel.",
			tagline: "Elke uitspraak bring handelsmerke nader aan die mense wat hulle dien. Gee joune. 🔥",
			spinningZwepe: "Draai tans Zwepe-munt... kyk hoe dit tol en plat val!",
			droppingBin: "Val in die asblik... kletter en klap!",
			tapCoin: "Tik op die Goue Munt om Stashes te sien",
			tapBin: "Tik op die Asblik om Trashes te sien",
			allTiers: "Alle vlakke",
			superBrands: "Superhandelsmerke",
			nationalPowerhouses: "Nasionale Reuse",
			emergingChallengers: "Opkomende Uitdagers",
			localHeroes: "Plaaslike Helde",
			sortBy: "Sorteer volgens",
			trustScore: "Vertrouenspunt",
			brandTier: "Handelsmerkvlak",
			alphabetical: "Alfabeties",
			liveSentiment: "Lewendige Sentiment Oor Handelsmerke",
			liveSentimentDesc: "Ware verbruikersuitsprake wat vertrouenspunte intyds vorm.",
			searchOrBrowse: "Soek handelsmerke of blaai hieronder",
			gettingStashed: "Wat gebêre word (Stashed)",
			gettingTrashed: "Wat weggegooi word (Trashed)",
			sotAwards: "Die SOT-Toekennings",
			crowningBrand: "Bekroon die jaar se mees betroubare handelsmerk",
			seeStandings: "Sien lewendige ranglys",
			prTeamClaim: "PR- & Handelsmerkspanne: Eis jou bladsy",
			prTeamDesc: "Monitor sentiment, reageer op kliënte en verdien geverifieerde status.",
			goToDashboard: "Gaan na Beheerpaneel",
			joinConversation: "Sluit aan by die gesprek",
			realPeopleVerdicts: "Ware mense. Ware uitsprake. Nul betaalmure.",
			exploreFeed: "Verken Stroom",
			scanProduct: "Skandeer Produk",
			stashes: "Bêre (Stashes)",
			trashes: "Weggooi (Trashes)"
		},
		feed: {
			pulse: "Gemeenskapspols",
			title: "Stash Or Trash",
			subtitle: "Die Handelsmerk-Barometer. Plaas enigiets oor 'n handelsmerk en laat die gemeenskap intyds besluit.",
			hook: "Elke uitspraak bring handelsmerke nader aan hul mense.",
			searchPlaceholder: "Soek plasings of handelsmerke",
			allVerdicts: "Alle uitsprake",
			stashesOfDay: "Stashes van die Dag",
			trashesOfDay: "Trashes van die Dag",
			resetFilter: "Herstel filter"
		}
	},
	tn: {
		nav: {
			home: "Gae",
			feed: "Ditiro",
			scan: "Sekena",
			brands: "Mabokgoni",
			awards: "Dikhumagadi",
			dashboard: "Letlapa la Taolo",
			profile: "Poeletso",
			messages: "Melaetsa",
			signIn: "Tsena",
			signUp: "Ikwadise",
			signOut: "Tswa"
		},
		hero: {
			badge: "Sekala sa Tshepo ya Mabokgoni",
			headlineBlack: "Boloka se se go direlang.",
			headlineGold: "Kgalemela se se sa direng.",
			subtitle: "Tlhopha Boloka (Stash) kgotsa Latlha (Trash) ka maitemogelo a gago a nnete — lentswe la bareki le le botlhokwa.",
			tagline: "Katlholo nngwe le nngwe e atametsa mabokgoni kwa bathong. Ntsha ya gago. 🔥",
			tapCoin: "Tobetsa Ledi la Gauta go bona tse di Bolokilweng",
			tapBin: "Tobetsa Moteme wa Matlakala go bona tse di Latlhilweng",
			trustScore: "Tekanyetso ya Tshepo",
			liveSentiment: "Maikutlo a Setšhaba ka Nako ya Nnete",
			liveSentimentDesc: "Dikatlholo tsa bareki ba nnete tse di agang tshepo ya mabokgoni.",
			gettingStashed: "Tse di Bolokwang (Stashed)",
			gettingTrashed: "Tse di Latlhwang (Trashed)",
			sotAwards: "Dikhumagadi tsa SOT",
			goToDashboard: "Ya kwa Letlapeng la Kgwebo",
			exploreFeed: "Lebelela Ditiro",
			scanProduct: "Sekena Khoutu ya Sehlahiswa",
			stashes: "Boloka (Stashes)",
			trashes: "Latlha (Trashes)"
		}
	},
	nso: {
		nav: {
			home: "Gae",
			feed: "Dikagare",
			scan: "Sekena",
			brands: "Mabrande",
			awards: "Difoka",
			dashboard: "Dashboto",
			profile: "Boitsebišo",
			messages: "Melaetsa",
			signIn: "Tsena",
			signUp: "Ingwadiše",
			signOut: "Tšwa"
		},
		hero: {
			badge: "Sekala sa Tshepo ya Mabrande",
			headlineBlack: "Boloka seo se go thušago.",
			headlineGold: "Ganana le seo se sa šomego.",
			subtitle: "Kgetha Boloka (Stash) goba Lahla (Trash) go ya ka maitemogelo a gago a nnete le mabrande.",
			tagline: "Kahlolo ye nngwe le ye nngwe e batametša mabrande bathong. Neela ya gago. 🔥",
			tapCoin: "Kgwatha Tšhelete ya Gauta go bona tše Bolokilwego",
			tapBin: "Kgwatha Motomo wa Ditšhila go bona tše Lahlilwego",
			trustScore: "Tekanyetšo ya Tshepo",
			liveSentiment: "Maikutlo a Setšhaba Semeetseng",
			gettingStashed: "Tše di Bolokwago (Stashed)",
			gettingTrashed: "Tše di Lahlwago (Trashed)",
			sotAwards: "Difoka tša SOT",
			goToDashboard: "Ya go Dashboto",
			exploreFeed: "Lekola Dikagare",
			scanProduct: "Sekena Setšweletšwa",
			stashes: "Boloka (Stashes)",
			trashes: "Lahla (Trashes)"
		}
	},
	sw: {
		nav: {
			home: "Nyumbani",
			feed: "Mlisho",
			scan: "Changanua",
			brands: "Chapa",
			awards: "Tuzo",
			dashboard: "Dashibodi",
			profile: "Wasifu",
			messages: "Ujumbe",
			signIn: "Ingia",
			signUp: "Jisajili",
			signOut: "Toka"
		},
		hero: {
			badge: "Kipima Joto cha Chapa",
			headlineBlack: "Tunza kinachokufaa.",
			headlineGold: "Pinga kisichokufaa.",
			subtitle: "Piga kura ya Hifadhi (Stash) au Tupa (Trash) kuhusu uzoefu wako halisi wa chapa — sauti ya wateja inayojenga uaminifu.",
			tagline: "Kila uamuzi huleta chapa karibu na watu wanaowahudumia. Toa uamuzi wako. 🔥",
			tapCoin: "Gusa Sarafu ya Dhahabu kuona Zilizohifadhiwa",
			tapBin: "Gusa Pipani kuona Zilizotupwa",
			trustScore: "Alama ya Uaminifu",
			liveSentiment: "Hisia za Moja kwa Moja za Wateja",
			liveSentimentDesc: "Maamuzi halisi ya watumiaji yanayounda alama za uaminifu moja kwa moja.",
			gettingStashed: "Zinazohifadhiwa Zaidi",
			gettingTrashed: "Zinazotupwa Zaidi",
			sotAwards: "Tuzo za SOT",
			goToDashboard: "Nenda kwenye Dashibodi",
			exploreFeed: "Chunguza Mlisho",
			scanProduct: "Changanua Bidhaa",
			stashes: "Hifadhi (Stashes)",
			trashes: "Tupa (Trashes)"
		}
	},
	ha: {
		nav: {
			home: "Gida",
			feed: "Labarai",
			scan: "Bincika",
			brands: "Kamfanoni",
			awards: "Kyaututtuka",
			dashboard: "Allon Sarauta",
			profile: "Bayanai",
			messages: "Saƙonni",
			signIn: "Shiga",
			signUp: "Yi Rajista",
			signOut: "Fita"
		},
		hero: {
			badge: "Ma'aunin Amincewar Kamfanoni",
			headlineBlack: "Ajiye abin da ke amfanar ka.",
			headlineGold: "Ƙalubalanci abin da ba ya amfani.",
			subtitle: "Zaɓi Ajiye (Stash) ko Zubar (Trash) bisa gaskiyar mu'amalarka da kamfanoni a yau.",
			tagline: "Kowane hukunci yana kusantar da kamfanoni ga jama'a. Bayar da naka. 🔥",
			tapCoin: "Danna Kuɗin Zinariya don ganin Ajiyayyu",
			tapBin: "Danna Kwandon Shara don ganin Zubarwa",
			trustScore: "Makin Amana",
			liveSentiment: "Ra'ayin Jama'a Kai Tsaye",
			gettingStashed: "Abubuwan da ake Ajiyewa",
			gettingTrashed: "Abubuwan da ake Zubarwa",
			sotAwards: "Kyaututtukan SOT",
			goToDashboard: "Je zuwa Allon Kamfani",
			exploreFeed: "Duba Labarai",
			scanProduct: "Bincika Lambar Kaya",
			stashes: "Ajiye (Stashes)",
			trashes: "Zubar (Trashes)"
		}
	},
	yo: {
		nav: {
			home: "Ilé",
			feed: "Àfikún",
			scan: "Ṣàyẹ̀wò",
			brands: "Àwọn Ilé-iṣẹ́",
			awards: "Àwọn Àmì-ẹ̀yẹ",
			dashboard: "Pẹpẹ Iṣẹ́",
			profile: "Profaili",
			messages: "Àwọn Ifiranṣẹ",
			signIn: "Wọlé",
			signUp: "Forúkọsílẹ̀",
			signOut: "Jáde"
		},
		hero: {
			badge: "Iwọn Ìgbẹ́kẹ̀lé Àwọn Ilé-iṣẹ́",
			headlineBlack: "Tọ́jú ohun tí óטי wúlò fún ọ.",
			headlineGold: "Kọ ohun tí kò bá ọ mu.",
			subtitle: "Dìbò Tọ́jú (Stash) tàbí Dà nù (Trash) lórí ìrírí rẹ gidi pẹ̀lú àwọn ilé-iṣẹ́.",
			tagline: "Gbogbo ìdájọ́ ló ń mú ilé-iṣẹ́ sún mọ́ àwọn ènìyàn. Sọ tìrẹ. 🔥",
			tapCoin: "Tẹ Owó Wúrà láti rí Àwọn Tí A Tọ́jú",
			tapBin: "Tẹ Apẹ̀rẹ̀ Ìdọ̀tí láti rí Àwọn Tí A Dà Nù",
			trustScore: "Iye Ìgbẹ́kẹ̀lé",
			liveSentiment: "Èrò Àwọn Ènìyàn Lọ́wọ́lọ́wọ́",
			gettingStashed: "Ohun Tí Àwọn Ènìyàn Ń Tọ́jú",
			gettingTrashed: "Ohun Tí Àwọn Ènìyàn Ń Dà Nù",
			sotAwards: "Àwọn Àmì-ẹ̀yẹ SOT",
			goToDashboard: "Lọ sí Pẹpẹ Ilé-iṣẹ́",
			exploreFeed: "Wo Àfikún",
			scanProduct: "Ṣàyẹ̀wò Ọjà",
			stashes: "Tọ́jú (Stashes)",
			trashes: "Dà nù (Trashes)"
		}
	},
	ig: {
		nav: {
			home: "Ụlọ",
			feed: "Ihe ọhụrụ",
			scan: "Nyochaa",
			brands: "Ụdị Ngwaahịa",
			awards: "Ihe nrite",
			dashboard: "Mpempe Nlekọta",
			profile: "Profaịlụ",
			messages: "Ozi",
			signIn: "Banye",
			signUp: "Debanye aha",
			signOut: "Pụọ"
		},
		hero: {
			badge: "Ọ̀tụ̀tụ̀ Ntụkwasị Obi Ụdị Ngwaahịa",
			headlineBlack: "Chekwaa ihe na-enyere gị aka.",
			headlineGold: "Jụ ihe na-adịghị mma.",
			subtitle: "ịtụ vootu Chekwaa (Stash) ma ọ bụ Tụfuo (Trash) maka ahụmịhe gị na ụdị ngwaahịa.",
			tagline: "Mkpebi ọ bụla na-eme ka ụlọ ọrụ bịaruo ndị mmadụ nso. Nye nke gị. 🔥",
			tapCoin: "Pịa Mkpụrụ Egoọlaedo ka ịhụ Nke Echekwara",
			tapBin: "Pịa Ngịga Ahịhịa ka ịhụ Nke Atụfuru",
			trustScore: "Akara Ntụkwasị Obi",
			liveSentiment: "echiche Ndị Mmadụ Ozugbo",
			gettingStashed: "Ihe Ndị A Na-echekwa",
			gettingTrashed: "Ihe Ndị A Na-atụfu",
			sotAwards: "Ihe Nrite SOT",
			goToDashboard: "Gaa na Mpempe Nlekọta",
			exploreFeed: "Chọpụta Ihe Ọhụrụ",
			scanProduct: "Nyochaa Ngwaahịa",
			stashes: "Chekwaa (Stashes)",
			trashes: "Tụfuo (Trashes)"
		}
	},
	am: {
		nav: {
			home: "መነሻ",
			feed: "ምግቦች",
			scan: "ቃኝ",
			brands: "ብራንዶች",
			awards: "ሽልማቶች",
			dashboard: "ዳሽቦርድ",
			profile: "መገለጫ",
			messages: "መልዕክቶች",
			signIn: "ግባ",
			signUp: "ይመዝገቡ",
			signOut: "ውጣ"
		},
		hero: {
			badge: "የብራንድ እምነት መለኪያ",
			headlineBlack: "የሚጠቅምዎትን ያስቀምጡ።",
			headlineGold: "የማይጠቅምዎትን ይቃወሙ።",
			subtitle: "በእውነተኛ የብራንድ ተሞክሮዎ ላይ አስቀምጥ (Stash) ወይም ጣለው (Trash) ብለው ድምጽ ይስጡ።",
			tagline: "እያንዳንዱ ውሳኔ ብራንዶችን ከሕዝቡ ጋር ያቀራርባል። የእርስዎን ይስጡ። 🔥",
			tapCoin: "የተቀመጡትን ለማየት የወርቅ ሳንቲሙን ይንኩ",
			tapBin: "የተጣሉትን ለማየት የቆሻሻ መጣያውን ይንኩ",
			trustScore: "የእምነት ነጥብ",
			liveSentiment: "የቀጥታ የደንበኞች ስሜት",
			gettingStashed: "በብዛት የተቀመጡ",
			gettingTrashed: "በብዛት የተጣሉ",
			sotAwards: "የSOT ሽልማቶች",
			goToDashboard: "ወደ ዳሽቦርድ ይሂዱ",
			exploreFeed: "ምግቦችን ያስሱ",
			scanProduct: "ምርት ይቃኙ",
			stashes: "አስቀምጥ (Stashes)",
			trashes: "ጣለው (Trashes)"
		}
	},
	ar: {
		nav: {
			home: "الرئيسية",
			feed: "المنشورات",
			scan: "مسح المنتج",
			brands: "العلامات التجارية",
			awards: "الجوائز",
			dashboard: "لوحة التحكم",
			profile: "الملف الشخصي",
			messages: "الرسائل",
			signIn: "تسجيل الدخول",
			signUp: "إنشاء حساب",
			signOut: "خروج"
		},
		hero: {
			badge: "مقياس ثقة العلامات التجارية",
			headlineBlack: "احتفظ بما يخدمك.",
			headlineGold: "تحدَّ ما لا يخدمك.",
			subtitle: "صوّت بـ احتفاظ (Stash) أو استبعاد (Trash) بناءً على تجربتك الحقيقية مع العلامات التجارية.",
			tagline: "كل حكم يقرّب العلامات التجارية من عملائها. أدلِ بصوتك الآن. 🔥",
			tapCoin: "اضغط على العملة الذهبية لعرض المحتفظ بها",
			tapBin: "اضغط على السلة لعرض المستبعدة",
			trustScore: "مؤشر الثقة",
			liveSentiment: "نبض المستهلكين المباشر",
			gettingStashed: "الأكثر احتفاظاً",
			gettingTrashed: "الأكثر استبعاداً",
			sotAwards: "جوائز SOT",
			goToDashboard: "انتقل إلى لوحة العلامة",
			exploreFeed: "تصفح المنشورات",
			scanProduct: "افحص باركود المنتج",
			stashes: "احتفاظ (Stash)",
			trashes: "استبعاد (Trash)"
		}
	},
	hi: {
		nav: {
			home: "होम",
			feed: "फ़ीड",
			scan: "स्कैन करें",
			brands: "ब्रांड्स",
			awards: "पुरस्कार",
			dashboard: "डैशबोर्ड",
			profile: "प्रोफ़ाइल",
			messages: "संदेश",
			signIn: "साइन इन",
			signUp: "साइन अप",
			signOut: "साइन आउट"
		},
		hero: {
			badge: "ब्रांड विश्वास बैरोमीटर",
			headlineBlack: "जो आपके काम आए उसे रखें।",
			headlineGold: "जो सही न हो उसे चुनौती दें।",
			subtitle: "अपने वास्तविक ब्रांड अनुभवों पर रखें (Stash) या हटाएं (Trash) में वोट करें।",
			tagline: "हर फैसला ब्रांड्स को लोगों के करीब लाता है। अपना फैसला दें। 🔥",
			tapCoin: "स्टैश देखने के लिए सोने के सिक्के पर टैप करें",
			tapBin: "ट्रैश देखने के लिए बिन पर टैप करें",
			trustScore: "विश्वास स्कोर",
			liveSentiment: "ब्रांड्स पर लाइव जनमत",
			gettingStashed: "जिन्हें सबसे ज़्यादा रखा जा रहा है",
			gettingTrashed: "जिन्हें सबसे ज़्यादा हटाया जा रहा है",
			sotAwards: "SOT पुरस्कार",
			goToDashboard: "डैशबोर्ड पर जाएं",
			exploreFeed: "फ़ीड देखें",
			scanProduct: "उत्पाद स्कैन करें",
			stashes: "रखें (Stashes)",
			trashes: "हटाएं (Trashes)"
		}
	},
	zh: {
		nav: {
			home: "首页",
			feed: "动态",
			scan: "扫码验真",
			brands: "品牌库",
			awards: "年度大奖",
			dashboard: "品牌控制台",
			profile: "个人主页",
			messages: "消息",
			signIn: "登录",
			signUp: "注册",
			signOut: "退出"
		},
		hero: {
			badge: "全球品牌信任晴雨表",
			headlineBlack: "保留值得信赖的好物。",
			headlineGold: "曝光名不副实的槽点。",
			subtitle: "根据您的真实消费体验投出 珍藏 (Stash) 或 吐槽 (Trash) — 最真实的客户体验信号。",
			tagline: "每一次真实裁决都让品牌更贴近消费者。立即投票！🔥",
			tapCoin: "点击金币查看珍藏榜",
			tapBin: "点击垃圾桶查看吐槽榜",
			trustScore: "信任指数",
			liveSentiment: "品牌实时口碑大盘",
			gettingStashed: "今日热门珍藏 (Stashed)",
			gettingTrashed: "今日热门吐槽 (Trashed)",
			sotAwards: "SOT 品牌大奖",
			goToDashboard: "进入品牌管理后台",
			exploreFeed: "浏览社区动态",
			scanProduct: "扫描商品条码验真",
			stashes: "珍藏 (Stashes)",
			trashes: "吐槽 (Trashes)"
		}
	},
	ja: {
		nav: {
			home: "ホーム",
			feed: "フィード",
			scan: "スキャン",
			brands: "ブランド",
			awards: "アワード",
			dashboard: "ダッシュボード",
			profile: "プロフィール",
			messages: "メッセージ",
			signIn: "ログイン",
			signUp: "新規登録",
			signOut: "ログアウト"
		},
		hero: {
			badge: "ブランド信頼バロメーター",
			headlineBlack: "価値あるものを残し、",
			headlineGold: "不誠実なものに声を上げよう。",
			subtitle: "実際のブランド体験に基づいて「キープ (Stash)」か「トラッシュ (Trash)」を投票しましょう。",
			tagline: "すべての評決がブランドと消費者を近づけます。あなたの一票を。🔥",
			tapCoin: "金貨をタップしてキープ一覧を表示",
			tapBin: "ゴミ箱をタップしてトラッシュ一覧を表示",
			trustScore: "信頼スコア",
			liveSentiment: "リアルタイム・ブランド評価",
			gettingStashed: "人気のキープ (Stashed)",
			gettingTrashed: "注目のトラッシュ (Trashed)",
			sotAwards: "SOT アワード",
			goToDashboard: "ダッシュボードへ",
			exploreFeed: "フィードを見る",
			scanProduct: "商品をスキャン",
			stashes: "キープ (Stashes)",
			trashes: "トラッシュ (Trashes)"
		}
	},
	ko: {
		nav: {
			home: "홈",
			feed: "피드",
			scan: "스캔",
			brands: "브랜드",
			awards: "어워드",
			dashboard: "대시보드",
			profile: "프로필",
			messages: "메시지",
			signIn: "로그인",
			signUp: "회원가입",
			signOut: "로그아웃"
		},
		hero: {
			badge: "브랜드 신뢰도 바로미터",
			headlineBlack: "가치 있는 브랜드는 간직하고,",
			headlineGold: "실망스러운 경험에는 목소리를 내세요.",
			subtitle: "실제 브랜드 경험을 바탕으로 보관(Stash) 또는 폐기(Trash)에 투표하세요.",
			tagline: "모든 평결이 브랜드를 소비자에게 더 가깝게 만듭니다. 🔥",
			tapCoin: "금화를 탭하여 보관(Stash) 보기",
			tapBin: "휴지통을 탭하여 폐기(Trash) 보기",
			trustScore: "신뢰 점수",
			liveSentiment: "실시간 브랜드 민심",
			gettingStashed: "인기 보관 브랜드",
			gettingTrashed: "집중 제보 브랜드",
			sotAwards: "SOT 어워드",
			goToDashboard: "브랜드 대시보드로 이동",
			exploreFeed: "피드 둘러보기",
			scanProduct: "바코드/정품 스캔",
			stashes: "보관 (Stashes)",
			trashes: "폐기 (Trashes)"
		}
	}
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQWVBLE9BQU8sTUFBTSw2QkFBdUQ7Q0FDbEU7RUFDRSxhQUFhO0VBQ2IsYUFBYTtFQUNiLE1BQU07RUFDTixXQUFXO0dBQ1Q7SUFBRSxNQUFNO0lBQU0sWUFBWTtJQUFXLGFBQWE7R0FBTztHQUN6RDtJQUFFLE1BQU07SUFBTSxZQUFZO0lBQVksYUFBYTtHQUFRO0dBQzNEO0lBQUUsTUFBTTtJQUFNLFlBQVk7SUFBYSxhQUFhO0dBQVk7R0FDaEU7SUFBRSxNQUFNO0lBQU0sWUFBWTtJQUFXLGFBQWE7R0FBVTtHQUM1RDtJQUFFLE1BQU07SUFBTSxZQUFZO0lBQVksYUFBYTtHQUFXO0dBQzlEO0lBQUUsTUFBTTtJQUFPLFlBQVk7SUFBVSxhQUFhO0dBQVM7R0FDM0Q7SUFBRSxNQUFNO0lBQU0sWUFBWTtJQUFXLGFBQWE7R0FBVTtFQUM5RDtDQUNGO0NBQ0E7RUFDRSxhQUFhO0VBQ2IsYUFBYTtFQUNiLE1BQU07RUFDTixXQUFXO0dBQ1Q7SUFBRSxNQUFNO0lBQU0sWUFBWTtJQUFTLGFBQWE7R0FBUTtHQUN4RDtJQUFFLE1BQU07SUFBTSxZQUFZO0lBQVUsYUFBYTtHQUFTO0dBQzFEO0lBQUUsTUFBTTtJQUFNLFlBQVk7SUFBUSxhQUFhO0dBQU87R0FDdEQ7SUFBRSxNQUFNO0lBQU0sWUFBWTtJQUFXLGFBQWE7R0FBVTtFQUM5RDtDQUNGO0NBQ0E7RUFDRSxhQUFhO0VBQ2IsYUFBYTtFQUNiLE1BQU07RUFDTixXQUFXLENBQ1Q7R0FBRSxNQUFNO0dBQU0sWUFBWTtHQUFhLGFBQWE7RUFBVSxHQUM5RDtHQUFFLE1BQU07R0FBTSxZQUFZO0dBQVcsYUFBYTtFQUFVLENBQzlEO0NBQ0Y7Q0FDQTtFQUNFLGFBQWE7RUFDYixhQUFhO0VBQ2IsTUFBTTtFQUNOLFdBQVcsQ0FDVDtHQUFFLE1BQU07R0FBTSxZQUFZO0dBQVEsYUFBYTtFQUFVLEdBQ3pEO0dBQUUsTUFBTTtHQUFNLFlBQVk7R0FBVyxhQUFhO0VBQVUsQ0FDOUQ7Q0FDRjtDQUNBO0VBQ0UsYUFBYTtFQUNiLGFBQWE7RUFDYixNQUFNO0VBQ04sV0FBVyxDQUNUO0dBQUUsTUFBTTtHQUFNLFlBQVk7R0FBWSxhQUFhO0VBQVcsR0FDOUQ7R0FBRSxNQUFNO0dBQU0sWUFBWTtHQUFXLGFBQWE7RUFBVSxDQUM5RDtDQUNGO0NBQ0E7RUFDRSxhQUFhO0VBQ2IsYUFBYTtFQUNiLE1BQU07RUFDTixXQUFXLENBQ1Q7R0FBRSxNQUFNO0dBQU0sWUFBWTtHQUFXLGFBQWE7RUFBUyxHQUMzRDtHQUFFLE1BQU07R0FBTSxZQUFZO0dBQVcsYUFBYTtFQUFVLENBQzlEO0NBQ0Y7Q0FDQTtFQUNFLGFBQWE7RUFDYixhQUFhO0VBQ2IsTUFBTTtFQUNOLFdBQVcsQ0FDVDtHQUFFLE1BQU07R0FBTSxZQUFZO0dBQVksYUFBYTtFQUFTLEdBQzVEO0dBQUUsTUFBTTtHQUFNLFlBQVk7R0FBVyxhQUFhO0VBQVUsQ0FDOUQ7Q0FDRjtDQUNBO0VBQ0UsYUFBYTtFQUNiLGFBQWE7RUFDYixNQUFNO0VBQ04sV0FBVyxDQUNUO0dBQUUsTUFBTTtHQUFNLFlBQVk7R0FBYSxhQUFhO0VBQWEsR0FDakU7R0FBRSxNQUFNO0dBQU0sWUFBWTtHQUFXLGFBQWE7RUFBVSxDQUM5RDtDQUNGO0NBQ0E7RUFDRSxhQUFhO0VBQ2IsYUFBYTtFQUNiLE1BQU07RUFDTixXQUFXLENBQ1Q7R0FBRSxNQUFNO0dBQU0sWUFBWTtHQUFXLGFBQWE7RUFBVSxHQUM1RDtHQUFFLE1BQU07R0FBTSxZQUFZO0dBQVcsYUFBYTtFQUFVLENBQzlEO0NBQ0Y7Q0FDQTtFQUNFLGFBQWE7RUFDYixhQUFhO0VBQ2IsTUFBTTtFQUNOLFdBQVcsQ0FDVDtHQUFFLE1BQU07R0FBTSxZQUFZO0dBQVcsYUFBYTtFQUFTLEdBQzNEO0dBQUUsTUFBTTtHQUFNLFlBQVk7R0FBWSxhQUFhO0VBQVMsQ0FDOUQ7Q0FDRjtDQUNBO0VBQ0UsYUFBYTtFQUNiLGFBQWE7RUFDYixNQUFNO0VBQ04sV0FBVyxDQUNUO0dBQUUsTUFBTTtHQUFNLFlBQVk7R0FBYyxhQUFhO0VBQVEsR0FDN0Q7R0FBRSxNQUFNO0dBQU0sWUFBWTtHQUFZLGFBQWE7RUFBUyxDQUM5RDtDQUNGO0NBQ0E7RUFDRSxhQUFhO0VBQ2IsYUFBYTtFQUNiLE1BQU07RUFDTixXQUFXLENBQ1Q7R0FBRSxNQUFNO0dBQU0sWUFBWTtHQUFZLGFBQWE7RUFBVSxHQUM3RDtHQUFFLE1BQU07R0FBTSxZQUFZO0dBQVcsYUFBYTtFQUFVLENBQzlEO0NBQ0Y7Q0FDQTtFQUNFLGFBQWE7RUFDYixhQUFhO0VBQ2IsTUFBTTtFQUNOLFdBQVc7R0FDVDtJQUFFLE1BQU07SUFBTSxZQUFZO0lBQVUsYUFBYTtHQUFRO0dBQ3pEO0lBQUUsTUFBTTtJQUFNLFlBQVk7SUFBUyxhQUFhO0dBQVE7R0FDeEQ7SUFBRSxNQUFNO0lBQU0sWUFBWTtJQUFTLGFBQWE7R0FBVTtFQUM1RDtDQUNGO0NBQ0E7RUFDRSxhQUFhO0VBQ2IsYUFBYTtFQUNiLE1BQU07RUFDTixXQUFXLENBQ1Q7R0FBRSxNQUFNO0dBQVMsWUFBWTtHQUFRLGFBQWE7RUFBcUIsR0FDdkU7R0FBRSxNQUFNO0dBQVMsWUFBWTtHQUFRLGFBQWE7RUFBc0IsQ0FDMUU7Q0FDRjtDQUNBO0VBQ0UsYUFBYTtFQUNiLGFBQWE7RUFDYixNQUFNO0VBQ04sV0FBVyxDQUNUO0dBQUUsTUFBTTtHQUFNLFlBQVk7R0FBTyxhQUFhO0VBQVcsR0FDekQ7R0FBRSxNQUFNO0dBQU0sWUFBWTtHQUFXLGFBQWE7RUFBVSxDQUM5RDtDQUNGO0NBQ0E7RUFDRSxhQUFhO0VBQ2IsYUFBYTtFQUNiLE1BQU07RUFDTixXQUFXLENBQ1Q7R0FBRSxNQUFNO0dBQU0sWUFBWTtHQUFPLGFBQWE7RUFBUyxHQUN2RDtHQUFFLE1BQU07R0FBTSxZQUFZO0dBQVcsYUFBYTtFQUFVLENBQzlEO0NBQ0Y7Q0FDQTtFQUNFLGFBQWE7RUFDYixhQUFhO0VBQ2IsTUFBTTtFQUNOLFdBQVcsQ0FDVDtHQUFFLE1BQU07R0FBTSxZQUFZO0dBQVUsYUFBYTtFQUFVLEdBQzNEO0dBQUUsTUFBTTtHQUFNLFlBQVk7R0FBVyxhQUFhO0VBQVUsQ0FDOUQ7Q0FDRjtDQUNBO0VBQ0UsYUFBYTtFQUNiLGFBQWE7RUFDYixNQUFNO0VBQ04sV0FBVyxDQUNUO0dBQUUsTUFBTTtHQUFNLFlBQVk7R0FBVSxhQUFhO0VBQVMsR0FDMUQ7R0FBRSxNQUFNO0dBQU0sWUFBWTtHQUFjLGFBQWE7RUFBWSxDQUNuRTtDQUNGO0FBQ0Y7Ozs7Ozs7QUFRQSxPQUFPLE1BQU0sK0JBT1Q7Q0FDRixJQUFJO0VBQ0YsS0FBSztHQUNILE1BQU07R0FDTixNQUFNO0dBQ04sTUFBTTtHQUNOLFFBQVE7R0FDUixRQUFRO0dBQ1IsV0FBVztHQUNYLFNBQVM7R0FDVCxVQUFVO0dBQ1YsUUFBUTtHQUNSLFFBQVE7R0FDUixTQUFTO0VBQ1g7RUFDQSxNQUFNO0dBQ0osT0FBTztHQUNQLGVBQWU7R0FDZixjQUFjO0dBQ2QsVUFBVTtHQUNWLFNBQVM7R0FDVCxlQUFlO0dBQ2YsYUFBYTtHQUNiLFNBQVM7R0FDVCxRQUFRO0dBQ1IsVUFBVTtHQUNWLGFBQWE7R0FDYixxQkFBcUI7R0FDckIscUJBQXFCO0dBQ3JCLGFBQWE7R0FDYixRQUFRO0dBQ1IsWUFBWTtHQUNaLFdBQVc7R0FDWCxjQUFjO0dBQ2QsZUFBZTtHQUNmLG1CQUFtQjtHQUNuQixnQkFBZ0I7R0FDaEIsZ0JBQWdCO0dBQ2hCLGdCQUFnQjtHQUNoQixXQUFXO0dBQ1gsZUFBZTtHQUNmLGNBQWM7R0FDZCxhQUFhO0dBQ2IsWUFBWTtHQUNaLGVBQWU7R0FDZixrQkFBa0I7R0FDbEIsb0JBQW9CO0dBQ3BCLGFBQWE7R0FDYixhQUFhO0dBQ2IsU0FBUztHQUNULFNBQVM7RUFDWDtFQUNBLE1BQU07R0FDSixPQUFPO0dBQ1AsT0FBTztHQUNQLFVBQVU7R0FDVixNQUFNO0dBQ04sbUJBQW1CO0dBQ25CLGFBQWE7R0FDYixjQUFjO0dBQ2QsY0FBYztHQUNkLGFBQWE7RUFDZjtDQUNGO0NBQ0EsSUFBSTtFQUNGLEtBQUs7R0FDSCxNQUFNO0dBQ04sTUFBTTtHQUNOLE1BQU07R0FDTixRQUFRO0dBQ1IsUUFBUTtHQUNSLFdBQVc7R0FDWCxTQUFTO0dBQ1QsVUFBVTtHQUNWLFFBQVE7R0FDUixRQUFRO0dBQ1IsU0FBUztFQUNYO0VBQ0EsTUFBTTtHQUNKLE9BQU87R0FDUCxlQUFlO0dBQ2YsY0FBYztHQUNkLFVBQVU7R0FDVixTQUFTO0dBQ1QsU0FBUztHQUNULFFBQVE7R0FDUixZQUFZO0dBQ1osZUFBZTtHQUNmLG1CQUFtQjtHQUNuQixnQkFBZ0I7R0FDaEIsZ0JBQWdCO0dBQ2hCLFdBQVc7R0FDWCxlQUFlO0dBQ2YsYUFBYTtHQUNiLGFBQWE7R0FDYixTQUFTO0dBQ1QsU0FBUztFQUNYO0NBQ0Y7Q0FDQSxLQUFLO0VBQ0gsS0FBSztHQUNILE1BQU07R0FDTixNQUFNO0dBQ04sTUFBTTtHQUNOLFFBQVE7R0FDUixRQUFRO0dBQ1IsV0FBVztHQUNYLFNBQVM7R0FDVCxVQUFVO0dBQ1YsUUFBUTtHQUNSLFFBQVE7R0FDUixTQUFTO0VBQ1g7RUFDQSxNQUFNO0dBQ0osT0FBTztHQUNQLGVBQWU7R0FDZixjQUFjO0dBQ2QsVUFBVTtHQUNWLFNBQVM7R0FDVCxTQUFTO0dBQ1QsUUFBUTtHQUNSLFlBQVk7R0FDWixlQUFlO0dBQ2YsZ0JBQWdCO0dBQ2hCLGdCQUFnQjtHQUNoQixXQUFXO0dBQ1gsZUFBZTtHQUNmLGFBQWE7R0FDYixhQUFhO0dBQ2IsU0FBUztHQUNULFNBQVM7RUFDWDtDQUNGO0NBQ0EsSUFBSTtFQUNGLEtBQUs7R0FDSCxNQUFNO0dBQ04sTUFBTTtHQUNOLE1BQU07R0FDTixRQUFRO0dBQ1IsUUFBUTtHQUNSLFdBQVc7R0FDWCxTQUFTO0dBQ1QsVUFBVTtHQUNWLFFBQVE7R0FDUixRQUFRO0dBQ1IsU0FBUztFQUNYO0VBQ0EsTUFBTTtHQUNKLE9BQU87R0FDUCxlQUFlO0dBQ2YsY0FBYztHQUNkLFVBQVU7R0FDVixTQUFTO0dBQ1QsU0FBUztHQUNULFFBQVE7R0FDUixZQUFZO0dBQ1osZUFBZTtHQUNmLG1CQUFtQjtHQUNuQixnQkFBZ0I7R0FDaEIsZ0JBQWdCO0dBQ2hCLFdBQVc7R0FDWCxlQUFlO0dBQ2YsYUFBYTtHQUNiLGFBQWE7R0FDYixTQUFTO0dBQ1QsU0FBUztFQUNYO0NBQ0Y7Q0FDQSxJQUFJO0VBQ0YsS0FBSztHQUNILE1BQU07R0FDTixNQUFNO0dBQ04sTUFBTTtHQUNOLFFBQVE7R0FDUixRQUFRO0dBQ1IsV0FBVztHQUNYLFNBQVM7R0FDVCxVQUFVO0dBQ1YsUUFBUTtHQUNSLFFBQVE7R0FDUixTQUFTO0VBQ1g7RUFDQSxNQUFNO0dBQ0osT0FBTztHQUNQLGVBQWU7R0FDZixjQUFjO0dBQ2QsVUFBVTtHQUNWLFNBQVM7R0FDVCxTQUFTO0dBQ1QsUUFBUTtHQUNSLFlBQVk7R0FDWixlQUFlO0dBQ2YsZ0JBQWdCO0dBQ2hCLGdCQUFnQjtHQUNoQixXQUFXO0dBQ1gsZUFBZTtHQUNmLGFBQWE7R0FDYixhQUFhO0dBQ2IsU0FBUztHQUNULFNBQVM7RUFDWDtDQUNGO0NBQ0EsSUFBSTtFQUNGLEtBQUs7R0FDSCxNQUFNO0dBQ04sTUFBTTtHQUNOLE1BQU07R0FDTixRQUFRO0dBQ1IsUUFBUTtHQUNSLFdBQVc7R0FDWCxTQUFTO0dBQ1QsVUFBVTtHQUNWLFFBQVE7R0FDUixRQUFRO0dBQ1IsU0FBUztFQUNYO0VBQ0EsTUFBTTtHQUNKLE9BQU87R0FDUCxlQUFlO0dBQ2YsY0FBYztHQUNkLFVBQVU7R0FDVixTQUFTO0dBQ1QsU0FBUztHQUNULFFBQVE7R0FDUixZQUFZO0dBQ1osZUFBZTtHQUNmLGdCQUFnQjtHQUNoQixnQkFBZ0I7R0FDaEIsV0FBVztHQUNYLGVBQWU7R0FDZixhQUFhO0dBQ2IsYUFBYTtHQUNiLFNBQVM7R0FDVCxTQUFTO0VBQ1g7Q0FDRjtDQUNBLElBQUk7RUFDRixLQUFLO0dBQ0gsTUFBTTtHQUNOLE1BQU07R0FDTixNQUFNO0dBQ04sUUFBUTtHQUNSLFFBQVE7R0FDUixXQUFXO0dBQ1gsU0FBUztHQUNULFVBQVU7R0FDVixRQUFRO0dBQ1IsUUFBUTtHQUNSLFNBQVM7RUFDWDtFQUNBLE1BQU07R0FDSixPQUFPO0dBQ1AsZUFBZTtHQUNmLGNBQWM7R0FDZCxVQUFVO0dBQ1YsU0FBUztHQUNULFNBQVM7R0FDVCxRQUFRO0dBQ1IsWUFBWTtHQUNaLGVBQWU7R0FDZixnQkFBZ0I7R0FDaEIsZ0JBQWdCO0dBQ2hCLFdBQVc7R0FDWCxlQUFlO0dBQ2YsYUFBYTtHQUNiLGFBQWE7R0FDYixTQUFTO0dBQ1QsU0FBUztFQUNYO0NBQ0Y7Q0FDQSxJQUFJO0VBQ0YsS0FBSztHQUNILE1BQU07R0FDTixNQUFNO0dBQ04sTUFBTTtHQUNOLFFBQVE7R0FDUixRQUFRO0dBQ1IsV0FBVztHQUNYLFNBQVM7R0FDVCxVQUFVO0dBQ1YsUUFBUTtHQUNSLFFBQVE7R0FDUixTQUFTO0VBQ1g7RUFDQSxNQUFNO0dBQ0osT0FBTztHQUNQLGVBQWU7R0FDZixjQUFjO0dBQ2QsVUFBVTtHQUNWLFNBQVM7R0FDVCxTQUFTO0dBQ1QsUUFBUTtHQUNSLFlBQVk7R0FDWixlQUFlO0dBQ2YsZ0JBQWdCO0dBQ2hCLGdCQUFnQjtHQUNoQixXQUFXO0dBQ1gsZUFBZTtHQUNmLGFBQWE7R0FDYixhQUFhO0dBQ2IsU0FBUztHQUNULFNBQVM7RUFDWDtDQUNGO0NBQ0EsSUFBSTtFQUNGLEtBQUs7R0FDSCxNQUFNO0dBQ04sTUFBTTtHQUNOLE1BQU07R0FDTixRQUFRO0dBQ1IsUUFBUTtHQUNSLFdBQVc7R0FDWCxTQUFTO0dBQ1QsVUFBVTtHQUNWLFFBQVE7R0FDUixRQUFRO0dBQ1IsU0FBUztFQUNYO0VBQ0EsTUFBTTtHQUNKLE9BQU87R0FDUCxlQUFlO0dBQ2YsY0FBYztHQUNkLFVBQVU7R0FDVixTQUFTO0dBQ1QsU0FBUztHQUNULFFBQVE7R0FDUixZQUFZO0dBQ1osZUFBZTtHQUNmLGdCQUFnQjtHQUNoQixnQkFBZ0I7R0FDaEIsV0FBVztHQUNYLGVBQWU7R0FDZixhQUFhO0dBQ2IsYUFBYTtHQUNiLFNBQVM7R0FDVCxTQUFTO0VBQ1g7Q0FDRjtDQUNBLElBQUk7RUFDRixLQUFLO0dBQ0gsTUFBTTtHQUNOLE1BQU07R0FDTixNQUFNO0dBQ04sUUFBUTtHQUNSLFFBQVE7R0FDUixXQUFXO0dBQ1gsU0FBUztHQUNULFVBQVU7R0FDVixRQUFRO0dBQ1IsUUFBUTtHQUNSLFNBQVM7RUFDWDtFQUNBLE1BQU07R0FDSixPQUFPO0dBQ1AsZUFBZTtHQUNmLGNBQWM7R0FDZCxVQUFVO0dBQ1YsU0FBUztHQUNULFNBQVM7R0FDVCxRQUFRO0dBQ1IsWUFBWTtHQUNaLGVBQWU7R0FDZixnQkFBZ0I7R0FDaEIsZ0JBQWdCO0dBQ2hCLFdBQVc7R0FDWCxlQUFlO0dBQ2YsYUFBYTtHQUNiLGFBQWE7R0FDYixTQUFTO0dBQ1QsU0FBUztFQUNYO0NBQ0Y7Q0FDQSxJQUFJO0VBQ0YsS0FBSztHQUNILE1BQU07R0FDTixNQUFNO0dBQ04sTUFBTTtHQUNOLFFBQVE7R0FDUixRQUFRO0dBQ1IsV0FBVztHQUNYLFNBQVM7R0FDVCxVQUFVO0dBQ1YsUUFBUTtHQUNSLFFBQVE7R0FDUixTQUFTO0VBQ1g7RUFDQSxNQUFNO0dBQ0osT0FBTztHQUNQLGVBQWU7R0FDZixjQUFjO0dBQ2QsVUFBVTtHQUNWLFNBQVM7R0FDVCxTQUFTO0dBQ1QsUUFBUTtHQUNSLFlBQVk7R0FDWixlQUFlO0dBQ2YsZ0JBQWdCO0dBQ2hCLGdCQUFnQjtHQUNoQixXQUFXO0dBQ1gsZUFBZTtHQUNmLGFBQWE7R0FDYixhQUFhO0dBQ2IsU0FBUztHQUNULFNBQVM7RUFDWDtDQUNGO0NBQ0EsSUFBSTtFQUNGLEtBQUs7R0FDSCxNQUFNO0dBQ04sTUFBTTtHQUNOLE1BQU07R0FDTixRQUFRO0dBQ1IsUUFBUTtHQUNSLFdBQVc7R0FDWCxTQUFTO0dBQ1QsVUFBVTtHQUNWLFFBQVE7R0FDUixRQUFRO0dBQ1IsU0FBUztFQUNYO0VBQ0EsTUFBTTtHQUNKLE9BQU87R0FDUCxlQUFlO0dBQ2YsY0FBYztHQUNkLFVBQVU7R0FDVixTQUFTO0dBQ1QsU0FBUztHQUNULFFBQVE7R0FDUixZQUFZO0dBQ1osZUFBZTtHQUNmLGdCQUFnQjtHQUNoQixnQkFBZ0I7R0FDaEIsV0FBVztHQUNYLGVBQWU7R0FDZixhQUFhO0dBQ2IsYUFBYTtHQUNiLFNBQVM7R0FDVCxTQUFTO0VBQ1g7Q0FDRjtDQUNBLElBQUk7RUFDRixLQUFLO0dBQ0gsTUFBTTtHQUNOLE1BQU07R0FDTixNQUFNO0dBQ04sUUFBUTtHQUNSLFFBQVE7R0FDUixXQUFXO0dBQ1gsU0FBUztHQUNULFVBQVU7R0FDVixRQUFRO0dBQ1IsUUFBUTtHQUNSLFNBQVM7RUFDWDtFQUNBLE1BQU07R0FDSixPQUFPO0dBQ1AsZUFBZTtHQUNmLGNBQWM7R0FDZCxVQUFVO0dBQ1YsU0FBUztHQUNULFNBQVM7R0FDVCxRQUFRO0dBQ1IsWUFBWTtHQUNaLGVBQWU7R0FDZixnQkFBZ0I7R0FDaEIsZ0JBQWdCO0dBQ2hCLFdBQVc7R0FDWCxlQUFlO0dBQ2YsYUFBYTtHQUNiLGFBQWE7R0FDYixTQUFTO0dBQ1QsU0FBUztFQUNYO0NBQ0Y7QUFDRiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJjb3VudHJ5LWxhbmd1YWdlcy50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgaW50ZXJmYWNlIENvdW50cnlMYW5ndWFnZU1hcHBpbmcge1xuICBjb3VudHJ5Q29kZTogc3RyaW5nO1xuICBjb3VudHJ5TmFtZTogc3RyaW5nO1xuICBmbGFnOiBzdHJpbmc7XG4gIGxhbmd1YWdlczoge1xuICAgIGNvZGU6IHN0cmluZztcbiAgICBuYXRpdmVOYW1lOiBzdHJpbmc7XG4gICAgZW5nbGlzaE5hbWU6IHN0cmluZztcbiAgfVtdO1xufVxuXG4vKipcbiAqIEFjY3VyYXRlIENvdW50cnkgLT4gMeKAkzIrIEZsYWdzaGlwIE5hdGl2ZSBMYW5ndWFnZXMgRGlyZWN0b3J5XG4gKiBBbGxvd3MgdXNlcnMgJiBicmFuZHMgdG8gcGljayBhIGNvdW50cnkgYW5kIGltbWVkaWF0ZWx5IHN3aXRjaCBpbnRvIGl0cyBhdXRoZW50aWMgbG9jYWwgbGFuZ3VhZ2UocykuXG4gKi9cbmV4cG9ydCBjb25zdCBDT1VOVFJZX0xBTkdVQUdFX0RJUkVDVE9SWTogQ291bnRyeUxhbmd1YWdlTWFwcGluZ1tdID0gW1xuICB7XG4gICAgY291bnRyeUNvZGU6IFwiWkFcIixcbiAgICBjb3VudHJ5TmFtZTogXCJTb3V0aCBBZnJpY2FcIixcbiAgICBmbGFnOiBcIvCfh7/wn4emXCIsXG4gICAgbGFuZ3VhZ2VzOiBbXG4gICAgICB7IGNvZGU6IFwienVcIiwgbmF0aXZlTmFtZTogXCJpc2ladWx1XCIsIGVuZ2xpc2hOYW1lOiBcIlp1bHVcIiB9LFxuICAgICAgeyBjb2RlOiBcInhoXCIsIG5hdGl2ZU5hbWU6IFwiaXNpWGhvc2FcIiwgZW5nbGlzaE5hbWU6IFwiWGhvc2FcIiB9LFxuICAgICAgeyBjb2RlOiBcImFmXCIsIG5hdGl2ZU5hbWU6IFwiQWZyaWthYW5zXCIsIGVuZ2xpc2hOYW1lOiBcIkFmcmlrYWFuc1wiIH0sXG4gICAgICB7IGNvZGU6IFwic3RcIiwgbmF0aXZlTmFtZTogXCJTZXNvdGhvXCIsIGVuZ2xpc2hOYW1lOiBcIlNlc290aG9cIiB9LFxuICAgICAgeyBjb2RlOiBcInRuXCIsIG5hdGl2ZU5hbWU6IFwiU2V0c3dhbmFcIiwgZW5nbGlzaE5hbWU6IFwiU2V0c3dhbmFcIiB9LFxuICAgICAgeyBjb2RlOiBcIm5zb1wiLCBuYXRpdmVOYW1lOiBcIlNlcGVkaVwiLCBlbmdsaXNoTmFtZTogXCJTZXBlZGlcIiB9LFxuICAgICAgeyBjb2RlOiBcImVuXCIsIG5hdGl2ZU5hbWU6IFwiRW5nbGlzaFwiLCBlbmdsaXNoTmFtZTogXCJFbmdsaXNoXCIgfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgY291bnRyeUNvZGU6IFwiTkdcIixcbiAgICBjb3VudHJ5TmFtZTogXCJOaWdlcmlhXCIsXG4gICAgZmxhZzogXCLwn4ez8J+HrFwiLFxuICAgIGxhbmd1YWdlczogW1xuICAgICAgeyBjb2RlOiBcImhhXCIsIG5hdGl2ZU5hbWU6IFwiSGF1c2FcIiwgZW5nbGlzaE5hbWU6IFwiSGF1c2FcIiB9LFxuICAgICAgeyBjb2RlOiBcInlvXCIsIG5hdGl2ZU5hbWU6IFwiWW9yw7liw6FcIiwgZW5nbGlzaE5hbWU6IFwiWW9ydWJhXCIgfSxcbiAgICAgIHsgY29kZTogXCJpZ1wiLCBuYXRpdmVOYW1lOiBcIklnYm9cIiwgZW5nbGlzaE5hbWU6IFwiSWdib1wiIH0sXG4gICAgICB7IGNvZGU6IFwiZW5cIiwgbmF0aXZlTmFtZTogXCJFbmdsaXNoXCIsIGVuZ2xpc2hOYW1lOiBcIkVuZ2xpc2hcIiB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBjb3VudHJ5Q29kZTogXCJLRVwiLFxuICAgIGNvdW50cnlOYW1lOiBcIktlbnlhICYgVGFuemFuaWFcIixcbiAgICBmbGFnOiBcIvCfh7Dwn4eqXCIsXG4gICAgbGFuZ3VhZ2VzOiBbXG4gICAgICB7IGNvZGU6IFwic3dcIiwgbmF0aXZlTmFtZTogXCJLaXN3YWhpbGlcIiwgZW5nbGlzaE5hbWU6IFwiU3dhaGlsaVwiIH0sXG4gICAgICB7IGNvZGU6IFwiZW5cIiwgbmF0aXZlTmFtZTogXCJFbmdsaXNoXCIsIGVuZ2xpc2hOYW1lOiBcIkVuZ2xpc2hcIiB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBjb3VudHJ5Q29kZTogXCJFVFwiLFxuICAgIGNvdW50cnlOYW1lOiBcIkV0aGlvcGlhXCIsXG4gICAgZmxhZzogXCLwn4eq8J+HuVwiLFxuICAgIGxhbmd1YWdlczogW1xuICAgICAgeyBjb2RlOiBcImFtXCIsIG5hdGl2ZU5hbWU6IFwi4Yqg4Yib4Yit4YqbXCIsIGVuZ2xpc2hOYW1lOiBcIkFtaGFyaWNcIiB9LFxuICAgICAgeyBjb2RlOiBcImVuXCIsIG5hdGl2ZU5hbWU6IFwiRW5nbGlzaFwiLCBlbmdsaXNoTmFtZTogXCJFbmdsaXNoXCIgfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgY291bnRyeUNvZGU6IFwiQldcIixcbiAgICBjb3VudHJ5TmFtZTogXCJCb3Rzd2FuYSAmIExlc290aG9cIixcbiAgICBmbGFnOiBcIvCfh6fwn4e8XCIsXG4gICAgbGFuZ3VhZ2VzOiBbXG4gICAgICB7IGNvZGU6IFwidG5cIiwgbmF0aXZlTmFtZTogXCJTZXRzd2FuYVwiLCBlbmdsaXNoTmFtZTogXCJTZXRzd2FuYVwiIH0sXG4gICAgICB7IGNvZGU6IFwic3RcIiwgbmF0aXZlTmFtZTogXCJTZXNvdGhvXCIsIGVuZ2xpc2hOYW1lOiBcIlNlc290aG9cIiB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBjb3VudHJ5Q29kZTogXCJFR1wiLFxuICAgIGNvdW50cnlOYW1lOiBcIkVneXB0LCBVQUUgJiBTYXVkaSBBcmFiaWFcIixcbiAgICBmbGFnOiBcIvCfh6rwn4esXCIsXG4gICAgbGFuZ3VhZ2VzOiBbXG4gICAgICB7IGNvZGU6IFwiYXJcIiwgbmF0aXZlTmFtZTogXCLYp9mE2LnYsdio2YrYqVwiLCBlbmdsaXNoTmFtZTogXCJBcmFiaWNcIiB9LFxuICAgICAgeyBjb2RlOiBcImVuXCIsIG5hdGl2ZU5hbWU6IFwiRW5nbGlzaFwiLCBlbmdsaXNoTmFtZTogXCJFbmdsaXNoXCIgfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgY291bnRyeUNvZGU6IFwiRlJcIixcbiAgICBjb3VudHJ5TmFtZTogXCJGcmFuY2UsIFNlbmVnYWwgJiBDw7R0ZSBkJ0l2b2lyZVwiLFxuICAgIGZsYWc6IFwi8J+Hq/Cfh7dcIixcbiAgICBsYW5ndWFnZXM6IFtcbiAgICAgIHsgY29kZTogXCJmclwiLCBuYXRpdmVOYW1lOiBcIkZyYW7Dp2Fpc1wiLCBlbmdsaXNoTmFtZTogXCJGcmVuY2hcIiB9LFxuICAgICAgeyBjb2RlOiBcImVuXCIsIG5hdGl2ZU5hbWU6IFwiRW5nbGlzaFwiLCBlbmdsaXNoTmFtZTogXCJFbmdsaXNoXCIgfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgY291bnRyeUNvZGU6IFwiQlJcIixcbiAgICBjb3VudHJ5TmFtZTogXCJCcmF6aWwsIFBvcnR1Z2FsLCBBbmdvbGEgJiBNb3phbWJpcXVlXCIsXG4gICAgZmxhZzogXCLwn4en8J+Ht1wiLFxuICAgIGxhbmd1YWdlczogW1xuICAgICAgeyBjb2RlOiBcInB0XCIsIG5hdGl2ZU5hbWU6IFwiUG9ydHVndcOqc1wiLCBlbmdsaXNoTmFtZTogXCJQb3J0dWd1ZXNlXCIgfSxcbiAgICAgIHsgY29kZTogXCJlblwiLCBuYXRpdmVOYW1lOiBcIkVuZ2xpc2hcIiwgZW5nbGlzaE5hbWU6IFwiRW5nbGlzaFwiIH0sXG4gICAgXSxcbiAgfSxcbiAge1xuICAgIGNvdW50cnlDb2RlOiBcIkVTXCIsXG4gICAgY291bnRyeU5hbWU6IFwiU3BhaW4sIE1leGljbyAmIExhdGluIEFtZXJpY2FcIixcbiAgICBmbGFnOiBcIvCfh6rwn4e4XCIsXG4gICAgbGFuZ3VhZ2VzOiBbXG4gICAgICB7IGNvZGU6IFwiZXNcIiwgbmF0aXZlTmFtZTogXCJFc3Bhw7FvbFwiLCBlbmdsaXNoTmFtZTogXCJTcGFuaXNoXCIgfSxcbiAgICAgIHsgY29kZTogXCJlblwiLCBuYXRpdmVOYW1lOiBcIkVuZ2xpc2hcIiwgZW5nbGlzaE5hbWU6IFwiRW5nbGlzaFwiIH0sXG4gICAgXSxcbiAgfSxcbiAge1xuICAgIGNvdW50cnlDb2RlOiBcIkRFXCIsXG4gICAgY291bnRyeU5hbWU6IFwiR2VybWFueSwgQXVzdHJpYSAmIFN3aXR6ZXJsYW5kXCIsXG4gICAgZmxhZzogXCLwn4ep8J+HqlwiLFxuICAgIGxhbmd1YWdlczogW1xuICAgICAgeyBjb2RlOiBcImRlXCIsIG5hdGl2ZU5hbWU6IFwiRGV1dHNjaFwiLCBlbmdsaXNoTmFtZTogXCJHZXJtYW5cIiB9LFxuICAgICAgeyBjb2RlOiBcImZyXCIsIG5hdGl2ZU5hbWU6IFwiRnJhbsOnYWlzXCIsIGVuZ2xpc2hOYW1lOiBcIkZyZW5jaFwiIH0sXG4gICAgXSxcbiAgfSxcbiAge1xuICAgIGNvdW50cnlDb2RlOiBcIk5MXCIsXG4gICAgY291bnRyeU5hbWU6IFwiTmV0aGVybGFuZHMgJiBCZWxnaXVtXCIsXG4gICAgZmxhZzogXCLwn4ez8J+HsVwiLFxuICAgIGxhbmd1YWdlczogW1xuICAgICAgeyBjb2RlOiBcIm5sXCIsIG5hdGl2ZU5hbWU6IFwiTmVkZXJsYW5kc1wiLCBlbmdsaXNoTmFtZTogXCJEdXRjaFwiIH0sXG4gICAgICB7IGNvZGU6IFwiZnJcIiwgbmF0aXZlTmFtZTogXCJGcmFuw6dhaXNcIiwgZW5nbGlzaE5hbWU6IFwiRnJlbmNoXCIgfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgY291bnRyeUNvZGU6IFwiSVRcIixcbiAgICBjb3VudHJ5TmFtZTogXCJJdGFseVwiLFxuICAgIGZsYWc6IFwi8J+HrvCfh7lcIixcbiAgICBsYW5ndWFnZXM6IFtcbiAgICAgIHsgY29kZTogXCJpdFwiLCBuYXRpdmVOYW1lOiBcIkl0YWxpYW5vXCIsIGVuZ2xpc2hOYW1lOiBcIkl0YWxpYW5cIiB9LFxuICAgICAgeyBjb2RlOiBcImVuXCIsIG5hdGl2ZU5hbWU6IFwiRW5nbGlzaFwiLCBlbmdsaXNoTmFtZTogXCJFbmdsaXNoXCIgfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgY291bnRyeUNvZGU6IFwiSU5cIixcbiAgICBjb3VudHJ5TmFtZTogXCJJbmRpYVwiLFxuICAgIGZsYWc6IFwi8J+HrvCfh7NcIixcbiAgICBsYW5ndWFnZXM6IFtcbiAgICAgIHsgY29kZTogXCJoaVwiLCBuYXRpdmVOYW1lOiBcIuCkueCkv+CkqOCljeCkpuClgFwiLCBlbmdsaXNoTmFtZTogXCJIaW5kaVwiIH0sXG4gICAgICB7IGNvZGU6IFwidGFcIiwgbmF0aXZlTmFtZTogXCLgrqTgrq7grr/grrTgr41cIiwgZW5nbGlzaE5hbWU6IFwiVGFtaWxcIiB9LFxuICAgICAgeyBjb2RlOiBcImJuXCIsIG5hdGl2ZU5hbWU6IFwi4Kas4Ka+4KaC4Kay4Ka+XCIsIGVuZ2xpc2hOYW1lOiBcIkJlbmdhbGlcIiB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBjb3VudHJ5Q29kZTogXCJDTlwiLFxuICAgIGNvdW50cnlOYW1lOiBcIkNoaW5hLCBUYWl3YW4gJiBTaW5nYXBvcmVcIixcbiAgICBmbGFnOiBcIvCfh6jwn4ezXCIsXG4gICAgbGFuZ3VhZ2VzOiBbXG4gICAgICB7IGNvZGU6IFwiemgtQ05cIiwgbmF0aXZlTmFtZTogXCLnroDkvZPkuK3mlodcIiwgZW5nbGlzaE5hbWU6IFwiU2ltcGxpZmllZCBDaGluZXNlXCIgfSxcbiAgICAgIHsgY29kZTogXCJ6aC1UV1wiLCBuYXRpdmVOYW1lOiBcIue5gemrlOS4reaWh1wiLCBlbmdsaXNoTmFtZTogXCJUcmFkaXRpb25hbCBDaGluZXNlXCIgfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgY291bnRyeUNvZGU6IFwiSlBcIixcbiAgICBjb3VudHJ5TmFtZTogXCJKYXBhblwiLFxuICAgIGZsYWc6IFwi8J+Hr/Cfh7VcIixcbiAgICBsYW5ndWFnZXM6IFtcbiAgICAgIHsgY29kZTogXCJqYVwiLCBuYXRpdmVOYW1lOiBcIuaXpeacrOiqnlwiLCBlbmdsaXNoTmFtZTogXCJKYXBhbmVzZVwiIH0sXG4gICAgICB7IGNvZGU6IFwiZW5cIiwgbmF0aXZlTmFtZTogXCJFbmdsaXNoXCIsIGVuZ2xpc2hOYW1lOiBcIkVuZ2xpc2hcIiB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBjb3VudHJ5Q29kZTogXCJLUlwiLFxuICAgIGNvdW50cnlOYW1lOiBcIlNvdXRoIEtvcmVhXCIsXG4gICAgZmxhZzogXCLwn4ew8J+Ht1wiLFxuICAgIGxhbmd1YWdlczogW1xuICAgICAgeyBjb2RlOiBcImtvXCIsIG5hdGl2ZU5hbWU6IFwi7ZWc6rWt7Ja0XCIsIGVuZ2xpc2hOYW1lOiBcIktvcmVhblwiIH0sXG4gICAgICB7IGNvZGU6IFwiZW5cIiwgbmF0aXZlTmFtZTogXCJFbmdsaXNoXCIsIGVuZ2xpc2hOYW1lOiBcIkVuZ2xpc2hcIiB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBjb3VudHJ5Q29kZTogXCJUUlwiLFxuICAgIGNvdW50cnlOYW1lOiBcIlR1cmtleVwiLFxuICAgIGZsYWc6IFwi8J+HufCfh7dcIixcbiAgICBsYW5ndWFnZXM6IFtcbiAgICAgIHsgY29kZTogXCJ0clwiLCBuYXRpdmVOYW1lOiBcIlTDvHJrw6dlXCIsIGVuZ2xpc2hOYW1lOiBcIlR1cmtpc2hcIiB9LFxuICAgICAgeyBjb2RlOiBcImVuXCIsIG5hdGl2ZU5hbWU6IFwiRW5nbGlzaFwiLCBlbmdsaXNoTmFtZTogXCJFbmdsaXNoXCIgfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgY291bnRyeUNvZGU6IFwiUExcIixcbiAgICBjb3VudHJ5TmFtZTogXCJQb2xhbmQgJiBFYXN0ZXJuIEV1cm9wZVwiLFxuICAgIGZsYWc6IFwi8J+HtfCfh7FcIixcbiAgICBsYW5ndWFnZXM6IFtcbiAgICAgIHsgY29kZTogXCJwbFwiLCBuYXRpdmVOYW1lOiBcIlBvbHNraVwiLCBlbmdsaXNoTmFtZTogXCJQb2xpc2hcIiB9LFxuICAgICAgeyBjb2RlOiBcInVrXCIsIG5hdGl2ZU5hbWU6IFwi0KPQutGA0LDRl9C90YHRjNC60LBcIiwgZW5nbGlzaE5hbWU6IFwiVWtyYWluaWFuXCIgfSxcbiAgICBdLFxuICB9LFxuXTtcblxuLyoqXG4gKiBSaWNoIE5hdGl2ZSBIZXJvICYgRmVlZCBidW5kbGVzIGZvciBtYWpvciBjb3VudHJ5IGZsYWdzaGlwIGxhbmd1YWdlc1xuICogc28gc3dpdGNoaW5nIHRvIEFmcmlrYWFucywgU2V0c3dhbmEsIFNlcGVkaSwgS2lzd2FoaWxpLCBIYXVzYSwgWW9ydWJhLCBJZ2JvLFxuICogQW1oYXJpYywgQXJhYmljLCBIaW5kaSwgQ2hpbmVzZSwgSmFwYW5lc2UsIEtvcmVhbiwgSXRhbGlhbiwgRHV0Y2gsIFR1cmtpc2gsIGV0Yy5cbiAqIHRyYW5zbGF0ZXMgdGhlIGVudGlyZSBIb21lIEhlcm8sIFp3ZXBlIENvaW4sIFJhbmR5IFRyYXNoIENhbiwgRmVlZCwgYW5kIE5hdmJhci5cbiAqL1xuZXhwb3J0IGNvbnN0IENPVU5UUllfRkxBR1NISVBfQVBQX0JVTkRMRVM6IFJlY29yZDxcbiAgc3RyaW5nLFxuICB7XG4gICAgbmF2PzogUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcbiAgICBoZXJvPzogUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcbiAgICBmZWVkPzogUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcbiAgfVxuPiA9IHtcbiAgYWY6IHtcbiAgICBuYXY6IHtcbiAgICAgIGhvbWU6IFwiVHVpc1wiLFxuICAgICAgZmVlZDogXCJTdHJvb21cIixcbiAgICAgIHNjYW46IFwiU2thbmRlZXJcIixcbiAgICAgIGJyYW5kczogXCJIYW5kZWxzbWVya2VcIixcbiAgICAgIGF3YXJkczogXCJUb2VrZW5uaW5nc1wiLFxuICAgICAgZGFzaGJvYXJkOiBcIkJlaGVlcnBhbmVlbFwiLFxuICAgICAgcHJvZmlsZTogXCJQcm9maWVsXCIsXG4gICAgICBtZXNzYWdlczogXCJCb29kc2thcHBlXCIsXG4gICAgICBzaWduSW46IFwiTWVsZCBhYW5cIixcbiAgICAgIHNpZ25VcDogXCJSZWdpc3RyZWVyXCIsXG4gICAgICBzaWduT3V0OiBcIk1lbGQgYWZcIixcbiAgICB9LFxuICAgIGhlcm86IHtcbiAgICAgIGJhZGdlOiBcIkRpZSBIYW5kZWxzbWVyay1CYXJvbWV0ZXJcIixcbiAgICAgIGhlYWRsaW5lQmxhY2s6IFwiSG91IHdhdCBqb3UgZGllbi5cIixcbiAgICAgIGhlYWRsaW5lR29sZDogXCJEYWFnIHVpdCB3YXQgbmllIHdlcmsgbmllLlwiLFxuICAgICAgc3VidGl0bGU6IFwiU3RlbSBCw6pyZSAoU3Rhc2gpIG9mIFdlZ2dvb2kgKFRyYXNoKSBvb3Igam91IHdhcmUgaGFuZGVsc21lcmstZXJ2YXJpbmdzIOKAlCBkaWUgQ1gtICYgUFItc2VpbiB3YXQgdGVsLlwiLFxuICAgICAgdGFnbGluZTogXCJFbGtlIHVpdHNwcmFhayBicmluZyBoYW5kZWxzbWVya2UgbmFkZXIgYWFuIGRpZSBtZW5zZSB3YXQgaHVsbGUgZGllbi4gR2VlIGpvdW5lLiDwn5SlXCIsXG4gICAgICBzcGlubmluZ1p3ZXBlOiBcIkRyYWFpIHRhbnMgWndlcGUtbXVudC4uLiBreWsgaG9lIGRpdCB0b2wgZW4gcGxhdCB2YWwhXCIsXG4gICAgICBkcm9wcGluZ0JpbjogXCJWYWwgaW4gZGllIGFzYmxpay4uLiBrbGV0dGVyIGVuIGtsYXAhXCIsXG4gICAgICB0YXBDb2luOiBcIlRpayBvcCBkaWUgR291ZSBNdW50IG9tIFN0YXNoZXMgdGUgc2llblwiLFxuICAgICAgdGFwQmluOiBcIlRpayBvcCBkaWUgQXNibGlrIG9tIFRyYXNoZXMgdGUgc2llblwiLFxuICAgICAgYWxsVGllcnM6IFwiQWxsZSB2bGFra2VcIixcbiAgICAgIHN1cGVyQnJhbmRzOiBcIlN1cGVyaGFuZGVsc21lcmtlXCIsXG4gICAgICBuYXRpb25hbFBvd2VyaG91c2VzOiBcIk5hc2lvbmFsZSBSZXVzZVwiLFxuICAgICAgZW1lcmdpbmdDaGFsbGVuZ2VyczogXCJPcGtvbWVuZGUgVWl0ZGFnZXJzXCIsXG4gICAgICBsb2NhbEhlcm9lczogXCJQbGFhc2xpa2UgSGVsZGVcIixcbiAgICAgIHNvcnRCeTogXCJTb3J0ZWVyIHZvbGdlbnNcIixcbiAgICAgIHRydXN0U2NvcmU6IFwiVmVydHJvdWVuc3B1bnRcIixcbiAgICAgIGJyYW5kVGllcjogXCJIYW5kZWxzbWVya3ZsYWtcIixcbiAgICAgIGFscGhhYmV0aWNhbDogXCJBbGZhYmV0aWVzXCIsXG4gICAgICBsaXZlU2VudGltZW50OiBcIkxld2VuZGlnZSBTZW50aW1lbnQgT29yIEhhbmRlbHNtZXJrZVwiLFxuICAgICAgbGl2ZVNlbnRpbWVudERlc2M6IFwiV2FyZSB2ZXJicnVpa2Vyc3VpdHNwcmFrZSB3YXQgdmVydHJvdWVuc3B1bnRlIGludHlkcyB2b3JtLlwiLFxuICAgICAgc2VhcmNoT3JCcm93c2U6IFwiU29layBoYW5kZWxzbWVya2Ugb2YgYmxhYWkgaGllcm9uZGVyXCIsXG4gICAgICBnZXR0aW5nU3Rhc2hlZDogXCJXYXQgZ2Viw6pyZSB3b3JkIChTdGFzaGVkKVwiLFxuICAgICAgZ2V0dGluZ1RyYXNoZWQ6IFwiV2F0IHdlZ2dlZ29vaSB3b3JkIChUcmFzaGVkKVwiLFxuICAgICAgc290QXdhcmRzOiBcIkRpZSBTT1QtVG9la2VubmluZ3NcIixcbiAgICAgIGNyb3duaW5nQnJhbmQ6IFwiQmVrcm9vbiBkaWUgamFhciBzZSBtZWVzIGJldHJvdWJhcmUgaGFuZGVsc21lcmtcIixcbiAgICAgIHNlZVN0YW5kaW5nczogXCJTaWVuIGxld2VuZGlnZSByYW5nbHlzXCIsXG4gICAgICBwclRlYW1DbGFpbTogXCJQUi0gJiBIYW5kZWxzbWVya3NwYW5uZTogRWlzIGpvdSBibGFkc3lcIixcbiAgICAgIHByVGVhbURlc2M6IFwiTW9uaXRvciBzZW50aW1lbnQsIHJlYWdlZXIgb3Aga2xpw6tudGUgZW4gdmVyZGllbiBnZXZlcmlmaWVlcmRlIHN0YXR1cy5cIixcbiAgICAgIGdvVG9EYXNoYm9hcmQ6IFwiR2FhbiBuYSBCZWhlZXJwYW5lZWxcIixcbiAgICAgIGpvaW5Db252ZXJzYXRpb246IFwiU2x1aXQgYWFuIGJ5IGRpZSBnZXNwcmVrXCIsXG4gICAgICByZWFsUGVvcGxlVmVyZGljdHM6IFwiV2FyZSBtZW5zZS4gV2FyZSB1aXRzcHJha2UuIE51bCBiZXRhYWxtdXJlLlwiLFxuICAgICAgZXhwbG9yZUZlZWQ6IFwiVmVya2VuIFN0cm9vbVwiLFxuICAgICAgc2NhblByb2R1Y3Q6IFwiU2thbmRlZXIgUHJvZHVrXCIsXG4gICAgICBzdGFzaGVzOiBcIkLDqnJlIChTdGFzaGVzKVwiLFxuICAgICAgdHJhc2hlczogXCJXZWdnb29pIChUcmFzaGVzKVwiLFxuICAgIH0sXG4gICAgZmVlZDoge1xuICAgICAgcHVsc2U6IFwiR2VtZWVuc2thcHNwb2xzXCIsXG4gICAgICB0aXRsZTogXCJTdGFzaCBPciBUcmFzaFwiLFxuICAgICAgc3VidGl0bGU6IFwiRGllIEhhbmRlbHNtZXJrLUJhcm9tZXRlci4gUGxhYXMgZW5pZ2lldHMgb29yICduIGhhbmRlbHNtZXJrIGVuIGxhYXQgZGllIGdlbWVlbnNrYXAgaW50eWRzIGJlc2x1aXQuXCIsXG4gICAgICBob29rOiBcIkVsa2UgdWl0c3ByYWFrIGJyaW5nIGhhbmRlbHNtZXJrZSBuYWRlciBhYW4gaHVsIG1lbnNlLlwiLFxuICAgICAgc2VhcmNoUGxhY2Vob2xkZXI6IFwiU29layBwbGFzaW5ncyBvZiBoYW5kZWxzbWVya2VcIixcbiAgICAgIGFsbFZlcmRpY3RzOiBcIkFsbGUgdWl0c3ByYWtlXCIsXG4gICAgICBzdGFzaGVzT2ZEYXk6IFwiU3Rhc2hlcyB2YW4gZGllIERhZ1wiLFxuICAgICAgdHJhc2hlc09mRGF5OiBcIlRyYXNoZXMgdmFuIGRpZSBEYWdcIixcbiAgICAgIHJlc2V0RmlsdGVyOiBcIkhlcnN0ZWwgZmlsdGVyXCIsXG4gICAgfSxcbiAgfSxcbiAgdG46IHtcbiAgICBuYXY6IHtcbiAgICAgIGhvbWU6IFwiR2FlXCIsXG4gICAgICBmZWVkOiBcIkRpdGlyb1wiLFxuICAgICAgc2NhbjogXCJTZWtlbmFcIixcbiAgICAgIGJyYW5kczogXCJNYWJva2dvbmlcIixcbiAgICAgIGF3YXJkczogXCJEaWtodW1hZ2FkaVwiLFxuICAgICAgZGFzaGJvYXJkOiBcIkxldGxhcGEgbGEgVGFvbG9cIixcbiAgICAgIHByb2ZpbGU6IFwiUG9lbGV0c29cIixcbiAgICAgIG1lc3NhZ2VzOiBcIk1lbGFldHNhXCIsXG4gICAgICBzaWduSW46IFwiVHNlbmFcIixcbiAgICAgIHNpZ25VcDogXCJJa3dhZGlzZVwiLFxuICAgICAgc2lnbk91dDogXCJUc3dhXCIsXG4gICAgfSxcbiAgICBoZXJvOiB7XG4gICAgICBiYWRnZTogXCJTZWthbGEgc2EgVHNoZXBvIHlhIE1hYm9rZ29uaVwiLFxuICAgICAgaGVhZGxpbmVCbGFjazogXCJCb2xva2Egc2Ugc2UgZ28gZGlyZWxhbmcuXCIsXG4gICAgICBoZWFkbGluZUdvbGQ6IFwiS2dhbGVtZWxhIHNlIHNlIHNhIGRpcmVuZy5cIixcbiAgICAgIHN1YnRpdGxlOiBcIlRsaG9waGEgQm9sb2thIChTdGFzaCkga2dvdHNhIExhdGxoYSAoVHJhc2gpIGthIG1haXRlbW9nZWxvIGEgZ2FnbyBhIG5uZXRlIOKAlCBsZW50c3dlIGxhIGJhcmVraSBsZSBsZSBib3RsaG9rd2EuXCIsXG4gICAgICB0YWdsaW5lOiBcIkthdGxob2xvIG5uZ3dlIGxlIG5uZ3dlIGUgYXRhbWV0c2EgbWFib2tnb25pIGt3YSBiYXRob25nLiBOdHNoYSB5YSBnYWdvLiDwn5SlXCIsXG4gICAgICB0YXBDb2luOiBcIlRvYmV0c2EgTGVkaSBsYSBHYXV0YSBnbyBib25hIHRzZSBkaSBCb2xva2lsd2VuZ1wiLFxuICAgICAgdGFwQmluOiBcIlRvYmV0c2EgTW90ZW1lIHdhIE1hdGxha2FsYSBnbyBib25hIHRzZSBkaSBMYXRsaGlsd2VuZ1wiLFxuICAgICAgdHJ1c3RTY29yZTogXCJUZWthbnlldHNvIHlhIFRzaGVwb1wiLFxuICAgICAgbGl2ZVNlbnRpbWVudDogXCJNYWlrdXRsbyBhIFNldMWhaGFiYSBrYSBOYWtvIHlhIE5uZXRlXCIsXG4gICAgICBsaXZlU2VudGltZW50RGVzYzogXCJEaWthdGxob2xvIHRzYSBiYXJla2kgYmEgbm5ldGUgdHNlIGRpIGFnYW5nIHRzaGVwbyB5YSBtYWJva2dvbmkuXCIsXG4gICAgICBnZXR0aW5nU3Rhc2hlZDogXCJUc2UgZGkgQm9sb2t3YW5nIChTdGFzaGVkKVwiLFxuICAgICAgZ2V0dGluZ1RyYXNoZWQ6IFwiVHNlIGRpIExhdGxod2FuZyAoVHJhc2hlZClcIixcbiAgICAgIHNvdEF3YXJkczogXCJEaWtodW1hZ2FkaSB0c2EgU09UXCIsXG4gICAgICBnb1RvRGFzaGJvYXJkOiBcIllhIGt3YSBMZXRsYXBlbmcgbGEgS2d3ZWJvXCIsXG4gICAgICBleHBsb3JlRmVlZDogXCJMZWJlbGVsYSBEaXRpcm9cIixcbiAgICAgIHNjYW5Qcm9kdWN0OiBcIlNla2VuYSBLaG91dHUgeWEgU2VobGFoaXN3YVwiLFxuICAgICAgc3Rhc2hlczogXCJCb2xva2EgKFN0YXNoZXMpXCIsXG4gICAgICB0cmFzaGVzOiBcIkxhdGxoYSAoVHJhc2hlcylcIixcbiAgICB9LFxuICB9LFxuICBuc286IHtcbiAgICBuYXY6IHtcbiAgICAgIGhvbWU6IFwiR2FlXCIsXG4gICAgICBmZWVkOiBcIkRpa2FnYXJlXCIsXG4gICAgICBzY2FuOiBcIlNla2VuYVwiLFxuICAgICAgYnJhbmRzOiBcIk1hYnJhbmRlXCIsXG4gICAgICBhd2FyZHM6IFwiRGlmb2thXCIsXG4gICAgICBkYXNoYm9hcmQ6IFwiRGFzaGJvdG9cIixcbiAgICAgIHByb2ZpbGU6IFwiQm9pdHNlYmnFoW9cIixcbiAgICAgIG1lc3NhZ2VzOiBcIk1lbGFldHNhXCIsXG4gICAgICBzaWduSW46IFwiVHNlbmFcIixcbiAgICAgIHNpZ25VcDogXCJJbmd3YWRpxaFlXCIsXG4gICAgICBzaWduT3V0OiBcIlTFoXdhXCIsXG4gICAgfSxcbiAgICBoZXJvOiB7XG4gICAgICBiYWRnZTogXCJTZWthbGEgc2EgVHNoZXBvIHlhIE1hYnJhbmRlXCIsXG4gICAgICBoZWFkbGluZUJsYWNrOiBcIkJvbG9rYSBzZW8gc2UgZ28gdGh1xaFhZ28uXCIsXG4gICAgICBoZWFkbGluZUdvbGQ6IFwiR2FuYW5hIGxlIHNlbyBzZSBzYSDFoW9tZWdvLlwiLFxuICAgICAgc3VidGl0bGU6IFwiS2dldGhhIEJvbG9rYSAoU3Rhc2gpIGdvYmEgTGFobGEgKFRyYXNoKSBnbyB5YSBrYSBtYWl0ZW1vZ2VsbyBhIGdhZ28gYSBubmV0ZSBsZSBtYWJyYW5kZS5cIixcbiAgICAgIHRhZ2xpbmU6IFwiS2FobG9sbyB5ZSBubmd3ZSBsZSB5ZSBubmd3ZSBlIGJhdGFtZXTFoWEgbWFicmFuZGUgYmF0aG9uZy4gTmVlbGEgeWEgZ2Fnby4g8J+UpVwiLFxuICAgICAgdGFwQ29pbjogXCJLZ3dhdGhhIFTFoWhlbGV0ZSB5YSBHYXV0YSBnbyBib25hIHTFoWUgQm9sb2tpbHdlZ29cIixcbiAgICAgIHRhcEJpbjogXCJLZ3dhdGhhIE1vdG9tbyB3YSBEaXTFoWhpbGEgZ28gYm9uYSB0xaFlIExhaGxpbHdlZ29cIixcbiAgICAgIHRydXN0U2NvcmU6IFwiVGVrYW55ZXTFoW8geWEgVHNoZXBvXCIsXG4gICAgICBsaXZlU2VudGltZW50OiBcIk1haWt1dGxvIGEgU2V0xaFoYWJhIFNlbWVldHNlbmdcIixcbiAgICAgIGdldHRpbmdTdGFzaGVkOiBcIlTFoWUgZGkgQm9sb2t3YWdvIChTdGFzaGVkKVwiLFxuICAgICAgZ2V0dGluZ1RyYXNoZWQ6IFwiVMWhZSBkaSBMYWhsd2FnbyAoVHJhc2hlZClcIixcbiAgICAgIHNvdEF3YXJkczogXCJEaWZva2EgdMWhYSBTT1RcIixcbiAgICAgIGdvVG9EYXNoYm9hcmQ6IFwiWWEgZ28gRGFzaGJvdG9cIixcbiAgICAgIGV4cGxvcmVGZWVkOiBcIkxla29sYSBEaWthZ2FyZVwiLFxuICAgICAgc2NhblByb2R1Y3Q6IFwiU2VrZW5hIFNldMWhd2VsZXTFoXdhXCIsXG4gICAgICBzdGFzaGVzOiBcIkJvbG9rYSAoU3Rhc2hlcylcIixcbiAgICAgIHRyYXNoZXM6IFwiTGFobGEgKFRyYXNoZXMpXCIsXG4gICAgfSxcbiAgfSxcbiAgc3c6IHtcbiAgICBuYXY6IHtcbiAgICAgIGhvbWU6IFwiTnl1bWJhbmlcIixcbiAgICAgIGZlZWQ6IFwiTWxpc2hvXCIsXG4gICAgICBzY2FuOiBcIkNoYW5nYW51YVwiLFxuICAgICAgYnJhbmRzOiBcIkNoYXBhXCIsXG4gICAgICBhd2FyZHM6IFwiVHV6b1wiLFxuICAgICAgZGFzaGJvYXJkOiBcIkRhc2hpYm9kaVwiLFxuICAgICAgcHJvZmlsZTogXCJXYXNpZnVcIixcbiAgICAgIG1lc3NhZ2VzOiBcIlVqdW1iZVwiLFxuICAgICAgc2lnbkluOiBcIkluZ2lhXCIsXG4gICAgICBzaWduVXA6IFwiSmlzYWppbGlcIixcbiAgICAgIHNpZ25PdXQ6IFwiVG9rYVwiLFxuICAgIH0sXG4gICAgaGVybzoge1xuICAgICAgYmFkZ2U6IFwiS2lwaW1hIEpvdG8gY2hhIENoYXBhXCIsXG4gICAgICBoZWFkbGluZUJsYWNrOiBcIlR1bnphIGtpbmFjaG9rdWZhYS5cIixcbiAgICAgIGhlYWRsaW5lR29sZDogXCJQaW5nYSBraXNpY2hva3VmYWEuXCIsXG4gICAgICBzdWJ0aXRsZTogXCJQaWdhIGt1cmEgeWEgSGlmYWRoaSAoU3Rhc2gpIGF1IFR1cGEgKFRyYXNoKSBrdWh1c3UgdXpvZWZ1IHdha28gaGFsaXNpIHdhIGNoYXBhIOKAlCBzYXV0aSB5YSB3YXRlamEgaW5heW9qZW5nYSB1YW1pbmlmdS5cIixcbiAgICAgIHRhZ2xpbmU6IFwiS2lsYSB1YW11emkgaHVsZXRhIGNoYXBhIGthcmlidSBuYSB3YXR1IHdhbmFvd2FodWR1bWlhLiBUb2EgdWFtdXppIHdha28uIPCflKVcIixcbiAgICAgIHRhcENvaW46IFwiR3VzYSBTYXJhZnUgeWEgRGhhaGFidSBrdW9uYSBaaWxpem9oaWZhZGhpd2FcIixcbiAgICAgIHRhcEJpbjogXCJHdXNhIFBpcGFuaSBrdW9uYSBaaWxpem90dXB3YVwiLFxuICAgICAgdHJ1c3RTY29yZTogXCJBbGFtYSB5YSBVYW1pbmlmdVwiLFxuICAgICAgbGl2ZVNlbnRpbWVudDogXCJIaXNpYSB6YSBNb2phIGt3YSBNb2phIHphIFdhdGVqYVwiLFxuICAgICAgbGl2ZVNlbnRpbWVudERlc2M6IFwiTWFhbXV6aSBoYWxpc2kgeWEgd2F0dW1pYWppIHlhbmF5b3VuZGEgYWxhbWEgemEgdWFtaW5pZnUgbW9qYSBrd2EgbW9qYS5cIixcbiAgICAgIGdldHRpbmdTdGFzaGVkOiBcIlppbmF6b2hpZmFkaGl3YSBaYWlkaVwiLFxuICAgICAgZ2V0dGluZ1RyYXNoZWQ6IFwiWmluYXpvdHVwd2EgWmFpZGlcIixcbiAgICAgIHNvdEF3YXJkczogXCJUdXpvIHphIFNPVFwiLFxuICAgICAgZ29Ub0Rhc2hib2FyZDogXCJOZW5kYSBrd2VueWUgRGFzaGlib2RpXCIsXG4gICAgICBleHBsb3JlRmVlZDogXCJDaHVuZ3V6YSBNbGlzaG9cIixcbiAgICAgIHNjYW5Qcm9kdWN0OiBcIkNoYW5nYW51YSBCaWRoYWFcIixcbiAgICAgIHN0YXNoZXM6IFwiSGlmYWRoaSAoU3Rhc2hlcylcIixcbiAgICAgIHRyYXNoZXM6IFwiVHVwYSAoVHJhc2hlcylcIixcbiAgICB9LFxuICB9LFxuICBoYToge1xuICAgIG5hdjoge1xuICAgICAgaG9tZTogXCJHaWRhXCIsXG4gICAgICBmZWVkOiBcIkxhYmFyYWlcIixcbiAgICAgIHNjYW46IFwiQmluY2lrYVwiLFxuICAgICAgYnJhbmRzOiBcIkthbWZhbm9uaVwiLFxuICAgICAgYXdhcmRzOiBcIkt5YXV0dXR0dWthXCIsXG4gICAgICBkYXNoYm9hcmQ6IFwiQWxsb24gU2FyYXV0YVwiLFxuICAgICAgcHJvZmlsZTogXCJCYXlhbmFpXCIsXG4gICAgICBtZXNzYWdlczogXCJTYcaZb25uaVwiLFxuICAgICAgc2lnbkluOiBcIlNoaWdhXCIsXG4gICAgICBzaWduVXA6IFwiWWkgUmFqaXN0YVwiLFxuICAgICAgc2lnbk91dDogXCJGaXRhXCIsXG4gICAgfSxcbiAgICBoZXJvOiB7XG4gICAgICBiYWRnZTogXCJNYSdhdW5pbiBBbWluY2V3YXIgS2FtZmFub25pXCIsXG4gICAgICBoZWFkbGluZUJsYWNrOiBcIkFqaXllIGFiaW4gZGEga2UgYW1mYW5hciBrYS5cIixcbiAgICAgIGhlYWRsaW5lR29sZDogXCLGmGFsdWJhbGFuY2kgYWJpbiBkYSBiYSB5YSBhbWZhbmkuXCIsXG4gICAgICBzdWJ0aXRsZTogXCJaYcmTaSBBaml5ZSAoU3Rhc2gpIGtvIFp1YmFyIChUcmFzaCkgYmlzYSBnYXNraXlhciBtdSdhbWFsYXJrYSBkYSBrYW1mYW5vbmkgYSB5YXUuXCIsXG4gICAgICB0YWdsaW5lOiBcIktvd2FuZSBodWt1bmNpIHlhbmEga3VzYW50YXIgZGEga2FtZmFub25pIGdhIGphbWEnYS4gQmF5YXIgZGEgbmFrYS4g8J+UpVwiLFxuICAgICAgdGFwQ29pbjogXCJEYW5uYSBLdcmXaW4gWmluYXJpeWEgZG9uIGdhbmluIEFqaXlheXl1XCIsXG4gICAgICB0YXBCaW46IFwiRGFubmEgS3dhbmRvbiBTaGFyYSBkb24gZ2FuaW4gWnViYXJ3YVwiLFxuICAgICAgdHJ1c3RTY29yZTogXCJNYWtpbiBBbWFuYVwiLFxuICAgICAgbGl2ZVNlbnRpbWVudDogXCJSYSdheWluIEphbWEnYSBLYWkgVHNheWVcIixcbiAgICAgIGdldHRpbmdTdGFzaGVkOiBcIkFidWJ1d2FuIGRhIGFrZSBBaml5ZXdhXCIsXG4gICAgICBnZXR0aW5nVHJhc2hlZDogXCJBYnVidXdhbiBkYSBha2UgWnViYXJ3YVwiLFxuICAgICAgc290QXdhcmRzOiBcIkt5YXV0dXR0dWthbiBTT1RcIixcbiAgICAgIGdvVG9EYXNoYm9hcmQ6IFwiSmUgenV3YSBBbGxvbiBLYW1mYW5pXCIsXG4gICAgICBleHBsb3JlRmVlZDogXCJEdWJhIExhYmFyYWlcIixcbiAgICAgIHNjYW5Qcm9kdWN0OiBcIkJpbmNpa2EgTGFtYmFyIEtheWFcIixcbiAgICAgIHN0YXNoZXM6IFwiQWppeWUgKFN0YXNoZXMpXCIsXG4gICAgICB0cmFzaGVzOiBcIlp1YmFyIChUcmFzaGVzKVwiLFxuICAgIH0sXG4gIH0sXG4gIHlvOiB7XG4gICAgbmF2OiB7XG4gICAgICBob21lOiBcIklsw6lcIixcbiAgICAgIGZlZWQ6IFwiw4BmaWvDum5cIixcbiAgICAgIHNjYW46IFwi4bmiw6B54bq5zIB3w7JcIixcbiAgICAgIGJyYW5kczogXCLDgHfhu41uIElsw6ktaeG5o+G6ucyBXCIsXG4gICAgICBhd2FyZHM6IFwiw4B34buNbiDDgG3DrC3hurnMgHnhurlcIixcbiAgICAgIGRhc2hib2FyZDogXCJQ4bq5cOG6uSBJ4bmj4bq5zIFcIixcbiAgICAgIHByb2ZpbGU6IFwiUHJvZmFpbGlcIixcbiAgICAgIG1lc3NhZ2VzOiBcIsOAd+G7jW4gSWZpcmFu4bmj4bq5XCIsXG4gICAgICBzaWduSW46IFwiV+G7jWzDqVwiLFxuICAgICAgc2lnblVwOiBcIkZvcsO6a+G7jXPDrWzhurnMgFwiLFxuICAgICAgc2lnbk91dDogXCJKw6FkZVwiLFxuICAgIH0sXG4gICAgaGVybzoge1xuICAgICAgYmFkZ2U6IFwiSXfhu41uIMOMZ2LhurnMgWvhurnMgGzDqSDDgHfhu41uIElsw6ktaeG5o+G6ucyBXCIsXG4gICAgICBoZWFkbGluZUJsYWNrOiBcIlThu43MgWrDuiBvaHVuIHTDrSDDs9eY15kgd8O6bMOyIGbDum4g4buNLlwiLFxuICAgICAgaGVhZGxpbmVHb2xkOiBcIkvhu40gb2h1biB0w60ga8OyIGLDoSDhu40gbXUuXCIsXG4gICAgICBzdWJ0aXRsZTogXCJEw6xiw7IgVOG7jcyBasO6IChTdGFzaCkgdMOgYsOtIETDoCBuw7kgKFRyYXNoKSBsw7Nyw60gw6xyw61yw60gcuG6uSBnaWRpIHDhurnMgGzDuiDDoHfhu41uIGlsw6ktaeG5o+G6ucyBLlwiLFxuICAgICAgdGFnbGluZTogXCJHYm9nYm8gw6xkw6Fq4buNzIEgbMOzIMWEIG3DuiBpbMOpLWnhuaPhurnMgSBzw7puIG3hu43MgSDDoHfhu41uIMOobsOsecOgbi4gU+G7jSB0w6xy4bq5LiDwn5SlXCIsXG4gICAgICB0YXBDb2luOiBcIlThurkgT3fDsyBXw7pyw6AgbMOhdGkgcsOtIMOAd+G7jW4gVMOtIEEgVOG7jcyBasO6XCIsXG4gICAgICB0YXBCaW46IFwiVOG6uSBBcOG6ucyAcuG6ucyAIMOMZOG7jcyAdMOtIGzDoXRpIHLDrSDDgHfhu41uIFTDrSBBIETDoCBOw7lcIixcbiAgICAgIHRydXN0U2NvcmU6IFwiSXllIMOMZ2LhurnMgWvhurnMgGzDqVwiLFxuICAgICAgbGl2ZVNlbnRpbWVudDogXCLDiHLDsiDDgHfhu41uIMOIbsOsecOgbiBM4buNzIF34buNzIFs4buNzIF34buNzIFcIixcbiAgICAgIGdldHRpbmdTdGFzaGVkOiBcIk9odW4gVMOtIMOAd+G7jW4gw4huw6x5w6BuIMWDIFThu43MgWrDulwiLFxuICAgICAgZ2V0dGluZ1RyYXNoZWQ6IFwiT2h1biBUw60gw4B34buNbiDDiG7DrHnDoG4gxYMgRMOgIE7DuVwiLFxuICAgICAgc290QXdhcmRzOiBcIsOAd+G7jW4gw4Btw6wt4bq5zIB54bq5IFNPVFwiLFxuICAgICAgZ29Ub0Rhc2hib2FyZDogXCJM4buNIHPDrSBQ4bq5cOG6uSBJbMOpLWnhuaPhurnMgVwiLFxuICAgICAgZXhwbG9yZUZlZWQ6IFwiV28gw4BmaWvDum5cIixcbiAgICAgIHNjYW5Qcm9kdWN0OiBcIuG5osOgeeG6ucyAd8OyIOG7jGrDoFwiLFxuICAgICAgc3Rhc2hlczogXCJU4buNzIFqw7ogKFN0YXNoZXMpXCIsXG4gICAgICB0cmFzaGVzOiBcIkTDoCBuw7kgKFRyYXNoZXMpXCIsXG4gICAgfSxcbiAgfSxcbiAgaWc6IHtcbiAgICBuYXY6IHtcbiAgICAgIGhvbWU6IFwi4bukbOG7jVwiLFxuICAgICAgZmVlZDogXCJJaGUg4buNaOG7pXLhu6VcIixcbiAgICAgIHNjYW46IFwiTnlvY2hhYVwiLFxuICAgICAgYnJhbmRzOiBcIuG7pGThu4sgTmd3YWFo4buLYVwiLFxuICAgICAgYXdhcmRzOiBcIkloZSBucml0ZVwiLFxuICAgICAgZGFzaGJvYXJkOiBcIk1wZW1wZSBObGVr4buNdGFcIixcbiAgICAgIHByb2ZpbGU6IFwiUHJvZmHhu4ts4bulXCIsXG4gICAgICBtZXNzYWdlczogXCJPemlcIixcbiAgICAgIHNpZ25JbjogXCJCYW55ZVwiLFxuICAgICAgc2lnblVwOiBcIkRlYmFueWUgYWhhXCIsXG4gICAgICBzaWduT3V0OiBcIlDhu6Xhu41cIixcbiAgICB9LFxuICAgIGhlcm86IHtcbiAgICAgIGJhZGdlOiBcIuG7jMyAdOG7pcyAdOG7pcyAIE504bula3dhc+G7iyBPYmkg4bukZOG7iyBOZ3dhYWjhu4thXCIsXG4gICAgICBoZWFkbGluZUJsYWNrOiBcIkNoZWt3YWEgaWhlIG5hLWVueWVyZSBn4buLIGFrYS5cIixcbiAgICAgIGhlYWRsaW5lR29sZDogXCJK4bulIGloZSBuYS1hZOG7i2do4buLIG1tYS5cIixcbiAgICAgIHN1YnRpdGxlOiBcIuG7i3Thu6Ugdm9vdHUgQ2hla3dhYSAoU3Rhc2gpIG1hIOG7jSBi4bulIFThu6VmdW8gKFRyYXNoKSBtYWthIGFo4bulbeG7i2hlIGfhu4sgbmEg4bulZOG7iyBuZ3dhYWjhu4thLlwiLFxuICAgICAgdGFnbGluZTogXCJNa3BlYmkg4buNIGLhu6VsYSBuYS1lbWUga2Eg4bulbOG7jSDhu41y4bulIGLhu4thcnVvIG5k4buLIG1tYWThu6UgbnNvLiBOeWUgbmtlIGfhu4suIPCflKVcIixcbiAgICAgIHRhcENvaW46IFwiUOG7i2EgTWtw4bulcuG7pSBFZ2/hu41sYWVkbyBrYSDhu4to4bulIE5rZSBFY2hla3dhcmFcIixcbiAgICAgIHRhcEJpbjogXCJQ4buLYSBOZ+G7i2dhIEFo4buLaOG7i2Ega2Eg4buLaOG7pSBOa2UgQXThu6VmdXJ1XCIsXG4gICAgICB0cnVzdFNjb3JlOiBcIkFrYXJhIE504bula3dhc+G7iyBPYmlcIixcbiAgICAgIGxpdmVTZW50aW1lbnQ6IFwiZWNoaWNoZSBOZOG7iyBNbWFk4bulIE96dWdib1wiLFxuICAgICAgZ2V0dGluZ1N0YXNoZWQ6IFwiSWhlIE5k4buLIEEgTmEtZWNoZWt3YVwiLFxuICAgICAgZ2V0dGluZ1RyYXNoZWQ6IFwiSWhlIE5k4buLIEEgTmEtYXThu6VmdVwiLFxuICAgICAgc290QXdhcmRzOiBcIkloZSBOcml0ZSBTT1RcIixcbiAgICAgIGdvVG9EYXNoYm9hcmQ6IFwiR2FhIG5hIE1wZW1wZSBObGVr4buNdGFcIixcbiAgICAgIGV4cGxvcmVGZWVkOiBcIkNo4buNcOG7pXRhIEloZSDhu4xo4bulcuG7pVwiLFxuICAgICAgc2NhblByb2R1Y3Q6IFwiTnlvY2hhYSBOZ3dhYWjhu4thXCIsXG4gICAgICBzdGFzaGVzOiBcIkNoZWt3YWEgKFN0YXNoZXMpXCIsXG4gICAgICB0cmFzaGVzOiBcIlThu6VmdW8gKFRyYXNoZXMpXCIsXG4gICAgfSxcbiAgfSxcbiAgYW06IHtcbiAgICBuYXY6IHtcbiAgICAgIGhvbWU6IFwi4YiY4YqQ4Yi7XCIsXG4gICAgICBmZWVkOiBcIuGIneGMjeGJpuGJvVwiLFxuICAgICAgc2NhbjogXCLhiYPhip1cIixcbiAgICAgIGJyYW5kczogXCLhiaXhiKvhipXhi7bhib1cIixcbiAgICAgIGF3YXJkczogXCLhiL3hiI3hiJvhibbhib1cIixcbiAgICAgIGRhc2hib2FyZDogXCLhi7PhiL3hiabhiK3hi7VcIixcbiAgICAgIHByb2ZpbGU6IFwi4YiY4YyI4YiI4YyrXCIsXG4gICAgICBtZXNzYWdlczogXCLhiJjhiI3hi5Xhiq3hibbhib1cIixcbiAgICAgIHNpZ25JbjogXCLhjI3hiaNcIixcbiAgICAgIHNpZ25VcDogXCLhi63hiJjhi53hjIjhiaFcIixcbiAgICAgIHNpZ25PdXQ6IFwi4YuN4YyjXCIsXG4gICAgfSxcbiAgICBoZXJvOiB7XG4gICAgICBiYWRnZTogXCLhi6jhiaXhiKvhipXhi7Ug4Yql4Yid4YqQ4Ym1IOGImOGIiOGKquGLq1wiLFxuICAgICAgaGVhZGxpbmVCbGFjazogXCLhi6jhiJrhjKDhiYXhiJ3hi47hibXhipUg4Yur4Yi14YmA4Yid4Yyh4Y2iXCIsXG4gICAgICBoZWFkbGluZUdvbGQ6IFwi4Yuo4Yib4Yut4Yyg4YmF4Yid4YuO4Ym14YqVIOGLreGJg+GLiOGImeGNolwiLFxuICAgICAgc3VidGl0bGU6IFwi4Ymg4Yql4YuN4YqQ4Ymw4YqbIOGLqOGJpeGIq+GKleGLtSDhibDhiJ7hiq3hiK7hi44g4YiL4YutIOGKoOGIteGJgOGIneGMpSAoU3Rhc2gpIOGLiOGLreGInSDhjKPhiIjhi40gKFRyYXNoKSDhiaXhiIjhi40g4Yu14Yid4Yy9IOGLreGIteGMoeGNolwiLFxuICAgICAgdGFnbGluZTogXCLhiqXhi6vhipXhi7PhipXhi7Eg4YuN4Yiz4YqUIOGJpeGIq+GKleGLtuGJveGKlSDhiqjhiJXhi53hiaEg4YyL4YitIOGLq+GJgOGIq+GIreGJo+GIjeGNoiDhi6jhiqXhiK3hiLXhi47hipUg4Yut4Yi14Yyh4Y2iIPCflKVcIixcbiAgICAgIHRhcENvaW46IFwi4Yuo4Ymw4YmA4YiY4Yyh4Ym14YqVIOGIiOGIm+GLqOGJtSDhi6jhi4jhiK3hiYUg4Yiz4YqV4Ymy4YiZ4YqVIOGLreGKleGKqVwiLFxuICAgICAgdGFwQmluOiBcIuGLqOGJsOGMo+GIieGJteGKlSDhiIjhiJvhi6jhibUg4Yuo4YmG4Yi74Yi7IOGImOGMo+GLq+GLjeGKlSDhi63hipXhiqlcIixcbiAgICAgIHRydXN0U2NvcmU6IFwi4Yuo4Yql4Yid4YqQ4Ym1IOGKkOGMpeGJpVwiLFxuICAgICAgbGl2ZVNlbnRpbWVudDogXCLhi6jhiYDhjKXhibMg4Yuo4Yuw4YqV4Ymg4Yqe4Ym9IOGIteGInOGJtVwiLFxuICAgICAgZ2V0dGluZ1N0YXNoZWQ6IFwi4Ymg4Yml4Yub4Ym1IOGLqOGJsOGJgOGImOGMoVwiLFxuICAgICAgZ2V0dGluZ1RyYXNoZWQ6IFwi4Ymg4Yml4Yub4Ym1IOGLqOGJsOGMo+GIiVwiLFxuICAgICAgc290QXdhcmRzOiBcIuGLqFNPVCDhiL3hiI3hiJvhibbhib1cIixcbiAgICAgIGdvVG9EYXNoYm9hcmQ6IFwi4YuI4YuwIOGLs+GIveGJpuGIreGLtSDhi63hiILhi7FcIixcbiAgICAgIGV4cGxvcmVGZWVkOiBcIuGIneGMjeGJpuGJveGKlSDhi6vhiLXhiLFcIixcbiAgICAgIHNjYW5Qcm9kdWN0OiBcIuGIneGIreGJtSDhi63hiYPhiplcIixcbiAgICAgIHN0YXNoZXM6IFwi4Yqg4Yi14YmA4Yid4YylIChTdGFzaGVzKVwiLFxuICAgICAgdHJhc2hlczogXCLhjKPhiIjhi40gKFRyYXNoZXMpXCIsXG4gICAgfSxcbiAgfSxcbiAgYXI6IHtcbiAgICBuYXY6IHtcbiAgICAgIGhvbWU6IFwi2KfZhNix2KbZitiz2YrYqVwiLFxuICAgICAgZmVlZDogXCLYp9mE2YXZhti02YjYsdin2KpcIixcbiAgICAgIHNjYW46IFwi2YXYs9itINin2YTZhdmG2KrYrFwiLFxuICAgICAgYnJhbmRzOiBcItin2YTYudmE2KfZhdin2Kog2KfZhNiq2KzYp9ix2YrYqVwiLFxuICAgICAgYXdhcmRzOiBcItin2YTYrNmI2KfYptiyXCIsXG4gICAgICBkYXNoYm9hcmQ6IFwi2YTZiNit2Kkg2KfZhNiq2K3Zg9mFXCIsXG4gICAgICBwcm9maWxlOiBcItin2YTZhdmE2YEg2KfZhNi02K7YtdmKXCIsXG4gICAgICBtZXNzYWdlczogXCLYp9mE2LHYs9in2KbZhFwiLFxuICAgICAgc2lnbkluOiBcItiq2LPYrNmK2YQg2KfZhNiv2K7ZiNmEXCIsXG4gICAgICBzaWduVXA6IFwi2KXZhti02KfYoSDYrdiz2KfYqFwiLFxuICAgICAgc2lnbk91dDogXCLYrtix2YjYrFwiLFxuICAgIH0sXG4gICAgaGVybzoge1xuICAgICAgYmFkZ2U6IFwi2YXZgtmK2KfYsyDYq9mC2Kkg2KfZhNi52YTYp9mF2KfYqiDYp9mE2KrYrNin2LHZitipXCIsXG4gICAgICBoZWFkbGluZUJsYWNrOiBcItin2K3YqtmB2Lgg2KjZhdinINmK2K7Yr9mF2YMuXCIsXG4gICAgICBoZWFkbGluZUdvbGQ6IFwi2KrYrdiv2Y7ZkSDZhdinINmE2Kcg2YrYrtiv2YXZgy5cIixcbiAgICAgIHN1YnRpdGxlOiBcIti12YjZkdiqINio2YAg2KfYrdiq2YHYp9i4IChTdGFzaCkg2KPZiCDYp9iz2KrYqNi52KfYryAoVHJhc2gpINio2YbYp9ih2Ysg2LnZhNmJINiq2KzYsdio2KrZgyDYp9mE2K3ZgtmK2YLZitipINmF2Lkg2KfZhNi52YTYp9mF2KfYqiDYp9mE2KrYrNin2LHZitipLlwiLFxuICAgICAgdGFnbGluZTogXCLZg9mEINit2YPZhSDZitmC2LHZkdioINin2YTYudmE2KfZhdin2Kog2KfZhNiq2KzYp9ix2YrYqSDZhdmGINi52YXZhNin2KbZh9inLiDYo9iv2YTZkCDYqNi12YjYqtmDINin2YTYotmGLiDwn5SlXCIsXG4gICAgICB0YXBDb2luOiBcItin2LbYuti3INi52YTZiSDYp9mE2LnZhdmE2Kkg2KfZhNiw2YfYqNmK2Kkg2YTYudix2LYg2KfZhNmF2K3YqtmB2Lgg2KjZh9inXCIsXG4gICAgICB0YXBCaW46IFwi2KfYtti62Lcg2LnZhNmJINin2YTYs9mE2Kkg2YTYudix2LYg2KfZhNmF2LPYqtio2LnYr9ipXCIsXG4gICAgICB0cnVzdFNjb3JlOiBcItmF2KTYtNixINin2YTYq9mC2KlcIixcbiAgICAgIGxpdmVTZW50aW1lbnQ6IFwi2YbYqNi2INin2YTZhdiz2KrZh9mE2YPZitmGINin2YTZhdio2KfYtNixXCIsXG4gICAgICBnZXR0aW5nU3Rhc2hlZDogXCLYp9mE2KPZg9ir2LEg2KfYrdiq2YHYp9i42KfZi1wiLFxuICAgICAgZ2V0dGluZ1RyYXNoZWQ6IFwi2KfZhNij2YPYq9ixINin2LPYqtio2LnYp9iv2KfZi1wiLFxuICAgICAgc290QXdhcmRzOiBcItis2YjYp9im2LIgU09UXCIsXG4gICAgICBnb1RvRGFzaGJvYXJkOiBcItin2YbYqtmC2YQg2KXZhNmJINmE2YjYrdipINin2YTYudmE2KfZhdipXCIsXG4gICAgICBleHBsb3JlRmVlZDogXCLYqti12YHYrSDYp9mE2YXZhti02YjYsdin2KpcIixcbiAgICAgIHNjYW5Qcm9kdWN0OiBcItin2YHYrdi1INio2KfYsdmD2YjYryDYp9mE2YXZhtiq2KxcIixcbiAgICAgIHN0YXNoZXM6IFwi2KfYrdiq2YHYp9i4IChTdGFzaClcIixcbiAgICAgIHRyYXNoZXM6IFwi2KfYs9iq2KjYudin2K8gKFRyYXNoKVwiLFxuICAgIH0sXG4gIH0sXG4gIGhpOiB7XG4gICAgbmF2OiB7XG4gICAgICBob21lOiBcIuCkueCli+CkrlwiLFxuICAgICAgZmVlZDogXCLgpKvgpLzgpYDgpKFcIixcbiAgICAgIHNjYW46IFwi4KS44KWN4KSV4KWI4KSoIOCkleCksOClh+CkglwiLFxuICAgICAgYnJhbmRzOiBcIuCkrOCljeCksOCkvuCkguCkoeCljeCkuFwiLFxuICAgICAgYXdhcmRzOiBcIuCkquClgeCksOCkuOCljeCkleCkvuCksFwiLFxuICAgICAgZGFzaGJvYXJkOiBcIuCkoeCliOCktuCkrOCli+CksOCljeCkoVwiLFxuICAgICAgcHJvZmlsZTogXCLgpKrgpY3gpLDgpYvgpKvgpLzgpL7gpIfgpLJcIixcbiAgICAgIG1lc3NhZ2VzOiBcIuCkuOCkguCkpuClh+CktlwiLFxuICAgICAgc2lnbkluOiBcIuCkuOCkvuCkh+CkqCDgpIfgpKhcIixcbiAgICAgIHNpZ25VcDogXCLgpLjgpL7gpIfgpKgg4KSF4KSqXCIsXG4gICAgICBzaWduT3V0OiBcIuCkuOCkvuCkh+CkqCDgpIbgpIngpJ9cIixcbiAgICB9LFxuICAgIGhlcm86IHtcbiAgICAgIGJhZGdlOiBcIuCkrOCljeCksOCkvuCkguCkoSDgpLXgpL/gpLbgpY3gpLXgpL7gpLgg4KSs4KWI4KSw4KWL4KSu4KWA4KSf4KSwXCIsXG4gICAgICBoZWFkbGluZUJsYWNrOiBcIuCknOCliyDgpIbgpKrgpJXgpYcg4KSV4KS+4KSuIOCkhuCkjyDgpIngpLjgpYcg4KSw4KSW4KWH4KSC4KWkXCIsXG4gICAgICBoZWFkbGluZUdvbGQ6IFwi4KSc4KWLIOCkuOCkueClgCDgpKgg4KS54KWLIOCkieCkuOClhyDgpJrgpYHgpKjgpYzgpKTgpYAg4KSm4KWH4KSC4KWkXCIsXG4gICAgICBzdWJ0aXRsZTogXCLgpIXgpKrgpKjgpYcg4KS14KS+4KS44KWN4KSk4KS14KS/4KSVIOCkrOCljeCksOCkvuCkguCkoSDgpIXgpKjgpYHgpK3gpLXgpYvgpIIg4KSq4KSwIOCksOCkluClh+CkgiAoU3Rhc2gpIOCkr+CkviDgpLngpJ/gpL7gpI/gpIIgKFRyYXNoKSDgpK7gpYfgpIIg4KS14KWL4KSfIOCkleCksOClh+CkguClpFwiLFxuICAgICAgdGFnbGluZTogXCLgpLngpLAg4KSr4KWI4KS44KSy4KS+IOCkrOCljeCksOCkvuCkguCkoeCljeCkuCDgpJXgpYsg4KSy4KWL4KSX4KWL4KSCIOCkleClhyDgpJXgpLDgpYDgpKwg4KSy4KS+4KSk4KS+IOCkueCliOClpCDgpIXgpKrgpKjgpL4g4KSr4KWI4KS44KSy4KS+IOCkpuClh+CkguClpCDwn5SlXCIsXG4gICAgICB0YXBDb2luOiBcIuCkuOCljeCkn+CliOCktiDgpKbgpYfgpJbgpKjgpYcg4KSV4KWHIOCksuCkv+CkjyDgpLjgpYvgpKjgpYcg4KSV4KWHIOCkuOCkv+CkleCljeCkleClhyDgpKrgpLAg4KSf4KWI4KSqIOCkleCksOClh+CkglwiLFxuICAgICAgdGFwQmluOiBcIuCkn+CljeCksOCliOCktiDgpKbgpYfgpJbgpKjgpYcg4KSV4KWHIOCksuCkv+CkjyDgpKzgpL/gpKgg4KSq4KSwIOCkn+CliOCkqiDgpJXgpLDgpYfgpIJcIixcbiAgICAgIHRydXN0U2NvcmU6IFwi4KS14KS/4KS24KWN4KS14KS+4KS4IOCkuOCljeCkleCli+CksFwiLFxuICAgICAgbGl2ZVNlbnRpbWVudDogXCLgpKzgpY3gpLDgpL7gpILgpKHgpY3gpLgg4KSq4KSwIOCksuCkvuCkh+CktSDgpJzgpKjgpK7gpKRcIixcbiAgICAgIGdldHRpbmdTdGFzaGVkOiBcIuCknOCkv+CkqOCljeCkueClh+CkgiDgpLjgpKzgpLjgpYcg4KSc4KS84KWN4KSv4KS+4KSm4KS+IOCksOCkluCkviDgpJzgpL4g4KSw4KS54KS+IOCkueCliFwiLFxuICAgICAgZ2V0dGluZ1RyYXNoZWQ6IFwi4KSc4KS/4KSo4KWN4KS54KWH4KSCIOCkuOCkrOCkuOClhyDgpJzgpLzgpY3gpK/gpL7gpKbgpL4g4KS54KSf4KS+4KSv4KS+IOCknOCkviDgpLDgpLngpL4g4KS54KWIXCIsXG4gICAgICBzb3RBd2FyZHM6IFwiU09UIOCkquClgeCksOCkuOCljeCkleCkvuCksFwiLFxuICAgICAgZ29Ub0Rhc2hib2FyZDogXCLgpKHgpYjgpLbgpKzgpYvgpLDgpY3gpKEg4KSq4KSwIOCknOCkvuCkj+CkglwiLFxuICAgICAgZXhwbG9yZUZlZWQ6IFwi4KSr4KS84KWA4KShIOCkpuClh+CkluClh+CkglwiLFxuICAgICAgc2NhblByb2R1Y3Q6IFwi4KSJ4KSk4KWN4KSq4KS+4KSmIOCkuOCljeCkleCliOCkqCDgpJXgpLDgpYfgpIJcIixcbiAgICAgIHN0YXNoZXM6IFwi4KSw4KSW4KWH4KSCIChTdGFzaGVzKVwiLFxuICAgICAgdHJhc2hlczogXCLgpLngpJ/gpL7gpI/gpIIgKFRyYXNoZXMpXCIsXG4gICAgfSxcbiAgfSxcbiAgemg6IHtcbiAgICBuYXY6IHtcbiAgICAgIGhvbWU6IFwi6aaW6aG1XCIsXG4gICAgICBmZWVkOiBcIuWKqOaAgVwiLFxuICAgICAgc2NhbjogXCLmiavnoIHpqoznnJ9cIixcbiAgICAgIGJyYW5kczogXCLlk4HniYzlupNcIixcbiAgICAgIGF3YXJkczogXCLlubTluqblpKflpZZcIixcbiAgICAgIGRhc2hib2FyZDogXCLlk4HniYzmjqfliLblj7BcIixcbiAgICAgIHByb2ZpbGU6IFwi5Liq5Lq65Li76aG1XCIsXG4gICAgICBtZXNzYWdlczogXCLmtojmga9cIixcbiAgICAgIHNpZ25JbjogXCLnmbvlvZVcIixcbiAgICAgIHNpZ25VcDogXCLms6jlhoxcIixcbiAgICAgIHNpZ25PdXQ6IFwi6YCA5Ye6XCIsXG4gICAgfSxcbiAgICBoZXJvOiB7XG4gICAgICBiYWRnZTogXCLlhajnkIPlk4HniYzkv6Hku7vmmbTpm6jooahcIixcbiAgICAgIGhlYWRsaW5lQmxhY2s6IFwi5L+d55WZ5YC85b6X5L+h6LWW55qE5aW954mp44CCXCIsXG4gICAgICBoZWFkbGluZUdvbGQ6IFwi5pud5YWJ5ZCN5LiN5Ymv5a6e55qE5qe954K544CCXCIsXG4gICAgICBzdWJ0aXRsZTogXCLmoLnmja7mgqjnmoTnnJ/lrp7mtojotLnkvZPpqozmipXlh7og54+N6JePIChTdGFzaCkg5oiWIOWQkOanvSAoVHJhc2gpIOKAlCDmnIDnnJ/lrp7nmoTlrqLmiLfkvZPpqozkv6Hlj7fjgIJcIixcbiAgICAgIHRhZ2xpbmU6IFwi5q+P5LiA5qyh55yf5a6e6KOB5Yaz6YO96K6p5ZOB54mM5pu06LS06L+R5raI6LS56ICF44CC56uL5Y2z5oqV56Wo77yB8J+UpVwiLFxuICAgICAgdGFwQ29pbjogXCLngrnlh7vph5HluIHmn6XnnIvnj43ol4/mppxcIixcbiAgICAgIHRhcEJpbjogXCLngrnlh7vlnoPlnL7mobbmn6XnnIvlkJDmp73mppxcIixcbiAgICAgIHRydXN0U2NvcmU6IFwi5L+h5Lu75oyH5pWwXCIsXG4gICAgICBsaXZlU2VudGltZW50OiBcIuWTgeeJjOWunuaXtuWPo+eikeWkp+ebmFwiLFxuICAgICAgZ2V0dGluZ1N0YXNoZWQ6IFwi5LuK5pel54Ot6Zeo54+N6JePIChTdGFzaGVkKVwiLFxuICAgICAgZ2V0dGluZ1RyYXNoZWQ6IFwi5LuK5pel54Ot6Zeo5ZCQ5qe9IChUcmFzaGVkKVwiLFxuICAgICAgc290QXdhcmRzOiBcIlNPVCDlk4HniYzlpKflpZZcIixcbiAgICAgIGdvVG9EYXNoYm9hcmQ6IFwi6L+b5YWl5ZOB54mM566h55CG5ZCO5Y+wXCIsXG4gICAgICBleHBsb3JlRmVlZDogXCLmtY/op4jnpL7ljLrliqjmgIFcIixcbiAgICAgIHNjYW5Qcm9kdWN0OiBcIuaJq+aPj+WVhuWTgeadoeeggemqjOecn1wiLFxuICAgICAgc3Rhc2hlczogXCLnj43ol48gKFN0YXNoZXMpXCIsXG4gICAgICB0cmFzaGVzOiBcIuWQkOanvSAoVHJhc2hlcylcIixcbiAgICB9LFxuICB9LFxuICBqYToge1xuICAgIG5hdjoge1xuICAgICAgaG9tZTogXCLjg5vjg7zjg6BcIixcbiAgICAgIGZlZWQ6IFwi44OV44Kj44O844OJXCIsXG4gICAgICBzY2FuOiBcIuOCueOCreODo+ODs1wiLFxuICAgICAgYnJhbmRzOiBcIuODluODqeODs+ODiVwiLFxuICAgICAgYXdhcmRzOiBcIuOCouODr+ODvOODiVwiLFxuICAgICAgZGFzaGJvYXJkOiBcIuODgOODg+OCt+ODpeODnOODvOODiVwiLFxuICAgICAgcHJvZmlsZTogXCLjg5fjg63jg5XjgqPjg7zjg6tcIixcbiAgICAgIG1lc3NhZ2VzOiBcIuODoeODg+OCu+ODvOOCuFwiLFxuICAgICAgc2lnbkluOiBcIuODreOCsOOCpOODs1wiLFxuICAgICAgc2lnblVwOiBcIuaWsOimj+eZu+mMslwiLFxuICAgICAgc2lnbk91dDogXCLjg63jgrDjgqLjgqbjg4hcIixcbiAgICB9LFxuICAgIGhlcm86IHtcbiAgICAgIGJhZGdlOiBcIuODluODqeODs+ODieS/oemgvOODkOODreODoeODvOOCv+ODvFwiLFxuICAgICAgaGVhZGxpbmVCbGFjazogXCLkvqHlgKTjgYLjgovjgoLjga7jgpLmrovjgZfjgIFcIixcbiAgICAgIGhlYWRsaW5lR29sZDogXCLkuI3oqqDlrp/jgarjgoLjga7jgavlo7DjgpLkuIrjgZLjgojjgYbjgIJcIixcbiAgICAgIHN1YnRpdGxlOiBcIuWun+mam+OBruODluODqeODs+ODieS9k+mok+OBq+WfuuOBpeOBhOOBpuOAjOOCreODvOODlyAoU3Rhc2gp44CN44GL44CM44OI44Op44OD44K344OlIChUcmFzaCnjgI3jgpLmipXnpajjgZfjgb7jgZfjgofjgYbjgIJcIixcbiAgICAgIHRhZ2xpbmU6IFwi44GZ44G544Gm44Gu6KmV5rG644GM44OW44Op44Oz44OJ44Go5raI6LK76ICF44KS6L+R44Gl44GR44G+44GZ44CC44GC44Gq44Gf44Gu5LiA56Wo44KS44CC8J+UpVwiLFxuICAgICAgdGFwQ29pbjogXCLph5HosqjjgpLjgr/jg4Pjg5fjgZfjgabjgq3jg7zjg5fkuIDopqfjgpLooajnpLpcIixcbiAgICAgIHRhcEJpbjogXCLjgrTjg5/nrrHjgpLjgr/jg4Pjg5fjgZfjgabjg4jjg6njg4Pjgrfjg6XkuIDopqfjgpLooajnpLpcIixcbiAgICAgIHRydXN0U2NvcmU6IFwi5L+h6aC844K544Kz44KiXCIsXG4gICAgICBsaXZlU2VudGltZW50OiBcIuODquOCouODq+OCv+OCpOODoOODu+ODluODqeODs+ODieipleS+oVwiLFxuICAgICAgZ2V0dGluZ1N0YXNoZWQ6IFwi5Lq65rCX44Gu44Kt44O844OXIChTdGFzaGVkKVwiLFxuICAgICAgZ2V0dGluZ1RyYXNoZWQ6IFwi5rOo55uu44Gu44OI44Op44OD44K344OlIChUcmFzaGVkKVwiLFxuICAgICAgc290QXdhcmRzOiBcIlNPVCDjgqLjg6/jg7zjg4lcIixcbiAgICAgIGdvVG9EYXNoYm9hcmQ6IFwi44OA44OD44K344Ol44Oc44O844OJ44G4XCIsXG4gICAgICBleHBsb3JlRmVlZDogXCLjg5XjgqPjg7zjg4njgpLopovjgotcIixcbiAgICAgIHNjYW5Qcm9kdWN0OiBcIuWVhuWTgeOCkuOCueOCreODo+ODs1wiLFxuICAgICAgc3Rhc2hlczogXCLjgq3jg7zjg5cgKFN0YXNoZXMpXCIsXG4gICAgICB0cmFzaGVzOiBcIuODiOODqeODg+OCt+ODpSAoVHJhc2hlcylcIixcbiAgICB9LFxuICB9LFxuICBrbzoge1xuICAgIG5hdjoge1xuICAgICAgaG9tZTogXCLtmYhcIixcbiAgICAgIGZlZWQ6IFwi7ZS865OcXCIsXG4gICAgICBzY2FuOiBcIuyKpOy6lFwiLFxuICAgICAgYnJhbmRzOiBcIuu4jOuenOuTnFwiLFxuICAgICAgYXdhcmRzOiBcIuyWtOybjOuTnFwiLFxuICAgICAgZGFzaGJvYXJkOiBcIuuMgOyLnOuztOuTnFwiLFxuICAgICAgcHJvZmlsZTogXCLtlITroZztlYRcIixcbiAgICAgIG1lc3NhZ2VzOiBcIuuplOyLnOyngFwiLFxuICAgICAgc2lnbkluOiBcIuuhnOq3uOyduFwiLFxuICAgICAgc2lnblVwOiBcIu2ajOybkOqwgOyehVwiLFxuICAgICAgc2lnbk91dDogXCLroZzqt7jslYTsm4NcIixcbiAgICB9LFxuICAgIGhlcm86IHtcbiAgICAgIGJhZGdlOiBcIuu4jOuenOuTnCDsi6DrorDrj4Qg67CU66Gc66+47YSwXCIsXG4gICAgICBoZWFkbGluZUJsYWNrOiBcIuqwgOy5mCDsnojripQg67iM656c65Oc64qUIOqwhOynge2VmOqzoCxcIixcbiAgICAgIGhlYWRsaW5lR29sZDogXCLsi6Trp53siqTrn6zsmrQg6rK97ZeY7JeQ64qUIOuqqeyGjOumrOulvCDrgrTshLjsmpQuXCIsXG4gICAgICBzdWJ0aXRsZTogXCLsi6TsoJwg67iM656c65OcIOqyve2XmOydhCDrsJTtg5XsnLzroZwg67O06rSAKFN0YXNoKSDrmJDripQg7Y+Q6riwKFRyYXNoKeyXkCDtiKztkZztlZjshLjsmpQuXCIsXG4gICAgICB0YWdsaW5lOiBcIuuqqOuToCDtj4nqsrDsnbQg67iM656c65Oc66W8IOyGjOu5hOyekOyXkOqyjCDrjZQg6rCA6rmd6rKMIOunjOuTreuLiOuLpC4g8J+UpVwiLFxuICAgICAgdGFwQ29pbjogXCLquIjtmZTrpbwg7YOt7ZWY7JesIOuztOq0gChTdGFzaCkg67O06riwXCIsXG4gICAgICB0YXBCaW46IFwi7Zy07KeA7Ya17J2EIO2Dre2VmOyXrCDtj5DquLAoVHJhc2gpIOuztOq4sFwiLFxuICAgICAgdHJ1c3RTY29yZTogXCLsi6DrorAg7KCQ7IiYXCIsXG4gICAgICBsaXZlU2VudGltZW50OiBcIuyLpOyLnOqwhCDruIzrnpzrk5wg66+87IusXCIsXG4gICAgICBnZXR0aW5nU3Rhc2hlZDogXCLsnbjquLAg67O06rSAIOu4jOuenOuTnFwiLFxuICAgICAgZ2V0dGluZ1RyYXNoZWQ6IFwi7KeR7KSRIOygnOuztCDruIzrnpzrk5xcIixcbiAgICAgIHNvdEF3YXJkczogXCJTT1Qg7Ja07JuM65OcXCIsXG4gICAgICBnb1RvRGFzaGJvYXJkOiBcIuu4jOuenOuTnCDrjIDsi5zrs7Trk5zroZwg7J2064+ZXCIsXG4gICAgICBleHBsb3JlRmVlZDogXCLtlLzrk5wg65GY65+s67O06riwXCIsXG4gICAgICBzY2FuUHJvZHVjdDogXCLrsJTsvZTrk5wv7KCV7ZKIIOyKpOy6lFwiLFxuICAgICAgc3Rhc2hlczogXCLrs7TqtIAgKFN0YXNoZXMpXCIsXG4gICAgICB0cmFzaGVzOiBcIu2PkOq4sCAoVHJhc2hlcylcIixcbiAgICB9LFxuICB9LFxufTtcbiJdfQ==