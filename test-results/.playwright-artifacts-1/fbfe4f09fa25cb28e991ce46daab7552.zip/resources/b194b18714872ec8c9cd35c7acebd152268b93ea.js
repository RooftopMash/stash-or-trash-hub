// Additional native translations for launch languages:
// Setswana (tn), Hausa (ha), Yorùbá (yo), Igbo (ig), Amharic (am), Sepedi (nso),
// Hebrew (he), Persian/Farsi (fa), Urdu (ur), Bengali (bn), Tamil (ta), Telugu (te),
// Marathi (mr), Gujarati (gu), Punjabi (pa), Thai (th), Vietnamese (vi), Malay (ms),
// Filipino (fil), Romanian (ro), Swedish (sv), Norwegian (no), Danish (da), Finnish (fi),
// Czech (cs), Slovak (sk), Hungarian (hu), Greek (el), Ukrainian (uk), Bulgarian (bg).
export const extraTranslations = {
	tn: {
		nav: {
			feed: "Ditiro",
			brands: "Mabokgoni",
			messages: "Melaetsa",
			awards: "Dikhumagadi",
			dashboard: "Letlapa",
			admin: "Molaodi",
			profile: "Poeletso",
			post: "Poso",
			signIn: "Tsena",
			signOut: "Tswa"
		},
		vote: {
			stash: "Boloka",
			trash: "Latlha",
			noVotes: "Ga gona ditlhopho",
			signInPrompt: "Tsena go romela katlholo ya gago.",
			stashCount: "{{count}} boloka",
			trashCount: "{{count}} latlha"
		},
		auth: {
			signIn: "Tsena",
			signUp: "Ikwadise",
			email: "Imeile",
			password: "Khunololo",
			displayName: "Leina la gago",
			createAccount: "Bopa akhaonto",
			continueGoogle: "Tswelela ka Google",
			welcome: "Re a go amogela gape!"
		},
		brand: {
			title: "Mabokgoni",
			subtitle: "Mabokgoni a a netefaditsweng le ditshwetso tsa setshaba.",
			verified: "Netefaditswe",
			trustScore: "Tekanyetso ya tshepo",
			searchPlaceholder: "Batla mabokgoni..."
		},
		awards: {
			title: "Dikhumagadi tsa SOT",
			tagline: "Sekala sa Tshepo sa Mabokgoni",
			leaderboard: "Ba ba eteletseng pele"
		}
	},
	ha: {
		nav: {
			feed: "Labarai",
			brands: "Kamfanoni",
			messages: "Saƙonni",
			awards: "Kyaututtuka",
			dashboard: "Allon Sarauta",
			admin: "Gudanarwa",
			profile: "Bayanai",
			post: "Aika",
			signIn: "Shiga",
			signOut: "Fita"
		},
		vote: {
			stash: "Ajiye",
			trash: "Zubar",
			noVotes: "Babu ƙuri'u tukuna",
			signInPrompt: "Shiga don bayar da ra'ayinka.",
			stashCount: "{{count}} an ajiye",
			trashCount: "{{count}} an zubar"
		},
		auth: {
			signIn: "Shiga",
			signUp: "Yi Rajista",
			email: "Imel",
			password: "Kalmar sirri",
			displayName: "Sunan nuni",
			createAccount: "Ƙirƙiri asusu",
			continueGoogle: "Ci gaba da Google",
			welcome: "Barka da dawowa!"
		},
		brand: {
			title: "Kamfanoni",
			subtitle: "Tantanceccen kamfanoni da ra'ayoyin jama'a kai tsaye.",
			verified: "An tabbatar",
			trustScore: "Makin amana",
			searchPlaceholder: "Nemi kamfani..."
		},
		awards: {
			title: "Kyaututtukan SOT",
			tagline: "Mizanin Amincewa da Alamar Kasuwanci",
			leaderboard: "Jagororin Shekara"
		}
	},
	yo: {
		nav: {
			feed: "Àfikún",
			brands: "Àwọn Ilé-iṣẹ́",
			messages: "Àwọn Ifiranṣẹ",
			awards: "Àwọn Àmì-ẹ̀yẹ",
			dashboard: "Pẹpẹ Iṣẹ́",
			admin: "Alákoso",
			profile: "Profaili",
			post: "Firanṣẹ",
			signIn: "Wọlé",
			signOut: "Jáde"
		},
		vote: {
			stash: "Tọ́jú",
			trash: "Dà nù",
			noVotes: "Kò tíì sí ìbò",
			signInPrompt: "Wọlé láti sọ èrò rẹ.",
			stashCount: "{{count}} tọ́jú",
			trashCount: "{{count}} dà nù"
		},
		auth: {
			signIn: "Wọlé",
			signUp: "Forúkọsílẹ̀",
			email: "Imeeli",
			password: "Ọrọ̀ aṣínà",
			displayName: "Orukọ rẹ",
			createAccount: "Ṣẹ̀dá àkọọ́lẹ̀",
			continueGoogle: "Tẹ̀síwájú pẹ̀lú Google",
			welcome: "Ẹ káàbọ̀ padà!"
		},
		brand: {
			title: "Àwọn Ilé-iṣẹ́",
			subtitle: "Àwọn ilé-iṣẹ́ tí a fọwọ́sí àti ìdájọ́ àwùjọ lórí wọn.",
			verified: "Fọwọ́sí",
			trustScore: "Iye ìgbẹ́kẹ̀lé",
			searchPlaceholder: "Wa àwọn ilé-iṣẹ́..."
		},
		awards: {
			title: "Àwọn Àmì-ẹ̀yẹ SOT",
			tagline: "Iwọn Ìgbẹ́kẹ̀lé Ilé-iṣẹ́",
			leaderboard: "Àtẹ Àwọn Asiwaju"
		}
	},
	ig: {
		nav: {
			feed: "Ihe ọhụrụ",
			brands: "Ụdị Ngwaahịa",
			messages: "Ozi",
			awards: "Ihe nrite",
			dashboard: "Mpempe akwụkwọ",
			admin: "Onye nlekọta",
			profile: "Profaịlụ",
			post: "Zipu",
			signIn: "Banye",
			signOut: "Pụọ"
		},
		vote: {
			stash: "Chekwaa",
			trash: "Tụfuo",
			noVotes: "Enweghị ntuli aka",
			signInPrompt: "Banye ka ikpebie.",
			stashCount: "{{count}} chekwaa",
			trashCount: "{{count}} tụfuo"
		},
		auth: {
			signIn: "Banye",
			signUp: "Debanye aha",
			email: "Ozi email",
			password: "Okwu nzuzo",
			displayName: "Aha ngosi",
			createAccount: "Mepụta akaụntụ",
			continueGoogle: "Gaa n'ihu na Google",
			welcome: "Nnọọ ọzọ!"
		},
		brand: {
			title: "Ụdị Ngwaahịa",
			subtitle: "Ụdị ngwaahịa kwadoro na mkpebi ndị mmadụ.",
			verified: "Kwadoro",
			trustScore: "Akara ntụkwasị obi",
			searchPlaceholder: "Chọọ ụdị..."
		},
		awards: {
			title: "Ihe nrite SOT",
			tagline: "Tebụl Ntụkwasị Obi Ụdị Ngwaahịa",
			leaderboard: "Ndị kachasị n'elu"
		}
	},
	am: {
		nav: {
			feed: "ምግቦች",
			brands: "ብራንዶች",
			messages: "መልዕክቶች",
			awards: "ሽልማቶች",
			dashboard: "ዳሽቦርድ",
			admin: "አስተዳዳሪ",
			profile: "መገለጫ",
			post: "ለጥፍ",
			signIn: "ግባ",
			signOut: "ውጣ"
		},
		vote: {
			stash: "አስቀምጥ",
			trash: "ጣለው",
			noVotes: "እስካሁን ድምጽ የለም",
			signInPrompt: "ውሳኔዎን ለመስጠት ይግቡ።",
			stashCount: "{{count}} አስቀምጥ",
			trashCount: "{{count}} ጣለው"
		},
		auth: {
			signIn: "ግባ",
			signUp: "ይመዝገቡ",
			email: "ኢሜይል",
			password: "የይለፍ ቃል",
			displayName: "የማሳያ ስም",
			createAccount: "መለያ ፍጠር",
			continueGoogle: "በGoogle ቀጥል",
			welcome: "እንኳን ደህና መጡ!"
		},
		brand: {
			title: "ብራንዶች",
			subtitle: "የተረጋገጡ ብራንዶች እና የቀጥታ ማህበረሰብ ውሳኔዎች።",
			verified: "የተረጋገጠ",
			trustScore: "የእምነት ደረጃ",
			searchPlaceholder: "ብራንዶችን ፈልግ..."
		},
		awards: {
			title: "የSOT ሽልማቶች",
			tagline: "የብራንድ እምነት መለኪያ",
			leaderboard: "የደረጃ ሰንጠረዥ"
		}
	},
	nso: {
		nav: {
			feed: "Dikagare",
			brands: "Mabrande",
			messages: "Melaetsa",
			awards: "Difoka",
			dashboard: "Dashboto",
			admin: "Molaodi",
			profile: "Boitsebišo",
			post: "Pasa",
			signIn: "Tsena",
			signOut: "Tšwa"
		},
		vote: {
			stash: "Boloka",
			trash: "Lahla",
			noVotes: "Ga go dikgetho tša bjale",
			signInPrompt: "Tsena go fana ka kahlolo ya gago.",
			stashCount: "{{count}} boloka",
			trashCount: "{{count}} lahla"
		},
		auth: {
			signIn: "Tsena",
			signUp: "Ingwadiše",
			email: "Imeile",
			password: "Phasewete",
			displayName: "Leina la go bonala",
			createAccount: "Hlama akhaonto",
			continueGoogle: "Tšwela pele ka Google",
			welcome: "O amogetšwe gape!"
		},
		brand: {
			title: "Mabrande",
			subtitle: "Mabrande a a netefaditšwego le dikahlolo tša setšhaba.",
			verified: "Netefaditšwe",
			trustScore: "Tekanyetšo ya tshepo",
			searchPlaceholder: "Nyaka mabrande..."
		},
		awards: {
			title: "Difoka tša SOT",
			tagline: "Tekanyetšo ya Tshepo ya Brand",
			leaderboard: "Baetapele ba Ngwaga"
		}
	},
	he: {
		nav: {
			feed: "פיד",
			brands: "מותגים",
			messages: "הודעות",
			awards: "פרסים",
			dashboard: "לוח בקרה",
			admin: "ניהול",
			profile: "פרופיל",
			post: "פרסם",
			signIn: "התחבר",
			signOut: "התנתק"
		},
		vote: {
			stash: "לשמור",
			trash: "לזרוק",
			noVotes: "אין עדיין קולות",
			signInPrompt: "התחבר כדי לתת את פסק הדין שלך.",
			stashCount: "{{count}} שמרו",
			trashCount: "{{count}} זרקו"
		},
		auth: {
			signIn: "התחבר",
			signUp: "הרשם",
			email: "דוא״ל",
			password: "סיסמה",
			displayName: "שם תצוגה",
			createAccount: "צור חשבון",
			continueGoogle: "המשך עם Google",
			welcome: "ברוך שובך!"
		},
		brand: {
			title: "מותגים",
			subtitle: "מותגים מאומתים ופסקי הדין של הקהילה בזמן אמת.",
			verified: "מאומת",
			trustScore: "מדד אמון",
			searchPlaceholder: "חפש מותגים..."
		},
		awards: {
			title: "פרסי SOT",
			tagline: "ברומטר אמון המותגים",
			leaderboard: "טבלת המובילים"
		}
	},
	fa: {
		nav: {
			feed: "فید",
			brands: "برندها",
			messages: "پیام‌ها",
			awards: "جوایز",
			dashboard: "داشبورد",
			admin: "مدیریت",
			profile: "پروفایل",
			post: "ارسال",
			signIn: "ورود",
			signOut: "خروج"
		},
		vote: {
			stash: "نگه‌داری",
			trash: "رد کردن",
			noVotes: "هنوز رأیی ثبت نشده",
			signInPrompt: "برای ثبت رأی خود وارد شوید.",
			stashCount: "{{count}} نگه‌داری",
			trashCount: "{{count}} رد کردن"
		},
		auth: {
			signIn: "ورود",
			signUp: "ثبت‌نام",
			email: "ایمیل",
			password: "رمز عبور",
			displayName: "نام نمایشی",
			createAccount: "ایجاد حساب",
			continueGoogle: "ادامه با گوگل",
			welcome: "خوش آمدید!"
		},
		brand: {
			title: "برندها",
			subtitle: "برندهای تأیید شده و قضاوت‌های زنده جامعه.",
			verified: "تأیید شده",
			trustScore: "امتیاز اعتماد",
			searchPlaceholder: "جستجوی برندها..."
		},
		awards: {
			title: "جوایز SOT",
			tagline: "فشارسنج اعتماد به برند",
			leaderboard: "جدول پیشتازان"
		}
	},
	ur: {
		nav: {
			feed: "فیڈ",
			brands: "برانڈز",
			messages: "پیغامات",
			awards: "ایوارڈز",
			dashboard: "ڈیش بورڈ",
			admin: "ایڈمن",
			profile: "پروفائل",
			post: "پوسٹ",
			signIn: "لاگ ان",
			signOut: "لاگ آؤٹ"
		},
		vote: {
			stash: "رکھیں",
			trash: "مسترد",
			noVotes: "ابھی تک کوئی ووٹ نہیں",
			signInPrompt: "اپنا فیصلہ دینے کے لیے لاگ ان کریں۔",
			stashCount: "{{count}} رکھیں",
			trashCount: "{{count}} مسترد"
		},
		auth: {
			signIn: "لاگ ان",
			signUp: "سائن اپ",
			email: "ای میل",
			password: "پاس ورڈ",
			displayName: "نام",
			createAccount: "اکاؤنٹ بنائیں",
			continueGoogle: "گوگل کے ساتھ جاری رکھیں",
			welcome: "خوش آمدید!"
		},
		brand: {
			title: "برانڈز",
			subtitle: "تصدیق شدہ برانڈز اور عوام کا براہ راست فیصلہ۔",
			verified: "تصدیق شدہ",
			trustScore: "اعتماد کا اسکور",
			searchPlaceholder: "برانڈ تلاش کریں..."
		},
		awards: {
			title: "ایس او ٹی ایوارڈز",
			tagline: "برانڈ پر عوام کے اعتماد کا پیمانہ",
			leaderboard: "لیڈر بورڈ"
		}
	},
	bn: {
		nav: {
			feed: "ফিড",
			brands: "ব্র্যান্ডস",
			messages: "বার্তা",
			awards: "পুরস্কার",
			dashboard: "ড্যাশবোর্ড",
			admin: "অ্যাডমিন",
			profile: "প্রোফাইল",
			post: "পোস্ট",
			signIn: "সাইন ইন",
			signOut: "সাইন আউট"
		},
		vote: {
			stash: "রাখুন",
			trash: "বাতিল",
			noVotes: "এখনও কোন ভোট নেই",
			signInPrompt: "আপনার রায় জানাতে সাইন ইন করুন।",
			stashCount: "{{count}} রাখুন",
			trashCount: "{{count}} বাতিল"
		},
		auth: {
			signIn: "সাইন ইন",
			signUp: "সাইন আপ",
			email: "ইমেল",
			password: "পাসওয়ার্ড",
			displayName: "নাম",
			createAccount: "অ্যাকাউন্ট তৈরি করুন",
			continueGoogle: "Google দিয়ে চালিয়ে যান",
			welcome: "স্বাগতম!"
		},
		brand: {
			title: "ব্র্যান্ডস",
			subtitle: "যাচাইকৃত ব্র্যান্ড এবং তাদের ওপর জনসাধারণের সরাসরি রায়।",
			verified: "যাচাইকৃত",
			trustScore: "আস্থার স্কোর",
			searchPlaceholder: "ব্র্যান্ড খুঁজুন..."
		},
		awards: {
			title: "SOT পুরস্কার",
			tagline: "ব্র্যান্ড আস্থার ব্যারোমিটার",
			leaderboard: "শীর্ষ তালিকা"
		}
	},
	ta: {
		nav: {
			feed: "பதிவுகள்",
			brands: "பிராண்டுகள்",
			messages: "செய்திகள்",
			awards: "விருதுகள்",
			dashboard: "முகப்பு பலகை",
			admin: "நிர்வாகி",
			profile: "சுயவிவரம்",
			post: "பதிவிடு",
			signIn: "உள்நுழைக",
			signOut: "வெளியேறுக"
		},
		vote: {
			stash: "சேமி",
			trash: "நிராகரி",
			noVotes: "வாக்குகள் இல்லை",
			signInPrompt: "உங்கள் தீர்ப்பை வழங்க உள்நுழைக.",
			stashCount: "{{count}} சேமி",
			trashCount: "{{count}} நிராகரி"
		},
		auth: {
			signIn: "உள்நுழைக",
			signUp: "பதிவு செய்க",
			email: "மின்னஞ்சல்",
			password: "கடவுச்சொல்",
			displayName: "பெயர்",
			createAccount: "கணக்கை உருவாக்குக",
			continueGoogle: "Google உடன் தொடர்க",
			welcome: "மீண்டும் வருக!"
		},
		brand: {
			title: "பிராண்டுகள்",
			subtitle: "சரிபார்க்கப்பட்ட பிராண்டுகள் மற்றும் மக்களின் நேரடித் தீர்ப்பு.",
			verified: "சரிபார்க்கப்பட்டது",
			trustScore: "நம்பகத்தன்மை மதிப்பெண்",
			searchPlaceholder: "பிராண்டைத் தேடுக..."
		},
		awards: {
			title: "SOT விருதுகள்",
			tagline: "பிராண்ட் நம்பிக்கையின் அளவுமானி",
			leaderboard: "முன்னணி பட்டியல்"
		}
	},
	te: {
		nav: {
			feed: "ఫీడ్",
			brands: "బ్రాండ్‌లు",
			messages: "సందేశాలు",
			awards: "అవార్డులు",
			dashboard: "డ్యాష్‌బోర్డ్",
			admin: "అడ్మిన్",
			profile: "ప్రొఫైల్",
			post: "పోస్ట్",
			signIn: "సైన్ ఇన్",
			signOut: "సైన్ అవుట్"
		},
		vote: {
			stash: "ఉంచు",
			trash: "వద్దు",
			noVotes: "ఇంకా ఓట్లు లేవు",
			signInPrompt: "మీ తీర్పు చెప్పడానికి సైన్ ఇన్ చేయండి.",
			stashCount: "{{count}} ఉంచు",
			trashCount: "{{count}} వద్దు"
		},
		auth: {
			signIn: "సైన్ ఇన్",
			signUp: "సైన్ అప్",
			email: "ఈమెయిల్",
			password: "పాస్‌వర్డ్",
			displayName: "పేరు",
			createAccount: "ఖాతాను సృష్టించండి",
			continueGoogle: "Googleతో కొనసాగించండి",
			welcome: "స్వాగతం!"
		},
		brand: {
			title: "బ్రాండ్‌లు",
			subtitle: "ధృవీకరించబడిన బ్రాండ్‌లు మరియు ప్రజల ప్రత్యక్ష తీర్పులు.",
			verified: "ధృవీకరించబడింది",
			trustScore: "విశ్వసనీయత స్కోర్",
			searchPlaceholder: "బ్రాండ్‌లను శోధించండి..."
		},
		awards: {
			title: "SOT అవార్డులు",
			tagline: "బ్రాండ్ విశ్వసనీయత బేరోమీటర్",
			leaderboard: "లీడర్‌బోర్డ్"
		}
	},
	mr: {
		nav: {
			feed: "फीड",
			brands: "ब्रँड्स",
			messages: "संदेश",
			awards: "पुरस्कार",
			dashboard: "डॅशबोर्ड",
			admin: "प्रशासक",
			profile: "प्रोफाइल",
			post: "पोस्ट",
			signIn: "साइन इन",
			signOut: "बाहेर पडा"
		},
		vote: {
			stash: "ठेवा",
			trash: "नको",
			noVotes: "अद्याप मते नाहीत",
			signInPrompt: "आपला निर्णय देण्यासाठी साइन इन करा.",
			stashCount: "{{count}} ठेवा",
			trashCount: "{{count}} नको"
		},
		auth: {
			signIn: "साइन इन",
			signUp: "नोंदणी करा",
			email: "ईमेल",
			password: "पासवर्ड",
			displayName: "नाव",
			createAccount: "खाते तयार करा",
			continueGoogle: "Google सह पुढे जा",
			welcome: "स्वागत आहे!"
		},
		brand: {
			title: "ब्रँड्स",
			subtitle: "प्रमाणित ब्रँड्स आणि लोकांचे थेट अभिप्राय.",
			verified: "प्रमाणित",
			trustScore: "विश्वासार्हता धावसंख्या",
			searchPlaceholder: "ब्रँड शोधा..."
		},
		awards: {
			title: "SOT पुरस्कार",
			tagline: "ब्रँड विश्वासाचे मोजमाप",
			leaderboard: "अव्वल यादी"
		}
	},
	gu: {
		nav: {
			feed: "ફીડ",
			brands: "બ્રાન્ડ્સ",
			messages: "સંદેશાઓ",
			awards: "એવોર્ડ્સ",
			dashboard: "ડેશબોર્ડ",
			admin: "એડમિન",
			profile: "પ્રોફાઇલ",
			post: "પોસ્ટ",
			signIn: "સાઇન ઇન",
			signOut: "સાઇન આઉટ"
		},
		vote: {
			stash: "સાચવો",
			trash: "નકારો",
			noVotes: "હજી સુધી કોઈ મત નથી",
			signInPrompt: "તમારો નિર્ણય આપવા માટે સાઇન ઇન કરો.",
			stashCount: "{{count}} સાચવો",
			trashCount: "{{count}} નકારો"
		},
		auth: {
			signIn: "સાઇન ઇન",
			signUp: "સાઇન અપ",
			email: "ઇમેઇલ",
			password: "પાસવર્ડ",
			displayName: "નામ",
			createAccount: "એકાઉન્ટ બનાવો",
			continueGoogle: "Google સાથે ચાલુ રાખો",
			welcome: "સ્વાગત છે!"
		},
		brand: {
			title: "બ્રાન્ડ્સ",
			subtitle: "ચકાસાયેલ બ્રાન્ડ્સ અને જનતાના નિર્ણયો.",
			verified: "ચકાસાયેલ",
			trustScore: "વિશ્વાસ સ્કોર",
			searchPlaceholder: "બ્રાન્ડ શોધો..."
		},
		awards: {
			title: "SOT એવોર્ડ્સ",
			tagline: "બ્રાન્ડ વિશ્વાસનું માપદંડ",
			leaderboard: "લીડરબોર્ડ"
		}
	},
	pa: {
		nav: {
			feed: "ਫੀਡ",
			brands: "ਬ੍ਰਾਂਡ",
			messages: "ਸੁਨੇਹੇ",
			awards: "ਇਨਾਮ",
			dashboard: "ਡੈਸ਼ਬੋਰਡ",
			admin: "ਐਡਮਿਨ",
			profile: "ਪ੍ਰੋਫਾਈਲ",
			post: "ਪੋਸਟ",
			signIn: "ਸਾਈਨ ਇਨ",
			signOut: "ਸਾਈਨ ਆਊਟ"
		},
		vote: {
			stash: "ਰੱਖੋ",
			trash: "ਰੱਦ",
			noVotes: "ਕੋਈ ਵੋਟ ਨਹੀਂ",
			signInPrompt: "ਆਪਣਾ ਫੈਸਲਾ ਦੇਣ ਲਈ ਸਾਈਨ ਇਨ ਕਰੋ।",
			stashCount: "{{count}} ਰੱਖੋ",
			trashCount: "{{count}} ਰੱਦ"
		},
		auth: {
			signIn: "ਸਾਈਨ ਇਨ",
			signUp: "ਸਾਈਨ ਅੱਪ",
			email: "ਈਮੇਲ",
			password: "ਪਾਸਵਰਡ",
			displayName: "ਨਾਮ",
			createAccount: "ਖਾਤਾ ਬਣਾਓ",
			continueGoogle: "Google ਨਾਲ ਜਾਰੀ ਰੱਖੋ",
			welcome: "ਜੀ ਆਇਆਂ ਨੂੰ!"
		},
		brand: {
			title: "ਬ੍ਰਾਂਡ",
			subtitle: "ਪ੍ਰਮਾਣਿਤ ਬ੍ਰਾਂਡ ਅਤੇ ਲੋਕਾਂ ਦਾ ਫੈਸਲਾ।",
			verified: "ਪ੍ਰਮਾਣਿਤ",
			trustScore: "ਭਰੋਸਾ ਸਕੋਰ",
			searchPlaceholder: "ਬ੍ਰਾਂਡ ਖੋਜੋ..."
		},
		awards: {
			title: "SOT ਇਨਾਮ",
			tagline: "ਬ੍ਰਾਂਡ ਭਰੋਸੇ ਦਾ ਪੈਮਾਨਾ",
			leaderboard: "ਲੀਡਰਬੋਰਡ"
		}
	},
	th: {
		nav: {
			feed: "ฟีด",
			brands: "แบรนด์",
			messages: "ข้อความ",
			awards: "รางวัล",
			dashboard: "แดชบอร์ด",
			admin: "ผู้ดูแลระบบ",
			profile: "โปรไฟล์",
			post: "โพสต์",
			signIn: "เข้าสู่ระบบ",
			signOut: "ออกจากระบบ"
		},
		vote: {
			stash: "เก็บไว้",
			trash: "ทิ้งไป",
			noVotes: "ยังไม่มีคะแนน",
			signInPrompt: "เข้าสู่ระบบเพื่อตัดสิน",
			stashCount: "{{count}} เก็บไว้",
			trashCount: "{{count}} ทิ้งไป"
		},
		auth: {
			signIn: "เข้าสู่ระบบ",
			signUp: "ลงทะเบียน",
			email: "อีเมล",
			password: "รหัสผ่าน",
			displayName: "ชื่อที่แสดง",
			createAccount: "สร้างบัญชี",
			continueGoogle: "ดำเนินการต่อด้วย Google",
			welcome: "ยินดีต้อนรับกลับ!"
		},
		brand: {
			title: "แบรนด์",
			subtitle: "แบรนด์ที่ผ่านการยืนยันและผลการตัดสินสดจากชุมชน",
			verified: "ยืนยันแล้ว",
			trustScore: "คะแนนความน่าเชื่อถือ",
			searchPlaceholder: "ค้นหาแบรนด์..."
		},
		awards: {
			title: "รางวัล SOT",
			tagline: "มาตรวัดความไว้วางใจในแบรนด์",
			leaderboard: "กระดานผู้นำ"
		}
	},
	vi: {
		nav: {
			feed: "Bảng tin",
			brands: "Thương hiệu",
			messages: "Tin nhắn",
			awards: "Giải thưởng",
			dashboard: "Bảng điều khiển",
			admin: "Quản trị",
			profile: "Hồ sơ",
			post: "Đăng",
			signIn: "Đăng nhập",
			signOut: "Đăng xuất"
		},
		vote: {
			stash: "Giữ lại",
			trash: "Loại bỏ",
			noVotes: "Chưa có bình chọn",
			signInPrompt: "Đăng nhập để đưa ra phán quyết của bạn.",
			stashCount: "{{count}} giữ lại",
			trashCount: "{{count}} loại bỏ"
		},
		auth: {
			signIn: "Đăng nhập",
			signUp: "Đăng ký",
			email: "Email",
			password: "Mật khẩu",
			displayName: "Tên hiển thị",
			createAccount: "Tạo tài khoản",
			continueGoogle: "Tiếp tục với Google",
			welcome: "Chào mừng trở lại!"
		},
		brand: {
			title: "Thương hiệu",
			subtitle: "Thương hiệu đã xác minh và phán quyết thực tế từ cộng đồng.",
			verified: "Đã xác minh",
			trustScore: "Điểm tin cậy",
			searchPlaceholder: "Tìm kiếm thương hiệu..."
		},
		awards: {
			title: "Giải thưởng SOT",
			tagline: "Thước Đo Niềm Tin Thương Hiệu",
			leaderboard: "Bảng xếp hạng"
		}
	},
	ms: {
		nav: {
			feed: "Suapan",
			brands: "Jenama",
			messages: "Mesej",
			awards: "Anugerah",
			dashboard: "Papan Pemuka",
			admin: "Pentadbir",
			profile: "Profil",
			post: "Siarkan",
			signIn: "Log masuk",
			signOut: "Log keluar"
		},
		vote: {
			stash: "Simpan",
			trash: "Buang",
			noVotes: "Belum ada undian",
			signInPrompt: "Log masuk untuk memberikan keputusan anda.",
			stashCount: "{{count}} simpan",
			trashCount: "{{count}} buang"
		},
		auth: {
			signIn: "Log masuk",
			signUp: "Daftar",
			email: "E-mel",
			password: "Kata laluan",
			displayName: "Nama paparan",
			createAccount: "Cipta akaun",
			continueGoogle: "Teruskan dengan Google",
			welcome: "Selamat kembali!"
		},
		brand: {
			title: "Jenama",
			subtitle: "Jenama disahkan dan keputusan komuniti secara langsung.",
			verified: "Disahkan",
			trustScore: "Skor kepercayaan",
			searchPlaceholder: "Cari jenama..."
		},
		awards: {
			title: "Anugerah SOT",
			tagline: "Barometer Kepercayaan Jenama",
			leaderboard: "Papan Pendahulu"
		}
	},
	fil: {
		nav: {
			feed: "Feed",
			brands: "Mga Brand",
			messages: "Mensahe",
			awards: "Mga Parangal",
			dashboard: "Dashboard",
			admin: "Admin",
			profile: "Profile",
			post: "Mag-post",
			signIn: "Mag-sign in",
			signOut: "Mag-sign out"
		},
		vote: {
			stash: "Itago",
			trash: "Itapon",
			noVotes: "Wala pang boto",
			signInPrompt: "Mag-sign in para magbigay ng iyong hatol.",
			stashCount: "{{count}} itago",
			trashCount: "{{count}} itapon"
		},
		auth: {
			signIn: "Mag-sign in",
			signUp: "Mag-sign up",
			email: "Email",
			password: "Password",
			displayName: "Pangalan",
			createAccount: "Gumawa ng account",
			continueGoogle: "Magpatuloy sa Google",
			welcome: "Maligayang pagbabalik!"
		},
		brand: {
			title: "Mga Brand",
			subtitle: "Mga beripikadong brand at live na hatol ng komunidad.",
			verified: "Beripikado",
			trustScore: "Marka ng tiwala",
			searchPlaceholder: "Maghanap ng brand..."
		},
		awards: {
			title: "Mga Parangal ng SOT",
			tagline: "Ang Barometro ng Tiwala sa Brand",
			leaderboard: "Leaderboard"
		}
	},
	ro: {
		nav: {
			feed: "Flux",
			brands: "Branduri",
			messages: "Mesaje",
			awards: "Premii",
			dashboard: "Panou de control",
			admin: "Admin",
			profile: "Profil",
			post: "Postează",
			signIn: "Conectare",
			signOut: "Deconectare"
		},
		vote: {
			stash: "Păstrează",
			trash: "Aruncă",
			noVotes: "Fără voturi încă",
			signInPrompt: "Conectează-te pentru a vota.",
			stashCount: "{{count}} păstrează",
			trashCount: "{{count}} aruncă"
		},
		auth: {
			signIn: "Conectare",
			signUp: "Înregistrare",
			email: "Email",
			password: "Parolă",
			displayName: "Nume afișat",
			createAccount: "Creează cont",
			continueGoogle: "Continuă cu Google",
			welcome: "Bine ai revenit!"
		},
		brand: {
			title: "Branduri",
			subtitle: "Branduri verificate și verdictul comunității în direct.",
			verified: "Verificat",
			trustScore: "Scor de încredere",
			searchPlaceholder: "Caută branduri..."
		},
		awards: {
			title: "Premiile SOT",
			tagline: "Barometrul Încrederii în Branduri",
			leaderboard: "Clasament"
		}
	},
	sv: {
		nav: {
			feed: "Flöde",
			brands: "Varumärken",
			messages: "Meddelanden",
			awards: "Utmärkelser",
			dashboard: "Översikt",
			admin: "Admin",
			profile: "Profil",
			post: "Inlägg",
			signIn: "Logga in",
			signOut: "Logga ut"
		},
		vote: {
			stash: "Behåll",
			trash: "Kasta",
			noVotes: "Inga röster än",
			signInPrompt: "Logga in för att avge ditt omdöme.",
			stashCount: "{{count}} behåll",
			trashCount: "{{count}} kasta"
		},
		auth: {
			signIn: "Logga in",
			signUp: "Skapa konto",
			email: "E-post",
			password: "Lösenord",
			displayName: "Visningsnamn",
			createAccount: "Skapa konto",
			continueGoogle: "Fortsätt med Google",
			welcome: "Välkommen tillbaka!"
		},
		brand: {
			title: "Varumärken",
			subtitle: "Verifierade varumärken och communityns direkta omdömen.",
			verified: "Verifierad",
			trustScore: "Förtroendepoäng",
			searchPlaceholder: "Sök varumärken..."
		},
		awards: {
			title: "SOT Awards",
			tagline: "Varumärkens Förtroendebarometer",
			leaderboard: "Topplista"
		}
	},
	no: {
		nav: {
			feed: "Strøm",
			brands: "Merkevarer",
			messages: "Meldinger",
			awards: "Priser",
			dashboard: "Dashbord",
			admin: "Admin",
			profile: "Profil",
			post: "Publiser",
			signIn: "Logg inn",
			signOut: "Logg ut"
		},
		vote: {
			stash: "Behold",
			trash: "Kast",
			noVotes: "Ingen stemmer ennå",
			signInPrompt: "Logg inn for å stemme.",
			stashCount: "{{count}} behold",
			trashCount: "{{count}} kast"
		},
		auth: {
			signIn: "Logg inn",
			signUp: "Registrer deg",
			email: "E-post",
			password: "Passord",
			displayName: "Visningsnavn",
			createAccount: "Opprett konto",
			continueGoogle: "Fortsett med Google",
			welcome: "Velkommen tilbake!"
		},
		brand: {
			title: "Merkevarer",
			subtitle: "Verifiserte merkevarer og folkets sanntidsdom.",
			verified: "Verifisert",
			trustScore: "Tillitsscore",
			searchPlaceholder: "Søk etter merkevarer..."
		},
		awards: {
			title: "SOT Awards",
			tagline: "Folkets Dom over Merkevarer",
			leaderboard: "Ledertavle"
		}
	},
	da: {
		nav: {
			feed: "Feed",
			brands: "Brands",
			messages: "Beskeder",
			awards: "Priser",
			dashboard: "Kontrolpanel",
			admin: "Admin",
			profile: "Profil",
			post: "Opret opslag",
			signIn: "Log ind",
			signOut: "Log ud"
		},
		vote: {
			stash: "Gem",
			trash: "Kassér",
			noVotes: "Ingen stemmer endnu",
			signInPrompt: "Log ind for at afgive din dom.",
			stashCount: "{{count}} gem",
			trashCount: "{{count}} kassér"
		},
		auth: {
			signIn: "Log ind",
			signUp: "Opret konto",
			email: "E-mail",
			password: "Adgangskode",
			displayName: "Vist navn",
			createAccount: "Opret konto",
			continueGoogle: "Fortsæt med Google",
			welcome: "Velkommen tilbage!"
		},
		brand: {
			title: "Brands",
			subtitle: "Verificerede brands og fællesskabets live-vurdering.",
			verified: "Verificeret",
			trustScore: "Tillidsscore",
			searchPlaceholder: "Søg efter brands..."
		},
		awards: {
			title: "SOT Awards",
			tagline: "Barometret for Brand-tillid",
			leaderboard: "Rangliste"
		}
	},
	fi: {
		nav: {
			feed: "Syöte",
			brands: "Brändit",
			messages: "Viestit",
			awards: "Palkinnot",
			dashboard: "Kojelauta",
			admin: "Ylläpito",
			profile: "Profiili",
			post: "Julkaise",
			signIn: "Kirjaudu sisään",
			signOut: "Kirjaudu ulos"
		},
		vote: {
			stash: "Säilytä",
			trash: "Hylkää",
			noVotes: "Ei ääniä vielä",
			signInPrompt: "Kirjaudu sisään antaaksesi tuomiosi.",
			stashCount: "{{count}} säilytä",
			trashCount: "{{count}} hylkää"
		},
		auth: {
			signIn: "Kirjaudu sisään",
			signUp: "Rekisteröidy",
			email: "Sähköposti",
			password: "Salasana",
			displayName: "Nimimerkki",
			createAccount: "Luo tili",
			continueGoogle: "Jatka Googlella",
			welcome: "Tervetuloa takaisin!"
		},
		brand: {
			title: "Brändit",
			subtitle: "Vahvistetut brändit ja yhteisön suora tuomio.",
			verified: "Vahvistettu",
			trustScore: "Luottamusindeksi",
			searchPlaceholder: "Etsi brändejä..."
		},
		awards: {
			title: "SOT Awards",
			tagline: "Brändien Luottamusbarometri",
			leaderboard: "Kärkitaulukko"
		}
	},
	cs: {
		nav: {
			feed: "Příspěvky",
			brands: "Značky",
			messages: "Zprávy",
			awards: "Ocenění",
			dashboard: "Přehled",
			admin: "Správa",
			profile: "Profil",
			post: "Vložit",
			signIn: "Přihlásit se",
			signOut: "Odhlásit se"
		},
		vote: {
			stash: "Nechat",
			trash: "Zahodit",
			noVotes: "Zatím žádné hlasy",
			signInPrompt: "Přihlaste se a vyjádřete svůj verdikt.",
			stashCount: "{{count}} nechat",
			trashCount: "{{count}} zahodit"
		},
		auth: {
			signIn: "Přihlásit se",
			signUp: "Registrovat",
			email: "E-mail",
			password: "Heslo",
			displayName: "Zobrazované jméno",
			createAccount: "Vytvořit účet",
			continueGoogle: "Pokračovat přes Google",
			welcome: "Vítejte zpět!"
		},
		brand: {
			title: "Značky",
			subtitle: "Ověřené značky a živý verdikt komunity.",
			verified: "Ověřeno",
			trustScore: "Skóre důvěry",
			searchPlaceholder: "Hledat značky..."
		},
		awards: {
			title: "Ceny SOT",
			tagline: "Barometr důvěry ve značky",
			leaderboard: "Žebříček"
		}
	},
	sk: {
		nav: {
			feed: "Príspevky",
			brands: "Značky",
			messages: "Správy",
			awards: "Ocenenia",
			dashboard: "Prehľad",
			admin: "Správca",
			profile: "Profil",
			post: "Pridať",
			signIn: "Prihlásiť sa",
			signOut: "Odhlásiť sa"
		},
		vote: {
			stash: "Nechať",
			trash: "Zahodiť",
			noVotes: "Zatiaľ žiadne hlasy",
			signInPrompt: "Prihláste sa a vyjadrite svoj verdikt.",
			stashCount: "{{count}} nechať",
			trashCount: "{{count}} zahodiť"
		},
		auth: {
			signIn: "Prihlásiť sa",
			signUp: "Registrovať sa",
			email: "E-mail",
			password: "Heslo",
			displayName: "Zobrazované meno",
			createAccount: "Vytvoriť účet",
			continueGoogle: "Pokračovať cez Google",
			welcome: "Vitajte späť!"
		},
		brand: {
			title: "Značky",
			subtitle: "Overené značky a živý verdikt komunity.",
			verified: "Overené",
			trustScore: "Skóre dôvery",
			searchPlaceholder: "Hľadať značky..."
		},
		awards: {
			title: "Ceny SOT",
			tagline: "Barometer dôvery v značky",
			leaderboard: "Rebríček"
		}
	},
	hu: {
		nav: {
			feed: "Hírcsatorna",
			brands: "Márkák",
			messages: "Üzenetek",
			awards: "Díjak",
			dashboard: "Irányítópult",
			admin: "Admin",
			profile: "Profil",
			post: "Közzététel",
			signIn: "Bejelentkezés",
			signOut: "Kijelentkezés"
		},
		vote: {
			stash: "Megtartás",
			trash: "Kuka",
			noVotes: "Még nincs szavazat",
			signInPrompt: "Jelentkezz be a véleményed leadásához.",
			stashCount: "{{count}} megtartás",
			trashCount: "{{count}} kuka"
		},
		auth: {
			signIn: "Bejelentkezés",
			signUp: "Regisztráció",
			email: "E-mail",
			password: "Jelszó",
			displayName: "Megjelenített név",
			createAccount: "Fiók létrehozása",
			continueGoogle: "Folytatás Google-lal",
			welcome: "Üdv újra itt!"
		},
		brand: {
			title: "Márkák",
			subtitle: "Hitelesített márkák és a közösség élő ítélete.",
			verified: "Hitelesített",
			trustScore: "Bizalmi pontszám",
			searchPlaceholder: "Márkák keresése..."
		},
		awards: {
			title: "SOT Díjak",
			tagline: "A Márkabizalom Barométere",
			leaderboard: "Rangsor"
		}
	},
	el: {
		nav: {
			feed: "Ροή",
			brands: "Μάρκες",
			messages: "Μηνύματα",
			awards: "Βραβεία",
			dashboard: "Πίνακας Ελέγχου",
			admin: "Διαχείριση",
			profile: "Προφίλ",
			post: "Δημοσίευση",
			signIn: "Σύνδεση",
			signOut: "Αποσύνδεση"
		},
		vote: {
			stash: "Κράτα",
			trash: "Πέτα",
			noVotes: "Δεν υπάρχουν ψήφοι ακόμη",
			signInPrompt: "Συνδεθείτε για να ψηφίσετε.",
			stashCount: "{{count}} κράτα",
			trashCount: "{{count}} πέτα"
		},
		auth: {
			signIn: "Σύνδεση",
			signUp: "Εγγραφή",
			email: "Email",
			password: "Κωδικός",
			displayName: "Όνομα εμφάνισης",
			createAccount: "Δημιουργία λογαριασμού",
			continueGoogle: "Συνέχεια με Google",
			welcome: "Καλώς ήρθατε πίσω!"
		},
		brand: {
			title: "Μάρκες",
			subtitle: "Επαληθευμένες μάρκες και ζωντανή ετυμηγορία της κοινότητας.",
			verified: "Επαληθευμένο",
			trustScore: "Δείκτης εμπιστοσύνης",
			searchPlaceholder: "Αναζήτηση μαρκών..."
		},
		awards: {
			title: "Βραβεία SOT",
			tagline: "Το Βαρόμετρο Εμπιστοσύνης στις Μάρκες",
			leaderboard: "Πίνακας Κατάταξης"
		}
	},
	uk: {
		nav: {
			feed: "Стрічка",
			brands: "Бренди",
			messages: "Повідомлення",
			awards: "Нагороди",
			dashboard: "Панель",
			admin: "Адмін",
			profile: "Профіль",
			post: "Опублікувати",
			signIn: "Увійти",
			signOut: "Вийти"
		},
		vote: {
			stash: "Залишити",
			trash: "Викинути",
			noVotes: "Ще немає голосів",
			signInPrompt: "Увійдіть, щоб винести свій вердикт.",
			stashCount: "{{count}} залишити",
			trashCount: "{{count}} викинути"
		},
		auth: {
			signIn: "Увійти",
			signUp: "Зареєструватися",
			email: "Ел. пошта",
			password: "Пароль",
			displayName: "Ім'я",
			createAccount: "Створити обліковий запис",
			continueGoogle: "Продовжити через Google",
			welcome: "З поверненням!"
		},
		brand: {
			title: "Бренди",
			subtitle: "Перевірені бренди та живий вердикт спільноти.",
			verified: "Перевірено",
			trustScore: "Рейтинг довіри",
			searchPlaceholder: "Пошук брендів..."
		},
		awards: {
			title: "Премії SOT",
			tagline: "Барометр Довіри до Брендів",
			leaderboard: "Таблиця лідерів"
		}
	},
	bg: {
		nav: {
			feed: "Поток",
			brands: "Брандове",
			messages: "Съобщения",
			awards: "Награди",
			dashboard: "Табло",
			admin: "Администратор",
			profile: "Профил",
			post: "Публикувай",
			signIn: "Вход",
			signOut: "Изход"
		},
		vote: {
			stash: "Запази",
			trash: "Изхвърли",
			noVotes: "Все още няма гласове",
			signInPrompt: "Влезте, за да дадете своята присъда.",
			stashCount: "{{count}} запази",
			trashCount: "{{count}} изхвърли"
		},
		auth: {
			signIn: "Вход",
			signUp: "Регистрация",
			email: "Имейл",
			password: "Парола",
			displayName: "Име",
			createAccount: "Създаване на профил",
			continueGoogle: "Продължи с Google",
			welcome: "Добре дошли отново!"
		},
		brand: {
			title: "Брандове",
			subtitle: "Проверени брандове и присъдата на общността в реално време.",
			verified: "Проверен",
			trustScore: "Оценка на доверие",
			searchPlaceholder: "Търсене на брандове..."
		},
		awards: {
			title: "Награди SOT",
			tagline: "Барометър на Доверието в Брандовете",
			leaderboard: "Класация"
		}
	}
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7O0FBT0EsT0FBTyxNQUFNLG9CQUF5RDtDQUNwRSxJQUFJO0VBQ0YsS0FBSztHQUFFLE1BQU07R0FBVSxRQUFRO0dBQWEsVUFBVTtHQUFZLFFBQVE7R0FBZSxXQUFXO0dBQVcsT0FBTztHQUFXLFNBQVM7R0FBWSxNQUFNO0dBQVEsUUFBUTtHQUFTLFNBQVM7RUFBTztFQUNyTSxNQUFNO0dBQUUsT0FBTztHQUFVLE9BQU87R0FBVSxTQUFTO0dBQXFCLGNBQWM7R0FBcUMsWUFBWTtHQUFvQixZQUFZO0VBQW1CO0VBQzFMLE1BQU07R0FBRSxRQUFRO0dBQVMsUUFBUTtHQUFZLE9BQU87R0FBVSxVQUFVO0dBQWEsYUFBYTtHQUFpQixlQUFlO0dBQWlCLGdCQUFnQjtHQUFzQixTQUFTO0VBQXdCO0VBQzFOLE9BQU87R0FBRSxPQUFPO0dBQWEsVUFBVTtHQUE0RCxVQUFVO0dBQWdCLFlBQVk7R0FBd0IsbUJBQW1CO0VBQXFCO0VBQ3pNLFFBQVE7R0FBRSxPQUFPO0dBQXVCLFNBQVM7R0FBaUMsYUFBYTtFQUF3QjtDQUN6SDtDQUNBLElBQUk7RUFDRixLQUFLO0dBQUUsTUFBTTtHQUFXLFFBQVE7R0FBYSxVQUFVO0dBQVcsUUFBUTtHQUFlLFdBQVc7R0FBaUIsT0FBTztHQUFhLFNBQVM7R0FBVyxNQUFNO0dBQVEsUUFBUTtHQUFTLFNBQVM7RUFBTztFQUM1TSxNQUFNO0dBQUUsT0FBTztHQUFTLE9BQU87R0FBUyxTQUFTO0dBQXNCLGNBQWM7R0FBaUMsWUFBWTtHQUFzQixZQUFZO0VBQXFCO0VBQ3pMLE1BQU07R0FBRSxRQUFRO0dBQVMsUUFBUTtHQUFjLE9BQU87R0FBUSxVQUFVO0dBQWdCLGFBQWE7R0FBYyxlQUFlO0dBQWlCLGdCQUFnQjtHQUFxQixTQUFTO0VBQW1CO0VBQ3BOLE9BQU87R0FBRSxPQUFPO0dBQWEsVUFBVTtHQUF5RCxVQUFVO0dBQWUsWUFBWTtHQUFlLG1CQUFtQjtFQUFrQjtFQUN6TCxRQUFRO0dBQUUsT0FBTztHQUFvQixTQUFTO0dBQXdDLGFBQWE7RUFBb0I7Q0FDekg7Q0FDQSxJQUFJO0VBQ0YsS0FBSztHQUFFLE1BQU07R0FBVSxRQUFRO0dBQWlCLFVBQVU7R0FBaUIsUUFBUTtHQUFpQixXQUFXO0dBQWEsT0FBTztHQUFXLFNBQVM7R0FBWSxNQUFNO0dBQVcsUUFBUTtHQUFRLFNBQVM7RUFBTztFQUNwTixNQUFNO0dBQUUsT0FBTztHQUFTLE9BQU87R0FBUyxTQUFTO0dBQWlCLGNBQWM7R0FBd0IsWUFBWTtHQUFtQixZQUFZO0VBQWtCO0VBQ3JLLE1BQU07R0FBRSxRQUFRO0dBQVEsUUFBUTtHQUFlLE9BQU87R0FBVSxVQUFVO0dBQWMsYUFBYTtHQUFZLGVBQWU7R0FBa0IsZ0JBQWdCO0dBQTBCLFNBQVM7RUFBaUI7RUFDdE4sT0FBTztHQUFFLE9BQU87R0FBaUIsVUFBVTtHQUF5RCxVQUFVO0dBQVcsWUFBWTtHQUFrQixtQkFBbUI7RUFBc0I7RUFDaE0sUUFBUTtHQUFFLE9BQU87R0FBcUIsU0FBUztHQUE0QixhQUFhO0VBQW1CO0NBQzdHO0NBQ0EsSUFBSTtFQUNGLEtBQUs7R0FBRSxNQUFNO0dBQWEsUUFBUTtHQUFnQixVQUFVO0dBQU8sUUFBUTtHQUFhLFdBQVc7R0FBa0IsT0FBTztHQUFnQixTQUFTO0dBQVksTUFBTTtHQUFRLFFBQVE7R0FBUyxTQUFTO0VBQU07RUFDL00sTUFBTTtHQUFFLE9BQU87R0FBVyxPQUFPO0dBQVMsU0FBUztHQUFxQixjQUFjO0dBQXFCLFlBQVk7R0FBcUIsWUFBWTtFQUFrQjtFQUMxSyxNQUFNO0dBQUUsUUFBUTtHQUFTLFFBQVE7R0FBZSxPQUFPO0dBQWEsVUFBVTtHQUFjLGFBQWE7R0FBYSxlQUFlO0dBQWtCLGdCQUFnQjtHQUF1QixTQUFTO0VBQVk7RUFDbk4sT0FBTztHQUFFLE9BQU87R0FBZ0IsVUFBVTtHQUE2QyxVQUFVO0dBQVcsWUFBWTtHQUFzQixtQkFBbUI7RUFBYztFQUMvSyxRQUFRO0dBQUUsT0FBTztHQUFpQixTQUFTO0dBQW1DLGFBQWE7RUFBb0I7Q0FDakg7Q0FDQSxJQUFJO0VBQ0YsS0FBSztHQUFFLE1BQU07R0FBUSxRQUFRO0dBQVMsVUFBVTtHQUFVLFFBQVE7R0FBUyxXQUFXO0dBQVMsT0FBTztHQUFVLFNBQVM7R0FBUSxNQUFNO0dBQU8sUUFBUTtHQUFNLFNBQVM7RUFBSztFQUMxSyxNQUFNO0dBQUUsT0FBTztHQUFTLE9BQU87R0FBTyxTQUFTO0dBQWlCLGNBQWM7R0FBb0IsWUFBWTtHQUFtQixZQUFZO0VBQWdCO0VBQzdKLE1BQU07R0FBRSxRQUFRO0dBQU0sUUFBUTtHQUFTLE9BQU87R0FBUSxVQUFVO0dBQVcsYUFBYTtHQUFXLGVBQWU7R0FBVyxnQkFBZ0I7R0FBZSxTQUFTO0VBQWU7RUFDcEwsT0FBTztHQUFFLE9BQU87R0FBUyxVQUFVO0dBQXNDLFVBQVU7R0FBVSxZQUFZO0dBQWEsbUJBQW1CO0VBQWdCO0VBQ3pKLFFBQVE7R0FBRSxPQUFPO0dBQWMsU0FBUztHQUFtQixhQUFhO0VBQWE7Q0FDdkY7Q0FDQSxLQUFLO0VBQ0gsS0FBSztHQUFFLE1BQU07R0FBWSxRQUFRO0dBQVksVUFBVTtHQUFZLFFBQVE7R0FBVSxXQUFXO0dBQVksT0FBTztHQUFXLFNBQVM7R0FBYyxNQUFNO0dBQVEsUUFBUTtHQUFTLFNBQVM7RUFBTztFQUNwTSxNQUFNO0dBQUUsT0FBTztHQUFVLE9BQU87R0FBUyxTQUFTO0dBQTRCLGNBQWM7R0FBcUMsWUFBWTtHQUFvQixZQUFZO0VBQWtCO0VBQy9MLE1BQU07R0FBRSxRQUFRO0dBQVMsUUFBUTtHQUFhLE9BQU87R0FBVSxVQUFVO0dBQWEsYUFBYTtHQUFzQixlQUFlO0dBQWtCLGdCQUFnQjtHQUF5QixTQUFTO0VBQW9CO0VBQ2hPLE9BQU87R0FBRSxPQUFPO0dBQVksVUFBVTtHQUEwRCxVQUFVO0dBQWdCLFlBQVk7R0FBd0IsbUJBQW1CO0VBQW9CO0VBQ3JNLFFBQVE7R0FBRSxPQUFPO0dBQWtCLFNBQVM7R0FBaUMsYUFBYTtFQUFzQjtDQUNsSDtDQUNBLElBQUk7RUFDRixLQUFLO0dBQUUsTUFBTTtHQUFPLFFBQVE7R0FBVSxVQUFVO0dBQVUsUUFBUTtHQUFTLFdBQVc7R0FBWSxPQUFPO0dBQVMsU0FBUztHQUFVLE1BQU07R0FBUSxRQUFRO0dBQVMsU0FBUztFQUFRO0VBQ3JMLE1BQU07R0FBRSxPQUFPO0dBQVMsT0FBTztHQUFTLFNBQVM7R0FBbUIsY0FBYztHQUFrQyxZQUFZO0dBQWtCLFlBQVk7RUFBaUI7RUFDL0ssTUFBTTtHQUFFLFFBQVE7R0FBUyxRQUFRO0dBQVEsT0FBTztHQUFTLFVBQVU7R0FBUyxhQUFhO0dBQVksZUFBZTtHQUFhLGdCQUFnQjtHQUFrQixTQUFTO0VBQWE7RUFDekwsT0FBTztHQUFFLE9BQU87R0FBVSxVQUFVO0dBQWlELFVBQVU7R0FBUyxZQUFZO0dBQVksbUJBQW1CO0VBQWdCO0VBQ25LLFFBQVE7R0FBRSxPQUFPO0dBQVksU0FBUztHQUF1QixhQUFhO0VBQWdCO0NBQzVGO0NBQ0EsSUFBSTtFQUNGLEtBQUs7R0FBRSxNQUFNO0dBQU8sUUFBUTtHQUFVLFVBQVU7R0FBVyxRQUFRO0dBQVMsV0FBVztHQUFXLE9BQU87R0FBVSxTQUFTO0dBQVcsTUFBTTtHQUFTLFFBQVE7R0FBUSxTQUFTO0VBQU87RUFDdEwsTUFBTTtHQUFFLE9BQU87R0FBWSxPQUFPO0dBQVcsU0FBUztHQUFzQixjQUFjO0dBQStCLFlBQVk7R0FBc0IsWUFBWTtFQUFvQjtFQUMzTCxNQUFNO0dBQUUsUUFBUTtHQUFRLFFBQVE7R0FBVyxPQUFPO0dBQVMsVUFBVTtHQUFZLGFBQWE7R0FBYyxlQUFlO0dBQWMsZ0JBQWdCO0dBQWlCLFNBQVM7RUFBYTtFQUNoTSxPQUFPO0dBQUUsT0FBTztHQUFVLFVBQVU7R0FBNkMsVUFBVTtHQUFhLFlBQVk7R0FBaUIsbUJBQW1CO0VBQW1CO0VBQzNLLFFBQVE7R0FBRSxPQUFPO0dBQWEsU0FBUztHQUEwQixhQUFhO0VBQWdCO0NBQ2hHO0NBQ0EsSUFBSTtFQUNGLEtBQUs7R0FBRSxNQUFNO0dBQU8sUUFBUTtHQUFVLFVBQVU7R0FBVyxRQUFRO0dBQVcsV0FBVztHQUFZLE9BQU87R0FBUyxTQUFTO0dBQVcsTUFBTTtHQUFRLFFBQVE7R0FBVSxTQUFTO0VBQVU7RUFDNUwsTUFBTTtHQUFFLE9BQU87R0FBUyxPQUFPO0dBQVMsU0FBUztHQUF5QixjQUFjO0dBQXVDLFlBQVk7R0FBbUIsWUFBWTtFQUFrQjtFQUM1TCxNQUFNO0dBQUUsUUFBUTtHQUFVLFFBQVE7R0FBVyxPQUFPO0dBQVUsVUFBVTtHQUFXLGFBQWE7R0FBTyxlQUFlO0dBQWlCLGdCQUFnQjtHQUEyQixTQUFTO0VBQWE7RUFDeE0sT0FBTztHQUFFLE9BQU87R0FBVSxVQUFVO0dBQWlELFVBQVU7R0FBYSxZQUFZO0dBQW1CLG1CQUFtQjtFQUFxQjtFQUNuTCxRQUFRO0dBQUUsT0FBTztHQUFxQixTQUFTO0dBQXFDLGFBQWE7RUFBWTtDQUMvRztDQUNBLElBQUk7RUFDRixLQUFLO0dBQUUsTUFBTTtHQUFPLFFBQVE7R0FBYyxVQUFVO0dBQVUsUUFBUTtHQUFZLFdBQVc7R0FBYyxPQUFPO0dBQVksU0FBUztHQUFZLE1BQU07R0FBUyxRQUFRO0dBQVcsU0FBUztFQUFXO0VBQ3pNLE1BQU07R0FBRSxPQUFPO0dBQVMsT0FBTztHQUFTLFNBQVM7R0FBb0IsY0FBYztHQUFtQyxZQUFZO0dBQW1CLFlBQVk7RUFBa0I7RUFDbkwsTUFBTTtHQUFFLFFBQVE7R0FBVyxRQUFRO0dBQVcsT0FBTztHQUFRLFVBQVU7R0FBYyxhQUFhO0dBQU8sZUFBZTtHQUF3QixnQkFBZ0I7R0FBNEIsU0FBUztFQUFXO0VBQ2hOLE9BQU87R0FBRSxPQUFPO0dBQWMsVUFBVTtHQUE0RCxVQUFVO0dBQVksWUFBWTtHQUFnQixtQkFBbUI7RUFBc0I7RUFDL0wsUUFBUTtHQUFFLE9BQU87R0FBZ0IsU0FBUztHQUFnQyxhQUFhO0VBQWU7Q0FDeEc7Q0FDQSxJQUFJO0VBQ0YsS0FBSztHQUFFLE1BQU07R0FBWSxRQUFRO0dBQWUsVUFBVTtHQUFhLFFBQVE7R0FBYSxXQUFXO0dBQWdCLE9BQU87R0FBWSxTQUFTO0dBQWEsTUFBTTtHQUFXLFFBQVE7R0FBWSxTQUFTO0VBQVk7RUFDMU4sTUFBTTtHQUFFLE9BQU87R0FBUSxPQUFPO0dBQVcsU0FBUztHQUFtQixjQUFjO0dBQW1DLFlBQVk7R0FBa0IsWUFBWTtFQUFvQjtFQUNwTCxNQUFNO0dBQUUsUUFBUTtHQUFZLFFBQVE7R0FBZSxPQUFPO0dBQWMsVUFBVTtHQUFjLGFBQWE7R0FBUyxlQUFlO0dBQXFCLGdCQUFnQjtHQUFzQixTQUFTO0VBQWlCO0VBQzFOLE9BQU87R0FBRSxPQUFPO0dBQWUsVUFBVTtHQUFtRSxVQUFVO0dBQXNCLFlBQVk7R0FBMEIsbUJBQW1CO0VBQXNCO0VBQzNOLFFBQVE7R0FBRSxPQUFPO0dBQWlCLFNBQVM7R0FBbUMsYUFBYTtFQUFtQjtDQUNoSDtDQUNBLElBQUk7RUFDRixLQUFLO0dBQUUsTUFBTTtHQUFRLFFBQVE7R0FBYyxVQUFVO0dBQVksUUFBUTtHQUFhLFdBQVc7R0FBaUIsT0FBTztHQUFXLFNBQVM7R0FBWSxNQUFNO0dBQVUsUUFBUTtHQUFZLFNBQVM7RUFBYTtFQUNuTixNQUFNO0dBQUUsT0FBTztHQUFRLE9BQU87R0FBUyxTQUFTO0dBQW1CLGNBQWM7R0FBMEMsWUFBWTtHQUFrQixZQUFZO0VBQWtCO0VBQ3ZMLE1BQU07R0FBRSxRQUFRO0dBQVksUUFBUTtHQUFZLE9BQU87R0FBVyxVQUFVO0dBQWMsYUFBYTtHQUFRLGVBQWU7R0FBc0IsZ0JBQWdCO0dBQXlCLFNBQVM7RUFBVztFQUNqTixPQUFPO0dBQUUsT0FBTztHQUFjLFVBQVU7R0FBNEQsVUFBVTtHQUFtQixZQUFZO0dBQXFCLG1CQUFtQjtFQUEyQjtFQUNoTixRQUFRO0dBQUUsT0FBTztHQUFpQixTQUFTO0dBQWdDLGFBQWE7RUFBZTtDQUN6RztDQUNBLElBQUk7RUFDRixLQUFLO0dBQUUsTUFBTTtHQUFPLFFBQVE7R0FBVyxVQUFVO0dBQVMsUUFBUTtHQUFZLFdBQVc7R0FBWSxPQUFPO0dBQVcsU0FBUztHQUFZLE1BQU07R0FBUyxRQUFRO0dBQVcsU0FBUztFQUFZO0VBQ25NLE1BQU07R0FBRSxPQUFPO0dBQVEsT0FBTztHQUFPLFNBQVM7R0FBb0IsY0FBYztHQUF1QyxZQUFZO0dBQWtCLFlBQVk7RUFBZ0I7RUFDakwsTUFBTTtHQUFFLFFBQVE7R0FBVyxRQUFRO0dBQWMsT0FBTztHQUFRLFVBQVU7R0FBVyxhQUFhO0dBQU8sZUFBZTtHQUFpQixnQkFBZ0I7R0FBcUIsU0FBUztFQUFjO0VBQ3JNLE9BQU87R0FBRSxPQUFPO0dBQVcsVUFBVTtHQUE4QyxVQUFVO0dBQVksWUFBWTtHQUEyQixtQkFBbUI7RUFBZ0I7RUFDbkwsUUFBUTtHQUFFLE9BQU87R0FBZ0IsU0FBUztHQUEyQixhQUFhO0VBQWE7Q0FDakc7Q0FDQSxJQUFJO0VBQ0YsS0FBSztHQUFFLE1BQU07R0FBTyxRQUFRO0dBQWEsVUFBVTtHQUFXLFFBQVE7R0FBWSxXQUFXO0dBQVksT0FBTztHQUFTLFNBQVM7R0FBWSxNQUFNO0dBQVMsUUFBUTtHQUFXLFNBQVM7RUFBVztFQUNwTSxNQUFNO0dBQUUsT0FBTztHQUFTLE9BQU87R0FBUyxTQUFTO0dBQXVCLGNBQWM7R0FBdUMsWUFBWTtHQUFtQixZQUFZO0VBQWtCO0VBQzFMLE1BQU07R0FBRSxRQUFRO0dBQVcsUUFBUTtHQUFXLE9BQU87R0FBUyxVQUFVO0dBQVcsYUFBYTtHQUFPLGVBQWU7R0FBaUIsZ0JBQWdCO0dBQXlCLFNBQVM7RUFBYTtFQUN0TSxPQUFPO0dBQUUsT0FBTztHQUFhLFVBQVU7R0FBMEMsVUFBVTtHQUFZLFlBQVk7R0FBaUIsbUJBQW1CO0VBQWtCO0VBQ3pLLFFBQVE7R0FBRSxPQUFPO0dBQWdCLFNBQVM7R0FBNkIsYUFBYTtFQUFZO0NBQ2xHO0NBQ0EsSUFBSTtFQUNGLEtBQUs7R0FBRSxNQUFNO0dBQU8sUUFBUTtHQUFVLFVBQVU7R0FBVSxRQUFRO0dBQVEsV0FBVztHQUFZLE9BQU87R0FBUyxTQUFTO0dBQVksTUFBTTtHQUFRLFFBQVE7R0FBVyxTQUFTO0VBQVc7RUFDM0wsTUFBTTtHQUFFLE9BQU87R0FBUSxPQUFPO0dBQU8sU0FBUztHQUFnQixjQUFjO0dBQWtDLFlBQVk7R0FBa0IsWUFBWTtFQUFnQjtFQUN4SyxNQUFNO0dBQUUsUUFBUTtHQUFXLFFBQVE7R0FBWSxPQUFPO0dBQVEsVUFBVTtHQUFVLGFBQWE7R0FBTyxlQUFlO0dBQWEsZ0JBQWdCO0dBQXdCLFNBQVM7RUFBZTtFQUNsTSxPQUFPO0dBQUUsT0FBTztHQUFVLFVBQVU7R0FBdUMsVUFBVTtHQUFZLFlBQVk7R0FBYyxtQkFBbUI7RUFBaUI7RUFDL0osUUFBUTtHQUFFLE9BQU87R0FBWSxTQUFTO0dBQTBCLGFBQWE7RUFBVztDQUMxRjtDQUNBLElBQUk7RUFDRixLQUFLO0dBQUUsTUFBTTtHQUFPLFFBQVE7R0FBVSxVQUFVO0dBQVcsUUFBUTtHQUFVLFdBQVc7R0FBWSxPQUFPO0dBQWUsU0FBUztHQUFXLE1BQU07R0FBUyxRQUFRO0dBQWUsU0FBUztFQUFhO0VBQzFNLE1BQU07R0FBRSxPQUFPO0dBQVcsT0FBTztHQUFVLFNBQVM7R0FBaUIsY0FBYztHQUEwQixZQUFZO0dBQXFCLFlBQVk7RUFBbUI7RUFDN0ssTUFBTTtHQUFFLFFBQVE7R0FBZSxRQUFRO0dBQWEsT0FBTztHQUFTLFVBQVU7R0FBWSxhQUFhO0dBQWUsZUFBZTtHQUFjLGdCQUFnQjtHQUEyQixTQUFTO0VBQW9CO0VBQzNOLE9BQU87R0FBRSxPQUFPO0dBQVUsVUFBVTtHQUFrRCxVQUFVO0dBQWMsWUFBWTtHQUF3QixtQkFBbUI7RUFBaUI7RUFDdEwsUUFBUTtHQUFFLE9BQU87R0FBYyxTQUFTO0dBQStCLGFBQWE7RUFBYztDQUNwRztDQUNBLElBQUk7RUFDRixLQUFLO0dBQUUsTUFBTTtHQUFZLFFBQVE7R0FBZSxVQUFVO0dBQVksUUFBUTtHQUFlLFdBQVc7R0FBbUIsT0FBTztHQUFZLFNBQVM7R0FBUyxNQUFNO0dBQVEsUUFBUTtHQUFhLFNBQVM7RUFBWTtFQUN4TixNQUFNO0dBQUUsT0FBTztHQUFXLE9BQU87R0FBVyxTQUFTO0dBQXFCLGNBQWM7R0FBMkMsWUFBWTtHQUFxQixZQUFZO0VBQW9CO0VBQ3BNLE1BQU07R0FBRSxRQUFRO0dBQWEsUUFBUTtHQUFXLE9BQU87R0FBUyxVQUFVO0dBQVksYUFBYTtHQUFnQixlQUFlO0dBQWlCLGdCQUFnQjtHQUF1QixTQUFTO0VBQXFCO0VBQ3hOLE9BQU87R0FBRSxPQUFPO0dBQWUsVUFBVTtHQUErRCxVQUFVO0dBQWUsWUFBWTtHQUFnQixtQkFBbUI7RUFBMEI7RUFDMU0sUUFBUTtHQUFFLE9BQU87R0FBbUIsU0FBUztHQUFpQyxhQUFhO0VBQWdCO0NBQzdHO0NBQ0EsSUFBSTtFQUNGLEtBQUs7R0FBRSxNQUFNO0dBQVUsUUFBUTtHQUFVLFVBQVU7R0FBUyxRQUFRO0dBQVksV0FBVztHQUFnQixPQUFPO0dBQWEsU0FBUztHQUFVLE1BQU07R0FBVyxRQUFRO0dBQWEsU0FBUztFQUFhO0VBQzlNLE1BQU07R0FBRSxPQUFPO0dBQVUsT0FBTztHQUFTLFNBQVM7R0FBb0IsY0FBYztHQUE4QyxZQUFZO0dBQW9CLFlBQVk7RUFBa0I7RUFDaE0sTUFBTTtHQUFFLFFBQVE7R0FBYSxRQUFRO0dBQVUsT0FBTztHQUFTLFVBQVU7R0FBZSxhQUFhO0dBQWdCLGVBQWU7R0FBZSxnQkFBZ0I7R0FBMEIsU0FBUztFQUFtQjtFQUN6TixPQUFPO0dBQUUsT0FBTztHQUFVLFVBQVU7R0FBMkQsVUFBVTtHQUFZLFlBQVk7R0FBb0IsbUJBQW1CO0VBQWlCO0VBQ3pMLFFBQVE7R0FBRSxPQUFPO0dBQWdCLFNBQVM7R0FBZ0MsYUFBYTtFQUFrQjtDQUMzRztDQUNBLEtBQUs7RUFDSCxLQUFLO0dBQUUsTUFBTTtHQUFRLFFBQVE7R0FBYSxVQUFVO0dBQVcsUUFBUTtHQUFnQixXQUFXO0dBQWEsT0FBTztHQUFTLFNBQVM7R0FBVyxNQUFNO0dBQVksUUFBUTtHQUFlLFNBQVM7RUFBZTtFQUNwTixNQUFNO0dBQUUsT0FBTztHQUFTLE9BQU87R0FBVSxTQUFTO0dBQWtCLGNBQWM7R0FBNkMsWUFBWTtHQUFtQixZQUFZO0VBQW1CO0VBQzdMLE1BQU07R0FBRSxRQUFRO0dBQWUsUUFBUTtHQUFlLE9BQU87R0FBUyxVQUFVO0dBQVksYUFBYTtHQUFZLGVBQWU7R0FBcUIsZ0JBQWdCO0dBQXdCLFNBQVM7RUFBeUI7RUFDbk8sT0FBTztHQUFFLE9BQU87R0FBYSxVQUFVO0dBQXlELFVBQVU7R0FBYyxZQUFZO0dBQW1CLG1CQUFtQjtFQUF1QjtFQUNqTSxRQUFRO0dBQUUsT0FBTztHQUF1QixTQUFTO0dBQW9DLGFBQWE7RUFBYztDQUNsSDtDQUNBLElBQUk7RUFDRixLQUFLO0dBQUUsTUFBTTtHQUFRLFFBQVE7R0FBWSxVQUFVO0dBQVUsUUFBUTtHQUFVLFdBQVc7R0FBb0IsT0FBTztHQUFTLFNBQVM7R0FBVSxNQUFNO0dBQVksUUFBUTtHQUFhLFNBQVM7RUFBYztFQUMvTSxNQUFNO0dBQUUsT0FBTztHQUFhLE9BQU87R0FBVSxTQUFTO0dBQW9CLGNBQWM7R0FBZ0MsWUFBWTtHQUF1QixZQUFZO0VBQW1CO0VBQzFMLE1BQU07R0FBRSxRQUFRO0dBQWEsUUFBUTtHQUFnQixPQUFPO0dBQVMsVUFBVTtHQUFVLGFBQWE7R0FBZSxlQUFlO0dBQWdCLGdCQUFnQjtHQUFzQixTQUFTO0VBQW1CO0VBQ3ROLE9BQU87R0FBRSxPQUFPO0dBQVksVUFBVTtHQUEyRCxVQUFVO0dBQWEsWUFBWTtHQUFxQixtQkFBbUI7RUFBb0I7RUFDaE0sUUFBUTtHQUFFLE9BQU87R0FBZ0IsU0FBUztHQUFxQyxhQUFhO0VBQVk7Q0FDMUc7Q0FDQSxJQUFJO0VBQ0YsS0FBSztHQUFFLE1BQU07R0FBUyxRQUFRO0dBQWMsVUFBVTtHQUFlLFFBQVE7R0FBZSxXQUFXO0dBQVksT0FBTztHQUFTLFNBQVM7R0FBVSxNQUFNO0dBQVUsUUFBUTtHQUFZLFNBQVM7RUFBVztFQUM5TSxNQUFNO0dBQUUsT0FBTztHQUFVLE9BQU87R0FBUyxTQUFTO0dBQWtCLGNBQWM7R0FBc0MsWUFBWTtHQUFvQixZQUFZO0VBQWtCO0VBQ3RMLE1BQU07R0FBRSxRQUFRO0dBQVksUUFBUTtHQUFlLE9BQU87R0FBVSxVQUFVO0dBQVksYUFBYTtHQUFnQixlQUFlO0dBQWUsZ0JBQWdCO0dBQXVCLFNBQVM7RUFBc0I7RUFDM04sT0FBTztHQUFFLE9BQU87R0FBYyxVQUFVO0dBQTJELFVBQVU7R0FBYyxZQUFZO0dBQW1CLG1CQUFtQjtFQUFvQjtFQUNqTSxRQUFRO0dBQUUsT0FBTztHQUFjLFNBQVM7R0FBbUMsYUFBYTtFQUFZO0NBQ3RHO0NBQ0EsSUFBSTtFQUNGLEtBQUs7R0FBRSxNQUFNO0dBQVMsUUFBUTtHQUFjLFVBQVU7R0FBYSxRQUFRO0dBQVUsV0FBVztHQUFZLE9BQU87R0FBUyxTQUFTO0dBQVUsTUFBTTtHQUFZLFFBQVE7R0FBWSxTQUFTO0VBQVU7RUFDeE0sTUFBTTtHQUFFLE9BQU87R0FBVSxPQUFPO0dBQVEsU0FBUztHQUFzQixjQUFjO0dBQTBCLFlBQVk7R0FBb0IsWUFBWTtFQUFpQjtFQUM1SyxNQUFNO0dBQUUsUUFBUTtHQUFZLFFBQVE7R0FBaUIsT0FBTztHQUFVLFVBQVU7R0FBVyxhQUFhO0dBQWdCLGVBQWU7R0FBaUIsZ0JBQWdCO0dBQXVCLFNBQVM7RUFBcUI7RUFDN04sT0FBTztHQUFFLE9BQU87R0FBYyxVQUFVO0dBQWtELFVBQVU7R0FBYyxZQUFZO0dBQWdCLG1CQUFtQjtFQUEwQjtFQUMzTCxRQUFRO0dBQUUsT0FBTztHQUFjLFNBQVM7R0FBK0IsYUFBYTtFQUFhO0NBQ25HO0NBQ0EsSUFBSTtFQUNGLEtBQUs7R0FBRSxNQUFNO0dBQVEsUUFBUTtHQUFVLFVBQVU7R0FBWSxRQUFRO0dBQVUsV0FBVztHQUFnQixPQUFPO0dBQVMsU0FBUztHQUFVLE1BQU07R0FBZ0IsUUFBUTtHQUFXLFNBQVM7RUFBUztFQUN4TSxNQUFNO0dBQUUsT0FBTztHQUFPLE9BQU87R0FBVSxTQUFTO0dBQXVCLGNBQWM7R0FBa0MsWUFBWTtHQUFpQixZQUFZO0VBQW1CO0VBQ25MLE1BQU07R0FBRSxRQUFRO0dBQVcsUUFBUTtHQUFlLE9BQU87R0FBVSxVQUFVO0dBQWUsYUFBYTtHQUFhLGVBQWU7R0FBZSxnQkFBZ0I7R0FBc0IsU0FBUztFQUFxQjtFQUN4TixPQUFPO0dBQUUsT0FBTztHQUFVLFVBQVU7R0FBd0QsVUFBVTtHQUFlLFlBQVk7R0FBZ0IsbUJBQW1CO0VBQXNCO0VBQzFMLFFBQVE7R0FBRSxPQUFPO0dBQWMsU0FBUztHQUErQixhQUFhO0VBQVk7Q0FDbEc7Q0FDQSxJQUFJO0VBQ0YsS0FBSztHQUFFLE1BQU07R0FBUyxRQUFRO0dBQVcsVUFBVTtHQUFXLFFBQVE7R0FBYSxXQUFXO0dBQWEsT0FBTztHQUFZLFNBQVM7R0FBWSxNQUFNO0dBQVksUUFBUTtHQUFtQixTQUFTO0VBQWdCO0VBQ3pOLE1BQU07R0FBRSxPQUFPO0dBQVcsT0FBTztHQUFVLFNBQVM7R0FBa0IsY0FBYztHQUF3QyxZQUFZO0dBQXFCLFlBQVk7RUFBbUI7RUFDNUwsTUFBTTtHQUFFLFFBQVE7R0FBbUIsUUFBUTtHQUFnQixPQUFPO0dBQWMsVUFBVTtHQUFZLGFBQWE7R0FBYyxlQUFlO0dBQVksZ0JBQWdCO0dBQW1CLFNBQVM7RUFBdUI7RUFDL04sT0FBTztHQUFFLE9BQU87R0FBVyxVQUFVO0dBQWlELFVBQVU7R0FBZSxZQUFZO0dBQW9CLG1CQUFtQjtFQUFtQjtFQUNyTCxRQUFRO0dBQUUsT0FBTztHQUFjLFNBQVM7R0FBK0IsYUFBYTtFQUFnQjtDQUN0RztDQUNBLElBQUk7RUFDRixLQUFLO0dBQUUsTUFBTTtHQUFhLFFBQVE7R0FBVSxVQUFVO0dBQVUsUUFBUTtHQUFXLFdBQVc7R0FBVyxPQUFPO0dBQVUsU0FBUztHQUFVLE1BQU07R0FBVSxRQUFRO0dBQWdCLFNBQVM7RUFBYztFQUM1TSxNQUFNO0dBQUUsT0FBTztHQUFVLE9BQU87R0FBVyxTQUFTO0dBQXFCLGNBQWM7R0FBMEMsWUFBWTtHQUFvQixZQUFZO0VBQW9CO0VBQ2pNLE1BQU07R0FBRSxRQUFRO0dBQWdCLFFBQVE7R0FBZSxPQUFPO0dBQVUsVUFBVTtHQUFTLGFBQWE7R0FBcUIsZUFBZTtHQUFpQixnQkFBZ0I7R0FBMEIsU0FBUztFQUFnQjtFQUNoTyxPQUFPO0dBQUUsT0FBTztHQUFVLFVBQVU7R0FBMkMsVUFBVTtHQUFXLFlBQVk7R0FBZ0IsbUJBQW1CO0VBQW1CO0VBQ3RLLFFBQVE7R0FBRSxPQUFPO0dBQVksU0FBUztHQUE2QixhQUFhO0VBQVc7Q0FDN0Y7Q0FDQSxJQUFJO0VBQ0YsS0FBSztHQUFFLE1BQU07R0FBYSxRQUFRO0dBQVUsVUFBVTtHQUFVLFFBQVE7R0FBWSxXQUFXO0dBQVcsT0FBTztHQUFXLFNBQVM7R0FBVSxNQUFNO0dBQVUsUUFBUTtHQUFnQixTQUFTO0VBQWM7RUFDOU0sTUFBTTtHQUFFLE9BQU87R0FBVSxPQUFPO0dBQVcsU0FBUztHQUF1QixjQUFjO0dBQTBDLFlBQVk7R0FBb0IsWUFBWTtFQUFvQjtFQUNuTSxNQUFNO0dBQUUsUUFBUTtHQUFnQixRQUFRO0dBQWtCLE9BQU87R0FBVSxVQUFVO0dBQVMsYUFBYTtHQUFvQixlQUFlO0dBQWlCLGdCQUFnQjtHQUF5QixTQUFTO0VBQWdCO0VBQ2pPLE9BQU87R0FBRSxPQUFPO0dBQVUsVUFBVTtHQUEyQyxVQUFVO0dBQVcsWUFBWTtHQUFnQixtQkFBbUI7RUFBbUI7RUFDdEssUUFBUTtHQUFFLE9BQU87R0FBWSxTQUFTO0dBQTZCLGFBQWE7RUFBVztDQUM3RjtDQUNBLElBQUk7RUFDRixLQUFLO0dBQUUsTUFBTTtHQUFlLFFBQVE7R0FBVSxVQUFVO0dBQVksUUFBUTtHQUFTLFdBQVc7R0FBZ0IsT0FBTztHQUFTLFNBQVM7R0FBVSxNQUFNO0dBQWMsUUFBUTtHQUFpQixTQUFTO0VBQWdCO0VBQ3pOLE1BQU07R0FBRSxPQUFPO0dBQWEsT0FBTztHQUFRLFNBQVM7R0FBc0IsY0FBYztHQUEwQyxZQUFZO0dBQXVCLFlBQVk7RUFBaUI7RUFDbE0sTUFBTTtHQUFFLFFBQVE7R0FBaUIsUUFBUTtHQUFnQixPQUFPO0dBQVUsVUFBVTtHQUFVLGFBQWE7R0FBcUIsZUFBZTtHQUFvQixnQkFBZ0I7R0FBd0IsU0FBUztFQUFnQjtFQUNwTyxPQUFPO0dBQUUsT0FBTztHQUFVLFVBQVU7R0FBa0QsVUFBVTtHQUFnQixZQUFZO0dBQW9CLG1CQUFtQjtFQUFxQjtFQUN4TCxRQUFRO0dBQUUsT0FBTztHQUFhLFNBQVM7R0FBNkIsYUFBYTtFQUFVO0NBQzdGO0NBQ0EsSUFBSTtFQUNGLEtBQUs7R0FBRSxNQUFNO0dBQU8sUUFBUTtHQUFVLFVBQVU7R0FBWSxRQUFRO0dBQVcsV0FBVztHQUFtQixPQUFPO0dBQWMsU0FBUztHQUFVLE1BQU07R0FBYyxRQUFRO0dBQVcsU0FBUztFQUFhO0VBQ2xOLE1BQU07R0FBRSxPQUFPO0dBQVMsT0FBTztHQUFRLFNBQVM7R0FBNEIsY0FBYztHQUErQixZQUFZO0dBQW1CLFlBQVk7RUFBaUI7RUFDckwsTUFBTTtHQUFFLFFBQVE7R0FBVyxRQUFRO0dBQVcsT0FBTztHQUFTLFVBQVU7R0FBVyxhQUFhO0dBQW1CLGVBQWU7R0FBMEIsZ0JBQWdCO0dBQXNCLFNBQVM7RUFBcUI7RUFDaE8sT0FBTztHQUFFLE9BQU87R0FBVSxVQUFVO0dBQStELFVBQVU7R0FBZ0IsWUFBWTtHQUF3QixtQkFBbUI7RUFBc0I7RUFDMU0sUUFBUTtHQUFFLE9BQU87R0FBZSxTQUFTO0dBQXlDLGFBQWE7RUFBb0I7Q0FDckg7Q0FDQSxJQUFJO0VBQ0YsS0FBSztHQUFFLE1BQU07R0FBVyxRQUFRO0dBQVUsVUFBVTtHQUFnQixRQUFRO0dBQVksV0FBVztHQUFVLE9BQU87R0FBUyxTQUFTO0dBQVcsTUFBTTtHQUFnQixRQUFRO0dBQVUsU0FBUztFQUFRO0VBQzFNLE1BQU07R0FBRSxPQUFPO0dBQVksT0FBTztHQUFZLFNBQVM7R0FBb0IsY0FBYztHQUF1QyxZQUFZO0dBQXNCLFlBQVk7RUFBcUI7RUFDbk0sTUFBTTtHQUFFLFFBQVE7R0FBVSxRQUFRO0dBQW1CLE9BQU87R0FBYSxVQUFVO0dBQVUsYUFBYTtHQUFRLGVBQWU7R0FBNEIsZ0JBQWdCO0dBQTJCLFNBQVM7RUFBaUI7RUFDbE8sT0FBTztHQUFFLE9BQU87R0FBVSxVQUFVO0dBQWlELFVBQVU7R0FBYyxZQUFZO0dBQWtCLG1CQUFtQjtFQUFtQjtFQUNqTCxRQUFRO0dBQUUsT0FBTztHQUFjLFNBQVM7R0FBOEIsYUFBYTtFQUFrQjtDQUN2RztDQUNBLElBQUk7RUFDRixLQUFLO0dBQUUsTUFBTTtHQUFTLFFBQVE7R0FBWSxVQUFVO0dBQWEsUUFBUTtHQUFXLFdBQVc7R0FBUyxPQUFPO0dBQWlCLFNBQVM7R0FBVSxNQUFNO0dBQWMsUUFBUTtHQUFRLFNBQVM7RUFBUTtFQUN4TSxNQUFNO0dBQUUsT0FBTztHQUFVLE9BQU87R0FBWSxTQUFTO0dBQXdCLGNBQWM7R0FBd0MsWUFBWTtHQUFvQixZQUFZO0VBQXFCO0VBQ3BNLE1BQU07R0FBRSxRQUFRO0dBQVEsUUFBUTtHQUFlLE9BQU87R0FBUyxVQUFVO0dBQVUsYUFBYTtHQUFPLGVBQWU7R0FBdUIsZ0JBQWdCO0dBQXFCLFNBQVM7RUFBc0I7RUFDak4sT0FBTztHQUFFLE9BQU87R0FBWSxVQUFVO0dBQStELFVBQVU7R0FBWSxZQUFZO0dBQXFCLG1CQUFtQjtFQUF5QjtFQUN4TSxRQUFRO0dBQUUsT0FBTztHQUFlLFNBQVM7R0FBdUMsYUFBYTtFQUFXO0NBQzFHO0FBQ0YiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsibG9jYWxlcy1leHRyYS50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvLyBBZGRpdGlvbmFsIG5hdGl2ZSB0cmFuc2xhdGlvbnMgZm9yIGxhdW5jaCBsYW5ndWFnZXM6XG4vLyBTZXRzd2FuYSAodG4pLCBIYXVzYSAoaGEpLCBZb3LDuWLDoSAoeW8pLCBJZ2JvIChpZyksIEFtaGFyaWMgKGFtKSwgU2VwZWRpIChuc28pLFxuLy8gSGVicmV3IChoZSksIFBlcnNpYW4vRmFyc2kgKGZhKSwgVXJkdSAodXIpLCBCZW5nYWxpIChibiksIFRhbWlsICh0YSksIFRlbHVndSAodGUpLFxuLy8gTWFyYXRoaSAobXIpLCBHdWphcmF0aSAoZ3UpLCBQdW5qYWJpIChwYSksIFRoYWkgKHRoKSwgVmlldG5hbWVzZSAodmkpLCBNYWxheSAobXMpLFxuLy8gRmlsaXBpbm8gKGZpbCksIFJvbWFuaWFuIChybyksIFN3ZWRpc2ggKHN2KSwgTm9yd2VnaWFuIChubyksIERhbmlzaCAoZGEpLCBGaW5uaXNoIChmaSksXG4vLyBDemVjaCAoY3MpLCBTbG92YWsgKHNrKSwgSHVuZ2FyaWFuIChodSksIEdyZWVrIChlbCksIFVrcmFpbmlhbiAodWspLCBCdWxnYXJpYW4gKGJnKS5cblxuZXhwb3J0IGNvbnN0IGV4dHJhVHJhbnNsYXRpb25zOiBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBhbnk+PiA9IHtcbiAgdG46IHsgLy8gU2V0c3dhbmFcbiAgICBuYXY6IHsgZmVlZDogXCJEaXRpcm9cIiwgYnJhbmRzOiBcIk1hYm9rZ29uaVwiLCBtZXNzYWdlczogXCJNZWxhZXRzYVwiLCBhd2FyZHM6IFwiRGlraHVtYWdhZGlcIiwgZGFzaGJvYXJkOiBcIkxldGxhcGFcIiwgYWRtaW46IFwiTW9sYW9kaVwiLCBwcm9maWxlOiBcIlBvZWxldHNvXCIsIHBvc3Q6IFwiUG9zb1wiLCBzaWduSW46IFwiVHNlbmFcIiwgc2lnbk91dDogXCJUc3dhXCIgfSxcbiAgICB2b3RlOiB7IHN0YXNoOiBcIkJvbG9rYVwiLCB0cmFzaDogXCJMYXRsaGFcIiwgbm9Wb3RlczogXCJHYSBnb25hIGRpdGxob3Bob1wiLCBzaWduSW5Qcm9tcHQ6IFwiVHNlbmEgZ28gcm9tZWxhIGthdGxob2xvIHlhIGdhZ28uXCIsIHN0YXNoQ291bnQ6IFwie3tjb3VudH19IGJvbG9rYVwiLCB0cmFzaENvdW50OiBcInt7Y291bnR9fSBsYXRsaGFcIiB9LFxuICAgIGF1dGg6IHsgc2lnbkluOiBcIlRzZW5hXCIsIHNpZ25VcDogXCJJa3dhZGlzZVwiLCBlbWFpbDogXCJJbWVpbGVcIiwgcGFzc3dvcmQ6IFwiS2h1bm9sb2xvXCIsIGRpc3BsYXlOYW1lOiBcIkxlaW5hIGxhIGdhZ29cIiwgY3JlYXRlQWNjb3VudDogXCJCb3BhIGFraGFvbnRvXCIsIGNvbnRpbnVlR29vZ2xlOiBcIlRzd2VsZWxhIGthIEdvb2dsZVwiLCB3ZWxjb21lOiBcIlJlIGEgZ28gYW1vZ2VsYSBnYXBlIVwiIH0sXG4gICAgYnJhbmQ6IHsgdGl0bGU6IFwiTWFib2tnb25pXCIsIHN1YnRpdGxlOiBcIk1hYm9rZ29uaSBhIGEgbmV0ZWZhZGl0c3dlbmcgbGUgZGl0c2h3ZXRzbyB0c2Egc2V0c2hhYmEuXCIsIHZlcmlmaWVkOiBcIk5ldGVmYWRpdHN3ZVwiLCB0cnVzdFNjb3JlOiBcIlRla2FueWV0c28geWEgdHNoZXBvXCIsIHNlYXJjaFBsYWNlaG9sZGVyOiBcIkJhdGxhIG1hYm9rZ29uaS4uLlwiIH0sXG4gICAgYXdhcmRzOiB7IHRpdGxlOiBcIkRpa2h1bWFnYWRpIHRzYSBTT1RcIiwgdGFnbGluZTogXCJTZWthbGEgc2EgVHNoZXBvIHNhIE1hYm9rZ29uaVwiLCBsZWFkZXJib2FyZDogXCJCYSBiYSBldGVsZXRzZW5nIHBlbGVcIiB9XG4gIH0sXG4gIGhhOiB7IC8vIEhhdXNhXG4gICAgbmF2OiB7IGZlZWQ6IFwiTGFiYXJhaVwiLCBicmFuZHM6IFwiS2FtZmFub25pXCIsIG1lc3NhZ2VzOiBcIlNhxplvbm5pXCIsIGF3YXJkczogXCJLeWF1dHV0dHVrYVwiLCBkYXNoYm9hcmQ6IFwiQWxsb24gU2FyYXV0YVwiLCBhZG1pbjogXCJHdWRhbmFyd2FcIiwgcHJvZmlsZTogXCJCYXlhbmFpXCIsIHBvc3Q6IFwiQWlrYVwiLCBzaWduSW46IFwiU2hpZ2FcIiwgc2lnbk91dDogXCJGaXRhXCIgfSxcbiAgICB2b3RlOiB7IHN0YXNoOiBcIkFqaXllXCIsIHRyYXNoOiBcIlp1YmFyXCIsIG5vVm90ZXM6IFwiQmFidSDGmXVyaSd1IHR1a3VuYVwiLCBzaWduSW5Qcm9tcHQ6IFwiU2hpZ2EgZG9uIGJheWFyIGRhIHJhJ2F5aW5rYS5cIiwgc3Rhc2hDb3VudDogXCJ7e2NvdW50fX0gYW4gYWppeWVcIiwgdHJhc2hDb3VudDogXCJ7e2NvdW50fX0gYW4genViYXJcIiB9LFxuICAgIGF1dGg6IHsgc2lnbkluOiBcIlNoaWdhXCIsIHNpZ25VcDogXCJZaSBSYWppc3RhXCIsIGVtYWlsOiBcIkltZWxcIiwgcGFzc3dvcmQ6IFwiS2FsbWFyIHNpcnJpXCIsIGRpc3BsYXlOYW1lOiBcIlN1bmFuIG51bmlcIiwgY3JlYXRlQWNjb3VudDogXCLGmGlyxplpcmkgYXN1c3VcIiwgY29udGludWVHb29nbGU6IFwiQ2kgZ2FiYSBkYSBHb29nbGVcIiwgd2VsY29tZTogXCJCYXJrYSBkYSBkYXdvd2EhXCIgfSxcbiAgICBicmFuZDogeyB0aXRsZTogXCJLYW1mYW5vbmlcIiwgc3VidGl0bGU6IFwiVGFudGFuY2VjY2VuIGthbWZhbm9uaSBkYSByYSdheW95aW4gamFtYSdhIGthaSB0c2F5ZS5cIiwgdmVyaWZpZWQ6IFwiQW4gdGFiYmF0YXJcIiwgdHJ1c3RTY29yZTogXCJNYWtpbiBhbWFuYVwiLCBzZWFyY2hQbGFjZWhvbGRlcjogXCJOZW1pIGthbWZhbmkuLi5cIiB9LFxuICAgIGF3YXJkczogeyB0aXRsZTogXCJLeWF1dHV0dHVrYW4gU09UXCIsIHRhZ2xpbmU6IFwiTWl6YW5pbiBBbWluY2V3YSBkYSBBbGFtYXIgS2FzdXdhbmNpXCIsIGxlYWRlcmJvYXJkOiBcIkphZ29yb3JpbiBTaGVrYXJhXCIgfVxuICB9LFxuICB5bzogeyAvLyBZb3LDuWLDoVxuICAgIG5hdjogeyBmZWVkOiBcIsOAZmlrw7puXCIsIGJyYW5kczogXCLDgHfhu41uIElsw6ktaeG5o+G6ucyBXCIsIG1lc3NhZ2VzOiBcIsOAd+G7jW4gSWZpcmFu4bmj4bq5XCIsIGF3YXJkczogXCLDgHfhu41uIMOAbcOsLeG6ucyAeeG6uVwiLCBkYXNoYm9hcmQ6IFwiUOG6uXDhurkgSeG5o+G6ucyBXCIsIGFkbWluOiBcIkFsw6Frb3NvXCIsIHByb2ZpbGU6IFwiUHJvZmFpbGlcIiwgcG9zdDogXCJGaXJhbuG5o+G6uVwiLCBzaWduSW46IFwiV+G7jWzDqVwiLCBzaWduT3V0OiBcIkrDoWRlXCIgfSxcbiAgICB2b3RlOiB7IHN0YXNoOiBcIlThu43MgWrDulwiLCB0cmFzaDogXCJEw6AgbsO5XCIsIG5vVm90ZXM6IFwiS8OyIHTDrcOsIHPDrSDDrGLDslwiLCBzaWduSW5Qcm9tcHQ6IFwiV+G7jWzDqSBsw6F0aSBz4buNIMOocsOyIHLhurkuXCIsIHN0YXNoQ291bnQ6IFwie3tjb3VudH19IHThu43MgWrDulwiLCB0cmFzaENvdW50OiBcInt7Y291bnR9fSBkw6AgbsO5XCIgfSxcbiAgICBhdXRoOiB7IHNpZ25JbjogXCJX4buNbMOpXCIsIHNpZ25VcDogXCJGb3LDumvhu41zw61s4bq5zIBcIiwgZW1haWw6IFwiSW1lZWxpXCIsIHBhc3N3b3JkOiBcIuG7jHLhu43MgCBh4bmjw61uw6BcIiwgZGlzcGxheU5hbWU6IFwiT3J1a+G7jSBy4bq5XCIsIGNyZWF0ZUFjY291bnQ6IFwi4bmi4bq5zIBkw6Egw6Br4buN4buNzIFs4bq5zIBcIiwgY29udGludWVHb29nbGU6IFwiVOG6ucyAc8Otd8OhasO6IHDhurnMgGzDuiBHb29nbGVcIiwgd2VsY29tZTogXCLhurgga8Ohw6Bi4buNzIAgcGFkw6AhXCIgfSxcbiAgICBicmFuZDogeyB0aXRsZTogXCLDgHfhu41uIElsw6ktaeG5o+G6ucyBXCIsIHN1YnRpdGxlOiBcIsOAd+G7jW4gaWzDqS1p4bmj4bq5zIEgdMOtIGEgZuG7jXfhu43MgXPDrSDDoHRpIMOsZMOhauG7jcyBIMOgd8O5auG7jSBsw7Nyw60gd+G7jW4uXCIsIHZlcmlmaWVkOiBcIkbhu4134buNzIFzw61cIiwgdHJ1c3RTY29yZTogXCJJeWUgw6xnYuG6ucyBa+G6ucyAbMOpXCIsIHNlYXJjaFBsYWNlaG9sZGVyOiBcIldhIMOgd+G7jW4gaWzDqS1p4bmj4bq5zIEuLi5cIiB9LFxuICAgIGF3YXJkczogeyB0aXRsZTogXCLDgHfhu41uIMOAbcOsLeG6ucyAeeG6uSBTT1RcIiwgdGFnbGluZTogXCJJd+G7jW4gw4xnYuG6ucyBa+G6ucyAbMOpIElsw6ktaeG5o+G6ucyBXCIsIGxlYWRlcmJvYXJkOiBcIsOAdOG6uSDDgHfhu41uIEFzaXdhanVcIiB9XG4gIH0sXG4gIGlnOiB7IC8vIElnYm9cbiAgICBuYXY6IHsgZmVlZDogXCJJaGUg4buNaOG7pXLhu6VcIiwgYnJhbmRzOiBcIuG7pGThu4sgTmd3YWFo4buLYVwiLCBtZXNzYWdlczogXCJPemlcIiwgYXdhcmRzOiBcIkloZSBucml0ZVwiLCBkYXNoYm9hcmQ6IFwiTXBlbXBlIGFrd+G7pWt34buNXCIsIGFkbWluOiBcIk9ueWUgbmxla+G7jXRhXCIsIHByb2ZpbGU6IFwiUHJvZmHhu4ts4bulXCIsIHBvc3Q6IFwiWmlwdVwiLCBzaWduSW46IFwiQmFueWVcIiwgc2lnbk91dDogXCJQ4bul4buNXCIgfSxcbiAgICB2b3RlOiB7IHN0YXNoOiBcIkNoZWt3YWFcIiwgdHJhc2g6IFwiVOG7pWZ1b1wiLCBub1ZvdGVzOiBcIkVud2VnaOG7iyBudHVsaSBha2FcIiwgc2lnbkluUHJvbXB0OiBcIkJhbnllIGthIGlrcGViaWUuXCIsIHN0YXNoQ291bnQ6IFwie3tjb3VudH19IGNoZWt3YWFcIiwgdHJhc2hDb3VudDogXCJ7e2NvdW50fX0gdOG7pWZ1b1wiIH0sXG4gICAgYXV0aDogeyBzaWduSW46IFwiQmFueWVcIiwgc2lnblVwOiBcIkRlYmFueWUgYWhhXCIsIGVtYWlsOiBcIk96aSBlbWFpbFwiLCBwYXNzd29yZDogXCJPa3d1IG56dXpvXCIsIGRpc3BsYXlOYW1lOiBcIkFoYSBuZ29zaVwiLCBjcmVhdGVBY2NvdW50OiBcIk1lcOG7pXRhIGFrYeG7pW504bulXCIsIGNvbnRpbnVlR29vZ2xlOiBcIkdhYSBuJ2lodSBuYSBHb29nbGVcIiwgd2VsY29tZTogXCJObuG7jeG7jSDhu4164buNIVwiIH0sXG4gICAgYnJhbmQ6IHsgdGl0bGU6IFwi4bukZOG7iyBOZ3dhYWjhu4thXCIsIHN1YnRpdGxlOiBcIuG7pGThu4sgbmd3YWFo4buLYSBrd2Fkb3JvIG5hIG1rcGViaSBuZOG7iyBtbWFk4bulLlwiLCB2ZXJpZmllZDogXCJLd2Fkb3JvXCIsIHRydXN0U2NvcmU6IFwiQWthcmEgbnThu6Vrd2Fz4buLIG9iaVwiLCBzZWFyY2hQbGFjZWhvbGRlcjogXCJDaOG7jeG7jSDhu6Vk4buLLi4uXCIgfSxcbiAgICBhd2FyZHM6IHsgdGl0bGU6IFwiSWhlIG5yaXRlIFNPVFwiLCB0YWdsaW5lOiBcIlRlYuG7pWwgTnThu6Vrd2Fz4buLIE9iaSDhu6Rk4buLIE5nd2FhaOG7i2FcIiwgbGVhZGVyYm9hcmQ6IFwiTmThu4sga2FjaGFz4buLIG4nZWx1XCIgfVxuICB9LFxuICBhbTogeyAvLyBBbWhhcmljXG4gICAgbmF2OiB7IGZlZWQ6IFwi4Yid4YyN4Ymm4Ym9XCIsIGJyYW5kczogXCLhiaXhiKvhipXhi7bhib1cIiwgbWVzc2FnZXM6IFwi4YiY4YiN4YuV4Yqt4Ym24Ym9XCIsIGF3YXJkczogXCLhiL3hiI3hiJvhibbhib1cIiwgZGFzaGJvYXJkOiBcIuGLs+GIveGJpuGIreGLtVwiLCBhZG1pbjogXCLhiqDhiLXhibDhi7Phi7PhiKpcIiwgcHJvZmlsZTogXCLhiJjhjIjhiIjhjKtcIiwgcG9zdDogXCLhiIjhjKXhjY1cIiwgc2lnbkluOiBcIuGMjeGJo1wiLCBzaWduT3V0OiBcIuGLjeGMo1wiIH0sXG4gICAgdm90ZTogeyBzdGFzaDogXCLhiqDhiLXhiYDhiJ3hjKVcIiwgdHJhc2g6IFwi4Yyj4YiI4YuNXCIsIG5vVm90ZXM6IFwi4Yql4Yi14Yqr4YiB4YqVIOGLteGIneGMvSDhi6jhiIjhiJ1cIiwgc2lnbkluUHJvbXB0OiBcIuGLjeGIs+GKlOGLjuGKlSDhiIjhiJjhiLXhjKDhibUg4Yut4YyN4Ymh4Y2iXCIsIHN0YXNoQ291bnQ6IFwie3tjb3VudH19IOGKoOGIteGJgOGIneGMpVwiLCB0cmFzaENvdW50OiBcInt7Y291bnR9fSDhjKPhiIjhi41cIiB9LFxuICAgIGF1dGg6IHsgc2lnbkluOiBcIuGMjeGJo1wiLCBzaWduVXA6IFwi4Yut4YiY4Yud4YyI4YmhXCIsIGVtYWlsOiBcIuGKouGInOGLreGIjVwiLCBwYXNzd29yZDogXCLhi6jhi63hiIjhjY0g4YmD4YiNXCIsIGRpc3BsYXlOYW1lOiBcIuGLqOGIm+GIs+GLqyDhiLXhiJ1cIiwgY3JlYXRlQWNjb3VudDogXCLhiJjhiIjhi6sg4Y2N4Yyg4YitXCIsIGNvbnRpbnVlR29vZ2xlOiBcIuGJoEdvb2dsZSDhiYDhjKXhiI1cIiwgd2VsY29tZTogXCLhiqXhipXhirPhipUg4Yuw4YiF4YqTIOGImOGMoSFcIiB9LFxuICAgIGJyYW5kOiB7IHRpdGxlOiBcIuGJpeGIq+GKleGLtuGJvVwiLCBzdWJ0aXRsZTogXCLhi6jhibDhiKjhjIvhjIjhjKEg4Yml4Yir4YqV4Yu24Ym9IOGKpeGKkyDhi6jhiYDhjKXhibMg4Yib4YiF4Ymg4Yio4Yiw4YmlIOGLjeGIs+GKlOGLjuGJveGNolwiLCB2ZXJpZmllZDogXCLhi6jhibDhiKjhjIvhjIjhjKBcIiwgdHJ1c3RTY29yZTogXCLhi6jhiqXhiJ3hipDhibUg4Yuw4Yio4YyDXCIsIHNlYXJjaFBsYWNlaG9sZGVyOiBcIuGJpeGIq+GKleGLtuGJveGKlSDhjYjhiI3hjI0uLi5cIiB9LFxuICAgIGF3YXJkczogeyB0aXRsZTogXCLhi6hTT1Qg4Yi94YiN4Yib4Ym24Ym9XCIsIHRhZ2xpbmU6IFwi4Yuo4Yml4Yir4YqV4Yu1IOGKpeGIneGKkOGJtSDhiJjhiIjhiqrhi6tcIiwgbGVhZGVyYm9hcmQ6IFwi4Yuo4Yuw4Yio4YyDIOGIsOGKleGMoOGIqOGLpVwiIH1cbiAgfSxcbiAgbnNvOiB7IC8vIFNlcGVkaSAvIE5vcnRoZXJuIFNvdGhvXG4gICAgbmF2OiB7IGZlZWQ6IFwiRGlrYWdhcmVcIiwgYnJhbmRzOiBcIk1hYnJhbmRlXCIsIG1lc3NhZ2VzOiBcIk1lbGFldHNhXCIsIGF3YXJkczogXCJEaWZva2FcIiwgZGFzaGJvYXJkOiBcIkRhc2hib3RvXCIsIGFkbWluOiBcIk1vbGFvZGlcIiwgcHJvZmlsZTogXCJCb2l0c2ViacWhb1wiLCBwb3N0OiBcIlBhc2FcIiwgc2lnbkluOiBcIlRzZW5hXCIsIHNpZ25PdXQ6IFwiVMWhd2FcIiB9LFxuICAgIHZvdGU6IHsgc3Rhc2g6IFwiQm9sb2thXCIsIHRyYXNoOiBcIkxhaGxhXCIsIG5vVm90ZXM6IFwiR2EgZ28gZGlrZ2V0aG8gdMWhYSBiamFsZVwiLCBzaWduSW5Qcm9tcHQ6IFwiVHNlbmEgZ28gZmFuYSBrYSBrYWhsb2xvIHlhIGdhZ28uXCIsIHN0YXNoQ291bnQ6IFwie3tjb3VudH19IGJvbG9rYVwiLCB0cmFzaENvdW50OiBcInt7Y291bnR9fSBsYWhsYVwiIH0sXG4gICAgYXV0aDogeyBzaWduSW46IFwiVHNlbmFcIiwgc2lnblVwOiBcIkluZ3dhZGnFoWVcIiwgZW1haWw6IFwiSW1laWxlXCIsIHBhc3N3b3JkOiBcIlBoYXNld2V0ZVwiLCBkaXNwbGF5TmFtZTogXCJMZWluYSBsYSBnbyBib25hbGFcIiwgY3JlYXRlQWNjb3VudDogXCJIbGFtYSBha2hhb250b1wiLCBjb250aW51ZUdvb2dsZTogXCJUxaF3ZWxhIHBlbGUga2EgR29vZ2xlXCIsIHdlbGNvbWU6IFwiTyBhbW9nZXTFoXdlIGdhcGUhXCIgfSxcbiAgICBicmFuZDogeyB0aXRsZTogXCJNYWJyYW5kZVwiLCBzdWJ0aXRsZTogXCJNYWJyYW5kZSBhIGEgbmV0ZWZhZGl0xaF3ZWdvIGxlIGRpa2FobG9sbyB0xaFhIHNldMWhaGFiYS5cIiwgdmVyaWZpZWQ6IFwiTmV0ZWZhZGl0xaF3ZVwiLCB0cnVzdFNjb3JlOiBcIlRla2FueWV0xaFvIHlhIHRzaGVwb1wiLCBzZWFyY2hQbGFjZWhvbGRlcjogXCJOeWFrYSBtYWJyYW5kZS4uLlwiIH0sXG4gICAgYXdhcmRzOiB7IHRpdGxlOiBcIkRpZm9rYSB0xaFhIFNPVFwiLCB0YWdsaW5lOiBcIlRla2FueWV0xaFvIHlhIFRzaGVwbyB5YSBCcmFuZFwiLCBsZWFkZXJib2FyZDogXCJCYWV0YXBlbGUgYmEgTmd3YWdhXCIgfVxuICB9LFxuICBoZTogeyAvLyBIZWJyZXcgKFJUTClcbiAgICBuYXY6IHsgZmVlZDogXCLXpNeZ15NcIiwgYnJhbmRzOiBcItee15XXqteS15nXnVwiLCBtZXNzYWdlczogXCLXlNeV15PXoteV16pcIiwgYXdhcmRzOiBcItek16jXodeZ151cIiwgZGFzaGJvYXJkOiBcItec15XXlyDXkden16jXlFwiLCBhZG1pbjogXCLXoNeZ15TXldecXCIsIHByb2ZpbGU6IFwi16TXqNeV16TXmdecXCIsIHBvc3Q6IFwi16TXqNeh151cIiwgc2lnbkluOiBcIteU16rXl9eR16hcIiwgc2lnbk91dDogXCLXlNeq16DXqtenXCIgfSxcbiAgICB2b3RlOiB7IHN0YXNoOiBcItec16nXnteV16hcIiwgdHJhc2g6IFwi15zXlteo15XXp1wiLCBub1ZvdGVzOiBcIteQ15nXnyDXoteT15nXmdefINen15XXnNeV16pcIiwgc2lnbkluUHJvbXB0OiBcIteU16rXl9eR16gg15vXk9eZINec16rXqiDXkNeqINek16HXpyDXlNeT15nXnyDXqdec15ouXCIsIHN0YXNoQ291bnQ6IFwie3tjb3VudH19INep157XqNeVXCIsIHRyYXNoQ291bnQ6IFwie3tjb3VudH19INeW16jXp9eVXCIgfSxcbiAgICBhdXRoOiB7IHNpZ25JbjogXCLXlNeq15fXkdeoXCIsIHNpZ25VcDogXCLXlNeo16nXnVwiLCBlbWFpbDogXCLXk9eV15DXtNecXCIsIHBhc3N3b3JkOiBcIteh15nXodee15RcIiwgZGlzcGxheU5hbWU6IFwi16nXnSDXqtem15XXkteUXCIsIGNyZWF0ZUFjY291bnQ6IFwi16bXldeoINeX16nXkdeV159cIiwgY29udGludWVHb29nbGU6IFwi15TXntep15og16LXnSBHb29nbGVcIiwgd2VsY29tZTogXCLXkdeo15XXmiDXqdeV15HXmiFcIiB9LFxuICAgIGJyYW5kOiB7IHRpdGxlOiBcItee15XXqteS15nXnVwiLCBzdWJ0aXRsZTogXCLXnteV16rXkteZ150g157XkNeV157XqteZ150g15XXpNeh16fXmSDXlNeT15nXnyDXqdecINeU16fXlNeZ15zXlCDXkdeW157XnyDXkNee16ouXCIsIHZlcmlmaWVkOiBcItee15DXldee16pcIiwgdHJ1c3RTY29yZTogXCLXnteT15Mg15DXnteV159cIiwgc2VhcmNoUGxhY2Vob2xkZXI6IFwi15fXpNepINee15XXqteS15nXnS4uLlwiIH0sXG4gICAgYXdhcmRzOiB7IHRpdGxlOiBcItek16jXodeZIFNPVFwiLCB0YWdsaW5lOiBcIteR16jXldee15jXqCDXkNee15XXnyDXlNee15XXqteS15nXnVwiLCBsZWFkZXJib2FyZDogXCLXmNeR15zXqiDXlNee15XXkdeZ15zXmdedXCIgfVxuICB9LFxuICBmYTogeyAvLyBQZXJzaWFuIChSVEwpXG4gICAgbmF2OiB7IGZlZWQ6IFwi2YHbjNivXCIsIGJyYW5kczogXCLYqNix2YbYr9mH2KdcIiwgbWVzc2FnZXM6IFwi2b7bjNin2YXigIzZh9inXCIsIGF3YXJkczogXCLYrNmI2KfbjNiyXCIsIGRhc2hib2FyZDogXCLYr9in2LTYqNmI2LHYr1wiLCBhZG1pbjogXCLZhdiv24zYsduM2KpcIiwgcHJvZmlsZTogXCLZvtix2YjZgdin24zZhFwiLCBwb3N0OiBcItin2LHYs9in2YRcIiwgc2lnbkluOiBcItmI2LHZiNivXCIsIHNpZ25PdXQ6IFwi2K7YsdmI2KxcIiB9LFxuICAgIHZvdGU6IHsgc3Rhc2g6IFwi2Ybar9mH4oCM2K/Yp9ix24xcIiwgdHJhc2g6IFwi2LHYryDaqdix2K/ZhlwiLCBub1ZvdGVzOiBcItmH2YbZiNiyINix2KPbjNuMINir2KjYqiDZhti02K/Zh1wiLCBzaWduSW5Qcm9tcHQ6IFwi2KjYsdin24wg2KvYqNiqINix2KPbjCDYrtmI2K8g2YjYp9ix2K8g2LTZiNuM2K8uXCIsIHN0YXNoQ291bnQ6IFwie3tjb3VudH19INmG2q/Zh+KAjNiv2KfYsduMXCIsIHRyYXNoQ291bnQ6IFwie3tjb3VudH19INix2K8g2qnYsdiv2YZcIiB9LFxuICAgIGF1dGg6IHsgc2lnbkluOiBcItmI2LHZiNivXCIsIHNpZ25VcDogXCLYq9io2KrigIzZhtin2YVcIiwgZW1haWw6IFwi2KfbjNmF24zZhFwiLCBwYXNzd29yZDogXCLYsdmF2LIg2LnYqNmI2LFcIiwgZGlzcGxheU5hbWU6IFwi2YbYp9mFINmG2YXYp9uM2LTbjFwiLCBjcmVhdGVBY2NvdW50OiBcItin24zYrNin2K8g2K3Ys9in2KhcIiwgY29udGludWVHb29nbGU6IFwi2KfYr9in2YXZhyDYqNinINqv2Yjar9mEXCIsIHdlbGNvbWU6IFwi2K7ZiNi0INii2YXYr9uM2K8hXCIgfSxcbiAgICBicmFuZDogeyB0aXRsZTogXCLYqNix2YbYr9mH2KdcIiwgc3VidGl0bGU6IFwi2KjYsdmG2K/Zh9in24wg2KrYo9uM24zYryDYtNiv2Ycg2Ygg2YLYttin2YjYquKAjNmH2KfbjCDYstmG2K/ZhyDYrNin2YXYudmHLlwiLCB2ZXJpZmllZDogXCLYqtij24zbjNivINi02K/Zh1wiLCB0cnVzdFNjb3JlOiBcItin2YXYqtuM2KfYsiDYp9i52KrZhdin2K9cIiwgc2VhcmNoUGxhY2Vob2xkZXI6IFwi2KzYs9iq2KzZiNuMINio2LHZhtiv2YfYpy4uLlwiIH0sXG4gICAgYXdhcmRzOiB7IHRpdGxlOiBcItis2YjYp9uM2LIgU09UXCIsIHRhZ2xpbmU6IFwi2YHYtNin2LHYs9mG2Kwg2KfYudiq2YXYp9ivINio2Ycg2KjYsdmG2K9cIiwgbGVhZGVyYm9hcmQ6IFwi2KzYr9mI2YQg2b7bjNi02KrYp9iy2KfZhlwiIH1cbiAgfSxcbiAgdXI6IHsgLy8gVXJkdSAoUlRMKVxuICAgIG5hdjogeyBmZWVkOiBcItmB24zaiFwiLCBicmFuZHM6IFwi2KjYsdin2YbaiNiyXCIsIG1lc3NhZ2VzOiBcItm+24zYutin2YXYp9iqXCIsIGF3YXJkczogXCLYp9uM2YjYp9ix2ojYslwiLCBkYXNoYm9hcmQ6IFwi2ojbjNi0INio2YjYsdqIXCIsIGFkbWluOiBcItin24zaiNmF2YZcIiwgcHJvZmlsZTogXCLZvtix2YjZgdin2KbZhFwiLCBwb3N0OiBcItm+2YjYs9m5XCIsIHNpZ25JbjogXCLZhNin2q8g2KfZhlwiLCBzaWduT3V0OiBcItmE2KfaryDYotik2blcIiB9LFxuICAgIHZvdGU6IHsgc3Rhc2g6IFwi2LHaqdq+24zaulwiLCB0cmFzaDogXCLZhdiz2KrYsdivXCIsIG5vVm90ZXM6IFwi2KfYqNq+24wg2KraqSDaqdmI2KbbjCDZiNmI2bkg2YbbgduM2rpcIiwgc2lnbkluUHJvbXB0OiBcItin2b7ZhtinINmB24zYtdmE24Eg2K/bjNmG25Ig2qnbkiDZhNuM25Ig2YTYp9qvINin2YYg2qnYsduM2rrblFwiLCBzdGFzaENvdW50OiBcInt7Y291bnR9fSDYsdqp2r7bjNq6XCIsIHRyYXNoQ291bnQ6IFwie3tjb3VudH19INmF2LPYqtix2K9cIiB9LFxuICAgIGF1dGg6IHsgc2lnbkluOiBcItmE2KfaryDYp9mGXCIsIHNpZ25VcDogXCLYs9in2KbZhiDYp9m+XCIsIGVtYWlsOiBcItin24wg2YXbjNmEXCIsIHBhc3N3b3JkOiBcItm+2KfYsyDZiNix2ohcIiwgZGlzcGxheU5hbWU6IFwi2YbYp9mFXCIsIGNyZWF0ZUFjY291bnQ6IFwi2Kfaqdin2KTZhtm5INio2YbYp9im24zaulwiLCBjb250aW51ZUdvb2dsZTogXCLar9mI2q/ZhCDaqduSINiz2KfYqtq+INis2KfYsduMINix2qnavtuM2rpcIiwgd2VsY29tZTogXCLYrtmI2LQg2KLZhdiv24zYryFcIiB9LFxuICAgIGJyYW5kOiB7IHRpdGxlOiBcItio2LHYp9mG2ojYslwiLCBzdWJ0aXRsZTogXCLYqti12K/bjNmCINi02K/bgSDYqNix2KfZhtqI2LIg2KfZiNixINi52YjYp9mFINqp2Kcg2KjYsdin24Eg2LHYp9iz2Kog2YHbjNi12YTbgduUXCIsIHZlcmlmaWVkOiBcItiq2LXYr9uM2YIg2LTYr9uBXCIsIHRydXN0U2NvcmU6IFwi2KfYudiq2YXYp9ivINqp2Kcg2KfYs9qp2YjYsVwiLCBzZWFyY2hQbGFjZWhvbGRlcjogXCLYqNix2KfZhtqIINiq2YTYp9i0INqp2LHbjNq6Li4uXCIgfSxcbiAgICBhd2FyZHM6IHsgdGl0bGU6IFwi2KfbjNizINin2Ygg2bnbjCDYp9uM2YjYp9ix2ojYslwiLCB0YWdsaW5lOiBcItio2LHYp9mG2ogg2b7YsSDYudmI2KfZhSDaqduSINin2LnYqtmF2KfYryDaqdinINm+24zZhdin2YbbgVwiLCBsZWFkZXJib2FyZDogXCLZhNuM2ojYsSDYqNmI2LHaiFwiIH1cbiAgfSxcbiAgYm46IHsgLy8gQmVuZ2FsaVxuICAgIG5hdjogeyBmZWVkOiBcIuCmq+Cmv+CmoVwiLCBicmFuZHM6IFwi4Kas4KeN4Kaw4KeN4Kav4Ka+4Kao4KeN4Kah4Ka4XCIsIG1lc3NhZ2VzOiBcIuCmrOCmvuCmsOCnjeCmpOCmvlwiLCBhd2FyZHM6IFwi4Kaq4KeB4Kaw4Ka44KeN4KaV4Ka+4KawXCIsIGRhc2hib2FyZDogXCLgpqHgp43gpq/gpr7gprbgpqzgp4vgprDgp43gpqFcIiwgYWRtaW46IFwi4KaF4KeN4Kav4Ka+4Kah4Kau4Ka/4KaoXCIsIHByb2ZpbGU6IFwi4Kaq4KeN4Kaw4KeL4Kar4Ka+4KaH4KayXCIsIHBvc3Q6IFwi4Kaq4KeL4Ka44KeN4KafXCIsIHNpZ25JbjogXCLgprjgpr7gpofgpqgg4KaH4KaoXCIsIHNpZ25PdXQ6IFwi4Ka44Ka+4KaH4KaoIOCmhuCmieCmn1wiIH0sXG4gICAgdm90ZTogeyBzdGFzaDogXCLgprDgpr7gppbgp4HgpqhcIiwgdHJhc2g6IFwi4Kas4Ka+4Kak4Ka/4KayXCIsIG5vVm90ZXM6IFwi4KaP4KaW4Kao4KaTIOCmleCni+CmqCDgpq3gp4vgpp8g4Kao4KeH4KaHXCIsIHNpZ25JblByb21wdDogXCLgpobgpqrgpqjgpr7gprAg4Kaw4Ka+4Kav4Ka8IOCmnOCmvuCmqOCmvuCmpOCnhyDgprjgpr7gpofgpqgg4KaH4KaoIOCmleCmsOCngeCmqOClpFwiLCBzdGFzaENvdW50OiBcInt7Y291bnR9fSDgprDgpr7gppbgp4HgpqhcIiwgdHJhc2hDb3VudDogXCJ7e2NvdW50fX0g4Kas4Ka+4Kak4Ka/4KayXCIgfSxcbiAgICBhdXRoOiB7IHNpZ25JbjogXCLgprjgpr7gpofgpqgg4KaH4KaoXCIsIHNpZ25VcDogXCLgprjgpr7gpofgpqgg4KaG4KaqXCIsIGVtYWlsOiBcIuCmh+CmruCnh+CmslwiLCBwYXNzd29yZDogXCLgpqrgpr7gprjgppPgpq/gprzgpr7gprDgp43gpqFcIiwgZGlzcGxheU5hbWU6IFwi4Kao4Ka+4KauXCIsIGNyZWF0ZUFjY291bnQ6IFwi4KaF4KeN4Kav4Ka+4KaV4Ka+4KaJ4Kao4KeN4KafIOCmpOCniOCmsOCmvyDgppXgprDgp4HgpqhcIiwgY29udGludWVHb29nbGU6IFwiR29vZ2xlIOCmpuCmv+Cmr+CmvOCnhyDgpprgpr7gprLgpr/gpq/gprzgp4cg4Kav4Ka+4KaoXCIsIHdlbGNvbWU6IFwi4Ka44KeN4Kas4Ka+4KaX4Kak4KauIVwiIH0sXG4gICAgYnJhbmQ6IHsgdGl0bGU6IFwi4Kas4KeN4Kaw4KeN4Kav4Ka+4Kao4KeN4Kah4Ka4XCIsIHN1YnRpdGxlOiBcIuCmr+CmvuCmmuCmvuCmh+CmleCng+CmpCDgpqzgp43gprDgp43gpq/gpr7gpqjgp43gpqEg4KaP4Kas4KaCIOCmpOCmvuCmpuCnh+CmsCDgppPgpqrgprAg4Kac4Kao4Ka44Ka+4Kan4Ka+4Kaw4Kaj4KeH4KawIOCmuOCmsOCmvuCmuOCmsOCmvyDgprDgpr7gpq/gprzgpaRcIiwgdmVyaWZpZWQ6IFwi4Kav4Ka+4Kaa4Ka+4KaH4KaV4KeD4KakXCIsIHRydXN0U2NvcmU6IFwi4KaG4Ka44KeN4Kal4Ka+4KawIOCmuOCnjeCmleCni+CmsFwiLCBzZWFyY2hQbGFjZWhvbGRlcjogXCLgpqzgp43gprDgp43gpq/gpr7gpqjgp43gpqEg4KaW4KeB4KaB4Kac4KeB4KaoLi4uXCIgfSxcbiAgICBhd2FyZHM6IHsgdGl0bGU6IFwiU09UIOCmquCngeCmsOCmuOCnjeCmleCmvuCmsFwiLCB0YWdsaW5lOiBcIuCmrOCnjeCmsOCnjeCmr+CmvuCmqOCnjeCmoSDgpobgprjgp43gpqXgpr7gprAg4Kas4KeN4Kav4Ka+4Kaw4KeL4Kau4Ka/4Kaf4Ka+4KawXCIsIGxlYWRlcmJvYXJkOiBcIuCmtuCngOCmsOCnjeCmtyDgpqTgpr7gprLgpr/gppXgpr5cIiB9XG4gIH0sXG4gIHRhOiB7IC8vIFRhbWlsXG4gICAgbmF2OiB7IGZlZWQ6IFwi4K6q4K6k4K6/4K614K+B4K6V4K6z4K+NXCIsIGJyYW5kczogXCLgrqrgrr/grrDgrr7grqPgr43grp/gr4HgrpXgrrPgr41cIiwgbWVzc2FnZXM6IFwi4K6a4K+G4K6v4K+N4K6k4K6/4K6V4K6z4K+NXCIsIGF3YXJkczogXCLgrrXgrr/grrDgr4HgrqTgr4HgrpXgrrPgr41cIiwgZGFzaGJvYXJkOiBcIuCuruCvgeCuleCuquCvjeCuquCvgSDgrqrgrrLgrpXgr4hcIiwgYWRtaW46IFwi4K6o4K6/4K6w4K+N4K614K6+4K6V4K6/XCIsIHByb2ZpbGU6IFwi4K6a4K+B4K6v4K614K6/4K614K6w4K6u4K+NXCIsIHBvc3Q6IFwi4K6q4K6k4K6/4K614K6/4K6f4K+BXCIsIHNpZ25JbjogXCLgrongrrPgr43grqjgr4HgrrTgr4jgrpVcIiwgc2lnbk91dDogXCLgrrXgr4bgrrPgrr/grq/gr4fgrrHgr4HgrpVcIiB9LFxuICAgIHZvdGU6IHsgc3Rhc2g6IFwi4K6a4K+H4K6u4K6/XCIsIHRyYXNoOiBcIuCuqOCuv+CusOCuvuCuleCusOCuv1wiLCBub1ZvdGVzOiBcIuCuteCuvuCuleCvjeCuleCvgeCuleCus+CvjSDgrofgrrLgr43grrLgr4hcIiwgc2lnbkluUHJvbXB0OiBcIuCuieCumeCvjeCuleCus+CvjSDgrqTgr4DgrrDgr43grqrgr43grqrgr4gg4K614K604K6Z4K+N4K6VIOCuieCus+CvjeCuqOCvgeCutOCviOCulS5cIiwgc3Rhc2hDb3VudDogXCJ7e2NvdW50fX0g4K6a4K+H4K6u4K6/XCIsIHRyYXNoQ291bnQ6IFwie3tjb3VudH19IOCuqOCuv+CusOCuvuCuleCusOCuv1wiIH0sXG4gICAgYXV0aDogeyBzaWduSW46IFwi4K6J4K6z4K+N4K6o4K+B4K604K+I4K6VXCIsIHNpZ25VcDogXCLgrqrgrqTgrr/grrXgr4Eg4K6a4K+G4K6v4K+N4K6VXCIsIGVtYWlsOiBcIuCuruCuv+CuqeCvjeCuqeCunuCvjeCumuCusuCvjVwiLCBwYXNzd29yZDogXCLgrpXgrp/grrXgr4Hgrprgr43grprgr4rgrrLgr41cIiwgZGlzcGxheU5hbWU6IFwi4K6q4K+G4K6v4K6w4K+NXCIsIGNyZWF0ZUFjY291bnQ6IFwi4K6V4K6j4K6V4K+N4K6V4K+IIOCuieCusOCvgeCuteCuvuCuleCvjeCuleCvgeCulVwiLCBjb250aW51ZUdvb2dsZTogXCJHb29nbGUg4K6J4K6f4K6p4K+NIOCupOCviuCun+CusOCvjeCulVwiLCB3ZWxjb21lOiBcIuCuruCvgOCuo+CvjeCun+CvgeCuruCvjSDgrrXgrrDgr4HgrpUhXCIgfSxcbiAgICBicmFuZDogeyB0aXRsZTogXCLgrqrgrr/grrDgrr7grqPgr43grp/gr4HgrpXgrrPgr41cIiwgc3VidGl0bGU6IFwi4K6a4K6w4K6/4K6q4K6+4K6w4K+N4K6V4K+N4K6V4K6q4K+N4K6q4K6f4K+N4K6fIOCuquCuv+CusOCuvuCuo+CvjeCun+CvgeCuleCus+CvjSDgrq7grrHgr43grrHgr4Hgrq7gr40g4K6u4K6V4K+N4K6V4K6z4K6/4K6p4K+NIOCuqOCvh+CusOCun+Cuv+CupOCvjSDgrqTgr4DgrrDgr43grqrgr43grqrgr4EuXCIsIHZlcmlmaWVkOiBcIuCumuCusOCuv+CuquCuvuCusOCvjeCuleCvjeCuleCuquCvjeCuquCun+CvjeCun+CupOCvgVwiLCB0cnVzdFNjb3JlOiBcIuCuqOCuruCvjeCuquCuleCupOCvjeCupOCuqeCvjeCuruCviCDgrq7grqTgrr/grqrgr43grqrgr4bgrqPgr41cIiwgc2VhcmNoUGxhY2Vob2xkZXI6IFwi4K6q4K6/4K6w4K6+4K6j4K+N4K6f4K+I4K6k4K+NIOCupOCvh+Cun+CvgeCulS4uLlwiIH0sXG4gICAgYXdhcmRzOiB7IHRpdGxlOiBcIlNPVCDgrrXgrr/grrDgr4HgrqTgr4HgrpXgrrPgr41cIiwgdGFnbGluZTogXCLgrqrgrr/grrDgrr7grqPgr43grp/gr40g4K6o4K6u4K+N4K6q4K6/4K6V4K+N4K6V4K+I4K6v4K6/4K6p4K+NIOCuheCus+CuteCvgeCuruCuvuCuqeCuv1wiLCBsZWFkZXJib2FyZDogXCLgrq7gr4Hgrqngr43grqngrqPgrr8g4K6q4K6f4K+N4K6f4K6/4K6v4K6y4K+NXCIgfVxuICB9LFxuICB0ZTogeyAvLyBUZWx1Z3VcbiAgICBuYXY6IHsgZmVlZDogXCLgsKvgsYDgsKHgsY1cIiwgYnJhbmRzOiBcIuCwrOCxjeCwsOCwvuCwguCwoeCxjeKAjOCwsuCxgVwiLCBtZXNzYWdlczogXCLgsLjgsILgsKbgsYfgsLbgsL7gsLLgsYFcIiwgYXdhcmRzOiBcIuCwheCwteCwvuCwsOCxjeCwoeCxgeCwsuCxgVwiLCBkYXNoYm9hcmQ6IFwi4LCh4LGN4LCv4LC+4LC34LGN4oCM4LCs4LGL4LCw4LGN4LCh4LGNXCIsIGFkbWluOiBcIuCwheCwoeCxjeCwruCwv+CwqOCxjVwiLCBwcm9maWxlOiBcIuCwquCxjeCwsOCxiuCwq+CxiOCwsuCxjVwiLCBwb3N0OiBcIuCwquCxi+CwuOCxjeCwn+CxjVwiLCBzaWduSW46IFwi4LC44LGI4LCo4LGNIOCwh+CwqOCxjVwiLCBzaWduT3V0OiBcIuCwuOCxiOCwqOCxjSDgsIXgsLXgsYHgsJ/gsY1cIiB9LFxuICAgIHZvdGU6IHsgc3Rhc2g6IFwi4LCJ4LCC4LCa4LGBXCIsIHRyYXNoOiBcIuCwteCwpuCxjeCwpuCxgVwiLCBub1ZvdGVzOiBcIuCwh+CwguCwleCwviDgsJPgsJ/gsY3gsLLgsYEg4LCy4LGH4LC14LGBXCIsIHNpZ25JblByb21wdDogXCLgsK7gsYAg4LCk4LGA4LCw4LGN4LCq4LGBIOCwmuCxhuCwquCxjeCwquCwoeCwvuCwqOCwv+CwleCwvyDgsLjgsYjgsKjgsY0g4LCH4LCo4LGNIOCwmuCxh+Cwr+CwguCwoeCwvy5cIiwgc3Rhc2hDb3VudDogXCJ7e2NvdW50fX0g4LCJ4LCC4LCa4LGBXCIsIHRyYXNoQ291bnQ6IFwie3tjb3VudH19IOCwteCwpuCxjeCwpuCxgVwiIH0sXG4gICAgYXV0aDogeyBzaWduSW46IFwi4LC44LGI4LCo4LGNIOCwh+CwqOCxjVwiLCBzaWduVXA6IFwi4LC44LGI4LCo4LGNIOCwheCwquCxjVwiLCBlbWFpbDogXCLgsIjgsK7gsYbgsK/gsL/gsLLgsY1cIiwgcGFzc3dvcmQ6IFwi4LCq4LC+4LC44LGN4oCM4LC14LCw4LGN4LCh4LGNXCIsIGRpc3BsYXlOYW1lOiBcIuCwquCxh+CwsOCxgVwiLCBjcmVhdGVBY2NvdW50OiBcIuCwluCwvuCwpOCwvuCwqOCxgSDgsLjgsYPgsLfgsY3gsJ/gsL/gsILgsJrgsILgsKHgsL9cIiwgY29udGludWVHb29nbGU6IFwiR29vZ2xl4LCk4LGLIOCwleCxiuCwqOCwuOCwvuCwl+Cwv+CwguCwmuCwguCwoeCwv1wiLCB3ZWxjb21lOiBcIuCwuOCxjeCwteCwvuCwl+CwpOCwgiFcIiB9LFxuICAgIGJyYW5kOiB7IHRpdGxlOiBcIuCwrOCxjeCwsOCwvuCwguCwoeCxjeKAjOCwsuCxgVwiLCBzdWJ0aXRsZTogXCLgsKfgsYPgsLXgsYDgsJXgsLDgsL/gsILgsJrgsKzgsKHgsL/gsKgg4LCs4LGN4LCw4LC+4LCC4LCh4LGN4oCM4LCy4LGBIOCwruCwsOCwv+Cwr+CxgSDgsKrgsY3gsLDgsJzgsLIg4LCq4LGN4LCw4LCk4LGN4LCv4LCV4LGN4LC3IOCwpOCxgOCwsOCxjeCwquCxgeCwsuCxgS5cIiwgdmVyaWZpZWQ6IFwi4LCn4LGD4LC14LGA4LCV4LCw4LC/4LCC4LCa4LCs4LCh4LC/4LCC4LCm4LC/XCIsIHRydXN0U2NvcmU6IFwi4LC14LC/4LC24LGN4LC14LC44LCo4LGA4LCv4LCkIOCwuOCxjeCwleCxi+CwsOCxjVwiLCBzZWFyY2hQbGFjZWhvbGRlcjogXCLgsKzgsY3gsLDgsL7gsILgsKHgsY3igIzgsLLgsKjgsYEg4LC24LGL4LCn4LC/4LCC4LCa4LCC4LCh4LC/Li4uXCIgfSxcbiAgICBhd2FyZHM6IHsgdGl0bGU6IFwiU09UIOCwheCwteCwvuCwsOCxjeCwoeCxgeCwsuCxgVwiLCB0YWdsaW5lOiBcIuCwrOCxjeCwsOCwvuCwguCwoeCxjSDgsLXgsL/gsLbgsY3gsLXgsLjgsKjgsYDgsK/gsKQg4LCs4LGH4LCw4LGL4LCu4LGA4LCf4LCw4LGNXCIsIGxlYWRlcmJvYXJkOiBcIuCwsuCxgOCwoeCwsOCxjeKAjOCwrOCxi+CwsOCxjeCwoeCxjVwiIH1cbiAgfSxcbiAgbXI6IHsgLy8gTWFyYXRoaVxuICAgIG5hdjogeyBmZWVkOiBcIuCkq+ClgOCkoVwiLCBicmFuZHM6IFwi4KSs4KWN4KSw4KSB4KSh4KWN4KS4XCIsIG1lc3NhZ2VzOiBcIuCkuOCkguCkpuClh+CktlwiLCBhd2FyZHM6IFwi4KSq4KWB4KSw4KS44KWN4KSV4KS+4KSwXCIsIGRhc2hib2FyZDogXCLgpKHgpYXgpLbgpKzgpYvgpLDgpY3gpKFcIiwgYWRtaW46IFwi4KSq4KWN4KSw4KS24KS+4KS44KSVXCIsIHByb2ZpbGU6IFwi4KSq4KWN4KSw4KWL4KSr4KS+4KSH4KSyXCIsIHBvc3Q6IFwi4KSq4KWL4KS44KWN4KSfXCIsIHNpZ25JbjogXCLgpLjgpL7gpIfgpKgg4KSH4KSoXCIsIHNpZ25PdXQ6IFwi4KSs4KS+4KS54KWH4KSwIOCkquCkoeCkvlwiIH0sXG4gICAgdm90ZTogeyBzdGFzaDogXCLgpKDgpYfgpLXgpL5cIiwgdHJhc2g6IFwi4KSo4KSV4KWLXCIsIG5vVm90ZXM6IFwi4KSF4KSm4KWN4KSv4KS+4KSqIOCkruCkpOClhyDgpKjgpL7gpLngpYDgpKRcIiwgc2lnbkluUHJvbXB0OiBcIuCkhuCkquCksuCkviDgpKjgpL/gpLDgpY3gpKPgpK8g4KSm4KWH4KSj4KWN4KSv4KS+4KS44KS+4KSg4KWAIOCkuOCkvuCkh+CkqCDgpIfgpKgg4KSV4KSw4KS+LlwiLCBzdGFzaENvdW50OiBcInt7Y291bnR9fSDgpKDgpYfgpLXgpL5cIiwgdHJhc2hDb3VudDogXCJ7e2NvdW50fX0g4KSo4KSV4KWLXCIgfSxcbiAgICBhdXRoOiB7IHNpZ25JbjogXCLgpLjgpL7gpIfgpKgg4KSH4KSoXCIsIHNpZ25VcDogXCLgpKjgpYvgpILgpKbgpKPgpYAg4KSV4KSw4KS+XCIsIGVtYWlsOiBcIuCkiOCkruClh+CkslwiLCBwYXNzd29yZDogXCLgpKrgpL7gpLjgpLXgpLDgpY3gpKFcIiwgZGlzcGxheU5hbWU6IFwi4KSo4KS+4KS1XCIsIGNyZWF0ZUFjY291bnQ6IFwi4KSW4KS+4KSk4KWHIOCkpOCkr+CkvuCksCDgpJXgpLDgpL5cIiwgY29udGludWVHb29nbGU6IFwiR29vZ2xlIOCkuOCkuSDgpKrgpYHgpKLgpYcg4KSc4KS+XCIsIHdlbGNvbWU6IFwi4KS44KWN4KS14KS+4KSX4KSkIOCkhuCkueClhyFcIiB9LFxuICAgIGJyYW5kOiB7IHRpdGxlOiBcIuCkrOCljeCksOCkgeCkoeCljeCkuFwiLCBzdWJ0aXRsZTogXCLgpKrgpY3gpLDgpK7gpL7gpKPgpL/gpKQg4KSs4KWN4KSw4KSB4KSh4KWN4KS4IOCkhuCko+CkvyDgpLLgpYvgpJXgpL7gpILgpJrgpYcg4KSl4KWH4KSfIOCkheCkreCkv+CkquCljeCksOCkvuCkry5cIiwgdmVyaWZpZWQ6IFwi4KSq4KWN4KSw4KSu4KS+4KSj4KS/4KSkXCIsIHRydXN0U2NvcmU6IFwi4KS14KS/4KS24KWN4KS14KS+4KS44KS+4KSw4KWN4KS54KSk4KS+IOCkp+CkvuCkteCkuOCkguCkluCljeCkr+CkvlwiLCBzZWFyY2hQbGFjZWhvbGRlcjogXCLgpKzgpY3gpLDgpIHgpKEg4KS24KWL4KSn4KS+Li4uXCIgfSxcbiAgICBhd2FyZHM6IHsgdGl0bGU6IFwiU09UIOCkquClgeCksOCkuOCljeCkleCkvuCksFwiLCB0YWdsaW5lOiBcIuCkrOCljeCksOCkgeCkoSDgpLXgpL/gpLbgpY3gpLXgpL7gpLjgpL7gpJrgpYcg4KSu4KWL4KSc4KSu4KS+4KSqXCIsIGxlYWRlcmJvYXJkOiBcIuCkheCkteCljeCkteCksiDgpK/gpL7gpKbgpYBcIiB9XG4gIH0sXG4gIGd1OiB7IC8vIEd1amFyYXRpXG4gICAgbmF2OiB7IGZlZWQ6IFwi4Kqr4KuA4KqhXCIsIGJyYW5kczogXCLgqqzgq43gqrDgqr7gqqjgq43gqqHgq43gqrhcIiwgbWVzc2FnZXM6IFwi4Kq44KqC4Kqm4KuH4Kq24Kq+4KqTXCIsIGF3YXJkczogXCLgqo/gqrXgq4vgqrDgq43gqqHgq43gqrhcIiwgZGFzaGJvYXJkOiBcIuCqoeCrh+CqtuCqrOCri+CqsOCrjeCqoVwiLCBhZG1pbjogXCLgqo/gqqHgqq7gqr/gqqhcIiwgcHJvZmlsZTogXCLgqqrgq43gqrDgq4vgqqvgqr7gqofgqrJcIiwgcG9zdDogXCLgqqrgq4vgqrjgq43gqp9cIiwgc2lnbkluOiBcIuCquOCqvuCqh+CqqCDgqofgqqhcIiwgc2lnbk91dDogXCLgqrjgqr7gqofgqqgg4KqG4KqJ4KqfXCIgfSxcbiAgICB2b3RlOiB7IHN0YXNoOiBcIuCquOCqvuCqmuCqteCri1wiLCB0cmFzaDogXCLgqqjgqpXgqr7gqrDgq4tcIiwgbm9Wb3RlczogXCLgqrngqpzgq4Ag4Kq44KuB4Kqn4KuAIOCqleCri+CqiCDgqq7gqqQg4Kqo4Kql4KuAXCIsIHNpZ25JblByb21wdDogXCLgqqTgqq7gqr7gqrDgq4sg4Kqo4Kq/4Kqw4KuN4Kqj4KqvIOCqhuCqquCqteCqviDgqq7gqr7gqp/gq4cg4Kq44Kq+4KqH4KqoIOCqh+CqqCDgqpXgqrDgq4suXCIsIHN0YXNoQ291bnQ6IFwie3tjb3VudH19IOCquOCqvuCqmuCqteCri1wiLCB0cmFzaENvdW50OiBcInt7Y291bnR9fSDgqqjgqpXgqr7gqrDgq4tcIiB9LFxuICAgIGF1dGg6IHsgc2lnbkluOiBcIuCquOCqvuCqh+CqqCDgqofgqqhcIiwgc2lnblVwOiBcIuCquOCqvuCqh+CqqCDgqoXgqqpcIiwgZW1haWw6IFwi4KqH4Kqu4KuH4KqH4KqyXCIsIHBhc3N3b3JkOiBcIuCqquCqvuCquOCqteCqsOCrjeCqoVwiLCBkaXNwbGF5TmFtZTogXCLgqqjgqr7gqq5cIiwgY3JlYXRlQWNjb3VudDogXCLgqo/gqpXgqr7gqongqqjgq43gqp8g4Kqs4Kqo4Kq+4Kq14KuLXCIsIGNvbnRpbnVlR29vZ2xlOiBcIkdvb2dsZSDgqrjgqr7gqqXgq4cg4Kqa4Kq+4Kqy4KuBIOCqsOCqvuCqluCri1wiLCB3ZWxjb21lOiBcIuCquOCrjeCqteCqvuCql+CqpCDgqpvgq4chXCIgfSxcbiAgICBicmFuZDogeyB0aXRsZTogXCLgqqzgq43gqrDgqr7gqqjgq43gqqHgq43gqrhcIiwgc3VidGl0bGU6IFwi4Kqa4KqV4Kq+4Kq44Kq+4Kqv4KuH4KqyIOCqrOCrjeCqsOCqvuCqqOCrjeCqoeCrjeCquCDgqoXgqqjgq4cg4Kqc4Kqo4Kqk4Kq+4Kqo4Kq+IOCqqOCqv+CqsOCrjeCqo+Cqr+Criy5cIiwgdmVyaWZpZWQ6IFwi4Kqa4KqV4Kq+4Kq44Kq+4Kqv4KuH4KqyXCIsIHRydXN0U2NvcmU6IFwi4Kq14Kq/4Kq24KuN4Kq14Kq+4Kq4IOCquOCrjeCqleCri+CqsFwiLCBzZWFyY2hQbGFjZWhvbGRlcjogXCLgqqzgq43gqrDgqr7gqqjgq43gqqEg4Kq24KuL4Kqn4KuLLi4uXCIgfSxcbiAgICBhd2FyZHM6IHsgdGl0bGU6IFwiU09UIOCqj+CqteCri+CqsOCrjeCqoeCrjeCquFwiLCB0YWdsaW5lOiBcIuCqrOCrjeCqsOCqvuCqqOCrjeCqoSDgqrXgqr/gqrbgq43gqrXgqr7gqrjgqqjgq4HgqoIg4Kqu4Kq+4Kqq4Kqm4KqC4KqhXCIsIGxlYWRlcmJvYXJkOiBcIuCqsuCrgOCqoeCqsOCqrOCri+CqsOCrjeCqoVwiIH1cbiAgfSxcbiAgcGE6IHsgLy8gUHVuamFiaVxuICAgIG5hdjogeyBmZWVkOiBcIuCoq+CpgOCooVwiLCBicmFuZHM6IFwi4Kis4KmN4Kiw4Ki+4KiC4KihXCIsIG1lc3NhZ2VzOiBcIuCouOCpgeCoqOCph+CoueCph1wiLCBhd2FyZHM6IFwi4KiH4Kio4Ki+4KiuXCIsIGRhc2hib2FyZDogXCLgqKHgqYjgqLjgqLzgqKzgqYvgqLDgqKFcIiwgYWRtaW46IFwi4KiQ4Kih4Kiu4Ki/4KioXCIsIHByb2ZpbGU6IFwi4Kiq4KmN4Kiw4KmL4Kir4Ki+4KiI4KiyXCIsIHBvc3Q6IFwi4Kiq4KmL4Ki44KifXCIsIHNpZ25JbjogXCLgqLjgqL7gqIjgqKgg4KiH4KioXCIsIHNpZ25PdXQ6IFwi4Ki44Ki+4KiI4KioIOCohuCoiuCon1wiIH0sXG4gICAgdm90ZTogeyBzdGFzaDogXCLgqLDgqbHgqJbgqYtcIiwgdHJhc2g6IFwi4Kiw4Kmx4KimXCIsIG5vVm90ZXM6IFwi4KiV4KmL4KiIIOCoteCpi+ConyDgqKjgqLngqYDgqIJcIiwgc2lnbkluUHJvbXB0OiBcIuCohuCoquCoo+CoviDgqKvgqYjgqLjgqLLgqL4g4Kim4KmH4KijIOCosuCoiCDgqLjgqL7gqIjgqKgg4KiH4KioIOColeCosOCpi+ClpFwiLCBzdGFzaENvdW50OiBcInt7Y291bnR9fSDgqLDgqbHgqJbgqYtcIiwgdHJhc2hDb3VudDogXCJ7e2NvdW50fX0g4Kiw4Kmx4KimXCIgfSxcbiAgICBhdXRoOiB7IHNpZ25JbjogXCLgqLjgqL7gqIjgqKgg4KiH4KioXCIsIHNpZ25VcDogXCLgqLjgqL7gqIjgqKgg4KiF4Kmx4KiqXCIsIGVtYWlsOiBcIuCoiOCoruCph+CoslwiLCBwYXNzd29yZDogXCLgqKrgqL7gqLjgqLXgqLDgqKFcIiwgZGlzcGxheU5hbWU6IFwi4Kio4Ki+4KiuXCIsIGNyZWF0ZUFjY291bnQ6IFwi4KiW4Ki+4Kik4Ki+IOCorOCoo+CovuCok1wiLCBjb250aW51ZUdvb2dsZTogXCJHb29nbGUg4Kio4Ki+4KiyIOConOCovuCosOCpgCDgqLDgqbHgqJbgqYtcIiwgd2VsY29tZTogXCLgqJzgqYAg4KiG4KiH4KiG4KiCIOCoqOCpguCpsCFcIiB9LFxuICAgIGJyYW5kOiB7IHRpdGxlOiBcIuCorOCpjeCosOCovuCoguCooVwiLCBzdWJ0aXRsZTogXCLgqKrgqY3gqLDgqK7gqL7gqKPgqL/gqKQg4Kis4KmN4Kiw4Ki+4KiC4KihIOCoheCopOCphyDgqLLgqYvgqJXgqL7gqIIg4Kim4Ki+IOCoq+CpiOCouOCosuCovuClpFwiLCB2ZXJpZmllZDogXCLgqKrgqY3gqLDgqK7gqL7gqKPgqL/gqKRcIiwgdHJ1c3RTY29yZTogXCLgqK3gqLDgqYvgqLjgqL4g4Ki44KiV4KmL4KiwXCIsIHNlYXJjaFBsYWNlaG9sZGVyOiBcIuCorOCpjeCosOCovuCoguCooSDgqJbgqYvgqJzgqYsuLi5cIiB9LFxuICAgIGF3YXJkczogeyB0aXRsZTogXCJTT1Qg4KiH4Kio4Ki+4KiuXCIsIHRhZ2xpbmU6IFwi4Kis4KmN4Kiw4Ki+4KiC4KihIOCoreCosOCpi+CouOCphyDgqKbgqL4g4Kiq4KmI4Kiu4Ki+4Kio4Ki+XCIsIGxlYWRlcmJvYXJkOiBcIuCosuCpgOCooeCosOCorOCpi+CosOCooVwiIH1cbiAgfSxcbiAgdGg6IHsgLy8gVGhhaVxuICAgIG5hdjogeyBmZWVkOiBcIuC4n+C4teC4lFwiLCBicmFuZHM6IFwi4LmB4Lia4Lij4LiZ4LiU4LmMXCIsIG1lc3NhZ2VzOiBcIuC4guC5ieC4reC4hOC4p+C4suC4oVwiLCBhd2FyZHM6IFwi4Lij4Liy4LiH4Lin4Lix4LilXCIsIGRhc2hib2FyZDogXCLguYHguJTguIrguJrguK3guKPguYzguJRcIiwgYWRtaW46IFwi4Lic4Li54LmJ4LiU4Li54LmB4Lil4Lij4Liw4Lia4LiaXCIsIHByb2ZpbGU6IFwi4LmC4Lib4Lij4LmE4Lif4Lil4LmMXCIsIHBvc3Q6IFwi4LmC4Lie4Liq4LiV4LmMXCIsIHNpZ25JbjogXCLguYDguILguYnguLLguKrguLnguYjguKPguLDguJrguJpcIiwgc2lnbk91dDogXCLguK3guK3guIHguIjguLLguIHguKPguLDguJrguJpcIiB9LFxuICAgIHZvdGU6IHsgc3Rhc2g6IFwi4LmA4LiB4LmH4Lia4LmE4Lin4LmJXCIsIHRyYXNoOiBcIuC4l+C4tOC5ieC4h+C5hOC4m1wiLCBub1ZvdGVzOiBcIuC4ouC4seC4h+C5hOC4oeC5iOC4oeC4teC4hOC4sOC5geC4meC4mVwiLCBzaWduSW5Qcm9tcHQ6IFwi4LmA4LiC4LmJ4Liy4Liq4Li54LmI4Lij4Liw4Lia4Lia4LmA4Lie4Li34LmI4Lit4LiV4Lix4LiU4Liq4Li04LiZXCIsIHN0YXNoQ291bnQ6IFwie3tjb3VudH19IOC5gOC4geC5h+C4muC5hOC4p+C5iVwiLCB0cmFzaENvdW50OiBcInt7Y291bnR9fSDguJfguLTguYnguIfguYTguJtcIiB9LFxuICAgIGF1dGg6IHsgc2lnbkluOiBcIuC5gOC4guC5ieC4suC4quC4ueC5iOC4o+C4sOC4muC4mlwiLCBzaWduVXA6IFwi4Lil4LiH4LiX4Liw4LmA4Lia4Li14Lii4LiZXCIsIGVtYWlsOiBcIuC4reC4teC5gOC4oeC4pVwiLCBwYXNzd29yZDogXCLguKPguKvguLHguKrguJzguYjguLLguJlcIiwgZGlzcGxheU5hbWU6IFwi4LiK4Li34LmI4Lit4LiX4Li14LmI4LmB4Liq4LiU4LiHXCIsIGNyZWF0ZUFjY291bnQ6IFwi4Liq4Lij4LmJ4Liy4LiH4Lia4Lix4LiN4LiK4Li1XCIsIGNvbnRpbnVlR29vZ2xlOiBcIuC4lOC4s+C5gOC4meC4tOC4meC4geC4suC4o+C4leC5iOC4reC4lOC5ieC4p+C4oiBHb29nbGVcIiwgd2VsY29tZTogXCLguKLguLTguJnguJTguLXguJXguYnguK3guJnguKPguLHguJrguIHguKXguLHguJohXCIgfSxcbiAgICBicmFuZDogeyB0aXRsZTogXCLguYHguJrguKPguJnguJTguYxcIiwgc3VidGl0bGU6IFwi4LmB4Lia4Lij4LiZ4LiU4LmM4LiX4Li14LmI4Lic4LmI4Liy4LiZ4LiB4Liy4Lij4Lii4Li34LiZ4Lii4Lix4LiZ4LmB4Lil4Liw4Lic4Lil4LiB4Liy4Lij4LiV4Lix4LiU4Liq4Li04LiZ4Liq4LiU4LiI4Liy4LiB4LiK4Li44Lih4LiK4LiZXCIsIHZlcmlmaWVkOiBcIuC4ouC4t+C4meC4ouC4seC4meC5geC4peC5ieC4p1wiLCB0cnVzdFNjb3JlOiBcIuC4hOC4sOC5geC4meC4meC4hOC4p+C4suC4oeC4meC5iOC4suC5gOC4iuC4t+C5iOC4reC4luC4t+C4rVwiLCBzZWFyY2hQbGFjZWhvbGRlcjogXCLguITguYnguJnguKvguLLguYHguJrguKPguJnguJTguYwuLi5cIiB9LFxuICAgIGF3YXJkczogeyB0aXRsZTogXCLguKPguLLguIfguKfguLHguKUgU09UXCIsIHRhZ2xpbmU6IFwi4Lih4Liy4LiV4Lij4Lin4Lix4LiU4LiE4Lin4Liy4Lih4LmE4Lin4LmJ4Lin4Liy4LiH4LmD4LiI4LmD4LiZ4LmB4Lia4Lij4LiZ4LiU4LmMXCIsIGxlYWRlcmJvYXJkOiBcIuC4geC4o+C4sOC4lOC4suC4meC4nOC4ueC5ieC4meC4s1wiIH1cbiAgfSxcbiAgdmk6IHsgLy8gVmlldG5hbWVzZVxuICAgIG5hdjogeyBmZWVkOiBcIkLhuqNuZyB0aW5cIiwgYnJhbmRzOiBcIlRoxrDGoW5nIGhp4buHdVwiLCBtZXNzYWdlczogXCJUaW4gbmjhuq9uXCIsIGF3YXJkczogXCJHaeG6o2kgdGjGsOG7n25nXCIsIGRhc2hib2FyZDogXCJC4bqjbmcgxJFp4buBdSBraGnhu4NuXCIsIGFkbWluOiBcIlF14bqjbiB0cuG7i1wiLCBwcm9maWxlOiBcIkjhu5Mgc8ahXCIsIHBvc3Q6IFwixJDEg25nXCIsIHNpZ25JbjogXCLEkMSDbmcgbmjhuq1wXCIsIHNpZ25PdXQ6IFwixJDEg25nIHh14bqldFwiIH0sXG4gICAgdm90ZTogeyBzdGFzaDogXCJHaeG7ryBs4bqhaVwiLCB0cmFzaDogXCJMb+G6oWkgYuG7j1wiLCBub1ZvdGVzOiBcIkNoxrBhIGPDsyBiw6xuaCBjaOG7jW5cIiwgc2lnbkluUHJvbXB0OiBcIsSQxINuZyBuaOG6rXAgxJHhu4MgxJHGsGEgcmEgcGjDoW4gcXV54bq/dCBj4bunYSBi4bqhbi5cIiwgc3Rhc2hDb3VudDogXCJ7e2NvdW50fX0gZ2nhu68gbOG6oWlcIiwgdHJhc2hDb3VudDogXCJ7e2NvdW50fX0gbG/huqFpIGLhu49cIiB9LFxuICAgIGF1dGg6IHsgc2lnbkluOiBcIsSQxINuZyBuaOG6rXBcIiwgc2lnblVwOiBcIsSQxINuZyBrw71cIiwgZW1haWw6IFwiRW1haWxcIiwgcGFzc3dvcmQ6IFwiTeG6rXQga2jhuql1XCIsIGRpc3BsYXlOYW1lOiBcIlTDqm4gaGnhu4NuIHRo4buLXCIsIGNyZWF0ZUFjY291bnQ6IFwiVOG6oW8gdMOgaSBraG/huqNuXCIsIGNvbnRpbnVlR29vZ2xlOiBcIlRp4bq/cCB04bulYyB24bubaSBHb29nbGVcIiwgd2VsY29tZTogXCJDaMOgbyBt4burbmcgdHLhu58gbOG6oWkhXCIgfSxcbiAgICBicmFuZDogeyB0aXRsZTogXCJUaMawxqFuZyBoaeG7h3VcIiwgc3VidGl0bGU6IFwiVGjGsMahbmcgaGnhu4d1IMSRw6MgeMOhYyBtaW5oIHbDoCBwaMOhbiBxdXnhur90IHRo4buxYyB04bq/IHThu6sgY+G7mW5nIMSR4buTbmcuXCIsIHZlcmlmaWVkOiBcIsSQw6MgeMOhYyBtaW5oXCIsIHRydXN0U2NvcmU6IFwixJBp4buDbSB0aW4gY+G6rXlcIiwgc2VhcmNoUGxhY2Vob2xkZXI6IFwiVMOsbSBraeG6v20gdGjGsMahbmcgaGnhu4d1Li4uXCIgfSxcbiAgICBhd2FyZHM6IHsgdGl0bGU6IFwiR2nhuqNpIHRoxrDhu59uZyBTT1RcIiwgdGFnbGluZTogXCJUaMaw4bubYyDEkG8gTmnhu4FtIFRpbiBUaMawxqFuZyBIaeG7h3VcIiwgbGVhZGVyYm9hcmQ6IFwiQuG6o25nIHjhur9wIGjhuqFuZ1wiIH1cbiAgfSxcbiAgbXM6IHsgLy8gTWFsYXlcbiAgICBuYXY6IHsgZmVlZDogXCJTdWFwYW5cIiwgYnJhbmRzOiBcIkplbmFtYVwiLCBtZXNzYWdlczogXCJNZXNlalwiLCBhd2FyZHM6IFwiQW51Z2VyYWhcIiwgZGFzaGJvYXJkOiBcIlBhcGFuIFBlbXVrYVwiLCBhZG1pbjogXCJQZW50YWRiaXJcIiwgcHJvZmlsZTogXCJQcm9maWxcIiwgcG9zdDogXCJTaWFya2FuXCIsIHNpZ25JbjogXCJMb2cgbWFzdWtcIiwgc2lnbk91dDogXCJMb2cga2VsdWFyXCIgfSxcbiAgICB2b3RlOiB7IHN0YXNoOiBcIlNpbXBhblwiLCB0cmFzaDogXCJCdWFuZ1wiLCBub1ZvdGVzOiBcIkJlbHVtIGFkYSB1bmRpYW5cIiwgc2lnbkluUHJvbXB0OiBcIkxvZyBtYXN1ayB1bnR1ayBtZW1iZXJpa2FuIGtlcHV0dXNhbiBhbmRhLlwiLCBzdGFzaENvdW50OiBcInt7Y291bnR9fSBzaW1wYW5cIiwgdHJhc2hDb3VudDogXCJ7e2NvdW50fX0gYnVhbmdcIiB9LFxuICAgIGF1dGg6IHsgc2lnbkluOiBcIkxvZyBtYXN1a1wiLCBzaWduVXA6IFwiRGFmdGFyXCIsIGVtYWlsOiBcIkUtbWVsXCIsIHBhc3N3b3JkOiBcIkthdGEgbGFsdWFuXCIsIGRpc3BsYXlOYW1lOiBcIk5hbWEgcGFwYXJhblwiLCBjcmVhdGVBY2NvdW50OiBcIkNpcHRhIGFrYXVuXCIsIGNvbnRpbnVlR29vZ2xlOiBcIlRlcnVza2FuIGRlbmdhbiBHb29nbGVcIiwgd2VsY29tZTogXCJTZWxhbWF0IGtlbWJhbGkhXCIgfSxcbiAgICBicmFuZDogeyB0aXRsZTogXCJKZW5hbWFcIiwgc3VidGl0bGU6IFwiSmVuYW1hIGRpc2Foa2FuIGRhbiBrZXB1dHVzYW4ga29tdW5pdGkgc2VjYXJhIGxhbmdzdW5nLlwiLCB2ZXJpZmllZDogXCJEaXNhaGthblwiLCB0cnVzdFNjb3JlOiBcIlNrb3Iga2VwZXJjYXlhYW5cIiwgc2VhcmNoUGxhY2Vob2xkZXI6IFwiQ2FyaSBqZW5hbWEuLi5cIiB9LFxuICAgIGF3YXJkczogeyB0aXRsZTogXCJBbnVnZXJhaCBTT1RcIiwgdGFnbGluZTogXCJCYXJvbWV0ZXIgS2VwZXJjYXlhYW4gSmVuYW1hXCIsIGxlYWRlcmJvYXJkOiBcIlBhcGFuIFBlbmRhaHVsdVwiIH1cbiAgfSxcbiAgZmlsOiB7IC8vIEZpbGlwaW5vXG4gICAgbmF2OiB7IGZlZWQ6IFwiRmVlZFwiLCBicmFuZHM6IFwiTWdhIEJyYW5kXCIsIG1lc3NhZ2VzOiBcIk1lbnNhaGVcIiwgYXdhcmRzOiBcIk1nYSBQYXJhbmdhbFwiLCBkYXNoYm9hcmQ6IFwiRGFzaGJvYXJkXCIsIGFkbWluOiBcIkFkbWluXCIsIHByb2ZpbGU6IFwiUHJvZmlsZVwiLCBwb3N0OiBcIk1hZy1wb3N0XCIsIHNpZ25JbjogXCJNYWctc2lnbiBpblwiLCBzaWduT3V0OiBcIk1hZy1zaWduIG91dFwiIH0sXG4gICAgdm90ZTogeyBzdGFzaDogXCJJdGFnb1wiLCB0cmFzaDogXCJJdGFwb25cIiwgbm9Wb3RlczogXCJXYWxhIHBhbmcgYm90b1wiLCBzaWduSW5Qcm9tcHQ6IFwiTWFnLXNpZ24gaW4gcGFyYSBtYWdiaWdheSBuZyBpeW9uZyBoYXRvbC5cIiwgc3Rhc2hDb3VudDogXCJ7e2NvdW50fX0gaXRhZ29cIiwgdHJhc2hDb3VudDogXCJ7e2NvdW50fX0gaXRhcG9uXCIgfSxcbiAgICBhdXRoOiB7IHNpZ25JbjogXCJNYWctc2lnbiBpblwiLCBzaWduVXA6IFwiTWFnLXNpZ24gdXBcIiwgZW1haWw6IFwiRW1haWxcIiwgcGFzc3dvcmQ6IFwiUGFzc3dvcmRcIiwgZGlzcGxheU5hbWU6IFwiUGFuZ2FsYW5cIiwgY3JlYXRlQWNjb3VudDogXCJHdW1hd2EgbmcgYWNjb3VudFwiLCBjb250aW51ZUdvb2dsZTogXCJNYWdwYXR1bG95IHNhIEdvb2dsZVwiLCB3ZWxjb21lOiBcIk1hbGlnYXlhbmcgcGFnYmFiYWxpayFcIiB9LFxuICAgIGJyYW5kOiB7IHRpdGxlOiBcIk1nYSBCcmFuZFwiLCBzdWJ0aXRsZTogXCJNZ2EgYmVyaXBpa2Fkb25nIGJyYW5kIGF0IGxpdmUgbmEgaGF0b2wgbmcga29tdW5pZGFkLlwiLCB2ZXJpZmllZDogXCJCZXJpcGlrYWRvXCIsIHRydXN0U2NvcmU6IFwiTWFya2EgbmcgdGl3YWxhXCIsIHNlYXJjaFBsYWNlaG9sZGVyOiBcIk1hZ2hhbmFwIG5nIGJyYW5kLi4uXCIgfSxcbiAgICBhd2FyZHM6IHsgdGl0bGU6IFwiTWdhIFBhcmFuZ2FsIG5nIFNPVFwiLCB0YWdsaW5lOiBcIkFuZyBCYXJvbWV0cm8gbmcgVGl3YWxhIHNhIEJyYW5kXCIsIGxlYWRlcmJvYXJkOiBcIkxlYWRlcmJvYXJkXCIgfVxuICB9LFxuICBybzogeyAvLyBSb21hbmlhblxuICAgIG5hdjogeyBmZWVkOiBcIkZsdXhcIiwgYnJhbmRzOiBcIkJyYW5kdXJpXCIsIG1lc3NhZ2VzOiBcIk1lc2FqZVwiLCBhd2FyZHM6IFwiUHJlbWlpXCIsIGRhc2hib2FyZDogXCJQYW5vdSBkZSBjb250cm9sXCIsIGFkbWluOiBcIkFkbWluXCIsIHByb2ZpbGU6IFwiUHJvZmlsXCIsIHBvc3Q6IFwiUG9zdGVhesSDXCIsIHNpZ25JbjogXCJDb25lY3RhcmVcIiwgc2lnbk91dDogXCJEZWNvbmVjdGFyZVwiIH0sXG4gICAgdm90ZTogeyBzdGFzaDogXCJQxINzdHJlYXrEg1wiLCB0cmFzaDogXCJBcnVuY8SDXCIsIG5vVm90ZXM6IFwiRsSDcsSDIHZvdHVyaSDDrm5jxINcIiwgc2lnbkluUHJvbXB0OiBcIkNvbmVjdGVhesSDLXRlIHBlbnRydSBhIHZvdGEuXCIsIHN0YXNoQ291bnQ6IFwie3tjb3VudH19IHDEg3N0cmVhesSDXCIsIHRyYXNoQ291bnQ6IFwie3tjb3VudH19IGFydW5jxINcIiB9LFxuICAgIGF1dGg6IHsgc2lnbkluOiBcIkNvbmVjdGFyZVwiLCBzaWduVXA6IFwiw45ucmVnaXN0cmFyZVwiLCBlbWFpbDogXCJFbWFpbFwiLCBwYXNzd29yZDogXCJQYXJvbMSDXCIsIGRpc3BsYXlOYW1lOiBcIk51bWUgYWZpyJlhdFwiLCBjcmVhdGVBY2NvdW50OiBcIkNyZWVhesSDIGNvbnRcIiwgY29udGludWVHb29nbGU6IFwiQ29udGludcSDIGN1IEdvb2dsZVwiLCB3ZWxjb21lOiBcIkJpbmUgYWkgcmV2ZW5pdCFcIiB9LFxuICAgIGJyYW5kOiB7IHRpdGxlOiBcIkJyYW5kdXJpXCIsIHN1YnRpdGxlOiBcIkJyYW5kdXJpIHZlcmlmaWNhdGUgyJlpIHZlcmRpY3R1bCBjb211bml0xIPIm2lpIMOubiBkaXJlY3QuXCIsIHZlcmlmaWVkOiBcIlZlcmlmaWNhdFwiLCB0cnVzdFNjb3JlOiBcIlNjb3IgZGUgw65uY3JlZGVyZVwiLCBzZWFyY2hQbGFjZWhvbGRlcjogXCJDYXV0xIMgYnJhbmR1cmkuLi5cIiB9LFxuICAgIGF3YXJkczogeyB0aXRsZTogXCJQcmVtaWlsZSBTT1RcIiwgdGFnbGluZTogXCJCYXJvbWV0cnVsIMOObmNyZWRlcmlpIMOubiBCcmFuZHVyaVwiLCBsZWFkZXJib2FyZDogXCJDbGFzYW1lbnRcIiB9XG4gIH0sXG4gIHN2OiB7IC8vIFN3ZWRpc2hcbiAgICBuYXY6IHsgZmVlZDogXCJGbMO2ZGVcIiwgYnJhbmRzOiBcIlZhcnVtw6Rya2VuXCIsIG1lc3NhZ2VzOiBcIk1lZGRlbGFuZGVuXCIsIGF3YXJkczogXCJVdG3DpHJrZWxzZXJcIiwgZGFzaGJvYXJkOiBcIsOWdmVyc2lrdFwiLCBhZG1pbjogXCJBZG1pblwiLCBwcm9maWxlOiBcIlByb2ZpbFwiLCBwb3N0OiBcIklubMOkZ2dcIiwgc2lnbkluOiBcIkxvZ2dhIGluXCIsIHNpZ25PdXQ6IFwiTG9nZ2EgdXRcIiB9LFxuICAgIHZvdGU6IHsgc3Rhc2g6IFwiQmVow6VsbFwiLCB0cmFzaDogXCJLYXN0YVwiLCBub1ZvdGVzOiBcIkluZ2EgcsO2c3RlciDDpG5cIiwgc2lnbkluUHJvbXB0OiBcIkxvZ2dhIGluIGbDtnIgYXR0IGF2Z2UgZGl0dCBvbWTDtm1lLlwiLCBzdGFzaENvdW50OiBcInt7Y291bnR9fSBiZWjDpWxsXCIsIHRyYXNoQ291bnQ6IFwie3tjb3VudH19IGthc3RhXCIgfSxcbiAgICBhdXRoOiB7IHNpZ25JbjogXCJMb2dnYSBpblwiLCBzaWduVXA6IFwiU2thcGEga29udG9cIiwgZW1haWw6IFwiRS1wb3N0XCIsIHBhc3N3b3JkOiBcIkzDtnNlbm9yZFwiLCBkaXNwbGF5TmFtZTogXCJWaXNuaW5nc25hbW5cIiwgY3JlYXRlQWNjb3VudDogXCJTa2FwYSBrb250b1wiLCBjb250aW51ZUdvb2dsZTogXCJGb3J0c8OkdHQgbWVkIEdvb2dsZVwiLCB3ZWxjb21lOiBcIlbDpGxrb21tZW4gdGlsbGJha2EhXCIgfSxcbiAgICBicmFuZDogeyB0aXRsZTogXCJWYXJ1bcOkcmtlblwiLCBzdWJ0aXRsZTogXCJWZXJpZmllcmFkZSB2YXJ1bcOkcmtlbiBvY2ggY29tbXVuaXR5bnMgZGlyZWt0YSBvbWTDtm1lbi5cIiwgdmVyaWZpZWQ6IFwiVmVyaWZpZXJhZFwiLCB0cnVzdFNjb3JlOiBcIkbDtnJ0cm9lbmRlcG/DpG5nXCIsIHNlYXJjaFBsYWNlaG9sZGVyOiBcIlPDtmsgdmFydW3DpHJrZW4uLi5cIiB9LFxuICAgIGF3YXJkczogeyB0aXRsZTogXCJTT1QgQXdhcmRzXCIsIHRhZ2xpbmU6IFwiVmFydW3DpHJrZW5zIEbDtnJ0cm9lbmRlYmFyb21ldGVyXCIsIGxlYWRlcmJvYXJkOiBcIlRvcHBsaXN0YVwiIH1cbiAgfSxcbiAgbm86IHsgLy8gTm9yd2VnaWFuXG4gICAgbmF2OiB7IGZlZWQ6IFwiU3Ryw7htXCIsIGJyYW5kczogXCJNZXJrZXZhcmVyXCIsIG1lc3NhZ2VzOiBcIk1lbGRpbmdlclwiLCBhd2FyZHM6IFwiUHJpc2VyXCIsIGRhc2hib2FyZDogXCJEYXNoYm9yZFwiLCBhZG1pbjogXCJBZG1pblwiLCBwcm9maWxlOiBcIlByb2ZpbFwiLCBwb3N0OiBcIlB1Ymxpc2VyXCIsIHNpZ25JbjogXCJMb2dnIGlublwiLCBzaWduT3V0OiBcIkxvZ2cgdXRcIiB9LFxuICAgIHZvdGU6IHsgc3Rhc2g6IFwiQmVob2xkXCIsIHRyYXNoOiBcIkthc3RcIiwgbm9Wb3RlczogXCJJbmdlbiBzdGVtbWVyIGVubsOlXCIsIHNpZ25JblByb21wdDogXCJMb2dnIGlubiBmb3Igw6Ugc3RlbW1lLlwiLCBzdGFzaENvdW50OiBcInt7Y291bnR9fSBiZWhvbGRcIiwgdHJhc2hDb3VudDogXCJ7e2NvdW50fX0ga2FzdFwiIH0sXG4gICAgYXV0aDogeyBzaWduSW46IFwiTG9nZyBpbm5cIiwgc2lnblVwOiBcIlJlZ2lzdHJlciBkZWdcIiwgZW1haWw6IFwiRS1wb3N0XCIsIHBhc3N3b3JkOiBcIlBhc3NvcmRcIiwgZGlzcGxheU5hbWU6IFwiVmlzbmluZ3NuYXZuXCIsIGNyZWF0ZUFjY291bnQ6IFwiT3BwcmV0dCBrb250b1wiLCBjb250aW51ZUdvb2dsZTogXCJGb3J0c2V0dCBtZWQgR29vZ2xlXCIsIHdlbGNvbWU6IFwiVmVsa29tbWVuIHRpbGJha2UhXCIgfSxcbiAgICBicmFuZDogeyB0aXRsZTogXCJNZXJrZXZhcmVyXCIsIHN1YnRpdGxlOiBcIlZlcmlmaXNlcnRlIG1lcmtldmFyZXIgb2cgZm9sa2V0cyBzYW5udGlkc2RvbS5cIiwgdmVyaWZpZWQ6IFwiVmVyaWZpc2VydFwiLCB0cnVzdFNjb3JlOiBcIlRpbGxpdHNzY29yZVwiLCBzZWFyY2hQbGFjZWhvbGRlcjogXCJTw7hrIGV0dGVyIG1lcmtldmFyZXIuLi5cIiB9LFxuICAgIGF3YXJkczogeyB0aXRsZTogXCJTT1QgQXdhcmRzXCIsIHRhZ2xpbmU6IFwiRm9sa2V0cyBEb20gb3ZlciBNZXJrZXZhcmVyXCIsIGxlYWRlcmJvYXJkOiBcIkxlZGVydGF2bGVcIiB9XG4gIH0sXG4gIGRhOiB7IC8vIERhbmlzaFxuICAgIG5hdjogeyBmZWVkOiBcIkZlZWRcIiwgYnJhbmRzOiBcIkJyYW5kc1wiLCBtZXNzYWdlczogXCJCZXNrZWRlclwiLCBhd2FyZHM6IFwiUHJpc2VyXCIsIGRhc2hib2FyZDogXCJLb250cm9scGFuZWxcIiwgYWRtaW46IFwiQWRtaW5cIiwgcHJvZmlsZTogXCJQcm9maWxcIiwgcG9zdDogXCJPcHJldCBvcHNsYWdcIiwgc2lnbkluOiBcIkxvZyBpbmRcIiwgc2lnbk91dDogXCJMb2cgdWRcIiB9LFxuICAgIHZvdGU6IHsgc3Rhc2g6IFwiR2VtXCIsIHRyYXNoOiBcIkthc3PDqXJcIiwgbm9Wb3RlczogXCJJbmdlbiBzdGVtbWVyIGVuZG51XCIsIHNpZ25JblByb21wdDogXCJMb2cgaW5kIGZvciBhdCBhZmdpdmUgZGluIGRvbS5cIiwgc3Rhc2hDb3VudDogXCJ7e2NvdW50fX0gZ2VtXCIsIHRyYXNoQ291bnQ6IFwie3tjb3VudH19IGthc3PDqXJcIiB9LFxuICAgIGF1dGg6IHsgc2lnbkluOiBcIkxvZyBpbmRcIiwgc2lnblVwOiBcIk9wcmV0IGtvbnRvXCIsIGVtYWlsOiBcIkUtbWFpbFwiLCBwYXNzd29yZDogXCJBZGdhbmdza29kZVwiLCBkaXNwbGF5TmFtZTogXCJWaXN0IG5hdm5cIiwgY3JlYXRlQWNjb3VudDogXCJPcHJldCBrb250b1wiLCBjb250aW51ZUdvb2dsZTogXCJGb3J0c8OmdCBtZWQgR29vZ2xlXCIsIHdlbGNvbWU6IFwiVmVsa29tbWVuIHRpbGJhZ2UhXCIgfSxcbiAgICBicmFuZDogeyB0aXRsZTogXCJCcmFuZHNcIiwgc3VidGl0bGU6IFwiVmVyaWZpY2VyZWRlIGJyYW5kcyBvZyBmw6ZsbGVzc2thYmV0cyBsaXZlLXZ1cmRlcmluZy5cIiwgdmVyaWZpZWQ6IFwiVmVyaWZpY2VyZXRcIiwgdHJ1c3RTY29yZTogXCJUaWxsaWRzc2NvcmVcIiwgc2VhcmNoUGxhY2Vob2xkZXI6IFwiU8O4ZyBlZnRlciBicmFuZHMuLi5cIiB9LFxuICAgIGF3YXJkczogeyB0aXRsZTogXCJTT1QgQXdhcmRzXCIsIHRhZ2xpbmU6IFwiQmFyb21ldHJldCBmb3IgQnJhbmQtdGlsbGlkXCIsIGxlYWRlcmJvYXJkOiBcIlJhbmdsaXN0ZVwiIH1cbiAgfSxcbiAgZmk6IHsgLy8gRmlubmlzaFxuICAgIG5hdjogeyBmZWVkOiBcIlN5w7Z0ZVwiLCBicmFuZHM6IFwiQnLDpG5kaXRcIiwgbWVzc2FnZXM6IFwiVmllc3RpdFwiLCBhd2FyZHM6IFwiUGFsa2lubm90XCIsIGRhc2hib2FyZDogXCJLb2plbGF1dGFcIiwgYWRtaW46IFwiWWxsw6RwaXRvXCIsIHByb2ZpbGU6IFwiUHJvZmlpbGlcIiwgcG9zdDogXCJKdWxrYWlzZVwiLCBzaWduSW46IFwiS2lyamF1ZHUgc2lzw6TDpG5cIiwgc2lnbk91dDogXCJLaXJqYXVkdSB1bG9zXCIgfSxcbiAgICB2b3RlOiB7IHN0YXNoOiBcIlPDpGlseXTDpFwiLCB0cmFzaDogXCJIeWxrw6TDpFwiLCBub1ZvdGVzOiBcIkVpIMOkw6RuacOkIHZpZWzDpFwiLCBzaWduSW5Qcm9tcHQ6IFwiS2lyamF1ZHUgc2lzw6TDpG4gYW50YWFrc2VzaSB0dW9taW9zaS5cIiwgc3Rhc2hDb3VudDogXCJ7e2NvdW50fX0gc8OkaWx5dMOkXCIsIHRyYXNoQ291bnQ6IFwie3tjb3VudH19IGh5bGvDpMOkXCIgfSxcbiAgICBhdXRoOiB7IHNpZ25JbjogXCJLaXJqYXVkdSBzaXPDpMOkblwiLCBzaWduVXA6IFwiUmVraXN0ZXLDtmlkeVwiLCBlbWFpbDogXCJTw6Roa8O2cG9zdGlcIiwgcGFzc3dvcmQ6IFwiU2FsYXNhbmFcIiwgZGlzcGxheU5hbWU6IFwiTmltaW1lcmtraVwiLCBjcmVhdGVBY2NvdW50OiBcIkx1byB0aWxpXCIsIGNvbnRpbnVlR29vZ2xlOiBcIkphdGthIEdvb2dsZWxsYVwiLCB3ZWxjb21lOiBcIlRlcnZldHVsb2EgdGFrYWlzaW4hXCIgfSxcbiAgICBicmFuZDogeyB0aXRsZTogXCJCcsOkbmRpdFwiLCBzdWJ0aXRsZTogXCJWYWh2aXN0ZXR1dCBicsOkbmRpdCBqYSB5aHRlaXPDtm4gc3VvcmEgdHVvbWlvLlwiLCB2ZXJpZmllZDogXCJWYWh2aXN0ZXR0dVwiLCB0cnVzdFNjb3JlOiBcIkx1b3R0YW11c2luZGVrc2lcIiwgc2VhcmNoUGxhY2Vob2xkZXI6IFwiRXRzaSBicsOkbmRlasOkLi4uXCIgfSxcbiAgICBhd2FyZHM6IHsgdGl0bGU6IFwiU09UIEF3YXJkc1wiLCB0YWdsaW5lOiBcIkJyw6RuZGllbiBMdW90dGFtdXNiYXJvbWV0cmlcIiwgbGVhZGVyYm9hcmQ6IFwiS8OkcmtpdGF1bHVra29cIiB9XG4gIH0sXG4gIGNzOiB7IC8vIEN6ZWNoXG4gICAgbmF2OiB7IGZlZWQ6IFwiUMWZw61zcMSbdmt5XCIsIGJyYW5kczogXCJabmHEjWt5XCIsIG1lc3NhZ2VzOiBcIlpwcsOhdnlcIiwgYXdhcmRzOiBcIk9jZW7Em27DrVwiLCBkYXNoYm9hcmQ6IFwiUMWZZWhsZWRcIiwgYWRtaW46IFwiU3Byw6F2YVwiLCBwcm9maWxlOiBcIlByb2ZpbFwiLCBwb3N0OiBcIlZsb8W+aXRcIiwgc2lnbkluOiBcIlDFmWlobMOhc2l0IHNlXCIsIHNpZ25PdXQ6IFwiT2RobMOhc2l0IHNlXCIgfSxcbiAgICB2b3RlOiB7IHN0YXNoOiBcIk5lY2hhdFwiLCB0cmFzaDogXCJaYWhvZGl0XCIsIG5vVm90ZXM6IFwiWmF0w61tIMW+w6FkbsOpIGhsYXN5XCIsIHNpZ25JblByb21wdDogXCJQxZlpaGxhc3RlIHNlIGEgdnlqw6FkxZlldGUgc3bFr2ogdmVyZGlrdC5cIiwgc3Rhc2hDb3VudDogXCJ7e2NvdW50fX0gbmVjaGF0XCIsIHRyYXNoQ291bnQ6IFwie3tjb3VudH19IHphaG9kaXRcIiB9LFxuICAgIGF1dGg6IHsgc2lnbkluOiBcIlDFmWlobMOhc2l0IHNlXCIsIHNpZ25VcDogXCJSZWdpc3Ryb3ZhdFwiLCBlbWFpbDogXCJFLW1haWxcIiwgcGFzc3dvcmQ6IFwiSGVzbG9cIiwgZGlzcGxheU5hbWU6IFwiWm9icmF6b3ZhbsOpIGptw6lub1wiLCBjcmVhdGVBY2NvdW50OiBcIlZ5dHZvxZlpdCDDusSNZXRcIiwgY29udGludWVHb29nbGU6IFwiUG9rcmHEjW92YXQgcMWZZXMgR29vZ2xlXCIsIHdlbGNvbWU6IFwiVsOtdGVqdGUgenDEm3QhXCIgfSxcbiAgICBicmFuZDogeyB0aXRsZTogXCJabmHEjWt5XCIsIHN1YnRpdGxlOiBcIk92xJvFmWVuw6kgem5hxI1reSBhIMW+aXbDvSB2ZXJkaWt0IGtvbXVuaXR5LlwiLCB2ZXJpZmllZDogXCJPdsSbxZllbm9cIiwgdHJ1c3RTY29yZTogXCJTa8OzcmUgZMWvdsSbcnlcIiwgc2VhcmNoUGxhY2Vob2xkZXI6IFwiSGxlZGF0IHpuYcSNa3kuLi5cIiB9LFxuICAgIGF3YXJkczogeyB0aXRsZTogXCJDZW55IFNPVFwiLCB0YWdsaW5lOiBcIkJhcm9tZXRyIGTFr3bEm3J5IHZlIHpuYcSNa3lcIiwgbGVhZGVyYm9hcmQ6IFwixb1lYsWZw63EjWVrXCIgfVxuICB9LFxuICBzazogeyAvLyBTbG92YWtcbiAgICBuYXY6IHsgZmVlZDogXCJQcsOtc3Bldmt5XCIsIGJyYW5kczogXCJabmHEjWt5XCIsIG1lc3NhZ2VzOiBcIlNwcsOhdnlcIiwgYXdhcmRzOiBcIk9jZW5lbmlhXCIsIGRhc2hib2FyZDogXCJQcmVoxL5hZFwiLCBhZG1pbjogXCJTcHLDoXZjYVwiLCBwcm9maWxlOiBcIlByb2ZpbFwiLCBwb3N0OiBcIlByaWRhxaVcIiwgc2lnbkluOiBcIlByaWhsw6FzacWlIHNhXCIsIHNpZ25PdXQ6IFwiT2RobMOhc2nFpSBzYVwiIH0sXG4gICAgdm90ZTogeyBzdGFzaDogXCJOZWNoYcWlXCIsIHRyYXNoOiBcIlphaG9kacWlXCIsIG5vVm90ZXM6IFwiWmF0aWHEviDFvmlhZG5lIGhsYXN5XCIsIHNpZ25JblByb21wdDogXCJQcmlobMOhc3RlIHNhIGEgdnlqYWRyaXRlIHN2b2ogdmVyZGlrdC5cIiwgc3Rhc2hDb3VudDogXCJ7e2NvdW50fX0gbmVjaGHFpVwiLCB0cmFzaENvdW50OiBcInt7Y291bnR9fSB6YWhvZGnFpVwiIH0sXG4gICAgYXV0aDogeyBzaWduSW46IFwiUHJpaGzDoXNpxaUgc2FcIiwgc2lnblVwOiBcIlJlZ2lzdHJvdmHFpSBzYVwiLCBlbWFpbDogXCJFLW1haWxcIiwgcGFzc3dvcmQ6IFwiSGVzbG9cIiwgZGlzcGxheU5hbWU6IFwiWm9icmF6b3ZhbsOpIG1lbm9cIiwgY3JlYXRlQWNjb3VudDogXCJWeXR2b3JpxaUgw7rEjWV0XCIsIGNvbnRpbnVlR29vZ2xlOiBcIlBva3JhxI1vdmHFpSBjZXogR29vZ2xlXCIsIHdlbGNvbWU6IFwiVml0YWp0ZSBzcMOkxaUhXCIgfSxcbiAgICBicmFuZDogeyB0aXRsZTogXCJabmHEjWt5XCIsIHN1YnRpdGxlOiBcIk92ZXJlbsOpIHpuYcSNa3kgYSDFvml2w70gdmVyZGlrdCBrb211bml0eS5cIiwgdmVyaWZpZWQ6IFwiT3ZlcmVuw6lcIiwgdHJ1c3RTY29yZTogXCJTa8OzcmUgZMO0dmVyeVwiLCBzZWFyY2hQbGFjZWhvbGRlcjogXCJIxL5hZGHFpSB6bmHEjWt5Li4uXCIgfSxcbiAgICBhd2FyZHM6IHsgdGl0bGU6IFwiQ2VueSBTT1RcIiwgdGFnbGluZTogXCJCYXJvbWV0ZXIgZMO0dmVyeSB2IHpuYcSNa3lcIiwgbGVhZGVyYm9hcmQ6IFwiUmVicsOtxI1la1wiIH1cbiAgfSxcbiAgaHU6IHsgLy8gSHVuZ2FyaWFuXG4gICAgbmF2OiB7IGZlZWQ6IFwiSMOtcmNzYXRvcm5hXCIsIGJyYW5kczogXCJNw6Fya8Oha1wiLCBtZXNzYWdlczogXCLDnHplbmV0ZWtcIiwgYXdhcmRzOiBcIkTDrWpha1wiLCBkYXNoYm9hcmQ6IFwiSXLDoW55w610w7NwdWx0XCIsIGFkbWluOiBcIkFkbWluXCIsIHByb2ZpbGU6IFwiUHJvZmlsXCIsIHBvc3Q6IFwiS8O2enrDqXTDqXRlbFwiLCBzaWduSW46IFwiQmVqZWxlbnRrZXrDqXNcIiwgc2lnbk91dDogXCJLaWplbGVudGtlesOpc1wiIH0sXG4gICAgdm90ZTogeyBzdGFzaDogXCJNZWd0YXJ0w6FzXCIsIHRyYXNoOiBcIkt1a2FcIiwgbm9Wb3RlczogXCJNw6lnIG5pbmNzIHN6YXZhemF0XCIsIHNpZ25JblByb21wdDogXCJKZWxlbnRrZXp6IGJlIGEgdsOpbGVtw6lueWVkIGxlYWTDoXPDoWhvei5cIiwgc3Rhc2hDb3VudDogXCJ7e2NvdW50fX0gbWVndGFydMOhc1wiLCB0cmFzaENvdW50OiBcInt7Y291bnR9fSBrdWthXCIgfSxcbiAgICBhdXRoOiB7IHNpZ25JbjogXCJCZWplbGVudGtlesOpc1wiLCBzaWduVXA6IFwiUmVnaXN6dHLDoWNpw7NcIiwgZW1haWw6IFwiRS1tYWlsXCIsIHBhc3N3b3JkOiBcIkplbHN6w7NcIiwgZGlzcGxheU5hbWU6IFwiTWVnamVsZW7DrXRldHQgbsOpdlwiLCBjcmVhdGVBY2NvdW50OiBcIkZpw7NrIGzDqXRyZWhvesOhc2FcIiwgY29udGludWVHb29nbGU6IFwiRm9seXRhdMOhcyBHb29nbGUtbGFsXCIsIHdlbGNvbWU6IFwiw5xkdiDDumpyYSBpdHQhXCIgfSxcbiAgICBicmFuZDogeyB0aXRsZTogXCJNw6Fya8Oha1wiLCBzdWJ0aXRsZTogXCJIaXRlbGVzw610ZXR0IG3DoXJrw6FrIMOpcyBhIGvDtnrDtnNzw6lnIMOpbMWRIMOtdMOpbGV0ZS5cIiwgdmVyaWZpZWQ6IFwiSGl0ZWxlc8OtdGV0dFwiLCB0cnVzdFNjb3JlOiBcIkJpemFsbWkgcG9udHN6w6FtXCIsIHNlYXJjaFBsYWNlaG9sZGVyOiBcIk3DoXJrw6FrIGtlcmVzw6lzZS4uLlwiIH0sXG4gICAgYXdhcmRzOiB7IHRpdGxlOiBcIlNPVCBEw61qYWtcIiwgdGFnbGluZTogXCJBIE3DoXJrYWJpemFsb20gQmFyb23DqXRlcmVcIiwgbGVhZGVyYm9hcmQ6IFwiUmFuZ3NvclwiIH1cbiAgfSxcbiAgZWw6IHsgLy8gR3JlZWtcbiAgICBuYXY6IHsgZmVlZDogXCLOoc6/zq5cIiwgYnJhbmRzOiBcIs6czqzPgc66zrXPglwiLCBtZXNzYWdlczogXCLOnM63zr3Pjc68zrHPhM6xXCIsIGF3YXJkczogXCLOks+BzrHOss61zq/OsVwiLCBkYXNoYm9hcmQ6IFwizqDOr869zrHOus6xz4IgzpXOu86tzrPPh86/z4VcIiwgYWRtaW46IFwizpTOuc6xz4fOtc6vz4HOuc+DzrdcIiwgcHJvZmlsZTogXCLOoM+Bzr/Phs6vzrtcIiwgcG9zdDogXCLOlM63zrzOv8+Dzq/Otc+Fz4POt1wiLCBzaWduSW46IFwizqPPjc69zrTOtc+DzrdcIiwgc2lnbk91dDogXCLOkc+Azr/Pg8+Nzr3OtM61z4POt1wiIH0sXG4gICAgdm90ZTogeyBzdGFzaDogXCLOms+BzqzPhM6xXCIsIHRyYXNoOiBcIs6gzq3PhM6xXCIsIG5vVm90ZXM6IFwizpTOtc69IM+Fz4DOrM+Bz4fOv8+Fzr0gz4jOrs+Gzr/OuSDOsc66z4zOvM63XCIsIHNpZ25JblByb21wdDogXCLOo8+Fzr3OtM61zrjOtc6vz4TOtSDOs865zrEgzr3OsSDPiM63z4bOr8+DzrXPhM61LlwiLCBzdGFzaENvdW50OiBcInt7Y291bnR9fSDOus+BzqzPhM6xXCIsIHRyYXNoQ291bnQ6IFwie3tjb3VudH19IM+Azq3PhM6xXCIgfSxcbiAgICBhdXRoOiB7IHNpZ25JbjogXCLOo8+Nzr3OtM61z4POt1wiLCBzaWduVXA6IFwizpXOs86zz4HOsc+Gzq5cIiwgZW1haWw6IFwiRW1haWxcIiwgcGFzc3dvcmQ6IFwizprPic60zrnOus+Mz4JcIiwgZGlzcGxheU5hbWU6IFwizozOvc6/zrzOsSDOtc68z4bOrM69zrnPg863z4JcIiwgY3JlYXRlQWNjb3VudDogXCLOlM63zrzOuc6/z4XPgc6zzq/OsSDOu86/zrPOsc+BzrnOsc+DzrzOv8+NXCIsIGNvbnRpbnVlR29vZ2xlOiBcIs6jz4XOvc6tz4fOtc65zrEgzrzOtSBHb29nbGVcIiwgd2VsY29tZTogXCLOms6xzrvPjs+CIM6uz4HOuM6xz4TOtSDPgM6vz4PPiSFcIiB9LFxuICAgIGJyYW5kOiB7IHRpdGxlOiBcIs6czqzPgc66zrXPglwiLCBzdWJ0aXRsZTogXCLOlc+AzrHOu863zrjOtc+FzrzOrc69zrXPgiDOvM6sz4HOus61z4IgzrrOsc65IM62z4nOvc+EzrHOvc6uIM61z4TPhc68zrfOs86/z4HOr86xIM+EzrfPgiDOus6/zrnOvc+Mz4TOt8+EzrHPgi5cIiwgdmVyaWZpZWQ6IFwizpXPgM6xzrvOt864zrXPhc68zq3Ovc6/XCIsIHRydXN0U2NvcmU6IFwizpTOtc6vzrrPhM63z4IgzrXOvM+AzrnPg8+Ezr/Pg8+Nzr3Ot8+CXCIsIHNlYXJjaFBsYWNlaG9sZGVyOiBcIs6Rzr3Osc62zq7PhM63z4POtyDOvM6xz4HOus+Ozr0uLi5cIiB9LFxuICAgIGF3YXJkczogeyB0aXRsZTogXCLOks+BzrHOss61zq/OsSBTT1RcIiwgdGFnbGluZTogXCLOpM6/IM6SzrHPgc+MzrzOtc+Ez4HOvyDOlc68z4DOuc+Dz4TOv8+Dz43Ovc63z4Igz4PPhM65z4IgzpzOrM+BzrrOtc+CXCIsIGxlYWRlcmJvYXJkOiBcIs6gzq/Ovc6xzrrOsc+CIM6azrHPhM6sz4TOsc6+zrfPglwiIH1cbiAgfSxcbiAgdWs6IHsgLy8gVWtyYWluaWFuXG4gICAgbmF2OiB7IGZlZWQ6IFwi0KHRgtGA0ZbRh9C60LBcIiwgYnJhbmRzOiBcItCR0YDQtdC90LTQuFwiLCBtZXNzYWdlczogXCLQn9C+0LLRltC00L7QvNC70LXQvdC90Y9cIiwgYXdhcmRzOiBcItCd0LDQs9C+0YDQvtC00LhcIiwgZGFzaGJvYXJkOiBcItCf0LDQvdC10LvRjFwiLCBhZG1pbjogXCLQkNC00LzRltC9XCIsIHByb2ZpbGU6IFwi0J/RgNC+0YTRltC70YxcIiwgcG9zdDogXCLQntC/0YPQsdC70ZbQutGD0LLQsNGC0LhcIiwgc2lnbkluOiBcItCj0LLRltC50YLQuFwiLCBzaWduT3V0OiBcItCS0LjQudGC0LhcIiB9LFxuICAgIHZvdGU6IHsgc3Rhc2g6IFwi0JfQsNC70LjRiNC40YLQuFwiLCB0cmFzaDogXCLQktC40LrQuNC90YPRgtC4XCIsIG5vVm90ZXM6IFwi0KnQtSDQvdC10LzQsNGUINCz0L7Qu9C+0YHRltCyXCIsIHNpZ25JblByb21wdDogXCLQo9Cy0ZbQudC00ZbRgtGMLCDRidC+0LEg0LLQuNC90LXRgdGC0Lgg0YHQstGW0Lkg0LLQtdGA0LTQuNC60YIuXCIsIHN0YXNoQ291bnQ6IFwie3tjb3VudH19INC30LDQu9C40YjQuNGC0LhcIiwgdHJhc2hDb3VudDogXCJ7e2NvdW50fX0g0LLQuNC60LjQvdGD0YLQuFwiIH0sXG4gICAgYXV0aDogeyBzaWduSW46IFwi0KPQstGW0LnRgtC4XCIsIHNpZ25VcDogXCLQl9Cw0YDQtdGU0YHRgtGA0YPQstCw0YLQuNGB0Y9cIiwgZW1haWw6IFwi0JXQuy4g0L/QvtGI0YLQsFwiLCBwYXNzd29yZDogXCLQn9Cw0YDQvtC70YxcIiwgZGlzcGxheU5hbWU6IFwi0IbQvCfRj1wiLCBjcmVhdGVBY2NvdW50OiBcItCh0YLQstC+0YDQuNGC0Lgg0L7QsdC70ZbQutC+0LLQuNC5INC30LDQv9C40YFcIiwgY29udGludWVHb29nbGU6IFwi0J/RgNC+0LTQvtCy0LbQuNGC0Lgg0YfQtdGA0LXQtyBHb29nbGVcIiwgd2VsY29tZTogXCLQlyDQv9C+0LLQtdGA0L3QtdC90L3Rj9C8IVwiIH0sXG4gICAgYnJhbmQ6IHsgdGl0bGU6IFwi0JHRgNC10L3QtNC4XCIsIHN1YnRpdGxlOiBcItCf0LXRgNC10LLRltGA0LXQvdGWINCx0YDQtdC90LTQuCDRgtCwINC20LjQstC40Lkg0LLQtdGA0LTQuNC60YIg0YHQv9GW0LvRjNC90L7RgtC4LlwiLCB2ZXJpZmllZDogXCLQn9C10YDQtdCy0ZbRgNC10L3QvlwiLCB0cnVzdFNjb3JlOiBcItCg0LXQudGC0LjQvdCzINC00L7QstGW0YDQuFwiLCBzZWFyY2hQbGFjZWhvbGRlcjogXCLQn9C+0YjRg9C6INCx0YDQtdC90LTRltCyLi4uXCIgfSxcbiAgICBhd2FyZHM6IHsgdGl0bGU6IFwi0J/RgNC10LzRltGXIFNPVFwiLCB0YWdsaW5lOiBcItCR0LDRgNC+0LzQtdGC0YAg0JTQvtCy0ZbRgNC4INC00L4g0JHRgNC10L3QtNGW0LJcIiwgbGVhZGVyYm9hcmQ6IFwi0KLQsNCx0LvQuNGG0Y8g0LvRltC00LXRgNGW0LJcIiB9XG4gIH0sXG4gIGJnOiB7IC8vIEJ1bGdhcmlhblxuICAgIG5hdjogeyBmZWVkOiBcItCf0L7RgtC+0LpcIiwgYnJhbmRzOiBcItCR0YDQsNC90LTQvtCy0LVcIiwgbWVzc2FnZXM6IFwi0KHRitC+0LHRidC10L3QuNGPXCIsIGF3YXJkczogXCLQndCw0LPRgNCw0LTQuFwiLCBkYXNoYm9hcmQ6IFwi0KLQsNCx0LvQvlwiLCBhZG1pbjogXCLQkNC00LzQuNC90LjRgdGC0YDQsNGC0L7RgFwiLCBwcm9maWxlOiBcItCf0YDQvtGE0LjQu1wiLCBwb3N0OiBcItCf0YPQsdC70LjQutGD0LLQsNC5XCIsIHNpZ25JbjogXCLQktGF0L7QtFwiLCBzaWduT3V0OiBcItCY0LfRhdC+0LRcIiB9LFxuICAgIHZvdGU6IHsgc3Rhc2g6IFwi0JfQsNC/0LDQt9C4XCIsIHRyYXNoOiBcItCY0LfRhdCy0YrRgNC70LhcIiwgbm9Wb3RlczogXCLQktGB0LUg0L7RidC1INC90Y/QvNCwINCz0LvQsNGB0L7QstC1XCIsIHNpZ25JblByb21wdDogXCLQktC70LXQt9GC0LUsINC30LAg0LTQsCDQtNCw0LTQtdGC0LUg0YHQstC+0Y/RgtCwINC/0YDQuNGB0YrQtNCwLlwiLCBzdGFzaENvdW50OiBcInt7Y291bnR9fSDQt9Cw0L/QsNC30LhcIiwgdHJhc2hDb3VudDogXCJ7e2NvdW50fX0g0LjQt9GF0LLRitGA0LvQuFwiIH0sXG4gICAgYXV0aDogeyBzaWduSW46IFwi0JLRhdC+0LRcIiwgc2lnblVwOiBcItCg0LXQs9C40YHRgtGA0LDRhtC40Y9cIiwgZW1haWw6IFwi0JjQvNC10LnQu1wiLCBwYXNzd29yZDogXCLQn9Cw0YDQvtC70LBcIiwgZGlzcGxheU5hbWU6IFwi0JjQvNC1XCIsIGNyZWF0ZUFjY291bnQ6IFwi0KHRitC30LTQsNCy0LDQvdC1INC90LAg0L/RgNC+0YTQuNC7XCIsIGNvbnRpbnVlR29vZ2xlOiBcItCf0YDQvtC00YrQu9C20Lgg0YEgR29vZ2xlXCIsIHdlbGNvbWU6IFwi0JTQvtCx0YDQtSDQtNC+0YjQu9C4INC+0YLQvdC+0LLQviFcIiB9LFxuICAgIGJyYW5kOiB7IHRpdGxlOiBcItCR0YDQsNC90LTQvtCy0LVcIiwgc3VidGl0bGU6IFwi0J/RgNC+0LLQtdGA0LXQvdC4INCx0YDQsNC90LTQvtCy0LUg0Lgg0L/RgNC40YHRitC00LDRgtCwINC90LAg0L7QsdGJ0L3QvtGB0YLRgtCwINCyINGA0LXQsNC70L3QviDQstGA0LXQvNC1LlwiLCB2ZXJpZmllZDogXCLQn9GA0L7QstC10YDQtdC9XCIsIHRydXN0U2NvcmU6IFwi0J7RhtC10L3QutCwINC90LAg0LTQvtCy0LXRgNC40LVcIiwgc2VhcmNoUGxhY2Vob2xkZXI6IFwi0KLRitGA0YHQtdC90LUg0L3QsCDQsdGA0LDQvdC00L7QstC1Li4uXCIgfSxcbiAgICBhd2FyZHM6IHsgdGl0bGU6IFwi0J3QsNCz0YDQsNC00LggU09UXCIsIHRhZ2xpbmU6IFwi0JHQsNGA0L7QvNC10YLRitGAINC90LAg0JTQvtCy0LXRgNC40LXRgtC+INCyINCR0YDQsNC90LTQvtCy0LXRgtC1XCIsIGxlYWRlcmJvYXJkOiBcItCa0LvQsNGB0LDRhtC40Y9cIiB9XG4gIH1cbn07XG4iXX0=