import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BrandSearch.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];"use client";
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { useNavigate } from "/node_modules/@tanstack/react-router/dist/esm/index.dev.js?v=a8030269";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=a8030269";
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=a8030269";
import { Check, Plus, Search } from "/node_modules/.vite/deps/lucide-react.js?v=a8030269";
import { searchBrands } from "/src/lib/brands.ts";
import { Button } from "/src/components/ui/button.tsx";
import { Command, CommandGroup, CommandInput, CommandItem, CommandList } from "/src/components/ui/command.tsx";
import { Popover, PopoverContent, PopoverTrigger } from "/src/components/ui/popover.tsx";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "/app/applet/src/components/BrandSearch.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
var _s = $RefreshSig$();
export function BrandSearch({ onSelectBrand, selectedId, placeholder, className }) {
	_s();
	const { t } = useTranslation();
	const navigate = useNavigate();
	const [open, setOpen] = useState(false);
	const [query, setQuery] = useState("");
	const { data: results } = useQuery({
		queryKey: ["brand-search", query],
		queryFn: () => searchBrands(query),
		enabled: open && query.trim().length > 0
	});
	useEffect(() => {
		if (selectedId) setOpen(false);
	}, [selectedId]);
	const q = query.trim();
	const handleSelect = (brand) => {
		setOpen(false);
		setQuery("");
		if (onSelectBrand) onSelectBrand(brand);
		else navigate({
			to: "/brands/$slug",
			params: { slug: brand.slug }
		});
	};
	const addNew = () => {
		setOpen(false);
		setQuery("");
		navigate({
			to: "/brands/new",
			search: { name: q }
		});
	};
	const exactMatch = (results ?? []).some((b) => b.name.toLowerCase() === q.toLowerCase());
	return /* @__PURE__ */ _jsxDEV(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ _jsxDEV(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ _jsxDEV(Button, {
				variant: "outline",
				role: "combobox",
				"aria-expanded": open,
				className: cn("w-full justify-start", className),
				children: [/* @__PURE__ */ _jsxDEV(Search, { className: "h-4 w-4 shrink-0 opacity-60" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "truncate text-muted-foreground",
					children: placeholder ?? t("brand.searchPlaceholder")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 65,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(PopoverContent, {
			align: "start",
			className: "w-80 max-w-[90vw] p-0",
			children: /* @__PURE__ */ _jsxDEV(Command, {
				shouldFilter: false,
				children: [/* @__PURE__ */ _jsxDEV(CommandInput, {
					value: query,
					onValueChange: setQuery,
					placeholder: placeholder ?? t("brand.searchPlaceholder")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(CommandList, { children: [
					results && results.length === 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: "px-3 py-6 text-center text-sm text-muted-foreground",
						children: t("brand.searchNoResults")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 87,
						columnNumber: 15
					}, this),
					results && results.length > 0 && /* @__PURE__ */ _jsxDEV(CommandGroup, {
						heading: t("brand.searchResults"),
						children: results.map((b) => /* @__PURE__ */ _jsxDEV(CommandItem, {
							value: b.id,
							onSelect: () => handleSelect(b),
							children: [
								/* @__PURE__ */ _jsxDEV(Check, { className: cn("mr-2 h-4 w-4", selectedId === b.id ? "opacity-100" : "opacity-0") }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 95,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "truncate",
									children: b.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 101,
									columnNumber: 21
								}, this),
								b.country && /* @__PURE__ */ _jsxDEV("span", {
									className: "ml-auto shrink-0 pl-2 text-xs text-muted-foreground",
									children: b.country
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 103,
									columnNumber: 23
								}, this)
							]
						}, b.id, true, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 19
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 15
					}, this),
					q.length > 0 && !exactMatch && /* @__PURE__ */ _jsxDEV(CommandGroup, { children: /* @__PURE__ */ _jsxDEV(CommandItem, {
						value: "__add_new_brand__",
						onSelect: addNew,
						children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "mr-2 h-4 w-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 19
						}, this), t("brand.addNew", { name: q })]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 17
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 15
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 78,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 64,
		columnNumber: 5
	}, this);
}
_s(BrandSearch, "yZ6EqpHss9/p/4rOHmYfDKbwb70=", false, function() {
	return [
		useTranslation,
		useNavigate,
		useQuery
	];
});
_c = BrandSearch;
var _c;
$RefreshReg$(_c, "BrandSearch");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/BrandSearch.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/BrandSearch.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/BrandSearch.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/BrandSearch.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUE7QUFFQSxTQUFTLFdBQVcsZ0JBQWdCO0FBQ3BDLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsT0FBTyxNQUFNLGNBQWM7QUFDcEMsU0FBUyxvQkFBZ0M7QUFDekMsU0FBUyxjQUFjO0FBQ3ZCLFNBQ0UsU0FDQSxjQUNBLGNBQ0EsYUFDQSxtQkFDSztBQUNQLFNBQVMsU0FBUyxnQkFBZ0Isc0JBQXNCO0FBQ3hELFNBQVMsVUFBVTs7OztBQUVuQixPQUFPLFNBQVMsWUFBWSxFQUMxQixlQUNBLFlBQ0EsYUFDQSxhQU1DOztDQUNELE1BQU0sRUFBRSxNQUFNLGVBQWU7Q0FDN0IsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEtBQUs7Q0FDdEMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FFckMsTUFBTSxFQUFFLE1BQU0sWUFBWSxTQUFTO0VBQ2pDLFVBQVUsQ0FBQyxnQkFBZ0IsS0FBSztFQUNoQyxlQUFlLGFBQWEsS0FBSztFQUNqQyxTQUFTLFFBQVEsTUFBTSxLQUFLLENBQUMsQ0FBQyxTQUFTO0NBQ3pDLENBQUM7Q0FFRCxnQkFBZ0I7RUFDZCxJQUFJLFlBQVksUUFBUSxLQUFLO0NBQy9CLEdBQUcsQ0FBQyxVQUFVLENBQUM7Q0FFZixNQUFNLElBQUksTUFBTSxLQUFLO0NBRXJCLE1BQU0sZ0JBQWdCLFVBQWlCO0VBQ3JDLFFBQVEsS0FBSztFQUNiLFNBQVMsRUFBRTtFQUNYLElBQUksZUFBZSxjQUFjLEtBQUs7T0FDakMsU0FBUztHQUFFLElBQUk7R0FBaUIsUUFBUSxFQUFFLE1BQU0sTUFBTSxLQUFLO0VBQUUsQ0FBQztDQUNyRTtDQUVBLE1BQU0sZUFBZTtFQUNuQixRQUFRLEtBQUs7RUFDYixTQUFTLEVBQUU7RUFDWCxTQUFTO0dBQUUsSUFBSTtHQUFlLFFBQVEsRUFBRSxNQUFNLEVBQUU7RUFBRSxDQUFDO0NBQ3JEO0NBRUEsTUFBTSxjQUFjLFdBQVcsQ0FBQyxFQUFDLENBQUUsTUFBTSxNQUFNLEVBQUUsS0FBSyxZQUFZLE1BQU0sRUFBRSxZQUFZLENBQUM7Q0FFdkYsT0FDRSx3QkFBQyxTQUFEO0VBQWU7RUFBTSxjQUFjO1lBQW5DLENBQ0Usd0JBQUMsZ0JBQUQ7R0FBZ0I7YUFDZCx3QkFBQyxRQUFEO0lBQ0UsU0FBUTtJQUNSLE1BQUs7SUFDTCxpQkFBZTtJQUNmLFdBQVcsR0FBRyx3QkFBd0IsU0FBUztjQUpqRCxDQU1FLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDhCQUErQjs7OztjQUNqRCx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUNiLGVBQWUsRUFBRSx5QkFBeUI7SUFDdkM7Ozs7WUFDQTs7Ozs7O0VBQ007Ozs7WUFDaEIsd0JBQUMsZ0JBQUQ7R0FBZ0IsT0FBTTtHQUFRLFdBQVU7YUFDdEMsd0JBQUMsU0FBRDtJQUFTLGNBQWM7Y0FBdkIsQ0FDRSx3QkFBQyxjQUFEO0tBQ0UsT0FBTztLQUNQLGVBQWU7S0FDZixhQUFhLGVBQWUsRUFBRSx5QkFBeUI7SUFDeEQ7Ozs7Y0FDRCx3QkFBQyxhQUFEO0tBQ0csV0FBVyxRQUFRLFdBQVcsS0FDN0Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1osRUFBRSx1QkFBdUI7S0FDdkI7Ozs7O0tBRU4sV0FBVyxRQUFRLFNBQVMsS0FDM0Isd0JBQUMsY0FBRDtNQUFjLFNBQVMsRUFBRSxxQkFBcUI7Z0JBQzNDLFFBQVEsS0FBSyxNQUNaLHdCQUFDLGFBQUQ7T0FBd0IsT0FBTyxFQUFFO09BQUksZ0JBQWdCLGFBQWEsQ0FBQztpQkFBbkU7UUFDRSx3QkFBQyxPQUFELEVBQ0UsV0FBVyxHQUNULGdCQUNBLGVBQWUsRUFBRSxLQUFLLGdCQUFnQixXQUN4QyxFQUNEOzs7OztRQUNELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFZLEVBQUU7UUFBVzs7Ozs7UUFDeEMsRUFBRSxXQUNELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLEVBQUU7UUFDQzs7Ozs7T0FFRztTQWJLLEVBQUU7Ozs7YUFhUCxDQUNkO0tBQ1c7Ozs7O0tBRWYsRUFBRSxTQUFTLEtBQUssQ0FBQyxjQUNoQix3QkFBQyxjQUFELFlBQ0Usd0JBQUMsYUFBRDtNQUFhLE9BQU07TUFBb0IsVUFBVTtnQkFBakQsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxlQUFnQjs7OztnQkFDL0IsRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUNuQjs7Ozs7Y0FDRDs7Ozs7SUFFTDs7OztZQUNOOzs7Ozs7RUFDSzs7OztVQUNUOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJCcmFuZFNlYXJjaC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiXCJ1c2UgY2xpZW50XCI7XG5cbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1yb3V0ZXJcIjtcbmltcG9ydCB7IHVzZVRyYW5zbGF0aW9uIH0gZnJvbSBcInJlYWN0LWkxOG5leHRcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5IH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xuaW1wb3J0IHsgQ2hlY2ssIFBsdXMsIFNlYXJjaCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHNlYXJjaEJyYW5kcywgdHlwZSBCcmFuZCB9IGZyb20gXCJAL2xpYi9icmFuZHNcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQge1xuICBDb21tYW5kLFxuICBDb21tYW5kR3JvdXAsXG4gIENvbW1hbmRJbnB1dCxcbiAgQ29tbWFuZEl0ZW0sXG4gIENvbW1hbmRMaXN0LFxufSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2NvbW1hbmRcIjtcbmltcG9ydCB7IFBvcG92ZXIsIFBvcG92ZXJDb250ZW50LCBQb3BvdmVyVHJpZ2dlciB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvcG9wb3ZlclwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIEJyYW5kU2VhcmNoKHtcbiAgb25TZWxlY3RCcmFuZCxcbiAgc2VsZWN0ZWRJZCxcbiAgcGxhY2Vob2xkZXIsXG4gIGNsYXNzTmFtZSxcbn06IHtcbiAgb25TZWxlY3RCcmFuZD86IChicmFuZDogQnJhbmQpID0+IHZvaWQ7XG4gIHNlbGVjdGVkSWQ/OiBzdHJpbmc7XG4gIHBsYWNlaG9sZGVyPzogc3RyaW5nO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59KSB7XG4gIGNvbnN0IHsgdCB9ID0gdXNlVHJhbnNsYXRpb24oKTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtxdWVyeSwgc2V0UXVlcnldID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgY29uc3QgeyBkYXRhOiByZXN1bHRzIH0gPSB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IFtcImJyYW5kLXNlYXJjaFwiLCBxdWVyeV0sXG4gICAgcXVlcnlGbjogKCkgPT4gc2VhcmNoQnJhbmRzKHF1ZXJ5KSxcbiAgICBlbmFibGVkOiBvcGVuICYmIHF1ZXJ5LnRyaW0oKS5sZW5ndGggPiAwLFxuICB9KTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChzZWxlY3RlZElkKSBzZXRPcGVuKGZhbHNlKTtcbiAgfSwgW3NlbGVjdGVkSWRdKTtcblxuICBjb25zdCBxID0gcXVlcnkudHJpbSgpO1xuXG4gIGNvbnN0IGhhbmRsZVNlbGVjdCA9IChicmFuZDogQnJhbmQpID0+IHtcbiAgICBzZXRPcGVuKGZhbHNlKTtcbiAgICBzZXRRdWVyeShcIlwiKTtcbiAgICBpZiAob25TZWxlY3RCcmFuZCkgb25TZWxlY3RCcmFuZChicmFuZCk7XG4gICAgZWxzZSBuYXZpZ2F0ZSh7IHRvOiBcIi9icmFuZHMvJHNsdWdcIiwgcGFyYW1zOiB7IHNsdWc6IGJyYW5kLnNsdWcgfSB9KTtcbiAgfTtcblxuICBjb25zdCBhZGROZXcgPSAoKSA9PiB7XG4gICAgc2V0T3BlbihmYWxzZSk7XG4gICAgc2V0UXVlcnkoXCJcIik7XG4gICAgbmF2aWdhdGUoeyB0bzogXCIvYnJhbmRzL25ld1wiLCBzZWFyY2g6IHsgbmFtZTogcSB9IH0pO1xuICB9O1xuXG4gIGNvbnN0IGV4YWN0TWF0Y2ggPSAocmVzdWx0cyA/PyBbXSkuc29tZSgoYikgPT4gYi5uYW1lLnRvTG93ZXJDYXNlKCkgPT09IHEudG9Mb3dlckNhc2UoKSk7XG5cbiAgcmV0dXJuIChcbiAgICA8UG9wb3ZlciBvcGVuPXtvcGVufSBvbk9wZW5DaGFuZ2U9e3NldE9wZW59PlxuICAgICAgPFBvcG92ZXJUcmlnZ2VyIGFzQ2hpbGQ+XG4gICAgICAgIDxCdXR0b25cbiAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgcm9sZT1cImNvbWJvYm94XCJcbiAgICAgICAgICBhcmlhLWV4cGFuZGVkPXtvcGVufVxuICAgICAgICAgIGNsYXNzTmFtZT17Y24oXCJ3LWZ1bGwganVzdGlmeS1zdGFydFwiLCBjbGFzc05hbWUpfVxuICAgICAgICA+XG4gICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJoLTQgdy00IHNocmluay0wIG9wYWNpdHktNjBcIiAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAge3BsYWNlaG9sZGVyID8/IHQoXCJicmFuZC5zZWFyY2hQbGFjZWhvbGRlclwiKX1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvQnV0dG9uPlxuICAgICAgPC9Qb3BvdmVyVHJpZ2dlcj5cbiAgICAgIDxQb3BvdmVyQ29udGVudCBhbGlnbj1cInN0YXJ0XCIgY2xhc3NOYW1lPVwidy04MCBtYXgtdy1bOTB2d10gcC0wXCI+XG4gICAgICAgIDxDb21tYW5kIHNob3VsZEZpbHRlcj17ZmFsc2V9PlxuICAgICAgICAgIDxDb21tYW5kSW5wdXRcbiAgICAgICAgICAgIHZhbHVlPXtxdWVyeX1cbiAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9e3NldFF1ZXJ5fVxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3BsYWNlaG9sZGVyID8/IHQoXCJicmFuZC5zZWFyY2hQbGFjZWhvbGRlclwiKX1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxDb21tYW5kTGlzdD5cbiAgICAgICAgICAgIHtyZXN1bHRzICYmIHJlc3VsdHMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC0zIHB5LTYgdGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICB7dChcImJyYW5kLnNlYXJjaE5vUmVzdWx0c1wiKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAge3Jlc3VsdHMgJiYgcmVzdWx0cy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgPENvbW1hbmRHcm91cCBoZWFkaW5nPXt0KFwiYnJhbmQuc2VhcmNoUmVzdWx0c1wiKX0+XG4gICAgICAgICAgICAgICAge3Jlc3VsdHMubWFwKChiKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8Q29tbWFuZEl0ZW0ga2V5PXtiLmlkfSB2YWx1ZT17Yi5pZH0gb25TZWxlY3Q9eygpID0+IGhhbmRsZVNlbGVjdChiKX0+XG4gICAgICAgICAgICAgICAgICAgIDxDaGVja1xuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgICBcIm1yLTIgaC00IHctNFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRJZCA9PT0gYi5pZCA/IFwib3BhY2l0eS0xMDBcIiA6IFwib3BhY2l0eS0wXCIsXG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj57Yi5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAge2IuY291bnRyeSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtYXV0byBzaHJpbmstMCBwbC0yIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Yi5jb3VudHJ5fVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvQ29tbWFuZEl0ZW0+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvQ29tbWFuZEdyb3VwPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHtxLmxlbmd0aCA+IDAgJiYgIWV4YWN0TWF0Y2ggJiYgKFxuICAgICAgICAgICAgICA8Q29tbWFuZEdyb3VwPlxuICAgICAgICAgICAgICAgIDxDb21tYW5kSXRlbSB2YWx1ZT1cIl9fYWRkX25ld19icmFuZF9fXCIgb25TZWxlY3Q9e2FkZE5ld30+XG4gICAgICAgICAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJtci0yIGgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAge3QoXCJicmFuZC5hZGROZXdcIiwgeyBuYW1lOiBxIH0pfVxuICAgICAgICAgICAgICAgIDwvQ29tbWFuZEl0ZW0+XG4gICAgICAgICAgICAgIDwvQ29tbWFuZEdyb3VwPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L0NvbW1hbmRMaXN0PlxuICAgICAgICA8L0NvbW1hbmQ+XG4gICAgICA8L1BvcG92ZXJDb250ZW50PlxuICAgIDwvUG9wb3Zlcj5cbiAgKTtcbn1cbiJdfQ==