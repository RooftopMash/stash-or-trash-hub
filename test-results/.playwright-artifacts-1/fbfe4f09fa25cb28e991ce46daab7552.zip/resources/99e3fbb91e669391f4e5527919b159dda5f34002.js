import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=a8030269";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=a8030269";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/react_jsx-runtime.js?v=a8030269";
//#region node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
/**
* The context that `useQueryClient` reads from. `QueryClientProvider` is the normal way to set it.
*/
var QueryClientContext = import_react.createContext(void 0);
/**
* The `useQueryClient` hook returns the current `QueryClient` instance.
*
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns The current `QueryClient` instance.
* @throws If no `queryClient` argument is passed and no `QueryClientProvider` is found in the component tree.
*/
var useQueryClient = (queryClient) => {
	const client = import_react.useContext(QueryClientContext);
	if (queryClient) return queryClient;
	if (!client) throw new Error("No QueryClient set, use QueryClientProvider to set one");
	return client;
};
/**
* Use the `QueryClientProvider` component to connect and provide a `QueryClient` to your application. Also
* calls `client.mount()`/`client.unmount()` as this component mounts/unmounts, which subscribes the client to
* focus/online events (resuming any paused mutations and refetching as needed when the app regains focus or
* comes back online).
*
* @returns The provided `children`, wrapped so they can read the `QueryClient` via `useQueryClient`.
*
* @example
* ```tsx
* import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
*
* const queryClient = new QueryClient()
*
* function App() {
*   return <QueryClientProvider client={queryClient}>...</QueryClientProvider>
* }
* ```
*/
var QueryClientProvider = ({ client, children }) => {
	import_react.useEffect(() => {
		client.mount();
		return () => {
			client.unmount();
		};
	}, [client]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientContext.Provider, {
		value: client,
		children
	});
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/timeoutManager.js
var defaultTimeoutProvider = {
	setTimeout: (callback, delay) => setTimeout(callback, delay),
	clearTimeout: (timeoutId) => clearTimeout(timeoutId),
	setInterval: (callback, delay) => setInterval(callback, delay),
	clearInterval: (intervalId) => clearInterval(intervalId)
};
/**
* Allows customization of how timeouts are created.
*
* @tanstack/query-core makes liberal use of timeouts to implement `staleTime`
* and `gcTime`. The default TimeoutManager provider uses the platform's global
* `setTimeout` implementation, which is known to have scalability issues with
* thousands of timeouts on the event loop.
*
* If you hit this limitation, consider providing a custom TimeoutProvider that
* coalesces timeouts.
*/
var TimeoutManager = class {
	#provider = defaultTimeoutProvider;
	#providerCalled = false;
	/**
	* `setTimeoutProvider` can be used to set a custom implementation of the
	* `setTimeout`, `clearTimeout`, `setInterval`, `clearInterval` functions,
	* called a `TimeoutProvider`.
	*
	* This may be useful if you notice event loop performance issues with
	* thousands of queries. A custom TimeoutProvider could also support timer
	* delays longer than the global `setTimeout` maximum delay value of about
	* 24 days.
	*
	* It is important to call `setTimeoutProvider` before creating a
	* QueryClient or queries, so that the same provider is used consistently
	* for all timers in the application, since different TimeoutProviders
	* cannot cancel each others' timers.
	*
	* @example
	* ```ts
	* import { timeoutManager, QueryClient } from '@tanstack/query-core'
	* import { CustomTimeoutProvider } from './CustomTimeoutProvider'
	*
	* timeoutManager.setTimeoutProvider(new CustomTimeoutProvider())
	*
	* export const queryClient = new QueryClient()
	* ```
	*/
	setTimeoutProvider(provider) {
		if (this.#providerCalled && provider !== this.#provider) console.error(`[timeoutManager]: Switching provider after calls to previous provider might result in unexpected behavior.`, {
			previous: this.#provider,
			provider
		});
		this.#provider = provider;
		this.#providerCalled = false;
	}
	/**
	* `setTimeout` schedules a callback to run after approximately `delay`
	* milliseconds, like the global `setTimeout` function. The callback can be
	* canceled with `clearTimeout`.
	*
	* It returns a timer ID, which may be a number or an object that can be
	* coerced to a number via `Symbol.toPrimitive`.
	*
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const timeoutId = timeoutManager.setTimeout(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* const timeoutIdNumber: number = Number(timeoutId)
	* ```
	*/
	setTimeout(callback, delay) {
		this.#providerCalled = true;
		return this.#provider.setTimeout(callback, delay);
	}
	/**
	* `clearTimeout` cancels a timeout callback scheduled with `setTimeout`,
	* like the global `clearTimeout` function. It should be called with a
	* timer ID returned by `setTimeout`.
	*
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const timeoutId = timeoutManager.setTimeout(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* timeoutManager.clearTimeout(timeoutId)
	* ```
	*/
	clearTimeout(timeoutId) {
		this.#provider.clearTimeout(timeoutId);
	}
	/**
	* `setInterval` schedules a callback to be called approximately every
	* `delay` milliseconds, like the global `setInterval` function.
	*
	* Like `setTimeout`, it returns a timer ID, which may be a number or an
	* object that can be coerced to a number via `Symbol.toPrimitive`.
	*
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const intervalId = timeoutManager.setInterval(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	* ```
	*/
	setInterval(callback, delay) {
		this.#providerCalled = true;
		return this.#provider.setInterval(callback, delay);
	}
	/**
	* `clearInterval` can be used to cancel an interval, like the global
	* `clearInterval` function. It should be called with an interval ID
	* returned by `setInterval`.
	*
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const intervalId = timeoutManager.setInterval(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* timeoutManager.clearInterval(intervalId)
	* ```
	*/
	clearInterval(intervalId) {
		this.#provider.clearInterval(intervalId);
	}
};
/**
* Singleton instance of {@link TimeoutManager}, used throughout TanStack Query to schedule and cancel timers.
*/
var timeoutManager = new TimeoutManager();
/**
* In many cases code wants to delay to the next event loop tick; this is not
* mediated by {@link timeoutManager}.
*
* This function is provided to make auditing the `tanstack/query-core` for
* incorrect use of system `setTimeout` easier.
*/
function systemSetTimeoutZero(callback) {
	setTimeout(callback, 0);
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/utils.js
/** @deprecated
* use `environmentManager.isServer()` instead.
*/
var isServer = typeof window === "undefined" || "Deno" in globalThis;
function noop() {}
function functionalUpdate(updater, input) {
	return typeof updater === "function" ? updater(input) : updater;
}
function isValidTimeout(value) {
	return typeof value === "number" && value >= 0 && value !== Infinity;
}
function timeUntilStale(updatedAt, staleTime) {
	return Math.max(updatedAt + (staleTime || 0) - Date.now(), 0);
}
function resolveQueryValue(value, query) {
	return typeof value === "function" ? value(query) : value;
}
/**
* Checks whether a query matches the given {@link QueryFilters}.
* Every filter that is specified must match; filters that are left unspecified are ignored.
*
* @example
* ```ts
* const queryCache = queryClient.getQueryCache()
*
* const matchingQueries = queryCache
*   .getAll()
*   .filter((query) => matchQuery({ queryKey: ['posts'] }, query))
* ```
*/
function matchQuery(filters, query) {
	const { type = "all", exact, fetchStatus, predicate, queryKey, stale } = filters;
	if (queryKey) {
		if (exact) {
			if (query.queryHash !== hashQueryKeyByOptions(queryKey, query.options)) return false;
		} else if (!partialMatchKey(query.queryKey, queryKey)) return false;
	}
	if (type !== "all") {
		const isActive = query.isActive();
		if (type === "active" && !isActive) return false;
		if (type === "inactive" && isActive) return false;
	}
	if (typeof stale === "boolean" && query.isStale() !== stale) return false;
	if (fetchStatus && fetchStatus !== query.state.fetchStatus) return false;
	if (predicate && !predicate(query)) return false;
	return true;
}
/**
* Checks whether a mutation matches the given {@link MutationFilters}.
* Every filter that is specified must match; filters that are left unspecified are ignored.
* If a `mutationKey` filter is provided but the mutation has no `mutationKey` of its own, it does not match.
*
* @example
* ```ts
* const mutationCache = queryClient.getMutationCache()
*
* const matchingMutations = mutationCache
*   .getAll()
*   .filter((mutation) => matchMutation({ mutationKey: ['addPost'] }, mutation))
* ```
*/
function matchMutation(filters, mutation) {
	const { exact, status, predicate, mutationKey } = filters;
	if (mutationKey) {
		if (!mutation.options.mutationKey) return false;
		if (exact) {
			if (hashKey(mutation.options.mutationKey) !== hashKey(mutationKey)) return false;
		} else if (!partialMatchKey(mutation.options.mutationKey, mutationKey)) return false;
	}
	if (status && mutation.state.status !== status) return false;
	if (predicate && !predicate(mutation)) return false;
	return true;
}
function hashQueryKeyByOptions(queryKey, options) {
	return (options?.queryKeyHashFn || hashKey)(queryKey);
}
/**
* Default query & mutation keys hash function.
* Hashes the value into a stable hash.
*
* @example
* ```ts
* // Object keys are sorted, so key order doesn't affect the hash:
* hashKey(['todos', { page: 1, filter: 'done' }]) // === '["todos",{"filter":"done","page":1}]'
* ```
*/
function hashKey(queryKey) {
	return JSON.stringify(queryKey, (_, val) => isPlainObject(val) ? Object.keys(val).sort().reduce((result, key) => {
		result[key] = val[key];
		return result;
	}, {}) : val);
}
function partialMatchKey(a, b) {
	if (a === b) return true;
	if (typeof a !== typeof b) return false;
	if (a && b && typeof a === "object" && typeof b === "object") {
		if (Array.isArray(a) && Array.isArray(b)) {
			if (b.length > a.length) return false;
			for (let i = 0; i < b.length; i++) if (!partialMatchKey(a[i], b[i])) return false;
			return true;
		}
		const bKeys = Object.keys(b);
		for (const key of bKeys) if (!partialMatchKey(a[key], b[key])) return false;
		return true;
	}
	return false;
}
var hasOwn = Object.prototype.hasOwnProperty;
function replaceEqualDeep(a, b, depth = 0) {
	if (a === b) return a;
	if (depth > 500) return b;
	const array = isPlainArray(a) && isPlainArray(b);
	if (!array && !(isPlainObject(a) && isPlainObject(b))) return b;
	const aSize = (array ? a : Object.keys(a)).length;
	const bItems = array ? b : Object.keys(b);
	const bSize = bItems.length;
	const copy = array ? new Array(bSize) : {};
	let equalItems = 0;
	for (let i = 0; i < bSize; i++) {
		const key = array ? i : bItems[i];
		const aItem = a[key];
		const bItem = b[key];
		if (aItem === bItem) {
			copy[key] = aItem;
			if (array ? i < aSize : hasOwn.call(a, key)) equalItems++;
			continue;
		}
		if (aItem === null || bItem === null || typeof aItem !== "object" || typeof bItem !== "object") {
			copy[key] = bItem;
			continue;
		}
		const v = replaceEqualDeep(aItem, bItem, depth + 1);
		copy[key] = v;
		if (v === aItem) equalItems++;
	}
	return aSize === bSize && equalItems === aSize ? a : copy;
}
/**
* Shallow compare objects.
*/
function shallowEqualObjects(a, b) {
	if (!b || Object.keys(a).length !== Object.keys(b).length) return false;
	for (const key in a) if (a[key] !== b[key]) return false;
	return true;
}
function isPlainArray(value) {
	return Array.isArray(value) && value.length === Object.keys(value).length;
}
function isPlainObject(o) {
	if (!hasObjectPrototype(o)) return false;
	const objectPrototype = Object.getPrototypeOf(o);
	const ctor = objectPrototype?.constructor;
	if (ctor === void 0) return true;
	if (typeof ctor !== "function") return false;
	const prot = ctor.prototype;
	if (!hasObjectPrototype(prot)) return false;
	if (!prot.hasOwnProperty("isPrototypeOf")) return false;
	if (objectPrototype !== Object.prototype) return false;
	return true;
}
function hasObjectPrototype(o) {
	return Object.prototype.toString.call(o) === "[object Object]";
}
function sleep(timeout) {
	return new Promise((resolve) => {
		timeoutManager.setTimeout(resolve, timeout);
	});
}
function replaceData(prevData, data, options) {
	if (typeof options.structuralSharing === "function") return options.structuralSharing(prevData, data);
	else if (options.structuralSharing !== false) try {
		return replaceEqualDeep(prevData, data);
	} catch (error) {
		console.error(`Structural sharing requires data to be JSON serializable. To fix this, turn off structuralSharing or return JSON-serializable data from your queryFn. [${options.queryHash}]: ${error}`);
		throw error;
	}
	return data;
}
/**
* Intended to be passed as a query's `placeholderData` option, for example
* `placeholderData: keepPreviousData`. Instead of resetting the query's data to `undefined` while a new
* query key is fetching, it keeps displaying the previously fetched data until the new data arrives.
*
* @example
* ```ts
* new QueryObserver(queryClient, {
*   queryKey: ['posts', page],
*   queryFn: () => fetchPosts(page),
*   placeholderData: keepPreviousData,
* })
* ```
*/
function keepPreviousData(previousData) {
	return previousData;
}
function addToEnd(items, item, max = 0) {
	const newItems = [...items, item];
	return max && newItems.length > max ? newItems.slice(1) : newItems;
}
function addToStart(items, item, max = 0) {
	const newItems = [item, ...items];
	return max && newItems.length > max ? newItems.slice(0, -1) : newItems;
}
/**
* Sentinel value that can be passed as a query's `queryFn` to conditionally disable the query (equivalent
* to `enabled: false`) while preserving full type inference for the query's data. Unlike `enabled: false`,
* a query disabled via `skipToken` cannot be triggered with `refetch`.
*
* @example
* ```ts
* new QueryObserver(queryClient, {
*   queryKey: ['post', postId],
*   queryFn: postId != null ? () => fetchPost(postId) : skipToken,
* })
* ```
*/
var skipToken = Symbol();
function ensureQueryFn(options, fetchOptions) {
	if (options.queryFn === skipToken) console.error(`Attempted to invoke queryFn when set to skipToken. This is likely a configuration error. Query hash: '${options.queryHash}'`);
	if (!options.queryFn && fetchOptions?.initialPromise) return () => fetchOptions.initialPromise;
	if (!options.queryFn || options.queryFn === skipToken) return () => Promise.reject(/* @__PURE__ */ new Error(`Missing queryFn: '${options.queryHash}'`));
	return options.queryFn;
}
/**
* Resolves a `throwOnError` option to a boolean.
* If `throwOnError` is a function, it is called with `params` (e.g. the error and, depending on the caller,
* additional context such as the query or mutation) and its result is returned, allowing the throwing
* behavior to be decided per error. Otherwise, `throwOnError` itself is coerced to a boolean (`undefined`
* resolves to `false`).
*
* @example
* ```ts
* const throwOnError =
*   query.state.error && typeof options.throwOnError === 'function'
*     ? shouldThrowError(options.throwOnError, [query.state.error, query])
*     : options.throwOnError
* ```
*/
function shouldThrowError(throwOnError, params) {
	if (typeof throwOnError === "function") return throwOnError(...params);
	return !!throwOnError;
}
function addConsumeAwareSignal(object, getSignal, onCancelled) {
	let consumed = false;
	let signal;
	Object.defineProperty(object, "signal", {
		enumerable: true,
		get: () => {
			signal ??= getSignal();
			if (consumed) return signal;
			consumed = true;
			if (signal.aborted) onCancelled();
			else signal.addEventListener("abort", onCancelled, { once: true });
			return signal;
		}
	});
	return object;
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/environmentManager.js
var isServerFn = () => isServer;
/**
* Returns whether the current runtime should be treated as a server environment.
*/
var isServer$1 = () => isServerFn();
/**
* Manages how TanStack Query detects whether the current runtime should be treated as
* server-side, which disables scheduling refetch timers and changes the default `retry` count
* and `gcTime`. By default, the detection treats a missing `window` (or the presence of a
* `Deno` global) as server.
*
* Override this for runtimes where that default detection would give the wrong answer — for
* example, a Service Worker, where `window` is undefined even though the environment should
* behave like a client.
*
* @example
* ```ts
* import { environmentManager } from '@tanstack/query-core'
*
* environmentManager.setIsServer(() => false)
* ```
*/
var environmentManager = {
	isServer: isServer$1,
	/**
	* Overrides the server check globally.
	*/
	setIsServer(isServerValue) {
		isServerFn = isServerValue;
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/subscribable.js
var Subscribable = class {
	constructor() {
		this.listeners = /* @__PURE__ */ new Set();
		this.subscribe = this.subscribe.bind(this);
	}
	subscribe(listener) {
		this.listeners.add(listener);
		this.onSubscribe();
		return () => {
			this.listeners.delete(listener);
			this.onUnsubscribe();
		};
	}
	hasListeners() {
		return this.listeners.size > 0;
	}
	onSubscribe() {}
	onUnsubscribe() {}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/focusManager.js
/**
* The `FocusManager` manages the focus state within TanStack Query.
*
* It can be used to change the default event listeners or to manually change the focus state.
*/
var FocusManager = class extends Subscribable {
	#focused;
	#cleanup;
	#setup;
	constructor() {
		super();
		this.#setup = (onFocus) => {
			if (typeof window !== "undefined" && window.addEventListener) {
				const listener = () => onFocus();
				window.addEventListener("visibilitychange", listener, false);
				return () => {
					window.removeEventListener("visibilitychange", listener);
				};
			}
		};
	}
	onSubscribe() {
		if (!this.#cleanup) this.setEventListener(this.#setup);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) {
			this.#cleanup?.();
			this.#cleanup = void 0;
		}
	}
	/**
	* `setEventListener` can be used to set a custom event listener that will
	* be used to determine the focus state. The provided `setup` function
	* receives a `setFocused` callback: call it with a `boolean` to manually
	* set the focus state, or with no arguments to re-evaluate the current
	* focus state and notify subscribers.
	*
	* @example
	* ```ts
	* import { focusManager } from '@tanstack/query-core'
	*
	* focusManager.setEventListener((handleFocus) => {
	*   const listener = () => handleFocus()
	*   // Listen to visibilitychange
	*   if (typeof window !== 'undefined' && window.addEventListener) {
	*     window.addEventListener('visibilitychange', listener, false)
	*   }
	*
	*   return () => {
	*     // Be sure to unsubscribe if a new handler is set
	*     window.removeEventListener('visibilitychange', listener)
	*   }
	* })
	* ```
	*/
	setEventListener(setup) {
		this.#setup = setup;
		this.#cleanup?.();
		this.#cleanup = setup((focused) => {
			if (typeof focused === "boolean") this.setFocused(focused);
			else this.onFocus();
		});
	}
	/**
	* `setFocused` can be used to manually set the focus state. Set `undefined`
	* to fall back to the default focus check.
	*
	* @example
	* ```ts
	* import { focusManager } from '@tanstack/query-core'
	*
	* // Set focused
	* focusManager.setFocused(true)
	*
	* // Set unfocused
	* focusManager.setFocused(false)
	*
	* // Fallback to the default focus check
	* focusManager.setFocused(undefined)
	* ```
	*/
	setFocused(focused) {
		if (this.#focused !== focused) {
			this.#focused = focused;
			this.onFocus();
		}
	}
	/**
	* `onFocus` notifies all subscribed listeners with the current focus state.
	*/
	onFocus() {
		const isFocused = this.isFocused();
		this.listeners.forEach((listener) => {
			listener(isFocused);
		});
	}
	/**
	* `isFocused` can be used to get the current focus state.
	*/
	isFocused() {
		if (typeof this.#focused === "boolean") return this.#focused;
		return globalThis.document?.visibilityState !== "hidden";
	}
};
/**
* Singleton instance of {@link FocusManager}, used to manage and observe the focus state within TanStack Query.
*/
var focusManager = new FocusManager();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/hydration.js
function tryResolveSync(promise) {
	let data;
	promise.then((result) => {
		data = result;
		return result;
	}, noop)?.catch?.(noop);
	if (data !== void 0) return { data };
}
function dehydrateMutation(mutation) {
	return {
		mutationKey: mutation.options.mutationKey,
		state: mutation.state,
		...mutation.options.scope && { scope: mutation.options.scope },
		...mutation.meta && { meta: mutation.meta }
	};
}
function dehydratePromise(query, serializeData, shouldRedactErrors) {
	const promise = query.promise?.then(serializeData).catch((error) => {
		if (shouldRedactErrors?.(error) === false) return Promise.reject(error);
		console.error(`A query that was dehydrated as pending ended up rejecting. [${query.queryHash}]: ${error}; The error will be redacted in production builds`);
		return Promise.reject(/* @__PURE__ */ new Error("redacted"));
	});
	promise?.catch(noop);
	return promise;
}
/**
* Dehydrates a single `Query` into a serializable `DehydratedQuery` snapshot. Note that most query config (e.g.
* `queryFn`, `staleTime`) is not dehydrated but instead meant to be configured again when consuming the
* de/rehydrated data, typically with `useQuery` on the client. If the query is still `pending`, its in-flight
* promise is dehydrated too so it can be resumed on the other side instead of re-fetched.
* @param query - The query to dehydrate.
* @param serializeData - Optional transform applied to `query.state.data` before it is included in the snapshot.
* @param shouldRedactErrors - Optional predicate; if it returns `false` for the promise's rejection error, that
* error is kept as-is instead of being redacted.
*/
function dehydrateQuery(query, serializeData, shouldRedactErrors) {
	return {
		dehydratedAt: Date.now(),
		state: {
			...query.state,
			...query.state.data !== void 0 && { data: serializeData ? serializeData(query.state.data) : query.state.data }
		},
		queryKey: query.queryKey,
		queryHash: query.queryHash,
		...query.state.status === "pending" && { promise: dehydratePromise(query, serializeData, shouldRedactErrors) },
		...query.meta && { meta: query.meta },
		...query.queryType && { queryType: query.queryType }
	};
}
/**
* The default `shouldDehydrateMutation` predicate used by `dehydrate`. Only dehydrates mutations that are
* currently paused (e.g. paused by `networkMode` while offline).
*/
function defaultShouldDehydrateMutation(mutation) {
	return mutation.state.isPaused;
}
/**
* The default `shouldDehydrateQuery` predicate used by `dehydrate`. Only dehydrates queries whose status is
* `'success'`.
*/
function defaultShouldDehydrateQuery(query) {
	return query.state.status === "success";
}
/**
* Dehydrates a `QueryClient`'s cache (queries and mutations) into a plain, serializable `DehydratedState`,
* typically to embed in server-rendered markup and later restore into a client-side `QueryClient` via `hydrate`.
* Which queries/mutations are included, and how their data/errors are transformed, is controlled by `options`,
* falling back to the client's `dehydrate` default options, and finally to `defaultShouldDehydrateQuery` /
* `defaultShouldDehydrateMutation`.
* @example
* ```ts
* const queryClient = new QueryClient()
*
* await queryClient.prefetchQuery({
*   queryKey: ['posts'],
*   queryFn: getPosts,
* })
*
* const dehydratedState = dehydrate(queryClient)
* ```
*/
function dehydrate(client, options = {}) {
	const filterMutation = options.shouldDehydrateMutation ?? client.getDefaultOptions().dehydrate?.shouldDehydrateMutation ?? defaultShouldDehydrateMutation;
	const mutations = client.getMutationCache().getAll().flatMap((mutation) => filterMutation(mutation) ? [dehydrateMutation(mutation)] : []);
	const filterQuery = options.shouldDehydrateQuery ?? client.getDefaultOptions().dehydrate?.shouldDehydrateQuery ?? defaultShouldDehydrateQuery;
	const shouldRedactErrors = options.shouldRedactErrors ?? client.getDefaultOptions().dehydrate?.shouldRedactErrors;
	const serializeData = options.serializeData ?? client.getDefaultOptions().dehydrate?.serializeData;
	return {
		mutations,
		queries: client.getQueryCache().getAll().flatMap((query) => filterQuery(query) ? [dehydrateQuery(query, serializeData, shouldRedactErrors)] : [])
	};
}
/**
* Restores a `DehydratedState` (as produced by `dehydrate`) into a `QueryClient`'s cache, typically to seed the
* client with data already fetched on the server. `mutations` and `queries` are each optional on `dehydratedState`.
* Queries not yet in the cache are built from the dehydrated snapshot; queries that already exist are only updated
* when the dehydrated data is newer than what's already cached. Newly built queries have their `fetchStatus` reset
* to `'idle'` so they don't hydrate stuck in a fetching state. If a dehydrated query still had an in-flight
* promise, it is resumed via `query.fetch()` (reusing that promise as `initialPromise`) rather than re-invoking
* `queryFn`.
* @example
* ```ts
* // dehydratedState was produced by `dehydrate` on the server
* // and sent to the client, e.g. embedded in server-rendered markup.
* const queryClient = new QueryClient()
*
* hydrate(queryClient, dehydratedState)
* ```
*/
function hydrate(client, dehydratedState, options) {
	const mutationCache = client.getMutationCache();
	const queryCache = client.getQueryCache();
	const deserializeData = options?.defaultOptions?.deserializeData ?? client.getDefaultOptions().hydrate?.deserializeData;
	dehydratedState.mutations?.forEach(({ state, ...mutationOptions }) => {
		mutationCache.build(client, {
			...client.getDefaultOptions().hydrate?.mutations,
			...options?.defaultOptions?.mutations,
			...mutationOptions
		}, state);
	});
	dehydratedState.queries?.forEach(({ queryKey, state, queryHash, meta, promise, dehydratedAt, queryType }) => {
		const syncData = promise ? tryResolveSync(promise) : void 0;
		const rawData = state.data === void 0 ? syncData?.data : state.data;
		const data = rawData === void 0 ? rawData : deserializeData ? deserializeData(rawData) : rawData;
		let query = queryCache.get(queryHash);
		const existingQueryIsPending = query?.state.status === "pending";
		const existingQueryIsFetching = query?.state.fetchStatus === "fetching";
		if (query) {
			const hasNewerSyncData = syncData && dehydratedAt > query.state.dataUpdatedAt;
			if (state.dataUpdatedAt > query.state.dataUpdatedAt || hasNewerSyncData) {
				const { fetchStatus: _ignored, ...serializedState } = state;
				query.setState({
					...serializedState,
					data,
					...state.status === "pending" && data !== void 0 && {
						status: "success",
						dataUpdatedAt: dehydratedAt,
						...!existingQueryIsFetching && { fetchStatus: "idle" }
					}
				});
			}
		} else query = queryCache.build(client, {
			...client.getDefaultOptions().hydrate?.queries,
			...options?.defaultOptions?.queries,
			queryKey,
			queryHash,
			meta,
			_type: queryType
		}, {
			...state,
			data,
			fetchStatus: "idle",
			status: state.status === "pending" && data !== void 0 ? "success" : state.status,
			...state.status === "pending" && data !== void 0 && { dataUpdatedAt: dehydratedAt }
		});
		if (promise && !syncData && !existingQueryIsPending && !existingQueryIsFetching && dehydratedAt > query.state.dataUpdatedAt) query.fetch(void 0, { initialPromise: Promise.resolve(promise).then(deserializeData) }).catch(noop);
	});
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/notifyManager.js
/**
* Default scheduling function used by the notify manager.
* Schedules the callback with the system's `setTimeout(callback, 0)`.
*/
var defaultScheduler = systemSetTimeoutZero;
function createNotifyManager() {
	let queue = [];
	let transactions = 0;
	let notifyFn = (callback) => {
		callback();
	};
	let batchNotifyFn = (callback) => {
		callback();
	};
	let scheduleFn = defaultScheduler;
	const schedule = (callback) => {
		if (transactions) queue.push(callback);
		else scheduleFn(() => {
			notifyFn(callback);
		});
	};
	const flush = () => {
		const originalQueue = queue;
		queue = [];
		if (originalQueue.length) scheduleFn(() => {
			batchNotifyFn(() => {
				originalQueue.forEach((callback) => {
					notifyFn(callback);
				});
			});
		});
	};
	return {
		/**
		* Batches all updates scheduled inside the passed callback.
		* This is mainly used internally to optimize query client updating.
		* Batches can be nested; the queue is only flushed once the outermost `batch` call finishes.
		* The return value of `callback` is passed through.
		*/
		batch: (callback) => {
			let result;
			transactions++;
			try {
				result = callback();
			} finally {
				transactions--;
				if (!transactions) flush();
			}
			return result;
		},
		/**
		* All calls to the wrapped function will be batched.
		*/
		batchCalls: (callback) => {
			return (...args) => {
				schedule(() => {
					callback(...args);
				});
			};
		},
		/**
		* Schedules a function to be run on the next batch.
		* By default, the batch is run with a `setTimeout`, but this can be configured via `setScheduler`.
		*/
		schedule,
		/**
		* Use this method to set a custom notify function.
		* This can be used to for example wrap notifications with `React.act` while running tests.
		*/
		setNotifyFunction: (fn) => {
			notifyFn = fn;
		},
		/**
		* Use this method to set a custom function to batch notifications together into a single tick.
		* Framework adapters use this to plug in their own batching primitive, so that a single query
		* update only triggers one re-render instead of one per subscriber.
		*
		* @example
		* ```ts
		* import { notifyManager } from '@tanstack/query-core'
		* import { batch } from 'solid-js'
		*
		* notifyManager.setBatchNotifyFunction(batch)
		* ```
		*/
		setBatchNotifyFunction: (fn) => {
			batchNotifyFn = fn;
		},
		/**
		* Configures a custom callback that schedules when the next batch runs.
		* The default behavior is `setTimeout(callback, 0)`.
		*
		* @example
		* ```ts
		* import { notifyManager } from '@tanstack/query-core'
		*
		* // Schedule batches in the next microtask
		* notifyManager.setScheduler(queueMicrotask)
		*
		* // Schedule batches before the next frame is rendered
		* notifyManager.setScheduler(requestAnimationFrame)
		*
		* // Schedule batches some time in the future
		* notifyManager.setScheduler((cb) => setTimeout(cb, 10))
		* ```
		*/
		setScheduler: (fn) => {
			scheduleFn = fn;
		}
	};
}
/**
* Handles scheduling and batching callbacks in TanStack Query.
*/
var notifyManager = createNotifyManager();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/onlineManager.js
/**
* The `OnlineManager` manages the online state within TanStack Query. It can
* be used to change the default event listeners or to manually change the
* online state.
*
* By default, the `onlineManager` assumes an active network connection, and
* listens to the `online` and `offline` events on the `window` object to
* detect changes.
*/
var OnlineManager = class extends Subscribable {
	#online = true;
	#cleanup;
	#setup;
	constructor() {
		super();
		this.#setup = (onOnline) => {
			if (typeof window !== "undefined" && window.addEventListener) {
				const onlineListener = () => onOnline(true);
				const offlineListener = () => onOnline(false);
				window.addEventListener("online", onlineListener, false);
				window.addEventListener("offline", offlineListener, false);
				return () => {
					window.removeEventListener("online", onlineListener);
					window.removeEventListener("offline", offlineListener);
				};
			}
		};
	}
	onSubscribe() {
		if (!this.#cleanup) this.setEventListener(this.#setup);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) {
			this.#cleanup?.();
			this.#cleanup = void 0;
		}
	}
	/**
	* `setEventListener` can be used to set a custom event listener that will
	* be used to determine the online state. The provided `setup` function
	* receives a `setOnline` callback that should be called with a `boolean`
	* whenever the online state changes.
	*
	* @example
	* ```ts
	* import NetInfo from '@react-native-community/netinfo'
	* import { onlineManager } from '@tanstack/query-core'
	*
	* onlineManager.setEventListener((setOnline) => {
	*   return NetInfo.addEventListener((state) => {
	*     setOnline(!!state.isConnected)
	*   })
	* })
	* ```
	*/
	setEventListener(setup) {
		this.#setup = setup;
		this.#cleanup?.();
		this.#cleanup = setup(this.setOnline.bind(this));
	}
	/**
	* `setOnline` can be used to manually set the online state.
	*
	* @example
	* ```ts
	* import { onlineManager } from '@tanstack/query-core'
	*
	* // Set to online
	* onlineManager.setOnline(true)
	*
	* // Set to offline
	* onlineManager.setOnline(false)
	* ```
	*/
	setOnline(online) {
		if (this.#online !== online) {
			this.#online = online;
			this.listeners.forEach((listener) => {
				listener(online);
			});
		}
	}
	/**
	* `isOnline` can be used to get the current online state.
	*/
	isOnline() {
		return this.#online;
	}
};
/**
* Singleton instance of {@link OnlineManager}, used to manage and observe the online state within TanStack Query.
*/
var onlineManager = new OnlineManager();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/retryer.js
function defaultRetryDelay(failureCount) {
	return Math.min(1e3 * 2 ** failureCount, 3e4);
}
function canFetch(networkMode) {
	return (networkMode ?? "online") === "online" ? onlineManager.isOnline() : true;
}
/**
* The error thrown by a `Retryer` (and surfaced to `query.promise`/`mutation`) when a fetch is cancelled, e.g. via
* `query.cancel()`. `revert`, if `true`, tells the caller to restore the state the query was in before the fetch
* started instead of surfacing the error. `silent`, if `true`, tells the caller to suppress this error and instead
* resolve with the promise of the fetch that triggered the cancellation.
* @example
* ```ts
* query.cancel()
*
* try {
*   await query.promise
* } catch (error) {
*   if (error instanceof CancelledError) {
*     // the fetch was cancelled, e.g. via `query.cancel()`
*   }
* }
* ```
*/
var CancelledError = class extends Error {
	constructor(options) {
		super("CancelledError");
		this.revert = options?.revert;
		this.silent = options?.silent;
	}
};
/**
* @deprecated Use instanceof `CancelledError` instead.
*/
function isCancelledError(value) {
	return value instanceof CancelledError;
}
function createRetryer(config) {
	let isRetryCancelled = false;
	let failureCount = 0;
	let continueFn;
	let status = "pending";
	let promiseResolve;
	let promiseReject;
	const promise = new Promise((resolve, reject) => {
		promiseResolve = resolve;
		promiseReject = reject;
	});
	promise.catch(noop);
	const isResolved = () => status !== "pending";
	const cancel = (cancelOptions) => {
		if (!isResolved()) {
			const error = new CancelledError(cancelOptions);
			reject(error);
			config.onCancel?.(error);
		}
	};
	const cancelRetry = () => {
		isRetryCancelled = true;
	};
	const continueRetry = () => {
		isRetryCancelled = false;
	};
	const canContinue = () => focusManager.isFocused() && (config.networkMode === "always" || onlineManager.isOnline()) && config.canRun();
	const canStart = () => canFetch(config.networkMode) && config.canRun();
	const resolve = (value) => {
		if (!isResolved()) {
			continueFn?.();
			status = "resolved";
			promiseResolve(value);
		}
	};
	const reject = (value) => {
		if (!isResolved()) {
			continueFn?.();
			status = "rejected";
			promiseReject(value);
		}
	};
	const pause = () => {
		return new Promise((continueResolve) => {
			continueFn = (value) => {
				if (isResolved() || canContinue()) continueResolve(value);
			};
			config.onPause?.();
		}).then(() => {
			continueFn = void 0;
			if (!isResolved()) config.onContinue?.();
		});
	};
	const run = () => {
		if (isResolved()) return;
		let promiseOrValue;
		const initialPromise = failureCount === 0 ? config.initialPromise : void 0;
		try {
			promiseOrValue = initialPromise ?? config.fn();
		} catch (error) {
			promiseOrValue = Promise.reject(error);
		}
		Promise.resolve(promiseOrValue).then(resolve).catch((error) => {
			if (isResolved()) return;
			const retry = config.retry ?? (isServer$1() ? 0 : 3);
			const retryDelay = config.retryDelay ?? defaultRetryDelay;
			const delay = typeof retryDelay === "function" ? retryDelay(failureCount, error) : retryDelay;
			const shouldRetry = retry === true || typeof retry === "number" && failureCount < retry || typeof retry === "function" && retry(failureCount, error);
			if (isRetryCancelled || !shouldRetry) {
				reject(error);
				return;
			}
			failureCount++;
			config.onFail?.(failureCount, error);
			sleep(delay).then(() => {
				return canContinue() ? void 0 : pause();
			}).then(() => {
				if (isRetryCancelled) reject(error);
				else run();
			});
		});
	};
	return {
		promise,
		status: () => status,
		cancel,
		continue: () => {
			continueFn?.();
			return promise;
		},
		cancelRetry,
		continueRetry,
		canStart,
		start: () => {
			if (canStart()) run();
			else pause().then(run);
			return promise;
		}
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/removable.js
var Removable = class {
	#gcTimeout;
	destroy() {
		this.clearGcTimeout();
	}
	scheduleGc() {
		this.clearGcTimeout();
		if (isValidTimeout(this.gcTime)) this.#gcTimeout = timeoutManager.setTimeout(() => {
			this.optionalRemove();
		}, this.gcTime);
	}
	updateGcTime(newGcTime) {
		this.gcTime = Math.max(this.gcTime || 0, newGcTime ?? (isServer$1() ? Infinity : 3e5));
	}
	clearGcTimeout() {
		if (this.#gcTimeout !== void 0) {
			timeoutManager.clearTimeout(this.#gcTimeout);
			this.#gcTimeout = void 0;
		}
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/infiniteQueryBehavior.js
function infiniteQueryBehavior(pages) {
	return { onFetch: (context, query) => {
		const options = context.options;
		const direction = context.fetchOptions?.meta?.fetchMore?.direction;
		const oldPages = context.state.data?.pages || [];
		const oldPageParams = context.state.data?.pageParams || [];
		let result = {
			pages: [],
			pageParams: []
		};
		let currentPage = 0;
		const fetchFn = async () => {
			let cancelled = false;
			const addSignalProperty = (object) => {
				addConsumeAwareSignal(object, () => context.signal, () => cancelled = true);
			};
			const queryFn = ensureQueryFn(context.options, context.fetchOptions);
			const fetchPage = async (data, param, previous) => {
				if (cancelled) return Promise.reject(context.signal.reason);
				if (param == null && data.pages.length) return Promise.resolve(data);
				const createQueryFnContext = () => {
					const queryFnContext = {
						client: context.client,
						queryKey: context.queryKey,
						pageParam: param,
						direction: previous ? "backward" : "forward",
						meta: context.options.meta
					};
					addSignalProperty(queryFnContext);
					return queryFnContext;
				};
				const queryFnContext = createQueryFnContext();
				const page = await queryFn(queryFnContext);
				const { maxPages } = context.options;
				const addTo = previous ? addToStart : addToEnd;
				return {
					pages: addTo(data.pages, page, maxPages),
					pageParams: addTo(data.pageParams, param, maxPages)
				};
			};
			if (direction && oldPages.length) {
				const previous = direction === "backward";
				const pageParamFn = previous ? getPreviousPageParam : getNextPageParam;
				const oldData = {
					pages: oldPages,
					pageParams: oldPageParams
				};
				result = await fetchPage(oldData, pageParamFn(options, oldData), previous);
			} else {
				const remainingPages = pages ?? oldPages.length;
				do {
					const param = currentPage === 0 ? oldPageParams[0] ?? options.initialPageParam : getNextPageParam(options, result);
					if (currentPage > 0 && param == null) break;
					result = await fetchPage(result, param);
					currentPage++;
				} while (currentPage < remainingPages);
			}
			return result;
		};
		if (context.options.persister) context.fetchFn = () => {
			return context.options.persister?.(fetchFn, {
				client: context.client,
				queryKey: context.queryKey,
				meta: context.options.meta,
				signal: context.signal
			}, query);
		};
		else context.fetchFn = fetchFn;
	} };
}
function getNextPageParam(options, { pages, pageParams }) {
	const lastIndex = pages.length - 1;
	return pages.length > 0 ? options.getNextPageParam(pages[lastIndex], pages, pageParams[lastIndex], pageParams) : void 0;
}
function getPreviousPageParam(options, { pages, pageParams }) {
	return pages.length > 0 ? options.getPreviousPageParam?.(pages[0], pages, pageParams[0], pageParams) : void 0;
}
/**
* Checks if there is a next page.
*/
function hasNextPage(options, data) {
	if (!data) return false;
	return getNextPageParam(options, data) != null;
}
/**
* Checks if there is a previous page.
*/
function hasPreviousPage(options, data) {
	if (!data || !options.getPreviousPageParam) return false;
	return getPreviousPageParam(options, data) != null;
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/query.js
/**
* Represents a single cached query. A `Query` holds the query's key, options,
* state (data/error/status), and the observers currently subscribed to it.
*
* Instances are created and managed internally by `QueryCache`; application
* code typically interacts with queries indirectly through `QueryClient` or
* a framework hook like `useQuery`. Direct access to a `Query` instance is
* possible via `queryCache.find()`/`findAll()` for inspecting cache state.
*
* @example
* ```ts
* const queryCache = queryClient.getQueryCache()
* const query = queryCache.find({ queryKey: ['posts'] })
*
* if (query) {
*   console.log(query.state.dataUpdatedAt)
* }
* ```
*/
var Query = class extends Removable {
	#queryType;
	#initialState;
	#revertState;
	#cache;
	#client;
	#retryer;
	#defaultOptions;
	#abortSignalConsumed;
	constructor(config) {
		super();
		this.#abortSignalConsumed = false;
		this.#defaultOptions = config.defaultOptions;
		this.setOptions(config.options);
		this.observers = [];
		this.#client = config.client;
		this.#cache = this.#client.getQueryCache();
		this.queryKey = config.queryKey;
		this.queryHash = config.queryHash;
		this.#initialState = getDefaultState$1(this.options);
		this.state = config.state ?? this.#initialState;
		this.scheduleGc();
	}
	/**
	* The `meta` object passed in the query's options, if any.
	*/
	get meta() {
		return this.options.meta;
	}
	/** @internal */
	get queryType() {
		return this.#queryType;
	}
	/**
	* The promise for the currently in-flight fetch, if the query is fetching.
	* `undefined` when the query is not fetching.
	*/
	get promise() {
		return this.#retryer?.promise;
	}
	/** @internal */
	setOptions(options) {
		this.options = {
			...this.#defaultOptions,
			...options
		};
		if (options?._type) this.#queryType = options._type;
		this.updateGcTime(this.options.gcTime);
		if (this.state && this.state.data === void 0) {
			const defaultState = getDefaultState$1(this.options);
			if (defaultState.data !== void 0) {
				this.setState(successState(defaultState.data, defaultState.dataUpdatedAt));
				this.#initialState = defaultState;
			}
		}
	}
	optionalRemove() {
		if (!this.observers.length && this.state.fetchStatus === "idle") this.#cache.remove(this);
	}
	/** @internal */
	setData(newData, options) {
		const data = replaceData(this.state.data, newData, this.options);
		this.#dispatch({
			data,
			type: "success",
			dataUpdatedAt: options?.updatedAt,
			manual: options?.manual
		});
		return data;
	}
	/**
	* Merges the given partial state directly into this query's state, notifying observers. Used
	* by persistence and broadcast plugins to restore a state snapshot, and by devtools to let a
	* user manually trigger a loading/error state or edit the cached data.
	*/
	setState(state) {
		this.#dispatch({
			type: "setState",
			state
		});
	}
	/**
	* Cancels the query's currently in-flight fetch, if any.
	* - Returns a promise that resolves once the cancellation has settled.
	* - If no fetch is in progress, resolves immediately.
	*
	* @example
	* ```ts
	* await query.cancel()
	* ```
	*/
	cancel(options) {
		const promise = this.#retryer?.promise;
		this.#retryer?.cancel(options);
		return promise ? promise.then(noop).catch(noop) : Promise.resolve();
	}
	/**
	* Clears the query's garbage collection timeout and silently cancels any
	* in-flight fetch. Called by `QueryCache` when the query is removed from
	* the cache.
	*
	* @see {@link Query#cancel}
	*/
	destroy() {
		super.destroy();
		this.cancel({ silent: true });
	}
	/** @internal */
	get resetState() {
		return this.#initialState;
	}
	/**
	* Resets the query back to its initial state (the state it had when it was
	* first created, e.g. any `initialData`), destroying it first to cancel any
	* in-flight fetch.
	*/
	reset() {
		this.destroy();
		this.setState(this.resetState);
	}
	/**
	* Returns `true` if the query has at least one observer for which `enabled`
	* does not resolve to `false`.
	*/
	isActive() {
		return this.observers.some((observer) => resolveQueryValue(observer.options.enabled, this) !== false);
	}
	/**
	* Returns `true` if the query is disabled, meaning it will not fetch
	* automatically.
	* - If the query has observers, it is disabled when none of them are active
	*   (see `isActive`).
	* - If the query has no observers, it is disabled when its `queryFn` is
	*   `skipToken` or it has never been fetched.
	*/
	isDisabled() {
		if (this.getObserversCount() > 0) return !this.isActive();
		return this.options.queryFn === skipToken || !this.isFetched();
	}
	/**
	* Returns `true` if the query has been fetched, i.e. it has resolved with
	* either data or an error at least once.
	*/
	isFetched() {
		return this.state.dataUpdateCount + this.state.errorUpdateCount > 0;
	}
	/**
	* Returns `true` if the query has at least one observer configured with
	* `staleTime: 'static'`, meaning it is treated as never stale.
	*/
	isStatic() {
		if (this.getObserversCount() > 0) return this.observers.some((observer) => resolveQueryValue(observer.options.staleTime, this) === "static");
		return false;
	}
	/**
	* Returns `true` if the query is stale.
	* - If the query has observers, defers to whether any observer's current
	*   result reports `isStale` (which accounts for each observer's own
	*   `staleTime` and `enabled` state).
	* - If the query has no observers, it is considered stale when it has no
	*   data or has been invalidated.
	*
	* @see {@link Query#isStaleByTime}
	* @example
	* ```ts
	* if (query.isStale()) {
	*   // refetch or otherwise treat the cached data as outdated
	* }
	* ```
	*/
	isStale() {
		if (this.getObserversCount() > 0) return this.observers.some((observer) => observer.getCurrentResult().isStale);
		return this.state.data === void 0 || this.state.isInvalidated;
	}
	/**
	* Returns `true` if the query's data is stale relative to the given
	* `staleTime` (defaults to `0`).
	* - A query with no data is always stale.
	* - `staleTime: 'static'` is never stale.
	* - An invalidated query is always stale.
	* - Otherwise, staleness is based on elapsed time since `dataUpdatedAt`.
	*
	* @see {@link Query#isStale}
	* @example
	* ```ts
	* const isStale = query.isStaleByTime(1000 * 60)
	* ```
	*/
	isStaleByTime(staleTime = 0) {
		if (this.state.data === void 0) return true;
		if (staleTime === "static") return false;
		if (this.state.isInvalidated) return true;
		return !timeUntilStale(this.state.dataUpdatedAt, staleTime);
	}
	/** @internal */
	onFocus() {
		this.observers.find((x) => x.shouldFetchOnWindowFocus())?.refetch({ cancelRefetch: false });
		this.#retryer?.continue();
	}
	/** @internal */
	onOnline() {
		this.observers.find((x) => x.shouldFetchOnReconnect())?.refetch({ cancelRefetch: false });
		this.#retryer?.continue();
	}
	/** @internal */
	addObserver(observer) {
		if (!this.observers.includes(observer)) {
			this.observers.push(observer);
			this.clearGcTimeout();
			this.#cache.notify({
				type: "observerAdded",
				query: this,
				observer
			});
		}
	}
	/** @internal */
	removeObserver(observer) {
		const index = this.observers.indexOf(observer);
		if (index !== -1) {
			this.observers.splice(index, 1);
			if (!this.observers.length) {
				if (this.#retryer) {
					if (this.#abortSignalConsumed || this.state.fetchStatus === "paused" && this.state.status === "pending") this.#retryer.cancel({ revert: true });
					else this.#retryer.cancelRetry();
				}
				this.scheduleGc();
			}
			this.#cache.notify({
				type: "observerRemoved",
				query: this,
				observer
			});
		}
	}
	/**
	* Returns the number of observers currently subscribed to this query.
	*
	* @example
	* ```ts
	* if (query.getObserversCount() === 0) {
	*   // no component is currently watching this query
	* }
	* ```
	*/
	getObserversCount() {
		return this.observers.length;
	}
	/**
	* Marks the query as invalidated, unless it is already invalidated. This
	* updates `state.isInvalidated` and notifies observers, but does not by
	* itself trigger a refetch.
	*
	* @example
	* ```ts
	* query.invalidate()
	* ```
	*/
	invalidate() {
		if (!this.state.isInvalidated) this.#dispatch({ type: "invalidate" });
	}
	/**
	* Fetches the query, i.e. runs its `queryFn` (through any configured
	* retryer/behavior) and updates the query's state with the result.
	* - If a fetch is already in flight, returns its promise instead of
	*   starting a new one, unless `fetchOptions.cancelRefetch` is set and the
	*   query already has data, in which case the current fetch is silently
	*   cancelled first.
	* - If `options` is passed, it replaces the query's current options
	*   before fetching.
	*/
	async fetch(options, fetchOptions) {
		if (this.state.fetchStatus !== "idle" && this.#retryer?.status() !== "rejected") {
			if (this.state.data !== void 0 && fetchOptions?.cancelRefetch) this.cancel({ silent: true });
			else if (this.#retryer) {
				this.#retryer.continueRetry();
				return this.#retryer.promise;
			}
		}
		if (options) this.setOptions(options);
		if (!this.options.queryFn) {
			const observer = this.observers.find((x) => x.options.queryFn);
			if (observer) this.setOptions(observer.options);
		}
		if (!Array.isArray(this.options.queryKey)) console.error(`As of v4, queryKey needs to be an Array. If you are using a string like 'repoData', please change it to an Array, e.g. ['repoData']`);
		const abortController = new AbortController();
		const addSignalProperty = (object) => {
			Object.defineProperty(object, "signal", {
				enumerable: true,
				get: () => {
					this.#abortSignalConsumed = true;
					return abortController.signal;
				}
			});
		};
		const fetchFn = () => {
			const queryFn = ensureQueryFn(this.options, fetchOptions);
			const createQueryFnContext = () => {
				const queryFnContext = {
					client: this.#client,
					queryKey: this.queryKey,
					meta: this.meta
				};
				addSignalProperty(queryFnContext);
				return queryFnContext;
			};
			const queryFnContext = createQueryFnContext();
			this.#abortSignalConsumed = false;
			if (this.options.persister) return this.options.persister(queryFn, queryFnContext, this);
			return queryFn(queryFnContext);
		};
		const createFetchContext = () => {
			const context = {
				fetchOptions,
				options: this.options,
				queryKey: this.queryKey,
				client: this.#client,
				state: this.state,
				fetchFn
			};
			addSignalProperty(context);
			return context;
		};
		const context = createFetchContext();
		(this.#queryType === "infinite" ? infiniteQueryBehavior(this.options.pages) : this.options.behavior)?.onFetch(context, this);
		this.#revertState = this.state;
		if (this.state.fetchStatus === "idle" || this.state.fetchMeta !== context.fetchOptions?.meta) this.#dispatch({
			type: "fetch",
			meta: context.fetchOptions?.meta
		});
		const retryer = this.#retryer = createRetryer({
			initialPromise: fetchOptions?.initialPromise,
			fn: context.fetchFn,
			onCancel: (error) => {
				if (error instanceof CancelledError && error.revert) this.setState({
					...this.#revertState,
					fetchStatus: "idle"
				});
				abortController.abort();
			},
			onFail: (failureCount, error) => {
				this.#dispatch({
					type: "failed",
					failureCount,
					error
				});
			},
			onPause: () => {
				this.#dispatch({ type: "pause" });
			},
			onContinue: () => {
				this.#dispatch({ type: "continue" });
			},
			retry: context.options.retry,
			retryDelay: context.options.retryDelay,
			networkMode: context.options.networkMode,
			canRun: () => true
		});
		try {
			const data = await retryer.start();
			if (data === void 0) {
				console.error(`Query data cannot be undefined. Please make sure to return a value other than undefined from your query function. Affected query key: ${this.queryHash}`);
				throw new Error(`${this.queryHash} data is undefined`);
			}
			this.setData(data);
			this.#cache.config.onSuccess?.(data, this);
			this.#cache.config.onSettled?.(data, this.state.error, this);
			return data;
		} catch (error) {
			if (error instanceof CancelledError) {
				if (error.silent) return this.#retryer.promise;
				else if (error.revert) {
					if (this.state.data === void 0) throw error;
					return this.state.data;
				}
			}
			this.#dispatch({
				type: "error",
				error
			});
			this.#cache.config.onError?.(error, this);
			this.#cache.config.onSettled?.(this.state.data, error, this);
			throw error;
		} finally {
			if (this.#retryer === retryer) this.#retryer = void 0;
			this.scheduleGc();
		}
	}
	#dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return {
					...state,
					fetchFailureCount: action.failureCount,
					fetchFailureReason: action.error
				};
				case "pause": return {
					...state,
					fetchStatus: "paused"
				};
				case "continue": return {
					...state,
					fetchStatus: "fetching"
				};
				case "fetch": return {
					...state,
					...fetchState(state.data, this.options),
					fetchMeta: action.meta ?? null
				};
				case "success":
					const newState = {
						...state,
						...successState(action.data, action.dataUpdatedAt),
						dataUpdateCount: state.dataUpdateCount + 1,
						...!action.manual && {
							fetchStatus: "idle",
							fetchFailureCount: 0,
							fetchFailureReason: null
						}
					};
					this.#revertState = action.manual ? newState : void 0;
					return newState;
				case "error":
					const error = action.error;
					return {
						...state,
						error,
						errorUpdateCount: state.errorUpdateCount + 1,
						errorUpdatedAt: Date.now(),
						fetchFailureCount: state.fetchFailureCount + 1,
						fetchFailureReason: error,
						fetchStatus: "idle",
						status: "error",
						isInvalidated: true
					};
				case "invalidate": return {
					...state,
					isInvalidated: true
				};
				case "setState": return {
					...state,
					...action.state
				};
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.observers.slice().forEach((observer) => {
				observer.onQueryUpdate();
			});
			this.#cache.notify({
				query: this,
				type: "updated",
				action
			});
		});
	}
};
function fetchState(data, options) {
	return {
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchStatus: canFetch(options.networkMode) ? "fetching" : "paused",
		...data === void 0 && {
			error: null,
			status: "pending"
		}
	};
}
function successState(data, dataUpdatedAt) {
	return {
		data,
		dataUpdatedAt: dataUpdatedAt ?? Date.now(),
		error: null,
		isInvalidated: false,
		status: "success"
	};
}
function getDefaultState$1(options) {
	const data = typeof options.initialData === "function" ? options.initialData() : options.initialData;
	const hasData = data !== void 0;
	const initialDataUpdatedAt = hasData ? typeof options.initialDataUpdatedAt === "function" ? options.initialDataUpdatedAt() : options.initialDataUpdatedAt : 0;
	return {
		data,
		dataUpdateCount: 0,
		dataUpdatedAt: hasData ? initialDataUpdatedAt ?? Date.now() : 0,
		error: null,
		errorUpdateCount: 0,
		errorUpdatedAt: 0,
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchMeta: null,
		isInvalidated: false,
		status: hasData ? "success" : "pending",
		fetchStatus: "idle"
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queryObserver.js
/**
* A `QueryObserver` watches a single query in the `QueryCache` and computes a
* `QueryObserverResult` from its state, recomputing and notifying subscribers
* whenever the underlying query (or the observer's options) changes. It is
* the primitive that framework adapters (e.g. `useQuery`) build their hooks
* on top of, but it can also be used directly to observe and switch between
* queries outside of any framework.
*
* @example
* ```ts
* const observer = new QueryObserver(queryClient, {
*   queryKey: ['posts'],
*   queryFn: fetchPosts,
* })
*
* const unsubscribe = observer.subscribe((result) => {
*   console.log(result.data)
* })
* ```
*/
var QueryObserver = class extends Subscribable {
	#client;
	#currentQuery = void 0;
	#currentQueryInitialState = void 0;
	#currentResult = void 0;
	#currentResultState;
	#currentResultOptions;
	#selectError;
	#selectFn;
	#selectResult;
	#lastQueryWithDefinedData;
	#staleTimeoutId;
	#refetchIntervalId;
	#currentRefetchInterval;
	#trackedProps = /* @__PURE__ */ new Set();
	constructor(client, options) {
		super();
		this.options = options;
		this.#client = client;
		this.#selectError = null;
		this.bindMethods();
		this.setOptions(options);
	}
	bindMethods() {
		this.refetch = this.refetch.bind(this);
	}
	onSubscribe() {
		if (this.listeners.size === 1) {
			this.#currentQuery.addObserver(this);
			if (shouldFetchOnMount(this.#currentQuery, this.options)) this.#executeFetch();
			else this.updateResult();
			this.#updateTimers();
		}
	}
	onUnsubscribe() {
		if (!this.hasListeners()) this.destroy();
	}
	/**
	* Returns whether the observed query is currently stale and configured
	* (via the `refetchOnReconnect` option) to refetch when the network
	* reconnects.
	*/
	shouldFetchOnReconnect() {
		return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnReconnect);
	}
	/**
	* Returns whether the observed query is currently stale and configured
	* (via the `refetchOnWindowFocus` option) to refetch when the window
	* regains focus.
	*/
	shouldFetchOnWindowFocus() {
		return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnWindowFocus);
	}
	/**
	* Stops observing the current query: clears all listeners, cancels the
	* stale and refetch-interval timers, and removes this observer from the
	* query it was observing.
	*/
	destroy() {
		this.listeners = /* @__PURE__ */ new Set();
		this.#clearStaleTimeout();
		this.#clearRefetchInterval();
		this.#currentQuery.removeObserver(this);
	}
	/**
	* Updates the observer's options. This will re-resolve the query being
	* observed (switching to a different query if the `queryKey` changed),
	* trigger a fetch if the new options require one and the observer has
	* subscribers, recompute the current result, and reschedule the stale and
	* refetch-interval timers as needed.
	*
	* @example
	* ```ts
	* observer.setOptions({ queryKey: ['posts', 1], queryFn: () => fetchPost(1) })
	* // later: switch to a different query, reusing the same observer
	* observer.setOptions({ queryKey: ['posts', 2], queryFn: () => fetchPost(2) })
	* ```
	*/
	setOptions(options) {
		const prevOptions = this.options;
		const prevQuery = this.#currentQuery;
		this.options = this.#client.defaultQueryOptions(options);
		if (this.options.enabled !== void 0 && typeof this.options.enabled !== "boolean" && typeof this.options.enabled !== "function" && typeof resolveQueryValue(this.options.enabled, this.#currentQuery) !== "boolean") throw new Error("Expected enabled to be a boolean or a callback that returns a boolean");
		this.#updateQuery();
		this.#currentQuery.setOptions(this.options);
		if (prevOptions._defaulted && !shallowEqualObjects(this.options, prevOptions)) this.#client.getQueryCache().notify({
			type: "observerOptionsUpdated",
			query: this.#currentQuery,
			observer: this
		});
		const mounted = this.hasListeners();
		if (mounted && shouldFetchOptionally(this.#currentQuery, prevQuery, this.options, prevOptions)) this.#executeFetch();
		this.updateResult();
		if (mounted && (this.#currentQuery !== prevQuery || resolveQueryValue(this.options.enabled, this.#currentQuery) !== resolveQueryValue(prevOptions.enabled, this.#currentQuery) || resolveQueryValue(this.options.staleTime, this.#currentQuery) !== resolveQueryValue(prevOptions.staleTime, this.#currentQuery))) this.#updateStaleTimeout();
		const nextRefetchInterval = this.#computeRefetchInterval();
		if (mounted && (this.#currentQuery !== prevQuery || resolveQueryValue(this.options.enabled, this.#currentQuery) !== resolveQueryValue(prevOptions.enabled, this.#currentQuery) || nextRefetchInterval !== this.#currentRefetchInterval)) this.#updateRefetchInterval(nextRefetchInterval);
	}
	/**
	* Computes the result the observer would produce for the given (already-defaulted) options
	* right now, building the underlying `Query` if it doesn't exist yet, without waiting for a
	* subscription callback. Called by framework adapters on every render (e.g. `useQuery`) so the
	* returned value is available synchronously, ahead of `setOptions` triggering an actual fetch.
	*/
	getOptimisticResult(options) {
		const query = this.#client.getQueryCache().build(this.#client, options);
		const result = this.createResult(query, options);
		if (!shallowEqualObjects(this.getCurrentResult(), result)) {
			this.#currentResult = result;
			this.#currentResultOptions = this.options;
			this.#currentResultState = this.#currentQuery.state;
		}
		return result;
	}
	/**
	* Returns the most recently computed `QueryObserverResult` for the
	* observed query. This is a point-in-time read; to be notified of updates
	* as they happen, subscribe to the observer instead (its inherited
	* `subscribe` method).
	*
	* @example
	* ```ts
	* const result = observer.getCurrentResult()
	* console.log(result.status, result.data)
	* ```
	*/
	getCurrentResult() {
		return this.#currentResult;
	}
	/**
	* Wraps a `QueryObserverResult` in a `Proxy` that records which properties are read, via
	* {@link QueryObserver#trackProp} (and an optional `onPropTracked` callback). Used by framework
	* adapters when `notifyOnChangeProps` is not set, to implement its default "only re-render on
	* properties you actually read" behavior.
	*/
	trackResult(result, onPropTracked) {
		return new Proxy(result, { get: (target, key) => {
			this.trackProp(key);
			onPropTracked?.(key);
			return Reflect.get(target, key);
		} });
	}
	/**
	* Records that the given `QueryObserverResult` property was read, so a subsequent update only
	* notifies this observer if a tracked property actually changed. Normally called indirectly via
	* {@link QueryObserver#trackResult}'s proxy; exposed directly for adapters that track property
	* access themselves (e.g. through their own reactivity system) instead of via the proxy.
	*/
	trackProp(key) {
		this.#trackedProps.add(key);
	}
	/**
	* Returns the `Query` instance this observer is currently observing.
	*/
	getCurrentQuery() {
		return this.#currentQuery;
	}
	/**
	* Refetches the observed query and returns a promise that resolves with
	* the resulting `QueryObserverResult`.
	*
	* @example
	* ```ts
	* const result = await observer.refetch({ cancelRefetch: false })
	* console.log(result.data)
	* ```
	*/
	refetch({ ...options } = {}) {
		return this.fetch({ ...options });
	}
	/**
	* Fetches a query defined by the given options without affecting this
	* observer's own tracked query or result, and returns a promise that
	* resolves with the `QueryObserverResult` for that fetch. This is useful
	* for prefetching data that another observer (e.g. a query about to be
	* navigated to) will need, ahead of time.
	*
	* @example
	* ```ts
	* const result = await observer.fetchOptimistic({
	*   queryKey: ['posts', 2],
	*   queryFn: () => fetchPost(2),
	* })
	* console.log(result.data)
	* ```
	*/
	fetchOptimistic(options) {
		const defaultedOptions = this.#client.defaultQueryOptions(options);
		const query = this.#client.getQueryCache().build(this.#client, defaultedOptions);
		let unsubscribe = () => {};
		let resolveEarly;
		const cachePromise = new Promise((resolve) => {
			resolveEarly = resolve;
			unsubscribe = this.#client.getQueryCache().subscribe((event) => {
				if (event.type === "updated" && event.query.queryHash === query.queryHash && query.state.data !== void 0) {
					unsubscribe();
					resolve(this.createResult(query, defaultedOptions));
				}
			});
		});
		return Promise.race([query.fetch().then(() => {
			const result = this.createResult(query, defaultedOptions);
			resolveEarly?.(result);
			return result;
		}).finally(() => {
			unsubscribe();
		}), cachePromise]);
	}
	fetch(fetchOptions) {
		return this.#executeFetch({
			...fetchOptions,
			cancelRefetch: fetchOptions.cancelRefetch ?? true
		}).then(() => {
			this.updateResult();
			return this.#currentResult;
		});
	}
	#executeFetch(fetchOptions) {
		this.#updateQuery();
		let promise = this.#currentQuery.fetch(this.options, fetchOptions);
		if (!fetchOptions?.throwOnError) promise = promise.catch(noop);
		return promise;
	}
	#shouldScheduleTimer(timeout) {
		return !isServer$1() && resolveQueryValue(this.options.enabled, this.#currentQuery) !== false && isValidTimeout(timeout);
	}
	#updateStaleTimeout() {
		this.#clearStaleTimeout();
		const staleTime = resolveQueryValue(this.options.staleTime, this.#currentQuery);
		if (this.#currentResult.isStale || !this.#shouldScheduleTimer(staleTime)) return;
		const timeout = timeUntilStale(this.#currentResult.dataUpdatedAt, staleTime) + 1;
		this.#staleTimeoutId = timeoutManager.setTimeout(() => {
			if (!this.#currentResult.isStale) this.updateResult();
		}, timeout);
	}
	#computeRefetchInterval() {
		return resolveQueryValue(this.options.refetchInterval, this.#currentQuery) ?? false;
	}
	#updateRefetchInterval(nextInterval) {
		this.#clearRefetchInterval();
		this.#currentRefetchInterval = nextInterval;
		if (this.#currentRefetchInterval === 0 || !this.#shouldScheduleTimer(this.#currentRefetchInterval)) return;
		this.#refetchIntervalId = timeoutManager.setInterval(() => {
			if (this.options.refetchIntervalInBackground || focusManager.isFocused()) this.#executeFetch();
		}, this.#currentRefetchInterval);
	}
	#updateTimers() {
		this.#updateStaleTimeout();
		this.#updateRefetchInterval(this.#computeRefetchInterval());
	}
	#clearStaleTimeout() {
		if (this.#staleTimeoutId !== void 0) {
			timeoutManager.clearTimeout(this.#staleTimeoutId);
			this.#staleTimeoutId = void 0;
		}
	}
	#clearRefetchInterval() {
		if (this.#refetchIntervalId !== void 0) {
			timeoutManager.clearInterval(this.#refetchIntervalId);
			this.#refetchIntervalId = void 0;
		}
	}
	createResult(query, options) {
		const prevQuery = this.#currentQuery;
		const prevOptions = this.options;
		const prevResult = this.#currentResult;
		const prevResultState = this.#currentResultState;
		const prevResultOptions = this.#currentResultOptions;
		const queryInitialState = query !== prevQuery ? query.state : this.#currentQueryInitialState;
		const { state } = query;
		let newState = { ...state };
		let isPlaceholderData = false;
		let data;
		if (options._optimisticResults) {
			const mounted = this.hasListeners();
			const fetchOnMount = !mounted && shouldFetchOnMount(query, options);
			const fetchOptionally = mounted && shouldFetchOptionally(query, prevQuery, options, prevOptions);
			if (fetchOnMount || fetchOptionally) newState = {
				...newState,
				...fetchState(state.data, query.options)
			};
			if (options._optimisticResults === "isRestoring") newState.fetchStatus = "idle";
		}
		let { error, errorUpdatedAt, status } = newState;
		data = newState.data;
		let skipSelect = false;
		if (options.placeholderData !== void 0 && data === void 0 && status === "pending") {
			let placeholderData;
			if (prevResult?.isPlaceholderData && options.placeholderData === prevResultOptions?.placeholderData) {
				placeholderData = prevResult.data;
				skipSelect = true;
			} else placeholderData = typeof options.placeholderData === "function" ? options.placeholderData(this.#lastQueryWithDefinedData?.state.data, this.#lastQueryWithDefinedData) : options.placeholderData;
			if (placeholderData !== void 0) {
				status = "success";
				data = replaceData(prevResult?.data, placeholderData, options);
				isPlaceholderData = true;
			}
		}
		if (options.select && data !== void 0 && !skipSelect) {
			if (prevResult && data === prevResultState?.data && options.select === this.#selectFn) data = this.#selectResult;
			else try {
				this.#selectFn = options.select;
				data = options.select(data);
				data = replaceData(prevResult?.data, data, options);
				this.#selectResult = data;
				this.#selectError = null;
			} catch (selectError) {
				this.#selectError = selectError;
			}
		} else if (data === void 0) this.#selectError = null;
		if (this.#selectError) {
			error = this.#selectError;
			data = this.#selectResult;
			errorUpdatedAt = Date.now();
			status = "error";
			isPlaceholderData = false;
		}
		const isFetching = newState.fetchStatus === "fetching";
		const isPending = status === "pending";
		const isError = status === "error";
		const isLoading = isPending && isFetching;
		const hasData = data !== void 0;
		return {
			status,
			fetchStatus: newState.fetchStatus,
			isPending,
			isSuccess: status === "success",
			isError,
			isInitialLoading: isLoading,
			isLoading,
			data,
			dataUpdatedAt: newState.dataUpdatedAt,
			error,
			errorUpdatedAt,
			failureCount: newState.fetchFailureCount,
			failureReason: newState.fetchFailureReason,
			errorUpdateCount: newState.errorUpdateCount,
			isFetched: query.isFetched(),
			isFetchedAfterMount: newState.dataUpdateCount > queryInitialState.dataUpdateCount || newState.errorUpdateCount > queryInitialState.errorUpdateCount,
			isFetching,
			isRefetching: isFetching && !isPending,
			isLoadingError: isError && !hasData,
			isPaused: newState.fetchStatus === "paused",
			isPlaceholderData,
			isRefetchError: isError && hasData,
			isStale: isStale(query, options),
			refetch: this.refetch,
			isEnabled: resolveQueryValue(options.enabled, query) !== false
		};
	}
	/**
	* Recomputes and stores the current result from the current query/options, notifying listeners
	* if it changed. Framework adapters call this right after subscribing to make sure no query
	* update was missed in the gap between creating the observer and subscribing to it.
	*/
	updateResult() {
		const prevResult = this.#currentResult;
		const nextResult = this.createResult(this.#currentQuery, this.options);
		this.#currentResultState = this.#currentQuery.state;
		this.#currentResultOptions = this.options;
		if (this.#currentResultState.data !== void 0) this.#lastQueryWithDefinedData = this.#currentQuery;
		if (shallowEqualObjects(nextResult, prevResult)) return;
		this.#currentResult = nextResult;
		const shouldNotifyListeners = () => {
			if (!prevResult) return true;
			const { notifyOnChangeProps } = this.options;
			const notifyOnChangePropsValue = typeof notifyOnChangeProps === "function" ? notifyOnChangeProps() : notifyOnChangeProps;
			if (notifyOnChangePropsValue === "all" || !notifyOnChangePropsValue && !this.#trackedProps.size) return true;
			const includedProps = new Set(notifyOnChangePropsValue ?? this.#trackedProps);
			if (this.options.throwOnError) includedProps.add("error");
			return Object.keys(this.#currentResult).some((key) => {
				const typedKey = key;
				return this.#currentResult[typedKey] !== prevResult[typedKey] && includedProps.has(typedKey);
			});
		};
		const notifyListeners = shouldNotifyListeners();
		notifyManager.batch(() => {
			if (notifyListeners) this.listeners.forEach((listener) => {
				listener(this.#currentResult);
			});
			this.#client.getQueryCache().notify({
				query: this.#currentQuery,
				type: "observerResultsUpdated"
			});
		});
	}
	#updateQuery() {
		const query = this.#client.getQueryCache().build(this.#client, this.options);
		if (query === this.#currentQuery) return;
		const prevQuery = this.#currentQuery;
		this.#currentQuery = query;
		this.#currentQueryInitialState = query.state;
		if (this.hasListeners()) {
			prevQuery?.removeObserver(this);
			query.addObserver(this);
		}
	}
	/** @internal */
	onQueryUpdate() {
		this.updateResult();
		if (this.hasListeners()) this.#updateTimers();
	}
};
function shouldLoadOnMount(query, options) {
	return resolveQueryValue(options.enabled, query) !== false && query.state.data === void 0 && !(query.state.status === "error" && resolveQueryValue(options.retryOnMount, query) === false);
}
function shouldFetchOnMount(query, options) {
	return shouldLoadOnMount(query, options) || query.state.data !== void 0 && shouldFetchOn(query, options, options.refetchOnMount);
}
function shouldFetchOn(query, options, field) {
	if (resolveQueryValue(options.enabled, query) !== false && resolveQueryValue(options.staleTime, query) !== "static") {
		const value = resolveQueryValue(field, query);
		return value === "always" || value !== false && isStale(query, options);
	}
	return false;
}
function shouldFetchOptionally(query, prevQuery, options, prevOptions) {
	return (query !== prevQuery || resolveQueryValue(prevOptions.enabled, query) === false) && (!options.suspense || query.state.status !== "error") && isStale(query, options);
}
function isStale(query, options) {
	return resolveQueryValue(options.enabled, query) !== false && query.isStaleByTime(resolveQueryValue(options.staleTime, query));
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/infiniteQueryObserver.js
/**
* An `InfiniteQueryObserver` extends `QueryObserver` to observe and switch
* between infinite queries. It augments the base `QueryObserverResult` with
* infinite-query-specific fields and methods, such as `hasNextPage` and
* `fetchNextPage`, and is the primitive that framework adapters (e.g.
* `useInfiniteQuery`) build their hooks on top of.
*
* @example
* ```ts
* const observer = new InfiniteQueryObserver(queryClient, {
*   queryKey: ['projects'],
*   queryFn: ({ pageParam }) => fetchProjects(pageParam),
*   initialPageParam: 0,
*   getNextPageParam: (lastPage) => lastPage.nextCursor,
* })
*
* const unsubscribe = observer.subscribe((result) => console.log(result))
* ```
*/
var InfiniteQueryObserver = class extends QueryObserver {
	constructor(client, options) {
		super(client, options);
	}
	bindMethods() {
		super.bindMethods();
		this.fetchNextPage = this.fetchNextPage.bind(this);
		this.fetchPreviousPage = this.fetchPreviousPage.bind(this);
	}
	/**
	* Updates the observer's options. Behaves the same as
	* `QueryObserver.setOptions`, additionally marking the options as
	* belonging to an infinite query before delegating to the base
	* implementation.
	*/
	setOptions(options) {
		options._type = "infinite";
		super.setOptions(options);
	}
	/**
	* The infinite-query counterpart of {@link QueryObserver#getOptimisticResult}, marking the
	* options as an infinite query before delegating to it. Called by framework adapters (e.g.
	* `useInfiniteQuery`) ahead of subscribing, to compute the current `InfiniteQueryObserverResult`
	* synchronously.
	*/
	getOptimisticResult(options) {
		options._type = "infinite";
		return super.getOptimisticResult(options);
	}
	/**
	* Fetches the next page of the infinite query and returns a promise that
	* resolves with the resulting `InfiniteQueryObserverResult`. The page
	* param used for the fetch is determined by `getNextPageParam`, which
	* receives the current pages/page params and whose result also determines
	* `hasNextPage`.
	*
	* @example
	* ```ts
	* const { hasNextPage } = observer.getCurrentResult()
	*
	* if (hasNextPage) {
	*   await observer.fetchNextPage()
	* }
	* ```
	*
	* @see {@link InfiniteQueryObserver#fetchPreviousPage}
	*/
	fetchNextPage(options) {
		return this.fetch({
			...options,
			meta: { fetchMore: { direction: "forward" } }
		});
	}
	/**
	* Fetches the previous page of the infinite query and returns a promise
	* that resolves with the resulting `InfiniteQueryObserverResult`. The page
	* param used for the fetch is determined by `getPreviousPageParam`, which
	* receives the current pages/page params and whose result also determines
	* `hasPreviousPage`.
	*
	* @example
	* ```ts
	* const { hasPreviousPage } = observer.getCurrentResult()
	*
	* if (hasPreviousPage) {
	*   await observer.fetchPreviousPage()
	* }
	* ```
	*
	* @see {@link InfiniteQueryObserver#fetchNextPage}
	*/
	fetchPreviousPage(options) {
		return this.fetch({
			...options,
			meta: { fetchMore: { direction: "backward" } }
		});
	}
	createResult(query, options) {
		const { state } = query;
		const parentResult = super.createResult(query, options);
		const { isFetching, isRefetching, isError, isRefetchError } = parentResult;
		const fetchDirection = state.fetchMeta?.fetchMore?.direction;
		const isFetchNextPageError = isError && fetchDirection === "forward";
		const isFetchingNextPage = isFetching && fetchDirection === "forward";
		const isFetchPreviousPageError = isError && fetchDirection === "backward";
		const isFetchingPreviousPage = isFetching && fetchDirection === "backward";
		return {
			...parentResult,
			fetchNextPage: this.fetchNextPage,
			fetchPreviousPage: this.fetchPreviousPage,
			hasNextPage: hasNextPage(options, state.data),
			hasPreviousPage: hasPreviousPage(options, state.data),
			isFetchNextPageError,
			isFetchingNextPage,
			isFetchPreviousPageError,
			isFetchingPreviousPage,
			isRefetchError: isRefetchError && !isFetchNextPageError && !isFetchPreviousPageError,
			isRefetching: isRefetching && !isFetchingNextPage && !isFetchingPreviousPage
		};
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutation.js
/**
* Represents a single mutation attempt. A `Mutation` holds the mutation's
* options, state (data/error/status), and the `MutationObserver`s currently
* subscribed to it.
*
* Instances are created and managed internally by `MutationCache`; application
* code typically interacts with mutations indirectly through `QueryClient` or
* a framework hook like `useMutation`. Direct access to a `Mutation` instance
* is possible via `mutationCache.find()`/`getAll()` for inspecting cache state.
*
* @example
* ```ts
* const mutationCache = queryClient.getMutationCache()
*
* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
* ```
*/
var Mutation = class extends Removable {
	#client;
	#observers;
	#mutationCache;
	#retryer;
	constructor(config) {
		super();
		this.#client = config.client;
		this.mutationId = config.mutationId;
		this.#mutationCache = config.mutationCache;
		this.#observers = [];
		this.state = config.state || getDefaultState();
		this.setOptions(config.options);
		this.scheduleGc();
	}
	/** @internal */
	setOptions(options) {
		this.options = options;
		this.updateGcTime(this.options.gcTime);
	}
	/**
	* The `meta` object passed in the mutation's options, if any.
	*/
	get meta() {
		return this.options.meta;
	}
	/** @internal */
	addObserver(observer) {
		if (!this.#observers.includes(observer)) {
			this.#observers.push(observer);
			this.clearGcTimeout();
			this.#mutationCache.notify({
				type: "observerAdded",
				mutation: this,
				observer
			});
		}
	}
	/** @internal */
	removeObserver(observer) {
		this.#observers = this.#observers.filter((x) => x !== observer);
		this.scheduleGc();
		this.#mutationCache.notify({
			type: "observerRemoved",
			mutation: this,
			observer
		});
	}
	optionalRemove() {
		if (!this.#observers.length) {
			if (this.state.status === "pending") this.scheduleGc();
			else this.#mutationCache.remove(this);
		}
	}
	/**
	* Resumes a mutation that is currently paused or was restored from a
	* dehydrated, still-`pending` state.
	*
	* - If this mutation has an active retryer (it paused mid-attempt, e.g. due
	*   to the network mode or scope-based queuing), its retryer is resumed.
	* - Otherwise, if the mutation's status is still `pending` (e.g. it was
	*   dehydrated while an attempt was in flight and never got a retryer in
	*   this instance), `execute` is called again with the last known variables.
	* - Otherwise the mutation has already settled and this resolves immediately
	*   without running anything again.
	*
	* @example
	* ```ts
	* // typically driven by reconnect handling, e.g. queryClient.resumePausedMutations()
	* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
	* await mutation?.continue()
	* ```
	*
	* @see {@link Mutation#execute}
	*/
	continue() {
		return this.#retryer?.continue() ?? (this.state.status === "pending" ? this.execute(this.state.variables) : Promise.resolve());
	}
	/**
	* Runs the mutation function for the given variables through a retryer, and
	* drives the mutation's state and lifecycle callbacks through to settlement.
	*
	* If this mutation's state is already `pending` when `execute` is called
	* (i.e. it was restored, still in-flight, from a dehydrated state), the
	* `onMutate` step is skipped and a `continue` action is dispatched to
	* unpause it; otherwise a `pending` action is dispatched first, then the
	* mutation cache's `onMutate` and the mutation's own `onMutate` option are
	* awaited in that order, and the resulting context is stored.
	*
	* The mutation function is then run (subject to `retry`/`retryDelay`/
	* `networkMode`, and to the mutation cache's scope-based serialization).
	* On success, the cache's `onSuccess`/`onSettled` callbacks run before the
	* mutation's own `onSuccess`/`onSettled` options, a `success` action is
	* dispatched, and the resolved data is returned. On failure, the same
	* cache-then-option ordering is used for `onError`/`onSettled`, but each of
	* those four callbacks is individually caught so that a throwing callback
	* cannot mask the original error; an `error` action is then dispatched and
	* the original error is re-thrown.
	*
	* @example
	* ```ts
	* // Called internally by `MutationObserver.mutate` and `Mutation.continue` —
	* // applications normally trigger mutations through those, not this method.
	* const data = await mutation.execute(variables)
	* ```
	*
	* @see {@link Mutation#continue}
	*/
	async execute(variables) {
		const onContinue = () => {
			this.#dispatch({ type: "continue" });
		};
		const mutationFnContext = {
			client: this.#client,
			meta: this.options.meta,
			mutationKey: this.options.mutationKey
		};
		const retryer = this.#retryer = createRetryer({
			fn: () => {
				if (!this.options.mutationFn) return Promise.reject(/* @__PURE__ */ new Error("No mutationFn found"));
				return this.options.mutationFn(variables, mutationFnContext);
			},
			onFail: (failureCount, error) => {
				this.#dispatch({
					type: "failed",
					failureCount,
					error
				});
			},
			onPause: () => {
				this.#dispatch({ type: "pause" });
			},
			onContinue,
			retry: this.options.retry ?? 0,
			retryDelay: this.options.retryDelay,
			networkMode: this.options.networkMode,
			canRun: () => this.#mutationCache.canRun(this)
		});
		const restored = this.state.status === "pending";
		const isPaused = !retryer.canStart();
		try {
			if (restored) onContinue();
			else {
				this.#dispatch({
					type: "pending",
					variables,
					isPaused
				});
				if (this.#mutationCache.config.onMutate) await this.#mutationCache.config.onMutate(variables, this, mutationFnContext);
				const context = await this.options.onMutate?.(variables, mutationFnContext);
				if (context !== this.state.context) this.#dispatch({
					type: "pending",
					context,
					variables,
					isPaused
				});
			}
			const data = await retryer.start();
			await this.#mutationCache.config.onSuccess?.(data, variables, this.state.context, this, mutationFnContext);
			await this.options.onSuccess?.(data, variables, this.state.context, mutationFnContext);
			await this.#mutationCache.config.onSettled?.(data, null, this.state.variables, this.state.context, this, mutationFnContext);
			await this.options.onSettled?.(data, null, variables, this.state.context, mutationFnContext);
			this.#dispatch({
				type: "success",
				data
			});
			return data;
		} catch (error) {
			try {
				await this.#mutationCache.config.onError?.(error, variables, this.state.context, this, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.options.onError?.(error, variables, this.state.context, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.#mutationCache.config.onSettled?.(void 0, error, this.state.variables, this.state.context, this, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.options.onSettled?.(void 0, error, variables, this.state.context, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			this.#dispatch({
				type: "error",
				error
			});
			throw error;
		} finally {
			if (this.#retryer === retryer) this.#retryer = void 0;
			this.#mutationCache.runNext(this);
		}
	}
	#dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return {
					...state,
					failureCount: action.failureCount,
					failureReason: action.error
				};
				case "pause": return {
					...state,
					isPaused: true
				};
				case "continue": return {
					...state,
					isPaused: false
				};
				case "pending": return {
					...state,
					context: action.context,
					data: void 0,
					failureCount: 0,
					failureReason: null,
					error: null,
					isPaused: action.isPaused,
					status: "pending",
					variables: action.variables,
					submittedAt: Date.now()
				};
				case "success": return {
					...state,
					data: action.data,
					failureCount: 0,
					failureReason: null,
					error: null,
					status: "success",
					isPaused: false
				};
				case "error": return {
					...state,
					data: void 0,
					error: action.error,
					failureCount: state.failureCount + 1,
					failureReason: action.error,
					isPaused: false,
					status: "error"
				};
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.#observers.forEach((observer) => {
				observer.onMutationUpdate(action);
			});
			this.#mutationCache.notify({
				mutation: this,
				type: "updated",
				action
			});
		});
	}
};
function getDefaultState() {
	return {
		context: void 0,
		data: void 0,
		error: null,
		failureCount: 0,
		failureReason: null,
		isPaused: false,
		status: "idle",
		variables: void 0,
		submittedAt: 0
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutationCache.js
/**
* The `MutationCache` is the storage for mutations.
*
* Normally, you will not interact with the `MutationCache` directly and instead use a
* `QueryClient`. You can subscribe to it (inherited from `Subscribable`) to be informed of
* safe/known updates to the cache, such as mutations being added, removed, or updated.
*
* @example
* ```ts
* const unsubscribe = mutationCache.subscribe((event) => {
*   console.log(event.type, event.mutation)
* })
* ```
*/
var MutationCache = class extends Subscribable {
	#mutations;
	#scopes;
	#mutationId;
	constructor(config = {}) {
		super();
		this.config = config;
		this.#mutations = /* @__PURE__ */ new Set();
		this.#scopes = /* @__PURE__ */ new Map();
		this.#mutationId = 0;
	}
	/** @internal */
	build(client, options, state) {
		const mutation = new Mutation({
			client,
			mutationCache: this,
			mutationId: ++this.#mutationId,
			options: client.defaultMutationOptions(options),
			state
		});
		this.add(mutation);
		return mutation;
	}
	/** @internal */
	add(mutation) {
		this.#mutations.add(mutation);
		const scope = scopeFor(mutation);
		if (typeof scope === "string") {
			const scopedMutations = this.#scopes.get(scope);
			if (scopedMutations) scopedMutations.push(mutation);
			else this.#scopes.set(scope, [mutation]);
		}
		this.notify({
			type: "added",
			mutation
		});
	}
	/** @internal */
	remove(mutation) {
		if (this.#mutations.delete(mutation)) {
			const scope = scopeFor(mutation);
			if (typeof scope === "string") {
				const scopedMutations = this.#scopes.get(scope);
				if (scopedMutations) {
					if (scopedMutations.length > 1) {
						const index = scopedMutations.indexOf(mutation);
						if (index !== -1) scopedMutations.splice(index, 1);
					} else if (scopedMutations[0] === mutation) this.#scopes.delete(scope);
				}
			}
		}
		this.notify({
			type: "removed",
			mutation
		});
	}
	/** @internal */
	canRun(mutation) {
		const scope = scopeFor(mutation);
		if (typeof scope === "string") {
			const firstPendingMutation = this.#scopes.get(scope)?.find((m) => m.state.status === "pending");
			return !firstPendingMutation || firstPendingMutation === mutation;
		} else return true;
	}
	/** @internal */
	runNext(mutation) {
		const scope = scopeFor(mutation);
		if (typeof scope === "string") return (this.#scopes.get(scope)?.find((m) => m !== mutation && m.state.isPaused))?.continue() ?? Promise.resolve();
		else return Promise.resolve();
	}
	/**
	* Removes all mutations from the cache.
	*
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* mutationCache.clear()
	* ```
	*/
	clear() {
		notifyManager.batch(() => {
			this.#mutations.forEach((mutation) => {
				this.notify({
					type: "removed",
					mutation
				});
			});
			this.#mutations.clear();
			this.#scopes.clear();
		});
	}
	/**
	* Returns all mutations within the cache.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about a mutation in rare scenarios.
	*
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* const mutations = mutationCache.getAll()
	* ```
	*/
	getAll() {
		return Array.from(this.#mutations);
	}
	/**
	* A slightly more advanced method that can be used to get an existing mutation instance from
	* the cache. If the mutation does not exist, `undefined` is returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about a mutation in rare scenarios.
	*
	* @see {@link MutationCache#findAll}
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
	* ```
	*/
	find(filters) {
		const defaultedFilters = {
			exact: true,
			...filters
		};
		return this.getAll().find((mutation) => matchMutation(defaultedFilters, mutation));
	}
	/**
	* An even more advanced method that can be used to get existing mutation instances from the
	* cache that match the given filters. If no mutations match, an empty array is returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about mutations in rare scenarios.
	*
	* @see {@link MutationCache#find}
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* const mutations = mutationCache.findAll({ mutationKey: ['addPost'] })
	* ```
	*/
	findAll(filters = {}) {
		return this.getAll().filter((mutation) => matchMutation(filters, mutation));
	}
	/** @internal */
	notify(event) {
		notifyManager.batch(() => {
			this.listeners.forEach((listener) => {
				listener(event);
			});
		});
	}
	/** @internal */
	resumePausedMutations() {
		const pausedMutations = this.getAll().filter((x) => x.state.isPaused);
		return notifyManager.batch(() => Promise.all(pausedMutations.map((mutation) => mutation.continue().catch(noop))));
	}
};
function scopeFor(mutation) {
	return mutation.options.scope?.id;
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutationObserver.js
/**
* Observes a single mutation and derives a `MutationObserverResult` from it.
* A framework hook like `useMutation` creates one `MutationObserver` per hook
* call, keeps it stable across re-renders, calls `setOptions` when the options
* passed to the hook change, subscribes to it to re-render on updates, and
* reads `getCurrentResult()` for the value to return. Calling `mutate()`
* builds a new underlying `Mutation` in the `MutationCache` and executes it.
*
* @example
* ```ts
* const observer = new MutationObserver(queryClient, {
*   mutationFn: (variables: { title: string }) => addPost(variables),
* })
* ```
*/
var MutationObserver = class extends Subscribable {
	#client;
	#currentResult = void 0;
	#currentMutation;
	#mutateOptions;
	constructor(client, options) {
		super();
		this.#client = client;
		this.setOptions(options);
		this.bindMethods();
		this.#updateResult();
	}
	bindMethods() {
		this.mutate = this.mutate.bind(this);
		this.reset = this.reset.bind(this);
	}
	/**
	* Updates the observer's options.
	*
	* If the new `mutationKey` differs from the previous one (and both were
	* defined), the observer is reset, detaching it from the mutation it was
	* observing. Otherwise, if the currently observed mutation is still
	* `pending`, its options are updated in place as well.
	*
	* @example
	* ```ts
	* observer.setOptions({
	*   mutationFn: (variables: { title: string }) => addPost(variables),
	*   onSuccess: (data) => console.log(data),
	* })
	* ```
	*/
	setOptions(options) {
		const prevOptions = this.options;
		this.options = this.#client.defaultMutationOptions(options);
		if (!shallowEqualObjects(this.options, prevOptions)) this.#client.getMutationCache().notify({
			type: "observerOptionsUpdated",
			mutation: this.#currentMutation,
			observer: this
		});
		if (prevOptions?.mutationKey && this.options.mutationKey && hashKey(prevOptions.mutationKey) !== hashKey(this.options.mutationKey)) this.reset();
		else if (this.#currentMutation?.state.status === "pending") this.#currentMutation.setOptions(this.options);
	}
	onSubscribe() {
		if (this.listeners.size === 1 && this.#currentMutation) {
			this.#currentMutation.addObserver(this);
			this.#updateResult();
		}
	}
	onUnsubscribe() {
		if (!this.hasListeners()) this.#currentMutation?.removeObserver(this);
	}
	/** @internal */
	onMutationUpdate(action) {
		this.#updateResult();
		this.#notify(action);
	}
	/**
	* Returns the observer's current result, derived from the observed
	* mutation's state (or the default, `idle` state if no mutation has been
	* built yet, e.g. before the first `mutate()` call or after `reset()`).
	*/
	getCurrentResult() {
		return this.#currentResult;
	}
	/**
	* Detaches the observer from the mutation it is currently observing (if
	* any) and resets the observed result back to its default, `idle` state.
	*
	* This does not cancel an in-flight mutation; the mutation itself keeps
	* running to completion and its own callbacks still fire, but this
	* observer stops reflecting its state and a subsequent `mutate()` call
	* will build a brand new mutation.
	*
	* @example
	* ```ts
	* observer.reset()
	* ```
	*
	* @see {@link MutationObserver#mutate}
	*/
	reset() {
		this.#currentMutation?.removeObserver(this);
		this.#currentMutation = void 0;
		this.#updateResult();
		this.#notify();
	}
	/**
	* Builds a new `Mutation` in the `MutationCache` using the observer's
	* current options, detaches this observer from any previously observed
	* mutation, attaches it to the new one, and executes it with the given
	* variables.
	*
	* The optional per-call `options` (`onSuccess`/`onError`/`onSettled`) are
	* invoked once the mutation settles, in addition to any callbacks defined
	* on the observer's own options.
	*
	* @example
	* ```ts
	* await observer.mutate(
	*   { title: 'New post' },
	*   { onSuccess: (data) => console.log(data) },
	* )
	* ```
	*/
	mutate(variables, options) {
		this.#mutateOptions = options;
		this.#currentMutation?.removeObserver(this);
		this.#currentMutation = this.#client.getMutationCache().build(this.#client, this.options);
		this.#currentMutation.addObserver(this);
		return this.#currentMutation.execute(variables);
	}
	#updateResult() {
		const state = this.#currentMutation?.state ?? getDefaultState();
		this.#currentResult = {
			...state,
			isPending: state.status === "pending",
			isSuccess: state.status === "success",
			isError: state.status === "error",
			isIdle: state.status === "idle",
			mutate: this.mutate,
			reset: this.reset
		};
	}
	#notify(action) {
		notifyManager.batch(() => {
			if (this.#mutateOptions && this.hasListeners()) {
				const variables = this.#currentResult.variables;
				const onMutateResult = this.#currentResult.context;
				const context = {
					client: this.#client,
					meta: this.options.meta,
					mutationKey: this.options.mutationKey
				};
				if (action?.type === "success") {
					try {
						this.#mutateOptions.onSuccess?.(action.data, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						this.#mutateOptions.onSettled?.(action.data, null, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				} else if (action?.type === "error") {
					try {
						this.#mutateOptions.onError?.(action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						this.#mutateOptions.onSettled?.(void 0, action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				}
			}
			this.listeners.forEach((listener) => {
				listener(this.#currentResult);
			});
		});
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queriesObserver.js
function difference(array1, array2) {
	const excludeSet = new Set(array2);
	return array1.filter((x) => !excludeSet.has(x));
}
/**
* A `QueriesObserver` watches an array of queries at once, exposing them as
* a single array of `QueryObserverResult`s (or, when a `combine` option is
* given, as a combined value derived from that array). It manages one
* internal `QueryObserver` per query, and is the primitive that framework
* adapters (e.g. `useQueries`) build their hooks on top of.
*
* @example
* ```ts
* const observer = new QueriesObserver(queryClient, [
*   { queryKey: ['post', 1], queryFn: fetchPost },
*   { queryKey: ['post', 2], queryFn: fetchPost },
* ])
*
* const unsubscribe = observer.subscribe((result) => {
*   console.log(result)
* })
* ```
*/
var QueriesObserver = class extends Subscribable {
	#client;
	#result;
	#queries;
	#options;
	#observers;
	#combinedResult;
	#lastCombine;
	#lastResult;
	#lastQueryHashes;
	#observerMatches = [];
	constructor(client, queries, options) {
		super();
		this.#client = client;
		this.#options = options;
		this.#queries = [];
		this.#observers = [];
		this.#result = [];
		this.setQueries(queries);
	}
	onSubscribe() {
		if (this.listeners.size === 1) this.#observers.forEach((observer) => {
			observer.subscribe((result) => {
				this.#onUpdate(observer, result);
			});
		});
	}
	onUnsubscribe() {
		if (!this.listeners.size) this.destroy();
	}
	/**
	* Stops observing all queries: clears all listeners and destroys every
	* underlying `QueryObserver` this observer manages.
	*/
	destroy() {
		this.listeners = /* @__PURE__ */ new Set();
		this.#observers.forEach((observer) => {
			observer.destroy();
		});
	}
	/**
	* Replaces the set of queries being observed. Existing `QueryObserver`s
	* are reused for queries that match an already-observed query hash;
	* observers for queries that are no longer present are destroyed, and new
	* observers are created and subscribed to for newly added queries.
	*
	* @example
	* ```ts
	* observer.setQueries([
	*   { queryKey: ['post', 1], queryFn: fetchPost },
	*   { queryKey: ['post', 3], queryFn: fetchPost },
	* ])
	* ```
	*/
	setQueries(queries, options) {
		this.#queries = queries;
		this.#options = options;
		{
			const queryHashes = queries.map((query) => this.#client.defaultQueryOptions(query).queryHash);
			if (new Set(queryHashes).size !== queryHashes.length) console.warn("[QueriesObserver]: Duplicate Queries found. This might result in unexpected behavior.");
		}
		notifyManager.batch(() => {
			const prevObservers = this.#observers;
			const newObserverMatches = this.#findMatchingObservers(this.#queries);
			newObserverMatches.forEach((match) => match.observer.setOptions(match.defaultedQueryOptions));
			const newObservers = newObserverMatches.map((match) => match.observer);
			const newResult = newObservers.map((observer) => observer.getCurrentResult());
			const hasLengthChange = prevObservers.length !== newObservers.length;
			const hasIndexChange = newObservers.some((observer, index) => observer !== prevObservers[index]);
			const hasStructuralChange = hasLengthChange || hasIndexChange;
			const hasResultChange = hasStructuralChange ? true : newResult.some((result, index) => {
				const prev = this.#result[index];
				return !prev || !shallowEqualObjects(result, prev);
			});
			if (!hasStructuralChange && !hasResultChange) return;
			if (hasStructuralChange) {
				this.#observerMatches = newObserverMatches;
				this.#observers = newObservers;
			}
			this.#result = newResult;
			if (!this.hasListeners()) return;
			if (hasStructuralChange) {
				difference(prevObservers, newObservers).forEach((observer) => {
					observer.destroy();
				});
				difference(newObservers, prevObservers).forEach((observer) => {
					observer.subscribe((result) => {
						this.#onUpdate(observer, result);
					});
				});
			}
			this.#notify();
		});
	}
	/**
	* Returns the most recently computed array of `QueryObserverResult`s, one
	* per observed query, in the same order as the queries passed to the
	* constructor or `setQueries`.
	*
	* @example
	* ```ts
	* const results = observer.getCurrentResult()
	* const data = results.map((result) => result.data)
	* ```
	*/
	getCurrentResult() {
		return this.#result;
	}
	/**
	* Returns the underlying `Query` instances currently being observed, in
	* the same order as the queries passed to the constructor or `setQueries`.
	*/
	getQueries() {
		return this.#observers.map((observer) => observer.getCurrentQuery());
	}
	/**
	* Returns the underlying `QueryObserver` instances this observer manages,
	* in the same order as the queries passed to the constructor or
	* `setQueries`.
	*/
	getObservers() {
		return this.#observers;
	}
	/**
	* The `QueriesObserver` counterpart of {@link QueryObserver#getOptimisticResult} — computes
	* the result for the given (already-defaulted) queries right now, synchronously. Called by
	* framework adapters (e.g. `useQueries`) ahead of subscribing, returning a tuple of the raw
	* per-query results, a function to compute the combined result from them, and a function to
	* wrap the results for property-access tracking.
	*/
	getOptimisticResult(queries, combine) {
		const matches = this.#findMatchingObservers(queries);
		const result = matches.map((match) => match.observer.getOptimisticResult(match.defaultedQueryOptions));
		const queryHashes = matches.map((match) => match.defaultedQueryOptions.queryHash);
		return [
			result,
			(r) => {
				return this.#combineResult(r ?? result, combine, queryHashes);
			},
			() => {
				return this.#trackResult(result, matches);
			}
		];
	}
	#trackResult(result, matches) {
		const trackedProps = /* @__PURE__ */ new Set();
		return matches.map((match, index) => {
			const observerResult = result[index];
			return !match.defaultedQueryOptions.notifyOnChangeProps ? match.observer.trackResult(observerResult, (accessedProp) => {
				if (!trackedProps.has(accessedProp)) {
					trackedProps.add(accessedProp);
					matches.forEach((m) => {
						m.observer.trackProp(accessedProp);
					});
				}
			}) : observerResult;
		});
	}
	#combineResult(input, combine, queryHashes) {
		if (combine) {
			const lastHashes = this.#lastQueryHashes;
			const queryHashesChanged = queryHashes !== void 0 && lastHashes !== void 0 && (lastHashes.length !== queryHashes.length || queryHashes.some((hash, i) => hash !== lastHashes[i]));
			if (this.#result !== this.#lastResult || queryHashesChanged || combine !== this.#lastCombine) {
				this.#lastCombine = combine;
				this.#lastResult = this.#result;
				if (queryHashes !== void 0) this.#lastQueryHashes = queryHashes;
				this.#combinedResult = replaceEqualDeep(this.#combinedResult, combine(input));
			}
			return this.#combinedResult;
		}
		return input;
	}
	#shouldSkipCombine() {
		return !this.#options?.combine || this.#observers.some((observer, index) => {
			return observer.options.suspense && this.#result[index]?.data === void 0;
		});
	}
	#findMatchingObservers(queries) {
		const prevObserversMap = /* @__PURE__ */ new Map();
		this.#observers.forEach((observer) => {
			const key = observer.options.queryHash;
			if (!key) return;
			const previousObservers = prevObserversMap.get(key);
			if (previousObservers) previousObservers.push(observer);
			else prevObserversMap.set(key, [observer]);
		});
		const observers = [];
		queries.forEach((options) => {
			const defaultedOptions = this.#client.defaultQueryOptions(options);
			const observer = prevObserversMap.get(defaultedOptions.queryHash)?.shift() ?? new QueryObserver(this.#client, defaultedOptions);
			observers.push({
				defaultedQueryOptions: defaultedOptions,
				observer
			});
		});
		return observers;
	}
	#onUpdate(observer, result) {
		const index = this.#observers.indexOf(observer);
		if (index !== -1) {
			this.#result = this.#result.slice();
			this.#result[index] = result;
			this.#notify();
		}
	}
	#notify() {
		if (this.hasListeners()) {
			const shouldSkipCombine = this.#shouldSkipCombine();
			const previousResult = this.#combinedResult;
			const newResult = shouldSkipCombine ? previousResult : this.#combineResult(this.#trackResult(this.#result, this.#observerMatches), this.#options?.combine);
			if (shouldSkipCombine || previousResult !== newResult) notifyManager.batch(() => {
				this.listeners.forEach((listener) => {
					listener(this.#result);
				});
			});
		}
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queryCache.js
/**
* The `QueryCache` is the storage mechanism for TanStack Query. It stores all the data, meta
* information, and state of the queries it contains.
*
* Normally, you will not interact with the `QueryCache` directly and instead use a `QueryClient`
* for a specific cache. You can subscribe to it (inherited from `Subscribable`) to be informed of
* safe/known updates to the cache, such as queries being added, removed, or updated — updates made
* outside of the cache's own tracked mechanisms (e.g. mutating a query's state object directly) do
* not notify subscribers.
*
* @example
* ```ts
* const unsubscribe = queryCache.subscribe((event) => {
*   console.log(event.type, event.query)
* })
* ```
*/
var QueryCache = class extends Subscribable {
	#queries;
	constructor(config = {}) {
		super();
		this.config = config;
		this.#queries = /* @__PURE__ */ new Map();
	}
	/**
	* Returns the existing `Query` instance for the given options' `queryKey`/`queryHash`, or
	* builds and adds a new one to the cache if none exists yet. Used by framework adapters and
	* plugins (e.g. broadcast/persistence) that need to get-or-create a `Query` directly, bypassing
	* the reactive `QueryObserver` machinery.
	*
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const query = queryCache.build(queryClient, {
	*   queryKey: ['posts'],
	*   queryFn: fetchPosts,
	* })
	* ```
	*/
	build(client, options, state) {
		const queryKey = options.queryKey;
		const queryHash = options.queryHash ?? hashQueryKeyByOptions(queryKey, options);
		let query = this.get(queryHash);
		if (!query) {
			query = new Query({
				client,
				queryKey,
				queryHash,
				options: client.defaultQueryOptions(options),
				state,
				defaultOptions: client.getQueryDefaults(queryKey)
			});
			this.add(query);
		}
		return query;
	}
	/** @internal */
	add(query) {
		if (!this.#queries.has(query.queryHash)) {
			this.#queries.set(query.queryHash, query);
			this.notify({
				type: "added",
				query
			});
		}
	}
	/**
	* Destroys the given `Query` and removes it from the cache, notifying subscribers with a
	* `'removed'` event. A no-op if the query is no longer the one currently stored under its hash
	* (e.g. it was already replaced). Used by plugins (e.g. the broadcast client) that mirror
	* removals across `QueryCache` instances.
	*
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	* const query = queryCache.find({ queryKey: ['posts'] })
	*
	* if (query) {
	*   queryCache.remove(query)
	* }
	* ```
	*/
	remove(query) {
		if (this.#queries.get(query.queryHash) === query) {
			query.destroy();
			this.#queries.delete(query.queryHash);
			this.notify({
				type: "removed",
				query
			});
		}
	}
	/**
	* Removes all queries from the cache.
	*
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* queryCache.clear()
	* ```
	*/
	clear() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				this.remove(query);
			});
		});
	}
	/**
	* Returns the `Query` instance stored under the given `queryHash`, or `undefined` if none
	* exists. Unlike {@link QueryCache#find}, this looks up by the already-computed hash rather
	* than by `QueryFilters`. Used by plugins (e.g. broadcast/hydration) that already have a hash
	* to look up directly.
	*
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	* const queryHash = hashKey(['posts'])
	*
	* const query = queryCache.get(queryHash)
	* ```
	*/
	get(queryHash) {
		return this.#queries.get(queryHash);
	}
	/**
	* Returns all queries within the cache.
	*
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const queries = queryCache.getAll()
	* ```
	*/
	getAll() {
		return [...this.#queries.values()];
	}
	/**
	* A slightly more advanced method that can be used to get an existing query instance from the
	* cache. This instance not only contains all the state for the query, but all of the instances,
	* and underlying guts of the query as well. If the query does not exist, `undefined` is
	* returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about a query in rare scenarios (e.g. looking at `query.state.dataUpdatedAt` to
	* decide whether a query is fresh enough to be used as an initial value).
	*
	* @see {@link QueryCache#findAll}
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const query = queryCache.find({ queryKey: ['posts'] })
	* ```
	*/
	find(filters) {
		const defaultedFilters = {
			exact: true,
			...filters
		};
		return this.getAll().find((query) => matchQuery(defaultedFilters, query));
	}
	/**
	* An even more advanced method that can be used to get existing query instances from the cache
	* that partially match a query key. If no queries match, an empty array is returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about queries in rare scenarios.
	*
	* @see {@link QueryCache#find}
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const queries = queryCache.findAll({ queryKey: ['posts'] })
	* ```
	*/
	findAll(filters = {}) {
		const queries = this.getAll();
		return Object.keys(filters).length > 0 ? queries.filter((query) => matchQuery(filters, query)) : queries;
	}
	/** @internal */
	notify(event) {
		notifyManager.batch(() => {
			this.listeners.forEach((listener) => {
				listener(event);
			});
		});
	}
	/** @internal */
	onFocus() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				query.onFocus();
			});
		});
	}
	/** @internal */
	onOnline() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				query.onOnline();
			});
		});
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queryClient.js
/**
* `QueryClient` is used to interact with a cache of queries and mutations. It owns a
* `QueryCache` and a `MutationCache` (creating default ones if none are passed in) and holds
* the default options that are applied to queries and mutations created through it.
*
* @example
* ```ts
* const queryClient = new QueryClient({
*   defaultOptions: {
*     queries: {
*       staleTime: Infinity,
*     },
*   },
* })
*
* await queryClient.query({ queryKey: ['posts'], queryFn: fetchPosts })
* ```
*/
var QueryClient = class {
	#queryCache;
	#mutationCache;
	#defaultOptions;
	#queryDefaults;
	#mutationDefaults;
	#mountCount;
	#unsubscribeFocus;
	#unsubscribeOnline;
	constructor(config = {}) {
		this.#queryCache = config.queryCache || new QueryCache();
		this.#mutationCache = config.mutationCache || new MutationCache();
		this.#defaultOptions = config.defaultOptions || {};
		this.#queryDefaults = /* @__PURE__ */ new Map();
		this.#mutationDefaults = /* @__PURE__ */ new Map();
		this.#mountCount = 0;
	}
	/**
	* Called by a framework adapter's `QueryClientProvider`-equivalent when it mounts, to start
	* listening for focus/online events and resume paused mutations. Ref-counted via an internal
	* mount count, so nested or multiple providers sharing the same `QueryClient` don't tear down
	* the shared listeners until the last one unmounts.
	*/
	mount() {
		this.#mountCount++;
		if (this.#mountCount !== 1) return;
		this.#unsubscribeFocus = focusManager.subscribe(async (focused) => {
			if (focused) {
				await this.resumePausedMutations();
				this.#queryCache.onFocus();
			}
		});
		this.#unsubscribeOnline = onlineManager.subscribe(async (online) => {
			if (online) {
				await this.resumePausedMutations();
				this.#queryCache.onOnline();
			}
		});
	}
	/**
	* The inverse of {@link QueryClient#mount} — called by a framework adapter's
	* `QueryClientProvider`-equivalent when it unmounts. Only tears down the focus/online
	* listeners once the mount count returns to `0`.
	*/
	unmount() {
		this.#mountCount--;
		if (this.#mountCount !== 0) return;
		this.#unsubscribeFocus?.();
		this.#unsubscribeFocus = void 0;
		this.#unsubscribeOnline?.();
		this.#unsubscribeOnline = void 0;
	}
	/**
	* Returns the number of queries in the cache that are currently fetching, optionally
	* matching a set of filters. This includes background-fetching, loading new pages, and
	* loading more infinite query results.
	*
	* @example
	* ```ts
	* if (queryClient.isFetching()) {
	*   console.log('At least one query is fetching!')
	* }
	* ```
	*/
	isFetching(filters) {
		return this.#queryCache.findAll({
			...filters,
			fetchStatus: "fetching"
		}).length;
	}
	/**
	* Returns the number of mutations in the cache that are currently pending, optionally
	* matching a set of filters.
	*
	* @example
	* ```ts
	* if (queryClient.isMutating()) {
	*   console.log('At least one mutation is pending!')
	* }
	* ```
	*/
	isMutating(filters) {
		return this.#mutationCache.findAll({
			...filters,
			status: "pending"
		}).length;
	}
	/**
	* Imperative (non-reactive) way to retrieve data for a QueryKey.
	* Should only be used in callbacks or functions where reading the latest data is necessary, e.g. for optimistic updates.
	*
	* Hint: Do not use this function inside a component, because it won't receive updates.
	* Use `useQuery` to create a `QueryObserver` that subscribes to changes.
	*
	* @see {@link QueryClient#getQueriesData}
	*/
	getQueryData(queryKey) {
		const options = this.defaultQueryOptions({ queryKey });
		return this.#queryCache.get(options.queryHash)?.state.data;
	}
	/**
	* @deprecated Use queryClient.query({ ...options, staleTime: 'static' }) instead. This method will be removed in the next major version.
	*/
	ensureQueryData(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		const query = this.#queryCache.build(this, defaultedOptions);
		const cachedData = query.state.data;
		if (cachedData === void 0) return this.fetchQuery(options);
		if (options.revalidateIfStale && query.isStaleByTime(resolveQueryValue(defaultedOptions.staleTime, query))) this.prefetchQuery(defaultedOptions);
		return Promise.resolve(cachedData);
	}
	/**
	* Imperative (non-reactive) way to retrieve the cached data of multiple queries at once.
	* Only queries matching the given filters are returned; if none match, an empty array is
	* returned.
	*
	* Because the matched queries can hold data of different shapes (e.g. a broad filter can match
	* queries with unrelated data types), the `TQueryFnData` generic defaults to `unknown` rather
	* than being inferred. Passing a more specific type is a convenience for call sites that know
	* every matched query holds the same shape — it is not checked against the actual cache
	* contents.
	*
	* @see {@link QueryClient#getQueryData}
	* @example
	* ```ts
	* const data = queryClient.getQueriesData({ queryKey: ['posts'] })
	* ```
	*/
	getQueriesData(filters) {
		return this.#queryCache.findAll(filters).map(({ queryKey, state }) => {
			return [queryKey, state.data];
		});
	}
	/**
	* Synchronous way to immediately update a query's cached data. If the updater (or the value
	* passed) resolves to `undefined`, the cache is left untouched and no query is created;
	* otherwise, if the query does not exist yet, it will be created. To update multiple queries
	* at once by partially matching query keys, use {@link QueryClient#setQueriesData} instead.
	*
	* Updates must be performed immutably: do not mutate `oldData`, or data previously retrieved
	* via {@link QueryClient#getQueryData}, in place.
	*
	* @param queryKey - The query key to set data for.
	* @param updater - Either the new data, or a function that receives the current data (which
	* may be `undefined`) and returns the new data.
	*
	* @example
	* ```ts
	* queryClient.setQueryData(['posts'], newPosts)
	*
	* // Or, using an updater function that receives the current data:
	* queryClient.setQueryData(['posts'], (oldPosts) => [...oldPosts, newPost])
	* ```
	*/
	setQueryData(queryKey, updater, options) {
		const defaultedOptions = this.defaultQueryOptions({ queryKey });
		const prevData = this.#queryCache.get(defaultedOptions.queryHash)?.state.data;
		const data = functionalUpdate(updater, prevData);
		if (data === void 0) return;
		return this.#queryCache.build(this, defaultedOptions).setData(data, {
			...options,
			manual: true
		});
	}
	/**
	* Synchronous way to immediately update the cached data of multiple queries at once, using
	* filters or partial query key matching. Only queries that already exist and match the given
	* filters are updated; no new cache entries are created. Internally this calls
	* {@link QueryClient#setQueryData} for each matching query.
	*
	* @example
	* ```ts
	* queryClient.setQueriesData({ queryKey: ['posts'] }, (oldPosts) =>
	*   oldPosts ? oldPosts.filter((post) => post.id !== deletedId) : oldPosts,
	* )
	* ```
	*/
	setQueriesData(filters, updater, options) {
		return notifyManager.batch(() => this.#queryCache.findAll(filters).map(({ queryKey }) => [queryKey, this.setQueryData(queryKey, updater, options)]));
	}
	/**
	* Imperative (non-reactive) way to retrieve an existing query's state. If the query does not
	* exist, `undefined` is returned.
	*
	* @example
	* ```ts
	* const state = queryClient.getQueryState(['posts'])
	* console.log(state?.dataUpdatedAt)
	* ```
	*/
	getQueryState(queryKey) {
		const options = this.defaultQueryOptions({ queryKey });
		return this.#queryCache.get(options.queryHash)?.state;
	}
	/**
	* Removes queries from the cache that match the given filters. Unlike
	* {@link QueryClient#invalidateQueries} or {@link QueryClient#refetchQueries}, this removes
	* matching queries from the cache instead of refetching them. Without filters, every query in
	* the cache is removed.
	*
	* @example
	* ```ts
	* queryClient.removeQueries({ queryKey: ['posts'], exact: true })
	* ```
	*/
	removeQueries(filters) {
		const queryCache = this.#queryCache;
		notifyManager.batch(() => {
			queryCache.findAll(filters).forEach((query) => {
				queryCache.remove(query);
			});
		});
	}
	/**
	* Resets queries matching the given filters back to their initial state (e.g. any
	* `initialData`), notifying subscribers rather than removing them. Active queries among the
	* matched set are then refetched, and the returned promise resolves once that refetch settles.
	*
	* @example
	* ```ts
	* await queryClient.resetQueries({ queryKey: ['posts'], exact: true })
	* ```
	*/
	resetQueries(filters, options) {
		const queryCache = this.#queryCache;
		return notifyManager.batch(() => {
			const matched = queryCache.findAll(filters);
			const queriesToRefetch = new Set(matched);
			matched.forEach((query) => {
				query.reset();
			});
			return this.refetchQueries({
				type: "active",
				predicate: (query) => queriesToRefetch.has(query)
			}, options);
		});
	}
	/**
	* Cancels outgoing fetches for queries matching the given filters. Most useful when performing
	* optimistic updates, since any outgoing refetch that resolves afterwards would otherwise
	* overwrite the optimistic update. By default (`revert: true`), a cancelled query's data is
	* reverted to its state before the outgoing fetch started.
	*
	* The returned promise never rejects, even if individual cancellations fail.
	*
	* @example
	* ```ts
	* await queryClient.cancelQueries({ queryKey: ['posts'], exact: true })
	* ```
	*/
	cancelQueries(filters, cancelOptions = {}) {
		const defaultedCancelOptions = {
			revert: true,
			...cancelOptions
		};
		const promises = notifyManager.batch(() => this.#queryCache.findAll(filters).map((query) => query.cancel(defaultedCancelOptions)));
		return Promise.all(promises).then(noop).catch(noop);
	}
	/**
	* Marks queries matching the given filters as invalidated. Unlike
	* {@link QueryClient#removeQueries}, invalidated queries stay in the cache.
	*
	* Unless `filters.refetchType` is `'none'`, matching queries are then refetched via
	* {@link QueryClient#refetchQueries}, using `filters.refetchType` if set, otherwise
	* `filters.type`, otherwise `'active'`.
	*
	* @example
	* ```ts
	* await queryClient.invalidateQueries({ queryKey: ['posts'], refetchType: 'active' })
	* ```
	*/
	invalidateQueries(filters, options = {}) {
		return notifyManager.batch(() => {
			this.#queryCache.findAll(filters).forEach((query) => {
				query.invalidate();
			});
			if (filters?.refetchType === "none") return Promise.resolve();
			return this.refetchQueries({
				...filters,
				type: filters?.refetchType ?? filters?.type ?? "active"
			}, options);
		});
	}
	/**
	* Refetches queries matching the given filters, regardless of whether they are stale. Without
	* filters, every query in the cache is refetched. Queries that are disabled, or static (only
	* have observers with a static `staleTime`), are never refetched.
	*
	* By default (`cancelRefetch: true`), a currently running fetch is cancelled before the new
	* one starts. The returned promise resolves once all matching queries have settled; it does
	* not reject on individual query failures unless `throwOnError` is set.
	*
	* @example
	* ```ts
	* // refetch all active queries partially matching a query key:
	* await queryClient.refetchQueries({ queryKey: ['posts'], type: 'active' })
	* ```
	*/
	refetchQueries(filters, options = {}) {
		const fetchOptions = {
			...options,
			cancelRefetch: options.cancelRefetch ?? true
		};
		const promises = notifyManager.batch(() => this.#queryCache.findAll(filters).filter((query) => !query.isDisabled() && !query.isStatic()).map((query) => {
			let promise = query.fetch(void 0, fetchOptions);
			if (!fetchOptions.throwOnError) promise = promise.catch(noop);
			return query.state.fetchStatus === "paused" ? Promise.resolve() : promise;
		}));
		return Promise.all(promises).then(noop);
	}
	/**
	* Asynchronous method to fetch and cache a query, resolving with the data or throwing with
	* the error.
	*
	* If the query already exists in the cache and its data is not stale (per the given
	* `staleTime`), the cached data is returned without fetching. Otherwise, the query is fetched
	* and the promise resolves once the fetch settles. If a `select` function is provided, it is
	* applied to the data in both cases (cached or freshly fetched) before it is returned.
	*
	* Unlike a reactive observer, retries are disabled by default here (`retry: false`) unless
	* explicitly configured, since there is no component to catch a thrown error and retry through
	* re-render.
	*
	* The accepted options are `QueryObserverOptions` minus the fields that only make sense for a
	* reactive observer — `enabled`, `refetchInterval`, `refetchIntervalInBackground`,
	* `refetchOnWindowFocus`, `refetchOnReconnect`, `refetchOnMount`, `retryOnMount`,
	* `notifyOnChangeProps`, `throwOnError`, `suspense`, and `placeholderData` are not part of this
	* method's options.
	*
	* This method replaces the deprecated `fetchQuery`, and — combined with
	* `{ staleTime: 'static' }` — the deprecated `ensureQueryData`.
	*
	* @example
	* ```ts
	* try {
	*   const data = await queryClient.query({ queryKey, queryFn, staleTime: 10000 })
	* } catch (error) {
	*   console.log(error)
	* }
	* ```
	*/
	async query(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		if (defaultedOptions.retry === void 0) defaultedOptions.retry = false;
		const query = this.#queryCache.build(this, defaultedOptions);
		const queryData = query.isStaleByTime(resolveQueryValue(defaultedOptions.staleTime, query)) ? await query.fetch(defaultedOptions) : query.state.data;
		const select = defaultedOptions.select;
		if (select) return select(queryData);
		return queryData;
	}
	/**
	* @deprecated Use queryClient.query(options) instead. This method will be removed in the next major version.
	*/
	fetchQuery(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		if (defaultedOptions.retry === void 0) defaultedOptions.retry = false;
		const query = this.#queryCache.build(this, defaultedOptions);
		return query.isStaleByTime(resolveQueryValue(defaultedOptions.staleTime, query)) ? query.fetch(defaultedOptions) : Promise.resolve(query.state.data);
	}
	/**
	* @deprecated Use queryClient.query(options) instead. You can swallow errors with `.catch(noop)`. This method will be removed in the next major version.
	*/
	prefetchQuery(options) {
		return this.fetchQuery(options).then(noop).catch(noop);
	}
	/**
	* Asynchronous method to fetch and cache an infinite query, resolving with an
	* {@link InfiniteData} object or throwing with the error.
	*
	* Behaves like {@link QueryClient#query}, accepting the same options (minus
	* `initialPageParam`), plus the required `initialPageParam`, and an optional `pages` /
	* `getNextPageParam` pair used to refetch a fixed number of pages from the start.
	*
	* This method replaces the deprecated `fetchInfiniteQuery`, and — combined with
	* `{ staleTime: 'static' }` — the deprecated `ensureInfiniteQueryData`.
	*
	* @example
	* ```ts
	* try {
	*   const data = await queryClient.infiniteQuery({ queryKey, queryFn, initialPageParam: 0 })
	*   console.log(data.pages)
	* } catch (error) {
	*   console.log(error)
	* }
	* ```
	*/
	infiniteQuery(options) {
		options._type = "infinite";
		return this.query(options);
	}
	/**
	* @deprecated Use queryClient.infiniteQuery(options) instead. This method will be removed in the next major version.
	*/
	fetchInfiniteQuery(options) {
		options._type = "infinite";
		return this.fetchQuery(options);
	}
	/**
	* @deprecated Use queryClient.infiniteQuery(options) instead. You can swallow errors with `.catch(noop)`. This method will be removed in the next major version.
	*/
	prefetchInfiniteQuery(options) {
		return this.fetchInfiniteQuery(options).then(noop).catch(noop);
	}
	/**
	* @deprecated Use queryClient.infiniteQuery({ ...options, staleTime: 'static' }) instead. This method will be removed in the next major version.
	*/
	ensureInfiniteQueryData(options) {
		options._type = "infinite";
		return this.ensureQueryData(options);
	}
	/**
	* Resumes mutations that were paused because there was no network connection. Does nothing
	* (resolving immediately) if the client is currently offline.
	*
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* await queryClient.resumePausedMutations()
	* ```
	*/
	resumePausedMutations() {
		if (onlineManager.isOnline()) return this.#mutationCache.resumePausedMutations();
		return Promise.resolve();
	}
	/**
	* Returns the query cache this client is connected to.
	*
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* const queryCache = queryClient.getQueryCache()
	* const queries = queryCache.findAll({ queryKey: ['posts'] })
	* ```
	*/
	getQueryCache() {
		return this.#queryCache;
	}
	/**
	* Returns the mutation cache this client is connected to.
	*
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* const mutationCache = queryClient.getMutationCache()
	* const mutations = mutationCache.findAll({ status: 'pending' })
	* ```
	*/
	getMutationCache() {
		return this.#mutationCache;
	}
	/**
	* Returns the default options that were set when creating the client, or via
	* {@link QueryClient#setDefaultOptions}.
	*
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* const defaultOptions = queryClient.getDefaultOptions()
	* ```
	*/
	getDefaultOptions() {
		return this.#defaultOptions;
	}
	/**
	* Dynamically sets the default options for this client, overwriting any previously defined
	* default options.
	*
	* @see {@link QueryClient#getDefaultOptions}
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* queryClient.setDefaultOptions({
	*   queries: {
	*     staleTime: Infinity,
	*   },
	* })
	* ```
	*/
	setDefaultOptions(options) {
		this.#defaultOptions = options;
	}
	/**
	* Sets default options for queries whose query key partially matches the given `queryKey`.
	*
	* If several registered query defaults match a given query key, they are merged together in
	* registration order by {@link QueryClient#getQueryDefaults}, so register defaults from the
	* most generic key to the least generic one — more specific defaults should be registered
	* after more generic ones so they take precedence.
	*
	* @example
	* ```ts
	* queryClient.setQueryDefaults(['posts'], { queryFn: fetchPosts })
	*
	* await queryClient.query({ queryKey: ['posts'] })
	* ```
	*/
	setQueryDefaults(queryKey, options) {
		this.#queryDefaults.set(hashKey(queryKey), {
			queryKey,
			defaultOptions: options
		});
	}
	/**
	* Returns the default options registered for queries whose query key partially matches the
	* given `queryKey`, via {@link QueryClient#setQueryDefaults}. If multiple registered defaults
	* match, they are merged together in registration order.
	*
	* @example
	* ```ts
	* const defaultOptions = queryClient.getQueryDefaults(['posts'])
	* ```
	*/
	getQueryDefaults(queryKey) {
		const defaults = [...this.#queryDefaults.values()];
		const result = {};
		defaults.forEach((queryDefault) => {
			if (partialMatchKey(queryKey, queryDefault.queryKey)) Object.assign(result, queryDefault.defaultOptions);
		});
		return result;
	}
	/**
	* Sets default options for mutations whose mutation key partially matches the given
	* `mutationKey`. As with {@link QueryClient#setQueryDefaults}, the order of registration
	* matters when several registered defaults match the same mutation key.
	*
	* @see {@link QueryClient#getMutationDefaults}
	* @example
	* ```ts
	* queryClient.setMutationDefaults(['addPost'], { mutationFn: addPost })
	* ```
	*/
	setMutationDefaults(mutationKey, options) {
		this.#mutationDefaults.set(hashKey(mutationKey), {
			mutationKey,
			defaultOptions: options
		});
	}
	/**
	* Returns the default options registered for mutations whose mutation key partially matches
	* the given `mutationKey`, via {@link QueryClient#setMutationDefaults}. If multiple registered
	* defaults match, they are merged together in registration order.
	*
	* @example
	* ```ts
	* const defaultOptions = queryClient.getMutationDefaults(['addPost'])
	* ```
	*/
	getMutationDefaults(mutationKey) {
		const defaults = [...this.#mutationDefaults.values()];
		const result = {};
		defaults.forEach((queryDefault) => {
			if (partialMatchKey(mutationKey, queryDefault.mutationKey)) Object.assign(result, queryDefault.defaultOptions);
		});
		return result;
	}
	/**
	* Called by framework adapters (e.g. inside `useQuery`) to resolve the options passed by the
	* caller into their final, defaulted form: merging `queryClient.setQueryDefaults` for the
	* given `queryKey`, then the client's own `defaultOptions.queries`, then the caller's options
	* on top. A no-op if the options are already defaulted (`_defaulted: true`).
	*/
	defaultQueryOptions(options) {
		if (options._defaulted) return options;
		const defaultedOptions = {
			...this.#defaultOptions.queries,
			...this.getQueryDefaults(options.queryKey),
			...options,
			_defaulted: true
		};
		if (!defaultedOptions.queryHash) defaultedOptions.queryHash = hashQueryKeyByOptions(defaultedOptions.queryKey, defaultedOptions);
		if (defaultedOptions.refetchOnReconnect === void 0) defaultedOptions.refetchOnReconnect = defaultedOptions.networkMode !== "always";
		if (defaultedOptions.throwOnError === void 0) defaultedOptions.throwOnError = !!defaultedOptions.suspense;
		if (!defaultedOptions.networkMode && defaultedOptions.persister) defaultedOptions.networkMode = "offlineFirst";
		if (defaultedOptions.queryFn === skipToken) defaultedOptions.enabled = false;
		return defaultedOptions;
	}
	/**
	* The mutation counterpart of {@link QueryClient#defaultQueryOptions}. Called by framework
	* adapters (e.g. inside `useMutation`) to merge `queryClient.setMutationDefaults` for the
	* given `mutationKey`, then the client's `defaultOptions.mutations`, then the caller's options
	* on top. A no-op if the options are already defaulted (`_defaulted: true`).
	*/
	defaultMutationOptions(options) {
		if (options?._defaulted) return options;
		return {
			...this.#defaultOptions.mutations,
			...options?.mutationKey && this.getMutationDefaults(options.mutationKey),
			...options,
			_defaulted: true
		};
	}
	/**
	* Clears both the query cache and the mutation cache this client is connected to.
	*
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* queryClient.clear()
	* ```
	*/
	clear() {
		this.#queryCache.clear();
		this.#mutationCache.clear();
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/streamedQuery.js
/**
* This is a helper function to create a query function that streams data from an AsyncIterable.
* Data will be an Array of all the chunks received.
* The query will be in a 'pending' state until the first chunk of data is received, but will go to 'success' after that.
* The query will stay in fetchStatus 'fetching' until the stream ends.
* @param streamFn - The function that returns an AsyncIterable to stream data from.
* @param refetchMode - Defines how re-fetches are handled.
* Defaults to `'reset'`, erases all data and puts the query back into `pending` state.
* Set to `'append'` to append new data to the existing data.
* Set to `'replace'` to write all data to the cache once the stream ends.
* @param reducer - A function to reduce the streamed chunks into the final data.
* Defaults to a function that appends chunks to the end of the array.
* @param initialValue - Initial value to be used while the first chunk is being fetched, and returned if the stream yields no values.
* @example
* ```ts
* await queryClient.query({
*   queryKey: ['data'],
*   queryFn: streamedQuery({
*     streamFn: fetchDataInChunks,
*   }),
* })
* ```
*/
function streamedQuery({ streamFn, refetchMode = "reset", reducer = (items, chunk) => addToEnd(items, chunk), initialValue = [] }) {
	return async (context) => {
		const query = context.client.getQueryCache().find({
			queryKey: context.queryKey,
			exact: true
		});
		const isRefetch = !!query && query.isFetched();
		if (isRefetch && refetchMode === "reset") query.setState({
			...query.resetState,
			fetchStatus: "fetching"
		});
		let result = initialValue;
		let cancelled = false;
		const stream = await streamFn(addConsumeAwareSignal({
			client: context.client,
			meta: context.meta,
			queryKey: context.queryKey,
			pageParam: context.pageParam,
			direction: context.direction
		}, () => context.signal, () => cancelled = true));
		const isReplaceRefetch = isRefetch && refetchMode === "replace";
		for await (const chunk of stream) {
			if (cancelled) break;
			if (isReplaceRefetch) result = reducer(result, chunk);
			else context.client.setQueryData(context.queryKey, (prev) => reducer(prev === void 0 ? initialValue : prev, chunk));
		}
		if (isReplaceRefetch && !cancelled) context.client.setQueryData(context.queryKey, result);
		const data = context.client.getQueryData(context.queryKey);
		return data === void 0 ? initialValue : data;
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/types.js
/* istanbul ignore file */
var dataTagSymbol = Symbol();
var dataTagErrorSymbol = Symbol();
var unsetMarker = Symbol();
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/HydrationBoundary.js
/**
* `HydrationBoundary` adds a previously dehydrated state into the `queryClient` that would be returned by
* `useQueryClient()`. If the client already contains data, the new queries will be intelligently merged based on
* update timestamp.
*
* Note: Only `queries` can be dehydrated with an `HydrationBoundary`.
*
* @returns The provided `children`, rendered unconditionally. New queries in `state` are hydrated into the
* cache during render; for queries already in the cache, only newer dehydrated data is hydrated, in an effect
* after commit.
*
* @example
* ```tsx
* import { HydrationBoundary } from '@tanstack/react-query'
*
* function App() {
*   return <HydrationBoundary state={dehydratedState}>...</HydrationBoundary>
* }
* ```
*
* @example
* Server-side prefetch handed off to the client via `dehydrate`:
* ```tsx
* import { HydrationBoundary, dehydrate, noop } from '@tanstack/react-query'
*
* async function ServerComponent() {
*   const queryClient = getQueryClient()
*
*   await queryClient
*     .query({
*       queryKey: ['posts'],
*       queryFn: fetchPosts,
*     })
*     .catch(noop)
*
*   return (
*     <HydrationBoundary state={dehydrate(queryClient)}>
*       <Posts />
*     </HydrationBoundary>
*   )
* }
* ```
*/
var HydrationBoundary = ({ children, options = {}, state, queryClient }) => {
	const client = useQueryClient(queryClient);
	const optionsRef = import_react.useRef(options);
	import_react.useEffect(() => {
		optionsRef.current = options;
	});
	const hydrationQueue = import_react.useMemo(() => {
		if (state) {
			if (typeof state !== "object") return;
			const queryCache = client.getQueryCache();
			const queries = state.queries || [];
			const newQueries = [];
			const existingQueries = [];
			for (const dehydratedQuery of queries) {
				const existingQuery = queryCache.get(dehydratedQuery.queryHash);
				if (!existingQuery) newQueries.push(dehydratedQuery);
				else if (dehydratedQuery.state.dataUpdatedAt > existingQuery.state.dataUpdatedAt || dehydratedQuery.promise && existingQuery.state.status !== "pending" && existingQuery.state.fetchStatus !== "fetching" && dehydratedQuery.dehydratedAt > existingQuery.state.dataUpdatedAt) existingQueries.push(dehydratedQuery);
			}
			if (newQueries.length > 0) hydrate(client, { queries: newQueries }, optionsRef.current);
			if (existingQueries.length > 0) return existingQueries;
		}
	}, [client, state]);
	import_react.useEffect(() => {
		if (hydrationQueue) hydrate(client, { queries: hydrationQueue }, optionsRef.current);
	}, [client, hydrationQueue]);
	return children;
};
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/IsRestoringProvider.js
var IsRestoringContext = import_react.createContext(false);
/**
* If you are using `PersistQueryClientProvider`, you can also use the `useIsRestoring` hook alongside it to
* check if a restore is currently in progress. `useQuery` and friends also check this internally to avoid
* race conditions between the restore and mounting queries.
*
* @returns `true` while a persisted client is being restored, `false` otherwise.
*/
var useIsRestoring = () => import_react.useContext(IsRestoringContext);
/**
* The Provider that `PersistQueryClientProvider` uses to signal whether a persisted client is currently
* being restored, read by `useIsRestoring`.
*/
var IsRestoringProvider = IsRestoringContext.Provider;
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/QueryErrorResetBoundary.js
/**
* Resets any query errors within the boundary, so queries know they can try again.
*/
function createValue() {
	let isReset = false;
	return {
		/**
		* Clears the reset state, so queries know not to try again until the boundary is reset again.
		*/
		clearReset: () => {
			isReset = false;
		},
		/**
		* Resets any query errors within the boundary, so queries know they can try again.
		*/
		reset: () => {
			isReset = true;
		},
		/**
		* Returns whether the boundary has been reset and not yet cleared.
		*/
		isReset: () => {
			return isReset;
		}
	};
}
var QueryErrorResetBoundaryContext = import_react.createContext(createValue());
/**
* This hook will reset any query errors within the closest `QueryErrorResetBoundary`. If there is no boundary
* defined it will reset them globally.
*
* @returns The boundary's {@link QueryErrorResetBoundaryValue}.
*
* @example
* ```tsx
* import { ErrorBoundary } from 'react-error-boundary'
* import { useQueryErrorResetBoundary } from '@tanstack/react-query'
*
* function App({ children }: { children: React.ReactNode }) {
*   const { reset } = useQueryErrorResetBoundary()
*
*   return (
*     <ErrorBoundary
*       onReset={reset}
*       fallbackRender={({ resetErrorBoundary }) => (
*         <div>
*           There was an error!
*           <button onClick={() => resetErrorBoundary()}>Try again</button>
*         </div>
*       )}
*     >
*       {children}
*     </ErrorBoundary>
*   )
* }
* ```
*/
var useQueryErrorResetBoundary = () => import_react.useContext(QueryErrorResetBoundaryContext);
/**
* When using `suspense` or `throwOnError` in your queries, you need a way to let queries know that you want to
* try again when re-rendering after some error occurred. With the `QueryErrorResetBoundary` component you can
* reset any query errors within the boundaries of the component.
*
* @returns The `children`, rendered as-is, or called with the boundary's {@link QueryErrorResetBoundaryValue}
* if `children` is a function.
*
* @example
* ```tsx
* import { ErrorBoundary } from 'react-error-boundary'
* import { QueryErrorResetBoundary } from '@tanstack/react-query'
*
* function App() {
*   return (
*     <QueryErrorResetBoundary>
*       {({ reset }) => (
*         <ErrorBoundary
*           onReset={reset}
*           fallbackRender={({ resetErrorBoundary }) => (
*             <div>
*               There was an error!
*               <button onClick={() => resetErrorBoundary()}>Try again</button>
*             </div>
*           )}
*         >
*           <Page />
*         </ErrorBoundary>
*       )}
*     </QueryErrorResetBoundary>
*   )
* }
* ```
*/
var QueryErrorResetBoundary = ({ children }) => {
	const [value] = import_react.useState(() => createValue());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryErrorResetBoundaryContext.Provider, {
		value,
		children: typeof children === "function" ? children(value) : children
	});
};
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/errorBoundaryUtils.js
var ensurePreventErrorBoundaryRetry = (options, errorResetBoundary, query) => {
	const throwOnError = query?.state.error && typeof options.throwOnError === "function" ? shouldThrowError(options.throwOnError, [query.state.error, query]) : options.throwOnError;
	if (options.suspense || throwOnError) {
		if (!errorResetBoundary.isReset()) options.retryOnMount = false;
	}
};
var useClearResetErrorBoundary = (errorResetBoundary) => {
	import_react.useEffect(() => {
		errorResetBoundary.clearReset();
	}, [errorResetBoundary]);
};
var getHasError = ({ result, errorResetBoundary, throwOnError, query, suspense }) => {
	return result.isError && !errorResetBoundary.isReset() && !result.isFetching && query && (suspense && result.data === void 0 || shouldThrowError(throwOnError, [result.error, query]));
};
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/suspense.js
var defaultThrowOnError = (_error, query) => query.state.data === void 0;
var ensureSuspenseTimers = (defaultedOptions) => {
	if (defaultedOptions.suspense) {
		const MIN_SUSPENSE_TIME_MS = 1e3;
		const clamp = (value) => value === "static" ? value : Math.max(value ?? MIN_SUSPENSE_TIME_MS, MIN_SUSPENSE_TIME_MS);
		const originalStaleTime = defaultedOptions.staleTime;
		defaultedOptions.staleTime = typeof originalStaleTime === "function" ? (...args) => clamp(originalStaleTime(...args)) : clamp(originalStaleTime);
		if (typeof defaultedOptions.gcTime === "number") defaultedOptions.gcTime = Math.max(defaultedOptions.gcTime, MIN_SUSPENSE_TIME_MS);
	}
};
var shouldSuspend = (defaultedOptions, result) => defaultedOptions?.suspense && result.isPending;
var fetchOptimistic = (defaultedOptions, observer, errorResetBoundary) => observer.fetchOptimistic(defaultedOptions).catch(() => {
	errorResetBoundary.clearReset();
});
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useQueries.js
/**
* The `useQueries` hook can be used to fetch a variable number of queries.
*
* The `queries` key accepts an array with query option objects mostly identical to `useQuery` — the top-level
* `subscribed` option isn't accepted per query (see `placeholderData` below for another difference). A custom
* `QueryClient` is supplied once, as `useQueries`' own top-level second argument, rather than per query.
*
* Having the same query key more than once in the array of query objects may cause some data to be shared
* between queries. To avoid this, consider de-duplicating the queries and map the results back to the desired
* structure.
*
* The `combine` option can be used to combine the results of the queries into a single value. The result will
* be structurally shared to be as referentially stable as possible.
*
* @remarks The `combine` function only re-runs if it changed referentially, or if any of the query results
* changed. An inlined `combine` function, as shown in the example below, therefore runs on every render — wrap
* it in `useCallback`, or extract it to a stable function reference if it doesn't have any dependencies, to
* avoid that.
*
* Unlike `useQuery`, `useQueries` cannot infer the `data` argument of an _inline_ `select` from its sibling
* `queryFn`. Because `useQueries` infers the type of the whole `queries` array at once, the `select` parameter
* of a query object written inline cannot be contextually typed from that same object's `queryFn`, so it falls
* back to `unknown` — a [known TypeScript limitation](https://github.com/TanStack/query/issues/6556). Annotate
* the `select` parameter explicitly, or define the query with {@link queryOptions}, which resolves its types in
* a single object _before_ it reaches `useQueries`, to work around this — see the example below. The same
* limitation applies to {@link useSuspenseQueries}.
*
* `placeholderData` is supported here too, but unlike `useQuery`, it doesn't receive information from
* previously rendered queries, because the number of queries can differ between renders.
* @param queryClient - Use this to provide a custom `QueryClient`. Otherwise, the one from the nearest context
* will be used.
* @returns The combined result. Without `combine`, this is an array with all the query results, in the same
* order as the input. When `combine` is provided, this is the value returned by `combine` instead.
*
* @example
* ```tsx
* import { useQueries } from '@tanstack/react-query'
*
* function Posts({ ids }: { ids: Array<number> }) {
*   const postQueries = useQueries({
*     queries: ids.map((id) => ({
*       queryKey: ['post', id],
*       queryFn: () => fetchPost(id),
*       staleTime: Infinity,
*     })),
*   })
*
*   return (
*     <ul>
*       {postQueries.map((query, index) => {
*         if (query.isPending) return <li key={ids[index]}>Loading...</li>
*         if (query.isError) return <li key={ids[index]}>Error: {query.error.message}</li>
*         return <li key={ids[index]}>{query.data.title}</li>
*       })}
*     </ul>
*   )
* }
* ```
*
* @example
* Combining results into a single value:
* ```tsx
* import { useQueries } from '@tanstack/react-query'
*
* function Posts({ ids }: { ids: Array<number> }) {
*   const { data, isPending, isError } = useQueries({
*     queries: ids.map((id) => ({
*       queryKey: ['post', id],
*       queryFn: () => fetchPost(id),
*     })),
*     combine: (postQueries) => {
*       return {
*         data: postQueries.map((query) => query.data),
*         isPending: postQueries.some((query) => query.isPending),
*         isError: postQueries.some((query) => query.isError),
*       }
*     },
*   })
*
*   if (isPending) return 'Loading...'
*   if (isError) return 'Error loading posts'
*
*   return (
*     <ul>
*       {data.map((post) => (
*         <li key={post?.id}>{post?.title}</li>
*       ))}
*     </ul>
*   )
* }
* ```
*
* @example
* Typing `select` via {@link queryOptions}. Note that spreading a `queryOptions` result and overriding
* `select` inline still falls back to `unknown` — wrap the spread in `queryOptions` again so the override is
* resolved before it reaches `useQueries`:
* ```tsx
* import { queryOptions, useQueries } from '@tanstack/react-query'
*
* const postOptions = (id: number) =>
*   queryOptions({
*     queryKey: ['post', id],
*     queryFn: () => fetchPost(id),
*   })
*
* function PostTitle({ id }: { id: number }) {
*   const [{ data: broken }] = useQueries({
*     queries: [
*       {
*         ...postOptions(id),
*         // ❌ `data` is `unknown` here
*         select: (data) => data.title,
*       },
*     ],
*   })
*
*   const [{ data: fixed }] = useQueries({
*     queries: [
*       queryOptions({
*         ...postOptions(id),
*         // ✅ `data` is `Post`
*         select: (data) => data.title,
*       }),
*     ],
*   })
*
*   return <h1>{fixed}</h1>
* }
* ```
*/
function useQueries({ queries, ...options }, queryClient) {
	const client = useQueryClient(queryClient);
	const isRestoring = useIsRestoring();
	const errorResetBoundary = useQueryErrorResetBoundary();
	const subscribed = options.subscribed !== false;
	const defaultedQueries = import_react.useMemo(() => queries.map((opts) => {
		const defaultedOptions = client.defaultQueryOptions(opts);
		defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : subscribed ? "optimistic" : void 0;
		return defaultedOptions;
	}), [
		queries,
		client,
		isRestoring,
		subscribed
	]);
	defaultedQueries.forEach((queryOptions) => {
		ensureSuspenseTimers(queryOptions);
		const query = client.getQueryCache().get(queryOptions.queryHash);
		ensurePreventErrorBoundaryRetry(queryOptions, errorResetBoundary, query);
	});
	useClearResetErrorBoundary(errorResetBoundary);
	const [observer] = import_react.useState(() => new QueriesObserver(client, defaultedQueries, options));
	const [optimisticResult, getCombinedResult, trackResult] = observer.getOptimisticResult(defaultedQueries, options.combine);
	const shouldSubscribe = !isRestoring && subscribed;
	import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	import_react.useEffect(() => {
		observer.setQueries(defaultedQueries, options);
	}, [
		defaultedQueries,
		options,
		observer
	]);
	const suspensePromises = optimisticResult.some((result, index) => shouldSuspend(defaultedQueries[index], result)) ? optimisticResult.flatMap((result, index) => {
		const opts = defaultedQueries[index];
		if (opts && shouldSuspend(opts, result)) return fetchOptimistic(opts, new QueryObserver(client, opts), errorResetBoundary);
		return [];
	}) : [];
	if (suspensePromises.length > 0) throw Promise.all(suspensePromises);
	const firstSingleResultWhichShouldThrow = optimisticResult.find((result, index) => {
		const query = defaultedQueries[index];
		return query && getHasError({
			result,
			errorResetBoundary,
			throwOnError: query.throwOnError,
			query: client.getQueryCache().get(query.queryHash),
			suspense: query.suspense
		});
	});
	if (firstSingleResultWhichShouldThrow) throw firstSingleResultWhichShouldThrow.error;
	return getCombinedResult(trackResult());
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useBaseQuery.js
function useBaseQuery(options, Observer, queryClient) {
	if (typeof options !== "object" || Array.isArray(options)) throw new Error("Bad argument type. Starting with v5, only the \"Object\" form is allowed when calling query related functions. Please use the error stack to find the culprit call. More info here: https://tanstack.com/query/latest/docs/react/guides/migrating-to-v5#supports-a-single-signature-one-object");
	const isRestoring = useIsRestoring();
	const errorResetBoundary = useQueryErrorResetBoundary();
	const client = useQueryClient(queryClient);
	const defaultedOptions = client.defaultQueryOptions(options);
	const query = client.getQueryCache().get(defaultedOptions.queryHash);
	if (!defaultedOptions.queryFn) console.error(`[${defaultedOptions.queryHash}]: No queryFn was passed as an option, and no default queryFn was found. The queryFn parameter is only optional when using a default queryFn. More info here: https://tanstack.com/query/latest/docs/framework/react/guides/default-query-function`);
	const subscribed = options.subscribed !== false;
	defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : subscribed ? "optimistic" : void 0;
	ensureSuspenseTimers(defaultedOptions);
	ensurePreventErrorBoundaryRetry(defaultedOptions, errorResetBoundary, query);
	useClearResetErrorBoundary(errorResetBoundary);
	const [observer] = import_react.useState(() => new Observer(client, defaultedOptions));
	const result = observer.getOptimisticResult(defaultedOptions);
	const shouldSubscribe = !isRestoring && subscribed;
	import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => {
		const unsubscribe = shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop;
		observer.updateResult();
		return unsubscribe;
	}, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	import_react.useEffect(() => {
		observer.setOptions(defaultedOptions);
	}, [defaultedOptions, observer]);
	if (shouldSuspend(defaultedOptions, result)) throw fetchOptimistic(defaultedOptions, observer, errorResetBoundary);
	if (getHasError({
		result,
		errorResetBoundary,
		throwOnError: defaultedOptions.throwOnError,
		query,
		suspense: defaultedOptions.suspense
	})) throw result.error;
	return !defaultedOptions.notifyOnChangeProps ? observer.trackResult(result) : result;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useQuery.js
function useQuery(options, queryClient) {
	return useBaseQuery(options, QueryObserver, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useSuspenseQuery.js
/**
* The options for `useSuspenseQuery` are the same as for `useQuery`, except for `throwOnError`, `enabled`, and
* `placeholderData` — and `queryFn` may not be `skipToken`, since Suspense hooks can't render a "disabled" state.
*
* Caveat: cancellation does not work.
*
* @remarks Multiple `useSuspenseQuery` calls in the same component suspend serially, causing a request
* waterfall — each one blocks rendering until it resolves, so the next doesn't even start fetching until then.
* Use {@link useSuspenseQueries} instead when you have more than one suspenseful query in a component, so they
* fetch in parallel.
* @param options - The {@link UseSuspenseQueryOptions} to use — the same options as `useQuery`, minus the ones listed above.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns The same object as `useQuery`, except that `data` is guaranteed to be defined, `isPlaceholderData`
* is missing, and `status` is either `success` or `error` (with the derived flags set accordingly).
*
* @example
* The query error is thrown if the fetch fails and no cached data exists yet, so an error boundary is
* required around `<Suspense>`. A failed background refetch instead continues to render the cached data.
* Use {@link QueryErrorResetBoundary} to let the user retry after such an error:
* ```tsx
* import { Suspense } from 'react'
* import { ErrorBoundary } from 'react-error-boundary'
* import { QueryErrorResetBoundary, useSuspenseQuery } from '@tanstack/react-query'
*
* function Posts() {
*   // `data` is guaranteed to be defined here — no `isPending` check needed.
*   const { data, isFetching } = useSuspenseQuery({
*     queryKey: ['posts'],
*     queryFn: fetchPosts,
*   })
*
*   return (
*     <div>
*       <h1>Posts {isFetching ? '(refreshing...)' : null}</h1>
*       <ul>
*         {data.map((post) => (
*           <li key={post.id}>{post.title}</li>
*         ))}
*       </ul>
*     </div>
*   )
* }
*
* function App() {
*   return (
*     <QueryErrorResetBoundary>
*       {({ reset }) => (
*         <ErrorBoundary
*           onReset={reset}
*           fallbackRender={({ resetErrorBoundary }) => (
*             <div>
*               There was an error!
*               <button onClick={() => resetErrorBoundary()}>Try again</button>
*             </div>
*           )}
*         >
*           <Suspense fallback={<h1>Loading posts...</h1>}>
*             <Posts />
*           </Suspense>
*         </ErrorBoundary>
*       )}
*     </QueryErrorResetBoundary>
*   )
* }
* ```
*/
function useSuspenseQuery(options, queryClient) {
	if (options.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseQuery");
	return useBaseQuery({
		...options,
		enabled: true,
		suspense: true,
		throwOnError: defaultThrowOnError,
		placeholderData: void 0
	}, QueryObserver, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useSuspenseInfiniteQuery.js
/**
* The options for `useSuspenseInfiniteQuery` are the same as for `useInfiniteQuery`, except for `throwOnError`,
* `enabled`, and `placeholderData`.
*
* Caveat: cancellation does not work.
*
* @remarks Multiple suspenseful query calls in the same component suspend serially, causing a request
* waterfall — each one blocks rendering until it resolves, so the next doesn't even start fetching until
* then. There's no way to parallelize multiple infinite queries under Suspense. Also keep in mind that
* imperative fetch calls, such as `fetchNextPage`, may interfere with the default refetch behavior,
* resulting in outdated data. Make sure to call these functions only in response to user actions, or add
* conditions like `hasNextPage && !isFetching`.
* @see {@link useInfiniteQuery} for the non-Suspense version of this hook.
* @param options - The {@link UseSuspenseInfiniteQueryOptions} to use — the same options as `useInfiniteQuery`, minus the ones listed above.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns The same object as `useInfiniteQuery`, except that `data` is guaranteed to be defined,
* `isPlaceholderData` is missing, and `status` is either `success` or `error` (with the derived flags set
* accordingly).
*
* @example
* The query error is thrown if a fetch fails and no cached data exists yet, so an error boundary is
* required around `<Suspense>`. A failed background refetch instead continues to render the cached data.
* Use {@link QueryErrorResetBoundary} to let the user retry after such an error:
* ```tsx
* import { Suspense } from 'react'
* import { ErrorBoundary } from 'react-error-boundary'
* import {
*   QueryErrorResetBoundary,
*   useSuspenseInfiniteQuery,
* } from '@tanstack/react-query'
*
* function Projects() {
*   // `data` is guaranteed to be defined here — no `isPending` check needed.
*   const { data, fetchNextPage, hasNextPage, isFetching, isFetchingNextPage } =
*     useSuspenseInfiniteQuery({
*       queryKey: ['projects'],
*       queryFn: ({ pageParam }) => fetchProjects(pageParam),
*       initialPageParam: 0,
*       getNextPageParam: (lastPage) => lastPage.nextId,
*     })
*
*   return (
*     <div>
*       <ul>
*         {data.pages.map((page) =>
*           page.projects.map((project) => <li key={project.id}>{project.name}</li>),
*         )}
*       </ul>
*       <button
*         onClick={() => fetchNextPage()}
*         disabled={!hasNextPage || isFetching}
*       >
*         {isFetchingNextPage
*           ? 'Loading more...'
*           : hasNextPage
*             ? 'Load More'
*             : 'Nothing more to load'}
*       </button>
*     </div>
*   )
* }
*
* function App() {
*   return (
*     <QueryErrorResetBoundary>
*       {({ reset }) => (
*         <ErrorBoundary
*           onReset={reset}
*           fallbackRender={({ resetErrorBoundary }) => (
*             <div>
*               There was an error!
*               <button onClick={() => resetErrorBoundary()}>Try again</button>
*             </div>
*           )}
*         >
*           <Suspense fallback={<h1>Loading projects...</h1>}>
*             <Projects />
*           </Suspense>
*         </ErrorBoundary>
*       )}
*     </QueryErrorResetBoundary>
*   )
* }
* ```
*/
function useSuspenseInfiniteQuery(options, queryClient) {
	if (options.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseInfiniteQuery");
	return useBaseQuery({
		...options,
		enabled: true,
		suspense: true,
		throwOnError: defaultThrowOnError,
		placeholderData: void 0
	}, InfiniteQueryObserver, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useSuspenseQueries.js
function useSuspenseQueries(options, queryClient) {
	return useQueries({
		...options,
		queries: options.queries.map((query) => {
			if (query.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseQueries");
			return {
				...query,
				suspense: true,
				throwOnError: defaultThrowOnError,
				enabled: true,
				placeholderData: void 0
			};
		})
	}, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/usePrefetchQuery.js
/**
* `usePrefetchQuery` does not return anything, it should be used just to fire a prefetch during render, before
* a suspense boundary that wraps a component that uses `useSuspenseQuery`. You can pass everything to
* `usePrefetchQuery` that you can pass to `queryClient.query`, though `queryKey` is always required, and
* `queryFn` is required unless a default query function has been defined.
*
* The prefetch is skipped if the query already has any cached state — including a `pending`/`error` state left
* over from a previous attempt — so calling this on every render is cheap and won't refetch data that's
* already there or already in flight.
*
* @param options - The {@link UsePrefetchQueryOptions} to use — everything you can pass to `queryClient.query`.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns `void` — nothing is returned.
*
* @example
* ```tsx
* import { Suspense } from 'react'
* import { usePrefetchQuery } from '@tanstack/react-query'
*
* function App() {
*   // Fire the prefetch during render, before the suspense boundary below.
*   usePrefetchQuery({
*     queryKey: ['posts'],
*     queryFn: fetchPosts,
*   })
*
*   return (
*     <Suspense fallback={<h1>Loading posts...</h1>}>
*       <Posts />
*     </Suspense>
*   )
* }
* ```
*/
function usePrefetchQuery(options, queryClient) {
	const client = useQueryClient(queryClient);
	if (!client.getQueryState(options.queryKey)) client.query(options).catch(noop);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/usePrefetchInfiniteQuery.js
/**
* `usePrefetchInfiniteQuery` does not return anything, it should be used just to fire a prefetch during render,
* before a suspense boundary that wraps a component that uses `useSuspenseInfiniteQuery`. You can pass
* everything to `usePrefetchInfiniteQuery` that you can pass to `queryClient.infiniteQuery`, though
* `queryKey`, `initialPageParam`, and `getNextPageParam` are always required, and `queryFn` is required unless
* a default query function has been defined.
*
* `getNextPageParam` receives both the last page of the infinite list of data and the full array of all pages,
* as well as pageParam information, and should return a single variable that will be passed to your query
* function as `context.pageParam`. Return `undefined` or `null` to indicate there is no next page available.
*
* The prefetch is skipped if the query already has any cached state — including a `pending`/`error` state left
* over from a previous attempt — so calling this on every render is cheap and won't refetch data that's
* already there or already in flight.
*
* @param options - The {@link UsePrefetchInfiniteQueryOptions} to use — everything you can pass to `queryClient.infiniteQuery`.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns `void` — nothing is returned.
*
* @example
* ```tsx
* import { Suspense } from 'react'
* import { infiniteQueryOptions, usePrefetchInfiniteQuery } from '@tanstack/react-query'
*
* const projectsOptions = infiniteQueryOptions({
*   queryKey: ['projects'],
*   queryFn: ({ pageParam }) => fetchProjects(pageParam),
*   initialPageParam: 0,
*   getNextPageParam: (lastPage) => lastPage.nextId,
* })
*
* function App() {
*   // Fire the prefetch during render, before the suspense boundary below.
*   usePrefetchInfiniteQuery(projectsOptions)
*
*   return (
*     <Suspense fallback={<h1>Loading projects...</h1>}>
*       <Projects />
*     </Suspense>
*   )
* }
* ```
*/
function usePrefetchInfiniteQuery(options, queryClient) {
	const client = useQueryClient(queryClient);
	if (!client.getQueryState(options.queryKey)) client.infiniteQuery(options).catch(noop);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/queryOptions.js
function queryOptions(options) {
	return options;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/infiniteQueryOptions.js
function infiniteQueryOptions(options) {
	return options;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useIsFetching.js
/**
* The `useIsFetching` hook returns the `number` of the queries that your application is loading or fetching in
* the background (useful for app-wide loading indicators).
*
* @param filters - The {@link QueryFilters} to narrow down the matched queries.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns Will be the `number` of the queries that your application is currently loading or fetching in the
* background.
*
* @example
* ```tsx
* import { useIsFetching } from '@tanstack/react-query'
*
* function PostsFetchingIndicator() {
*   // How many queries matching the posts prefix are fetching?
*   const isFetchingPosts = useIsFetching({ queryKey: ['posts'] })
*
*   return isFetchingPosts ? <span>Refreshing posts...</span> : null
* }
* ```
*
* @example
* A global loading indicator for any query fetching in the background, not just the ones on screen:
* ```tsx
* import { useIsFetching } from '@tanstack/react-query'
*
* function GlobalLoadingIndicator() {
*   const isFetching = useIsFetching()
*
*   return isFetching ? (
*     <div>Queries are fetching in the background...</div>
*   ) : null
* }
* ```
*/
function useIsFetching(filters, queryClient) {
	const client = useQueryClient(queryClient);
	const queryCache = client.getQueryCache();
	return import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => queryCache.subscribe(notifyManager.batchCalls(onStoreChange)), [queryCache]), () => client.isFetching(filters), () => client.isFetching(filters));
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useMutationState.js
/**
* The `useIsMutating` hook returns the `number` of mutations that your application currently has `pending`
* (useful for app-wide loading indicators).
*
* @param filters - The {@link MutationFilters} to narrow down the matched mutations.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns Will be the `number` of the mutations that your application currently has `pending`.
*
* @example
* ```tsx
* import { useIsMutating } from '@tanstack/react-query'
*
* function PostsMutatingIndicator() {
*   // How many mutations matching the posts prefix are in progress?
*   const isMutatingPosts = useIsMutating({ mutationKey: ['posts'] })
*
*   return isMutatingPosts ? <span>Saving posts...</span> : null
* }
* ```
*/
function useIsMutating(filters, queryClient) {
	const client = useQueryClient(queryClient);
	return useMutationState({ filters: {
		...filters,
		status: "pending"
	} }, client).length;
}
function getResult(mutationCache, options) {
	return mutationCache.findAll(options.filters).map((mutation) => options.select ? options.select(mutation) : mutation.state);
}
/**
* `useMutationState` is a hook that gives you access to all mutations in the `MutationCache`. You can pass
* `filters` ({@link MutationFilters}) to narrow down your mutations, and `select` to transform the mutation
* state.
*
* @param options - The `filters` to narrow down matched mutations, and an optional `select` to transform the
* mutation state.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns Will be an Array of whatever `select` returns for each matching mutation.
*
* @example
* Get all variables of all running mutations:
* ```tsx
* import { useMutationState } from '@tanstack/react-query'
*
* function PendingPosts() {
*   const pendingVariables = useMutationState({
*     filters: { status: 'pending' },
*     select: (mutation) => mutation.state.variables,
*   })
*
*   return <>{pendingVariables.length} posts saving...</>
* }
* ```
*
* @example
* Get all data for specific mutations via the `mutationKey`:
* ```tsx
* import { useMutation, useMutationState } from '@tanstack/react-query'
*
* const mutationKey = ['posts']
*
* function Posts() {
*   // Some mutation that we want to get the state for
*   const mutation = useMutation({
*     mutationKey,
*     mutationFn: createPosts,
*   })
*
*   const savedPosts = useMutationState({
*     // this mutation key needs to match the mutation key of the given mutation (see above)
*     filters: { mutationKey, status: 'success' },
*     select: (mutation) => mutation.state.data,
*   })
*
*   return (
*     <button onClick={() => mutation.mutate(['New Post'])}>
*       Create post ({savedPosts.length} saved so far)
*     </button>
*   )
* }
* ```
*
* @example
* Access the latest successful mutation data via the `mutationKey`. Each invocation of `mutate` adds a new
* entry to the mutation cache for `gcTime` milliseconds — with the `status: 'success'` filter below, check the
* last item that `useMutationState` returns to get the latest successful invocation:
* ```tsx
* import { useMutationState } from '@tanstack/react-query'
*
* function LatestPost() {
*   const savedPosts = useMutationState({
*     filters: { mutationKey: ['posts'], status: 'success' },
*     select: (mutation) => mutation.state.data,
*   })
*
*   const latestSavedPost = savedPosts[savedPosts.length - 1]
*
*   return <>{latestSavedPost ? 'Saved' : 'Nothing saved yet'}</>
* }
* ```
*/
function useMutationState(options = {}, queryClient) {
	const mutationCache = useQueryClient(queryClient).getMutationCache();
	const optionsRef = import_react.useRef(options);
	const result = import_react.useRef(null);
	if (result.current === null) result.current = getResult(mutationCache, options);
	import_react.useEffect(() => {
		optionsRef.current = options;
	});
	return import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => mutationCache.subscribe(() => {
		const nextResult = replaceEqualDeep(result.current, getResult(mutationCache, optionsRef.current));
		if (result.current !== nextResult) {
			result.current = nextResult;
			notifyManager.schedule(onStoreChange);
		}
	}), [mutationCache]), () => result.current, () => result.current);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useMutation.js
/**
* Unlike queries, mutations are typically used to create/update/delete data or perform server side-effects.
* `useMutation` is the hook for that.
*
* @see {@link mutationOptions} to share these options across multiple `useMutation` call sites, or to look
* the mutation up elsewhere via its `mutationKey` (e.g. with `useMutationState`).
* @param options - The {@link UseMutationOptions} to use — everything you can pass to `useMutation`.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns `mutate`/`mutateAsync` also accept per-call `onSuccess`/`onError`/`onSettled` callbacks as a second
* argument, useful for triggering call-site side effects (e.g. navigation) without coupling them to the shared
* mutation definition. Hook-level callbacks (passed to `options`) fire for every mutation; per-call callbacks
* fire only for the latest call you've made, and only while the component is still mounted — unmounting before
* the mutation settles removes the subscription and prevents them from firing.
*
* @example
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   return (
*     <button
*       onClick={() =>
*         addMutation.mutate('Item', {
*           onError: (error) => console.error('Failed to add item:', error),
*         })
*       }
*     >
*       Add
*     </button>
*   )
* }
* ```
*
* @example
* Rendering the mutation's own state, rather than just firing it off:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   return (
*     <div>
*       {addMutation.isPending ? (
*         'Adding todo...'
*       ) : (
*         <>
*           {addMutation.isError ? (
*             <div>An error occurred: {addMutation.error.message}</div>
*           ) : null}
*           <button onClick={() => addMutation.mutate('Item')}>Add</button>
*         </>
*       )}
*     </div>
*   )
* }
* ```
*
* @example
* Optimistic update via `onMutate`, rolling back on `onError`:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onMutate: async (newTodo) => {
*       await queryClient.cancelQueries({ queryKey: ['todos'] })
*       const previousTodos = queryClient.getQueryData<Array<string>>(['todos'])
*
*       queryClient.setQueryData<Array<string>>(['todos'], (old) => [
*         ...(old ?? []),
*         newTodo,
*       ])
*
*       // Passed to `onError` as `onMutateResult` if the mutation fails.
*       return { previousTodos }
*     },
*     onError: (_err, _newTodo, onMutateResult) => {
*       queryClient.setQueryData(['todos'], onMutateResult?.previousTodos)
*     },
*     onSettled: () => {
*       queryClient.invalidateQueries({ queryKey: ['todos'] })
*     },
*   })
*
*   return (
*     <button onClick={() => addMutation.mutate('Item')}>Add</button>
*   )
* }
* ```
*
* @example
* Callbacks passed per call to `mutate` only fire for the last call — `mutateAsync` gives you a
* promise per call instead, so you can wait for all of them when they succeed:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodos() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   async function handleAddAll(todos: Array<string>) {
*     try {
*       await Promise.all(todos.map((todo) => addMutation.mutateAsync(todo)))
*     } catch (error) {
*       console.error('Failed to add todos:', error)
*     }
*   }
*
*   return (
*     <button onClick={() => handleAddAll(['Todo 1', 'Todo 2', 'Todo 3'])}>
*       Add all
*     </button>
*   )
* }
* ```
*
* @example
* If some of the mutations above can fail independently of the others, and you want to know which ones
* did — rather than losing that information the moment the first one rejects — swap `Promise.all` for
* `Promise.allSettled`:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodos() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   async function handleAddAll(todos: Array<string>) {
*     const addResults = await Promise.allSettled(
*       todos.map((todo) => addMutation.mutateAsync(todo)),
*     )
*
*     addResults.forEach((addResult, index) => {
*       if (addResult.status === 'rejected') {
*         console.error(`Failed to add "${todos[index]}":`, addResult.reason)
*       }
*     })
*   }
*
*   return (
*     <button onClick={() => handleAddAll(['Todo 1', 'Todo 2', 'Todo 3'])}>
*       Add all
*     </button>
*   )
* }
* ```
*/
function useMutation(options, queryClient) {
	const client = useQueryClient(queryClient);
	const [observer] = import_react.useState(() => new MutationObserver(client, options));
	import_react.useEffect(() => {
		observer.setOptions(options);
	}, [observer, options]);
	const result = import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => observer.subscribe(notifyManager.batchCalls(onStoreChange)), [observer]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	const mutate = import_react.useCallback((...args) => {
		observer.mutate(args[0], args[1]).catch(noop);
	}, [observer]);
	if (result.error && shouldThrowError(observer.options.throwOnError, [result.error])) throw result.error;
	return {
		...result,
		mutate,
		mutateAsync: result.mutate
	};
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/mutationOptions.js
function mutationOptions(options) {
	return options;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useInfiniteQuery.js
function useInfiniteQuery(options, queryClient) {
	return useBaseQuery(options, InfiniteQueryObserver, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/index.js
/* istanbul ignore file */
//#endregion
export { CancelledError, HydrationBoundary, InfiniteQueryObserver, IsRestoringProvider, Mutation, MutationCache, MutationObserver, QueriesObserver, Query, QueryCache, QueryClient, QueryClientContext, QueryClientProvider, QueryErrorResetBoundary, QueryObserver, dataTagErrorSymbol, dataTagSymbol, defaultScheduler, defaultShouldDehydrateMutation, defaultShouldDehydrateQuery, dehydrate, dehydrateQuery, environmentManager, streamedQuery as experimental_streamedQuery, focusManager, hashKey, hydrate, infiniteQueryOptions, isCancelledError, isServer, keepPreviousData, matchMutation, matchQuery, mutationOptions, noop, notifyManager, onlineManager, partialMatchKey, queryOptions, replaceEqualDeep, shouldThrowError, skipToken, timeoutManager, unsetMarker, useInfiniteQuery, useIsFetching, useIsMutating, useIsRestoring, useMutation, useMutationState, usePrefetchInfiniteQuery, usePrefetchQuery, useQueries, useQuery, useQueryClient, useQueryErrorResetBoundary, useSuspenseInfiniteQuery, useSuspenseQueries, useSuspenseQuery };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHRhbnN0YWNrX3JlYWN0LXF1ZXJ5LmpzIiwibmFtZXMiOlsiaXNTZXJ2ZXIkMSIsImlzU2VydmVyIiwiaXNTZXJ2ZXIiLCJpc1NlcnZlciIsImdldERlZmF1bHRTdGF0ZSIsImlzU2VydmVyIl0sInNvdXJjZXMiOlsiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3RpbWVvdXRNYW5hZ2VyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3V0aWxzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL2Vudmlyb25tZW50TWFuYWdlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9zdWJzY3JpYmFibGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vZm9jdXNNYW5hZ2VyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL2h5ZHJhdGlvbi5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9ub3RpZnlNYW5hZ2VyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL29ubGluZU1hbmFnZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vcmV0cnllci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9yZW1vdmFibGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeUJlaGF2aW9yLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3F1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3F1ZXJ5T2JzZXJ2ZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeU9ic2VydmVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL211dGF0aW9uLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL211dGF0aW9uQ2FjaGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vbXV0YXRpb25PYnNlcnZlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9xdWVyaWVzT2JzZXJ2ZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vcXVlcnlDYWNoZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9xdWVyeUNsaWVudC5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9zdHJlYW1lZFF1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3R5cGVzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9IeWRyYXRpb25Cb3VuZGFyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vSXNSZXN0b3JpbmdQcm92aWRlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL2Vycm9yQm91bmRhcnlVdGlscy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vc3VzcGVuc2UuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVF1ZXJpZXMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZUJhc2VRdWVyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVN1c3BlbnNlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVN1c3BlbnNlSW5maW5pdGVRdWVyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlU3VzcGVuc2VRdWVyaWVzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VQcmVmZXRjaFF1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VQcmVmZXRjaEluZmluaXRlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3F1ZXJ5T3B0aW9ucy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeU9wdGlvbnMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZUlzRmV0Y2hpbmcuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZU11dGF0aW9uU3RhdGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZU11dGF0aW9uLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9tdXRhdGlvbk9wdGlvbnMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZUluZmluaXRlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvUXVlcnlDbGllbnRQcm92aWRlci50c3hcbi8qKlxuKiBUaGUgY29udGV4dCB0aGF0IGB1c2VRdWVyeUNsaWVudGAgcmVhZHMgZnJvbS4gYFF1ZXJ5Q2xpZW50UHJvdmlkZXJgIGlzIHRoZSBub3JtYWwgd2F5IHRvIHNldCBpdC5cbiovXG5jb25zdCBRdWVyeUNsaWVudENvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KHZvaWQgMCk7XG4vKipcbiogVGhlIGB1c2VRdWVyeUNsaWVudGAgaG9vayByZXR1cm5zIHRoZSBjdXJyZW50IGBRdWVyeUNsaWVudGAgaW5zdGFuY2UuXG4qXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgVGhlIGN1cnJlbnQgYFF1ZXJ5Q2xpZW50YCBpbnN0YW5jZS5cbiogQHRocm93cyBJZiBubyBgcXVlcnlDbGllbnRgIGFyZ3VtZW50IGlzIHBhc3NlZCBhbmQgbm8gYFF1ZXJ5Q2xpZW50UHJvdmlkZXJgIGlzIGZvdW5kIGluIHRoZSBjb21wb25lbnQgdHJlZS5cbiovXG5jb25zdCB1c2VRdWVyeUNsaWVudCA9IChxdWVyeUNsaWVudCkgPT4ge1xuXHRjb25zdCBjbGllbnQgPSBSZWFjdC51c2VDb250ZXh0KFF1ZXJ5Q2xpZW50Q29udGV4dCk7XG5cdGlmIChxdWVyeUNsaWVudCkgcmV0dXJuIHF1ZXJ5Q2xpZW50O1xuXHRpZiAoIWNsaWVudCkgdGhyb3cgbmV3IEVycm9yKFwiTm8gUXVlcnlDbGllbnQgc2V0LCB1c2UgUXVlcnlDbGllbnRQcm92aWRlciB0byBzZXQgb25lXCIpO1xuXHRyZXR1cm4gY2xpZW50O1xufTtcbi8qKlxuKiBVc2UgdGhlIGBRdWVyeUNsaWVudFByb3ZpZGVyYCBjb21wb25lbnQgdG8gY29ubmVjdCBhbmQgcHJvdmlkZSBhIGBRdWVyeUNsaWVudGAgdG8geW91ciBhcHBsaWNhdGlvbi4gQWxzb1xuKiBjYWxscyBgY2xpZW50Lm1vdW50KClgL2BjbGllbnQudW5tb3VudCgpYCBhcyB0aGlzIGNvbXBvbmVudCBtb3VudHMvdW5tb3VudHMsIHdoaWNoIHN1YnNjcmliZXMgdGhlIGNsaWVudCB0b1xuKiBmb2N1cy9vbmxpbmUgZXZlbnRzIChyZXN1bWluZyBhbnkgcGF1c2VkIG11dGF0aW9ucyBhbmQgcmVmZXRjaGluZyBhcyBuZWVkZWQgd2hlbiB0aGUgYXBwIHJlZ2FpbnMgZm9jdXMgb3JcbiogY29tZXMgYmFjayBvbmxpbmUpLlxuKlxuKiBAcmV0dXJucyBUaGUgcHJvdmlkZWQgYGNoaWxkcmVuYCwgd3JhcHBlZCBzbyB0aGV5IGNhbiByZWFkIHRoZSBgUXVlcnlDbGllbnRgIHZpYSBgdXNlUXVlcnlDbGllbnRgLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgUXVlcnlDbGllbnQsIFF1ZXJ5Q2xpZW50UHJvdmlkZXIgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KClcbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIHJldHVybiA8UXVlcnlDbGllbnRQcm92aWRlciBjbGllbnQ9e3F1ZXJ5Q2xpZW50fT4uLi48L1F1ZXJ5Q2xpZW50UHJvdmlkZXI+XG4qIH1cbiogYGBgXG4qL1xuY29uc3QgUXVlcnlDbGllbnRQcm92aWRlciA9ICh7IGNsaWVudCwgY2hpbGRyZW4gfSkgPT4ge1xuXHRSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdGNsaWVudC5tb3VudCgpO1xuXHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRjbGllbnQudW5tb3VudCgpO1xuXHRcdH07XG5cdH0sIFtjbGllbnRdKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goUXVlcnlDbGllbnRDb250ZXh0LlByb3ZpZGVyLCB7XG5cdFx0dmFsdWU6IGNsaWVudCxcblx0XHRjaGlsZHJlblxuXHR9KTtcbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFF1ZXJ5Q2xpZW50Q29udGV4dCwgUXVlcnlDbGllbnRQcm92aWRlciwgdXNlUXVlcnlDbGllbnQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9UXVlcnlDbGllbnRQcm92aWRlci5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL3RpbWVvdXRNYW5hZ2VyLnRzXG5jb25zdCBkZWZhdWx0VGltZW91dFByb3ZpZGVyID0ge1xuXHRzZXRUaW1lb3V0OiAoY2FsbGJhY2ssIGRlbGF5KSA9PiBzZXRUaW1lb3V0KGNhbGxiYWNrLCBkZWxheSksXG5cdGNsZWFyVGltZW91dDogKHRpbWVvdXRJZCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCksXG5cdHNldEludGVydmFsOiAoY2FsbGJhY2ssIGRlbGF5KSA9PiBzZXRJbnRlcnZhbChjYWxsYmFjaywgZGVsYXkpLFxuXHRjbGVhckludGVydmFsOiAoaW50ZXJ2YWxJZCkgPT4gY2xlYXJJbnRlcnZhbChpbnRlcnZhbElkKVxufTtcbi8qKlxuKiBBbGxvd3MgY3VzdG9taXphdGlvbiBvZiBob3cgdGltZW91dHMgYXJlIGNyZWF0ZWQuXG4qXG4qIEB0YW5zdGFjay9xdWVyeS1jb3JlIG1ha2VzIGxpYmVyYWwgdXNlIG9mIHRpbWVvdXRzIHRvIGltcGxlbWVudCBgc3RhbGVUaW1lYFxuKiBhbmQgYGdjVGltZWAuIFRoZSBkZWZhdWx0IFRpbWVvdXRNYW5hZ2VyIHByb3ZpZGVyIHVzZXMgdGhlIHBsYXRmb3JtJ3MgZ2xvYmFsXG4qIGBzZXRUaW1lb3V0YCBpbXBsZW1lbnRhdGlvbiwgd2hpY2ggaXMga25vd24gdG8gaGF2ZSBzY2FsYWJpbGl0eSBpc3N1ZXMgd2l0aFxuKiB0aG91c2FuZHMgb2YgdGltZW91dHMgb24gdGhlIGV2ZW50IGxvb3AuXG4qXG4qIElmIHlvdSBoaXQgdGhpcyBsaW1pdGF0aW9uLCBjb25zaWRlciBwcm92aWRpbmcgYSBjdXN0b20gVGltZW91dFByb3ZpZGVyIHRoYXRcbiogY29hbGVzY2VzIHRpbWVvdXRzLlxuKi9cbnZhciBUaW1lb3V0TWFuYWdlciA9IGNsYXNzIHtcblx0I3Byb3ZpZGVyID0gZGVmYXVsdFRpbWVvdXRQcm92aWRlcjtcblx0I3Byb3ZpZGVyQ2FsbGVkID0gZmFsc2U7XG5cdC8qKlxuXHQqIGBzZXRUaW1lb3V0UHJvdmlkZXJgIGNhbiBiZSB1c2VkIHRvIHNldCBhIGN1c3RvbSBpbXBsZW1lbnRhdGlvbiBvZiB0aGVcblx0KiBgc2V0VGltZW91dGAsIGBjbGVhclRpbWVvdXRgLCBgc2V0SW50ZXJ2YWxgLCBgY2xlYXJJbnRlcnZhbGAgZnVuY3Rpb25zLFxuXHQqIGNhbGxlZCBhIGBUaW1lb3V0UHJvdmlkZXJgLlxuXHQqXG5cdCogVGhpcyBtYXkgYmUgdXNlZnVsIGlmIHlvdSBub3RpY2UgZXZlbnQgbG9vcCBwZXJmb3JtYW5jZSBpc3N1ZXMgd2l0aFxuXHQqIHRob3VzYW5kcyBvZiBxdWVyaWVzLiBBIGN1c3RvbSBUaW1lb3V0UHJvdmlkZXIgY291bGQgYWxzbyBzdXBwb3J0IHRpbWVyXG5cdCogZGVsYXlzIGxvbmdlciB0aGFuIHRoZSBnbG9iYWwgYHNldFRpbWVvdXRgIG1heGltdW0gZGVsYXkgdmFsdWUgb2YgYWJvdXRcblx0KiAyNCBkYXlzLlxuXHQqXG5cdCogSXQgaXMgaW1wb3J0YW50IHRvIGNhbGwgYHNldFRpbWVvdXRQcm92aWRlcmAgYmVmb3JlIGNyZWF0aW5nIGFcblx0KiBRdWVyeUNsaWVudCBvciBxdWVyaWVzLCBzbyB0aGF0IHRoZSBzYW1lIHByb3ZpZGVyIGlzIHVzZWQgY29uc2lzdGVudGx5XG5cdCogZm9yIGFsbCB0aW1lcnMgaW4gdGhlIGFwcGxpY2F0aW9uLCBzaW5jZSBkaWZmZXJlbnQgVGltZW91dFByb3ZpZGVyc1xuXHQqIGNhbm5vdCBjYW5jZWwgZWFjaCBvdGhlcnMnIHRpbWVycy5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciwgUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KiBpbXBvcnQgeyBDdXN0b21UaW1lb3V0UHJvdmlkZXIgfSBmcm9tICcuL0N1c3RvbVRpbWVvdXRQcm92aWRlcidcblx0KlxuXHQqIHRpbWVvdXRNYW5hZ2VyLnNldFRpbWVvdXRQcm92aWRlcihuZXcgQ3VzdG9tVGltZW91dFByb3ZpZGVyKCkpXG5cdCpcblx0KiBleHBvcnQgY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRUaW1lb3V0UHJvdmlkZXIocHJvdmlkZXIpIHtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0XHRpZiAodGhpcy4jcHJvdmlkZXJDYWxsZWQgJiYgcHJvdmlkZXIgIT09IHRoaXMuI3Byb3ZpZGVyKSBjb25zb2xlLmVycm9yKGBbdGltZW91dE1hbmFnZXJdOiBTd2l0Y2hpbmcgcHJvdmlkZXIgYWZ0ZXIgY2FsbHMgdG8gcHJldmlvdXMgcHJvdmlkZXIgbWlnaHQgcmVzdWx0IGluIHVuZXhwZWN0ZWQgYmVoYXZpb3IuYCwge1xuXHRcdFx0XHRwcmV2aW91czogdGhpcy4jcHJvdmlkZXIsXG5cdFx0XHRcdHByb3ZpZGVyXG5cdFx0XHR9KTtcblx0XHR9XG5cdFx0dGhpcy4jcHJvdmlkZXIgPSBwcm92aWRlcjtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB0aGlzLiNwcm92aWRlckNhbGxlZCA9IGZhbHNlO1xuXHR9XG5cdC8qKlxuXHQqIGBzZXRUaW1lb3V0YCBzY2hlZHVsZXMgYSBjYWxsYmFjayB0byBydW4gYWZ0ZXIgYXBwcm94aW1hdGVseSBgZGVsYXlgXG5cdCogbWlsbGlzZWNvbmRzLCBsaWtlIHRoZSBnbG9iYWwgYHNldFRpbWVvdXRgIGZ1bmN0aW9uLiBUaGUgY2FsbGJhY2sgY2FuIGJlXG5cdCogY2FuY2VsZWQgd2l0aCBgY2xlYXJUaW1lb3V0YC5cblx0KlxuXHQqIEl0IHJldHVybnMgYSB0aW1lciBJRCwgd2hpY2ggbWF5IGJlIGEgbnVtYmVyIG9yIGFuIG9iamVjdCB0aGF0IGNhbiBiZVxuXHQqIGNvZXJjZWQgdG8gYSBudW1iZXIgdmlhIGBTeW1ib2wudG9QcmltaXRpdmVgLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IHRpbWVvdXRNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCB0aW1lb3V0SWQgPSB0aW1lb3V0TWFuYWdlci5zZXRUaW1lb3V0KFxuXHQqICAgKCkgPT4gY29uc29sZS5sb2coJ3JhbiBhdDonLCBuZXcgRGF0ZSgpKSxcblx0KiAgIDEwMDAsXG5cdCogKVxuXHQqXG5cdCogY29uc3QgdGltZW91dElkTnVtYmVyOiBudW1iZXIgPSBOdW1iZXIodGltZW91dElkKVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRUaW1lb3V0KGNhbGxiYWNrLCBkZWxheSkge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHRoaXMuI3Byb3ZpZGVyQ2FsbGVkID0gdHJ1ZTtcblx0XHRyZXR1cm4gdGhpcy4jcHJvdmlkZXIuc2V0VGltZW91dChjYWxsYmFjaywgZGVsYXkpO1xuXHR9XG5cdC8qKlxuXHQqIGBjbGVhclRpbWVvdXRgIGNhbmNlbHMgYSB0aW1lb3V0IGNhbGxiYWNrIHNjaGVkdWxlZCB3aXRoIGBzZXRUaW1lb3V0YCxcblx0KiBsaWtlIHRoZSBnbG9iYWwgYGNsZWFyVGltZW91dGAgZnVuY3Rpb24uIEl0IHNob3VsZCBiZSBjYWxsZWQgd2l0aCBhXG5cdCogdGltZXIgSUQgcmV0dXJuZWQgYnkgYHNldFRpbWVvdXRgLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IHRpbWVvdXRNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCB0aW1lb3V0SWQgPSB0aW1lb3V0TWFuYWdlci5zZXRUaW1lb3V0KFxuXHQqICAgKCkgPT4gY29uc29sZS5sb2coJ3JhbiBhdDonLCBuZXcgRGF0ZSgpKSxcblx0KiAgIDEwMDAsXG5cdCogKVxuXHQqXG5cdCogdGltZW91dE1hbmFnZXIuY2xlYXJUaW1lb3V0KHRpbWVvdXRJZClcblx0KiBgYGBcblx0Ki9cblx0Y2xlYXJUaW1lb3V0KHRpbWVvdXRJZCkge1xuXHRcdHRoaXMuI3Byb3ZpZGVyLmNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuXHR9XG5cdC8qKlxuXHQqIGBzZXRJbnRlcnZhbGAgc2NoZWR1bGVzIGEgY2FsbGJhY2sgdG8gYmUgY2FsbGVkIGFwcHJveGltYXRlbHkgZXZlcnlcblx0KiBgZGVsYXlgIG1pbGxpc2Vjb25kcywgbGlrZSB0aGUgZ2xvYmFsIGBzZXRJbnRlcnZhbGAgZnVuY3Rpb24uXG5cdCpcblx0KiBMaWtlIGBzZXRUaW1lb3V0YCwgaXQgcmV0dXJucyBhIHRpbWVyIElELCB3aGljaCBtYXkgYmUgYSBudW1iZXIgb3IgYW5cblx0KiBvYmplY3QgdGhhdCBjYW4gYmUgY29lcmNlZCB0byBhIG51bWJlciB2aWEgYFN5bWJvbC50b1ByaW1pdGl2ZWAuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaW1wb3J0IHsgdGltZW91dE1hbmFnZXIgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIGNvbnN0IGludGVydmFsSWQgPSB0aW1lb3V0TWFuYWdlci5zZXRJbnRlcnZhbChcblx0KiAgICgpID0+IGNvbnNvbGUubG9nKCdyYW4gYXQ6JywgbmV3IERhdGUoKSksXG5cdCogICAxMDAwLFxuXHQqIClcblx0KiBgYGBcblx0Ki9cblx0c2V0SW50ZXJ2YWwoY2FsbGJhY2ssIGRlbGF5KSB7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgdGhpcy4jcHJvdmlkZXJDYWxsZWQgPSB0cnVlO1xuXHRcdHJldHVybiB0aGlzLiNwcm92aWRlci5zZXRJbnRlcnZhbChjYWxsYmFjaywgZGVsYXkpO1xuXHR9XG5cdC8qKlxuXHQqIGBjbGVhckludGVydmFsYCBjYW4gYmUgdXNlZCB0byBjYW5jZWwgYW4gaW50ZXJ2YWwsIGxpa2UgdGhlIGdsb2JhbFxuXHQqIGBjbGVhckludGVydmFsYCBmdW5jdGlvbi4gSXQgc2hvdWxkIGJlIGNhbGxlZCB3aXRoIGFuIGludGVydmFsIElEXG5cdCogcmV0dXJuZWQgYnkgYHNldEludGVydmFsYC5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgaW50ZXJ2YWxJZCA9IHRpbWVvdXRNYW5hZ2VyLnNldEludGVydmFsKFxuXHQqICAgKCkgPT4gY29uc29sZS5sb2coJ3JhbiBhdDonLCBuZXcgRGF0ZSgpKSxcblx0KiAgIDEwMDAsXG5cdCogKVxuXHQqXG5cdCogdGltZW91dE1hbmFnZXIuY2xlYXJJbnRlcnZhbChpbnRlcnZhbElkKVxuXHQqIGBgYFxuXHQqL1xuXHRjbGVhckludGVydmFsKGludGVydmFsSWQpIHtcblx0XHR0aGlzLiNwcm92aWRlci5jbGVhckludGVydmFsKGludGVydmFsSWQpO1xuXHR9XG59O1xuLyoqXG4qIFNpbmdsZXRvbiBpbnN0YW5jZSBvZiB7QGxpbmsgVGltZW91dE1hbmFnZXJ9LCB1c2VkIHRocm91Z2hvdXQgVGFuU3RhY2sgUXVlcnkgdG8gc2NoZWR1bGUgYW5kIGNhbmNlbCB0aW1lcnMuXG4qL1xuY29uc3QgdGltZW91dE1hbmFnZXIgPSBuZXcgVGltZW91dE1hbmFnZXIoKTtcbi8qKlxuKiBJbiBtYW55IGNhc2VzIGNvZGUgd2FudHMgdG8gZGVsYXkgdG8gdGhlIG5leHQgZXZlbnQgbG9vcCB0aWNrOyB0aGlzIGlzIG5vdFxuKiBtZWRpYXRlZCBieSB7QGxpbmsgdGltZW91dE1hbmFnZXJ9LlxuKlxuKiBUaGlzIGZ1bmN0aW9uIGlzIHByb3ZpZGVkIHRvIG1ha2UgYXVkaXRpbmcgdGhlIGB0YW5zdGFjay9xdWVyeS1jb3JlYCBmb3JcbiogaW5jb3JyZWN0IHVzZSBvZiBzeXN0ZW0gYHNldFRpbWVvdXRgIGVhc2llci5cbiovXG5mdW5jdGlvbiBzeXN0ZW1TZXRUaW1lb3V0WmVybyhjYWxsYmFjaykge1xuXHRzZXRUaW1lb3V0KGNhbGxiYWNrLCAwKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgVGltZW91dE1hbmFnZXIsIGRlZmF1bHRUaW1lb3V0UHJvdmlkZXIsIHN5c3RlbVNldFRpbWVvdXRaZXJvLCB0aW1lb3V0TWFuYWdlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD10aW1lb3V0TWFuYWdlci5qcy5tYXAiLCJpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gXCIuL3RpbWVvdXRNYW5hZ2VyLmpzXCI7XG4vLyNyZWdpb24gc3JjL3V0aWxzLnRzXG4vKiogQGRlcHJlY2F0ZWRcbiogdXNlIGBlbnZpcm9ubWVudE1hbmFnZXIuaXNTZXJ2ZXIoKWAgaW5zdGVhZC5cbiovXG5jb25zdCBpc1NlcnZlciA9IHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIgfHwgXCJEZW5vXCIgaW4gZ2xvYmFsVGhpcztcbmZ1bmN0aW9uIG5vb3AoKSB7fVxuZnVuY3Rpb24gZnVuY3Rpb25hbFVwZGF0ZSh1cGRhdGVyLCBpbnB1dCkge1xuXHRyZXR1cm4gdHlwZW9mIHVwZGF0ZXIgPT09IFwiZnVuY3Rpb25cIiA/IHVwZGF0ZXIoaW5wdXQpIDogdXBkYXRlcjtcbn1cbmZ1bmN0aW9uIGlzVmFsaWRUaW1lb3V0KHZhbHVlKSB7XG5cdHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwibnVtYmVyXCIgJiYgdmFsdWUgPj0gMCAmJiB2YWx1ZSAhPT0gSW5maW5pdHk7XG59XG5mdW5jdGlvbiB0aW1lVW50aWxTdGFsZSh1cGRhdGVkQXQsIHN0YWxlVGltZSkge1xuXHRyZXR1cm4gTWF0aC5tYXgodXBkYXRlZEF0ICsgKHN0YWxlVGltZSB8fCAwKSAtIERhdGUubm93KCksIDApO1xufVxuZnVuY3Rpb24gcmVzb2x2ZVF1ZXJ5VmFsdWUodmFsdWUsIHF1ZXJ5KSB7XG5cdHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIiA/IHZhbHVlKHF1ZXJ5KSA6IHZhbHVlO1xufVxuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgcXVlcnkgbWF0Y2hlcyB0aGUgZ2l2ZW4ge0BsaW5rIFF1ZXJ5RmlsdGVyc30uXG4qIEV2ZXJ5IGZpbHRlciB0aGF0IGlzIHNwZWNpZmllZCBtdXN0IG1hdGNoOyBmaWx0ZXJzIHRoYXQgYXJlIGxlZnQgdW5zcGVjaWZpZWQgYXJlIGlnbm9yZWQuXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcbipcbiogY29uc3QgbWF0Y2hpbmdRdWVyaWVzID0gcXVlcnlDYWNoZVxuKiAgIC5nZXRBbGwoKVxuKiAgIC5maWx0ZXIoKHF1ZXJ5KSA9PiBtYXRjaFF1ZXJ5KHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9LCBxdWVyeSkpXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIG1hdGNoUXVlcnkoZmlsdGVycywgcXVlcnkpIHtcblx0Y29uc3QgeyB0eXBlID0gXCJhbGxcIiwgZXhhY3QsIGZldGNoU3RhdHVzLCBwcmVkaWNhdGUsIHF1ZXJ5S2V5LCBzdGFsZSB9ID0gZmlsdGVycztcblx0aWYgKHF1ZXJ5S2V5KSB7XG5cdFx0aWYgKGV4YWN0KSB7XG5cdFx0XHRpZiAocXVlcnkucXVlcnlIYXNoICE9PSBoYXNoUXVlcnlLZXlCeU9wdGlvbnMocXVlcnlLZXksIHF1ZXJ5Lm9wdGlvbnMpKSByZXR1cm4gZmFsc2U7XG5cdFx0fSBlbHNlIGlmICghcGFydGlhbE1hdGNoS2V5KHF1ZXJ5LnF1ZXJ5S2V5LCBxdWVyeUtleSkpIHJldHVybiBmYWxzZTtcblx0fVxuXHRpZiAodHlwZSAhPT0gXCJhbGxcIikge1xuXHRcdGNvbnN0IGlzQWN0aXZlID0gcXVlcnkuaXNBY3RpdmUoKTtcblx0XHRpZiAodHlwZSA9PT0gXCJhY3RpdmVcIiAmJiAhaXNBY3RpdmUpIHJldHVybiBmYWxzZTtcblx0XHRpZiAodHlwZSA9PT0gXCJpbmFjdGl2ZVwiICYmIGlzQWN0aXZlKSByZXR1cm4gZmFsc2U7XG5cdH1cblx0aWYgKHR5cGVvZiBzdGFsZSA9PT0gXCJib29sZWFuXCIgJiYgcXVlcnkuaXNTdGFsZSgpICE9PSBzdGFsZSkgcmV0dXJuIGZhbHNlO1xuXHRpZiAoZmV0Y2hTdGF0dXMgJiYgZmV0Y2hTdGF0dXMgIT09IHF1ZXJ5LnN0YXRlLmZldGNoU3RhdHVzKSByZXR1cm4gZmFsc2U7XG5cdGlmIChwcmVkaWNhdGUgJiYgIXByZWRpY2F0ZShxdWVyeSkpIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIHRydWU7XG59XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSBtdXRhdGlvbiBtYXRjaGVzIHRoZSBnaXZlbiB7QGxpbmsgTXV0YXRpb25GaWx0ZXJzfS5cbiogRXZlcnkgZmlsdGVyIHRoYXQgaXMgc3BlY2lmaWVkIG11c3QgbWF0Y2g7IGZpbHRlcnMgdGhhdCBhcmUgbGVmdCB1bnNwZWNpZmllZCBhcmUgaWdub3JlZC5cbiogSWYgYSBgbXV0YXRpb25LZXlgIGZpbHRlciBpcyBwcm92aWRlZCBidXQgdGhlIG11dGF0aW9uIGhhcyBubyBgbXV0YXRpb25LZXlgIG9mIGl0cyBvd24sIGl0IGRvZXMgbm90IG1hdGNoLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCBtdXRhdGlvbkNhY2hlID0gcXVlcnlDbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpXG4qXG4qIGNvbnN0IG1hdGNoaW5nTXV0YXRpb25zID0gbXV0YXRpb25DYWNoZVxuKiAgIC5nZXRBbGwoKVxuKiAgIC5maWx0ZXIoKG11dGF0aW9uKSA9PiBtYXRjaE11dGF0aW9uKHsgbXV0YXRpb25LZXk6IFsnYWRkUG9zdCddIH0sIG11dGF0aW9uKSlcbiogYGBgXG4qL1xuZnVuY3Rpb24gbWF0Y2hNdXRhdGlvbihmaWx0ZXJzLCBtdXRhdGlvbikge1xuXHRjb25zdCB7IGV4YWN0LCBzdGF0dXMsIHByZWRpY2F0ZSwgbXV0YXRpb25LZXkgfSA9IGZpbHRlcnM7XG5cdGlmIChtdXRhdGlvbktleSkge1xuXHRcdGlmICghbXV0YXRpb24ub3B0aW9ucy5tdXRhdGlvbktleSkgcmV0dXJuIGZhbHNlO1xuXHRcdGlmIChleGFjdCkge1xuXHRcdFx0aWYgKGhhc2hLZXkobXV0YXRpb24ub3B0aW9ucy5tdXRhdGlvbktleSkgIT09IGhhc2hLZXkobXV0YXRpb25LZXkpKSByZXR1cm4gZmFsc2U7XG5cdFx0fSBlbHNlIGlmICghcGFydGlhbE1hdGNoS2V5KG11dGF0aW9uLm9wdGlvbnMubXV0YXRpb25LZXksIG11dGF0aW9uS2V5KSkgcmV0dXJuIGZhbHNlO1xuXHR9XG5cdGlmIChzdGF0dXMgJiYgbXV0YXRpb24uc3RhdGUuc3RhdHVzICE9PSBzdGF0dXMpIHJldHVybiBmYWxzZTtcblx0aWYgKHByZWRpY2F0ZSAmJiAhcHJlZGljYXRlKG11dGF0aW9uKSkgcmV0dXJuIGZhbHNlO1xuXHRyZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIGhhc2hRdWVyeUtleUJ5T3B0aW9ucyhxdWVyeUtleSwgb3B0aW9ucykge1xuXHRyZXR1cm4gKG9wdGlvbnM/LnF1ZXJ5S2V5SGFzaEZuIHx8IGhhc2hLZXkpKHF1ZXJ5S2V5KTtcbn1cbi8qKlxuKiBEZWZhdWx0IHF1ZXJ5ICYgbXV0YXRpb24ga2V5cyBoYXNoIGZ1bmN0aW9uLlxuKiBIYXNoZXMgdGhlIHZhbHVlIGludG8gYSBzdGFibGUgaGFzaC5cbipcbiogQGV4YW1wbGVcbiogYGBgdHNcbiogLy8gT2JqZWN0IGtleXMgYXJlIHNvcnRlZCwgc28ga2V5IG9yZGVyIGRvZXNuJ3QgYWZmZWN0IHRoZSBoYXNoOlxuKiBoYXNoS2V5KFsndG9kb3MnLCB7IHBhZ2U6IDEsIGZpbHRlcjogJ2RvbmUnIH1dKSAvLyA9PT0gJ1tcInRvZG9zXCIse1wiZmlsdGVyXCI6XCJkb25lXCIsXCJwYWdlXCI6MX1dJ1xuKiBgYGBcbiovXG5mdW5jdGlvbiBoYXNoS2V5KHF1ZXJ5S2V5KSB7XG5cdHJldHVybiBKU09OLnN0cmluZ2lmeShxdWVyeUtleSwgKF8sIHZhbCkgPT4gaXNQbGFpbk9iamVjdCh2YWwpID8gT2JqZWN0LmtleXModmFsKS5zb3J0KCkucmVkdWNlKChyZXN1bHQsIGtleSkgPT4ge1xuXHRcdHJlc3VsdFtrZXldID0gdmFsW2tleV07XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fSwge30pIDogdmFsKTtcbn1cbmZ1bmN0aW9uIHBhcnRpYWxNYXRjaEtleShhLCBiKSB7XG5cdGlmIChhID09PSBiKSByZXR1cm4gdHJ1ZTtcblx0aWYgKHR5cGVvZiBhICE9PSB0eXBlb2YgYikgcmV0dXJuIGZhbHNlO1xuXHRpZiAoYSAmJiBiICYmIHR5cGVvZiBhID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBiID09PSBcIm9iamVjdFwiKSB7XG5cdFx0aWYgKEFycmF5LmlzQXJyYXkoYSkgJiYgQXJyYXkuaXNBcnJheShiKSkge1xuXHRcdFx0aWYgKGIubGVuZ3RoID4gYS5sZW5ndGgpIHJldHVybiBmYWxzZTtcblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgYi5sZW5ndGg7IGkrKykgaWYgKCFwYXJ0aWFsTWF0Y2hLZXkoYVtpXSwgYltpXSkpIHJldHVybiBmYWxzZTtcblx0XHRcdHJldHVybiB0cnVlO1xuXHRcdH1cblx0XHRjb25zdCBiS2V5cyA9IE9iamVjdC5rZXlzKGIpO1xuXHRcdGZvciAoY29uc3Qga2V5IG9mIGJLZXlzKSBpZiAoIXBhcnRpYWxNYXRjaEtleShhW2tleV0sIGJba2V5XSkpIHJldHVybiBmYWxzZTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0fVxuXHRyZXR1cm4gZmFsc2U7XG59XG5jb25zdCBoYXNPd24gPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5O1xuZnVuY3Rpb24gcmVwbGFjZUVxdWFsRGVlcChhLCBiLCBkZXB0aCA9IDApIHtcblx0aWYgKGEgPT09IGIpIHJldHVybiBhO1xuXHRpZiAoZGVwdGggPiA1MDApIHJldHVybiBiO1xuXHRjb25zdCBhcnJheSA9IGlzUGxhaW5BcnJheShhKSAmJiBpc1BsYWluQXJyYXkoYik7XG5cdGlmICghYXJyYXkgJiYgIShpc1BsYWluT2JqZWN0KGEpICYmIGlzUGxhaW5PYmplY3QoYikpKSByZXR1cm4gYjtcblx0Y29uc3QgYVNpemUgPSAoYXJyYXkgPyBhIDogT2JqZWN0LmtleXMoYSkpLmxlbmd0aDtcblx0Y29uc3QgYkl0ZW1zID0gYXJyYXkgPyBiIDogT2JqZWN0LmtleXMoYik7XG5cdGNvbnN0IGJTaXplID0gYkl0ZW1zLmxlbmd0aDtcblx0Y29uc3QgY29weSA9IGFycmF5ID8gbmV3IEFycmF5KGJTaXplKSA6IHt9O1xuXHRsZXQgZXF1YWxJdGVtcyA9IDA7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgYlNpemU7IGkrKykge1xuXHRcdGNvbnN0IGtleSA9IGFycmF5ID8gaSA6IGJJdGVtc1tpXTtcblx0XHRjb25zdCBhSXRlbSA9IGFba2V5XTtcblx0XHRjb25zdCBiSXRlbSA9IGJba2V5XTtcblx0XHRpZiAoYUl0ZW0gPT09IGJJdGVtKSB7XG5cdFx0XHRjb3B5W2tleV0gPSBhSXRlbTtcblx0XHRcdGlmIChhcnJheSA/IGkgPCBhU2l6ZSA6IGhhc093bi5jYWxsKGEsIGtleSkpIGVxdWFsSXRlbXMrKztcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHRpZiAoYUl0ZW0gPT09IG51bGwgfHwgYkl0ZW0gPT09IG51bGwgfHwgdHlwZW9mIGFJdGVtICE9PSBcIm9iamVjdFwiIHx8IHR5cGVvZiBiSXRlbSAhPT0gXCJvYmplY3RcIikge1xuXHRcdFx0Y29weVtrZXldID0gYkl0ZW07XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0Y29uc3QgdiA9IHJlcGxhY2VFcXVhbERlZXAoYUl0ZW0sIGJJdGVtLCBkZXB0aCArIDEpO1xuXHRcdGNvcHlba2V5XSA9IHY7XG5cdFx0aWYgKHYgPT09IGFJdGVtKSBlcXVhbEl0ZW1zKys7XG5cdH1cblx0cmV0dXJuIGFTaXplID09PSBiU2l6ZSAmJiBlcXVhbEl0ZW1zID09PSBhU2l6ZSA/IGEgOiBjb3B5O1xufVxuLyoqXG4qIFNoYWxsb3cgY29tcGFyZSBvYmplY3RzLlxuKi9cbmZ1bmN0aW9uIHNoYWxsb3dFcXVhbE9iamVjdHMoYSwgYikge1xuXHRpZiAoIWIgfHwgT2JqZWN0LmtleXMoYSkubGVuZ3RoICE9PSBPYmplY3Qua2V5cyhiKS5sZW5ndGgpIHJldHVybiBmYWxzZTtcblx0Zm9yIChjb25zdCBrZXkgaW4gYSkgaWYgKGFba2V5XSAhPT0gYltrZXldKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gaXNQbGFpbkFycmF5KHZhbHVlKSB7XG5cdHJldHVybiBBcnJheS5pc0FycmF5KHZhbHVlKSAmJiB2YWx1ZS5sZW5ndGggPT09IE9iamVjdC5rZXlzKHZhbHVlKS5sZW5ndGg7XG59XG5mdW5jdGlvbiBpc1BsYWluT2JqZWN0KG8pIHtcblx0aWYgKCFoYXNPYmplY3RQcm90b3R5cGUobykpIHJldHVybiBmYWxzZTtcblx0Y29uc3Qgb2JqZWN0UHJvdG90eXBlID0gT2JqZWN0LmdldFByb3RvdHlwZU9mKG8pO1xuXHRjb25zdCBjdG9yID0gb2JqZWN0UHJvdG90eXBlPy5jb25zdHJ1Y3Rvcjtcblx0aWYgKGN0b3IgPT09IHZvaWQgMCkgcmV0dXJuIHRydWU7XG5cdGlmICh0eXBlb2YgY3RvciAhPT0gXCJmdW5jdGlvblwiKSByZXR1cm4gZmFsc2U7XG5cdGNvbnN0IHByb3QgPSBjdG9yLnByb3RvdHlwZTtcblx0aWYgKCFoYXNPYmplY3RQcm90b3R5cGUocHJvdCkpIHJldHVybiBmYWxzZTtcblx0aWYgKCFwcm90Lmhhc093blByb3BlcnR5KFwiaXNQcm90b3R5cGVPZlwiKSkgcmV0dXJuIGZhbHNlO1xuXHRpZiAob2JqZWN0UHJvdG90eXBlICE9PSBPYmplY3QucHJvdG90eXBlKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gaGFzT2JqZWN0UHJvdG90eXBlKG8pIHtcblx0cmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvKSA9PT0gXCJbb2JqZWN0IE9iamVjdF1cIjtcbn1cbmZ1bmN0aW9uIHNsZWVwKHRpbWVvdXQpIHtcblx0cmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0dGltZW91dE1hbmFnZXIuc2V0VGltZW91dChyZXNvbHZlLCB0aW1lb3V0KTtcblx0fSk7XG59XG5mdW5jdGlvbiByZXBsYWNlRGF0YShwcmV2RGF0YSwgZGF0YSwgb3B0aW9ucykge1xuXHRpZiAodHlwZW9mIG9wdGlvbnMuc3RydWN0dXJhbFNoYXJpbmcgPT09IFwiZnVuY3Rpb25cIikgcmV0dXJuIG9wdGlvbnMuc3RydWN0dXJhbFNoYXJpbmcocHJldkRhdGEsIGRhdGEpO1xuXHRlbHNlIGlmIChvcHRpb25zLnN0cnVjdHVyYWxTaGFyaW5nICE9PSBmYWxzZSkge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHRyeSB7XG5cdFx0XHRyZXR1cm4gcmVwbGFjZUVxdWFsRGVlcChwcmV2RGF0YSwgZGF0YSk7XG5cdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdGNvbnNvbGUuZXJyb3IoYFN0cnVjdHVyYWwgc2hhcmluZyByZXF1aXJlcyBkYXRhIHRvIGJlIEpTT04gc2VyaWFsaXphYmxlLiBUbyBmaXggdGhpcywgdHVybiBvZmYgc3RydWN0dXJhbFNoYXJpbmcgb3IgcmV0dXJuIEpTT04tc2VyaWFsaXphYmxlIGRhdGEgZnJvbSB5b3VyIHF1ZXJ5Rm4uIFske29wdGlvbnMucXVlcnlIYXNofV06ICR7ZXJyb3J9YCk7XG5cdFx0XHR0aHJvdyBlcnJvcjtcblx0XHR9XG5cdFx0cmV0dXJuIHJlcGxhY2VFcXVhbERlZXAocHJldkRhdGEsIGRhdGEpO1xuXHR9XG5cdHJldHVybiBkYXRhO1xufVxuLyoqXG4qIEludGVuZGVkIHRvIGJlIHBhc3NlZCBhcyBhIHF1ZXJ5J3MgYHBsYWNlaG9sZGVyRGF0YWAgb3B0aW9uLCBmb3IgZXhhbXBsZVxuKiBgcGxhY2Vob2xkZXJEYXRhOiBrZWVwUHJldmlvdXNEYXRhYC4gSW5zdGVhZCBvZiByZXNldHRpbmcgdGhlIHF1ZXJ5J3MgZGF0YSB0byBgdW5kZWZpbmVkYCB3aGlsZSBhIG5ld1xuKiBxdWVyeSBrZXkgaXMgZmV0Y2hpbmcsIGl0IGtlZXBzIGRpc3BsYXlpbmcgdGhlIHByZXZpb3VzbHkgZmV0Y2hlZCBkYXRhIHVudGlsIHRoZSBuZXcgZGF0YSBhcnJpdmVzLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBuZXcgUXVlcnlPYnNlcnZlcihxdWVyeUNsaWVudCwge1xuKiAgIHF1ZXJ5S2V5OiBbJ3Bvc3RzJywgcGFnZV0sXG4qICAgcXVlcnlGbjogKCkgPT4gZmV0Y2hQb3N0cyhwYWdlKSxcbiogICBwbGFjZWhvbGRlckRhdGE6IGtlZXBQcmV2aW91c0RhdGEsXG4qIH0pXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIGtlZXBQcmV2aW91c0RhdGEocHJldmlvdXNEYXRhKSB7XG5cdHJldHVybiBwcmV2aW91c0RhdGE7XG59XG5mdW5jdGlvbiBhZGRUb0VuZChpdGVtcywgaXRlbSwgbWF4ID0gMCkge1xuXHRjb25zdCBuZXdJdGVtcyA9IFsuLi5pdGVtcywgaXRlbV07XG5cdHJldHVybiBtYXggJiYgbmV3SXRlbXMubGVuZ3RoID4gbWF4ID8gbmV3SXRlbXMuc2xpY2UoMSkgOiBuZXdJdGVtcztcbn1cbmZ1bmN0aW9uIGFkZFRvU3RhcnQoaXRlbXMsIGl0ZW0sIG1heCA9IDApIHtcblx0Y29uc3QgbmV3SXRlbXMgPSBbaXRlbSwgLi4uaXRlbXNdO1xuXHRyZXR1cm4gbWF4ICYmIG5ld0l0ZW1zLmxlbmd0aCA+IG1heCA/IG5ld0l0ZW1zLnNsaWNlKDAsIC0xKSA6IG5ld0l0ZW1zO1xufVxuLyoqXG4qIFNlbnRpbmVsIHZhbHVlIHRoYXQgY2FuIGJlIHBhc3NlZCBhcyBhIHF1ZXJ5J3MgYHF1ZXJ5Rm5gIHRvIGNvbmRpdGlvbmFsbHkgZGlzYWJsZSB0aGUgcXVlcnkgKGVxdWl2YWxlbnRcbiogdG8gYGVuYWJsZWQ6IGZhbHNlYCkgd2hpbGUgcHJlc2VydmluZyBmdWxsIHR5cGUgaW5mZXJlbmNlIGZvciB0aGUgcXVlcnkncyBkYXRhLiBVbmxpa2UgYGVuYWJsZWQ6IGZhbHNlYCxcbiogYSBxdWVyeSBkaXNhYmxlZCB2aWEgYHNraXBUb2tlbmAgY2Fubm90IGJlIHRyaWdnZXJlZCB3aXRoIGByZWZldGNoYC5cbipcbiogQGV4YW1wbGVcbiogYGBgdHNcbiogbmV3IFF1ZXJ5T2JzZXJ2ZXIocXVlcnlDbGllbnQsIHtcbiogICBxdWVyeUtleTogWydwb3N0JywgcG9zdElkXSxcbiogICBxdWVyeUZuOiBwb3N0SWQgIT0gbnVsbCA/ICgpID0+IGZldGNoUG9zdChwb3N0SWQpIDogc2tpcFRva2VuLFxuKiB9KVxuKiBgYGBcbiovXG5jb25zdCBza2lwVG9rZW4gPSBTeW1ib2woKTtcbmZ1bmN0aW9uIGVuc3VyZVF1ZXJ5Rm4ob3B0aW9ucywgZmV0Y2hPcHRpb25zKSB7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRpZiAob3B0aW9ucy5xdWVyeUZuID09PSBza2lwVG9rZW4pIGNvbnNvbGUuZXJyb3IoYEF0dGVtcHRlZCB0byBpbnZva2UgcXVlcnlGbiB3aGVuIHNldCB0byBza2lwVG9rZW4uIFRoaXMgaXMgbGlrZWx5IGEgY29uZmlndXJhdGlvbiBlcnJvci4gUXVlcnkgaGFzaDogJyR7b3B0aW9ucy5xdWVyeUhhc2h9J2ApO1xuXHR9XG5cdGlmICghb3B0aW9ucy5xdWVyeUZuICYmIGZldGNoT3B0aW9ucz8uaW5pdGlhbFByb21pc2UpIHJldHVybiAoKSA9PiBmZXRjaE9wdGlvbnMuaW5pdGlhbFByb21pc2U7XG5cdGlmICghb3B0aW9ucy5xdWVyeUZuIHx8IG9wdGlvbnMucXVlcnlGbiA9PT0gc2tpcFRva2VuKSByZXR1cm4gKCkgPT4gUHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihgTWlzc2luZyBxdWVyeUZuOiAnJHtvcHRpb25zLnF1ZXJ5SGFzaH0nYCkpO1xuXHRyZXR1cm4gb3B0aW9ucy5xdWVyeUZuO1xufVxuLyoqXG4qIFJlc29sdmVzIGEgYHRocm93T25FcnJvcmAgb3B0aW9uIHRvIGEgYm9vbGVhbi5cbiogSWYgYHRocm93T25FcnJvcmAgaXMgYSBmdW5jdGlvbiwgaXQgaXMgY2FsbGVkIHdpdGggYHBhcmFtc2AgKGUuZy4gdGhlIGVycm9yIGFuZCwgZGVwZW5kaW5nIG9uIHRoZSBjYWxsZXIsXG4qIGFkZGl0aW9uYWwgY29udGV4dCBzdWNoIGFzIHRoZSBxdWVyeSBvciBtdXRhdGlvbikgYW5kIGl0cyByZXN1bHQgaXMgcmV0dXJuZWQsIGFsbG93aW5nIHRoZSB0aHJvd2luZ1xuKiBiZWhhdmlvciB0byBiZSBkZWNpZGVkIHBlciBlcnJvci4gT3RoZXJ3aXNlLCBgdGhyb3dPbkVycm9yYCBpdHNlbGYgaXMgY29lcmNlZCB0byBhIGJvb2xlYW4gKGB1bmRlZmluZWRgXG4qIHJlc29sdmVzIHRvIGBmYWxzZWApLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCB0aHJvd09uRXJyb3IgPVxuKiAgIHF1ZXJ5LnN0YXRlLmVycm9yICYmIHR5cGVvZiBvcHRpb25zLnRocm93T25FcnJvciA9PT0gJ2Z1bmN0aW9uJ1xuKiAgICAgPyBzaG91bGRUaHJvd0Vycm9yKG9wdGlvbnMudGhyb3dPbkVycm9yLCBbcXVlcnkuc3RhdGUuZXJyb3IsIHF1ZXJ5XSlcbiogICAgIDogb3B0aW9ucy50aHJvd09uRXJyb3JcbiogYGBgXG4qL1xuZnVuY3Rpb24gc2hvdWxkVGhyb3dFcnJvcih0aHJvd09uRXJyb3IsIHBhcmFtcykge1xuXHRpZiAodHlwZW9mIHRocm93T25FcnJvciA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gdGhyb3dPbkVycm9yKC4uLnBhcmFtcyk7XG5cdHJldHVybiAhIXRocm93T25FcnJvcjtcbn1cbmZ1bmN0aW9uIGFkZENvbnN1bWVBd2FyZVNpZ25hbChvYmplY3QsIGdldFNpZ25hbCwgb25DYW5jZWxsZWQpIHtcblx0bGV0IGNvbnN1bWVkID0gZmFsc2U7XG5cdGxldCBzaWduYWw7XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmplY3QsIFwic2lnbmFsXCIsIHtcblx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuXHRcdGdldDogKCkgPT4ge1xuXHRcdFx0c2lnbmFsID8/PSBnZXRTaWduYWwoKTtcblx0XHRcdGlmIChjb25zdW1lZCkgcmV0dXJuIHNpZ25hbDtcblx0XHRcdGNvbnN1bWVkID0gdHJ1ZTtcblx0XHRcdGlmIChzaWduYWwuYWJvcnRlZCkgb25DYW5jZWxsZWQoKTtcblx0XHRcdGVsc2Ugc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBvbkNhbmNlbGxlZCwgeyBvbmNlOiB0cnVlIH0pO1xuXHRcdFx0cmV0dXJuIHNpZ25hbDtcblx0XHR9XG5cdH0pO1xuXHRyZXR1cm4gb2JqZWN0O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBhZGRDb25zdW1lQXdhcmVTaWduYWwsIGFkZFRvRW5kLCBhZGRUb1N0YXJ0LCBlbnN1cmVRdWVyeUZuLCBmdW5jdGlvbmFsVXBkYXRlLCBoYXNoS2V5LCBoYXNoUXVlcnlLZXlCeU9wdGlvbnMsIGlzUGxhaW5BcnJheSwgaXNQbGFpbk9iamVjdCwgaXNTZXJ2ZXIsIGlzVmFsaWRUaW1lb3V0LCBrZWVwUHJldmlvdXNEYXRhLCBtYXRjaE11dGF0aW9uLCBtYXRjaFF1ZXJ5LCBub29wLCBwYXJ0aWFsTWF0Y2hLZXksIHJlcGxhY2VEYXRhLCByZXBsYWNlRXF1YWxEZWVwLCByZXNvbHZlUXVlcnlWYWx1ZSwgc2hhbGxvd0VxdWFsT2JqZWN0cywgc2hvdWxkVGhyb3dFcnJvciwgc2tpcFRva2VuLCBzbGVlcCwgdGltZVVudGlsU3RhbGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXRpbHMuanMubWFwIiwiaW1wb3J0IHsgaXNTZXJ2ZXIgYXMgaXNTZXJ2ZXIkMSB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG4vLyNyZWdpb24gc3JjL2Vudmlyb25tZW50TWFuYWdlci50c1xubGV0IGlzU2VydmVyRm4gPSAoKSA9PiBpc1NlcnZlciQxO1xuLyoqXG4qIFJldHVybnMgd2hldGhlciB0aGUgY3VycmVudCBydW50aW1lIHNob3VsZCBiZSB0cmVhdGVkIGFzIGEgc2VydmVyIGVudmlyb25tZW50LlxuKi9cbmNvbnN0IGlzU2VydmVyID0gKCkgPT4gaXNTZXJ2ZXJGbigpO1xuLyoqXG4qIE1hbmFnZXMgaG93IFRhblN0YWNrIFF1ZXJ5IGRldGVjdHMgd2hldGhlciB0aGUgY3VycmVudCBydW50aW1lIHNob3VsZCBiZSB0cmVhdGVkIGFzXG4qIHNlcnZlci1zaWRlLCB3aGljaCBkaXNhYmxlcyBzY2hlZHVsaW5nIHJlZmV0Y2ggdGltZXJzIGFuZCBjaGFuZ2VzIHRoZSBkZWZhdWx0IGByZXRyeWAgY291bnRcbiogYW5kIGBnY1RpbWVgLiBCeSBkZWZhdWx0LCB0aGUgZGV0ZWN0aW9uIHRyZWF0cyBhIG1pc3NpbmcgYHdpbmRvd2AgKG9yIHRoZSBwcmVzZW5jZSBvZiBhXG4qIGBEZW5vYCBnbG9iYWwpIGFzIHNlcnZlci5cbipcbiogT3ZlcnJpZGUgdGhpcyBmb3IgcnVudGltZXMgd2hlcmUgdGhhdCBkZWZhdWx0IGRldGVjdGlvbiB3b3VsZCBnaXZlIHRoZSB3cm9uZyBhbnN3ZXIg4oCUIGZvclxuKiBleGFtcGxlLCBhIFNlcnZpY2UgV29ya2VyLCB3aGVyZSBgd2luZG93YCBpcyB1bmRlZmluZWQgZXZlbiB0aG91Z2ggdGhlIGVudmlyb25tZW50IHNob3VsZFxuKiBiZWhhdmUgbGlrZSBhIGNsaWVudC5cbipcbiogQGV4YW1wbGVcbiogYGBgdHNcbiogaW1wb3J0IHsgZW52aXJvbm1lbnRNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG4qXG4qIGVudmlyb25tZW50TWFuYWdlci5zZXRJc1NlcnZlcigoKSA9PiBmYWxzZSlcbiogYGBgXG4qL1xuY29uc3QgZW52aXJvbm1lbnRNYW5hZ2VyID0ge1xuXHRpc1NlcnZlcixcblx0LyoqXG5cdCogT3ZlcnJpZGVzIHRoZSBzZXJ2ZXIgY2hlY2sgZ2xvYmFsbHkuXG5cdCovXG5cdHNldElzU2VydmVyKGlzU2VydmVyVmFsdWUpIHtcblx0XHRpc1NlcnZlckZuID0gaXNTZXJ2ZXJWYWx1ZTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZW52aXJvbm1lbnRNYW5hZ2VyLCBpc1NlcnZlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1lbnZpcm9ubWVudE1hbmFnZXIuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9zdWJzY3JpYmFibGUudHNcbnZhciBTdWJzY3JpYmFibGUgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdHRoaXMubGlzdGVuZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHR0aGlzLnN1YnNjcmliZSA9IHRoaXMuc3Vic2NyaWJlLmJpbmQodGhpcyk7XG5cdH1cblx0c3Vic2NyaWJlKGxpc3RlbmVyKSB7XG5cdFx0dGhpcy5saXN0ZW5lcnMuYWRkKGxpc3RlbmVyKTtcblx0XHR0aGlzLm9uU3Vic2NyaWJlKCk7XG5cdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdHRoaXMubGlzdGVuZXJzLmRlbGV0ZShsaXN0ZW5lcik7XG5cdFx0XHR0aGlzLm9uVW5zdWJzY3JpYmUoKTtcblx0XHR9O1xuXHR9XG5cdGhhc0xpc3RlbmVycygpIHtcblx0XHRyZXR1cm4gdGhpcy5saXN0ZW5lcnMuc2l6ZSA+IDA7XG5cdH1cblx0b25TdWJzY3JpYmUoKSB7fVxuXHRvblVuc3Vic2NyaWJlKCkge31cbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFN1YnNjcmliYWJsZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1zdWJzY3JpYmFibGUuanMubWFwIiwiaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG4vLyNyZWdpb24gc3JjL2ZvY3VzTWFuYWdlci50c1xuLyoqXG4qIFRoZSBgRm9jdXNNYW5hZ2VyYCBtYW5hZ2VzIHRoZSBmb2N1cyBzdGF0ZSB3aXRoaW4gVGFuU3RhY2sgUXVlcnkuXG4qXG4qIEl0IGNhbiBiZSB1c2VkIHRvIGNoYW5nZSB0aGUgZGVmYXVsdCBldmVudCBsaXN0ZW5lcnMgb3IgdG8gbWFudWFsbHkgY2hhbmdlIHRoZSBmb2N1cyBzdGF0ZS5cbiovXG52YXIgRm9jdXNNYW5hZ2VyID0gY2xhc3MgZXh0ZW5kcyBTdWJzY3JpYmFibGUge1xuXHQjZm9jdXNlZDtcblx0I2NsZWFudXA7XG5cdCNzZXR1cDtcblx0Y29uc3RydWN0b3IoKSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLiNzZXR1cCA9IChvbkZvY3VzKSA9PiB7XG5cdFx0XHRpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiAmJiB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcikge1xuXHRcdFx0XHRjb25zdCBsaXN0ZW5lciA9ICgpID0+IG9uRm9jdXMoKTtcblx0XHRcdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJ2aXNpYmlsaXR5Y2hhbmdlXCIsIGxpc3RlbmVyLCBmYWxzZSk7XG5cdFx0XHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRcdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJ2aXNpYmlsaXR5Y2hhbmdlXCIsIGxpc3RlbmVyKTtcblx0XHRcdFx0fTtcblx0XHRcdH1cblx0XHR9O1xuXHR9XG5cdG9uU3Vic2NyaWJlKCkge1xuXHRcdGlmICghdGhpcy4jY2xlYW51cCkgdGhpcy5zZXRFdmVudExpc3RlbmVyKHRoaXMuI3NldHVwKTtcblx0fVxuXHRvblVuc3Vic2NyaWJlKCkge1xuXHRcdGlmICghdGhpcy5oYXNMaXN0ZW5lcnMoKSkge1xuXHRcdFx0dGhpcy4jY2xlYW51cD8uKCk7XG5cdFx0XHR0aGlzLiNjbGVhbnVwID0gdm9pZCAwO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBgc2V0RXZlbnRMaXN0ZW5lcmAgY2FuIGJlIHVzZWQgdG8gc2V0IGEgY3VzdG9tIGV2ZW50IGxpc3RlbmVyIHRoYXQgd2lsbFxuXHQqIGJlIHVzZWQgdG8gZGV0ZXJtaW5lIHRoZSBmb2N1cyBzdGF0ZS4gVGhlIHByb3ZpZGVkIGBzZXR1cGAgZnVuY3Rpb25cblx0KiByZWNlaXZlcyBhIGBzZXRGb2N1c2VkYCBjYWxsYmFjazogY2FsbCBpdCB3aXRoIGEgYGJvb2xlYW5gIHRvIG1hbnVhbGx5XG5cdCogc2V0IHRoZSBmb2N1cyBzdGF0ZSwgb3Igd2l0aCBubyBhcmd1bWVudHMgdG8gcmUtZXZhbHVhdGUgdGhlIGN1cnJlbnRcblx0KiBmb2N1cyBzdGF0ZSBhbmQgbm90aWZ5IHN1YnNjcmliZXJzLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IGZvY3VzTWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogZm9jdXNNYW5hZ2VyLnNldEV2ZW50TGlzdGVuZXIoKGhhbmRsZUZvY3VzKSA9PiB7XG5cdCogICBjb25zdCBsaXN0ZW5lciA9ICgpID0+IGhhbmRsZUZvY3VzKClcblx0KiAgIC8vIExpc3RlbiB0byB2aXNpYmlsaXR5Y2hhbmdlXG5cdCogICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIpIHtcblx0KiAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnLCBsaXN0ZW5lciwgZmFsc2UpXG5cdCogICB9XG5cdCpcblx0KiAgIHJldHVybiAoKSA9PiB7XG5cdCogICAgIC8vIEJlIHN1cmUgdG8gdW5zdWJzY3JpYmUgaWYgYSBuZXcgaGFuZGxlciBpcyBzZXRcblx0KiAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnLCBsaXN0ZW5lcilcblx0KiAgIH1cblx0KiB9KVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRFdmVudExpc3RlbmVyKHNldHVwKSB7XG5cdFx0dGhpcy4jc2V0dXAgPSBzZXR1cDtcblx0XHR0aGlzLiNjbGVhbnVwPy4oKTtcblx0XHR0aGlzLiNjbGVhbnVwID0gc2V0dXAoKGZvY3VzZWQpID0+IHtcblx0XHRcdGlmICh0eXBlb2YgZm9jdXNlZCA9PT0gXCJib29sZWFuXCIpIHRoaXMuc2V0Rm9jdXNlZChmb2N1c2VkKTtcblx0XHRcdGVsc2UgdGhpcy5vbkZvY3VzKCk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogYHNldEZvY3VzZWRgIGNhbiBiZSB1c2VkIHRvIG1hbnVhbGx5IHNldCB0aGUgZm9jdXMgc3RhdGUuIFNldCBgdW5kZWZpbmVkYFxuXHQqIHRvIGZhbGwgYmFjayB0byB0aGUgZGVmYXVsdCBmb2N1cyBjaGVjay5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBmb2N1c01hbmFnZXIgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIC8vIFNldCBmb2N1c2VkXG5cdCogZm9jdXNNYW5hZ2VyLnNldEZvY3VzZWQodHJ1ZSlcblx0KlxuXHQqIC8vIFNldCB1bmZvY3VzZWRcblx0KiBmb2N1c01hbmFnZXIuc2V0Rm9jdXNlZChmYWxzZSlcblx0KlxuXHQqIC8vIEZhbGxiYWNrIHRvIHRoZSBkZWZhdWx0IGZvY3VzIGNoZWNrXG5cdCogZm9jdXNNYW5hZ2VyLnNldEZvY3VzZWQodW5kZWZpbmVkKVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRGb2N1c2VkKGZvY3VzZWQpIHtcblx0XHRpZiAodGhpcy4jZm9jdXNlZCAhPT0gZm9jdXNlZCkge1xuXHRcdFx0dGhpcy4jZm9jdXNlZCA9IGZvY3VzZWQ7XG5cdFx0XHR0aGlzLm9uRm9jdXMoKTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogYG9uRm9jdXNgIG5vdGlmaWVzIGFsbCBzdWJzY3JpYmVkIGxpc3RlbmVycyB3aXRoIHRoZSBjdXJyZW50IGZvY3VzIHN0YXRlLlxuXHQqL1xuXHRvbkZvY3VzKCkge1xuXHRcdGNvbnN0IGlzRm9jdXNlZCA9IHRoaXMuaXNGb2N1c2VkKCk7XG5cdFx0dGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcblx0XHRcdGxpc3RlbmVyKGlzRm9jdXNlZCk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogYGlzRm9jdXNlZGAgY2FuIGJlIHVzZWQgdG8gZ2V0IHRoZSBjdXJyZW50IGZvY3VzIHN0YXRlLlxuXHQqL1xuXHRpc0ZvY3VzZWQoKSB7XG5cdFx0aWYgKHR5cGVvZiB0aGlzLiNmb2N1c2VkID09PSBcImJvb2xlYW5cIikgcmV0dXJuIHRoaXMuI2ZvY3VzZWQ7XG5cdFx0cmV0dXJuIGdsb2JhbFRoaXMuZG9jdW1lbnQ/LnZpc2liaWxpdHlTdGF0ZSAhPT0gXCJoaWRkZW5cIjtcblx0fVxufTtcbi8qKlxuKiBTaW5nbGV0b24gaW5zdGFuY2Ugb2Yge0BsaW5rIEZvY3VzTWFuYWdlcn0sIHVzZWQgdG8gbWFuYWdlIGFuZCBvYnNlcnZlIHRoZSBmb2N1cyBzdGF0ZSB3aXRoaW4gVGFuU3RhY2sgUXVlcnkuXG4qL1xuY29uc3QgZm9jdXNNYW5hZ2VyID0gbmV3IEZvY3VzTWFuYWdlcigpO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBGb2N1c01hbmFnZXIsIGZvY3VzTWFuYWdlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1mb2N1c01hbmFnZXIuanMubWFwIiwiaW1wb3J0IHsgbm9vcCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG4vLyNyZWdpb24gc3JjL2h5ZHJhdGlvbi50c1xuZnVuY3Rpb24gdHJ5UmVzb2x2ZVN5bmMocHJvbWlzZSkge1xuXHRsZXQgZGF0YTtcblx0cHJvbWlzZS50aGVuKChyZXN1bHQpID0+IHtcblx0XHRkYXRhID0gcmVzdWx0O1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH0sIG5vb3ApPy5jYXRjaD8uKG5vb3ApO1xuXHRpZiAoZGF0YSAhPT0gdm9pZCAwKSByZXR1cm4geyBkYXRhIH07XG59XG5mdW5jdGlvbiBkZWh5ZHJhdGVNdXRhdGlvbihtdXRhdGlvbikge1xuXHRyZXR1cm4ge1xuXHRcdG11dGF0aW9uS2V5OiBtdXRhdGlvbi5vcHRpb25zLm11dGF0aW9uS2V5LFxuXHRcdHN0YXRlOiBtdXRhdGlvbi5zdGF0ZSxcblx0XHQuLi5tdXRhdGlvbi5vcHRpb25zLnNjb3BlICYmIHsgc2NvcGU6IG11dGF0aW9uLm9wdGlvbnMuc2NvcGUgfSxcblx0XHQuLi5tdXRhdGlvbi5tZXRhICYmIHsgbWV0YTogbXV0YXRpb24ubWV0YSB9XG5cdH07XG59XG5mdW5jdGlvbiBkZWh5ZHJhdGVQcm9taXNlKHF1ZXJ5LCBzZXJpYWxpemVEYXRhLCBzaG91bGRSZWRhY3RFcnJvcnMpIHtcblx0Y29uc3QgcHJvbWlzZSA9IHF1ZXJ5LnByb21pc2U/LnRoZW4oc2VyaWFsaXplRGF0YSkuY2F0Y2goKGVycm9yKSA9PiB7XG5cdFx0aWYgKHNob3VsZFJlZGFjdEVycm9ycz8uKGVycm9yKSA9PT0gZmFsc2UpIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgY29uc29sZS5lcnJvcihgQSBxdWVyeSB0aGF0IHdhcyBkZWh5ZHJhdGVkIGFzIHBlbmRpbmcgZW5kZWQgdXAgcmVqZWN0aW5nLiBbJHtxdWVyeS5xdWVyeUhhc2h9XTogJHtlcnJvcn07IFRoZSBlcnJvciB3aWxsIGJlIHJlZGFjdGVkIGluIHByb2R1Y3Rpb24gYnVpbGRzYCk7XG5cdFx0cmV0dXJuIFByb21pc2UucmVqZWN0KC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoXCJyZWRhY3RlZFwiKSk7XG5cdH0pO1xuXHRwcm9taXNlPy5jYXRjaChub29wKTtcblx0cmV0dXJuIHByb21pc2U7XG59XG4vKipcbiogRGVoeWRyYXRlcyBhIHNpbmdsZSBgUXVlcnlgIGludG8gYSBzZXJpYWxpemFibGUgYERlaHlkcmF0ZWRRdWVyeWAgc25hcHNob3QuIE5vdGUgdGhhdCBtb3N0IHF1ZXJ5IGNvbmZpZyAoZS5nLlxuKiBgcXVlcnlGbmAsIGBzdGFsZVRpbWVgKSBpcyBub3QgZGVoeWRyYXRlZCBidXQgaW5zdGVhZCBtZWFudCB0byBiZSBjb25maWd1cmVkIGFnYWluIHdoZW4gY29uc3VtaW5nIHRoZVxuKiBkZS9yZWh5ZHJhdGVkIGRhdGEsIHR5cGljYWxseSB3aXRoIGB1c2VRdWVyeWAgb24gdGhlIGNsaWVudC4gSWYgdGhlIHF1ZXJ5IGlzIHN0aWxsIGBwZW5kaW5nYCwgaXRzIGluLWZsaWdodFxuKiBwcm9taXNlIGlzIGRlaHlkcmF0ZWQgdG9vIHNvIGl0IGNhbiBiZSByZXN1bWVkIG9uIHRoZSBvdGhlciBzaWRlIGluc3RlYWQgb2YgcmUtZmV0Y2hlZC5cbiogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHRvIGRlaHlkcmF0ZS5cbiogQHBhcmFtIHNlcmlhbGl6ZURhdGEgLSBPcHRpb25hbCB0cmFuc2Zvcm0gYXBwbGllZCB0byBgcXVlcnkuc3RhdGUuZGF0YWAgYmVmb3JlIGl0IGlzIGluY2x1ZGVkIGluIHRoZSBzbmFwc2hvdC5cbiogQHBhcmFtIHNob3VsZFJlZGFjdEVycm9ycyAtIE9wdGlvbmFsIHByZWRpY2F0ZTsgaWYgaXQgcmV0dXJucyBgZmFsc2VgIGZvciB0aGUgcHJvbWlzZSdzIHJlamVjdGlvbiBlcnJvciwgdGhhdFxuKiBlcnJvciBpcyBrZXB0IGFzLWlzIGluc3RlYWQgb2YgYmVpbmcgcmVkYWN0ZWQuXG4qL1xuZnVuY3Rpb24gZGVoeWRyYXRlUXVlcnkocXVlcnksIHNlcmlhbGl6ZURhdGEsIHNob3VsZFJlZGFjdEVycm9ycykge1xuXHRyZXR1cm4ge1xuXHRcdGRlaHlkcmF0ZWRBdDogRGF0ZS5ub3coKSxcblx0XHRzdGF0ZToge1xuXHRcdFx0Li4ucXVlcnkuc3RhdGUsXG5cdFx0XHQuLi5xdWVyeS5zdGF0ZS5kYXRhICE9PSB2b2lkIDAgJiYgeyBkYXRhOiBzZXJpYWxpemVEYXRhID8gc2VyaWFsaXplRGF0YShxdWVyeS5zdGF0ZS5kYXRhKSA6IHF1ZXJ5LnN0YXRlLmRhdGEgfVxuXHRcdH0sXG5cdFx0cXVlcnlLZXk6IHF1ZXJ5LnF1ZXJ5S2V5LFxuXHRcdHF1ZXJ5SGFzaDogcXVlcnkucXVlcnlIYXNoLFxuXHRcdC4uLnF1ZXJ5LnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIgJiYgeyBwcm9taXNlOiBkZWh5ZHJhdGVQcm9taXNlKHF1ZXJ5LCBzZXJpYWxpemVEYXRhLCBzaG91bGRSZWRhY3RFcnJvcnMpIH0sXG5cdFx0Li4ucXVlcnkubWV0YSAmJiB7IG1ldGE6IHF1ZXJ5Lm1ldGEgfSxcblx0XHQuLi5xdWVyeS5xdWVyeVR5cGUgJiYgeyBxdWVyeVR5cGU6IHF1ZXJ5LnF1ZXJ5VHlwZSB9XG5cdH07XG59XG4vKipcbiogVGhlIGRlZmF1bHQgYHNob3VsZERlaHlkcmF0ZU11dGF0aW9uYCBwcmVkaWNhdGUgdXNlZCBieSBgZGVoeWRyYXRlYC4gT25seSBkZWh5ZHJhdGVzIG11dGF0aW9ucyB0aGF0IGFyZVxuKiBjdXJyZW50bHkgcGF1c2VkIChlLmcuIHBhdXNlZCBieSBgbmV0d29ya01vZGVgIHdoaWxlIG9mZmxpbmUpLlxuKi9cbmZ1bmN0aW9uIGRlZmF1bHRTaG91bGREZWh5ZHJhdGVNdXRhdGlvbihtdXRhdGlvbikge1xuXHRyZXR1cm4gbXV0YXRpb24uc3RhdGUuaXNQYXVzZWQ7XG59XG4vKipcbiogVGhlIGRlZmF1bHQgYHNob3VsZERlaHlkcmF0ZVF1ZXJ5YCBwcmVkaWNhdGUgdXNlZCBieSBgZGVoeWRyYXRlYC4gT25seSBkZWh5ZHJhdGVzIHF1ZXJpZXMgd2hvc2Ugc3RhdHVzIGlzXG4qIGAnc3VjY2VzcydgLlxuKi9cbmZ1bmN0aW9uIGRlZmF1bHRTaG91bGREZWh5ZHJhdGVRdWVyeShxdWVyeSkge1xuXHRyZXR1cm4gcXVlcnkuc3RhdGUuc3RhdHVzID09PSBcInN1Y2Nlc3NcIjtcbn1cbi8qKlxuKiBEZWh5ZHJhdGVzIGEgYFF1ZXJ5Q2xpZW50YCdzIGNhY2hlIChxdWVyaWVzIGFuZCBtdXRhdGlvbnMpIGludG8gYSBwbGFpbiwgc2VyaWFsaXphYmxlIGBEZWh5ZHJhdGVkU3RhdGVgLFxuKiB0eXBpY2FsbHkgdG8gZW1iZWQgaW4gc2VydmVyLXJlbmRlcmVkIG1hcmt1cCBhbmQgbGF0ZXIgcmVzdG9yZSBpbnRvIGEgY2xpZW50LXNpZGUgYFF1ZXJ5Q2xpZW50YCB2aWEgYGh5ZHJhdGVgLlxuKiBXaGljaCBxdWVyaWVzL211dGF0aW9ucyBhcmUgaW5jbHVkZWQsIGFuZCBob3cgdGhlaXIgZGF0YS9lcnJvcnMgYXJlIHRyYW5zZm9ybWVkLCBpcyBjb250cm9sbGVkIGJ5IGBvcHRpb25zYCxcbiogZmFsbGluZyBiYWNrIHRvIHRoZSBjbGllbnQncyBgZGVoeWRyYXRlYCBkZWZhdWx0IG9wdGlvbnMsIGFuZCBmaW5hbGx5IHRvIGBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlUXVlcnlgIC9cbiogYGRlZmF1bHRTaG91bGREZWh5ZHJhdGVNdXRhdGlvbmAuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KClcbipcbiogYXdhaXQgcXVlcnlDbGllbnQucHJlZmV0Y2hRdWVyeSh7XG4qICAgcXVlcnlLZXk6IFsncG9zdHMnXSxcbiogICBxdWVyeUZuOiBnZXRQb3N0cyxcbiogfSlcbipcbiogY29uc3QgZGVoeWRyYXRlZFN0YXRlID0gZGVoeWRyYXRlKHF1ZXJ5Q2xpZW50KVxuKiBgYGBcbiovXG5mdW5jdGlvbiBkZWh5ZHJhdGUoY2xpZW50LCBvcHRpb25zID0ge30pIHtcblx0Y29uc3QgZmlsdGVyTXV0YXRpb24gPSBvcHRpb25zLnNob3VsZERlaHlkcmF0ZU11dGF0aW9uID8/IGNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmRlaHlkcmF0ZT8uc2hvdWxkRGVoeWRyYXRlTXV0YXRpb24gPz8gZGVmYXVsdFNob3VsZERlaHlkcmF0ZU11dGF0aW9uO1xuXHRjb25zdCBtdXRhdGlvbnMgPSBjbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpLmdldEFsbCgpLmZsYXRNYXAoKG11dGF0aW9uKSA9PiBmaWx0ZXJNdXRhdGlvbihtdXRhdGlvbikgPyBbZGVoeWRyYXRlTXV0YXRpb24obXV0YXRpb24pXSA6IFtdKTtcblx0Y29uc3QgZmlsdGVyUXVlcnkgPSBvcHRpb25zLnNob3VsZERlaHlkcmF0ZVF1ZXJ5ID8/IGNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmRlaHlkcmF0ZT8uc2hvdWxkRGVoeWRyYXRlUXVlcnkgPz8gZGVmYXVsdFNob3VsZERlaHlkcmF0ZVF1ZXJ5O1xuXHRjb25zdCBzaG91bGRSZWRhY3RFcnJvcnMgPSBvcHRpb25zLnNob3VsZFJlZGFjdEVycm9ycyA/PyBjbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5kZWh5ZHJhdGU/LnNob3VsZFJlZGFjdEVycm9ycztcblx0Y29uc3Qgc2VyaWFsaXplRGF0YSA9IG9wdGlvbnMuc2VyaWFsaXplRGF0YSA/PyBjbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5kZWh5ZHJhdGU/LnNlcmlhbGl6ZURhdGE7XG5cdHJldHVybiB7XG5cdFx0bXV0YXRpb25zLFxuXHRcdHF1ZXJpZXM6IGNsaWVudC5nZXRRdWVyeUNhY2hlKCkuZ2V0QWxsKCkuZmxhdE1hcCgocXVlcnkpID0+IGZpbHRlclF1ZXJ5KHF1ZXJ5KSA/IFtkZWh5ZHJhdGVRdWVyeShxdWVyeSwgc2VyaWFsaXplRGF0YSwgc2hvdWxkUmVkYWN0RXJyb3JzKV0gOiBbXSlcblx0fTtcbn1cbi8qKlxuKiBSZXN0b3JlcyBhIGBEZWh5ZHJhdGVkU3RhdGVgIChhcyBwcm9kdWNlZCBieSBgZGVoeWRyYXRlYCkgaW50byBhIGBRdWVyeUNsaWVudGAncyBjYWNoZSwgdHlwaWNhbGx5IHRvIHNlZWQgdGhlXG4qIGNsaWVudCB3aXRoIGRhdGEgYWxyZWFkeSBmZXRjaGVkIG9uIHRoZSBzZXJ2ZXIuIGBtdXRhdGlvbnNgIGFuZCBgcXVlcmllc2AgYXJlIGVhY2ggb3B0aW9uYWwgb24gYGRlaHlkcmF0ZWRTdGF0ZWAuXG4qIFF1ZXJpZXMgbm90IHlldCBpbiB0aGUgY2FjaGUgYXJlIGJ1aWx0IGZyb20gdGhlIGRlaHlkcmF0ZWQgc25hcHNob3Q7IHF1ZXJpZXMgdGhhdCBhbHJlYWR5IGV4aXN0IGFyZSBvbmx5IHVwZGF0ZWRcbiogd2hlbiB0aGUgZGVoeWRyYXRlZCBkYXRhIGlzIG5ld2VyIHRoYW4gd2hhdCdzIGFscmVhZHkgY2FjaGVkLiBOZXdseSBidWlsdCBxdWVyaWVzIGhhdmUgdGhlaXIgYGZldGNoU3RhdHVzYCByZXNldFxuKiB0byBgJ2lkbGUnYCBzbyB0aGV5IGRvbid0IGh5ZHJhdGUgc3R1Y2sgaW4gYSBmZXRjaGluZyBzdGF0ZS4gSWYgYSBkZWh5ZHJhdGVkIHF1ZXJ5IHN0aWxsIGhhZCBhbiBpbi1mbGlnaHRcbiogcHJvbWlzZSwgaXQgaXMgcmVzdW1lZCB2aWEgYHF1ZXJ5LmZldGNoKClgIChyZXVzaW5nIHRoYXQgcHJvbWlzZSBhcyBgaW5pdGlhbFByb21pc2VgKSByYXRoZXIgdGhhbiByZS1pbnZva2luZ1xuKiBgcXVlcnlGbmAuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIC8vIGRlaHlkcmF0ZWRTdGF0ZSB3YXMgcHJvZHVjZWQgYnkgYGRlaHlkcmF0ZWAgb24gdGhlIHNlcnZlclxuKiAvLyBhbmQgc2VudCB0byB0aGUgY2xpZW50LCBlLmcuIGVtYmVkZGVkIGluIHNlcnZlci1yZW5kZXJlZCBtYXJrdXAuXG4qIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KClcbipcbiogaHlkcmF0ZShxdWVyeUNsaWVudCwgZGVoeWRyYXRlZFN0YXRlKVxuKiBgYGBcbiovXG5mdW5jdGlvbiBoeWRyYXRlKGNsaWVudCwgZGVoeWRyYXRlZFN0YXRlLCBvcHRpb25zKSB7XG5cdGNvbnN0IG11dGF0aW9uQ2FjaGUgPSBjbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpO1xuXHRjb25zdCBxdWVyeUNhY2hlID0gY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKTtcblx0Y29uc3QgZGVzZXJpYWxpemVEYXRhID0gb3B0aW9ucz8uZGVmYXVsdE9wdGlvbnM/LmRlc2VyaWFsaXplRGF0YSA/PyBjbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5oeWRyYXRlPy5kZXNlcmlhbGl6ZURhdGE7XG5cdGRlaHlkcmF0ZWRTdGF0ZS5tdXRhdGlvbnM/LmZvckVhY2goKHsgc3RhdGUsIC4uLm11dGF0aW9uT3B0aW9ucyB9KSA9PiB7XG5cdFx0bXV0YXRpb25DYWNoZS5idWlsZChjbGllbnQsIHtcblx0XHRcdC4uLmNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmh5ZHJhdGU/Lm11dGF0aW9ucyxcblx0XHRcdC4uLm9wdGlvbnM/LmRlZmF1bHRPcHRpb25zPy5tdXRhdGlvbnMsXG5cdFx0XHQuLi5tdXRhdGlvbk9wdGlvbnNcblx0XHR9LCBzdGF0ZSk7XG5cdH0pO1xuXHRkZWh5ZHJhdGVkU3RhdGUucXVlcmllcz8uZm9yRWFjaCgoeyBxdWVyeUtleSwgc3RhdGUsIHF1ZXJ5SGFzaCwgbWV0YSwgcHJvbWlzZSwgZGVoeWRyYXRlZEF0LCBxdWVyeVR5cGUgfSkgPT4ge1xuXHRcdGNvbnN0IHN5bmNEYXRhID0gcHJvbWlzZSA/IHRyeVJlc29sdmVTeW5jKHByb21pc2UpIDogdm9pZCAwO1xuXHRcdGNvbnN0IHJhd0RhdGEgPSBzdGF0ZS5kYXRhID09PSB2b2lkIDAgPyBzeW5jRGF0YT8uZGF0YSA6IHN0YXRlLmRhdGE7XG5cdFx0Y29uc3QgZGF0YSA9IHJhd0RhdGEgPT09IHZvaWQgMCA/IHJhd0RhdGEgOiBkZXNlcmlhbGl6ZURhdGEgPyBkZXNlcmlhbGl6ZURhdGEocmF3RGF0YSkgOiByYXdEYXRhO1xuXHRcdGxldCBxdWVyeSA9IHF1ZXJ5Q2FjaGUuZ2V0KHF1ZXJ5SGFzaCk7XG5cdFx0Y29uc3QgZXhpc3RpbmdRdWVyeUlzUGVuZGluZyA9IHF1ZXJ5Py5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiO1xuXHRcdGNvbnN0IGV4aXN0aW5nUXVlcnlJc0ZldGNoaW5nID0gcXVlcnk/LnN0YXRlLmZldGNoU3RhdHVzID09PSBcImZldGNoaW5nXCI7XG5cdFx0aWYgKHF1ZXJ5KSB7XG5cdFx0XHRjb25zdCBoYXNOZXdlclN5bmNEYXRhID0gc3luY0RhdGEgJiYgZGVoeWRyYXRlZEF0ID4gcXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdDtcblx0XHRcdGlmIChzdGF0ZS5kYXRhVXBkYXRlZEF0ID4gcXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdCB8fCBoYXNOZXdlclN5bmNEYXRhKSB7XG5cdFx0XHRcdGNvbnN0IHsgZmV0Y2hTdGF0dXM6IF9pZ25vcmVkLCAuLi5zZXJpYWxpemVkU3RhdGUgfSA9IHN0YXRlO1xuXHRcdFx0XHRxdWVyeS5zZXRTdGF0ZSh7XG5cdFx0XHRcdFx0Li4uc2VyaWFsaXplZFN0YXRlLFxuXHRcdFx0XHRcdGRhdGEsXG5cdFx0XHRcdFx0Li4uc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIiAmJiBkYXRhICE9PSB2b2lkIDAgJiYge1xuXHRcdFx0XHRcdFx0c3RhdHVzOiBcInN1Y2Nlc3NcIixcblx0XHRcdFx0XHRcdGRhdGFVcGRhdGVkQXQ6IGRlaHlkcmF0ZWRBdCxcblx0XHRcdFx0XHRcdC4uLiFleGlzdGluZ1F1ZXJ5SXNGZXRjaGluZyAmJiB7IGZldGNoU3RhdHVzOiBcImlkbGVcIiB9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9KTtcblx0XHRcdH1cblx0XHR9IGVsc2UgcXVlcnkgPSBxdWVyeUNhY2hlLmJ1aWxkKGNsaWVudCwge1xuXHRcdFx0Li4uY2xpZW50LmdldERlZmF1bHRPcHRpb25zKCkuaHlkcmF0ZT8ucXVlcmllcyxcblx0XHRcdC4uLm9wdGlvbnM/LmRlZmF1bHRPcHRpb25zPy5xdWVyaWVzLFxuXHRcdFx0cXVlcnlLZXksXG5cdFx0XHRxdWVyeUhhc2gsXG5cdFx0XHRtZXRhLFxuXHRcdFx0X3R5cGU6IHF1ZXJ5VHlwZVxuXHRcdH0sIHtcblx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0ZGF0YSxcblx0XHRcdGZldGNoU3RhdHVzOiBcImlkbGVcIixcblx0XHRcdHN0YXR1czogc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIiAmJiBkYXRhICE9PSB2b2lkIDAgPyBcInN1Y2Nlc3NcIiA6IHN0YXRlLnN0YXR1cyxcblx0XHRcdC4uLnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIgJiYgZGF0YSAhPT0gdm9pZCAwICYmIHsgZGF0YVVwZGF0ZWRBdDogZGVoeWRyYXRlZEF0IH1cblx0XHR9KTtcblx0XHRpZiAocHJvbWlzZSAmJiAhc3luY0RhdGEgJiYgIWV4aXN0aW5nUXVlcnlJc1BlbmRpbmcgJiYgIWV4aXN0aW5nUXVlcnlJc0ZldGNoaW5nICYmIGRlaHlkcmF0ZWRBdCA+IHF1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXQpIHF1ZXJ5LmZldGNoKHZvaWQgMCwgeyBpbml0aWFsUHJvbWlzZTogUHJvbWlzZS5yZXNvbHZlKHByb21pc2UpLnRoZW4oZGVzZXJpYWxpemVEYXRhKSB9KS5jYXRjaChub29wKTtcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGRlZmF1bHRTaG91bGREZWh5ZHJhdGVNdXRhdGlvbiwgZGVmYXVsdFNob3VsZERlaHlkcmF0ZVF1ZXJ5LCBkZWh5ZHJhdGUsIGRlaHlkcmF0ZVF1ZXJ5LCBoeWRyYXRlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWh5ZHJhdGlvbi5qcy5tYXAiLCJpbXBvcnQgeyBzeXN0ZW1TZXRUaW1lb3V0WmVybyB9IGZyb20gXCIuL3RpbWVvdXRNYW5hZ2VyLmpzXCI7XG4vLyNyZWdpb24gc3JjL25vdGlmeU1hbmFnZXIudHNcbi8qKlxuKiBEZWZhdWx0IHNjaGVkdWxpbmcgZnVuY3Rpb24gdXNlZCBieSB0aGUgbm90aWZ5IG1hbmFnZXIuXG4qIFNjaGVkdWxlcyB0aGUgY2FsbGJhY2sgd2l0aCB0aGUgc3lzdGVtJ3MgYHNldFRpbWVvdXQoY2FsbGJhY2ssIDApYC5cbiovXG5jb25zdCBkZWZhdWx0U2NoZWR1bGVyID0gc3lzdGVtU2V0VGltZW91dFplcm87XG5mdW5jdGlvbiBjcmVhdGVOb3RpZnlNYW5hZ2VyKCkge1xuXHRsZXQgcXVldWUgPSBbXTtcblx0bGV0IHRyYW5zYWN0aW9ucyA9IDA7XG5cdGxldCBub3RpZnlGbiA9IChjYWxsYmFjaykgPT4ge1xuXHRcdGNhbGxiYWNrKCk7XG5cdH07XG5cdGxldCBiYXRjaE5vdGlmeUZuID0gKGNhbGxiYWNrKSA9PiB7XG5cdFx0Y2FsbGJhY2soKTtcblx0fTtcblx0bGV0IHNjaGVkdWxlRm4gPSBkZWZhdWx0U2NoZWR1bGVyO1xuXHRjb25zdCBzY2hlZHVsZSA9IChjYWxsYmFjaykgPT4ge1xuXHRcdGlmICh0cmFuc2FjdGlvbnMpIHF1ZXVlLnB1c2goY2FsbGJhY2spO1xuXHRcdGVsc2Ugc2NoZWR1bGVGbigoKSA9PiB7XG5cdFx0XHRub3RpZnlGbihjYWxsYmFjayk7XG5cdFx0fSk7XG5cdH07XG5cdGNvbnN0IGZsdXNoID0gKCkgPT4ge1xuXHRcdGNvbnN0IG9yaWdpbmFsUXVldWUgPSBxdWV1ZTtcblx0XHRxdWV1ZSA9IFtdO1xuXHRcdGlmIChvcmlnaW5hbFF1ZXVlLmxlbmd0aCkgc2NoZWR1bGVGbigoKSA9PiB7XG5cdFx0XHRiYXRjaE5vdGlmeUZuKCgpID0+IHtcblx0XHRcdFx0b3JpZ2luYWxRdWV1ZS5mb3JFYWNoKChjYWxsYmFjaykgPT4ge1xuXHRcdFx0XHRcdG5vdGlmeUZuKGNhbGxiYWNrKTtcblx0XHRcdFx0fSk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fTtcblx0cmV0dXJuIHtcblx0XHQvKipcblx0XHQqIEJhdGNoZXMgYWxsIHVwZGF0ZXMgc2NoZWR1bGVkIGluc2lkZSB0aGUgcGFzc2VkIGNhbGxiYWNrLlxuXHRcdCogVGhpcyBpcyBtYWlubHkgdXNlZCBpbnRlcm5hbGx5IHRvIG9wdGltaXplIHF1ZXJ5IGNsaWVudCB1cGRhdGluZy5cblx0XHQqIEJhdGNoZXMgY2FuIGJlIG5lc3RlZDsgdGhlIHF1ZXVlIGlzIG9ubHkgZmx1c2hlZCBvbmNlIHRoZSBvdXRlcm1vc3QgYGJhdGNoYCBjYWxsIGZpbmlzaGVzLlxuXHRcdCogVGhlIHJldHVybiB2YWx1ZSBvZiBgY2FsbGJhY2tgIGlzIHBhc3NlZCB0aHJvdWdoLlxuXHRcdCovXG5cdFx0YmF0Y2g6IChjYWxsYmFjaykgPT4ge1xuXHRcdFx0bGV0IHJlc3VsdDtcblx0XHRcdHRyYW5zYWN0aW9ucysrO1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0cmVzdWx0ID0gY2FsbGJhY2soKTtcblx0XHRcdH0gZmluYWxseSB7XG5cdFx0XHRcdHRyYW5zYWN0aW9ucy0tO1xuXHRcdFx0XHRpZiAoIXRyYW5zYWN0aW9ucykgZmx1c2goKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiByZXN1bHQ7XG5cdFx0fSxcblx0XHQvKipcblx0XHQqIEFsbCBjYWxscyB0byB0aGUgd3JhcHBlZCBmdW5jdGlvbiB3aWxsIGJlIGJhdGNoZWQuXG5cdFx0Ki9cblx0XHRiYXRjaENhbGxzOiAoY2FsbGJhY2spID0+IHtcblx0XHRcdHJldHVybiAoLi4uYXJncykgPT4ge1xuXHRcdFx0XHRzY2hlZHVsZSgoKSA9PiB7XG5cdFx0XHRcdFx0Y2FsbGJhY2soLi4uYXJncyk7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fTtcblx0XHR9LFxuXHRcdC8qKlxuXHRcdCogU2NoZWR1bGVzIGEgZnVuY3Rpb24gdG8gYmUgcnVuIG9uIHRoZSBuZXh0IGJhdGNoLlxuXHRcdCogQnkgZGVmYXVsdCwgdGhlIGJhdGNoIGlzIHJ1biB3aXRoIGEgYHNldFRpbWVvdXRgLCBidXQgdGhpcyBjYW4gYmUgY29uZmlndXJlZCB2aWEgYHNldFNjaGVkdWxlcmAuXG5cdFx0Ki9cblx0XHRzY2hlZHVsZSxcblx0XHQvKipcblx0XHQqIFVzZSB0aGlzIG1ldGhvZCB0byBzZXQgYSBjdXN0b20gbm90aWZ5IGZ1bmN0aW9uLlxuXHRcdCogVGhpcyBjYW4gYmUgdXNlZCB0byBmb3IgZXhhbXBsZSB3cmFwIG5vdGlmaWNhdGlvbnMgd2l0aCBgUmVhY3QuYWN0YCB3aGlsZSBydW5uaW5nIHRlc3RzLlxuXHRcdCovXG5cdFx0c2V0Tm90aWZ5RnVuY3Rpb246IChmbikgPT4ge1xuXHRcdFx0bm90aWZ5Rm4gPSBmbjtcblx0XHR9LFxuXHRcdC8qKlxuXHRcdCogVXNlIHRoaXMgbWV0aG9kIHRvIHNldCBhIGN1c3RvbSBmdW5jdGlvbiB0byBiYXRjaCBub3RpZmljYXRpb25zIHRvZ2V0aGVyIGludG8gYSBzaW5nbGUgdGljay5cblx0XHQqIEZyYW1ld29yayBhZGFwdGVycyB1c2UgdGhpcyB0byBwbHVnIGluIHRoZWlyIG93biBiYXRjaGluZyBwcmltaXRpdmUsIHNvIHRoYXQgYSBzaW5nbGUgcXVlcnlcblx0XHQqIHVwZGF0ZSBvbmx5IHRyaWdnZXJzIG9uZSByZS1yZW5kZXIgaW5zdGVhZCBvZiBvbmUgcGVyIHN1YnNjcmliZXIuXG5cdFx0KlxuXHRcdCogQGV4YW1wbGVcblx0XHQqIGBgYHRzXG5cdFx0KiBpbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdFx0KiBpbXBvcnQgeyBiYXRjaCB9IGZyb20gJ3NvbGlkLWpzJ1xuXHRcdCpcblx0XHQqIG5vdGlmeU1hbmFnZXIuc2V0QmF0Y2hOb3RpZnlGdW5jdGlvbihiYXRjaClcblx0XHQqIGBgYFxuXHRcdCovXG5cdFx0c2V0QmF0Y2hOb3RpZnlGdW5jdGlvbjogKGZuKSA9PiB7XG5cdFx0XHRiYXRjaE5vdGlmeUZuID0gZm47XG5cdFx0fSxcblx0XHQvKipcblx0XHQqIENvbmZpZ3VyZXMgYSBjdXN0b20gY2FsbGJhY2sgdGhhdCBzY2hlZHVsZXMgd2hlbiB0aGUgbmV4dCBiYXRjaCBydW5zLlxuXHRcdCogVGhlIGRlZmF1bHQgYmVoYXZpb3IgaXMgYHNldFRpbWVvdXQoY2FsbGJhY2ssIDApYC5cblx0XHQqXG5cdFx0KiBAZXhhbXBsZVxuXHRcdCogYGBgdHNcblx0XHQqIGltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0XHQqXG5cdFx0KiAvLyBTY2hlZHVsZSBiYXRjaGVzIGluIHRoZSBuZXh0IG1pY3JvdGFza1xuXHRcdCogbm90aWZ5TWFuYWdlci5zZXRTY2hlZHVsZXIocXVldWVNaWNyb3Rhc2spXG5cdFx0KlxuXHRcdCogLy8gU2NoZWR1bGUgYmF0Y2hlcyBiZWZvcmUgdGhlIG5leHQgZnJhbWUgaXMgcmVuZGVyZWRcblx0XHQqIG5vdGlmeU1hbmFnZXIuc2V0U2NoZWR1bGVyKHJlcXVlc3RBbmltYXRpb25GcmFtZSlcblx0XHQqXG5cdFx0KiAvLyBTY2hlZHVsZSBiYXRjaGVzIHNvbWUgdGltZSBpbiB0aGUgZnV0dXJlXG5cdFx0KiBub3RpZnlNYW5hZ2VyLnNldFNjaGVkdWxlcigoY2IpID0+IHNldFRpbWVvdXQoY2IsIDEwKSlcblx0XHQqIGBgYFxuXHRcdCovXG5cdFx0c2V0U2NoZWR1bGVyOiAoZm4pID0+IHtcblx0XHRcdHNjaGVkdWxlRm4gPSBmbjtcblx0XHR9XG5cdH07XG59XG4vKipcbiogSGFuZGxlcyBzY2hlZHVsaW5nIGFuZCBiYXRjaGluZyBjYWxsYmFja3MgaW4gVGFuU3RhY2sgUXVlcnkuXG4qL1xuY29uc3Qgbm90aWZ5TWFuYWdlciA9IGNyZWF0ZU5vdGlmeU1hbmFnZXIoKTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgY3JlYXRlTm90aWZ5TWFuYWdlciwgZGVmYXVsdFNjaGVkdWxlciwgbm90aWZ5TWFuYWdlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1ub3RpZnlNYW5hZ2VyLmpzLm1hcCIsImltcG9ydCB7IFN1YnNjcmliYWJsZSB9IGZyb20gXCIuL3N1YnNjcmliYWJsZS5qc1wiO1xuLy8jcmVnaW9uIHNyYy9vbmxpbmVNYW5hZ2VyLnRzXG4vKipcbiogVGhlIGBPbmxpbmVNYW5hZ2VyYCBtYW5hZ2VzIHRoZSBvbmxpbmUgc3RhdGUgd2l0aGluIFRhblN0YWNrIFF1ZXJ5LiBJdCBjYW5cbiogYmUgdXNlZCB0byBjaGFuZ2UgdGhlIGRlZmF1bHQgZXZlbnQgbGlzdGVuZXJzIG9yIHRvIG1hbnVhbGx5IGNoYW5nZSB0aGVcbiogb25saW5lIHN0YXRlLlxuKlxuKiBCeSBkZWZhdWx0LCB0aGUgYG9ubGluZU1hbmFnZXJgIGFzc3VtZXMgYW4gYWN0aXZlIG5ldHdvcmsgY29ubmVjdGlvbiwgYW5kXG4qIGxpc3RlbnMgdG8gdGhlIGBvbmxpbmVgIGFuZCBgb2ZmbGluZWAgZXZlbnRzIG9uIHRoZSBgd2luZG93YCBvYmplY3QgdG9cbiogZGV0ZWN0IGNoYW5nZXMuXG4qL1xudmFyIE9ubGluZU1hbmFnZXIgPSBjbGFzcyBleHRlbmRzIFN1YnNjcmliYWJsZSB7XG5cdCNvbmxpbmUgPSB0cnVlO1xuXHQjY2xlYW51cDtcblx0I3NldHVwO1xuXHRjb25zdHJ1Y3RvcigpIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuI3NldHVwID0gKG9uT25saW5lKSA9PiB7XG5cdFx0XHRpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiAmJiB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcikge1xuXHRcdFx0XHRjb25zdCBvbmxpbmVMaXN0ZW5lciA9ICgpID0+IG9uT25saW5lKHRydWUpO1xuXHRcdFx0XHRjb25zdCBvZmZsaW5lTGlzdGVuZXIgPSAoKSA9PiBvbk9ubGluZShmYWxzZSk7XG5cdFx0XHRcdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwib25saW5lXCIsIG9ubGluZUxpc3RlbmVyLCBmYWxzZSk7XG5cdFx0XHRcdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwib2ZmbGluZVwiLCBvZmZsaW5lTGlzdGVuZXIsIGZhbHNlKTtcblx0XHRcdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdFx0XHR3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm9ubGluZVwiLCBvbmxpbmVMaXN0ZW5lcik7XG5cdFx0XHRcdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJvZmZsaW5lXCIsIG9mZmxpbmVMaXN0ZW5lcik7XG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cdFx0fTtcblx0fVxuXHRvblN1YnNjcmliZSgpIHtcblx0XHRpZiAoIXRoaXMuI2NsZWFudXApIHRoaXMuc2V0RXZlbnRMaXN0ZW5lcih0aGlzLiNzZXR1cCk7XG5cdH1cblx0b25VbnN1YnNjcmliZSgpIHtcblx0XHRpZiAoIXRoaXMuaGFzTGlzdGVuZXJzKCkpIHtcblx0XHRcdHRoaXMuI2NsZWFudXA/LigpO1xuXHRcdFx0dGhpcy4jY2xlYW51cCA9IHZvaWQgMDtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogYHNldEV2ZW50TGlzdGVuZXJgIGNhbiBiZSB1c2VkIHRvIHNldCBhIGN1c3RvbSBldmVudCBsaXN0ZW5lciB0aGF0IHdpbGxcblx0KiBiZSB1c2VkIHRvIGRldGVybWluZSB0aGUgb25saW5lIHN0YXRlLiBUaGUgcHJvdmlkZWQgYHNldHVwYCBmdW5jdGlvblxuXHQqIHJlY2VpdmVzIGEgYHNldE9ubGluZWAgY2FsbGJhY2sgdGhhdCBzaG91bGQgYmUgY2FsbGVkIHdpdGggYSBgYm9vbGVhbmBcblx0KiB3aGVuZXZlciB0aGUgb25saW5lIHN0YXRlIGNoYW5nZXMuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaW1wb3J0IE5ldEluZm8gZnJvbSAnQHJlYWN0LW5hdGl2ZS1jb21tdW5pdHkvbmV0aW5mbydcblx0KiBpbXBvcnQgeyBvbmxpbmVNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBvbmxpbmVNYW5hZ2VyLnNldEV2ZW50TGlzdGVuZXIoKHNldE9ubGluZSkgPT4ge1xuXHQqICAgcmV0dXJuIE5ldEluZm8uYWRkRXZlbnRMaXN0ZW5lcigoc3RhdGUpID0+IHtcblx0KiAgICAgc2V0T25saW5lKCEhc3RhdGUuaXNDb25uZWN0ZWQpXG5cdCogICB9KVxuXHQqIH0pXG5cdCogYGBgXG5cdCovXG5cdHNldEV2ZW50TGlzdGVuZXIoc2V0dXApIHtcblx0XHR0aGlzLiNzZXR1cCA9IHNldHVwO1xuXHRcdHRoaXMuI2NsZWFudXA/LigpO1xuXHRcdHRoaXMuI2NsZWFudXAgPSBzZXR1cCh0aGlzLnNldE9ubGluZS5iaW5kKHRoaXMpKTtcblx0fVxuXHQvKipcblx0KiBgc2V0T25saW5lYCBjYW4gYmUgdXNlZCB0byBtYW51YWxseSBzZXQgdGhlIG9ubGluZSBzdGF0ZS5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBvbmxpbmVNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiAvLyBTZXQgdG8gb25saW5lXG5cdCogb25saW5lTWFuYWdlci5zZXRPbmxpbmUodHJ1ZSlcblx0KlxuXHQqIC8vIFNldCB0byBvZmZsaW5lXG5cdCogb25saW5lTWFuYWdlci5zZXRPbmxpbmUoZmFsc2UpXG5cdCogYGBgXG5cdCovXG5cdHNldE9ubGluZShvbmxpbmUpIHtcblx0XHRpZiAodGhpcy4jb25saW5lICE9PSBvbmxpbmUpIHtcblx0XHRcdHRoaXMuI29ubGluZSA9IG9ubGluZTtcblx0XHRcdHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG5cdFx0XHRcdGxpc3RlbmVyKG9ubGluZSk7XG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogYGlzT25saW5lYCBjYW4gYmUgdXNlZCB0byBnZXQgdGhlIGN1cnJlbnQgb25saW5lIHN0YXRlLlxuXHQqL1xuXHRpc09ubGluZSgpIHtcblx0XHRyZXR1cm4gdGhpcy4jb25saW5lO1xuXHR9XG59O1xuLyoqXG4qIFNpbmdsZXRvbiBpbnN0YW5jZSBvZiB7QGxpbmsgT25saW5lTWFuYWdlcn0sIHVzZWQgdG8gbWFuYWdlIGFuZCBvYnNlcnZlIHRoZSBvbmxpbmUgc3RhdGUgd2l0aGluIFRhblN0YWNrIFF1ZXJ5LlxuKi9cbmNvbnN0IG9ubGluZU1hbmFnZXIgPSBuZXcgT25saW5lTWFuYWdlcigpO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBPbmxpbmVNYW5hZ2VyLCBvbmxpbmVNYW5hZ2VyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW9ubGluZU1hbmFnZXIuanMubWFwIiwiaW1wb3J0IHsgbm9vcCwgc2xlZXAgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiLi9lbnZpcm9ubWVudE1hbmFnZXIuanNcIjtcbmltcG9ydCB7IGZvY3VzTWFuYWdlciB9IGZyb20gXCIuL2ZvY3VzTWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgb25saW5lTWFuYWdlciB9IGZyb20gXCIuL29ubGluZU1hbmFnZXIuanNcIjtcbi8vI3JlZ2lvbiBzcmMvcmV0cnllci50c1xuZnVuY3Rpb24gZGVmYXVsdFJldHJ5RGVsYXkoZmFpbHVyZUNvdW50KSB7XG5cdHJldHVybiBNYXRoLm1pbigxZTMgKiAyICoqIGZhaWx1cmVDb3VudCwgM2U0KTtcbn1cbmZ1bmN0aW9uIGNhbkZldGNoKG5ldHdvcmtNb2RlKSB7XG5cdHJldHVybiAobmV0d29ya01vZGUgPz8gXCJvbmxpbmVcIikgPT09IFwib25saW5lXCIgPyBvbmxpbmVNYW5hZ2VyLmlzT25saW5lKCkgOiB0cnVlO1xufVxuLyoqXG4qIFRoZSBlcnJvciB0aHJvd24gYnkgYSBgUmV0cnllcmAgKGFuZCBzdXJmYWNlZCB0byBgcXVlcnkucHJvbWlzZWAvYG11dGF0aW9uYCkgd2hlbiBhIGZldGNoIGlzIGNhbmNlbGxlZCwgZS5nLiB2aWFcbiogYHF1ZXJ5LmNhbmNlbCgpYC4gYHJldmVydGAsIGlmIGB0cnVlYCwgdGVsbHMgdGhlIGNhbGxlciB0byByZXN0b3JlIHRoZSBzdGF0ZSB0aGUgcXVlcnkgd2FzIGluIGJlZm9yZSB0aGUgZmV0Y2hcbiogc3RhcnRlZCBpbnN0ZWFkIG9mIHN1cmZhY2luZyB0aGUgZXJyb3IuIGBzaWxlbnRgLCBpZiBgdHJ1ZWAsIHRlbGxzIHRoZSBjYWxsZXIgdG8gc3VwcHJlc3MgdGhpcyBlcnJvciBhbmQgaW5zdGVhZFxuKiByZXNvbHZlIHdpdGggdGhlIHByb21pc2Ugb2YgdGhlIGZldGNoIHRoYXQgdHJpZ2dlcmVkIHRoZSBjYW5jZWxsYXRpb24uXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIHF1ZXJ5LmNhbmNlbCgpXG4qXG4qIHRyeSB7XG4qICAgYXdhaXQgcXVlcnkucHJvbWlzZVxuKiB9IGNhdGNoIChlcnJvcikge1xuKiAgIGlmIChlcnJvciBpbnN0YW5jZW9mIENhbmNlbGxlZEVycm9yKSB7XG4qICAgICAvLyB0aGUgZmV0Y2ggd2FzIGNhbmNlbGxlZCwgZS5nLiB2aWEgYHF1ZXJ5LmNhbmNlbCgpYFxuKiAgIH1cbiogfVxuKiBgYGBcbiovXG52YXIgQ2FuY2VsbGVkRXJyb3IgPSBjbGFzcyBleHRlbmRzIEVycm9yIHtcblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdHN1cGVyKFwiQ2FuY2VsbGVkRXJyb3JcIik7XG5cdFx0dGhpcy5yZXZlcnQgPSBvcHRpb25zPy5yZXZlcnQ7XG5cdFx0dGhpcy5zaWxlbnQgPSBvcHRpb25zPy5zaWxlbnQ7XG5cdH1cbn07XG4vKipcbiogQGRlcHJlY2F0ZWQgVXNlIGluc3RhbmNlb2YgYENhbmNlbGxlZEVycm9yYCBpbnN0ZWFkLlxuKi9cbmZ1bmN0aW9uIGlzQ2FuY2VsbGVkRXJyb3IodmFsdWUpIHtcblx0cmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgQ2FuY2VsbGVkRXJyb3I7XG59XG5mdW5jdGlvbiBjcmVhdGVSZXRyeWVyKGNvbmZpZykge1xuXHRsZXQgaXNSZXRyeUNhbmNlbGxlZCA9IGZhbHNlO1xuXHRsZXQgZmFpbHVyZUNvdW50ID0gMDtcblx0bGV0IGNvbnRpbnVlRm47XG5cdGxldCBzdGF0dXMgPSBcInBlbmRpbmdcIjtcblx0bGV0IHByb21pc2VSZXNvbHZlO1xuXHRsZXQgcHJvbWlzZVJlamVjdDtcblx0Y29uc3QgcHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRwcm9taXNlUmVzb2x2ZSA9IHJlc29sdmU7XG5cdFx0cHJvbWlzZVJlamVjdCA9IHJlamVjdDtcblx0fSk7XG5cdHByb21pc2UuY2F0Y2gobm9vcCk7XG5cdGNvbnN0IGlzUmVzb2x2ZWQgPSAoKSA9PiBzdGF0dXMgIT09IFwicGVuZGluZ1wiO1xuXHRjb25zdCBjYW5jZWwgPSAoY2FuY2VsT3B0aW9ucykgPT4ge1xuXHRcdGlmICghaXNSZXNvbHZlZCgpKSB7XG5cdFx0XHRjb25zdCBlcnJvciA9IG5ldyBDYW5jZWxsZWRFcnJvcihjYW5jZWxPcHRpb25zKTtcblx0XHRcdHJlamVjdChlcnJvcik7XG5cdFx0XHRjb25maWcub25DYW5jZWw/LihlcnJvcik7XG5cdFx0fVxuXHR9O1xuXHRjb25zdCBjYW5jZWxSZXRyeSA9ICgpID0+IHtcblx0XHRpc1JldHJ5Q2FuY2VsbGVkID0gdHJ1ZTtcblx0fTtcblx0Y29uc3QgY29udGludWVSZXRyeSA9ICgpID0+IHtcblx0XHRpc1JldHJ5Q2FuY2VsbGVkID0gZmFsc2U7XG5cdH07XG5cdGNvbnN0IGNhbkNvbnRpbnVlID0gKCkgPT4gZm9jdXNNYW5hZ2VyLmlzRm9jdXNlZCgpICYmIChjb25maWcubmV0d29ya01vZGUgPT09IFwiYWx3YXlzXCIgfHwgb25saW5lTWFuYWdlci5pc09ubGluZSgpKSAmJiBjb25maWcuY2FuUnVuKCk7XG5cdGNvbnN0IGNhblN0YXJ0ID0gKCkgPT4gY2FuRmV0Y2goY29uZmlnLm5ldHdvcmtNb2RlKSAmJiBjb25maWcuY2FuUnVuKCk7XG5cdGNvbnN0IHJlc29sdmUgPSAodmFsdWUpID0+IHtcblx0XHRpZiAoIWlzUmVzb2x2ZWQoKSkge1xuXHRcdFx0Y29udGludWVGbj8uKCk7XG5cdFx0XHRzdGF0dXMgPSBcInJlc29sdmVkXCI7XG5cdFx0XHRwcm9taXNlUmVzb2x2ZSh2YWx1ZSk7XG5cdFx0fVxuXHR9O1xuXHRjb25zdCByZWplY3QgPSAodmFsdWUpID0+IHtcblx0XHRpZiAoIWlzUmVzb2x2ZWQoKSkge1xuXHRcdFx0Y29udGludWVGbj8uKCk7XG5cdFx0XHRzdGF0dXMgPSBcInJlamVjdGVkXCI7XG5cdFx0XHRwcm9taXNlUmVqZWN0KHZhbHVlKTtcblx0XHR9XG5cdH07XG5cdGNvbnN0IHBhdXNlID0gKCkgPT4ge1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZSgoY29udGludWVSZXNvbHZlKSA9PiB7XG5cdFx0XHRjb250aW51ZUZuID0gKHZhbHVlKSA9PiB7XG5cdFx0XHRcdGlmIChpc1Jlc29sdmVkKCkgfHwgY2FuQ29udGludWUoKSkgY29udGludWVSZXNvbHZlKHZhbHVlKTtcblx0XHRcdH07XG5cdFx0XHRjb25maWcub25QYXVzZT8uKCk7XG5cdFx0fSkudGhlbigoKSA9PiB7XG5cdFx0XHRjb250aW51ZUZuID0gdm9pZCAwO1xuXHRcdFx0aWYgKCFpc1Jlc29sdmVkKCkpIGNvbmZpZy5vbkNvbnRpbnVlPy4oKTtcblx0XHR9KTtcblx0fTtcblx0Y29uc3QgcnVuID0gKCkgPT4ge1xuXHRcdGlmIChpc1Jlc29sdmVkKCkpIHJldHVybjtcblx0XHRsZXQgcHJvbWlzZU9yVmFsdWU7XG5cdFx0Y29uc3QgaW5pdGlhbFByb21pc2UgPSBmYWlsdXJlQ291bnQgPT09IDAgPyBjb25maWcuaW5pdGlhbFByb21pc2UgOiB2b2lkIDA7XG5cdFx0dHJ5IHtcblx0XHRcdHByb21pc2VPclZhbHVlID0gaW5pdGlhbFByb21pc2UgPz8gY29uZmlnLmZuKCk7XG5cdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdHByb21pc2VPclZhbHVlID0gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuXHRcdH1cblx0XHRQcm9taXNlLnJlc29sdmUocHJvbWlzZU9yVmFsdWUpLnRoZW4ocmVzb2x2ZSkuY2F0Y2goKGVycm9yKSA9PiB7XG5cdFx0XHRpZiAoaXNSZXNvbHZlZCgpKSByZXR1cm47XG5cdFx0XHRjb25zdCByZXRyeSA9IGNvbmZpZy5yZXRyeSA/PyAoaXNTZXJ2ZXIoKSA/IDAgOiAzKTtcblx0XHRcdGNvbnN0IHJldHJ5RGVsYXkgPSBjb25maWcucmV0cnlEZWxheSA/PyBkZWZhdWx0UmV0cnlEZWxheTtcblx0XHRcdGNvbnN0IGRlbGF5ID0gdHlwZW9mIHJldHJ5RGVsYXkgPT09IFwiZnVuY3Rpb25cIiA/IHJldHJ5RGVsYXkoZmFpbHVyZUNvdW50LCBlcnJvcikgOiByZXRyeURlbGF5O1xuXHRcdFx0Y29uc3Qgc2hvdWxkUmV0cnkgPSByZXRyeSA9PT0gdHJ1ZSB8fCB0eXBlb2YgcmV0cnkgPT09IFwibnVtYmVyXCIgJiYgZmFpbHVyZUNvdW50IDwgcmV0cnkgfHwgdHlwZW9mIHJldHJ5ID09PSBcImZ1bmN0aW9uXCIgJiYgcmV0cnkoZmFpbHVyZUNvdW50LCBlcnJvcik7XG5cdFx0XHRpZiAoaXNSZXRyeUNhbmNlbGxlZCB8fCAhc2hvdWxkUmV0cnkpIHtcblx0XHRcdFx0cmVqZWN0KGVycm9yKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdFx0ZmFpbHVyZUNvdW50Kys7XG5cdFx0XHRjb25maWcub25GYWlsPy4oZmFpbHVyZUNvdW50LCBlcnJvcik7XG5cdFx0XHRzbGVlcChkZWxheSkudGhlbigoKSA9PiB7XG5cdFx0XHRcdHJldHVybiBjYW5Db250aW51ZSgpID8gdm9pZCAwIDogcGF1c2UoKTtcblx0XHRcdH0pLnRoZW4oKCkgPT4ge1xuXHRcdFx0XHRpZiAoaXNSZXRyeUNhbmNlbGxlZCkgcmVqZWN0KGVycm9yKTtcblx0XHRcdFx0ZWxzZSBydW4oKTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdHByb21pc2UsXG5cdFx0c3RhdHVzOiAoKSA9PiBzdGF0dXMsXG5cdFx0Y2FuY2VsLFxuXHRcdGNvbnRpbnVlOiAoKSA9PiB7XG5cdFx0XHRjb250aW51ZUZuPy4oKTtcblx0XHRcdHJldHVybiBwcm9taXNlO1xuXHRcdH0sXG5cdFx0Y2FuY2VsUmV0cnksXG5cdFx0Y29udGludWVSZXRyeSxcblx0XHRjYW5TdGFydCxcblx0XHRzdGFydDogKCkgPT4ge1xuXHRcdFx0aWYgKGNhblN0YXJ0KCkpIHJ1bigpO1xuXHRcdFx0ZWxzZSBwYXVzZSgpLnRoZW4ocnVuKTtcblx0XHRcdHJldHVybiBwcm9taXNlO1xuXHRcdH1cblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgQ2FuY2VsbGVkRXJyb3IsIGNhbkZldGNoLCBjcmVhdGVSZXRyeWVyLCBpc0NhbmNlbGxlZEVycm9yIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJldHJ5ZXIuanMubWFwIiwiaW1wb3J0IHsgdGltZW91dE1hbmFnZXIgfSBmcm9tIFwiLi90aW1lb3V0TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgaXNWYWxpZFRpbWVvdXQgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiLi9lbnZpcm9ubWVudE1hbmFnZXIuanNcIjtcbi8vI3JlZ2lvbiBzcmMvcmVtb3ZhYmxlLnRzXG52YXIgUmVtb3ZhYmxlID0gY2xhc3Mge1xuXHQjZ2NUaW1lb3V0O1xuXHRkZXN0cm95KCkge1xuXHRcdHRoaXMuY2xlYXJHY1RpbWVvdXQoKTtcblx0fVxuXHRzY2hlZHVsZUdjKCkge1xuXHRcdHRoaXMuY2xlYXJHY1RpbWVvdXQoKTtcblx0XHRpZiAoaXNWYWxpZFRpbWVvdXQodGhpcy5nY1RpbWUpKSB0aGlzLiNnY1RpbWVvdXQgPSB0aW1lb3V0TWFuYWdlci5zZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdHRoaXMub3B0aW9uYWxSZW1vdmUoKTtcblx0XHR9LCB0aGlzLmdjVGltZSk7XG5cdH1cblx0dXBkYXRlR2NUaW1lKG5ld0djVGltZSkge1xuXHRcdHRoaXMuZ2NUaW1lID0gTWF0aC5tYXgodGhpcy5nY1RpbWUgfHwgMCwgbmV3R2NUaW1lID8/IChpc1NlcnZlcigpID8gSW5maW5pdHkgOiAzZTUpKTtcblx0fVxuXHRjbGVhckdjVGltZW91dCgpIHtcblx0XHRpZiAodGhpcy4jZ2NUaW1lb3V0ICE9PSB2b2lkIDApIHtcblx0XHRcdHRpbWVvdXRNYW5hZ2VyLmNsZWFyVGltZW91dCh0aGlzLiNnY1RpbWVvdXQpO1xuXHRcdFx0dGhpcy4jZ2NUaW1lb3V0ID0gdm9pZCAwO1xuXHRcdH1cblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUmVtb3ZhYmxlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJlbW92YWJsZS5qcy5tYXAiLCJpbXBvcnQgeyBhZGRDb25zdW1lQXdhcmVTaWduYWwsIGFkZFRvRW5kLCBhZGRUb1N0YXJ0LCBlbnN1cmVRdWVyeUZuIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbi8vI3JlZ2lvbiBzcmMvaW5maW5pdGVRdWVyeUJlaGF2aW9yLnRzXG5mdW5jdGlvbiBpbmZpbml0ZVF1ZXJ5QmVoYXZpb3IocGFnZXMpIHtcblx0cmV0dXJuIHsgb25GZXRjaDogKGNvbnRleHQsIHF1ZXJ5KSA9PiB7XG5cdFx0Y29uc3Qgb3B0aW9ucyA9IGNvbnRleHQub3B0aW9ucztcblx0XHRjb25zdCBkaXJlY3Rpb24gPSBjb250ZXh0LmZldGNoT3B0aW9ucz8ubWV0YT8uZmV0Y2hNb3JlPy5kaXJlY3Rpb247XG5cdFx0Y29uc3Qgb2xkUGFnZXMgPSBjb250ZXh0LnN0YXRlLmRhdGE/LnBhZ2VzIHx8IFtdO1xuXHRcdGNvbnN0IG9sZFBhZ2VQYXJhbXMgPSBjb250ZXh0LnN0YXRlLmRhdGE/LnBhZ2VQYXJhbXMgfHwgW107XG5cdFx0bGV0IHJlc3VsdCA9IHtcblx0XHRcdHBhZ2VzOiBbXSxcblx0XHRcdHBhZ2VQYXJhbXM6IFtdXG5cdFx0fTtcblx0XHRsZXQgY3VycmVudFBhZ2UgPSAwO1xuXHRcdGNvbnN0IGZldGNoRm4gPSBhc3luYyAoKSA9PiB7XG5cdFx0XHRsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG5cdFx0XHRjb25zdCBhZGRTaWduYWxQcm9wZXJ0eSA9IChvYmplY3QpID0+IHtcblx0XHRcdFx0YWRkQ29uc3VtZUF3YXJlU2lnbmFsKG9iamVjdCwgKCkgPT4gY29udGV4dC5zaWduYWwsICgpID0+IGNhbmNlbGxlZCA9IHRydWUpO1xuXHRcdFx0fTtcblx0XHRcdGNvbnN0IHF1ZXJ5Rm4gPSBlbnN1cmVRdWVyeUZuKGNvbnRleHQub3B0aW9ucywgY29udGV4dC5mZXRjaE9wdGlvbnMpO1xuXHRcdFx0Y29uc3QgZmV0Y2hQYWdlID0gYXN5bmMgKGRhdGEsIHBhcmFtLCBwcmV2aW91cykgPT4ge1xuXHRcdFx0XHRpZiAoY2FuY2VsbGVkKSByZXR1cm4gUHJvbWlzZS5yZWplY3QoY29udGV4dC5zaWduYWwucmVhc29uKTtcblx0XHRcdFx0aWYgKHBhcmFtID09IG51bGwgJiYgZGF0YS5wYWdlcy5sZW5ndGgpIHJldHVybiBQcm9taXNlLnJlc29sdmUoZGF0YSk7XG5cdFx0XHRcdGNvbnN0IGNyZWF0ZVF1ZXJ5Rm5Db250ZXh0ID0gKCkgPT4ge1xuXHRcdFx0XHRcdGNvbnN0IHF1ZXJ5Rm5Db250ZXh0ID0ge1xuXHRcdFx0XHRcdFx0Y2xpZW50OiBjb250ZXh0LmNsaWVudCxcblx0XHRcdFx0XHRcdHF1ZXJ5S2V5OiBjb250ZXh0LnF1ZXJ5S2V5LFxuXHRcdFx0XHRcdFx0cGFnZVBhcmFtOiBwYXJhbSxcblx0XHRcdFx0XHRcdGRpcmVjdGlvbjogcHJldmlvdXMgPyBcImJhY2t3YXJkXCIgOiBcImZvcndhcmRcIixcblx0XHRcdFx0XHRcdG1ldGE6IGNvbnRleHQub3B0aW9ucy5tZXRhXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRhZGRTaWduYWxQcm9wZXJ0eShxdWVyeUZuQ29udGV4dCk7XG5cdFx0XHRcdFx0cmV0dXJuIHF1ZXJ5Rm5Db250ZXh0O1xuXHRcdFx0XHR9O1xuXHRcdFx0XHRjb25zdCBxdWVyeUZuQ29udGV4dCA9IGNyZWF0ZVF1ZXJ5Rm5Db250ZXh0KCk7XG5cdFx0XHRcdGNvbnN0IHBhZ2UgPSBhd2FpdCBxdWVyeUZuKHF1ZXJ5Rm5Db250ZXh0KTtcblx0XHRcdFx0Y29uc3QgeyBtYXhQYWdlcyB9ID0gY29udGV4dC5vcHRpb25zO1xuXHRcdFx0XHRjb25zdCBhZGRUbyA9IHByZXZpb3VzID8gYWRkVG9TdGFydCA6IGFkZFRvRW5kO1xuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdHBhZ2VzOiBhZGRUbyhkYXRhLnBhZ2VzLCBwYWdlLCBtYXhQYWdlcyksXG5cdFx0XHRcdFx0cGFnZVBhcmFtczogYWRkVG8oZGF0YS5wYWdlUGFyYW1zLCBwYXJhbSwgbWF4UGFnZXMpXG5cdFx0XHRcdH07XG5cdFx0XHR9O1xuXHRcdFx0aWYgKGRpcmVjdGlvbiAmJiBvbGRQYWdlcy5sZW5ndGgpIHtcblx0XHRcdFx0Y29uc3QgcHJldmlvdXMgPSBkaXJlY3Rpb24gPT09IFwiYmFja3dhcmRcIjtcblx0XHRcdFx0Y29uc3QgcGFnZVBhcmFtRm4gPSBwcmV2aW91cyA/IGdldFByZXZpb3VzUGFnZVBhcmFtIDogZ2V0TmV4dFBhZ2VQYXJhbTtcblx0XHRcdFx0Y29uc3Qgb2xkRGF0YSA9IHtcblx0XHRcdFx0XHRwYWdlczogb2xkUGFnZXMsXG5cdFx0XHRcdFx0cGFnZVBhcmFtczogb2xkUGFnZVBhcmFtc1xuXHRcdFx0XHR9O1xuXHRcdFx0XHRyZXN1bHQgPSBhd2FpdCBmZXRjaFBhZ2Uob2xkRGF0YSwgcGFnZVBhcmFtRm4ob3B0aW9ucywgb2xkRGF0YSksIHByZXZpb3VzKTtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGNvbnN0IHJlbWFpbmluZ1BhZ2VzID0gcGFnZXMgPz8gb2xkUGFnZXMubGVuZ3RoO1xuXHRcdFx0XHRkbyB7XG5cdFx0XHRcdFx0Y29uc3QgcGFyYW0gPSBjdXJyZW50UGFnZSA9PT0gMCA/IG9sZFBhZ2VQYXJhbXNbMF0gPz8gb3B0aW9ucy5pbml0aWFsUGFnZVBhcmFtIDogZ2V0TmV4dFBhZ2VQYXJhbShvcHRpb25zLCByZXN1bHQpO1xuXHRcdFx0XHRcdGlmIChjdXJyZW50UGFnZSA+IDAgJiYgcGFyYW0gPT0gbnVsbCkgYnJlYWs7XG5cdFx0XHRcdFx0cmVzdWx0ID0gYXdhaXQgZmV0Y2hQYWdlKHJlc3VsdCwgcGFyYW0pO1xuXHRcdFx0XHRcdGN1cnJlbnRQYWdlKys7XG5cdFx0XHRcdH0gd2hpbGUgKGN1cnJlbnRQYWdlIDwgcmVtYWluaW5nUGFnZXMpO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9O1xuXHRcdGlmIChjb250ZXh0Lm9wdGlvbnMucGVyc2lzdGVyKSBjb250ZXh0LmZldGNoRm4gPSAoKSA9PiB7XG5cdFx0XHRyZXR1cm4gY29udGV4dC5vcHRpb25zLnBlcnNpc3Rlcj8uKGZldGNoRm4sIHtcblx0XHRcdFx0Y2xpZW50OiBjb250ZXh0LmNsaWVudCxcblx0XHRcdFx0cXVlcnlLZXk6IGNvbnRleHQucXVlcnlLZXksXG5cdFx0XHRcdG1ldGE6IGNvbnRleHQub3B0aW9ucy5tZXRhLFxuXHRcdFx0XHRzaWduYWw6IGNvbnRleHQuc2lnbmFsXG5cdFx0XHR9LCBxdWVyeSk7XG5cdFx0fTtcblx0XHRlbHNlIGNvbnRleHQuZmV0Y2hGbiA9IGZldGNoRm47XG5cdH0gfTtcbn1cbmZ1bmN0aW9uIGdldE5leHRQYWdlUGFyYW0ob3B0aW9ucywgeyBwYWdlcywgcGFnZVBhcmFtcyB9KSB7XG5cdGNvbnN0IGxhc3RJbmRleCA9IHBhZ2VzLmxlbmd0aCAtIDE7XG5cdHJldHVybiBwYWdlcy5sZW5ndGggPiAwID8gb3B0aW9ucy5nZXROZXh0UGFnZVBhcmFtKHBhZ2VzW2xhc3RJbmRleF0sIHBhZ2VzLCBwYWdlUGFyYW1zW2xhc3RJbmRleF0sIHBhZ2VQYXJhbXMpIDogdm9pZCAwO1xufVxuZnVuY3Rpb24gZ2V0UHJldmlvdXNQYWdlUGFyYW0ob3B0aW9ucywgeyBwYWdlcywgcGFnZVBhcmFtcyB9KSB7XG5cdHJldHVybiBwYWdlcy5sZW5ndGggPiAwID8gb3B0aW9ucy5nZXRQcmV2aW91c1BhZ2VQYXJhbT8uKHBhZ2VzWzBdLCBwYWdlcywgcGFnZVBhcmFtc1swXSwgcGFnZVBhcmFtcykgOiB2b2lkIDA7XG59XG4vKipcbiogQ2hlY2tzIGlmIHRoZXJlIGlzIGEgbmV4dCBwYWdlLlxuKi9cbmZ1bmN0aW9uIGhhc05leHRQYWdlKG9wdGlvbnMsIGRhdGEpIHtcblx0aWYgKCFkYXRhKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiBnZXROZXh0UGFnZVBhcmFtKG9wdGlvbnMsIGRhdGEpICE9IG51bGw7XG59XG4vKipcbiogQ2hlY2tzIGlmIHRoZXJlIGlzIGEgcHJldmlvdXMgcGFnZS5cbiovXG5mdW5jdGlvbiBoYXNQcmV2aW91c1BhZ2Uob3B0aW9ucywgZGF0YSkge1xuXHRpZiAoIWRhdGEgfHwgIW9wdGlvbnMuZ2V0UHJldmlvdXNQYWdlUGFyYW0pIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIGdldFByZXZpb3VzUGFnZVBhcmFtKG9wdGlvbnMsIGRhdGEpICE9IG51bGw7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGhhc05leHRQYWdlLCBoYXNQcmV2aW91c1BhZ2UsIGluZmluaXRlUXVlcnlCZWhhdmlvciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmZpbml0ZVF1ZXJ5QmVoYXZpb3IuanMubWFwIiwiaW1wb3J0IHsgZW5zdXJlUXVlcnlGbiwgbm9vcCwgcmVwbGFjZURhdGEsIHJlc29sdmVRdWVyeVZhbHVlLCBza2lwVG9rZW4sIHRpbWVVbnRpbFN0YWxlIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBDYW5jZWxsZWRFcnJvciwgY2FuRmV0Y2gsIGNyZWF0ZVJldHJ5ZXIgfSBmcm9tIFwiLi9yZXRyeWVyLmpzXCI7XG5pbXBvcnQgeyBSZW1vdmFibGUgfSBmcm9tIFwiLi9yZW1vdmFibGUuanNcIjtcbmltcG9ydCB7IGluZmluaXRlUXVlcnlCZWhhdmlvciB9IGZyb20gXCIuL2luZmluaXRlUXVlcnlCZWhhdmlvci5qc1wiO1xuLy8jcmVnaW9uIHNyYy9xdWVyeS50c1xuLyoqXG4qIFJlcHJlc2VudHMgYSBzaW5nbGUgY2FjaGVkIHF1ZXJ5LiBBIGBRdWVyeWAgaG9sZHMgdGhlIHF1ZXJ5J3Mga2V5LCBvcHRpb25zLFxuKiBzdGF0ZSAoZGF0YS9lcnJvci9zdGF0dXMpLCBhbmQgdGhlIG9ic2VydmVycyBjdXJyZW50bHkgc3Vic2NyaWJlZCB0byBpdC5cbipcbiogSW5zdGFuY2VzIGFyZSBjcmVhdGVkIGFuZCBtYW5hZ2VkIGludGVybmFsbHkgYnkgYFF1ZXJ5Q2FjaGVgOyBhcHBsaWNhdGlvblxuKiBjb2RlIHR5cGljYWxseSBpbnRlcmFjdHMgd2l0aCBxdWVyaWVzIGluZGlyZWN0bHkgdGhyb3VnaCBgUXVlcnlDbGllbnRgIG9yXG4qIGEgZnJhbWV3b3JrIGhvb2sgbGlrZSBgdXNlUXVlcnlgLiBEaXJlY3QgYWNjZXNzIHRvIGEgYFF1ZXJ5YCBpbnN0YW5jZSBpc1xuKiBwb3NzaWJsZSB2aWEgYHF1ZXJ5Q2FjaGUuZmluZCgpYC9gZmluZEFsbCgpYCBmb3IgaW5zcGVjdGluZyBjYWNoZSBzdGF0ZS5cbipcbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3QgcXVlcnlDYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5Q2FjaGUoKVxuKiBjb25zdCBxdWVyeSA9IHF1ZXJ5Q2FjaGUuZmluZCh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10gfSlcbipcbiogaWYgKHF1ZXJ5KSB7XG4qICAgY29uc29sZS5sb2cocXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdClcbiogfVxuKiBgYGBcbiovXG52YXIgUXVlcnkgPSBjbGFzcyBleHRlbmRzIFJlbW92YWJsZSB7XG5cdCNxdWVyeVR5cGU7XG5cdCNpbml0aWFsU3RhdGU7XG5cdCNyZXZlcnRTdGF0ZTtcblx0I2NhY2hlO1xuXHQjY2xpZW50O1xuXHQjcmV0cnllcjtcblx0I2RlZmF1bHRPcHRpb25zO1xuXHQjYWJvcnRTaWduYWxDb25zdW1lZDtcblx0Y29uc3RydWN0b3IoY29uZmlnKSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLiNhYm9ydFNpZ25hbENvbnN1bWVkID0gZmFsc2U7XG5cdFx0dGhpcy4jZGVmYXVsdE9wdGlvbnMgPSBjb25maWcuZGVmYXVsdE9wdGlvbnM7XG5cdFx0dGhpcy5zZXRPcHRpb25zKGNvbmZpZy5vcHRpb25zKTtcblx0XHR0aGlzLm9ic2VydmVycyA9IFtdO1xuXHRcdHRoaXMuI2NsaWVudCA9IGNvbmZpZy5jbGllbnQ7XG5cdFx0dGhpcy4jY2FjaGUgPSB0aGlzLiNjbGllbnQuZ2V0UXVlcnlDYWNoZSgpO1xuXHRcdHRoaXMucXVlcnlLZXkgPSBjb25maWcucXVlcnlLZXk7XG5cdFx0dGhpcy5xdWVyeUhhc2ggPSBjb25maWcucXVlcnlIYXNoO1xuXHRcdHRoaXMuI2luaXRpYWxTdGF0ZSA9IGdldERlZmF1bHRTdGF0ZSh0aGlzLm9wdGlvbnMpO1xuXHRcdHRoaXMuc3RhdGUgPSBjb25maWcuc3RhdGUgPz8gdGhpcy4jaW5pdGlhbFN0YXRlO1xuXHRcdHRoaXMuc2NoZWR1bGVHYygpO1xuXHR9XG5cdC8qKlxuXHQqIFRoZSBgbWV0YWAgb2JqZWN0IHBhc3NlZCBpbiB0aGUgcXVlcnkncyBvcHRpb25zLCBpZiBhbnkuXG5cdCovXG5cdGdldCBtZXRhKCkge1xuXHRcdHJldHVybiB0aGlzLm9wdGlvbnMubWV0YTtcblx0fVxuXHQvKiogQGludGVybmFsICovXG5cdGdldCBxdWVyeVR5cGUoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI3F1ZXJ5VHlwZTtcblx0fVxuXHQvKipcblx0KiBUaGUgcHJvbWlzZSBmb3IgdGhlIGN1cnJlbnRseSBpbi1mbGlnaHQgZmV0Y2gsIGlmIHRoZSBxdWVyeSBpcyBmZXRjaGluZy5cblx0KiBgdW5kZWZpbmVkYCB3aGVuIHRoZSBxdWVyeSBpcyBub3QgZmV0Y2hpbmcuXG5cdCovXG5cdGdldCBwcm9taXNlKCkge1xuXHRcdHJldHVybiB0aGlzLiNyZXRyeWVyPy5wcm9taXNlO1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0c2V0T3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0dGhpcy5vcHRpb25zID0ge1xuXHRcdFx0Li4udGhpcy4jZGVmYXVsdE9wdGlvbnMsXG5cdFx0XHQuLi5vcHRpb25zXG5cdFx0fTtcblx0XHRpZiAob3B0aW9ucz8uX3R5cGUpIHRoaXMuI3F1ZXJ5VHlwZSA9IG9wdGlvbnMuX3R5cGU7XG5cdFx0dGhpcy51cGRhdGVHY1RpbWUodGhpcy5vcHRpb25zLmdjVGltZSk7XG5cdFx0aWYgKHRoaXMuc3RhdGUgJiYgdGhpcy5zdGF0ZS5kYXRhID09PSB2b2lkIDApIHtcblx0XHRcdGNvbnN0IGRlZmF1bHRTdGF0ZSA9IGdldERlZmF1bHRTdGF0ZSh0aGlzLm9wdGlvbnMpO1xuXHRcdFx0aWYgKGRlZmF1bHRTdGF0ZS5kYXRhICE9PSB2b2lkIDApIHtcblx0XHRcdFx0dGhpcy5zZXRTdGF0ZShzdWNjZXNzU3RhdGUoZGVmYXVsdFN0YXRlLmRhdGEsIGRlZmF1bHRTdGF0ZS5kYXRhVXBkYXRlZEF0KSk7XG5cdFx0XHRcdHRoaXMuI2luaXRpYWxTdGF0ZSA9IGRlZmF1bHRTdGF0ZTtcblx0XHRcdH1cblx0XHR9XG5cdH1cblx0b3B0aW9uYWxSZW1vdmUoKSB7XG5cdFx0aWYgKCF0aGlzLm9ic2VydmVycy5sZW5ndGggJiYgdGhpcy5zdGF0ZS5mZXRjaFN0YXR1cyA9PT0gXCJpZGxlXCIpIHRoaXMuI2NhY2hlLnJlbW92ZSh0aGlzKTtcblx0fVxuXHQvKiogQGludGVybmFsICovXG5cdHNldERhdGEobmV3RGF0YSwgb3B0aW9ucykge1xuXHRcdGNvbnN0IGRhdGEgPSByZXBsYWNlRGF0YSh0aGlzLnN0YXRlLmRhdGEsIG5ld0RhdGEsIHRoaXMub3B0aW9ucyk7XG5cdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0ZGF0YSxcblx0XHRcdHR5cGU6IFwic3VjY2Vzc1wiLFxuXHRcdFx0ZGF0YVVwZGF0ZWRBdDogb3B0aW9ucz8udXBkYXRlZEF0LFxuXHRcdFx0bWFudWFsOiBvcHRpb25zPy5tYW51YWxcblx0XHR9KTtcblx0XHRyZXR1cm4gZGF0YTtcblx0fVxuXHQvKipcblx0KiBNZXJnZXMgdGhlIGdpdmVuIHBhcnRpYWwgc3RhdGUgZGlyZWN0bHkgaW50byB0aGlzIHF1ZXJ5J3Mgc3RhdGUsIG5vdGlmeWluZyBvYnNlcnZlcnMuIFVzZWRcblx0KiBieSBwZXJzaXN0ZW5jZSBhbmQgYnJvYWRjYXN0IHBsdWdpbnMgdG8gcmVzdG9yZSBhIHN0YXRlIHNuYXBzaG90LCBhbmQgYnkgZGV2dG9vbHMgdG8gbGV0IGFcblx0KiB1c2VyIG1hbnVhbGx5IHRyaWdnZXIgYSBsb2FkaW5nL2Vycm9yIHN0YXRlIG9yIGVkaXQgdGhlIGNhY2hlZCBkYXRhLlxuXHQqL1xuXHRzZXRTdGF0ZShzdGF0ZSkge1xuXHRcdHRoaXMuI2Rpc3BhdGNoKHtcblx0XHRcdHR5cGU6IFwic2V0U3RhdGVcIixcblx0XHRcdHN0YXRlXG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogQ2FuY2VscyB0aGUgcXVlcnkncyBjdXJyZW50bHkgaW4tZmxpZ2h0IGZldGNoLCBpZiBhbnkuXG5cdCogLSBSZXR1cm5zIGEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIG9uY2UgdGhlIGNhbmNlbGxhdGlvbiBoYXMgc2V0dGxlZC5cblx0KiAtIElmIG5vIGZldGNoIGlzIGluIHByb2dyZXNzLCByZXNvbHZlcyBpbW1lZGlhdGVseS5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBhd2FpdCBxdWVyeS5jYW5jZWwoKVxuXHQqIGBgYFxuXHQqL1xuXHRjYW5jZWwob3B0aW9ucykge1xuXHRcdGNvbnN0IHByb21pc2UgPSB0aGlzLiNyZXRyeWVyPy5wcm9taXNlO1xuXHRcdHRoaXMuI3JldHJ5ZXI/LmNhbmNlbChvcHRpb25zKTtcblx0XHRyZXR1cm4gcHJvbWlzZSA/IHByb21pc2UudGhlbihub29wKS5jYXRjaChub29wKSA6IFByb21pc2UucmVzb2x2ZSgpO1xuXHR9XG5cdC8qKlxuXHQqIENsZWFycyB0aGUgcXVlcnkncyBnYXJiYWdlIGNvbGxlY3Rpb24gdGltZW91dCBhbmQgc2lsZW50bHkgY2FuY2VscyBhbnlcblx0KiBpbi1mbGlnaHQgZmV0Y2guIENhbGxlZCBieSBgUXVlcnlDYWNoZWAgd2hlbiB0aGUgcXVlcnkgaXMgcmVtb3ZlZCBmcm9tXG5cdCogdGhlIGNhY2hlLlxuXHQqXG5cdCogQHNlZSB7QGxpbmsgUXVlcnkjY2FuY2VsfVxuXHQqL1xuXHRkZXN0cm95KCkge1xuXHRcdHN1cGVyLmRlc3Ryb3koKTtcblx0XHR0aGlzLmNhbmNlbCh7IHNpbGVudDogdHJ1ZSB9KTtcblx0fVxuXHQvKiogQGludGVybmFsICovXG5cdGdldCByZXNldFN0YXRlKCkge1xuXHRcdHJldHVybiB0aGlzLiNpbml0aWFsU3RhdGU7XG5cdH1cblx0LyoqXG5cdCogUmVzZXRzIHRoZSBxdWVyeSBiYWNrIHRvIGl0cyBpbml0aWFsIHN0YXRlICh0aGUgc3RhdGUgaXQgaGFkIHdoZW4gaXQgd2FzXG5cdCogZmlyc3QgY3JlYXRlZCwgZS5nLiBhbnkgYGluaXRpYWxEYXRhYCksIGRlc3Ryb3lpbmcgaXQgZmlyc3QgdG8gY2FuY2VsIGFueVxuXHQqIGluLWZsaWdodCBmZXRjaC5cblx0Ki9cblx0cmVzZXQoKSB7XG5cdFx0dGhpcy5kZXN0cm95KCk7XG5cdFx0dGhpcy5zZXRTdGF0ZSh0aGlzLnJlc2V0U3RhdGUpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBoYXMgYXQgbGVhc3Qgb25lIG9ic2VydmVyIGZvciB3aGljaCBgZW5hYmxlZGBcblx0KiBkb2VzIG5vdCByZXNvbHZlIHRvIGBmYWxzZWAuXG5cdCovXG5cdGlzQWN0aXZlKCkge1xuXHRcdHJldHVybiB0aGlzLm9ic2VydmVycy5zb21lKChvYnNlcnZlcikgPT4gcmVzb2x2ZVF1ZXJ5VmFsdWUob2JzZXJ2ZXIub3B0aW9ucy5lbmFibGVkLCB0aGlzKSAhPT0gZmFsc2UpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBpcyBkaXNhYmxlZCwgbWVhbmluZyBpdCB3aWxsIG5vdCBmZXRjaFxuXHQqIGF1dG9tYXRpY2FsbHkuXG5cdCogLSBJZiB0aGUgcXVlcnkgaGFzIG9ic2VydmVycywgaXQgaXMgZGlzYWJsZWQgd2hlbiBub25lIG9mIHRoZW0gYXJlIGFjdGl2ZVxuXHQqICAgKHNlZSBgaXNBY3RpdmVgKS5cblx0KiAtIElmIHRoZSBxdWVyeSBoYXMgbm8gb2JzZXJ2ZXJzLCBpdCBpcyBkaXNhYmxlZCB3aGVuIGl0cyBgcXVlcnlGbmAgaXNcblx0KiAgIGBza2lwVG9rZW5gIG9yIGl0IGhhcyBuZXZlciBiZWVuIGZldGNoZWQuXG5cdCovXG5cdGlzRGlzYWJsZWQoKSB7XG5cdFx0aWYgKHRoaXMuZ2V0T2JzZXJ2ZXJzQ291bnQoKSA+IDApIHJldHVybiAhdGhpcy5pc0FjdGl2ZSgpO1xuXHRcdHJldHVybiB0aGlzLm9wdGlvbnMucXVlcnlGbiA9PT0gc2tpcFRva2VuIHx8ICF0aGlzLmlzRmV0Y2hlZCgpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBoYXMgYmVlbiBmZXRjaGVkLCBpLmUuIGl0IGhhcyByZXNvbHZlZCB3aXRoXG5cdCogZWl0aGVyIGRhdGEgb3IgYW4gZXJyb3IgYXQgbGVhc3Qgb25jZS5cblx0Ki9cblx0aXNGZXRjaGVkKCkge1xuXHRcdHJldHVybiB0aGlzLnN0YXRlLmRhdGFVcGRhdGVDb3VudCArIHRoaXMuc3RhdGUuZXJyb3JVcGRhdGVDb3VudCA+IDA7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGhhcyBhdCBsZWFzdCBvbmUgb2JzZXJ2ZXIgY29uZmlndXJlZCB3aXRoXG5cdCogYHN0YWxlVGltZTogJ3N0YXRpYydgLCBtZWFuaW5nIGl0IGlzIHRyZWF0ZWQgYXMgbmV2ZXIgc3RhbGUuXG5cdCovXG5cdGlzU3RhdGljKCkge1xuXHRcdGlmICh0aGlzLmdldE9ic2VydmVyc0NvdW50KCkgPiAwKSByZXR1cm4gdGhpcy5vYnNlcnZlcnMuc29tZSgob2JzZXJ2ZXIpID0+IHJlc29sdmVRdWVyeVZhbHVlKG9ic2VydmVyLm9wdGlvbnMuc3RhbGVUaW1lLCB0aGlzKSA9PT0gXCJzdGF0aWNcIik7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBpcyBzdGFsZS5cblx0KiAtIElmIHRoZSBxdWVyeSBoYXMgb2JzZXJ2ZXJzLCBkZWZlcnMgdG8gd2hldGhlciBhbnkgb2JzZXJ2ZXIncyBjdXJyZW50XG5cdCogICByZXN1bHQgcmVwb3J0cyBgaXNTdGFsZWAgKHdoaWNoIGFjY291bnRzIGZvciBlYWNoIG9ic2VydmVyJ3Mgb3duXG5cdCogICBgc3RhbGVUaW1lYCBhbmQgYGVuYWJsZWRgIHN0YXRlKS5cblx0KiAtIElmIHRoZSBxdWVyeSBoYXMgbm8gb2JzZXJ2ZXJzLCBpdCBpcyBjb25zaWRlcmVkIHN0YWxlIHdoZW4gaXQgaGFzIG5vXG5cdCogICBkYXRhIG9yIGhhcyBiZWVuIGludmFsaWRhdGVkLlxuXHQqXG5cdCogQHNlZSB7QGxpbmsgUXVlcnkjaXNTdGFsZUJ5VGltZX1cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaWYgKHF1ZXJ5LmlzU3RhbGUoKSkge1xuXHQqICAgLy8gcmVmZXRjaCBvciBvdGhlcndpc2UgdHJlYXQgdGhlIGNhY2hlZCBkYXRhIGFzIG91dGRhdGVkXG5cdCogfVxuXHQqIGBgYFxuXHQqL1xuXHRpc1N0YWxlKCkge1xuXHRcdGlmICh0aGlzLmdldE9ic2VydmVyc0NvdW50KCkgPiAwKSByZXR1cm4gdGhpcy5vYnNlcnZlcnMuc29tZSgob2JzZXJ2ZXIpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKS5pc1N0YWxlKTtcblx0XHRyZXR1cm4gdGhpcy5zdGF0ZS5kYXRhID09PSB2b2lkIDAgfHwgdGhpcy5zdGF0ZS5pc0ludmFsaWRhdGVkO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSdzIGRhdGEgaXMgc3RhbGUgcmVsYXRpdmUgdG8gdGhlIGdpdmVuXG5cdCogYHN0YWxlVGltZWAgKGRlZmF1bHRzIHRvIGAwYCkuXG5cdCogLSBBIHF1ZXJ5IHdpdGggbm8gZGF0YSBpcyBhbHdheXMgc3RhbGUuXG5cdCogLSBgc3RhbGVUaW1lOiAnc3RhdGljJ2AgaXMgbmV2ZXIgc3RhbGUuXG5cdCogLSBBbiBpbnZhbGlkYXRlZCBxdWVyeSBpcyBhbHdheXMgc3RhbGUuXG5cdCogLSBPdGhlcndpc2UsIHN0YWxlbmVzcyBpcyBiYXNlZCBvbiBlbGFwc2VkIHRpbWUgc2luY2UgYGRhdGFVcGRhdGVkQXRgLlxuXHQqXG5cdCogQHNlZSB7QGxpbmsgUXVlcnkjaXNTdGFsZX1cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgaXNTdGFsZSA9IHF1ZXJ5LmlzU3RhbGVCeVRpbWUoMTAwMCAqIDYwKVxuXHQqIGBgYFxuXHQqL1xuXHRpc1N0YWxlQnlUaW1lKHN0YWxlVGltZSA9IDApIHtcblx0XHRpZiAodGhpcy5zdGF0ZS5kYXRhID09PSB2b2lkIDApIHJldHVybiB0cnVlO1xuXHRcdGlmIChzdGFsZVRpbWUgPT09IFwic3RhdGljXCIpIHJldHVybiBmYWxzZTtcblx0XHRpZiAodGhpcy5zdGF0ZS5pc0ludmFsaWRhdGVkKSByZXR1cm4gdHJ1ZTtcblx0XHRyZXR1cm4gIXRpbWVVbnRpbFN0YWxlKHRoaXMuc3RhdGUuZGF0YVVwZGF0ZWRBdCwgc3RhbGVUaW1lKTtcblx0fVxuXHQvKiogQGludGVybmFsICovXG5cdG9uRm9jdXMoKSB7XG5cdFx0dGhpcy5vYnNlcnZlcnMuZmluZCgoeCkgPT4geC5zaG91bGRGZXRjaE9uV2luZG93Rm9jdXMoKSk/LnJlZmV0Y2goeyBjYW5jZWxSZWZldGNoOiBmYWxzZSB9KTtcblx0XHR0aGlzLiNyZXRyeWVyPy5jb250aW51ZSgpO1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0b25PbmxpbmUoKSB7XG5cdFx0dGhpcy5vYnNlcnZlcnMuZmluZCgoeCkgPT4geC5zaG91bGRGZXRjaE9uUmVjb25uZWN0KCkpPy5yZWZldGNoKHsgY2FuY2VsUmVmZXRjaDogZmFsc2UgfSk7XG5cdFx0dGhpcy4jcmV0cnllcj8uY29udGludWUoKTtcblx0fVxuXHQvKiogQGludGVybmFsICovXG5cdGFkZE9ic2VydmVyKG9ic2VydmVyKSB7XG5cdFx0aWYgKCF0aGlzLm9ic2VydmVycy5pbmNsdWRlcyhvYnNlcnZlcikpIHtcblx0XHRcdHRoaXMub2JzZXJ2ZXJzLnB1c2gob2JzZXJ2ZXIpO1xuXHRcdFx0dGhpcy5jbGVhckdjVGltZW91dCgpO1xuXHRcdFx0dGhpcy4jY2FjaGUubm90aWZ5KHtcblx0XHRcdFx0dHlwZTogXCJvYnNlcnZlckFkZGVkXCIsXG5cdFx0XHRcdHF1ZXJ5OiB0aGlzLFxuXHRcdFx0XHRvYnNlcnZlclxuXHRcdFx0fSk7XG5cdFx0fVxuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0cmVtb3ZlT2JzZXJ2ZXIob2JzZXJ2ZXIpIHtcblx0XHRjb25zdCBpbmRleCA9IHRoaXMub2JzZXJ2ZXJzLmluZGV4T2Yob2JzZXJ2ZXIpO1xuXHRcdGlmIChpbmRleCAhPT0gLTEpIHtcblx0XHRcdHRoaXMub2JzZXJ2ZXJzLnNwbGljZShpbmRleCwgMSk7XG5cdFx0XHRpZiAoIXRoaXMub2JzZXJ2ZXJzLmxlbmd0aCkge1xuXHRcdFx0XHRpZiAodGhpcy4jcmV0cnllcikge1xuXHRcdFx0XHRcdGlmICh0aGlzLiNhYm9ydFNpZ25hbENvbnN1bWVkIHx8IHRoaXMuc3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwicGF1c2VkXCIgJiYgdGhpcy5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiKSB0aGlzLiNyZXRyeWVyLmNhbmNlbCh7IHJldmVydDogdHJ1ZSB9KTtcblx0XHRcdFx0XHRlbHNlIHRoaXMuI3JldHJ5ZXIuY2FuY2VsUmV0cnkoKTtcblx0XHRcdFx0fVxuXHRcdFx0XHR0aGlzLnNjaGVkdWxlR2MoKTtcblx0XHRcdH1cblx0XHRcdHRoaXMuI2NhY2hlLm5vdGlmeSh7XG5cdFx0XHRcdHR5cGU6IFwib2JzZXJ2ZXJSZW1vdmVkXCIsXG5cdFx0XHRcdHF1ZXJ5OiB0aGlzLFxuXHRcdFx0XHRvYnNlcnZlclxuXHRcdFx0fSk7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIG51bWJlciBvZiBvYnNlcnZlcnMgY3VycmVudGx5IHN1YnNjcmliZWQgdG8gdGhpcyBxdWVyeS5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpZiAocXVlcnkuZ2V0T2JzZXJ2ZXJzQ291bnQoKSA9PT0gMCkge1xuXHQqICAgLy8gbm8gY29tcG9uZW50IGlzIGN1cnJlbnRseSB3YXRjaGluZyB0aGlzIHF1ZXJ5XG5cdCogfVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRPYnNlcnZlcnNDb3VudCgpIHtcblx0XHRyZXR1cm4gdGhpcy5vYnNlcnZlcnMubGVuZ3RoO1xuXHR9XG5cdC8qKlxuXHQqIE1hcmtzIHRoZSBxdWVyeSBhcyBpbnZhbGlkYXRlZCwgdW5sZXNzIGl0IGlzIGFscmVhZHkgaW52YWxpZGF0ZWQuIFRoaXNcblx0KiB1cGRhdGVzIGBzdGF0ZS5pc0ludmFsaWRhdGVkYCBhbmQgbm90aWZpZXMgb2JzZXJ2ZXJzLCBidXQgZG9lcyBub3QgYnlcblx0KiBpdHNlbGYgdHJpZ2dlciBhIHJlZmV0Y2guXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogcXVlcnkuaW52YWxpZGF0ZSgpXG5cdCogYGBgXG5cdCovXG5cdGludmFsaWRhdGUoKSB7XG5cdFx0aWYgKCF0aGlzLnN0YXRlLmlzSW52YWxpZGF0ZWQpIHRoaXMuI2Rpc3BhdGNoKHsgdHlwZTogXCJpbnZhbGlkYXRlXCIgfSk7XG5cdH1cblx0LyoqXG5cdCogRmV0Y2hlcyB0aGUgcXVlcnksIGkuZS4gcnVucyBpdHMgYHF1ZXJ5Rm5gICh0aHJvdWdoIGFueSBjb25maWd1cmVkXG5cdCogcmV0cnllci9iZWhhdmlvcikgYW5kIHVwZGF0ZXMgdGhlIHF1ZXJ5J3Mgc3RhdGUgd2l0aCB0aGUgcmVzdWx0LlxuXHQqIC0gSWYgYSBmZXRjaCBpcyBhbHJlYWR5IGluIGZsaWdodCwgcmV0dXJucyBpdHMgcHJvbWlzZSBpbnN0ZWFkIG9mXG5cdCogICBzdGFydGluZyBhIG5ldyBvbmUsIHVubGVzcyBgZmV0Y2hPcHRpb25zLmNhbmNlbFJlZmV0Y2hgIGlzIHNldCBhbmQgdGhlXG5cdCogICBxdWVyeSBhbHJlYWR5IGhhcyBkYXRhLCBpbiB3aGljaCBjYXNlIHRoZSBjdXJyZW50IGZldGNoIGlzIHNpbGVudGx5XG5cdCogICBjYW5jZWxsZWQgZmlyc3QuXG5cdCogLSBJZiBgb3B0aW9uc2AgaXMgcGFzc2VkLCBpdCByZXBsYWNlcyB0aGUgcXVlcnkncyBjdXJyZW50IG9wdGlvbnNcblx0KiAgIGJlZm9yZSBmZXRjaGluZy5cblx0Ki9cblx0YXN5bmMgZmV0Y2gob3B0aW9ucywgZmV0Y2hPcHRpb25zKSB7XG5cdFx0aWYgKHRoaXMuc3RhdGUuZmV0Y2hTdGF0dXMgIT09IFwiaWRsZVwiICYmIHRoaXMuI3JldHJ5ZXI/LnN0YXR1cygpICE9PSBcInJlamVjdGVkXCIpIHtcblx0XHRcdGlmICh0aGlzLnN0YXRlLmRhdGEgIT09IHZvaWQgMCAmJiBmZXRjaE9wdGlvbnM/LmNhbmNlbFJlZmV0Y2gpIHRoaXMuY2FuY2VsKHsgc2lsZW50OiB0cnVlIH0pO1xuXHRcdFx0ZWxzZSBpZiAodGhpcy4jcmV0cnllcikge1xuXHRcdFx0XHR0aGlzLiNyZXRyeWVyLmNvbnRpbnVlUmV0cnkoKTtcblx0XHRcdFx0cmV0dXJuIHRoaXMuI3JldHJ5ZXIucHJvbWlzZTtcblx0XHRcdH1cblx0XHR9XG5cdFx0aWYgKG9wdGlvbnMpIHRoaXMuc2V0T3B0aW9ucyhvcHRpb25zKTtcblx0XHRpZiAoIXRoaXMub3B0aW9ucy5xdWVyeUZuKSB7XG5cdFx0XHRjb25zdCBvYnNlcnZlciA9IHRoaXMub2JzZXJ2ZXJzLmZpbmQoKHgpID0+IHgub3B0aW9ucy5xdWVyeUZuKTtcblx0XHRcdGlmIChvYnNlcnZlcikgdGhpcy5zZXRPcHRpb25zKG9ic2VydmVyLm9wdGlvbnMpO1xuXHRcdH1cblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0XHRpZiAoIUFycmF5LmlzQXJyYXkodGhpcy5vcHRpb25zLnF1ZXJ5S2V5KSkgY29uc29sZS5lcnJvcihgQXMgb2YgdjQsIHF1ZXJ5S2V5IG5lZWRzIHRvIGJlIGFuIEFycmF5LiBJZiB5b3UgYXJlIHVzaW5nIGEgc3RyaW5nIGxpa2UgJ3JlcG9EYXRhJywgcGxlYXNlIGNoYW5nZSBpdCB0byBhbiBBcnJheSwgZS5nLiBbJ3JlcG9EYXRhJ11gKTtcblx0XHR9XG5cdFx0Y29uc3QgYWJvcnRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuXHRcdGNvbnN0IGFkZFNpZ25hbFByb3BlcnR5ID0gKG9iamVjdCkgPT4ge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG9iamVjdCwgXCJzaWduYWxcIiwge1xuXHRcdFx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuXHRcdFx0XHRnZXQ6ICgpID0+IHtcblx0XHRcdFx0XHR0aGlzLiNhYm9ydFNpZ25hbENvbnN1bWVkID0gdHJ1ZTtcblx0XHRcdFx0XHRyZXR1cm4gYWJvcnRDb250cm9sbGVyLnNpZ25hbDtcblx0XHRcdFx0fVxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHRjb25zdCBmZXRjaEZuID0gKCkgPT4ge1xuXHRcdFx0Y29uc3QgcXVlcnlGbiA9IGVuc3VyZVF1ZXJ5Rm4odGhpcy5vcHRpb25zLCBmZXRjaE9wdGlvbnMpO1xuXHRcdFx0Y29uc3QgY3JlYXRlUXVlcnlGbkNvbnRleHQgPSAoKSA9PiB7XG5cdFx0XHRcdGNvbnN0IHF1ZXJ5Rm5Db250ZXh0ID0ge1xuXHRcdFx0XHRcdGNsaWVudDogdGhpcy4jY2xpZW50LFxuXHRcdFx0XHRcdHF1ZXJ5S2V5OiB0aGlzLnF1ZXJ5S2V5LFxuXHRcdFx0XHRcdG1ldGE6IHRoaXMubWV0YVxuXHRcdFx0XHR9O1xuXHRcdFx0XHRhZGRTaWduYWxQcm9wZXJ0eShxdWVyeUZuQ29udGV4dCk7XG5cdFx0XHRcdHJldHVybiBxdWVyeUZuQ29udGV4dDtcblx0XHRcdH07XG5cdFx0XHRjb25zdCBxdWVyeUZuQ29udGV4dCA9IGNyZWF0ZVF1ZXJ5Rm5Db250ZXh0KCk7XG5cdFx0XHR0aGlzLiNhYm9ydFNpZ25hbENvbnN1bWVkID0gZmFsc2U7XG5cdFx0XHRpZiAodGhpcy5vcHRpb25zLnBlcnNpc3RlcikgcmV0dXJuIHRoaXMub3B0aW9ucy5wZXJzaXN0ZXIocXVlcnlGbiwgcXVlcnlGbkNvbnRleHQsIHRoaXMpO1xuXHRcdFx0cmV0dXJuIHF1ZXJ5Rm4ocXVlcnlGbkNvbnRleHQpO1xuXHRcdH07XG5cdFx0Y29uc3QgY3JlYXRlRmV0Y2hDb250ZXh0ID0gKCkgPT4ge1xuXHRcdFx0Y29uc3QgY29udGV4dCA9IHtcblx0XHRcdFx0ZmV0Y2hPcHRpb25zLFxuXHRcdFx0XHRvcHRpb25zOiB0aGlzLm9wdGlvbnMsXG5cdFx0XHRcdHF1ZXJ5S2V5OiB0aGlzLnF1ZXJ5S2V5LFxuXHRcdFx0XHRjbGllbnQ6IHRoaXMuI2NsaWVudCxcblx0XHRcdFx0c3RhdGU6IHRoaXMuc3RhdGUsXG5cdFx0XHRcdGZldGNoRm5cblx0XHRcdH07XG5cdFx0XHRhZGRTaWduYWxQcm9wZXJ0eShjb250ZXh0KTtcblx0XHRcdHJldHVybiBjb250ZXh0O1xuXHRcdH07XG5cdFx0Y29uc3QgY29udGV4dCA9IGNyZWF0ZUZldGNoQ29udGV4dCgpO1xuXHRcdCh0aGlzLiNxdWVyeVR5cGUgPT09IFwiaW5maW5pdGVcIiA/IGluZmluaXRlUXVlcnlCZWhhdmlvcih0aGlzLm9wdGlvbnMucGFnZXMpIDogdGhpcy5vcHRpb25zLmJlaGF2aW9yKT8ub25GZXRjaChjb250ZXh0LCB0aGlzKTtcblx0XHR0aGlzLiNyZXZlcnRTdGF0ZSA9IHRoaXMuc3RhdGU7XG5cdFx0aWYgKHRoaXMuc3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwiaWRsZVwiIHx8IHRoaXMuc3RhdGUuZmV0Y2hNZXRhICE9PSBjb250ZXh0LmZldGNoT3B0aW9ucz8ubWV0YSkgdGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0dHlwZTogXCJmZXRjaFwiLFxuXHRcdFx0bWV0YTogY29udGV4dC5mZXRjaE9wdGlvbnM/Lm1ldGFcblx0XHR9KTtcblx0XHRjb25zdCByZXRyeWVyID0gdGhpcy4jcmV0cnllciA9IGNyZWF0ZVJldHJ5ZXIoe1xuXHRcdFx0aW5pdGlhbFByb21pc2U6IGZldGNoT3B0aW9ucz8uaW5pdGlhbFByb21pc2UsXG5cdFx0XHRmbjogY29udGV4dC5mZXRjaEZuLFxuXHRcdFx0b25DYW5jZWw6IChlcnJvcikgPT4ge1xuXHRcdFx0XHRpZiAoZXJyb3IgaW5zdGFuY2VvZiBDYW5jZWxsZWRFcnJvciAmJiBlcnJvci5yZXZlcnQpIHRoaXMuc2V0U3RhdGUoe1xuXHRcdFx0XHRcdC4uLnRoaXMuI3JldmVydFN0YXRlLFxuXHRcdFx0XHRcdGZldGNoU3RhdHVzOiBcImlkbGVcIlxuXHRcdFx0XHR9KTtcblx0XHRcdFx0YWJvcnRDb250cm9sbGVyLmFib3J0KCk7XG5cdFx0XHR9LFxuXHRcdFx0b25GYWlsOiAoZmFpbHVyZUNvdW50LCBlcnJvcikgPT4ge1xuXHRcdFx0XHR0aGlzLiNkaXNwYXRjaCh7XG5cdFx0XHRcdFx0dHlwZTogXCJmYWlsZWRcIixcblx0XHRcdFx0XHRmYWlsdXJlQ291bnQsXG5cdFx0XHRcdFx0ZXJyb3Jcblx0XHRcdFx0fSk7XG5cdFx0XHR9LFxuXHRcdFx0b25QYXVzZTogKCkgPT4ge1xuXHRcdFx0XHR0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwicGF1c2VcIiB9KTtcblx0XHRcdH0sXG5cdFx0XHRvbkNvbnRpbnVlOiAoKSA9PiB7XG5cdFx0XHRcdHRoaXMuI2Rpc3BhdGNoKHsgdHlwZTogXCJjb250aW51ZVwiIH0pO1xuXHRcdFx0fSxcblx0XHRcdHJldHJ5OiBjb250ZXh0Lm9wdGlvbnMucmV0cnksXG5cdFx0XHRyZXRyeURlbGF5OiBjb250ZXh0Lm9wdGlvbnMucmV0cnlEZWxheSxcblx0XHRcdG5ldHdvcmtNb2RlOiBjb250ZXh0Lm9wdGlvbnMubmV0d29ya01vZGUsXG5cdFx0XHRjYW5SdW46ICgpID0+IHRydWVcblx0XHR9KTtcblx0XHR0cnkge1xuXHRcdFx0Y29uc3QgZGF0YSA9IGF3YWl0IHJldHJ5ZXIuc3RhcnQoKTtcblx0XHRcdGlmIChkYXRhID09PSB2b2lkIDApIHtcblx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgY29uc29sZS5lcnJvcihgUXVlcnkgZGF0YSBjYW5ub3QgYmUgdW5kZWZpbmVkLiBQbGVhc2UgbWFrZSBzdXJlIHRvIHJldHVybiBhIHZhbHVlIG90aGVyIHRoYW4gdW5kZWZpbmVkIGZyb20geW91ciBxdWVyeSBmdW5jdGlvbi4gQWZmZWN0ZWQgcXVlcnkga2V5OiAke3RoaXMucXVlcnlIYXNofWApO1xuXHRcdFx0XHR0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5xdWVyeUhhc2h9IGRhdGEgaXMgdW5kZWZpbmVkYCk7XG5cdFx0XHR9XG5cdFx0XHR0aGlzLnNldERhdGEoZGF0YSk7XG5cdFx0XHR0aGlzLiNjYWNoZS5jb25maWcub25TdWNjZXNzPy4oZGF0YSwgdGhpcyk7XG5cdFx0XHR0aGlzLiNjYWNoZS5jb25maWcub25TZXR0bGVkPy4oZGF0YSwgdGhpcy5zdGF0ZS5lcnJvciwgdGhpcyk7XG5cdFx0XHRyZXR1cm4gZGF0YTtcblx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0aWYgKGVycm9yIGluc3RhbmNlb2YgQ2FuY2VsbGVkRXJyb3IpIHtcblx0XHRcdFx0aWYgKGVycm9yLnNpbGVudCkgcmV0dXJuIHRoaXMuI3JldHJ5ZXIucHJvbWlzZTtcblx0XHRcdFx0ZWxzZSBpZiAoZXJyb3IucmV2ZXJ0KSB7XG5cdFx0XHRcdFx0aWYgKHRoaXMuc3RhdGUuZGF0YSA9PT0gdm9pZCAwKSB0aHJvdyBlcnJvcjtcblx0XHRcdFx0XHRyZXR1cm4gdGhpcy5zdGF0ZS5kYXRhO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHR0aGlzLiNkaXNwYXRjaCh7XG5cdFx0XHRcdHR5cGU6IFwiZXJyb3JcIixcblx0XHRcdFx0ZXJyb3Jcblx0XHRcdH0pO1xuXHRcdFx0dGhpcy4jY2FjaGUuY29uZmlnLm9uRXJyb3I/LihlcnJvciwgdGhpcyk7XG5cdFx0XHR0aGlzLiNjYWNoZS5jb25maWcub25TZXR0bGVkPy4odGhpcy5zdGF0ZS5kYXRhLCBlcnJvciwgdGhpcyk7XG5cdFx0XHR0aHJvdyBlcnJvcjtcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0aWYgKHRoaXMuI3JldHJ5ZXIgPT09IHJldHJ5ZXIpIHRoaXMuI3JldHJ5ZXIgPSB2b2lkIDA7XG5cdFx0XHR0aGlzLnNjaGVkdWxlR2MoKTtcblx0XHR9XG5cdH1cblx0I2Rpc3BhdGNoKGFjdGlvbikge1xuXHRcdGNvbnN0IHJlZHVjZXIgPSAoc3RhdGUpID0+IHtcblx0XHRcdHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcblx0XHRcdFx0Y2FzZSBcImZhaWxlZFwiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdGZldGNoRmFpbHVyZUNvdW50OiBhY3Rpb24uZmFpbHVyZUNvdW50LFxuXHRcdFx0XHRcdGZldGNoRmFpbHVyZVJlYXNvbjogYWN0aW9uLmVycm9yXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJwYXVzZVwiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdGZldGNoU3RhdHVzOiBcInBhdXNlZFwiXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJjb250aW51ZVwiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdGZldGNoU3RhdHVzOiBcImZldGNoaW5nXCJcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcImZldGNoXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0Li4uZmV0Y2hTdGF0ZShzdGF0ZS5kYXRhLCB0aGlzLm9wdGlvbnMpLFxuXHRcdFx0XHRcdGZldGNoTWV0YTogYWN0aW9uLm1ldGEgPz8gbnVsbFxuXHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlIFwic3VjY2Vzc1wiOlxuXHRcdFx0XHRcdGNvbnN0IG5ld1N0YXRlID0ge1xuXHRcdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0XHQuLi5zdWNjZXNzU3RhdGUoYWN0aW9uLmRhdGEsIGFjdGlvbi5kYXRhVXBkYXRlZEF0KSxcblx0XHRcdFx0XHRcdGRhdGFVcGRhdGVDb3VudDogc3RhdGUuZGF0YVVwZGF0ZUNvdW50ICsgMSxcblx0XHRcdFx0XHRcdC4uLiFhY3Rpb24ubWFudWFsICYmIHtcblx0XHRcdFx0XHRcdFx0ZmV0Y2hTdGF0dXM6IFwiaWRsZVwiLFxuXHRcdFx0XHRcdFx0XHRmZXRjaEZhaWx1cmVDb3VudDogMCxcblx0XHRcdFx0XHRcdFx0ZmV0Y2hGYWlsdXJlUmVhc29uOiBudWxsXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0XHR0aGlzLiNyZXZlcnRTdGF0ZSA9IGFjdGlvbi5tYW51YWwgPyBuZXdTdGF0ZSA6IHZvaWQgMDtcblx0XHRcdFx0XHRyZXR1cm4gbmV3U3RhdGU7XG5cdFx0XHRcdGNhc2UgXCJlcnJvclwiOlxuXHRcdFx0XHRcdGNvbnN0IGVycm9yID0gYWN0aW9uLmVycm9yO1xuXHRcdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHRcdGVycm9yLFxuXHRcdFx0XHRcdFx0ZXJyb3JVcGRhdGVDb3VudDogc3RhdGUuZXJyb3JVcGRhdGVDb3VudCArIDEsXG5cdFx0XHRcdFx0XHRlcnJvclVwZGF0ZWRBdDogRGF0ZS5ub3coKSxcblx0XHRcdFx0XHRcdGZldGNoRmFpbHVyZUNvdW50OiBzdGF0ZS5mZXRjaEZhaWx1cmVDb3VudCArIDEsXG5cdFx0XHRcdFx0XHRmZXRjaEZhaWx1cmVSZWFzb246IGVycm9yLFxuXHRcdFx0XHRcdFx0ZmV0Y2hTdGF0dXM6IFwiaWRsZVwiLFxuXHRcdFx0XHRcdFx0c3RhdHVzOiBcImVycm9yXCIsXG5cdFx0XHRcdFx0XHRpc0ludmFsaWRhdGVkOiB0cnVlXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcImludmFsaWRhdGVcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHRpc0ludmFsaWRhdGVkOiB0cnVlXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJzZXRTdGF0ZVwiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdC4uLmFjdGlvbi5zdGF0ZVxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdH07XG5cdFx0dGhpcy5zdGF0ZSA9IHJlZHVjZXIodGhpcy5zdGF0ZSk7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHR0aGlzLm9ic2VydmVycy5zbGljZSgpLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG5cdFx0XHRcdG9ic2VydmVyLm9uUXVlcnlVcGRhdGUoKTtcblx0XHRcdH0pO1xuXHRcdFx0dGhpcy4jY2FjaGUubm90aWZ5KHtcblx0XHRcdFx0cXVlcnk6IHRoaXMsXG5cdFx0XHRcdHR5cGU6IFwidXBkYXRlZFwiLFxuXHRcdFx0XHRhY3Rpb25cblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG59O1xuZnVuY3Rpb24gZmV0Y2hTdGF0ZShkYXRhLCBvcHRpb25zKSB7XG5cdHJldHVybiB7XG5cdFx0ZmV0Y2hGYWlsdXJlQ291bnQ6IDAsXG5cdFx0ZmV0Y2hGYWlsdXJlUmVhc29uOiBudWxsLFxuXHRcdGZldGNoU3RhdHVzOiBjYW5GZXRjaChvcHRpb25zLm5ldHdvcmtNb2RlKSA/IFwiZmV0Y2hpbmdcIiA6IFwicGF1c2VkXCIsXG5cdFx0Li4uZGF0YSA9PT0gdm9pZCAwICYmIHtcblx0XHRcdGVycm9yOiBudWxsLFxuXHRcdFx0c3RhdHVzOiBcInBlbmRpbmdcIlxuXHRcdH1cblx0fTtcbn1cbmZ1bmN0aW9uIHN1Y2Nlc3NTdGF0ZShkYXRhLCBkYXRhVXBkYXRlZEF0KSB7XG5cdHJldHVybiB7XG5cdFx0ZGF0YSxcblx0XHRkYXRhVXBkYXRlZEF0OiBkYXRhVXBkYXRlZEF0ID8/IERhdGUubm93KCksXG5cdFx0ZXJyb3I6IG51bGwsXG5cdFx0aXNJbnZhbGlkYXRlZDogZmFsc2UsXG5cdFx0c3RhdHVzOiBcInN1Y2Nlc3NcIlxuXHR9O1xufVxuZnVuY3Rpb24gZ2V0RGVmYXVsdFN0YXRlKG9wdGlvbnMpIHtcblx0Y29uc3QgZGF0YSA9IHR5cGVvZiBvcHRpb25zLmluaXRpYWxEYXRhID09PSBcImZ1bmN0aW9uXCIgPyBvcHRpb25zLmluaXRpYWxEYXRhKCkgOiBvcHRpb25zLmluaXRpYWxEYXRhO1xuXHRjb25zdCBoYXNEYXRhID0gZGF0YSAhPT0gdm9pZCAwO1xuXHRjb25zdCBpbml0aWFsRGF0YVVwZGF0ZWRBdCA9IGhhc0RhdGEgPyB0eXBlb2Ygb3B0aW9ucy5pbml0aWFsRGF0YVVwZGF0ZWRBdCA9PT0gXCJmdW5jdGlvblwiID8gb3B0aW9ucy5pbml0aWFsRGF0YVVwZGF0ZWRBdCgpIDogb3B0aW9ucy5pbml0aWFsRGF0YVVwZGF0ZWRBdCA6IDA7XG5cdHJldHVybiB7XG5cdFx0ZGF0YSxcblx0XHRkYXRhVXBkYXRlQ291bnQ6IDAsXG5cdFx0ZGF0YVVwZGF0ZWRBdDogaGFzRGF0YSA/IGluaXRpYWxEYXRhVXBkYXRlZEF0ID8/IERhdGUubm93KCkgOiAwLFxuXHRcdGVycm9yOiBudWxsLFxuXHRcdGVycm9yVXBkYXRlQ291bnQ6IDAsXG5cdFx0ZXJyb3JVcGRhdGVkQXQ6IDAsXG5cdFx0ZmV0Y2hGYWlsdXJlQ291bnQ6IDAsXG5cdFx0ZmV0Y2hGYWlsdXJlUmVhc29uOiBudWxsLFxuXHRcdGZldGNoTWV0YTogbnVsbCxcblx0XHRpc0ludmFsaWRhdGVkOiBmYWxzZSxcblx0XHRzdGF0dXM6IGhhc0RhdGEgPyBcInN1Y2Nlc3NcIiA6IFwicGVuZGluZ1wiLFxuXHRcdGZldGNoU3RhdHVzOiBcImlkbGVcIlxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBRdWVyeSwgZmV0Y2hTdGF0ZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1xdWVyeS5qcy5tYXAiLCJpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gXCIuL3RpbWVvdXRNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBpc1ZhbGlkVGltZW91dCwgbm9vcCwgcmVwbGFjZURhdGEsIHJlc29sdmVRdWVyeVZhbHVlLCBzaGFsbG93RXF1YWxPYmplY3RzLCB0aW1lVW50aWxTdGFsZSB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCIuL2Vudmlyb25tZW50TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG5pbXBvcnQgeyBmb2N1c01hbmFnZXIgfSBmcm9tIFwiLi9mb2N1c01hbmFnZXIuanNcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBmZXRjaFN0YXRlIH0gZnJvbSBcIi4vcXVlcnkuanNcIjtcbi8vI3JlZ2lvbiBzcmMvcXVlcnlPYnNlcnZlci50c1xuLyoqXG4qIEEgYFF1ZXJ5T2JzZXJ2ZXJgIHdhdGNoZXMgYSBzaW5nbGUgcXVlcnkgaW4gdGhlIGBRdWVyeUNhY2hlYCBhbmQgY29tcHV0ZXMgYVxuKiBgUXVlcnlPYnNlcnZlclJlc3VsdGAgZnJvbSBpdHMgc3RhdGUsIHJlY29tcHV0aW5nIGFuZCBub3RpZnlpbmcgc3Vic2NyaWJlcnNcbiogd2hlbmV2ZXIgdGhlIHVuZGVybHlpbmcgcXVlcnkgKG9yIHRoZSBvYnNlcnZlcidzIG9wdGlvbnMpIGNoYW5nZXMuIEl0IGlzXG4qIHRoZSBwcmltaXRpdmUgdGhhdCBmcmFtZXdvcmsgYWRhcHRlcnMgKGUuZy4gYHVzZVF1ZXJ5YCkgYnVpbGQgdGhlaXIgaG9va3Ncbiogb24gdG9wIG9mLCBidXQgaXQgY2FuIGFsc28gYmUgdXNlZCBkaXJlY3RseSB0byBvYnNlcnZlIGFuZCBzd2l0Y2ggYmV0d2VlblxuKiBxdWVyaWVzIG91dHNpZGUgb2YgYW55IGZyYW1ld29yay5cbipcbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgUXVlcnlPYnNlcnZlcihxdWVyeUNsaWVudCwge1xuKiAgIHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10sXG4qICAgcXVlcnlGbjogZmV0Y2hQb3N0cyxcbiogfSlcbipcbiogY29uc3QgdW5zdWJzY3JpYmUgPSBvYnNlcnZlci5zdWJzY3JpYmUoKHJlc3VsdCkgPT4ge1xuKiAgIGNvbnNvbGUubG9nKHJlc3VsdC5kYXRhKVxuKiB9KVxuKiBgYGBcbiovXG52YXIgUXVlcnlPYnNlcnZlciA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcblx0I2NsaWVudDtcblx0I2N1cnJlbnRRdWVyeSA9IHZvaWQgMDtcblx0I2N1cnJlbnRRdWVyeUluaXRpYWxTdGF0ZSA9IHZvaWQgMDtcblx0I2N1cnJlbnRSZXN1bHQgPSB2b2lkIDA7XG5cdCNjdXJyZW50UmVzdWx0U3RhdGU7XG5cdCNjdXJyZW50UmVzdWx0T3B0aW9ucztcblx0I3NlbGVjdEVycm9yO1xuXHQjc2VsZWN0Rm47XG5cdCNzZWxlY3RSZXN1bHQ7XG5cdCNsYXN0UXVlcnlXaXRoRGVmaW5lZERhdGE7XG5cdCNzdGFsZVRpbWVvdXRJZDtcblx0I3JlZmV0Y2hJbnRlcnZhbElkO1xuXHQjY3VycmVudFJlZmV0Y2hJbnRlcnZhbDtcblx0I3RyYWNrZWRQcm9wcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdGNvbnN0cnVjdG9yKGNsaWVudCwgb3B0aW9ucykge1xuXHRcdHN1cGVyKCk7XG5cdFx0dGhpcy5vcHRpb25zID0gb3B0aW9ucztcblx0XHR0aGlzLiNjbGllbnQgPSBjbGllbnQ7XG5cdFx0dGhpcy4jc2VsZWN0RXJyb3IgPSBudWxsO1xuXHRcdHRoaXMuYmluZE1ldGhvZHMoKTtcblx0XHR0aGlzLnNldE9wdGlvbnMob3B0aW9ucyk7XG5cdH1cblx0YmluZE1ldGhvZHMoKSB7XG5cdFx0dGhpcy5yZWZldGNoID0gdGhpcy5yZWZldGNoLmJpbmQodGhpcyk7XG5cdH1cblx0b25TdWJzY3JpYmUoKSB7XG5cdFx0aWYgKHRoaXMubGlzdGVuZXJzLnNpemUgPT09IDEpIHtcblx0XHRcdHRoaXMuI2N1cnJlbnRRdWVyeS5hZGRPYnNlcnZlcih0aGlzKTtcblx0XHRcdGlmIChzaG91bGRGZXRjaE9uTW91bnQodGhpcy4jY3VycmVudFF1ZXJ5LCB0aGlzLm9wdGlvbnMpKSB0aGlzLiNleGVjdXRlRmV0Y2goKTtcblx0XHRcdGVsc2UgdGhpcy51cGRhdGVSZXN1bHQoKTtcblx0XHRcdHRoaXMuI3VwZGF0ZVRpbWVycygpO1xuXHRcdH1cblx0fVxuXHRvblVuc3Vic2NyaWJlKCkge1xuXHRcdGlmICghdGhpcy5oYXNMaXN0ZW5lcnMoKSkgdGhpcy5kZXN0cm95KCk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB3aGV0aGVyIHRoZSBvYnNlcnZlZCBxdWVyeSBpcyBjdXJyZW50bHkgc3RhbGUgYW5kIGNvbmZpZ3VyZWRcblx0KiAodmlhIHRoZSBgcmVmZXRjaE9uUmVjb25uZWN0YCBvcHRpb24pIHRvIHJlZmV0Y2ggd2hlbiB0aGUgbmV0d29ya1xuXHQqIHJlY29ubmVjdHMuXG5cdCovXG5cdHNob3VsZEZldGNoT25SZWNvbm5lY3QoKSB7XG5cdFx0cmV0dXJuIHNob3VsZEZldGNoT24odGhpcy4jY3VycmVudFF1ZXJ5LCB0aGlzLm9wdGlvbnMsIHRoaXMub3B0aW9ucy5yZWZldGNoT25SZWNvbm5lY3QpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgd2hldGhlciB0aGUgb2JzZXJ2ZWQgcXVlcnkgaXMgY3VycmVudGx5IHN0YWxlIGFuZCBjb25maWd1cmVkXG5cdCogKHZpYSB0aGUgYHJlZmV0Y2hPbldpbmRvd0ZvY3VzYCBvcHRpb24pIHRvIHJlZmV0Y2ggd2hlbiB0aGUgd2luZG93XG5cdCogcmVnYWlucyBmb2N1cy5cblx0Ki9cblx0c2hvdWxkRmV0Y2hPbldpbmRvd0ZvY3VzKCkge1xuXHRcdHJldHVybiBzaG91bGRGZXRjaE9uKHRoaXMuI2N1cnJlbnRRdWVyeSwgdGhpcy5vcHRpb25zLCB0aGlzLm9wdGlvbnMucmVmZXRjaE9uV2luZG93Rm9jdXMpO1xuXHR9XG5cdC8qKlxuXHQqIFN0b3BzIG9ic2VydmluZyB0aGUgY3VycmVudCBxdWVyeTogY2xlYXJzIGFsbCBsaXN0ZW5lcnMsIGNhbmNlbHMgdGhlXG5cdCogc3RhbGUgYW5kIHJlZmV0Y2gtaW50ZXJ2YWwgdGltZXJzLCBhbmQgcmVtb3ZlcyB0aGlzIG9ic2VydmVyIGZyb20gdGhlXG5cdCogcXVlcnkgaXQgd2FzIG9ic2VydmluZy5cblx0Ki9cblx0ZGVzdHJveSgpIHtcblx0XHR0aGlzLmxpc3RlbmVycyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdFx0dGhpcy4jY2xlYXJTdGFsZVRpbWVvdXQoKTtcblx0XHR0aGlzLiNjbGVhclJlZmV0Y2hJbnRlcnZhbCgpO1xuXHRcdHRoaXMuI2N1cnJlbnRRdWVyeS5yZW1vdmVPYnNlcnZlcih0aGlzKTtcblx0fVxuXHQvKipcblx0KiBVcGRhdGVzIHRoZSBvYnNlcnZlcidzIG9wdGlvbnMuIFRoaXMgd2lsbCByZS1yZXNvbHZlIHRoZSBxdWVyeSBiZWluZ1xuXHQqIG9ic2VydmVkIChzd2l0Y2hpbmcgdG8gYSBkaWZmZXJlbnQgcXVlcnkgaWYgdGhlIGBxdWVyeUtleWAgY2hhbmdlZCksXG5cdCogdHJpZ2dlciBhIGZldGNoIGlmIHRoZSBuZXcgb3B0aW9ucyByZXF1aXJlIG9uZSBhbmQgdGhlIG9ic2VydmVyIGhhc1xuXHQqIHN1YnNjcmliZXJzLCByZWNvbXB1dGUgdGhlIGN1cnJlbnQgcmVzdWx0LCBhbmQgcmVzY2hlZHVsZSB0aGUgc3RhbGUgYW5kXG5cdCogcmVmZXRjaC1pbnRlcnZhbCB0aW1lcnMgYXMgbmVlZGVkLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIG9ic2VydmVyLnNldE9wdGlvbnMoeyBxdWVyeUtleTogWydwb3N0cycsIDFdLCBxdWVyeUZuOiAoKSA9PiBmZXRjaFBvc3QoMSkgfSlcblx0KiAvLyBsYXRlcjogc3dpdGNoIHRvIGEgZGlmZmVyZW50IHF1ZXJ5LCByZXVzaW5nIHRoZSBzYW1lIG9ic2VydmVyXG5cdCogb2JzZXJ2ZXIuc2V0T3B0aW9ucyh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJywgMl0sIHF1ZXJ5Rm46ICgpID0+IGZldGNoUG9zdCgyKSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRPcHRpb25zKG9wdGlvbnMpIHtcblx0XHRjb25zdCBwcmV2T3B0aW9ucyA9IHRoaXMub3B0aW9ucztcblx0XHRjb25zdCBwcmV2UXVlcnkgPSB0aGlzLiNjdXJyZW50UXVlcnk7XG5cdFx0dGhpcy5vcHRpb25zID0gdGhpcy4jY2xpZW50LmRlZmF1bHRRdWVyeU9wdGlvbnMob3B0aW9ucyk7XG5cdFx0aWYgKHRoaXMub3B0aW9ucy5lbmFibGVkICE9PSB2b2lkIDAgJiYgdHlwZW9mIHRoaXMub3B0aW9ucy5lbmFibGVkICE9PSBcImJvb2xlYW5cIiAmJiB0eXBlb2YgdGhpcy5vcHRpb25zLmVuYWJsZWQgIT09IFwiZnVuY3Rpb25cIiAmJiB0eXBlb2YgcmVzb2x2ZVF1ZXJ5VmFsdWUodGhpcy5vcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgIT09IFwiYm9vbGVhblwiKSB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBlbmFibGVkIHRvIGJlIGEgYm9vbGVhbiBvciBhIGNhbGxiYWNrIHRoYXQgcmV0dXJucyBhIGJvb2xlYW5cIik7XG5cdFx0dGhpcy4jdXBkYXRlUXVlcnkoKTtcblx0XHR0aGlzLiNjdXJyZW50UXVlcnkuc2V0T3B0aW9ucyh0aGlzLm9wdGlvbnMpO1xuXHRcdGlmIChwcmV2T3B0aW9ucy5fZGVmYXVsdGVkICYmICFzaGFsbG93RXF1YWxPYmplY3RzKHRoaXMub3B0aW9ucywgcHJldk9wdGlvbnMpKSB0aGlzLiNjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLm5vdGlmeSh7XG5cdFx0XHR0eXBlOiBcIm9ic2VydmVyT3B0aW9uc1VwZGF0ZWRcIixcblx0XHRcdHF1ZXJ5OiB0aGlzLiNjdXJyZW50UXVlcnksXG5cdFx0XHRvYnNlcnZlcjogdGhpc1xuXHRcdH0pO1xuXHRcdGNvbnN0IG1vdW50ZWQgPSB0aGlzLmhhc0xpc3RlbmVycygpO1xuXHRcdGlmIChtb3VudGVkICYmIHNob3VsZEZldGNoT3B0aW9uYWxseSh0aGlzLiNjdXJyZW50UXVlcnksIHByZXZRdWVyeSwgdGhpcy5vcHRpb25zLCBwcmV2T3B0aW9ucykpIHRoaXMuI2V4ZWN1dGVGZXRjaCgpO1xuXHRcdHRoaXMudXBkYXRlUmVzdWx0KCk7XG5cdFx0aWYgKG1vdW50ZWQgJiYgKHRoaXMuI2N1cnJlbnRRdWVyeSAhPT0gcHJldlF1ZXJ5IHx8IHJlc29sdmVRdWVyeVZhbHVlKHRoaXMub3B0aW9ucy5lbmFibGVkLCB0aGlzLiNjdXJyZW50UXVlcnkpICE9PSByZXNvbHZlUXVlcnlWYWx1ZShwcmV2T3B0aW9ucy5lbmFibGVkLCB0aGlzLiNjdXJyZW50UXVlcnkpIHx8IHJlc29sdmVRdWVyeVZhbHVlKHRoaXMub3B0aW9ucy5zdGFsZVRpbWUsIHRoaXMuI2N1cnJlbnRRdWVyeSkgIT09IHJlc29sdmVRdWVyeVZhbHVlKHByZXZPcHRpb25zLnN0YWxlVGltZSwgdGhpcy4jY3VycmVudFF1ZXJ5KSkpIHRoaXMuI3VwZGF0ZVN0YWxlVGltZW91dCgpO1xuXHRcdGNvbnN0IG5leHRSZWZldGNoSW50ZXJ2YWwgPSB0aGlzLiNjb21wdXRlUmVmZXRjaEludGVydmFsKCk7XG5cdFx0aWYgKG1vdW50ZWQgJiYgKHRoaXMuI2N1cnJlbnRRdWVyeSAhPT0gcHJldlF1ZXJ5IHx8IHJlc29sdmVRdWVyeVZhbHVlKHRoaXMub3B0aW9ucy5lbmFibGVkLCB0aGlzLiNjdXJyZW50UXVlcnkpICE9PSByZXNvbHZlUXVlcnlWYWx1ZShwcmV2T3B0aW9ucy5lbmFibGVkLCB0aGlzLiNjdXJyZW50UXVlcnkpIHx8IG5leHRSZWZldGNoSW50ZXJ2YWwgIT09IHRoaXMuI2N1cnJlbnRSZWZldGNoSW50ZXJ2YWwpKSB0aGlzLiN1cGRhdGVSZWZldGNoSW50ZXJ2YWwobmV4dFJlZmV0Y2hJbnRlcnZhbCk7XG5cdH1cblx0LyoqXG5cdCogQ29tcHV0ZXMgdGhlIHJlc3VsdCB0aGUgb2JzZXJ2ZXIgd291bGQgcHJvZHVjZSBmb3IgdGhlIGdpdmVuIChhbHJlYWR5LWRlZmF1bHRlZCkgb3B0aW9uc1xuXHQqIHJpZ2h0IG5vdywgYnVpbGRpbmcgdGhlIHVuZGVybHlpbmcgYFF1ZXJ5YCBpZiBpdCBkb2Vzbid0IGV4aXN0IHlldCwgd2l0aG91dCB3YWl0aW5nIGZvciBhXG5cdCogc3Vic2NyaXB0aW9uIGNhbGxiYWNrLiBDYWxsZWQgYnkgZnJhbWV3b3JrIGFkYXB0ZXJzIG9uIGV2ZXJ5IHJlbmRlciAoZS5nLiBgdXNlUXVlcnlgKSBzbyB0aGVcblx0KiByZXR1cm5lZCB2YWx1ZSBpcyBhdmFpbGFibGUgc3luY2hyb25vdXNseSwgYWhlYWQgb2YgYHNldE9wdGlvbnNgIHRyaWdnZXJpbmcgYW4gYWN0dWFsIGZldGNoLlxuXHQqL1xuXHRnZXRPcHRpbWlzdGljUmVzdWx0KG9wdGlvbnMpIHtcblx0XHRjb25zdCBxdWVyeSA9IHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkuYnVpbGQodGhpcy4jY2xpZW50LCBvcHRpb25zKTtcblx0XHRjb25zdCByZXN1bHQgPSB0aGlzLmNyZWF0ZVJlc3VsdChxdWVyeSwgb3B0aW9ucyk7XG5cdFx0aWYgKCFzaGFsbG93RXF1YWxPYmplY3RzKHRoaXMuZ2V0Q3VycmVudFJlc3VsdCgpLCByZXN1bHQpKSB7XG5cdFx0XHR0aGlzLiNjdXJyZW50UmVzdWx0ID0gcmVzdWx0O1xuXHRcdFx0dGhpcy4jY3VycmVudFJlc3VsdE9wdGlvbnMgPSB0aGlzLm9wdGlvbnM7XG5cdFx0XHR0aGlzLiNjdXJyZW50UmVzdWx0U3RhdGUgPSB0aGlzLiNjdXJyZW50UXVlcnkuc3RhdGU7XG5cdFx0fVxuXHRcdHJldHVybiByZXN1bHQ7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgbW9zdCByZWNlbnRseSBjb21wdXRlZCBgUXVlcnlPYnNlcnZlclJlc3VsdGAgZm9yIHRoZVxuXHQqIG9ic2VydmVkIHF1ZXJ5LiBUaGlzIGlzIGEgcG9pbnQtaW4tdGltZSByZWFkOyB0byBiZSBub3RpZmllZCBvZiB1cGRhdGVzXG5cdCogYXMgdGhleSBoYXBwZW4sIHN1YnNjcmliZSB0byB0aGUgb2JzZXJ2ZXIgaW5zdGVhZCAoaXRzIGluaGVyaXRlZFxuXHQqIGBzdWJzY3JpYmVgIG1ldGhvZCkuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgcmVzdWx0ID0gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpXG5cdCogY29uc29sZS5sb2cocmVzdWx0LnN0YXR1cywgcmVzdWx0LmRhdGEpXG5cdCogYGBgXG5cdCovXG5cdGdldEN1cnJlbnRSZXN1bHQoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI2N1cnJlbnRSZXN1bHQ7XG5cdH1cblx0LyoqXG5cdCogV3JhcHMgYSBgUXVlcnlPYnNlcnZlclJlc3VsdGAgaW4gYSBgUHJveHlgIHRoYXQgcmVjb3JkcyB3aGljaCBwcm9wZXJ0aWVzIGFyZSByZWFkLCB2aWFcblx0KiB7QGxpbmsgUXVlcnlPYnNlcnZlciN0cmFja1Byb3B9IChhbmQgYW4gb3B0aW9uYWwgYG9uUHJvcFRyYWNrZWRgIGNhbGxiYWNrKS4gVXNlZCBieSBmcmFtZXdvcmtcblx0KiBhZGFwdGVycyB3aGVuIGBub3RpZnlPbkNoYW5nZVByb3BzYCBpcyBub3Qgc2V0LCB0byBpbXBsZW1lbnQgaXRzIGRlZmF1bHQgXCJvbmx5IHJlLXJlbmRlciBvblxuXHQqIHByb3BlcnRpZXMgeW91IGFjdHVhbGx5IHJlYWRcIiBiZWhhdmlvci5cblx0Ki9cblx0dHJhY2tSZXN1bHQocmVzdWx0LCBvblByb3BUcmFja2VkKSB7XG5cdFx0cmV0dXJuIG5ldyBQcm94eShyZXN1bHQsIHsgZ2V0OiAodGFyZ2V0LCBrZXkpID0+IHtcblx0XHRcdHRoaXMudHJhY2tQcm9wKGtleSk7XG5cdFx0XHRvblByb3BUcmFja2VkPy4oa2V5KTtcblx0XHRcdHJldHVybiBSZWZsZWN0LmdldCh0YXJnZXQsIGtleSk7XG5cdFx0fSB9KTtcblx0fVxuXHQvKipcblx0KiBSZWNvcmRzIHRoYXQgdGhlIGdpdmVuIGBRdWVyeU9ic2VydmVyUmVzdWx0YCBwcm9wZXJ0eSB3YXMgcmVhZCwgc28gYSBzdWJzZXF1ZW50IHVwZGF0ZSBvbmx5XG5cdCogbm90aWZpZXMgdGhpcyBvYnNlcnZlciBpZiBhIHRyYWNrZWQgcHJvcGVydHkgYWN0dWFsbHkgY2hhbmdlZC4gTm9ybWFsbHkgY2FsbGVkIGluZGlyZWN0bHkgdmlhXG5cdCoge0BsaW5rIFF1ZXJ5T2JzZXJ2ZXIjdHJhY2tSZXN1bHR9J3MgcHJveHk7IGV4cG9zZWQgZGlyZWN0bHkgZm9yIGFkYXB0ZXJzIHRoYXQgdHJhY2sgcHJvcGVydHlcblx0KiBhY2Nlc3MgdGhlbXNlbHZlcyAoZS5nLiB0aHJvdWdoIHRoZWlyIG93biByZWFjdGl2aXR5IHN5c3RlbSkgaW5zdGVhZCBvZiB2aWEgdGhlIHByb3h5LlxuXHQqL1xuXHR0cmFja1Byb3Aoa2V5KSB7XG5cdFx0dGhpcy4jdHJhY2tlZFByb3BzLmFkZChrZXkpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIGBRdWVyeWAgaW5zdGFuY2UgdGhpcyBvYnNlcnZlciBpcyBjdXJyZW50bHkgb2JzZXJ2aW5nLlxuXHQqL1xuXHRnZXRDdXJyZW50UXVlcnkoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI2N1cnJlbnRRdWVyeTtcblx0fVxuXHQvKipcblx0KiBSZWZldGNoZXMgdGhlIG9ic2VydmVkIHF1ZXJ5IGFuZCByZXR1cm5zIGEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGhcblx0KiB0aGUgcmVzdWx0aW5nIGBRdWVyeU9ic2VydmVyUmVzdWx0YC5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCByZXN1bHQgPSBhd2FpdCBvYnNlcnZlci5yZWZldGNoKHsgY2FuY2VsUmVmZXRjaDogZmFsc2UgfSlcblx0KiBjb25zb2xlLmxvZyhyZXN1bHQuZGF0YSlcblx0KiBgYGBcblx0Ki9cblx0cmVmZXRjaCh7IC4uLm9wdGlvbnMgfSA9IHt9KSB7XG5cdFx0cmV0dXJuIHRoaXMuZmV0Y2goeyAuLi5vcHRpb25zIH0pO1xuXHR9XG5cdC8qKlxuXHQqIEZldGNoZXMgYSBxdWVyeSBkZWZpbmVkIGJ5IHRoZSBnaXZlbiBvcHRpb25zIHdpdGhvdXQgYWZmZWN0aW5nIHRoaXNcblx0KiBvYnNlcnZlcidzIG93biB0cmFja2VkIHF1ZXJ5IG9yIHJlc3VsdCwgYW5kIHJldHVybnMgYSBwcm9taXNlIHRoYXRcblx0KiByZXNvbHZlcyB3aXRoIHRoZSBgUXVlcnlPYnNlcnZlclJlc3VsdGAgZm9yIHRoYXQgZmV0Y2guIFRoaXMgaXMgdXNlZnVsXG5cdCogZm9yIHByZWZldGNoaW5nIGRhdGEgdGhhdCBhbm90aGVyIG9ic2VydmVyIChlLmcuIGEgcXVlcnkgYWJvdXQgdG8gYmVcblx0KiBuYXZpZ2F0ZWQgdG8pIHdpbGwgbmVlZCwgYWhlYWQgb2YgdGltZS5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCByZXN1bHQgPSBhd2FpdCBvYnNlcnZlci5mZXRjaE9wdGltaXN0aWMoe1xuXHQqICAgcXVlcnlLZXk6IFsncG9zdHMnLCAyXSxcblx0KiAgIHF1ZXJ5Rm46ICgpID0+IGZldGNoUG9zdCgyKSxcblx0KiB9KVxuXHQqIGNvbnNvbGUubG9nKHJlc3VsdC5kYXRhKVxuXHQqIGBgYFxuXHQqL1xuXHRmZXRjaE9wdGltaXN0aWMob3B0aW9ucykge1xuXHRcdGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSB0aGlzLiNjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKTtcblx0XHRjb25zdCBxdWVyeSA9IHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkuYnVpbGQodGhpcy4jY2xpZW50LCBkZWZhdWx0ZWRPcHRpb25zKTtcblx0XHRsZXQgdW5zdWJzY3JpYmUgPSAoKSA9PiB7fTtcblx0XHRsZXQgcmVzb2x2ZUVhcmx5O1xuXHRcdGNvbnN0IGNhY2hlUHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0XHRyZXNvbHZlRWFybHkgPSByZXNvbHZlO1xuXHRcdFx0dW5zdWJzY3JpYmUgPSB0aGlzLiNjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLnN1YnNjcmliZSgoZXZlbnQpID0+IHtcblx0XHRcdFx0aWYgKGV2ZW50LnR5cGUgPT09IFwidXBkYXRlZFwiICYmIGV2ZW50LnF1ZXJ5LnF1ZXJ5SGFzaCA9PT0gcXVlcnkucXVlcnlIYXNoICYmIHF1ZXJ5LnN0YXRlLmRhdGEgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRcdHVuc3Vic2NyaWJlKCk7XG5cdFx0XHRcdFx0cmVzb2x2ZSh0aGlzLmNyZWF0ZVJlc3VsdChxdWVyeSwgZGVmYXVsdGVkT3B0aW9ucykpO1xuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0XHRyZXR1cm4gUHJvbWlzZS5yYWNlKFtxdWVyeS5mZXRjaCgpLnRoZW4oKCkgPT4ge1xuXHRcdFx0Y29uc3QgcmVzdWx0ID0gdGhpcy5jcmVhdGVSZXN1bHQocXVlcnksIGRlZmF1bHRlZE9wdGlvbnMpO1xuXHRcdFx0cmVzb2x2ZUVhcmx5Py4ocmVzdWx0KTtcblx0XHRcdHJldHVybiByZXN1bHQ7XG5cdFx0fSkuZmluYWxseSgoKSA9PiB7XG5cdFx0XHR1bnN1YnNjcmliZSgpO1xuXHRcdH0pLCBjYWNoZVByb21pc2VdKTtcblx0fVxuXHRmZXRjaChmZXRjaE9wdGlvbnMpIHtcblx0XHRyZXR1cm4gdGhpcy4jZXhlY3V0ZUZldGNoKHtcblx0XHRcdC4uLmZldGNoT3B0aW9ucyxcblx0XHRcdGNhbmNlbFJlZmV0Y2g6IGZldGNoT3B0aW9ucy5jYW5jZWxSZWZldGNoID8/IHRydWVcblx0XHR9KS50aGVuKCgpID0+IHtcblx0XHRcdHRoaXMudXBkYXRlUmVzdWx0KCk7XG5cdFx0XHRyZXR1cm4gdGhpcy4jY3VycmVudFJlc3VsdDtcblx0XHR9KTtcblx0fVxuXHQjZXhlY3V0ZUZldGNoKGZldGNoT3B0aW9ucykge1xuXHRcdHRoaXMuI3VwZGF0ZVF1ZXJ5KCk7XG5cdFx0bGV0IHByb21pc2UgPSB0aGlzLiNjdXJyZW50UXVlcnkuZmV0Y2godGhpcy5vcHRpb25zLCBmZXRjaE9wdGlvbnMpO1xuXHRcdGlmICghZmV0Y2hPcHRpb25zPy50aHJvd09uRXJyb3IpIHByb21pc2UgPSBwcm9taXNlLmNhdGNoKG5vb3ApO1xuXHRcdHJldHVybiBwcm9taXNlO1xuXHR9XG5cdCNzaG91bGRTY2hlZHVsZVRpbWVyKHRpbWVvdXQpIHtcblx0XHRyZXR1cm4gIWlzU2VydmVyKCkgJiYgcmVzb2x2ZVF1ZXJ5VmFsdWUodGhpcy5vcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgIT09IGZhbHNlICYmIGlzVmFsaWRUaW1lb3V0KHRpbWVvdXQpO1xuXHR9XG5cdCN1cGRhdGVTdGFsZVRpbWVvdXQoKSB7XG5cdFx0dGhpcy4jY2xlYXJTdGFsZVRpbWVvdXQoKTtcblx0XHRjb25zdCBzdGFsZVRpbWUgPSByZXNvbHZlUXVlcnlWYWx1ZSh0aGlzLm9wdGlvbnMuc3RhbGVUaW1lLCB0aGlzLiNjdXJyZW50UXVlcnkpO1xuXHRcdGlmICh0aGlzLiNjdXJyZW50UmVzdWx0LmlzU3RhbGUgfHwgIXRoaXMuI3Nob3VsZFNjaGVkdWxlVGltZXIoc3RhbGVUaW1lKSkgcmV0dXJuO1xuXHRcdGNvbnN0IHRpbWVvdXQgPSB0aW1lVW50aWxTdGFsZSh0aGlzLiNjdXJyZW50UmVzdWx0LmRhdGFVcGRhdGVkQXQsIHN0YWxlVGltZSkgKyAxO1xuXHRcdHRoaXMuI3N0YWxlVGltZW91dElkID0gdGltZW91dE1hbmFnZXIuc2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHRpZiAoIXRoaXMuI2N1cnJlbnRSZXN1bHQuaXNTdGFsZSkgdGhpcy51cGRhdGVSZXN1bHQoKTtcblx0XHR9LCB0aW1lb3V0KTtcblx0fVxuXHQjY29tcHV0ZVJlZmV0Y2hJbnRlcnZhbCgpIHtcblx0XHRyZXR1cm4gcmVzb2x2ZVF1ZXJ5VmFsdWUodGhpcy5vcHRpb25zLnJlZmV0Y2hJbnRlcnZhbCwgdGhpcy4jY3VycmVudFF1ZXJ5KSA/PyBmYWxzZTtcblx0fVxuXHQjdXBkYXRlUmVmZXRjaEludGVydmFsKG5leHRJbnRlcnZhbCkge1xuXHRcdHRoaXMuI2NsZWFyUmVmZXRjaEludGVydmFsKCk7XG5cdFx0dGhpcy4jY3VycmVudFJlZmV0Y2hJbnRlcnZhbCA9IG5leHRJbnRlcnZhbDtcblx0XHRpZiAodGhpcy4jY3VycmVudFJlZmV0Y2hJbnRlcnZhbCA9PT0gMCB8fCAhdGhpcy4jc2hvdWxkU2NoZWR1bGVUaW1lcih0aGlzLiNjdXJyZW50UmVmZXRjaEludGVydmFsKSkgcmV0dXJuO1xuXHRcdHRoaXMuI3JlZmV0Y2hJbnRlcnZhbElkID0gdGltZW91dE1hbmFnZXIuc2V0SW50ZXJ2YWwoKCkgPT4ge1xuXHRcdFx0aWYgKHRoaXMub3B0aW9ucy5yZWZldGNoSW50ZXJ2YWxJbkJhY2tncm91bmQgfHwgZm9jdXNNYW5hZ2VyLmlzRm9jdXNlZCgpKSB0aGlzLiNleGVjdXRlRmV0Y2goKTtcblx0XHR9LCB0aGlzLiNjdXJyZW50UmVmZXRjaEludGVydmFsKTtcblx0fVxuXHQjdXBkYXRlVGltZXJzKCkge1xuXHRcdHRoaXMuI3VwZGF0ZVN0YWxlVGltZW91dCgpO1xuXHRcdHRoaXMuI3VwZGF0ZVJlZmV0Y2hJbnRlcnZhbCh0aGlzLiNjb21wdXRlUmVmZXRjaEludGVydmFsKCkpO1xuXHR9XG5cdCNjbGVhclN0YWxlVGltZW91dCgpIHtcblx0XHRpZiAodGhpcy4jc3RhbGVUaW1lb3V0SWQgIT09IHZvaWQgMCkge1xuXHRcdFx0dGltZW91dE1hbmFnZXIuY2xlYXJUaW1lb3V0KHRoaXMuI3N0YWxlVGltZW91dElkKTtcblx0XHRcdHRoaXMuI3N0YWxlVGltZW91dElkID0gdm9pZCAwO1xuXHRcdH1cblx0fVxuXHQjY2xlYXJSZWZldGNoSW50ZXJ2YWwoKSB7XG5cdFx0aWYgKHRoaXMuI3JlZmV0Y2hJbnRlcnZhbElkICE9PSB2b2lkIDApIHtcblx0XHRcdHRpbWVvdXRNYW5hZ2VyLmNsZWFySW50ZXJ2YWwodGhpcy4jcmVmZXRjaEludGVydmFsSWQpO1xuXHRcdFx0dGhpcy4jcmVmZXRjaEludGVydmFsSWQgPSB2b2lkIDA7XG5cdFx0fVxuXHR9XG5cdGNyZWF0ZVJlc3VsdChxdWVyeSwgb3B0aW9ucykge1xuXHRcdGNvbnN0IHByZXZRdWVyeSA9IHRoaXMuI2N1cnJlbnRRdWVyeTtcblx0XHRjb25zdCBwcmV2T3B0aW9ucyA9IHRoaXMub3B0aW9ucztcblx0XHRjb25zdCBwcmV2UmVzdWx0ID0gdGhpcy4jY3VycmVudFJlc3VsdDtcblx0XHRjb25zdCBwcmV2UmVzdWx0U3RhdGUgPSB0aGlzLiNjdXJyZW50UmVzdWx0U3RhdGU7XG5cdFx0Y29uc3QgcHJldlJlc3VsdE9wdGlvbnMgPSB0aGlzLiNjdXJyZW50UmVzdWx0T3B0aW9ucztcblx0XHRjb25zdCBxdWVyeUluaXRpYWxTdGF0ZSA9IHF1ZXJ5ICE9PSBwcmV2UXVlcnkgPyBxdWVyeS5zdGF0ZSA6IHRoaXMuI2N1cnJlbnRRdWVyeUluaXRpYWxTdGF0ZTtcblx0XHRjb25zdCB7IHN0YXRlIH0gPSBxdWVyeTtcblx0XHRsZXQgbmV3U3RhdGUgPSB7IC4uLnN0YXRlIH07XG5cdFx0bGV0IGlzUGxhY2Vob2xkZXJEYXRhID0gZmFsc2U7XG5cdFx0bGV0IGRhdGE7XG5cdFx0aWYgKG9wdGlvbnMuX29wdGltaXN0aWNSZXN1bHRzKSB7XG5cdFx0XHRjb25zdCBtb3VudGVkID0gdGhpcy5oYXNMaXN0ZW5lcnMoKTtcblx0XHRcdGNvbnN0IGZldGNoT25Nb3VudCA9ICFtb3VudGVkICYmIHNob3VsZEZldGNoT25Nb3VudChxdWVyeSwgb3B0aW9ucyk7XG5cdFx0XHRjb25zdCBmZXRjaE9wdGlvbmFsbHkgPSBtb3VudGVkICYmIHNob3VsZEZldGNoT3B0aW9uYWxseShxdWVyeSwgcHJldlF1ZXJ5LCBvcHRpb25zLCBwcmV2T3B0aW9ucyk7XG5cdFx0XHRpZiAoZmV0Y2hPbk1vdW50IHx8IGZldGNoT3B0aW9uYWxseSkgbmV3U3RhdGUgPSB7XG5cdFx0XHRcdC4uLm5ld1N0YXRlLFxuXHRcdFx0XHQuLi5mZXRjaFN0YXRlKHN0YXRlLmRhdGEsIHF1ZXJ5Lm9wdGlvbnMpXG5cdFx0XHR9O1xuXHRcdFx0aWYgKG9wdGlvbnMuX29wdGltaXN0aWNSZXN1bHRzID09PSBcImlzUmVzdG9yaW5nXCIpIG5ld1N0YXRlLmZldGNoU3RhdHVzID0gXCJpZGxlXCI7XG5cdFx0fVxuXHRcdGxldCB7IGVycm9yLCBlcnJvclVwZGF0ZWRBdCwgc3RhdHVzIH0gPSBuZXdTdGF0ZTtcblx0XHRkYXRhID0gbmV3U3RhdGUuZGF0YTtcblx0XHRsZXQgc2tpcFNlbGVjdCA9IGZhbHNlO1xuXHRcdGlmIChvcHRpb25zLnBsYWNlaG9sZGVyRGF0YSAhPT0gdm9pZCAwICYmIGRhdGEgPT09IHZvaWQgMCAmJiBzdGF0dXMgPT09IFwicGVuZGluZ1wiKSB7XG5cdFx0XHRsZXQgcGxhY2Vob2xkZXJEYXRhO1xuXHRcdFx0aWYgKHByZXZSZXN1bHQ/LmlzUGxhY2Vob2xkZXJEYXRhICYmIG9wdGlvbnMucGxhY2Vob2xkZXJEYXRhID09PSBwcmV2UmVzdWx0T3B0aW9ucz8ucGxhY2Vob2xkZXJEYXRhKSB7XG5cdFx0XHRcdHBsYWNlaG9sZGVyRGF0YSA9IHByZXZSZXN1bHQuZGF0YTtcblx0XHRcdFx0c2tpcFNlbGVjdCA9IHRydWU7XG5cdFx0XHR9IGVsc2UgcGxhY2Vob2xkZXJEYXRhID0gdHlwZW9mIG9wdGlvbnMucGxhY2Vob2xkZXJEYXRhID09PSBcImZ1bmN0aW9uXCIgPyBvcHRpb25zLnBsYWNlaG9sZGVyRGF0YSh0aGlzLiNsYXN0UXVlcnlXaXRoRGVmaW5lZERhdGE/LnN0YXRlLmRhdGEsIHRoaXMuI2xhc3RRdWVyeVdpdGhEZWZpbmVkRGF0YSkgOiBvcHRpb25zLnBsYWNlaG9sZGVyRGF0YTtcblx0XHRcdGlmIChwbGFjZWhvbGRlckRhdGEgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRzdGF0dXMgPSBcInN1Y2Nlc3NcIjtcblx0XHRcdFx0ZGF0YSA9IHJlcGxhY2VEYXRhKHByZXZSZXN1bHQ/LmRhdGEsIHBsYWNlaG9sZGVyRGF0YSwgb3B0aW9ucyk7XG5cdFx0XHRcdGlzUGxhY2Vob2xkZXJEYXRhID0gdHJ1ZTtcblx0XHRcdH1cblx0XHR9XG5cdFx0aWYgKG9wdGlvbnMuc2VsZWN0ICYmIGRhdGEgIT09IHZvaWQgMCAmJiAhc2tpcFNlbGVjdCkge1xuXHRcdFx0aWYgKHByZXZSZXN1bHQgJiYgZGF0YSA9PT0gcHJldlJlc3VsdFN0YXRlPy5kYXRhICYmIG9wdGlvbnMuc2VsZWN0ID09PSB0aGlzLiNzZWxlY3RGbikgZGF0YSA9IHRoaXMuI3NlbGVjdFJlc3VsdDtcblx0XHRcdGVsc2UgdHJ5IHtcblx0XHRcdFx0dGhpcy4jc2VsZWN0Rm4gPSBvcHRpb25zLnNlbGVjdDtcblx0XHRcdFx0ZGF0YSA9IG9wdGlvbnMuc2VsZWN0KGRhdGEpO1xuXHRcdFx0XHRkYXRhID0gcmVwbGFjZURhdGEocHJldlJlc3VsdD8uZGF0YSwgZGF0YSwgb3B0aW9ucyk7XG5cdFx0XHRcdHRoaXMuI3NlbGVjdFJlc3VsdCA9IGRhdGE7XG5cdFx0XHRcdHRoaXMuI3NlbGVjdEVycm9yID0gbnVsbDtcblx0XHRcdH0gY2F0Y2ggKHNlbGVjdEVycm9yKSB7XG5cdFx0XHRcdHRoaXMuI3NlbGVjdEVycm9yID0gc2VsZWN0RXJyb3I7XG5cdFx0XHR9XG5cdFx0fSBlbHNlIGlmIChkYXRhID09PSB2b2lkIDApIHRoaXMuI3NlbGVjdEVycm9yID0gbnVsbDtcblx0XHRpZiAodGhpcy4jc2VsZWN0RXJyb3IpIHtcblx0XHRcdGVycm9yID0gdGhpcy4jc2VsZWN0RXJyb3I7XG5cdFx0XHRkYXRhID0gdGhpcy4jc2VsZWN0UmVzdWx0O1xuXHRcdFx0ZXJyb3JVcGRhdGVkQXQgPSBEYXRlLm5vdygpO1xuXHRcdFx0c3RhdHVzID0gXCJlcnJvclwiO1xuXHRcdFx0aXNQbGFjZWhvbGRlckRhdGEgPSBmYWxzZTtcblx0XHR9XG5cdFx0Y29uc3QgaXNGZXRjaGluZyA9IG5ld1N0YXRlLmZldGNoU3RhdHVzID09PSBcImZldGNoaW5nXCI7XG5cdFx0Y29uc3QgaXNQZW5kaW5nID0gc3RhdHVzID09PSBcInBlbmRpbmdcIjtcblx0XHRjb25zdCBpc0Vycm9yID0gc3RhdHVzID09PSBcImVycm9yXCI7XG5cdFx0Y29uc3QgaXNMb2FkaW5nID0gaXNQZW5kaW5nICYmIGlzRmV0Y2hpbmc7XG5cdFx0Y29uc3QgaGFzRGF0YSA9IGRhdGEgIT09IHZvaWQgMDtcblx0XHRyZXR1cm4ge1xuXHRcdFx0c3RhdHVzLFxuXHRcdFx0ZmV0Y2hTdGF0dXM6IG5ld1N0YXRlLmZldGNoU3RhdHVzLFxuXHRcdFx0aXNQZW5kaW5nLFxuXHRcdFx0aXNTdWNjZXNzOiBzdGF0dXMgPT09IFwic3VjY2Vzc1wiLFxuXHRcdFx0aXNFcnJvcixcblx0XHRcdGlzSW5pdGlhbExvYWRpbmc6IGlzTG9hZGluZyxcblx0XHRcdGlzTG9hZGluZyxcblx0XHRcdGRhdGEsXG5cdFx0XHRkYXRhVXBkYXRlZEF0OiBuZXdTdGF0ZS5kYXRhVXBkYXRlZEF0LFxuXHRcdFx0ZXJyb3IsXG5cdFx0XHRlcnJvclVwZGF0ZWRBdCxcblx0XHRcdGZhaWx1cmVDb3VudDogbmV3U3RhdGUuZmV0Y2hGYWlsdXJlQ291bnQsXG5cdFx0XHRmYWlsdXJlUmVhc29uOiBuZXdTdGF0ZS5mZXRjaEZhaWx1cmVSZWFzb24sXG5cdFx0XHRlcnJvclVwZGF0ZUNvdW50OiBuZXdTdGF0ZS5lcnJvclVwZGF0ZUNvdW50LFxuXHRcdFx0aXNGZXRjaGVkOiBxdWVyeS5pc0ZldGNoZWQoKSxcblx0XHRcdGlzRmV0Y2hlZEFmdGVyTW91bnQ6IG5ld1N0YXRlLmRhdGFVcGRhdGVDb3VudCA+IHF1ZXJ5SW5pdGlhbFN0YXRlLmRhdGFVcGRhdGVDb3VudCB8fCBuZXdTdGF0ZS5lcnJvclVwZGF0ZUNvdW50ID4gcXVlcnlJbml0aWFsU3RhdGUuZXJyb3JVcGRhdGVDb3VudCxcblx0XHRcdGlzRmV0Y2hpbmcsXG5cdFx0XHRpc1JlZmV0Y2hpbmc6IGlzRmV0Y2hpbmcgJiYgIWlzUGVuZGluZyxcblx0XHRcdGlzTG9hZGluZ0Vycm9yOiBpc0Vycm9yICYmICFoYXNEYXRhLFxuXHRcdFx0aXNQYXVzZWQ6IG5ld1N0YXRlLmZldGNoU3RhdHVzID09PSBcInBhdXNlZFwiLFxuXHRcdFx0aXNQbGFjZWhvbGRlckRhdGEsXG5cdFx0XHRpc1JlZmV0Y2hFcnJvcjogaXNFcnJvciAmJiBoYXNEYXRhLFxuXHRcdFx0aXNTdGFsZTogaXNTdGFsZShxdWVyeSwgb3B0aW9ucyksXG5cdFx0XHRyZWZldGNoOiB0aGlzLnJlZmV0Y2gsXG5cdFx0XHRpc0VuYWJsZWQ6IHJlc29sdmVRdWVyeVZhbHVlKG9wdGlvbnMuZW5hYmxlZCwgcXVlcnkpICE9PSBmYWxzZVxuXHRcdH07XG5cdH1cblx0LyoqXG5cdCogUmVjb21wdXRlcyBhbmQgc3RvcmVzIHRoZSBjdXJyZW50IHJlc3VsdCBmcm9tIHRoZSBjdXJyZW50IHF1ZXJ5L29wdGlvbnMsIG5vdGlmeWluZyBsaXN0ZW5lcnNcblx0KiBpZiBpdCBjaGFuZ2VkLiBGcmFtZXdvcmsgYWRhcHRlcnMgY2FsbCB0aGlzIHJpZ2h0IGFmdGVyIHN1YnNjcmliaW5nIHRvIG1ha2Ugc3VyZSBubyBxdWVyeVxuXHQqIHVwZGF0ZSB3YXMgbWlzc2VkIGluIHRoZSBnYXAgYmV0d2VlbiBjcmVhdGluZyB0aGUgb2JzZXJ2ZXIgYW5kIHN1YnNjcmliaW5nIHRvIGl0LlxuXHQqL1xuXHR1cGRhdGVSZXN1bHQoKSB7XG5cdFx0Y29uc3QgcHJldlJlc3VsdCA9IHRoaXMuI2N1cnJlbnRSZXN1bHQ7XG5cdFx0Y29uc3QgbmV4dFJlc3VsdCA9IHRoaXMuY3JlYXRlUmVzdWx0KHRoaXMuI2N1cnJlbnRRdWVyeSwgdGhpcy5vcHRpb25zKTtcblx0XHR0aGlzLiNjdXJyZW50UmVzdWx0U3RhdGUgPSB0aGlzLiNjdXJyZW50UXVlcnkuc3RhdGU7XG5cdFx0dGhpcy4jY3VycmVudFJlc3VsdE9wdGlvbnMgPSB0aGlzLm9wdGlvbnM7XG5cdFx0aWYgKHRoaXMuI2N1cnJlbnRSZXN1bHRTdGF0ZS5kYXRhICE9PSB2b2lkIDApIHRoaXMuI2xhc3RRdWVyeVdpdGhEZWZpbmVkRGF0YSA9IHRoaXMuI2N1cnJlbnRRdWVyeTtcblx0XHRpZiAoc2hhbGxvd0VxdWFsT2JqZWN0cyhuZXh0UmVzdWx0LCBwcmV2UmVzdWx0KSkgcmV0dXJuO1xuXHRcdHRoaXMuI2N1cnJlbnRSZXN1bHQgPSBuZXh0UmVzdWx0O1xuXHRcdGNvbnN0IHNob3VsZE5vdGlmeUxpc3RlbmVycyA9ICgpID0+IHtcblx0XHRcdGlmICghcHJldlJlc3VsdCkgcmV0dXJuIHRydWU7XG5cdFx0XHRjb25zdCB7IG5vdGlmeU9uQ2hhbmdlUHJvcHMgfSA9IHRoaXMub3B0aW9ucztcblx0XHRcdGNvbnN0IG5vdGlmeU9uQ2hhbmdlUHJvcHNWYWx1ZSA9IHR5cGVvZiBub3RpZnlPbkNoYW5nZVByb3BzID09PSBcImZ1bmN0aW9uXCIgPyBub3RpZnlPbkNoYW5nZVByb3BzKCkgOiBub3RpZnlPbkNoYW5nZVByb3BzO1xuXHRcdFx0aWYgKG5vdGlmeU9uQ2hhbmdlUHJvcHNWYWx1ZSA9PT0gXCJhbGxcIiB8fCAhbm90aWZ5T25DaGFuZ2VQcm9wc1ZhbHVlICYmICF0aGlzLiN0cmFja2VkUHJvcHMuc2l6ZSkgcmV0dXJuIHRydWU7XG5cdFx0XHRjb25zdCBpbmNsdWRlZFByb3BzID0gbmV3IFNldChub3RpZnlPbkNoYW5nZVByb3BzVmFsdWUgPz8gdGhpcy4jdHJhY2tlZFByb3BzKTtcblx0XHRcdGlmICh0aGlzLm9wdGlvbnMudGhyb3dPbkVycm9yKSBpbmNsdWRlZFByb3BzLmFkZChcImVycm9yXCIpO1xuXHRcdFx0cmV0dXJuIE9iamVjdC5rZXlzKHRoaXMuI2N1cnJlbnRSZXN1bHQpLnNvbWUoKGtleSkgPT4ge1xuXHRcdFx0XHRjb25zdCB0eXBlZEtleSA9IGtleTtcblx0XHRcdFx0cmV0dXJuIHRoaXMuI2N1cnJlbnRSZXN1bHRbdHlwZWRLZXldICE9PSBwcmV2UmVzdWx0W3R5cGVkS2V5XSAmJiBpbmNsdWRlZFByb3BzLmhhcyh0eXBlZEtleSk7XG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdGNvbnN0IG5vdGlmeUxpc3RlbmVycyA9IHNob3VsZE5vdGlmeUxpc3RlbmVycygpO1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0aWYgKG5vdGlmeUxpc3RlbmVycykgdGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcblx0XHRcdFx0bGlzdGVuZXIodGhpcy4jY3VycmVudFJlc3VsdCk7XG5cdFx0XHR9KTtcblx0XHRcdHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkubm90aWZ5KHtcblx0XHRcdFx0cXVlcnk6IHRoaXMuI2N1cnJlbnRRdWVyeSxcblx0XHRcdFx0dHlwZTogXCJvYnNlcnZlclJlc3VsdHNVcGRhdGVkXCJcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG5cdCN1cGRhdGVRdWVyeSgpIHtcblx0XHRjb25zdCBxdWVyeSA9IHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkuYnVpbGQodGhpcy4jY2xpZW50LCB0aGlzLm9wdGlvbnMpO1xuXHRcdGlmIChxdWVyeSA9PT0gdGhpcy4jY3VycmVudFF1ZXJ5KSByZXR1cm47XG5cdFx0Y29uc3QgcHJldlF1ZXJ5ID0gdGhpcy4jY3VycmVudFF1ZXJ5O1xuXHRcdHRoaXMuI2N1cnJlbnRRdWVyeSA9IHF1ZXJ5O1xuXHRcdHRoaXMuI2N1cnJlbnRRdWVyeUluaXRpYWxTdGF0ZSA9IHF1ZXJ5LnN0YXRlO1xuXHRcdGlmICh0aGlzLmhhc0xpc3RlbmVycygpKSB7XG5cdFx0XHRwcmV2UXVlcnk/LnJlbW92ZU9ic2VydmVyKHRoaXMpO1xuXHRcdFx0cXVlcnkuYWRkT2JzZXJ2ZXIodGhpcyk7XG5cdFx0fVxuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0b25RdWVyeVVwZGF0ZSgpIHtcblx0XHR0aGlzLnVwZGF0ZVJlc3VsdCgpO1xuXHRcdGlmICh0aGlzLmhhc0xpc3RlbmVycygpKSB0aGlzLiN1cGRhdGVUaW1lcnMoKTtcblx0fVxufTtcbmZ1bmN0aW9uIHNob3VsZExvYWRPbk1vdW50KHF1ZXJ5LCBvcHRpb25zKSB7XG5cdHJldHVybiByZXNvbHZlUXVlcnlWYWx1ZShvcHRpb25zLmVuYWJsZWQsIHF1ZXJ5KSAhPT0gZmFsc2UgJiYgcXVlcnkuc3RhdGUuZGF0YSA9PT0gdm9pZCAwICYmICEocXVlcnkuc3RhdGUuc3RhdHVzID09PSBcImVycm9yXCIgJiYgcmVzb2x2ZVF1ZXJ5VmFsdWUob3B0aW9ucy5yZXRyeU9uTW91bnQsIHF1ZXJ5KSA9PT0gZmFsc2UpO1xufVxuZnVuY3Rpb24gc2hvdWxkRmV0Y2hPbk1vdW50KHF1ZXJ5LCBvcHRpb25zKSB7XG5cdHJldHVybiBzaG91bGRMb2FkT25Nb3VudChxdWVyeSwgb3B0aW9ucykgfHwgcXVlcnkuc3RhdGUuZGF0YSAhPT0gdm9pZCAwICYmIHNob3VsZEZldGNoT24ocXVlcnksIG9wdGlvbnMsIG9wdGlvbnMucmVmZXRjaE9uTW91bnQpO1xufVxuZnVuY3Rpb24gc2hvdWxkRmV0Y2hPbihxdWVyeSwgb3B0aW9ucywgZmllbGQpIHtcblx0aWYgKHJlc29sdmVRdWVyeVZhbHVlKG9wdGlvbnMuZW5hYmxlZCwgcXVlcnkpICE9PSBmYWxzZSAmJiByZXNvbHZlUXVlcnlWYWx1ZShvcHRpb25zLnN0YWxlVGltZSwgcXVlcnkpICE9PSBcInN0YXRpY1wiKSB7XG5cdFx0Y29uc3QgdmFsdWUgPSByZXNvbHZlUXVlcnlWYWx1ZShmaWVsZCwgcXVlcnkpO1xuXHRcdHJldHVybiB2YWx1ZSA9PT0gXCJhbHdheXNcIiB8fCB2YWx1ZSAhPT0gZmFsc2UgJiYgaXNTdGFsZShxdWVyeSwgb3B0aW9ucyk7XG5cdH1cblx0cmV0dXJuIGZhbHNlO1xufVxuZnVuY3Rpb24gc2hvdWxkRmV0Y2hPcHRpb25hbGx5KHF1ZXJ5LCBwcmV2UXVlcnksIG9wdGlvbnMsIHByZXZPcHRpb25zKSB7XG5cdHJldHVybiAocXVlcnkgIT09IHByZXZRdWVyeSB8fCByZXNvbHZlUXVlcnlWYWx1ZShwcmV2T3B0aW9ucy5lbmFibGVkLCBxdWVyeSkgPT09IGZhbHNlKSAmJiAoIW9wdGlvbnMuc3VzcGVuc2UgfHwgcXVlcnkuc3RhdGUuc3RhdHVzICE9PSBcImVycm9yXCIpICYmIGlzU3RhbGUocXVlcnksIG9wdGlvbnMpO1xufVxuZnVuY3Rpb24gaXNTdGFsZShxdWVyeSwgb3B0aW9ucykge1xuXHRyZXR1cm4gcmVzb2x2ZVF1ZXJ5VmFsdWUob3B0aW9ucy5lbmFibGVkLCBxdWVyeSkgIT09IGZhbHNlICYmIHF1ZXJ5LmlzU3RhbGVCeVRpbWUocmVzb2x2ZVF1ZXJ5VmFsdWUob3B0aW9ucy5zdGFsZVRpbWUsIHF1ZXJ5KSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFF1ZXJ5T2JzZXJ2ZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cXVlcnlPYnNlcnZlci5qcy5tYXAiLCJpbXBvcnQgeyBoYXNOZXh0UGFnZSwgaGFzUHJldmlvdXNQYWdlIH0gZnJvbSBcIi4vaW5maW5pdGVRdWVyeUJlaGF2aW9yLmpzXCI7XG5pbXBvcnQgeyBRdWVyeU9ic2VydmVyIH0gZnJvbSBcIi4vcXVlcnlPYnNlcnZlci5qc1wiO1xuLy8jcmVnaW9uIHNyYy9pbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIudHNcbi8qKlxuKiBBbiBgSW5maW5pdGVRdWVyeU9ic2VydmVyYCBleHRlbmRzIGBRdWVyeU9ic2VydmVyYCB0byBvYnNlcnZlIGFuZCBzd2l0Y2hcbiogYmV0d2VlbiBpbmZpbml0ZSBxdWVyaWVzLiBJdCBhdWdtZW50cyB0aGUgYmFzZSBgUXVlcnlPYnNlcnZlclJlc3VsdGAgd2l0aFxuKiBpbmZpbml0ZS1xdWVyeS1zcGVjaWZpYyBmaWVsZHMgYW5kIG1ldGhvZHMsIHN1Y2ggYXMgYGhhc05leHRQYWdlYCBhbmRcbiogYGZldGNoTmV4dFBhZ2VgLCBhbmQgaXMgdGhlIHByaW1pdGl2ZSB0aGF0IGZyYW1ld29yayBhZGFwdGVycyAoZS5nLlxuKiBgdXNlSW5maW5pdGVRdWVyeWApIGJ1aWxkIHRoZWlyIGhvb2tzIG9uIHRvcCBvZi5cbipcbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgSW5maW5pdGVRdWVyeU9ic2VydmVyKHF1ZXJ5Q2xpZW50LCB7XG4qICAgcXVlcnlLZXk6IFsncHJvamVjdHMnXSxcbiogICBxdWVyeUZuOiAoeyBwYWdlUGFyYW0gfSkgPT4gZmV0Y2hQcm9qZWN0cyhwYWdlUGFyYW0pLFxuKiAgIGluaXRpYWxQYWdlUGFyYW06IDAsXG4qICAgZ2V0TmV4dFBhZ2VQYXJhbTogKGxhc3RQYWdlKSA9PiBsYXN0UGFnZS5uZXh0Q3Vyc29yLFxuKiB9KVxuKlxuKiBjb25zdCB1bnN1YnNjcmliZSA9IG9ic2VydmVyLnN1YnNjcmliZSgocmVzdWx0KSA9PiBjb25zb2xlLmxvZyhyZXN1bHQpKVxuKiBgYGBcbiovXG52YXIgSW5maW5pdGVRdWVyeU9ic2VydmVyID0gY2xhc3MgZXh0ZW5kcyBRdWVyeU9ic2VydmVyIHtcblx0Y29uc3RydWN0b3IoY2xpZW50LCBvcHRpb25zKSB7XG5cdFx0c3VwZXIoY2xpZW50LCBvcHRpb25zKTtcblx0fVxuXHRiaW5kTWV0aG9kcygpIHtcblx0XHRzdXBlci5iaW5kTWV0aG9kcygpO1xuXHRcdHRoaXMuZmV0Y2hOZXh0UGFnZSA9IHRoaXMuZmV0Y2hOZXh0UGFnZS5iaW5kKHRoaXMpO1xuXHRcdHRoaXMuZmV0Y2hQcmV2aW91c1BhZ2UgPSB0aGlzLmZldGNoUHJldmlvdXNQYWdlLmJpbmQodGhpcyk7XG5cdH1cblx0LyoqXG5cdCogVXBkYXRlcyB0aGUgb2JzZXJ2ZXIncyBvcHRpb25zLiBCZWhhdmVzIHRoZSBzYW1lIGFzXG5cdCogYFF1ZXJ5T2JzZXJ2ZXIuc2V0T3B0aW9uc2AsIGFkZGl0aW9uYWxseSBtYXJraW5nIHRoZSBvcHRpb25zIGFzXG5cdCogYmVsb25naW5nIHRvIGFuIGluZmluaXRlIHF1ZXJ5IGJlZm9yZSBkZWxlZ2F0aW5nIHRvIHRoZSBiYXNlXG5cdCogaW1wbGVtZW50YXRpb24uXG5cdCovXG5cdHNldE9wdGlvbnMob3B0aW9ucykge1xuXHRcdG9wdGlvbnMuX3R5cGUgPSBcImluZmluaXRlXCI7XG5cdFx0c3VwZXIuc2V0T3B0aW9ucyhvcHRpb25zKTtcblx0fVxuXHQvKipcblx0KiBUaGUgaW5maW5pdGUtcXVlcnkgY291bnRlcnBhcnQgb2Yge0BsaW5rIFF1ZXJ5T2JzZXJ2ZXIjZ2V0T3B0aW1pc3RpY1Jlc3VsdH0sIG1hcmtpbmcgdGhlXG5cdCogb3B0aW9ucyBhcyBhbiBpbmZpbml0ZSBxdWVyeSBiZWZvcmUgZGVsZWdhdGluZyB0byBpdC4gQ2FsbGVkIGJ5IGZyYW1ld29yayBhZGFwdGVycyAoZS5nLlxuXHQqIGB1c2VJbmZpbml0ZVF1ZXJ5YCkgYWhlYWQgb2Ygc3Vic2NyaWJpbmcsIHRvIGNvbXB1dGUgdGhlIGN1cnJlbnQgYEluZmluaXRlUXVlcnlPYnNlcnZlclJlc3VsdGBcblx0KiBzeW5jaHJvbm91c2x5LlxuXHQqL1xuXHRnZXRPcHRpbWlzdGljUmVzdWx0KG9wdGlvbnMpIHtcblx0XHRvcHRpb25zLl90eXBlID0gXCJpbmZpbml0ZVwiO1xuXHRcdHJldHVybiBzdXBlci5nZXRPcHRpbWlzdGljUmVzdWx0KG9wdGlvbnMpO1xuXHR9XG5cdC8qKlxuXHQqIEZldGNoZXMgdGhlIG5leHQgcGFnZSBvZiB0aGUgaW5maW5pdGUgcXVlcnkgYW5kIHJldHVybnMgYSBwcm9taXNlIHRoYXRcblx0KiByZXNvbHZlcyB3aXRoIHRoZSByZXN1bHRpbmcgYEluZmluaXRlUXVlcnlPYnNlcnZlclJlc3VsdGAuIFRoZSBwYWdlXG5cdCogcGFyYW0gdXNlZCBmb3IgdGhlIGZldGNoIGlzIGRldGVybWluZWQgYnkgYGdldE5leHRQYWdlUGFyYW1gLCB3aGljaFxuXHQqIHJlY2VpdmVzIHRoZSBjdXJyZW50IHBhZ2VzL3BhZ2UgcGFyYW1zIGFuZCB3aG9zZSByZXN1bHQgYWxzbyBkZXRlcm1pbmVzXG5cdCogYGhhc05leHRQYWdlYC5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCB7IGhhc05leHRQYWdlIH0gPSBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KClcblx0KlxuXHQqIGlmIChoYXNOZXh0UGFnZSkge1xuXHQqICAgYXdhaXQgb2JzZXJ2ZXIuZmV0Y2hOZXh0UGFnZSgpXG5cdCogfVxuXHQqIGBgYFxuXHQqXG5cdCogQHNlZSB7QGxpbmsgSW5maW5pdGVRdWVyeU9ic2VydmVyI2ZldGNoUHJldmlvdXNQYWdlfVxuXHQqL1xuXHRmZXRjaE5leHRQYWdlKG9wdGlvbnMpIHtcblx0XHRyZXR1cm4gdGhpcy5mZXRjaCh7XG5cdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0bWV0YTogeyBmZXRjaE1vcmU6IHsgZGlyZWN0aW9uOiBcImZvcndhcmRcIiB9IH1cblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIHRoZSBwcmV2aW91cyBwYWdlIG9mIHRoZSBpbmZpbml0ZSBxdWVyeSBhbmQgcmV0dXJucyBhIHByb21pc2Vcblx0KiB0aGF0IHJlc29sdmVzIHdpdGggdGhlIHJlc3VsdGluZyBgSW5maW5pdGVRdWVyeU9ic2VydmVyUmVzdWx0YC4gVGhlIHBhZ2Vcblx0KiBwYXJhbSB1c2VkIGZvciB0aGUgZmV0Y2ggaXMgZGV0ZXJtaW5lZCBieSBgZ2V0UHJldmlvdXNQYWdlUGFyYW1gLCB3aGljaFxuXHQqIHJlY2VpdmVzIHRoZSBjdXJyZW50IHBhZ2VzL3BhZ2UgcGFyYW1zIGFuZCB3aG9zZSByZXN1bHQgYWxzbyBkZXRlcm1pbmVzXG5cdCogYGhhc1ByZXZpb3VzUGFnZWAuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgeyBoYXNQcmV2aW91c1BhZ2UgfSA9IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKVxuXHQqXG5cdCogaWYgKGhhc1ByZXZpb3VzUGFnZSkge1xuXHQqICAgYXdhaXQgb2JzZXJ2ZXIuZmV0Y2hQcmV2aW91c1BhZ2UoKVxuXHQqIH1cblx0KiBgYGBcblx0KlxuXHQqIEBzZWUge0BsaW5rIEluZmluaXRlUXVlcnlPYnNlcnZlciNmZXRjaE5leHRQYWdlfVxuXHQqL1xuXHRmZXRjaFByZXZpb3VzUGFnZShvcHRpb25zKSB7XG5cdFx0cmV0dXJuIHRoaXMuZmV0Y2goe1xuXHRcdFx0Li4ub3B0aW9ucyxcblx0XHRcdG1ldGE6IHsgZmV0Y2hNb3JlOiB7IGRpcmVjdGlvbjogXCJiYWNrd2FyZFwiIH0gfVxuXHRcdH0pO1xuXHR9XG5cdGNyZWF0ZVJlc3VsdChxdWVyeSwgb3B0aW9ucykge1xuXHRcdGNvbnN0IHsgc3RhdGUgfSA9IHF1ZXJ5O1xuXHRcdGNvbnN0IHBhcmVudFJlc3VsdCA9IHN1cGVyLmNyZWF0ZVJlc3VsdChxdWVyeSwgb3B0aW9ucyk7XG5cdFx0Y29uc3QgeyBpc0ZldGNoaW5nLCBpc1JlZmV0Y2hpbmcsIGlzRXJyb3IsIGlzUmVmZXRjaEVycm9yIH0gPSBwYXJlbnRSZXN1bHQ7XG5cdFx0Y29uc3QgZmV0Y2hEaXJlY3Rpb24gPSBzdGF0ZS5mZXRjaE1ldGE/LmZldGNoTW9yZT8uZGlyZWN0aW9uO1xuXHRcdGNvbnN0IGlzRmV0Y2hOZXh0UGFnZUVycm9yID0gaXNFcnJvciAmJiBmZXRjaERpcmVjdGlvbiA9PT0gXCJmb3J3YXJkXCI7XG5cdFx0Y29uc3QgaXNGZXRjaGluZ05leHRQYWdlID0gaXNGZXRjaGluZyAmJiBmZXRjaERpcmVjdGlvbiA9PT0gXCJmb3J3YXJkXCI7XG5cdFx0Y29uc3QgaXNGZXRjaFByZXZpb3VzUGFnZUVycm9yID0gaXNFcnJvciAmJiBmZXRjaERpcmVjdGlvbiA9PT0gXCJiYWNrd2FyZFwiO1xuXHRcdGNvbnN0IGlzRmV0Y2hpbmdQcmV2aW91c1BhZ2UgPSBpc0ZldGNoaW5nICYmIGZldGNoRGlyZWN0aW9uID09PSBcImJhY2t3YXJkXCI7XG5cdFx0cmV0dXJuIHtcblx0XHRcdC4uLnBhcmVudFJlc3VsdCxcblx0XHRcdGZldGNoTmV4dFBhZ2U6IHRoaXMuZmV0Y2hOZXh0UGFnZSxcblx0XHRcdGZldGNoUHJldmlvdXNQYWdlOiB0aGlzLmZldGNoUHJldmlvdXNQYWdlLFxuXHRcdFx0aGFzTmV4dFBhZ2U6IGhhc05leHRQYWdlKG9wdGlvbnMsIHN0YXRlLmRhdGEpLFxuXHRcdFx0aGFzUHJldmlvdXNQYWdlOiBoYXNQcmV2aW91c1BhZ2Uob3B0aW9ucywgc3RhdGUuZGF0YSksXG5cdFx0XHRpc0ZldGNoTmV4dFBhZ2VFcnJvcixcblx0XHRcdGlzRmV0Y2hpbmdOZXh0UGFnZSxcblx0XHRcdGlzRmV0Y2hQcmV2aW91c1BhZ2VFcnJvcixcblx0XHRcdGlzRmV0Y2hpbmdQcmV2aW91c1BhZ2UsXG5cdFx0XHRpc1JlZmV0Y2hFcnJvcjogaXNSZWZldGNoRXJyb3IgJiYgIWlzRmV0Y2hOZXh0UGFnZUVycm9yICYmICFpc0ZldGNoUHJldmlvdXNQYWdlRXJyb3IsXG5cdFx0XHRpc1JlZmV0Y2hpbmc6IGlzUmVmZXRjaGluZyAmJiAhaXNGZXRjaGluZ05leHRQYWdlICYmICFpc0ZldGNoaW5nUHJldmlvdXNQYWdlXG5cdFx0fTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgSW5maW5pdGVRdWVyeU9ic2VydmVyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZmluaXRlUXVlcnlPYnNlcnZlci5qcy5tYXAiLCJpbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgY3JlYXRlUmV0cnllciB9IGZyb20gXCIuL3JldHJ5ZXIuanNcIjtcbmltcG9ydCB7IFJlbW92YWJsZSB9IGZyb20gXCIuL3JlbW92YWJsZS5qc1wiO1xuLy8jcmVnaW9uIHNyYy9tdXRhdGlvbi50c1xuLyoqXG4qIFJlcHJlc2VudHMgYSBzaW5nbGUgbXV0YXRpb24gYXR0ZW1wdC4gQSBgTXV0YXRpb25gIGhvbGRzIHRoZSBtdXRhdGlvbidzXG4qIG9wdGlvbnMsIHN0YXRlIChkYXRhL2Vycm9yL3N0YXR1cyksIGFuZCB0aGUgYE11dGF0aW9uT2JzZXJ2ZXJgcyBjdXJyZW50bHlcbiogc3Vic2NyaWJlZCB0byBpdC5cbipcbiogSW5zdGFuY2VzIGFyZSBjcmVhdGVkIGFuZCBtYW5hZ2VkIGludGVybmFsbHkgYnkgYE11dGF0aW9uQ2FjaGVgOyBhcHBsaWNhdGlvblxuKiBjb2RlIHR5cGljYWxseSBpbnRlcmFjdHMgd2l0aCBtdXRhdGlvbnMgaW5kaXJlY3RseSB0aHJvdWdoIGBRdWVyeUNsaWVudGAgb3JcbiogYSBmcmFtZXdvcmsgaG9vayBsaWtlIGB1c2VNdXRhdGlvbmAuIERpcmVjdCBhY2Nlc3MgdG8gYSBgTXV0YXRpb25gIGluc3RhbmNlXG4qIGlzIHBvc3NpYmxlIHZpYSBgbXV0YXRpb25DYWNoZS5maW5kKClgL2BnZXRBbGwoKWAgZm9yIGluc3BlY3RpbmcgY2FjaGUgc3RhdGUuXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IG11dGF0aW9uQ2FjaGUgPSBxdWVyeUNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKClcbipcbiogY29uc3QgbXV0YXRpb24gPSBtdXRhdGlvbkNhY2hlLmZpbmQoeyBtdXRhdGlvbktleTogWydhZGRQb3N0J10gfSlcbiogYGBgXG4qL1xudmFyIE11dGF0aW9uID0gY2xhc3MgZXh0ZW5kcyBSZW1vdmFibGUge1xuXHQjY2xpZW50O1xuXHQjb2JzZXJ2ZXJzO1xuXHQjbXV0YXRpb25DYWNoZTtcblx0I3JldHJ5ZXI7XG5cdGNvbnN0cnVjdG9yKGNvbmZpZykge1xuXHRcdHN1cGVyKCk7XG5cdFx0dGhpcy4jY2xpZW50ID0gY29uZmlnLmNsaWVudDtcblx0XHR0aGlzLm11dGF0aW9uSWQgPSBjb25maWcubXV0YXRpb25JZDtcblx0XHR0aGlzLiNtdXRhdGlvbkNhY2hlID0gY29uZmlnLm11dGF0aW9uQ2FjaGU7XG5cdFx0dGhpcy4jb2JzZXJ2ZXJzID0gW107XG5cdFx0dGhpcy5zdGF0ZSA9IGNvbmZpZy5zdGF0ZSB8fCBnZXREZWZhdWx0U3RhdGUoKTtcblx0XHR0aGlzLnNldE9wdGlvbnMoY29uZmlnLm9wdGlvbnMpO1xuXHRcdHRoaXMuc2NoZWR1bGVHYygpO1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0c2V0T3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0dGhpcy5vcHRpb25zID0gb3B0aW9ucztcblx0XHR0aGlzLnVwZGF0ZUdjVGltZSh0aGlzLm9wdGlvbnMuZ2NUaW1lKTtcblx0fVxuXHQvKipcblx0KiBUaGUgYG1ldGFgIG9iamVjdCBwYXNzZWQgaW4gdGhlIG11dGF0aW9uJ3Mgb3B0aW9ucywgaWYgYW55LlxuXHQqL1xuXHRnZXQgbWV0YSgpIHtcblx0XHRyZXR1cm4gdGhpcy5vcHRpb25zLm1ldGE7XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRhZGRPYnNlcnZlcihvYnNlcnZlcikge1xuXHRcdGlmICghdGhpcy4jb2JzZXJ2ZXJzLmluY2x1ZGVzKG9ic2VydmVyKSkge1xuXHRcdFx0dGhpcy4jb2JzZXJ2ZXJzLnB1c2gob2JzZXJ2ZXIpO1xuXHRcdFx0dGhpcy5jbGVhckdjVGltZW91dCgpO1xuXHRcdFx0dGhpcy4jbXV0YXRpb25DYWNoZS5ub3RpZnkoe1xuXHRcdFx0XHR0eXBlOiBcIm9ic2VydmVyQWRkZWRcIixcblx0XHRcdFx0bXV0YXRpb246IHRoaXMsXG5cdFx0XHRcdG9ic2VydmVyXG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRyZW1vdmVPYnNlcnZlcihvYnNlcnZlcikge1xuXHRcdHRoaXMuI29ic2VydmVycyA9IHRoaXMuI29ic2VydmVycy5maWx0ZXIoKHgpID0+IHggIT09IG9ic2VydmVyKTtcblx0XHR0aGlzLnNjaGVkdWxlR2MoKTtcblx0XHR0aGlzLiNtdXRhdGlvbkNhY2hlLm5vdGlmeSh7XG5cdFx0XHR0eXBlOiBcIm9ic2VydmVyUmVtb3ZlZFwiLFxuXHRcdFx0bXV0YXRpb246IHRoaXMsXG5cdFx0XHRvYnNlcnZlclxuXHRcdH0pO1xuXHR9XG5cdG9wdGlvbmFsUmVtb3ZlKCkge1xuXHRcdGlmICghdGhpcy4jb2JzZXJ2ZXJzLmxlbmd0aCkge1xuXHRcdFx0aWYgKHRoaXMuc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIikgdGhpcy5zY2hlZHVsZUdjKCk7XG5cdFx0XHRlbHNlIHRoaXMuI211dGF0aW9uQ2FjaGUucmVtb3ZlKHRoaXMpO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBSZXN1bWVzIGEgbXV0YXRpb24gdGhhdCBpcyBjdXJyZW50bHkgcGF1c2VkIG9yIHdhcyByZXN0b3JlZCBmcm9tIGFcblx0KiBkZWh5ZHJhdGVkLCBzdGlsbC1gcGVuZGluZ2Agc3RhdGUuXG5cdCpcblx0KiAtIElmIHRoaXMgbXV0YXRpb24gaGFzIGFuIGFjdGl2ZSByZXRyeWVyIChpdCBwYXVzZWQgbWlkLWF0dGVtcHQsIGUuZy4gZHVlXG5cdCogICB0byB0aGUgbmV0d29yayBtb2RlIG9yIHNjb3BlLWJhc2VkIHF1ZXVpbmcpLCBpdHMgcmV0cnllciBpcyByZXN1bWVkLlxuXHQqIC0gT3RoZXJ3aXNlLCBpZiB0aGUgbXV0YXRpb24ncyBzdGF0dXMgaXMgc3RpbGwgYHBlbmRpbmdgIChlLmcuIGl0IHdhc1xuXHQqICAgZGVoeWRyYXRlZCB3aGlsZSBhbiBhdHRlbXB0IHdhcyBpbiBmbGlnaHQgYW5kIG5ldmVyIGdvdCBhIHJldHJ5ZXIgaW5cblx0KiAgIHRoaXMgaW5zdGFuY2UpLCBgZXhlY3V0ZWAgaXMgY2FsbGVkIGFnYWluIHdpdGggdGhlIGxhc3Qga25vd24gdmFyaWFibGVzLlxuXHQqIC0gT3RoZXJ3aXNlIHRoZSBtdXRhdGlvbiBoYXMgYWxyZWFkeSBzZXR0bGVkIGFuZCB0aGlzIHJlc29sdmVzIGltbWVkaWF0ZWx5XG5cdCogICB3aXRob3V0IHJ1bm5pbmcgYW55dGhpbmcgYWdhaW4uXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogLy8gdHlwaWNhbGx5IGRyaXZlbiBieSByZWNvbm5lY3QgaGFuZGxpbmcsIGUuZy4gcXVlcnlDbGllbnQucmVzdW1lUGF1c2VkTXV0YXRpb25zKClcblx0KiBjb25zdCBtdXRhdGlvbiA9IG11dGF0aW9uQ2FjaGUuZmluZCh7IG11dGF0aW9uS2V5OiBbJ2FkZFBvc3QnXSB9KVxuXHQqIGF3YWl0IG11dGF0aW9uPy5jb250aW51ZSgpXG5cdCogYGBgXG5cdCpcblx0KiBAc2VlIHtAbGluayBNdXRhdGlvbiNleGVjdXRlfVxuXHQqL1xuXHRjb250aW51ZSgpIHtcblx0XHRyZXR1cm4gdGhpcy4jcmV0cnllcj8uY29udGludWUoKSA/PyAodGhpcy5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiID8gdGhpcy5leGVjdXRlKHRoaXMuc3RhdGUudmFyaWFibGVzKSA6IFByb21pc2UucmVzb2x2ZSgpKTtcblx0fVxuXHQvKipcblx0KiBSdW5zIHRoZSBtdXRhdGlvbiBmdW5jdGlvbiBmb3IgdGhlIGdpdmVuIHZhcmlhYmxlcyB0aHJvdWdoIGEgcmV0cnllciwgYW5kXG5cdCogZHJpdmVzIHRoZSBtdXRhdGlvbidzIHN0YXRlIGFuZCBsaWZlY3ljbGUgY2FsbGJhY2tzIHRocm91Z2ggdG8gc2V0dGxlbWVudC5cblx0KlxuXHQqIElmIHRoaXMgbXV0YXRpb24ncyBzdGF0ZSBpcyBhbHJlYWR5IGBwZW5kaW5nYCB3aGVuIGBleGVjdXRlYCBpcyBjYWxsZWRcblx0KiAoaS5lLiBpdCB3YXMgcmVzdG9yZWQsIHN0aWxsIGluLWZsaWdodCwgZnJvbSBhIGRlaHlkcmF0ZWQgc3RhdGUpLCB0aGVcblx0KiBgb25NdXRhdGVgIHN0ZXAgaXMgc2tpcHBlZCBhbmQgYSBgY29udGludWVgIGFjdGlvbiBpcyBkaXNwYXRjaGVkIHRvXG5cdCogdW5wYXVzZSBpdDsgb3RoZXJ3aXNlIGEgYHBlbmRpbmdgIGFjdGlvbiBpcyBkaXNwYXRjaGVkIGZpcnN0LCB0aGVuIHRoZVxuXHQqIG11dGF0aW9uIGNhY2hlJ3MgYG9uTXV0YXRlYCBhbmQgdGhlIG11dGF0aW9uJ3Mgb3duIGBvbk11dGF0ZWAgb3B0aW9uIGFyZVxuXHQqIGF3YWl0ZWQgaW4gdGhhdCBvcmRlciwgYW5kIHRoZSByZXN1bHRpbmcgY29udGV4dCBpcyBzdG9yZWQuXG5cdCpcblx0KiBUaGUgbXV0YXRpb24gZnVuY3Rpb24gaXMgdGhlbiBydW4gKHN1YmplY3QgdG8gYHJldHJ5YC9gcmV0cnlEZWxheWAvXG5cdCogYG5ldHdvcmtNb2RlYCwgYW5kIHRvIHRoZSBtdXRhdGlvbiBjYWNoZSdzIHNjb3BlLWJhc2VkIHNlcmlhbGl6YXRpb24pLlxuXHQqIE9uIHN1Y2Nlc3MsIHRoZSBjYWNoZSdzIGBvblN1Y2Nlc3NgL2BvblNldHRsZWRgIGNhbGxiYWNrcyBydW4gYmVmb3JlIHRoZVxuXHQqIG11dGF0aW9uJ3Mgb3duIGBvblN1Y2Nlc3NgL2BvblNldHRsZWRgIG9wdGlvbnMsIGEgYHN1Y2Nlc3NgIGFjdGlvbiBpc1xuXHQqIGRpc3BhdGNoZWQsIGFuZCB0aGUgcmVzb2x2ZWQgZGF0YSBpcyByZXR1cm5lZC4gT24gZmFpbHVyZSwgdGhlIHNhbWVcblx0KiBjYWNoZS10aGVuLW9wdGlvbiBvcmRlcmluZyBpcyB1c2VkIGZvciBgb25FcnJvcmAvYG9uU2V0dGxlZGAsIGJ1dCBlYWNoIG9mXG5cdCogdGhvc2UgZm91ciBjYWxsYmFja3MgaXMgaW5kaXZpZHVhbGx5IGNhdWdodCBzbyB0aGF0IGEgdGhyb3dpbmcgY2FsbGJhY2tcblx0KiBjYW5ub3QgbWFzayB0aGUgb3JpZ2luYWwgZXJyb3I7IGFuIGBlcnJvcmAgYWN0aW9uIGlzIHRoZW4gZGlzcGF0Y2hlZCBhbmRcblx0KiB0aGUgb3JpZ2luYWwgZXJyb3IgaXMgcmUtdGhyb3duLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIC8vIENhbGxlZCBpbnRlcm5hbGx5IGJ5IGBNdXRhdGlvbk9ic2VydmVyLm11dGF0ZWAgYW5kIGBNdXRhdGlvbi5jb250aW51ZWAg4oCUXG5cdCogLy8gYXBwbGljYXRpb25zIG5vcm1hbGx5IHRyaWdnZXIgbXV0YXRpb25zIHRocm91Z2ggdGhvc2UsIG5vdCB0aGlzIG1ldGhvZC5cblx0KiBjb25zdCBkYXRhID0gYXdhaXQgbXV0YXRpb24uZXhlY3V0ZSh2YXJpYWJsZXMpXG5cdCogYGBgXG5cdCpcblx0KiBAc2VlIHtAbGluayBNdXRhdGlvbiNjb250aW51ZX1cblx0Ki9cblx0YXN5bmMgZXhlY3V0ZSh2YXJpYWJsZXMpIHtcblx0XHRjb25zdCBvbkNvbnRpbnVlID0gKCkgPT4ge1xuXHRcdFx0dGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcImNvbnRpbnVlXCIgfSk7XG5cdFx0fTtcblx0XHRjb25zdCBtdXRhdGlvbkZuQ29udGV4dCA9IHtcblx0XHRcdGNsaWVudDogdGhpcy4jY2xpZW50LFxuXHRcdFx0bWV0YTogdGhpcy5vcHRpb25zLm1ldGEsXG5cdFx0XHRtdXRhdGlvbktleTogdGhpcy5vcHRpb25zLm11dGF0aW9uS2V5XG5cdFx0fTtcblx0XHRjb25zdCByZXRyeWVyID0gdGhpcy4jcmV0cnllciA9IGNyZWF0ZVJldHJ5ZXIoe1xuXHRcdFx0Zm46ICgpID0+IHtcblx0XHRcdFx0aWYgKCF0aGlzLm9wdGlvbnMubXV0YXRpb25GbikgcmV0dXJuIFByb21pc2UucmVqZWN0KC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoXCJObyBtdXRhdGlvbkZuIGZvdW5kXCIpKTtcblx0XHRcdFx0cmV0dXJuIHRoaXMub3B0aW9ucy5tdXRhdGlvbkZuKHZhcmlhYmxlcywgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0fSxcblx0XHRcdG9uRmFpbDogKGZhaWx1cmVDb3VudCwgZXJyb3IpID0+IHtcblx0XHRcdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0XHRcdHR5cGU6IFwiZmFpbGVkXCIsXG5cdFx0XHRcdFx0ZmFpbHVyZUNvdW50LFxuXHRcdFx0XHRcdGVycm9yXG5cdFx0XHRcdH0pO1xuXHRcdFx0fSxcblx0XHRcdG9uUGF1c2U6ICgpID0+IHtcblx0XHRcdFx0dGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcInBhdXNlXCIgfSk7XG5cdFx0XHR9LFxuXHRcdFx0b25Db250aW51ZSxcblx0XHRcdHJldHJ5OiB0aGlzLm9wdGlvbnMucmV0cnkgPz8gMCxcblx0XHRcdHJldHJ5RGVsYXk6IHRoaXMub3B0aW9ucy5yZXRyeURlbGF5LFxuXHRcdFx0bmV0d29ya01vZGU6IHRoaXMub3B0aW9ucy5uZXR3b3JrTW9kZSxcblx0XHRcdGNhblJ1bjogKCkgPT4gdGhpcy4jbXV0YXRpb25DYWNoZS5jYW5SdW4odGhpcylcblx0XHR9KTtcblx0XHRjb25zdCByZXN0b3JlZCA9IHRoaXMuc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIjtcblx0XHRjb25zdCBpc1BhdXNlZCA9ICFyZXRyeWVyLmNhblN0YXJ0KCk7XG5cdFx0dHJ5IHtcblx0XHRcdGlmIChyZXN0b3JlZCkgb25Db250aW51ZSgpO1xuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdHRoaXMuI2Rpc3BhdGNoKHtcblx0XHRcdFx0XHR0eXBlOiBcInBlbmRpbmdcIixcblx0XHRcdFx0XHR2YXJpYWJsZXMsXG5cdFx0XHRcdFx0aXNQYXVzZWRcblx0XHRcdFx0fSk7XG5cdFx0XHRcdGlmICh0aGlzLiNtdXRhdGlvbkNhY2hlLmNvbmZpZy5vbk11dGF0ZSkgYXdhaXQgdGhpcy4jbXV0YXRpb25DYWNoZS5jb25maWcub25NdXRhdGUodmFyaWFibGVzLCB0aGlzLCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHRcdGNvbnN0IGNvbnRleHQgPSBhd2FpdCB0aGlzLm9wdGlvbnMub25NdXRhdGU/Lih2YXJpYWJsZXMsIG11dGF0aW9uRm5Db250ZXh0KTtcblx0XHRcdFx0aWYgKGNvbnRleHQgIT09IHRoaXMuc3RhdGUuY29udGV4dCkgdGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0XHRcdHR5cGU6IFwicGVuZGluZ1wiLFxuXHRcdFx0XHRcdGNvbnRleHQsXG5cdFx0XHRcdFx0dmFyaWFibGVzLFxuXHRcdFx0XHRcdGlzUGF1c2VkXG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgZGF0YSA9IGF3YWl0IHJldHJ5ZXIuc3RhcnQoKTtcblx0XHRcdGF3YWl0IHRoaXMuI211dGF0aW9uQ2FjaGUuY29uZmlnLm9uU3VjY2Vzcz8uKGRhdGEsIHZhcmlhYmxlcywgdGhpcy5zdGF0ZS5jb250ZXh0LCB0aGlzLCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHRhd2FpdCB0aGlzLm9wdGlvbnMub25TdWNjZXNzPy4oZGF0YSwgdmFyaWFibGVzLCB0aGlzLnN0YXRlLmNvbnRleHQsIG11dGF0aW9uRm5Db250ZXh0KTtcblx0XHRcdGF3YWl0IHRoaXMuI211dGF0aW9uQ2FjaGUuY29uZmlnLm9uU2V0dGxlZD8uKGRhdGEsIG51bGwsIHRoaXMuc3RhdGUudmFyaWFibGVzLCB0aGlzLnN0YXRlLmNvbnRleHQsIHRoaXMsIG11dGF0aW9uRm5Db250ZXh0KTtcblx0XHRcdGF3YWl0IHRoaXMub3B0aW9ucy5vblNldHRsZWQ/LihkYXRhLCBudWxsLCB2YXJpYWJsZXMsIHRoaXMuc3RhdGUuY29udGV4dCwgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0XHR0eXBlOiBcInN1Y2Nlc3NcIixcblx0XHRcdFx0ZGF0YVxuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gZGF0YTtcblx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgdGhpcy4jbXV0YXRpb25DYWNoZS5jb25maWcub25FcnJvcj8uKGVycm9yLCB2YXJpYWJsZXMsIHRoaXMuc3RhdGUuY29udGV4dCwgdGhpcywgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRQcm9taXNlLnJlamVjdChlKTtcblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGF3YWl0IHRoaXMub3B0aW9ucy5vbkVycm9yPy4oZXJyb3IsIHZhcmlhYmxlcywgdGhpcy5zdGF0ZS5jb250ZXh0LCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFByb21pc2UucmVqZWN0KGUpO1xuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgdGhpcy4jbXV0YXRpb25DYWNoZS5jb25maWcub25TZXR0bGVkPy4odm9pZCAwLCBlcnJvciwgdGhpcy5zdGF0ZS52YXJpYWJsZXMsIHRoaXMuc3RhdGUuY29udGV4dCwgdGhpcywgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRQcm9taXNlLnJlamVjdChlKTtcblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGF3YWl0IHRoaXMub3B0aW9ucy5vblNldHRsZWQ/Lih2b2lkIDAsIGVycm9yLCB2YXJpYWJsZXMsIHRoaXMuc3RhdGUuY29udGV4dCwgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRQcm9taXNlLnJlamVjdChlKTtcblx0XHRcdH1cblx0XHRcdHRoaXMuI2Rpc3BhdGNoKHtcblx0XHRcdFx0dHlwZTogXCJlcnJvclwiLFxuXHRcdFx0XHRlcnJvclxuXHRcdFx0fSk7XG5cdFx0XHR0aHJvdyBlcnJvcjtcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0aWYgKHRoaXMuI3JldHJ5ZXIgPT09IHJldHJ5ZXIpIHRoaXMuI3JldHJ5ZXIgPSB2b2lkIDA7XG5cdFx0XHR0aGlzLiNtdXRhdGlvbkNhY2hlLnJ1bk5leHQodGhpcyk7XG5cdFx0fVxuXHR9XG5cdCNkaXNwYXRjaChhY3Rpb24pIHtcblx0XHRjb25zdCByZWR1Y2VyID0gKHN0YXRlKSA9PiB7XG5cdFx0XHRzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XG5cdFx0XHRcdGNhc2UgXCJmYWlsZWRcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHRmYWlsdXJlQ291bnQ6IGFjdGlvbi5mYWlsdXJlQ291bnQsXG5cdFx0XHRcdFx0ZmFpbHVyZVJlYXNvbjogYWN0aW9uLmVycm9yXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJwYXVzZVwiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdGlzUGF1c2VkOiB0cnVlXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJjb250aW51ZVwiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdGlzUGF1c2VkOiBmYWxzZVxuXHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlIFwicGVuZGluZ1wiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdGNvbnRleHQ6IGFjdGlvbi5jb250ZXh0LFxuXHRcdFx0XHRcdGRhdGE6IHZvaWQgMCxcblx0XHRcdFx0XHRmYWlsdXJlQ291bnQ6IDAsXG5cdFx0XHRcdFx0ZmFpbHVyZVJlYXNvbjogbnVsbCxcblx0XHRcdFx0XHRlcnJvcjogbnVsbCxcblx0XHRcdFx0XHRpc1BhdXNlZDogYWN0aW9uLmlzUGF1c2VkLFxuXHRcdFx0XHRcdHN0YXR1czogXCJwZW5kaW5nXCIsXG5cdFx0XHRcdFx0dmFyaWFibGVzOiBhY3Rpb24udmFyaWFibGVzLFxuXHRcdFx0XHRcdHN1Ym1pdHRlZEF0OiBEYXRlLm5vdygpXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJzdWNjZXNzXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0ZGF0YTogYWN0aW9uLmRhdGEsXG5cdFx0XHRcdFx0ZmFpbHVyZUNvdW50OiAwLFxuXHRcdFx0XHRcdGZhaWx1cmVSZWFzb246IG51bGwsXG5cdFx0XHRcdFx0ZXJyb3I6IG51bGwsXG5cdFx0XHRcdFx0c3RhdHVzOiBcInN1Y2Nlc3NcIixcblx0XHRcdFx0XHRpc1BhdXNlZDogZmFsc2Vcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcImVycm9yXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0ZGF0YTogdm9pZCAwLFxuXHRcdFx0XHRcdGVycm9yOiBhY3Rpb24uZXJyb3IsXG5cdFx0XHRcdFx0ZmFpbHVyZUNvdW50OiBzdGF0ZS5mYWlsdXJlQ291bnQgKyAxLFxuXHRcdFx0XHRcdGZhaWx1cmVSZWFzb246IGFjdGlvbi5lcnJvcixcblx0XHRcdFx0XHRpc1BhdXNlZDogZmFsc2UsXG5cdFx0XHRcdFx0c3RhdHVzOiBcImVycm9yXCJcblx0XHRcdFx0fTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdHRoaXMuc3RhdGUgPSByZWR1Y2VyKHRoaXMuc3RhdGUpO1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0dGhpcy4jb2JzZXJ2ZXJzLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG5cdFx0XHRcdG9ic2VydmVyLm9uTXV0YXRpb25VcGRhdGUoYWN0aW9uKTtcblx0XHRcdH0pO1xuXHRcdFx0dGhpcy4jbXV0YXRpb25DYWNoZS5ub3RpZnkoe1xuXHRcdFx0XHRtdXRhdGlvbjogdGhpcyxcblx0XHRcdFx0dHlwZTogXCJ1cGRhdGVkXCIsXG5cdFx0XHRcdGFjdGlvblxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cbn07XG5mdW5jdGlvbiBnZXREZWZhdWx0U3RhdGUoKSB7XG5cdHJldHVybiB7XG5cdFx0Y29udGV4dDogdm9pZCAwLFxuXHRcdGRhdGE6IHZvaWQgMCxcblx0XHRlcnJvcjogbnVsbCxcblx0XHRmYWlsdXJlQ291bnQ6IDAsXG5cdFx0ZmFpbHVyZVJlYXNvbjogbnVsbCxcblx0XHRpc1BhdXNlZDogZmFsc2UsXG5cdFx0c3RhdHVzOiBcImlkbGVcIixcblx0XHR2YXJpYWJsZXM6IHZvaWQgMCxcblx0XHRzdWJtaXR0ZWRBdDogMFxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBNdXRhdGlvbiwgZ2V0RGVmYXVsdFN0YXRlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW11dGF0aW9uLmpzLm1hcCIsImltcG9ydCB7IG1hdGNoTXV0YXRpb24sIG5vb3AgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgTXV0YXRpb24gfSBmcm9tIFwiLi9tdXRhdGlvbi5qc1wiO1xuLy8jcmVnaW9uIHNyYy9tdXRhdGlvbkNhY2hlLnRzXG4vKipcbiogVGhlIGBNdXRhdGlvbkNhY2hlYCBpcyB0aGUgc3RvcmFnZSBmb3IgbXV0YXRpb25zLlxuKlxuKiBOb3JtYWxseSwgeW91IHdpbGwgbm90IGludGVyYWN0IHdpdGggdGhlIGBNdXRhdGlvbkNhY2hlYCBkaXJlY3RseSBhbmQgaW5zdGVhZCB1c2UgYVxuKiBgUXVlcnlDbGllbnRgLiBZb3UgY2FuIHN1YnNjcmliZSB0byBpdCAoaW5oZXJpdGVkIGZyb20gYFN1YnNjcmliYWJsZWApIHRvIGJlIGluZm9ybWVkIG9mXG4qIHNhZmUva25vd24gdXBkYXRlcyB0byB0aGUgY2FjaGUsIHN1Y2ggYXMgbXV0YXRpb25zIGJlaW5nIGFkZGVkLCByZW1vdmVkLCBvciB1cGRhdGVkLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCB1bnN1YnNjcmliZSA9IG11dGF0aW9uQ2FjaGUuc3Vic2NyaWJlKChldmVudCkgPT4ge1xuKiAgIGNvbnNvbGUubG9nKGV2ZW50LnR5cGUsIGV2ZW50Lm11dGF0aW9uKVxuKiB9KVxuKiBgYGBcbiovXG52YXIgTXV0YXRpb25DYWNoZSA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcblx0I211dGF0aW9ucztcblx0I3Njb3Blcztcblx0I211dGF0aW9uSWQ7XG5cdGNvbnN0cnVjdG9yKGNvbmZpZyA9IHt9KSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZztcblx0XHR0aGlzLiNtdXRhdGlvbnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdHRoaXMuI3Njb3BlcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0dGhpcy4jbXV0YXRpb25JZCA9IDA7XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRidWlsZChjbGllbnQsIG9wdGlvbnMsIHN0YXRlKSB7XG5cdFx0Y29uc3QgbXV0YXRpb24gPSBuZXcgTXV0YXRpb24oe1xuXHRcdFx0Y2xpZW50LFxuXHRcdFx0bXV0YXRpb25DYWNoZTogdGhpcyxcblx0XHRcdG11dGF0aW9uSWQ6ICsrdGhpcy4jbXV0YXRpb25JZCxcblx0XHRcdG9wdGlvbnM6IGNsaWVudC5kZWZhdWx0TXV0YXRpb25PcHRpb25zKG9wdGlvbnMpLFxuXHRcdFx0c3RhdGVcblx0XHR9KTtcblx0XHR0aGlzLmFkZChtdXRhdGlvbik7XG5cdFx0cmV0dXJuIG11dGF0aW9uO1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0YWRkKG11dGF0aW9uKSB7XG5cdFx0dGhpcy4jbXV0YXRpb25zLmFkZChtdXRhdGlvbik7XG5cdFx0Y29uc3Qgc2NvcGUgPSBzY29wZUZvcihtdXRhdGlvbik7XG5cdFx0aWYgKHR5cGVvZiBzY29wZSA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0Y29uc3Qgc2NvcGVkTXV0YXRpb25zID0gdGhpcy4jc2NvcGVzLmdldChzY29wZSk7XG5cdFx0XHRpZiAoc2NvcGVkTXV0YXRpb25zKSBzY29wZWRNdXRhdGlvbnMucHVzaChtdXRhdGlvbik7XG5cdFx0XHRlbHNlIHRoaXMuI3Njb3Blcy5zZXQoc2NvcGUsIFttdXRhdGlvbl0pO1xuXHRcdH1cblx0XHR0aGlzLm5vdGlmeSh7XG5cdFx0XHR0eXBlOiBcImFkZGVkXCIsXG5cdFx0XHRtdXRhdGlvblxuXHRcdH0pO1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0cmVtb3ZlKG11dGF0aW9uKSB7XG5cdFx0aWYgKHRoaXMuI211dGF0aW9ucy5kZWxldGUobXV0YXRpb24pKSB7XG5cdFx0XHRjb25zdCBzY29wZSA9IHNjb3BlRm9yKG11dGF0aW9uKTtcblx0XHRcdGlmICh0eXBlb2Ygc2NvcGUgPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdFx0Y29uc3Qgc2NvcGVkTXV0YXRpb25zID0gdGhpcy4jc2NvcGVzLmdldChzY29wZSk7XG5cdFx0XHRcdGlmIChzY29wZWRNdXRhdGlvbnMpIHtcblx0XHRcdFx0XHRpZiAoc2NvcGVkTXV0YXRpb25zLmxlbmd0aCA+IDEpIHtcblx0XHRcdFx0XHRcdGNvbnN0IGluZGV4ID0gc2NvcGVkTXV0YXRpb25zLmluZGV4T2YobXV0YXRpb24pO1xuXHRcdFx0XHRcdFx0aWYgKGluZGV4ICE9PSAtMSkgc2NvcGVkTXV0YXRpb25zLnNwbGljZShpbmRleCwgMSk7XG5cdFx0XHRcdFx0fSBlbHNlIGlmIChzY29wZWRNdXRhdGlvbnNbMF0gPT09IG11dGF0aW9uKSB0aGlzLiNzY29wZXMuZGVsZXRlKHNjb3BlKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0XHR0aGlzLm5vdGlmeSh7XG5cdFx0XHR0eXBlOiBcInJlbW92ZWRcIixcblx0XHRcdG11dGF0aW9uXG5cdFx0fSk7XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRjYW5SdW4obXV0YXRpb24pIHtcblx0XHRjb25zdCBzY29wZSA9IHNjb3BlRm9yKG11dGF0aW9uKTtcblx0XHRpZiAodHlwZW9mIHNjb3BlID09PSBcInN0cmluZ1wiKSB7XG5cdFx0XHRjb25zdCBmaXJzdFBlbmRpbmdNdXRhdGlvbiA9IHRoaXMuI3Njb3Blcy5nZXQoc2NvcGUpPy5maW5kKChtKSA9PiBtLnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIpO1xuXHRcdFx0cmV0dXJuICFmaXJzdFBlbmRpbmdNdXRhdGlvbiB8fCBmaXJzdFBlbmRpbmdNdXRhdGlvbiA9PT0gbXV0YXRpb247XG5cdFx0fSBlbHNlIHJldHVybiB0cnVlO1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0cnVuTmV4dChtdXRhdGlvbikge1xuXHRcdGNvbnN0IHNjb3BlID0gc2NvcGVGb3IobXV0YXRpb24pO1xuXHRcdGlmICh0eXBlb2Ygc2NvcGUgPT09IFwic3RyaW5nXCIpIHJldHVybiAodGhpcy4jc2NvcGVzLmdldChzY29wZSk/LmZpbmQoKG0pID0+IG0gIT09IG11dGF0aW9uICYmIG0uc3RhdGUuaXNQYXVzZWQpKT8uY29udGludWUoKSA/PyBQcm9taXNlLnJlc29sdmUoKTtcblx0XHRlbHNlIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcblx0fVxuXHQvKipcblx0KiBSZW1vdmVzIGFsbCBtdXRhdGlvbnMgZnJvbSB0aGUgY2FjaGUuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgbXV0YXRpb25DYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKVxuXHQqXG5cdCogbXV0YXRpb25DYWNoZS5jbGVhcigpXG5cdCogYGBgXG5cdCovXG5cdGNsZWFyKCkge1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0dGhpcy4jbXV0YXRpb25zLmZvckVhY2goKG11dGF0aW9uKSA9PiB7XG5cdFx0XHRcdHRoaXMubm90aWZ5KHtcblx0XHRcdFx0XHR0eXBlOiBcInJlbW92ZWRcIixcblx0XHRcdFx0XHRtdXRhdGlvblxuXHRcdFx0XHR9KTtcblx0XHRcdH0pO1xuXHRcdFx0dGhpcy4jbXV0YXRpb25zLmNsZWFyKCk7XG5cdFx0XHR0aGlzLiNzY29wZXMuY2xlYXIoKTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIGFsbCBtdXRhdGlvbnMgd2l0aGluIHRoZSBjYWNoZS5cblx0KlxuXHQqIFRoaXMgaXMgbm90IHR5cGljYWxseSBuZWVkZWQgZm9yIG1vc3QgYXBwbGljYXRpb25zLCBidXQgY2FuIGNvbWUgaW4gaGFuZHkgd2hlbiBuZWVkaW5nIG1vcmVcblx0KiBpbmZvcm1hdGlvbiBhYm91dCBhIG11dGF0aW9uIGluIHJhcmUgc2NlbmFyaW9zLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IG11dGF0aW9uQ2FjaGUgPSBxdWVyeUNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKClcblx0KlxuXHQqIGNvbnN0IG11dGF0aW9ucyA9IG11dGF0aW9uQ2FjaGUuZ2V0QWxsKClcblx0KiBgYGBcblx0Ki9cblx0Z2V0QWxsKCkge1xuXHRcdHJldHVybiBBcnJheS5mcm9tKHRoaXMuI211dGF0aW9ucyk7XG5cdH1cblx0LyoqXG5cdCogQSBzbGlnaHRseSBtb3JlIGFkdmFuY2VkIG1ldGhvZCB0aGF0IGNhbiBiZSB1c2VkIHRvIGdldCBhbiBleGlzdGluZyBtdXRhdGlvbiBpbnN0YW5jZSBmcm9tXG5cdCogdGhlIGNhY2hlLiBJZiB0aGUgbXV0YXRpb24gZG9lcyBub3QgZXhpc3QsIGB1bmRlZmluZWRgIGlzIHJldHVybmVkLlxuXHQqXG5cdCogVGhpcyBpcyBub3QgdHlwaWNhbGx5IG5lZWRlZCBmb3IgbW9zdCBhcHBsaWNhdGlvbnMsIGJ1dCBjYW4gY29tZSBpbiBoYW5keSB3aGVuIG5lZWRpbmcgbW9yZVxuXHQqIGluZm9ybWF0aW9uIGFib3V0IGEgbXV0YXRpb24gaW4gcmFyZSBzY2VuYXJpb3MuXG5cdCpcblx0KiBAc2VlIHtAbGluayBNdXRhdGlvbkNhY2hlI2ZpbmRBbGx9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IG11dGF0aW9uQ2FjaGUgPSBxdWVyeUNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKClcblx0KlxuXHQqIGNvbnN0IG11dGF0aW9uID0gbXV0YXRpb25DYWNoZS5maW5kKHsgbXV0YXRpb25LZXk6IFsnYWRkUG9zdCddIH0pXG5cdCogYGBgXG5cdCovXG5cdGZpbmQoZmlsdGVycykge1xuXHRcdGNvbnN0IGRlZmF1bHRlZEZpbHRlcnMgPSB7XG5cdFx0XHRleGFjdDogdHJ1ZSxcblx0XHRcdC4uLmZpbHRlcnNcblx0XHR9O1xuXHRcdHJldHVybiB0aGlzLmdldEFsbCgpLmZpbmQoKG11dGF0aW9uKSA9PiBtYXRjaE11dGF0aW9uKGRlZmF1bHRlZEZpbHRlcnMsIG11dGF0aW9uKSk7XG5cdH1cblx0LyoqXG5cdCogQW4gZXZlbiBtb3JlIGFkdmFuY2VkIG1ldGhvZCB0aGF0IGNhbiBiZSB1c2VkIHRvIGdldCBleGlzdGluZyBtdXRhdGlvbiBpbnN0YW5jZXMgZnJvbSB0aGVcblx0KiBjYWNoZSB0aGF0IG1hdGNoIHRoZSBnaXZlbiBmaWx0ZXJzLiBJZiBubyBtdXRhdGlvbnMgbWF0Y2gsIGFuIGVtcHR5IGFycmF5IGlzIHJldHVybmVkLlxuXHQqXG5cdCogVGhpcyBpcyBub3QgdHlwaWNhbGx5IG5lZWRlZCBmb3IgbW9zdCBhcHBsaWNhdGlvbnMsIGJ1dCBjYW4gY29tZSBpbiBoYW5keSB3aGVuIG5lZWRpbmcgbW9yZVxuXHQqIGluZm9ybWF0aW9uIGFib3V0IG11dGF0aW9ucyBpbiByYXJlIHNjZW5hcmlvcy5cblx0KlxuXHQqIEBzZWUge0BsaW5rIE11dGF0aW9uQ2FjaGUjZmluZH1cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgbXV0YXRpb25DYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKVxuXHQqXG5cdCogY29uc3QgbXV0YXRpb25zID0gbXV0YXRpb25DYWNoZS5maW5kQWxsKHsgbXV0YXRpb25LZXk6IFsnYWRkUG9zdCddIH0pXG5cdCogYGBgXG5cdCovXG5cdGZpbmRBbGwoZmlsdGVycyA9IHt9KSB7XG5cdFx0cmV0dXJuIHRoaXMuZ2V0QWxsKCkuZmlsdGVyKChtdXRhdGlvbikgPT4gbWF0Y2hNdXRhdGlvbihmaWx0ZXJzLCBtdXRhdGlvbikpO1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0bm90aWZ5KGV2ZW50KSB7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHR0aGlzLmxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4ge1xuXHRcdFx0XHRsaXN0ZW5lcihldmVudCk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxuXHQvKiogQGludGVybmFsICovXG5cdHJlc3VtZVBhdXNlZE11dGF0aW9ucygpIHtcblx0XHRjb25zdCBwYXVzZWRNdXRhdGlvbnMgPSB0aGlzLmdldEFsbCgpLmZpbHRlcigoeCkgPT4geC5zdGF0ZS5pc1BhdXNlZCk7XG5cdFx0cmV0dXJuIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4gUHJvbWlzZS5hbGwocGF1c2VkTXV0YXRpb25zLm1hcCgobXV0YXRpb24pID0+IG11dGF0aW9uLmNvbnRpbnVlKCkuY2F0Y2gobm9vcCkpKSk7XG5cdH1cbn07XG5mdW5jdGlvbiBzY29wZUZvcihtdXRhdGlvbikge1xuXHRyZXR1cm4gbXV0YXRpb24ub3B0aW9ucy5zY29wZT8uaWQ7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IE11dGF0aW9uQ2FjaGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bXV0YXRpb25DYWNoZS5qcy5tYXAiLCJpbXBvcnQgeyBoYXNoS2V5LCBzaGFsbG93RXF1YWxPYmplY3RzIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IFN1YnNjcmliYWJsZSB9IGZyb20gXCIuL3N1YnNjcmliYWJsZS5qc1wiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCIuL25vdGlmeU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IGdldERlZmF1bHRTdGF0ZSB9IGZyb20gXCIuL211dGF0aW9uLmpzXCI7XG4vLyNyZWdpb24gc3JjL211dGF0aW9uT2JzZXJ2ZXIudHNcbi8qKlxuKiBPYnNlcnZlcyBhIHNpbmdsZSBtdXRhdGlvbiBhbmQgZGVyaXZlcyBhIGBNdXRhdGlvbk9ic2VydmVyUmVzdWx0YCBmcm9tIGl0LlxuKiBBIGZyYW1ld29yayBob29rIGxpa2UgYHVzZU11dGF0aW9uYCBjcmVhdGVzIG9uZSBgTXV0YXRpb25PYnNlcnZlcmAgcGVyIGhvb2tcbiogY2FsbCwga2VlcHMgaXQgc3RhYmxlIGFjcm9zcyByZS1yZW5kZXJzLCBjYWxscyBgc2V0T3B0aW9uc2Agd2hlbiB0aGUgb3B0aW9uc1xuKiBwYXNzZWQgdG8gdGhlIGhvb2sgY2hhbmdlLCBzdWJzY3JpYmVzIHRvIGl0IHRvIHJlLXJlbmRlciBvbiB1cGRhdGVzLCBhbmRcbiogcmVhZHMgYGdldEN1cnJlbnRSZXN1bHQoKWAgZm9yIHRoZSB2YWx1ZSB0byByZXR1cm4uIENhbGxpbmcgYG11dGF0ZSgpYFxuKiBidWlsZHMgYSBuZXcgdW5kZXJseWluZyBgTXV0YXRpb25gIGluIHRoZSBgTXV0YXRpb25DYWNoZWAgYW5kIGV4ZWN1dGVzIGl0LlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKHF1ZXJ5Q2xpZW50LCB7XG4qICAgbXV0YXRpb25GbjogKHZhcmlhYmxlczogeyB0aXRsZTogc3RyaW5nIH0pID0+IGFkZFBvc3QodmFyaWFibGVzKSxcbiogfSlcbiogYGBgXG4qL1xudmFyIE11dGF0aW9uT2JzZXJ2ZXIgPSBjbGFzcyBleHRlbmRzIFN1YnNjcmliYWJsZSB7XG5cdCNjbGllbnQ7XG5cdCNjdXJyZW50UmVzdWx0ID0gdm9pZCAwO1xuXHQjY3VycmVudE11dGF0aW9uO1xuXHQjbXV0YXRlT3B0aW9ucztcblx0Y29uc3RydWN0b3IoY2xpZW50LCBvcHRpb25zKSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLiNjbGllbnQgPSBjbGllbnQ7XG5cdFx0dGhpcy5zZXRPcHRpb25zKG9wdGlvbnMpO1xuXHRcdHRoaXMuYmluZE1ldGhvZHMoKTtcblx0XHR0aGlzLiN1cGRhdGVSZXN1bHQoKTtcblx0fVxuXHRiaW5kTWV0aG9kcygpIHtcblx0XHR0aGlzLm11dGF0ZSA9IHRoaXMubXV0YXRlLmJpbmQodGhpcyk7XG5cdFx0dGhpcy5yZXNldCA9IHRoaXMucmVzZXQuYmluZCh0aGlzKTtcblx0fVxuXHQvKipcblx0KiBVcGRhdGVzIHRoZSBvYnNlcnZlcidzIG9wdGlvbnMuXG5cdCpcblx0KiBJZiB0aGUgbmV3IGBtdXRhdGlvbktleWAgZGlmZmVycyBmcm9tIHRoZSBwcmV2aW91cyBvbmUgKGFuZCBib3RoIHdlcmVcblx0KiBkZWZpbmVkKSwgdGhlIG9ic2VydmVyIGlzIHJlc2V0LCBkZXRhY2hpbmcgaXQgZnJvbSB0aGUgbXV0YXRpb24gaXQgd2FzXG5cdCogb2JzZXJ2aW5nLiBPdGhlcndpc2UsIGlmIHRoZSBjdXJyZW50bHkgb2JzZXJ2ZWQgbXV0YXRpb24gaXMgc3RpbGxcblx0KiBgcGVuZGluZ2AsIGl0cyBvcHRpb25zIGFyZSB1cGRhdGVkIGluIHBsYWNlIGFzIHdlbGwuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogb2JzZXJ2ZXIuc2V0T3B0aW9ucyh7XG5cdCogICBtdXRhdGlvbkZuOiAodmFyaWFibGVzOiB7IHRpdGxlOiBzdHJpbmcgfSkgPT4gYWRkUG9zdCh2YXJpYWJsZXMpLFxuXHQqICAgb25TdWNjZXNzOiAoZGF0YSkgPT4gY29uc29sZS5sb2coZGF0YSksXG5cdCogfSlcblx0KiBgYGBcblx0Ki9cblx0c2V0T3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0Y29uc3QgcHJldk9wdGlvbnMgPSB0aGlzLm9wdGlvbnM7XG5cdFx0dGhpcy5vcHRpb25zID0gdGhpcy4jY2xpZW50LmRlZmF1bHRNdXRhdGlvbk9wdGlvbnMob3B0aW9ucyk7XG5cdFx0aWYgKCFzaGFsbG93RXF1YWxPYmplY3RzKHRoaXMub3B0aW9ucywgcHJldk9wdGlvbnMpKSB0aGlzLiNjbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpLm5vdGlmeSh7XG5cdFx0XHR0eXBlOiBcIm9ic2VydmVyT3B0aW9uc1VwZGF0ZWRcIixcblx0XHRcdG11dGF0aW9uOiB0aGlzLiNjdXJyZW50TXV0YXRpb24sXG5cdFx0XHRvYnNlcnZlcjogdGhpc1xuXHRcdH0pO1xuXHRcdGlmIChwcmV2T3B0aW9ucz8ubXV0YXRpb25LZXkgJiYgdGhpcy5vcHRpb25zLm11dGF0aW9uS2V5ICYmIGhhc2hLZXkocHJldk9wdGlvbnMubXV0YXRpb25LZXkpICE9PSBoYXNoS2V5KHRoaXMub3B0aW9ucy5tdXRhdGlvbktleSkpIHRoaXMucmVzZXQoKTtcblx0XHRlbHNlIGlmICh0aGlzLiNjdXJyZW50TXV0YXRpb24/LnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIpIHRoaXMuI2N1cnJlbnRNdXRhdGlvbi5zZXRPcHRpb25zKHRoaXMub3B0aW9ucyk7XG5cdH1cblx0b25TdWJzY3JpYmUoKSB7XG5cdFx0aWYgKHRoaXMubGlzdGVuZXJzLnNpemUgPT09IDEgJiYgdGhpcy4jY3VycmVudE11dGF0aW9uKSB7XG5cdFx0XHR0aGlzLiNjdXJyZW50TXV0YXRpb24uYWRkT2JzZXJ2ZXIodGhpcyk7XG5cdFx0XHR0aGlzLiN1cGRhdGVSZXN1bHQoKTtcblx0XHR9XG5cdH1cblx0b25VbnN1YnNjcmliZSgpIHtcblx0XHRpZiAoIXRoaXMuaGFzTGlzdGVuZXJzKCkpIHRoaXMuI2N1cnJlbnRNdXRhdGlvbj8ucmVtb3ZlT2JzZXJ2ZXIodGhpcyk7XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRvbk11dGF0aW9uVXBkYXRlKGFjdGlvbikge1xuXHRcdHRoaXMuI3VwZGF0ZVJlc3VsdCgpO1xuXHRcdHRoaXMuI25vdGlmeShhY3Rpb24pO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIG9ic2VydmVyJ3MgY3VycmVudCByZXN1bHQsIGRlcml2ZWQgZnJvbSB0aGUgb2JzZXJ2ZWRcblx0KiBtdXRhdGlvbidzIHN0YXRlIChvciB0aGUgZGVmYXVsdCwgYGlkbGVgIHN0YXRlIGlmIG5vIG11dGF0aW9uIGhhcyBiZWVuXG5cdCogYnVpbHQgeWV0LCBlLmcuIGJlZm9yZSB0aGUgZmlyc3QgYG11dGF0ZSgpYCBjYWxsIG9yIGFmdGVyIGByZXNldCgpYCkuXG5cdCovXG5cdGdldEN1cnJlbnRSZXN1bHQoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI2N1cnJlbnRSZXN1bHQ7XG5cdH1cblx0LyoqXG5cdCogRGV0YWNoZXMgdGhlIG9ic2VydmVyIGZyb20gdGhlIG11dGF0aW9uIGl0IGlzIGN1cnJlbnRseSBvYnNlcnZpbmcgKGlmXG5cdCogYW55KSBhbmQgcmVzZXRzIHRoZSBvYnNlcnZlZCByZXN1bHQgYmFjayB0byBpdHMgZGVmYXVsdCwgYGlkbGVgIHN0YXRlLlxuXHQqXG5cdCogVGhpcyBkb2VzIG5vdCBjYW5jZWwgYW4gaW4tZmxpZ2h0IG11dGF0aW9uOyB0aGUgbXV0YXRpb24gaXRzZWxmIGtlZXBzXG5cdCogcnVubmluZyB0byBjb21wbGV0aW9uIGFuZCBpdHMgb3duIGNhbGxiYWNrcyBzdGlsbCBmaXJlLCBidXQgdGhpc1xuXHQqIG9ic2VydmVyIHN0b3BzIHJlZmxlY3RpbmcgaXRzIHN0YXRlIGFuZCBhIHN1YnNlcXVlbnQgYG11dGF0ZSgpYCBjYWxsXG5cdCogd2lsbCBidWlsZCBhIGJyYW5kIG5ldyBtdXRhdGlvbi5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBvYnNlcnZlci5yZXNldCgpXG5cdCogYGBgXG5cdCpcblx0KiBAc2VlIHtAbGluayBNdXRhdGlvbk9ic2VydmVyI211dGF0ZX1cblx0Ki9cblx0cmVzZXQoKSB7XG5cdFx0dGhpcy4jY3VycmVudE11dGF0aW9uPy5yZW1vdmVPYnNlcnZlcih0aGlzKTtcblx0XHR0aGlzLiNjdXJyZW50TXV0YXRpb24gPSB2b2lkIDA7XG5cdFx0dGhpcy4jdXBkYXRlUmVzdWx0KCk7XG5cdFx0dGhpcy4jbm90aWZ5KCk7XG5cdH1cblx0LyoqXG5cdCogQnVpbGRzIGEgbmV3IGBNdXRhdGlvbmAgaW4gdGhlIGBNdXRhdGlvbkNhY2hlYCB1c2luZyB0aGUgb2JzZXJ2ZXInc1xuXHQqIGN1cnJlbnQgb3B0aW9ucywgZGV0YWNoZXMgdGhpcyBvYnNlcnZlciBmcm9tIGFueSBwcmV2aW91c2x5IG9ic2VydmVkXG5cdCogbXV0YXRpb24sIGF0dGFjaGVzIGl0IHRvIHRoZSBuZXcgb25lLCBhbmQgZXhlY3V0ZXMgaXQgd2l0aCB0aGUgZ2l2ZW5cblx0KiB2YXJpYWJsZXMuXG5cdCpcblx0KiBUaGUgb3B0aW9uYWwgcGVyLWNhbGwgYG9wdGlvbnNgIChgb25TdWNjZXNzYC9gb25FcnJvcmAvYG9uU2V0dGxlZGApIGFyZVxuXHQqIGludm9rZWQgb25jZSB0aGUgbXV0YXRpb24gc2V0dGxlcywgaW4gYWRkaXRpb24gdG8gYW55IGNhbGxiYWNrcyBkZWZpbmVkXG5cdCogb24gdGhlIG9ic2VydmVyJ3Mgb3duIG9wdGlvbnMuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogYXdhaXQgb2JzZXJ2ZXIubXV0YXRlKFxuXHQqICAgeyB0aXRsZTogJ05ldyBwb3N0JyB9LFxuXHQqICAgeyBvblN1Y2Nlc3M6IChkYXRhKSA9PiBjb25zb2xlLmxvZyhkYXRhKSB9LFxuXHQqIClcblx0KiBgYGBcblx0Ki9cblx0bXV0YXRlKHZhcmlhYmxlcywgb3B0aW9ucykge1xuXHRcdHRoaXMuI211dGF0ZU9wdGlvbnMgPSBvcHRpb25zO1xuXHRcdHRoaXMuI2N1cnJlbnRNdXRhdGlvbj8ucmVtb3ZlT2JzZXJ2ZXIodGhpcyk7XG5cdFx0dGhpcy4jY3VycmVudE11dGF0aW9uID0gdGhpcy4jY2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKS5idWlsZCh0aGlzLiNjbGllbnQsIHRoaXMub3B0aW9ucyk7XG5cdFx0dGhpcy4jY3VycmVudE11dGF0aW9uLmFkZE9ic2VydmVyKHRoaXMpO1xuXHRcdHJldHVybiB0aGlzLiNjdXJyZW50TXV0YXRpb24uZXhlY3V0ZSh2YXJpYWJsZXMpO1xuXHR9XG5cdCN1cGRhdGVSZXN1bHQoKSB7XG5cdFx0Y29uc3Qgc3RhdGUgPSB0aGlzLiNjdXJyZW50TXV0YXRpb24/LnN0YXRlID8/IGdldERlZmF1bHRTdGF0ZSgpO1xuXHRcdHRoaXMuI2N1cnJlbnRSZXN1bHQgPSB7XG5cdFx0XHQuLi5zdGF0ZSxcblx0XHRcdGlzUGVuZGluZzogc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIixcblx0XHRcdGlzU3VjY2Vzczogc3RhdGUuc3RhdHVzID09PSBcInN1Y2Nlc3NcIixcblx0XHRcdGlzRXJyb3I6IHN0YXRlLnN0YXR1cyA9PT0gXCJlcnJvclwiLFxuXHRcdFx0aXNJZGxlOiBzdGF0ZS5zdGF0dXMgPT09IFwiaWRsZVwiLFxuXHRcdFx0bXV0YXRlOiB0aGlzLm11dGF0ZSxcblx0XHRcdHJlc2V0OiB0aGlzLnJlc2V0XG5cdFx0fTtcblx0fVxuXHQjbm90aWZ5KGFjdGlvbikge1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0aWYgKHRoaXMuI211dGF0ZU9wdGlvbnMgJiYgdGhpcy5oYXNMaXN0ZW5lcnMoKSkge1xuXHRcdFx0XHRjb25zdCB2YXJpYWJsZXMgPSB0aGlzLiNjdXJyZW50UmVzdWx0LnZhcmlhYmxlcztcblx0XHRcdFx0Y29uc3Qgb25NdXRhdGVSZXN1bHQgPSB0aGlzLiNjdXJyZW50UmVzdWx0LmNvbnRleHQ7XG5cdFx0XHRcdGNvbnN0IGNvbnRleHQgPSB7XG5cdFx0XHRcdFx0Y2xpZW50OiB0aGlzLiNjbGllbnQsXG5cdFx0XHRcdFx0bWV0YTogdGhpcy5vcHRpb25zLm1ldGEsXG5cdFx0XHRcdFx0bXV0YXRpb25LZXk6IHRoaXMub3B0aW9ucy5tdXRhdGlvbktleVxuXHRcdFx0XHR9O1xuXHRcdFx0XHRpZiAoYWN0aW9uPy50eXBlID09PSBcInN1Y2Nlc3NcIikge1xuXHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHR0aGlzLiNtdXRhdGVPcHRpb25zLm9uU3VjY2Vzcz8uKGFjdGlvbi5kYXRhLCB2YXJpYWJsZXMsIG9uTXV0YXRlUmVzdWx0LCBjb250ZXh0KTtcblx0XHRcdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0XHRQcm9taXNlLnJlamVjdChlKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdHRoaXMuI211dGF0ZU9wdGlvbnMub25TZXR0bGVkPy4oYWN0aW9uLmRhdGEsIG51bGwsIHZhcmlhYmxlcywgb25NdXRhdGVSZXN1bHQsIGNvbnRleHQpO1xuXHRcdFx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0XHRcdFByb21pc2UucmVqZWN0KGUpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSBlbHNlIGlmIChhY3Rpb24/LnR5cGUgPT09IFwiZXJyb3JcIikge1xuXHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHR0aGlzLiNtdXRhdGVPcHRpb25zLm9uRXJyb3I/LihhY3Rpb24uZXJyb3IsIHZhcmlhYmxlcywgb25NdXRhdGVSZXN1bHQsIGNvbnRleHQpO1xuXHRcdFx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0XHRcdFByb21pc2UucmVqZWN0KGUpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0dGhpcy4jbXV0YXRlT3B0aW9ucy5vblNldHRsZWQ/Lih2b2lkIDAsIGFjdGlvbi5lcnJvciwgdmFyaWFibGVzLCBvbk11dGF0ZVJlc3VsdCwgY29udGV4dCk7XG5cdFx0XHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRcdFx0UHJvbWlzZS5yZWplY3QoZSk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHR0aGlzLmxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4ge1xuXHRcdFx0XHRsaXN0ZW5lcih0aGlzLiNjdXJyZW50UmVzdWx0KTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBNdXRhdGlvbk9ic2VydmVyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW11dGF0aW9uT2JzZXJ2ZXIuanMubWFwIiwiaW1wb3J0IHsgcmVwbGFjZUVxdWFsRGVlcCwgc2hhbGxvd0VxdWFsT2JqZWN0cyB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBTdWJzY3JpYmFibGUgfSBmcm9tIFwiLi9zdWJzY3JpYmFibGUuanNcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBRdWVyeU9ic2VydmVyIH0gZnJvbSBcIi4vcXVlcnlPYnNlcnZlci5qc1wiO1xuLy8jcmVnaW9uIHNyYy9xdWVyaWVzT2JzZXJ2ZXIudHNcbmZ1bmN0aW9uIGRpZmZlcmVuY2UoYXJyYXkxLCBhcnJheTIpIHtcblx0Y29uc3QgZXhjbHVkZVNldCA9IG5ldyBTZXQoYXJyYXkyKTtcblx0cmV0dXJuIGFycmF5MS5maWx0ZXIoKHgpID0+ICFleGNsdWRlU2V0Lmhhcyh4KSk7XG59XG4vKipcbiogQSBgUXVlcmllc09ic2VydmVyYCB3YXRjaGVzIGFuIGFycmF5IG9mIHF1ZXJpZXMgYXQgb25jZSwgZXhwb3NpbmcgdGhlbSBhc1xuKiBhIHNpbmdsZSBhcnJheSBvZiBgUXVlcnlPYnNlcnZlclJlc3VsdGBzIChvciwgd2hlbiBhIGBjb21iaW5lYCBvcHRpb24gaXNcbiogZ2l2ZW4sIGFzIGEgY29tYmluZWQgdmFsdWUgZGVyaXZlZCBmcm9tIHRoYXQgYXJyYXkpLiBJdCBtYW5hZ2VzIG9uZVxuKiBpbnRlcm5hbCBgUXVlcnlPYnNlcnZlcmAgcGVyIHF1ZXJ5LCBhbmQgaXMgdGhlIHByaW1pdGl2ZSB0aGF0IGZyYW1ld29ya1xuKiBhZGFwdGVycyAoZS5nLiBgdXNlUXVlcmllc2ApIGJ1aWxkIHRoZWlyIGhvb2tzIG9uIHRvcCBvZi5cbipcbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgUXVlcmllc09ic2VydmVyKHF1ZXJ5Q2xpZW50LCBbXG4qICAgeyBxdWVyeUtleTogWydwb3N0JywgMV0sIHF1ZXJ5Rm46IGZldGNoUG9zdCB9LFxuKiAgIHsgcXVlcnlLZXk6IFsncG9zdCcsIDJdLCBxdWVyeUZuOiBmZXRjaFBvc3QgfSxcbiogXSlcbipcbiogY29uc3QgdW5zdWJzY3JpYmUgPSBvYnNlcnZlci5zdWJzY3JpYmUoKHJlc3VsdCkgPT4ge1xuKiAgIGNvbnNvbGUubG9nKHJlc3VsdClcbiogfSlcbiogYGBgXG4qL1xudmFyIFF1ZXJpZXNPYnNlcnZlciA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcblx0I2NsaWVudDtcblx0I3Jlc3VsdDtcblx0I3F1ZXJpZXM7XG5cdCNvcHRpb25zO1xuXHQjb2JzZXJ2ZXJzO1xuXHQjY29tYmluZWRSZXN1bHQ7XG5cdCNsYXN0Q29tYmluZTtcblx0I2xhc3RSZXN1bHQ7XG5cdCNsYXN0UXVlcnlIYXNoZXM7XG5cdCNvYnNlcnZlck1hdGNoZXMgPSBbXTtcblx0Y29uc3RydWN0b3IoY2xpZW50LCBxdWVyaWVzLCBvcHRpb25zKSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLiNjbGllbnQgPSBjbGllbnQ7XG5cdFx0dGhpcy4jb3B0aW9ucyA9IG9wdGlvbnM7XG5cdFx0dGhpcy4jcXVlcmllcyA9IFtdO1xuXHRcdHRoaXMuI29ic2VydmVycyA9IFtdO1xuXHRcdHRoaXMuI3Jlc3VsdCA9IFtdO1xuXHRcdHRoaXMuc2V0UXVlcmllcyhxdWVyaWVzKTtcblx0fVxuXHRvblN1YnNjcmliZSgpIHtcblx0XHRpZiAodGhpcy5saXN0ZW5lcnMuc2l6ZSA9PT0gMSkgdGhpcy4jb2JzZXJ2ZXJzLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG5cdFx0XHRvYnNlcnZlci5zdWJzY3JpYmUoKHJlc3VsdCkgPT4ge1xuXHRcdFx0XHR0aGlzLiNvblVwZGF0ZShvYnNlcnZlciwgcmVzdWx0KTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG5cdG9uVW5zdWJzY3JpYmUoKSB7XG5cdFx0aWYgKCF0aGlzLmxpc3RlbmVycy5zaXplKSB0aGlzLmRlc3Ryb3koKTtcblx0fVxuXHQvKipcblx0KiBTdG9wcyBvYnNlcnZpbmcgYWxsIHF1ZXJpZXM6IGNsZWFycyBhbGwgbGlzdGVuZXJzIGFuZCBkZXN0cm95cyBldmVyeVxuXHQqIHVuZGVybHlpbmcgYFF1ZXJ5T2JzZXJ2ZXJgIHRoaXMgb2JzZXJ2ZXIgbWFuYWdlcy5cblx0Ki9cblx0ZGVzdHJveSgpIHtcblx0XHR0aGlzLmxpc3RlbmVycyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdFx0dGhpcy4jb2JzZXJ2ZXJzLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG5cdFx0XHRvYnNlcnZlci5kZXN0cm95KCk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmVwbGFjZXMgdGhlIHNldCBvZiBxdWVyaWVzIGJlaW5nIG9ic2VydmVkLiBFeGlzdGluZyBgUXVlcnlPYnNlcnZlcmBzXG5cdCogYXJlIHJldXNlZCBmb3IgcXVlcmllcyB0aGF0IG1hdGNoIGFuIGFscmVhZHktb2JzZXJ2ZWQgcXVlcnkgaGFzaDtcblx0KiBvYnNlcnZlcnMgZm9yIHF1ZXJpZXMgdGhhdCBhcmUgbm8gbG9uZ2VyIHByZXNlbnQgYXJlIGRlc3Ryb3llZCwgYW5kIG5ld1xuXHQqIG9ic2VydmVycyBhcmUgY3JlYXRlZCBhbmQgc3Vic2NyaWJlZCB0byBmb3IgbmV3bHkgYWRkZWQgcXVlcmllcy5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBvYnNlcnZlci5zZXRRdWVyaWVzKFtcblx0KiAgIHsgcXVlcnlLZXk6IFsncG9zdCcsIDFdLCBxdWVyeUZuOiBmZXRjaFBvc3QgfSxcblx0KiAgIHsgcXVlcnlLZXk6IFsncG9zdCcsIDNdLCBxdWVyeUZuOiBmZXRjaFBvc3QgfSxcblx0KiBdKVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRRdWVyaWVzKHF1ZXJpZXMsIG9wdGlvbnMpIHtcblx0XHR0aGlzLiNxdWVyaWVzID0gcXVlcmllcztcblx0XHR0aGlzLiNvcHRpb25zID0gb3B0aW9ucztcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0XHRjb25zdCBxdWVyeUhhc2hlcyA9IHF1ZXJpZXMubWFwKChxdWVyeSkgPT4gdGhpcy4jY2xpZW50LmRlZmF1bHRRdWVyeU9wdGlvbnMocXVlcnkpLnF1ZXJ5SGFzaCk7XG5cdFx0XHRpZiAobmV3IFNldChxdWVyeUhhc2hlcykuc2l6ZSAhPT0gcXVlcnlIYXNoZXMubGVuZ3RoKSBjb25zb2xlLndhcm4oXCJbUXVlcmllc09ic2VydmVyXTogRHVwbGljYXRlIFF1ZXJpZXMgZm91bmQuIFRoaXMgbWlnaHQgcmVzdWx0IGluIHVuZXhwZWN0ZWQgYmVoYXZpb3IuXCIpO1xuXHRcdH1cblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdGNvbnN0IHByZXZPYnNlcnZlcnMgPSB0aGlzLiNvYnNlcnZlcnM7XG5cdFx0XHRjb25zdCBuZXdPYnNlcnZlck1hdGNoZXMgPSB0aGlzLiNmaW5kTWF0Y2hpbmdPYnNlcnZlcnModGhpcy4jcXVlcmllcyk7XG5cdFx0XHRuZXdPYnNlcnZlck1hdGNoZXMuZm9yRWFjaCgobWF0Y2gpID0+IG1hdGNoLm9ic2VydmVyLnNldE9wdGlvbnMobWF0Y2guZGVmYXVsdGVkUXVlcnlPcHRpb25zKSk7XG5cdFx0XHRjb25zdCBuZXdPYnNlcnZlcnMgPSBuZXdPYnNlcnZlck1hdGNoZXMubWFwKChtYXRjaCkgPT4gbWF0Y2gub2JzZXJ2ZXIpO1xuXHRcdFx0Y29uc3QgbmV3UmVzdWx0ID0gbmV3T2JzZXJ2ZXJzLm1hcCgob2JzZXJ2ZXIpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKSk7XG5cdFx0XHRjb25zdCBoYXNMZW5ndGhDaGFuZ2UgPSBwcmV2T2JzZXJ2ZXJzLmxlbmd0aCAhPT0gbmV3T2JzZXJ2ZXJzLmxlbmd0aDtcblx0XHRcdGNvbnN0IGhhc0luZGV4Q2hhbmdlID0gbmV3T2JzZXJ2ZXJzLnNvbWUoKG9ic2VydmVyLCBpbmRleCkgPT4gb2JzZXJ2ZXIgIT09IHByZXZPYnNlcnZlcnNbaW5kZXhdKTtcblx0XHRcdGNvbnN0IGhhc1N0cnVjdHVyYWxDaGFuZ2UgPSBoYXNMZW5ndGhDaGFuZ2UgfHwgaGFzSW5kZXhDaGFuZ2U7XG5cdFx0XHRjb25zdCBoYXNSZXN1bHRDaGFuZ2UgPSBoYXNTdHJ1Y3R1cmFsQ2hhbmdlID8gdHJ1ZSA6IG5ld1Jlc3VsdC5zb21lKChyZXN1bHQsIGluZGV4KSA9PiB7XG5cdFx0XHRcdGNvbnN0IHByZXYgPSB0aGlzLiNyZXN1bHRbaW5kZXhdO1xuXHRcdFx0XHRyZXR1cm4gIXByZXYgfHwgIXNoYWxsb3dFcXVhbE9iamVjdHMocmVzdWx0LCBwcmV2KTtcblx0XHRcdH0pO1xuXHRcdFx0aWYgKCFoYXNTdHJ1Y3R1cmFsQ2hhbmdlICYmICFoYXNSZXN1bHRDaGFuZ2UpIHJldHVybjtcblx0XHRcdGlmIChoYXNTdHJ1Y3R1cmFsQ2hhbmdlKSB7XG5cdFx0XHRcdHRoaXMuI29ic2VydmVyTWF0Y2hlcyA9IG5ld09ic2VydmVyTWF0Y2hlcztcblx0XHRcdFx0dGhpcy4jb2JzZXJ2ZXJzID0gbmV3T2JzZXJ2ZXJzO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy4jcmVzdWx0ID0gbmV3UmVzdWx0O1xuXHRcdFx0aWYgKCF0aGlzLmhhc0xpc3RlbmVycygpKSByZXR1cm47XG5cdFx0XHRpZiAoaGFzU3RydWN0dXJhbENoYW5nZSkge1xuXHRcdFx0XHRkaWZmZXJlbmNlKHByZXZPYnNlcnZlcnMsIG5ld09ic2VydmVycykuZm9yRWFjaCgob2JzZXJ2ZXIpID0+IHtcblx0XHRcdFx0XHRvYnNlcnZlci5kZXN0cm95KCk7XG5cdFx0XHRcdH0pO1xuXHRcdFx0XHRkaWZmZXJlbmNlKG5ld09ic2VydmVycywgcHJldk9ic2VydmVycykuZm9yRWFjaCgob2JzZXJ2ZXIpID0+IHtcblx0XHRcdFx0XHRvYnNlcnZlci5zdWJzY3JpYmUoKHJlc3VsdCkgPT4ge1xuXHRcdFx0XHRcdFx0dGhpcy4jb25VcGRhdGUob2JzZXJ2ZXIsIHJlc3VsdCk7XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy4jbm90aWZ5KCk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgbW9zdCByZWNlbnRseSBjb21wdXRlZCBhcnJheSBvZiBgUXVlcnlPYnNlcnZlclJlc3VsdGBzLCBvbmVcblx0KiBwZXIgb2JzZXJ2ZWQgcXVlcnksIGluIHRoZSBzYW1lIG9yZGVyIGFzIHRoZSBxdWVyaWVzIHBhc3NlZCB0byB0aGVcblx0KiBjb25zdHJ1Y3RvciBvciBgc2V0UXVlcmllc2AuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgcmVzdWx0cyA9IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKVxuXHQqIGNvbnN0IGRhdGEgPSByZXN1bHRzLm1hcCgocmVzdWx0KSA9PiByZXN1bHQuZGF0YSlcblx0KiBgYGBcblx0Ki9cblx0Z2V0Q3VycmVudFJlc3VsdCgpIHtcblx0XHRyZXR1cm4gdGhpcy4jcmVzdWx0O1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIHVuZGVybHlpbmcgYFF1ZXJ5YCBpbnN0YW5jZXMgY3VycmVudGx5IGJlaW5nIG9ic2VydmVkLCBpblxuXHQqIHRoZSBzYW1lIG9yZGVyIGFzIHRoZSBxdWVyaWVzIHBhc3NlZCB0byB0aGUgY29uc3RydWN0b3Igb3IgYHNldFF1ZXJpZXNgLlxuXHQqL1xuXHRnZXRRdWVyaWVzKCkge1xuXHRcdHJldHVybiB0aGlzLiNvYnNlcnZlcnMubWFwKChvYnNlcnZlcikgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFF1ZXJ5KCkpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIHVuZGVybHlpbmcgYFF1ZXJ5T2JzZXJ2ZXJgIGluc3RhbmNlcyB0aGlzIG9ic2VydmVyIG1hbmFnZXMsXG5cdCogaW4gdGhlIHNhbWUgb3JkZXIgYXMgdGhlIHF1ZXJpZXMgcGFzc2VkIHRvIHRoZSBjb25zdHJ1Y3RvciBvclxuXHQqIGBzZXRRdWVyaWVzYC5cblx0Ki9cblx0Z2V0T2JzZXJ2ZXJzKCkge1xuXHRcdHJldHVybiB0aGlzLiNvYnNlcnZlcnM7XG5cdH1cblx0LyoqXG5cdCogVGhlIGBRdWVyaWVzT2JzZXJ2ZXJgIGNvdW50ZXJwYXJ0IG9mIHtAbGluayBRdWVyeU9ic2VydmVyI2dldE9wdGltaXN0aWNSZXN1bHR9IOKAlCBjb21wdXRlc1xuXHQqIHRoZSByZXN1bHQgZm9yIHRoZSBnaXZlbiAoYWxyZWFkeS1kZWZhdWx0ZWQpIHF1ZXJpZXMgcmlnaHQgbm93LCBzeW5jaHJvbm91c2x5LiBDYWxsZWQgYnlcblx0KiBmcmFtZXdvcmsgYWRhcHRlcnMgKGUuZy4gYHVzZVF1ZXJpZXNgKSBhaGVhZCBvZiBzdWJzY3JpYmluZywgcmV0dXJuaW5nIGEgdHVwbGUgb2YgdGhlIHJhd1xuXHQqIHBlci1xdWVyeSByZXN1bHRzLCBhIGZ1bmN0aW9uIHRvIGNvbXB1dGUgdGhlIGNvbWJpbmVkIHJlc3VsdCBmcm9tIHRoZW0sIGFuZCBhIGZ1bmN0aW9uIHRvXG5cdCogd3JhcCB0aGUgcmVzdWx0cyBmb3IgcHJvcGVydHktYWNjZXNzIHRyYWNraW5nLlxuXHQqL1xuXHRnZXRPcHRpbWlzdGljUmVzdWx0KHF1ZXJpZXMsIGNvbWJpbmUpIHtcblx0XHRjb25zdCBtYXRjaGVzID0gdGhpcy4jZmluZE1hdGNoaW5nT2JzZXJ2ZXJzKHF1ZXJpZXMpO1xuXHRcdGNvbnN0IHJlc3VsdCA9IG1hdGNoZXMubWFwKChtYXRjaCkgPT4gbWF0Y2gub2JzZXJ2ZXIuZ2V0T3B0aW1pc3RpY1Jlc3VsdChtYXRjaC5kZWZhdWx0ZWRRdWVyeU9wdGlvbnMpKTtcblx0XHRjb25zdCBxdWVyeUhhc2hlcyA9IG1hdGNoZXMubWFwKChtYXRjaCkgPT4gbWF0Y2guZGVmYXVsdGVkUXVlcnlPcHRpb25zLnF1ZXJ5SGFzaCk7XG5cdFx0cmV0dXJuIFtcblx0XHRcdHJlc3VsdCxcblx0XHRcdChyKSA9PiB7XG5cdFx0XHRcdHJldHVybiB0aGlzLiNjb21iaW5lUmVzdWx0KHIgPz8gcmVzdWx0LCBjb21iaW5lLCBxdWVyeUhhc2hlcyk7XG5cdFx0XHR9LFxuXHRcdFx0KCkgPT4ge1xuXHRcdFx0XHRyZXR1cm4gdGhpcy4jdHJhY2tSZXN1bHQocmVzdWx0LCBtYXRjaGVzKTtcblx0XHRcdH1cblx0XHRdO1xuXHR9XG5cdCN0cmFja1Jlc3VsdChyZXN1bHQsIG1hdGNoZXMpIHtcblx0XHRjb25zdCB0cmFja2VkUHJvcHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdHJldHVybiBtYXRjaGVzLm1hcCgobWF0Y2gsIGluZGV4KSA9PiB7XG5cdFx0XHRjb25zdCBvYnNlcnZlclJlc3VsdCA9IHJlc3VsdFtpbmRleF07XG5cdFx0XHRyZXR1cm4gIW1hdGNoLmRlZmF1bHRlZFF1ZXJ5T3B0aW9ucy5ub3RpZnlPbkNoYW5nZVByb3BzID8gbWF0Y2gub2JzZXJ2ZXIudHJhY2tSZXN1bHQob2JzZXJ2ZXJSZXN1bHQsIChhY2Nlc3NlZFByb3ApID0+IHtcblx0XHRcdFx0aWYgKCF0cmFja2VkUHJvcHMuaGFzKGFjY2Vzc2VkUHJvcCkpIHtcblx0XHRcdFx0XHR0cmFja2VkUHJvcHMuYWRkKGFjY2Vzc2VkUHJvcCk7XG5cdFx0XHRcdFx0bWF0Y2hlcy5mb3JFYWNoKChtKSA9PiB7XG5cdFx0XHRcdFx0XHRtLm9ic2VydmVyLnRyYWNrUHJvcChhY2Nlc3NlZFByb3ApO1xuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHR9XG5cdFx0XHR9KSA6IG9ic2VydmVyUmVzdWx0O1xuXHRcdH0pO1xuXHR9XG5cdCNjb21iaW5lUmVzdWx0KGlucHV0LCBjb21iaW5lLCBxdWVyeUhhc2hlcykge1xuXHRcdGlmIChjb21iaW5lKSB7XG5cdFx0XHRjb25zdCBsYXN0SGFzaGVzID0gdGhpcy4jbGFzdFF1ZXJ5SGFzaGVzO1xuXHRcdFx0Y29uc3QgcXVlcnlIYXNoZXNDaGFuZ2VkID0gcXVlcnlIYXNoZXMgIT09IHZvaWQgMCAmJiBsYXN0SGFzaGVzICE9PSB2b2lkIDAgJiYgKGxhc3RIYXNoZXMubGVuZ3RoICE9PSBxdWVyeUhhc2hlcy5sZW5ndGggfHwgcXVlcnlIYXNoZXMuc29tZSgoaGFzaCwgaSkgPT4gaGFzaCAhPT0gbGFzdEhhc2hlc1tpXSkpO1xuXHRcdFx0aWYgKHRoaXMuI3Jlc3VsdCAhPT0gdGhpcy4jbGFzdFJlc3VsdCB8fCBxdWVyeUhhc2hlc0NoYW5nZWQgfHwgY29tYmluZSAhPT0gdGhpcy4jbGFzdENvbWJpbmUpIHtcblx0XHRcdFx0dGhpcy4jbGFzdENvbWJpbmUgPSBjb21iaW5lO1xuXHRcdFx0XHR0aGlzLiNsYXN0UmVzdWx0ID0gdGhpcy4jcmVzdWx0O1xuXHRcdFx0XHRpZiAocXVlcnlIYXNoZXMgIT09IHZvaWQgMCkgdGhpcy4jbGFzdFF1ZXJ5SGFzaGVzID0gcXVlcnlIYXNoZXM7XG5cdFx0XHRcdHRoaXMuI2NvbWJpbmVkUmVzdWx0ID0gcmVwbGFjZUVxdWFsRGVlcCh0aGlzLiNjb21iaW5lZFJlc3VsdCwgY29tYmluZShpbnB1dCkpO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHRoaXMuI2NvbWJpbmVkUmVzdWx0O1xuXHRcdH1cblx0XHRyZXR1cm4gaW5wdXQ7XG5cdH1cblx0I3Nob3VsZFNraXBDb21iaW5lKCkge1xuXHRcdHJldHVybiAhdGhpcy4jb3B0aW9ucz8uY29tYmluZSB8fCB0aGlzLiNvYnNlcnZlcnMuc29tZSgob2JzZXJ2ZXIsIGluZGV4KSA9PiB7XG5cdFx0XHRyZXR1cm4gb2JzZXJ2ZXIub3B0aW9ucy5zdXNwZW5zZSAmJiB0aGlzLiNyZXN1bHRbaW5kZXhdPy5kYXRhID09PSB2b2lkIDA7XG5cdFx0fSk7XG5cdH1cblx0I2ZpbmRNYXRjaGluZ09ic2VydmVycyhxdWVyaWVzKSB7XG5cdFx0Y29uc3QgcHJldk9ic2VydmVyc01hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0dGhpcy4jb2JzZXJ2ZXJzLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG5cdFx0XHRjb25zdCBrZXkgPSBvYnNlcnZlci5vcHRpb25zLnF1ZXJ5SGFzaDtcblx0XHRcdGlmICgha2V5KSByZXR1cm47XG5cdFx0XHRjb25zdCBwcmV2aW91c09ic2VydmVycyA9IHByZXZPYnNlcnZlcnNNYXAuZ2V0KGtleSk7XG5cdFx0XHRpZiAocHJldmlvdXNPYnNlcnZlcnMpIHByZXZpb3VzT2JzZXJ2ZXJzLnB1c2gob2JzZXJ2ZXIpO1xuXHRcdFx0ZWxzZSBwcmV2T2JzZXJ2ZXJzTWFwLnNldChrZXksIFtvYnNlcnZlcl0pO1xuXHRcdH0pO1xuXHRcdGNvbnN0IG9ic2VydmVycyA9IFtdO1xuXHRcdHF1ZXJpZXMuZm9yRWFjaCgob3B0aW9ucykgPT4ge1xuXHRcdFx0Y29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IHRoaXMuI2NsaWVudC5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdFx0Y29uc3Qgb2JzZXJ2ZXIgPSBwcmV2T2JzZXJ2ZXJzTWFwLmdldChkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaCk/LnNoaWZ0KCkgPz8gbmV3IFF1ZXJ5T2JzZXJ2ZXIodGhpcy4jY2xpZW50LCBkZWZhdWx0ZWRPcHRpb25zKTtcblx0XHRcdG9ic2VydmVycy5wdXNoKHtcblx0XHRcdFx0ZGVmYXVsdGVkUXVlcnlPcHRpb25zOiBkZWZhdWx0ZWRPcHRpb25zLFxuXHRcdFx0XHRvYnNlcnZlclxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdFx0cmV0dXJuIG9ic2VydmVycztcblx0fVxuXHQjb25VcGRhdGUob2JzZXJ2ZXIsIHJlc3VsdCkge1xuXHRcdGNvbnN0IGluZGV4ID0gdGhpcy4jb2JzZXJ2ZXJzLmluZGV4T2Yob2JzZXJ2ZXIpO1xuXHRcdGlmIChpbmRleCAhPT0gLTEpIHtcblx0XHRcdHRoaXMuI3Jlc3VsdCA9IHRoaXMuI3Jlc3VsdC5zbGljZSgpO1xuXHRcdFx0dGhpcy4jcmVzdWx0W2luZGV4XSA9IHJlc3VsdDtcblx0XHRcdHRoaXMuI25vdGlmeSgpO1xuXHRcdH1cblx0fVxuXHQjbm90aWZ5KCkge1xuXHRcdGlmICh0aGlzLmhhc0xpc3RlbmVycygpKSB7XG5cdFx0XHRjb25zdCBzaG91bGRTa2lwQ29tYmluZSA9IHRoaXMuI3Nob3VsZFNraXBDb21iaW5lKCk7XG5cdFx0XHRjb25zdCBwcmV2aW91c1Jlc3VsdCA9IHRoaXMuI2NvbWJpbmVkUmVzdWx0O1xuXHRcdFx0Y29uc3QgbmV3UmVzdWx0ID0gc2hvdWxkU2tpcENvbWJpbmUgPyBwcmV2aW91c1Jlc3VsdCA6IHRoaXMuI2NvbWJpbmVSZXN1bHQodGhpcy4jdHJhY2tSZXN1bHQodGhpcy4jcmVzdWx0LCB0aGlzLiNvYnNlcnZlck1hdGNoZXMpLCB0aGlzLiNvcHRpb25zPy5jb21iaW5lKTtcblx0XHRcdGlmIChzaG91bGRTa2lwQ29tYmluZSB8fCBwcmV2aW91c1Jlc3VsdCAhPT0gbmV3UmVzdWx0KSBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdFx0dGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcblx0XHRcdFx0XHRsaXN0ZW5lcih0aGlzLiNyZXN1bHQpO1xuXHRcdFx0XHR9KTtcblx0XHRcdH0pO1xuXHRcdH1cblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUXVlcmllc09ic2VydmVyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXF1ZXJpZXNPYnNlcnZlci5qcy5tYXAiLCJpbXBvcnQgeyBoYXNoUXVlcnlLZXlCeU9wdGlvbnMsIG1hdGNoUXVlcnkgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgUXVlcnkgfSBmcm9tIFwiLi9xdWVyeS5qc1wiO1xuLy8jcmVnaW9uIHNyYy9xdWVyeUNhY2hlLnRzXG4vKipcbiogVGhlIGBRdWVyeUNhY2hlYCBpcyB0aGUgc3RvcmFnZSBtZWNoYW5pc20gZm9yIFRhblN0YWNrIFF1ZXJ5LiBJdCBzdG9yZXMgYWxsIHRoZSBkYXRhLCBtZXRhXG4qIGluZm9ybWF0aW9uLCBhbmQgc3RhdGUgb2YgdGhlIHF1ZXJpZXMgaXQgY29udGFpbnMuXG4qXG4qIE5vcm1hbGx5LCB5b3Ugd2lsbCBub3QgaW50ZXJhY3Qgd2l0aCB0aGUgYFF1ZXJ5Q2FjaGVgIGRpcmVjdGx5IGFuZCBpbnN0ZWFkIHVzZSBhIGBRdWVyeUNsaWVudGBcbiogZm9yIGEgc3BlY2lmaWMgY2FjaGUuIFlvdSBjYW4gc3Vic2NyaWJlIHRvIGl0IChpbmhlcml0ZWQgZnJvbSBgU3Vic2NyaWJhYmxlYCkgdG8gYmUgaW5mb3JtZWQgb2Zcbiogc2FmZS9rbm93biB1cGRhdGVzIHRvIHRoZSBjYWNoZSwgc3VjaCBhcyBxdWVyaWVzIGJlaW5nIGFkZGVkLCByZW1vdmVkLCBvciB1cGRhdGVkIOKAlCB1cGRhdGVzIG1hZGVcbiogb3V0c2lkZSBvZiB0aGUgY2FjaGUncyBvd24gdHJhY2tlZCBtZWNoYW5pc21zIChlLmcuIG11dGF0aW5nIGEgcXVlcnkncyBzdGF0ZSBvYmplY3QgZGlyZWN0bHkpIGRvXG4qIG5vdCBub3RpZnkgc3Vic2NyaWJlcnMuXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IHVuc3Vic2NyaWJlID0gcXVlcnlDYWNoZS5zdWJzY3JpYmUoKGV2ZW50KSA9PiB7XG4qICAgY29uc29sZS5sb2coZXZlbnQudHlwZSwgZXZlbnQucXVlcnkpXG4qIH0pXG4qIGBgYFxuKi9cbnZhciBRdWVyeUNhY2hlID0gY2xhc3MgZXh0ZW5kcyBTdWJzY3JpYmFibGUge1xuXHQjcXVlcmllcztcblx0Y29uc3RydWN0b3IoY29uZmlnID0ge30pIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuY29uZmlnID0gY29uZmlnO1xuXHRcdHRoaXMuI3F1ZXJpZXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIGV4aXN0aW5nIGBRdWVyeWAgaW5zdGFuY2UgZm9yIHRoZSBnaXZlbiBvcHRpb25zJyBgcXVlcnlLZXlgL2BxdWVyeUhhc2hgLCBvclxuXHQqIGJ1aWxkcyBhbmQgYWRkcyBhIG5ldyBvbmUgdG8gdGhlIGNhY2hlIGlmIG5vbmUgZXhpc3RzIHlldC4gVXNlZCBieSBmcmFtZXdvcmsgYWRhcHRlcnMgYW5kXG5cdCogcGx1Z2lucyAoZS5nLiBicm9hZGNhc3QvcGVyc2lzdGVuY2UpIHRoYXQgbmVlZCB0byBnZXQtb3ItY3JlYXRlIGEgYFF1ZXJ5YCBkaXJlY3RseSwgYnlwYXNzaW5nXG5cdCogdGhlIHJlYWN0aXZlIGBRdWVyeU9ic2VydmVyYCBtYWNoaW5lcnkuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgcXVlcnlDYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5Q2FjaGUoKVxuXHQqXG5cdCogY29uc3QgcXVlcnkgPSBxdWVyeUNhY2hlLmJ1aWxkKHF1ZXJ5Q2xpZW50LCB7XG5cdCogICBxdWVyeUtleTogWydwb3N0cyddLFxuXHQqICAgcXVlcnlGbjogZmV0Y2hQb3N0cyxcblx0KiB9KVxuXHQqIGBgYFxuXHQqL1xuXHRidWlsZChjbGllbnQsIG9wdGlvbnMsIHN0YXRlKSB7XG5cdFx0Y29uc3QgcXVlcnlLZXkgPSBvcHRpb25zLnF1ZXJ5S2V5O1xuXHRcdGNvbnN0IHF1ZXJ5SGFzaCA9IG9wdGlvbnMucXVlcnlIYXNoID8/IGhhc2hRdWVyeUtleUJ5T3B0aW9ucyhxdWVyeUtleSwgb3B0aW9ucyk7XG5cdFx0bGV0IHF1ZXJ5ID0gdGhpcy5nZXQocXVlcnlIYXNoKTtcblx0XHRpZiAoIXF1ZXJ5KSB7XG5cdFx0XHRxdWVyeSA9IG5ldyBRdWVyeSh7XG5cdFx0XHRcdGNsaWVudCxcblx0XHRcdFx0cXVlcnlLZXksXG5cdFx0XHRcdHF1ZXJ5SGFzaCxcblx0XHRcdFx0b3B0aW9uczogY2xpZW50LmRlZmF1bHRRdWVyeU9wdGlvbnMob3B0aW9ucyksXG5cdFx0XHRcdHN0YXRlLFxuXHRcdFx0XHRkZWZhdWx0T3B0aW9uczogY2xpZW50LmdldFF1ZXJ5RGVmYXVsdHMocXVlcnlLZXkpXG5cdFx0XHR9KTtcblx0XHRcdHRoaXMuYWRkKHF1ZXJ5KTtcblx0XHR9XG5cdFx0cmV0dXJuIHF1ZXJ5O1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0YWRkKHF1ZXJ5KSB7XG5cdFx0aWYgKCF0aGlzLiNxdWVyaWVzLmhhcyhxdWVyeS5xdWVyeUhhc2gpKSB7XG5cdFx0XHR0aGlzLiNxdWVyaWVzLnNldChxdWVyeS5xdWVyeUhhc2gsIHF1ZXJ5KTtcblx0XHRcdHRoaXMubm90aWZ5KHtcblx0XHRcdFx0dHlwZTogXCJhZGRlZFwiLFxuXHRcdFx0XHRxdWVyeVxuXHRcdFx0fSk7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIERlc3Ryb3lzIHRoZSBnaXZlbiBgUXVlcnlgIGFuZCByZW1vdmVzIGl0IGZyb20gdGhlIGNhY2hlLCBub3RpZnlpbmcgc3Vic2NyaWJlcnMgd2l0aCBhXG5cdCogYCdyZW1vdmVkJ2AgZXZlbnQuIEEgbm8tb3AgaWYgdGhlIHF1ZXJ5IGlzIG5vIGxvbmdlciB0aGUgb25lIGN1cnJlbnRseSBzdG9yZWQgdW5kZXIgaXRzIGhhc2hcblx0KiAoZS5nLiBpdCB3YXMgYWxyZWFkeSByZXBsYWNlZCkuIFVzZWQgYnkgcGx1Z2lucyAoZS5nLiB0aGUgYnJvYWRjYXN0IGNsaWVudCkgdGhhdCBtaXJyb3Jcblx0KiByZW1vdmFscyBhY3Jvc3MgYFF1ZXJ5Q2FjaGVgIGluc3RhbmNlcy5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBxdWVyeUNhY2hlID0gcXVlcnlDbGllbnQuZ2V0UXVlcnlDYWNoZSgpXG5cdCogY29uc3QgcXVlcnkgPSBxdWVyeUNhY2hlLmZpbmQoeyBxdWVyeUtleTogWydwb3N0cyddIH0pXG5cdCpcblx0KiBpZiAocXVlcnkpIHtcblx0KiAgIHF1ZXJ5Q2FjaGUucmVtb3ZlKHF1ZXJ5KVxuXHQqIH1cblx0KiBgYGBcblx0Ki9cblx0cmVtb3ZlKHF1ZXJ5KSB7XG5cdFx0aWYgKHRoaXMuI3F1ZXJpZXMuZ2V0KHF1ZXJ5LnF1ZXJ5SGFzaCkgPT09IHF1ZXJ5KSB7XG5cdFx0XHRxdWVyeS5kZXN0cm95KCk7XG5cdFx0XHR0aGlzLiNxdWVyaWVzLmRlbGV0ZShxdWVyeS5xdWVyeUhhc2gpO1xuXHRcdFx0dGhpcy5ub3RpZnkoe1xuXHRcdFx0XHR0eXBlOiBcInJlbW92ZWRcIixcblx0XHRcdFx0cXVlcnlcblx0XHRcdH0pO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBSZW1vdmVzIGFsbCBxdWVyaWVzIGZyb20gdGhlIGNhY2hlLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KlxuXHQqIHF1ZXJ5Q2FjaGUuY2xlYXIoKVxuXHQqIGBgYFxuXHQqL1xuXHRjbGVhcigpIHtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdHRoaXMuZ2V0QWxsKCkuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0dGhpcy5yZW1vdmUocXVlcnkpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgYFF1ZXJ5YCBpbnN0YW5jZSBzdG9yZWQgdW5kZXIgdGhlIGdpdmVuIGBxdWVyeUhhc2hgLCBvciBgdW5kZWZpbmVkYCBpZiBub25lXG5cdCogZXhpc3RzLiBVbmxpa2Uge0BsaW5rIFF1ZXJ5Q2FjaGUjZmluZH0sIHRoaXMgbG9va3MgdXAgYnkgdGhlIGFscmVhZHktY29tcHV0ZWQgaGFzaCByYXRoZXJcblx0KiB0aGFuIGJ5IGBRdWVyeUZpbHRlcnNgLiBVc2VkIGJ5IHBsdWdpbnMgKGUuZy4gYnJvYWRjYXN0L2h5ZHJhdGlvbikgdGhhdCBhbHJlYWR5IGhhdmUgYSBoYXNoXG5cdCogdG8gbG9vayB1cCBkaXJlY3RseS5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBxdWVyeUNhY2hlID0gcXVlcnlDbGllbnQuZ2V0UXVlcnlDYWNoZSgpXG5cdCogY29uc3QgcXVlcnlIYXNoID0gaGFzaEtleShbJ3Bvc3RzJ10pXG5cdCpcblx0KiBjb25zdCBxdWVyeSA9IHF1ZXJ5Q2FjaGUuZ2V0KHF1ZXJ5SGFzaClcblx0KiBgYGBcblx0Ki9cblx0Z2V0KHF1ZXJ5SGFzaCkge1xuXHRcdHJldHVybiB0aGlzLiNxdWVyaWVzLmdldChxdWVyeUhhc2gpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgYWxsIHF1ZXJpZXMgd2l0aGluIHRoZSBjYWNoZS5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBxdWVyeUNhY2hlID0gcXVlcnlDbGllbnQuZ2V0UXVlcnlDYWNoZSgpXG5cdCpcblx0KiBjb25zdCBxdWVyaWVzID0gcXVlcnlDYWNoZS5nZXRBbGwoKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRBbGwoKSB7XG5cdFx0cmV0dXJuIFsuLi50aGlzLiNxdWVyaWVzLnZhbHVlcygpXTtcblx0fVxuXHQvKipcblx0KiBBIHNsaWdodGx5IG1vcmUgYWR2YW5jZWQgbWV0aG9kIHRoYXQgY2FuIGJlIHVzZWQgdG8gZ2V0IGFuIGV4aXN0aW5nIHF1ZXJ5IGluc3RhbmNlIGZyb20gdGhlXG5cdCogY2FjaGUuIFRoaXMgaW5zdGFuY2Ugbm90IG9ubHkgY29udGFpbnMgYWxsIHRoZSBzdGF0ZSBmb3IgdGhlIHF1ZXJ5LCBidXQgYWxsIG9mIHRoZSBpbnN0YW5jZXMsXG5cdCogYW5kIHVuZGVybHlpbmcgZ3V0cyBvZiB0aGUgcXVlcnkgYXMgd2VsbC4gSWYgdGhlIHF1ZXJ5IGRvZXMgbm90IGV4aXN0LCBgdW5kZWZpbmVkYCBpc1xuXHQqIHJldHVybmVkLlxuXHQqXG5cdCogVGhpcyBpcyBub3QgdHlwaWNhbGx5IG5lZWRlZCBmb3IgbW9zdCBhcHBsaWNhdGlvbnMsIGJ1dCBjYW4gY29tZSBpbiBoYW5keSB3aGVuIG5lZWRpbmcgbW9yZVxuXHQqIGluZm9ybWF0aW9uIGFib3V0IGEgcXVlcnkgaW4gcmFyZSBzY2VuYXJpb3MgKGUuZy4gbG9va2luZyBhdCBgcXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdGAgdG9cblx0KiBkZWNpZGUgd2hldGhlciBhIHF1ZXJ5IGlzIGZyZXNoIGVub3VnaCB0byBiZSB1c2VkIGFzIGFuIGluaXRpYWwgdmFsdWUpLlxuXHQqXG5cdCogQHNlZSB7QGxpbmsgUXVlcnlDYWNoZSNmaW5kQWxsfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBxdWVyeUNhY2hlID0gcXVlcnlDbGllbnQuZ2V0UXVlcnlDYWNoZSgpXG5cdCpcblx0KiBjb25zdCBxdWVyeSA9IHF1ZXJ5Q2FjaGUuZmluZCh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10gfSlcblx0KiBgYGBcblx0Ki9cblx0ZmluZChmaWx0ZXJzKSB7XG5cdFx0Y29uc3QgZGVmYXVsdGVkRmlsdGVycyA9IHtcblx0XHRcdGV4YWN0OiB0cnVlLFxuXHRcdFx0Li4uZmlsdGVyc1xuXHRcdH07XG5cdFx0cmV0dXJuIHRoaXMuZ2V0QWxsKCkuZmluZCgocXVlcnkpID0+IG1hdGNoUXVlcnkoZGVmYXVsdGVkRmlsdGVycywgcXVlcnkpKTtcblx0fVxuXHQvKipcblx0KiBBbiBldmVuIG1vcmUgYWR2YW5jZWQgbWV0aG9kIHRoYXQgY2FuIGJlIHVzZWQgdG8gZ2V0IGV4aXN0aW5nIHF1ZXJ5IGluc3RhbmNlcyBmcm9tIHRoZSBjYWNoZVxuXHQqIHRoYXQgcGFydGlhbGx5IG1hdGNoIGEgcXVlcnkga2V5LiBJZiBubyBxdWVyaWVzIG1hdGNoLCBhbiBlbXB0eSBhcnJheSBpcyByZXR1cm5lZC5cblx0KlxuXHQqIFRoaXMgaXMgbm90IHR5cGljYWxseSBuZWVkZWQgZm9yIG1vc3QgYXBwbGljYXRpb25zLCBidXQgY2FuIGNvbWUgaW4gaGFuZHkgd2hlbiBuZWVkaW5nIG1vcmVcblx0KiBpbmZvcm1hdGlvbiBhYm91dCBxdWVyaWVzIGluIHJhcmUgc2NlbmFyaW9zLlxuXHQqXG5cdCogQHNlZSB7QGxpbmsgUXVlcnlDYWNoZSNmaW5kfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBxdWVyeUNhY2hlID0gcXVlcnlDbGllbnQuZ2V0UXVlcnlDYWNoZSgpXG5cdCpcblx0KiBjb25zdCBxdWVyaWVzID0gcXVlcnlDYWNoZS5maW5kQWxsKHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRmaW5kQWxsKGZpbHRlcnMgPSB7fSkge1xuXHRcdGNvbnN0IHF1ZXJpZXMgPSB0aGlzLmdldEFsbCgpO1xuXHRcdHJldHVybiBPYmplY3Qua2V5cyhmaWx0ZXJzKS5sZW5ndGggPiAwID8gcXVlcmllcy5maWx0ZXIoKHF1ZXJ5KSA9PiBtYXRjaFF1ZXJ5KGZpbHRlcnMsIHF1ZXJ5KSkgOiBxdWVyaWVzO1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0bm90aWZ5KGV2ZW50KSB7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHR0aGlzLmxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4ge1xuXHRcdFx0XHRsaXN0ZW5lcihldmVudCk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxuXHQvKiogQGludGVybmFsICovXG5cdG9uRm9jdXMoKSB7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHR0aGlzLmdldEFsbCgpLmZvckVhY2goKHF1ZXJ5KSA9PiB7XG5cdFx0XHRcdHF1ZXJ5Lm9uRm9jdXMoKTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0b25PbmxpbmUoKSB7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHR0aGlzLmdldEFsbCgpLmZvckVhY2goKHF1ZXJ5KSA9PiB7XG5cdFx0XHRcdHF1ZXJ5Lm9uT25saW5lKCk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUXVlcnlDYWNoZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1xdWVyeUNhY2hlLmpzLm1hcCIsImltcG9ydCB7IGZ1bmN0aW9uYWxVcGRhdGUsIGhhc2hLZXksIGhhc2hRdWVyeUtleUJ5T3B0aW9ucywgbm9vcCwgcGFydGlhbE1hdGNoS2V5LCByZXNvbHZlUXVlcnlWYWx1ZSwgc2tpcFRva2VuIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IGZvY3VzTWFuYWdlciB9IGZyb20gXCIuL2ZvY3VzTWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCIuL25vdGlmeU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IG9ubGluZU1hbmFnZXIgfSBmcm9tIFwiLi9vbmxpbmVNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBNdXRhdGlvbkNhY2hlIH0gZnJvbSBcIi4vbXV0YXRpb25DYWNoZS5qc1wiO1xuaW1wb3J0IHsgUXVlcnlDYWNoZSB9IGZyb20gXCIuL3F1ZXJ5Q2FjaGUuanNcIjtcbi8vI3JlZ2lvbiBzcmMvcXVlcnlDbGllbnQudHNcbi8qKlxuKiBgUXVlcnlDbGllbnRgIGlzIHVzZWQgdG8gaW50ZXJhY3Qgd2l0aCBhIGNhY2hlIG9mIHF1ZXJpZXMgYW5kIG11dGF0aW9ucy4gSXQgb3ducyBhXG4qIGBRdWVyeUNhY2hlYCBhbmQgYSBgTXV0YXRpb25DYWNoZWAgKGNyZWF0aW5nIGRlZmF1bHQgb25lcyBpZiBub25lIGFyZSBwYXNzZWQgaW4pIGFuZCBob2xkc1xuKiB0aGUgZGVmYXVsdCBvcHRpb25zIHRoYXQgYXJlIGFwcGxpZWQgdG8gcXVlcmllcyBhbmQgbXV0YXRpb25zIGNyZWF0ZWQgdGhyb3VnaCBpdC5cbipcbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoe1xuKiAgIGRlZmF1bHRPcHRpb25zOiB7XG4qICAgICBxdWVyaWVzOiB7XG4qICAgICAgIHN0YWxlVGltZTogSW5maW5pdHksXG4qICAgICB9LFxuKiAgIH0sXG4qIH0pXG4qXG4qIGF3YWl0IHF1ZXJ5Q2xpZW50LnF1ZXJ5KHsgcXVlcnlLZXk6IFsncG9zdHMnXSwgcXVlcnlGbjogZmV0Y2hQb3N0cyB9KVxuKiBgYGBcbiovXG52YXIgUXVlcnlDbGllbnQgPSBjbGFzcyB7XG5cdCNxdWVyeUNhY2hlO1xuXHQjbXV0YXRpb25DYWNoZTtcblx0I2RlZmF1bHRPcHRpb25zO1xuXHQjcXVlcnlEZWZhdWx0cztcblx0I211dGF0aW9uRGVmYXVsdHM7XG5cdCNtb3VudENvdW50O1xuXHQjdW5zdWJzY3JpYmVGb2N1cztcblx0I3Vuc3Vic2NyaWJlT25saW5lO1xuXHRjb25zdHJ1Y3Rvcihjb25maWcgPSB7fSkge1xuXHRcdHRoaXMuI3F1ZXJ5Q2FjaGUgPSBjb25maWcucXVlcnlDYWNoZSB8fCBuZXcgUXVlcnlDYWNoZSgpO1xuXHRcdHRoaXMuI211dGF0aW9uQ2FjaGUgPSBjb25maWcubXV0YXRpb25DYWNoZSB8fCBuZXcgTXV0YXRpb25DYWNoZSgpO1xuXHRcdHRoaXMuI2RlZmF1bHRPcHRpb25zID0gY29uZmlnLmRlZmF1bHRPcHRpb25zIHx8IHt9O1xuXHRcdHRoaXMuI3F1ZXJ5RGVmYXVsdHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdHRoaXMuI211dGF0aW9uRGVmYXVsdHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdHRoaXMuI21vdW50Q291bnQgPSAwO1xuXHR9XG5cdC8qKlxuXHQqIENhbGxlZCBieSBhIGZyYW1ld29yayBhZGFwdGVyJ3MgYFF1ZXJ5Q2xpZW50UHJvdmlkZXJgLWVxdWl2YWxlbnQgd2hlbiBpdCBtb3VudHMsIHRvIHN0YXJ0XG5cdCogbGlzdGVuaW5nIGZvciBmb2N1cy9vbmxpbmUgZXZlbnRzIGFuZCByZXN1bWUgcGF1c2VkIG11dGF0aW9ucy4gUmVmLWNvdW50ZWQgdmlhIGFuIGludGVybmFsXG5cdCogbW91bnQgY291bnQsIHNvIG5lc3RlZCBvciBtdWx0aXBsZSBwcm92aWRlcnMgc2hhcmluZyB0aGUgc2FtZSBgUXVlcnlDbGllbnRgIGRvbid0IHRlYXIgZG93blxuXHQqIHRoZSBzaGFyZWQgbGlzdGVuZXJzIHVudGlsIHRoZSBsYXN0IG9uZSB1bm1vdW50cy5cblx0Ki9cblx0bW91bnQoKSB7XG5cdFx0dGhpcy4jbW91bnRDb3VudCsrO1xuXHRcdGlmICh0aGlzLiNtb3VudENvdW50ICE9PSAxKSByZXR1cm47XG5cdFx0dGhpcy4jdW5zdWJzY3JpYmVGb2N1cyA9IGZvY3VzTWFuYWdlci5zdWJzY3JpYmUoYXN5bmMgKGZvY3VzZWQpID0+IHtcblx0XHRcdGlmIChmb2N1c2VkKSB7XG5cdFx0XHRcdGF3YWl0IHRoaXMucmVzdW1lUGF1c2VkTXV0YXRpb25zKCk7XG5cdFx0XHRcdHRoaXMuI3F1ZXJ5Q2FjaGUub25Gb2N1cygpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdHRoaXMuI3Vuc3Vic2NyaWJlT25saW5lID0gb25saW5lTWFuYWdlci5zdWJzY3JpYmUoYXN5bmMgKG9ubGluZSkgPT4ge1xuXHRcdFx0aWYgKG9ubGluZSkge1xuXHRcdFx0XHRhd2FpdCB0aGlzLnJlc3VtZVBhdXNlZE11dGF0aW9ucygpO1xuXHRcdFx0XHR0aGlzLiNxdWVyeUNhY2hlLm9uT25saW5lKCk7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogVGhlIGludmVyc2Ugb2Yge0BsaW5rIFF1ZXJ5Q2xpZW50I21vdW50fSDigJQgY2FsbGVkIGJ5IGEgZnJhbWV3b3JrIGFkYXB0ZXInc1xuXHQqIGBRdWVyeUNsaWVudFByb3ZpZGVyYC1lcXVpdmFsZW50IHdoZW4gaXQgdW5tb3VudHMuIE9ubHkgdGVhcnMgZG93biB0aGUgZm9jdXMvb25saW5lXG5cdCogbGlzdGVuZXJzIG9uY2UgdGhlIG1vdW50IGNvdW50IHJldHVybnMgdG8gYDBgLlxuXHQqL1xuXHR1bm1vdW50KCkge1xuXHRcdHRoaXMuI21vdW50Q291bnQtLTtcblx0XHRpZiAodGhpcy4jbW91bnRDb3VudCAhPT0gMCkgcmV0dXJuO1xuXHRcdHRoaXMuI3Vuc3Vic2NyaWJlRm9jdXM/LigpO1xuXHRcdHRoaXMuI3Vuc3Vic2NyaWJlRm9jdXMgPSB2b2lkIDA7XG5cdFx0dGhpcy4jdW5zdWJzY3JpYmVPbmxpbmU/LigpO1xuXHRcdHRoaXMuI3Vuc3Vic2NyaWJlT25saW5lID0gdm9pZCAwO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIG51bWJlciBvZiBxdWVyaWVzIGluIHRoZSBjYWNoZSB0aGF0IGFyZSBjdXJyZW50bHkgZmV0Y2hpbmcsIG9wdGlvbmFsbHlcblx0KiBtYXRjaGluZyBhIHNldCBvZiBmaWx0ZXJzLiBUaGlzIGluY2x1ZGVzIGJhY2tncm91bmQtZmV0Y2hpbmcsIGxvYWRpbmcgbmV3IHBhZ2VzLCBhbmRcblx0KiBsb2FkaW5nIG1vcmUgaW5maW5pdGUgcXVlcnkgcmVzdWx0cy5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpZiAocXVlcnlDbGllbnQuaXNGZXRjaGluZygpKSB7XG5cdCogICBjb25zb2xlLmxvZygnQXQgbGVhc3Qgb25lIHF1ZXJ5IGlzIGZldGNoaW5nIScpXG5cdCogfVxuXHQqIGBgYFxuXHQqL1xuXHRpc0ZldGNoaW5nKGZpbHRlcnMpIHtcblx0XHRyZXR1cm4gdGhpcy4jcXVlcnlDYWNoZS5maW5kQWxsKHtcblx0XHRcdC4uLmZpbHRlcnMsXG5cdFx0XHRmZXRjaFN0YXR1czogXCJmZXRjaGluZ1wiXG5cdFx0fSkubGVuZ3RoO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIG51bWJlciBvZiBtdXRhdGlvbnMgaW4gdGhlIGNhY2hlIHRoYXQgYXJlIGN1cnJlbnRseSBwZW5kaW5nLCBvcHRpb25hbGx5XG5cdCogbWF0Y2hpbmcgYSBzZXQgb2YgZmlsdGVycy5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpZiAocXVlcnlDbGllbnQuaXNNdXRhdGluZygpKSB7XG5cdCogICBjb25zb2xlLmxvZygnQXQgbGVhc3Qgb25lIG11dGF0aW9uIGlzIHBlbmRpbmchJylcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdGlzTXV0YXRpbmcoZmlsdGVycykge1xuXHRcdHJldHVybiB0aGlzLiNtdXRhdGlvbkNhY2hlLmZpbmRBbGwoe1xuXHRcdFx0Li4uZmlsdGVycyxcblx0XHRcdHN0YXR1czogXCJwZW5kaW5nXCJcblx0XHR9KS5sZW5ndGg7XG5cdH1cblx0LyoqXG5cdCogSW1wZXJhdGl2ZSAobm9uLXJlYWN0aXZlKSB3YXkgdG8gcmV0cmlldmUgZGF0YSBmb3IgYSBRdWVyeUtleS5cblx0KiBTaG91bGQgb25seSBiZSB1c2VkIGluIGNhbGxiYWNrcyBvciBmdW5jdGlvbnMgd2hlcmUgcmVhZGluZyB0aGUgbGF0ZXN0IGRhdGEgaXMgbmVjZXNzYXJ5LCBlLmcuIGZvciBvcHRpbWlzdGljIHVwZGF0ZXMuXG5cdCpcblx0KiBIaW50OiBEbyBub3QgdXNlIHRoaXMgZnVuY3Rpb24gaW5zaWRlIGEgY29tcG9uZW50LCBiZWNhdXNlIGl0IHdvbid0IHJlY2VpdmUgdXBkYXRlcy5cblx0KiBVc2UgYHVzZVF1ZXJ5YCB0byBjcmVhdGUgYSBgUXVlcnlPYnNlcnZlcmAgdGhhdCBzdWJzY3JpYmVzIHRvIGNoYW5nZXMuXG5cdCpcblx0KiBAc2VlIHtAbGluayBRdWVyeUNsaWVudCNnZXRRdWVyaWVzRGF0YX1cblx0Ki9cblx0Z2V0UXVlcnlEYXRhKHF1ZXJ5S2V5KSB7XG5cdFx0Y29uc3Qgb3B0aW9ucyA9IHRoaXMuZGVmYXVsdFF1ZXJ5T3B0aW9ucyh7IHF1ZXJ5S2V5IH0pO1xuXHRcdHJldHVybiB0aGlzLiNxdWVyeUNhY2hlLmdldChvcHRpb25zLnF1ZXJ5SGFzaCk/LnN0YXRlLmRhdGE7XG5cdH1cblx0LyoqXG5cdCogQGRlcHJlY2F0ZWQgVXNlIHF1ZXJ5Q2xpZW50LnF1ZXJ5KHsgLi4ub3B0aW9ucywgc3RhbGVUaW1lOiAnc3RhdGljJyB9KSBpbnN0ZWFkLiBUaGlzIG1ldGhvZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi5cblx0Ki9cblx0ZW5zdXJlUXVlcnlEYXRhKG9wdGlvbnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGNvbnN0IHF1ZXJ5ID0gdGhpcy4jcXVlcnlDYWNoZS5idWlsZCh0aGlzLCBkZWZhdWx0ZWRPcHRpb25zKTtcblx0XHRjb25zdCBjYWNoZWREYXRhID0gcXVlcnkuc3RhdGUuZGF0YTtcblx0XHRpZiAoY2FjaGVkRGF0YSA9PT0gdm9pZCAwKSByZXR1cm4gdGhpcy5mZXRjaFF1ZXJ5KG9wdGlvbnMpO1xuXHRcdGlmIChvcHRpb25zLnJldmFsaWRhdGVJZlN0YWxlICYmIHF1ZXJ5LmlzU3RhbGVCeVRpbWUocmVzb2x2ZVF1ZXJ5VmFsdWUoZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWUsIHF1ZXJ5KSkpIHRoaXMucHJlZmV0Y2hRdWVyeShkZWZhdWx0ZWRPcHRpb25zKTtcblx0XHRyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGNhY2hlZERhdGEpO1xuXHR9XG5cdC8qKlxuXHQqIEltcGVyYXRpdmUgKG5vbi1yZWFjdGl2ZSkgd2F5IHRvIHJldHJpZXZlIHRoZSBjYWNoZWQgZGF0YSBvZiBtdWx0aXBsZSBxdWVyaWVzIGF0IG9uY2UuXG5cdCogT25seSBxdWVyaWVzIG1hdGNoaW5nIHRoZSBnaXZlbiBmaWx0ZXJzIGFyZSByZXR1cm5lZDsgaWYgbm9uZSBtYXRjaCwgYW4gZW1wdHkgYXJyYXkgaXNcblx0KiByZXR1cm5lZC5cblx0KlxuXHQqIEJlY2F1c2UgdGhlIG1hdGNoZWQgcXVlcmllcyBjYW4gaG9sZCBkYXRhIG9mIGRpZmZlcmVudCBzaGFwZXMgKGUuZy4gYSBicm9hZCBmaWx0ZXIgY2FuIG1hdGNoXG5cdCogcXVlcmllcyB3aXRoIHVucmVsYXRlZCBkYXRhIHR5cGVzKSwgdGhlIGBUUXVlcnlGbkRhdGFgIGdlbmVyaWMgZGVmYXVsdHMgdG8gYHVua25vd25gIHJhdGhlclxuXHQqIHRoYW4gYmVpbmcgaW5mZXJyZWQuIFBhc3NpbmcgYSBtb3JlIHNwZWNpZmljIHR5cGUgaXMgYSBjb252ZW5pZW5jZSBmb3IgY2FsbCBzaXRlcyB0aGF0IGtub3dcblx0KiBldmVyeSBtYXRjaGVkIHF1ZXJ5IGhvbGRzIHRoZSBzYW1lIHNoYXBlIOKAlCBpdCBpcyBub3QgY2hlY2tlZCBhZ2FpbnN0IHRoZSBhY3R1YWwgY2FjaGVcblx0KiBjb250ZW50cy5cblx0KlxuXHQqIEBzZWUge0BsaW5rIFF1ZXJ5Q2xpZW50I2dldFF1ZXJ5RGF0YX1cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgZGF0YSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJpZXNEYXRhKHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRRdWVyaWVzRGF0YShmaWx0ZXJzKSB7XG5cdFx0cmV0dXJuIHRoaXMuI3F1ZXJ5Q2FjaGUuZmluZEFsbChmaWx0ZXJzKS5tYXAoKHsgcXVlcnlLZXksIHN0YXRlIH0pID0+IHtcblx0XHRcdHJldHVybiBbcXVlcnlLZXksIHN0YXRlLmRhdGFdO1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFN5bmNocm9ub3VzIHdheSB0byBpbW1lZGlhdGVseSB1cGRhdGUgYSBxdWVyeSdzIGNhY2hlZCBkYXRhLiBJZiB0aGUgdXBkYXRlciAob3IgdGhlIHZhbHVlXG5cdCogcGFzc2VkKSByZXNvbHZlcyB0byBgdW5kZWZpbmVkYCwgdGhlIGNhY2hlIGlzIGxlZnQgdW50b3VjaGVkIGFuZCBubyBxdWVyeSBpcyBjcmVhdGVkO1xuXHQqIG90aGVyd2lzZSwgaWYgdGhlIHF1ZXJ5IGRvZXMgbm90IGV4aXN0IHlldCwgaXQgd2lsbCBiZSBjcmVhdGVkLiBUbyB1cGRhdGUgbXVsdGlwbGUgcXVlcmllc1xuXHQqIGF0IG9uY2UgYnkgcGFydGlhbGx5IG1hdGNoaW5nIHF1ZXJ5IGtleXMsIHVzZSB7QGxpbmsgUXVlcnlDbGllbnQjc2V0UXVlcmllc0RhdGF9IGluc3RlYWQuXG5cdCpcblx0KiBVcGRhdGVzIG11c3QgYmUgcGVyZm9ybWVkIGltbXV0YWJseTogZG8gbm90IG11dGF0ZSBgb2xkRGF0YWAsIG9yIGRhdGEgcHJldmlvdXNseSByZXRyaWV2ZWRcblx0KiB2aWEge0BsaW5rIFF1ZXJ5Q2xpZW50I2dldFF1ZXJ5RGF0YX0sIGluIHBsYWNlLlxuXHQqXG5cdCogQHBhcmFtIHF1ZXJ5S2V5IC0gVGhlIHF1ZXJ5IGtleSB0byBzZXQgZGF0YSBmb3IuXG5cdCogQHBhcmFtIHVwZGF0ZXIgLSBFaXRoZXIgdGhlIG5ldyBkYXRhLCBvciBhIGZ1bmN0aW9uIHRoYXQgcmVjZWl2ZXMgdGhlIGN1cnJlbnQgZGF0YSAod2hpY2hcblx0KiBtYXkgYmUgYHVuZGVmaW5lZGApIGFuZCByZXR1cm5zIHRoZSBuZXcgZGF0YS5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGEoWydwb3N0cyddLCBuZXdQb3N0cylcblx0KlxuXHQqIC8vIE9yLCB1c2luZyBhbiB1cGRhdGVyIGZ1bmN0aW9uIHRoYXQgcmVjZWl2ZXMgdGhlIGN1cnJlbnQgZGF0YTpcblx0KiBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGEoWydwb3N0cyddLCAob2xkUG9zdHMpID0+IFsuLi5vbGRQb3N0cywgbmV3UG9zdF0pXG5cdCogYGBgXG5cdCovXG5cdHNldFF1ZXJ5RGF0YShxdWVyeUtleSwgdXBkYXRlciwgb3B0aW9ucykge1xuXHRcdGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSB0aGlzLmRlZmF1bHRRdWVyeU9wdGlvbnMoeyBxdWVyeUtleSB9KTtcblx0XHRjb25zdCBwcmV2RGF0YSA9IHRoaXMuI3F1ZXJ5Q2FjaGUuZ2V0KGRlZmF1bHRlZE9wdGlvbnMucXVlcnlIYXNoKT8uc3RhdGUuZGF0YTtcblx0XHRjb25zdCBkYXRhID0gZnVuY3Rpb25hbFVwZGF0ZSh1cGRhdGVyLCBwcmV2RGF0YSk7XG5cdFx0aWYgKGRhdGEgPT09IHZvaWQgMCkgcmV0dXJuO1xuXHRcdHJldHVybiB0aGlzLiNxdWVyeUNhY2hlLmJ1aWxkKHRoaXMsIGRlZmF1bHRlZE9wdGlvbnMpLnNldERhdGEoZGF0YSwge1xuXHRcdFx0Li4ub3B0aW9ucyxcblx0XHRcdG1hbnVhbDogdHJ1ZVxuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFN5bmNocm9ub3VzIHdheSB0byBpbW1lZGlhdGVseSB1cGRhdGUgdGhlIGNhY2hlZCBkYXRhIG9mIG11bHRpcGxlIHF1ZXJpZXMgYXQgb25jZSwgdXNpbmdcblx0KiBmaWx0ZXJzIG9yIHBhcnRpYWwgcXVlcnkga2V5IG1hdGNoaW5nLiBPbmx5IHF1ZXJpZXMgdGhhdCBhbHJlYWR5IGV4aXN0IGFuZCBtYXRjaCB0aGUgZ2l2ZW5cblx0KiBmaWx0ZXJzIGFyZSB1cGRhdGVkOyBubyBuZXcgY2FjaGUgZW50cmllcyBhcmUgY3JlYXRlZC4gSW50ZXJuYWxseSB0aGlzIGNhbGxzXG5cdCoge0BsaW5rIFF1ZXJ5Q2xpZW50I3NldFF1ZXJ5RGF0YX0gZm9yIGVhY2ggbWF0Y2hpbmcgcXVlcnkuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogcXVlcnlDbGllbnQuc2V0UXVlcmllc0RhdGEoeyBxdWVyeUtleTogWydwb3N0cyddIH0sIChvbGRQb3N0cykgPT5cblx0KiAgIG9sZFBvc3RzID8gb2xkUG9zdHMuZmlsdGVyKChwb3N0KSA9PiBwb3N0LmlkICE9PSBkZWxldGVkSWQpIDogb2xkUG9zdHMsXG5cdCogKVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRRdWVyaWVzRGF0YShmaWx0ZXJzLCB1cGRhdGVyLCBvcHRpb25zKSB7XG5cdFx0cmV0dXJuIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4gdGhpcy4jcXVlcnlDYWNoZS5maW5kQWxsKGZpbHRlcnMpLm1hcCgoeyBxdWVyeUtleSB9KSA9PiBbcXVlcnlLZXksIHRoaXMuc2V0UXVlcnlEYXRhKHF1ZXJ5S2V5LCB1cGRhdGVyLCBvcHRpb25zKV0pKTtcblx0fVxuXHQvKipcblx0KiBJbXBlcmF0aXZlIChub24tcmVhY3RpdmUpIHdheSB0byByZXRyaWV2ZSBhbiBleGlzdGluZyBxdWVyeSdzIHN0YXRlLiBJZiB0aGUgcXVlcnkgZG9lcyBub3Rcblx0KiBleGlzdCwgYHVuZGVmaW5lZGAgaXMgcmV0dXJuZWQuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3Qgc3RhdGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeVN0YXRlKFsncG9zdHMnXSlcblx0KiBjb25zb2xlLmxvZyhzdGF0ZT8uZGF0YVVwZGF0ZWRBdClcblx0KiBgYGBcblx0Ki9cblx0Z2V0UXVlcnlTdGF0ZShxdWVyeUtleSkge1xuXHRcdGNvbnN0IG9wdGlvbnMgPSB0aGlzLmRlZmF1bHRRdWVyeU9wdGlvbnMoeyBxdWVyeUtleSB9KTtcblx0XHRyZXR1cm4gdGhpcy4jcXVlcnlDYWNoZS5nZXQob3B0aW9ucy5xdWVyeUhhc2gpPy5zdGF0ZTtcblx0fVxuXHQvKipcblx0KiBSZW1vdmVzIHF1ZXJpZXMgZnJvbSB0aGUgY2FjaGUgdGhhdCBtYXRjaCB0aGUgZ2l2ZW4gZmlsdGVycy4gVW5saWtlXG5cdCoge0BsaW5rIFF1ZXJ5Q2xpZW50I2ludmFsaWRhdGVRdWVyaWVzfSBvciB7QGxpbmsgUXVlcnlDbGllbnQjcmVmZXRjaFF1ZXJpZXN9LCB0aGlzIHJlbW92ZXNcblx0KiBtYXRjaGluZyBxdWVyaWVzIGZyb20gdGhlIGNhY2hlIGluc3RlYWQgb2YgcmVmZXRjaGluZyB0aGVtLiBXaXRob3V0IGZpbHRlcnMsIGV2ZXJ5IHF1ZXJ5IGluXG5cdCogdGhlIGNhY2hlIGlzIHJlbW92ZWQuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogcXVlcnlDbGllbnQucmVtb3ZlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10sIGV4YWN0OiB0cnVlIH0pXG5cdCogYGBgXG5cdCovXG5cdHJlbW92ZVF1ZXJpZXMoZmlsdGVycykge1xuXHRcdGNvbnN0IHF1ZXJ5Q2FjaGUgPSB0aGlzLiNxdWVyeUNhY2hlO1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0cXVlcnlDYWNoZS5maW5kQWxsKGZpbHRlcnMpLmZvckVhY2goKHF1ZXJ5KSA9PiB7XG5cdFx0XHRcdHF1ZXJ5Q2FjaGUucmVtb3ZlKHF1ZXJ5KTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFJlc2V0cyBxdWVyaWVzIG1hdGNoaW5nIHRoZSBnaXZlbiBmaWx0ZXJzIGJhY2sgdG8gdGhlaXIgaW5pdGlhbCBzdGF0ZSAoZS5nLiBhbnlcblx0KiBgaW5pdGlhbERhdGFgKSwgbm90aWZ5aW5nIHN1YnNjcmliZXJzIHJhdGhlciB0aGFuIHJlbW92aW5nIHRoZW0uIEFjdGl2ZSBxdWVyaWVzIGFtb25nIHRoZVxuXHQqIG1hdGNoZWQgc2V0IGFyZSB0aGVuIHJlZmV0Y2hlZCwgYW5kIHRoZSByZXR1cm5lZCBwcm9taXNlIHJlc29sdmVzIG9uY2UgdGhhdCByZWZldGNoIHNldHRsZXMuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogYXdhaXQgcXVlcnlDbGllbnQucmVzZXRRdWVyaWVzKHsgcXVlcnlLZXk6IFsncG9zdHMnXSwgZXhhY3Q6IHRydWUgfSlcblx0KiBgYGBcblx0Ki9cblx0cmVzZXRRdWVyaWVzKGZpbHRlcnMsIG9wdGlvbnMpIHtcblx0XHRjb25zdCBxdWVyeUNhY2hlID0gdGhpcy4jcXVlcnlDYWNoZTtcblx0XHRyZXR1cm4gbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHRjb25zdCBtYXRjaGVkID0gcXVlcnlDYWNoZS5maW5kQWxsKGZpbHRlcnMpO1xuXHRcdFx0Y29uc3QgcXVlcmllc1RvUmVmZXRjaCA9IG5ldyBTZXQobWF0Y2hlZCk7XG5cdFx0XHRtYXRjaGVkLmZvckVhY2goKHF1ZXJ5KSA9PiB7XG5cdFx0XHRcdHF1ZXJ5LnJlc2V0KCk7XG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiB0aGlzLnJlZmV0Y2hRdWVyaWVzKHtcblx0XHRcdFx0dHlwZTogXCJhY3RpdmVcIixcblx0XHRcdFx0cHJlZGljYXRlOiAocXVlcnkpID0+IHF1ZXJpZXNUb1JlZmV0Y2guaGFzKHF1ZXJ5KVxuXHRcdFx0fSwgb3B0aW9ucyk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogQ2FuY2VscyBvdXRnb2luZyBmZXRjaGVzIGZvciBxdWVyaWVzIG1hdGNoaW5nIHRoZSBnaXZlbiBmaWx0ZXJzLiBNb3N0IHVzZWZ1bCB3aGVuIHBlcmZvcm1pbmdcblx0KiBvcHRpbWlzdGljIHVwZGF0ZXMsIHNpbmNlIGFueSBvdXRnb2luZyByZWZldGNoIHRoYXQgcmVzb2x2ZXMgYWZ0ZXJ3YXJkcyB3b3VsZCBvdGhlcndpc2Vcblx0KiBvdmVyd3JpdGUgdGhlIG9wdGltaXN0aWMgdXBkYXRlLiBCeSBkZWZhdWx0IChgcmV2ZXJ0OiB0cnVlYCksIGEgY2FuY2VsbGVkIHF1ZXJ5J3MgZGF0YSBpc1xuXHQqIHJldmVydGVkIHRvIGl0cyBzdGF0ZSBiZWZvcmUgdGhlIG91dGdvaW5nIGZldGNoIHN0YXJ0ZWQuXG5cdCpcblx0KiBUaGUgcmV0dXJuZWQgcHJvbWlzZSBuZXZlciByZWplY3RzLCBldmVuIGlmIGluZGl2aWR1YWwgY2FuY2VsbGF0aW9ucyBmYWlsLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGF3YWl0IHF1ZXJ5Q2xpZW50LmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleTogWydwb3N0cyddLCBleGFjdDogdHJ1ZSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRjYW5jZWxRdWVyaWVzKGZpbHRlcnMsIGNhbmNlbE9wdGlvbnMgPSB7fSkge1xuXHRcdGNvbnN0IGRlZmF1bHRlZENhbmNlbE9wdGlvbnMgPSB7XG5cdFx0XHRyZXZlcnQ6IHRydWUsXG5cdFx0XHQuLi5jYW5jZWxPcHRpb25zXG5cdFx0fTtcblx0XHRjb25zdCBwcm9taXNlcyA9IG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4gdGhpcy4jcXVlcnlDYWNoZS5maW5kQWxsKGZpbHRlcnMpLm1hcCgocXVlcnkpID0+IHF1ZXJ5LmNhbmNlbChkZWZhdWx0ZWRDYW5jZWxPcHRpb25zKSkpO1xuXHRcdHJldHVybiBQcm9taXNlLmFsbChwcm9taXNlcykudGhlbihub29wKS5jYXRjaChub29wKTtcblx0fVxuXHQvKipcblx0KiBNYXJrcyBxdWVyaWVzIG1hdGNoaW5nIHRoZSBnaXZlbiBmaWx0ZXJzIGFzIGludmFsaWRhdGVkLiBVbmxpa2Vcblx0KiB7QGxpbmsgUXVlcnlDbGllbnQjcmVtb3ZlUXVlcmllc30sIGludmFsaWRhdGVkIHF1ZXJpZXMgc3RheSBpbiB0aGUgY2FjaGUuXG5cdCpcblx0KiBVbmxlc3MgYGZpbHRlcnMucmVmZXRjaFR5cGVgIGlzIGAnbm9uZSdgLCBtYXRjaGluZyBxdWVyaWVzIGFyZSB0aGVuIHJlZmV0Y2hlZCB2aWFcblx0KiB7QGxpbmsgUXVlcnlDbGllbnQjcmVmZXRjaFF1ZXJpZXN9LCB1c2luZyBgZmlsdGVycy5yZWZldGNoVHlwZWAgaWYgc2V0LCBvdGhlcndpc2Vcblx0KiBgZmlsdGVycy50eXBlYCwgb3RoZXJ3aXNlIGAnYWN0aXZlJ2AuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogYXdhaXQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWydwb3N0cyddLCByZWZldGNoVHlwZTogJ2FjdGl2ZScgfSlcblx0KiBgYGBcblx0Ki9cblx0aW52YWxpZGF0ZVF1ZXJpZXMoZmlsdGVycywgb3B0aW9ucyA9IHt9KSB7XG5cdFx0cmV0dXJuIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0dGhpcy4jcXVlcnlDYWNoZS5maW5kQWxsKGZpbHRlcnMpLmZvckVhY2goKHF1ZXJ5KSA9PiB7XG5cdFx0XHRcdHF1ZXJ5LmludmFsaWRhdGUoKTtcblx0XHRcdH0pO1xuXHRcdFx0aWYgKGZpbHRlcnM/LnJlZmV0Y2hUeXBlID09PSBcIm5vbmVcIikgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuXHRcdFx0cmV0dXJuIHRoaXMucmVmZXRjaFF1ZXJpZXMoe1xuXHRcdFx0XHQuLi5maWx0ZXJzLFxuXHRcdFx0XHR0eXBlOiBmaWx0ZXJzPy5yZWZldGNoVHlwZSA/PyBmaWx0ZXJzPy50eXBlID8/IFwiYWN0aXZlXCJcblx0XHRcdH0sIG9wdGlvbnMpO1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFJlZmV0Y2hlcyBxdWVyaWVzIG1hdGNoaW5nIHRoZSBnaXZlbiBmaWx0ZXJzLCByZWdhcmRsZXNzIG9mIHdoZXRoZXIgdGhleSBhcmUgc3RhbGUuIFdpdGhvdXRcblx0KiBmaWx0ZXJzLCBldmVyeSBxdWVyeSBpbiB0aGUgY2FjaGUgaXMgcmVmZXRjaGVkLiBRdWVyaWVzIHRoYXQgYXJlIGRpc2FibGVkLCBvciBzdGF0aWMgKG9ubHlcblx0KiBoYXZlIG9ic2VydmVycyB3aXRoIGEgc3RhdGljIGBzdGFsZVRpbWVgKSwgYXJlIG5ldmVyIHJlZmV0Y2hlZC5cblx0KlxuXHQqIEJ5IGRlZmF1bHQgKGBjYW5jZWxSZWZldGNoOiB0cnVlYCksIGEgY3VycmVudGx5IHJ1bm5pbmcgZmV0Y2ggaXMgY2FuY2VsbGVkIGJlZm9yZSB0aGUgbmV3XG5cdCogb25lIHN0YXJ0cy4gVGhlIHJldHVybmVkIHByb21pc2UgcmVzb2x2ZXMgb25jZSBhbGwgbWF0Y2hpbmcgcXVlcmllcyBoYXZlIHNldHRsZWQ7IGl0IGRvZXNcblx0KiBub3QgcmVqZWN0IG9uIGluZGl2aWR1YWwgcXVlcnkgZmFpbHVyZXMgdW5sZXNzIGB0aHJvd09uRXJyb3JgIGlzIHNldC5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiAvLyByZWZldGNoIGFsbCBhY3RpdmUgcXVlcmllcyBwYXJ0aWFsbHkgbWF0Y2hpbmcgYSBxdWVyeSBrZXk6XG5cdCogYXdhaXQgcXVlcnlDbGllbnQucmVmZXRjaFF1ZXJpZXMoeyBxdWVyeUtleTogWydwb3N0cyddLCB0eXBlOiAnYWN0aXZlJyB9KVxuXHQqIGBgYFxuXHQqL1xuXHRyZWZldGNoUXVlcmllcyhmaWx0ZXJzLCBvcHRpb25zID0ge30pIHtcblx0XHRjb25zdCBmZXRjaE9wdGlvbnMgPSB7XG5cdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0Y2FuY2VsUmVmZXRjaDogb3B0aW9ucy5jYW5jZWxSZWZldGNoID8/IHRydWVcblx0XHR9O1xuXHRcdGNvbnN0IHByb21pc2VzID0gbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykuZmlsdGVyKChxdWVyeSkgPT4gIXF1ZXJ5LmlzRGlzYWJsZWQoKSAmJiAhcXVlcnkuaXNTdGF0aWMoKSkubWFwKChxdWVyeSkgPT4ge1xuXHRcdFx0bGV0IHByb21pc2UgPSBxdWVyeS5mZXRjaCh2b2lkIDAsIGZldGNoT3B0aW9ucyk7XG5cdFx0XHRpZiAoIWZldGNoT3B0aW9ucy50aHJvd09uRXJyb3IpIHByb21pc2UgPSBwcm9taXNlLmNhdGNoKG5vb3ApO1xuXHRcdFx0cmV0dXJuIHF1ZXJ5LnN0YXRlLmZldGNoU3RhdHVzID09PSBcInBhdXNlZFwiID8gUHJvbWlzZS5yZXNvbHZlKCkgOiBwcm9taXNlO1xuXHRcdH0pKTtcblx0XHRyZXR1cm4gUHJvbWlzZS5hbGwocHJvbWlzZXMpLnRoZW4obm9vcCk7XG5cdH1cblx0LyoqXG5cdCogQXN5bmNocm9ub3VzIG1ldGhvZCB0byBmZXRjaCBhbmQgY2FjaGUgYSBxdWVyeSwgcmVzb2x2aW5nIHdpdGggdGhlIGRhdGEgb3IgdGhyb3dpbmcgd2l0aFxuXHQqIHRoZSBlcnJvci5cblx0KlxuXHQqIElmIHRoZSBxdWVyeSBhbHJlYWR5IGV4aXN0cyBpbiB0aGUgY2FjaGUgYW5kIGl0cyBkYXRhIGlzIG5vdCBzdGFsZSAocGVyIHRoZSBnaXZlblxuXHQqIGBzdGFsZVRpbWVgKSwgdGhlIGNhY2hlZCBkYXRhIGlzIHJldHVybmVkIHdpdGhvdXQgZmV0Y2hpbmcuIE90aGVyd2lzZSwgdGhlIHF1ZXJ5IGlzIGZldGNoZWRcblx0KiBhbmQgdGhlIHByb21pc2UgcmVzb2x2ZXMgb25jZSB0aGUgZmV0Y2ggc2V0dGxlcy4gSWYgYSBgc2VsZWN0YCBmdW5jdGlvbiBpcyBwcm92aWRlZCwgaXQgaXNcblx0KiBhcHBsaWVkIHRvIHRoZSBkYXRhIGluIGJvdGggY2FzZXMgKGNhY2hlZCBvciBmcmVzaGx5IGZldGNoZWQpIGJlZm9yZSBpdCBpcyByZXR1cm5lZC5cblx0KlxuXHQqIFVubGlrZSBhIHJlYWN0aXZlIG9ic2VydmVyLCByZXRyaWVzIGFyZSBkaXNhYmxlZCBieSBkZWZhdWx0IGhlcmUgKGByZXRyeTogZmFsc2VgKSB1bmxlc3Ncblx0KiBleHBsaWNpdGx5IGNvbmZpZ3VyZWQsIHNpbmNlIHRoZXJlIGlzIG5vIGNvbXBvbmVudCB0byBjYXRjaCBhIHRocm93biBlcnJvciBhbmQgcmV0cnkgdGhyb3VnaFxuXHQqIHJlLXJlbmRlci5cblx0KlxuXHQqIFRoZSBhY2NlcHRlZCBvcHRpb25zIGFyZSBgUXVlcnlPYnNlcnZlck9wdGlvbnNgIG1pbnVzIHRoZSBmaWVsZHMgdGhhdCBvbmx5IG1ha2Ugc2Vuc2UgZm9yIGFcblx0KiByZWFjdGl2ZSBvYnNlcnZlciDigJQgYGVuYWJsZWRgLCBgcmVmZXRjaEludGVydmFsYCwgYHJlZmV0Y2hJbnRlcnZhbEluQmFja2dyb3VuZGAsXG5cdCogYHJlZmV0Y2hPbldpbmRvd0ZvY3VzYCwgYHJlZmV0Y2hPblJlY29ubmVjdGAsIGByZWZldGNoT25Nb3VudGAsIGByZXRyeU9uTW91bnRgLFxuXHQqIGBub3RpZnlPbkNoYW5nZVByb3BzYCwgYHRocm93T25FcnJvcmAsIGBzdXNwZW5zZWAsIGFuZCBgcGxhY2Vob2xkZXJEYXRhYCBhcmUgbm90IHBhcnQgb2YgdGhpc1xuXHQqIG1ldGhvZCdzIG9wdGlvbnMuXG5cdCpcblx0KiBUaGlzIG1ldGhvZCByZXBsYWNlcyB0aGUgZGVwcmVjYXRlZCBgZmV0Y2hRdWVyeWAsIGFuZCDigJQgY29tYmluZWQgd2l0aFxuXHQqIGB7IHN0YWxlVGltZTogJ3N0YXRpYycgfWAg4oCUIHRoZSBkZXByZWNhdGVkIGBlbnN1cmVRdWVyeURhdGFgLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIHRyeSB7XG5cdCogICBjb25zdCBkYXRhID0gYXdhaXQgcXVlcnlDbGllbnQucXVlcnkoeyBxdWVyeUtleSwgcXVlcnlGbiwgc3RhbGVUaW1lOiAxMDAwMCB9KVxuXHQqIH0gY2F0Y2ggKGVycm9yKSB7XG5cdCogICBjb25zb2xlLmxvZyhlcnJvcilcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdGFzeW5jIHF1ZXJ5KG9wdGlvbnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGlmIChkZWZhdWx0ZWRPcHRpb25zLnJldHJ5ID09PSB2b2lkIDApIGRlZmF1bHRlZE9wdGlvbnMucmV0cnkgPSBmYWxzZTtcblx0XHRjb25zdCBxdWVyeSA9IHRoaXMuI3F1ZXJ5Q2FjaGUuYnVpbGQodGhpcywgZGVmYXVsdGVkT3B0aW9ucyk7XG5cdFx0Y29uc3QgcXVlcnlEYXRhID0gcXVlcnkuaXNTdGFsZUJ5VGltZShyZXNvbHZlUXVlcnlWYWx1ZShkZWZhdWx0ZWRPcHRpb25zLnN0YWxlVGltZSwgcXVlcnkpKSA/IGF3YWl0IHF1ZXJ5LmZldGNoKGRlZmF1bHRlZE9wdGlvbnMpIDogcXVlcnkuc3RhdGUuZGF0YTtcblx0XHRjb25zdCBzZWxlY3QgPSBkZWZhdWx0ZWRPcHRpb25zLnNlbGVjdDtcblx0XHRpZiAoc2VsZWN0KSByZXR1cm4gc2VsZWN0KHF1ZXJ5RGF0YSk7XG5cdFx0cmV0dXJuIHF1ZXJ5RGF0YTtcblx0fVxuXHQvKipcblx0KiBAZGVwcmVjYXRlZCBVc2UgcXVlcnlDbGllbnQucXVlcnkob3B0aW9ucykgaW5zdGVhZC4gVGhpcyBtZXRob2Qgd2lsbCBiZSByZW1vdmVkIGluIHRoZSBuZXh0IG1ham9yIHZlcnNpb24uXG5cdCovXG5cdGZldGNoUXVlcnkob3B0aW9ucykge1xuXHRcdGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSB0aGlzLmRlZmF1bHRRdWVyeU9wdGlvbnMob3B0aW9ucyk7XG5cdFx0aWYgKGRlZmF1bHRlZE9wdGlvbnMucmV0cnkgPT09IHZvaWQgMCkgZGVmYXVsdGVkT3B0aW9ucy5yZXRyeSA9IGZhbHNlO1xuXHRcdGNvbnN0IHF1ZXJ5ID0gdGhpcy4jcXVlcnlDYWNoZS5idWlsZCh0aGlzLCBkZWZhdWx0ZWRPcHRpb25zKTtcblx0XHRyZXR1cm4gcXVlcnkuaXNTdGFsZUJ5VGltZShyZXNvbHZlUXVlcnlWYWx1ZShkZWZhdWx0ZWRPcHRpb25zLnN0YWxlVGltZSwgcXVlcnkpKSA/IHF1ZXJ5LmZldGNoKGRlZmF1bHRlZE9wdGlvbnMpIDogUHJvbWlzZS5yZXNvbHZlKHF1ZXJ5LnN0YXRlLmRhdGEpO1xuXHR9XG5cdC8qKlxuXHQqIEBkZXByZWNhdGVkIFVzZSBxdWVyeUNsaWVudC5xdWVyeShvcHRpb25zKSBpbnN0ZWFkLiBZb3UgY2FuIHN3YWxsb3cgZXJyb3JzIHdpdGggYC5jYXRjaChub29wKWAuIFRoaXMgbWV0aG9kIHdpbGwgYmUgcmVtb3ZlZCBpbiB0aGUgbmV4dCBtYWpvciB2ZXJzaW9uLlxuXHQqL1xuXHRwcmVmZXRjaFF1ZXJ5KG9wdGlvbnMpIHtcblx0XHRyZXR1cm4gdGhpcy5mZXRjaFF1ZXJ5KG9wdGlvbnMpLnRoZW4obm9vcCkuY2F0Y2gobm9vcCk7XG5cdH1cblx0LyoqXG5cdCogQXN5bmNocm9ub3VzIG1ldGhvZCB0byBmZXRjaCBhbmQgY2FjaGUgYW4gaW5maW5pdGUgcXVlcnksIHJlc29sdmluZyB3aXRoIGFuXG5cdCoge0BsaW5rIEluZmluaXRlRGF0YX0gb2JqZWN0IG9yIHRocm93aW5nIHdpdGggdGhlIGVycm9yLlxuXHQqXG5cdCogQmVoYXZlcyBsaWtlIHtAbGluayBRdWVyeUNsaWVudCNxdWVyeX0sIGFjY2VwdGluZyB0aGUgc2FtZSBvcHRpb25zIChtaW51c1xuXHQqIGBpbml0aWFsUGFnZVBhcmFtYCksIHBsdXMgdGhlIHJlcXVpcmVkIGBpbml0aWFsUGFnZVBhcmFtYCwgYW5kIGFuIG9wdGlvbmFsIGBwYWdlc2AgL1xuXHQqIGBnZXROZXh0UGFnZVBhcmFtYCBwYWlyIHVzZWQgdG8gcmVmZXRjaCBhIGZpeGVkIG51bWJlciBvZiBwYWdlcyBmcm9tIHRoZSBzdGFydC5cblx0KlxuXHQqIFRoaXMgbWV0aG9kIHJlcGxhY2VzIHRoZSBkZXByZWNhdGVkIGBmZXRjaEluZmluaXRlUXVlcnlgLCBhbmQg4oCUIGNvbWJpbmVkIHdpdGhcblx0KiBgeyBzdGFsZVRpbWU6ICdzdGF0aWMnIH1gIOKAlCB0aGUgZGVwcmVjYXRlZCBgZW5zdXJlSW5maW5pdGVRdWVyeURhdGFgLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIHRyeSB7XG5cdCogICBjb25zdCBkYXRhID0gYXdhaXQgcXVlcnlDbGllbnQuaW5maW5pdGVRdWVyeSh7IHF1ZXJ5S2V5LCBxdWVyeUZuLCBpbml0aWFsUGFnZVBhcmFtOiAwIH0pXG5cdCogICBjb25zb2xlLmxvZyhkYXRhLnBhZ2VzKVxuXHQqIH0gY2F0Y2ggKGVycm9yKSB7XG5cdCogICBjb25zb2xlLmxvZyhlcnJvcilcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdGluZmluaXRlUXVlcnkob3B0aW9ucykge1xuXHRcdG9wdGlvbnMuX3R5cGUgPSBcImluZmluaXRlXCI7XG5cdFx0cmV0dXJuIHRoaXMucXVlcnkob3B0aW9ucyk7XG5cdH1cblx0LyoqXG5cdCogQGRlcHJlY2F0ZWQgVXNlIHF1ZXJ5Q2xpZW50LmluZmluaXRlUXVlcnkob3B0aW9ucykgaW5zdGVhZC4gVGhpcyBtZXRob2Qgd2lsbCBiZSByZW1vdmVkIGluIHRoZSBuZXh0IG1ham9yIHZlcnNpb24uXG5cdCovXG5cdGZldGNoSW5maW5pdGVRdWVyeShvcHRpb25zKSB7XG5cdFx0b3B0aW9ucy5fdHlwZSA9IFwiaW5maW5pdGVcIjtcblx0XHRyZXR1cm4gdGhpcy5mZXRjaFF1ZXJ5KG9wdGlvbnMpO1xuXHR9XG5cdC8qKlxuXHQqIEBkZXByZWNhdGVkIFVzZSBxdWVyeUNsaWVudC5pbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpIGluc3RlYWQuIFlvdSBjYW4gc3dhbGxvdyBlcnJvcnMgd2l0aCBgLmNhdGNoKG5vb3ApYC4gVGhpcyBtZXRob2Qgd2lsbCBiZSByZW1vdmVkIGluIHRoZSBuZXh0IG1ham9yIHZlcnNpb24uXG5cdCovXG5cdHByZWZldGNoSW5maW5pdGVRdWVyeShvcHRpb25zKSB7XG5cdFx0cmV0dXJuIHRoaXMuZmV0Y2hJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpLnRoZW4obm9vcCkuY2F0Y2gobm9vcCk7XG5cdH1cblx0LyoqXG5cdCogQGRlcHJlY2F0ZWQgVXNlIHF1ZXJ5Q2xpZW50LmluZmluaXRlUXVlcnkoeyAuLi5vcHRpb25zLCBzdGFsZVRpbWU6ICdzdGF0aWMnIH0pIGluc3RlYWQuIFRoaXMgbWV0aG9kIHdpbGwgYmUgcmVtb3ZlZCBpbiB0aGUgbmV4dCBtYWpvciB2ZXJzaW9uLlxuXHQqL1xuXHRlbnN1cmVJbmZpbml0ZVF1ZXJ5RGF0YShvcHRpb25zKSB7XG5cdFx0b3B0aW9ucy5fdHlwZSA9IFwiaW5maW5pdGVcIjtcblx0XHRyZXR1cm4gdGhpcy5lbnN1cmVRdWVyeURhdGEob3B0aW9ucyk7XG5cdH1cblx0LyoqXG5cdCogUmVzdW1lcyBtdXRhdGlvbnMgdGhhdCB3ZXJlIHBhdXNlZCBiZWNhdXNlIHRoZXJlIHdhcyBubyBuZXR3b3JrIGNvbm5lY3Rpb24uIERvZXMgbm90aGluZ1xuXHQqIChyZXNvbHZpbmcgaW1tZWRpYXRlbHkpIGlmIHRoZSBjbGllbnQgaXMgY3VycmVudGx5IG9mZmxpbmUuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaW1wb3J0IHsgUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KClcblx0KiBhd2FpdCBxdWVyeUNsaWVudC5yZXN1bWVQYXVzZWRNdXRhdGlvbnMoKVxuXHQqIGBgYFxuXHQqL1xuXHRyZXN1bWVQYXVzZWRNdXRhdGlvbnMoKSB7XG5cdFx0aWYgKG9ubGluZU1hbmFnZXIuaXNPbmxpbmUoKSkgcmV0dXJuIHRoaXMuI211dGF0aW9uQ2FjaGUucmVzdW1lUGF1c2VkTXV0YXRpb25zKCk7XG5cdFx0cmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIHF1ZXJ5IGNhY2hlIHRoaXMgY2xpZW50IGlzIGNvbm5lY3RlZCB0by5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KiBjb25zdCBxdWVyaWVzID0gcXVlcnlDYWNoZS5maW5kQWxsKHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRRdWVyeUNhY2hlKCkge1xuXHRcdHJldHVybiB0aGlzLiNxdWVyeUNhY2hlO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIG11dGF0aW9uIGNhY2hlIHRoaXMgY2xpZW50IGlzIGNvbm5lY3RlZCB0by5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuXHQqIGNvbnN0IG11dGF0aW9uQ2FjaGUgPSBxdWVyeUNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKClcblx0KiBjb25zdCBtdXRhdGlvbnMgPSBtdXRhdGlvbkNhY2hlLmZpbmRBbGwoeyBzdGF0dXM6ICdwZW5kaW5nJyB9KVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRNdXRhdGlvbkNhY2hlKCkge1xuXHRcdHJldHVybiB0aGlzLiNtdXRhdGlvbkNhY2hlO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIGRlZmF1bHQgb3B0aW9ucyB0aGF0IHdlcmUgc2V0IHdoZW4gY3JlYXRpbmcgdGhlIGNsaWVudCwgb3IgdmlhXG5cdCoge0BsaW5rIFF1ZXJ5Q2xpZW50I3NldERlZmF1bHRPcHRpb25zfS5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuXHQqIGNvbnN0IGRlZmF1bHRPcHRpb25zID0gcXVlcnlDbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXREZWZhdWx0T3B0aW9ucygpIHtcblx0XHRyZXR1cm4gdGhpcy4jZGVmYXVsdE9wdGlvbnM7XG5cdH1cblx0LyoqXG5cdCogRHluYW1pY2FsbHkgc2V0cyB0aGUgZGVmYXVsdCBvcHRpb25zIGZvciB0aGlzIGNsaWVudCwgb3ZlcndyaXRpbmcgYW55IHByZXZpb3VzbHkgZGVmaW5lZFxuXHQqIGRlZmF1bHQgb3B0aW9ucy5cblx0KlxuXHQqIEBzZWUge0BsaW5rIFF1ZXJ5Q2xpZW50I2dldERlZmF1bHRPcHRpb25zfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuXHQqIHF1ZXJ5Q2xpZW50LnNldERlZmF1bHRPcHRpb25zKHtcblx0KiAgIHF1ZXJpZXM6IHtcblx0KiAgICAgc3RhbGVUaW1lOiBJbmZpbml0eSxcblx0KiAgIH0sXG5cdCogfSlcblx0KiBgYGBcblx0Ki9cblx0c2V0RGVmYXVsdE9wdGlvbnMob3B0aW9ucykge1xuXHRcdHRoaXMuI2RlZmF1bHRPcHRpb25zID0gb3B0aW9ucztcblx0fVxuXHQvKipcblx0KiBTZXRzIGRlZmF1bHQgb3B0aW9ucyBmb3IgcXVlcmllcyB3aG9zZSBxdWVyeSBrZXkgcGFydGlhbGx5IG1hdGNoZXMgdGhlIGdpdmVuIGBxdWVyeUtleWAuXG5cdCpcblx0KiBJZiBzZXZlcmFsIHJlZ2lzdGVyZWQgcXVlcnkgZGVmYXVsdHMgbWF0Y2ggYSBnaXZlbiBxdWVyeSBrZXksIHRoZXkgYXJlIG1lcmdlZCB0b2dldGhlciBpblxuXHQqIHJlZ2lzdHJhdGlvbiBvcmRlciBieSB7QGxpbmsgUXVlcnlDbGllbnQjZ2V0UXVlcnlEZWZhdWx0c30sIHNvIHJlZ2lzdGVyIGRlZmF1bHRzIGZyb20gdGhlXG5cdCogbW9zdCBnZW5lcmljIGtleSB0byB0aGUgbGVhc3QgZ2VuZXJpYyBvbmUg4oCUIG1vcmUgc3BlY2lmaWMgZGVmYXVsdHMgc2hvdWxkIGJlIHJlZ2lzdGVyZWRcblx0KiBhZnRlciBtb3JlIGdlbmVyaWMgb25lcyBzbyB0aGV5IHRha2UgcHJlY2VkZW5jZS5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBxdWVyeUNsaWVudC5zZXRRdWVyeURlZmF1bHRzKFsncG9zdHMnXSwgeyBxdWVyeUZuOiBmZXRjaFBvc3RzIH0pXG5cdCpcblx0KiBhd2FpdCBxdWVyeUNsaWVudC5xdWVyeSh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10gfSlcblx0KiBgYGBcblx0Ki9cblx0c2V0UXVlcnlEZWZhdWx0cyhxdWVyeUtleSwgb3B0aW9ucykge1xuXHRcdHRoaXMuI3F1ZXJ5RGVmYXVsdHMuc2V0KGhhc2hLZXkocXVlcnlLZXkpLCB7XG5cdFx0XHRxdWVyeUtleSxcblx0XHRcdGRlZmF1bHRPcHRpb25zOiBvcHRpb25zXG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgZGVmYXVsdCBvcHRpb25zIHJlZ2lzdGVyZWQgZm9yIHF1ZXJpZXMgd2hvc2UgcXVlcnkga2V5IHBhcnRpYWxseSBtYXRjaGVzIHRoZVxuXHQqIGdpdmVuIGBxdWVyeUtleWAsIHZpYSB7QGxpbmsgUXVlcnlDbGllbnQjc2V0UXVlcnlEZWZhdWx0c30uIElmIG11bHRpcGxlIHJlZ2lzdGVyZWQgZGVmYXVsdHNcblx0KiBtYXRjaCwgdGhleSBhcmUgbWVyZ2VkIHRvZ2V0aGVyIGluIHJlZ2lzdHJhdGlvbiBvcmRlci5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBkZWZhdWx0T3B0aW9ucyA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5RGVmYXVsdHMoWydwb3N0cyddKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRRdWVyeURlZmF1bHRzKHF1ZXJ5S2V5KSB7XG5cdFx0Y29uc3QgZGVmYXVsdHMgPSBbLi4udGhpcy4jcXVlcnlEZWZhdWx0cy52YWx1ZXMoKV07XG5cdFx0Y29uc3QgcmVzdWx0ID0ge307XG5cdFx0ZGVmYXVsdHMuZm9yRWFjaCgocXVlcnlEZWZhdWx0KSA9PiB7XG5cdFx0XHRpZiAocGFydGlhbE1hdGNoS2V5KHF1ZXJ5S2V5LCBxdWVyeURlZmF1bHQucXVlcnlLZXkpKSBPYmplY3QuYXNzaWduKHJlc3VsdCwgcXVlcnlEZWZhdWx0LmRlZmF1bHRPcHRpb25zKTtcblx0XHR9KTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG5cdC8qKlxuXHQqIFNldHMgZGVmYXVsdCBvcHRpb25zIGZvciBtdXRhdGlvbnMgd2hvc2UgbXV0YXRpb24ga2V5IHBhcnRpYWxseSBtYXRjaGVzIHRoZSBnaXZlblxuXHQqIGBtdXRhdGlvbktleWAuIEFzIHdpdGgge0BsaW5rIFF1ZXJ5Q2xpZW50I3NldFF1ZXJ5RGVmYXVsdHN9LCB0aGUgb3JkZXIgb2YgcmVnaXN0cmF0aW9uXG5cdCogbWF0dGVycyB3aGVuIHNldmVyYWwgcmVnaXN0ZXJlZCBkZWZhdWx0cyBtYXRjaCB0aGUgc2FtZSBtdXRhdGlvbiBrZXkuXG5cdCpcblx0KiBAc2VlIHtAbGluayBRdWVyeUNsaWVudCNnZXRNdXRhdGlvbkRlZmF1bHRzfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBxdWVyeUNsaWVudC5zZXRNdXRhdGlvbkRlZmF1bHRzKFsnYWRkUG9zdCddLCB7IG11dGF0aW9uRm46IGFkZFBvc3QgfSlcblx0KiBgYGBcblx0Ki9cblx0c2V0TXV0YXRpb25EZWZhdWx0cyhtdXRhdGlvbktleSwgb3B0aW9ucykge1xuXHRcdHRoaXMuI211dGF0aW9uRGVmYXVsdHMuc2V0KGhhc2hLZXkobXV0YXRpb25LZXkpLCB7XG5cdFx0XHRtdXRhdGlvbktleSxcblx0XHRcdGRlZmF1bHRPcHRpb25zOiBvcHRpb25zXG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgZGVmYXVsdCBvcHRpb25zIHJlZ2lzdGVyZWQgZm9yIG11dGF0aW9ucyB3aG9zZSBtdXRhdGlvbiBrZXkgcGFydGlhbGx5IG1hdGNoZXNcblx0KiB0aGUgZ2l2ZW4gYG11dGF0aW9uS2V5YCwgdmlhIHtAbGluayBRdWVyeUNsaWVudCNzZXRNdXRhdGlvbkRlZmF1bHRzfS4gSWYgbXVsdGlwbGUgcmVnaXN0ZXJlZFxuXHQqIGRlZmF1bHRzIG1hdGNoLCB0aGV5IGFyZSBtZXJnZWQgdG9nZXRoZXIgaW4gcmVnaXN0cmF0aW9uIG9yZGVyLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IGRlZmF1bHRPcHRpb25zID0gcXVlcnlDbGllbnQuZ2V0TXV0YXRpb25EZWZhdWx0cyhbJ2FkZFBvc3QnXSlcblx0KiBgYGBcblx0Ki9cblx0Z2V0TXV0YXRpb25EZWZhdWx0cyhtdXRhdGlvbktleSkge1xuXHRcdGNvbnN0IGRlZmF1bHRzID0gWy4uLnRoaXMuI211dGF0aW9uRGVmYXVsdHMudmFsdWVzKCldO1xuXHRcdGNvbnN0IHJlc3VsdCA9IHt9O1xuXHRcdGRlZmF1bHRzLmZvckVhY2goKHF1ZXJ5RGVmYXVsdCkgPT4ge1xuXHRcdFx0aWYgKHBhcnRpYWxNYXRjaEtleShtdXRhdGlvbktleSwgcXVlcnlEZWZhdWx0Lm11dGF0aW9uS2V5KSkgT2JqZWN0LmFzc2lnbihyZXN1bHQsIHF1ZXJ5RGVmYXVsdC5kZWZhdWx0T3B0aW9ucyk7XG5cdFx0fSk7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fVxuXHQvKipcblx0KiBDYWxsZWQgYnkgZnJhbWV3b3JrIGFkYXB0ZXJzIChlLmcuIGluc2lkZSBgdXNlUXVlcnlgKSB0byByZXNvbHZlIHRoZSBvcHRpb25zIHBhc3NlZCBieSB0aGVcblx0KiBjYWxsZXIgaW50byB0aGVpciBmaW5hbCwgZGVmYXVsdGVkIGZvcm06IG1lcmdpbmcgYHF1ZXJ5Q2xpZW50LnNldFF1ZXJ5RGVmYXVsdHNgIGZvciB0aGVcblx0KiBnaXZlbiBgcXVlcnlLZXlgLCB0aGVuIHRoZSBjbGllbnQncyBvd24gYGRlZmF1bHRPcHRpb25zLnF1ZXJpZXNgLCB0aGVuIHRoZSBjYWxsZXIncyBvcHRpb25zXG5cdCogb24gdG9wLiBBIG5vLW9wIGlmIHRoZSBvcHRpb25zIGFyZSBhbHJlYWR5IGRlZmF1bHRlZCAoYF9kZWZhdWx0ZWQ6IHRydWVgKS5cblx0Ki9cblx0ZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0aWYgKG9wdGlvbnMuX2RlZmF1bHRlZCkgcmV0dXJuIG9wdGlvbnM7XG5cdFx0Y29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IHtcblx0XHRcdC4uLnRoaXMuI2RlZmF1bHRPcHRpb25zLnF1ZXJpZXMsXG5cdFx0XHQuLi50aGlzLmdldFF1ZXJ5RGVmYXVsdHMob3B0aW9ucy5xdWVyeUtleSksXG5cdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0X2RlZmF1bHRlZDogdHJ1ZVxuXHRcdH07XG5cdFx0aWYgKCFkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaCkgZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUhhc2ggPSBoYXNoUXVlcnlLZXlCeU9wdGlvbnMoZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUtleSwgZGVmYXVsdGVkT3B0aW9ucyk7XG5cdFx0aWYgKGRlZmF1bHRlZE9wdGlvbnMucmVmZXRjaE9uUmVjb25uZWN0ID09PSB2b2lkIDApIGRlZmF1bHRlZE9wdGlvbnMucmVmZXRjaE9uUmVjb25uZWN0ID0gZGVmYXVsdGVkT3B0aW9ucy5uZXR3b3JrTW9kZSAhPT0gXCJhbHdheXNcIjtcblx0XHRpZiAoZGVmYXVsdGVkT3B0aW9ucy50aHJvd09uRXJyb3IgPT09IHZvaWQgMCkgZGVmYXVsdGVkT3B0aW9ucy50aHJvd09uRXJyb3IgPSAhIWRlZmF1bHRlZE9wdGlvbnMuc3VzcGVuc2U7XG5cdFx0aWYgKCFkZWZhdWx0ZWRPcHRpb25zLm5ldHdvcmtNb2RlICYmIGRlZmF1bHRlZE9wdGlvbnMucGVyc2lzdGVyKSBkZWZhdWx0ZWRPcHRpb25zLm5ldHdvcmtNb2RlID0gXCJvZmZsaW5lRmlyc3RcIjtcblx0XHRpZiAoZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUZuID09PSBza2lwVG9rZW4pIGRlZmF1bHRlZE9wdGlvbnMuZW5hYmxlZCA9IGZhbHNlO1xuXHRcdHJldHVybiBkZWZhdWx0ZWRPcHRpb25zO1xuXHR9XG5cdC8qKlxuXHQqIFRoZSBtdXRhdGlvbiBjb3VudGVycGFydCBvZiB7QGxpbmsgUXVlcnlDbGllbnQjZGVmYXVsdFF1ZXJ5T3B0aW9uc30uIENhbGxlZCBieSBmcmFtZXdvcmtcblx0KiBhZGFwdGVycyAoZS5nLiBpbnNpZGUgYHVzZU11dGF0aW9uYCkgdG8gbWVyZ2UgYHF1ZXJ5Q2xpZW50LnNldE11dGF0aW9uRGVmYXVsdHNgIGZvciB0aGVcblx0KiBnaXZlbiBgbXV0YXRpb25LZXlgLCB0aGVuIHRoZSBjbGllbnQncyBgZGVmYXVsdE9wdGlvbnMubXV0YXRpb25zYCwgdGhlbiB0aGUgY2FsbGVyJ3Mgb3B0aW9uc1xuXHQqIG9uIHRvcC4gQSBuby1vcCBpZiB0aGUgb3B0aW9ucyBhcmUgYWxyZWFkeSBkZWZhdWx0ZWQgKGBfZGVmYXVsdGVkOiB0cnVlYCkuXG5cdCovXG5cdGRlZmF1bHRNdXRhdGlvbk9wdGlvbnMob3B0aW9ucykge1xuXHRcdGlmIChvcHRpb25zPy5fZGVmYXVsdGVkKSByZXR1cm4gb3B0aW9ucztcblx0XHRyZXR1cm4ge1xuXHRcdFx0Li4udGhpcy4jZGVmYXVsdE9wdGlvbnMubXV0YXRpb25zLFxuXHRcdFx0Li4ub3B0aW9ucz8ubXV0YXRpb25LZXkgJiYgdGhpcy5nZXRNdXRhdGlvbkRlZmF1bHRzKG9wdGlvbnMubXV0YXRpb25LZXkpLFxuXHRcdFx0Li4ub3B0aW9ucyxcblx0XHRcdF9kZWZhdWx0ZWQ6IHRydWVcblx0XHR9O1xuXHR9XG5cdC8qKlxuXHQqIENsZWFycyBib3RoIHRoZSBxdWVyeSBjYWNoZSBhbmQgdGhlIG11dGF0aW9uIGNhY2hlIHRoaXMgY2xpZW50IGlzIGNvbm5lY3RlZCB0by5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuXHQqIHF1ZXJ5Q2xpZW50LmNsZWFyKClcblx0KiBgYGBcblx0Ki9cblx0Y2xlYXIoKSB7XG5cdFx0dGhpcy4jcXVlcnlDYWNoZS5jbGVhcigpO1xuXHRcdHRoaXMuI211dGF0aW9uQ2FjaGUuY2xlYXIoKTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUXVlcnlDbGllbnQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cXVlcnlDbGllbnQuanMubWFwIiwiaW1wb3J0IHsgYWRkQ29uc3VtZUF3YXJlU2lnbmFsLCBhZGRUb0VuZCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG4vLyNyZWdpb24gc3JjL3N0cmVhbWVkUXVlcnkudHNcbi8qKlxuKiBUaGlzIGlzIGEgaGVscGVyIGZ1bmN0aW9uIHRvIGNyZWF0ZSBhIHF1ZXJ5IGZ1bmN0aW9uIHRoYXQgc3RyZWFtcyBkYXRhIGZyb20gYW4gQXN5bmNJdGVyYWJsZS5cbiogRGF0YSB3aWxsIGJlIGFuIEFycmF5IG9mIGFsbCB0aGUgY2h1bmtzIHJlY2VpdmVkLlxuKiBUaGUgcXVlcnkgd2lsbCBiZSBpbiBhICdwZW5kaW5nJyBzdGF0ZSB1bnRpbCB0aGUgZmlyc3QgY2h1bmsgb2YgZGF0YSBpcyByZWNlaXZlZCwgYnV0IHdpbGwgZ28gdG8gJ3N1Y2Nlc3MnIGFmdGVyIHRoYXQuXG4qIFRoZSBxdWVyeSB3aWxsIHN0YXkgaW4gZmV0Y2hTdGF0dXMgJ2ZldGNoaW5nJyB1bnRpbCB0aGUgc3RyZWFtIGVuZHMuXG4qIEBwYXJhbSBzdHJlYW1GbiAtIFRoZSBmdW5jdGlvbiB0aGF0IHJldHVybnMgYW4gQXN5bmNJdGVyYWJsZSB0byBzdHJlYW0gZGF0YSBmcm9tLlxuKiBAcGFyYW0gcmVmZXRjaE1vZGUgLSBEZWZpbmVzIGhvdyByZS1mZXRjaGVzIGFyZSBoYW5kbGVkLlxuKiBEZWZhdWx0cyB0byBgJ3Jlc2V0J2AsIGVyYXNlcyBhbGwgZGF0YSBhbmQgcHV0cyB0aGUgcXVlcnkgYmFjayBpbnRvIGBwZW5kaW5nYCBzdGF0ZS5cbiogU2V0IHRvIGAnYXBwZW5kJ2AgdG8gYXBwZW5kIG5ldyBkYXRhIHRvIHRoZSBleGlzdGluZyBkYXRhLlxuKiBTZXQgdG8gYCdyZXBsYWNlJ2AgdG8gd3JpdGUgYWxsIGRhdGEgdG8gdGhlIGNhY2hlIG9uY2UgdGhlIHN0cmVhbSBlbmRzLlxuKiBAcGFyYW0gcmVkdWNlciAtIEEgZnVuY3Rpb24gdG8gcmVkdWNlIHRoZSBzdHJlYW1lZCBjaHVua3MgaW50byB0aGUgZmluYWwgZGF0YS5cbiogRGVmYXVsdHMgdG8gYSBmdW5jdGlvbiB0aGF0IGFwcGVuZHMgY2h1bmtzIHRvIHRoZSBlbmQgb2YgdGhlIGFycmF5LlxuKiBAcGFyYW0gaW5pdGlhbFZhbHVlIC0gSW5pdGlhbCB2YWx1ZSB0byBiZSB1c2VkIHdoaWxlIHRoZSBmaXJzdCBjaHVuayBpcyBiZWluZyBmZXRjaGVkLCBhbmQgcmV0dXJuZWQgaWYgdGhlIHN0cmVhbSB5aWVsZHMgbm8gdmFsdWVzLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBhd2FpdCBxdWVyeUNsaWVudC5xdWVyeSh7XG4qICAgcXVlcnlLZXk6IFsnZGF0YSddLFxuKiAgIHF1ZXJ5Rm46IHN0cmVhbWVkUXVlcnkoe1xuKiAgICAgc3RyZWFtRm46IGZldGNoRGF0YUluQ2h1bmtzLFxuKiAgIH0pLFxuKiB9KVxuKiBgYGBcbiovXG5mdW5jdGlvbiBzdHJlYW1lZFF1ZXJ5KHsgc3RyZWFtRm4sIHJlZmV0Y2hNb2RlID0gXCJyZXNldFwiLCByZWR1Y2VyID0gKGl0ZW1zLCBjaHVuaykgPT4gYWRkVG9FbmQoaXRlbXMsIGNodW5rKSwgaW5pdGlhbFZhbHVlID0gW10gfSkge1xuXHRyZXR1cm4gYXN5bmMgKGNvbnRleHQpID0+IHtcblx0XHRjb25zdCBxdWVyeSA9IGNvbnRleHQuY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5maW5kKHtcblx0XHRcdHF1ZXJ5S2V5OiBjb250ZXh0LnF1ZXJ5S2V5LFxuXHRcdFx0ZXhhY3Q6IHRydWVcblx0XHR9KTtcblx0XHRjb25zdCBpc1JlZmV0Y2ggPSAhIXF1ZXJ5ICYmIHF1ZXJ5LmlzRmV0Y2hlZCgpO1xuXHRcdGlmIChpc1JlZmV0Y2ggJiYgcmVmZXRjaE1vZGUgPT09IFwicmVzZXRcIikgcXVlcnkuc2V0U3RhdGUoe1xuXHRcdFx0Li4ucXVlcnkucmVzZXRTdGF0ZSxcblx0XHRcdGZldGNoU3RhdHVzOiBcImZldGNoaW5nXCJcblx0XHR9KTtcblx0XHRsZXQgcmVzdWx0ID0gaW5pdGlhbFZhbHVlO1xuXHRcdGxldCBjYW5jZWxsZWQgPSBmYWxzZTtcblx0XHRjb25zdCBzdHJlYW0gPSBhd2FpdCBzdHJlYW1GbihhZGRDb25zdW1lQXdhcmVTaWduYWwoe1xuXHRcdFx0Y2xpZW50OiBjb250ZXh0LmNsaWVudCxcblx0XHRcdG1ldGE6IGNvbnRleHQubWV0YSxcblx0XHRcdHF1ZXJ5S2V5OiBjb250ZXh0LnF1ZXJ5S2V5LFxuXHRcdFx0cGFnZVBhcmFtOiBjb250ZXh0LnBhZ2VQYXJhbSxcblx0XHRcdGRpcmVjdGlvbjogY29udGV4dC5kaXJlY3Rpb25cblx0XHR9LCAoKSA9PiBjb250ZXh0LnNpZ25hbCwgKCkgPT4gY2FuY2VsbGVkID0gdHJ1ZSkpO1xuXHRcdGNvbnN0IGlzUmVwbGFjZVJlZmV0Y2ggPSBpc1JlZmV0Y2ggJiYgcmVmZXRjaE1vZGUgPT09IFwicmVwbGFjZVwiO1xuXHRcdGZvciBhd2FpdCAoY29uc3QgY2h1bmsgb2Ygc3RyZWFtKSB7XG5cdFx0XHRpZiAoY2FuY2VsbGVkKSBicmVhaztcblx0XHRcdGlmIChpc1JlcGxhY2VSZWZldGNoKSByZXN1bHQgPSByZWR1Y2VyKHJlc3VsdCwgY2h1bmspO1xuXHRcdFx0ZWxzZSBjb250ZXh0LmNsaWVudC5zZXRRdWVyeURhdGEoY29udGV4dC5xdWVyeUtleSwgKHByZXYpID0+IHJlZHVjZXIocHJldiA9PT0gdm9pZCAwID8gaW5pdGlhbFZhbHVlIDogcHJldiwgY2h1bmspKTtcblx0XHR9XG5cdFx0aWYgKGlzUmVwbGFjZVJlZmV0Y2ggJiYgIWNhbmNlbGxlZCkgY29udGV4dC5jbGllbnQuc2V0UXVlcnlEYXRhKGNvbnRleHQucXVlcnlLZXksIHJlc3VsdCk7XG5cdFx0Y29uc3QgZGF0YSA9IGNvbnRleHQuY2xpZW50LmdldFF1ZXJ5RGF0YShjb250ZXh0LnF1ZXJ5S2V5KTtcblx0XHRyZXR1cm4gZGF0YSA9PT0gdm9pZCAwID8gaW5pdGlhbFZhbHVlIDogZGF0YTtcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgc3RyZWFtZWRRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1zdHJlYW1lZFF1ZXJ5LmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvdHlwZXMudHNcbi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG5jb25zdCBkYXRhVGFnU3ltYm9sID0gU3ltYm9sKCk7XG5jb25zdCBkYXRhVGFnRXJyb3JTeW1ib2wgPSBTeW1ib2woKTtcbmNvbnN0IHVuc2V0TWFya2VyID0gU3ltYm9sKCk7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGRhdGFUYWdFcnJvclN5bWJvbCwgZGF0YVRhZ1N5bWJvbCwgdW5zZXRNYXJrZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dHlwZXMuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaHlkcmF0ZSB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy9IeWRyYXRpb25Cb3VuZGFyeS50c3hcbi8qKlxuKiBgSHlkcmF0aW9uQm91bmRhcnlgIGFkZHMgYSBwcmV2aW91c2x5IGRlaHlkcmF0ZWQgc3RhdGUgaW50byB0aGUgYHF1ZXJ5Q2xpZW50YCB0aGF0IHdvdWxkIGJlIHJldHVybmVkIGJ5XG4qIGB1c2VRdWVyeUNsaWVudCgpYC4gSWYgdGhlIGNsaWVudCBhbHJlYWR5IGNvbnRhaW5zIGRhdGEsIHRoZSBuZXcgcXVlcmllcyB3aWxsIGJlIGludGVsbGlnZW50bHkgbWVyZ2VkIGJhc2VkIG9uXG4qIHVwZGF0ZSB0aW1lc3RhbXAuXG4qXG4qIE5vdGU6IE9ubHkgYHF1ZXJpZXNgIGNhbiBiZSBkZWh5ZHJhdGVkIHdpdGggYW4gYEh5ZHJhdGlvbkJvdW5kYXJ5YC5cbipcbiogQHJldHVybnMgVGhlIHByb3ZpZGVkIGBjaGlsZHJlbmAsIHJlbmRlcmVkIHVuY29uZGl0aW9uYWxseS4gTmV3IHF1ZXJpZXMgaW4gYHN0YXRlYCBhcmUgaHlkcmF0ZWQgaW50byB0aGVcbiogY2FjaGUgZHVyaW5nIHJlbmRlcjsgZm9yIHF1ZXJpZXMgYWxyZWFkeSBpbiB0aGUgY2FjaGUsIG9ubHkgbmV3ZXIgZGVoeWRyYXRlZCBkYXRhIGlzIGh5ZHJhdGVkLCBpbiBhbiBlZmZlY3RcbiogYWZ0ZXIgY29tbWl0LlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgSHlkcmF0aW9uQm91bmRhcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIEFwcCgpIHtcbiogICByZXR1cm4gPEh5ZHJhdGlvbkJvdW5kYXJ5IHN0YXRlPXtkZWh5ZHJhdGVkU3RhdGV9Pi4uLjwvSHlkcmF0aW9uQm91bmRhcnk+XG4qIH1cbiogYGBgXG4qXG4qIEBleGFtcGxlXG4qIFNlcnZlci1zaWRlIHByZWZldGNoIGhhbmRlZCBvZmYgdG8gdGhlIGNsaWVudCB2aWEgYGRlaHlkcmF0ZWA6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBIeWRyYXRpb25Cb3VuZGFyeSwgZGVoeWRyYXRlLCBub29wIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBhc3luYyBmdW5jdGlvbiBTZXJ2ZXJDb21wb25lbnQoKSB7XG4qICAgY29uc3QgcXVlcnlDbGllbnQgPSBnZXRRdWVyeUNsaWVudCgpXG4qXG4qICAgYXdhaXQgcXVlcnlDbGllbnRcbiogICAgIC5xdWVyeSh7XG4qICAgICAgIHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10sXG4qICAgICAgIHF1ZXJ5Rm46IGZldGNoUG9zdHMsXG4qICAgICB9KVxuKiAgICAgLmNhdGNoKG5vb3ApXG4qXG4qICAgcmV0dXJuIChcbiogICAgIDxIeWRyYXRpb25Cb3VuZGFyeSBzdGF0ZT17ZGVoeWRyYXRlKHF1ZXJ5Q2xpZW50KX0+XG4qICAgICAgIDxQb3N0cyAvPlxuKiAgICAgPC9IeWRyYXRpb25Cb3VuZGFyeT5cbiogICApXG4qIH1cbiogYGBgXG4qL1xuY29uc3QgSHlkcmF0aW9uQm91bmRhcnkgPSAoeyBjaGlsZHJlbiwgb3B0aW9ucyA9IHt9LCBzdGF0ZSwgcXVlcnlDbGllbnQgfSkgPT4ge1xuXHRjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG5cdGNvbnN0IG9wdGlvbnNSZWYgPSBSZWFjdC51c2VSZWYob3B0aW9ucyk7XG5cdFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0b3B0aW9uc1JlZi5jdXJyZW50ID0gb3B0aW9ucztcblx0fSk7XG5cdGNvbnN0IGh5ZHJhdGlvblF1ZXVlID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG5cdFx0aWYgKHN0YXRlKSB7XG5cdFx0XHRpZiAodHlwZW9mIHN0YXRlICE9PSBcIm9iamVjdFwiKSByZXR1cm47XG5cdFx0XHRjb25zdCBxdWVyeUNhY2hlID0gY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKTtcblx0XHRcdGNvbnN0IHF1ZXJpZXMgPSBzdGF0ZS5xdWVyaWVzIHx8IFtdO1xuXHRcdFx0Y29uc3QgbmV3UXVlcmllcyA9IFtdO1xuXHRcdFx0Y29uc3QgZXhpc3RpbmdRdWVyaWVzID0gW107XG5cdFx0XHRmb3IgKGNvbnN0IGRlaHlkcmF0ZWRRdWVyeSBvZiBxdWVyaWVzKSB7XG5cdFx0XHRcdGNvbnN0IGV4aXN0aW5nUXVlcnkgPSBxdWVyeUNhY2hlLmdldChkZWh5ZHJhdGVkUXVlcnkucXVlcnlIYXNoKTtcblx0XHRcdFx0aWYgKCFleGlzdGluZ1F1ZXJ5KSBuZXdRdWVyaWVzLnB1c2goZGVoeWRyYXRlZFF1ZXJ5KTtcblx0XHRcdFx0ZWxzZSBpZiAoZGVoeWRyYXRlZFF1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXQgPiBleGlzdGluZ1F1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXQgfHwgZGVoeWRyYXRlZFF1ZXJ5LnByb21pc2UgJiYgZXhpc3RpbmdRdWVyeS5zdGF0ZS5zdGF0dXMgIT09IFwicGVuZGluZ1wiICYmIGV4aXN0aW5nUXVlcnkuc3RhdGUuZmV0Y2hTdGF0dXMgIT09IFwiZmV0Y2hpbmdcIiAmJiBkZWh5ZHJhdGVkUXVlcnkuZGVoeWRyYXRlZEF0ID4gZXhpc3RpbmdRdWVyeS5zdGF0ZS5kYXRhVXBkYXRlZEF0KSBleGlzdGluZ1F1ZXJpZXMucHVzaChkZWh5ZHJhdGVkUXVlcnkpO1xuXHRcdFx0fVxuXHRcdFx0aWYgKG5ld1F1ZXJpZXMubGVuZ3RoID4gMCkgaHlkcmF0ZShjbGllbnQsIHsgcXVlcmllczogbmV3UXVlcmllcyB9LCBvcHRpb25zUmVmLmN1cnJlbnQpO1xuXHRcdFx0aWYgKGV4aXN0aW5nUXVlcmllcy5sZW5ndGggPiAwKSByZXR1cm4gZXhpc3RpbmdRdWVyaWVzO1xuXHRcdH1cblx0fSwgW2NsaWVudCwgc3RhdGVdKTtcblx0UmVhY3QudXNlRWZmZWN0KCgpID0+IHtcblx0XHRpZiAoaHlkcmF0aW9uUXVldWUpIGh5ZHJhdGUoY2xpZW50LCB7IHF1ZXJpZXM6IGh5ZHJhdGlvblF1ZXVlIH0sIG9wdGlvbnNSZWYuY3VycmVudCk7XG5cdH0sIFtjbGllbnQsIGh5ZHJhdGlvblF1ZXVlXSk7XG5cdHJldHVybiBjaGlsZHJlbjtcbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IEh5ZHJhdGlvbkJvdW5kYXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUh5ZHJhdGlvbkJvdW5kYXJ5LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG4vLyNyZWdpb24gc3JjL0lzUmVzdG9yaW5nUHJvdmlkZXIudHNcbmNvbnN0IElzUmVzdG9yaW5nQ29udGV4dCA9IFJlYWN0LmNyZWF0ZUNvbnRleHQoZmFsc2UpO1xuLyoqXG4qIElmIHlvdSBhcmUgdXNpbmcgYFBlcnNpc3RRdWVyeUNsaWVudFByb3ZpZGVyYCwgeW91IGNhbiBhbHNvIHVzZSB0aGUgYHVzZUlzUmVzdG9yaW5nYCBob29rIGFsb25nc2lkZSBpdCB0b1xuKiBjaGVjayBpZiBhIHJlc3RvcmUgaXMgY3VycmVudGx5IGluIHByb2dyZXNzLiBgdXNlUXVlcnlgIGFuZCBmcmllbmRzIGFsc28gY2hlY2sgdGhpcyBpbnRlcm5hbGx5IHRvIGF2b2lkXG4qIHJhY2UgY29uZGl0aW9ucyBiZXR3ZWVuIHRoZSByZXN0b3JlIGFuZCBtb3VudGluZyBxdWVyaWVzLlxuKlxuKiBAcmV0dXJucyBgdHJ1ZWAgd2hpbGUgYSBwZXJzaXN0ZWQgY2xpZW50IGlzIGJlaW5nIHJlc3RvcmVkLCBgZmFsc2VgIG90aGVyd2lzZS5cbiovXG5jb25zdCB1c2VJc1Jlc3RvcmluZyA9ICgpID0+IFJlYWN0LnVzZUNvbnRleHQoSXNSZXN0b3JpbmdDb250ZXh0KTtcbi8qKlxuKiBUaGUgUHJvdmlkZXIgdGhhdCBgUGVyc2lzdFF1ZXJ5Q2xpZW50UHJvdmlkZXJgIHVzZXMgdG8gc2lnbmFsIHdoZXRoZXIgYSBwZXJzaXN0ZWQgY2xpZW50IGlzIGN1cnJlbnRseVxuKiBiZWluZyByZXN0b3JlZCwgcmVhZCBieSBgdXNlSXNSZXN0b3JpbmdgLlxuKi9cbmNvbnN0IElzUmVzdG9yaW5nUHJvdmlkZXIgPSBJc1Jlc3RvcmluZ0NvbnRleHQuUHJvdmlkZXI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IElzUmVzdG9yaW5nUHJvdmlkZXIsIHVzZUlzUmVzdG9yaW5nIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUlzUmVzdG9yaW5nUHJvdmlkZXIuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9RdWVyeUVycm9yUmVzZXRCb3VuZGFyeS50c3hcbi8qKlxuKiBSZXNldHMgYW55IHF1ZXJ5IGVycm9ycyB3aXRoaW4gdGhlIGJvdW5kYXJ5LCBzbyBxdWVyaWVzIGtub3cgdGhleSBjYW4gdHJ5IGFnYWluLlxuKi9cbmZ1bmN0aW9uIGNyZWF0ZVZhbHVlKCkge1xuXHRsZXQgaXNSZXNldCA9IGZhbHNlO1xuXHRyZXR1cm4ge1xuXHRcdC8qKlxuXHRcdCogQ2xlYXJzIHRoZSByZXNldCBzdGF0ZSwgc28gcXVlcmllcyBrbm93IG5vdCB0byB0cnkgYWdhaW4gdW50aWwgdGhlIGJvdW5kYXJ5IGlzIHJlc2V0IGFnYWluLlxuXHRcdCovXG5cdFx0Y2xlYXJSZXNldDogKCkgPT4ge1xuXHRcdFx0aXNSZXNldCA9IGZhbHNlO1xuXHRcdH0sXG5cdFx0LyoqXG5cdFx0KiBSZXNldHMgYW55IHF1ZXJ5IGVycm9ycyB3aXRoaW4gdGhlIGJvdW5kYXJ5LCBzbyBxdWVyaWVzIGtub3cgdGhleSBjYW4gdHJ5IGFnYWluLlxuXHRcdCovXG5cdFx0cmVzZXQ6ICgpID0+IHtcblx0XHRcdGlzUmVzZXQgPSB0cnVlO1xuXHRcdH0sXG5cdFx0LyoqXG5cdFx0KiBSZXR1cm5zIHdoZXRoZXIgdGhlIGJvdW5kYXJ5IGhhcyBiZWVuIHJlc2V0IGFuZCBub3QgeWV0IGNsZWFyZWQuXG5cdFx0Ki9cblx0XHRpc1Jlc2V0OiAoKSA9PiB7XG5cdFx0XHRyZXR1cm4gaXNSZXNldDtcblx0XHR9XG5cdH07XG59XG5jb25zdCBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeUNvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KGNyZWF0ZVZhbHVlKCkpO1xuLyoqXG4qIFRoaXMgaG9vayB3aWxsIHJlc2V0IGFueSBxdWVyeSBlcnJvcnMgd2l0aGluIHRoZSBjbG9zZXN0IGBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeWAuIElmIHRoZXJlIGlzIG5vIGJvdW5kYXJ5XG4qIGRlZmluZWQgaXQgd2lsbCByZXNldCB0aGVtIGdsb2JhbGx5LlxuKlxuKiBAcmV0dXJucyBUaGUgYm91bmRhcnkncyB7QGxpbmsgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnlWYWx1ZX0uXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAncmVhY3QtZXJyb3ItYm91bmRhcnknXG4qIGltcG9ydCB7IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBBcHAoeyBjaGlsZHJlbiB9OiB7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfSkge1xuKiAgIGNvbnN0IHsgcmVzZXQgfSA9IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5KClcbipcbiogICByZXR1cm4gKFxuKiAgICAgPEVycm9yQm91bmRhcnlcbiogICAgICAgb25SZXNldD17cmVzZXR9XG4qICAgICAgIGZhbGxiYWNrUmVuZGVyPXsoeyByZXNldEVycm9yQm91bmRhcnkgfSkgPT4gKFxuKiAgICAgICAgIDxkaXY+XG4qICAgICAgICAgICBUaGVyZSB3YXMgYW4gZXJyb3IhXG4qICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHJlc2V0RXJyb3JCb3VuZGFyeSgpfT5UcnkgYWdhaW48L2J1dHRvbj5cbiogICAgICAgICA8L2Rpdj5cbiogICAgICAgKX1cbiogICAgID5cbiogICAgICAge2NoaWxkcmVufVxuKiAgICAgPC9FcnJvckJvdW5kYXJ5PlxuKiAgIClcbiogfVxuKiBgYGBcbiovXG5jb25zdCB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSA9ICgpID0+IFJlYWN0LnVzZUNvbnRleHQoUXVlcnlFcnJvclJlc2V0Qm91bmRhcnlDb250ZXh0KTtcbi8qKlxuKiBXaGVuIHVzaW5nIGBzdXNwZW5zZWAgb3IgYHRocm93T25FcnJvcmAgaW4geW91ciBxdWVyaWVzLCB5b3UgbmVlZCBhIHdheSB0byBsZXQgcXVlcmllcyBrbm93IHRoYXQgeW91IHdhbnQgdG9cbiogdHJ5IGFnYWluIHdoZW4gcmUtcmVuZGVyaW5nIGFmdGVyIHNvbWUgZXJyb3Igb2NjdXJyZWQuIFdpdGggdGhlIGBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeWAgY29tcG9uZW50IHlvdSBjYW5cbiogcmVzZXQgYW55IHF1ZXJ5IGVycm9ycyB3aXRoaW4gdGhlIGJvdW5kYXJpZXMgb2YgdGhlIGNvbXBvbmVudC5cbipcbiogQHJldHVybnMgVGhlIGBjaGlsZHJlbmAsIHJlbmRlcmVkIGFzLWlzLCBvciBjYWxsZWQgd2l0aCB0aGUgYm91bmRhcnkncyB7QGxpbmsgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnlWYWx1ZX1cbiogaWYgYGNoaWxkcmVuYCBpcyBhIGZ1bmN0aW9uLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgRXJyb3JCb3VuZGFyeSB9IGZyb20gJ3JlYWN0LWVycm9yLWJvdW5kYXJ5J1xuKiBpbXBvcnQgeyBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIHJldHVybiAoXG4qICAgICA8UXVlcnlFcnJvclJlc2V0Qm91bmRhcnk+XG4qICAgICAgIHsoeyByZXNldCB9KSA9PiAoXG4qICAgICAgICAgPEVycm9yQm91bmRhcnlcbiogICAgICAgICAgIG9uUmVzZXQ9e3Jlc2V0fVxuKiAgICAgICAgICAgZmFsbGJhY2tSZW5kZXI9eyh7IHJlc2V0RXJyb3JCb3VuZGFyeSB9KSA9PiAoXG4qICAgICAgICAgICAgIDxkaXY+XG4qICAgICAgICAgICAgICAgVGhlcmUgd2FzIGFuIGVycm9yIVxuKiAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gcmVzZXRFcnJvckJvdW5kYXJ5KCl9PlRyeSBhZ2FpbjwvYnV0dG9uPlxuKiAgICAgICAgICAgICA8L2Rpdj5cbiogICAgICAgICAgICl9XG4qICAgICAgICAgPlxuKiAgICAgICAgICAgPFBhZ2UgLz5cbiogICAgICAgICA8L0Vycm9yQm91bmRhcnk+XG4qICAgICAgICl9XG4qICAgICA8L1F1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5PlxuKiAgIClcbiogfVxuKiBgYGBcbiovXG5jb25zdCBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSA9ICh7IGNoaWxkcmVuIH0pID0+IHtcblx0Y29uc3QgW3ZhbHVlXSA9IFJlYWN0LnVzZVN0YXRlKCgpID0+IGNyZWF0ZVZhbHVlKCkpO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChRdWVyeUVycm9yUmVzZXRCb3VuZGFyeUNvbnRleHQuUHJvdmlkZXIsIHtcblx0XHR2YWx1ZSxcblx0XHRjaGlsZHJlbjogdHlwZW9mIGNoaWxkcmVuID09PSBcImZ1bmN0aW9uXCIgPyBjaGlsZHJlbih2YWx1ZSkgOiBjaGlsZHJlblxuXHR9KTtcbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LCB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1RdWVyeUVycm9yUmVzZXRCb3VuZGFyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgc2hvdWxkVGhyb3dFcnJvciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy9lcnJvckJvdW5kYXJ5VXRpbHMudHNcbmNvbnN0IGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnkgPSAob3B0aW9ucywgZXJyb3JSZXNldEJvdW5kYXJ5LCBxdWVyeSkgPT4ge1xuXHRjb25zdCB0aHJvd09uRXJyb3IgPSBxdWVyeT8uc3RhdGUuZXJyb3IgJiYgdHlwZW9mIG9wdGlvbnMudGhyb3dPbkVycm9yID09PSBcImZ1bmN0aW9uXCIgPyBzaG91bGRUaHJvd0Vycm9yKG9wdGlvbnMudGhyb3dPbkVycm9yLCBbcXVlcnkuc3RhdGUuZXJyb3IsIHF1ZXJ5XSkgOiBvcHRpb25zLnRocm93T25FcnJvcjtcblx0aWYgKG9wdGlvbnMuc3VzcGVuc2UgfHwgdGhyb3dPbkVycm9yKSB7XG5cdFx0aWYgKCFlcnJvclJlc2V0Qm91bmRhcnkuaXNSZXNldCgpKSBvcHRpb25zLnJldHJ5T25Nb3VudCA9IGZhbHNlO1xuXHR9XG59O1xuY29uc3QgdXNlQ2xlYXJSZXNldEVycm9yQm91bmRhcnkgPSAoZXJyb3JSZXNldEJvdW5kYXJ5KSA9PiB7XG5cdFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0ZXJyb3JSZXNldEJvdW5kYXJ5LmNsZWFyUmVzZXQoKTtcblx0fSwgW2Vycm9yUmVzZXRCb3VuZGFyeV0pO1xufTtcbmNvbnN0IGdldEhhc0Vycm9yID0gKHsgcmVzdWx0LCBlcnJvclJlc2V0Qm91bmRhcnksIHRocm93T25FcnJvciwgcXVlcnksIHN1c3BlbnNlIH0pID0+IHtcblx0cmV0dXJuIHJlc3VsdC5pc0Vycm9yICYmICFlcnJvclJlc2V0Qm91bmRhcnkuaXNSZXNldCgpICYmICFyZXN1bHQuaXNGZXRjaGluZyAmJiBxdWVyeSAmJiAoc3VzcGVuc2UgJiYgcmVzdWx0LmRhdGEgPT09IHZvaWQgMCB8fCBzaG91bGRUaHJvd0Vycm9yKHRocm93T25FcnJvciwgW3Jlc3VsdC5lcnJvciwgcXVlcnldKSk7XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBlbnN1cmVQcmV2ZW50RXJyb3JCb3VuZGFyeVJldHJ5LCBnZXRIYXNFcnJvciwgdXNlQ2xlYXJSZXNldEVycm9yQm91bmRhcnkgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXJyb3JCb3VuZGFyeVV0aWxzLmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvc3VzcGVuc2UudHNcbmNvbnN0IGRlZmF1bHRUaHJvd09uRXJyb3IgPSAoX2Vycm9yLCBxdWVyeSkgPT4gcXVlcnkuc3RhdGUuZGF0YSA9PT0gdm9pZCAwO1xuY29uc3QgZW5zdXJlU3VzcGVuc2VUaW1lcnMgPSAoZGVmYXVsdGVkT3B0aW9ucykgPT4ge1xuXHRpZiAoZGVmYXVsdGVkT3B0aW9ucy5zdXNwZW5zZSkge1xuXHRcdGNvbnN0IE1JTl9TVVNQRU5TRV9USU1FX01TID0gMWUzO1xuXHRcdGNvbnN0IGNsYW1wID0gKHZhbHVlKSA9PiB2YWx1ZSA9PT0gXCJzdGF0aWNcIiA/IHZhbHVlIDogTWF0aC5tYXgodmFsdWUgPz8gTUlOX1NVU1BFTlNFX1RJTUVfTVMsIE1JTl9TVVNQRU5TRV9USU1FX01TKTtcblx0XHRjb25zdCBvcmlnaW5hbFN0YWxlVGltZSA9IGRlZmF1bHRlZE9wdGlvbnMuc3RhbGVUaW1lO1xuXHRcdGRlZmF1bHRlZE9wdGlvbnMuc3RhbGVUaW1lID0gdHlwZW9mIG9yaWdpbmFsU3RhbGVUaW1lID09PSBcImZ1bmN0aW9uXCIgPyAoLi4uYXJncykgPT4gY2xhbXAob3JpZ2luYWxTdGFsZVRpbWUoLi4uYXJncykpIDogY2xhbXAob3JpZ2luYWxTdGFsZVRpbWUpO1xuXHRcdGlmICh0eXBlb2YgZGVmYXVsdGVkT3B0aW9ucy5nY1RpbWUgPT09IFwibnVtYmVyXCIpIGRlZmF1bHRlZE9wdGlvbnMuZ2NUaW1lID0gTWF0aC5tYXgoZGVmYXVsdGVkT3B0aW9ucy5nY1RpbWUsIE1JTl9TVVNQRU5TRV9USU1FX01TKTtcblx0fVxufTtcbmNvbnN0IHNob3VsZFN1c3BlbmQgPSAoZGVmYXVsdGVkT3B0aW9ucywgcmVzdWx0KSA9PiBkZWZhdWx0ZWRPcHRpb25zPy5zdXNwZW5zZSAmJiByZXN1bHQuaXNQZW5kaW5nO1xuY29uc3QgZmV0Y2hPcHRpbWlzdGljID0gKGRlZmF1bHRlZE9wdGlvbnMsIG9ic2VydmVyLCBlcnJvclJlc2V0Qm91bmRhcnkpID0+IG9ic2VydmVyLmZldGNoT3B0aW1pc3RpYyhkZWZhdWx0ZWRPcHRpb25zKS5jYXRjaCgoKSA9PiB7XG5cdGVycm9yUmVzZXRCb3VuZGFyeS5jbGVhclJlc2V0KCk7XG59KTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZGVmYXVsdFRocm93T25FcnJvciwgZW5zdXJlU3VzcGVuc2VUaW1lcnMsIGZldGNoT3B0aW1pc3RpYywgc2hvdWxkU3VzcGVuZCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1zdXNwZW5zZS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIi4vUXVlcnlDbGllbnRQcm92aWRlci5qc1wiO1xuaW1wb3J0IHsgdXNlSXNSZXN0b3JpbmcgfSBmcm9tIFwiLi9Jc1Jlc3RvcmluZ1Byb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSB9IGZyb20gXCIuL1F1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LmpzXCI7XG5pbXBvcnQgeyBlbnN1cmVQcmV2ZW50RXJyb3JCb3VuZGFyeVJldHJ5LCBnZXRIYXNFcnJvciwgdXNlQ2xlYXJSZXNldEVycm9yQm91bmRhcnkgfSBmcm9tIFwiLi9lcnJvckJvdW5kYXJ5VXRpbHMuanNcIjtcbmltcG9ydCB7IGVuc3VyZVN1c3BlbnNlVGltZXJzLCBmZXRjaE9wdGltaXN0aWMsIHNob3VsZFN1c3BlbmQgfSBmcm9tIFwiLi9zdXNwZW5zZS5qc1wiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBRdWVyaWVzT2JzZXJ2ZXIsIFF1ZXJ5T2JzZXJ2ZXIsIG5vb3AsIG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlUXVlcmllcy50c1xuLyoqXG4qIFRoZSBgdXNlUXVlcmllc2AgaG9vayBjYW4gYmUgdXNlZCB0byBmZXRjaCBhIHZhcmlhYmxlIG51bWJlciBvZiBxdWVyaWVzLlxuKlxuKiBUaGUgYHF1ZXJpZXNgIGtleSBhY2NlcHRzIGFuIGFycmF5IHdpdGggcXVlcnkgb3B0aW9uIG9iamVjdHMgbW9zdGx5IGlkZW50aWNhbCB0byBgdXNlUXVlcnlgIOKAlCB0aGUgdG9wLWxldmVsXG4qIGBzdWJzY3JpYmVkYCBvcHRpb24gaXNuJ3QgYWNjZXB0ZWQgcGVyIHF1ZXJ5IChzZWUgYHBsYWNlaG9sZGVyRGF0YWAgYmVsb3cgZm9yIGFub3RoZXIgZGlmZmVyZW5jZSkuIEEgY3VzdG9tXG4qIGBRdWVyeUNsaWVudGAgaXMgc3VwcGxpZWQgb25jZSwgYXMgYHVzZVF1ZXJpZXNgJyBvd24gdG9wLWxldmVsIHNlY29uZCBhcmd1bWVudCwgcmF0aGVyIHRoYW4gcGVyIHF1ZXJ5LlxuKlxuKiBIYXZpbmcgdGhlIHNhbWUgcXVlcnkga2V5IG1vcmUgdGhhbiBvbmNlIGluIHRoZSBhcnJheSBvZiBxdWVyeSBvYmplY3RzIG1heSBjYXVzZSBzb21lIGRhdGEgdG8gYmUgc2hhcmVkXG4qIGJldHdlZW4gcXVlcmllcy4gVG8gYXZvaWQgdGhpcywgY29uc2lkZXIgZGUtZHVwbGljYXRpbmcgdGhlIHF1ZXJpZXMgYW5kIG1hcCB0aGUgcmVzdWx0cyBiYWNrIHRvIHRoZSBkZXNpcmVkXG4qIHN0cnVjdHVyZS5cbipcbiogVGhlIGBjb21iaW5lYCBvcHRpb24gY2FuIGJlIHVzZWQgdG8gY29tYmluZSB0aGUgcmVzdWx0cyBvZiB0aGUgcXVlcmllcyBpbnRvIGEgc2luZ2xlIHZhbHVlLiBUaGUgcmVzdWx0IHdpbGxcbiogYmUgc3RydWN0dXJhbGx5IHNoYXJlZCB0byBiZSBhcyByZWZlcmVudGlhbGx5IHN0YWJsZSBhcyBwb3NzaWJsZS5cbipcbiogQHJlbWFya3MgVGhlIGBjb21iaW5lYCBmdW5jdGlvbiBvbmx5IHJlLXJ1bnMgaWYgaXQgY2hhbmdlZCByZWZlcmVudGlhbGx5LCBvciBpZiBhbnkgb2YgdGhlIHF1ZXJ5IHJlc3VsdHNcbiogY2hhbmdlZC4gQW4gaW5saW5lZCBgY29tYmluZWAgZnVuY3Rpb24sIGFzIHNob3duIGluIHRoZSBleGFtcGxlIGJlbG93LCB0aGVyZWZvcmUgcnVucyBvbiBldmVyeSByZW5kZXIg4oCUIHdyYXBcbiogaXQgaW4gYHVzZUNhbGxiYWNrYCwgb3IgZXh0cmFjdCBpdCB0byBhIHN0YWJsZSBmdW5jdGlvbiByZWZlcmVuY2UgaWYgaXQgZG9lc24ndCBoYXZlIGFueSBkZXBlbmRlbmNpZXMsIHRvXG4qIGF2b2lkIHRoYXQuXG4qXG4qIFVubGlrZSBgdXNlUXVlcnlgLCBgdXNlUXVlcmllc2AgY2Fubm90IGluZmVyIHRoZSBgZGF0YWAgYXJndW1lbnQgb2YgYW4gX2lubGluZV8gYHNlbGVjdGAgZnJvbSBpdHMgc2libGluZ1xuKiBgcXVlcnlGbmAuIEJlY2F1c2UgYHVzZVF1ZXJpZXNgIGluZmVycyB0aGUgdHlwZSBvZiB0aGUgd2hvbGUgYHF1ZXJpZXNgIGFycmF5IGF0IG9uY2UsIHRoZSBgc2VsZWN0YCBwYXJhbWV0ZXJcbiogb2YgYSBxdWVyeSBvYmplY3Qgd3JpdHRlbiBpbmxpbmUgY2Fubm90IGJlIGNvbnRleHR1YWxseSB0eXBlZCBmcm9tIHRoYXQgc2FtZSBvYmplY3QncyBgcXVlcnlGbmAsIHNvIGl0IGZhbGxzXG4qIGJhY2sgdG8gYHVua25vd25gIOKAlCBhIFtrbm93biBUeXBlU2NyaXB0IGxpbWl0YXRpb25dKGh0dHBzOi8vZ2l0aHViLmNvbS9UYW5TdGFjay9xdWVyeS9pc3N1ZXMvNjU1NikuIEFubm90YXRlXG4qIHRoZSBgc2VsZWN0YCBwYXJhbWV0ZXIgZXhwbGljaXRseSwgb3IgZGVmaW5lIHRoZSBxdWVyeSB3aXRoIHtAbGluayBxdWVyeU9wdGlvbnN9LCB3aGljaCByZXNvbHZlcyBpdHMgdHlwZXMgaW5cbiogYSBzaW5nbGUgb2JqZWN0IF9iZWZvcmVfIGl0IHJlYWNoZXMgYHVzZVF1ZXJpZXNgLCB0byB3b3JrIGFyb3VuZCB0aGlzIOKAlCBzZWUgdGhlIGV4YW1wbGUgYmVsb3cuIFRoZSBzYW1lXG4qIGxpbWl0YXRpb24gYXBwbGllcyB0byB7QGxpbmsgdXNlU3VzcGVuc2VRdWVyaWVzfS5cbipcbiogYHBsYWNlaG9sZGVyRGF0YWAgaXMgc3VwcG9ydGVkIGhlcmUgdG9vLCBidXQgdW5saWtlIGB1c2VRdWVyeWAsIGl0IGRvZXNuJ3QgcmVjZWl2ZSBpbmZvcm1hdGlvbiBmcm9tXG4qIHByZXZpb3VzbHkgcmVuZGVyZWQgcXVlcmllcywgYmVjYXVzZSB0aGUgbnVtYmVyIG9mIHF1ZXJpZXMgY2FuIGRpZmZlciBiZXR3ZWVuIHJlbmRlcnMuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHByb3ZpZGUgYSBjdXN0b20gYFF1ZXJ5Q2xpZW50YC4gT3RoZXJ3aXNlLCB0aGUgb25lIGZyb20gdGhlIG5lYXJlc3QgY29udGV4dFxuKiB3aWxsIGJlIHVzZWQuXG4qIEByZXR1cm5zIFRoZSBjb21iaW5lZCByZXN1bHQuIFdpdGhvdXQgYGNvbWJpbmVgLCB0aGlzIGlzIGFuIGFycmF5IHdpdGggYWxsIHRoZSBxdWVyeSByZXN1bHRzLCBpbiB0aGUgc2FtZVxuKiBvcmRlciBhcyB0aGUgaW5wdXQuIFdoZW4gYGNvbWJpbmVgIGlzIHByb3ZpZGVkLCB0aGlzIGlzIHRoZSB2YWx1ZSByZXR1cm5lZCBieSBgY29tYmluZWAgaW5zdGVhZC5cbipcbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZVF1ZXJpZXMgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIFBvc3RzKHsgaWRzIH06IHsgaWRzOiBBcnJheTxudW1iZXI+IH0pIHtcbiogICBjb25zdCBwb3N0UXVlcmllcyA9IHVzZVF1ZXJpZXMoe1xuKiAgICAgcXVlcmllczogaWRzLm1hcCgoaWQpID0+ICh7XG4qICAgICAgIHF1ZXJ5S2V5OiBbJ3Bvc3QnLCBpZF0sXG4qICAgICAgIHF1ZXJ5Rm46ICgpID0+IGZldGNoUG9zdChpZCksXG4qICAgICAgIHN0YWxlVGltZTogSW5maW5pdHksXG4qICAgICB9KSksXG4qICAgfSlcbipcbiogICByZXR1cm4gKFxuKiAgICAgPHVsPlxuKiAgICAgICB7cG9zdFF1ZXJpZXMubWFwKChxdWVyeSwgaW5kZXgpID0+IHtcbiogICAgICAgICBpZiAocXVlcnkuaXNQZW5kaW5nKSByZXR1cm4gPGxpIGtleT17aWRzW2luZGV4XX0+TG9hZGluZy4uLjwvbGk+XG4qICAgICAgICAgaWYgKHF1ZXJ5LmlzRXJyb3IpIHJldHVybiA8bGkga2V5PXtpZHNbaW5kZXhdfT5FcnJvcjoge3F1ZXJ5LmVycm9yLm1lc3NhZ2V9PC9saT5cbiogICAgICAgICByZXR1cm4gPGxpIGtleT17aWRzW2luZGV4XX0+e3F1ZXJ5LmRhdGEudGl0bGV9PC9saT5cbiogICAgICAgfSl9XG4qICAgICA8L3VsPlxuKiAgIClcbiogfVxuKiBgYGBcbipcbiogQGV4YW1wbGVcbiogQ29tYmluaW5nIHJlc3VsdHMgaW50byBhIHNpbmdsZSB2YWx1ZTpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZVF1ZXJpZXMgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIFBvc3RzKHsgaWRzIH06IHsgaWRzOiBBcnJheTxudW1iZXI+IH0pIHtcbiogICBjb25zdCB7IGRhdGEsIGlzUGVuZGluZywgaXNFcnJvciB9ID0gdXNlUXVlcmllcyh7XG4qICAgICBxdWVyaWVzOiBpZHMubWFwKChpZCkgPT4gKHtcbiogICAgICAgcXVlcnlLZXk6IFsncG9zdCcsIGlkXSxcbiogICAgICAgcXVlcnlGbjogKCkgPT4gZmV0Y2hQb3N0KGlkKSxcbiogICAgIH0pKSxcbiogICAgIGNvbWJpbmU6IChwb3N0UXVlcmllcykgPT4ge1xuKiAgICAgICByZXR1cm4ge1xuKiAgICAgICAgIGRhdGE6IHBvc3RRdWVyaWVzLm1hcCgocXVlcnkpID0+IHF1ZXJ5LmRhdGEpLFxuKiAgICAgICAgIGlzUGVuZGluZzogcG9zdFF1ZXJpZXMuc29tZSgocXVlcnkpID0+IHF1ZXJ5LmlzUGVuZGluZyksXG4qICAgICAgICAgaXNFcnJvcjogcG9zdFF1ZXJpZXMuc29tZSgocXVlcnkpID0+IHF1ZXJ5LmlzRXJyb3IpLFxuKiAgICAgICB9XG4qICAgICB9LFxuKiAgIH0pXG4qXG4qICAgaWYgKGlzUGVuZGluZykgcmV0dXJuICdMb2FkaW5nLi4uJ1xuKiAgIGlmIChpc0Vycm9yKSByZXR1cm4gJ0Vycm9yIGxvYWRpbmcgcG9zdHMnXG4qXG4qICAgcmV0dXJuIChcbiogICAgIDx1bD5cbiogICAgICAge2RhdGEubWFwKChwb3N0KSA9PiAoXG4qICAgICAgICAgPGxpIGtleT17cG9zdD8uaWR9Pntwb3N0Py50aXRsZX08L2xpPlxuKiAgICAgICApKX1cbiogICAgIDwvdWw+XG4qICAgKVxuKiB9XG4qIGBgYFxuKlxuKiBAZXhhbXBsZVxuKiBUeXBpbmcgYHNlbGVjdGAgdmlhIHtAbGluayBxdWVyeU9wdGlvbnN9LiBOb3RlIHRoYXQgc3ByZWFkaW5nIGEgYHF1ZXJ5T3B0aW9uc2AgcmVzdWx0IGFuZCBvdmVycmlkaW5nXG4qIGBzZWxlY3RgIGlubGluZSBzdGlsbCBmYWxscyBiYWNrIHRvIGB1bmtub3duYCDigJQgd3JhcCB0aGUgc3ByZWFkIGluIGBxdWVyeU9wdGlvbnNgIGFnYWluIHNvIHRoZSBvdmVycmlkZSBpc1xuKiByZXNvbHZlZCBiZWZvcmUgaXQgcmVhY2hlcyBgdXNlUXVlcmllc2A6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBxdWVyeU9wdGlvbnMsIHVzZVF1ZXJpZXMgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGNvbnN0IHBvc3RPcHRpb25zID0gKGlkOiBudW1iZXIpID0+XG4qICAgcXVlcnlPcHRpb25zKHtcbiogICAgIHF1ZXJ5S2V5OiBbJ3Bvc3QnLCBpZF0sXG4qICAgICBxdWVyeUZuOiAoKSA9PiBmZXRjaFBvc3QoaWQpLFxuKiAgIH0pXG4qXG4qIGZ1bmN0aW9uIFBvc3RUaXRsZSh7IGlkIH06IHsgaWQ6IG51bWJlciB9KSB7XG4qICAgY29uc3QgW3sgZGF0YTogYnJva2VuIH1dID0gdXNlUXVlcmllcyh7XG4qICAgICBxdWVyaWVzOiBbXG4qICAgICAgIHtcbiogICAgICAgICAuLi5wb3N0T3B0aW9ucyhpZCksXG4qICAgICAgICAgLy8g4p2MIGBkYXRhYCBpcyBgdW5rbm93bmAgaGVyZVxuKiAgICAgICAgIHNlbGVjdDogKGRhdGEpID0+IGRhdGEudGl0bGUsXG4qICAgICAgIH0sXG4qICAgICBdLFxuKiAgIH0pXG4qXG4qICAgY29uc3QgW3sgZGF0YTogZml4ZWQgfV0gPSB1c2VRdWVyaWVzKHtcbiogICAgIHF1ZXJpZXM6IFtcbiogICAgICAgcXVlcnlPcHRpb25zKHtcbiogICAgICAgICAuLi5wb3N0T3B0aW9ucyhpZCksXG4qICAgICAgICAgLy8g4pyFIGBkYXRhYCBpcyBgUG9zdGBcbiogICAgICAgICBzZWxlY3Q6IChkYXRhKSA9PiBkYXRhLnRpdGxlLFxuKiAgICAgICB9KSxcbiogICAgIF0sXG4qICAgfSlcbipcbiogICByZXR1cm4gPGgxPntmaXhlZH08L2gxPlxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZVF1ZXJpZXMoeyBxdWVyaWVzLCAuLi5vcHRpb25zIH0sIHF1ZXJ5Q2xpZW50KSB7XG5cdGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcblx0Y29uc3QgaXNSZXN0b3JpbmcgPSB1c2VJc1Jlc3RvcmluZygpO1xuXHRjb25zdCBlcnJvclJlc2V0Qm91bmRhcnkgPSB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSgpO1xuXHRjb25zdCBzdWJzY3JpYmVkID0gb3B0aW9ucy5zdWJzY3JpYmVkICE9PSBmYWxzZTtcblx0Y29uc3QgZGVmYXVsdGVkUXVlcmllcyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gcXVlcmllcy5tYXAoKG9wdHMpID0+IHtcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gY2xpZW50LmRlZmF1bHRRdWVyeU9wdGlvbnMob3B0cyk7XG5cdFx0ZGVmYXVsdGVkT3B0aW9ucy5fb3B0aW1pc3RpY1Jlc3VsdHMgPSBpc1Jlc3RvcmluZyA/IFwiaXNSZXN0b3JpbmdcIiA6IHN1YnNjcmliZWQgPyBcIm9wdGltaXN0aWNcIiA6IHZvaWQgMDtcblx0XHRyZXR1cm4gZGVmYXVsdGVkT3B0aW9ucztcblx0fSksIFtcblx0XHRxdWVyaWVzLFxuXHRcdGNsaWVudCxcblx0XHRpc1Jlc3RvcmluZyxcblx0XHRzdWJzY3JpYmVkXG5cdF0pO1xuXHRkZWZhdWx0ZWRRdWVyaWVzLmZvckVhY2goKHF1ZXJ5T3B0aW9ucykgPT4ge1xuXHRcdGVuc3VyZVN1c3BlbnNlVGltZXJzKHF1ZXJ5T3B0aW9ucyk7XG5cdFx0Y29uc3QgcXVlcnkgPSBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmdldChxdWVyeU9wdGlvbnMucXVlcnlIYXNoKTtcblx0XHRlbnN1cmVQcmV2ZW50RXJyb3JCb3VuZGFyeVJldHJ5KHF1ZXJ5T3B0aW9ucywgZXJyb3JSZXNldEJvdW5kYXJ5LCBxdWVyeSk7XG5cdH0pO1xuXHR1c2VDbGVhclJlc2V0RXJyb3JCb3VuZGFyeShlcnJvclJlc2V0Qm91bmRhcnkpO1xuXHRjb25zdCBbb2JzZXJ2ZXJdID0gUmVhY3QudXNlU3RhdGUoKCkgPT4gbmV3IFF1ZXJpZXNPYnNlcnZlcihjbGllbnQsIGRlZmF1bHRlZFF1ZXJpZXMsIG9wdGlvbnMpKTtcblx0Y29uc3QgW29wdGltaXN0aWNSZXN1bHQsIGdldENvbWJpbmVkUmVzdWx0LCB0cmFja1Jlc3VsdF0gPSBvYnNlcnZlci5nZXRPcHRpbWlzdGljUmVzdWx0KGRlZmF1bHRlZFF1ZXJpZXMsIG9wdGlvbnMuY29tYmluZSk7XG5cdGNvbnN0IHNob3VsZFN1YnNjcmliZSA9ICFpc1Jlc3RvcmluZyAmJiBzdWJzY3JpYmVkO1xuXHRSZWFjdC51c2VTeW5jRXh0ZXJuYWxTdG9yZShSZWFjdC51c2VDYWxsYmFjaygob25TdG9yZUNoYW5nZSkgPT4gc2hvdWxkU3Vic2NyaWJlID8gb2JzZXJ2ZXIuc3Vic2NyaWJlKG5vdGlmeU1hbmFnZXIuYmF0Y2hDYWxscyhvblN0b3JlQ2hhbmdlKSkgOiBub29wLCBbb2JzZXJ2ZXIsIHNob3VsZFN1YnNjcmliZV0pLCAoKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KCksICgpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKSk7XG5cdFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0b2JzZXJ2ZXIuc2V0UXVlcmllcyhkZWZhdWx0ZWRRdWVyaWVzLCBvcHRpb25zKTtcblx0fSwgW1xuXHRcdGRlZmF1bHRlZFF1ZXJpZXMsXG5cdFx0b3B0aW9ucyxcblx0XHRvYnNlcnZlclxuXHRdKTtcblx0Y29uc3Qgc3VzcGVuc2VQcm9taXNlcyA9IG9wdGltaXN0aWNSZXN1bHQuc29tZSgocmVzdWx0LCBpbmRleCkgPT4gc2hvdWxkU3VzcGVuZChkZWZhdWx0ZWRRdWVyaWVzW2luZGV4XSwgcmVzdWx0KSkgPyBvcHRpbWlzdGljUmVzdWx0LmZsYXRNYXAoKHJlc3VsdCwgaW5kZXgpID0+IHtcblx0XHRjb25zdCBvcHRzID0gZGVmYXVsdGVkUXVlcmllc1tpbmRleF07XG5cdFx0aWYgKG9wdHMgJiYgc2hvdWxkU3VzcGVuZChvcHRzLCByZXN1bHQpKSB7XG5cdFx0XHRjb25zdCBxdWVyeU9ic2VydmVyID0gbmV3IFF1ZXJ5T2JzZXJ2ZXIoY2xpZW50LCBvcHRzKTtcblx0XHRcdHJldHVybiBmZXRjaE9wdGltaXN0aWMob3B0cywgcXVlcnlPYnNlcnZlciwgZXJyb3JSZXNldEJvdW5kYXJ5KTtcblx0XHR9XG5cdFx0cmV0dXJuIFtdO1xuXHR9KSA6IFtdO1xuXHRpZiAoc3VzcGVuc2VQcm9taXNlcy5sZW5ndGggPiAwKSB0aHJvdyBQcm9taXNlLmFsbChzdXNwZW5zZVByb21pc2VzKTtcblx0Y29uc3QgZmlyc3RTaW5nbGVSZXN1bHRXaGljaFNob3VsZFRocm93ID0gb3B0aW1pc3RpY1Jlc3VsdC5maW5kKChyZXN1bHQsIGluZGV4KSA9PiB7XG5cdFx0Y29uc3QgcXVlcnkgPSBkZWZhdWx0ZWRRdWVyaWVzW2luZGV4XTtcblx0XHRyZXR1cm4gcXVlcnkgJiYgZ2V0SGFzRXJyb3Ioe1xuXHRcdFx0cmVzdWx0LFxuXHRcdFx0ZXJyb3JSZXNldEJvdW5kYXJ5LFxuXHRcdFx0dGhyb3dPbkVycm9yOiBxdWVyeS50aHJvd09uRXJyb3IsXG5cdFx0XHRxdWVyeTogY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5nZXQocXVlcnkucXVlcnlIYXNoKSxcblx0XHRcdHN1c3BlbnNlOiBxdWVyeS5zdXNwZW5zZVxuXHRcdH0pO1xuXHR9KTtcblx0aWYgKGZpcnN0U2luZ2xlUmVzdWx0V2hpY2hTaG91bGRUaHJvdykgdGhyb3cgZmlyc3RTaW5nbGVSZXN1bHRXaGljaFNob3VsZFRocm93LmVycm9yO1xuXHRyZXR1cm4gZ2V0Q29tYmluZWRSZXN1bHQodHJhY2tSZXN1bHQoKSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZVF1ZXJpZXMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlUXVlcmllcy5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIi4vUXVlcnlDbGllbnRQcm92aWRlci5qc1wiO1xuaW1wb3J0IHsgdXNlSXNSZXN0b3JpbmcgfSBmcm9tIFwiLi9Jc1Jlc3RvcmluZ1Byb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSB9IGZyb20gXCIuL1F1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LmpzXCI7XG5pbXBvcnQgeyBlbnN1cmVQcmV2ZW50RXJyb3JCb3VuZGFyeVJldHJ5LCBnZXRIYXNFcnJvciwgdXNlQ2xlYXJSZXNldEVycm9yQm91bmRhcnkgfSBmcm9tIFwiLi9lcnJvckJvdW5kYXJ5VXRpbHMuanNcIjtcbmltcG9ydCB7IGVuc3VyZVN1c3BlbnNlVGltZXJzLCBmZXRjaE9wdGltaXN0aWMsIHNob3VsZFN1c3BlbmQgfSBmcm9tIFwiLi9zdXNwZW5zZS5qc1wiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBub29wLCBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyNyZWdpb24gc3JjL3VzZUJhc2VRdWVyeS50c1xuZnVuY3Rpb24gdXNlQmFzZVF1ZXJ5KG9wdGlvbnMsIE9ic2VydmVyLCBxdWVyeUNsaWVudCkge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0aWYgKHR5cGVvZiBvcHRpb25zICE9PSBcIm9iamVjdFwiIHx8IEFycmF5LmlzQXJyYXkob3B0aW9ucykpIHRocm93IG5ldyBFcnJvcihcIkJhZCBhcmd1bWVudCB0eXBlLiBTdGFydGluZyB3aXRoIHY1LCBvbmx5IHRoZSBcXFwiT2JqZWN0XFxcIiBmb3JtIGlzIGFsbG93ZWQgd2hlbiBjYWxsaW5nIHF1ZXJ5IHJlbGF0ZWQgZnVuY3Rpb25zLiBQbGVhc2UgdXNlIHRoZSBlcnJvciBzdGFjayB0byBmaW5kIHRoZSBjdWxwcml0IGNhbGwuIE1vcmUgaW5mbyBoZXJlOiBodHRwczovL3RhbnN0YWNrLmNvbS9xdWVyeS9sYXRlc3QvZG9jcy9yZWFjdC9ndWlkZXMvbWlncmF0aW5nLXRvLXY1I3N1cHBvcnRzLWEtc2luZ2xlLXNpZ25hdHVyZS1vbmUtb2JqZWN0XCIpO1xuXHR9XG5cdGNvbnN0IGlzUmVzdG9yaW5nID0gdXNlSXNSZXN0b3JpbmcoKTtcblx0Y29uc3QgZXJyb3JSZXNldEJvdW5kYXJ5ID0gdXNlUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkoKTtcblx0Y29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuXHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gY2xpZW50LmRlZmF1bHRRdWVyeU9wdGlvbnMob3B0aW9ucyk7XG5cdGNvbnN0IHF1ZXJ5ID0gY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5nZXQoZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUhhc2gpO1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0aWYgKCFkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5Rm4pIGNvbnNvbGUuZXJyb3IoYFske2RlZmF1bHRlZE9wdGlvbnMucXVlcnlIYXNofV06IE5vIHF1ZXJ5Rm4gd2FzIHBhc3NlZCBhcyBhbiBvcHRpb24sIGFuZCBubyBkZWZhdWx0IHF1ZXJ5Rm4gd2FzIGZvdW5kLiBUaGUgcXVlcnlGbiBwYXJhbWV0ZXIgaXMgb25seSBvcHRpb25hbCB3aGVuIHVzaW5nIGEgZGVmYXVsdCBxdWVyeUZuLiBNb3JlIGluZm8gaGVyZTogaHR0cHM6Ly90YW5zdGFjay5jb20vcXVlcnkvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2d1aWRlcy9kZWZhdWx0LXF1ZXJ5LWZ1bmN0aW9uYCk7XG5cdH1cblx0Y29uc3Qgc3Vic2NyaWJlZCA9IG9wdGlvbnMuc3Vic2NyaWJlZCAhPT0gZmFsc2U7XG5cdGRlZmF1bHRlZE9wdGlvbnMuX29wdGltaXN0aWNSZXN1bHRzID0gaXNSZXN0b3JpbmcgPyBcImlzUmVzdG9yaW5nXCIgOiBzdWJzY3JpYmVkID8gXCJvcHRpbWlzdGljXCIgOiB2b2lkIDA7XG5cdGVuc3VyZVN1c3BlbnNlVGltZXJzKGRlZmF1bHRlZE9wdGlvbnMpO1xuXHRlbnN1cmVQcmV2ZW50RXJyb3JCb3VuZGFyeVJldHJ5KGRlZmF1bHRlZE9wdGlvbnMsIGVycm9yUmVzZXRCb3VuZGFyeSwgcXVlcnkpO1xuXHR1c2VDbGVhclJlc2V0RXJyb3JCb3VuZGFyeShlcnJvclJlc2V0Qm91bmRhcnkpO1xuXHRjb25zdCBbb2JzZXJ2ZXJdID0gUmVhY3QudXNlU3RhdGUoKCkgPT4gbmV3IE9ic2VydmVyKGNsaWVudCwgZGVmYXVsdGVkT3B0aW9ucykpO1xuXHRjb25zdCByZXN1bHQgPSBvYnNlcnZlci5nZXRPcHRpbWlzdGljUmVzdWx0KGRlZmF1bHRlZE9wdGlvbnMpO1xuXHRjb25zdCBzaG91bGRTdWJzY3JpYmUgPSAhaXNSZXN0b3JpbmcgJiYgc3Vic2NyaWJlZDtcblx0UmVhY3QudXNlU3luY0V4dGVybmFsU3RvcmUoUmVhY3QudXNlQ2FsbGJhY2soKG9uU3RvcmVDaGFuZ2UpID0+IHtcblx0XHRjb25zdCB1bnN1YnNjcmliZSA9IHNob3VsZFN1YnNjcmliZSA/IG9ic2VydmVyLnN1YnNjcmliZShub3RpZnlNYW5hZ2VyLmJhdGNoQ2FsbHMob25TdG9yZUNoYW5nZSkpIDogbm9vcDtcblx0XHRvYnNlcnZlci51cGRhdGVSZXN1bHQoKTtcblx0XHRyZXR1cm4gdW5zdWJzY3JpYmU7XG5cdH0sIFtvYnNlcnZlciwgc2hvdWxkU3Vic2NyaWJlXSksICgpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKSwgKCkgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpKTtcblx0UmVhY3QudXNlRWZmZWN0KCgpID0+IHtcblx0XHRvYnNlcnZlci5zZXRPcHRpb25zKGRlZmF1bHRlZE9wdGlvbnMpO1xuXHR9LCBbZGVmYXVsdGVkT3B0aW9ucywgb2JzZXJ2ZXJdKTtcblx0aWYgKHNob3VsZFN1c3BlbmQoZGVmYXVsdGVkT3B0aW9ucywgcmVzdWx0KSkgdGhyb3cgZmV0Y2hPcHRpbWlzdGljKGRlZmF1bHRlZE9wdGlvbnMsIG9ic2VydmVyLCBlcnJvclJlc2V0Qm91bmRhcnkpO1xuXHRpZiAoZ2V0SGFzRXJyb3Ioe1xuXHRcdHJlc3VsdCxcblx0XHRlcnJvclJlc2V0Qm91bmRhcnksXG5cdFx0dGhyb3dPbkVycm9yOiBkZWZhdWx0ZWRPcHRpb25zLnRocm93T25FcnJvcixcblx0XHRxdWVyeSxcblx0XHRzdXNwZW5zZTogZGVmYXVsdGVkT3B0aW9ucy5zdXNwZW5zZVxuXHR9KSkgdGhyb3cgcmVzdWx0LmVycm9yO1xuXHRyZXR1cm4gIWRlZmF1bHRlZE9wdGlvbnMubm90aWZ5T25DaGFuZ2VQcm9wcyA/IG9ic2VydmVyLnRyYWNrUmVzdWx0KHJlc3VsdCkgOiByZXN1bHQ7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZUJhc2VRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VCYXNlUXVlcnkuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VCYXNlUXVlcnkgfSBmcm9tIFwiLi91c2VCYXNlUXVlcnkuanNcIjtcbmltcG9ydCB7IFF1ZXJ5T2JzZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlUXVlcnkudHNcbmZ1bmN0aW9uIHVzZVF1ZXJ5KG9wdGlvbnMsIHF1ZXJ5Q2xpZW50KSB7XG5cdHJldHVybiB1c2VCYXNlUXVlcnkob3B0aW9ucywgUXVlcnlPYnNlcnZlciwgcXVlcnlDbGllbnQpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VRdWVyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IGRlZmF1bHRUaHJvd09uRXJyb3IgfSBmcm9tIFwiLi9zdXNwZW5zZS5qc1wiO1xuaW1wb3J0IHsgdXNlQmFzZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlQmFzZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyBRdWVyeU9ic2VydmVyLCBza2lwVG9rZW4gfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlU3VzcGVuc2VRdWVyeS50c1xuLyoqXG4qIFRoZSBvcHRpb25zIGZvciBgdXNlU3VzcGVuc2VRdWVyeWAgYXJlIHRoZSBzYW1lIGFzIGZvciBgdXNlUXVlcnlgLCBleGNlcHQgZm9yIGB0aHJvd09uRXJyb3JgLCBgZW5hYmxlZGAsIGFuZFxuKiBgcGxhY2Vob2xkZXJEYXRhYCDigJQgYW5kIGBxdWVyeUZuYCBtYXkgbm90IGJlIGBza2lwVG9rZW5gLCBzaW5jZSBTdXNwZW5zZSBob29rcyBjYW4ndCByZW5kZXIgYSBcImRpc2FibGVkXCIgc3RhdGUuXG4qXG4qIENhdmVhdDogY2FuY2VsbGF0aW9uIGRvZXMgbm90IHdvcmsuXG4qXG4qIEByZW1hcmtzIE11bHRpcGxlIGB1c2VTdXNwZW5zZVF1ZXJ5YCBjYWxscyBpbiB0aGUgc2FtZSBjb21wb25lbnQgc3VzcGVuZCBzZXJpYWxseSwgY2F1c2luZyBhIHJlcXVlc3Rcbiogd2F0ZXJmYWxsIOKAlCBlYWNoIG9uZSBibG9ja3MgcmVuZGVyaW5nIHVudGlsIGl0IHJlc29sdmVzLCBzbyB0aGUgbmV4dCBkb2Vzbid0IGV2ZW4gc3RhcnQgZmV0Y2hpbmcgdW50aWwgdGhlbi5cbiogVXNlIHtAbGluayB1c2VTdXNwZW5zZVF1ZXJpZXN9IGluc3RlYWQgd2hlbiB5b3UgaGF2ZSBtb3JlIHRoYW4gb25lIHN1c3BlbnNlZnVsIHF1ZXJ5IGluIGEgY29tcG9uZW50LCBzbyB0aGV5XG4qIGZldGNoIGluIHBhcmFsbGVsLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSB7QGxpbmsgVXNlU3VzcGVuc2VRdWVyeU9wdGlvbnN9IHRvIHVzZSDigJQgdGhlIHNhbWUgb3B0aW9ucyBhcyBgdXNlUXVlcnlgLCBtaW51cyB0aGUgb25lcyBsaXN0ZWQgYWJvdmUuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgVGhlIHNhbWUgb2JqZWN0IGFzIGB1c2VRdWVyeWAsIGV4Y2VwdCB0aGF0IGBkYXRhYCBpcyBndWFyYW50ZWVkIHRvIGJlIGRlZmluZWQsIGBpc1BsYWNlaG9sZGVyRGF0YWBcbiogaXMgbWlzc2luZywgYW5kIGBzdGF0dXNgIGlzIGVpdGhlciBgc3VjY2Vzc2Agb3IgYGVycm9yYCAod2l0aCB0aGUgZGVyaXZlZCBmbGFncyBzZXQgYWNjb3JkaW5nbHkpLlxuKlxuKiBAZXhhbXBsZVxuKiBUaGUgcXVlcnkgZXJyb3IgaXMgdGhyb3duIGlmIHRoZSBmZXRjaCBmYWlscyBhbmQgbm8gY2FjaGVkIGRhdGEgZXhpc3RzIHlldCwgc28gYW4gZXJyb3IgYm91bmRhcnkgaXNcbiogcmVxdWlyZWQgYXJvdW5kIGA8U3VzcGVuc2U+YC4gQSBmYWlsZWQgYmFja2dyb3VuZCByZWZldGNoIGluc3RlYWQgY29udGludWVzIHRvIHJlbmRlciB0aGUgY2FjaGVkIGRhdGEuXG4qIFVzZSB7QGxpbmsgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnl9IHRvIGxldCB0aGUgdXNlciByZXRyeSBhZnRlciBzdWNoIGFuIGVycm9yOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgU3VzcGVuc2UgfSBmcm9tICdyZWFjdCdcbiogaW1wb3J0IHsgRXJyb3JCb3VuZGFyeSB9IGZyb20gJ3JlYWN0LWVycm9yLWJvdW5kYXJ5J1xuKiBpbXBvcnQgeyBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSwgdXNlU3VzcGVuc2VRdWVyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gUG9zdHMoKSB7XG4qICAgLy8gYGRhdGFgIGlzIGd1YXJhbnRlZWQgdG8gYmUgZGVmaW5lZCBoZXJlIOKAlCBubyBgaXNQZW5kaW5nYCBjaGVjayBuZWVkZWQuXG4qICAgY29uc3QgeyBkYXRhLCBpc0ZldGNoaW5nIH0gPSB1c2VTdXNwZW5zZVF1ZXJ5KHtcbiogICAgIHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10sXG4qICAgICBxdWVyeUZuOiBmZXRjaFBvc3RzLFxuKiAgIH0pXG4qXG4qICAgcmV0dXJuIChcbiogICAgIDxkaXY+XG4qICAgICAgIDxoMT5Qb3N0cyB7aXNGZXRjaGluZyA/ICcocmVmcmVzaGluZy4uLiknIDogbnVsbH08L2gxPlxuKiAgICAgICA8dWw+XG4qICAgICAgICAge2RhdGEubWFwKChwb3N0KSA9PiAoXG4qICAgICAgICAgICA8bGkga2V5PXtwb3N0LmlkfT57cG9zdC50aXRsZX08L2xpPlxuKiAgICAgICAgICkpfVxuKiAgICAgICA8L3VsPlxuKiAgICAgPC9kaXY+XG4qICAgKVxuKiB9XG4qXG4qIGZ1bmN0aW9uIEFwcCgpIHtcbiogICByZXR1cm4gKFxuKiAgICAgPFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5PlxuKiAgICAgICB7KHsgcmVzZXQgfSkgPT4gKFxuKiAgICAgICAgIDxFcnJvckJvdW5kYXJ5XG4qICAgICAgICAgICBvblJlc2V0PXtyZXNldH1cbiogICAgICAgICAgIGZhbGxiYWNrUmVuZGVyPXsoeyByZXNldEVycm9yQm91bmRhcnkgfSkgPT4gKFxuKiAgICAgICAgICAgICA8ZGl2PlxuKiAgICAgICAgICAgICAgIFRoZXJlIHdhcyBhbiBlcnJvciFcbiogICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHJlc2V0RXJyb3JCb3VuZGFyeSgpfT5UcnkgYWdhaW48L2J1dHRvbj5cbiogICAgICAgICAgICAgPC9kaXY+XG4qICAgICAgICAgICApfVxuKiAgICAgICAgID5cbiogICAgICAgICAgIDxTdXNwZW5zZSBmYWxsYmFjaz17PGgxPkxvYWRpbmcgcG9zdHMuLi48L2gxPn0+XG4qICAgICAgICAgICAgIDxQb3N0cyAvPlxuKiAgICAgICAgICAgPC9TdXNwZW5zZT5cbiogICAgICAgICA8L0Vycm9yQm91bmRhcnk+XG4qICAgICAgICl9XG4qICAgICA8L1F1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5PlxuKiAgIClcbiogfVxuKiBgYGBcbiovXG5mdW5jdGlvbiB1c2VTdXNwZW5zZVF1ZXJ5KG9wdGlvbnMsIHF1ZXJ5Q2xpZW50KSB7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRpZiAob3B0aW9ucy5xdWVyeUZuID09PSBza2lwVG9rZW4pIGNvbnNvbGUuZXJyb3IoXCJza2lwVG9rZW4gaXMgbm90IGFsbG93ZWQgZm9yIHVzZVN1c3BlbnNlUXVlcnlcIik7XG5cdH1cblx0cmV0dXJuIHVzZUJhc2VRdWVyeSh7XG5cdFx0Li4ub3B0aW9ucyxcblx0XHRlbmFibGVkOiB0cnVlLFxuXHRcdHN1c3BlbnNlOiB0cnVlLFxuXHRcdHRocm93T25FcnJvcjogZGVmYXVsdFRocm93T25FcnJvcixcblx0XHRwbGFjZWhvbGRlckRhdGE6IHZvaWQgMFxuXHR9LCBRdWVyeU9ic2VydmVyLCBxdWVyeUNsaWVudCk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZVN1c3BlbnNlUXVlcnkgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlU3VzcGVuc2VRdWVyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IGRlZmF1bHRUaHJvd09uRXJyb3IgfSBmcm9tIFwiLi9zdXNwZW5zZS5qc1wiO1xuaW1wb3J0IHsgdXNlQmFzZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlQmFzZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIsIHNraXBUb2tlbiB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VTdXNwZW5zZUluZmluaXRlUXVlcnkudHNcbi8qKlxuKiBUaGUgb3B0aW9ucyBmb3IgYHVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeWAgYXJlIHRoZSBzYW1lIGFzIGZvciBgdXNlSW5maW5pdGVRdWVyeWAsIGV4Y2VwdCBmb3IgYHRocm93T25FcnJvcmAsXG4qIGBlbmFibGVkYCwgYW5kIGBwbGFjZWhvbGRlckRhdGFgLlxuKlxuKiBDYXZlYXQ6IGNhbmNlbGxhdGlvbiBkb2VzIG5vdCB3b3JrLlxuKlxuKiBAcmVtYXJrcyBNdWx0aXBsZSBzdXNwZW5zZWZ1bCBxdWVyeSBjYWxscyBpbiB0aGUgc2FtZSBjb21wb25lbnQgc3VzcGVuZCBzZXJpYWxseSwgY2F1c2luZyBhIHJlcXVlc3Rcbiogd2F0ZXJmYWxsIOKAlCBlYWNoIG9uZSBibG9ja3MgcmVuZGVyaW5nIHVudGlsIGl0IHJlc29sdmVzLCBzbyB0aGUgbmV4dCBkb2Vzbid0IGV2ZW4gc3RhcnQgZmV0Y2hpbmcgdW50aWxcbiogdGhlbi4gVGhlcmUncyBubyB3YXkgdG8gcGFyYWxsZWxpemUgbXVsdGlwbGUgaW5maW5pdGUgcXVlcmllcyB1bmRlciBTdXNwZW5zZS4gQWxzbyBrZWVwIGluIG1pbmQgdGhhdFxuKiBpbXBlcmF0aXZlIGZldGNoIGNhbGxzLCBzdWNoIGFzIGBmZXRjaE5leHRQYWdlYCwgbWF5IGludGVyZmVyZSB3aXRoIHRoZSBkZWZhdWx0IHJlZmV0Y2ggYmVoYXZpb3IsXG4qIHJlc3VsdGluZyBpbiBvdXRkYXRlZCBkYXRhLiBNYWtlIHN1cmUgdG8gY2FsbCB0aGVzZSBmdW5jdGlvbnMgb25seSBpbiByZXNwb25zZSB0byB1c2VyIGFjdGlvbnMsIG9yIGFkZFxuKiBjb25kaXRpb25zIGxpa2UgYGhhc05leHRQYWdlICYmICFpc0ZldGNoaW5nYC5cbiogQHNlZSB7QGxpbmsgdXNlSW5maW5pdGVRdWVyeX0gZm9yIHRoZSBub24tU3VzcGVuc2UgdmVyc2lvbiBvZiB0aGlzIGhvb2suXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIHtAbGluayBVc2VTdXNwZW5zZUluZmluaXRlUXVlcnlPcHRpb25zfSB0byB1c2Ug4oCUIHRoZSBzYW1lIG9wdGlvbnMgYXMgYHVzZUluZmluaXRlUXVlcnlgLCBtaW51cyB0aGUgb25lcyBsaXN0ZWQgYWJvdmUuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgVGhlIHNhbWUgb2JqZWN0IGFzIGB1c2VJbmZpbml0ZVF1ZXJ5YCwgZXhjZXB0IHRoYXQgYGRhdGFgIGlzIGd1YXJhbnRlZWQgdG8gYmUgZGVmaW5lZCxcbiogYGlzUGxhY2Vob2xkZXJEYXRhYCBpcyBtaXNzaW5nLCBhbmQgYHN0YXR1c2AgaXMgZWl0aGVyIGBzdWNjZXNzYCBvciBgZXJyb3JgICh3aXRoIHRoZSBkZXJpdmVkIGZsYWdzIHNldFxuKiBhY2NvcmRpbmdseSkuXG4qXG4qIEBleGFtcGxlXG4qIFRoZSBxdWVyeSBlcnJvciBpcyB0aHJvd24gaWYgYSBmZXRjaCBmYWlscyBhbmQgbm8gY2FjaGVkIGRhdGEgZXhpc3RzIHlldCwgc28gYW4gZXJyb3IgYm91bmRhcnkgaXNcbiogcmVxdWlyZWQgYXJvdW5kIGA8U3VzcGVuc2U+YC4gQSBmYWlsZWQgYmFja2dyb3VuZCByZWZldGNoIGluc3RlYWQgY29udGludWVzIHRvIHJlbmRlciB0aGUgY2FjaGVkIGRhdGEuXG4qIFVzZSB7QGxpbmsgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnl9IHRvIGxldCB0aGUgdXNlciByZXRyeSBhZnRlciBzdWNoIGFuIGVycm9yOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgU3VzcGVuc2UgfSBmcm9tICdyZWFjdCdcbiogaW1wb3J0IHsgRXJyb3JCb3VuZGFyeSB9IGZyb20gJ3JlYWN0LWVycm9yLWJvdW5kYXJ5J1xuKiBpbXBvcnQge1xuKiAgIFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LFxuKiAgIHVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeSxcbiogfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIFByb2plY3RzKCkge1xuKiAgIC8vIGBkYXRhYCBpcyBndWFyYW50ZWVkIHRvIGJlIGRlZmluZWQgaGVyZSDigJQgbm8gYGlzUGVuZGluZ2AgY2hlY2sgbmVlZGVkLlxuKiAgIGNvbnN0IHsgZGF0YSwgZmV0Y2hOZXh0UGFnZSwgaGFzTmV4dFBhZ2UsIGlzRmV0Y2hpbmcsIGlzRmV0Y2hpbmdOZXh0UGFnZSB9ID1cbiogICAgIHVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeSh7XG4qICAgICAgIHF1ZXJ5S2V5OiBbJ3Byb2plY3RzJ10sXG4qICAgICAgIHF1ZXJ5Rm46ICh7IHBhZ2VQYXJhbSB9KSA9PiBmZXRjaFByb2plY3RzKHBhZ2VQYXJhbSksXG4qICAgICAgIGluaXRpYWxQYWdlUGFyYW06IDAsXG4qICAgICAgIGdldE5leHRQYWdlUGFyYW06IChsYXN0UGFnZSkgPT4gbGFzdFBhZ2UubmV4dElkLFxuKiAgICAgfSlcbipcbiogICByZXR1cm4gKFxuKiAgICAgPGRpdj5cbiogICAgICAgPHVsPlxuKiAgICAgICAgIHtkYXRhLnBhZ2VzLm1hcCgocGFnZSkgPT5cbiogICAgICAgICAgIHBhZ2UucHJvamVjdHMubWFwKChwcm9qZWN0KSA9PiA8bGkga2V5PXtwcm9qZWN0LmlkfT57cHJvamVjdC5uYW1lfTwvbGk+KSxcbiogICAgICAgICApfVxuKiAgICAgICA8L3VsPlxuKiAgICAgICA8YnV0dG9uXG4qICAgICAgICAgb25DbGljaz17KCkgPT4gZmV0Y2hOZXh0UGFnZSgpfVxuKiAgICAgICAgIGRpc2FibGVkPXshaGFzTmV4dFBhZ2UgfHwgaXNGZXRjaGluZ31cbiogICAgICAgPlxuKiAgICAgICAgIHtpc0ZldGNoaW5nTmV4dFBhZ2VcbiogICAgICAgICAgID8gJ0xvYWRpbmcgbW9yZS4uLidcbiogICAgICAgICAgIDogaGFzTmV4dFBhZ2VcbiogICAgICAgICAgICAgPyAnTG9hZCBNb3JlJ1xuKiAgICAgICAgICAgICA6ICdOb3RoaW5nIG1vcmUgdG8gbG9hZCd9XG4qICAgICAgIDwvYnV0dG9uPlxuKiAgICAgPC9kaXY+XG4qICAgKVxuKiB9XG4qXG4qIGZ1bmN0aW9uIEFwcCgpIHtcbiogICByZXR1cm4gKFxuKiAgICAgPFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5PlxuKiAgICAgICB7KHsgcmVzZXQgfSkgPT4gKFxuKiAgICAgICAgIDxFcnJvckJvdW5kYXJ5XG4qICAgICAgICAgICBvblJlc2V0PXtyZXNldH1cbiogICAgICAgICAgIGZhbGxiYWNrUmVuZGVyPXsoeyByZXNldEVycm9yQm91bmRhcnkgfSkgPT4gKFxuKiAgICAgICAgICAgICA8ZGl2PlxuKiAgICAgICAgICAgICAgIFRoZXJlIHdhcyBhbiBlcnJvciFcbiogICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHJlc2V0RXJyb3JCb3VuZGFyeSgpfT5UcnkgYWdhaW48L2J1dHRvbj5cbiogICAgICAgICAgICAgPC9kaXY+XG4qICAgICAgICAgICApfVxuKiAgICAgICAgID5cbiogICAgICAgICAgIDxTdXNwZW5zZSBmYWxsYmFjaz17PGgxPkxvYWRpbmcgcHJvamVjdHMuLi48L2gxPn0+XG4qICAgICAgICAgICAgIDxQcm9qZWN0cyAvPlxuKiAgICAgICAgICAgPC9TdXNwZW5zZT5cbiogICAgICAgICA8L0Vycm9yQm91bmRhcnk+XG4qICAgICAgICl9XG4qICAgICA8L1F1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5PlxuKiAgIClcbiogfVxuKiBgYGBcbiovXG5mdW5jdGlvbiB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnkob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdGlmIChvcHRpb25zLnF1ZXJ5Rm4gPT09IHNraXBUb2tlbikgY29uc29sZS5lcnJvcihcInNraXBUb2tlbiBpcyBub3QgYWxsb3dlZCBmb3IgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5XCIpO1xuXHR9XG5cdHJldHVybiB1c2VCYXNlUXVlcnkoe1xuXHRcdC4uLm9wdGlvbnMsXG5cdFx0ZW5hYmxlZDogdHJ1ZSxcblx0XHRzdXNwZW5zZTogdHJ1ZSxcblx0XHR0aHJvd09uRXJyb3I6IGRlZmF1bHRUaHJvd09uRXJyb3IsXG5cdFx0cGxhY2Vob2xkZXJEYXRhOiB2b2lkIDBcblx0fSwgSW5maW5pdGVRdWVyeU9ic2VydmVyLCBxdWVyeUNsaWVudCk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VTdXNwZW5zZUluZmluaXRlUXVlcnkuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyBkZWZhdWx0VGhyb3dPbkVycm9yIH0gZnJvbSBcIi4vc3VzcGVuc2UuanNcIjtcbmltcG9ydCB7IHVzZVF1ZXJpZXMgfSBmcm9tIFwiLi91c2VRdWVyaWVzLmpzXCI7XG5pbXBvcnQgeyBza2lwVG9rZW4gfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlU3VzcGVuc2VRdWVyaWVzLnRzXG5mdW5jdGlvbiB1c2VTdXNwZW5zZVF1ZXJpZXMob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcblx0cmV0dXJuIHVzZVF1ZXJpZXMoe1xuXHRcdC4uLm9wdGlvbnMsXG5cdFx0cXVlcmllczogb3B0aW9ucy5xdWVyaWVzLm1hcCgocXVlcnkpID0+IHtcblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRcdFx0aWYgKHF1ZXJ5LnF1ZXJ5Rm4gPT09IHNraXBUb2tlbikgY29uc29sZS5lcnJvcihcInNraXBUb2tlbiBpcyBub3QgYWxsb3dlZCBmb3IgdXNlU3VzcGVuc2VRdWVyaWVzXCIpO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0Li4ucXVlcnksXG5cdFx0XHRcdHN1c3BlbnNlOiB0cnVlLFxuXHRcdFx0XHR0aHJvd09uRXJyb3I6IGRlZmF1bHRUaHJvd09uRXJyb3IsXG5cdFx0XHRcdGVuYWJsZWQ6IHRydWUsXG5cdFx0XHRcdHBsYWNlaG9sZGVyRGF0YTogdm9pZCAwXG5cdFx0XHR9O1xuXHRcdH0pXG5cdH0sIHF1ZXJ5Q2xpZW50KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlU3VzcGVuc2VRdWVyaWVzIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVN1c3BlbnNlUXVlcmllcy5qcy5tYXAiLCJpbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IG5vb3AgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlUHJlZmV0Y2hRdWVyeS50c3hcbi8qKlxuKiBgdXNlUHJlZmV0Y2hRdWVyeWAgZG9lcyBub3QgcmV0dXJuIGFueXRoaW5nLCBpdCBzaG91bGQgYmUgdXNlZCBqdXN0IHRvIGZpcmUgYSBwcmVmZXRjaCBkdXJpbmcgcmVuZGVyLCBiZWZvcmVcbiogYSBzdXNwZW5zZSBib3VuZGFyeSB0aGF0IHdyYXBzIGEgY29tcG9uZW50IHRoYXQgdXNlcyBgdXNlU3VzcGVuc2VRdWVyeWAuIFlvdSBjYW4gcGFzcyBldmVyeXRoaW5nIHRvXG4qIGB1c2VQcmVmZXRjaFF1ZXJ5YCB0aGF0IHlvdSBjYW4gcGFzcyB0byBgcXVlcnlDbGllbnQucXVlcnlgLCB0aG91Z2ggYHF1ZXJ5S2V5YCBpcyBhbHdheXMgcmVxdWlyZWQsIGFuZFxuKiBgcXVlcnlGbmAgaXMgcmVxdWlyZWQgdW5sZXNzIGEgZGVmYXVsdCBxdWVyeSBmdW5jdGlvbiBoYXMgYmVlbiBkZWZpbmVkLlxuKlxuKiBUaGUgcHJlZmV0Y2ggaXMgc2tpcHBlZCBpZiB0aGUgcXVlcnkgYWxyZWFkeSBoYXMgYW55IGNhY2hlZCBzdGF0ZSDigJQgaW5jbHVkaW5nIGEgYHBlbmRpbmdgL2BlcnJvcmAgc3RhdGUgbGVmdFxuKiBvdmVyIGZyb20gYSBwcmV2aW91cyBhdHRlbXB0IOKAlCBzbyBjYWxsaW5nIHRoaXMgb24gZXZlcnkgcmVuZGVyIGlzIGNoZWFwIGFuZCB3b24ndCByZWZldGNoIGRhdGEgdGhhdCdzXG4qIGFscmVhZHkgdGhlcmUgb3IgYWxyZWFkeSBpbiBmbGlnaHQuXG4qXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIHtAbGluayBVc2VQcmVmZXRjaFF1ZXJ5T3B0aW9uc30gdG8gdXNlIOKAlCBldmVyeXRoaW5nIHlvdSBjYW4gcGFzcyB0byBgcXVlcnlDbGllbnQucXVlcnlgLlxuKiBAcGFyYW0gcXVlcnlDbGllbnQgLSBVc2UgdGhpcyB0byB1c2UgYSBjdXN0b20gYFF1ZXJ5Q2xpZW50YC4gT3RoZXJ3aXNlLCB0aGUgb25lIGZyb20gdGhlIG5lYXJlc3QgY29udGV4dCB3aWxsXG4qIGJlIHVzZWQuXG4qIEByZXR1cm5zIGB2b2lkYCDigJQgbm90aGluZyBpcyByZXR1cm5lZC5cbipcbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGltcG9ydCB7IFN1c3BlbnNlIH0gZnJvbSAncmVhY3QnXG4qIGltcG9ydCB7IHVzZVByZWZldGNoUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIEFwcCgpIHtcbiogICAvLyBGaXJlIHRoZSBwcmVmZXRjaCBkdXJpbmcgcmVuZGVyLCBiZWZvcmUgdGhlIHN1c3BlbnNlIGJvdW5kYXJ5IGJlbG93LlxuKiAgIHVzZVByZWZldGNoUXVlcnkoe1xuKiAgICAgcXVlcnlLZXk6IFsncG9zdHMnXSxcbiogICAgIHF1ZXJ5Rm46IGZldGNoUG9zdHMsXG4qICAgfSlcbipcbiogICByZXR1cm4gKFxuKiAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8aDE+TG9hZGluZyBwb3N0cy4uLjwvaDE+fT5cbiogICAgICAgPFBvc3RzIC8+XG4qICAgICA8L1N1c3BlbnNlPlxuKiAgIClcbiogfVxuKiBgYGBcbiovXG5mdW5jdGlvbiB1c2VQcmVmZXRjaFF1ZXJ5KG9wdGlvbnMsIHF1ZXJ5Q2xpZW50KSB7XG5cdGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcblx0aWYgKCFjbGllbnQuZ2V0UXVlcnlTdGF0ZShvcHRpb25zLnF1ZXJ5S2V5KSkgY2xpZW50LnF1ZXJ5KG9wdGlvbnMpLmNhdGNoKG5vb3ApO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VQcmVmZXRjaFF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVByZWZldGNoUXVlcnkuanMubWFwIiwiaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyBub29wIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyNyZWdpb24gc3JjL3VzZVByZWZldGNoSW5maW5pdGVRdWVyeS50c3hcbi8qKlxuKiBgdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5YCBkb2VzIG5vdCByZXR1cm4gYW55dGhpbmcsIGl0IHNob3VsZCBiZSB1c2VkIGp1c3QgdG8gZmlyZSBhIHByZWZldGNoIGR1cmluZyByZW5kZXIsXG4qIGJlZm9yZSBhIHN1c3BlbnNlIGJvdW5kYXJ5IHRoYXQgd3JhcHMgYSBjb21wb25lbnQgdGhhdCB1c2VzIGB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnlgLiBZb3UgY2FuIHBhc3NcbiogZXZlcnl0aGluZyB0byBgdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5YCB0aGF0IHlvdSBjYW4gcGFzcyB0byBgcXVlcnlDbGllbnQuaW5maW5pdGVRdWVyeWAsIHRob3VnaFxuKiBgcXVlcnlLZXlgLCBgaW5pdGlhbFBhZ2VQYXJhbWAsIGFuZCBgZ2V0TmV4dFBhZ2VQYXJhbWAgYXJlIGFsd2F5cyByZXF1aXJlZCwgYW5kIGBxdWVyeUZuYCBpcyByZXF1aXJlZCB1bmxlc3NcbiogYSBkZWZhdWx0IHF1ZXJ5IGZ1bmN0aW9uIGhhcyBiZWVuIGRlZmluZWQuXG4qXG4qIGBnZXROZXh0UGFnZVBhcmFtYCByZWNlaXZlcyBib3RoIHRoZSBsYXN0IHBhZ2Ugb2YgdGhlIGluZmluaXRlIGxpc3Qgb2YgZGF0YSBhbmQgdGhlIGZ1bGwgYXJyYXkgb2YgYWxsIHBhZ2VzLFxuKiBhcyB3ZWxsIGFzIHBhZ2VQYXJhbSBpbmZvcm1hdGlvbiwgYW5kIHNob3VsZCByZXR1cm4gYSBzaW5nbGUgdmFyaWFibGUgdGhhdCB3aWxsIGJlIHBhc3NlZCB0byB5b3VyIHF1ZXJ5XG4qIGZ1bmN0aW9uIGFzIGBjb250ZXh0LnBhZ2VQYXJhbWAuIFJldHVybiBgdW5kZWZpbmVkYCBvciBgbnVsbGAgdG8gaW5kaWNhdGUgdGhlcmUgaXMgbm8gbmV4dCBwYWdlIGF2YWlsYWJsZS5cbipcbiogVGhlIHByZWZldGNoIGlzIHNraXBwZWQgaWYgdGhlIHF1ZXJ5IGFscmVhZHkgaGFzIGFueSBjYWNoZWQgc3RhdGUg4oCUIGluY2x1ZGluZyBhIGBwZW5kaW5nYC9gZXJyb3JgIHN0YXRlIGxlZnRcbiogb3ZlciBmcm9tIGEgcHJldmlvdXMgYXR0ZW1wdCDigJQgc28gY2FsbGluZyB0aGlzIG9uIGV2ZXJ5IHJlbmRlciBpcyBjaGVhcCBhbmQgd29uJ3QgcmVmZXRjaCBkYXRhIHRoYXQnc1xuKiBhbHJlYWR5IHRoZXJlIG9yIGFscmVhZHkgaW4gZmxpZ2h0LlxuKlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSB7QGxpbmsgVXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5T3B0aW9uc30gdG8gdXNlIOKAlCBldmVyeXRoaW5nIHlvdSBjYW4gcGFzcyB0byBgcXVlcnlDbGllbnQuaW5maW5pdGVRdWVyeWAuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgYHZvaWRgIOKAlCBub3RoaW5nIGlzIHJldHVybmVkLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgU3VzcGVuc2UgfSBmcm9tICdyZWFjdCdcbiogaW1wb3J0IHsgaW5maW5pdGVRdWVyeU9wdGlvbnMsIHVzZVByZWZldGNoSW5maW5pdGVRdWVyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogY29uc3QgcHJvamVjdHNPcHRpb25zID0gaW5maW5pdGVRdWVyeU9wdGlvbnMoe1xuKiAgIHF1ZXJ5S2V5OiBbJ3Byb2plY3RzJ10sXG4qICAgcXVlcnlGbjogKHsgcGFnZVBhcmFtIH0pID0+IGZldGNoUHJvamVjdHMocGFnZVBhcmFtKSxcbiogICBpbml0aWFsUGFnZVBhcmFtOiAwLFxuKiAgIGdldE5leHRQYWdlUGFyYW06IChsYXN0UGFnZSkgPT4gbGFzdFBhZ2UubmV4dElkLFxuKiB9KVxuKlxuKiBmdW5jdGlvbiBBcHAoKSB7XG4qICAgLy8gRmlyZSB0aGUgcHJlZmV0Y2ggZHVyaW5nIHJlbmRlciwgYmVmb3JlIHRoZSBzdXNwZW5zZSBib3VuZGFyeSBiZWxvdy5cbiogICB1c2VQcmVmZXRjaEluZmluaXRlUXVlcnkocHJvamVjdHNPcHRpb25zKVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxoMT5Mb2FkaW5nIHByb2plY3RzLi4uPC9oMT59PlxuKiAgICAgICA8UHJvamVjdHMgLz5cbiogICAgIDwvU3VzcGVuc2U+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZVByZWZldGNoSW5maW5pdGVRdWVyeShvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuXHRjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG5cdGlmICghY2xpZW50LmdldFF1ZXJ5U3RhdGUob3B0aW9ucy5xdWVyeUtleSkpIGNsaWVudC5pbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpLmNhdGNoKG5vb3ApO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VQcmVmZXRjaEluZmluaXRlUXVlcnkgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5LmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvcXVlcnlPcHRpb25zLnRzXG5mdW5jdGlvbiBxdWVyeU9wdGlvbnMob3B0aW9ucykge1xuXHRyZXR1cm4gb3B0aW9ucztcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgcXVlcnlPcHRpb25zIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXF1ZXJ5T3B0aW9ucy5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL2luZmluaXRlUXVlcnlPcHRpb25zLnRzXG5mdW5jdGlvbiBpbmZpbml0ZVF1ZXJ5T3B0aW9ucyhvcHRpb25zKSB7XG5cdHJldHVybiBvcHRpb25zO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBpbmZpbml0ZVF1ZXJ5T3B0aW9ucyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmZpbml0ZVF1ZXJ5T3B0aW9ucy5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIi4vUXVlcnlDbGllbnRQcm92aWRlci5qc1wiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyNyZWdpb24gc3JjL3VzZUlzRmV0Y2hpbmcudHNcbi8qKlxuKiBUaGUgYHVzZUlzRmV0Y2hpbmdgIGhvb2sgcmV0dXJucyB0aGUgYG51bWJlcmAgb2YgdGhlIHF1ZXJpZXMgdGhhdCB5b3VyIGFwcGxpY2F0aW9uIGlzIGxvYWRpbmcgb3IgZmV0Y2hpbmcgaW5cbiogdGhlIGJhY2tncm91bmQgKHVzZWZ1bCBmb3IgYXBwLXdpZGUgbG9hZGluZyBpbmRpY2F0b3JzKS5cbipcbiogQHBhcmFtIGZpbHRlcnMgLSBUaGUge0BsaW5rIFF1ZXJ5RmlsdGVyc30gdG8gbmFycm93IGRvd24gdGhlIG1hdGNoZWQgcXVlcmllcy5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0IGNvbnRleHQgd2lsbFxuKiBiZSB1c2VkLlxuKiBAcmV0dXJucyBXaWxsIGJlIHRoZSBgbnVtYmVyYCBvZiB0aGUgcXVlcmllcyB0aGF0IHlvdXIgYXBwbGljYXRpb24gaXMgY3VycmVudGx5IGxvYWRpbmcgb3IgZmV0Y2hpbmcgaW4gdGhlXG4qIGJhY2tncm91bmQuXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VJc0ZldGNoaW5nIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBQb3N0c0ZldGNoaW5nSW5kaWNhdG9yKCkge1xuKiAgIC8vIEhvdyBtYW55IHF1ZXJpZXMgbWF0Y2hpbmcgdGhlIHBvc3RzIHByZWZpeCBhcmUgZmV0Y2hpbmc/XG4qICAgY29uc3QgaXNGZXRjaGluZ1Bvc3RzID0gdXNlSXNGZXRjaGluZyh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10gfSlcbipcbiogICByZXR1cm4gaXNGZXRjaGluZ1Bvc3RzID8gPHNwYW4+UmVmcmVzaGluZyBwb3N0cy4uLjwvc3Bhbj4gOiBudWxsXG4qIH1cbiogYGBgXG4qXG4qIEBleGFtcGxlXG4qIEEgZ2xvYmFsIGxvYWRpbmcgaW5kaWNhdG9yIGZvciBhbnkgcXVlcnkgZmV0Y2hpbmcgaW4gdGhlIGJhY2tncm91bmQsIG5vdCBqdXN0IHRoZSBvbmVzIG9uIHNjcmVlbjpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZUlzRmV0Y2hpbmcgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIEdsb2JhbExvYWRpbmdJbmRpY2F0b3IoKSB7XG4qICAgY29uc3QgaXNGZXRjaGluZyA9IHVzZUlzRmV0Y2hpbmcoKVxuKlxuKiAgIHJldHVybiBpc0ZldGNoaW5nID8gKFxuKiAgICAgPGRpdj5RdWVyaWVzIGFyZSBmZXRjaGluZyBpbiB0aGUgYmFja2dyb3VuZC4uLjwvZGl2PlxuKiAgICkgOiBudWxsXG4qIH1cbiogYGBgXG4qL1xuZnVuY3Rpb24gdXNlSXNGZXRjaGluZyhmaWx0ZXJzLCBxdWVyeUNsaWVudCkge1xuXHRjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG5cdGNvbnN0IHF1ZXJ5Q2FjaGUgPSBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpO1xuXHRyZXR1cm4gUmVhY3QudXNlU3luY0V4dGVybmFsU3RvcmUoUmVhY3QudXNlQ2FsbGJhY2soKG9uU3RvcmVDaGFuZ2UpID0+IHF1ZXJ5Q2FjaGUuc3Vic2NyaWJlKG5vdGlmeU1hbmFnZXIuYmF0Y2hDYWxscyhvblN0b3JlQ2hhbmdlKSksIFtxdWVyeUNhY2hlXSksICgpID0+IGNsaWVudC5pc0ZldGNoaW5nKGZpbHRlcnMpLCAoKSA9PiBjbGllbnQuaXNGZXRjaGluZyhmaWx0ZXJzKSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZUlzRmV0Y2hpbmcgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlSXNGZXRjaGluZy5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIi4vUXVlcnlDbGllbnRQcm92aWRlci5qc1wiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyLCByZXBsYWNlRXF1YWxEZWVwIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyNyZWdpb24gc3JjL3VzZU11dGF0aW9uU3RhdGUudHNcbi8qKlxuKiBUaGUgYHVzZUlzTXV0YXRpbmdgIGhvb2sgcmV0dXJucyB0aGUgYG51bWJlcmAgb2YgbXV0YXRpb25zIHRoYXQgeW91ciBhcHBsaWNhdGlvbiBjdXJyZW50bHkgaGFzIGBwZW5kaW5nYFxuKiAodXNlZnVsIGZvciBhcHAtd2lkZSBsb2FkaW5nIGluZGljYXRvcnMpLlxuKlxuKiBAcGFyYW0gZmlsdGVycyAtIFRoZSB7QGxpbmsgTXV0YXRpb25GaWx0ZXJzfSB0byBuYXJyb3cgZG93biB0aGUgbWF0Y2hlZCBtdXRhdGlvbnMuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgV2lsbCBiZSB0aGUgYG51bWJlcmAgb2YgdGhlIG11dGF0aW9ucyB0aGF0IHlvdXIgYXBwbGljYXRpb24gY3VycmVudGx5IGhhcyBgcGVuZGluZ2AuXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VJc011dGF0aW5nIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBQb3N0c011dGF0aW5nSW5kaWNhdG9yKCkge1xuKiAgIC8vIEhvdyBtYW55IG11dGF0aW9ucyBtYXRjaGluZyB0aGUgcG9zdHMgcHJlZml4IGFyZSBpbiBwcm9ncmVzcz9cbiogICBjb25zdCBpc011dGF0aW5nUG9zdHMgPSB1c2VJc011dGF0aW5nKHsgbXV0YXRpb25LZXk6IFsncG9zdHMnXSB9KVxuKlxuKiAgIHJldHVybiBpc011dGF0aW5nUG9zdHMgPyA8c3Bhbj5TYXZpbmcgcG9zdHMuLi48L3NwYW4+IDogbnVsbFxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZUlzTXV0YXRpbmcoZmlsdGVycywgcXVlcnlDbGllbnQpIHtcblx0Y29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuXHRyZXR1cm4gdXNlTXV0YXRpb25TdGF0ZSh7IGZpbHRlcnM6IHtcblx0XHQuLi5maWx0ZXJzLFxuXHRcdHN0YXR1czogXCJwZW5kaW5nXCJcblx0fSB9LCBjbGllbnQpLmxlbmd0aDtcbn1cbmZ1bmN0aW9uIGdldFJlc3VsdChtdXRhdGlvbkNhY2hlLCBvcHRpb25zKSB7XG5cdHJldHVybiBtdXRhdGlvbkNhY2hlLmZpbmRBbGwob3B0aW9ucy5maWx0ZXJzKS5tYXAoKG11dGF0aW9uKSA9PiBvcHRpb25zLnNlbGVjdCA/IG9wdGlvbnMuc2VsZWN0KG11dGF0aW9uKSA6IG11dGF0aW9uLnN0YXRlKTtcbn1cbi8qKlxuKiBgdXNlTXV0YXRpb25TdGF0ZWAgaXMgYSBob29rIHRoYXQgZ2l2ZXMgeW91IGFjY2VzcyB0byBhbGwgbXV0YXRpb25zIGluIHRoZSBgTXV0YXRpb25DYWNoZWAuIFlvdSBjYW4gcGFzc1xuKiBgZmlsdGVyc2AgKHtAbGluayBNdXRhdGlvbkZpbHRlcnN9KSB0byBuYXJyb3cgZG93biB5b3VyIG11dGF0aW9ucywgYW5kIGBzZWxlY3RgIHRvIHRyYW5zZm9ybSB0aGUgbXV0YXRpb25cbiogc3RhdGUuXG4qXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIGBmaWx0ZXJzYCB0byBuYXJyb3cgZG93biBtYXRjaGVkIG11dGF0aW9ucywgYW5kIGFuIG9wdGlvbmFsIGBzZWxlY3RgIHRvIHRyYW5zZm9ybSB0aGVcbiogbXV0YXRpb24gc3RhdGUuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgV2lsbCBiZSBhbiBBcnJheSBvZiB3aGF0ZXZlciBgc2VsZWN0YCByZXR1cm5zIGZvciBlYWNoIG1hdGNoaW5nIG11dGF0aW9uLlxuKlxuKiBAZXhhbXBsZVxuKiBHZXQgYWxsIHZhcmlhYmxlcyBvZiBhbGwgcnVubmluZyBtdXRhdGlvbnM6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VNdXRhdGlvblN0YXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBQZW5kaW5nUG9zdHMoKSB7XG4qICAgY29uc3QgcGVuZGluZ1ZhcmlhYmxlcyA9IHVzZU11dGF0aW9uU3RhdGUoe1xuKiAgICAgZmlsdGVyczogeyBzdGF0dXM6ICdwZW5kaW5nJyB9LFxuKiAgICAgc2VsZWN0OiAobXV0YXRpb24pID0+IG11dGF0aW9uLnN0YXRlLnZhcmlhYmxlcyxcbiogICB9KVxuKlxuKiAgIHJldHVybiA8PntwZW5kaW5nVmFyaWFibGVzLmxlbmd0aH0gcG9zdHMgc2F2aW5nLi4uPC8+XG4qIH1cbiogYGBgXG4qXG4qIEBleGFtcGxlXG4qIEdldCBhbGwgZGF0YSBmb3Igc3BlY2lmaWMgbXV0YXRpb25zIHZpYSB0aGUgYG11dGF0aW9uS2V5YDpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VNdXRhdGlvblN0YXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBjb25zdCBtdXRhdGlvbktleSA9IFsncG9zdHMnXVxuKlxuKiBmdW5jdGlvbiBQb3N0cygpIHtcbiogICAvLyBTb21lIG11dGF0aW9uIHRoYXQgd2Ugd2FudCB0byBnZXQgdGhlIHN0YXRlIGZvclxuKiAgIGNvbnN0IG11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xuKiAgICAgbXV0YXRpb25LZXksXG4qICAgICBtdXRhdGlvbkZuOiBjcmVhdGVQb3N0cyxcbiogICB9KVxuKlxuKiAgIGNvbnN0IHNhdmVkUG9zdHMgPSB1c2VNdXRhdGlvblN0YXRlKHtcbiogICAgIC8vIHRoaXMgbXV0YXRpb24ga2V5IG5lZWRzIHRvIG1hdGNoIHRoZSBtdXRhdGlvbiBrZXkgb2YgdGhlIGdpdmVuIG11dGF0aW9uIChzZWUgYWJvdmUpXG4qICAgICBmaWx0ZXJzOiB7IG11dGF0aW9uS2V5LCBzdGF0dXM6ICdzdWNjZXNzJyB9LFxuKiAgICAgc2VsZWN0OiAobXV0YXRpb24pID0+IG11dGF0aW9uLnN0YXRlLmRhdGEsXG4qICAgfSlcbipcbiogICByZXR1cm4gKFxuKiAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBtdXRhdGlvbi5tdXRhdGUoWydOZXcgUG9zdCddKX0+XG4qICAgICAgIENyZWF0ZSBwb3N0ICh7c2F2ZWRQb3N0cy5sZW5ndGh9IHNhdmVkIHNvIGZhcilcbiogICAgIDwvYnV0dG9uPlxuKiAgIClcbiogfVxuKiBgYGBcbipcbiogQGV4YW1wbGVcbiogQWNjZXNzIHRoZSBsYXRlc3Qgc3VjY2Vzc2Z1bCBtdXRhdGlvbiBkYXRhIHZpYSB0aGUgYG11dGF0aW9uS2V5YC4gRWFjaCBpbnZvY2F0aW9uIG9mIGBtdXRhdGVgIGFkZHMgYSBuZXdcbiogZW50cnkgdG8gdGhlIG11dGF0aW9uIGNhY2hlIGZvciBgZ2NUaW1lYCBtaWxsaXNlY29uZHMg4oCUIHdpdGggdGhlIGBzdGF0dXM6ICdzdWNjZXNzJ2AgZmlsdGVyIGJlbG93LCBjaGVjayB0aGVcbiogbGFzdCBpdGVtIHRoYXQgYHVzZU11dGF0aW9uU3RhdGVgIHJldHVybnMgdG8gZ2V0IHRoZSBsYXRlc3Qgc3VjY2Vzc2Z1bCBpbnZvY2F0aW9uOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlTXV0YXRpb25TdGF0ZSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gTGF0ZXN0UG9zdCgpIHtcbiogICBjb25zdCBzYXZlZFBvc3RzID0gdXNlTXV0YXRpb25TdGF0ZSh7XG4qICAgICBmaWx0ZXJzOiB7IG11dGF0aW9uS2V5OiBbJ3Bvc3RzJ10sIHN0YXR1czogJ3N1Y2Nlc3MnIH0sXG4qICAgICBzZWxlY3Q6IChtdXRhdGlvbikgPT4gbXV0YXRpb24uc3RhdGUuZGF0YSxcbiogICB9KVxuKlxuKiAgIGNvbnN0IGxhdGVzdFNhdmVkUG9zdCA9IHNhdmVkUG9zdHNbc2F2ZWRQb3N0cy5sZW5ndGggLSAxXVxuKlxuKiAgIHJldHVybiA8PntsYXRlc3RTYXZlZFBvc3QgPyAnU2F2ZWQnIDogJ05vdGhpbmcgc2F2ZWQgeWV0J308Lz5cbiogfVxuKiBgYGBcbiovXG5mdW5jdGlvbiB1c2VNdXRhdGlvblN0YXRlKG9wdGlvbnMgPSB7fSwgcXVlcnlDbGllbnQpIHtcblx0Y29uc3QgbXV0YXRpb25DYWNoZSA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KS5nZXRNdXRhdGlvbkNhY2hlKCk7XG5cdGNvbnN0IG9wdGlvbnNSZWYgPSBSZWFjdC51c2VSZWYob3B0aW9ucyk7XG5cdGNvbnN0IHJlc3VsdCA9IFJlYWN0LnVzZVJlZihudWxsKTtcblx0aWYgKHJlc3VsdC5jdXJyZW50ID09PSBudWxsKSByZXN1bHQuY3VycmVudCA9IGdldFJlc3VsdChtdXRhdGlvbkNhY2hlLCBvcHRpb25zKTtcblx0UmVhY3QudXNlRWZmZWN0KCgpID0+IHtcblx0XHRvcHRpb25zUmVmLmN1cnJlbnQgPSBvcHRpb25zO1xuXHR9KTtcblx0cmV0dXJuIFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlKFJlYWN0LnVzZUNhbGxiYWNrKChvblN0b3JlQ2hhbmdlKSA9PiBtdXRhdGlvbkNhY2hlLnN1YnNjcmliZSgoKSA9PiB7XG5cdFx0Y29uc3QgbmV4dFJlc3VsdCA9IHJlcGxhY2VFcXVhbERlZXAocmVzdWx0LmN1cnJlbnQsIGdldFJlc3VsdChtdXRhdGlvbkNhY2hlLCBvcHRpb25zUmVmLmN1cnJlbnQpKTtcblx0XHRpZiAocmVzdWx0LmN1cnJlbnQgIT09IG5leHRSZXN1bHQpIHtcblx0XHRcdHJlc3VsdC5jdXJyZW50ID0gbmV4dFJlc3VsdDtcblx0XHRcdG5vdGlmeU1hbmFnZXIuc2NoZWR1bGUob25TdG9yZUNoYW5nZSk7XG5cdFx0fVxuXHR9KSwgW211dGF0aW9uQ2FjaGVdKSwgKCkgPT4gcmVzdWx0LmN1cnJlbnQsICgpID0+IHJlc3VsdC5jdXJyZW50KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlSXNNdXRhdGluZywgdXNlTXV0YXRpb25TdGF0ZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VNdXRhdGlvblN0YXRlLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IE11dGF0aW9uT2JzZXJ2ZXIsIG5vb3AsIG5vdGlmeU1hbmFnZXIsIHNob3VsZFRocm93RXJyb3IgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlTXV0YXRpb24udHNcbi8qKlxuKiBVbmxpa2UgcXVlcmllcywgbXV0YXRpb25zIGFyZSB0eXBpY2FsbHkgdXNlZCB0byBjcmVhdGUvdXBkYXRlL2RlbGV0ZSBkYXRhIG9yIHBlcmZvcm0gc2VydmVyIHNpZGUtZWZmZWN0cy5cbiogYHVzZU11dGF0aW9uYCBpcyB0aGUgaG9vayBmb3IgdGhhdC5cbipcbiogQHNlZSB7QGxpbmsgbXV0YXRpb25PcHRpb25zfSB0byBzaGFyZSB0aGVzZSBvcHRpb25zIGFjcm9zcyBtdWx0aXBsZSBgdXNlTXV0YXRpb25gIGNhbGwgc2l0ZXMsIG9yIHRvIGxvb2tcbiogdGhlIG11dGF0aW9uIHVwIGVsc2V3aGVyZSB2aWEgaXRzIGBtdXRhdGlvbktleWAgKGUuZy4gd2l0aCBgdXNlTXV0YXRpb25TdGF0ZWApLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSB7QGxpbmsgVXNlTXV0YXRpb25PcHRpb25zfSB0byB1c2Ug4oCUIGV2ZXJ5dGhpbmcgeW91IGNhbiBwYXNzIHRvIGB1c2VNdXRhdGlvbmAuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgYG11dGF0ZWAvYG11dGF0ZUFzeW5jYCBhbHNvIGFjY2VwdCBwZXItY2FsbCBgb25TdWNjZXNzYC9gb25FcnJvcmAvYG9uU2V0dGxlZGAgY2FsbGJhY2tzIGFzIGEgc2Vjb25kXG4qIGFyZ3VtZW50LCB1c2VmdWwgZm9yIHRyaWdnZXJpbmcgY2FsbC1zaXRlIHNpZGUgZWZmZWN0cyAoZS5nLiBuYXZpZ2F0aW9uKSB3aXRob3V0IGNvdXBsaW5nIHRoZW0gdG8gdGhlIHNoYXJlZFxuKiBtdXRhdGlvbiBkZWZpbml0aW9uLiBIb29rLWxldmVsIGNhbGxiYWNrcyAocGFzc2VkIHRvIGBvcHRpb25zYCkgZmlyZSBmb3IgZXZlcnkgbXV0YXRpb247IHBlci1jYWxsIGNhbGxiYWNrc1xuKiBmaXJlIG9ubHkgZm9yIHRoZSBsYXRlc3QgY2FsbCB5b3UndmUgbWFkZSwgYW5kIG9ubHkgd2hpbGUgdGhlIGNvbXBvbmVudCBpcyBzdGlsbCBtb3VudGVkIOKAlCB1bm1vdW50aW5nIGJlZm9yZVxuKiB0aGUgbXV0YXRpb24gc2V0dGxlcyByZW1vdmVzIHRoZSBzdWJzY3JpcHRpb24gYW5kIHByZXZlbnRzIHRoZW0gZnJvbSBmaXJpbmcuXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIEFkZFRvZG8oKSB7XG4qICAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpXG4qXG4qICAgY29uc3QgYWRkTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XG4qICAgICBtdXRhdGlvbkZuOiBhZGRUb2RvLFxuKiAgICAgb25TdWNjZXNzOiAoKSA9PiBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ3RvZG9zJ10gfSksXG4qICAgfSlcbipcbiogICByZXR1cm4gKFxuKiAgICAgPGJ1dHRvblxuKiAgICAgICBvbkNsaWNrPXsoKSA9PlxuKiAgICAgICAgIGFkZE11dGF0aW9uLm11dGF0ZSgnSXRlbScsIHtcbiogICAgICAgICAgIG9uRXJyb3I6IChlcnJvcikgPT4gY29uc29sZS5lcnJvcignRmFpbGVkIHRvIGFkZCBpdGVtOicsIGVycm9yKSxcbiogICAgICAgICB9KVxuKiAgICAgICB9XG4qICAgICA+XG4qICAgICAgIEFkZFxuKiAgICAgPC9idXR0b24+XG4qICAgKVxuKiB9XG4qIGBgYFxuKlxuKiBAZXhhbXBsZVxuKiBSZW5kZXJpbmcgdGhlIG11dGF0aW9uJ3Mgb3duIHN0YXRlLCByYXRoZXIgdGhhbiBqdXN0IGZpcmluZyBpdCBvZmY6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIEFkZFRvZG8oKSB7XG4qICAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpXG4qXG4qICAgY29uc3QgYWRkTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XG4qICAgICBtdXRhdGlvbkZuOiBhZGRUb2RvLFxuKiAgICAgb25TdWNjZXNzOiAoKSA9PiBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ3RvZG9zJ10gfSksXG4qICAgfSlcbipcbiogICByZXR1cm4gKFxuKiAgICAgPGRpdj5cbiogICAgICAge2FkZE11dGF0aW9uLmlzUGVuZGluZyA/IChcbiogICAgICAgICAnQWRkaW5nIHRvZG8uLi4nXG4qICAgICAgICkgOiAoXG4qICAgICAgICAgPD5cbiogICAgICAgICAgIHthZGRNdXRhdGlvbi5pc0Vycm9yID8gKFxuKiAgICAgICAgICAgICA8ZGl2PkFuIGVycm9yIG9jY3VycmVkOiB7YWRkTXV0YXRpb24uZXJyb3IubWVzc2FnZX08L2Rpdj5cbiogICAgICAgICAgICkgOiBudWxsfVxuKiAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBhZGRNdXRhdGlvbi5tdXRhdGUoJ0l0ZW0nKX0+QWRkPC9idXR0b24+XG4qICAgICAgICAgPC8+XG4qICAgICAgICl9XG4qICAgICA8L2Rpdj5cbiogICApXG4qIH1cbiogYGBgXG4qXG4qIEBleGFtcGxlXG4qIE9wdGltaXN0aWMgdXBkYXRlIHZpYSBgb25NdXRhdGVgLCByb2xsaW5nIGJhY2sgb24gYG9uRXJyb3JgOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBBZGRUb2RvKCkge1xuKiAgIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKVxuKlxuKiAgIGNvbnN0IGFkZE11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xuKiAgICAgbXV0YXRpb25GbjogYWRkVG9kbyxcbiogICAgIG9uTXV0YXRlOiBhc3luYyAobmV3VG9kbykgPT4ge1xuKiAgICAgICBhd2FpdCBxdWVyeUNsaWVudC5jYW5jZWxRdWVyaWVzKHsgcXVlcnlLZXk6IFsndG9kb3MnXSB9KVxuKiAgICAgICBjb25zdCBwcmV2aW91c1RvZG9zID0gcXVlcnlDbGllbnQuZ2V0UXVlcnlEYXRhPEFycmF5PHN0cmluZz4+KFsndG9kb3MnXSlcbipcbiogICAgICAgcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhPEFycmF5PHN0cmluZz4+KFsndG9kb3MnXSwgKG9sZCkgPT4gW1xuKiAgICAgICAgIC4uLihvbGQgPz8gW10pLFxuKiAgICAgICAgIG5ld1RvZG8sXG4qICAgICAgIF0pXG4qXG4qICAgICAgIC8vIFBhc3NlZCB0byBgb25FcnJvcmAgYXMgYG9uTXV0YXRlUmVzdWx0YCBpZiB0aGUgbXV0YXRpb24gZmFpbHMuXG4qICAgICAgIHJldHVybiB7IHByZXZpb3VzVG9kb3MgfVxuKiAgICAgfSxcbiogICAgIG9uRXJyb3I6IChfZXJyLCBfbmV3VG9kbywgb25NdXRhdGVSZXN1bHQpID0+IHtcbiogICAgICAgcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhKFsndG9kb3MnXSwgb25NdXRhdGVSZXN1bHQ/LnByZXZpb3VzVG9kb3MpXG4qICAgICB9LFxuKiAgICAgb25TZXR0bGVkOiAoKSA9PiB7XG4qICAgICAgIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsndG9kb3MnXSB9KVxuKiAgICAgfSxcbiogICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGFkZE11dGF0aW9uLm11dGF0ZSgnSXRlbScpfT5BZGQ8L2J1dHRvbj5cbiogICApXG4qIH1cbiogYGBgXG4qXG4qIEBleGFtcGxlXG4qIENhbGxiYWNrcyBwYXNzZWQgcGVyIGNhbGwgdG8gYG11dGF0ZWAgb25seSBmaXJlIGZvciB0aGUgbGFzdCBjYWxsIOKAlCBgbXV0YXRlQXN5bmNgIGdpdmVzIHlvdSBhXG4qIHByb21pc2UgcGVyIGNhbGwgaW5zdGVhZCwgc28geW91IGNhbiB3YWl0IGZvciBhbGwgb2YgdGhlbSB3aGVuIHRoZXkgc3VjY2VlZDpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gQWRkVG9kb3MoKSB7XG4qICAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpXG4qXG4qICAgY29uc3QgYWRkTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XG4qICAgICBtdXRhdGlvbkZuOiBhZGRUb2RvLFxuKiAgICAgb25TdWNjZXNzOiAoKSA9PiBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ3RvZG9zJ10gfSksXG4qICAgfSlcbipcbiogICBhc3luYyBmdW5jdGlvbiBoYW5kbGVBZGRBbGwodG9kb3M6IEFycmF5PHN0cmluZz4pIHtcbiogICAgIHRyeSB7XG4qICAgICAgIGF3YWl0IFByb21pc2UuYWxsKHRvZG9zLm1hcCgodG9kbykgPT4gYWRkTXV0YXRpb24ubXV0YXRlQXN5bmModG9kbykpKVxuKiAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiogICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIGFkZCB0b2RvczonLCBlcnJvcilcbiogICAgIH1cbiogICB9XG4qXG4qICAgcmV0dXJuIChcbiogICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlQWRkQWxsKFsnVG9kbyAxJywgJ1RvZG8gMicsICdUb2RvIDMnXSl9PlxuKiAgICAgICBBZGQgYWxsXG4qICAgICA8L2J1dHRvbj5cbiogICApXG4qIH1cbiogYGBgXG4qXG4qIEBleGFtcGxlXG4qIElmIHNvbWUgb2YgdGhlIG11dGF0aW9ucyBhYm92ZSBjYW4gZmFpbCBpbmRlcGVuZGVudGx5IG9mIHRoZSBvdGhlcnMsIGFuZCB5b3Ugd2FudCB0byBrbm93IHdoaWNoIG9uZXNcbiogZGlkIOKAlCByYXRoZXIgdGhhbiBsb3NpbmcgdGhhdCBpbmZvcm1hdGlvbiB0aGUgbW9tZW50IHRoZSBmaXJzdCBvbmUgcmVqZWN0cyDigJQgc3dhcCBgUHJvbWlzZS5hbGxgIGZvclxuKiBgUHJvbWlzZS5hbGxTZXR0bGVkYDpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gQWRkVG9kb3MoKSB7XG4qICAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpXG4qXG4qICAgY29uc3QgYWRkTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XG4qICAgICBtdXRhdGlvbkZuOiBhZGRUb2RvLFxuKiAgICAgb25TdWNjZXNzOiAoKSA9PiBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ3RvZG9zJ10gfSksXG4qICAgfSlcbipcbiogICBhc3luYyBmdW5jdGlvbiBoYW5kbGVBZGRBbGwodG9kb3M6IEFycmF5PHN0cmluZz4pIHtcbiogICAgIGNvbnN0IGFkZFJlc3VsdHMgPSBhd2FpdCBQcm9taXNlLmFsbFNldHRsZWQoXG4qICAgICAgIHRvZG9zLm1hcCgodG9kbykgPT4gYWRkTXV0YXRpb24ubXV0YXRlQXN5bmModG9kbykpLFxuKiAgICAgKVxuKlxuKiAgICAgYWRkUmVzdWx0cy5mb3JFYWNoKChhZGRSZXN1bHQsIGluZGV4KSA9PiB7XG4qICAgICAgIGlmIChhZGRSZXN1bHQuc3RhdHVzID09PSAncmVqZWN0ZWQnKSB7XG4qICAgICAgICAgY29uc29sZS5lcnJvcihgRmFpbGVkIHRvIGFkZCBcIiR7dG9kb3NbaW5kZXhdfVwiOmAsIGFkZFJlc3VsdC5yZWFzb24pXG4qICAgICAgIH1cbiogICAgIH0pXG4qICAgfVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFkZEFsbChbJ1RvZG8gMScsICdUb2RvIDInLCAnVG9kbyAzJ10pfT5cbiogICAgICAgQWRkIGFsbFxuKiAgICAgPC9idXR0b24+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZU11dGF0aW9uKG9wdGlvbnMsIHF1ZXJ5Q2xpZW50KSB7XG5cdGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcblx0Y29uc3QgW29ic2VydmVyXSA9IFJlYWN0LnVzZVN0YXRlKCgpID0+IG5ldyBNdXRhdGlvbk9ic2VydmVyKGNsaWVudCwgb3B0aW9ucykpO1xuXHRSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdG9ic2VydmVyLnNldE9wdGlvbnMob3B0aW9ucyk7XG5cdH0sIFtvYnNlcnZlciwgb3B0aW9uc10pO1xuXHRjb25zdCByZXN1bHQgPSBSZWFjdC51c2VTeW5jRXh0ZXJuYWxTdG9yZShSZWFjdC51c2VDYWxsYmFjaygob25TdG9yZUNoYW5nZSkgPT4gb2JzZXJ2ZXIuc3Vic2NyaWJlKG5vdGlmeU1hbmFnZXIuYmF0Y2hDYWxscyhvblN0b3JlQ2hhbmdlKSksIFtvYnNlcnZlcl0pLCAoKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KCksICgpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKSk7XG5cdGNvbnN0IG11dGF0ZSA9IFJlYWN0LnVzZUNhbGxiYWNrKCguLi5hcmdzKSA9PiB7XG5cdFx0b2JzZXJ2ZXIubXV0YXRlKGFyZ3NbMF0sIGFyZ3NbMV0pLmNhdGNoKG5vb3ApO1xuXHR9LCBbb2JzZXJ2ZXJdKTtcblx0aWYgKHJlc3VsdC5lcnJvciAmJiBzaG91bGRUaHJvd0Vycm9yKG9ic2VydmVyLm9wdGlvbnMudGhyb3dPbkVycm9yLCBbcmVzdWx0LmVycm9yXSkpIHRocm93IHJlc3VsdC5lcnJvcjtcblx0cmV0dXJuIHtcblx0XHQuLi5yZXN1bHQsXG5cdFx0bXV0YXRlLFxuXHRcdG11dGF0ZUFzeW5jOiByZXN1bHQubXV0YXRlXG5cdH07XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZU11dGF0aW9uIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZU11dGF0aW9uLmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvbXV0YXRpb25PcHRpb25zLnRzXG5mdW5jdGlvbiBtdXRhdGlvbk9wdGlvbnMob3B0aW9ucykge1xuXHRyZXR1cm4gb3B0aW9ucztcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgbXV0YXRpb25PcHRpb25zIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW11dGF0aW9uT3B0aW9ucy5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZUJhc2VRdWVyeSB9IGZyb20gXCIuL3VzZUJhc2VRdWVyeS5qc1wiO1xuaW1wb3J0IHsgSW5maW5pdGVRdWVyeU9ic2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyNyZWdpb24gc3JjL3VzZUluZmluaXRlUXVlcnkudHNcbmZ1bmN0aW9uIHVzZUluZmluaXRlUXVlcnkob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcblx0cmV0dXJuIHVzZUJhc2VRdWVyeShvcHRpb25zLCBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIsIHF1ZXJ5Q2xpZW50KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlSW5maW5pdGVRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VJbmZpbml0ZVF1ZXJ5LmpzLm1hcCIsImltcG9ydCB7IFF1ZXJ5Q2xpZW50Q29udGV4dCwgUXVlcnlDbGllbnRQcm92aWRlciwgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyBIeWRyYXRpb25Cb3VuZGFyeSB9IGZyb20gXCIuL0h5ZHJhdGlvbkJvdW5kYXJ5LmpzXCI7XG5pbXBvcnQgeyBJc1Jlc3RvcmluZ1Byb3ZpZGVyLCB1c2VJc1Jlc3RvcmluZyB9IGZyb20gXCIuL0lzUmVzdG9yaW5nUHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LCB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSB9IGZyb20gXCIuL1F1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LmpzXCI7XG5pbXBvcnQgeyB1c2VRdWVyaWVzIH0gZnJvbSBcIi4vdXNlUXVlcmllcy5qc1wiO1xuaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiLi91c2VRdWVyeS5qc1wiO1xuaW1wb3J0IHsgdXNlU3VzcGVuc2VRdWVyeSB9IGZyb20gXCIuL3VzZVN1c3BlbnNlUXVlcnkuanNcIjtcbmltcG9ydCB7IHVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeSB9IGZyb20gXCIuL3VzZVN1c3BlbnNlSW5maW5pdGVRdWVyeS5qc1wiO1xuaW1wb3J0IHsgdXNlU3VzcGVuc2VRdWVyaWVzIH0gZnJvbSBcIi4vdXNlU3VzcGVuc2VRdWVyaWVzLmpzXCI7XG5pbXBvcnQgeyB1c2VQcmVmZXRjaFF1ZXJ5IH0gZnJvbSBcIi4vdXNlUHJlZmV0Y2hRdWVyeS5qc1wiO1xuaW1wb3J0IHsgdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyBxdWVyeU9wdGlvbnMgfSBmcm9tIFwiLi9xdWVyeU9wdGlvbnMuanNcIjtcbmltcG9ydCB7IGluZmluaXRlUXVlcnlPcHRpb25zIH0gZnJvbSBcIi4vaW5maW5pdGVRdWVyeU9wdGlvbnMuanNcIjtcbmltcG9ydCB7IHVzZUlzRmV0Y2hpbmcgfSBmcm9tIFwiLi91c2VJc0ZldGNoaW5nLmpzXCI7XG5pbXBvcnQgeyB1c2VJc011dGF0aW5nLCB1c2VNdXRhdGlvblN0YXRlIH0gZnJvbSBcIi4vdXNlTXV0YXRpb25TdGF0ZS5qc1wiO1xuaW1wb3J0IHsgdXNlTXV0YXRpb24gfSBmcm9tIFwiLi91c2VNdXRhdGlvbi5qc1wiO1xuaW1wb3J0IHsgbXV0YXRpb25PcHRpb25zIH0gZnJvbSBcIi4vbXV0YXRpb25PcHRpb25zLmpzXCI7XG5pbXBvcnQgeyB1c2VJbmZpbml0ZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlSW5maW5pdGVRdWVyeS5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyNyZWdpb24gc3JjL2luZGV4LnRzXG4vKiBpc3RhbmJ1bCBpZ25vcmUgZmlsZSAqL1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBIeWRyYXRpb25Cb3VuZGFyeSwgSXNSZXN0b3JpbmdQcm92aWRlciwgUXVlcnlDbGllbnRDb250ZXh0LCBRdWVyeUNsaWVudFByb3ZpZGVyLCBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSwgaW5maW5pdGVRdWVyeU9wdGlvbnMsIG11dGF0aW9uT3B0aW9ucywgcXVlcnlPcHRpb25zLCB1c2VJbmZpbml0ZVF1ZXJ5LCB1c2VJc0ZldGNoaW5nLCB1c2VJc011dGF0aW5nLCB1c2VJc1Jlc3RvcmluZywgdXNlTXV0YXRpb24sIHVzZU11dGF0aW9uU3RhdGUsIHVzZVByZWZldGNoSW5maW5pdGVRdWVyeSwgdXNlUHJlZmV0Y2hRdWVyeSwgdXNlUXVlcmllcywgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50LCB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSwgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5LCB1c2VTdXNwZW5zZVF1ZXJpZXMsIHVzZVN1c3BlbnNlUXVlcnkgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFPQSxJQUFNLHFCQUFBLGFBQTJCLGNBQWMsS0FBSyxDQUFDOzs7Ozs7Ozs7QUFTckQsSUFBTSxrQkFBa0IsZ0JBQWdCO0NBQ3ZDLE1BQU0sU0FBQSxhQUFlLFdBQVcsa0JBQWtCO0NBQ2xELElBQUksYUFBYSxPQUFPO0NBQ3hCLElBQUksQ0FBQyxRQUFRLE1BQU0sSUFBSSxNQUFNLHdEQUF3RDtDQUNyRixPQUFPO0FBQ1I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBb0JBLElBQU0sdUJBQXVCLEVBQUUsUUFBUSxlQUFlO0NBQ3JELGFBQU0sZ0JBQWdCO0VBQ3JCLE9BQU8sTUFBTTtFQUNiLGFBQWE7R0FDWixPQUFPLFFBQVE7RUFDaEI7Q0FDRCxHQUFHLENBQUMsTUFBTSxDQUFDO0NBQ1gsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksbUJBQW1CLFVBQVU7RUFDdkQsT0FBTztFQUNQO0NBQ0QsQ0FBQztBQUNGOzs7QUNuREEsSUFBTSx5QkFBeUI7Q0FDOUIsYUFBYSxVQUFVLFVBQVUsV0FBVyxVQUFVLEtBQUs7Q0FDM0QsZUFBZSxjQUFjLGFBQWEsU0FBUztDQUNuRCxjQUFjLFVBQVUsVUFBVSxZQUFZLFVBQVUsS0FBSztDQUM3RCxnQkFBZ0IsZUFBZSxjQUFjLFVBQVU7QUFDeEQ7Ozs7Ozs7Ozs7OztBQVlBLElBQUksaUJBQWlCLE1BQU07Q0FDMUIsWUFBWTtDQUNaLGtCQUFrQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EwQmxCLG1CQUFtQixVQUFVO0VBRTNCLElBQUksS0FBSyxtQkFBbUIsYUFBYSxLQUFLLFdBQVcsUUFBUSxNQUFNLDhHQUE4RztHQUNwTCxVQUFVLEtBQUs7R0FDZjtFQUNELENBQUM7RUFFRixLQUFLLFlBQVk7RUFDMEIsS0FBSyxrQkFBa0I7Q0FDbkU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXFCQSxXQUFXLFVBQVUsT0FBTztFQUNnQixLQUFLLGtCQUFrQjtFQUNsRSxPQUFPLEtBQUssVUFBVSxXQUFXLFVBQVUsS0FBSztDQUNqRDs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0JBLGFBQWEsV0FBVztFQUN2QixLQUFLLFVBQVUsYUFBYSxTQUFTO0NBQ3RDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsWUFBWSxVQUFVLE9BQU87RUFDZSxLQUFLLGtCQUFrQjtFQUNsRSxPQUFPLEtBQUssVUFBVSxZQUFZLFVBQVUsS0FBSztDQUNsRDs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0JBLGNBQWMsWUFBWTtFQUN6QixLQUFLLFVBQVUsY0FBYyxVQUFVO0NBQ3hDO0FBQ0Q7Ozs7QUFJQSxJQUFNLGlCQUFpQixJQUFJLGVBQWU7Ozs7Ozs7O0FBUTFDLFNBQVMscUJBQXFCLFVBQVU7Q0FDdkMsV0FBVyxVQUFVLENBQUM7QUFDdkI7Ozs7OztBQ3RKQSxJQUFNLFdBQVcsT0FBTyxXQUFXLGVBQWUsVUFBVTtBQUM1RCxTQUFTLE9BQU8sQ0FBQztBQUNqQixTQUFTLGlCQUFpQixTQUFTLE9BQU87Q0FDekMsT0FBTyxPQUFPLFlBQVksYUFBYSxRQUFRLEtBQUssSUFBSTtBQUN6RDtBQUNBLFNBQVMsZUFBZSxPQUFPO0NBQzlCLE9BQU8sT0FBTyxVQUFVLFlBQVksU0FBUyxLQUFLLFVBQVU7QUFDN0Q7QUFDQSxTQUFTLGVBQWUsV0FBVyxXQUFXO0NBQzdDLE9BQU8sS0FBSyxJQUFJLGFBQWEsYUFBYSxLQUFLLEtBQUssSUFBSSxHQUFHLENBQUM7QUFDN0Q7QUFDQSxTQUFTLGtCQUFrQixPQUFPLE9BQU87Q0FDeEMsT0FBTyxPQUFPLFVBQVUsYUFBYSxNQUFNLEtBQUssSUFBSTtBQUNyRDs7Ozs7Ozs7Ozs7Ozs7QUFjQSxTQUFTLFdBQVcsU0FBUyxPQUFPO0NBQ25DLE1BQU0sRUFBRSxPQUFPLE9BQU8sT0FBTyxhQUFhLFdBQVcsVUFBVSxVQUFVO0NBQ3pFLElBQUksVUFBVTtFQUNiLElBQUksT0FDQztPQUFBLE1BQU0sY0FBYyxzQkFBc0IsVUFBVSxNQUFNLE9BQU8sR0FBRyxPQUFPO0VBQUEsT0FDekUsSUFBSSxDQUFDLGdCQUFnQixNQUFNLFVBQVUsUUFBUSxHQUFHLE9BQU87Q0FDL0Q7Q0FDQSxJQUFJLFNBQVMsT0FBTztFQUNuQixNQUFNLFdBQVcsTUFBTSxTQUFTO0VBQ2hDLElBQUksU0FBUyxZQUFZLENBQUMsVUFBVSxPQUFPO0VBQzNDLElBQUksU0FBUyxjQUFjLFVBQVUsT0FBTztDQUM3QztDQUNBLElBQUksT0FBTyxVQUFVLGFBQWEsTUFBTSxRQUFRLE1BQU0sT0FBTyxPQUFPO0NBQ3BFLElBQUksZUFBZSxnQkFBZ0IsTUFBTSxNQUFNLGFBQWEsT0FBTztDQUNuRSxJQUFJLGFBQWEsQ0FBQyxVQUFVLEtBQUssR0FBRyxPQUFPO0NBQzNDLE9BQU87QUFDUjs7Ozs7Ozs7Ozs7Ozs7O0FBZUEsU0FBUyxjQUFjLFNBQVMsVUFBVTtDQUN6QyxNQUFNLEVBQUUsT0FBTyxRQUFRLFdBQVcsZ0JBQWdCO0NBQ2xELElBQUksYUFBYTtFQUNoQixJQUFJLENBQUMsU0FBUyxRQUFRLGFBQWEsT0FBTztFQUMxQyxJQUFJLE9BQ0M7T0FBQSxRQUFRLFNBQVMsUUFBUSxXQUFXLE1BQU0sUUFBUSxXQUFXLEdBQUcsT0FBTztFQUFBLE9BQ3JFLElBQUksQ0FBQyxnQkFBZ0IsU0FBUyxRQUFRLGFBQWEsV0FBVyxHQUFHLE9BQU87Q0FDaEY7Q0FDQSxJQUFJLFVBQVUsU0FBUyxNQUFNLFdBQVcsUUFBUSxPQUFPO0NBQ3ZELElBQUksYUFBYSxDQUFDLFVBQVUsUUFBUSxHQUFHLE9BQU87Q0FDOUMsT0FBTztBQUNSO0FBQ0EsU0FBUyxzQkFBc0IsVUFBVSxTQUFTO0NBQ2pELFFBQVEsU0FBUyxrQkFBa0IsUUFBQSxDQUFTLFFBQVE7QUFDckQ7Ozs7Ozs7Ozs7O0FBV0EsU0FBUyxRQUFRLFVBQVU7Q0FDMUIsT0FBTyxLQUFLLFVBQVUsV0FBVyxHQUFHLFFBQVEsY0FBYyxHQUFHLElBQUksT0FBTyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsUUFBUSxRQUFRO0VBQ2hILE9BQU8sT0FBTyxJQUFJO0VBQ2xCLE9BQU87Q0FDUixHQUFHLENBQUMsQ0FBQyxJQUFJLEdBQUc7QUFDYjtBQUNBLFNBQVMsZ0JBQWdCLEdBQUcsR0FBRztDQUM5QixJQUFJLE1BQU0sR0FBRyxPQUFPO0NBQ3BCLElBQUksT0FBTyxNQUFNLE9BQU8sR0FBRyxPQUFPO0NBQ2xDLElBQUksS0FBSyxLQUFLLE9BQU8sTUFBTSxZQUFZLE9BQU8sTUFBTSxVQUFVO0VBQzdELElBQUksTUFBTSxRQUFRLENBQUMsS0FBSyxNQUFNLFFBQVEsQ0FBQyxHQUFHO0dBQ3pDLElBQUksRUFBRSxTQUFTLEVBQUUsUUFBUSxPQUFPO0dBQ2hDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLEVBQUUsR0FBRyxPQUFPO0dBQzVFLE9BQU87RUFDUjtFQUNBLE1BQU0sUUFBUSxPQUFPLEtBQUssQ0FBQztFQUMzQixLQUFLLE1BQU0sT0FBTyxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxNQUFNLEVBQUUsSUFBSSxHQUFHLE9BQU87RUFDdEUsT0FBTztDQUNSO0NBQ0EsT0FBTztBQUNSO0FBQ0EsSUFBTSxTQUFTLE9BQU8sVUFBVTtBQUNoQyxTQUFTLGlCQUFpQixHQUFHLEdBQUcsUUFBUSxHQUFHO0NBQzFDLElBQUksTUFBTSxHQUFHLE9BQU87Q0FDcEIsSUFBSSxRQUFRLEtBQUssT0FBTztDQUN4QixNQUFNLFFBQVEsYUFBYSxDQUFDLEtBQUssYUFBYSxDQUFDO0NBQy9DLElBQUksQ0FBQyxTQUFTLEVBQUUsY0FBYyxDQUFDLEtBQUssY0FBYyxDQUFDLElBQUksT0FBTztDQUM5RCxNQUFNLFNBQVMsUUFBUSxJQUFJLE9BQU8sS0FBSyxDQUFDLEVBQUEsQ0FBRztDQUMzQyxNQUFNLFNBQVMsUUFBUSxJQUFJLE9BQU8sS0FBSyxDQUFDO0NBQ3hDLE1BQU0sUUFBUSxPQUFPO0NBQ3JCLE1BQU0sT0FBTyxRQUFRLElBQUksTUFBTSxLQUFLLElBQUksQ0FBQztDQUN6QyxJQUFJLGFBQWE7Q0FDakIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sS0FBSztFQUMvQixNQUFNLE1BQU0sUUFBUSxJQUFJLE9BQU87RUFDL0IsTUFBTSxRQUFRLEVBQUU7RUFDaEIsTUFBTSxRQUFRLEVBQUU7RUFDaEIsSUFBSSxVQUFVLE9BQU87R0FDcEIsS0FBSyxPQUFPO0dBQ1osSUFBSSxRQUFRLElBQUksUUFBUSxPQUFPLEtBQUssR0FBRyxHQUFHLEdBQUc7R0FDN0M7RUFDRDtFQUNBLElBQUksVUFBVSxRQUFRLFVBQVUsUUFBUSxPQUFPLFVBQVUsWUFBWSxPQUFPLFVBQVUsVUFBVTtHQUMvRixLQUFLLE9BQU87R0FDWjtFQUNEO0VBQ0EsTUFBTSxJQUFJLGlCQUFpQixPQUFPLE9BQU8sUUFBUSxDQUFDO0VBQ2xELEtBQUssT0FBTztFQUNaLElBQUksTUFBTSxPQUFPO0NBQ2xCO0NBQ0EsT0FBTyxVQUFVLFNBQVMsZUFBZSxRQUFRLElBQUk7QUFDdEQ7Ozs7QUFJQSxTQUFTLG9CQUFvQixHQUFHLEdBQUc7Q0FDbEMsSUFBSSxDQUFDLEtBQUssT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLFdBQVcsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsT0FBTztDQUNsRSxLQUFLLE1BQU0sT0FBTyxHQUFHLElBQUksRUFBRSxTQUFTLEVBQUUsTUFBTSxPQUFPO0NBQ25ELE9BQU87QUFDUjtBQUNBLFNBQVMsYUFBYSxPQUFPO0NBQzVCLE9BQU8sTUFBTSxRQUFRLEtBQUssS0FBSyxNQUFNLFdBQVcsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDO0FBQ3BFO0FBQ0EsU0FBUyxjQUFjLEdBQUc7Q0FDekIsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsT0FBTztDQUNuQyxNQUFNLGtCQUFrQixPQUFPLGVBQWUsQ0FBQztDQUMvQyxNQUFNLE9BQU8saUJBQWlCO0NBQzlCLElBQUksU0FBUyxLQUFLLEdBQUcsT0FBTztDQUM1QixJQUFJLE9BQU8sU0FBUyxZQUFZLE9BQU87Q0FDdkMsTUFBTSxPQUFPLEtBQUs7Q0FDbEIsSUFBSSxDQUFDLG1CQUFtQixJQUFJLEdBQUcsT0FBTztDQUN0QyxJQUFJLENBQUMsS0FBSyxlQUFlLGVBQWUsR0FBRyxPQUFPO0NBQ2xELElBQUksb0JBQW9CLE9BQU8sV0FBVyxPQUFPO0NBQ2pELE9BQU87QUFDUjtBQUNBLFNBQVMsbUJBQW1CLEdBQUc7Q0FDOUIsT0FBTyxPQUFPLFVBQVUsU0FBUyxLQUFLLENBQUMsTUFBTTtBQUM5QztBQUNBLFNBQVMsTUFBTSxTQUFTO0NBQ3ZCLE9BQU8sSUFBSSxTQUFTLFlBQVk7RUFDL0IsZUFBZSxXQUFXLFNBQVMsT0FBTztDQUMzQyxDQUFDO0FBQ0Y7QUFDQSxTQUFTLFlBQVksVUFBVSxNQUFNLFNBQVM7Q0FDN0MsSUFBSSxPQUFPLFFBQVEsc0JBQXNCLFlBQVksT0FBTyxRQUFRLGtCQUFrQixVQUFVLElBQUk7TUFDL0YsSUFBSSxRQUFRLHNCQUFzQixPQUNLLElBQUk7RUFDOUMsT0FBTyxpQkFBaUIsVUFBVSxJQUFJO0NBQ3ZDLFNBQVMsT0FBTztFQUNmLFFBQVEsTUFBTSwwSkFBMEosUUFBUSxVQUFVLEtBQUssT0FBTztFQUN0TSxNQUFNO0NBQ1A7Q0FHRCxPQUFPO0FBQ1I7Ozs7Ozs7Ozs7Ozs7OztBQWVBLFNBQVMsaUJBQWlCLGNBQWM7Q0FDdkMsT0FBTztBQUNSO0FBQ0EsU0FBUyxTQUFTLE9BQU8sTUFBTSxNQUFNLEdBQUc7Q0FDdkMsTUFBTSxXQUFXLENBQUMsR0FBRyxPQUFPLElBQUk7Q0FDaEMsT0FBTyxPQUFPLFNBQVMsU0FBUyxNQUFNLFNBQVMsTUFBTSxDQUFDLElBQUk7QUFDM0Q7QUFDQSxTQUFTLFdBQVcsT0FBTyxNQUFNLE1BQU0sR0FBRztDQUN6QyxNQUFNLFdBQVcsQ0FBQyxNQUFNLEdBQUcsS0FBSztDQUNoQyxPQUFPLE9BQU8sU0FBUyxTQUFTLE1BQU0sU0FBUyxNQUFNLEdBQUcsRUFBRSxJQUFJO0FBQy9EOzs7Ozs7Ozs7Ozs7OztBQWNBLElBQU0sWUFBWSxPQUFPO0FBQ3pCLFNBQVMsY0FBYyxTQUFTLGNBQWM7Q0FFNUMsSUFBSSxRQUFRLFlBQVksV0FBVyxRQUFRLE1BQU0seUdBQXlHLFFBQVEsVUFBVSxFQUFFO0NBRS9LLElBQUksQ0FBQyxRQUFRLFdBQVcsY0FBYyxnQkFBZ0IsYUFBYSxhQUFhO0NBQ2hGLElBQUksQ0FBQyxRQUFRLFdBQVcsUUFBUSxZQUFZLFdBQVcsYUFBYSxRQUFRLHVCQUF1QixJQUFJLE1BQU0scUJBQXFCLFFBQVEsVUFBVSxFQUFFLENBQUM7Q0FDdkosT0FBTyxRQUFRO0FBQ2hCOzs7Ozs7Ozs7Ozs7Ozs7O0FBZ0JBLFNBQVMsaUJBQWlCLGNBQWMsUUFBUTtDQUMvQyxJQUFJLE9BQU8saUJBQWlCLFlBQVksT0FBTyxhQUFhLEdBQUcsTUFBTTtDQUNyRSxPQUFPLENBQUMsQ0FBQztBQUNWO0FBQ0EsU0FBUyxzQkFBc0IsUUFBUSxXQUFXLGFBQWE7Q0FDOUQsSUFBSSxXQUFXO0NBQ2YsSUFBSTtDQUNKLE9BQU8sZUFBZSxRQUFRLFVBQVU7RUFDdkMsWUFBWTtFQUNaLFdBQVc7R0FDVixXQUFXLFVBQVU7R0FDckIsSUFBSSxVQUFVLE9BQU87R0FDckIsV0FBVztHQUNYLElBQUksT0FBTyxTQUFTLFlBQVk7UUFDM0IsT0FBTyxpQkFBaUIsU0FBUyxhQUFhLEVBQUUsTUFBTSxLQUFLLENBQUM7R0FDakUsT0FBTztFQUNSO0NBQ0QsQ0FBQztDQUNELE9BQU87QUFDUjs7O0FDdFFBLElBQUksbUJBQW1CQTs7OztBQUl2QixJQUFNQyxtQkFBaUIsV0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBa0JsQyxJQUFNLHFCQUFxQjtDQUMxQixVQUFBOzs7O0NBSUEsWUFBWSxlQUFlO0VBQzFCLGFBQWE7Q0FDZDtBQUNEOzs7QUMvQkEsSUFBSSxlQUFlLE1BQU07Q0FDeEIsY0FBYztFQUNiLEtBQUssNEJBQTRCLElBQUksSUFBSTtFQUN6QyxLQUFLLFlBQVksS0FBSyxVQUFVLEtBQUssSUFBSTtDQUMxQztDQUNBLFVBQVUsVUFBVTtFQUNuQixLQUFLLFVBQVUsSUFBSSxRQUFRO0VBQzNCLEtBQUssWUFBWTtFQUNqQixhQUFhO0dBQ1osS0FBSyxVQUFVLE9BQU8sUUFBUTtHQUM5QixLQUFLLGNBQWM7RUFDcEI7Q0FDRDtDQUNBLGVBQWU7RUFDZCxPQUFPLEtBQUssVUFBVSxPQUFPO0NBQzlCO0NBQ0EsY0FBYyxDQUFDO0NBQ2YsZ0JBQWdCLENBQUM7QUFDbEI7Ozs7Ozs7O0FDWkEsSUFBSSxlQUFlLGNBQWMsYUFBYTtDQUM3QztDQUNBO0NBQ0E7Q0FDQSxjQUFjO0VBQ2IsTUFBTTtFQUNOLEtBQUssVUFBVSxZQUFZO0dBQzFCLElBQUksT0FBTyxXQUFXLGVBQWUsT0FBTyxrQkFBa0I7SUFDN0QsTUFBTSxpQkFBaUIsUUFBUTtJQUMvQixPQUFPLGlCQUFpQixvQkFBb0IsVUFBVSxLQUFLO0lBQzNELGFBQWE7S0FDWixPQUFPLG9CQUFvQixvQkFBb0IsUUFBUTtJQUN4RDtHQUNEO0VBQ0Q7Q0FDRDtDQUNBLGNBQWM7RUFDYixJQUFJLENBQUMsS0FBSyxVQUFVLEtBQUssaUJBQWlCLEtBQUssTUFBTTtDQUN0RDtDQUNBLGdCQUFnQjtFQUNmLElBQUksQ0FBQyxLQUFLLGFBQWEsR0FBRztHQUN6QixLQUFLLFdBQVc7R0FDaEIsS0FBSyxXQUFXLEtBQUs7RUFDdEI7Q0FDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EwQkEsaUJBQWlCLE9BQU87RUFDdkIsS0FBSyxTQUFTO0VBQ2QsS0FBSyxXQUFXO0VBQ2hCLEtBQUssV0FBVyxPQUFPLFlBQVk7R0FDbEMsSUFBSSxPQUFPLFlBQVksV0FBVyxLQUFLLFdBQVcsT0FBTztRQUNwRCxLQUFLLFFBQVE7RUFDbkIsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUJBLFdBQVcsU0FBUztFQUNuQixJQUFJLEtBQUssYUFBYSxTQUFTO0dBQzlCLEtBQUssV0FBVztHQUNoQixLQUFLLFFBQVE7RUFDZDtDQUNEOzs7O0NBSUEsVUFBVTtFQUNULE1BQU0sWUFBWSxLQUFLLFVBQVU7RUFDakMsS0FBSyxVQUFVLFNBQVMsYUFBYTtHQUNwQyxTQUFTLFNBQVM7RUFDbkIsQ0FBQztDQUNGOzs7O0NBSUEsWUFBWTtFQUNYLElBQUksT0FBTyxLQUFLLGFBQWEsV0FBVyxPQUFPLEtBQUs7RUFDcEQsT0FBTyxXQUFXLFVBQVUsb0JBQW9CO0NBQ2pEO0FBQ0Q7Ozs7QUFJQSxJQUFNLGVBQWUsSUFBSSxhQUFhOzs7QUMzR3RDLFNBQVMsZUFBZSxTQUFTO0NBQ2hDLElBQUk7Q0FDSixRQUFRLE1BQU0sV0FBVztFQUN4QixPQUFPO0VBQ1AsT0FBTztDQUNSLEdBQUcsSUFBSSxDQUFDLEVBQUUsUUFBUSxJQUFJO0NBQ3RCLElBQUksU0FBUyxLQUFLLEdBQUcsT0FBTyxFQUFFLEtBQUs7QUFDcEM7QUFDQSxTQUFTLGtCQUFrQixVQUFVO0NBQ3BDLE9BQU87RUFDTixhQUFhLFNBQVMsUUFBUTtFQUM5QixPQUFPLFNBQVM7RUFDaEIsR0FBRyxTQUFTLFFBQVEsU0FBUyxFQUFFLE9BQU8sU0FBUyxRQUFRLE1BQU07RUFDN0QsR0FBRyxTQUFTLFFBQVEsRUFBRSxNQUFNLFNBQVMsS0FBSztDQUMzQztBQUNEO0FBQ0EsU0FBUyxpQkFBaUIsT0FBTyxlQUFlLG9CQUFvQjtDQUNuRSxNQUFNLFVBQVUsTUFBTSxTQUFTLEtBQUssYUFBYSxDQUFDLENBQUMsT0FBTyxVQUFVO0VBQ25FLElBQUkscUJBQXFCLEtBQUssTUFBTSxPQUFPLE9BQU8sUUFBUSxPQUFPLEtBQUs7RUFDM0IsUUFBUSxNQUFNLCtEQUErRCxNQUFNLFVBQVUsS0FBSyxNQUFNLGtEQUFrRDtFQUNyTSxPQUFPLFFBQVEsdUJBQXVCLElBQUksTUFBTSxVQUFVLENBQUM7Q0FDNUQsQ0FBQztDQUNELFNBQVMsTUFBTSxJQUFJO0NBQ25CLE9BQU87QUFDUjs7Ozs7Ozs7Ozs7QUFXQSxTQUFTLGVBQWUsT0FBTyxlQUFlLG9CQUFvQjtDQUNqRSxPQUFPO0VBQ04sY0FBYyxLQUFLLElBQUk7RUFDdkIsT0FBTztHQUNOLEdBQUcsTUFBTTtHQUNULEdBQUcsTUFBTSxNQUFNLFNBQVMsS0FBSyxLQUFLLEVBQUUsTUFBTSxnQkFBZ0IsY0FBYyxNQUFNLE1BQU0sSUFBSSxJQUFJLE1BQU0sTUFBTSxLQUFLO0VBQzlHO0VBQ0EsVUFBVSxNQUFNO0VBQ2hCLFdBQVcsTUFBTTtFQUNqQixHQUFHLE1BQU0sTUFBTSxXQUFXLGFBQWEsRUFBRSxTQUFTLGlCQUFpQixPQUFPLGVBQWUsa0JBQWtCLEVBQUU7RUFDN0csR0FBRyxNQUFNLFFBQVEsRUFBRSxNQUFNLE1BQU0sS0FBSztFQUNwQyxHQUFHLE1BQU0sYUFBYSxFQUFFLFdBQVcsTUFBTSxVQUFVO0NBQ3BEO0FBQ0Q7Ozs7O0FBS0EsU0FBUywrQkFBK0IsVUFBVTtDQUNqRCxPQUFPLFNBQVMsTUFBTTtBQUN2Qjs7Ozs7QUFLQSxTQUFTLDRCQUE0QixPQUFPO0NBQzNDLE9BQU8sTUFBTSxNQUFNLFdBQVc7QUFDL0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFtQkEsU0FBUyxVQUFVLFFBQVEsVUFBVSxDQUFDLEdBQUc7Q0FDeEMsTUFBTSxpQkFBaUIsUUFBUSwyQkFBMkIsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLFdBQVcsMkJBQTJCO0NBQzNILE1BQU0sWUFBWSxPQUFPLGlCQUFpQixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxhQUFhLGVBQWUsUUFBUSxJQUFJLENBQUMsa0JBQWtCLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztDQUN4SSxNQUFNLGNBQWMsUUFBUSx3QkFBd0IsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLFdBQVcsd0JBQXdCO0NBQ2xILE1BQU0scUJBQXFCLFFBQVEsc0JBQXNCLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxXQUFXO0NBQy9GLE1BQU0sZ0JBQWdCLFFBQVEsaUJBQWlCLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxXQUFXO0NBQ3JGLE9BQU87RUFDTjtFQUNBLFNBQVMsT0FBTyxjQUFjLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLFVBQVUsWUFBWSxLQUFLLElBQUksQ0FBQyxlQUFlLE9BQU8sZUFBZSxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztDQUNqSjtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFrQkEsU0FBUyxRQUFRLFFBQVEsaUJBQWlCLFNBQVM7Q0FDbEQsTUFBTSxnQkFBZ0IsT0FBTyxpQkFBaUI7Q0FDOUMsTUFBTSxhQUFhLE9BQU8sY0FBYztDQUN4QyxNQUFNLGtCQUFrQixTQUFTLGdCQUFnQixtQkFBbUIsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLFNBQVM7Q0FDeEcsZ0JBQWdCLFdBQVcsU0FBUyxFQUFFLE9BQU8sR0FBRyxzQkFBc0I7RUFDckUsY0FBYyxNQUFNLFFBQVE7R0FDM0IsR0FBRyxPQUFPLGtCQUFrQixDQUFDLENBQUMsU0FBUztHQUN2QyxHQUFHLFNBQVMsZ0JBQWdCO0dBQzVCLEdBQUc7RUFDSixHQUFHLEtBQUs7Q0FDVCxDQUFDO0NBQ0QsZ0JBQWdCLFNBQVMsU0FBUyxFQUFFLFVBQVUsT0FBTyxXQUFXLE1BQU0sU0FBUyxjQUFjLGdCQUFnQjtFQUM1RyxNQUFNLFdBQVcsVUFBVSxlQUFlLE9BQU8sSUFBSSxLQUFLO0VBQzFELE1BQU0sVUFBVSxNQUFNLFNBQVMsS0FBSyxJQUFJLFVBQVUsT0FBTyxNQUFNO0VBQy9ELE1BQU0sT0FBTyxZQUFZLEtBQUssSUFBSSxVQUFVLGtCQUFrQixnQkFBZ0IsT0FBTyxJQUFJO0VBQ3pGLElBQUksUUFBUSxXQUFXLElBQUksU0FBUztFQUNwQyxNQUFNLHlCQUF5QixPQUFPLE1BQU0sV0FBVztFQUN2RCxNQUFNLDBCQUEwQixPQUFPLE1BQU0sZ0JBQWdCO0VBQzdELElBQUksT0FBTztHQUNWLE1BQU0sbUJBQW1CLFlBQVksZUFBZSxNQUFNLE1BQU07R0FDaEUsSUFBSSxNQUFNLGdCQUFnQixNQUFNLE1BQU0saUJBQWlCLGtCQUFrQjtJQUN4RSxNQUFNLEVBQUUsYUFBYSxVQUFVLEdBQUcsb0JBQW9CO0lBQ3RELE1BQU0sU0FBUztLQUNkLEdBQUc7S0FDSDtLQUNBLEdBQUcsTUFBTSxXQUFXLGFBQWEsU0FBUyxLQUFLLEtBQUs7TUFDbkQsUUFBUTtNQUNSLGVBQWU7TUFDZixHQUFHLENBQUMsMkJBQTJCLEVBQUUsYUFBYSxPQUFPO0tBQ3REO0lBQ0QsQ0FBQztHQUNGO0VBQ0QsT0FBTyxRQUFRLFdBQVcsTUFBTSxRQUFRO0dBQ3ZDLEdBQUcsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLFNBQVM7R0FDdkMsR0FBRyxTQUFTLGdCQUFnQjtHQUM1QjtHQUNBO0dBQ0E7R0FDQSxPQUFPO0VBQ1IsR0FBRztHQUNGLEdBQUc7R0FDSDtHQUNBLGFBQWE7R0FDYixRQUFRLE1BQU0sV0FBVyxhQUFhLFNBQVMsS0FBSyxJQUFJLFlBQVksTUFBTTtHQUMxRSxHQUFHLE1BQU0sV0FBVyxhQUFhLFNBQVMsS0FBSyxLQUFLLEVBQUUsZUFBZSxhQUFhO0VBQ25GLENBQUM7RUFDRCxJQUFJLFdBQVcsQ0FBQyxZQUFZLENBQUMsMEJBQTBCLENBQUMsMkJBQTJCLGVBQWUsTUFBTSxNQUFNLGVBQWUsTUFBTSxNQUFNLEtBQUssR0FBRyxFQUFFLGdCQUFnQixRQUFRLFFBQVEsT0FBTyxDQUFDLENBQUMsS0FBSyxlQUFlLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFJO0NBQ2hPLENBQUM7QUFDRjs7Ozs7OztBQ3pKQSxJQUFNLG1CQUFtQjtBQUN6QixTQUFTLHNCQUFzQjtDQUM5QixJQUFJLFFBQVEsQ0FBQztDQUNiLElBQUksZUFBZTtDQUNuQixJQUFJLFlBQVksYUFBYTtFQUM1QixTQUFTO0NBQ1Y7Q0FDQSxJQUFJLGlCQUFpQixhQUFhO0VBQ2pDLFNBQVM7Q0FDVjtDQUNBLElBQUksYUFBYTtDQUNqQixNQUFNLFlBQVksYUFBYTtFQUM5QixJQUFJLGNBQWMsTUFBTSxLQUFLLFFBQVE7T0FDaEMsaUJBQWlCO0dBQ3JCLFNBQVMsUUFBUTtFQUNsQixDQUFDO0NBQ0Y7Q0FDQSxNQUFNLGNBQWM7RUFDbkIsTUFBTSxnQkFBZ0I7RUFDdEIsUUFBUSxDQUFDO0VBQ1QsSUFBSSxjQUFjLFFBQVEsaUJBQWlCO0dBQzFDLG9CQUFvQjtJQUNuQixjQUFjLFNBQVMsYUFBYTtLQUNuQyxTQUFTLFFBQVE7SUFDbEIsQ0FBQztHQUNGLENBQUM7RUFDRixDQUFDO0NBQ0Y7Q0FDQSxPQUFPOzs7Ozs7O0VBT04sUUFBUSxhQUFhO0dBQ3BCLElBQUk7R0FDSjtHQUNBLElBQUk7SUFDSCxTQUFTLFNBQVM7R0FDbkIsVUFBVTtJQUNUO0lBQ0EsSUFBSSxDQUFDLGNBQWMsTUFBTTtHQUMxQjtHQUNBLE9BQU87RUFDUjs7OztFQUlBLGFBQWEsYUFBYTtHQUN6QixRQUFRLEdBQUcsU0FBUztJQUNuQixlQUFlO0tBQ2QsU0FBUyxHQUFHLElBQUk7SUFDakIsQ0FBQztHQUNGO0VBQ0Q7Ozs7O0VBS0E7Ozs7O0VBS0Esb0JBQW9CLE9BQU87R0FDMUIsV0FBVztFQUNaOzs7Ozs7Ozs7Ozs7OztFQWNBLHlCQUF5QixPQUFPO0dBQy9CLGdCQUFnQjtFQUNqQjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQW1CQSxlQUFlLE9BQU87R0FDckIsYUFBYTtFQUNkO0NBQ0Q7QUFDRDs7OztBQUlBLElBQU0sZ0JBQWdCLG9CQUFvQjs7Ozs7Ozs7Ozs7O0FDekcxQyxJQUFJLGdCQUFnQixjQUFjLGFBQWE7Q0FDOUMsVUFBVTtDQUNWO0NBQ0E7Q0FDQSxjQUFjO0VBQ2IsTUFBTTtFQUNOLEtBQUssVUFBVSxhQUFhO0dBQzNCLElBQUksT0FBTyxXQUFXLGVBQWUsT0FBTyxrQkFBa0I7SUFDN0QsTUFBTSx1QkFBdUIsU0FBUyxJQUFJO0lBQzFDLE1BQU0sd0JBQXdCLFNBQVMsS0FBSztJQUM1QyxPQUFPLGlCQUFpQixVQUFVLGdCQUFnQixLQUFLO0lBQ3ZELE9BQU8saUJBQWlCLFdBQVcsaUJBQWlCLEtBQUs7SUFDekQsYUFBYTtLQUNaLE9BQU8sb0JBQW9CLFVBQVUsY0FBYztLQUNuRCxPQUFPLG9CQUFvQixXQUFXLGVBQWU7SUFDdEQ7R0FDRDtFQUNEO0NBQ0Q7Q0FDQSxjQUFjO0VBQ2IsSUFBSSxDQUFDLEtBQUssVUFBVSxLQUFLLGlCQUFpQixLQUFLLE1BQU07Q0FDdEQ7Q0FDQSxnQkFBZ0I7RUFDZixJQUFJLENBQUMsS0FBSyxhQUFhLEdBQUc7R0FDekIsS0FBSyxXQUFXO0dBQ2hCLEtBQUssV0FBVyxLQUFLO0VBQ3RCO0NBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQkEsaUJBQWlCLE9BQU87RUFDdkIsS0FBSyxTQUFTO0VBQ2QsS0FBSyxXQUFXO0VBQ2hCLEtBQUssV0FBVyxNQUFNLEtBQUssVUFBVSxLQUFLLElBQUksQ0FBQztDQUNoRDs7Ozs7Ozs7Ozs7Ozs7O0NBZUEsVUFBVSxRQUFRO0VBQ2pCLElBQUksS0FBSyxZQUFZLFFBQVE7R0FDNUIsS0FBSyxVQUFVO0dBQ2YsS0FBSyxVQUFVLFNBQVMsYUFBYTtJQUNwQyxTQUFTLE1BQU07R0FDaEIsQ0FBQztFQUNGO0NBQ0Q7Ozs7Q0FJQSxXQUFXO0VBQ1YsT0FBTyxLQUFLO0NBQ2I7QUFDRDs7OztBQUlBLElBQU0sZ0JBQWdCLElBQUksY0FBYzs7O0FDekZ4QyxTQUFTLGtCQUFrQixjQUFjO0NBQ3hDLE9BQU8sS0FBSyxJQUFJLE1BQU0sS0FBSyxjQUFjLEdBQUc7QUFDN0M7QUFDQSxTQUFTLFNBQVMsYUFBYTtDQUM5QixRQUFRLGVBQWUsY0FBYyxXQUFXLGNBQWMsU0FBUyxJQUFJO0FBQzVFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbUJBLElBQUksaUJBQWlCLGNBQWMsTUFBTTtDQUN4QyxZQUFZLFNBQVM7RUFDcEIsTUFBTSxnQkFBZ0I7RUFDdEIsS0FBSyxTQUFTLFNBQVM7RUFDdkIsS0FBSyxTQUFTLFNBQVM7Q0FDeEI7QUFDRDs7OztBQUlBLFNBQVMsaUJBQWlCLE9BQU87Q0FDaEMsT0FBTyxpQkFBaUI7QUFDekI7QUFDQSxTQUFTLGNBQWMsUUFBUTtDQUM5QixJQUFJLG1CQUFtQjtDQUN2QixJQUFJLGVBQWU7Q0FDbkIsSUFBSTtDQUNKLElBQUksU0FBUztDQUNiLElBQUk7Q0FDSixJQUFJO0NBQ0osTUFBTSxVQUFVLElBQUksU0FBUyxTQUFTLFdBQVc7RUFDaEQsaUJBQWlCO0VBQ2pCLGdCQUFnQjtDQUNqQixDQUFDO0NBQ0QsUUFBUSxNQUFNLElBQUk7Q0FDbEIsTUFBTSxtQkFBbUIsV0FBVztDQUNwQyxNQUFNLFVBQVUsa0JBQWtCO0VBQ2pDLElBQUksQ0FBQyxXQUFXLEdBQUc7R0FDbEIsTUFBTSxRQUFRLElBQUksZUFBZSxhQUFhO0dBQzlDLE9BQU8sS0FBSztHQUNaLE9BQU8sV0FBVyxLQUFLO0VBQ3hCO0NBQ0Q7Q0FDQSxNQUFNLG9CQUFvQjtFQUN6QixtQkFBbUI7Q0FDcEI7Q0FDQSxNQUFNLHNCQUFzQjtFQUMzQixtQkFBbUI7Q0FDcEI7Q0FDQSxNQUFNLG9CQUFvQixhQUFhLFVBQVUsTUFBTSxPQUFPLGdCQUFnQixZQUFZLGNBQWMsU0FBUyxNQUFNLE9BQU8sT0FBTztDQUNySSxNQUFNLGlCQUFpQixTQUFTLE9BQU8sV0FBVyxLQUFLLE9BQU8sT0FBTztDQUNyRSxNQUFNLFdBQVcsVUFBVTtFQUMxQixJQUFJLENBQUMsV0FBVyxHQUFHO0dBQ2xCLGFBQWE7R0FDYixTQUFTO0dBQ1QsZUFBZSxLQUFLO0VBQ3JCO0NBQ0Q7Q0FDQSxNQUFNLFVBQVUsVUFBVTtFQUN6QixJQUFJLENBQUMsV0FBVyxHQUFHO0dBQ2xCLGFBQWE7R0FDYixTQUFTO0dBQ1QsY0FBYyxLQUFLO0VBQ3BCO0NBQ0Q7Q0FDQSxNQUFNLGNBQWM7RUFDbkIsT0FBTyxJQUFJLFNBQVMsb0JBQW9CO0dBQ3ZDLGNBQWMsVUFBVTtJQUN2QixJQUFJLFdBQVcsS0FBSyxZQUFZLEdBQUcsZ0JBQWdCLEtBQUs7R0FDekQ7R0FDQSxPQUFPLFVBQVU7RUFDbEIsQ0FBQyxDQUFDLENBQUMsV0FBVztHQUNiLGFBQWEsS0FBSztHQUNsQixJQUFJLENBQUMsV0FBVyxHQUFHLE9BQU8sYUFBYTtFQUN4QyxDQUFDO0NBQ0Y7Q0FDQSxNQUFNLFlBQVk7RUFDakIsSUFBSSxXQUFXLEdBQUc7RUFDbEIsSUFBSTtFQUNKLE1BQU0saUJBQWlCLGlCQUFpQixJQUFJLE9BQU8saUJBQWlCLEtBQUs7RUFDekUsSUFBSTtHQUNILGlCQUFpQixrQkFBa0IsT0FBTyxHQUFHO0VBQzlDLFNBQVMsT0FBTztHQUNmLGlCQUFpQixRQUFRLE9BQU8sS0FBSztFQUN0QztFQUNBLFFBQVEsUUFBUSxjQUFjLENBQUMsQ0FBQyxLQUFLLE9BQU8sQ0FBQyxDQUFDLE9BQU8sVUFBVTtHQUM5RCxJQUFJLFdBQVcsR0FBRztHQUNsQixNQUFNLFFBQVEsT0FBTyxVQUFVQyxXQUFTLElBQUksSUFBSTtHQUNoRCxNQUFNLGFBQWEsT0FBTyxjQUFjO0dBQ3hDLE1BQU0sUUFBUSxPQUFPLGVBQWUsYUFBYSxXQUFXLGNBQWMsS0FBSyxJQUFJO0dBQ25GLE1BQU0sY0FBYyxVQUFVLFFBQVEsT0FBTyxVQUFVLFlBQVksZUFBZSxTQUFTLE9BQU8sVUFBVSxjQUFjLE1BQU0sY0FBYyxLQUFLO0dBQ25KLElBQUksb0JBQW9CLENBQUMsYUFBYTtJQUNyQyxPQUFPLEtBQUs7SUFDWjtHQUNEO0dBQ0E7R0FDQSxPQUFPLFNBQVMsY0FBYyxLQUFLO0dBQ25DLE1BQU0sS0FBSyxDQUFDLENBQUMsV0FBVztJQUN2QixPQUFPLFlBQVksSUFBSSxLQUFLLElBQUksTUFBTTtHQUN2QyxDQUFDLENBQUMsQ0FBQyxXQUFXO0lBQ2IsSUFBSSxrQkFBa0IsT0FBTyxLQUFLO1NBQzdCLElBQUk7R0FDVixDQUFDO0VBQ0YsQ0FBQztDQUNGO0NBQ0EsT0FBTztFQUNOO0VBQ0EsY0FBYztFQUNkO0VBQ0EsZ0JBQWdCO0dBQ2YsYUFBYTtHQUNiLE9BQU87RUFDUjtFQUNBO0VBQ0E7RUFDQTtFQUNBLGFBQWE7R0FDWixJQUFJLFNBQVMsR0FBRyxJQUFJO1FBQ2YsTUFBTSxDQUFDLENBQUMsS0FBSyxHQUFHO0dBQ3JCLE9BQU87RUFDUjtDQUNEO0FBQ0Q7OztBQ3pJQSxJQUFJLFlBQVksTUFBTTtDQUNyQjtDQUNBLFVBQVU7RUFDVCxLQUFLLGVBQWU7Q0FDckI7Q0FDQSxhQUFhO0VBQ1osS0FBSyxlQUFlO0VBQ3BCLElBQUksZUFBZSxLQUFLLE1BQU0sR0FBRyxLQUFLLGFBQWEsZUFBZSxpQkFBaUI7R0FDbEYsS0FBSyxlQUFlO0VBQ3JCLEdBQUcsS0FBSyxNQUFNO0NBQ2Y7Q0FDQSxhQUFhLFdBQVc7RUFDdkIsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFVBQVUsR0FBRyxjQUFjQyxXQUFTLElBQUksV0FBVyxJQUFJO0NBQ3BGO0NBQ0EsaUJBQWlCO0VBQ2hCLElBQUksS0FBSyxlQUFlLEtBQUssR0FBRztHQUMvQixlQUFlLGFBQWEsS0FBSyxVQUFVO0dBQzNDLEtBQUssYUFBYSxLQUFLO0VBQ3hCO0NBQ0Q7QUFDRDs7O0FDdEJBLFNBQVMsc0JBQXNCLE9BQU87Q0FDckMsT0FBTyxFQUFFLFVBQVUsU0FBUyxVQUFVO0VBQ3JDLE1BQU0sVUFBVSxRQUFRO0VBQ3hCLE1BQU0sWUFBWSxRQUFRLGNBQWMsTUFBTSxXQUFXO0VBQ3pELE1BQU0sV0FBVyxRQUFRLE1BQU0sTUFBTSxTQUFTLENBQUM7RUFDL0MsTUFBTSxnQkFBZ0IsUUFBUSxNQUFNLE1BQU0sY0FBYyxDQUFDO0VBQ3pELElBQUksU0FBUztHQUNaLE9BQU8sQ0FBQztHQUNSLFlBQVksQ0FBQztFQUNkO0VBQ0EsSUFBSSxjQUFjO0VBQ2xCLE1BQU0sVUFBVSxZQUFZO0dBQzNCLElBQUksWUFBWTtHQUNoQixNQUFNLHFCQUFxQixXQUFXO0lBQ3JDLHNCQUFzQixjQUFjLFFBQVEsY0FBYyxZQUFZLElBQUk7R0FDM0U7R0FDQSxNQUFNLFVBQVUsY0FBYyxRQUFRLFNBQVMsUUFBUSxZQUFZO0dBQ25FLE1BQU0sWUFBWSxPQUFPLE1BQU0sT0FBTyxhQUFhO0lBQ2xELElBQUksV0FBVyxPQUFPLFFBQVEsT0FBTyxRQUFRLE9BQU8sTUFBTTtJQUMxRCxJQUFJLFNBQVMsUUFBUSxLQUFLLE1BQU0sUUFBUSxPQUFPLFFBQVEsUUFBUSxJQUFJO0lBQ25FLE1BQU0sNkJBQTZCO0tBQ2xDLE1BQU0saUJBQWlCO01BQ3RCLFFBQVEsUUFBUTtNQUNoQixVQUFVLFFBQVE7TUFDbEIsV0FBVztNQUNYLFdBQVcsV0FBVyxhQUFhO01BQ25DLE1BQU0sUUFBUSxRQUFRO0tBQ3ZCO0tBQ0Esa0JBQWtCLGNBQWM7S0FDaEMsT0FBTztJQUNSO0lBQ0EsTUFBTSxpQkFBaUIscUJBQXFCO0lBQzVDLE1BQU0sT0FBTyxNQUFNLFFBQVEsY0FBYztJQUN6QyxNQUFNLEVBQUUsYUFBYSxRQUFRO0lBQzdCLE1BQU0sUUFBUSxXQUFXLGFBQWE7SUFDdEMsT0FBTztLQUNOLE9BQU8sTUFBTSxLQUFLLE9BQU8sTUFBTSxRQUFRO0tBQ3ZDLFlBQVksTUFBTSxLQUFLLFlBQVksT0FBTyxRQUFRO0lBQ25EO0dBQ0Q7R0FDQSxJQUFJLGFBQWEsU0FBUyxRQUFRO0lBQ2pDLE1BQU0sV0FBVyxjQUFjO0lBQy9CLE1BQU0sY0FBYyxXQUFXLHVCQUF1QjtJQUN0RCxNQUFNLFVBQVU7S0FDZixPQUFPO0tBQ1AsWUFBWTtJQUNiO0lBQ0EsU0FBUyxNQUFNLFVBQVUsU0FBUyxZQUFZLFNBQVMsT0FBTyxHQUFHLFFBQVE7R0FDMUUsT0FBTztJQUNOLE1BQU0saUJBQWlCLFNBQVMsU0FBUztJQUN6QyxHQUFHO0tBQ0YsTUFBTSxRQUFRLGdCQUFnQixJQUFJLGNBQWMsTUFBTSxRQUFRLG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0tBQ2pILElBQUksY0FBYyxLQUFLLFNBQVMsTUFBTTtLQUN0QyxTQUFTLE1BQU0sVUFBVSxRQUFRLEtBQUs7S0FDdEM7SUFDRCxTQUFTLGNBQWM7R0FDeEI7R0FDQSxPQUFPO0VBQ1I7RUFDQSxJQUFJLFFBQVEsUUFBUSxXQUFXLFFBQVEsZ0JBQWdCO0dBQ3RELE9BQU8sUUFBUSxRQUFRLFlBQVksU0FBUztJQUMzQyxRQUFRLFFBQVE7SUFDaEIsVUFBVSxRQUFRO0lBQ2xCLE1BQU0sUUFBUSxRQUFRO0lBQ3RCLFFBQVEsUUFBUTtHQUNqQixHQUFHLEtBQUs7RUFDVDtPQUNLLFFBQVEsVUFBVTtDQUN4QixFQUFFO0FBQ0g7QUFDQSxTQUFTLGlCQUFpQixTQUFTLEVBQUUsT0FBTyxjQUFjO0NBQ3pELE1BQU0sWUFBWSxNQUFNLFNBQVM7Q0FDakMsT0FBTyxNQUFNLFNBQVMsSUFBSSxRQUFRLGlCQUFpQixNQUFNLFlBQVksT0FBTyxXQUFXLFlBQVksVUFBVSxJQUFJLEtBQUs7QUFDdkg7QUFDQSxTQUFTLHFCQUFxQixTQUFTLEVBQUUsT0FBTyxjQUFjO0NBQzdELE9BQU8sTUFBTSxTQUFTLElBQUksUUFBUSx1QkFBdUIsTUFBTSxJQUFJLE9BQU8sV0FBVyxJQUFJLFVBQVUsSUFBSSxLQUFLO0FBQzdHOzs7O0FBSUEsU0FBUyxZQUFZLFNBQVMsTUFBTTtDQUNuQyxJQUFJLENBQUMsTUFBTSxPQUFPO0NBQ2xCLE9BQU8saUJBQWlCLFNBQVMsSUFBSSxLQUFLO0FBQzNDOzs7O0FBSUEsU0FBUyxnQkFBZ0IsU0FBUyxNQUFNO0NBQ3ZDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxzQkFBc0IsT0FBTztDQUNuRCxPQUFPLHFCQUFxQixTQUFTLElBQUksS0FBSztBQUMvQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25FQSxJQUFJLFFBQVEsY0FBYyxVQUFVO0NBQ25DO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxZQUFZLFFBQVE7RUFDbkIsTUFBTTtFQUNOLEtBQUssdUJBQXVCO0VBQzVCLEtBQUssa0JBQWtCLE9BQU87RUFDOUIsS0FBSyxXQUFXLE9BQU8sT0FBTztFQUM5QixLQUFLLFlBQVksQ0FBQztFQUNsQixLQUFLLFVBQVUsT0FBTztFQUN0QixLQUFLLFNBQVMsS0FBSyxRQUFRLGNBQWM7RUFDekMsS0FBSyxXQUFXLE9BQU87RUFDdkIsS0FBSyxZQUFZLE9BQU87RUFDeEIsS0FBSyxnQkFBZ0JDLGtCQUFnQixLQUFLLE9BQU87RUFDakQsS0FBSyxRQUFRLE9BQU8sU0FBUyxLQUFLO0VBQ2xDLEtBQUssV0FBVztDQUNqQjs7OztDQUlBLElBQUksT0FBTztFQUNWLE9BQU8sS0FBSyxRQUFRO0NBQ3JCOztDQUVBLElBQUksWUFBWTtFQUNmLE9BQU8sS0FBSztDQUNiOzs7OztDQUtBLElBQUksVUFBVTtFQUNiLE9BQU8sS0FBSyxVQUFVO0NBQ3ZCOztDQUVBLFdBQVcsU0FBUztFQUNuQixLQUFLLFVBQVU7R0FDZCxHQUFHLEtBQUs7R0FDUixHQUFHO0VBQ0o7RUFDQSxJQUFJLFNBQVMsT0FBTyxLQUFLLGFBQWEsUUFBUTtFQUM5QyxLQUFLLGFBQWEsS0FBSyxRQUFRLE1BQU07RUFDckMsSUFBSSxLQUFLLFNBQVMsS0FBSyxNQUFNLFNBQVMsS0FBSyxHQUFHO0dBQzdDLE1BQU0sZUFBZUEsa0JBQWdCLEtBQUssT0FBTztHQUNqRCxJQUFJLGFBQWEsU0FBUyxLQUFLLEdBQUc7SUFDakMsS0FBSyxTQUFTLGFBQWEsYUFBYSxNQUFNLGFBQWEsYUFBYSxDQUFDO0lBQ3pFLEtBQUssZ0JBQWdCO0dBQ3RCO0VBQ0Q7Q0FDRDtDQUNBLGlCQUFpQjtFQUNoQixJQUFJLENBQUMsS0FBSyxVQUFVLFVBQVUsS0FBSyxNQUFNLGdCQUFnQixRQUFRLEtBQUssT0FBTyxPQUFPLElBQUk7Q0FDekY7O0NBRUEsUUFBUSxTQUFTLFNBQVM7RUFDekIsTUFBTSxPQUFPLFlBQVksS0FBSyxNQUFNLE1BQU0sU0FBUyxLQUFLLE9BQU87RUFDL0QsS0FBSyxVQUFVO0dBQ2Q7R0FDQSxNQUFNO0dBQ04sZUFBZSxTQUFTO0dBQ3hCLFFBQVEsU0FBUztFQUNsQixDQUFDO0VBQ0QsT0FBTztDQUNSOzs7Ozs7Q0FNQSxTQUFTLE9BQU87RUFDZixLQUFLLFVBQVU7R0FDZCxNQUFNO0dBQ047RUFDRCxDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7O0NBV0EsT0FBTyxTQUFTO0VBQ2YsTUFBTSxVQUFVLEtBQUssVUFBVTtFQUMvQixLQUFLLFVBQVUsT0FBTyxPQUFPO0VBQzdCLE9BQU8sVUFBVSxRQUFRLEtBQUssSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJLElBQUksUUFBUSxRQUFRO0NBQ25FOzs7Ozs7OztDQVFBLFVBQVU7RUFDVCxNQUFNLFFBQVE7RUFDZCxLQUFLLE9BQU8sRUFBRSxRQUFRLEtBQUssQ0FBQztDQUM3Qjs7Q0FFQSxJQUFJLGFBQWE7RUFDaEIsT0FBTyxLQUFLO0NBQ2I7Ozs7OztDQU1BLFFBQVE7RUFDUCxLQUFLLFFBQVE7RUFDYixLQUFLLFNBQVMsS0FBSyxVQUFVO0NBQzlCOzs7OztDQUtBLFdBQVc7RUFDVixPQUFPLEtBQUssVUFBVSxNQUFNLGFBQWEsa0JBQWtCLFNBQVMsUUFBUSxTQUFTLElBQUksTUFBTSxLQUFLO0NBQ3JHOzs7Ozs7Ozs7Q0FTQSxhQUFhO0VBQ1osSUFBSSxLQUFLLGtCQUFrQixJQUFJLEdBQUcsT0FBTyxDQUFDLEtBQUssU0FBUztFQUN4RCxPQUFPLEtBQUssUUFBUSxZQUFZLGFBQWEsQ0FBQyxLQUFLLFVBQVU7Q0FDOUQ7Ozs7O0NBS0EsWUFBWTtFQUNYLE9BQU8sS0FBSyxNQUFNLGtCQUFrQixLQUFLLE1BQU0sbUJBQW1CO0NBQ25FOzs7OztDQUtBLFdBQVc7RUFDVixJQUFJLEtBQUssa0JBQWtCLElBQUksR0FBRyxPQUFPLEtBQUssVUFBVSxNQUFNLGFBQWEsa0JBQWtCLFNBQVMsUUFBUSxXQUFXLElBQUksTUFBTSxRQUFRO0VBQzNJLE9BQU87Q0FDUjs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsVUFBVTtFQUNULElBQUksS0FBSyxrQkFBa0IsSUFBSSxHQUFHLE9BQU8sS0FBSyxVQUFVLE1BQU0sYUFBYSxTQUFTLGlCQUFpQixDQUFDLENBQUMsT0FBTztFQUM5RyxPQUFPLEtBQUssTUFBTSxTQUFTLEtBQUssS0FBSyxLQUFLLE1BQU07Q0FDakQ7Ozs7Ozs7Ozs7Ozs7OztDQWVBLGNBQWMsWUFBWSxHQUFHO0VBQzVCLElBQUksS0FBSyxNQUFNLFNBQVMsS0FBSyxHQUFHLE9BQU87RUFDdkMsSUFBSSxjQUFjLFVBQVUsT0FBTztFQUNuQyxJQUFJLEtBQUssTUFBTSxlQUFlLE9BQU87RUFDckMsT0FBTyxDQUFDLGVBQWUsS0FBSyxNQUFNLGVBQWUsU0FBUztDQUMzRDs7Q0FFQSxVQUFVO0VBQ1QsS0FBSyxVQUFVLE1BQU0sTUFBTSxFQUFFLHlCQUF5QixDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsZUFBZSxNQUFNLENBQUM7RUFDMUYsS0FBSyxVQUFVLFNBQVM7Q0FDekI7O0NBRUEsV0FBVztFQUNWLEtBQUssVUFBVSxNQUFNLE1BQU0sRUFBRSx1QkFBdUIsQ0FBQyxDQUFDLEVBQUUsUUFBUSxFQUFFLGVBQWUsTUFBTSxDQUFDO0VBQ3hGLEtBQUssVUFBVSxTQUFTO0NBQ3pCOztDQUVBLFlBQVksVUFBVTtFQUNyQixJQUFJLENBQUMsS0FBSyxVQUFVLFNBQVMsUUFBUSxHQUFHO0dBQ3ZDLEtBQUssVUFBVSxLQUFLLFFBQVE7R0FDNUIsS0FBSyxlQUFlO0dBQ3BCLEtBQUssT0FBTyxPQUFPO0lBQ2xCLE1BQU07SUFDTixPQUFPO0lBQ1A7R0FDRCxDQUFDO0VBQ0Y7Q0FDRDs7Q0FFQSxlQUFlLFVBQVU7RUFDeEIsTUFBTSxRQUFRLEtBQUssVUFBVSxRQUFRLFFBQVE7RUFDN0MsSUFBSSxVQUFVLElBQUk7R0FDakIsS0FBSyxVQUFVLE9BQU8sT0FBTyxDQUFDO0dBQzlCLElBQUksQ0FBQyxLQUFLLFVBQVUsUUFBUTtJQUMzQixJQUFJLEtBQUssVUFBVTtLQUNsQixJQUFJLEtBQUssd0JBQXdCLEtBQUssTUFBTSxnQkFBZ0IsWUFBWSxLQUFLLE1BQU0sV0FBVyxXQUFXLEtBQUssU0FBUyxPQUFPLEVBQUUsUUFBUSxLQUFLLENBQUM7VUFDekksS0FBSyxTQUFTLFlBQVk7SUFDaEM7SUFDQSxLQUFLLFdBQVc7R0FDakI7R0FDQSxLQUFLLE9BQU8sT0FBTztJQUNsQixNQUFNO0lBQ04sT0FBTztJQUNQO0dBQ0QsQ0FBQztFQUNGO0NBQ0Q7Ozs7Ozs7Ozs7O0NBV0Esb0JBQW9CO0VBQ25CLE9BQU8sS0FBSyxVQUFVO0NBQ3ZCOzs7Ozs7Ozs7OztDQVdBLGFBQWE7RUFDWixJQUFJLENBQUMsS0FBSyxNQUFNLGVBQWUsS0FBSyxVQUFVLEVBQUUsTUFBTSxhQUFhLENBQUM7Q0FDckU7Ozs7Ozs7Ozs7O0NBV0EsTUFBTSxNQUFNLFNBQVMsY0FBYztFQUNsQyxJQUFJLEtBQUssTUFBTSxnQkFBZ0IsVUFBVSxLQUFLLFVBQVUsT0FBTyxNQUFNLFlBQVk7R0FDaEYsSUFBSSxLQUFLLE1BQU0sU0FBUyxLQUFLLEtBQUssY0FBYyxlQUFlLEtBQUssT0FBTyxFQUFFLFFBQVEsS0FBSyxDQUFDO1FBQ3RGLElBQUksS0FBSyxVQUFVO0lBQ3ZCLEtBQUssU0FBUyxjQUFjO0lBQzVCLE9BQU8sS0FBSyxTQUFTO0dBQ3RCO0VBQ0Q7RUFDQSxJQUFJLFNBQVMsS0FBSyxXQUFXLE9BQU87RUFDcEMsSUFBSSxDQUFDLEtBQUssUUFBUSxTQUFTO0dBQzFCLE1BQU0sV0FBVyxLQUFLLFVBQVUsTUFBTSxNQUFNLEVBQUUsUUFBUSxPQUFPO0dBQzdELElBQUksVUFBVSxLQUFLLFdBQVcsU0FBUyxPQUFPO0VBQy9DO0VBRUMsSUFBSSxDQUFDLE1BQU0sUUFBUSxLQUFLLFFBQVEsUUFBUSxHQUFHLFFBQVEsTUFBTSxxSUFBcUk7RUFFL0wsTUFBTSxrQkFBa0IsSUFBSSxnQkFBZ0I7RUFDNUMsTUFBTSxxQkFBcUIsV0FBVztHQUNyQyxPQUFPLGVBQWUsUUFBUSxVQUFVO0lBQ3ZDLFlBQVk7SUFDWixXQUFXO0tBQ1YsS0FBSyx1QkFBdUI7S0FDNUIsT0FBTyxnQkFBZ0I7SUFDeEI7R0FDRCxDQUFDO0VBQ0Y7RUFDQSxNQUFNLGdCQUFnQjtHQUNyQixNQUFNLFVBQVUsY0FBYyxLQUFLLFNBQVMsWUFBWTtHQUN4RCxNQUFNLDZCQUE2QjtJQUNsQyxNQUFNLGlCQUFpQjtLQUN0QixRQUFRLEtBQUs7S0FDYixVQUFVLEtBQUs7S0FDZixNQUFNLEtBQUs7SUFDWjtJQUNBLGtCQUFrQixjQUFjO0lBQ2hDLE9BQU87R0FDUjtHQUNBLE1BQU0saUJBQWlCLHFCQUFxQjtHQUM1QyxLQUFLLHVCQUF1QjtHQUM1QixJQUFJLEtBQUssUUFBUSxXQUFXLE9BQU8sS0FBSyxRQUFRLFVBQVUsU0FBUyxnQkFBZ0IsSUFBSTtHQUN2RixPQUFPLFFBQVEsY0FBYztFQUM5QjtFQUNBLE1BQU0sMkJBQTJCO0dBQ2hDLE1BQU0sVUFBVTtJQUNmO0lBQ0EsU0FBUyxLQUFLO0lBQ2QsVUFBVSxLQUFLO0lBQ2YsUUFBUSxLQUFLO0lBQ2IsT0FBTyxLQUFLO0lBQ1o7R0FDRDtHQUNBLGtCQUFrQixPQUFPO0dBQ3pCLE9BQU87RUFDUjtFQUNBLE1BQU0sVUFBVSxtQkFBbUI7RUFDbkMsQ0FBQyxLQUFLLGVBQWUsYUFBYSxzQkFBc0IsS0FBSyxRQUFRLEtBQUssSUFBSSxLQUFLLFFBQVEsU0FBQSxFQUFXLFFBQVEsU0FBUyxJQUFJO0VBQzNILEtBQUssZUFBZSxLQUFLO0VBQ3pCLElBQUksS0FBSyxNQUFNLGdCQUFnQixVQUFVLEtBQUssTUFBTSxjQUFjLFFBQVEsY0FBYyxNQUFNLEtBQUssVUFBVTtHQUM1RyxNQUFNO0dBQ04sTUFBTSxRQUFRLGNBQWM7RUFDN0IsQ0FBQztFQUNELE1BQU0sVUFBVSxLQUFLLFdBQVcsY0FBYztHQUM3QyxnQkFBZ0IsY0FBYztHQUM5QixJQUFJLFFBQVE7R0FDWixXQUFXLFVBQVU7SUFDcEIsSUFBSSxpQkFBaUIsa0JBQWtCLE1BQU0sUUFBUSxLQUFLLFNBQVM7S0FDbEUsR0FBRyxLQUFLO0tBQ1IsYUFBYTtJQUNkLENBQUM7SUFDRCxnQkFBZ0IsTUFBTTtHQUN2QjtHQUNBLFNBQVMsY0FBYyxVQUFVO0lBQ2hDLEtBQUssVUFBVTtLQUNkLE1BQU07S0FDTjtLQUNBO0lBQ0QsQ0FBQztHQUNGO0dBQ0EsZUFBZTtJQUNkLEtBQUssVUFBVSxFQUFFLE1BQU0sUUFBUSxDQUFDO0dBQ2pDO0dBQ0Esa0JBQWtCO0lBQ2pCLEtBQUssVUFBVSxFQUFFLE1BQU0sV0FBVyxDQUFDO0dBQ3BDO0dBQ0EsT0FBTyxRQUFRLFFBQVE7R0FDdkIsWUFBWSxRQUFRLFFBQVE7R0FDNUIsYUFBYSxRQUFRLFFBQVE7R0FDN0IsY0FBYztFQUNmLENBQUM7RUFDRCxJQUFJO0dBQ0gsTUFBTSxPQUFPLE1BQU0sUUFBUSxNQUFNO0dBQ2pDLElBQUksU0FBUyxLQUFLLEdBQUc7SUFDdUIsUUFBUSxNQUFNLHlJQUF5SSxLQUFLLFdBQVc7SUFDbE4sTUFBTSxJQUFJLE1BQU0sR0FBRyxLQUFLLFVBQVUsbUJBQW1CO0dBQ3REO0dBQ0EsS0FBSyxRQUFRLElBQUk7R0FDakIsS0FBSyxPQUFPLE9BQU8sWUFBWSxNQUFNLElBQUk7R0FDekMsS0FBSyxPQUFPLE9BQU8sWUFBWSxNQUFNLEtBQUssTUFBTSxPQUFPLElBQUk7R0FDM0QsT0FBTztFQUNSLFNBQVMsT0FBTztHQUNmLElBQUksaUJBQWlCLGdCQUFnQjtJQUNwQyxJQUFJLE1BQU0sUUFBUSxPQUFPLEtBQUssU0FBUztTQUNsQyxJQUFJLE1BQU0sUUFBUTtLQUN0QixJQUFJLEtBQUssTUFBTSxTQUFTLEtBQUssR0FBRyxNQUFNO0tBQ3RDLE9BQU8sS0FBSyxNQUFNO0lBQ25CO0dBQ0Q7R0FDQSxLQUFLLFVBQVU7SUFDZCxNQUFNO0lBQ047R0FDRCxDQUFDO0dBQ0QsS0FBSyxPQUFPLE9BQU8sVUFBVSxPQUFPLElBQUk7R0FDeEMsS0FBSyxPQUFPLE9BQU8sWUFBWSxLQUFLLE1BQU0sTUFBTSxPQUFPLElBQUk7R0FDM0QsTUFBTTtFQUNQLFVBQVU7R0FDVCxJQUFJLEtBQUssYUFBYSxTQUFTLEtBQUssV0FBVyxLQUFLO0dBQ3BELEtBQUssV0FBVztFQUNqQjtDQUNEO0NBQ0EsVUFBVSxRQUFRO0VBQ2pCLE1BQU0sV0FBVyxVQUFVO0dBQzFCLFFBQVEsT0FBTyxNQUFmO0lBQ0MsS0FBSyxVQUFVLE9BQU87S0FDckIsR0FBRztLQUNILG1CQUFtQixPQUFPO0tBQzFCLG9CQUFvQixPQUFPO0lBQzVCO0lBQ0EsS0FBSyxTQUFTLE9BQU87S0FDcEIsR0FBRztLQUNILGFBQWE7SUFDZDtJQUNBLEtBQUssWUFBWSxPQUFPO0tBQ3ZCLEdBQUc7S0FDSCxhQUFhO0lBQ2Q7SUFDQSxLQUFLLFNBQVMsT0FBTztLQUNwQixHQUFHO0tBQ0gsR0FBRyxXQUFXLE1BQU0sTUFBTSxLQUFLLE9BQU87S0FDdEMsV0FBVyxPQUFPLFFBQVE7SUFDM0I7SUFDQSxLQUFLO0tBQ0osTUFBTSxXQUFXO01BQ2hCLEdBQUc7TUFDSCxHQUFHLGFBQWEsT0FBTyxNQUFNLE9BQU8sYUFBYTtNQUNqRCxpQkFBaUIsTUFBTSxrQkFBa0I7TUFDekMsR0FBRyxDQUFDLE9BQU8sVUFBVTtPQUNwQixhQUFhO09BQ2IsbUJBQW1CO09BQ25CLG9CQUFvQjtNQUNyQjtLQUNEO0tBQ0EsS0FBSyxlQUFlLE9BQU8sU0FBUyxXQUFXLEtBQUs7S0FDcEQsT0FBTztJQUNSLEtBQUs7S0FDSixNQUFNLFFBQVEsT0FBTztLQUNyQixPQUFPO01BQ04sR0FBRztNQUNIO01BQ0Esa0JBQWtCLE1BQU0sbUJBQW1CO01BQzNDLGdCQUFnQixLQUFLLElBQUk7TUFDekIsbUJBQW1CLE1BQU0sb0JBQW9CO01BQzdDLG9CQUFvQjtNQUNwQixhQUFhO01BQ2IsUUFBUTtNQUNSLGVBQWU7S0FDaEI7SUFDRCxLQUFLLGNBQWMsT0FBTztLQUN6QixHQUFHO0tBQ0gsZUFBZTtJQUNoQjtJQUNBLEtBQUssWUFBWSxPQUFPO0tBQ3ZCLEdBQUc7S0FDSCxHQUFHLE9BQU87SUFDWDtHQUNEO0VBQ0Q7RUFDQSxLQUFLLFFBQVEsUUFBUSxLQUFLLEtBQUs7RUFDL0IsY0FBYyxZQUFZO0dBQ3pCLEtBQUssVUFBVSxNQUFNLENBQUMsQ0FBQyxTQUFTLGFBQWE7SUFDNUMsU0FBUyxjQUFjO0dBQ3hCLENBQUM7R0FDRCxLQUFLLE9BQU8sT0FBTztJQUNsQixPQUFPO0lBQ1AsTUFBTTtJQUNOO0dBQ0QsQ0FBQztFQUNGLENBQUM7Q0FDRjtBQUNEO0FBQ0EsU0FBUyxXQUFXLE1BQU0sU0FBUztDQUNsQyxPQUFPO0VBQ04sbUJBQW1CO0VBQ25CLG9CQUFvQjtFQUNwQixhQUFhLFNBQVMsUUFBUSxXQUFXLElBQUksYUFBYTtFQUMxRCxHQUFHLFNBQVMsS0FBSyxLQUFLO0dBQ3JCLE9BQU87R0FDUCxRQUFRO0VBQ1Q7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxhQUFhLE1BQU0sZUFBZTtDQUMxQyxPQUFPO0VBQ047RUFDQSxlQUFlLGlCQUFpQixLQUFLLElBQUk7RUFDekMsT0FBTztFQUNQLGVBQWU7RUFDZixRQUFRO0NBQ1Q7QUFDRDtBQUNBLFNBQVNBLGtCQUFnQixTQUFTO0NBQ2pDLE1BQU0sT0FBTyxPQUFPLFFBQVEsZ0JBQWdCLGFBQWEsUUFBUSxZQUFZLElBQUksUUFBUTtDQUN6RixNQUFNLFVBQVUsU0FBUyxLQUFLO0NBQzlCLE1BQU0sdUJBQXVCLFVBQVUsT0FBTyxRQUFRLHlCQUF5QixhQUFhLFFBQVEscUJBQXFCLElBQUksUUFBUSx1QkFBdUI7Q0FDNUosT0FBTztFQUNOO0VBQ0EsaUJBQWlCO0VBQ2pCLGVBQWUsVUFBVSx3QkFBd0IsS0FBSyxJQUFJLElBQUk7RUFDOUQsT0FBTztFQUNQLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsbUJBQW1CO0VBQ25CLG9CQUFvQjtFQUNwQixXQUFXO0VBQ1gsZUFBZTtFQUNmLFFBQVEsVUFBVSxZQUFZO0VBQzlCLGFBQWE7Q0FDZDtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9lQSxJQUFJLGdCQUFnQixjQUFjLGFBQWE7Q0FDOUM7Q0FDQSxnQkFBZ0IsS0FBSztDQUNyQiw0QkFBNEIsS0FBSztDQUNqQyxpQkFBaUIsS0FBSztDQUN0QjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxnQ0FBZ0MsSUFBSSxJQUFJO0NBQ3hDLFlBQVksUUFBUSxTQUFTO0VBQzVCLE1BQU07RUFDTixLQUFLLFVBQVU7RUFDZixLQUFLLFVBQVU7RUFDZixLQUFLLGVBQWU7RUFDcEIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssV0FBVyxPQUFPO0NBQ3hCO0NBQ0EsY0FBYztFQUNiLEtBQUssVUFBVSxLQUFLLFFBQVEsS0FBSyxJQUFJO0NBQ3RDO0NBQ0EsY0FBYztFQUNiLElBQUksS0FBSyxVQUFVLFNBQVMsR0FBRztHQUM5QixLQUFLLGNBQWMsWUFBWSxJQUFJO0dBQ25DLElBQUksbUJBQW1CLEtBQUssZUFBZSxLQUFLLE9BQU8sR0FBRyxLQUFLLGNBQWM7UUFDeEUsS0FBSyxhQUFhO0dBQ3ZCLEtBQUssY0FBYztFQUNwQjtDQUNEO0NBQ0EsZ0JBQWdCO0VBQ2YsSUFBSSxDQUFDLEtBQUssYUFBYSxHQUFHLEtBQUssUUFBUTtDQUN4Qzs7Ozs7O0NBTUEseUJBQXlCO0VBQ3hCLE9BQU8sY0FBYyxLQUFLLGVBQWUsS0FBSyxTQUFTLEtBQUssUUFBUSxrQkFBa0I7Q0FDdkY7Ozs7OztDQU1BLDJCQUEyQjtFQUMxQixPQUFPLGNBQWMsS0FBSyxlQUFlLEtBQUssU0FBUyxLQUFLLFFBQVEsb0JBQW9CO0NBQ3pGOzs7Ozs7Q0FNQSxVQUFVO0VBQ1QsS0FBSyw0QkFBNEIsSUFBSSxJQUFJO0VBQ3pDLEtBQUssbUJBQW1CO0VBQ3hCLEtBQUssc0JBQXNCO0VBQzNCLEtBQUssY0FBYyxlQUFlLElBQUk7Q0FDdkM7Ozs7Ozs7Ozs7Ozs7OztDQWVBLFdBQVcsU0FBUztFQUNuQixNQUFNLGNBQWMsS0FBSztFQUN6QixNQUFNLFlBQVksS0FBSztFQUN2QixLQUFLLFVBQVUsS0FBSyxRQUFRLG9CQUFvQixPQUFPO0VBQ3ZELElBQUksS0FBSyxRQUFRLFlBQVksS0FBSyxLQUFLLE9BQU8sS0FBSyxRQUFRLFlBQVksYUFBYSxPQUFPLEtBQUssUUFBUSxZQUFZLGNBQWMsT0FBTyxrQkFBa0IsS0FBSyxRQUFRLFNBQVMsS0FBSyxhQUFhLE1BQU0sV0FBVyxNQUFNLElBQUksTUFBTSx1RUFBdUU7RUFDM1MsS0FBSyxhQUFhO0VBQ2xCLEtBQUssY0FBYyxXQUFXLEtBQUssT0FBTztFQUMxQyxJQUFJLFlBQVksY0FBYyxDQUFDLG9CQUFvQixLQUFLLFNBQVMsV0FBVyxHQUFHLEtBQUssUUFBUSxjQUFjLENBQUMsQ0FBQyxPQUFPO0dBQ2xILE1BQU07R0FDTixPQUFPLEtBQUs7R0FDWixVQUFVO0VBQ1gsQ0FBQztFQUNELE1BQU0sVUFBVSxLQUFLLGFBQWE7RUFDbEMsSUFBSSxXQUFXLHNCQUFzQixLQUFLLGVBQWUsV0FBVyxLQUFLLFNBQVMsV0FBVyxHQUFHLEtBQUssY0FBYztFQUNuSCxLQUFLLGFBQWE7RUFDbEIsSUFBSSxZQUFZLEtBQUssa0JBQWtCLGFBQWEsa0JBQWtCLEtBQUssUUFBUSxTQUFTLEtBQUssYUFBYSxNQUFNLGtCQUFrQixZQUFZLFNBQVMsS0FBSyxhQUFhLEtBQUssa0JBQWtCLEtBQUssUUFBUSxXQUFXLEtBQUssYUFBYSxNQUFNLGtCQUFrQixZQUFZLFdBQVcsS0FBSyxhQUFhLElBQUksS0FBSyxvQkFBb0I7RUFDNVUsTUFBTSxzQkFBc0IsS0FBSyx3QkFBd0I7RUFDekQsSUFBSSxZQUFZLEtBQUssa0JBQWtCLGFBQWEsa0JBQWtCLEtBQUssUUFBUSxTQUFTLEtBQUssYUFBYSxNQUFNLGtCQUFrQixZQUFZLFNBQVMsS0FBSyxhQUFhLEtBQUssd0JBQXdCLEtBQUssMEJBQTBCLEtBQUssdUJBQXVCLG1CQUFtQjtDQUN6Ujs7Ozs7OztDQU9BLG9CQUFvQixTQUFTO0VBQzVCLE1BQU0sUUFBUSxLQUFLLFFBQVEsY0FBYyxDQUFDLENBQUMsTUFBTSxLQUFLLFNBQVMsT0FBTztFQUN0RSxNQUFNLFNBQVMsS0FBSyxhQUFhLE9BQU8sT0FBTztFQUMvQyxJQUFJLENBQUMsb0JBQW9CLEtBQUssaUJBQWlCLEdBQUcsTUFBTSxHQUFHO0dBQzFELEtBQUssaUJBQWlCO0dBQ3RCLEtBQUssd0JBQXdCLEtBQUs7R0FDbEMsS0FBSyxzQkFBc0IsS0FBSyxjQUFjO0VBQy9DO0VBQ0EsT0FBTztDQUNSOzs7Ozs7Ozs7Ozs7O0NBYUEsbUJBQW1CO0VBQ2xCLE9BQU8sS0FBSztDQUNiOzs7Ozs7O0NBT0EsWUFBWSxRQUFRLGVBQWU7RUFDbEMsT0FBTyxJQUFJLE1BQU0sUUFBUSxFQUFFLE1BQU0sUUFBUSxRQUFRO0dBQ2hELEtBQUssVUFBVSxHQUFHO0dBQ2xCLGdCQUFnQixHQUFHO0dBQ25CLE9BQU8sUUFBUSxJQUFJLFFBQVEsR0FBRztFQUMvQixFQUFFLENBQUM7Q0FDSjs7Ozs7OztDQU9BLFVBQVUsS0FBSztFQUNkLEtBQUssY0FBYyxJQUFJLEdBQUc7Q0FDM0I7Ozs7Q0FJQSxrQkFBa0I7RUFDakIsT0FBTyxLQUFLO0NBQ2I7Ozs7Ozs7Ozs7O0NBV0EsUUFBUSxFQUFFLEdBQUcsWUFBWSxDQUFDLEdBQUc7RUFDNUIsT0FBTyxLQUFLLE1BQU0sRUFBRSxHQUFHLFFBQVEsQ0FBQztDQUNqQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsZ0JBQWdCLFNBQVM7RUFDeEIsTUFBTSxtQkFBbUIsS0FBSyxRQUFRLG9CQUFvQixPQUFPO0VBQ2pFLE1BQU0sUUFBUSxLQUFLLFFBQVEsY0FBYyxDQUFDLENBQUMsTUFBTSxLQUFLLFNBQVMsZ0JBQWdCO0VBQy9FLElBQUksb0JBQW9CLENBQUM7RUFDekIsSUFBSTtFQUNKLE1BQU0sZUFBZSxJQUFJLFNBQVMsWUFBWTtHQUM3QyxlQUFlO0dBQ2YsY0FBYyxLQUFLLFFBQVEsY0FBYyxDQUFDLENBQUMsV0FBVyxVQUFVO0lBQy9ELElBQUksTUFBTSxTQUFTLGFBQWEsTUFBTSxNQUFNLGNBQWMsTUFBTSxhQUFhLE1BQU0sTUFBTSxTQUFTLEtBQUssR0FBRztLQUN6RyxZQUFZO0tBQ1osUUFBUSxLQUFLLGFBQWEsT0FBTyxnQkFBZ0IsQ0FBQztJQUNuRDtHQUNELENBQUM7RUFDRixDQUFDO0VBQ0QsT0FBTyxRQUFRLEtBQUssQ0FBQyxNQUFNLE1BQU0sQ0FBQyxDQUFDLFdBQVc7R0FDN0MsTUFBTSxTQUFTLEtBQUssYUFBYSxPQUFPLGdCQUFnQjtHQUN4RCxlQUFlLE1BQU07R0FDckIsT0FBTztFQUNSLENBQUMsQ0FBQyxDQUFDLGNBQWM7R0FDaEIsWUFBWTtFQUNiLENBQUMsR0FBRyxZQUFZLENBQUM7Q0FDbEI7Q0FDQSxNQUFNLGNBQWM7RUFDbkIsT0FBTyxLQUFLLGNBQWM7R0FDekIsR0FBRztHQUNILGVBQWUsYUFBYSxpQkFBaUI7RUFDOUMsQ0FBQyxDQUFDLENBQUMsV0FBVztHQUNiLEtBQUssYUFBYTtHQUNsQixPQUFPLEtBQUs7RUFDYixDQUFDO0NBQ0Y7Q0FDQSxjQUFjLGNBQWM7RUFDM0IsS0FBSyxhQUFhO0VBQ2xCLElBQUksVUFBVSxLQUFLLGNBQWMsTUFBTSxLQUFLLFNBQVMsWUFBWTtFQUNqRSxJQUFJLENBQUMsY0FBYyxjQUFjLFVBQVUsUUFBUSxNQUFNLElBQUk7RUFDN0QsT0FBTztDQUNSO0NBQ0EscUJBQXFCLFNBQVM7RUFDN0IsT0FBTyxDQUFDQyxXQUFTLEtBQUssa0JBQWtCLEtBQUssUUFBUSxTQUFTLEtBQUssYUFBYSxNQUFNLFNBQVMsZUFBZSxPQUFPO0NBQ3RIO0NBQ0Esc0JBQXNCO0VBQ3JCLEtBQUssbUJBQW1CO0VBQ3hCLE1BQU0sWUFBWSxrQkFBa0IsS0FBSyxRQUFRLFdBQVcsS0FBSyxhQUFhO0VBQzlFLElBQUksS0FBSyxlQUFlLFdBQVcsQ0FBQyxLQUFLLHFCQUFxQixTQUFTLEdBQUc7RUFDMUUsTUFBTSxVQUFVLGVBQWUsS0FBSyxlQUFlLGVBQWUsU0FBUyxJQUFJO0VBQy9FLEtBQUssa0JBQWtCLGVBQWUsaUJBQWlCO0dBQ3RELElBQUksQ0FBQyxLQUFLLGVBQWUsU0FBUyxLQUFLLGFBQWE7RUFDckQsR0FBRyxPQUFPO0NBQ1g7Q0FDQSwwQkFBMEI7RUFDekIsT0FBTyxrQkFBa0IsS0FBSyxRQUFRLGlCQUFpQixLQUFLLGFBQWEsS0FBSztDQUMvRTtDQUNBLHVCQUF1QixjQUFjO0VBQ3BDLEtBQUssc0JBQXNCO0VBQzNCLEtBQUssMEJBQTBCO0VBQy9CLElBQUksS0FBSyw0QkFBNEIsS0FBSyxDQUFDLEtBQUsscUJBQXFCLEtBQUssdUJBQXVCLEdBQUc7RUFDcEcsS0FBSyxxQkFBcUIsZUFBZSxrQkFBa0I7R0FDMUQsSUFBSSxLQUFLLFFBQVEsK0JBQStCLGFBQWEsVUFBVSxHQUFHLEtBQUssY0FBYztFQUM5RixHQUFHLEtBQUssdUJBQXVCO0NBQ2hDO0NBQ0EsZ0JBQWdCO0VBQ2YsS0FBSyxvQkFBb0I7RUFDekIsS0FBSyx1QkFBdUIsS0FBSyx3QkFBd0IsQ0FBQztDQUMzRDtDQUNBLHFCQUFxQjtFQUNwQixJQUFJLEtBQUssb0JBQW9CLEtBQUssR0FBRztHQUNwQyxlQUFlLGFBQWEsS0FBSyxlQUFlO0dBQ2hELEtBQUssa0JBQWtCLEtBQUs7RUFDN0I7Q0FDRDtDQUNBLHdCQUF3QjtFQUN2QixJQUFJLEtBQUssdUJBQXVCLEtBQUssR0FBRztHQUN2QyxlQUFlLGNBQWMsS0FBSyxrQkFBa0I7R0FDcEQsS0FBSyxxQkFBcUIsS0FBSztFQUNoQztDQUNEO0NBQ0EsYUFBYSxPQUFPLFNBQVM7RUFDNUIsTUFBTSxZQUFZLEtBQUs7RUFDdkIsTUFBTSxjQUFjLEtBQUs7RUFDekIsTUFBTSxhQUFhLEtBQUs7RUFDeEIsTUFBTSxrQkFBa0IsS0FBSztFQUM3QixNQUFNLG9CQUFvQixLQUFLO0VBQy9CLE1BQU0sb0JBQW9CLFVBQVUsWUFBWSxNQUFNLFFBQVEsS0FBSztFQUNuRSxNQUFNLEVBQUUsVUFBVTtFQUNsQixJQUFJLFdBQVcsRUFBRSxHQUFHLE1BQU07RUFDMUIsSUFBSSxvQkFBb0I7RUFDeEIsSUFBSTtFQUNKLElBQUksUUFBUSxvQkFBb0I7R0FDL0IsTUFBTSxVQUFVLEtBQUssYUFBYTtHQUNsQyxNQUFNLGVBQWUsQ0FBQyxXQUFXLG1CQUFtQixPQUFPLE9BQU87R0FDbEUsTUFBTSxrQkFBa0IsV0FBVyxzQkFBc0IsT0FBTyxXQUFXLFNBQVMsV0FBVztHQUMvRixJQUFJLGdCQUFnQixpQkFBaUIsV0FBVztJQUMvQyxHQUFHO0lBQ0gsR0FBRyxXQUFXLE1BQU0sTUFBTSxNQUFNLE9BQU87R0FDeEM7R0FDQSxJQUFJLFFBQVEsdUJBQXVCLGVBQWUsU0FBUyxjQUFjO0VBQzFFO0VBQ0EsSUFBSSxFQUFFLE9BQU8sZ0JBQWdCLFdBQVc7RUFDeEMsT0FBTyxTQUFTO0VBQ2hCLElBQUksYUFBYTtFQUNqQixJQUFJLFFBQVEsb0JBQW9CLEtBQUssS0FBSyxTQUFTLEtBQUssS0FBSyxXQUFXLFdBQVc7R0FDbEYsSUFBSTtHQUNKLElBQUksWUFBWSxxQkFBcUIsUUFBUSxvQkFBb0IsbUJBQW1CLGlCQUFpQjtJQUNwRyxrQkFBa0IsV0FBVztJQUM3QixhQUFhO0dBQ2QsT0FBTyxrQkFBa0IsT0FBTyxRQUFRLG9CQUFvQixhQUFhLFFBQVEsZ0JBQWdCLEtBQUssMkJBQTJCLE1BQU0sTUFBTSxLQUFLLHlCQUF5QixJQUFJLFFBQVE7R0FDdkwsSUFBSSxvQkFBb0IsS0FBSyxHQUFHO0lBQy9CLFNBQVM7SUFDVCxPQUFPLFlBQVksWUFBWSxNQUFNLGlCQUFpQixPQUFPO0lBQzdELG9CQUFvQjtHQUNyQjtFQUNEO0VBQ0EsSUFBSSxRQUFRLFVBQVUsU0FBUyxLQUFLLEtBQUssQ0FBQyxZQUFZO0dBQ3JELElBQUksY0FBYyxTQUFTLGlCQUFpQixRQUFRLFFBQVEsV0FBVyxLQUFLLFdBQVcsT0FBTyxLQUFLO1FBQzlGLElBQUk7SUFDUixLQUFLLFlBQVksUUFBUTtJQUN6QixPQUFPLFFBQVEsT0FBTyxJQUFJO0lBQzFCLE9BQU8sWUFBWSxZQUFZLE1BQU0sTUFBTSxPQUFPO0lBQ2xELEtBQUssZ0JBQWdCO0lBQ3JCLEtBQUssZUFBZTtHQUNyQixTQUFTLGFBQWE7SUFDckIsS0FBSyxlQUFlO0dBQ3JCO0VBQ0QsT0FBTyxJQUFJLFNBQVMsS0FBSyxHQUFHLEtBQUssZUFBZTtFQUNoRCxJQUFJLEtBQUssY0FBYztHQUN0QixRQUFRLEtBQUs7R0FDYixPQUFPLEtBQUs7R0FDWixpQkFBaUIsS0FBSyxJQUFJO0dBQzFCLFNBQVM7R0FDVCxvQkFBb0I7RUFDckI7RUFDQSxNQUFNLGFBQWEsU0FBUyxnQkFBZ0I7RUFDNUMsTUFBTSxZQUFZLFdBQVc7RUFDN0IsTUFBTSxVQUFVLFdBQVc7RUFDM0IsTUFBTSxZQUFZLGFBQWE7RUFDL0IsTUFBTSxVQUFVLFNBQVMsS0FBSztFQUM5QixPQUFPO0dBQ047R0FDQSxhQUFhLFNBQVM7R0FDdEI7R0FDQSxXQUFXLFdBQVc7R0FDdEI7R0FDQSxrQkFBa0I7R0FDbEI7R0FDQTtHQUNBLGVBQWUsU0FBUztHQUN4QjtHQUNBO0dBQ0EsY0FBYyxTQUFTO0dBQ3ZCLGVBQWUsU0FBUztHQUN4QixrQkFBa0IsU0FBUztHQUMzQixXQUFXLE1BQU0sVUFBVTtHQUMzQixxQkFBcUIsU0FBUyxrQkFBa0Isa0JBQWtCLG1CQUFtQixTQUFTLG1CQUFtQixrQkFBa0I7R0FDbkk7R0FDQSxjQUFjLGNBQWMsQ0FBQztHQUM3QixnQkFBZ0IsV0FBVyxDQUFDO0dBQzVCLFVBQVUsU0FBUyxnQkFBZ0I7R0FDbkM7R0FDQSxnQkFBZ0IsV0FBVztHQUMzQixTQUFTLFFBQVEsT0FBTyxPQUFPO0dBQy9CLFNBQVMsS0FBSztHQUNkLFdBQVcsa0JBQWtCLFFBQVEsU0FBUyxLQUFLLE1BQU07RUFDMUQ7Q0FDRDs7Ozs7O0NBTUEsZUFBZTtFQUNkLE1BQU0sYUFBYSxLQUFLO0VBQ3hCLE1BQU0sYUFBYSxLQUFLLGFBQWEsS0FBSyxlQUFlLEtBQUssT0FBTztFQUNyRSxLQUFLLHNCQUFzQixLQUFLLGNBQWM7RUFDOUMsS0FBSyx3QkFBd0IsS0FBSztFQUNsQyxJQUFJLEtBQUssb0JBQW9CLFNBQVMsS0FBSyxHQUFHLEtBQUssNEJBQTRCLEtBQUs7RUFDcEYsSUFBSSxvQkFBb0IsWUFBWSxVQUFVLEdBQUc7RUFDakQsS0FBSyxpQkFBaUI7RUFDdEIsTUFBTSw4QkFBOEI7R0FDbkMsSUFBSSxDQUFDLFlBQVksT0FBTztHQUN4QixNQUFNLEVBQUUsd0JBQXdCLEtBQUs7R0FDckMsTUFBTSwyQkFBMkIsT0FBTyx3QkFBd0IsYUFBYSxvQkFBb0IsSUFBSTtHQUNyRyxJQUFJLDZCQUE2QixTQUFTLENBQUMsNEJBQTRCLENBQUMsS0FBSyxjQUFjLE1BQU0sT0FBTztHQUN4RyxNQUFNLGdCQUFnQixJQUFJLElBQUksNEJBQTRCLEtBQUssYUFBYTtHQUM1RSxJQUFJLEtBQUssUUFBUSxjQUFjLGNBQWMsSUFBSSxPQUFPO0dBQ3hELE9BQU8sT0FBTyxLQUFLLEtBQUssY0FBYyxDQUFDLENBQUMsTUFBTSxRQUFRO0lBQ3JELE1BQU0sV0FBVztJQUNqQixPQUFPLEtBQUssZUFBZSxjQUFjLFdBQVcsYUFBYSxjQUFjLElBQUksUUFBUTtHQUM1RixDQUFDO0VBQ0Y7RUFDQSxNQUFNLGtCQUFrQixzQkFBc0I7RUFDOUMsY0FBYyxZQUFZO0dBQ3pCLElBQUksaUJBQWlCLEtBQUssVUFBVSxTQUFTLGFBQWE7SUFDekQsU0FBUyxLQUFLLGNBQWM7R0FDN0IsQ0FBQztHQUNELEtBQUssUUFBUSxjQUFjLENBQUMsQ0FBQyxPQUFPO0lBQ25DLE9BQU8sS0FBSztJQUNaLE1BQU07R0FDUCxDQUFDO0VBQ0YsQ0FBQztDQUNGO0NBQ0EsZUFBZTtFQUNkLE1BQU0sUUFBUSxLQUFLLFFBQVEsY0FBYyxDQUFDLENBQUMsTUFBTSxLQUFLLFNBQVMsS0FBSyxPQUFPO0VBQzNFLElBQUksVUFBVSxLQUFLLGVBQWU7RUFDbEMsTUFBTSxZQUFZLEtBQUs7RUFDdkIsS0FBSyxnQkFBZ0I7RUFDckIsS0FBSyw0QkFBNEIsTUFBTTtFQUN2QyxJQUFJLEtBQUssYUFBYSxHQUFHO0dBQ3hCLFdBQVcsZUFBZSxJQUFJO0dBQzlCLE1BQU0sWUFBWSxJQUFJO0VBQ3ZCO0NBQ0Q7O0NBRUEsZ0JBQWdCO0VBQ2YsS0FBSyxhQUFhO0VBQ2xCLElBQUksS0FBSyxhQUFhLEdBQUcsS0FBSyxjQUFjO0NBQzdDO0FBQ0Q7QUFDQSxTQUFTLGtCQUFrQixPQUFPLFNBQVM7Q0FDMUMsT0FBTyxrQkFBa0IsUUFBUSxTQUFTLEtBQUssTUFBTSxTQUFTLE1BQU0sTUFBTSxTQUFTLEtBQUssS0FBSyxFQUFFLE1BQU0sTUFBTSxXQUFXLFdBQVcsa0JBQWtCLFFBQVEsY0FBYyxLQUFLLE1BQU07QUFDckw7QUFDQSxTQUFTLG1CQUFtQixPQUFPLFNBQVM7Q0FDM0MsT0FBTyxrQkFBa0IsT0FBTyxPQUFPLEtBQUssTUFBTSxNQUFNLFNBQVMsS0FBSyxLQUFLLGNBQWMsT0FBTyxTQUFTLFFBQVEsY0FBYztBQUNoSTtBQUNBLFNBQVMsY0FBYyxPQUFPLFNBQVMsT0FBTztDQUM3QyxJQUFJLGtCQUFrQixRQUFRLFNBQVMsS0FBSyxNQUFNLFNBQVMsa0JBQWtCLFFBQVEsV0FBVyxLQUFLLE1BQU0sVUFBVTtFQUNwSCxNQUFNLFFBQVEsa0JBQWtCLE9BQU8sS0FBSztFQUM1QyxPQUFPLFVBQVUsWUFBWSxVQUFVLFNBQVMsUUFBUSxPQUFPLE9BQU87Q0FDdkU7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLHNCQUFzQixPQUFPLFdBQVcsU0FBUyxhQUFhO0NBQ3RFLFFBQVEsVUFBVSxhQUFhLGtCQUFrQixZQUFZLFNBQVMsS0FBSyxNQUFNLFdBQVcsQ0FBQyxRQUFRLFlBQVksTUFBTSxNQUFNLFdBQVcsWUFBWSxRQUFRLE9BQU8sT0FBTztBQUMzSztBQUNBLFNBQVMsUUFBUSxPQUFPLFNBQVM7Q0FDaEMsT0FBTyxrQkFBa0IsUUFBUSxTQUFTLEtBQUssTUFBTSxTQUFTLE1BQU0sY0FBYyxrQkFBa0IsUUFBUSxXQUFXLEtBQUssQ0FBQztBQUM5SDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFhQSxJQUFJLHdCQUF3QixjQUFjLGNBQWM7Q0FDdkQsWUFBWSxRQUFRLFNBQVM7RUFDNUIsTUFBTSxRQUFRLE9BQU87Q0FDdEI7Q0FDQSxjQUFjO0VBQ2IsTUFBTSxZQUFZO0VBQ2xCLEtBQUssZ0JBQWdCLEtBQUssY0FBYyxLQUFLLElBQUk7RUFDakQsS0FBSyxvQkFBb0IsS0FBSyxrQkFBa0IsS0FBSyxJQUFJO0NBQzFEOzs7Ozs7O0NBT0EsV0FBVyxTQUFTO0VBQ25CLFFBQVEsUUFBUTtFQUNoQixNQUFNLFdBQVcsT0FBTztDQUN6Qjs7Ozs7OztDQU9BLG9CQUFvQixTQUFTO0VBQzVCLFFBQVEsUUFBUTtFQUNoQixPQUFPLE1BQU0sb0JBQW9CLE9BQU87Q0FDekM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQkEsY0FBYyxTQUFTO0VBQ3RCLE9BQU8sS0FBSyxNQUFNO0dBQ2pCLEdBQUc7R0FDSCxNQUFNLEVBQUUsV0FBVyxFQUFFLFdBQVcsVUFBVSxFQUFFO0VBQzdDLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW1CQSxrQkFBa0IsU0FBUztFQUMxQixPQUFPLEtBQUssTUFBTTtHQUNqQixHQUFHO0dBQ0gsTUFBTSxFQUFFLFdBQVcsRUFBRSxXQUFXLFdBQVcsRUFBRTtFQUM5QyxDQUFDO0NBQ0Y7Q0FDQSxhQUFhLE9BQU8sU0FBUztFQUM1QixNQUFNLEVBQUUsVUFBVTtFQUNsQixNQUFNLGVBQWUsTUFBTSxhQUFhLE9BQU8sT0FBTztFQUN0RCxNQUFNLEVBQUUsWUFBWSxjQUFjLFNBQVMsbUJBQW1CO0VBQzlELE1BQU0saUJBQWlCLE1BQU0sV0FBVyxXQUFXO0VBQ25ELE1BQU0sdUJBQXVCLFdBQVcsbUJBQW1CO0VBQzNELE1BQU0scUJBQXFCLGNBQWMsbUJBQW1CO0VBQzVELE1BQU0sMkJBQTJCLFdBQVcsbUJBQW1CO0VBQy9ELE1BQU0seUJBQXlCLGNBQWMsbUJBQW1CO0VBQ2hFLE9BQU87R0FDTixHQUFHO0dBQ0gsZUFBZSxLQUFLO0dBQ3BCLG1CQUFtQixLQUFLO0dBQ3hCLGFBQWEsWUFBWSxTQUFTLE1BQU0sSUFBSTtHQUM1QyxpQkFBaUIsZ0JBQWdCLFNBQVMsTUFBTSxJQUFJO0dBQ3BEO0dBQ0E7R0FDQTtHQUNBO0dBQ0EsZ0JBQWdCLGtCQUFrQixDQUFDLHdCQUF3QixDQUFDO0dBQzVELGNBQWMsZ0JBQWdCLENBQUMsc0JBQXNCLENBQUM7RUFDdkQ7Q0FDRDtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JHQSxJQUFJLFdBQVcsY0FBYyxVQUFVO0NBQ3RDO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsWUFBWSxRQUFRO0VBQ25CLE1BQU07RUFDTixLQUFLLFVBQVUsT0FBTztFQUN0QixLQUFLLGFBQWEsT0FBTztFQUN6QixLQUFLLGlCQUFpQixPQUFPO0VBQzdCLEtBQUssYUFBYSxDQUFDO0VBQ25CLEtBQUssUUFBUSxPQUFPLFNBQVMsZ0JBQWdCO0VBQzdDLEtBQUssV0FBVyxPQUFPLE9BQU87RUFDOUIsS0FBSyxXQUFXO0NBQ2pCOztDQUVBLFdBQVcsU0FBUztFQUNuQixLQUFLLFVBQVU7RUFDZixLQUFLLGFBQWEsS0FBSyxRQUFRLE1BQU07Q0FDdEM7Ozs7Q0FJQSxJQUFJLE9BQU87RUFDVixPQUFPLEtBQUssUUFBUTtDQUNyQjs7Q0FFQSxZQUFZLFVBQVU7RUFDckIsSUFBSSxDQUFDLEtBQUssV0FBVyxTQUFTLFFBQVEsR0FBRztHQUN4QyxLQUFLLFdBQVcsS0FBSyxRQUFRO0dBQzdCLEtBQUssZUFBZTtHQUNwQixLQUFLLGVBQWUsT0FBTztJQUMxQixNQUFNO0lBQ04sVUFBVTtJQUNWO0dBQ0QsQ0FBQztFQUNGO0NBQ0Q7O0NBRUEsZUFBZSxVQUFVO0VBQ3hCLEtBQUssYUFBYSxLQUFLLFdBQVcsUUFBUSxNQUFNLE1BQU0sUUFBUTtFQUM5RCxLQUFLLFdBQVc7RUFDaEIsS0FBSyxlQUFlLE9BQU87R0FDMUIsTUFBTTtHQUNOLFVBQVU7R0FDVjtFQUNELENBQUM7Q0FDRjtDQUNBLGlCQUFpQjtFQUNoQixJQUFJLENBQUMsS0FBSyxXQUFXLFFBQVE7R0FDNUIsSUFBSSxLQUFLLE1BQU0sV0FBVyxXQUFXLEtBQUssV0FBVztRQUNoRCxLQUFLLGVBQWUsT0FBTyxJQUFJO0VBQ3JDO0NBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQkEsV0FBVztFQUNWLE9BQU8sS0FBSyxVQUFVLFNBQVMsTUFBTSxLQUFLLE1BQU0sV0FBVyxZQUFZLEtBQUssUUFBUSxLQUFLLE1BQU0sU0FBUyxJQUFJLFFBQVEsUUFBUTtDQUM3SDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQStCQSxNQUFNLFFBQVEsV0FBVztFQUN4QixNQUFNLG1CQUFtQjtHQUN4QixLQUFLLFVBQVUsRUFBRSxNQUFNLFdBQVcsQ0FBQztFQUNwQztFQUNBLE1BQU0sb0JBQW9CO0dBQ3pCLFFBQVEsS0FBSztHQUNiLE1BQU0sS0FBSyxRQUFRO0dBQ25CLGFBQWEsS0FBSyxRQUFRO0VBQzNCO0VBQ0EsTUFBTSxVQUFVLEtBQUssV0FBVyxjQUFjO0dBQzdDLFVBQVU7SUFDVCxJQUFJLENBQUMsS0FBSyxRQUFRLFlBQVksT0FBTyxRQUFRLHVCQUF1QixJQUFJLE1BQU0scUJBQXFCLENBQUM7SUFDcEcsT0FBTyxLQUFLLFFBQVEsV0FBVyxXQUFXLGlCQUFpQjtHQUM1RDtHQUNBLFNBQVMsY0FBYyxVQUFVO0lBQ2hDLEtBQUssVUFBVTtLQUNkLE1BQU07S0FDTjtLQUNBO0lBQ0QsQ0FBQztHQUNGO0dBQ0EsZUFBZTtJQUNkLEtBQUssVUFBVSxFQUFFLE1BQU0sUUFBUSxDQUFDO0dBQ2pDO0dBQ0E7R0FDQSxPQUFPLEtBQUssUUFBUSxTQUFTO0dBQzdCLFlBQVksS0FBSyxRQUFRO0dBQ3pCLGFBQWEsS0FBSyxRQUFRO0dBQzFCLGNBQWMsS0FBSyxlQUFlLE9BQU8sSUFBSTtFQUM5QyxDQUFDO0VBQ0QsTUFBTSxXQUFXLEtBQUssTUFBTSxXQUFXO0VBQ3ZDLE1BQU0sV0FBVyxDQUFDLFFBQVEsU0FBUztFQUNuQyxJQUFJO0dBQ0gsSUFBSSxVQUFVLFdBQVc7UUFDcEI7SUFDSixLQUFLLFVBQVU7S0FDZCxNQUFNO0tBQ047S0FDQTtJQUNELENBQUM7SUFDRCxJQUFJLEtBQUssZUFBZSxPQUFPLFVBQVUsTUFBTSxLQUFLLGVBQWUsT0FBTyxTQUFTLFdBQVcsTUFBTSxpQkFBaUI7SUFDckgsTUFBTSxVQUFVLE1BQU0sS0FBSyxRQUFRLFdBQVcsV0FBVyxpQkFBaUI7SUFDMUUsSUFBSSxZQUFZLEtBQUssTUFBTSxTQUFTLEtBQUssVUFBVTtLQUNsRCxNQUFNO0tBQ047S0FDQTtLQUNBO0lBQ0QsQ0FBQztHQUNGO0dBQ0EsTUFBTSxPQUFPLE1BQU0sUUFBUSxNQUFNO0dBQ2pDLE1BQU0sS0FBSyxlQUFlLE9BQU8sWUFBWSxNQUFNLFdBQVcsS0FBSyxNQUFNLFNBQVMsTUFBTSxpQkFBaUI7R0FDekcsTUFBTSxLQUFLLFFBQVEsWUFBWSxNQUFNLFdBQVcsS0FBSyxNQUFNLFNBQVMsaUJBQWlCO0dBQ3JGLE1BQU0sS0FBSyxlQUFlLE9BQU8sWUFBWSxNQUFNLE1BQU0sS0FBSyxNQUFNLFdBQVcsS0FBSyxNQUFNLFNBQVMsTUFBTSxpQkFBaUI7R0FDMUgsTUFBTSxLQUFLLFFBQVEsWUFBWSxNQUFNLE1BQU0sV0FBVyxLQUFLLE1BQU0sU0FBUyxpQkFBaUI7R0FDM0YsS0FBSyxVQUFVO0lBQ2QsTUFBTTtJQUNOO0dBQ0QsQ0FBQztHQUNELE9BQU87RUFDUixTQUFTLE9BQU87R0FDZixJQUFJO0lBQ0gsTUFBTSxLQUFLLGVBQWUsT0FBTyxVQUFVLE9BQU8sV0FBVyxLQUFLLE1BQU0sU0FBUyxNQUFNLGlCQUFpQjtHQUN6RyxTQUFTLEdBQUc7SUFDWCxRQUFRLE9BQU8sQ0FBQztHQUNqQjtHQUNBLElBQUk7SUFDSCxNQUFNLEtBQUssUUFBUSxVQUFVLE9BQU8sV0FBVyxLQUFLLE1BQU0sU0FBUyxpQkFBaUI7R0FDckYsU0FBUyxHQUFHO0lBQ1gsUUFBUSxPQUFPLENBQUM7R0FDakI7R0FDQSxJQUFJO0lBQ0gsTUFBTSxLQUFLLGVBQWUsT0FBTyxZQUFZLEtBQUssR0FBRyxPQUFPLEtBQUssTUFBTSxXQUFXLEtBQUssTUFBTSxTQUFTLE1BQU0saUJBQWlCO0dBQzlILFNBQVMsR0FBRztJQUNYLFFBQVEsT0FBTyxDQUFDO0dBQ2pCO0dBQ0EsSUFBSTtJQUNILE1BQU0sS0FBSyxRQUFRLFlBQVksS0FBSyxHQUFHLE9BQU8sV0FBVyxLQUFLLE1BQU0sU0FBUyxpQkFBaUI7R0FDL0YsU0FBUyxHQUFHO0lBQ1gsUUFBUSxPQUFPLENBQUM7R0FDakI7R0FDQSxLQUFLLFVBQVU7SUFDZCxNQUFNO0lBQ047R0FDRCxDQUFDO0dBQ0QsTUFBTTtFQUNQLFVBQVU7R0FDVCxJQUFJLEtBQUssYUFBYSxTQUFTLEtBQUssV0FBVyxLQUFLO0dBQ3BELEtBQUssZUFBZSxRQUFRLElBQUk7RUFDakM7Q0FDRDtDQUNBLFVBQVUsUUFBUTtFQUNqQixNQUFNLFdBQVcsVUFBVTtHQUMxQixRQUFRLE9BQU8sTUFBZjtJQUNDLEtBQUssVUFBVSxPQUFPO0tBQ3JCLEdBQUc7S0FDSCxjQUFjLE9BQU87S0FDckIsZUFBZSxPQUFPO0lBQ3ZCO0lBQ0EsS0FBSyxTQUFTLE9BQU87S0FDcEIsR0FBRztLQUNILFVBQVU7SUFDWDtJQUNBLEtBQUssWUFBWSxPQUFPO0tBQ3ZCLEdBQUc7S0FDSCxVQUFVO0lBQ1g7SUFDQSxLQUFLLFdBQVcsT0FBTztLQUN0QixHQUFHO0tBQ0gsU0FBUyxPQUFPO0tBQ2hCLE1BQU0sS0FBSztLQUNYLGNBQWM7S0FDZCxlQUFlO0tBQ2YsT0FBTztLQUNQLFVBQVUsT0FBTztLQUNqQixRQUFRO0tBQ1IsV0FBVyxPQUFPO0tBQ2xCLGFBQWEsS0FBSyxJQUFJO0lBQ3ZCO0lBQ0EsS0FBSyxXQUFXLE9BQU87S0FDdEIsR0FBRztLQUNILE1BQU0sT0FBTztLQUNiLGNBQWM7S0FDZCxlQUFlO0tBQ2YsT0FBTztLQUNQLFFBQVE7S0FDUixVQUFVO0lBQ1g7SUFDQSxLQUFLLFNBQVMsT0FBTztLQUNwQixHQUFHO0tBQ0gsTUFBTSxLQUFLO0tBQ1gsT0FBTyxPQUFPO0tBQ2QsY0FBYyxNQUFNLGVBQWU7S0FDbkMsZUFBZSxPQUFPO0tBQ3RCLFVBQVU7S0FDVixRQUFRO0lBQ1Q7R0FDRDtFQUNEO0VBQ0EsS0FBSyxRQUFRLFFBQVEsS0FBSyxLQUFLO0VBQy9CLGNBQWMsWUFBWTtHQUN6QixLQUFLLFdBQVcsU0FBUyxhQUFhO0lBQ3JDLFNBQVMsaUJBQWlCLE1BQU07R0FDakMsQ0FBQztHQUNELEtBQUssZUFBZSxPQUFPO0lBQzFCLFVBQVU7SUFDVixNQUFNO0lBQ047R0FDRCxDQUFDO0VBQ0YsQ0FBQztDQUNGO0FBQ0Q7QUFDQSxTQUFTLGtCQUFrQjtDQUMxQixPQUFPO0VBQ04sU0FBUyxLQUFLO0VBQ2QsTUFBTSxLQUFLO0VBQ1gsT0FBTztFQUNQLGNBQWM7RUFDZCxlQUFlO0VBQ2YsVUFBVTtFQUNWLFFBQVE7RUFDUixXQUFXLEtBQUs7RUFDaEIsYUFBYTtDQUNkO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDalJBLElBQUksZ0JBQWdCLGNBQWMsYUFBYTtDQUM5QztDQUNBO0NBQ0E7Q0FDQSxZQUFZLFNBQVMsQ0FBQyxHQUFHO0VBQ3hCLE1BQU07RUFDTixLQUFLLFNBQVM7RUFDZCxLQUFLLDZCQUE2QixJQUFJLElBQUk7RUFDMUMsS0FBSywwQkFBMEIsSUFBSSxJQUFJO0VBQ3ZDLEtBQUssY0FBYztDQUNwQjs7Q0FFQSxNQUFNLFFBQVEsU0FBUyxPQUFPO0VBQzdCLE1BQU0sV0FBVyxJQUFJLFNBQVM7R0FDN0I7R0FDQSxlQUFlO0dBQ2YsWUFBWSxFQUFFLEtBQUs7R0FDbkIsU0FBUyxPQUFPLHVCQUF1QixPQUFPO0dBQzlDO0VBQ0QsQ0FBQztFQUNELEtBQUssSUFBSSxRQUFRO0VBQ2pCLE9BQU87Q0FDUjs7Q0FFQSxJQUFJLFVBQVU7RUFDYixLQUFLLFdBQVcsSUFBSSxRQUFRO0VBQzVCLE1BQU0sUUFBUSxTQUFTLFFBQVE7RUFDL0IsSUFBSSxPQUFPLFVBQVUsVUFBVTtHQUM5QixNQUFNLGtCQUFrQixLQUFLLFFBQVEsSUFBSSxLQUFLO0dBQzlDLElBQUksaUJBQWlCLGdCQUFnQixLQUFLLFFBQVE7UUFDN0MsS0FBSyxRQUFRLElBQUksT0FBTyxDQUFDLFFBQVEsQ0FBQztFQUN4QztFQUNBLEtBQUssT0FBTztHQUNYLE1BQU07R0FDTjtFQUNELENBQUM7Q0FDRjs7Q0FFQSxPQUFPLFVBQVU7RUFDaEIsSUFBSSxLQUFLLFdBQVcsT0FBTyxRQUFRLEdBQUc7R0FDckMsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUMvQixJQUFJLE9BQU8sVUFBVSxVQUFVO0lBQzlCLE1BQU0sa0JBQWtCLEtBQUssUUFBUSxJQUFJLEtBQUs7SUFDOUMsSUFBSSxpQkFBaUI7S0FDcEIsSUFBSSxnQkFBZ0IsU0FBUyxHQUFHO01BQy9CLE1BQU0sUUFBUSxnQkFBZ0IsUUFBUSxRQUFRO01BQzlDLElBQUksVUFBVSxJQUFJLGdCQUFnQixPQUFPLE9BQU8sQ0FBQztLQUNsRCxPQUFPLElBQUksZ0JBQWdCLE9BQU8sVUFBVSxLQUFLLFFBQVEsT0FBTyxLQUFLO0lBQ3RFO0dBQ0Q7RUFDRDtFQUNBLEtBQUssT0FBTztHQUNYLE1BQU07R0FDTjtFQUNELENBQUM7Q0FDRjs7Q0FFQSxPQUFPLFVBQVU7RUFDaEIsTUFBTSxRQUFRLFNBQVMsUUFBUTtFQUMvQixJQUFJLE9BQU8sVUFBVSxVQUFVO0dBQzlCLE1BQU0sdUJBQXVCLEtBQUssUUFBUSxJQUFJLEtBQUssQ0FBQyxFQUFFLE1BQU0sTUFBTSxFQUFFLE1BQU0sV0FBVyxTQUFTO0dBQzlGLE9BQU8sQ0FBQyx3QkFBd0IseUJBQXlCO0VBQzFELE9BQU8sT0FBTztDQUNmOztDQUVBLFFBQVEsVUFBVTtFQUNqQixNQUFNLFFBQVEsU0FBUyxRQUFRO0VBQy9CLElBQUksT0FBTyxVQUFVLFVBQVUsUUFBUSxLQUFLLFFBQVEsSUFBSSxLQUFLLENBQUMsRUFBRSxNQUFNLE1BQU0sTUFBTSxZQUFZLEVBQUUsTUFBTSxRQUFRLEVBQUEsRUFBSSxTQUFTLEtBQUssUUFBUSxRQUFRO09BQzNJLE9BQU8sUUFBUSxRQUFRO0NBQzdCOzs7Ozs7Ozs7OztDQVdBLFFBQVE7RUFDUCxjQUFjLFlBQVk7R0FDekIsS0FBSyxXQUFXLFNBQVMsYUFBYTtJQUNyQyxLQUFLLE9BQU87S0FDWCxNQUFNO0tBQ047SUFDRCxDQUFDO0dBQ0YsQ0FBQztHQUNELEtBQUssV0FBVyxNQUFNO0dBQ3RCLEtBQUssUUFBUSxNQUFNO0VBQ3BCLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Q0FjQSxTQUFTO0VBQ1IsT0FBTyxNQUFNLEtBQUssS0FBSyxVQUFVO0NBQ2xDOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JBLEtBQUssU0FBUztFQUNiLE1BQU0sbUJBQW1CO0dBQ3hCLE9BQU87R0FDUCxHQUFHO0VBQ0o7RUFDQSxPQUFPLEtBQUssT0FBTyxDQUFDLENBQUMsTUFBTSxhQUFhLGNBQWMsa0JBQWtCLFFBQVEsQ0FBQztDQUNsRjs7Ozs7Ozs7Ozs7Ozs7OztDQWdCQSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0VBQ3JCLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxRQUFRLGFBQWEsY0FBYyxTQUFTLFFBQVEsQ0FBQztDQUMzRTs7Q0FFQSxPQUFPLE9BQU87RUFDYixjQUFjLFlBQVk7R0FDekIsS0FBSyxVQUFVLFNBQVMsYUFBYTtJQUNwQyxTQUFTLEtBQUs7R0FDZixDQUFDO0VBQ0YsQ0FBQztDQUNGOztDQUVBLHdCQUF3QjtFQUN2QixNQUFNLGtCQUFrQixLQUFLLE9BQU8sQ0FBQyxDQUFDLFFBQVEsTUFBTSxFQUFFLE1BQU0sUUFBUTtFQUNwRSxPQUFPLGNBQWMsWUFBWSxRQUFRLElBQUksZ0JBQWdCLEtBQUssYUFBYSxTQUFTLFNBQVMsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQztDQUNqSDtBQUNEO0FBQ0EsU0FBUyxTQUFTLFVBQVU7Q0FDM0IsT0FBTyxTQUFTLFFBQVEsT0FBTztBQUNoQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbktBLElBQUksbUJBQW1CLGNBQWMsYUFBYTtDQUNqRDtDQUNBLGlCQUFpQixLQUFLO0NBQ3RCO0NBQ0E7Q0FDQSxZQUFZLFFBQVEsU0FBUztFQUM1QixNQUFNO0VBQ04sS0FBSyxVQUFVO0VBQ2YsS0FBSyxXQUFXLE9BQU87RUFDdkIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssY0FBYztDQUNwQjtDQUNBLGNBQWM7RUFDYixLQUFLLFNBQVMsS0FBSyxPQUFPLEtBQUssSUFBSTtFQUNuQyxLQUFLLFFBQVEsS0FBSyxNQUFNLEtBQUssSUFBSTtDQUNsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsV0FBVyxTQUFTO0VBQ25CLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLEtBQUssVUFBVSxLQUFLLFFBQVEsdUJBQXVCLE9BQU87RUFDMUQsSUFBSSxDQUFDLG9CQUFvQixLQUFLLFNBQVMsV0FBVyxHQUFHLEtBQUssUUFBUSxpQkFBaUIsQ0FBQyxDQUFDLE9BQU87R0FDM0YsTUFBTTtHQUNOLFVBQVUsS0FBSztHQUNmLFVBQVU7RUFDWCxDQUFDO0VBQ0QsSUFBSSxhQUFhLGVBQWUsS0FBSyxRQUFRLGVBQWUsUUFBUSxZQUFZLFdBQVcsTUFBTSxRQUFRLEtBQUssUUFBUSxXQUFXLEdBQUcsS0FBSyxNQUFNO09BQzFJLElBQUksS0FBSyxrQkFBa0IsTUFBTSxXQUFXLFdBQVcsS0FBSyxpQkFBaUIsV0FBVyxLQUFLLE9BQU87Q0FDMUc7Q0FDQSxjQUFjO0VBQ2IsSUFBSSxLQUFLLFVBQVUsU0FBUyxLQUFLLEtBQUssa0JBQWtCO0dBQ3ZELEtBQUssaUJBQWlCLFlBQVksSUFBSTtHQUN0QyxLQUFLLGNBQWM7RUFDcEI7Q0FDRDtDQUNBLGdCQUFnQjtFQUNmLElBQUksQ0FBQyxLQUFLLGFBQWEsR0FBRyxLQUFLLGtCQUFrQixlQUFlLElBQUk7Q0FDckU7O0NBRUEsaUJBQWlCLFFBQVE7RUFDeEIsS0FBSyxjQUFjO0VBQ25CLEtBQUssUUFBUSxNQUFNO0NBQ3BCOzs7Ozs7Q0FNQSxtQkFBbUI7RUFDbEIsT0FBTyxLQUFLO0NBQ2I7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUJBLFFBQVE7RUFDUCxLQUFLLGtCQUFrQixlQUFlLElBQUk7RUFDMUMsS0FBSyxtQkFBbUIsS0FBSztFQUM3QixLQUFLLGNBQWM7RUFDbkIsS0FBSyxRQUFRO0NBQ2Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQkEsT0FBTyxXQUFXLFNBQVM7RUFDMUIsS0FBSyxpQkFBaUI7RUFDdEIsS0FBSyxrQkFBa0IsZUFBZSxJQUFJO0VBQzFDLEtBQUssbUJBQW1CLEtBQUssUUFBUSxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sS0FBSyxTQUFTLEtBQUssT0FBTztFQUN4RixLQUFLLGlCQUFpQixZQUFZLElBQUk7RUFDdEMsT0FBTyxLQUFLLGlCQUFpQixRQUFRLFNBQVM7Q0FDL0M7Q0FDQSxnQkFBZ0I7RUFDZixNQUFNLFFBQVEsS0FBSyxrQkFBa0IsU0FBUyxnQkFBZ0I7RUFDOUQsS0FBSyxpQkFBaUI7R0FDckIsR0FBRztHQUNILFdBQVcsTUFBTSxXQUFXO0dBQzVCLFdBQVcsTUFBTSxXQUFXO0dBQzVCLFNBQVMsTUFBTSxXQUFXO0dBQzFCLFFBQVEsTUFBTSxXQUFXO0dBQ3pCLFFBQVEsS0FBSztHQUNiLE9BQU8sS0FBSztFQUNiO0NBQ0Q7Q0FDQSxRQUFRLFFBQVE7RUFDZixjQUFjLFlBQVk7R0FDekIsSUFBSSxLQUFLLGtCQUFrQixLQUFLLGFBQWEsR0FBRztJQUMvQyxNQUFNLFlBQVksS0FBSyxlQUFlO0lBQ3RDLE1BQU0saUJBQWlCLEtBQUssZUFBZTtJQUMzQyxNQUFNLFVBQVU7S0FDZixRQUFRLEtBQUs7S0FDYixNQUFNLEtBQUssUUFBUTtLQUNuQixhQUFhLEtBQUssUUFBUTtJQUMzQjtJQUNBLElBQUksUUFBUSxTQUFTLFdBQVc7S0FDL0IsSUFBSTtNQUNILEtBQUssZUFBZSxZQUFZLE9BQU8sTUFBTSxXQUFXLGdCQUFnQixPQUFPO0tBQ2hGLFNBQVMsR0FBRztNQUNYLFFBQVEsT0FBTyxDQUFDO0tBQ2pCO0tBQ0EsSUFBSTtNQUNILEtBQUssZUFBZSxZQUFZLE9BQU8sTUFBTSxNQUFNLFdBQVcsZ0JBQWdCLE9BQU87S0FDdEYsU0FBUyxHQUFHO01BQ1gsUUFBUSxPQUFPLENBQUM7S0FDakI7SUFDRCxPQUFPLElBQUksUUFBUSxTQUFTLFNBQVM7S0FDcEMsSUFBSTtNQUNILEtBQUssZUFBZSxVQUFVLE9BQU8sT0FBTyxXQUFXLGdCQUFnQixPQUFPO0tBQy9FLFNBQVMsR0FBRztNQUNYLFFBQVEsT0FBTyxDQUFDO0tBQ2pCO0tBQ0EsSUFBSTtNQUNILEtBQUssZUFBZSxZQUFZLEtBQUssR0FBRyxPQUFPLE9BQU8sV0FBVyxnQkFBZ0IsT0FBTztLQUN6RixTQUFTLEdBQUc7TUFDWCxRQUFRLE9BQU8sQ0FBQztLQUNqQjtJQUNEO0dBQ0Q7R0FDQSxLQUFLLFVBQVUsU0FBUyxhQUFhO0lBQ3BDLFNBQVMsS0FBSyxjQUFjO0dBQzdCLENBQUM7RUFDRixDQUFDO0NBQ0Y7QUFDRDs7O0FDbExBLFNBQVMsV0FBVyxRQUFRLFFBQVE7Q0FDbkMsTUFBTSxhQUFhLElBQUksSUFBSSxNQUFNO0NBQ2pDLE9BQU8sT0FBTyxRQUFRLE1BQU0sQ0FBQyxXQUFXLElBQUksQ0FBQyxDQUFDO0FBQy9DOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW9CQSxJQUFJLGtCQUFrQixjQUFjLGFBQWE7Q0FDaEQ7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsbUJBQW1CLENBQUM7Q0FDcEIsWUFBWSxRQUFRLFNBQVMsU0FBUztFQUNyQyxNQUFNO0VBQ04sS0FBSyxVQUFVO0VBQ2YsS0FBSyxXQUFXO0VBQ2hCLEtBQUssV0FBVyxDQUFDO0VBQ2pCLEtBQUssYUFBYSxDQUFDO0VBQ25CLEtBQUssVUFBVSxDQUFDO0VBQ2hCLEtBQUssV0FBVyxPQUFPO0NBQ3hCO0NBQ0EsY0FBYztFQUNiLElBQUksS0FBSyxVQUFVLFNBQVMsR0FBRyxLQUFLLFdBQVcsU0FBUyxhQUFhO0dBQ3BFLFNBQVMsV0FBVyxXQUFXO0lBQzlCLEtBQUssVUFBVSxVQUFVLE1BQU07R0FDaEMsQ0FBQztFQUNGLENBQUM7Q0FDRjtDQUNBLGdCQUFnQjtFQUNmLElBQUksQ0FBQyxLQUFLLFVBQVUsTUFBTSxLQUFLLFFBQVE7Q0FDeEM7Ozs7O0NBS0EsVUFBVTtFQUNULEtBQUssNEJBQTRCLElBQUksSUFBSTtFQUN6QyxLQUFLLFdBQVcsU0FBUyxhQUFhO0dBQ3JDLFNBQVMsUUFBUTtFQUNsQixDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7OztDQWVBLFdBQVcsU0FBUyxTQUFTO0VBQzVCLEtBQUssV0FBVztFQUNoQixLQUFLLFdBQVc7RUFDMkI7R0FDMUMsTUFBTSxjQUFjLFFBQVEsS0FBSyxVQUFVLEtBQUssUUFBUSxvQkFBb0IsS0FBSyxDQUFDLENBQUMsU0FBUztHQUM1RixJQUFJLElBQUksSUFBSSxXQUFXLENBQUMsQ0FBQyxTQUFTLFlBQVksUUFBUSxRQUFRLEtBQUssdUZBQXVGO0VBQzNKO0VBQ0EsY0FBYyxZQUFZO0dBQ3pCLE1BQU0sZ0JBQWdCLEtBQUs7R0FDM0IsTUFBTSxxQkFBcUIsS0FBSyx1QkFBdUIsS0FBSyxRQUFRO0dBQ3BFLG1CQUFtQixTQUFTLFVBQVUsTUFBTSxTQUFTLFdBQVcsTUFBTSxxQkFBcUIsQ0FBQztHQUM1RixNQUFNLGVBQWUsbUJBQW1CLEtBQUssVUFBVSxNQUFNLFFBQVE7R0FDckUsTUFBTSxZQUFZLGFBQWEsS0FBSyxhQUFhLFNBQVMsaUJBQWlCLENBQUM7R0FDNUUsTUFBTSxrQkFBa0IsY0FBYyxXQUFXLGFBQWE7R0FDOUQsTUFBTSxpQkFBaUIsYUFBYSxNQUFNLFVBQVUsVUFBVSxhQUFhLGNBQWMsTUFBTTtHQUMvRixNQUFNLHNCQUFzQixtQkFBbUI7R0FDL0MsTUFBTSxrQkFBa0Isc0JBQXNCLE9BQU8sVUFBVSxNQUFNLFFBQVEsVUFBVTtJQUN0RixNQUFNLE9BQU8sS0FBSyxRQUFRO0lBQzFCLE9BQU8sQ0FBQyxRQUFRLENBQUMsb0JBQW9CLFFBQVEsSUFBSTtHQUNsRCxDQUFDO0dBQ0QsSUFBSSxDQUFDLHVCQUF1QixDQUFDLGlCQUFpQjtHQUM5QyxJQUFJLHFCQUFxQjtJQUN4QixLQUFLLG1CQUFtQjtJQUN4QixLQUFLLGFBQWE7R0FDbkI7R0FDQSxLQUFLLFVBQVU7R0FDZixJQUFJLENBQUMsS0FBSyxhQUFhLEdBQUc7R0FDMUIsSUFBSSxxQkFBcUI7SUFDeEIsV0FBVyxlQUFlLFlBQVksQ0FBQyxDQUFDLFNBQVMsYUFBYTtLQUM3RCxTQUFTLFFBQVE7SUFDbEIsQ0FBQztJQUNELFdBQVcsY0FBYyxhQUFhLENBQUMsQ0FBQyxTQUFTLGFBQWE7S0FDN0QsU0FBUyxXQUFXLFdBQVc7TUFDOUIsS0FBSyxVQUFVLFVBQVUsTUFBTTtLQUNoQyxDQUFDO0lBQ0YsQ0FBQztHQUNGO0dBQ0EsS0FBSyxRQUFRO0VBQ2QsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7Q0FZQSxtQkFBbUI7RUFDbEIsT0FBTyxLQUFLO0NBQ2I7Ozs7O0NBS0EsYUFBYTtFQUNaLE9BQU8sS0FBSyxXQUFXLEtBQUssYUFBYSxTQUFTLGdCQUFnQixDQUFDO0NBQ3BFOzs7Ozs7Q0FNQSxlQUFlO0VBQ2QsT0FBTyxLQUFLO0NBQ2I7Ozs7Ozs7O0NBUUEsb0JBQW9CLFNBQVMsU0FBUztFQUNyQyxNQUFNLFVBQVUsS0FBSyx1QkFBdUIsT0FBTztFQUNuRCxNQUFNLFNBQVMsUUFBUSxLQUFLLFVBQVUsTUFBTSxTQUFTLG9CQUFvQixNQUFNLHFCQUFxQixDQUFDO0VBQ3JHLE1BQU0sY0FBYyxRQUFRLEtBQUssVUFBVSxNQUFNLHNCQUFzQixTQUFTO0VBQ2hGLE9BQU87R0FDTjtJQUNDLE1BQU07SUFDTixPQUFPLEtBQUssZUFBZSxLQUFLLFFBQVEsU0FBUyxXQUFXO0dBQzdEO1NBQ007SUFDTCxPQUFPLEtBQUssYUFBYSxRQUFRLE9BQU87R0FDekM7RUFDRDtDQUNEO0NBQ0EsYUFBYSxRQUFRLFNBQVM7RUFDN0IsTUFBTSwrQkFBK0IsSUFBSSxJQUFJO0VBQzdDLE9BQU8sUUFBUSxLQUFLLE9BQU8sVUFBVTtHQUNwQyxNQUFNLGlCQUFpQixPQUFPO0dBQzlCLE9BQU8sQ0FBQyxNQUFNLHNCQUFzQixzQkFBc0IsTUFBTSxTQUFTLFlBQVksaUJBQWlCLGlCQUFpQjtJQUN0SCxJQUFJLENBQUMsYUFBYSxJQUFJLFlBQVksR0FBRztLQUNwQyxhQUFhLElBQUksWUFBWTtLQUM3QixRQUFRLFNBQVMsTUFBTTtNQUN0QixFQUFFLFNBQVMsVUFBVSxZQUFZO0tBQ2xDLENBQUM7SUFDRjtHQUNELENBQUMsSUFBSTtFQUNOLENBQUM7Q0FDRjtDQUNBLGVBQWUsT0FBTyxTQUFTLGFBQWE7RUFDM0MsSUFBSSxTQUFTO0dBQ1osTUFBTSxhQUFhLEtBQUs7R0FDeEIsTUFBTSxxQkFBcUIsZ0JBQWdCLEtBQUssS0FBSyxlQUFlLEtBQUssTUFBTSxXQUFXLFdBQVcsWUFBWSxVQUFVLFlBQVksTUFBTSxNQUFNLE1BQU0sU0FBUyxXQUFXLEVBQUU7R0FDL0ssSUFBSSxLQUFLLFlBQVksS0FBSyxlQUFlLHNCQUFzQixZQUFZLEtBQUssY0FBYztJQUM3RixLQUFLLGVBQWU7SUFDcEIsS0FBSyxjQUFjLEtBQUs7SUFDeEIsSUFBSSxnQkFBZ0IsS0FBSyxHQUFHLEtBQUssbUJBQW1CO0lBQ3BELEtBQUssa0JBQWtCLGlCQUFpQixLQUFLLGlCQUFpQixRQUFRLEtBQUssQ0FBQztHQUM3RTtHQUNBLE9BQU8sS0FBSztFQUNiO0VBQ0EsT0FBTztDQUNSO0NBQ0EscUJBQXFCO0VBQ3BCLE9BQU8sQ0FBQyxLQUFLLFVBQVUsV0FBVyxLQUFLLFdBQVcsTUFBTSxVQUFVLFVBQVU7R0FDM0UsT0FBTyxTQUFTLFFBQVEsWUFBWSxLQUFLLFFBQVEsTUFBTSxFQUFFLFNBQVMsS0FBSztFQUN4RSxDQUFDO0NBQ0Y7Q0FDQSx1QkFBdUIsU0FBUztFQUMvQixNQUFNLG1DQUFtQyxJQUFJLElBQUk7RUFDakQsS0FBSyxXQUFXLFNBQVMsYUFBYTtHQUNyQyxNQUFNLE1BQU0sU0FBUyxRQUFRO0dBQzdCLElBQUksQ0FBQyxLQUFLO0dBQ1YsTUFBTSxvQkFBb0IsaUJBQWlCLElBQUksR0FBRztHQUNsRCxJQUFJLG1CQUFtQixrQkFBa0IsS0FBSyxRQUFRO1FBQ2pELGlCQUFpQixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUM7RUFDMUMsQ0FBQztFQUNELE1BQU0sWUFBWSxDQUFDO0VBQ25CLFFBQVEsU0FBUyxZQUFZO0dBQzVCLE1BQU0sbUJBQW1CLEtBQUssUUFBUSxvQkFBb0IsT0FBTztHQUNqRSxNQUFNLFdBQVcsaUJBQWlCLElBQUksaUJBQWlCLFNBQVMsQ0FBQyxFQUFFLE1BQU0sS0FBSyxJQUFJLGNBQWMsS0FBSyxTQUFTLGdCQUFnQjtHQUM5SCxVQUFVLEtBQUs7SUFDZCx1QkFBdUI7SUFDdkI7R0FDRCxDQUFDO0VBQ0YsQ0FBQztFQUNELE9BQU87Q0FDUjtDQUNBLFVBQVUsVUFBVSxRQUFRO0VBQzNCLE1BQU0sUUFBUSxLQUFLLFdBQVcsUUFBUSxRQUFRO0VBQzlDLElBQUksVUFBVSxJQUFJO0dBQ2pCLEtBQUssVUFBVSxLQUFLLFFBQVEsTUFBTTtHQUNsQyxLQUFLLFFBQVEsU0FBUztHQUN0QixLQUFLLFFBQVE7RUFDZDtDQUNEO0NBQ0EsVUFBVTtFQUNULElBQUksS0FBSyxhQUFhLEdBQUc7R0FDeEIsTUFBTSxvQkFBb0IsS0FBSyxtQkFBbUI7R0FDbEQsTUFBTSxpQkFBaUIsS0FBSztHQUM1QixNQUFNLFlBQVksb0JBQW9CLGlCQUFpQixLQUFLLGVBQWUsS0FBSyxhQUFhLEtBQUssU0FBUyxLQUFLLGdCQUFnQixHQUFHLEtBQUssVUFBVSxPQUFPO0dBQ3pKLElBQUkscUJBQXFCLG1CQUFtQixXQUFXLGNBQWMsWUFBWTtJQUNoRixLQUFLLFVBQVUsU0FBUyxhQUFhO0tBQ3BDLFNBQVMsS0FBSyxPQUFPO0lBQ3RCLENBQUM7R0FDRixDQUFDO0VBQ0Y7Q0FDRDtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9OQSxJQUFJLGFBQWEsY0FBYyxhQUFhO0NBQzNDO0NBQ0EsWUFBWSxTQUFTLENBQUMsR0FBRztFQUN4QixNQUFNO0VBQ04sS0FBSyxTQUFTO0VBQ2QsS0FBSywyQkFBMkIsSUFBSSxJQUFJO0NBQ3pDOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxNQUFNLFFBQVEsU0FBUyxPQUFPO0VBQzdCLE1BQU0sV0FBVyxRQUFRO0VBQ3pCLE1BQU0sWUFBWSxRQUFRLGFBQWEsc0JBQXNCLFVBQVUsT0FBTztFQUM5RSxJQUFJLFFBQVEsS0FBSyxJQUFJLFNBQVM7RUFDOUIsSUFBSSxDQUFDLE9BQU87R0FDWCxRQUFRLElBQUksTUFBTTtJQUNqQjtJQUNBO0lBQ0E7SUFDQSxTQUFTLE9BQU8sb0JBQW9CLE9BQU87SUFDM0M7SUFDQSxnQkFBZ0IsT0FBTyxpQkFBaUIsUUFBUTtHQUNqRCxDQUFDO0dBQ0QsS0FBSyxJQUFJLEtBQUs7RUFDZjtFQUNBLE9BQU87Q0FDUjs7Q0FFQSxJQUFJLE9BQU87RUFDVixJQUFJLENBQUMsS0FBSyxTQUFTLElBQUksTUFBTSxTQUFTLEdBQUc7R0FDeEMsS0FBSyxTQUFTLElBQUksTUFBTSxXQUFXLEtBQUs7R0FDeEMsS0FBSyxPQUFPO0lBQ1gsTUFBTTtJQUNOO0dBQ0QsQ0FBQztFQUNGO0NBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUJBLE9BQU8sT0FBTztFQUNiLElBQUksS0FBSyxTQUFTLElBQUksTUFBTSxTQUFTLE1BQU0sT0FBTztHQUNqRCxNQUFNLFFBQVE7R0FDZCxLQUFLLFNBQVMsT0FBTyxNQUFNLFNBQVM7R0FDcEMsS0FBSyxPQUFPO0lBQ1gsTUFBTTtJQUNOO0dBQ0QsQ0FBQztFQUNGO0NBQ0Q7Ozs7Ozs7Ozs7O0NBV0EsUUFBUTtFQUNQLGNBQWMsWUFBWTtHQUN6QixLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVTtJQUNoQyxLQUFLLE9BQU8sS0FBSztHQUNsQixDQUFDO0VBQ0YsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxJQUFJLFdBQVc7RUFDZCxPQUFPLEtBQUssU0FBUyxJQUFJLFNBQVM7Q0FDbkM7Ozs7Ozs7Ozs7O0NBV0EsU0FBUztFQUNSLE9BQU8sQ0FBQyxHQUFHLEtBQUssU0FBUyxPQUFPLENBQUM7Q0FDbEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQkEsS0FBSyxTQUFTO0VBQ2IsTUFBTSxtQkFBbUI7R0FDeEIsT0FBTztHQUNQLEdBQUc7RUFDSjtFQUNBLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxNQUFNLFVBQVUsV0FBVyxrQkFBa0IsS0FBSyxDQUFDO0NBQ3pFOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JBLFFBQVEsVUFBVSxDQUFDLEdBQUc7RUFDckIsTUFBTSxVQUFVLEtBQUssT0FBTztFQUM1QixPQUFPLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTLElBQUksUUFBUSxRQUFRLFVBQVUsV0FBVyxTQUFTLEtBQUssQ0FBQyxJQUFJO0NBQ2xHOztDQUVBLE9BQU8sT0FBTztFQUNiLGNBQWMsWUFBWTtHQUN6QixLQUFLLFVBQVUsU0FBUyxhQUFhO0lBQ3BDLFNBQVMsS0FBSztHQUNmLENBQUM7RUFDRixDQUFDO0NBQ0Y7O0NBRUEsVUFBVTtFQUNULGNBQWMsWUFBWTtHQUN6QixLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVTtJQUNoQyxNQUFNLFFBQVE7R0FDZixDQUFDO0VBQ0YsQ0FBQztDQUNGOztDQUVBLFdBQVc7RUFDVixjQUFjLFlBQVk7R0FDekIsS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTLFVBQVU7SUFDaEMsTUFBTSxTQUFTO0dBQ2hCLENBQUM7RUFDRixDQUFDO0NBQ0Y7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUxBLElBQUksY0FBYyxNQUFNO0NBQ3ZCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxZQUFZLFNBQVMsQ0FBQyxHQUFHO0VBQ3hCLEtBQUssY0FBYyxPQUFPLGNBQWMsSUFBSSxXQUFXO0VBQ3ZELEtBQUssaUJBQWlCLE9BQU8saUJBQWlCLElBQUksY0FBYztFQUNoRSxLQUFLLGtCQUFrQixPQUFPLGtCQUFrQixDQUFDO0VBQ2pELEtBQUssaUNBQWlDLElBQUksSUFBSTtFQUM5QyxLQUFLLG9DQUFvQyxJQUFJLElBQUk7RUFDakQsS0FBSyxjQUFjO0NBQ3BCOzs7Ozs7O0NBT0EsUUFBUTtFQUNQLEtBQUs7RUFDTCxJQUFJLEtBQUssZ0JBQWdCLEdBQUc7RUFDNUIsS0FBSyxvQkFBb0IsYUFBYSxVQUFVLE9BQU8sWUFBWTtHQUNsRSxJQUFJLFNBQVM7SUFDWixNQUFNLEtBQUssc0JBQXNCO0lBQ2pDLEtBQUssWUFBWSxRQUFRO0dBQzFCO0VBQ0QsQ0FBQztFQUNELEtBQUsscUJBQXFCLGNBQWMsVUFBVSxPQUFPLFdBQVc7R0FDbkUsSUFBSSxRQUFRO0lBQ1gsTUFBTSxLQUFLLHNCQUFzQjtJQUNqQyxLQUFLLFlBQVksU0FBUztHQUMzQjtFQUNELENBQUM7Q0FDRjs7Ozs7O0NBTUEsVUFBVTtFQUNULEtBQUs7RUFDTCxJQUFJLEtBQUssZ0JBQWdCLEdBQUc7RUFDNUIsS0FBSyxvQkFBb0I7RUFDekIsS0FBSyxvQkFBb0IsS0FBSztFQUM5QixLQUFLLHFCQUFxQjtFQUMxQixLQUFLLHFCQUFxQixLQUFLO0NBQ2hDOzs7Ozs7Ozs7Ozs7O0NBYUEsV0FBVyxTQUFTO0VBQ25CLE9BQU8sS0FBSyxZQUFZLFFBQVE7R0FDL0IsR0FBRztHQUNILGFBQWE7RUFDZCxDQUFDLENBQUMsQ0FBQztDQUNKOzs7Ozs7Ozs7Ozs7Q0FZQSxXQUFXLFNBQVM7RUFDbkIsT0FBTyxLQUFLLGVBQWUsUUFBUTtHQUNsQyxHQUFHO0dBQ0gsUUFBUTtFQUNULENBQUMsQ0FBQyxDQUFDO0NBQ0o7Ozs7Ozs7Ozs7Q0FVQSxhQUFhLFVBQVU7RUFDdEIsTUFBTSxVQUFVLEtBQUssb0JBQW9CLEVBQUUsU0FBUyxDQUFDO0VBQ3JELE9BQU8sS0FBSyxZQUFZLElBQUksUUFBUSxTQUFTLENBQUMsRUFBRSxNQUFNO0NBQ3ZEOzs7O0NBSUEsZ0JBQWdCLFNBQVM7RUFDeEIsTUFBTSxtQkFBbUIsS0FBSyxvQkFBb0IsT0FBTztFQUN6RCxNQUFNLFFBQVEsS0FBSyxZQUFZLE1BQU0sTUFBTSxnQkFBZ0I7RUFDM0QsTUFBTSxhQUFhLE1BQU0sTUFBTTtFQUMvQixJQUFJLGVBQWUsS0FBSyxHQUFHLE9BQU8sS0FBSyxXQUFXLE9BQU87RUFDekQsSUFBSSxRQUFRLHFCQUFxQixNQUFNLGNBQWMsa0JBQWtCLGlCQUFpQixXQUFXLEtBQUssQ0FBQyxHQUFHLEtBQUssY0FBYyxnQkFBZ0I7RUFDL0ksT0FBTyxRQUFRLFFBQVEsVUFBVTtDQUNsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0JBLGVBQWUsU0FBUztFQUN2QixPQUFPLEtBQUssWUFBWSxRQUFRLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRSxVQUFVLFlBQVk7R0FDckUsT0FBTyxDQUFDLFVBQVUsTUFBTSxJQUFJO0VBQzdCLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXNCQSxhQUFhLFVBQVUsU0FBUyxTQUFTO0VBQ3hDLE1BQU0sbUJBQW1CLEtBQUssb0JBQW9CLEVBQUUsU0FBUyxDQUFDO0VBQzlELE1BQU0sV0FBVyxLQUFLLFlBQVksSUFBSSxpQkFBaUIsU0FBUyxDQUFDLEVBQUUsTUFBTTtFQUN6RSxNQUFNLE9BQU8saUJBQWlCLFNBQVMsUUFBUTtFQUMvQyxJQUFJLFNBQVMsS0FBSyxHQUFHO0VBQ3JCLE9BQU8sS0FBSyxZQUFZLE1BQU0sTUFBTSxnQkFBZ0IsQ0FBQyxDQUFDLFFBQVEsTUFBTTtHQUNuRSxHQUFHO0dBQ0gsUUFBUTtFQUNULENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Q0FjQSxlQUFlLFNBQVMsU0FBUyxTQUFTO0VBQ3pDLE9BQU8sY0FBYyxZQUFZLEtBQUssWUFBWSxRQUFRLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRSxlQUFlLENBQUMsVUFBVSxLQUFLLGFBQWEsVUFBVSxTQUFTLE9BQU8sQ0FBQyxDQUFDLENBQUM7Q0FDcEo7Ozs7Ozs7Ozs7O0NBV0EsY0FBYyxVQUFVO0VBQ3ZCLE1BQU0sVUFBVSxLQUFLLG9CQUFvQixFQUFFLFNBQVMsQ0FBQztFQUNyRCxPQUFPLEtBQUssWUFBWSxJQUFJLFFBQVEsU0FBUyxDQUFDLEVBQUU7Q0FDakQ7Ozs7Ozs7Ozs7OztDQVlBLGNBQWMsU0FBUztFQUN0QixNQUFNLGFBQWEsS0FBSztFQUN4QixjQUFjLFlBQVk7R0FDekIsV0FBVyxRQUFRLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVTtJQUM5QyxXQUFXLE9BQU8sS0FBSztHQUN4QixDQUFDO0VBQ0YsQ0FBQztDQUNGOzs7Ozs7Ozs7OztDQVdBLGFBQWEsU0FBUyxTQUFTO0VBQzlCLE1BQU0sYUFBYSxLQUFLO0VBQ3hCLE9BQU8sY0FBYyxZQUFZO0dBQ2hDLE1BQU0sVUFBVSxXQUFXLFFBQVEsT0FBTztHQUMxQyxNQUFNLG1CQUFtQixJQUFJLElBQUksT0FBTztHQUN4QyxRQUFRLFNBQVMsVUFBVTtJQUMxQixNQUFNLE1BQU07R0FDYixDQUFDO0dBQ0QsT0FBTyxLQUFLLGVBQWU7SUFDMUIsTUFBTTtJQUNOLFlBQVksVUFBVSxpQkFBaUIsSUFBSSxLQUFLO0dBQ2pELEdBQUcsT0FBTztFQUNYLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Q0FjQSxjQUFjLFNBQVMsZ0JBQWdCLENBQUMsR0FBRztFQUMxQyxNQUFNLHlCQUF5QjtHQUM5QixRQUFRO0dBQ1IsR0FBRztFQUNKO0VBQ0EsTUFBTSxXQUFXLGNBQWMsWUFBWSxLQUFLLFlBQVksUUFBUSxPQUFPLENBQUMsQ0FBQyxLQUFLLFVBQVUsTUFBTSxPQUFPLHNCQUFzQixDQUFDLENBQUM7RUFDakksT0FBTyxRQUFRLElBQUksUUFBUSxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDbkQ7Ozs7Ozs7Ozs7Ozs7O0NBY0Esa0JBQWtCLFNBQVMsVUFBVSxDQUFDLEdBQUc7RUFDeEMsT0FBTyxjQUFjLFlBQVk7R0FDaEMsS0FBSyxZQUFZLFFBQVEsT0FBTyxDQUFDLENBQUMsU0FBUyxVQUFVO0lBQ3BELE1BQU0sV0FBVztHQUNsQixDQUFDO0dBQ0QsSUFBSSxTQUFTLGdCQUFnQixRQUFRLE9BQU8sUUFBUSxRQUFRO0dBQzVELE9BQU8sS0FBSyxlQUFlO0lBQzFCLEdBQUc7SUFDSCxNQUFNLFNBQVMsZUFBZSxTQUFTLFFBQVE7R0FDaEQsR0FBRyxPQUFPO0VBQ1gsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JBLGVBQWUsU0FBUyxVQUFVLENBQUMsR0FBRztFQUNyQyxNQUFNLGVBQWU7R0FDcEIsR0FBRztHQUNILGVBQWUsUUFBUSxpQkFBaUI7RUFDekM7RUFDQSxNQUFNLFdBQVcsY0FBYyxZQUFZLEtBQUssWUFBWSxRQUFRLE9BQU8sQ0FBQyxDQUFDLFFBQVEsVUFBVSxDQUFDLE1BQU0sV0FBVyxLQUFLLENBQUMsTUFBTSxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssVUFBVTtHQUN2SixJQUFJLFVBQVUsTUFBTSxNQUFNLEtBQUssR0FBRyxZQUFZO0dBQzlDLElBQUksQ0FBQyxhQUFhLGNBQWMsVUFBVSxRQUFRLE1BQU0sSUFBSTtHQUM1RCxPQUFPLE1BQU0sTUFBTSxnQkFBZ0IsV0FBVyxRQUFRLFFBQVEsSUFBSTtFQUNuRSxDQUFDLENBQUM7RUFDRixPQUFPLFFBQVEsSUFBSSxRQUFRLENBQUMsQ0FBQyxLQUFLLElBQUk7Q0FDdkM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBZ0NBLE1BQU0sTUFBTSxTQUFTO0VBQ3BCLE1BQU0sbUJBQW1CLEtBQUssb0JBQW9CLE9BQU87RUFDekQsSUFBSSxpQkFBaUIsVUFBVSxLQUFLLEdBQUcsaUJBQWlCLFFBQVE7RUFDaEUsTUFBTSxRQUFRLEtBQUssWUFBWSxNQUFNLE1BQU0sZ0JBQWdCO0VBQzNELE1BQU0sWUFBWSxNQUFNLGNBQWMsa0JBQWtCLGlCQUFpQixXQUFXLEtBQUssQ0FBQyxJQUFJLE1BQU0sTUFBTSxNQUFNLGdCQUFnQixJQUFJLE1BQU0sTUFBTTtFQUNoSixNQUFNLFNBQVMsaUJBQWlCO0VBQ2hDLElBQUksUUFBUSxPQUFPLE9BQU8sU0FBUztFQUNuQyxPQUFPO0NBQ1I7Ozs7Q0FJQSxXQUFXLFNBQVM7RUFDbkIsTUFBTSxtQkFBbUIsS0FBSyxvQkFBb0IsT0FBTztFQUN6RCxJQUFJLGlCQUFpQixVQUFVLEtBQUssR0FBRyxpQkFBaUIsUUFBUTtFQUNoRSxNQUFNLFFBQVEsS0FBSyxZQUFZLE1BQU0sTUFBTSxnQkFBZ0I7RUFDM0QsT0FBTyxNQUFNLGNBQWMsa0JBQWtCLGlCQUFpQixXQUFXLEtBQUssQ0FBQyxJQUFJLE1BQU0sTUFBTSxnQkFBZ0IsSUFBSSxRQUFRLFFBQVEsTUFBTSxNQUFNLElBQUk7Q0FDcEo7Ozs7Q0FJQSxjQUFjLFNBQVM7RUFDdEIsT0FBTyxLQUFLLFdBQVcsT0FBTyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDdEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQkEsY0FBYyxTQUFTO0VBQ3RCLFFBQVEsUUFBUTtFQUNoQixPQUFPLEtBQUssTUFBTSxPQUFPO0NBQzFCOzs7O0NBSUEsbUJBQW1CLFNBQVM7RUFDM0IsUUFBUSxRQUFRO0VBQ2hCLE9BQU8sS0FBSyxXQUFXLE9BQU87Q0FDL0I7Ozs7Q0FJQSxzQkFBc0IsU0FBUztFQUM5QixPQUFPLEtBQUssbUJBQW1CLE9BQU8sQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJO0NBQzlEOzs7O0NBSUEsd0JBQXdCLFNBQVM7RUFDaEMsUUFBUSxRQUFRO0VBQ2hCLE9BQU8sS0FBSyxnQkFBZ0IsT0FBTztDQUNwQzs7Ozs7Ozs7Ozs7OztDQWFBLHdCQUF3QjtFQUN2QixJQUFJLGNBQWMsU0FBUyxHQUFHLE9BQU8sS0FBSyxlQUFlLHNCQUFzQjtFQUMvRSxPQUFPLFFBQVEsUUFBUTtDQUN4Qjs7Ozs7Ozs7Ozs7OztDQWFBLGdCQUFnQjtFQUNmLE9BQU8sS0FBSztDQUNiOzs7Ozs7Ozs7Ozs7O0NBYUEsbUJBQW1CO0VBQ2xCLE9BQU8sS0FBSztDQUNiOzs7Ozs7Ozs7Ozs7O0NBYUEsb0JBQW9CO0VBQ25CLE9BQU8sS0FBSztDQUNiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsa0JBQWtCLFNBQVM7RUFDMUIsS0FBSyxrQkFBa0I7Q0FDeEI7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQkEsaUJBQWlCLFVBQVUsU0FBUztFQUNuQyxLQUFLLGVBQWUsSUFBSSxRQUFRLFFBQVEsR0FBRztHQUMxQztHQUNBLGdCQUFnQjtFQUNqQixDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7O0NBV0EsaUJBQWlCLFVBQVU7RUFDMUIsTUFBTSxXQUFXLENBQUMsR0FBRyxLQUFLLGVBQWUsT0FBTyxDQUFDO0VBQ2pELE1BQU0sU0FBUyxDQUFDO0VBQ2hCLFNBQVMsU0FBUyxpQkFBaUI7R0FDbEMsSUFBSSxnQkFBZ0IsVUFBVSxhQUFhLFFBQVEsR0FBRyxPQUFPLE9BQU8sUUFBUSxhQUFhLGNBQWM7RUFDeEcsQ0FBQztFQUNELE9BQU87Q0FDUjs7Ozs7Ozs7Ozs7O0NBWUEsb0JBQW9CLGFBQWEsU0FBUztFQUN6QyxLQUFLLGtCQUFrQixJQUFJLFFBQVEsV0FBVyxHQUFHO0dBQ2hEO0dBQ0EsZ0JBQWdCO0VBQ2pCLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Q0FXQSxvQkFBb0IsYUFBYTtFQUNoQyxNQUFNLFdBQVcsQ0FBQyxHQUFHLEtBQUssa0JBQWtCLE9BQU8sQ0FBQztFQUNwRCxNQUFNLFNBQVMsQ0FBQztFQUNoQixTQUFTLFNBQVMsaUJBQWlCO0dBQ2xDLElBQUksZ0JBQWdCLGFBQWEsYUFBYSxXQUFXLEdBQUcsT0FBTyxPQUFPLFFBQVEsYUFBYSxjQUFjO0VBQzlHLENBQUM7RUFDRCxPQUFPO0NBQ1I7Ozs7Ozs7Q0FPQSxvQkFBb0IsU0FBUztFQUM1QixJQUFJLFFBQVEsWUFBWSxPQUFPO0VBQy9CLE1BQU0sbUJBQW1CO0dBQ3hCLEdBQUcsS0FBSyxnQkFBZ0I7R0FDeEIsR0FBRyxLQUFLLGlCQUFpQixRQUFRLFFBQVE7R0FDekMsR0FBRztHQUNILFlBQVk7RUFDYjtFQUNBLElBQUksQ0FBQyxpQkFBaUIsV0FBVyxpQkFBaUIsWUFBWSxzQkFBc0IsaUJBQWlCLFVBQVUsZ0JBQWdCO0VBQy9ILElBQUksaUJBQWlCLHVCQUF1QixLQUFLLEdBQUcsaUJBQWlCLHFCQUFxQixpQkFBaUIsZ0JBQWdCO0VBQzNILElBQUksaUJBQWlCLGlCQUFpQixLQUFLLEdBQUcsaUJBQWlCLGVBQWUsQ0FBQyxDQUFDLGlCQUFpQjtFQUNqRyxJQUFJLENBQUMsaUJBQWlCLGVBQWUsaUJBQWlCLFdBQVcsaUJBQWlCLGNBQWM7RUFDaEcsSUFBSSxpQkFBaUIsWUFBWSxXQUFXLGlCQUFpQixVQUFVO0VBQ3ZFLE9BQU87Q0FDUjs7Ozs7OztDQU9BLHVCQUF1QixTQUFTO0VBQy9CLElBQUksU0FBUyxZQUFZLE9BQU87RUFDaEMsT0FBTztHQUNOLEdBQUcsS0FBSyxnQkFBZ0I7R0FDeEIsR0FBRyxTQUFTLGVBQWUsS0FBSyxvQkFBb0IsUUFBUSxXQUFXO0dBQ3ZFLEdBQUc7R0FDSCxZQUFZO0VBQ2I7Q0FDRDs7Ozs7Ozs7Ozs7O0NBWUEsUUFBUTtFQUNQLEtBQUssWUFBWSxNQUFNO0VBQ3ZCLEtBQUssZUFBZSxNQUFNO0NBQzNCO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeG1CQSxTQUFTLGNBQWMsRUFBRSxVQUFVLGNBQWMsU0FBUyxXQUFXLE9BQU8sVUFBVSxTQUFTLE9BQU8sS0FBSyxHQUFHLGVBQWUsQ0FBQyxLQUFLO0NBQ2xJLE9BQU8sT0FBTyxZQUFZO0VBQ3pCLE1BQU0sUUFBUSxRQUFRLE9BQU8sY0FBYyxDQUFDLENBQUMsS0FBSztHQUNqRCxVQUFVLFFBQVE7R0FDbEIsT0FBTztFQUNSLENBQUM7RUFDRCxNQUFNLFlBQVksQ0FBQyxDQUFDLFNBQVMsTUFBTSxVQUFVO0VBQzdDLElBQUksYUFBYSxnQkFBZ0IsU0FBUyxNQUFNLFNBQVM7R0FDeEQsR0FBRyxNQUFNO0dBQ1QsYUFBYTtFQUNkLENBQUM7RUFDRCxJQUFJLFNBQVM7RUFDYixJQUFJLFlBQVk7RUFDaEIsTUFBTSxTQUFTLE1BQU0sU0FBUyxzQkFBc0I7R0FDbkQsUUFBUSxRQUFRO0dBQ2hCLE1BQU0sUUFBUTtHQUNkLFVBQVUsUUFBUTtHQUNsQixXQUFXLFFBQVE7R0FDbkIsV0FBVyxRQUFRO0VBQ3BCLFNBQVMsUUFBUSxjQUFjLFlBQVksSUFBSSxDQUFDO0VBQ2hELE1BQU0sbUJBQW1CLGFBQWEsZ0JBQWdCO0VBQ3RELFdBQVcsTUFBTSxTQUFTLFFBQVE7R0FDakMsSUFBSSxXQUFXO0dBQ2YsSUFBSSxrQkFBa0IsU0FBUyxRQUFRLFFBQVEsS0FBSztRQUMvQyxRQUFRLE9BQU8sYUFBYSxRQUFRLFdBQVcsU0FBUyxRQUFRLFNBQVMsS0FBSyxJQUFJLGVBQWUsTUFBTSxLQUFLLENBQUM7RUFDbkg7RUFDQSxJQUFJLG9CQUFvQixDQUFDLFdBQVcsUUFBUSxPQUFPLGFBQWEsUUFBUSxVQUFVLE1BQU07RUFDeEYsTUFBTSxPQUFPLFFBQVEsT0FBTyxhQUFhLFFBQVEsUUFBUTtFQUN6RCxPQUFPLFNBQVMsS0FBSyxJQUFJLGVBQWU7Q0FDekM7QUFDRDs7OztBQ3JEQSxJQUFNLGdCQUFnQixPQUFPO0FBQzdCLElBQU0scUJBQXFCLE9BQU87QUFDbEMsSUFBTSxjQUFjLE9BQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM0QzNCLElBQU0scUJBQXFCLEVBQUUsVUFBVSxVQUFVLENBQUMsR0FBRyxPQUFPLGtCQUFrQjtDQUM3RSxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLE1BQU0sYUFBQSxhQUFtQixPQUFPLE9BQU87Q0FDdkMsYUFBTSxnQkFBZ0I7RUFDckIsV0FBVyxVQUFVO0NBQ3RCLENBQUM7Q0FDRCxNQUFNLGlCQUFBLGFBQXVCLGNBQWM7RUFDMUMsSUFBSSxPQUFPO0dBQ1YsSUFBSSxPQUFPLFVBQVUsVUFBVTtHQUMvQixNQUFNLGFBQWEsT0FBTyxjQUFjO0dBQ3hDLE1BQU0sVUFBVSxNQUFNLFdBQVcsQ0FBQztHQUNsQyxNQUFNLGFBQWEsQ0FBQztHQUNwQixNQUFNLGtCQUFrQixDQUFDO0dBQ3pCLEtBQUssTUFBTSxtQkFBbUIsU0FBUztJQUN0QyxNQUFNLGdCQUFnQixXQUFXLElBQUksZ0JBQWdCLFNBQVM7SUFDOUQsSUFBSSxDQUFDLGVBQWUsV0FBVyxLQUFLLGVBQWU7U0FDOUMsSUFBSSxnQkFBZ0IsTUFBTSxnQkFBZ0IsY0FBYyxNQUFNLGlCQUFpQixnQkFBZ0IsV0FBVyxjQUFjLE1BQU0sV0FBVyxhQUFhLGNBQWMsTUFBTSxnQkFBZ0IsY0FBYyxnQkFBZ0IsZUFBZSxjQUFjLE1BQU0sZUFBZSxnQkFBZ0IsS0FBSyxlQUFlO0dBQ3BUO0dBQ0EsSUFBSSxXQUFXLFNBQVMsR0FBRyxRQUFRLFFBQVEsRUFBRSxTQUFTLFdBQVcsR0FBRyxXQUFXLE9BQU87R0FDdEYsSUFBSSxnQkFBZ0IsU0FBUyxHQUFHLE9BQU87RUFDeEM7Q0FDRCxHQUFHLENBQUMsUUFBUSxLQUFLLENBQUM7Q0FDbEIsYUFBTSxnQkFBZ0I7RUFDckIsSUFBSSxnQkFBZ0IsUUFBUSxRQUFRLEVBQUUsU0FBUyxlQUFlLEdBQUcsV0FBVyxPQUFPO0NBQ3BGLEdBQUcsQ0FBQyxRQUFRLGNBQWMsQ0FBQztDQUMzQixPQUFPO0FBQ1I7OztBQ3ZFQSxJQUFNLHFCQUFBLGFBQTJCLGNBQWMsS0FBSzs7Ozs7Ozs7QUFRcEQsSUFBTSx1QkFBQSxhQUE2QixXQUFXLGtCQUFrQjs7Ozs7QUFLaEUsSUFBTSxzQkFBc0IsbUJBQW1COzs7Ozs7QUNUL0MsU0FBUyxjQUFjO0NBQ3RCLElBQUksVUFBVTtDQUNkLE9BQU87Ozs7RUFJTixrQkFBa0I7R0FDakIsVUFBVTtFQUNYOzs7O0VBSUEsYUFBYTtHQUNaLFVBQVU7RUFDWDs7OztFQUlBLGVBQWU7R0FDZCxPQUFPO0VBQ1I7Q0FDRDtBQUNEO0FBQ0EsSUFBTSxpQ0FBQSxhQUF1QyxjQUFjLFlBQVksQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQStCeEUsSUFBTSxtQ0FBQSxhQUF5QyxXQUFXLDhCQUE4Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFtQ3hGLElBQU0sMkJBQTJCLEVBQUUsZUFBZTtDQUNqRCxNQUFNLENBQUMsU0FBQSxhQUFlLGVBQWUsWUFBWSxDQUFDO0NBQ2xELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLCtCQUErQixVQUFVO0VBQ25FO0VBQ0EsVUFBVSxPQUFPLGFBQWEsYUFBYSxTQUFTLEtBQUssSUFBSTtDQUM5RCxDQUFDO0FBQ0Y7OztBQ2xHQSxJQUFNLG1DQUFtQyxTQUFTLG9CQUFvQixVQUFVO0NBQy9FLE1BQU0sZUFBZSxPQUFPLE1BQU0sU0FBUyxPQUFPLFFBQVEsaUJBQWlCLGFBQWEsaUJBQWlCLFFBQVEsY0FBYyxDQUFDLE1BQU0sTUFBTSxPQUFPLEtBQUssQ0FBQyxJQUFJLFFBQVE7Q0FDckssSUFBSSxRQUFRLFlBQVksY0FDbkI7TUFBQSxDQUFDLG1CQUFtQixRQUFRLEdBQUcsUUFBUSxlQUFlO0NBQUE7QUFFNUQ7QUFDQSxJQUFNLDhCQUE4Qix1QkFBdUI7Q0FDMUQsYUFBTSxnQkFBZ0I7RUFDckIsbUJBQW1CLFdBQVc7Q0FDL0IsR0FBRyxDQUFDLGtCQUFrQixDQUFDO0FBQ3hCO0FBQ0EsSUFBTSxlQUFlLEVBQUUsUUFBUSxvQkFBb0IsY0FBYyxPQUFPLGVBQWU7Q0FDdEYsT0FBTyxPQUFPLFdBQVcsQ0FBQyxtQkFBbUIsUUFBUSxLQUFLLENBQUMsT0FBTyxjQUFjLFVBQVUsWUFBWSxPQUFPLFNBQVMsS0FBSyxLQUFLLGlCQUFpQixjQUFjLENBQUMsT0FBTyxPQUFPLEtBQUssQ0FBQztBQUNyTDs7O0FDaEJBLElBQU0sdUJBQXVCLFFBQVEsVUFBVSxNQUFNLE1BQU0sU0FBUyxLQUFLO0FBQ3pFLElBQU0sd0JBQXdCLHFCQUFxQjtDQUNsRCxJQUFJLGlCQUFpQixVQUFVO0VBQzlCLE1BQU0sdUJBQXVCO0VBQzdCLE1BQU0sU0FBUyxVQUFVLFVBQVUsV0FBVyxRQUFRLEtBQUssSUFBSSxTQUFTLHNCQUFzQixvQkFBb0I7RUFDbEgsTUFBTSxvQkFBb0IsaUJBQWlCO0VBQzNDLGlCQUFpQixZQUFZLE9BQU8sc0JBQXNCLGNBQWMsR0FBRyxTQUFTLE1BQU0sa0JBQWtCLEdBQUcsSUFBSSxDQUFDLElBQUksTUFBTSxpQkFBaUI7RUFDL0ksSUFBSSxPQUFPLGlCQUFpQixXQUFXLFVBQVUsaUJBQWlCLFNBQVMsS0FBSyxJQUFJLGlCQUFpQixRQUFRLG9CQUFvQjtDQUNsSTtBQUNEO0FBQ0EsSUFBTSxpQkFBaUIsa0JBQWtCLFdBQVcsa0JBQWtCLFlBQVksT0FBTztBQUN6RixJQUFNLG1CQUFtQixrQkFBa0IsVUFBVSx1QkFBdUIsU0FBUyxnQkFBZ0IsZ0JBQWdCLENBQUMsQ0FBQyxZQUFZO0NBQ2xJLG1CQUFtQixXQUFXO0FBQy9CLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM2SEQsU0FBUyxXQUFXLEVBQUUsU0FBUyxHQUFHLFdBQVcsYUFBYTtDQUN6RCxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLE1BQU0sY0FBYyxlQUFlO0NBQ25DLE1BQU0scUJBQXFCLDJCQUEyQjtDQUN0RCxNQUFNLGFBQWEsUUFBUSxlQUFlO0NBQzFDLE1BQU0sbUJBQUEsYUFBeUIsY0FBYyxRQUFRLEtBQUssU0FBUztFQUNsRSxNQUFNLG1CQUFtQixPQUFPLG9CQUFvQixJQUFJO0VBQ3hELGlCQUFpQixxQkFBcUIsY0FBYyxnQkFBZ0IsYUFBYSxlQUFlLEtBQUs7RUFDckcsT0FBTztDQUNSLENBQUMsR0FBRztFQUNIO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELGlCQUFpQixTQUFTLGlCQUFpQjtFQUMxQyxxQkFBcUIsWUFBWTtFQUNqQyxNQUFNLFFBQVEsT0FBTyxjQUFjLENBQUMsQ0FBQyxJQUFJLGFBQWEsU0FBUztFQUMvRCxnQ0FBZ0MsY0FBYyxvQkFBb0IsS0FBSztDQUN4RSxDQUFDO0NBQ0QsMkJBQTJCLGtCQUFrQjtDQUM3QyxNQUFNLENBQUMsWUFBQSxhQUFrQixlQUFlLElBQUksZ0JBQWdCLFFBQVEsa0JBQWtCLE9BQU8sQ0FBQztDQUM5RixNQUFNLENBQUMsa0JBQWtCLG1CQUFtQixlQUFlLFNBQVMsb0JBQW9CLGtCQUFrQixRQUFRLE9BQU87Q0FDekgsTUFBTSxrQkFBa0IsQ0FBQyxlQUFlO0NBQ3hDLGFBQU0scUJBQUEsYUFBMkIsYUFBYSxrQkFBa0Isa0JBQWtCLFNBQVMsVUFBVSxjQUFjLFdBQVcsYUFBYSxDQUFDLElBQUksTUFBTSxDQUFDLFVBQVUsZUFBZSxDQUFDLFNBQVMsU0FBUyxpQkFBaUIsU0FBUyxTQUFTLGlCQUFpQixDQUFDO0NBQ3hQLGFBQU0sZ0JBQWdCO0VBQ3JCLFNBQVMsV0FBVyxrQkFBa0IsT0FBTztDQUM5QyxHQUFHO0VBQ0Y7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELE1BQU0sbUJBQW1CLGlCQUFpQixNQUFNLFFBQVEsVUFBVSxjQUFjLGlCQUFpQixRQUFRLE1BQU0sQ0FBQyxJQUFJLGlCQUFpQixTQUFTLFFBQVEsVUFBVTtFQUMvSixNQUFNLE9BQU8saUJBQWlCO0VBQzlCLElBQUksUUFBUSxjQUFjLE1BQU0sTUFBTSxHQUVyQyxPQUFPLGdCQUFnQixNQUFNLElBREgsY0FBYyxRQUFRLElBQ25CLEdBQWUsa0JBQWtCO0VBRS9ELE9BQU8sQ0FBQztDQUNULENBQUMsSUFBSSxDQUFDO0NBQ04sSUFBSSxpQkFBaUIsU0FBUyxHQUFHLE1BQU0sUUFBUSxJQUFJLGdCQUFnQjtDQUNuRSxNQUFNLG9DQUFvQyxpQkFBaUIsTUFBTSxRQUFRLFVBQVU7RUFDbEYsTUFBTSxRQUFRLGlCQUFpQjtFQUMvQixPQUFPLFNBQVMsWUFBWTtHQUMzQjtHQUNBO0dBQ0EsY0FBYyxNQUFNO0dBQ3BCLE9BQU8sT0FBTyxjQUFjLENBQUMsQ0FBQyxJQUFJLE1BQU0sU0FBUztHQUNqRCxVQUFVLE1BQU07RUFDakIsQ0FBQztDQUNGLENBQUM7Q0FDRCxJQUFJLG1DQUFtQyxNQUFNLGtDQUFrQztDQUMvRSxPQUFPLGtCQUFrQixZQUFZLENBQUM7QUFDdkM7OztBQ3ZMQSxTQUFTLGFBQWEsU0FBUyxVQUFVLGFBQWE7Q0FFcEQsSUFBSSxPQUFPLFlBQVksWUFBWSxNQUFNLFFBQVEsT0FBTyxHQUFHLE1BQU0sSUFBSSxNQUFNLGdTQUFnUztDQUU1VyxNQUFNLGNBQWMsZUFBZTtDQUNuQyxNQUFNLHFCQUFxQiwyQkFBMkI7Q0FDdEQsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxNQUFNLG1CQUFtQixPQUFPLG9CQUFvQixPQUFPO0NBQzNELE1BQU0sUUFBUSxPQUFPLGNBQWMsQ0FBQyxDQUFDLElBQUksaUJBQWlCLFNBQVM7Q0FFbEUsSUFBSSxDQUFDLGlCQUFpQixTQUFTLFFBQVEsTUFBTSxJQUFJLGlCQUFpQixVQUFVLG1QQUFtUDtDQUVoVSxNQUFNLGFBQWEsUUFBUSxlQUFlO0NBQzFDLGlCQUFpQixxQkFBcUIsY0FBYyxnQkFBZ0IsYUFBYSxlQUFlLEtBQUs7Q0FDckcscUJBQXFCLGdCQUFnQjtDQUNyQyxnQ0FBZ0Msa0JBQWtCLG9CQUFvQixLQUFLO0NBQzNFLDJCQUEyQixrQkFBa0I7Q0FDN0MsTUFBTSxDQUFDLFlBQUEsYUFBa0IsZUFBZSxJQUFJLFNBQVMsUUFBUSxnQkFBZ0IsQ0FBQztDQUM5RSxNQUFNLFNBQVMsU0FBUyxvQkFBb0IsZ0JBQWdCO0NBQzVELE1BQU0sa0JBQWtCLENBQUMsZUFBZTtDQUN4QyxhQUFNLHFCQUFBLGFBQTJCLGFBQWEsa0JBQWtCO0VBQy9ELE1BQU0sY0FBYyxrQkFBa0IsU0FBUyxVQUFVLGNBQWMsV0FBVyxhQUFhLENBQUMsSUFBSTtFQUNwRyxTQUFTLGFBQWE7RUFDdEIsT0FBTztDQUNSLEdBQUcsQ0FBQyxVQUFVLGVBQWUsQ0FBQyxTQUFTLFNBQVMsaUJBQWlCLFNBQVMsU0FBUyxpQkFBaUIsQ0FBQztDQUNyRyxhQUFNLGdCQUFnQjtFQUNyQixTQUFTLFdBQVcsZ0JBQWdCO0NBQ3JDLEdBQUcsQ0FBQyxrQkFBa0IsUUFBUSxDQUFDO0NBQy9CLElBQUksY0FBYyxrQkFBa0IsTUFBTSxHQUFHLE1BQU0sZ0JBQWdCLGtCQUFrQixVQUFVLGtCQUFrQjtDQUNqSCxJQUFJLFlBQVk7RUFDZjtFQUNBO0VBQ0EsY0FBYyxpQkFBaUI7RUFDL0I7RUFDQSxVQUFVLGlCQUFpQjtDQUM1QixDQUFDLEdBQUcsTUFBTSxPQUFPO0NBQ2pCLE9BQU8sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsWUFBWSxNQUFNLElBQUk7QUFDL0U7OztBQzFDQSxTQUFTLFNBQVMsU0FBUyxhQUFhO0NBQ3ZDLE9BQU8sYUFBYSxTQUFTLGVBQWUsV0FBVztBQUN4RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2tFQSxTQUFTLGlCQUFpQixTQUFTLGFBQWE7Q0FFOUMsSUFBSSxRQUFRLFlBQVksV0FBVyxRQUFRLE1BQU0sK0NBQStDO0NBRWpHLE9BQU8sYUFBYTtFQUNuQixHQUFHO0VBQ0gsU0FBUztFQUNULFVBQVU7RUFDVixjQUFjO0VBQ2QsaUJBQWlCLEtBQUs7Q0FDdkIsR0FBRyxlQUFlLFdBQVc7QUFDOUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUUEsU0FBUyx5QkFBeUIsU0FBUyxhQUFhO0NBRXRELElBQUksUUFBUSxZQUFZLFdBQVcsUUFBUSxNQUFNLHVEQUF1RDtDQUV6RyxPQUFPLGFBQWE7RUFDbkIsR0FBRztFQUNILFNBQVM7RUFDVCxVQUFVO0VBQ1YsY0FBYztFQUNkLGlCQUFpQixLQUFLO0NBQ3ZCLEdBQUcsdUJBQXVCLFdBQVc7QUFDdEM7OztBQ2pHQSxTQUFTLG1CQUFtQixTQUFTLGFBQWE7Q0FDakQsT0FBTyxXQUFXO0VBQ2pCLEdBQUc7RUFDSCxTQUFTLFFBQVEsUUFBUSxLQUFLLFVBQVU7R0FFdEMsSUFBSSxNQUFNLFlBQVksV0FBVyxRQUFRLE1BQU0saURBQWlEO0dBRWpHLE9BQU87SUFDTixHQUFHO0lBQ0gsVUFBVTtJQUNWLGNBQWM7SUFDZCxTQUFTO0lBQ1QsaUJBQWlCLEtBQUs7R0FDdkI7RUFDRCxDQUFDO0NBQ0YsR0FBRyxXQUFXO0FBQ2Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaUJBLFNBQVMsaUJBQWlCLFNBQVMsYUFBYTtDQUMvQyxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLElBQUksQ0FBQyxPQUFPLGNBQWMsUUFBUSxRQUFRLEdBQUcsT0FBTyxNQUFNLE9BQU8sQ0FBQyxDQUFDLE1BQU0sSUFBSTtBQUM5RTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNNQSxTQUFTLHlCQUF5QixTQUFTLGFBQWE7Q0FDdkQsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxJQUFJLENBQUMsT0FBTyxjQUFjLFFBQVEsUUFBUSxHQUFHLE9BQU8sY0FBYyxPQUFPLENBQUMsQ0FBQyxNQUFNLElBQUk7QUFDdEY7OztBQ2pEQSxTQUFTLGFBQWEsU0FBUztDQUM5QixPQUFPO0FBQ1I7OztBQ0ZBLFNBQVMscUJBQXFCLFNBQVM7Q0FDdEMsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNzQ0EsU0FBUyxjQUFjLFNBQVMsYUFBYTtDQUM1QyxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLE1BQU0sYUFBYSxPQUFPLGNBQWM7Q0FDeEMsT0FBQSxhQUFhLHFCQUFBLGFBQTJCLGFBQWEsa0JBQWtCLFdBQVcsVUFBVSxjQUFjLFdBQVcsYUFBYSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsU0FBUyxPQUFPLFdBQVcsT0FBTyxTQUFTLE9BQU8sV0FBVyxPQUFPLENBQUM7QUFDeE47Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25CQSxTQUFTLGNBQWMsU0FBUyxhQUFhO0NBQzVDLE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsT0FBTyxpQkFBaUIsRUFBRSxTQUFTO0VBQ2xDLEdBQUc7RUFDSCxRQUFRO0NBQ1QsRUFBRSxHQUFHLE1BQU0sQ0FBQyxDQUFDO0FBQ2Q7QUFDQSxTQUFTLFVBQVUsZUFBZSxTQUFTO0NBQzFDLE9BQU8sY0FBYyxRQUFRLFFBQVEsT0FBTyxDQUFDLENBQUMsS0FBSyxhQUFhLFFBQVEsU0FBUyxRQUFRLE9BQU8sUUFBUSxJQUFJLFNBQVMsS0FBSztBQUMzSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUEwRUEsU0FBUyxpQkFBaUIsVUFBVSxDQUFDLEdBQUcsYUFBYTtDQUNwRCxNQUFNLGdCQUFnQixlQUFlLFdBQVcsQ0FBQyxDQUFDLGlCQUFpQjtDQUNuRSxNQUFNLGFBQUEsYUFBbUIsT0FBTyxPQUFPO0NBQ3ZDLE1BQU0sU0FBQSxhQUFlLE9BQU8sSUFBSTtDQUNoQyxJQUFJLE9BQU8sWUFBWSxNQUFNLE9BQU8sVUFBVSxVQUFVLGVBQWUsT0FBTztDQUM5RSxhQUFNLGdCQUFnQjtFQUNyQixXQUFXLFVBQVU7Q0FDdEIsQ0FBQztDQUNELE9BQUEsYUFBYSxxQkFBQSxhQUEyQixhQUFhLGtCQUFrQixjQUFjLGdCQUFnQjtFQUNwRyxNQUFNLGFBQWEsaUJBQWlCLE9BQU8sU0FBUyxVQUFVLGVBQWUsV0FBVyxPQUFPLENBQUM7RUFDaEcsSUFBSSxPQUFPLFlBQVksWUFBWTtHQUNsQyxPQUFPLFVBQVU7R0FDakIsY0FBYyxTQUFTLGFBQWE7RUFDckM7Q0FDRCxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsU0FBUyxPQUFPLGVBQWUsT0FBTyxPQUFPO0FBQ2pFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcURBLFNBQVMsWUFBWSxTQUFTLGFBQWE7Q0FDMUMsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxNQUFNLENBQUMsWUFBQSxhQUFrQixlQUFlLElBQUksaUJBQWlCLFFBQVEsT0FBTyxDQUFDO0NBQzdFLGFBQU0sZ0JBQWdCO0VBQ3JCLFNBQVMsV0FBVyxPQUFPO0NBQzVCLEdBQUcsQ0FBQyxVQUFVLE9BQU8sQ0FBQztDQUN0QixNQUFNLFNBQUEsYUFBZSxxQkFBQSxhQUEyQixhQUFhLGtCQUFrQixTQUFTLFVBQVUsY0FBYyxXQUFXLGFBQWEsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFNBQVMsU0FBUyxpQkFBaUIsU0FBUyxTQUFTLGlCQUFpQixDQUFDO0NBQzdOLE1BQU0sU0FBQSxhQUFlLGFBQWEsR0FBRyxTQUFTO0VBQzdDLFNBQVMsT0FBTyxLQUFLLElBQUksS0FBSyxFQUFFLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDN0MsR0FBRyxDQUFDLFFBQVEsQ0FBQztDQUNiLElBQUksT0FBTyxTQUFTLGlCQUFpQixTQUFTLFFBQVEsY0FBYyxDQUFDLE9BQU8sS0FBSyxDQUFDLEdBQUcsTUFBTSxPQUFPO0NBQ2xHLE9BQU87RUFDTixHQUFHO0VBQ0g7RUFDQSxhQUFhLE9BQU87Q0FDckI7QUFDRDs7O0FDaE1BLFNBQVMsZ0JBQWdCLFNBQVM7Q0FDakMsT0FBTztBQUNSOzs7QUNDQSxTQUFTLGlCQUFpQixTQUFTLGFBQWE7Q0FDL0MsT0FBTyxhQUFhLFNBQVMsdUJBQXVCLFdBQVc7QUFDaEUiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNiwyNywyOCwyOSwzMCwzMSwzMiwzMywzNCwzNSwzNiwzNywzOCwzOSw0MCw0MSw0Miw0M119