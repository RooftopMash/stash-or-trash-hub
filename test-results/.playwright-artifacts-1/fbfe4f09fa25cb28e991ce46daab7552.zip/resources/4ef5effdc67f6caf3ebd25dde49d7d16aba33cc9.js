import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/VerdictSuccess.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { Coins, Sparkles, CheckCircle2 } from "/node_modules/.vite/deps/lucide-react.js?v=a8030269";
import { cn } from "/src/lib/utils.ts";
import coinIcon from "/src/assets/icon-coin.png?import";
var _jsxFileName = "/app/applet/src/components/VerdictSuccess.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
var _s = $RefreshSig$();
const VERDICT_SUCCESS_EVENT = "sot:verdict-success";
/**
* Imperatively trigger the celebratory gold-dust VerdictSuccess animation
* from any Stash action across the app.
*/
export function triggerVerdictSuccess(detail = {}) {
	if (typeof window === "undefined") return;
	window.dispatchEvent(new CustomEvent(VERDICT_SUCCESS_EVENT, { detail }));
}
const GOLD_SHADES = [
	"#FFE885",
	"#F5D061",
	"#D6A928",
	"#B8860B",
	"#FFF6CC",
	"#111115"
];
export function VerdictSuccess({ active = false, onComplete, label = "STASHED!", sublabel = "Keep what serves you · Gold standard verdict recorded", duration = 2400, inline = false, listenGlobal = false, className }) {
	_s();
	const [isVisible, setIsVisible] = useState(active);
	const [burstKey, setBurstKey] = useState(0);
	const [dynamicLabel, setDynamicLabel] = useState(label);
	const [dynamicSublabel, setDynamicSublabel] = useState(sublabel);
	useEffect(() => {
		setDynamicLabel(label);
	}, [label]);
	useEffect(() => {
		setDynamicSublabel(sublabel);
	}, [sublabel]);
	useEffect(() => {
		if (active) {
			setIsVisible(true);
			setBurstKey((k) => k + 1);
			const timer = window.setTimeout(() => {
				setIsVisible(false);
				onComplete?.();
			}, duration);
			return () => window.clearTimeout(timer);
		} else if (!listenGlobal) {
			setIsVisible(false);
		}
	}, [
		active,
		duration,
		onComplete,
		listenGlobal
	]);
	const handleGlobalTrigger = useCallback((e) => {
		const customEvent = e;
		const detail = customEvent.detail ?? {};
		if (detail.label) setDynamicLabel(detail.label);
		else setDynamicLabel(label);
		if (detail.sublabel) setDynamicSublabel(detail.sublabel);
		else setDynamicSublabel(sublabel);
		setIsVisible(true);
		setBurstKey((k) => k + 1);
		const activeDuration = detail.duration ?? duration;
		window.setTimeout(() => {
			setIsVisible(false);
			onComplete?.();
		}, activeDuration);
	}, [
		duration,
		label,
		sublabel,
		onComplete
	]);
	useEffect(() => {
		if (!listenGlobal || typeof window === "undefined") return;
		window.addEventListener(VERDICT_SUCCESS_EVENT, handleGlobalTrigger);
		return () => {
			window.removeEventListener(VERDICT_SUCCESS_EVENT, handleGlobalTrigger);
		};
	}, [listenGlobal, handleGlobalTrigger]);
	// Deterministic yet rich 48-particle gold-dust cloud per burst
	const particles = useMemo(() => {
		return Array.from({ length: 48 }, (_, i) => {
			const seed = (i * 37 + burstKey * 13) % 100;
			const angle = i / 48 * Math.PI * 2 + seed % 7 * .08;
			const ring = i % 3;
			const distance = 48 + ring * 55 + seed % 45;
			const size = ring === 0 ? 4 + seed % 4 : ring === 1 ? 6 + seed % 5 : 3 + seed % 4;
			const delay = i % 8 * 28;
			const partDuration = 1100 + seed % 900;
			const shade = GOLD_SHADES[i % GOLD_SHADES.length];
			const shape = i % 5 === 0 ? "spark" : i % 2 === 0 ? "diamond" : "circle";
			const driftX = Math.cos(angle) * distance;
			const fallY = Math.sin(angle) * distance + 28;
			return {
				id: i,
				angle,
				distance,
				size,
				delay,
				duration: partDuration,
				shade,
				shape,
				driftX,
				fallY
			};
		});
	}, [burstKey]);
	if (!isVisible) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		role: "status",
		"aria-live": "polite",
		"data-testid": "verdict-success",
		className: cn("pointer-events-none z-50 flex items-center justify-center overflow-hidden select-none", inline ? "absolute inset-0 rounded-inherit" : "fixed inset-0", className),
		"data-tsd-source": "/src/components/VerdictSuccess.tsx:164:5",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			"aria-hidden": "true",
			className: "verdict-gold-aura absolute inset-0",
			"data-tsd-source": "/src/components/VerdictSuccess.tsx:176:7"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 176,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "relative flex flex-col items-center justify-center",
			"data-tsd-source": "/src/components/VerdictSuccess.tsx:182:7",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					"aria-hidden": "true",
					className: "verdict-shockwave-ring absolute h-28 w-28 rounded-full border-2 border-[#d6a928]",
					"data-tsd-source": "/src/components/VerdictSuccess.tsx:184:9"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 184,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					"aria-hidden": "true",
					className: "verdict-shockwave-ring-delayed absolute h-40 w-40 rounded-full border border-[#ffe885]/70",
					"data-tsd-source": "/src/components/VerdictSuccess.tsx:188:9"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 188,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					"aria-hidden": "true",
					className: "relative h-0 w-0",
					"data-tsd-source": "/src/components/VerdictSuccess.tsx:194:9",
					children: particles.map((p) => /* @__PURE__ */ _jsxDEV("span", {
						className: cn("verdict-gold-dust-particle absolute block", p.shape === "circle" && "rounded-full", p.shape === "diamond" && "rotate-45 rounded-[2px]", p.shape === "spark" && "rounded-full scale-x-150"),
						style: {
							width: `${p.size}px`,
							height: `${p.size}px`,
							backgroundColor: p.shade,
							boxShadow: p.shade === "#111115" ? "0 0 6px rgba(214, 169, 40, 0.85)" : `0 0 ${p.size * 2}px ${p.shade}, 0 0 ${p.size}px #ffffff`,
							"--tx": `${p.driftX.toFixed(1)}px`,
							"--ty": `${p.fallY.toFixed(1)}px`,
							animationDelay: `${p.delay}ms`,
							animationDuration: `${p.duration}ms`
						},
						"data-tsd-source": "/src/components/VerdictSuccess.tsx:196:13"
					}, p.id, false, {
						fileName: _jsxFileName,
						lineNumber: 196,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 194,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "verdict-crest-pop relative z-10 flex items-center gap-3.5 rounded-2xl border-2 border-[#d6a928] bg-[#0b0b0f]/95 px-5 py-3.5 text-white shadow-[0_16px_40px_rgba(0,0,0,0.55),0_0_30px_rgba(214,169,40,0.45)] backdrop-blur-md",
					"data-tsd-source": "/src/components/VerdictSuccess.tsx:224:9",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "relative flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-[#ffe885] via-[#d6a928] to-[#9a6f0a] p-1.5 shadow-[inset_0_1px_2px_rgba(255,255,255,0.8),0_4px_12px_rgba(214,169,40,0.5)]",
							"data-tsd-source": "/src/components/VerdictSuccess.tsx:226:11",
							children: [/* @__PURE__ */ _jsxDEV("img", {
								src: coinIcon,
								alt: "",
								"aria-hidden": "true",
								className: "h-8 w-8 object-contain drop-shadow-sm animate-spin",
								style: { animationDuration: "1.8s" },
								"data-tsd-source": "/src/components/VerdictSuccess.tsx:227:13"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 227,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(Sparkles, {
								className: "absolute -right-1 -top-1 h-4 w-4 text-[#ffe885] drop-shadow",
								"data-tsd-source": "/src/components/VerdictSuccess.tsx:234:13"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 234,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 226,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col text-left",
							"data-tsd-source": "/src/components/VerdictSuccess.tsx:237:11",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1.5",
								"data-tsd-source": "/src/components/VerdictSuccess.tsx:238:13",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "font-display text-base font-black uppercase tracking-wider bg-gradient-to-r from-[#ffe885] via-[#f5d061] to-[#d6a928] bg-clip-text text-transparent",
									"data-tsd-source": "/src/components/VerdictSuccess.tsx:239:15",
									children: dynamicLabel
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 239,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV(CheckCircle2, {
									className: "h-4 w-4 text-[#d6a928]",
									"data-tsd-source": "/src/components/VerdictSuccess.tsx:242:15"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 242,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 238,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] font-semibold text-zinc-300",
								"data-tsd-source": "/src/components/VerdictSuccess.tsx:244:13",
								children: dynamicSublabel
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 244,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 237,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Coins, {
							className: "ml-1 h-5 w-5 text-[#d6a928]/80 hidden sm:block",
							"aria-hidden": "true",
							"data-tsd-source": "/src/components/VerdictSuccess.tsx:249:11"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 249,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 224,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 182,
			columnNumber: 7
		}, this)]
	}, burstKey, true, {
		fileName: _jsxFileName,
		lineNumber: 164,
		columnNumber: 5
	}, this);
}
_s(VerdictSuccess, "3hDfA7i1GludzSrX39lQ4xe43FM=");
_c = VerdictSuccess;
var _c;
$RefreshReg$(_c, "VerdictSuccess");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/VerdictSuccess.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/VerdictSuccess.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/VerdictSuccess.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/VerdictSuccess.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7Ozs7QUFVQTs7Ozs7QUFNQTtDQUNBO0NBQ0E7QUFDQTtBQWlDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNBO0FBRUEsaUNBQ0EsZ0JBQ0EsWUFDQSxvQkFDQSxvRUFDQSxpQkFDQSxnQkFDQSxzQkFDQSxhQUNBOztDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBRUE7RUFDQTtDQUNBO0NBRUE7RUFDQTtDQUNBO0NBRUE7RUFDQTtHQUNBO0dBQ0E7R0FDQTtJQUNBO0lBQ0E7R0FDQTtHQUNBO0VBQ0E7R0FDQTtFQUNBO0NBQ0E7RUFBQTtFQUFBO0VBQUE7RUFBQTtDQUFBO0NBRUEseUNBQ0E7RUFDQTtFQUNBO0VBQ0E7T0FDQTtFQUNBO09BQ0E7RUFFQTtFQUNBO0VBRUE7RUFDQTtHQUNBO0dBQ0E7RUFDQTtDQUNBLEdBQ0E7RUFBQTtFQUFBO0VBQUE7RUFBQTtDQUFBLENBQ0E7Q0FFQTtFQUNBO0VBQ0E7RUFDQTtHQUNBO0VBQ0E7Q0FDQTs7Q0FHQTtFQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUVBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FDQTtFQUNBO0NBQ0E7Q0FFQTtDQUVBLE9BQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQSxjQUNBLHlGQUNBLCtEQUNBLFNBQ0E7RUFDQTtZQVZBLENBWUE7R0FDQTtHQUNBO0dBQ0E7RUFBTTs7OztZQUdOO0dBQUE7R0FBQTthQUFBO0lBRUE7S0FDQTtLQUNBO0tBQ0E7SUFBUTs7Ozs7SUFDUjtLQUNBO0tBQ0E7S0FDQTtJQUFROzs7OztJQUdSO0tBQUE7S0FBQTtLQUFBO2VBQ0EscUJBQ0E7TUFFQSxjQUNBLDZDQUNBLHdDQUNBLG9EQUNBLGlEQUNBO01BQ0EsT0FDQTtPQUNBO09BQ0E7T0FDQTtPQUNBLFdBQ0Esd0JBQ0EscUNBQ0E7T0FDQTtPQUNBO09BQ0E7T0FDQTtNQUNBO01BRUE7S0FBWSxHQXRCWjs7OztZQXNCWSxDQUNaO0lBQ0E7Ozs7O0lBR0E7S0FBQTtLQUFBO2VBQUE7TUFFQTtPQUFBO09BQUE7aUJBQUEsQ0FDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtPQUFZOzs7O2lCQUNaO1FBQUE7UUFBQTtPQUE4Rjs7OztlQUM5Rjs7Ozs7O01BRUE7T0FBQTtPQUFBO2lCQUFBLENBQ0E7UUFBQTtRQUFBO2tCQUFBLENBQ0E7U0FBQTtTQUFBO21CQUNBO1FBQ0E7Ozs7a0JBQ0E7U0FBQTtTQUFBO1FBQStEOzs7O2dCQUMvRDs7Ozs7aUJBQ0E7UUFBQTtRQUFBO2tCQUNBO09BQ0E7Ozs7ZUFDQTs7Ozs7O01BRUE7T0FBQTtPQUFBO09BQUE7TUFBK0Y7Ozs7O0tBQy9GOzs7Ozs7R0FDQTs7Ozs7VUFDQTtJQXZGQTs7OztRQXVGQTtBQUVBIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJWZXJkaWN0U3VjY2Vzcy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VTdGF0ZSwgdXNlQ2FsbGJhY2sgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IENvaW5zLCBTcGFya2xlcywgQ2hlY2tDaXJjbGUyIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcbmltcG9ydCBjb2luSWNvbiBmcm9tIFwiQC9hc3NldHMvaWNvbi1jb2luLnBuZ1wiO1xuXG5leHBvcnQgaW50ZXJmYWNlIFZlcmRpY3RTdWNjZXNzRXZlbnREZXRhaWwge1xuICBsYWJlbD86IHN0cmluZztcbiAgc3VibGFiZWw/OiBzdHJpbmc7XG4gIG9yaWdpblg/OiBudW1iZXI7XG4gIG9yaWdpblk/OiBudW1iZXI7XG4gIGR1cmF0aW9uPzogbnVtYmVyO1xufVxuXG5jb25zdCBWRVJESUNUX1NVQ0NFU1NfRVZFTlQgPSBcInNvdDp2ZXJkaWN0LXN1Y2Nlc3NcIjtcblxuLyoqXG4gKiBJbXBlcmF0aXZlbHkgdHJpZ2dlciB0aGUgY2VsZWJyYXRvcnkgZ29sZC1kdXN0IFZlcmRpY3RTdWNjZXNzIGFuaW1hdGlvblxuICogZnJvbSBhbnkgU3Rhc2ggYWN0aW9uIGFjcm9zcyB0aGUgYXBwLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdHJpZ2dlclZlcmRpY3RTdWNjZXNzKGRldGFpbDogVmVyZGljdFN1Y2Nlc3NFdmVudERldGFpbCA9IHt9KSB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm47XG4gIHdpbmRvdy5kaXNwYXRjaEV2ZW50KG5ldyBDdXN0b21FdmVudDxWZXJkaWN0U3VjY2Vzc0V2ZW50RGV0YWlsPihWRVJESUNUX1NVQ0NFU1NfRVZFTlQsIHsgZGV0YWlsIH0pKTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBWZXJkaWN0U3VjY2Vzc1Byb3BzIHtcbiAgLyoqIFdoZXRoZXIgdGhlIGdvbGQtZHVzdCBjZWxlYnJhdGlvbiBpcyBjdXJyZW50bHkgYWN0aXZlICovXG4gIGFjdGl2ZT86IGJvb2xlYW47XG4gIC8qKiBPcHRpb25hbCBjYWxsYmFjayBmaXJlZCB3aGVuIHRoZSBjZWxlYnJhdGlvbiBhbmltYXRpb24gZmluaXNoZXMgKi9cbiAgb25Db21wbGV0ZT86ICgpID0+IHZvaWQ7XG4gIC8qKiBIZWFkbGluZSBkaXNwbGF5ZWQgaW4gdGhlIGJsYWNrICYgZ29sZCBjZWxlYnJhdG9yeSBjcmVzdCAqL1xuICBsYWJlbD86IHN0cmluZztcbiAgLyoqIFN1YnRpdGxlIGRpc3BsYXllZCBiZW5lYXRoIHRoZSBoZWFkbGluZSAqL1xuICBzdWJsYWJlbD86IHN0cmluZztcbiAgLyoqIER1cmF0aW9uIGluIG1zIGJlZm9yZSBhdXRvLWNvbXBsZXRpbmcgKGRlZmF1bHQ6IDI0MDBtcykgKi9cbiAgZHVyYXRpb24/OiBudW1iZXI7XG4gIC8qKiBSZW5kZXIgaW5saW5lIGluc2lkZSBhIGNhcmQvY29udGFpbmVyIGluc3RlYWQgb2YgYSBmaXhlZCB2aWV3cG9ydCBvdmVybGF5ICovXG4gIGlubGluZT86IGJvb2xlYW47XG4gIC8qKiBMaXN0ZW4gdG8gZ2xvYmFsIGB0cmlnZ2VyVmVyZGljdFN1Y2Nlc3NgIGV2ZW50cyAodXNlZCBieSByb290IGluc3RhbmNlKSAqL1xuICBsaXN0ZW5HbG9iYWw/OiBib29sZWFuO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBHb2xkRHVzdFBhcnRpY2xlIHtcbiAgaWQ6IG51bWJlcjtcbiAgYW5nbGU6IG51bWJlcjtcbiAgZGlzdGFuY2U6IG51bWJlcjtcbiAgc2l6ZTogbnVtYmVyO1xuICBkZWxheTogbnVtYmVyO1xuICBkdXJhdGlvbjogbnVtYmVyO1xuICBzaGFkZTogc3RyaW5nO1xuICBzaGFwZTogXCJjaXJjbGVcIiB8IFwiZGlhbW9uZFwiIHwgXCJzcGFya1wiO1xuICBkcmlmdFg6IG51bWJlcjtcbiAgZmFsbFk6IG51bWJlcjtcbn1cblxuY29uc3QgR09MRF9TSEFERVMgPSBbXG4gIFwiI0ZGRTg4NVwiLCAvLyBicmlnaHQgc3BlY3VsYXIgZ29sZCBoaWdobGlnaHRcbiAgXCIjRjVEMDYxXCIsIC8vIHdhcm0gY2hhbXBhZ25lIGdvbGRcbiAgXCIjRDZBOTI4XCIsIC8vIHNpZ25hdHVyZSBTT1QgYnJhbmQgZ29sZFxuICBcIiNCODg2MEJcIiwgLy8gZGVlcCBidXJuaXNoZWQgYnVsbGlvbiBnb2xkXG4gIFwiI0ZGRjZDQ1wiLCAvLyB3aGl0ZS1nb2xkIGdsaW50XG4gIFwiIzExMTExNVwiLCAvLyBqZXQtYmxhY2sgY29udHJhc3QgZmxlY2tcbl07XG5cbmV4cG9ydCBmdW5jdGlvbiBWZXJkaWN0U3VjY2Vzcyh7XG4gIGFjdGl2ZSA9IGZhbHNlLFxuICBvbkNvbXBsZXRlLFxuICBsYWJlbCA9IFwiU1RBU0hFRCFcIixcbiAgc3VibGFiZWwgPSBcIktlZXAgd2hhdCBzZXJ2ZXMgeW91IMK3IEdvbGQgc3RhbmRhcmQgdmVyZGljdCByZWNvcmRlZFwiLFxuICBkdXJhdGlvbiA9IDI0MDAsXG4gIGlubGluZSA9IGZhbHNlLFxuICBsaXN0ZW5HbG9iYWwgPSBmYWxzZSxcbiAgY2xhc3NOYW1lLFxufTogVmVyZGljdFN1Y2Nlc3NQcm9wcykge1xuICBjb25zdCBbaXNWaXNpYmxlLCBzZXRJc1Zpc2libGVdID0gdXNlU3RhdGUoYWN0aXZlKTtcbiAgY29uc3QgW2J1cnN0S2V5LCBzZXRCdXJzdEtleV0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW2R5bmFtaWNMYWJlbCwgc2V0RHluYW1pY0xhYmVsXSA9IHVzZVN0YXRlKGxhYmVsKTtcbiAgY29uc3QgW2R5bmFtaWNTdWJsYWJlbCwgc2V0RHluYW1pY1N1YmxhYmVsXSA9IHVzZVN0YXRlKHN1YmxhYmVsKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNldER5bmFtaWNMYWJlbChsYWJlbCk7XG4gIH0sIFtsYWJlbF0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2V0RHluYW1pY1N1YmxhYmVsKHN1YmxhYmVsKTtcbiAgfSwgW3N1YmxhYmVsXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoYWN0aXZlKSB7XG4gICAgICBzZXRJc1Zpc2libGUodHJ1ZSk7XG4gICAgICBzZXRCdXJzdEtleSgoaykgPT4gayArIDEpO1xuICAgICAgY29uc3QgdGltZXIgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldElzVmlzaWJsZShmYWxzZSk7XG4gICAgICAgIG9uQ29tcGxldGU/LigpO1xuICAgICAgfSwgZHVyYXRpb24pO1xuICAgICAgcmV0dXJuICgpID0+IHdpbmRvdy5jbGVhclRpbWVvdXQodGltZXIpO1xuICAgIH0gZWxzZSBpZiAoIWxpc3Rlbkdsb2JhbCkge1xuICAgICAgc2V0SXNWaXNpYmxlKGZhbHNlKTtcbiAgICB9XG4gIH0sIFthY3RpdmUsIGR1cmF0aW9uLCBvbkNvbXBsZXRlLCBsaXN0ZW5HbG9iYWxdKTtcblxuICBjb25zdCBoYW5kbGVHbG9iYWxUcmlnZ2VyID0gdXNlQ2FsbGJhY2soXG4gICAgKGU6IEV2ZW50KSA9PiB7XG4gICAgICBjb25zdCBjdXN0b21FdmVudCA9IGUgYXMgQ3VzdG9tRXZlbnQ8VmVyZGljdFN1Y2Nlc3NFdmVudERldGFpbD47XG4gICAgICBjb25zdCBkZXRhaWwgPSBjdXN0b21FdmVudC5kZXRhaWwgPz8ge307XG4gICAgICBpZiAoZGV0YWlsLmxhYmVsKSBzZXREeW5hbWljTGFiZWwoZGV0YWlsLmxhYmVsKTtcbiAgICAgIGVsc2Ugc2V0RHluYW1pY0xhYmVsKGxhYmVsKTtcbiAgICAgIGlmIChkZXRhaWwuc3VibGFiZWwpIHNldER5bmFtaWNTdWJsYWJlbChkZXRhaWwuc3VibGFiZWwpO1xuICAgICAgZWxzZSBzZXREeW5hbWljU3VibGFiZWwoc3VibGFiZWwpO1xuXG4gICAgICBzZXRJc1Zpc2libGUodHJ1ZSk7XG4gICAgICBzZXRCdXJzdEtleSgoaykgPT4gayArIDEpO1xuXG4gICAgICBjb25zdCBhY3RpdmVEdXJhdGlvbiA9IGRldGFpbC5kdXJhdGlvbiA/PyBkdXJhdGlvbjtcbiAgICAgIHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0SXNWaXNpYmxlKGZhbHNlKTtcbiAgICAgICAgb25Db21wbGV0ZT8uKCk7XG4gICAgICB9LCBhY3RpdmVEdXJhdGlvbik7XG4gICAgfSxcbiAgICBbZHVyYXRpb24sIGxhYmVsLCBzdWJsYWJlbCwgb25Db21wbGV0ZV0sXG4gICk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWxpc3Rlbkdsb2JhbCB8fCB0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm47XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoVkVSRElDVF9TVUNDRVNTX0VWRU5ULCBoYW5kbGVHbG9iYWxUcmlnZ2VyKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoVkVSRElDVF9TVUNDRVNTX0VWRU5ULCBoYW5kbGVHbG9iYWxUcmlnZ2VyKTtcbiAgICB9O1xuICB9LCBbbGlzdGVuR2xvYmFsLCBoYW5kbGVHbG9iYWxUcmlnZ2VyXSk7XG5cbiAgLy8gRGV0ZXJtaW5pc3RpYyB5ZXQgcmljaCA0OC1wYXJ0aWNsZSBnb2xkLWR1c3QgY2xvdWQgcGVyIGJ1cnN0XG4gIGNvbnN0IHBhcnRpY2xlcyA9IHVzZU1lbW88R29sZER1c3RQYXJ0aWNsZVtdPigoKSA9PiB7XG4gICAgcmV0dXJuIEFycmF5LmZyb20oeyBsZW5ndGg6IDQ4IH0sIChfLCBpKSA9PiB7XG4gICAgICBjb25zdCBzZWVkID0gKGkgKiAzNyArIGJ1cnN0S2V5ICogMTMpICUgMTAwO1xuICAgICAgY29uc3QgYW5nbGUgPSAoaSAvIDQ4KSAqIE1hdGguUEkgKiAyICsgKHNlZWQgJSA3KSAqIDAuMDg7XG4gICAgICBjb25zdCByaW5nID0gaSAlIDM7IC8vIGlubmVyLCBtaWRkbGUsIG91dGVyIHJhZGlhbCByaW5nc1xuICAgICAgY29uc3QgZGlzdGFuY2UgPSA0OCArIHJpbmcgKiA1NSArIChzZWVkICUgNDUpO1xuICAgICAgY29uc3Qgc2l6ZSA9IHJpbmcgPT09IDAgPyA0ICsgKHNlZWQgJSA0KSA6IHJpbmcgPT09IDEgPyA2ICsgKHNlZWQgJSA1KSA6IDMgKyAoc2VlZCAlIDQpO1xuICAgICAgY29uc3QgZGVsYXkgPSAoaSAlIDgpICogMjg7XG4gICAgICBjb25zdCBwYXJ0RHVyYXRpb24gPSAxMTAwICsgKHNlZWQgJSA5MDApO1xuICAgICAgY29uc3Qgc2hhZGUgPSBHT0xEX1NIQURFU1tpICUgR09MRF9TSEFERVMubGVuZ3RoXTtcbiAgICAgIGNvbnN0IHNoYXBlID0gaSAlIDUgPT09IDAgPyBcInNwYXJrXCIgOiBpICUgMiA9PT0gMCA/IFwiZGlhbW9uZFwiIDogXCJjaXJjbGVcIjtcbiAgICAgIGNvbnN0IGRyaWZ0WCA9IE1hdGguY29zKGFuZ2xlKSAqIGRpc3RhbmNlO1xuICAgICAgY29uc3QgZmFsbFkgPSBNYXRoLnNpbihhbmdsZSkgKiBkaXN0YW5jZSArIDI4OyAvLyBzbGlnaHQgZ3Jhdml0eSBzZXR0bGVcblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgaWQ6IGksXG4gICAgICAgIGFuZ2xlLFxuICAgICAgICBkaXN0YW5jZSxcbiAgICAgICAgc2l6ZSxcbiAgICAgICAgZGVsYXksXG4gICAgICAgIGR1cmF0aW9uOiBwYXJ0RHVyYXRpb24sXG4gICAgICAgIHNoYWRlLFxuICAgICAgICBzaGFwZSxcbiAgICAgICAgZHJpZnRYLFxuICAgICAgICBmYWxsWSxcbiAgICAgIH07XG4gICAgfSk7XG4gIH0sIFtidXJzdEtleV0pO1xuXG4gIGlmICghaXNWaXNpYmxlKSByZXR1cm4gbnVsbDtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGtleT17YnVyc3RLZXl9XG4gICAgICByb2xlPVwic3RhdHVzXCJcbiAgICAgIGFyaWEtbGl2ZT1cInBvbGl0ZVwiXG4gICAgICBkYXRhLXRlc3RpZD1cInZlcmRpY3Qtc3VjY2Vzc1wiXG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcInBvaW50ZXItZXZlbnRzLW5vbmUgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW4gc2VsZWN0LW5vbmVcIixcbiAgICAgICAgaW5saW5lID8gXCJhYnNvbHV0ZSBpbnNldC0wIHJvdW5kZWQtaW5oZXJpdFwiIDogXCJmaXhlZCBpbnNldC0wXCIsXG4gICAgICAgIGNsYXNzTmFtZSxcbiAgICAgICl9XG4gICAgPlxuICAgICAgey8qIFN1YnRsZSByYWRpYWwgZ29sZC1hbmQtYmxhY2sgYXRtb3NwaGVyaWMgdmlnbmV0dGUgKi99XG4gICAgICA8ZGl2XG4gICAgICAgIGFyaWEtaGlkZGVuPVwidHJ1ZVwiXG4gICAgICAgIGNsYXNzTmFtZT1cInZlcmRpY3QtZ29sZC1hdXJhIGFic29sdXRlIGluc2V0LTBcIlxuICAgICAgLz5cblxuICAgICAgey8qIENlbnRyYWwgR29sZC1EdXN0IFBhcnRpY2xlIEJ1cnN0IFN0YWdlICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICB7LyogRXhwYW5kaW5nIEdvbGQgU2hvY2t3YXZlIFJpbmdzICovfVxuICAgICAgICA8ZGl2XG4gICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJ2ZXJkaWN0LXNob2Nrd2F2ZS1yaW5nIGFic29sdXRlIGgtMjggdy0yOCByb3VuZGVkLWZ1bGwgYm9yZGVyLTIgYm9yZGVyLVsjZDZhOTI4XVwiXG4gICAgICAgIC8+XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICAgIGNsYXNzTmFtZT1cInZlcmRpY3Qtc2hvY2t3YXZlLXJpbmctZGVsYXllZCBhYnNvbHV0ZSBoLTQwIHctNDAgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItWyNmZmU4ODVdLzcwXCJcbiAgICAgICAgLz5cblxuICAgICAgICB7LyogU2hpbW1lcmluZyBHb2xkLUR1c3QgUGFydGljbGVzICovfVxuICAgICAgICA8ZGl2IGFyaWEtaGlkZGVuPVwidHJ1ZVwiIGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtMCB3LTBcIj5cbiAgICAgICAgICB7cGFydGljbGVzLm1hcCgocCkgPT4gKFxuICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAga2V5PXtwLmlkfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgIFwidmVyZGljdC1nb2xkLWR1c3QtcGFydGljbGUgYWJzb2x1dGUgYmxvY2tcIixcbiAgICAgICAgICAgICAgICBwLnNoYXBlID09PSBcImNpcmNsZVwiICYmIFwicm91bmRlZC1mdWxsXCIsXG4gICAgICAgICAgICAgICAgcC5zaGFwZSA9PT0gXCJkaWFtb25kXCIgJiYgXCJyb3RhdGUtNDUgcm91bmRlZC1bMnB4XVwiLFxuICAgICAgICAgICAgICAgIHAuc2hhcGUgPT09IFwic3BhcmtcIiAmJiBcInJvdW5kZWQtZnVsbCBzY2FsZS14LTE1MFwiLFxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICBzdHlsZT17XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgd2lkdGg6IGAke3Auc2l6ZX1weGAsXG4gICAgICAgICAgICAgICAgICBoZWlnaHQ6IGAke3Auc2l6ZX1weGAsXG4gICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHAuc2hhZGUsXG4gICAgICAgICAgICAgICAgICBib3hTaGFkb3c6XG4gICAgICAgICAgICAgICAgICAgIHAuc2hhZGUgPT09IFwiIzExMTExNVwiXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIjAgMCA2cHggcmdiYSgyMTQsIDE2OSwgNDAsIDAuODUpXCJcbiAgICAgICAgICAgICAgICAgICAgICA6IGAwIDAgJHtwLnNpemUgKiAyfXB4ICR7cC5zaGFkZX0sIDAgMCAke3Auc2l6ZX1weCAjZmZmZmZmYCxcbiAgICAgICAgICAgICAgICAgIFwiLS10eFwiOiBgJHtwLmRyaWZ0WC50b0ZpeGVkKDEpfXB4YCxcbiAgICAgICAgICAgICAgICAgIFwiLS10eVwiOiBgJHtwLmZhbGxZLnRvRml4ZWQoMSl9cHhgLFxuICAgICAgICAgICAgICAgICAgYW5pbWF0aW9uRGVsYXk6IGAke3AuZGVsYXl9bXNgLFxuICAgICAgICAgICAgICAgICAgYW5pbWF0aW9uRHVyYXRpb246IGAke3AuZHVyYXRpb259bXNgLFxuICAgICAgICAgICAgICAgIH0gYXMgUmVhY3QuQ1NTUHJvcGVydGllc1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogU2lnbmF0dXJlIEJsYWNrICYgR29sZCBDZWxlYnJhdG9yeSBWZXJkaWN0IENyZXN0ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInZlcmRpY3QtY3Jlc3QtcG9wIHJlbGF0aXZlIHotMTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMuNSByb3VuZGVkLTJ4bCBib3JkZXItMiBib3JkZXItWyNkNmE5MjhdIGJnLVsjMGIwYjBmXS85NSBweC01IHB5LTMuNSB0ZXh0LXdoaXRlIHNoYWRvdy1bMF8xNnB4XzQwcHhfcmdiYSgwLDAsMCwwLjU1KSwwXzBfMzBweF9yZ2JhKDIxNCwxNjksNDAsMC40NSldIGJhY2tkcm9wLWJsdXItbWRcIj5cbiAgICAgICAgICB7LyogR2xlYW1pbmcgU3Bpbm5pbmcgR29sZCBDb2luIEVtYmxlbSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggaC0xMSB3LTExIHNocmluay0wIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tWyNmZmU4ODVdIHZpYS1bI2Q2YTkyOF0gdG8tWyM5YTZmMGFdIHAtMS41IHNoYWRvdy1baW5zZXRfMF8xcHhfMnB4X3JnYmEoMjU1LDI1NSwyNTUsMC44KSwwXzRweF8xMnB4X3JnYmEoMjE0LDE2OSw0MCwwLjUpXVwiPlxuICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICBzcmM9e2NvaW5JY29ufVxuICAgICAgICAgICAgICBhbHQ9XCJcIlxuICAgICAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggdy04IG9iamVjdC1jb250YWluIGRyb3Atc2hhZG93LXNtIGFuaW1hdGUtc3BpblwiXG4gICAgICAgICAgICAgIHN0eWxlPXt7IGFuaW1hdGlvbkR1cmF0aW9uOiBcIjEuOHNcIiB9fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtcmlnaHQtMSAtdG9wLTEgaC00IHctNCB0ZXh0LVsjZmZlODg1XSBkcm9wLXNoYWRvd1wiIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgdGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtYmFzZSBmb250LWJsYWNrIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBiZy1ncmFkaWVudC10by1yIGZyb20tWyNmZmU4ODVdIHZpYS1bI2Y1ZDA2MV0gdG8tWyNkNmE5MjhdIGJnLWNsaXAtdGV4dCB0ZXh0LXRyYW5zcGFyZW50XCI+XG4gICAgICAgICAgICAgICAge2R5bmFtaWNMYWJlbH1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1bI2Q2YTkyOF1cIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtemluYy0zMDBcIj5cbiAgICAgICAgICAgICAge2R5bmFtaWNTdWJsYWJlbH1cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxDb2lucyBjbGFzc05hbWU9XCJtbC0xIGgtNSB3LTUgdGV4dC1bI2Q2YTkyOF0vODAgaGlkZGVuIHNtOmJsb2NrXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL2FwcC9hcHBsZXQvc3JjL2NvbXBvbmVudHMvVmVyZGljdFN1Y2Nlc3MudHN4In0=