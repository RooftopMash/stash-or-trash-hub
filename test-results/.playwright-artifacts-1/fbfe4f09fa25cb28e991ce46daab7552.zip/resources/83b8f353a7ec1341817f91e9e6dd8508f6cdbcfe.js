import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/__root.tsx");const useEffect = __vite__cjsImport2_react["useEffect"];const _jsxDEV = __vite__cjsImport15_react_jsxDevRuntime["jsxDEV"];import { QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=a8030269";
import { Outlet, Link, createRootRouteWithContext, useRouter, HeadContent, Scripts } from "/node_modules/@tanstack/react-router/dist/esm/index.dev.js?v=a8030269";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { Toaster } from "/node_modules/.vite/deps/sonner.js?v=a8030269";
import appCss from "/src/styles.css?url";
import { reportApplicationError } from "/src/lib/error-reporting.ts";
import { installProductionSecurityShield } from "/src/lib/security-shield.ts";
import { AppErrorBoundary } from "/src/components/AppErrorBoundary.tsx";
import { AuthProvider } from "/src/hooks/useAuth.tsx";
import { OfflineStatus } from "/src/components/OfflineStatus.tsx";
import { ProductionMonitoring } from "/src/components/ProductionMonitoring.tsx";
import { VerdictSuccess } from "/src/components/VerdictSuccess.tsx";
import { autoSeedFirestoreIfEmpty } from "/src/lib/seedFirestore.ts";
import { SeoHelmet } from "/src/components/SeoHelmet.tsx";
import "/src/lib/i18n.ts";
var _jsxFileName = "/app/applet/src/routes/__root.tsx";
import __vite__cjsImport15_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const BRAND_BAROMETER_SCHEMA = {
	"@context": "https://schema.org",
	"@graph": [{
		"@type": "Organization",
		"@id": "https://stash-or-trash-hub.vercel.app/#organization",
		name: "SOT — Stash Or Trash",
		url: "https://stash-or-trash-hub.vercel.app",
		logo: "https://stash-or-trash-hub.vercel.app/apple-touch-icon.png",
		description: "SOT is the global Brand Barometer providing authentic customer reviews, trust ratings, and anti-counterfeit verification."
	}, {
		"@type": "WebApplication",
		"@id": "https://stash-or-trash-hub.vercel.app/#webapp",
		name: "SOT — Stash Or Trash | Brand Barometer",
		url: "https://stash-or-trash-hub.vercel.app",
		description: "Live CX & PR platform where consumers deliver real-time verdicts on brands with verified proof.",
		applicationCategory: "BusinessApplication",
		operatingSystem: "All",
		offers: {
			"@type": "Offer",
			price: "0",
			priceCurrency: "USD"
		}
	}]
};
function NotFoundComponent() {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		"data-tsd-source": "/src/routes/__root.tsx:58:5",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-md text-center",
			"data-tsd-source": "/src/routes/__root.tsx:59:7",
			children: [
				/* @__PURE__ */ _jsxDEV("h1", {
					className: "text-7xl font-bold text-foreground",
					"data-tsd-source": "/src/routes/__root.tsx:60:9",
					children: "404"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					"data-tsd-source": "/src/routes/__root.tsx:61:9",
					children: "Page not found"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-muted-foreground",
					"data-tsd-source": "/src/routes/__root.tsx:62:9",
					children: "The page you're looking for doesn't exist or has been moved."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-6",
					"data-tsd-source": "/src/routes/__root.tsx:65:9",
					children: /* @__PURE__ */ _jsxDEV(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						"data-tsd-source": "/src/routes/__root.tsx:66:11",
						children: "Go home"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 10
	}, this);
}
_c = NotFoundComponent;
function ErrorComponent({ error, reset }) {
	_s();
	const router = useRouter();
	useEffect(() => {
		reportApplicationError(error instanceof Error ? error : new Error(String(error)), { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ _jsxDEV("div", {
		role: "alert",
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		"data-tsd-source": "/src/routes/__root.tsx:85:5",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-md rounded-2xl border border-border bg-card p-8 text-center shadow-sm",
			"data-tsd-source": "/src/routes/__root.tsx:86:7",
			children: [
				/* @__PURE__ */ _jsxDEV("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					"data-tsd-source": "/src/routes/__root.tsx:87:9",
					children: "Something went wrong, please refresh"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 text-sm text-muted-foreground",
					"data-tsd-source": "/src/routes/__root.tsx:90:9",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					"data-tsd-source": "/src/routes/__root.tsx:93:9",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						"data-tsd-source": "/src/routes/__root.tsx:94:11",
						children: "Try again"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						"data-tsd-source": "/src/routes/__root.tsx:103:11",
						children: "Go home"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 70,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 69,
		columnNumber: 10
	}, this);
}
_s(ErrorComponent, "g4BU1bO32KZmjSq/EmV92VkGdF0=", false, function() {
	return [useRouter];
});
_c2 = ErrorComponent;
export const Route = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover"
			},
			{
				name: "theme-color",
				content: "#000000"
			},
			{
				name: "mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "apple-mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "apple-mobile-web-app-status-bar-style",
				content: "black-translucent"
			},
			{
				name: "apple-mobile-web-app-title",
				content: "SOrT"
			},
			{ title: "SOT — Stash Or Trash | Brand Barometer & Consumer Reviews" },
			{
				name: "description",
				content: "SOT (Stash Or Trash) is the Brand Barometer — a live CX/UX verdict platform for authentic consumer brand reviews and accountability. Cast your verdict now."
			},
			{
				name: "author",
				content: "SOT — Stash Or Trash"
			},
			{
				property: "og:title",
				content: "SOT — Stash Or Trash | Brand Barometer & Consumer Reviews"
			},
			{
				property: "og:description",
				content: "SOT (Stash Or Trash) is the Brand Barometer — a live CX/UX verdict platform for authentic consumer brand reviews and accountability. Cast your verdict now."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:title",
				content: "SOT — Stash Or Trash | Brand Barometer & Consumer Reviews"
			},
			{
				name: "twitter:description",
				content: "SOT (Stash Or Trash) is the Brand Barometer — a live CX/UX verdict platform for authentic consumer brand reviews and accountability. Cast your verdict now."
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: appCss
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			},
			{
				rel: "icon",
				type: "image/png",
				sizes: "96x96",
				href: "/favicon-96x96.png"
			},
			{
				rel: "icon",
				type: "image/png",
				sizes: "192x192",
				href: "/icon-192x192.png"
			},
			{
				rel: "icon",
				type: "image/png",
				sizes: "512x512",
				href: "/icon-512x512.png"
			},
			{
				rel: "apple-touch-icon",
				sizes: "180x180",
				href: "/apple-touch-icon.png"
			},
			{
				rel: "manifest",
				href: "/manifest.json"
			},
			{
				rel: "manifest",
				href: "/site.webmanifest"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "preconnect",
				href: "https://apis.google.com"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700;12..96,800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ _jsxDEV("html", {
		lang: "en",
		suppressHydrationWarning: true,
		"data-tsd-source": "/src/routes/__root.tsx:179:5",
		children: [/* @__PURE__ */ _jsxDEV("head", {
			"data-tsd-source": "/src/routes/__root.tsx:180:7",
			children: [/* @__PURE__ */ _jsxDEV(HeadContent, { "data-tsd-source": "/src/routes/__root.tsx:181:9" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 201,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("script", {
				dangerouslySetInnerHTML: { __html: `
              if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
                function registerSW() {
                  navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(function() {});
                }
                if (document.readyState === 'complete' || document.readyState === 'interactive') {
                  registerSW();
                } else {
                  window.addEventListener('load', registerSW);
                }
              }
            ` },
				"data-tsd-source": "/src/routes/__root.tsx:182:9"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 202,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 200,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("body", {
			suppressHydrationWarning: true,
			"data-tsd-source": "/src/routes/__root.tsx:199:7",
			children: [children, /* @__PURE__ */ _jsxDEV(Scripts, { "data-tsd-source": "/src/routes/__root.tsx:201:9" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 219,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 217,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 199,
		columnNumber: 10
	}, this);
}
_c3 = RootShell;
function RootComponent() {
	_s2();
	const { queryClient } = Route.useRouteContext();
	useEffect(() => {
		installProductionSecurityShield();
		autoSeedFirestoreIfEmpty();
		// Register PWA Service Worker for store package & offline caching
		if (typeof window !== "undefined" && "serviceWorker" in navigator) {
			const runRegister = () => {
				navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(() => {});
			};
			if (document.readyState === "complete" || document.readyState === "interactive") {
				runRegister();
			} else {
				window.addEventListener("load", runRegister);
			}
		}
	}, []);
	return /* @__PURE__ */ _jsxDEV(AppErrorBoundary, {
		"data-tsd-source": "/src/routes/__root.tsx:228:5",
		children: /* @__PURE__ */ _jsxDEV(QueryClientProvider, {
			client: queryClient,
			"data-tsd-source": "/src/routes/__root.tsx:229:7",
			children: /* @__PURE__ */ _jsxDEV(AuthProvider, {
				"data-tsd-source": "/src/routes/__root.tsx:230:9",
				children: [
					/* @__PURE__ */ _jsxDEV(SeoHelmet, {
						structuredData: BRAND_BAROMETER_SCHEMA,
						"data-tsd-source": "/src/routes/__root.tsx:231:11"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 248,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Outlet, { "data-tsd-source": "/src/routes/__root.tsx:233:11" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 250,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(VerdictSuccess, {
						listenGlobal: true,
						"data-tsd-source": "/src/routes/__root.tsx:234:11"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 251,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Toaster, {
						position: "top-center",
						richColors: true,
						"data-tsd-source": "/src/routes/__root.tsx:235:11"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 252,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(OfflineStatus, { "data-tsd-source": "/src/routes/__root.tsx:236:11" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 253,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(ProductionMonitoring, { "data-tsd-source": "/src/routes/__root.tsx:237:11" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 254,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 247,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 246,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 245,
		columnNumber: 10
	}, this);
}
_s2(RootComponent, "8sgJGTDdadnK/b+LGJrnHjvqvRU=", false, function() {
	return [Route.useRouteContext];
});
_c4 = RootComponent;
const hot = import.meta.hot;
if (hot && typeof window !== "undefined") {
	hot.data ??= {};
	const tsrReactRefresh = window.__TSR_REACT_REFRESH__ ??= (() => {
		const ignoredExportsById = new Map();
		const previousGetIgnoredExports = window.__getReactRefreshIgnoredExports;
		window.__getReactRefreshIgnoredExports = (ctx) => {
			const ignoredExports = previousGetIgnoredExports?.(ctx) ?? [];
			const moduleIgnored = ignoredExportsById.get(ctx.id) ?? [];
			return [...ignoredExports, ...moduleIgnored];
		};
		return { ignoredExportsById };
	})();
	tsrReactRefresh.ignoredExportsById.set("/app/applet/src/routes/__root.tsx", ["Route"]);
}
export function TSRFastRefreshAnchor() {
	return null;
}
_c5 = TSRFastRefreshAnchor;
if (import.meta.hot) {
	const hot = import.meta.hot;
	const hotData = hot.data ??= {};
	const handleRouteUpdate = function handleRouteUpdate(routeId, newRoute) {
		const router = window.__TSR_ROUTER__;
		const oldRoute = router.routesById[routeId];
		if (!oldRoute) return;
		const generatedRouteOptionKeys = new Set([
			"id",
			"path",
			"getParentRoute"
		]);
		const generatedRouteOptions = {};
		generatedRouteOptionKeys.forEach((key) => {
			if (key in oldRoute.options) generatedRouteOptions[key] = oldRoute.options[key];
		});
		const preserveComponentIdentity = "shellComponent" in oldRoute.options === "shellComponent" in newRoute.options;
		const componentKeys = [
			"component",
			"shellComponent",
			"pendingComponent",
			"errorComponent",
			"notFoundComponent"
		];
		if (preserveComponentIdentity) componentKeys.forEach((key) => {
			if (key in oldRoute.options && key in newRoute.options) newRoute.options[key] = oldRoute.options[key];
		});
		const nextOptions = {
			...newRoute.options,
			...generatedRouteOptions
		};
		oldRoute.options = nextOptions;
		oldRoute.update(nextOptions);
		router._replaceRouteChunk(oldRoute, newRoute.lazyFn);
		router.setRoutes(router.buildRouteTree());
		syncHotRouteExport(oldRoute);
		router.resolvePathCache.clear();
		router._refreshRoute?.();
		function syncHotRouteExport(liveRoute) {
			newRoute.options = liveRoute.options;
			newRoute.parentRoute = liveRoute.parentRoute;
			newRoute._path = liveRoute._path;
			newRoute._id = liveRoute._id;
			newRoute._fullPath = liveRoute._fullPath;
			newRoute._to = liveRoute._to;
		}
	};
	const initialRouteId = "__root__" ?? hotData["tsr-route-id"];
	if (initialRouteId) {
		hotData["tsr-route-id"] = initialRouteId;
	}
	const existingRoute = typeof window !== "undefined" && initialRouteId ? window.__TSR_ROUTER__?.routesById?.[initialRouteId] : undefined;
	if (initialRouteId && existingRoute && existingRoute !== Route) {
		handleRouteUpdate(initialRouteId, Route);
		hotData["tsr-route-update-handled"] = Route;
	}
	hot.accept((newModule) => {
		if (Route && newModule && newModule.Route) {
			const routeId = hotData["tsr-route-id"] ?? "__root__";
			if (routeId) {
				hotData["tsr-route-id"] = routeId;
			}
			if (hotData["tsr-route-update-handled"] === newModule.Route) {
				delete hotData["tsr-route-update-handled"];
				return;
			}
			handleRouteUpdate(routeId, newModule.Route);
		}
	});
}
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "NotFoundComponent");
$RefreshReg$(_c2, "ErrorComponent");
$RefreshReg$(_c3, "RootShell");
$RefreshReg$(_c4, "RootComponent");
$RefreshReg$(_c5, "TSRFastRefreshAnchor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/__root.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/routes/__root.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/routes/__root.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/routes/__root.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsU0FBQUEsMkJBQUE7QUFDQSxTQUNBQyxRQUNBQyxNQUNBQyw0QkFDQUMsV0FDQUMsYUFDQUMsZUFDQTtBQUNBLFNBQUFDLGlCQUFBO0FBRUEsU0FBQUMsZUFBQTtBQUVBLE9BQUFDLFlBQUE7QUFDQSxTQUFBQyw4QkFBQTtBQUNBLFNBQUFDLHVDQUFBO0FBQ0EsU0FBQUMsd0JBQUE7QUFDQSxTQUFBQyxvQkFBQTtBQUNBLFNBQUFDLHFCQUFBO0FBQ0EsU0FBQUMsNEJBQUE7QUFDQSxTQUFBQyxzQkFBQTtBQUNBLFNBQUFDLGdDQUFBO0FBQ0EsU0FBQUMsaUJBQUE7QUFDQTs7OztBQUVBLE1BQUFDLHlCQUFBO0NBQ0E7Q0FDQSxXQUNBO0VBQ0E7RUFDQTtFQUNBQyxNQUFBO0VBQ0FDLEtBQUE7RUFDQUMsTUFBQTtFQUNBQyxhQUNBO0NBQ0EsR0FDQTtFQUNBO0VBQ0E7RUFDQUgsTUFBQTtFQUNBQyxLQUFBO0VBQ0FFLGFBQ0E7RUFDQUMscUJBQUE7RUFDQUMsaUJBQUE7RUFDQUMsUUFBQTtHQUNBO0dBQ0FDLE9BQUE7R0FDQUMsZUFBQTtFQUNBO0NBQ0E7QUFFQTtBQUVBLFNBQUFDLG9CQUFBO0NBQ0EsT0FDQTtFQUFBO0VBQUE7WUFDQTtHQUFBO0dBQUE7YUFBQTtJQUNBO0tBQUE7S0FBQTtlQUEwRDtJQUFBOzs7OztJQUMxRDtLQUFBO0tBQUE7ZUFBa0U7SUFBQTs7Ozs7SUFDbEU7S0FBQTtLQUFBO2VBQXlEO0lBRXpEOzs7OztJQUNBO0tBQUE7S0FBQTtlQUNBO01BQ0E7TUFDQTtNQUNBO2dCQUFVO0tBRVY7Ozs7O0lBQ0E7Ozs7O0dBQ0E7Ozs7OztDQUNBOzs7OztBQUVBOztBQUVBLFNBQUFDLGVBQUEsRUFBQUMsT0FBQUMsU0FBQTs7Q0FDQSxNQUFBQyxTQUFBN0IsVUFBQTtDQUNBRyxnQkFBQTtFQUNBRyx1QkFBQXFCLGlCQUFBRyxRQUFBSCxRQUFBLElBQUFHLE1BQUFDLE9BQUFKLEtBQUEsTUFBQUssVUFBQTtDQUNBLElBQUFMLEtBQUE7Q0FFQSxPQUNBO0VBQUE7RUFBQTtFQUFBO1lBQ0E7R0FBQTtHQUFBO2FBQUE7SUFDQTtLQUFBO0tBQUE7ZUFBNEU7SUFFNUU7Ozs7O0lBQ0E7S0FBQTtLQUFBO2VBQXlEO0lBRXpEOzs7OztJQUNBO0tBQUE7S0FBQTtlQUFBLENBQ0E7TUFDQTtPQUNBRSxPQUFBSSxXQUFBO09BQ0FMLE1BQUE7TUFDQTtNQUNBO01BQ0E7Z0JBQVU7S0FFVjs7OztlQUNBO01BQ0E7TUFDQTtNQUNBO2dCQUFVO0tBRVY7Ozs7YUFDQTs7Ozs7O0dBQ0E7Ozs7OztDQUNBOzs7OztBQUVBOzs7OztBQUVBLGFBQUFNLFFBQUFuQywyQkFBQTtDQUNBb0MsYUFBQTtFQUNBQyxNQUFBO0dBQ0EsRUFBQUMsU0FBQTtHQUNBO0lBQ0FyQixNQUFBO0lBQ0FzQixTQUFBO0dBQ0E7R0FDQTtJQUFBdEIsTUFBQTtJQUFBc0IsU0FBQTtHQUFBO0dBQ0E7SUFBQXRCLE1BQUE7SUFBQXNCLFNBQUE7R0FBQTtHQUNBO0lBQUF0QixNQUFBO0lBQUFzQixTQUFBO0dBQUE7R0FDQTtJQUFBdEIsTUFBQTtJQUFBc0IsU0FBQTtHQUFBO0dBQ0E7SUFBQXRCLE1BQUE7SUFBQXNCLFNBQUE7R0FBQTtHQUNBLEVBQUFDLE9BQUE7R0FDQTtJQUNBdkIsTUFBQTtJQUNBc0IsU0FDQTtHQUNBO0dBQ0E7SUFBQXRCLE1BQUE7SUFBQXNCLFNBQUE7R0FBQTtHQUNBO0lBQUFFLFVBQUE7SUFBQUYsU0FBQTtHQUFBO0dBQ0E7SUFDQUUsVUFBQTtJQUNBRixTQUNBO0dBQ0E7R0FDQTtJQUFBRSxVQUFBO0lBQUFGLFNBQUE7R0FBQTtHQUNBO0lBQUF0QixNQUFBO0lBQUFzQixTQUFBO0dBQUE7R0FDQTtJQUFBdEIsTUFBQTtJQUFBc0IsU0FBQTtHQUFBO0dBQ0E7SUFDQXRCLE1BQUE7SUFDQXNCLFNBQ0E7R0FDQTtFQUFBO0VBRUFHLE9BQUE7R0FDQTtJQUNBQyxLQUFBO0lBQ0FDLE1BQUF0QztHQUNBO0dBQ0E7SUFBQXFDLEtBQUE7SUFBQUMsTUFBQTtJQUFBQyxNQUFBO0dBQUE7R0FDQTtJQUFBRixLQUFBO0lBQUFFLE1BQUE7SUFBQUMsT0FBQTtJQUFBRixNQUFBO0dBQUE7R0FDQTtJQUFBRCxLQUFBO0lBQUFFLE1BQUE7SUFBQUMsT0FBQTtJQUFBRixNQUFBO0dBQUE7R0FDQTtJQUFBRCxLQUFBO0lBQUFFLE1BQUE7SUFBQUMsT0FBQTtJQUFBRixNQUFBO0dBQUE7R0FDQTtJQUFBRCxLQUFBO0lBQUFHLE9BQUE7SUFBQUYsTUFBQTtHQUFBO0dBQ0E7SUFBQUQsS0FBQTtJQUFBQyxNQUFBO0dBQUE7R0FDQTtJQUFBRCxLQUFBO0lBQUFDLE1BQUE7R0FBQTtHQUNBO0lBQUFELEtBQUE7SUFBQUMsTUFBQTtHQUFBO0dBQ0E7SUFBQUQsS0FBQTtJQUFBQyxNQUFBO0lBQUFHLGFBQUE7R0FBQTtHQUNBO0lBQUFKLEtBQUE7SUFBQUMsTUFBQTtHQUFBO0dBQ0E7SUFDQUQsS0FBQTtJQUNBQyxNQUFBO0dBQ0E7RUFBQTtDQUVBO0NBQ0FJLGdCQUFBQztDQUNBQyxXQUFBQztDQUNBQyxtQkFBQTFCO0NBQ0EyQixnQkFBQTFCO0FBQ0E7QUFFQSxTQUFBc0IsVUFBQSxFQUFBSyxZQUFBO0NBQ0EsT0FDQTtFQUFBO0VBQUE7RUFBQTtZQUFBLENBQ0E7R0FBQTthQUFBLENBQ0EseUZBQXFCOzs7O2FBQ3JCO0lBQ0EsMkJBQ0FDLFFBQUE7Ozs7Ozs7Ozs7O2NBWUE7SUFDQTtHQUFROzs7O1dBQ1I7Ozs7O1lBQ0E7R0FBQTtHQUFBO2FBQUEsQ0FDQUQsVUFDQSxxRkFBaUI7Ozs7V0FDakI7Ozs7O1VBQ0E7Ozs7OztBQUVBOztBQUVBLFNBQUFILGdCQUFBOztDQUNBLFFBQUFLLGdCQUFBckIsTUFBQXNCLGdCQUFBO0NBRUFyRCxnQkFBQTtFQUNBSSxnQ0FBQTtFQUNBTSx5QkFBQTs7RUFHQSxXQUFBNEMsV0FBQSxrQ0FBQUMsV0FBQTtHQUNBLE1BQUFDLG9CQUFBO0lBQ0FELFVBQUFFLGNBQUFDLFNBQUEsWUFBQUMsT0FBQSxPQUFBQyxZQUFBO0dBQ0E7R0FDQSxJQUFBQyxTQUFBQyxlQUFBLGNBQUFELFNBQUFDLGVBQUE7SUFDQU4sWUFBQTtHQUNBO0lBQ0FGLE9BQUFTLGlCQUFBLFFBQUFQLFdBQUE7R0FDQTtFQUNBO0NBQ0E7Q0FFQSxPQUNBO0VBQUE7WUFDQTtHQUFBLFFBQUFKO0dBQUE7YUFDQTtJQUFBO2NBQUE7S0FDQTtNQUFBLGdCQUFBeEM7TUFBQTtLQUE2RDs7Ozs7S0FFN0QscUZBQWtCOzs7OztLQUNsQjtNQUFBO01BQUE7S0FBdUM7Ozs7O0tBQ3ZDO01BQUE7TUFBQTtNQUFBO0tBQW9EOzs7OztLQUNwRCw0RkFBeUI7Ozs7O0tBQ3pCLG1HQUFnQzs7Ozs7SUFDaEM7Ozs7OztFQUNBOzs7OztDQUNBOzs7OztBQUVBOzs7OztBQUFBLE1BQUFvRCxNQUFBQyxZQUFBRDtBQUFBLElBQUFBLE9BQUEsT0FBQVYsV0FBQTtDQUFBVSxJQUFBRSxTQUFBO0NBQUEsTUFBQUMsa0JBQUFiLE9BQUFjLGlDQUFBO0VBQUEsTUFBQUMscUJBQUEsSUFBQUMsSUFBQTtFQUFBLE1BQUFDLDRCQUFBakIsT0FBQWtCO0VBQUFsQixPQUFBa0IsbUNBQUFDLFFBQUE7R0FBQSxNQUFBQyxpQkFBQUgsNEJBQUFFLEdBQUE7R0FBQSxNQUFBRSxnQkFBQU4sbUJBQUFPLElBQUFILElBQUFJLEVBQUE7R0FBQSxXQUFBSCxnQkFBQSxHQUFBQyxhQUFBO0VBQUE7RUFBQSxTQUFBTixtQkFBQTtDQUFBO0NBQUFGLGdCQUFBRSxtQkFBQVMsSUFBQTtBQUFBO0FBQUEsZ0JBQUFDLHVCQUFBO0NBQUE7QUFBQTs7QUFBQSxJQUFBZCxZQUFBRCxLQUFBO0NBQUEsTUFBQUEsTUFBQUMsWUFBQUQ7Q0FBQSxNQUFBZ0IsVUFBQWhCLElBQUFFLFNBQUE7Q0FBQSxNQUFBZSxvQkFBQSxTQUFBQSxrQkFBQUMsU0FBQUMsVUFBQTtFQUFBLE1BQUF6RCxTQUFBNEIsT0FBQThCO0VBQUEsTUFBQUMsV0FBQTNELE9BQUE0RCxXQUFBSjtFQUFBLEtBQUFHLFVBQUE7RUFBQSxNQUFBRSwyQkFBQSxJQUFBQyxJQUFBO0dBQUE7R0FBQTtHQUFBO0VBQUE7RUFBQSxNQUFBQyx3QkFBQTtFQUFBRix5QkFBQUcsU0FBQUMsUUFBQTtHQUFBLElBQUFBLE9BQUFOLFNBQUFPLFNBQUFILHNCQUFBRSxPQUFBTixTQUFBTyxRQUFBRDtFQUFBO0VBQUEsTUFBQUUsNEJBQUEsb0JBQUFSLFNBQUFPLFlBQUEsb0JBQUFULFNBQUFTO0VBQUEsTUFBQUUsZ0JBQUE7R0FBQTtHQUFBO0dBQUE7R0FBQTtHQUFBO0VBQUE7RUFBQSxJQUFBRCwyQkFBQUMsY0FBQUosU0FBQUMsUUFBQTtHQUFBLElBQUFBLE9BQUFOLFNBQUFPLFdBQUFELE9BQUFSLFNBQUFTLFNBQUFULFNBQUFTLFFBQUFELE9BQUFOLFNBQUFPLFFBQUFEO0VBQUE7RUFBQSxNQUFBSSxjQUFBO0dBQUEsR0FBQVosU0FBQVM7R0FBQSxHQUFBSDtFQUFBO0VBQUFKLFNBQUFPLFVBQUFHO0VBQUFWLFNBQUFXLE9BQUFELFdBQUE7RUFBQXJFLE9BQUF1RSxtQkFBQVosVUFBQUYsU0FBQWUsTUFBQTtFQUFBeEUsT0FBQXlFLFVBQUF6RSxPQUFBMEUsZUFBQTtFQUFBQyxtQkFBQWhCLFFBQUE7RUFBQTNELE9BQUE0RSxpQkFBQUMsTUFBQTtFQUFBN0UsT0FBQThFLGdCQUFBO0VBQUEsU0FBQUgsbUJBQUFJLFdBQUE7R0FBQXRCLFNBQUFTLFVBQUFhLFVBQUFiO0dBQUFULFNBQUF1QixjQUFBRCxVQUFBQztHQUFBdkIsU0FBQXdCLFFBQUFGLFVBQUFFO0dBQUF4QixTQUFBeUIsTUFBQUgsVUFBQUc7R0FBQXpCLFNBQUEwQixZQUFBSixVQUFBSTtHQUFBMUIsU0FBQTJCLE1BQUFMLFVBQUFLO0VBQUE7Q0FBQTtDQUFBLE1BQUFDLGlCQUFBLGNBQUEvQixRQUFBO0NBQUEsSUFBQStCLGdCQUFBO0VBQUEvQixRQUFBLGtCQUFBK0I7Q0FBQTtDQUFBLE1BQUFDLGdCQUFBLE9BQUExRCxXQUFBLGVBQUF5RCxpQkFBQXpELE9BQUE4QixnQkFBQUUsYUFBQXlCLGtCQUFBRTtDQUFBLElBQUFGLGtCQUFBQyxtQ0FBQWpGLE9BQUE7RUFBQWtELGtCQUFBOEIsZ0JBQUFoRixLQUFBO0VBQUFpRCxRQUFBLDhCQUFBakQ7Q0FBQTtDQUFBaUMsSUFBQWtELFFBQUFDLGNBQUE7RUFBQSxJQUFBcEYsU0FBQW9GLHVCQUFBcEYsT0FBQTtHQUFBLE1BQUFtRCxVQUFBRixRQUFBO0dBQUEsSUFBQUUsU0FBQTtJQUFBRixRQUFBLGtCQUFBRTtHQUFBO0dBQUEsSUFBQUYsUUFBQSxnQ0FBQW1DLFVBQUFwRixPQUFBO0lBQUEsT0FBQWlELFFBQUE7SUFBQTtHQUFBO0dBQUFDLGtCQUFBQyxTQUFBaUMsVUFBQXBGLEtBQUE7RUFBQTtDQUFBO0FBQUEiLCJuYW1lcyI6WyJRdWVyeUNsaWVudFByb3ZpZGVyIiwiT3V0bGV0IiwiTGluayIsImNyZWF0ZVJvb3RSb3V0ZVdpdGhDb250ZXh0IiwidXNlUm91dGVyIiwiSGVhZENvbnRlbnQiLCJTY3JpcHRzIiwidXNlRWZmZWN0IiwiVG9hc3RlciIsImFwcENzcyIsInJlcG9ydEFwcGxpY2F0aW9uRXJyb3IiLCJpbnN0YWxsUHJvZHVjdGlvblNlY3VyaXR5U2hpZWxkIiwiQXBwRXJyb3JCb3VuZGFyeSIsIkF1dGhQcm92aWRlciIsIk9mZmxpbmVTdGF0dXMiLCJQcm9kdWN0aW9uTW9uaXRvcmluZyIsIlZlcmRpY3RTdWNjZXNzIiwiYXV0b1NlZWRGaXJlc3RvcmVJZkVtcHR5IiwiU2VvSGVsbWV0IiwiQlJBTkRfQkFST01FVEVSX1NDSEVNQSIsIm5hbWUiLCJ1cmwiLCJsb2dvIiwiZGVzY3JpcHRpb24iLCJhcHBsaWNhdGlvbkNhdGVnb3J5Iiwib3BlcmF0aW5nU3lzdGVtIiwib2ZmZXJzIiwicHJpY2UiLCJwcmljZUN1cnJlbmN5IiwiTm90Rm91bmRDb21wb25lbnQiLCJFcnJvckNvbXBvbmVudCIsImVycm9yIiwicmVzZXQiLCJyb3V0ZXIiLCJFcnJvciIsIlN0cmluZyIsImJvdW5kYXJ5IiwiaW52YWxpZGF0ZSIsIlJvdXRlIiwiaGVhZCIsIm1ldGEiLCJjaGFyU2V0IiwiY29udGVudCIsInRpdGxlIiwicHJvcGVydHkiLCJsaW5rcyIsInJlbCIsImhyZWYiLCJ0eXBlIiwic2l6ZXMiLCJjcm9zc09yaWdpbiIsInNoZWxsQ29tcG9uZW50IiwiUm9vdFNoZWxsIiwiY29tcG9uZW50IiwiUm9vdENvbXBvbmVudCIsIm5vdEZvdW5kQ29tcG9uZW50IiwiZXJyb3JDb21wb25lbnQiLCJjaGlsZHJlbiIsIl9faHRtbCIsInF1ZXJ5Q2xpZW50IiwidXNlUm91dGVDb250ZXh0Iiwid2luZG93IiwibmF2aWdhdG9yIiwicnVuUmVnaXN0ZXIiLCJzZXJ2aWNlV29ya2VyIiwicmVnaXN0ZXIiLCJzY29wZSIsImNhdGNoIiwiZG9jdW1lbnQiLCJyZWFkeVN0YXRlIiwiYWRkRXZlbnRMaXN0ZW5lciIsImhvdCIsImltcG9ydCIsImRhdGEiLCJ0c3JSZWFjdFJlZnJlc2giLCJfX1RTUl9SRUFDVF9SRUZSRVNIX18iLCJpZ25vcmVkRXhwb3J0c0J5SWQiLCJNYXAiLCJwcmV2aW91c0dldElnbm9yZWRFeHBvcnRzIiwiX19nZXRSZWFjdFJlZnJlc2hJZ25vcmVkRXhwb3J0cyIsImN0eCIsImlnbm9yZWRFeHBvcnRzIiwibW9kdWxlSWdub3JlZCIsImdldCIsImlkIiwic2V0IiwiVFNSRmFzdFJlZnJlc2hBbmNob3IiLCJob3REYXRhIiwiaGFuZGxlUm91dGVVcGRhdGUiLCJyb3V0ZUlkIiwibmV3Um91dGUiLCJfX1RTUl9ST1VURVJfXyIsIm9sZFJvdXRlIiwicm91dGVzQnlJZCIsImdlbmVyYXRlZFJvdXRlT3B0aW9uS2V5cyIsIlNldCIsImdlbmVyYXRlZFJvdXRlT3B0aW9ucyIsImZvckVhY2giLCJrZXkiLCJvcHRpb25zIiwicHJlc2VydmVDb21wb25lbnRJZGVudGl0eSIsImNvbXBvbmVudEtleXMiLCJuZXh0T3B0aW9ucyIsInVwZGF0ZSIsIl9yZXBsYWNlUm91dGVDaHVuayIsImxhenlGbiIsInNldFJvdXRlcyIsImJ1aWxkUm91dGVUcmVlIiwic3luY0hvdFJvdXRlRXhwb3J0IiwicmVzb2x2ZVBhdGhDYWNoZSIsImNsZWFyIiwiX3JlZnJlc2hSb3V0ZSIsImxpdmVSb3V0ZSIsInBhcmVudFJvdXRlIiwiX3BhdGgiLCJfaWQiLCJfZnVsbFBhdGgiLCJfdG8iLCJpbml0aWFsUm91dGVJZCIsImV4aXN0aW5nUm91dGUiLCJ1bmRlZmluZWQiLCJhY2NlcHQiLCJuZXdNb2R1bGUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiX19yb290LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBRdWVyeUNsaWVudCwgUXVlcnlDbGllbnRQcm92aWRlciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcbmltcG9ydCB7XG4gIE91dGxldCxcbiAgTGluayxcbiAgY3JlYXRlUm9vdFJvdXRlV2l0aENvbnRleHQsXG4gIHVzZVJvdXRlcixcbiAgSGVhZENvbnRlbnQsXG4gIFNjcmlwdHMsXG59IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtcm91dGVyXCI7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHR5cGUgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XG5cbmltcG9ydCB7IFRvYXN0ZXIgfSBmcm9tIFwic29ubmVyXCI7XG5cbmltcG9ydCBhcHBDc3MgZnJvbSBcIi4uL3N0eWxlcy5jc3M/dXJsXCI7XG5pbXBvcnQgeyByZXBvcnRBcHBsaWNhdGlvbkVycm9yIH0gZnJvbSBcIi4uL2xpYi9lcnJvci1yZXBvcnRpbmdcIjtcbmltcG9ydCB7IGluc3RhbGxQcm9kdWN0aW9uU2VjdXJpdHlTaGllbGQgfSBmcm9tIFwiLi4vbGliL3NlY3VyaXR5LXNoaWVsZFwiO1xuaW1wb3J0IHsgQXBwRXJyb3JCb3VuZGFyeSB9IGZyb20gXCJAL2NvbXBvbmVudHMvQXBwRXJyb3JCb3VuZGFyeVwiO1xuaW1wb3J0IHsgQXV0aFByb3ZpZGVyIH0gZnJvbSBcIkAvaG9va3MvdXNlQXV0aFwiO1xuaW1wb3J0IHsgT2ZmbGluZVN0YXR1cyB9IGZyb20gXCJAL2NvbXBvbmVudHMvT2ZmbGluZVN0YXR1c1wiO1xuaW1wb3J0IHsgUHJvZHVjdGlvbk1vbml0b3JpbmcgfSBmcm9tIFwiQC9jb21wb25lbnRzL1Byb2R1Y3Rpb25Nb25pdG9yaW5nXCI7XG5pbXBvcnQgeyBWZXJkaWN0U3VjY2VzcyB9IGZyb20gXCJAL2NvbXBvbmVudHMvVmVyZGljdFN1Y2Nlc3NcIjtcbmltcG9ydCB7IGF1dG9TZWVkRmlyZXN0b3JlSWZFbXB0eSB9IGZyb20gXCJAL2xpYi9zZWVkRmlyZXN0b3JlXCI7XG5pbXBvcnQgeyBTZW9IZWxtZXQgfSBmcm9tIFwiQC9jb21wb25lbnRzL1Nlb0hlbG1ldFwiO1xuaW1wb3J0IFwiQC9saWIvaTE4blwiO1xuXG5jb25zdCBCUkFORF9CQVJPTUVURVJfU0NIRU1BID0ge1xuICBcIkBjb250ZXh0XCI6IFwiaHR0cHM6Ly9zY2hlbWEub3JnXCIsXG4gIFwiQGdyYXBoXCI6IFtcbiAgICB7XG4gICAgICBcIkB0eXBlXCI6IFwiT3JnYW5pemF0aW9uXCIsXG4gICAgICBcIkBpZFwiOiBcImh0dHBzOi8vc3Rhc2gtb3ItdHJhc2gtaHViLnZlcmNlbC5hcHAvI29yZ2FuaXphdGlvblwiLFxuICAgICAgbmFtZTogXCJTT1Qg4oCUIFN0YXNoIE9yIFRyYXNoXCIsXG4gICAgICB1cmw6IFwiaHR0cHM6Ly9zdGFzaC1vci10cmFzaC1odWIudmVyY2VsLmFwcFwiLFxuICAgICAgbG9nbzogXCJodHRwczovL3N0YXNoLW9yLXRyYXNoLWh1Yi52ZXJjZWwuYXBwL2FwcGxlLXRvdWNoLWljb24ucG5nXCIsXG4gICAgICBkZXNjcmlwdGlvbjpcbiAgICAgICAgXCJTT1QgaXMgdGhlIGdsb2JhbCBCcmFuZCBCYXJvbWV0ZXIgcHJvdmlkaW5nIGF1dGhlbnRpYyBjdXN0b21lciByZXZpZXdzLCB0cnVzdCByYXRpbmdzLCBhbmQgYW50aS1jb3VudGVyZmVpdCB2ZXJpZmljYXRpb24uXCIsXG4gICAgfSxcbiAgICB7XG4gICAgICBcIkB0eXBlXCI6IFwiV2ViQXBwbGljYXRpb25cIixcbiAgICAgIFwiQGlkXCI6IFwiaHR0cHM6Ly9zdGFzaC1vci10cmFzaC1odWIudmVyY2VsLmFwcC8jd2ViYXBwXCIsXG4gICAgICBuYW1lOiBcIlNPVCDigJQgU3Rhc2ggT3IgVHJhc2ggfCBCcmFuZCBCYXJvbWV0ZXJcIixcbiAgICAgIHVybDogXCJodHRwczovL3N0YXNoLW9yLXRyYXNoLWh1Yi52ZXJjZWwuYXBwXCIsXG4gICAgICBkZXNjcmlwdGlvbjpcbiAgICAgICAgXCJMaXZlIENYICYgUFIgcGxhdGZvcm0gd2hlcmUgY29uc3VtZXJzIGRlbGl2ZXIgcmVhbC10aW1lIHZlcmRpY3RzIG9uIGJyYW5kcyB3aXRoIHZlcmlmaWVkIHByb29mLlwiLFxuICAgICAgYXBwbGljYXRpb25DYXRlZ29yeTogXCJCdXNpbmVzc0FwcGxpY2F0aW9uXCIsXG4gICAgICBvcGVyYXRpbmdTeXN0ZW06IFwiQWxsXCIsXG4gICAgICBvZmZlcnM6IHtcbiAgICAgICAgXCJAdHlwZVwiOiBcIk9mZmVyXCIsXG4gICAgICAgIHByaWNlOiBcIjBcIixcbiAgICAgICAgcHJpY2VDdXJyZW5jeTogXCJVU0RcIixcbiAgICAgIH0sXG4gICAgfSxcbiAgXSxcbn07XG5cbmZ1bmN0aW9uIE5vdEZvdW5kQ29tcG9uZW50KCkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW4gaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJhY2tncm91bmQgcHgtNFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy1tZCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC03eGwgZm9udC1ib2xkIHRleHQtZm9yZWdyb3VuZFwiPjQwNDwvaDE+XG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJtdC00IHRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWZvcmVncm91bmRcIj5QYWdlIG5vdCBmb3VuZDwvaDI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICBUaGUgcGFnZSB5b3UncmUgbG9va2luZyBmb3IgZG9lc24ndCBleGlzdCBvciBoYXMgYmVlbiBtb3ZlZC5cbiAgICAgICAgPC9wPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTZcIj5cbiAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgdG89XCIvXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLW1kIGJnLXByaW1hcnkgcHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1wcmltYXJ5LWZvcmVncm91bmQgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6YmctcHJpbWFyeS85MFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgR28gaG9tZVxuICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gRXJyb3JDb21wb25lbnQoeyBlcnJvciwgcmVzZXQgfTogeyBlcnJvcjogYW55OyByZXNldDogKCkgPT4gdm9pZCB9KSB7XG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJlcG9ydEFwcGxpY2F0aW9uRXJyb3IoZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yIDogbmV3IEVycm9yKFN0cmluZyhlcnJvcikpLCB7IGJvdW5kYXJ5OiBcInRhbnN0YWNrX3Jvb3RfZXJyb3JfY29tcG9uZW50XCIgfSk7XG4gIH0sIFtlcnJvcl0pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYmFja2dyb3VuZCBweC00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LW1kIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLWNhcmQgcC04IHRleHQtY2VudGVyIHNoYWRvdy1zbVwiPlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgIFNvbWV0aGluZyB3ZW50IHdyb25nLCBwbGVhc2UgcmVmcmVzaFxuICAgICAgICA8L2gxPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgU29tZXRoaW5nIHdlbnQgd3Jvbmcgb24gb3VyIGVuZC4gWW91IGNhbiB0cnkgcmVmcmVzaGluZyBvciBoZWFkIGJhY2sgaG9tZS5cbiAgICAgICAgPC9wPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgZmxleCBmbGV4LXdyYXAganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgIHJvdXRlci5pbnZhbGlkYXRlKCk7XG4gICAgICAgICAgICAgIHJlc2V0KCk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbWQgYmctcHJpbWFyeSBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXByaW1hcnktZm9yZWdyb3VuZCB0cmFuc2l0aW9uLWNvbG9ycyBob3ZlcjpiZy1wcmltYXJ5LzkwXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBUcnkgYWdhaW5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YVxuICAgICAgICAgICAgaHJlZj1cIi9cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1pbnB1dCBiZy1iYWNrZ3JvdW5kIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZCB0cmFuc2l0aW9uLWNvbG9ycyBob3ZlcjpiZy1hY2NlbnRcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIEdvIGhvbWVcbiAgICAgICAgICA8L2E+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBjb25zdCBSb3V0ZSA9IGNyZWF0ZVJvb3RSb3V0ZVdpdGhDb250ZXh0PHsgcXVlcnlDbGllbnQ6IFF1ZXJ5Q2xpZW50IH0+KCkoe1xuICBoZWFkOiAoKSA9PiAoe1xuICAgIG1ldGE6IFtcbiAgICAgIHsgY2hhclNldDogXCJ1dGYtOFwiIH0sXG4gICAgICB7XG4gICAgICAgIG5hbWU6IFwidmlld3BvcnRcIixcbiAgICAgICAgY29udGVudDogXCJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MS4wLCBtYXhpbXVtLXNjYWxlPTEuMCwgdXNlci1zY2FsYWJsZT1ubywgdmlld3BvcnQtZml0PWNvdmVyXCIsXG4gICAgICB9LFxuICAgICAgeyBuYW1lOiBcInRoZW1lLWNvbG9yXCIsIGNvbnRlbnQ6IFwiIzAwMDAwMFwiIH0sXG4gICAgICB7IG5hbWU6IFwibW9iaWxlLXdlYi1hcHAtY2FwYWJsZVwiLCBjb250ZW50OiBcInllc1wiIH0sXG4gICAgICB7IG5hbWU6IFwiYXBwbGUtbW9iaWxlLXdlYi1hcHAtY2FwYWJsZVwiLCBjb250ZW50OiBcInllc1wiIH0sXG4gICAgICB7IG5hbWU6IFwiYXBwbGUtbW9iaWxlLXdlYi1hcHAtc3RhdHVzLWJhci1zdHlsZVwiLCBjb250ZW50OiBcImJsYWNrLXRyYW5zbHVjZW50XCIgfSxcbiAgICAgIHsgbmFtZTogXCJhcHBsZS1tb2JpbGUtd2ViLWFwcC10aXRsZVwiLCBjb250ZW50OiBcIlNPclRcIiB9LFxuICAgICAgeyB0aXRsZTogXCJTT1Qg4oCUIFN0YXNoIE9yIFRyYXNoIHwgQnJhbmQgQmFyb21ldGVyICYgQ29uc3VtZXIgUmV2aWV3c1wiIH0sXG4gICAgICB7XG4gICAgICAgIG5hbWU6IFwiZGVzY3JpcHRpb25cIixcbiAgICAgICAgY29udGVudDpcbiAgICAgICAgICBcIlNPVCAoU3Rhc2ggT3IgVHJhc2gpIGlzIHRoZSBCcmFuZCBCYXJvbWV0ZXIg4oCUIGEgbGl2ZSBDWC9VWCB2ZXJkaWN0IHBsYXRmb3JtIGZvciBhdXRoZW50aWMgY29uc3VtZXIgYnJhbmQgcmV2aWV3cyBhbmQgYWNjb3VudGFiaWxpdHkuIENhc3QgeW91ciB2ZXJkaWN0IG5vdy5cIixcbiAgICAgIH0sXG4gICAgICB7IG5hbWU6IFwiYXV0aG9yXCIsIGNvbnRlbnQ6IFwiU09UIOKAlCBTdGFzaCBPciBUcmFzaFwiIH0sXG4gICAgICB7IHByb3BlcnR5OiBcIm9nOnRpdGxlXCIsIGNvbnRlbnQ6IFwiU09UIOKAlCBTdGFzaCBPciBUcmFzaCB8IEJyYW5kIEJhcm9tZXRlciAmIENvbnN1bWVyIFJldmlld3NcIiB9LFxuICAgICAge1xuICAgICAgICBwcm9wZXJ0eTogXCJvZzpkZXNjcmlwdGlvblwiLFxuICAgICAgICBjb250ZW50OlxuICAgICAgICAgIFwiU09UIChTdGFzaCBPciBUcmFzaCkgaXMgdGhlIEJyYW5kIEJhcm9tZXRlciDigJQgYSBsaXZlIENYL1VYIHZlcmRpY3QgcGxhdGZvcm0gZm9yIGF1dGhlbnRpYyBjb25zdW1lciBicmFuZCByZXZpZXdzIGFuZCBhY2NvdW50YWJpbGl0eS4gQ2FzdCB5b3VyIHZlcmRpY3Qgbm93LlwiLFxuICAgICAgfSxcbiAgICAgIHsgcHJvcGVydHk6IFwib2c6dHlwZVwiLCBjb250ZW50OiBcIndlYnNpdGVcIiB9LFxuICAgICAgeyBuYW1lOiBcInR3aXR0ZXI6Y2FyZFwiLCBjb250ZW50OiBcInN1bW1hcnlfbGFyZ2VfaW1hZ2VcIiB9LFxuICAgICAgeyBuYW1lOiBcInR3aXR0ZXI6dGl0bGVcIiwgY29udGVudDogXCJTT1Qg4oCUIFN0YXNoIE9yIFRyYXNoIHwgQnJhbmQgQmFyb21ldGVyICYgQ29uc3VtZXIgUmV2aWV3c1wiIH0sXG4gICAgICB7XG4gICAgICAgIG5hbWU6IFwidHdpdHRlcjpkZXNjcmlwdGlvblwiLFxuICAgICAgICBjb250ZW50OlxuICAgICAgICAgIFwiU09UIChTdGFzaCBPciBUcmFzaCkgaXMgdGhlIEJyYW5kIEJhcm9tZXRlciDigJQgYSBsaXZlIENYL1VYIHZlcmRpY3QgcGxhdGZvcm0gZm9yIGF1dGhlbnRpYyBjb25zdW1lciBicmFuZCByZXZpZXdzIGFuZCBhY2NvdW50YWJpbGl0eS4gQ2FzdCB5b3VyIHZlcmRpY3Qgbm93LlwiLFxuICAgICAgfSxcbiAgICBdLFxuICAgIGxpbmtzOiBbXG4gICAgICB7XG4gICAgICAgIHJlbDogXCJzdHlsZXNoZWV0XCIsXG4gICAgICAgIGhyZWY6IGFwcENzcyxcbiAgICAgIH0sXG4gICAgICB7IHJlbDogXCJpY29uXCIsIGhyZWY6IFwiL2Zhdmljb24uaWNvXCIsIHR5cGU6IFwiaW1hZ2UveC1pY29uXCIgfSxcbiAgICAgIHsgcmVsOiBcImljb25cIiwgdHlwZTogXCJpbWFnZS9wbmdcIiwgc2l6ZXM6IFwiOTZ4OTZcIiwgaHJlZjogXCIvZmF2aWNvbi05Nng5Ni5wbmdcIiB9LFxuICAgICAgeyByZWw6IFwiaWNvblwiLCB0eXBlOiBcImltYWdlL3BuZ1wiLCBzaXplczogXCIxOTJ4MTkyXCIsIGhyZWY6IFwiL2ljb24tMTkyeDE5Mi5wbmdcIiB9LFxuICAgICAgeyByZWw6IFwiaWNvblwiLCB0eXBlOiBcImltYWdlL3BuZ1wiLCBzaXplczogXCI1MTJ4NTEyXCIsIGhyZWY6IFwiL2ljb24tNTEyeDUxMi5wbmdcIiB9LFxuICAgICAgeyByZWw6IFwiYXBwbGUtdG91Y2gtaWNvblwiLCBzaXplczogXCIxODB4MTgwXCIsIGhyZWY6IFwiL2FwcGxlLXRvdWNoLWljb24ucG5nXCIgfSxcbiAgICAgIHsgcmVsOiBcIm1hbmlmZXN0XCIsIGhyZWY6IFwiL21hbmlmZXN0Lmpzb25cIiB9LFxuICAgICAgeyByZWw6IFwibWFuaWZlc3RcIiwgaHJlZjogXCIvc2l0ZS53ZWJtYW5pZmVzdFwiIH0sXG4gICAgICB7IHJlbDogXCJwcmVjb25uZWN0XCIsIGhyZWY6IFwiaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbVwiIH0sXG4gICAgICB7IHJlbDogXCJwcmVjb25uZWN0XCIsIGhyZWY6IFwiaHR0cHM6Ly9mb250cy5nc3RhdGljLmNvbVwiLCBjcm9zc09yaWdpbjogXCJhbm9ueW1vdXNcIiB9LFxuICAgICAgeyByZWw6IFwicHJlY29ubmVjdFwiLCBocmVmOiBcImh0dHBzOi8vYXBpcy5nb29nbGUuY29tXCIgfSxcbiAgICAgIHtcbiAgICAgICAgcmVsOiBcInN0eWxlc2hlZXRcIixcbiAgICAgICAgaHJlZjogXCJodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5PUJyaWNvbGFnZStHcm90ZXNxdWU6b3Bzeix3Z2h0QDEyLi45Niw2MDA7MTIuLjk2LDcwMDsxMi4uOTYsODAwJmZhbWlseT1QbHVzK0pha2FydGErU2Fuczp3Z2h0QDQwMDs1MDA7NjAwOzcwMCZkaXNwbGF5PXN3YXBcIixcbiAgICAgIH0sXG4gICAgXSxcbiAgfSksXG4gIHNoZWxsQ29tcG9uZW50OiBSb290U2hlbGwsXG4gIGNvbXBvbmVudDogUm9vdENvbXBvbmVudCxcbiAgbm90Rm91bmRDb21wb25lbnQ6IE5vdEZvdW5kQ29tcG9uZW50LFxuICBlcnJvckNvbXBvbmVudDogRXJyb3JDb21wb25lbnQsXG59KTtcblxuZnVuY3Rpb24gUm9vdFNoZWxsKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbjogUmVhY3ROb2RlIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8aHRtbCBsYW5nPVwiZW5cIiBzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc+XG4gICAgICA8aGVhZD5cbiAgICAgICAgPEhlYWRDb250ZW50IC8+XG4gICAgICAgIDxzY3JpcHRcbiAgICAgICAgICBkYW5nZXJvdXNseVNldElubmVySFRNTD17e1xuICAgICAgICAgICAgX19odG1sOiBgXG4gICAgICAgICAgICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiAnc2VydmljZVdvcmtlcicgaW4gbmF2aWdhdG9yKSB7XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gcmVnaXN0ZXJTVygpIHtcbiAgICAgICAgICAgICAgICAgIG5hdmlnYXRvci5zZXJ2aWNlV29ya2VyLnJlZ2lzdGVyKCcvc3cuanMnLCB7IHNjb3BlOiAnLycgfSkuY2F0Y2goZnVuY3Rpb24oKSB7fSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChkb2N1bWVudC5yZWFkeVN0YXRlID09PSAnY29tcGxldGUnIHx8IGRvY3VtZW50LnJlYWR5U3RhdGUgPT09ICdpbnRlcmFjdGl2ZScpIHtcbiAgICAgICAgICAgICAgICAgIHJlZ2lzdGVyU1coKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2xvYWQnLCByZWdpc3RlclNXKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGAsXG4gICAgICAgICAgfX1cbiAgICAgICAgLz5cbiAgICAgIDwvaGVhZD5cbiAgICAgIDxib2R5IHN1cHByZXNzSHlkcmF0aW9uV2FybmluZz5cbiAgICAgICAge2NoaWxkcmVufVxuICAgICAgICA8U2NyaXB0cyAvPlxuICAgICAgPC9ib2R5PlxuICAgIDwvaHRtbD5cbiAgKTtcbn1cblxuZnVuY3Rpb24gUm9vdENvbXBvbmVudCgpIHtcbiAgY29uc3QgeyBxdWVyeUNsaWVudCB9ID0gUm91dGUudXNlUm91dGVDb250ZXh0KCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpbnN0YWxsUHJvZHVjdGlvblNlY3VyaXR5U2hpZWxkKCk7XG4gICAgYXV0b1NlZWRGaXJlc3RvcmVJZkVtcHR5KCk7XG5cbiAgICAvLyBSZWdpc3RlciBQV0EgU2VydmljZSBXb3JrZXIgZm9yIHN0b3JlIHBhY2thZ2UgJiBvZmZsaW5lIGNhY2hpbmdcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiAmJiBcInNlcnZpY2VXb3JrZXJcIiBpbiBuYXZpZ2F0b3IpIHtcbiAgICAgIGNvbnN0IHJ1blJlZ2lzdGVyID0gKCkgPT4ge1xuICAgICAgICBuYXZpZ2F0b3Iuc2VydmljZVdvcmtlci5yZWdpc3RlcihcIi9zdy5qc1wiLCB7IHNjb3BlOiBcIi9cIiB9KS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgICB9O1xuICAgICAgaWYgKGRvY3VtZW50LnJlYWR5U3RhdGUgPT09IFwiY29tcGxldGVcIiB8fCBkb2N1bWVudC5yZWFkeVN0YXRlID09PSBcImludGVyYWN0aXZlXCIpIHtcbiAgICAgICAgcnVuUmVnaXN0ZXIoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwibG9hZFwiLCBydW5SZWdpc3Rlcik7XG4gICAgICB9XG4gICAgfVxuICB9LCBbXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8QXBwRXJyb3JCb3VuZGFyeT5cbiAgICAgIDxRdWVyeUNsaWVudFByb3ZpZGVyIGNsaWVudD17cXVlcnlDbGllbnR9PlxuICAgICAgICA8QXV0aFByb3ZpZGVyPlxuICAgICAgICAgIDxTZW9IZWxtZXQgc3RydWN0dXJlZERhdGE9e0JSQU5EX0JBUk9NRVRFUl9TQ0hFTUF9IC8+XG4gICAgICAgICAgey8qIFJlcXVpcmVkOiBuZXN0ZWQgcm91dGVzIHJlbmRlciBoZXJlLiBSZW1vdmluZyA8T3V0bGV0IC8+IGJyZWFrcyBhbGwgY2hpbGQgcm91dGVzLiAqL31cbiAgICAgICAgICA8T3V0bGV0IC8+XG4gICAgICAgICAgPFZlcmRpY3RTdWNjZXNzIGxpc3Rlbkdsb2JhbCAvPlxuICAgICAgICAgIDxUb2FzdGVyIHBvc2l0aW9uPVwidG9wLWNlbnRlclwiIHJpY2hDb2xvcnMgLz5cbiAgICAgICAgICA8T2ZmbGluZVN0YXR1cyAvPlxuICAgICAgICAgIDxQcm9kdWN0aW9uTW9uaXRvcmluZyAvPlxuICAgICAgICA8L0F1dGhQcm92aWRlcj5cbiAgICAgIDwvUXVlcnlDbGllbnRQcm92aWRlcj5cbiAgICA8L0FwcEVycm9yQm91bmRhcnk+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9hcHAvYXBwbGV0L3NyYy9yb3V0ZXMvX19yb290LnRzeCJ9