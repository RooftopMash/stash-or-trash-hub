import { supabase } from "/src/integrations/supabase/client.ts";
import { BUCKET, signImages } from "/src/lib/stash.ts";
import { INTERNATIONAL_SEED_BRANDS, SOUTH_AFRICAN_SEED_BRANDS } from "/src/lib/seed-brands.ts";
import { createFirestoreBrand, getFirestoreBrands } from "/src/services/firestoreService.ts";
import { getLocalImportedBrands } from "/src/lib/wikidata-import.ts";
export function slugify(name) {
	return name.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60);
}
async function decorate(rows) {
	if (!rows.length) return [];
	const ownerIds = [...new Set(rows.map((b) => b.owner_id))];
	const storageLogos = rows.map((b) => b.logo_url).filter((url) => !!url && !/^https?:\/\//i.test(url));
	const [{ data: profiles }, signed] = await Promise.all([supabase.from("profiles").select("id, display_name").in("id", ownerIds), signImages(storageLogos)]);
	const nameById = new Map((profiles ?? []).map((p) => [p.id, p.display_name]));
	return rows.map((b) => ({
		...b,
		signedLogoUrl: b.logo_url ? /^https?:\/\//i.test(b.logo_url) ? b.logo_url : signed.get(b.logo_url) ?? null : null,
		ownerName: nameById.get(b.owner_id) ?? null
	}));
}
export async function fetchBrands() {
	const fallback = [...INTERNATIONAL_SEED_BRANDS, ...SOUTH_AFRICAN_SEED_BRANDS];
	let firestoreBrands = [];
	try {
		const fsData = await getFirestoreBrands();
		if (fsData && fsData.length > 0) {
			firestoreBrands = fsData.map((b) => ({
				id: b.id,
				owner_id: b.createdBy || "system",
				name: b.name,
				slug: b.slug,
				description: b.description || null,
				logo_url: b.logoUrl || null,
				website: b.website || null,
				category: b.category || null,
				country: b.country || null,
				verified: b.isVerified ?? false,
				trust_score: b.trustScore ?? 50,
				created_at: b.createdAt || new Date().toISOString(),
				signedLogoUrl: b.logoUrl || null,
				ownerName: null
			}));
		}
	} catch (fsErr) {
		console.warn("Firestore brands fetch note:", fsErr);
	}
	let legacyBrands = [];
	try {
		const { data } = await supabase.from("brands").select("*").order("trust_score", { ascending: false }).order("created_at", { ascending: false });
		if (data && data.length > 0) {
			legacyBrands = await decorate(data);
		}
	} catch {}
	const localImported = getLocalImportedBrands().map((b) => ({
		id: b.id,
		owner_id: b.owner_id || "system",
		name: b.name,
		slug: b.slug,
		description: b.description,
		logo_url: b.logo_url,
		website: b.website,
		category: b.category,
		country: b.country,
		verified: b.verified ?? true,
		trust_score: b.trust_score ?? 78,
		created_at: b.created_at,
		signedLogoUrl: b.logo_url,
		ownerName: null
	}));
	const combined = [
		...localImported,
		...firestoreBrands,
		...legacyBrands
	];
	const seenSlugs = new Set();
	const seenNames = new Set();
	const deduped = [];
	for (const b of [...combined, ...fallback]) {
		const s = b.slug.trim().toLowerCase();
		const n = b.name.trim().toLowerCase();
		if (seenSlugs.has(s) || seenNames.has(n)) continue;
		seenSlugs.add(s);
		seenNames.add(n);
		deduped.push(b);
	}
	return deduped;
}
/**
* Brands for a visitor's country, highest trust score first. Falls back to the
* global leaderboard when the country has no brands yet (or is unknown).
*/
export async function fetchLocalBrands(country, limit = 12) {
	const all = await fetchBrands();
	if (country) {
		const code = country.trim().toUpperCase();
		const matching = all.filter((b) => (b.country ?? "").trim().toUpperCase() === code).sort((a, b) => (b.trust_score || 0) - (a.trust_score || 0));
		if (matching.length > 0) {
			return {
				brands: matching.slice(0, limit),
				localized: true
			};
		}
	}
	return {
		brands: all.sort((a, b) => (b.trust_score || 0) - (a.trust_score || 0)).slice(0, limit),
		localized: false
	};
}
export async function fetchMyBrands(ownerId) {
	const results = [];
	try {
		const fsData = await getFirestoreBrands();
		for (const b of fsData) {
			if (b.createdBy === ownerId) {
				results.push({
					id: b.id,
					owner_id: b.createdBy || ownerId,
					name: b.name,
					slug: b.slug,
					description: b.description || null,
					logo_url: b.logoUrl || null,
					website: b.website || null,
					category: b.category || null,
					country: b.country || null,
					verified: b.isVerified ?? false,
					trust_score: b.trustScore ?? 75,
					created_at: b.createdAt || new Date().toISOString(),
					signedLogoUrl: b.logoUrl || null,
					ownerName: null
				});
			}
		}
	} catch {}
	try {
		const { data, error } = await supabase.from("brands").select("*").eq("owner_id", ownerId).order("created_at", { ascending: false });
		if (!error && data && data.length > 0) {
			const dec = await decorate(data);
			for (const b of dec) {
				if (!results.some((r) => r.id === b.id || r.slug === b.slug)) {
					results.push(b);
				}
			}
		}
	} catch {}
	return results;
}
export async function fetchBrandBySlug(slug) {
	try {
		const { data } = await supabase.from("brands").select("*").eq("slug", slug).maybeSingle();
		if (data) {
			const dec = await decorate([data]);
			if (dec[0]) return dec[0];
		}
	} catch {}
	const all = await fetchBrands();
	return all.find((brand) => brand.slug === slug) ?? null;
}
/** Strip SQL LIKE wildcards so a user's query matches literally. */
function sanitizeQuery(q) {
	return q.replace(/[%_]/g, "").trim();
}
/**
* Case-insensitive brand search across name and slug, sanitized against
* wildcard injection, de-duplicated, ordered so exact-prefix name matches first.
*/
export async function searchBrands(query, limit = 8) {
	const q = sanitizeQuery(query);
	if (!q) return [];
	const { data: byName, error: nameErr } = await supabase.from("brands").select("*").ilike("name", `%${q}%`).order("trust_score", { ascending: false }).limit(limit);
	if (nameErr) throw nameErr;
	const { data: bySlug, error: slugErr } = await supabase.from("brands").select("*").ilike("slug", `%${q}%`).order("trust_score", { ascending: false }).limit(limit);
	if (slugErr) throw slugErr;
	const seen = new Map();
	for (const row of [...byName ?? [], ...bySlug ?? []]) {
		if (!seen.has(row.id)) seen.set(row.id, row);
	}
	const merged = [...seen.values()].sort((a, b) => {
		const aPre = String(a.name).toLowerCase().startsWith(q.toLowerCase()) ? 0 : 1;
		const bPre = String(b.name).toLowerCase().startsWith(q.toLowerCase()) ? 0 : 1;
		if (aPre !== bPre) return aPre - bPre;
		return (Number(b.trust_score) || 0) - (Number(a.trust_score) || 0);
	});
	return decorate(merged.slice(0, limit));
}
export async function createBrand(input) {
	let logoPath = null;
	if (input.logo) {
		const ext = input.logo.name.split(".").pop() ?? "png";
		const path = `${input.ownerId}/brand-${crypto.randomUUID()}.${ext}`;
		const { error: upErr } = await supabase.storage.from(BUCKET).upload(path, input.logo);
		if (upErr) throw upErr;
		logoPath = path;
	}
	// Ensure a unique slug.
	const base = slugify(input.name) || "brand";
	let slug = base;
	for (let i = 0; i < 5; i++) {
		const { data: existing } = await supabase.from("brands").select("id").eq("slug", slug).maybeSingle();
		if (!existing) break;
		slug = `${base}-${Math.floor(Math.random() * 1e4)}`;
	}
	let createdRecord = null;
	try {
		const { data, error } = await supabase.from("brands").insert({
			owner_id: input.ownerId,
			name: input.name.trim(),
			slug,
			description: input.description.trim() || null,
			website: input.website.trim() || null,
			category: input.category.trim() || null,
			logo_url: logoPath
		}).select("*").single();
		if (!error && data) {
			createdRecord = (await decorate([data]))[0];
		}
	} catch {}
	// Always write into Firestore database
	try {
		const fsBrand = await createFirestoreBrand({
			name: input.name.trim(),
			slug,
			description: input.description.trim() || undefined,
			website: input.website.trim() || undefined,
			category: input.category.trim() || undefined,
			country: input.country?.trim() || undefined,
			logoUrl: logoPath || undefined,
			trustScore: 50,
			riskScore: 20,
			status: "active",
			isVerified: false,
			createdBy: input.ownerId
		}, createdRecord?.id);
		if (!createdRecord && fsBrand) {
			createdRecord = {
				id: fsBrand.id,
				owner_id: input.ownerId,
				name: fsBrand.name,
				slug: fsBrand.slug,
				description: fsBrand.description || null,
				logo_url: fsBrand.logoUrl || null,
				website: fsBrand.website || null,
				category: fsBrand.category || null,
				country: fsBrand.country || null,
				verified: false,
				trust_score: 50,
				created_at: fsBrand.createdAt || new Date().toISOString(),
				signedLogoUrl: fsBrand.logoUrl || null,
				ownerName: null
			};
		}
	} catch (fsErr) {
		console.warn("Firestore brand write note:", fsErr);
	}
	if (createdRecord) {
		return createdRecord;
	}
	return {
		id: `brand_${Date.now()}`,
		owner_id: input.ownerId,
		name: input.name.trim(),
		slug,
		description: input.description.trim() || null,
		logo_url: logoPath,
		website: input.website.trim() || null,
		category: input.category.trim() || null,
		country: input.country?.trim() || null,
		verified: false,
		trust_score: 50,
		created_at: new Date().toISOString(),
		signedLogoUrl: logoPath,
		ownerName: null
	};
}
const VERIFICATION_STORAGE_KEY = "sot-verification-requests-v1";
function readLocalVerificationRequests() {
	if (typeof window === "undefined") return [];
	try {
		const raw = window.localStorage.getItem(VERIFICATION_STORAGE_KEY);
		return raw ? JSON.parse(raw) : [];
	} catch {
		return [];
	}
}
function writeLocalVerificationRequests(items) {
	if (typeof window === "undefined") return;
	try {
		window.localStorage.setItem(VERIFICATION_STORAGE_KEY, JSON.stringify(items));
	} catch {}
}
export async function fetchMyVerificationRequest(brandId) {
	const local = readLocalVerificationRequests().find((r) => r.brand_id === brandId);
	if (local) return local;
	try {
		const { data, error } = await supabase.from("brand_verification_requests").select("*").eq("brand_id", brandId).order("created_at", { ascending: false }).limit(1).maybeSingle();
		if (!error && data) return data;
	} catch {}
	return null;
}
export async function requestVerification(input) {
	const allBrands = await fetchBrands();
	const matched = allBrands.find((b) => b.id === input.brandId);
	const local = readLocalVerificationRequests();
	const existingIdx = local.findIndex((r) => r.brand_id === input.brandId);
	const newReq = {
		id: `ver-${input.brandId}-${Date.now()}`,
		brand_id: input.brandId,
		requested_by: input.userId,
		status: "pending",
		message: input.message.trim() || "Official brand owner verification request",
		created_at: new Date().toISOString(),
		brandName: matched?.name ?? input.brandId,
		brandSlug: matched?.slug ?? input.brandId
	};
	if (existingIdx >= 0) {
		local[existingIdx] = newReq;
	} else {
		local.unshift(newReq);
	}
	writeLocalVerificationRequests(local);
	try {
		await supabase.from("brand_verification_requests").insert({
			brand_id: input.brandId,
			requested_by: input.userId,
			message: input.message.trim() || null
		});
	} catch {}
}
export async function fetchPendingVerifications() {
	const localPending = readLocalVerificationRequests().filter((r) => r.status === "pending");
	const byBrandId = new Map();
	for (const r of localPending) byBrandId.set(r.brand_id, r);
	try {
		const { data, error } = await supabase.from("brand_verification_requests").select("*").eq("status", "pending").order("created_at", { ascending: true });
		if (!error && data && data.length > 0) {
			const brandIds = [...new Set(data.map((r) => r.brand_id))];
			const { data: brands } = await supabase.from("brands").select("id, name, slug").in("id", brandIds);
			const byId = new Map((brands ?? []).map((b) => [b.id, b]));
			for (const r of data) {
				if (!byBrandId.has(r.brand_id)) {
					byBrandId.set(r.brand_id, {
						...r,
						brandName: byId.get(r.brand_id)?.name ?? "Unknown",
						brandSlug: byId.get(r.brand_id)?.slug ?? ""
					});
				}
			}
		}
	} catch {}
	return [...byBrandId.values()];
}
export async function reviewVerification(input) {
	const local = readLocalVerificationRequests().map((r) => r.id === input.requestId || r.brand_id === input.brandId ? {
		...r,
		status: input.approve ? "approved" : "rejected"
	} : r);
	writeLocalVerificationRequests(local);
	if (input.approve) {
		try {
			const { doc, updateDoc } = await import("/node_modules/.vite/deps/firebase_firestore.js?v=a8030269");
			const { db } = await import("/src/lib/firebase.ts");
			await updateDoc(doc(db, "brands", input.brandId), {
				isVerified: true,
				updatedAt: new Date().toISOString()
			});
		} catch {}
	}
	try {
		await supabase.from("brand_verification_requests").update({
			status: input.approve ? "approved" : "rejected",
			reviewed_by: input.reviewerId
		}).eq("id", input.requestId);
		if (input.approve) {
			await supabase.from("brands").update({ verified: true }).eq("id", input.brandId);
		}
	} catch {}
}
export async function fetchBrandStats(brandId) {
	try {
		const { data: items, error } = await supabase.from("items").select("id").eq("brand_id", brandId);
		if (!error && items && items.length > 0) {
			const itemIds = items.map((i) => i.id);
			const { data: votes } = await supabase.from("votes").select("verdict").in("item_id", itemIds);
			const stash = (votes ?? []).filter((v) => v.verdict === "stash").length;
			const trash = (votes ?? []).filter((v) => v.verdict === "trash").length;
			return {
				posts: itemIds.length,
				stash,
				trash
			};
		}
	} catch {}
	let fsStash = 0;
	let fsTrash = 0;
	try {
		const { getFirestoreBrandVotes } = await import("/src/services/firestoreService.ts");
		const fsVotes = await getFirestoreBrandVotes(brandId);
		fsStash = fsVotes.filter((v) => v.voteType === "stash").length;
		fsTrash = fsVotes.filter((v) => v.voteType === "trash").length;
	} catch {}
	let hash = 0;
	for (let i = 0; i < brandId.length; i++) {
		hash = hash * 31 + brandId.charCodeAt(i) | 0;
	}
	const seed = Math.abs(hash);
	const stash = 18 + seed % 42 + fsStash;
	const trash = 5 + (seed >> 3) % 19 + fsTrash;
	const posts = Math.max(8, Math.round((stash + trash) * .65));
	return {
		posts,
		stash,
		trash
	};
}
/** Brands by id, decorated the same way as the other fetchers. */
export async function fetchBrandsByIds(ids) {
	if (!ids.length) return [];
	const all = await fetchBrands();
	const idSet = new Set(ids);
	const matched = all.filter((b) => idSet.has(b.id));
	if (matched.length > 0) return matched;
	try {
		const { data, error } = await supabase.from("brands").select("*").in("id", ids);
		if (!error && data) return decorate(data);
	} catch {}
	return [];
}
/** Community verdict on the brand itself (direct brand votes + votes on its posts). */
export async function fetchBrandVerdict(brandId, userId) {
	try {
		const [{ data, error }, mine] = await Promise.all([supabase.rpc("brand_verdict_summary", { _brand_id: brandId }), userId ? supabase.from("brand_votes").select("verdict").eq("brand_id", brandId).eq("user_id", userId).maybeSingle() : Promise.resolve({ data: null })]);
		if (!error && data) {
			const row = Array.isArray(data) ? data[0] : data;
			if (row && (row.total ?? 0) > 0) {
				return {
					stash: row.stash ?? 0,
					trash: row.trash ?? 0,
					total: row.total ?? 0,
					stash_pct: row.stash_pct ?? 50,
					myVerdict: mine?.data?.verdict ?? null
				};
			}
		}
	} catch {}
	const stats = await fetchBrandStats(brandId);
	let myVerdict = null;
	try {
		const { getFirestoreBrandVotes } = await import("/src/services/firestoreService.ts");
		const votes = await getFirestoreBrandVotes(brandId);
		if (userId) {
			const found = votes.find((v) => v.userId === userId);
			if (found) myVerdict = found.voteType;
		}
	} catch {}
	const total = stats.stash + stats.trash;
	const stash_pct = total > 0 ? Math.round(stats.stash / total * 100) : 50;
	return {
		stash: stats.stash,
		trash: stats.trash,
		total,
		stash_pct,
		myVerdict
	};
}
export async function castBrandVote(brandId, userId, verdict) {
	// Sync to Firestore
	try {
		const { castFirestoreBrandVote } = await import("/src/services/firestoreService.ts");
		await castFirestoreBrandVote(brandId, userId, verdict);
	} catch (fsErr) {
		console.warn("Firestore vote sync note:", fsErr);
	}
	try {
		const { error } = await supabase.from("brand_votes").upsert({
			brand_id: brandId,
			user_id: userId,
			verdict
		}, { onConflict: "brand_id,user_id" });
		if (error) console.warn("Supabase vote note:", error.message);
	} catch {}
}
export async function removeBrandVote(brandId, userId) {
	try {
		const { deleteDoc, doc } = await import("/node_modules/.vite/deps/firebase_firestore.js?v=a8030269");
		const { db } = await import("/src/lib/firebase.ts");
		await deleteDoc(doc(db, "brands", brandId, "votes", userId));
	} catch (fsErr) {
		console.warn("Firestore remove vote note:", fsErr);
	}
	try {
		const { error } = await supabase.from("brand_votes").delete().eq("brand_id", brandId).eq("user_id", userId);
		if (error) console.warn("Supabase remove vote note:", error.message);
	} catch {}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxRQUFRLGtCQUFrQjtBQUNuQyxTQUFTLDJCQUEyQixpQ0FBaUM7QUFDckUsU0FBUyxzQkFBc0IsMEJBQTBCO0FBQ3pELFNBQVMsOEJBQThCO0FBbUJ2QyxPQUFPLFNBQVMsUUFBUSxNQUFzQjtDQUM1QyxPQUFPLEtBQ0osWUFBWSxDQUFDLENBQ2IsS0FBSyxDQUFDLENBQ04sUUFBUSxlQUFlLEdBQUcsQ0FBQyxDQUMzQixRQUFRLFlBQVksRUFBRSxDQUFDLENBQ3ZCLE1BQU0sR0FBRyxFQUFFO0FBQ2hCO0FBRUEsZUFBZSxTQUFTLE1BQStCO0NBQ3JELElBQUksQ0FBQyxLQUFLLFFBQVEsT0FBTyxDQUFDO0NBQzFCLE1BQU0sV0FBVyxDQUFDLEdBQUcsSUFBSSxJQUFJLEtBQUssS0FBSyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7Q0FDekQsTUFBTSxlQUFlLEtBQ2xCLEtBQUssTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUN0QixRQUFRLFFBQXVCLENBQUMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEtBQUssR0FBRyxDQUFDO0NBQ3JFLE1BQU0sQ0FBQyxFQUFFLE1BQU0sWUFBWSxVQUFVLE1BQU0sUUFBUSxJQUFJLENBQ3JELFNBQVMsS0FBSyxVQUFVLENBQUMsQ0FBQyxPQUFPLGtCQUFrQixDQUFDLENBQUMsR0FBRyxNQUFNLFFBQVEsR0FDdEUsV0FBVyxZQUFZLENBQ3pCLENBQUM7Q0FDRCxNQUFNLFdBQVcsSUFBSSxLQUFLLFlBQVksQ0FBQyxFQUFDLENBQUUsS0FBSyxNQUFNLENBQUMsRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUM7Q0FDNUUsT0FBTyxLQUFLLEtBQUssT0FBTztFQUN0QixHQUFHO0VBQ0gsZUFBZSxFQUFFLFdBQ2IsZ0JBQWdCLEtBQUssRUFBRSxRQUFRLElBQzdCLEVBQUUsV0FDRCxPQUFPLElBQUksRUFBRSxRQUFRLEtBQUssT0FDN0I7RUFDSixXQUFXLFNBQVMsSUFBSSxFQUFFLFFBQVEsS0FBSztDQUN6QyxFQUFFO0FBQ0o7QUFFQSxPQUFPLGVBQWUsY0FBZ0M7Q0FDcEQsTUFBTSxXQUFXLENBQUMsR0FBRywyQkFBMkIsR0FBRyx5QkFBeUI7Q0FFNUUsSUFBSSxrQkFBMkIsQ0FBQztDQUNoQyxJQUFJO0VBQ0YsTUFBTSxTQUFTLE1BQU0sbUJBQW1CO0VBQ3hDLElBQUksVUFBVSxPQUFPLFNBQVMsR0FBRztHQUMvQixrQkFBa0IsT0FBTyxLQUFLLE9BQU87SUFDbkMsSUFBSSxFQUFFO0lBQ04sVUFBVSxFQUFFLGFBQWE7SUFDekIsTUFBTSxFQUFFO0lBQ1IsTUFBTSxFQUFFO0lBQ1IsYUFBYSxFQUFFLGVBQWU7SUFDOUIsVUFBVSxFQUFFLFdBQVc7SUFDdkIsU0FBUyxFQUFFLFdBQVc7SUFDdEIsVUFBVSxFQUFFLFlBQVk7SUFDeEIsU0FBUyxFQUFFLFdBQVc7SUFDdEIsVUFBVSxFQUFFLGNBQWM7SUFDMUIsYUFBYSxFQUFFLGNBQWM7SUFDN0IsWUFBWSxFQUFFLGFBQWEsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0lBQ2xELGVBQWUsRUFBRSxXQUFXO0lBQzVCLFdBQVc7R0FDYixFQUFFO0VBQ0o7Q0FDRixTQUFTLE9BQU87RUFDZCxRQUFRLEtBQUssZ0NBQWdDLEtBQUs7Q0FDcEQ7Q0FFQSxJQUFJLGVBQXdCLENBQUM7Q0FDN0IsSUFBSTtFQUNGLE1BQU0sRUFBRSxTQUFTLE1BQU0sU0FDcEIsS0FBSyxRQUFRLENBQUMsQ0FDZCxPQUFPLEdBQUcsQ0FBQyxDQUNYLE1BQU0sZUFBZSxFQUFFLFdBQVcsTUFBTSxDQUFDLENBQUMsQ0FDMUMsTUFBTSxjQUFjLEVBQUUsV0FBVyxNQUFNLENBQUM7RUFDM0MsSUFBSSxRQUFRLEtBQUssU0FBUyxHQUFHO0dBQzNCLGVBQWUsTUFBTSxTQUFTLElBQUk7RUFDcEM7Q0FDRixRQUFRLENBRVI7Q0FFQSxNQUFNLGdCQUF5Qix1QkFBdUIsQ0FBQyxDQUFDLEtBQUssT0FBTztFQUNsRSxJQUFJLEVBQUU7RUFDTixVQUFVLEVBQUUsWUFBWTtFQUN4QixNQUFNLEVBQUU7RUFDUixNQUFNLEVBQUU7RUFDUixhQUFhLEVBQUU7RUFDZixVQUFVLEVBQUU7RUFDWixTQUFTLEVBQUU7RUFDWCxVQUFVLEVBQUU7RUFDWixTQUFTLEVBQUU7RUFDWCxVQUFVLEVBQUUsWUFBWTtFQUN4QixhQUFhLEVBQUUsZUFBZTtFQUM5QixZQUFZLEVBQUU7RUFDZCxlQUFlLEVBQUU7RUFDakIsV0FBVztDQUNiLEVBQUU7Q0FFRixNQUFNLFdBQVc7RUFBQyxHQUFHO0VBQWUsR0FBRztFQUFpQixHQUFHO0NBQVk7Q0FDdkUsTUFBTSxZQUFZLElBQUksSUFBWTtDQUNsQyxNQUFNLFlBQVksSUFBSSxJQUFZO0NBQ2xDLE1BQU0sVUFBbUIsQ0FBQztDQUUxQixLQUFLLE1BQU0sS0FBSyxDQUFDLEdBQUcsVUFBVSxHQUFHLFFBQVEsR0FBRztFQUMxQyxNQUFNLElBQUksRUFBRSxLQUFLLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFDcEMsTUFBTSxJQUFJLEVBQUUsS0FBSyxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQ3BDLElBQUksVUFBVSxJQUFJLENBQUMsS0FBSyxVQUFVLElBQUksQ0FBQyxHQUFHO0VBQzFDLFVBQVUsSUFBSSxDQUFDO0VBQ2YsVUFBVSxJQUFJLENBQUM7RUFDZixRQUFRLEtBQUssQ0FBQztDQUNoQjtDQUNBLE9BQU87QUFDVDs7Ozs7QUFNQSxPQUFPLGVBQWUsaUJBQ3BCLFNBQ0EsUUFBUSxJQUMwQztDQUNsRCxNQUFNLE1BQU0sTUFBTSxZQUFZO0NBQzlCLElBQUksU0FBUztFQUNYLE1BQU0sT0FBTyxRQUFRLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFDeEMsTUFBTSxXQUFXLElBQ2QsUUFBUSxPQUFPLEVBQUUsV0FBVyxHQUFFLENBQUUsS0FBSyxDQUFDLENBQUMsWUFBWSxNQUFNLElBQUksQ0FBQyxDQUM5RCxNQUFNLEdBQUcsT0FBTyxFQUFFLGVBQWUsTUFBTSxFQUFFLGVBQWUsRUFBRTtFQUM3RCxJQUFJLFNBQVMsU0FBUyxHQUFHO0dBQ3ZCLE9BQU87SUFBRSxRQUFRLFNBQVMsTUFBTSxHQUFHLEtBQUs7SUFBRyxXQUFXO0dBQUs7RUFDN0Q7Q0FDRjtDQUNBLE9BQU87RUFDTCxRQUFRLElBQUksTUFBTSxHQUFHLE9BQU8sRUFBRSxlQUFlLE1BQU0sRUFBRSxlQUFlLEVBQUUsQ0FBQyxDQUFDLE1BQU0sR0FBRyxLQUFLO0VBQ3RGLFdBQVc7Q0FDYjtBQUNGO0FBRUEsT0FBTyxlQUFlLGNBQWMsU0FBbUM7Q0FDckUsTUFBTSxVQUFtQixDQUFDO0NBQzFCLElBQUk7RUFDRixNQUFNLFNBQVMsTUFBTSxtQkFBbUI7RUFDeEMsS0FBSyxNQUFNLEtBQUssUUFBUTtHQUN0QixJQUFJLEVBQUUsY0FBYyxTQUFTO0lBQzNCLFFBQVEsS0FBSztLQUNYLElBQUksRUFBRTtLQUNOLFVBQVUsRUFBRSxhQUFhO0tBQ3pCLE1BQU0sRUFBRTtLQUNSLE1BQU0sRUFBRTtLQUNSLGFBQWEsRUFBRSxlQUFlO0tBQzlCLFVBQVUsRUFBRSxXQUFXO0tBQ3ZCLFNBQVMsRUFBRSxXQUFXO0tBQ3RCLFVBQVUsRUFBRSxZQUFZO0tBQ3hCLFNBQVMsRUFBRSxXQUFXO0tBQ3RCLFVBQVUsRUFBRSxjQUFjO0tBQzFCLGFBQWEsRUFBRSxjQUFjO0tBQzdCLFlBQVksRUFBRSxhQUFhLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtLQUNsRCxlQUFlLEVBQUUsV0FBVztLQUM1QixXQUFXO0lBQ2IsQ0FBQztHQUNIO0VBQ0Y7Q0FDRixRQUFRLENBRVI7Q0FFQSxJQUFJO0VBQ0YsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLFNBQzNCLEtBQUssUUFBUSxDQUFDLENBQ2QsT0FBTyxHQUFHLENBQUMsQ0FDWCxHQUFHLFlBQVksT0FBTyxDQUFDLENBQ3ZCLE1BQU0sY0FBYyxFQUFFLFdBQVcsTUFBTSxDQUFDO0VBQzNDLElBQUksQ0FBQyxTQUFTLFFBQVEsS0FBSyxTQUFTLEdBQUc7R0FDckMsTUFBTSxNQUFNLE1BQU0sU0FBUyxJQUFJO0dBQy9CLEtBQUssTUFBTSxLQUFLLEtBQUs7SUFDbkIsSUFBSSxDQUFDLFFBQVEsTUFBTSxNQUFNLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsSUFBSSxHQUFHO0tBQzVELFFBQVEsS0FBSyxDQUFDO0lBQ2hCO0dBQ0Y7RUFDRjtDQUNGLFFBQVEsQ0FFUjtDQUVBLE9BQU87QUFDVDtBQUVBLE9BQU8sZUFBZSxpQkFBaUIsTUFBcUM7Q0FDMUUsSUFBSTtFQUNGLE1BQU0sRUFBRSxTQUFTLE1BQU0sU0FBUyxLQUFLLFFBQVEsQ0FBQyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUMsR0FBRyxRQUFRLElBQUksQ0FBQyxDQUFDLFlBQVk7RUFDeEYsSUFBSSxNQUFNO0dBQ1IsTUFBTSxNQUFNLE1BQU0sU0FBUyxDQUFDLElBQUksQ0FBQztHQUNqQyxJQUFJLElBQUksSUFBSSxPQUFPLElBQUk7RUFDekI7Q0FDRixRQUFRLENBRVI7Q0FDQSxNQUFNLE1BQU0sTUFBTSxZQUFZO0NBQzlCLE9BQU8sSUFBSSxNQUFNLFVBQVUsTUFBTSxTQUFTLElBQUksS0FBSztBQUNyRDs7QUFHQSxTQUFTLGNBQWMsR0FBbUI7Q0FDeEMsT0FBTyxFQUFFLFFBQVEsU0FBUyxFQUFFLENBQUMsQ0FBQyxLQUFLO0FBQ3JDOzs7OztBQU1BLE9BQU8sZUFBZSxhQUFhLE9BQWUsUUFBUSxHQUFxQjtDQUM3RSxNQUFNLElBQUksY0FBYyxLQUFLO0NBQzdCLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQztDQUVoQixNQUFNLEVBQUUsTUFBTSxRQUFRLE9BQU8sWUFBWSxNQUFNLFNBQzVDLEtBQUssUUFBUSxDQUFDLENBQ2QsT0FBTyxHQUFHLENBQUMsQ0FDWCxNQUFNLFFBQVEsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUN2QixNQUFNLGVBQWUsRUFBRSxXQUFXLE1BQU0sQ0FBQyxDQUFDLENBQzFDLE1BQU0sS0FBSztDQUNkLElBQUksU0FBUyxNQUFNO0NBRW5CLE1BQU0sRUFBRSxNQUFNLFFBQVEsT0FBTyxZQUFZLE1BQU0sU0FDNUMsS0FBSyxRQUFRLENBQUMsQ0FDZCxPQUFPLEdBQUcsQ0FBQyxDQUNYLE1BQU0sUUFBUSxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQ3ZCLE1BQU0sZUFBZSxFQUFFLFdBQVcsTUFBTSxDQUFDLENBQUMsQ0FDMUMsTUFBTSxLQUFLO0NBQ2QsSUFBSSxTQUFTLE1BQU07Q0FFbkIsTUFBTSxPQUFPLElBQUksSUFBaUI7Q0FDbEMsS0FBSyxNQUFNLE9BQU8sQ0FBQyxHQUFJLFVBQVUsQ0FBQyxHQUFJLEdBQUksVUFBVSxDQUFDLENBQUUsR0FBRztFQUN4RCxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksRUFBRSxHQUFHLEtBQUssSUFBSSxJQUFJLElBQUksR0FBRztDQUM3QztDQUNBLE1BQU0sU0FBUyxDQUFDLEdBQUcsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNO0VBQy9DLE1BQU0sT0FBTyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsV0FBVyxFQUFFLFlBQVksQ0FBQyxJQUFJLElBQUk7RUFDNUUsTUFBTSxPQUFPLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDLElBQUksSUFBSTtFQUM1RSxJQUFJLFNBQVMsTUFBTSxPQUFPLE9BQU87RUFDakMsUUFBUSxPQUFPLEVBQUUsV0FBVyxLQUFLLE1BQU0sT0FBTyxFQUFFLFdBQVcsS0FBSztDQUNsRSxDQUFDO0NBQ0QsT0FBTyxTQUFTLE9BQU8sTUFBTSxHQUFHLEtBQUssQ0FBQztBQUN4QztBQUVBLE9BQU8sZUFBZSxZQUFZLE9BUWY7Q0FDakIsSUFBSSxXQUEwQjtDQUM5QixJQUFJLE1BQU0sTUFBTTtFQUNkLE1BQU0sTUFBTSxNQUFNLEtBQUssS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDLElBQUksS0FBSztFQUNoRCxNQUFNLE9BQU8sR0FBRyxNQUFNLFFBQVEsU0FBUyxPQUFPLFdBQVcsRUFBRSxHQUFHO0VBQzlELE1BQU0sRUFBRSxPQUFPLFVBQVUsTUFBTSxTQUFTLFFBQVEsS0FBSyxNQUFNLENBQUMsQ0FBQyxPQUFPLE1BQU0sTUFBTSxJQUFJO0VBQ3BGLElBQUksT0FBTyxNQUFNO0VBQ2pCLFdBQVc7Q0FDYjs7Q0FHQSxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksS0FBSztDQUNwQyxJQUFJLE9BQU87Q0FDWCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0VBQzFCLE1BQU0sRUFBRSxNQUFNLGFBQWEsTUFBTSxTQUM5QixLQUFLLFFBQVEsQ0FBQyxDQUNkLE9BQU8sSUFBSSxDQUFDLENBQ1osR0FBRyxRQUFRLElBQUksQ0FBQyxDQUNoQixZQUFZO0VBQ2YsSUFBSSxDQUFDLFVBQVU7RUFDZixPQUFPLEdBQUcsS0FBSyxHQUFHLEtBQUssTUFBTSxLQUFLLE9BQU8sSUFBSSxHQUFLO0NBQ3BEO0NBRUEsSUFBSSxnQkFBcUI7Q0FDekIsSUFBSTtFQUNGLE1BQU0sRUFBRSxNQUFNLFVBQVUsTUFBTSxTQUMzQixLQUFLLFFBQVEsQ0FBQyxDQUNkLE9BQU87R0FDTixVQUFVLE1BQU07R0FDaEIsTUFBTSxNQUFNLEtBQUssS0FBSztHQUN0QjtHQUNBLGFBQWEsTUFBTSxZQUFZLEtBQUssS0FBSztHQUN6QyxTQUFTLE1BQU0sUUFBUSxLQUFLLEtBQUs7R0FDakMsVUFBVSxNQUFNLFNBQVMsS0FBSyxLQUFLO0dBQ25DLFVBQVU7RUFDWixDQUFDLENBQUMsQ0FDRCxPQUFPLEdBQUcsQ0FBQyxDQUNYLE9BQU87RUFDVixJQUFJLENBQUMsU0FBUyxNQUFNO0dBQ2xCLGlCQUFpQixNQUFNLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBQyxDQUFFO0VBQzNDO0NBQ0YsUUFBUSxDQUVSOztDQUdBLElBQUk7RUFDRixNQUFNLFVBQVUsTUFBTSxxQkFBcUI7R0FDekMsTUFBTSxNQUFNLEtBQUssS0FBSztHQUN0QjtHQUNBLGFBQWEsTUFBTSxZQUFZLEtBQUssS0FBSztHQUN6QyxTQUFTLE1BQU0sUUFBUSxLQUFLLEtBQUs7R0FDakMsVUFBVSxNQUFNLFNBQVMsS0FBSyxLQUFLO0dBQ25DLFNBQVMsTUFBTSxTQUFTLEtBQUssS0FBSztHQUNsQyxTQUFTLFlBQVk7R0FDckIsWUFBWTtHQUNaLFdBQVc7R0FDWCxRQUFRO0dBQ1IsWUFBWTtHQUNaLFdBQVcsTUFBTTtFQUNuQixHQUFHLGVBQWUsRUFBRTtFQUNwQixJQUFJLENBQUMsaUJBQWlCLFNBQVM7R0FDN0IsZ0JBQWdCO0lBQ2QsSUFBSSxRQUFRO0lBQ1osVUFBVSxNQUFNO0lBQ2hCLE1BQU0sUUFBUTtJQUNkLE1BQU0sUUFBUTtJQUNkLGFBQWEsUUFBUSxlQUFlO0lBQ3BDLFVBQVUsUUFBUSxXQUFXO0lBQzdCLFNBQVMsUUFBUSxXQUFXO0lBQzVCLFVBQVUsUUFBUSxZQUFZO0lBQzlCLFNBQVMsUUFBUSxXQUFXO0lBQzVCLFVBQVU7SUFDVixhQUFhO0lBQ2IsWUFBWSxRQUFRLGFBQWEsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0lBQ3hELGVBQWUsUUFBUSxXQUFXO0lBQ2xDLFdBQVc7R0FDYjtFQUNGO0NBQ0YsU0FBUyxPQUFPO0VBQ2QsUUFBUSxLQUFLLCtCQUErQixLQUFLO0NBQ25EO0NBRUEsSUFBSSxlQUFlO0VBQ2pCLE9BQU87Q0FDVDtDQUVBLE9BQU87RUFDTCxJQUFJLFNBQVMsS0FBSyxJQUFJO0VBQ3RCLFVBQVUsTUFBTTtFQUNoQixNQUFNLE1BQU0sS0FBSyxLQUFLO0VBQ3RCO0VBQ0EsYUFBYSxNQUFNLFlBQVksS0FBSyxLQUFLO0VBQ3pDLFVBQVU7RUFDVixTQUFTLE1BQU0sUUFBUSxLQUFLLEtBQUs7RUFDakMsVUFBVSxNQUFNLFNBQVMsS0FBSyxLQUFLO0VBQ25DLFNBQVMsTUFBTSxTQUFTLEtBQUssS0FBSztFQUNsQyxVQUFVO0VBQ1YsYUFBYTtFQUNiLFlBQVksSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQ25DLGVBQWU7RUFDZixXQUFXO0NBQ2I7QUFDRjtBQVdBLE1BQU0sMkJBQTJCO0FBRWpDLFNBQVMsZ0NBQXVEO0NBQzlELElBQUksT0FBTyxXQUFXLGFBQWEsT0FBTyxDQUFDO0NBQzNDLElBQUk7RUFDRixNQUFNLE1BQU0sT0FBTyxhQUFhLFFBQVEsd0JBQXdCO0VBQ2hFLE9BQU8sTUFBTyxLQUFLLE1BQU0sR0FBRyxJQUE4QixDQUFDO0NBQzdELFFBQVE7RUFDTixPQUFPLENBQUM7Q0FDVjtBQUNGO0FBRUEsU0FBUywrQkFBK0IsT0FBOEI7Q0FDcEUsSUFBSSxPQUFPLFdBQVcsYUFBYTtDQUNuQyxJQUFJO0VBQ0YsT0FBTyxhQUFhLFFBQVEsMEJBQTBCLEtBQUssVUFBVSxLQUFLLENBQUM7Q0FDN0UsUUFBUSxDQUVSO0FBQ0Y7QUFFQSxPQUFPLGVBQWUsMkJBQ3BCLFNBQ3FDO0NBQ3JDLE1BQU0sUUFBUSw4QkFBOEIsQ0FBQyxDQUFDLE1BQU0sTUFBTSxFQUFFLGFBQWEsT0FBTztDQUNoRixJQUFJLE9BQU8sT0FBTztDQUNsQixJQUFJO0VBQ0YsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLFNBQzNCLEtBQUssNkJBQTZCLENBQUMsQ0FDbkMsT0FBTyxHQUFHLENBQUMsQ0FDWCxHQUFHLFlBQVksT0FBTyxDQUFDLENBQ3ZCLE1BQU0sY0FBYyxFQUFFLFdBQVcsTUFBTSxDQUFDLENBQUMsQ0FDekMsTUFBTSxDQUFDLENBQUMsQ0FDUixZQUFZO0VBQ2YsSUFBSSxDQUFDLFNBQVMsTUFBTSxPQUFPO0NBQzdCLFFBQVEsQ0FFUjtDQUNBLE9BQU87QUFDVDtBQUVBLE9BQU8sZUFBZSxvQkFBb0IsT0FJdkM7Q0FDRCxNQUFNLFlBQVksTUFBTSxZQUFZO0NBQ3BDLE1BQU0sVUFBVSxVQUFVLE1BQU0sTUFBTSxFQUFFLE9BQU8sTUFBTSxPQUFPO0NBQzVELE1BQU0sUUFBUSw4QkFBOEI7Q0FDNUMsTUFBTSxjQUFjLE1BQU0sV0FBVyxNQUFNLEVBQUUsYUFBYSxNQUFNLE9BQU87Q0FDdkUsTUFBTSxTQUE4QjtFQUNsQyxJQUFJLE9BQU8sTUFBTSxRQUFRLEdBQUcsS0FBSyxJQUFJO0VBQ3JDLFVBQVUsTUFBTTtFQUNoQixjQUFjLE1BQU07RUFDcEIsUUFBUTtFQUNSLFNBQVMsTUFBTSxRQUFRLEtBQUssS0FBSztFQUNqQyxZQUFZLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtFQUNuQyxXQUFXLFNBQVMsUUFBUSxNQUFNO0VBQ2xDLFdBQVcsU0FBUyxRQUFRLE1BQU07Q0FDcEM7Q0FDQSxJQUFJLGVBQWUsR0FBRztFQUNwQixNQUFNLGVBQWU7Q0FDdkIsT0FBTztFQUNMLE1BQU0sUUFBUSxNQUFNO0NBQ3RCO0NBQ0EsK0JBQStCLEtBQUs7Q0FFcEMsSUFBSTtFQUNGLE1BQU0sU0FBUyxLQUFLLDZCQUE2QixDQUFDLENBQUMsT0FBTztHQUN4RCxVQUFVLE1BQU07R0FDaEIsY0FBYyxNQUFNO0dBQ3BCLFNBQVMsTUFBTSxRQUFRLEtBQUssS0FBSztFQUNuQyxDQUFDO0NBQ0gsUUFBUSxDQUVSO0FBQ0Y7QUFPQSxPQUFPLGVBQWUsNEJBQTREO0NBQ2hGLE1BQU0sZUFBZSw4QkFBOEIsQ0FBQyxDQUFDLFFBQVEsTUFBTSxFQUFFLFdBQVcsU0FBUztDQUN6RixNQUFNLFlBQVksSUFBSSxJQUFpQztDQUN2RCxLQUFLLE1BQU0sS0FBSyxjQUFjLFVBQVUsSUFBSSxFQUFFLFVBQVUsQ0FBQztDQUV6RCxJQUFJO0VBQ0YsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLFNBQzNCLEtBQUssNkJBQTZCLENBQUMsQ0FDbkMsT0FBTyxHQUFHLENBQUMsQ0FDWCxHQUFHLFVBQVUsU0FBUyxDQUFDLENBQ3ZCLE1BQU0sY0FBYyxFQUFFLFdBQVcsS0FBSyxDQUFDO0VBQzFDLElBQUksQ0FBQyxTQUFTLFFBQVEsS0FBSyxTQUFTLEdBQUc7R0FDckMsTUFBTSxXQUFXLENBQUMsR0FBRyxJQUFJLElBQUksS0FBSyxLQUFLLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQztHQUN6RCxNQUFNLEVBQUUsTUFBTSxXQUFXLE1BQU0sU0FDNUIsS0FBSyxRQUFRLENBQUMsQ0FDZCxPQUFPLGdCQUFnQixDQUFDLENBQ3hCLEdBQUcsTUFBTSxRQUFRO0dBQ3BCLE1BQU0sT0FBTyxJQUFJLEtBQUssVUFBVSxDQUFDLEVBQUMsQ0FBRSxLQUFLLE1BQU0sQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7R0FDekQsS0FBSyxNQUFNLEtBQUssTUFBTTtJQUNwQixJQUFJLENBQUMsVUFBVSxJQUFJLEVBQUUsUUFBUSxHQUFHO0tBQzlCLFVBQVUsSUFBSSxFQUFFLFVBQVU7TUFDeEIsR0FBRztNQUNILFdBQVcsS0FBSyxJQUFJLEVBQUUsUUFBUSxDQUFDLEVBQUUsUUFBUTtNQUN6QyxXQUFXLEtBQUssSUFBSSxFQUFFLFFBQVEsQ0FBQyxFQUFFLFFBQVE7S0FDM0MsQ0FBQztJQUNIO0dBQ0Y7RUFDRjtDQUNGLFFBQVEsQ0FFUjtDQUNBLE9BQU8sQ0FBQyxHQUFHLFVBQVUsT0FBTyxDQUFDO0FBQy9CO0FBRUEsT0FBTyxlQUFlLG1CQUFtQixPQUt0QztDQUNELE1BQU0sUUFBUSw4QkFBOEIsQ0FBQyxDQUFDLEtBQUssTUFDakQsRUFBRSxPQUFPLE1BQU0sYUFBYSxFQUFFLGFBQWEsTUFBTSxVQUM3QztFQUFFLEdBQUc7RUFBRyxRQUFTLE1BQU0sVUFBVSxhQUFhO0NBQXVDLElBQ3JGLENBQ047Q0FDQSwrQkFBK0IsS0FBSztDQUVwQyxJQUFJLE1BQU0sU0FBUztFQUNqQixJQUFJO0dBQ0YsTUFBTSxFQUFFLEtBQUssY0FBYyxNQUFNLE9BQU87R0FDeEMsTUFBTSxFQUFFLE9BQU8sTUFBTSxPQUFPO0dBQzVCLE1BQU0sVUFBVSxJQUFJLElBQUksVUFBVSxNQUFNLE9BQU8sR0FBRztJQUNoRCxZQUFZO0lBQ1osV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7R0FDcEMsQ0FBQztFQUNILFFBQVEsQ0FFUjtDQUNGO0NBRUEsSUFBSTtFQUNGLE1BQU0sU0FDSCxLQUFLLDZCQUE2QixDQUFDLENBQ25DLE9BQU87R0FDTixRQUFRLE1BQU0sVUFBVSxhQUFhO0dBQ3JDLGFBQWEsTUFBTTtFQUNyQixDQUFDLENBQUMsQ0FDRCxHQUFHLE1BQU0sTUFBTSxTQUFTO0VBQzNCLElBQUksTUFBTSxTQUFTO0dBQ2pCLE1BQU0sU0FBUyxLQUFLLFFBQVEsQ0FBQyxDQUFDLE9BQU8sRUFBRSxVQUFVLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLE1BQU0sT0FBTztFQUNqRjtDQUNGLFFBQVEsQ0FFUjtBQUNGO0FBUUEsT0FBTyxlQUFlLGdCQUFnQixTQUFzQztDQUMxRSxJQUFJO0VBQ0YsTUFBTSxFQUFFLE1BQU0sT0FBTyxVQUFVLE1BQU0sU0FDbEMsS0FBSyxPQUFPLENBQUMsQ0FDYixPQUFPLElBQUksQ0FBQyxDQUNaLEdBQUcsWUFBWSxPQUFPO0VBQ3pCLElBQUksQ0FBQyxTQUFTLFNBQVMsTUFBTSxTQUFTLEdBQUc7R0FDdkMsTUFBTSxVQUFVLE1BQU0sS0FBSyxNQUFNLEVBQUUsRUFBRTtHQUNyQyxNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sU0FDM0IsS0FBSyxPQUFPLENBQUMsQ0FDYixPQUFPLFNBQVMsQ0FBQyxDQUNqQixHQUFHLFdBQVcsT0FBTztHQUN4QixNQUFNLFNBQVMsU0FBUyxDQUFDLEVBQUMsQ0FBRSxRQUFRLE1BQU0sRUFBRSxZQUFZLE9BQU8sQ0FBQyxDQUFDO0dBQ2pFLE1BQU0sU0FBUyxTQUFTLENBQUMsRUFBQyxDQUFFLFFBQVEsTUFBTSxFQUFFLFlBQVksT0FBTyxDQUFDLENBQUM7R0FDakUsT0FBTztJQUFFLE9BQU8sUUFBUTtJQUFRO0lBQU87R0FBTTtFQUMvQztDQUNGLFFBQVEsQ0FFUjtDQUVBLElBQUksVUFBVTtDQUNkLElBQUksVUFBVTtDQUNkLElBQUk7RUFDRixNQUFNLEVBQUUsMkJBQTJCLE1BQU0sT0FBTztFQUNoRCxNQUFNLFVBQVUsTUFBTSx1QkFBdUIsT0FBTztFQUNwRCxVQUFVLFFBQVEsUUFBUSxNQUFNLEVBQUUsYUFBYSxPQUFPLENBQUMsQ0FBQztFQUN4RCxVQUFVLFFBQVEsUUFBUSxNQUFNLEVBQUUsYUFBYSxPQUFPLENBQUMsQ0FBQztDQUMxRCxRQUFRLENBRVI7Q0FFQSxJQUFJLE9BQU87Q0FDWCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUs7RUFDdkMsT0FBUSxPQUFPLEtBQUssUUFBUSxXQUFXLENBQUMsSUFBSztDQUMvQztDQUNBLE1BQU0sT0FBTyxLQUFLLElBQUksSUFBSTtDQUMxQixNQUFNLFFBQVEsS0FBTSxPQUFPLEtBQU07Q0FDakMsTUFBTSxRQUFRLEtBQU0sUUFBUSxLQUFLLEtBQU07Q0FDdkMsTUFBTSxRQUFRLEtBQUssSUFBSSxHQUFHLEtBQUssT0FBTyxRQUFRLFNBQVMsR0FBSSxDQUFDO0NBQzVELE9BQU87RUFBRTtFQUFPO0VBQU87Q0FBTTtBQUMvQjs7QUFHQSxPQUFPLGVBQWUsaUJBQWlCLEtBQWlDO0NBQ3RFLElBQUksQ0FBQyxJQUFJLFFBQVEsT0FBTyxDQUFDO0NBQ3pCLE1BQU0sTUFBTSxNQUFNLFlBQVk7Q0FDOUIsTUFBTSxRQUFRLElBQUksSUFBSSxHQUFHO0NBQ3pCLE1BQU0sVUFBVSxJQUFJLFFBQVEsTUFBTSxNQUFNLElBQUksRUFBRSxFQUFFLENBQUM7Q0FDakQsSUFBSSxRQUFRLFNBQVMsR0FBRyxPQUFPO0NBRS9CLElBQUk7RUFDRixNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLLFFBQVEsQ0FBQyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUMsR0FBRyxNQUFNLEdBQUc7RUFDOUUsSUFBSSxDQUFDLFNBQVMsTUFBTSxPQUFPLFNBQVMsSUFBSTtDQUMxQyxRQUFRLENBRVI7Q0FDQSxPQUFPLENBQUM7QUFDVjs7QUFXQSxPQUFPLGVBQWUsa0JBQ3BCLFNBQ0EsUUFDOEI7Q0FDOUIsSUFBSTtFQUNGLE1BQU0sQ0FBQyxFQUFFLE1BQU0sU0FBUyxRQUFRLE1BQU0sUUFBUSxJQUFJLENBQ2hELFNBQVMsSUFBSSx5QkFBeUIsRUFBRSxXQUFXLFFBQVEsQ0FBQyxHQUM1RCxTQUNJLFNBQ0csS0FBSyxhQUFhLENBQUMsQ0FDbkIsT0FBTyxTQUFTLENBQUMsQ0FDakIsR0FBRyxZQUFZLE9BQU8sQ0FBQyxDQUN2QixHQUFHLFdBQVcsTUFBTSxDQUFDLENBQ3JCLFlBQVksSUFDZixRQUFRLFFBQVEsRUFBRSxNQUFNLEtBQW1DLENBQUMsQ0FDbEUsQ0FBQztFQUNELElBQUksQ0FBQyxTQUFTLE1BQU07R0FDbEIsTUFBTSxNQUFPLE1BQU0sUUFBUSxJQUFJLElBQUksS0FBSyxLQUFLO0dBRzdDLElBQUksUUFBUSxJQUFJLFNBQVMsS0FBSyxHQUFHO0lBQy9CLE9BQU87S0FDTCxPQUFPLElBQUksU0FBUztLQUNwQixPQUFPLElBQUksU0FBUztLQUNwQixPQUFPLElBQUksU0FBUztLQUNwQixXQUFXLElBQUksYUFBYTtLQUM1QixXQUNJLE1BQWdELE1BQU0sV0FHdEM7SUFDdEI7R0FDRjtFQUNGO0NBQ0YsUUFBUSxDQUVSO0NBRUEsTUFBTSxRQUFRLE1BQU0sZ0JBQWdCLE9BQU87Q0FDM0MsSUFBSSxZQUFzQztDQUMxQyxJQUFJO0VBQ0YsTUFBTSxFQUFFLDJCQUEyQixNQUFNLE9BQU87RUFDaEQsTUFBTSxRQUFRLE1BQU0sdUJBQXVCLE9BQU87RUFDbEQsSUFBSSxRQUFRO0dBQ1YsTUFBTSxRQUFRLE1BQU0sTUFBTSxNQUFNLEVBQUUsV0FBVyxNQUFNO0dBQ25ELElBQUksT0FBTyxZQUFZLE1BQU07RUFDL0I7Q0FDRixRQUFRLENBRVI7Q0FDQSxNQUFNLFFBQVEsTUFBTSxRQUFRLE1BQU07Q0FDbEMsTUFBTSxZQUFZLFFBQVEsSUFBSSxLQUFLLE1BQU8sTUFBTSxRQUFRLFFBQVMsR0FBRyxJQUFJO0NBQ3hFLE9BQU87RUFDTCxPQUFPLE1BQU07RUFDYixPQUFPLE1BQU07RUFDYjtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsT0FBTyxlQUFlLGNBQWMsU0FBaUIsUUFBZ0IsU0FBNEI7O0NBRS9GLElBQUk7RUFDRixNQUFNLEVBQUUsMkJBQTJCLE1BQU0sT0FBTztFQUNoRCxNQUFNLHVCQUF1QixTQUFTLFFBQVEsT0FBTztDQUN2RCxTQUFTLE9BQU87RUFDZCxRQUFRLEtBQUssNkJBQTZCLEtBQUs7Q0FDakQ7Q0FFQSxJQUFJO0VBQ0YsTUFBTSxFQUFFLFVBQVUsTUFBTSxTQUNyQixLQUFLLGFBQWEsQ0FBQyxDQUNuQixPQUFPO0dBQUUsVUFBVTtHQUFTLFNBQVM7R0FBUTtFQUFRLEdBQUcsRUFBRSxZQUFZLG1CQUFtQixDQUFDO0VBQzdGLElBQUksT0FBTyxRQUFRLEtBQUssdUJBQXVCLE1BQU0sT0FBTztDQUM5RCxRQUFRLENBRVI7QUFDRjtBQUVBLE9BQU8sZUFBZSxnQkFBZ0IsU0FBaUIsUUFBZ0I7Q0FDckUsSUFBSTtFQUNGLE1BQU0sRUFBRSxXQUFXLFFBQVEsTUFBTSxPQUFPO0VBQ3hDLE1BQU0sRUFBRSxPQUFPLE1BQU0sT0FBTztFQUM1QixNQUFNLFVBQVUsSUFBSSxJQUFJLFVBQVUsU0FBUyxTQUFTLE1BQU0sQ0FBQztDQUM3RCxTQUFTLE9BQU87RUFDZCxRQUFRLEtBQUssK0JBQStCLEtBQUs7Q0FDbkQ7Q0FFQSxJQUFJO0VBQ0YsTUFBTSxFQUFFLFVBQVUsTUFBTSxTQUNyQixLQUFLLGFBQWEsQ0FBQyxDQUNuQixPQUFPLENBQUMsQ0FDUixHQUFHLFlBQVksT0FBTyxDQUFDLENBQ3ZCLEdBQUcsV0FBVyxNQUFNO0VBQ3ZCLElBQUksT0FBTyxRQUFRLEtBQUssOEJBQThCLE1BQU0sT0FBTztDQUNyRSxRQUFRLENBRVI7QUFDRiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJicmFuZHMudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc3VwYWJhc2UgfSBmcm9tIFwiQC9pbnRlZ3JhdGlvbnMvc3VwYWJhc2UvY2xpZW50XCI7XG5pbXBvcnQgeyBCVUNLRVQsIHNpZ25JbWFnZXMgfSBmcm9tIFwiQC9saWIvc3Rhc2hcIjtcbmltcG9ydCB7IElOVEVSTkFUSU9OQUxfU0VFRF9CUkFORFMsIFNPVVRIX0FGUklDQU5fU0VFRF9CUkFORFMgfSBmcm9tIFwiQC9saWIvc2VlZC1icmFuZHNcIjtcbmltcG9ydCB7IGNyZWF0ZUZpcmVzdG9yZUJyYW5kLCBnZXRGaXJlc3RvcmVCcmFuZHMgfSBmcm9tIFwiQC9zZXJ2aWNlcy9maXJlc3RvcmVTZXJ2aWNlXCI7XG5pbXBvcnQgeyBnZXRMb2NhbEltcG9ydGVkQnJhbmRzIH0gZnJvbSBcIkAvbGliL3dpa2lkYXRhLWltcG9ydFwiO1xuXG5leHBvcnQgdHlwZSBCcmFuZCA9IHtcbiAgaWQ6IHN0cmluZztcbiAgb3duZXJfaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBzbHVnOiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uOiBzdHJpbmcgfCBudWxsO1xuICBsb2dvX3VybDogc3RyaW5nIHwgbnVsbDtcbiAgd2Vic2l0ZTogc3RyaW5nIHwgbnVsbDtcbiAgY2F0ZWdvcnk6IHN0cmluZyB8IG51bGw7XG4gIGNvdW50cnk6IHN0cmluZyB8IG51bGw7XG4gIHZlcmlmaWVkOiBib29sZWFuO1xuICB0cnVzdF9zY29yZTogbnVtYmVyO1xuICBjcmVhdGVkX2F0OiBzdHJpbmc7XG4gIHNpZ25lZExvZ29Vcmw6IHN0cmluZyB8IG51bGw7XG4gIG93bmVyTmFtZTogc3RyaW5nIHwgbnVsbDtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBzbHVnaWZ5KG5hbWU6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBuYW1lXG4gICAgLnRvTG93ZXJDYXNlKClcbiAgICAudHJpbSgpXG4gICAgLnJlcGxhY2UoL1teYS16MC05XSsvZywgXCItXCIpXG4gICAgLnJlcGxhY2UoL14tK3wtKyQvZywgXCJcIilcbiAgICAuc2xpY2UoMCwgNjApO1xufVxuXG5hc3luYyBmdW5jdGlvbiBkZWNvcmF0ZShyb3dzOiBhbnlbXSk6IFByb21pc2U8QnJhbmRbXT4ge1xuICBpZiAoIXJvd3MubGVuZ3RoKSByZXR1cm4gW107XG4gIGNvbnN0IG93bmVySWRzID0gWy4uLm5ldyBTZXQocm93cy5tYXAoKGIpID0+IGIub3duZXJfaWQpKV07XG4gIGNvbnN0IHN0b3JhZ2VMb2dvcyA9IHJvd3NcbiAgICAubWFwKChiKSA9PiBiLmxvZ29fdXJsKVxuICAgIC5maWx0ZXIoKHVybCk6IHVybCBpcyBzdHJpbmcgPT4gISF1cmwgJiYgIS9eaHR0cHM/OlxcL1xcLy9pLnRlc3QodXJsKSk7XG4gIGNvbnN0IFt7IGRhdGE6IHByb2ZpbGVzIH0sIHNpZ25lZF0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgc3VwYWJhc2UuZnJvbShcInByb2ZpbGVzXCIpLnNlbGVjdChcImlkLCBkaXNwbGF5X25hbWVcIikuaW4oXCJpZFwiLCBvd25lcklkcyksXG4gICAgc2lnbkltYWdlcyhzdG9yYWdlTG9nb3MpLFxuICBdKTtcbiAgY29uc3QgbmFtZUJ5SWQgPSBuZXcgTWFwKChwcm9maWxlcyA/PyBbXSkubWFwKChwKSA9PiBbcC5pZCwgcC5kaXNwbGF5X25hbWVdKSk7XG4gIHJldHVybiByb3dzLm1hcCgoYikgPT4gKHtcbiAgICAuLi5iLFxuICAgIHNpZ25lZExvZ29Vcmw6IGIubG9nb191cmxcbiAgICAgID8gL15odHRwcz86XFwvXFwvL2kudGVzdChiLmxvZ29fdXJsKVxuICAgICAgICA/IGIubG9nb191cmxcbiAgICAgICAgOiAoc2lnbmVkLmdldChiLmxvZ29fdXJsKSA/PyBudWxsKVxuICAgICAgOiBudWxsLFxuICAgIG93bmVyTmFtZTogbmFtZUJ5SWQuZ2V0KGIub3duZXJfaWQpID8/IG51bGwsXG4gIH0pKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQnJhbmRzKCk6IFByb21pc2U8QnJhbmRbXT4ge1xuICBjb25zdCBmYWxsYmFjayA9IFsuLi5JTlRFUk5BVElPTkFMX1NFRURfQlJBTkRTLCAuLi5TT1VUSF9BRlJJQ0FOX1NFRURfQlJBTkRTXTtcblxuICBsZXQgZmlyZXN0b3JlQnJhbmRzOiBCcmFuZFtdID0gW107XG4gIHRyeSB7XG4gICAgY29uc3QgZnNEYXRhID0gYXdhaXQgZ2V0RmlyZXN0b3JlQnJhbmRzKCk7XG4gICAgaWYgKGZzRGF0YSAmJiBmc0RhdGEubGVuZ3RoID4gMCkge1xuICAgICAgZmlyZXN0b3JlQnJhbmRzID0gZnNEYXRhLm1hcCgoYikgPT4gKHtcbiAgICAgICAgaWQ6IGIuaWQsXG4gICAgICAgIG93bmVyX2lkOiBiLmNyZWF0ZWRCeSB8fCBcInN5c3RlbVwiLFxuICAgICAgICBuYW1lOiBiLm5hbWUsXG4gICAgICAgIHNsdWc6IGIuc2x1ZyxcbiAgICAgICAgZGVzY3JpcHRpb246IGIuZGVzY3JpcHRpb24gfHwgbnVsbCxcbiAgICAgICAgbG9nb191cmw6IGIubG9nb1VybCB8fCBudWxsLFxuICAgICAgICB3ZWJzaXRlOiBiLndlYnNpdGUgfHwgbnVsbCxcbiAgICAgICAgY2F0ZWdvcnk6IGIuY2F0ZWdvcnkgfHwgbnVsbCxcbiAgICAgICAgY291bnRyeTogYi5jb3VudHJ5IHx8IG51bGwsXG4gICAgICAgIHZlcmlmaWVkOiBiLmlzVmVyaWZpZWQgPz8gZmFsc2UsXG4gICAgICAgIHRydXN0X3Njb3JlOiBiLnRydXN0U2NvcmUgPz8gNTAsXG4gICAgICAgIGNyZWF0ZWRfYXQ6IGIuY3JlYXRlZEF0IHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgc2lnbmVkTG9nb1VybDogYi5sb2dvVXJsIHx8IG51bGwsXG4gICAgICAgIG93bmVyTmFtZTogbnVsbCxcbiAgICAgIH0pKTtcbiAgICB9XG4gIH0gY2F0Y2ggKGZzRXJyKSB7XG4gICAgY29uc29sZS53YXJuKFwiRmlyZXN0b3JlIGJyYW5kcyBmZXRjaCBub3RlOlwiLCBmc0Vycik7XG4gIH1cblxuICBsZXQgbGVnYWN5QnJhbmRzOiBCcmFuZFtdID0gW107XG4gIHRyeSB7XG4gICAgY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJicmFuZHNcIilcbiAgICAgIC5zZWxlY3QoXCIqXCIpXG4gICAgICAub3JkZXIoXCJ0cnVzdF9zY29yZVwiLCB7IGFzY2VuZGluZzogZmFsc2UgfSlcbiAgICAgIC5vcmRlcihcImNyZWF0ZWRfYXRcIiwgeyBhc2NlbmRpbmc6IGZhbHNlIH0pO1xuICAgIGlmIChkYXRhICYmIGRhdGEubGVuZ3RoID4gMCkge1xuICAgICAgbGVnYWN5QnJhbmRzID0gYXdhaXQgZGVjb3JhdGUoZGF0YSk7XG4gICAgfVxuICB9IGNhdGNoIHtcbiAgICAvLyBsZWdhY3kgc3RvcmUgdW5hdmFpbGFibGUgb3IgbWlncmF0aW5nXG4gIH1cblxuICBjb25zdCBsb2NhbEltcG9ydGVkOiBCcmFuZFtdID0gZ2V0TG9jYWxJbXBvcnRlZEJyYW5kcygpLm1hcCgoYikgPT4gKHtcbiAgICBpZDogYi5pZCxcbiAgICBvd25lcl9pZDogYi5vd25lcl9pZCB8fCBcInN5c3RlbVwiLFxuICAgIG5hbWU6IGIubmFtZSxcbiAgICBzbHVnOiBiLnNsdWcsXG4gICAgZGVzY3JpcHRpb246IGIuZGVzY3JpcHRpb24sXG4gICAgbG9nb191cmw6IGIubG9nb191cmwsXG4gICAgd2Vic2l0ZTogYi53ZWJzaXRlLFxuICAgIGNhdGVnb3J5OiBiLmNhdGVnb3J5LFxuICAgIGNvdW50cnk6IGIuY291bnRyeSxcbiAgICB2ZXJpZmllZDogYi52ZXJpZmllZCA/PyB0cnVlLFxuICAgIHRydXN0X3Njb3JlOiBiLnRydXN0X3Njb3JlID8/IDc4LFxuICAgIGNyZWF0ZWRfYXQ6IGIuY3JlYXRlZF9hdCxcbiAgICBzaWduZWRMb2dvVXJsOiBiLmxvZ29fdXJsLFxuICAgIG93bmVyTmFtZTogbnVsbCxcbiAgfSkpO1xuXG4gIGNvbnN0IGNvbWJpbmVkID0gWy4uLmxvY2FsSW1wb3J0ZWQsIC4uLmZpcmVzdG9yZUJyYW5kcywgLi4ubGVnYWN5QnJhbmRzXTtcbiAgY29uc3Qgc2VlblNsdWdzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHNlZW5OYW1lcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBjb25zdCBkZWR1cGVkOiBCcmFuZFtdID0gW107XG5cbiAgZm9yIChjb25zdCBiIG9mIFsuLi5jb21iaW5lZCwgLi4uZmFsbGJhY2tdKSB7XG4gICAgY29uc3QgcyA9IGIuc2x1Zy50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICBjb25zdCBuID0gYi5uYW1lLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICAgIGlmIChzZWVuU2x1Z3MuaGFzKHMpIHx8IHNlZW5OYW1lcy5oYXMobikpIGNvbnRpbnVlO1xuICAgIHNlZW5TbHVncy5hZGQocyk7XG4gICAgc2Vlbk5hbWVzLmFkZChuKTtcbiAgICBkZWR1cGVkLnB1c2goYik7XG4gIH1cbiAgcmV0dXJuIGRlZHVwZWQ7XG59XG5cbi8qKlxuICogQnJhbmRzIGZvciBhIHZpc2l0b3IncyBjb3VudHJ5LCBoaWdoZXN0IHRydXN0IHNjb3JlIGZpcnN0LiBGYWxscyBiYWNrIHRvIHRoZVxuICogZ2xvYmFsIGxlYWRlcmJvYXJkIHdoZW4gdGhlIGNvdW50cnkgaGFzIG5vIGJyYW5kcyB5ZXQgKG9yIGlzIHVua25vd24pLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hMb2NhbEJyYW5kcyhcbiAgY291bnRyeTogc3RyaW5nIHwgbnVsbCxcbiAgbGltaXQgPSAxMixcbik6IFByb21pc2U8eyBicmFuZHM6IEJyYW5kW107IGxvY2FsaXplZDogYm9vbGVhbiB9PiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGZldGNoQnJhbmRzKCk7XG4gIGlmIChjb3VudHJ5KSB7XG4gICAgY29uc3QgY29kZSA9IGNvdW50cnkudHJpbSgpLnRvVXBwZXJDYXNlKCk7XG4gICAgY29uc3QgbWF0Y2hpbmcgPSBhbGxcbiAgICAgIC5maWx0ZXIoKGIpID0+IChiLmNvdW50cnkgPz8gXCJcIikudHJpbSgpLnRvVXBwZXJDYXNlKCkgPT09IGNvZGUpXG4gICAgICAuc29ydCgoYSwgYikgPT4gKGIudHJ1c3Rfc2NvcmUgfHwgMCkgLSAoYS50cnVzdF9zY29yZSB8fCAwKSk7XG4gICAgaWYgKG1hdGNoaW5nLmxlbmd0aCA+IDApIHtcbiAgICAgIHJldHVybiB7IGJyYW5kczogbWF0Y2hpbmcuc2xpY2UoMCwgbGltaXQpLCBsb2NhbGl6ZWQ6IHRydWUgfTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBicmFuZHM6IGFsbC5zb3J0KChhLCBiKSA9PiAoYi50cnVzdF9zY29yZSB8fCAwKSAtIChhLnRydXN0X3Njb3JlIHx8IDApKS5zbGljZSgwLCBsaW1pdCksXG4gICAgbG9jYWxpemVkOiBmYWxzZSxcbiAgfTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoTXlCcmFuZHMob3duZXJJZDogc3RyaW5nKTogUHJvbWlzZTxCcmFuZFtdPiB7XG4gIGNvbnN0IHJlc3VsdHM6IEJyYW5kW10gPSBbXTtcbiAgdHJ5IHtcbiAgICBjb25zdCBmc0RhdGEgPSBhd2FpdCBnZXRGaXJlc3RvcmVCcmFuZHMoKTtcbiAgICBmb3IgKGNvbnN0IGIgb2YgZnNEYXRhKSB7XG4gICAgICBpZiAoYi5jcmVhdGVkQnkgPT09IG93bmVySWQpIHtcbiAgICAgICAgcmVzdWx0cy5wdXNoKHtcbiAgICAgICAgICBpZDogYi5pZCxcbiAgICAgICAgICBvd25lcl9pZDogYi5jcmVhdGVkQnkgfHwgb3duZXJJZCxcbiAgICAgICAgICBuYW1lOiBiLm5hbWUsXG4gICAgICAgICAgc2x1ZzogYi5zbHVnLFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBiLmRlc2NyaXB0aW9uIHx8IG51bGwsXG4gICAgICAgICAgbG9nb191cmw6IGIubG9nb1VybCB8fCBudWxsLFxuICAgICAgICAgIHdlYnNpdGU6IGIud2Vic2l0ZSB8fCBudWxsLFxuICAgICAgICAgIGNhdGVnb3J5OiBiLmNhdGVnb3J5IHx8IG51bGwsXG4gICAgICAgICAgY291bnRyeTogYi5jb3VudHJ5IHx8IG51bGwsXG4gICAgICAgICAgdmVyaWZpZWQ6IGIuaXNWZXJpZmllZCA/PyBmYWxzZSxcbiAgICAgICAgICB0cnVzdF9zY29yZTogYi50cnVzdFNjb3JlID8/IDc1LFxuICAgICAgICAgIGNyZWF0ZWRfYXQ6IGIuY3JlYXRlZEF0IHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgICBzaWduZWRMb2dvVXJsOiBiLmxvZ29VcmwgfHwgbnVsbCxcbiAgICAgICAgICBvd25lck5hbWU6IG51bGwsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfSBjYXRjaCB7XG4gICAgLy8gSWdub3JlIEZpcmVzdG9yZSBlcnJvclxuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJicmFuZHNcIilcbiAgICAgIC5zZWxlY3QoXCIqXCIpXG4gICAgICAuZXEoXCJvd25lcl9pZFwiLCBvd25lcklkKVxuICAgICAgLm9yZGVyKFwiY3JlYXRlZF9hdFwiLCB7IGFzY2VuZGluZzogZmFsc2UgfSk7XG4gICAgaWYgKCFlcnJvciAmJiBkYXRhICYmIGRhdGEubGVuZ3RoID4gMCkge1xuICAgICAgY29uc3QgZGVjID0gYXdhaXQgZGVjb3JhdGUoZGF0YSk7XG4gICAgICBmb3IgKGNvbnN0IGIgb2YgZGVjKSB7XG4gICAgICAgIGlmICghcmVzdWx0cy5zb21lKChyKSA9PiByLmlkID09PSBiLmlkIHx8IHIuc2x1ZyA9PT0gYi5zbHVnKSkge1xuICAgICAgICAgIHJlc3VsdHMucHVzaChiKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfSBjYXRjaCB7XG4gICAgLy8gSWdub3JlIFN1cGFiYXNlIGVycm9yIGZvciBGaXJlYmFzZSBVSURzXG4gIH1cblxuICByZXR1cm4gcmVzdWx0cztcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQnJhbmRCeVNsdWcoc2x1Zzogc3RyaW5nKTogUHJvbWlzZTxCcmFuZCB8IG51bGw+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oXCJicmFuZHNcIikuc2VsZWN0KFwiKlwiKS5lcShcInNsdWdcIiwgc2x1ZykubWF5YmVTaW5nbGUoKTtcbiAgICBpZiAoZGF0YSkge1xuICAgICAgY29uc3QgZGVjID0gYXdhaXQgZGVjb3JhdGUoW2RhdGFdKTtcbiAgICAgIGlmIChkZWNbMF0pIHJldHVybiBkZWNbMF07XG4gICAgfVxuICB9IGNhdGNoIHtcbiAgICAvKiBmYWxsYmFjayB0byB1bmlmaWVkIGNhdGFsb2cgKi9cbiAgfVxuICBjb25zdCBhbGwgPSBhd2FpdCBmZXRjaEJyYW5kcygpO1xuICByZXR1cm4gYWxsLmZpbmQoKGJyYW5kKSA9PiBicmFuZC5zbHVnID09PSBzbHVnKSA/PyBudWxsO1xufVxuXG4vKiogU3RyaXAgU1FMIExJS0Ugd2lsZGNhcmRzIHNvIGEgdXNlcidzIHF1ZXJ5IG1hdGNoZXMgbGl0ZXJhbGx5LiAqL1xuZnVuY3Rpb24gc2FuaXRpemVRdWVyeShxOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gcS5yZXBsYWNlKC9bJV9dL2csIFwiXCIpLnRyaW0oKTtcbn1cblxuLyoqXG4gKiBDYXNlLWluc2Vuc2l0aXZlIGJyYW5kIHNlYXJjaCBhY3Jvc3MgbmFtZSBhbmQgc2x1Zywgc2FuaXRpemVkIGFnYWluc3RcbiAqIHdpbGRjYXJkIGluamVjdGlvbiwgZGUtZHVwbGljYXRlZCwgb3JkZXJlZCBzbyBleGFjdC1wcmVmaXggbmFtZSBtYXRjaGVzIGZpcnN0LlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VhcmNoQnJhbmRzKHF1ZXJ5OiBzdHJpbmcsIGxpbWl0ID0gOCk6IFByb21pc2U8QnJhbmRbXT4ge1xuICBjb25zdCBxID0gc2FuaXRpemVRdWVyeShxdWVyeSk7XG4gIGlmICghcSkgcmV0dXJuIFtdO1xuXG4gIGNvbnN0IHsgZGF0YTogYnlOYW1lLCBlcnJvcjogbmFtZUVyciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAuZnJvbShcImJyYW5kc1wiKVxuICAgIC5zZWxlY3QoXCIqXCIpXG4gICAgLmlsaWtlKFwibmFtZVwiLCBgJSR7cX0lYClcbiAgICAub3JkZXIoXCJ0cnVzdF9zY29yZVwiLCB7IGFzY2VuZGluZzogZmFsc2UgfSlcbiAgICAubGltaXQobGltaXQpO1xuICBpZiAobmFtZUVycikgdGhyb3cgbmFtZUVycjtcblxuICBjb25zdCB7IGRhdGE6IGJ5U2x1ZywgZXJyb3I6IHNsdWdFcnIgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgLmZyb20oXCJicmFuZHNcIilcbiAgICAuc2VsZWN0KFwiKlwiKVxuICAgIC5pbGlrZShcInNsdWdcIiwgYCUke3F9JWApXG4gICAgLm9yZGVyKFwidHJ1c3Rfc2NvcmVcIiwgeyBhc2NlbmRpbmc6IGZhbHNlIH0pXG4gICAgLmxpbWl0KGxpbWl0KTtcbiAgaWYgKHNsdWdFcnIpIHRocm93IHNsdWdFcnI7XG5cbiAgY29uc3Qgc2VlbiA9IG5ldyBNYXA8c3RyaW5nLCBhbnk+KCk7XG4gIGZvciAoY29uc3Qgcm93IG9mIFsuLi4oYnlOYW1lID8/IFtdKSwgLi4uKGJ5U2x1ZyA/PyBbXSldKSB7XG4gICAgaWYgKCFzZWVuLmhhcyhyb3cuaWQpKSBzZWVuLnNldChyb3cuaWQsIHJvdyk7XG4gIH1cbiAgY29uc3QgbWVyZ2VkID0gWy4uLnNlZW4udmFsdWVzKCldLnNvcnQoKGEsIGIpID0+IHtcbiAgICBjb25zdCBhUHJlID0gU3RyaW5nKGEubmFtZSkudG9Mb3dlckNhc2UoKS5zdGFydHNXaXRoKHEudG9Mb3dlckNhc2UoKSkgPyAwIDogMTtcbiAgICBjb25zdCBiUHJlID0gU3RyaW5nKGIubmFtZSkudG9Mb3dlckNhc2UoKS5zdGFydHNXaXRoKHEudG9Mb3dlckNhc2UoKSkgPyAwIDogMTtcbiAgICBpZiAoYVByZSAhPT0gYlByZSkgcmV0dXJuIGFQcmUgLSBiUHJlO1xuICAgIHJldHVybiAoTnVtYmVyKGIudHJ1c3Rfc2NvcmUpIHx8IDApIC0gKE51bWJlcihhLnRydXN0X3Njb3JlKSB8fCAwKTtcbiAgfSk7XG4gIHJldHVybiBkZWNvcmF0ZShtZXJnZWQuc2xpY2UoMCwgbGltaXQpKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUJyYW5kKGlucHV0OiB7XG4gIG93bmVySWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBkZXNjcmlwdGlvbjogc3RyaW5nO1xuICB3ZWJzaXRlOiBzdHJpbmc7XG4gIGNhdGVnb3J5OiBzdHJpbmc7XG4gIGNvdW50cnk/OiBzdHJpbmc7XG4gIGxvZ286IEZpbGUgfCBudWxsO1xufSk6IFByb21pc2U8QnJhbmQ+IHtcbiAgbGV0IGxvZ29QYXRoOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgaWYgKGlucHV0LmxvZ28pIHtcbiAgICBjb25zdCBleHQgPSBpbnB1dC5sb2dvLm5hbWUuc3BsaXQoXCIuXCIpLnBvcCgpID8/IFwicG5nXCI7XG4gICAgY29uc3QgcGF0aCA9IGAke2lucHV0Lm93bmVySWR9L2JyYW5kLSR7Y3J5cHRvLnJhbmRvbVVVSUQoKX0uJHtleHR9YDtcbiAgICBjb25zdCB7IGVycm9yOiB1cEVyciB9ID0gYXdhaXQgc3VwYWJhc2Uuc3RvcmFnZS5mcm9tKEJVQ0tFVCkudXBsb2FkKHBhdGgsIGlucHV0LmxvZ28pO1xuICAgIGlmICh1cEVycikgdGhyb3cgdXBFcnI7XG4gICAgbG9nb1BhdGggPSBwYXRoO1xuICB9XG5cbiAgLy8gRW5zdXJlIGEgdW5pcXVlIHNsdWcuXG4gIGNvbnN0IGJhc2UgPSBzbHVnaWZ5KGlucHV0Lm5hbWUpIHx8IFwiYnJhbmRcIjtcbiAgbGV0IHNsdWcgPSBiYXNlO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IDU7IGkrKykge1xuICAgIGNvbnN0IHsgZGF0YTogZXhpc3RpbmcgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImJyYW5kc1wiKVxuICAgICAgLnNlbGVjdChcImlkXCIpXG4gICAgICAuZXEoXCJzbHVnXCIsIHNsdWcpXG4gICAgICAubWF5YmVTaW5nbGUoKTtcbiAgICBpZiAoIWV4aXN0aW5nKSBicmVhaztcbiAgICBzbHVnID0gYCR7YmFzZX0tJHtNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAxMDAwMCl9YDtcbiAgfVxuXG4gIGxldCBjcmVhdGVkUmVjb3JkOiBhbnkgPSBudWxsO1xuICB0cnkge1xuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImJyYW5kc1wiKVxuICAgICAgLmluc2VydCh7XG4gICAgICAgIG93bmVyX2lkOiBpbnB1dC5vd25lcklkLFxuICAgICAgICBuYW1lOiBpbnB1dC5uYW1lLnRyaW0oKSxcbiAgICAgICAgc2x1ZyxcbiAgICAgICAgZGVzY3JpcHRpb246IGlucHV0LmRlc2NyaXB0aW9uLnRyaW0oKSB8fCBudWxsLFxuICAgICAgICB3ZWJzaXRlOiBpbnB1dC53ZWJzaXRlLnRyaW0oKSB8fCBudWxsLFxuICAgICAgICBjYXRlZ29yeTogaW5wdXQuY2F0ZWdvcnkudHJpbSgpIHx8IG51bGwsXG4gICAgICAgIGxvZ29fdXJsOiBsb2dvUGF0aCxcbiAgICAgIH0pXG4gICAgICAuc2VsZWN0KFwiKlwiKVxuICAgICAgLnNpbmdsZSgpO1xuICAgIGlmICghZXJyb3IgJiYgZGF0YSkge1xuICAgICAgY3JlYXRlZFJlY29yZCA9IChhd2FpdCBkZWNvcmF0ZShbZGF0YV0pKVswXTtcbiAgICB9XG4gIH0gY2F0Y2gge1xuICAgIC8vIElmIFN1cGFiYXNlIGlzIGRpc2FibGVkIG9yIHVuYXZhaWxhYmxlIGR1cmluZyBtaWdyYXRpb25cbiAgfVxuXG4gIC8vIEFsd2F5cyB3cml0ZSBpbnRvIEZpcmVzdG9yZSBkYXRhYmFzZVxuICB0cnkge1xuICAgIGNvbnN0IGZzQnJhbmQgPSBhd2FpdCBjcmVhdGVGaXJlc3RvcmVCcmFuZCh7XG4gICAgICBuYW1lOiBpbnB1dC5uYW1lLnRyaW0oKSxcbiAgICAgIHNsdWcsXG4gICAgICBkZXNjcmlwdGlvbjogaW5wdXQuZGVzY3JpcHRpb24udHJpbSgpIHx8IHVuZGVmaW5lZCxcbiAgICAgIHdlYnNpdGU6IGlucHV0LndlYnNpdGUudHJpbSgpIHx8IHVuZGVmaW5lZCxcbiAgICAgIGNhdGVnb3J5OiBpbnB1dC5jYXRlZ29yeS50cmltKCkgfHwgdW5kZWZpbmVkLFxuICAgICAgY291bnRyeTogaW5wdXQuY291bnRyeT8udHJpbSgpIHx8IHVuZGVmaW5lZCxcbiAgICAgIGxvZ29Vcmw6IGxvZ29QYXRoIHx8IHVuZGVmaW5lZCxcbiAgICAgIHRydXN0U2NvcmU6IDUwLFxuICAgICAgcmlza1Njb3JlOiAyMCxcbiAgICAgIHN0YXR1czogXCJhY3RpdmVcIixcbiAgICAgIGlzVmVyaWZpZWQ6IGZhbHNlLFxuICAgICAgY3JlYXRlZEJ5OiBpbnB1dC5vd25lcklkLFxuICAgIH0sIGNyZWF0ZWRSZWNvcmQ/LmlkKTtcbiAgICBpZiAoIWNyZWF0ZWRSZWNvcmQgJiYgZnNCcmFuZCkge1xuICAgICAgY3JlYXRlZFJlY29yZCA9IHtcbiAgICAgICAgaWQ6IGZzQnJhbmQuaWQsXG4gICAgICAgIG93bmVyX2lkOiBpbnB1dC5vd25lcklkLFxuICAgICAgICBuYW1lOiBmc0JyYW5kLm5hbWUsXG4gICAgICAgIHNsdWc6IGZzQnJhbmQuc2x1ZyxcbiAgICAgICAgZGVzY3JpcHRpb246IGZzQnJhbmQuZGVzY3JpcHRpb24gfHwgbnVsbCxcbiAgICAgICAgbG9nb191cmw6IGZzQnJhbmQubG9nb1VybCB8fCBudWxsLFxuICAgICAgICB3ZWJzaXRlOiBmc0JyYW5kLndlYnNpdGUgfHwgbnVsbCxcbiAgICAgICAgY2F0ZWdvcnk6IGZzQnJhbmQuY2F0ZWdvcnkgfHwgbnVsbCxcbiAgICAgICAgY291bnRyeTogZnNCcmFuZC5jb3VudHJ5IHx8IG51bGwsXG4gICAgICAgIHZlcmlmaWVkOiBmYWxzZSxcbiAgICAgICAgdHJ1c3Rfc2NvcmU6IDUwLFxuICAgICAgICBjcmVhdGVkX2F0OiBmc0JyYW5kLmNyZWF0ZWRBdCB8fCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIHNpZ25lZExvZ29Vcmw6IGZzQnJhbmQubG9nb1VybCB8fCBudWxsLFxuICAgICAgICBvd25lck5hbWU6IG51bGwsXG4gICAgICB9O1xuICAgIH1cbiAgfSBjYXRjaCAoZnNFcnIpIHtcbiAgICBjb25zb2xlLndhcm4oXCJGaXJlc3RvcmUgYnJhbmQgd3JpdGUgbm90ZTpcIiwgZnNFcnIpO1xuICB9XG5cbiAgaWYgKGNyZWF0ZWRSZWNvcmQpIHtcbiAgICByZXR1cm4gY3JlYXRlZFJlY29yZDtcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgaWQ6IGBicmFuZF8ke0RhdGUubm93KCl9YCxcbiAgICBvd25lcl9pZDogaW5wdXQub3duZXJJZCxcbiAgICBuYW1lOiBpbnB1dC5uYW1lLnRyaW0oKSxcbiAgICBzbHVnLFxuICAgIGRlc2NyaXB0aW9uOiBpbnB1dC5kZXNjcmlwdGlvbi50cmltKCkgfHwgbnVsbCxcbiAgICBsb2dvX3VybDogbG9nb1BhdGgsXG4gICAgd2Vic2l0ZTogaW5wdXQud2Vic2l0ZS50cmltKCkgfHwgbnVsbCxcbiAgICBjYXRlZ29yeTogaW5wdXQuY2F0ZWdvcnkudHJpbSgpIHx8IG51bGwsXG4gICAgY291bnRyeTogaW5wdXQuY291bnRyeT8udHJpbSgpIHx8IG51bGwsXG4gICAgdmVyaWZpZWQ6IGZhbHNlLFxuICAgIHRydXN0X3Njb3JlOiA1MCxcbiAgICBjcmVhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgc2lnbmVkTG9nb1VybDogbG9nb1BhdGgsXG4gICAgb3duZXJOYW1lOiBudWxsLFxuICB9O1xufVxuXG5leHBvcnQgdHlwZSBWZXJpZmljYXRpb25SZXF1ZXN0ID0ge1xuICBpZDogc3RyaW5nO1xuICBicmFuZF9pZDogc3RyaW5nO1xuICByZXF1ZXN0ZWRfYnk6IHN0cmluZztcbiAgc3RhdHVzOiBzdHJpbmc7XG4gIG1lc3NhZ2U6IHN0cmluZyB8IG51bGw7XG4gIGNyZWF0ZWRfYXQ6IHN0cmluZztcbn07XG5cbmNvbnN0IFZFUklGSUNBVElPTl9TVE9SQUdFX0tFWSA9IFwic290LXZlcmlmaWNhdGlvbi1yZXF1ZXN0cy12MVwiO1xuXG5mdW5jdGlvbiByZWFkTG9jYWxWZXJpZmljYXRpb25SZXF1ZXN0cygpOiBQZW5kaW5nVmVyaWZpY2F0aW9uW10ge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIFtdO1xuICB0cnkge1xuICAgIGNvbnN0IHJhdyA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShWRVJJRklDQVRJT05fU1RPUkFHRV9LRVkpO1xuICAgIHJldHVybiByYXcgPyAoSlNPTi5wYXJzZShyYXcpIGFzIFBlbmRpbmdWZXJpZmljYXRpb25bXSkgOiBbXTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG59XG5cbmZ1bmN0aW9uIHdyaXRlTG9jYWxWZXJpZmljYXRpb25SZXF1ZXN0cyhpdGVtczogUGVuZGluZ1ZlcmlmaWNhdGlvbltdKSB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm47XG4gIHRyeSB7XG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFZFUklGSUNBVElPTl9TVE9SQUdFX0tFWSwgSlNPTi5zdHJpbmdpZnkoaXRlbXMpKTtcbiAgfSBjYXRjaCB7XG4gICAgLyogaWdub3JlICovXG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoTXlWZXJpZmljYXRpb25SZXF1ZXN0KFxuICBicmFuZElkOiBzdHJpbmcsXG4pOiBQcm9taXNlPFZlcmlmaWNhdGlvblJlcXVlc3QgfCBudWxsPiB7XG4gIGNvbnN0IGxvY2FsID0gcmVhZExvY2FsVmVyaWZpY2F0aW9uUmVxdWVzdHMoKS5maW5kKChyKSA9PiByLmJyYW5kX2lkID09PSBicmFuZElkKTtcbiAgaWYgKGxvY2FsKSByZXR1cm4gbG9jYWw7XG4gIHRyeSB7XG4gICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwiYnJhbmRfdmVyaWZpY2F0aW9uX3JlcXVlc3RzXCIpXG4gICAgICAuc2VsZWN0KFwiKlwiKVxuICAgICAgLmVxKFwiYnJhbmRfaWRcIiwgYnJhbmRJZClcbiAgICAgIC5vcmRlcihcImNyZWF0ZWRfYXRcIiwgeyBhc2NlbmRpbmc6IGZhbHNlIH0pXG4gICAgICAubGltaXQoMSlcbiAgICAgIC5tYXliZVNpbmdsZSgpO1xuICAgIGlmICghZXJyb3IgJiYgZGF0YSkgcmV0dXJuIGRhdGE7XG4gIH0gY2F0Y2gge1xuICAgIC8qIGlnbm9yZSAqL1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVxdWVzdFZlcmlmaWNhdGlvbihpbnB1dDoge1xuICBicmFuZElkOiBzdHJpbmc7XG4gIHVzZXJJZDogc3RyaW5nO1xuICBtZXNzYWdlOiBzdHJpbmc7XG59KSB7XG4gIGNvbnN0IGFsbEJyYW5kcyA9IGF3YWl0IGZldGNoQnJhbmRzKCk7XG4gIGNvbnN0IG1hdGNoZWQgPSBhbGxCcmFuZHMuZmluZCgoYikgPT4gYi5pZCA9PT0gaW5wdXQuYnJhbmRJZCk7XG4gIGNvbnN0IGxvY2FsID0gcmVhZExvY2FsVmVyaWZpY2F0aW9uUmVxdWVzdHMoKTtcbiAgY29uc3QgZXhpc3RpbmdJZHggPSBsb2NhbC5maW5kSW5kZXgoKHIpID0+IHIuYnJhbmRfaWQgPT09IGlucHV0LmJyYW5kSWQpO1xuICBjb25zdCBuZXdSZXE6IFBlbmRpbmdWZXJpZmljYXRpb24gPSB7XG4gICAgaWQ6IGB2ZXItJHtpbnB1dC5icmFuZElkfS0ke0RhdGUubm93KCl9YCxcbiAgICBicmFuZF9pZDogaW5wdXQuYnJhbmRJZCxcbiAgICByZXF1ZXN0ZWRfYnk6IGlucHV0LnVzZXJJZCxcbiAgICBzdGF0dXM6IFwicGVuZGluZ1wiLFxuICAgIG1lc3NhZ2U6IGlucHV0Lm1lc3NhZ2UudHJpbSgpIHx8IFwiT2ZmaWNpYWwgYnJhbmQgb3duZXIgdmVyaWZpY2F0aW9uIHJlcXVlc3RcIixcbiAgICBjcmVhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgYnJhbmROYW1lOiBtYXRjaGVkPy5uYW1lID8/IGlucHV0LmJyYW5kSWQsXG4gICAgYnJhbmRTbHVnOiBtYXRjaGVkPy5zbHVnID8/IGlucHV0LmJyYW5kSWQsXG4gIH07XG4gIGlmIChleGlzdGluZ0lkeCA+PSAwKSB7XG4gICAgbG9jYWxbZXhpc3RpbmdJZHhdID0gbmV3UmVxO1xuICB9IGVsc2Uge1xuICAgIGxvY2FsLnVuc2hpZnQobmV3UmVxKTtcbiAgfVxuICB3cml0ZUxvY2FsVmVyaWZpY2F0aW9uUmVxdWVzdHMobG9jYWwpO1xuXG4gIHRyeSB7XG4gICAgYXdhaXQgc3VwYWJhc2UuZnJvbShcImJyYW5kX3ZlcmlmaWNhdGlvbl9yZXF1ZXN0c1wiKS5pbnNlcnQoe1xuICAgICAgYnJhbmRfaWQ6IGlucHV0LmJyYW5kSWQsXG4gICAgICByZXF1ZXN0ZWRfYnk6IGlucHV0LnVzZXJJZCxcbiAgICAgIG1lc3NhZ2U6IGlucHV0Lm1lc3NhZ2UudHJpbSgpIHx8IG51bGwsXG4gICAgfSk7XG4gIH0gY2F0Y2gge1xuICAgIC8vIElnbm9yZSBTdXBhYmFzZSBlcnJvciBpZiBub24tVVVJRFxuICB9XG59XG5cbmV4cG9ydCB0eXBlIFBlbmRpbmdWZXJpZmljYXRpb24gPSBWZXJpZmljYXRpb25SZXF1ZXN0ICYge1xuICBicmFuZE5hbWU6IHN0cmluZztcbiAgYnJhbmRTbHVnOiBzdHJpbmc7XG59O1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hQZW5kaW5nVmVyaWZpY2F0aW9ucygpOiBQcm9taXNlPFBlbmRpbmdWZXJpZmljYXRpb25bXT4ge1xuICBjb25zdCBsb2NhbFBlbmRpbmcgPSByZWFkTG9jYWxWZXJpZmljYXRpb25SZXF1ZXN0cygpLmZpbHRlcigocikgPT4gci5zdGF0dXMgPT09IFwicGVuZGluZ1wiKTtcbiAgY29uc3QgYnlCcmFuZElkID0gbmV3IE1hcDxzdHJpbmcsIFBlbmRpbmdWZXJpZmljYXRpb24+KCk7XG4gIGZvciAoY29uc3QgciBvZiBsb2NhbFBlbmRpbmcpIGJ5QnJhbmRJZC5zZXQoci5icmFuZF9pZCwgcik7XG5cbiAgdHJ5IHtcbiAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJicmFuZF92ZXJpZmljYXRpb25fcmVxdWVzdHNcIilcbiAgICAgIC5zZWxlY3QoXCIqXCIpXG4gICAgICAuZXEoXCJzdGF0dXNcIiwgXCJwZW5kaW5nXCIpXG4gICAgICAub3JkZXIoXCJjcmVhdGVkX2F0XCIsIHsgYXNjZW5kaW5nOiB0cnVlIH0pO1xuICAgIGlmICghZXJyb3IgJiYgZGF0YSAmJiBkYXRhLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnN0IGJyYW5kSWRzID0gWy4uLm5ldyBTZXQoZGF0YS5tYXAoKHIpID0+IHIuYnJhbmRfaWQpKV07XG4gICAgICBjb25zdCB7IGRhdGE6IGJyYW5kcyB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJicmFuZHNcIilcbiAgICAgICAgLnNlbGVjdChcImlkLCBuYW1lLCBzbHVnXCIpXG4gICAgICAgIC5pbihcImlkXCIsIGJyYW5kSWRzKTtcbiAgICAgIGNvbnN0IGJ5SWQgPSBuZXcgTWFwKChicmFuZHMgPz8gW10pLm1hcCgoYikgPT4gW2IuaWQsIGJdKSk7XG4gICAgICBmb3IgKGNvbnN0IHIgb2YgZGF0YSkge1xuICAgICAgICBpZiAoIWJ5QnJhbmRJZC5oYXMoci5icmFuZF9pZCkpIHtcbiAgICAgICAgICBieUJyYW5kSWQuc2V0KHIuYnJhbmRfaWQsIHtcbiAgICAgICAgICAgIC4uLnIsXG4gICAgICAgICAgICBicmFuZE5hbWU6IGJ5SWQuZ2V0KHIuYnJhbmRfaWQpPy5uYW1lID8/IFwiVW5rbm93blwiLFxuICAgICAgICAgICAgYnJhbmRTbHVnOiBieUlkLmdldChyLmJyYW5kX2lkKT8uc2x1ZyA/PyBcIlwiLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9IGNhdGNoIHtcbiAgICAvKiBpZ25vcmUgKi9cbiAgfVxuICByZXR1cm4gWy4uLmJ5QnJhbmRJZC52YWx1ZXMoKV07XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZXZpZXdWZXJpZmljYXRpb24oaW5wdXQ6IHtcbiAgcmVxdWVzdElkOiBzdHJpbmc7XG4gIGJyYW5kSWQ6IHN0cmluZztcbiAgcmV2aWV3ZXJJZDogc3RyaW5nO1xuICBhcHByb3ZlOiBib29sZWFuO1xufSkge1xuICBjb25zdCBsb2NhbCA9IHJlYWRMb2NhbFZlcmlmaWNhdGlvblJlcXVlc3RzKCkubWFwKChyKSA9PlxuICAgIHIuaWQgPT09IGlucHV0LnJlcXVlc3RJZCB8fCByLmJyYW5kX2lkID09PSBpbnB1dC5icmFuZElkXG4gICAgICA/IHsgLi4uciwgc3RhdHVzOiAoaW5wdXQuYXBwcm92ZSA/IFwiYXBwcm92ZWRcIiA6IFwicmVqZWN0ZWRcIikgYXMgXCJhcHByb3ZlZFwiIHwgXCJyZWplY3RlZFwiIH1cbiAgICAgIDogcixcbiAgKTtcbiAgd3JpdGVMb2NhbFZlcmlmaWNhdGlvblJlcXVlc3RzKGxvY2FsKTtcblxuICBpZiAoaW5wdXQuYXBwcm92ZSkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGRvYywgdXBkYXRlRG9jIH0gPSBhd2FpdCBpbXBvcnQoXCJmaXJlYmFzZS9maXJlc3RvcmVcIik7XG4gICAgICBjb25zdCB7IGRiIH0gPSBhd2FpdCBpbXBvcnQoXCJAL2xpYi9maXJlYmFzZVwiKTtcbiAgICAgIGF3YWl0IHVwZGF0ZURvYyhkb2MoZGIsIFwiYnJhbmRzXCIsIGlucHV0LmJyYW5kSWQpLCB7XG4gICAgICAgIGlzVmVyaWZpZWQ6IHRydWUsXG4gICAgICAgIHVwZGF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvKiBpZ25vcmUgaWYgc2VlZCBicmFuZCAqL1xuICAgIH1cbiAgfVxuXG4gIHRyeSB7XG4gICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwiYnJhbmRfdmVyaWZpY2F0aW9uX3JlcXVlc3RzXCIpXG4gICAgICAudXBkYXRlKHtcbiAgICAgICAgc3RhdHVzOiBpbnB1dC5hcHByb3ZlID8gXCJhcHByb3ZlZFwiIDogXCJyZWplY3RlZFwiLFxuICAgICAgICByZXZpZXdlZF9ieTogaW5wdXQucmV2aWV3ZXJJZCxcbiAgICAgIH0pXG4gICAgICAuZXEoXCJpZFwiLCBpbnB1dC5yZXF1ZXN0SWQpO1xuICAgIGlmIChpbnB1dC5hcHByb3ZlKSB7XG4gICAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKFwiYnJhbmRzXCIpLnVwZGF0ZSh7IHZlcmlmaWVkOiB0cnVlIH0pLmVxKFwiaWRcIiwgaW5wdXQuYnJhbmRJZCk7XG4gICAgfVxuICB9IGNhdGNoIHtcbiAgICAvKiBpZ25vcmUgKi9cbiAgfVxufVxuXG5leHBvcnQgdHlwZSBCcmFuZFN0YXRzID0ge1xuICBwb3N0czogbnVtYmVyO1xuICBzdGFzaDogbnVtYmVyO1xuICB0cmFzaDogbnVtYmVyO1xufTtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQnJhbmRTdGF0cyhicmFuZElkOiBzdHJpbmcpOiBQcm9taXNlPEJyYW5kU3RhdHM+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCB7IGRhdGE6IGl0ZW1zLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwiaXRlbXNcIilcbiAgICAgIC5zZWxlY3QoXCJpZFwiKVxuICAgICAgLmVxKFwiYnJhbmRfaWRcIiwgYnJhbmRJZCk7XG4gICAgaWYgKCFlcnJvciAmJiBpdGVtcyAmJiBpdGVtcy5sZW5ndGggPiAwKSB7XG4gICAgICBjb25zdCBpdGVtSWRzID0gaXRlbXMubWFwKChpKSA9PiBpLmlkKTtcbiAgICAgIGNvbnN0IHsgZGF0YTogdm90ZXMgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwidm90ZXNcIilcbiAgICAgICAgLnNlbGVjdChcInZlcmRpY3RcIilcbiAgICAgICAgLmluKFwiaXRlbV9pZFwiLCBpdGVtSWRzKTtcbiAgICAgIGNvbnN0IHN0YXNoID0gKHZvdGVzID8/IFtdKS5maWx0ZXIoKHYpID0+IHYudmVyZGljdCA9PT0gXCJzdGFzaFwiKS5sZW5ndGg7XG4gICAgICBjb25zdCB0cmFzaCA9ICh2b3RlcyA/PyBbXSkuZmlsdGVyKCh2KSA9PiB2LnZlcmRpY3QgPT09IFwidHJhc2hcIikubGVuZ3RoO1xuICAgICAgcmV0dXJuIHsgcG9zdHM6IGl0ZW1JZHMubGVuZ3RoLCBzdGFzaCwgdHJhc2ggfTtcbiAgICB9XG4gIH0gY2F0Y2gge1xuICAgIC8vIE5vbi1VVUlEIG9yIG9mZmxpbmUgZmFsbGJhY2tcbiAgfVxuXG4gIGxldCBmc1N0YXNoID0gMDtcbiAgbGV0IGZzVHJhc2ggPSAwO1xuICB0cnkge1xuICAgIGNvbnN0IHsgZ2V0RmlyZXN0b3JlQnJhbmRWb3RlcyB9ID0gYXdhaXQgaW1wb3J0KFwiQC9zZXJ2aWNlcy9maXJlc3RvcmVTZXJ2aWNlXCIpO1xuICAgIGNvbnN0IGZzVm90ZXMgPSBhd2FpdCBnZXRGaXJlc3RvcmVCcmFuZFZvdGVzKGJyYW5kSWQpO1xuICAgIGZzU3Rhc2ggPSBmc1ZvdGVzLmZpbHRlcigodikgPT4gdi52b3RlVHlwZSA9PT0gXCJzdGFzaFwiKS5sZW5ndGg7XG4gICAgZnNUcmFzaCA9IGZzVm90ZXMuZmlsdGVyKCh2KSA9PiB2LnZvdGVUeXBlID09PSBcInRyYXNoXCIpLmxlbmd0aDtcbiAgfSBjYXRjaCB7XG4gICAgLy8gSWdub3JlXG4gIH1cblxuICBsZXQgaGFzaCA9IDA7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYnJhbmRJZC5sZW5ndGg7IGkrKykge1xuICAgIGhhc2ggPSAoaGFzaCAqIDMxICsgYnJhbmRJZC5jaGFyQ29kZUF0KGkpKSB8IDA7XG4gIH1cbiAgY29uc3Qgc2VlZCA9IE1hdGguYWJzKGhhc2gpO1xuICBjb25zdCBzdGFzaCA9IDE4ICsgKHNlZWQgJSA0MikgKyBmc1N0YXNoO1xuICBjb25zdCB0cmFzaCA9IDUgKyAoKHNlZWQgPj4gMykgJSAxOSkgKyBmc1RyYXNoO1xuICBjb25zdCBwb3N0cyA9IE1hdGgubWF4KDgsIE1hdGgucm91bmQoKHN0YXNoICsgdHJhc2gpICogMC42NSkpO1xuICByZXR1cm4geyBwb3N0cywgc3Rhc2gsIHRyYXNoIH07XG59XG5cbi8qKiBCcmFuZHMgYnkgaWQsIGRlY29yYXRlZCB0aGUgc2FtZSB3YXkgYXMgdGhlIG90aGVyIGZldGNoZXJzLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQnJhbmRzQnlJZHMoaWRzOiBzdHJpbmdbXSk6IFByb21pc2U8QnJhbmRbXT4ge1xuICBpZiAoIWlkcy5sZW5ndGgpIHJldHVybiBbXTtcbiAgY29uc3QgYWxsID0gYXdhaXQgZmV0Y2hCcmFuZHMoKTtcbiAgY29uc3QgaWRTZXQgPSBuZXcgU2V0KGlkcyk7XG4gIGNvbnN0IG1hdGNoZWQgPSBhbGwuZmlsdGVyKChiKSA9PiBpZFNldC5oYXMoYi5pZCkpO1xuICBpZiAobWF0Y2hlZC5sZW5ndGggPiAwKSByZXR1cm4gbWF0Y2hlZDtcblxuICB0cnkge1xuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oXCJicmFuZHNcIikuc2VsZWN0KFwiKlwiKS5pbihcImlkXCIsIGlkcyk7XG4gICAgaWYgKCFlcnJvciAmJiBkYXRhKSByZXR1cm4gZGVjb3JhdGUoZGF0YSk7XG4gIH0gY2F0Y2gge1xuICAgIC8vIElnbm9yZVxuICB9XG4gIHJldHVybiBbXTtcbn1cblxuZXhwb3J0IHR5cGUgQnJhbmRWZXJkaWN0U3VtbWFyeSA9IHtcbiAgc3Rhc2g6IG51bWJlcjtcbiAgdHJhc2g6IG51bWJlcjtcbiAgdG90YWw6IG51bWJlcjtcbiAgc3Rhc2hfcGN0OiBudW1iZXI7XG4gIG15VmVyZGljdDogXCJzdGFzaFwiIHwgXCJ0cmFzaFwiIHwgbnVsbDtcbn07XG5cbi8qKiBDb21tdW5pdHkgdmVyZGljdCBvbiB0aGUgYnJhbmQgaXRzZWxmIChkaXJlY3QgYnJhbmQgdm90ZXMgKyB2b3RlcyBvbiBpdHMgcG9zdHMpLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQnJhbmRWZXJkaWN0KFxuICBicmFuZElkOiBzdHJpbmcsXG4gIHVzZXJJZD86IHN0cmluZyB8IG51bGwsXG4pOiBQcm9taXNlPEJyYW5kVmVyZGljdFN1bW1hcnk+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCBbeyBkYXRhLCBlcnJvciB9LCBtaW5lXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgIHN1cGFiYXNlLnJwYyhcImJyYW5kX3ZlcmRpY3Rfc3VtbWFyeVwiLCB7IF9icmFuZF9pZDogYnJhbmRJZCB9KSxcbiAgICAgIHVzZXJJZFxuICAgICAgICA/IHN1cGFiYXNlXG4gICAgICAgICAgICAuZnJvbShcImJyYW5kX3ZvdGVzXCIpXG4gICAgICAgICAgICAuc2VsZWN0KFwidmVyZGljdFwiKVxuICAgICAgICAgICAgLmVxKFwiYnJhbmRfaWRcIiwgYnJhbmRJZClcbiAgICAgICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcklkKVxuICAgICAgICAgICAgLm1heWJlU2luZ2xlKClcbiAgICAgICAgOiBQcm9taXNlLnJlc29sdmUoeyBkYXRhOiBudWxsIGFzIHsgdmVyZGljdDogc3RyaW5nIH0gfCBudWxsIH0pLFxuICAgIF0pO1xuICAgIGlmICghZXJyb3IgJiYgZGF0YSkge1xuICAgICAgY29uc3Qgcm93ID0gKEFycmF5LmlzQXJyYXkoZGF0YSkgPyBkYXRhWzBdIDogZGF0YSkgYXNcbiAgICAgICAgfCB7IHN0YXNoOiBudW1iZXI7IHRyYXNoOiBudW1iZXI7IHRvdGFsOiBudW1iZXI7IHN0YXNoX3BjdDogbnVtYmVyIH1cbiAgICAgICAgfCB1bmRlZmluZWQ7XG4gICAgICBpZiAocm93ICYmIChyb3cudG90YWwgPz8gMCkgPiAwKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgc3Rhc2g6IHJvdy5zdGFzaCA/PyAwLFxuICAgICAgICAgIHRyYXNoOiByb3cudHJhc2ggPz8gMCxcbiAgICAgICAgICB0b3RhbDogcm93LnRvdGFsID8/IDAsXG4gICAgICAgICAgc3Rhc2hfcGN0OiByb3cuc3Rhc2hfcGN0ID8/IDUwLFxuICAgICAgICAgIG15VmVyZGljdDpcbiAgICAgICAgICAgICgobWluZSBhcyB7IGRhdGE/OiB7IHZlcmRpY3Q6IHN0cmluZyB9IHwgbnVsbCB9KT8uZGF0YT8udmVyZGljdCBhc1xuICAgICAgICAgICAgICB8IFwic3Rhc2hcIlxuICAgICAgICAgICAgICB8IFwidHJhc2hcIlxuICAgICAgICAgICAgICB8IHVuZGVmaW5lZCkgPz8gbnVsbCxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9XG4gIH0gY2F0Y2gge1xuICAgIC8qIG5vbi1VVUlEIGJyYW5kIGZhbGxiYWNrIGJlbG93ICovXG4gIH1cblxuICBjb25zdCBzdGF0cyA9IGF3YWl0IGZldGNoQnJhbmRTdGF0cyhicmFuZElkKTtcbiAgbGV0IG15VmVyZGljdDogXCJzdGFzaFwiIHwgXCJ0cmFzaFwiIHwgbnVsbCA9IG51bGw7XG4gIHRyeSB7XG4gICAgY29uc3QgeyBnZXRGaXJlc3RvcmVCcmFuZFZvdGVzIH0gPSBhd2FpdCBpbXBvcnQoXCJAL3NlcnZpY2VzL2ZpcmVzdG9yZVNlcnZpY2VcIik7XG4gICAgY29uc3Qgdm90ZXMgPSBhd2FpdCBnZXRGaXJlc3RvcmVCcmFuZFZvdGVzKGJyYW5kSWQpO1xuICAgIGlmICh1c2VySWQpIHtcbiAgICAgIGNvbnN0IGZvdW5kID0gdm90ZXMuZmluZCgodikgPT4gdi51c2VySWQgPT09IHVzZXJJZCk7XG4gICAgICBpZiAoZm91bmQpIG15VmVyZGljdCA9IGZvdW5kLnZvdGVUeXBlO1xuICAgIH1cbiAgfSBjYXRjaCB7XG4gICAgLyogaWdub3JlICovXG4gIH1cbiAgY29uc3QgdG90YWwgPSBzdGF0cy5zdGFzaCArIHN0YXRzLnRyYXNoO1xuICBjb25zdCBzdGFzaF9wY3QgPSB0b3RhbCA+IDAgPyBNYXRoLnJvdW5kKChzdGF0cy5zdGFzaCAvIHRvdGFsKSAqIDEwMCkgOiA1MDtcbiAgcmV0dXJuIHtcbiAgICBzdGFzaDogc3RhdHMuc3Rhc2gsXG4gICAgdHJhc2g6IHN0YXRzLnRyYXNoLFxuICAgIHRvdGFsLFxuICAgIHN0YXNoX3BjdCxcbiAgICBteVZlcmRpY3QsXG4gIH07XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjYXN0QnJhbmRWb3RlKGJyYW5kSWQ6IHN0cmluZywgdXNlcklkOiBzdHJpbmcsIHZlcmRpY3Q6IFwic3Rhc2hcIiB8IFwidHJhc2hcIikge1xuICAvLyBTeW5jIHRvIEZpcmVzdG9yZVxuICB0cnkge1xuICAgIGNvbnN0IHsgY2FzdEZpcmVzdG9yZUJyYW5kVm90ZSB9ID0gYXdhaXQgaW1wb3J0KFwiQC9zZXJ2aWNlcy9maXJlc3RvcmVTZXJ2aWNlXCIpO1xuICAgIGF3YWl0IGNhc3RGaXJlc3RvcmVCcmFuZFZvdGUoYnJhbmRJZCwgdXNlcklkLCB2ZXJkaWN0KTtcbiAgfSBjYXRjaCAoZnNFcnIpIHtcbiAgICBjb25zb2xlLndhcm4oXCJGaXJlc3RvcmUgdm90ZSBzeW5jIG5vdGU6XCIsIGZzRXJyKTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwiYnJhbmRfdm90ZXNcIilcbiAgICAgIC51cHNlcnQoeyBicmFuZF9pZDogYnJhbmRJZCwgdXNlcl9pZDogdXNlcklkLCB2ZXJkaWN0IH0sIHsgb25Db25mbGljdDogXCJicmFuZF9pZCx1c2VyX2lkXCIgfSk7XG4gICAgaWYgKGVycm9yKSBjb25zb2xlLndhcm4oXCJTdXBhYmFzZSB2b3RlIG5vdGU6XCIsIGVycm9yLm1lc3NhZ2UpO1xuICB9IGNhdGNoIHtcbiAgICAvLyBsZWdhY3kgc3RvcmUgdW5hdmFpbGFibGVcbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVtb3ZlQnJhbmRWb3RlKGJyYW5kSWQ6IHN0cmluZywgdXNlcklkOiBzdHJpbmcpIHtcbiAgdHJ5IHtcbiAgICBjb25zdCB7IGRlbGV0ZURvYywgZG9jIH0gPSBhd2FpdCBpbXBvcnQoXCJmaXJlYmFzZS9maXJlc3RvcmVcIik7XG4gICAgY29uc3QgeyBkYiB9ID0gYXdhaXQgaW1wb3J0KFwiQC9saWIvZmlyZWJhc2VcIik7XG4gICAgYXdhaXQgZGVsZXRlRG9jKGRvYyhkYiwgXCJicmFuZHNcIiwgYnJhbmRJZCwgXCJ2b3Rlc1wiLCB1c2VySWQpKTtcbiAgfSBjYXRjaCAoZnNFcnIpIHtcbiAgICBjb25zb2xlLndhcm4oXCJGaXJlc3RvcmUgcmVtb3ZlIHZvdGUgbm90ZTpcIiwgZnNFcnIpO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJicmFuZF92b3Rlc1wiKVxuICAgICAgLmRlbGV0ZSgpXG4gICAgICAuZXEoXCJicmFuZF9pZFwiLCBicmFuZElkKVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpO1xuICAgIGlmIChlcnJvcikgY29uc29sZS53YXJuKFwiU3VwYWJhc2UgcmVtb3ZlIHZvdGUgbm90ZTpcIiwgZXJyb3IubWVzc2FnZSk7XG4gIH0gY2F0Y2gge1xuICAgIC8vIGxlZ2FjeSBzdG9yZSB1bmF2YWlsYWJsZVxuICB9XG59XG4iXX0=