import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=a8030269";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=a8030269";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/react_jsx-runtime.js?v=a8030269";
import { t as createContextScope } from "/node_modules/.vite/deps/dist-Dic5YkbB.js?v=a8030269";
import { o as useComposedRefs, r as createSlot } from "/node_modules/.vite/deps/dist-DIAF6ZLP.js?v=a8030269";
//#region node_modules/@radix-ui/react-collection/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var __defProp$1 = Object.defineProperty;
var __name$1 = (target, value) => __defProp$1(target, "name", {
	value,
	configurable: true
});
// @__NO_SIDE_EFFECTS__
function createCollection(name) {
	const PROVIDER_NAME = name + "CollectionProvider";
	const [createCollectionContext, createCollectionScope] = createContextScope(PROVIDER_NAME);
	const [CollectionProviderImpl, useCollectionContext] = createCollectionContext(PROVIDER_NAME, {
		collectionRef: { current: null },
		itemMap: /* @__PURE__ */ new Map()
	});
	const CollectionProvider = /* @__PURE__ */ __name$1((props) => {
		const { scope, children } = props;
		const ref = import_react.useRef(null);
		const itemMap = import_react.useRef(/* @__PURE__ */ new Map()).current;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionProviderImpl, {
			scope,
			itemMap,
			collectionRef: ref,
			children
		});
	}, "CollectionProvider");
	CollectionProvider.displayName = PROVIDER_NAME;
	const COLLECTION_SLOT_NAME = name + "CollectionSlot";
	const CollectionSlotImpl = createSlot(COLLECTION_SLOT_NAME);
	const CollectionSlot = import_react.forwardRef((props, forwardedRef) => {
		const { scope, children } = props;
		const context = useCollectionContext(COLLECTION_SLOT_NAME, scope);
		const composedRefs = useComposedRefs(forwardedRef, context.collectionRef);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionSlotImpl, {
			ref: composedRefs,
			children
		});
	});
	CollectionSlot.displayName = COLLECTION_SLOT_NAME;
	const ITEM_SLOT_NAME = name + "CollectionItemSlot";
	const ITEM_DATA_ATTR = "data-radix-collection-item";
	const CollectionItemSlotImpl = createSlot(ITEM_SLOT_NAME);
	const CollectionItemSlot = import_react.forwardRef((props, forwardedRef) => {
		const { scope, children, ...itemData } = props;
		const ref = import_react.useRef(null);
		const composedRefs = useComposedRefs(forwardedRef, ref);
		const context = useCollectionContext(ITEM_SLOT_NAME, scope);
		import_react.useEffect(() => {
			context.itemMap.set(ref, {
				ref,
				...itemData
			});
			return () => void context.itemMap.delete(ref);
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionItemSlotImpl, {
			[ITEM_DATA_ATTR]: "",
			ref: composedRefs,
			children
		});
	});
	CollectionItemSlot.displayName = ITEM_SLOT_NAME;
	function useCollection(scope) {
		const context = useCollectionContext(name + "CollectionConsumer", scope);
		return import_react.useCallback(() => {
			const collectionNode = context.collectionRef.current;
			if (!collectionNode) return [];
			const orderedNodes = Array.from(collectionNode.querySelectorAll(`[${ITEM_DATA_ATTR}]`));
			return Array.from(context.itemMap.values()).sort((a, b) => orderedNodes.indexOf(a.ref.current) - orderedNodes.indexOf(b.ref.current));
		}, [context.collectionRef, context.itemMap]);
	}
	__name$1(useCollection, "useCollection");
	return [
		{
			Provider: CollectionProvider,
			Slot: CollectionSlot,
			ItemSlot: CollectionItemSlot
		},
		useCollection,
		createCollectionScope
	];
}
__name$1(createCollection, "createCollection");
var __instanciated = /* @__PURE__ */ new WeakMap();
var OrderedDict = class _OrderedDict extends Map {
	static {
		__name$1(this, "OrderedDict");
	}
	#keys;
	constructor(entries) {
		super(entries);
		this.#keys = [...super.keys()];
		__instanciated.set(this, true);
	}
	set(key, value) {
		if (__instanciated.get(this)) {
			if (this.has(key)) this.#keys[this.#keys.indexOf(key)] = key;
			else this.#keys.push(key);
		}
		super.set(key, value);
		return this;
	}
	insert(index, key, value) {
		const has = this.has(key);
		const length = this.#keys.length;
		const relativeIndex = toSafeInteger(index);
		let actualIndex = relativeIndex >= 0 ? relativeIndex : length + relativeIndex;
		const safeIndex = actualIndex < 0 || actualIndex >= length ? -1 : actualIndex;
		if (safeIndex === this.size || has && safeIndex === this.size - 1 || safeIndex === -1) {
			this.set(key, value);
			return this;
		}
		const size = this.size + (has ? 0 : 1);
		if (relativeIndex < 0) actualIndex++;
		const keys = [...this.#keys];
		let nextValue;
		let shouldSkip = false;
		for (let i = actualIndex; i < size; i++) if (actualIndex === i) {
			let nextKey = keys[i];
			if (keys[i] === key) nextKey = keys[i + 1];
			if (has) this.delete(key);
			nextValue = this.get(nextKey);
			this.set(key, value);
		} else {
			if (!shouldSkip && keys[i - 1] === key) shouldSkip = true;
			const currentKey = keys[shouldSkip ? i : i - 1];
			const currentValue = nextValue;
			nextValue = this.get(currentKey);
			this.delete(currentKey);
			this.set(currentKey, currentValue);
		}
		return this;
	}
	with(index, key, value) {
		const copy = new _OrderedDict(this);
		copy.insert(index, key, value);
		return copy;
	}
	before(key) {
		const index = this.#keys.indexOf(key) - 1;
		if (index < 0) return;
		return this.entryAt(index);
	}
	/**
	* Sets a new key-value pair at the position before the given key.
	*/
	setBefore(key, newKey, value) {
		const index = this.#keys.indexOf(key);
		if (index === -1) return this;
		return this.insert(index, newKey, value);
	}
	after(key) {
		let index = this.#keys.indexOf(key);
		index = index === -1 || index === this.size - 1 ? -1 : index + 1;
		if (index === -1) return;
		return this.entryAt(index);
	}
	/**
	* Sets a new key-value pair at the position after the given key.
	*/
	setAfter(key, newKey, value) {
		const index = this.#keys.indexOf(key);
		if (index === -1) return this;
		return this.insert(index + 1, newKey, value);
	}
	first() {
		return this.entryAt(0);
	}
	last() {
		return this.entryAt(-1);
	}
	clear() {
		this.#keys = [];
		return super.clear();
	}
	delete(key) {
		const deleted = super.delete(key);
		if (deleted) this.#keys.splice(this.#keys.indexOf(key), 1);
		return deleted;
	}
	deleteAt(index) {
		const key = this.keyAt(index);
		if (key !== void 0) return this.delete(key);
		return false;
	}
	at(index) {
		const key = at(this.#keys, index);
		if (key !== void 0) return this.get(key);
	}
	entryAt(index) {
		const key = at(this.#keys, index);
		if (key !== void 0) return [key, this.get(key)];
	}
	indexOf(key) {
		return this.#keys.indexOf(key);
	}
	keyAt(index) {
		return at(this.#keys, index);
	}
	from(key, offset) {
		const index = this.indexOf(key);
		if (index === -1) return;
		let dest = index + offset;
		if (dest < 0) dest = 0;
		if (dest >= this.size) dest = this.size - 1;
		return this.at(dest);
	}
	keyFrom(key, offset) {
		const index = this.indexOf(key);
		if (index === -1) return;
		let dest = index + offset;
		if (dest < 0) dest = 0;
		if (dest >= this.size) dest = this.size - 1;
		return this.keyAt(dest);
	}
	find(predicate, thisArg) {
		let index = 0;
		for (const entry of this) {
			if (Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) return entry;
			index++;
		}
	}
	findIndex(predicate, thisArg) {
		let index = 0;
		for (const entry of this) {
			if (Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) return index;
			index++;
		}
		return -1;
	}
	filter(predicate, thisArg) {
		const entries = [];
		let index = 0;
		for (const entry of this) {
			if (Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) entries.push(entry);
			index++;
		}
		return new _OrderedDict(entries);
	}
	map(callbackfn, thisArg) {
		const entries = [];
		let index = 0;
		for (const entry of this) {
			entries.push([entry[0], Reflect.apply(callbackfn, thisArg, [
				entry,
				index,
				this
			])]);
			index++;
		}
		return new _OrderedDict(entries);
	}
	reduce(...args) {
		const [callbackfn, initialValue] = args;
		let index = 0;
		let accumulator = initialValue ?? this.at(0);
		for (const entry of this) {
			if (index === 0 && args.length === 1) accumulator = entry;
			else accumulator = Reflect.apply(callbackfn, this, [
				accumulator,
				entry,
				index,
				this
			]);
			index++;
		}
		return accumulator;
	}
	reduceRight(...args) {
		const [callbackfn, initialValue] = args;
		let accumulator = initialValue ?? this.at(-1);
		for (let index = this.size - 1; index >= 0; index--) {
			const entry = this.at(index);
			if (index === this.size - 1 && args.length === 1) accumulator = entry;
			else accumulator = Reflect.apply(callbackfn, this, [
				accumulator,
				entry,
				index,
				this
			]);
		}
		return accumulator;
	}
	toSorted(compareFn) {
		const entries = [...this.entries()].sort(compareFn);
		return new _OrderedDict(entries);
	}
	toReversed() {
		const reversed = new _OrderedDict();
		for (let index = this.size - 1; index >= 0; index--) {
			const key = this.keyAt(index);
			const element = this.get(key);
			reversed.set(key, element);
		}
		return reversed;
	}
	toSpliced(...args) {
		const entries = [...this.entries()];
		entries.splice(...args);
		return new _OrderedDict(entries);
	}
	slice(start, end) {
		const result = new _OrderedDict();
		let stop = this.size - 1;
		if (start === void 0) return result;
		if (start < 0) start = start + this.size;
		if (end !== void 0 && end > 0) stop = end - 1;
		for (let index = start; index <= stop; index++) {
			const key = this.keyAt(index);
			const element = this.get(key);
			result.set(key, element);
		}
		return result;
	}
	every(predicate, thisArg) {
		let index = 0;
		for (const entry of this) {
			if (!Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) return false;
			index++;
		}
		return true;
	}
	some(predicate, thisArg) {
		let index = 0;
		for (const entry of this) {
			if (Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) return true;
			index++;
		}
		return false;
	}
};
function at(array, index) {
	if ("at" in Array.prototype) return Array.prototype.at.call(array, index);
	const actualIndex = toSafeIndex(array, index);
	return actualIndex === -1 ? void 0 : array[actualIndex];
}
__name$1(at, "at");
function toSafeIndex(array, index) {
	const length = array.length;
	const relativeIndex = toSafeInteger(index);
	const actualIndex = relativeIndex >= 0 ? relativeIndex : length + relativeIndex;
	return actualIndex < 0 || actualIndex >= length ? -1 : actualIndex;
}
__name$1(toSafeIndex, "toSafeIndex");
function toSafeInteger(number) {
	return number !== number || number === 0 ? 0 : Math.trunc(number);
}
__name$1(toSafeInteger, "toSafeInteger");
// @__NO_SIDE_EFFECTS__
function createCollection2(name) {
	const PROVIDER_NAME = name + "CollectionProvider";
	const [createCollectionContext, createCollectionScope] = createContextScope(PROVIDER_NAME);
	const [CollectionContextProvider, useCollectionContext] = createCollectionContext(PROVIDER_NAME, {
		collectionElement: null,
		collectionRef: { current: null },
		collectionRefObject: { current: null },
		itemMap: new OrderedDict(),
		setItemMap: /* @__PURE__ */ __name$1(() => void 0, "setItemMap")
	});
	const CollectionProvider = /* @__PURE__ */ __name$1(({ state, ...props }) => {
		return state ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionProviderImpl, {
			...props,
			state
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionInit, { ...props });
	}, "CollectionProvider");
	CollectionProvider.displayName = PROVIDER_NAME;
	const CollectionInit = /* @__PURE__ */ __name$1((props) => {
		const state = useInitCollection();
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionProviderImpl, {
			...props,
			state
		});
	}, "CollectionInit");
	CollectionInit.displayName = PROVIDER_NAME + "Init";
	const CollectionProviderImpl = /* @__PURE__ */ __name$1((props) => {
		const { scope, children, state } = props;
		const ref = import_react.useRef(null);
		const [collectionElement, setCollectionElement] = import_react.useState(null);
		const composeRefs = useComposedRefs(ref, setCollectionElement);
		const [itemMap, setItemMap] = state;
		import_react.useEffect(() => {
			if (!collectionElement) return;
			const observer = getChildListObserver(() => {});
			observer.observe(collectionElement, {
				childList: true,
				subtree: true
			});
			return () => {
				observer.disconnect();
			};
		}, [collectionElement]);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionContextProvider, {
			scope,
			itemMap,
			setItemMap,
			collectionRef: composeRefs,
			collectionRefObject: ref,
			collectionElement,
			children
		});
	}, "CollectionProviderImpl");
	CollectionProviderImpl.displayName = PROVIDER_NAME + "Impl";
	const COLLECTION_SLOT_NAME = name + "CollectionSlot";
	const CollectionSlotImpl = createSlot(COLLECTION_SLOT_NAME);
	const CollectionSlot = import_react.forwardRef((props, forwardedRef) => {
		const { scope, children } = props;
		const context = useCollectionContext(COLLECTION_SLOT_NAME, scope);
		const composedRefs = useComposedRefs(forwardedRef, context.collectionRef);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionSlotImpl, {
			ref: composedRefs,
			children
		});
	});
	CollectionSlot.displayName = COLLECTION_SLOT_NAME;
	const ITEM_SLOT_NAME = name + "CollectionItemSlot";
	const ITEM_DATA_ATTR = "data-radix-collection-item";
	const CollectionItemSlotImpl = createSlot(ITEM_SLOT_NAME);
	const CollectionItemSlot = import_react.forwardRef((props, forwardedRef) => {
		const { scope, children, ...itemData } = props;
		const ref = import_react.useRef(null);
		const [element, setElement] = import_react.useState(null);
		const composedRefs = useComposedRefs(forwardedRef, ref, setElement);
		const { setItemMap } = useCollectionContext(ITEM_SLOT_NAME, scope);
		const itemDataRef = import_react.useRef(itemData);
		if (!shallowEqual(itemDataRef.current, itemData)) itemDataRef.current = itemData;
		const memoizedItemData = itemDataRef.current;
		import_react.useEffect(() => {
			const itemData2 = memoizedItemData;
			setItemMap((map) => {
				if (!element) return map;
				if (!map.has(element)) {
					map.set(element, {
						...itemData2,
						element
					});
					return map.toSorted(sortByDocumentPosition);
				}
				return map.set(element, {
					...itemData2,
					element
				}).toSorted(sortByDocumentPosition);
			});
			return () => {
				setItemMap((map) => {
					if (!element || !map.has(element)) return map;
					map.delete(element);
					return new OrderedDict(map);
				});
			};
		}, [
			element,
			memoizedItemData,
			setItemMap
		]);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionItemSlotImpl, {
			[ITEM_DATA_ATTR]: "",
			ref: composedRefs,
			children
		});
	});
	CollectionItemSlot.displayName = ITEM_SLOT_NAME;
	function useInitCollection() {
		return import_react.useState(new OrderedDict());
	}
	__name$1(useInitCollection, "useInitCollection");
	function useCollection(scope) {
		const { itemMap } = useCollectionContext(name + "CollectionConsumer", scope);
		return itemMap;
	}
	__name$1(useCollection, "useCollection");
	return [{
		Provider: CollectionProvider,
		Slot: CollectionSlot,
		ItemSlot: CollectionItemSlot
	}, {
		createCollectionScope,
		useCollection,
		useInitCollection
	}];
}
__name$1(createCollection2, "createCollection");
function shallowEqual(a, b) {
	if (a === b) return true;
	if (typeof a !== "object" || typeof b !== "object") return false;
	if (a == null || b == null) return false;
	const keysA = Object.keys(a);
	const keysB = Object.keys(b);
	if (keysA.length !== keysB.length) return false;
	for (const key of keysA) {
		if (!Object.prototype.hasOwnProperty.call(b, key)) return false;
		if (a[key] !== b[key]) return false;
	}
	return true;
}
__name$1(shallowEqual, "shallowEqual");
function isElementPreceding(a, b) {
	return !!(b.compareDocumentPosition(a) & Node.DOCUMENT_POSITION_PRECEDING);
}
__name$1(isElementPreceding, "isElementPreceding");
function sortByDocumentPosition(a, b) {
	return !a[1].element || !b[1].element ? 0 : isElementPreceding(a[1].element, b[1].element) ? -1 : 1;
}
__name$1(sortByDocumentPosition, "sortByDocumentPosition");
function getChildListObserver(callback) {
	return new MutationObserver((mutationsList) => {
		for (const mutation of mutationsList) if (mutation.type === "childList") {
			callback();
			return;
		}
	});
}
__name$1(getChildListObserver, "getChildListObserver");
//#endregion
//#region node_modules/@radix-ui/react-direction/dist/index.mjs
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", {
	value,
	configurable: true
});
var DirectionContext = import_react.createContext(void 0);
function useDirection(localDir) {
	const globalDir = import_react.useContext(DirectionContext);
	return localDir || globalDir || "ltr";
}
__name(useDirection, "useDirection");
//#endregion
export { createCollection as n, useDirection as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlzdC1EcGE4YVJDVS5qcyIsIm5hbWVzIjpbIl9fZGVmUHJvcCIsIl9fbmFtZSIsImNyZWF0ZUNvbnRleHRTY29wZTIiLCJ1c2VDb21wb3NlZFJlZnMyIiwiY3JlYXRlU2xvdDIiXSwic291cmNlcyI6WyIuLi8uLi9AcmFkaXgtdWkvcmVhY3QtY29sbGVjdGlvbi9kaXN0L2luZGV4Lm1qcyIsIi4uLy4uL0ByYWRpeC11aS9yZWFjdC1kaXJlY3Rpb24vZGlzdC9pbmRleC5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2UgY2xpZW50XCI7XG52YXIgX19kZWZQcm9wID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fbmFtZSA9ICh0YXJnZXQsIHZhbHVlKSA9PiBfX2RlZlByb3AodGFyZ2V0LCBcIm5hbWVcIiwgeyB2YWx1ZSwgY29uZmlndXJhYmxlOiB0cnVlIH0pO1xuXG4vLyBzcmMvY29sbGVjdGlvbi1sZWdhY3kudHN4XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNyZWF0ZUNvbnRleHRTY29wZSB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtY29udGV4dFwiO1xuaW1wb3J0IHsgdXNlQ29tcG9zZWRSZWZzIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1jb21wb3NlLXJlZnNcIjtcbmltcG9ydCB7IGNyZWF0ZVNsb3QgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXNsb3RcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIGNyZWF0ZUNvbGxlY3Rpb24obmFtZSkge1xuICBjb25zdCBQUk9WSURFUl9OQU1FID0gbmFtZSArIFwiQ29sbGVjdGlvblByb3ZpZGVyXCI7XG4gIGNvbnN0IFtjcmVhdGVDb2xsZWN0aW9uQ29udGV4dCwgY3JlYXRlQ29sbGVjdGlvblNjb3BlXSA9IGNyZWF0ZUNvbnRleHRTY29wZShQUk9WSURFUl9OQU1FKTtcbiAgY29uc3QgW0NvbGxlY3Rpb25Qcm92aWRlckltcGwsIHVzZUNvbGxlY3Rpb25Db250ZXh0XSA9IGNyZWF0ZUNvbGxlY3Rpb25Db250ZXh0KFxuICAgIFBST1ZJREVSX05BTUUsXG4gICAgeyBjb2xsZWN0aW9uUmVmOiB7IGN1cnJlbnQ6IG51bGwgfSwgaXRlbU1hcDogLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSB9XG4gICk7XG4gIGNvbnN0IENvbGxlY3Rpb25Qcm92aWRlciA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKHByb3BzKSA9PiB7XG4gICAgY29uc3QgeyBzY29wZSwgY2hpbGRyZW4gfSA9IHByb3BzO1xuICAgIGNvbnN0IHJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgICBjb25zdCBpdGVtTWFwID0gUmVhY3QudXNlUmVmKC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCkpLmN1cnJlbnQ7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goQ29sbGVjdGlvblByb3ZpZGVySW1wbCwgeyBzY29wZSwgaXRlbU1hcCwgY29sbGVjdGlvblJlZjogcmVmLCBjaGlsZHJlbiB9KTtcbiAgfSwgXCJDb2xsZWN0aW9uUHJvdmlkZXJcIik7XG4gIENvbGxlY3Rpb25Qcm92aWRlci5kaXNwbGF5TmFtZSA9IFBST1ZJREVSX05BTUU7XG4gIGNvbnN0IENPTExFQ1RJT05fU0xPVF9OQU1FID0gbmFtZSArIFwiQ29sbGVjdGlvblNsb3RcIjtcbiAgY29uc3QgQ29sbGVjdGlvblNsb3RJbXBsID0gY3JlYXRlU2xvdChDT0xMRUNUSU9OX1NMT1RfTkFNRSk7XG4gIGNvbnN0IENvbGxlY3Rpb25TbG90ID0gUmVhY3QuZm9yd2FyZFJlZihcbiAgICAocHJvcHMsIGZvcndhcmRlZFJlZikgPT4ge1xuICAgICAgY29uc3QgeyBzY29wZSwgY2hpbGRyZW4gfSA9IHByb3BzO1xuICAgICAgY29uc3QgY29udGV4dCA9IHVzZUNvbGxlY3Rpb25Db250ZXh0KENPTExFQ1RJT05fU0xPVF9OQU1FLCBzY29wZSk7XG4gICAgICBjb25zdCBjb21wb3NlZFJlZnMgPSB1c2VDb21wb3NlZFJlZnMoZm9yd2FyZGVkUmVmLCBjb250ZXh0LmNvbGxlY3Rpb25SZWYpO1xuICAgICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goQ29sbGVjdGlvblNsb3RJbXBsLCB7IHJlZjogY29tcG9zZWRSZWZzLCBjaGlsZHJlbiB9KTtcbiAgICB9XG4gICk7XG4gIENvbGxlY3Rpb25TbG90LmRpc3BsYXlOYW1lID0gQ09MTEVDVElPTl9TTE9UX05BTUU7XG4gIGNvbnN0IElURU1fU0xPVF9OQU1FID0gbmFtZSArIFwiQ29sbGVjdGlvbkl0ZW1TbG90XCI7XG4gIGNvbnN0IElURU1fREFUQV9BVFRSID0gXCJkYXRhLXJhZGl4LWNvbGxlY3Rpb24taXRlbVwiO1xuICBjb25zdCBDb2xsZWN0aW9uSXRlbVNsb3RJbXBsID0gY3JlYXRlU2xvdChJVEVNX1NMT1RfTkFNRSk7XG4gIGNvbnN0IENvbGxlY3Rpb25JdGVtU2xvdCA9IFJlYWN0LmZvcndhcmRSZWYoXG4gICAgKHByb3BzLCBmb3J3YXJkZWRSZWYpID0+IHtcbiAgICAgIGNvbnN0IHsgc2NvcGUsIGNoaWxkcmVuLCAuLi5pdGVtRGF0YSB9ID0gcHJvcHM7XG4gICAgICBjb25zdCByZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gICAgICBjb25zdCBjb21wb3NlZFJlZnMgPSB1c2VDb21wb3NlZFJlZnMoZm9yd2FyZGVkUmVmLCByZWYpO1xuICAgICAgY29uc3QgY29udGV4dCA9IHVzZUNvbGxlY3Rpb25Db250ZXh0KElURU1fU0xPVF9OQU1FLCBzY29wZSk7XG4gICAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb250ZXh0Lml0ZW1NYXAuc2V0KHJlZiwgeyByZWYsIC4uLml0ZW1EYXRhIH0pO1xuICAgICAgICByZXR1cm4gKCkgPT4gdm9pZCBjb250ZXh0Lml0ZW1NYXAuZGVsZXRlKHJlZik7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KENvbGxlY3Rpb25JdGVtU2xvdEltcGwsIHsgLi4ueyBbSVRFTV9EQVRBX0FUVFJdOiBcIlwiIH0sIHJlZjogY29tcG9zZWRSZWZzLCBjaGlsZHJlbiB9KTtcbiAgICB9XG4gICk7XG4gIENvbGxlY3Rpb25JdGVtU2xvdC5kaXNwbGF5TmFtZSA9IElURU1fU0xPVF9OQU1FO1xuICBmdW5jdGlvbiB1c2VDb2xsZWN0aW9uKHNjb3BlKSB7XG4gICAgY29uc3QgY29udGV4dCA9IHVzZUNvbGxlY3Rpb25Db250ZXh0KG5hbWUgKyBcIkNvbGxlY3Rpb25Db25zdW1lclwiLCBzY29wZSk7XG4gICAgY29uc3QgZ2V0SXRlbXMgPSBSZWFjdC51c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgICBjb25zdCBjb2xsZWN0aW9uTm9kZSA9IGNvbnRleHQuY29sbGVjdGlvblJlZi5jdXJyZW50O1xuICAgICAgaWYgKCFjb2xsZWN0aW9uTm9kZSkgcmV0dXJuIFtdO1xuICAgICAgY29uc3Qgb3JkZXJlZE5vZGVzID0gQXJyYXkuZnJvbShjb2xsZWN0aW9uTm9kZS5xdWVyeVNlbGVjdG9yQWxsKGBbJHtJVEVNX0RBVEFfQVRUUn1dYCkpO1xuICAgICAgY29uc3QgaXRlbXMgPSBBcnJheS5mcm9tKGNvbnRleHQuaXRlbU1hcC52YWx1ZXMoKSk7XG4gICAgICBjb25zdCBvcmRlcmVkSXRlbXMgPSBpdGVtcy5zb3J0KFxuICAgICAgICAoYSwgYikgPT4gb3JkZXJlZE5vZGVzLmluZGV4T2YoYS5yZWYuY3VycmVudCkgLSBvcmRlcmVkTm9kZXMuaW5kZXhPZihiLnJlZi5jdXJyZW50KVxuICAgICAgKTtcbiAgICAgIHJldHVybiBvcmRlcmVkSXRlbXM7XG4gICAgfSwgW2NvbnRleHQuY29sbGVjdGlvblJlZiwgY29udGV4dC5pdGVtTWFwXSk7XG4gICAgcmV0dXJuIGdldEl0ZW1zO1xuICB9XG4gIF9fbmFtZSh1c2VDb2xsZWN0aW9uLCBcInVzZUNvbGxlY3Rpb25cIik7XG4gIHJldHVybiBbXG4gICAgeyBQcm92aWRlcjogQ29sbGVjdGlvblByb3ZpZGVyLCBTbG90OiBDb2xsZWN0aW9uU2xvdCwgSXRlbVNsb3Q6IENvbGxlY3Rpb25JdGVtU2xvdCB9LFxuICAgIHVzZUNvbGxlY3Rpb24sXG4gICAgY3JlYXRlQ29sbGVjdGlvblNjb3BlXG4gIF07XG59XG5fX25hbWUoY3JlYXRlQ29sbGVjdGlvbiwgXCJjcmVhdGVDb2xsZWN0aW9uXCIpO1xuXG4vLyBzcmMvY29sbGVjdGlvbi50c3hcbmltcG9ydCAqIGFzIFJlYWN0MiBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNyZWF0ZUNvbnRleHRTY29wZSBhcyBjcmVhdGVDb250ZXh0U2NvcGUyIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1jb250ZXh0XCI7XG5pbXBvcnQgeyB1c2VDb21wb3NlZFJlZnMgYXMgdXNlQ29tcG9zZWRSZWZzMiB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtY29tcG9zZS1yZWZzXCI7XG5pbXBvcnQgeyBjcmVhdGVTbG90IGFzIGNyZWF0ZVNsb3QyIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1zbG90XCI7XG5cbi8vIHNyYy9vcmRlcmVkLWRpY3Rpb25hcnkudHNcbnZhciBfX2luc3RhbmNpYXRlZCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xudmFyIE9yZGVyZWREaWN0ID0gY2xhc3MgX09yZGVyZWREaWN0IGV4dGVuZHMgTWFwIHtcbiAgc3RhdGljIHtcbiAgICBfX25hbWUodGhpcywgXCJPcmRlcmVkRGljdFwiKTtcbiAgfVxuICAja2V5cztcbiAgY29uc3RydWN0b3IoZW50cmllcykge1xuICAgIHN1cGVyKGVudHJpZXMpO1xuICAgIHRoaXMuI2tleXMgPSBbLi4uc3VwZXIua2V5cygpXTtcbiAgICBfX2luc3RhbmNpYXRlZC5zZXQodGhpcywgdHJ1ZSk7XG4gIH1cbiAgc2V0KGtleSwgdmFsdWUpIHtcbiAgICBpZiAoX19pbnN0YW5jaWF0ZWQuZ2V0KHRoaXMpKSB7XG4gICAgICBpZiAodGhpcy5oYXMoa2V5KSkge1xuICAgICAgICB0aGlzLiNrZXlzW3RoaXMuI2tleXMuaW5kZXhPZihrZXkpXSA9IGtleTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuI2tleXMucHVzaChrZXkpO1xuICAgICAgfVxuICAgIH1cbiAgICBzdXBlci5zZXQoa2V5LCB2YWx1ZSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgaW5zZXJ0KGluZGV4LCBrZXksIHZhbHVlKSB7XG4gICAgY29uc3QgaGFzID0gdGhpcy5oYXMoa2V5KTtcbiAgICBjb25zdCBsZW5ndGggPSB0aGlzLiNrZXlzLmxlbmd0aDtcbiAgICBjb25zdCByZWxhdGl2ZUluZGV4ID0gdG9TYWZlSW50ZWdlcihpbmRleCk7XG4gICAgbGV0IGFjdHVhbEluZGV4ID0gcmVsYXRpdmVJbmRleCA+PSAwID8gcmVsYXRpdmVJbmRleCA6IGxlbmd0aCArIHJlbGF0aXZlSW5kZXg7XG4gICAgY29uc3Qgc2FmZUluZGV4ID0gYWN0dWFsSW5kZXggPCAwIHx8IGFjdHVhbEluZGV4ID49IGxlbmd0aCA/IC0xIDogYWN0dWFsSW5kZXg7XG4gICAgaWYgKHNhZmVJbmRleCA9PT0gdGhpcy5zaXplIHx8IGhhcyAmJiBzYWZlSW5kZXggPT09IHRoaXMuc2l6ZSAtIDEgfHwgc2FmZUluZGV4ID09PSAtMSkge1xuICAgICAgdGhpcy5zZXQoa2V5LCB2YWx1ZSk7XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgY29uc3Qgc2l6ZSA9IHRoaXMuc2l6ZSArIChoYXMgPyAwIDogMSk7XG4gICAgaWYgKHJlbGF0aXZlSW5kZXggPCAwKSB7XG4gICAgICBhY3R1YWxJbmRleCsrO1xuICAgIH1cbiAgICBjb25zdCBrZXlzID0gWy4uLnRoaXMuI2tleXNdO1xuICAgIGxldCBuZXh0VmFsdWU7XG4gICAgbGV0IHNob3VsZFNraXAgPSBmYWxzZTtcbiAgICBmb3IgKGxldCBpID0gYWN0dWFsSW5kZXg7IGkgPCBzaXplOyBpKyspIHtcbiAgICAgIGlmIChhY3R1YWxJbmRleCA9PT0gaSkge1xuICAgICAgICBsZXQgbmV4dEtleSA9IGtleXNbaV07XG4gICAgICAgIGlmIChrZXlzW2ldID09PSBrZXkpIHtcbiAgICAgICAgICBuZXh0S2V5ID0ga2V5c1tpICsgMV07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGhhcykge1xuICAgICAgICAgIHRoaXMuZGVsZXRlKGtleSk7XG4gICAgICAgIH1cbiAgICAgICAgbmV4dFZhbHVlID0gdGhpcy5nZXQobmV4dEtleSk7XG4gICAgICAgIHRoaXMuc2V0KGtleSwgdmFsdWUpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKCFzaG91bGRTa2lwICYmIGtleXNbaSAtIDFdID09PSBrZXkpIHtcbiAgICAgICAgICBzaG91bGRTa2lwID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjdXJyZW50S2V5ID0ga2V5c1tzaG91bGRTa2lwID8gaSA6IGkgLSAxXTtcbiAgICAgICAgY29uc3QgY3VycmVudFZhbHVlID0gbmV4dFZhbHVlO1xuICAgICAgICBuZXh0VmFsdWUgPSB0aGlzLmdldChjdXJyZW50S2V5KTtcbiAgICAgICAgdGhpcy5kZWxldGUoY3VycmVudEtleSk7XG4gICAgICAgIHRoaXMuc2V0KGN1cnJlbnRLZXksIGN1cnJlbnRWYWx1ZSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIHdpdGgoaW5kZXgsIGtleSwgdmFsdWUpIHtcbiAgICBjb25zdCBjb3B5ID0gbmV3IF9PcmRlcmVkRGljdCh0aGlzKTtcbiAgICBjb3B5Lmluc2VydChpbmRleCwga2V5LCB2YWx1ZSk7XG4gICAgcmV0dXJuIGNvcHk7XG4gIH1cbiAgYmVmb3JlKGtleSkge1xuICAgIGNvbnN0IGluZGV4ID0gdGhpcy4ja2V5cy5pbmRleE9mKGtleSkgLSAxO1xuICAgIGlmIChpbmRleCA8IDApIHtcbiAgICAgIHJldHVybiB2b2lkIDA7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmVudHJ5QXQoaW5kZXgpO1xuICB9XG4gIC8qKlxuICAgKiBTZXRzIGEgbmV3IGtleS12YWx1ZSBwYWlyIGF0IHRoZSBwb3NpdGlvbiBiZWZvcmUgdGhlIGdpdmVuIGtleS5cbiAgICovXG4gIHNldEJlZm9yZShrZXksIG5ld0tleSwgdmFsdWUpIHtcbiAgICBjb25zdCBpbmRleCA9IHRoaXMuI2tleXMuaW5kZXhPZihrZXkpO1xuICAgIGlmIChpbmRleCA9PT0gLTEpIHtcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5pbnNlcnQoaW5kZXgsIG5ld0tleSwgdmFsdWUpO1xuICB9XG4gIGFmdGVyKGtleSkge1xuICAgIGxldCBpbmRleCA9IHRoaXMuI2tleXMuaW5kZXhPZihrZXkpO1xuICAgIGluZGV4ID0gaW5kZXggPT09IC0xIHx8IGluZGV4ID09PSB0aGlzLnNpemUgLSAxID8gLTEgOiBpbmRleCArIDE7XG4gICAgaWYgKGluZGV4ID09PSAtMSkge1xuICAgICAgcmV0dXJuIHZvaWQgMDtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuZW50cnlBdChpbmRleCk7XG4gIH1cbiAgLyoqXG4gICAqIFNldHMgYSBuZXcga2V5LXZhbHVlIHBhaXIgYXQgdGhlIHBvc2l0aW9uIGFmdGVyIHRoZSBnaXZlbiBrZXkuXG4gICAqL1xuICBzZXRBZnRlcihrZXksIG5ld0tleSwgdmFsdWUpIHtcbiAgICBjb25zdCBpbmRleCA9IHRoaXMuI2tleXMuaW5kZXhPZihrZXkpO1xuICAgIGlmIChpbmRleCA9PT0gLTEpIHtcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5pbnNlcnQoaW5kZXggKyAxLCBuZXdLZXksIHZhbHVlKTtcbiAgfVxuICBmaXJzdCgpIHtcbiAgICByZXR1cm4gdGhpcy5lbnRyeUF0KDApO1xuICB9XG4gIGxhc3QoKSB7XG4gICAgcmV0dXJuIHRoaXMuZW50cnlBdCgtMSk7XG4gIH1cbiAgY2xlYXIoKSB7XG4gICAgdGhpcy4ja2V5cyA9IFtdO1xuICAgIHJldHVybiBzdXBlci5jbGVhcigpO1xuICB9XG4gIGRlbGV0ZShrZXkpIHtcbiAgICBjb25zdCBkZWxldGVkID0gc3VwZXIuZGVsZXRlKGtleSk7XG4gICAgaWYgKGRlbGV0ZWQpIHtcbiAgICAgIHRoaXMuI2tleXMuc3BsaWNlKHRoaXMuI2tleXMuaW5kZXhPZihrZXkpLCAxKTtcbiAgICB9XG4gICAgcmV0dXJuIGRlbGV0ZWQ7XG4gIH1cbiAgZGVsZXRlQXQoaW5kZXgpIHtcbiAgICBjb25zdCBrZXkgPSB0aGlzLmtleUF0KGluZGV4KTtcbiAgICBpZiAoa2V5ICE9PSB2b2lkIDApIHtcbiAgICAgIHJldHVybiB0aGlzLmRlbGV0ZShrZXkpO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgYXQoaW5kZXgpIHtcbiAgICBjb25zdCBrZXkgPSBhdCh0aGlzLiNrZXlzLCBpbmRleCk7XG4gICAgaWYgKGtleSAhPT0gdm9pZCAwKSB7XG4gICAgICByZXR1cm4gdGhpcy5nZXQoa2V5KTtcbiAgICB9XG4gIH1cbiAgZW50cnlBdChpbmRleCkge1xuICAgIGNvbnN0IGtleSA9IGF0KHRoaXMuI2tleXMsIGluZGV4KTtcbiAgICBpZiAoa2V5ICE9PSB2b2lkIDApIHtcbiAgICAgIHJldHVybiBba2V5LCB0aGlzLmdldChrZXkpXTtcbiAgICB9XG4gIH1cbiAgaW5kZXhPZihrZXkpIHtcbiAgICByZXR1cm4gdGhpcy4ja2V5cy5pbmRleE9mKGtleSk7XG4gIH1cbiAga2V5QXQoaW5kZXgpIHtcbiAgICByZXR1cm4gYXQodGhpcy4ja2V5cywgaW5kZXgpO1xuICB9XG4gIGZyb20oa2V5LCBvZmZzZXQpIHtcbiAgICBjb25zdCBpbmRleCA9IHRoaXMuaW5kZXhPZihrZXkpO1xuICAgIGlmIChpbmRleCA9PT0gLTEpIHtcbiAgICAgIHJldHVybiB2b2lkIDA7XG4gICAgfVxuICAgIGxldCBkZXN0ID0gaW5kZXggKyBvZmZzZXQ7XG4gICAgaWYgKGRlc3QgPCAwKSBkZXN0ID0gMDtcbiAgICBpZiAoZGVzdCA+PSB0aGlzLnNpemUpIGRlc3QgPSB0aGlzLnNpemUgLSAxO1xuICAgIHJldHVybiB0aGlzLmF0KGRlc3QpO1xuICB9XG4gIGtleUZyb20oa2V5LCBvZmZzZXQpIHtcbiAgICBjb25zdCBpbmRleCA9IHRoaXMuaW5kZXhPZihrZXkpO1xuICAgIGlmIChpbmRleCA9PT0gLTEpIHtcbiAgICAgIHJldHVybiB2b2lkIDA7XG4gICAgfVxuICAgIGxldCBkZXN0ID0gaW5kZXggKyBvZmZzZXQ7XG4gICAgaWYgKGRlc3QgPCAwKSBkZXN0ID0gMDtcbiAgICBpZiAoZGVzdCA+PSB0aGlzLnNpemUpIGRlc3QgPSB0aGlzLnNpemUgLSAxO1xuICAgIHJldHVybiB0aGlzLmtleUF0KGRlc3QpO1xuICB9XG4gIGZpbmQocHJlZGljYXRlLCB0aGlzQXJnKSB7XG4gICAgbGV0IGluZGV4ID0gMDtcbiAgICBmb3IgKGNvbnN0IGVudHJ5IG9mIHRoaXMpIHtcbiAgICAgIGlmIChSZWZsZWN0LmFwcGx5KHByZWRpY2F0ZSwgdGhpc0FyZywgW2VudHJ5LCBpbmRleCwgdGhpc10pKSB7XG4gICAgICAgIHJldHVybiBlbnRyeTtcbiAgICAgIH1cbiAgICAgIGluZGV4Kys7XG4gICAgfVxuICAgIHJldHVybiB2b2lkIDA7XG4gIH1cbiAgZmluZEluZGV4KHByZWRpY2F0ZSwgdGhpc0FyZykge1xuICAgIGxldCBpbmRleCA9IDA7XG4gICAgZm9yIChjb25zdCBlbnRyeSBvZiB0aGlzKSB7XG4gICAgICBpZiAoUmVmbGVjdC5hcHBseShwcmVkaWNhdGUsIHRoaXNBcmcsIFtlbnRyeSwgaW5kZXgsIHRoaXNdKSkge1xuICAgICAgICByZXR1cm4gaW5kZXg7XG4gICAgICB9XG4gICAgICBpbmRleCsrO1xuICAgIH1cbiAgICByZXR1cm4gLTE7XG4gIH1cbiAgZmlsdGVyKHByZWRpY2F0ZSwgdGhpc0FyZykge1xuICAgIGNvbnN0IGVudHJpZXMgPSBbXTtcbiAgICBsZXQgaW5kZXggPSAwO1xuICAgIGZvciAoY29uc3QgZW50cnkgb2YgdGhpcykge1xuICAgICAgaWYgKFJlZmxlY3QuYXBwbHkocHJlZGljYXRlLCB0aGlzQXJnLCBbZW50cnksIGluZGV4LCB0aGlzXSkpIHtcbiAgICAgICAgZW50cmllcy5wdXNoKGVudHJ5KTtcbiAgICAgIH1cbiAgICAgIGluZGV4Kys7XG4gICAgfVxuICAgIHJldHVybiBuZXcgX09yZGVyZWREaWN0KGVudHJpZXMpO1xuICB9XG4gIG1hcChjYWxsYmFja2ZuLCB0aGlzQXJnKSB7XG4gICAgY29uc3QgZW50cmllcyA9IFtdO1xuICAgIGxldCBpbmRleCA9IDA7XG4gICAgZm9yIChjb25zdCBlbnRyeSBvZiB0aGlzKSB7XG4gICAgICBlbnRyaWVzLnB1c2goW2VudHJ5WzBdLCBSZWZsZWN0LmFwcGx5KGNhbGxiYWNrZm4sIHRoaXNBcmcsIFtlbnRyeSwgaW5kZXgsIHRoaXNdKV0pO1xuICAgICAgaW5kZXgrKztcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBfT3JkZXJlZERpY3QoZW50cmllcyk7XG4gIH1cbiAgcmVkdWNlKC4uLmFyZ3MpIHtcbiAgICBjb25zdCBbY2FsbGJhY2tmbiwgaW5pdGlhbFZhbHVlXSA9IGFyZ3M7XG4gICAgbGV0IGluZGV4ID0gMDtcbiAgICBsZXQgYWNjdW11bGF0b3IgPSBpbml0aWFsVmFsdWUgPz8gdGhpcy5hdCgwKTtcbiAgICBmb3IgKGNvbnN0IGVudHJ5IG9mIHRoaXMpIHtcbiAgICAgIGlmIChpbmRleCA9PT0gMCAmJiBhcmdzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICBhY2N1bXVsYXRvciA9IGVudHJ5O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYWNjdW11bGF0b3IgPSBSZWZsZWN0LmFwcGx5KGNhbGxiYWNrZm4sIHRoaXMsIFthY2N1bXVsYXRvciwgZW50cnksIGluZGV4LCB0aGlzXSk7XG4gICAgICB9XG4gICAgICBpbmRleCsrO1xuICAgIH1cbiAgICByZXR1cm4gYWNjdW11bGF0b3I7XG4gIH1cbiAgcmVkdWNlUmlnaHQoLi4uYXJncykge1xuICAgIGNvbnN0IFtjYWxsYmFja2ZuLCBpbml0aWFsVmFsdWVdID0gYXJncztcbiAgICBsZXQgYWNjdW11bGF0b3IgPSBpbml0aWFsVmFsdWUgPz8gdGhpcy5hdCgtMSk7XG4gICAgZm9yIChsZXQgaW5kZXggPSB0aGlzLnNpemUgLSAxOyBpbmRleCA+PSAwOyBpbmRleC0tKSB7XG4gICAgICBjb25zdCBlbnRyeSA9IHRoaXMuYXQoaW5kZXgpO1xuICAgICAgaWYgKGluZGV4ID09PSB0aGlzLnNpemUgLSAxICYmIGFyZ3MubGVuZ3RoID09PSAxKSB7XG4gICAgICAgIGFjY3VtdWxhdG9yID0gZW50cnk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhY2N1bXVsYXRvciA9IFJlZmxlY3QuYXBwbHkoY2FsbGJhY2tmbiwgdGhpcywgW2FjY3VtdWxhdG9yLCBlbnRyeSwgaW5kZXgsIHRoaXNdKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGFjY3VtdWxhdG9yO1xuICB9XG4gIHRvU29ydGVkKGNvbXBhcmVGbikge1xuICAgIGNvbnN0IGVudHJpZXMgPSBbLi4udGhpcy5lbnRyaWVzKCldLnNvcnQoY29tcGFyZUZuKTtcbiAgICByZXR1cm4gbmV3IF9PcmRlcmVkRGljdChlbnRyaWVzKTtcbiAgfVxuICB0b1JldmVyc2VkKCkge1xuICAgIGNvbnN0IHJldmVyc2VkID0gbmV3IF9PcmRlcmVkRGljdCgpO1xuICAgIGZvciAobGV0IGluZGV4ID0gdGhpcy5zaXplIC0gMTsgaW5kZXggPj0gMDsgaW5kZXgtLSkge1xuICAgICAgY29uc3Qga2V5ID0gdGhpcy5rZXlBdChpbmRleCk7XG4gICAgICBjb25zdCBlbGVtZW50ID0gdGhpcy5nZXQoa2V5KTtcbiAgICAgIHJldmVyc2VkLnNldChrZXksIGVsZW1lbnQpO1xuICAgIH1cbiAgICByZXR1cm4gcmV2ZXJzZWQ7XG4gIH1cbiAgdG9TcGxpY2VkKC4uLmFyZ3MpIHtcbiAgICBjb25zdCBlbnRyaWVzID0gWy4uLnRoaXMuZW50cmllcygpXTtcbiAgICBlbnRyaWVzLnNwbGljZSguLi5hcmdzKTtcbiAgICByZXR1cm4gbmV3IF9PcmRlcmVkRGljdChlbnRyaWVzKTtcbiAgfVxuICBzbGljZShzdGFydCwgZW5kKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gbmV3IF9PcmRlcmVkRGljdCgpO1xuICAgIGxldCBzdG9wID0gdGhpcy5zaXplIC0gMTtcbiAgICBpZiAoc3RhcnQgPT09IHZvaWQgMCkge1xuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgaWYgKHN0YXJ0IDwgMCkge1xuICAgICAgc3RhcnQgPSBzdGFydCArIHRoaXMuc2l6ZTtcbiAgICB9XG4gICAgaWYgKGVuZCAhPT0gdm9pZCAwICYmIGVuZCA+IDApIHtcbiAgICAgIHN0b3AgPSBlbmQgLSAxO1xuICAgIH1cbiAgICBmb3IgKGxldCBpbmRleCA9IHN0YXJ0OyBpbmRleCA8PSBzdG9wOyBpbmRleCsrKSB7XG4gICAgICBjb25zdCBrZXkgPSB0aGlzLmtleUF0KGluZGV4KTtcbiAgICAgIGNvbnN0IGVsZW1lbnQgPSB0aGlzLmdldChrZXkpO1xuICAgICAgcmVzdWx0LnNldChrZXksIGVsZW1lbnQpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG4gIGV2ZXJ5KHByZWRpY2F0ZSwgdGhpc0FyZykge1xuICAgIGxldCBpbmRleCA9IDA7XG4gICAgZm9yIChjb25zdCBlbnRyeSBvZiB0aGlzKSB7XG4gICAgICBpZiAoIVJlZmxlY3QuYXBwbHkocHJlZGljYXRlLCB0aGlzQXJnLCBbZW50cnksIGluZGV4LCB0aGlzXSkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgaW5kZXgrKztcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgc29tZShwcmVkaWNhdGUsIHRoaXNBcmcpIHtcbiAgICBsZXQgaW5kZXggPSAwO1xuICAgIGZvciAoY29uc3QgZW50cnkgb2YgdGhpcykge1xuICAgICAgaWYgKFJlZmxlY3QuYXBwbHkocHJlZGljYXRlLCB0aGlzQXJnLCBbZW50cnksIGluZGV4LCB0aGlzXSkpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBpbmRleCsrO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn07XG5mdW5jdGlvbiBhdChhcnJheSwgaW5kZXgpIHtcbiAgaWYgKFwiYXRcIiBpbiBBcnJheS5wcm90b3R5cGUpIHtcbiAgICByZXR1cm4gQXJyYXkucHJvdG90eXBlLmF0LmNhbGwoYXJyYXksIGluZGV4KTtcbiAgfVxuICBjb25zdCBhY3R1YWxJbmRleCA9IHRvU2FmZUluZGV4KGFycmF5LCBpbmRleCk7XG4gIHJldHVybiBhY3R1YWxJbmRleCA9PT0gLTEgPyB2b2lkIDAgOiBhcnJheVthY3R1YWxJbmRleF07XG59XG5fX25hbWUoYXQsIFwiYXRcIik7XG5mdW5jdGlvbiB0b1NhZmVJbmRleChhcnJheSwgaW5kZXgpIHtcbiAgY29uc3QgbGVuZ3RoID0gYXJyYXkubGVuZ3RoO1xuICBjb25zdCByZWxhdGl2ZUluZGV4ID0gdG9TYWZlSW50ZWdlcihpbmRleCk7XG4gIGNvbnN0IGFjdHVhbEluZGV4ID0gcmVsYXRpdmVJbmRleCA+PSAwID8gcmVsYXRpdmVJbmRleCA6IGxlbmd0aCArIHJlbGF0aXZlSW5kZXg7XG4gIHJldHVybiBhY3R1YWxJbmRleCA8IDAgfHwgYWN0dWFsSW5kZXggPj0gbGVuZ3RoID8gLTEgOiBhY3R1YWxJbmRleDtcbn1cbl9fbmFtZSh0b1NhZmVJbmRleCwgXCJ0b1NhZmVJbmRleFwiKTtcbmZ1bmN0aW9uIHRvU2FmZUludGVnZXIobnVtYmVyKSB7XG4gIHJldHVybiBudW1iZXIgIT09IG51bWJlciB8fCBudW1iZXIgPT09IDAgPyAwIDogTWF0aC50cnVuYyhudW1iZXIpO1xufVxuX19uYW1lKHRvU2FmZUludGVnZXIsIFwidG9TYWZlSW50ZWdlclwiKTtcblxuLy8gc3JjL2NvbGxlY3Rpb24udHN4XG5pbXBvcnQgeyBqc3ggYXMganN4MiB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIGNyZWF0ZUNvbGxlY3Rpb24yKG5hbWUpIHtcbiAgY29uc3QgUFJPVklERVJfTkFNRSA9IG5hbWUgKyBcIkNvbGxlY3Rpb25Qcm92aWRlclwiO1xuICBjb25zdCBbY3JlYXRlQ29sbGVjdGlvbkNvbnRleHQsIGNyZWF0ZUNvbGxlY3Rpb25TY29wZV0gPSBjcmVhdGVDb250ZXh0U2NvcGUyKFBST1ZJREVSX05BTUUpO1xuICBjb25zdCBbQ29sbGVjdGlvbkNvbnRleHRQcm92aWRlciwgdXNlQ29sbGVjdGlvbkNvbnRleHRdID0gY3JlYXRlQ29sbGVjdGlvbkNvbnRleHQoXG4gICAgUFJPVklERVJfTkFNRSxcbiAgICB7XG4gICAgICBjb2xsZWN0aW9uRWxlbWVudDogbnVsbCxcbiAgICAgIGNvbGxlY3Rpb25SZWY6IHsgY3VycmVudDogbnVsbCB9LFxuICAgICAgY29sbGVjdGlvblJlZk9iamVjdDogeyBjdXJyZW50OiBudWxsIH0sXG4gICAgICBpdGVtTWFwOiBuZXcgT3JkZXJlZERpY3QoKSxcbiAgICAgIHNldEl0ZW1NYXA6IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKCkgPT4gdm9pZCAwLCBcInNldEl0ZW1NYXBcIilcbiAgICB9XG4gICk7XG4gIGNvbnN0IENvbGxlY3Rpb25Qcm92aWRlciA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKHsgc3RhdGUsIC4uLnByb3BzIH0pID0+IHtcbiAgICByZXR1cm4gc3RhdGUgPyAvKiBAX19QVVJFX18gKi8ganN4MihDb2xsZWN0aW9uUHJvdmlkZXJJbXBsLCB7IC4uLnByb3BzLCBzdGF0ZSB9KSA6IC8qIEBfX1BVUkVfXyAqLyBqc3gyKENvbGxlY3Rpb25Jbml0LCB7IC4uLnByb3BzIH0pO1xuICB9LCBcIkNvbGxlY3Rpb25Qcm92aWRlclwiKTtcbiAgQ29sbGVjdGlvblByb3ZpZGVyLmRpc3BsYXlOYW1lID0gUFJPVklERVJfTkFNRTtcbiAgY29uc3QgQ29sbGVjdGlvbkluaXQgPSAvKiBAX19QVVJFX18gKi8gX19uYW1lKChwcm9wcykgPT4ge1xuICAgIGNvbnN0IHN0YXRlID0gdXNlSW5pdENvbGxlY3Rpb24oKTtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeDIoQ29sbGVjdGlvblByb3ZpZGVySW1wbCwgeyAuLi5wcm9wcywgc3RhdGUgfSk7XG4gIH0sIFwiQ29sbGVjdGlvbkluaXRcIik7XG4gIENvbGxlY3Rpb25Jbml0LmRpc3BsYXlOYW1lID0gUFJPVklERVJfTkFNRSArIFwiSW5pdFwiO1xuICBjb25zdCBDb2xsZWN0aW9uUHJvdmlkZXJJbXBsID0gLyogQF9fUFVSRV9fICovIF9fbmFtZSgocHJvcHMpID0+IHtcbiAgICBjb25zdCB7IHNjb3BlLCBjaGlsZHJlbiwgc3RhdGUgfSA9IHByb3BzO1xuICAgIGNvbnN0IHJlZiA9IFJlYWN0Mi51c2VSZWYobnVsbCk7XG4gICAgY29uc3QgW2NvbGxlY3Rpb25FbGVtZW50LCBzZXRDb2xsZWN0aW9uRWxlbWVudF0gPSBSZWFjdDIudXNlU3RhdGUoXG4gICAgICBudWxsXG4gICAgKTtcbiAgICBjb25zdCBjb21wb3NlUmVmcyA9IHVzZUNvbXBvc2VkUmVmczIocmVmLCBzZXRDb2xsZWN0aW9uRWxlbWVudCk7XG4gICAgY29uc3QgW2l0ZW1NYXAsIHNldEl0ZW1NYXBdID0gc3RhdGU7XG4gICAgUmVhY3QyLnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICBpZiAoIWNvbGxlY3Rpb25FbGVtZW50KSByZXR1cm47XG4gICAgICBjb25zdCBvYnNlcnZlciA9IGdldENoaWxkTGlzdE9ic2VydmVyKCgpID0+IHtcbiAgICAgIH0pO1xuICAgICAgb2JzZXJ2ZXIub2JzZXJ2ZShjb2xsZWN0aW9uRWxlbWVudCwge1xuICAgICAgICBjaGlsZExpc3Q6IHRydWUsXG4gICAgICAgIHN1YnRyZWU6IHRydWVcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgfTtcbiAgICB9LCBbY29sbGVjdGlvbkVsZW1lbnRdKTtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeDIoXG4gICAgICBDb2xsZWN0aW9uQ29udGV4dFByb3ZpZGVyLFxuICAgICAge1xuICAgICAgICBzY29wZSxcbiAgICAgICAgaXRlbU1hcCxcbiAgICAgICAgc2V0SXRlbU1hcCxcbiAgICAgICAgY29sbGVjdGlvblJlZjogY29tcG9zZVJlZnMsXG4gICAgICAgIGNvbGxlY3Rpb25SZWZPYmplY3Q6IHJlZixcbiAgICAgICAgY29sbGVjdGlvbkVsZW1lbnQsXG4gICAgICAgIGNoaWxkcmVuXG4gICAgICB9XG4gICAgKTtcbiAgfSwgXCJDb2xsZWN0aW9uUHJvdmlkZXJJbXBsXCIpO1xuICBDb2xsZWN0aW9uUHJvdmlkZXJJbXBsLmRpc3BsYXlOYW1lID0gUFJPVklERVJfTkFNRSArIFwiSW1wbFwiO1xuICBjb25zdCBDT0xMRUNUSU9OX1NMT1RfTkFNRSA9IG5hbWUgKyBcIkNvbGxlY3Rpb25TbG90XCI7XG4gIGNvbnN0IENvbGxlY3Rpb25TbG90SW1wbCA9IGNyZWF0ZVNsb3QyKENPTExFQ1RJT05fU0xPVF9OQU1FKTtcbiAgY29uc3QgQ29sbGVjdGlvblNsb3QgPSBSZWFjdDIuZm9yd2FyZFJlZihcbiAgICAocHJvcHMsIGZvcndhcmRlZFJlZikgPT4ge1xuICAgICAgY29uc3QgeyBzY29wZSwgY2hpbGRyZW4gfSA9IHByb3BzO1xuICAgICAgY29uc3QgY29udGV4dCA9IHVzZUNvbGxlY3Rpb25Db250ZXh0KENPTExFQ1RJT05fU0xPVF9OQU1FLCBzY29wZSk7XG4gICAgICBjb25zdCBjb21wb3NlZFJlZnMgPSB1c2VDb21wb3NlZFJlZnMyKGZvcndhcmRlZFJlZiwgY29udGV4dC5jb2xsZWN0aW9uUmVmKTtcbiAgICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4MihDb2xsZWN0aW9uU2xvdEltcGwsIHsgcmVmOiBjb21wb3NlZFJlZnMsIGNoaWxkcmVuIH0pO1xuICAgIH1cbiAgKTtcbiAgQ29sbGVjdGlvblNsb3QuZGlzcGxheU5hbWUgPSBDT0xMRUNUSU9OX1NMT1RfTkFNRTtcbiAgY29uc3QgSVRFTV9TTE9UX05BTUUgPSBuYW1lICsgXCJDb2xsZWN0aW9uSXRlbVNsb3RcIjtcbiAgY29uc3QgSVRFTV9EQVRBX0FUVFIgPSBcImRhdGEtcmFkaXgtY29sbGVjdGlvbi1pdGVtXCI7XG4gIGNvbnN0IENvbGxlY3Rpb25JdGVtU2xvdEltcGwgPSBjcmVhdGVTbG90MihJVEVNX1NMT1RfTkFNRSk7XG4gIGNvbnN0IENvbGxlY3Rpb25JdGVtU2xvdCA9IFJlYWN0Mi5mb3J3YXJkUmVmKFxuICAgIChwcm9wcywgZm9yd2FyZGVkUmVmKSA9PiB7XG4gICAgICBjb25zdCB7IHNjb3BlLCBjaGlsZHJlbiwgLi4uaXRlbURhdGEgfSA9IHByb3BzO1xuICAgICAgY29uc3QgcmVmID0gUmVhY3QyLnVzZVJlZihudWxsKTtcbiAgICAgIGNvbnN0IFtlbGVtZW50LCBzZXRFbGVtZW50XSA9IFJlYWN0Mi51c2VTdGF0ZShudWxsKTtcbiAgICAgIGNvbnN0IGNvbXBvc2VkUmVmcyA9IHVzZUNvbXBvc2VkUmVmczIoZm9yd2FyZGVkUmVmLCByZWYsIHNldEVsZW1lbnQpO1xuICAgICAgY29uc3QgY29udGV4dCA9IHVzZUNvbGxlY3Rpb25Db250ZXh0KElURU1fU0xPVF9OQU1FLCBzY29wZSk7XG4gICAgICBjb25zdCB7IHNldEl0ZW1NYXAgfSA9IGNvbnRleHQ7XG4gICAgICBjb25zdCBpdGVtRGF0YVJlZiA9IFJlYWN0Mi51c2VSZWYoaXRlbURhdGEpO1xuICAgICAgaWYgKCFzaGFsbG93RXF1YWwoaXRlbURhdGFSZWYuY3VycmVudCwgaXRlbURhdGEpKSB7XG4gICAgICAgIGl0ZW1EYXRhUmVmLmN1cnJlbnQgPSBpdGVtRGF0YTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG1lbW9pemVkSXRlbURhdGEgPSBpdGVtRGF0YVJlZi5jdXJyZW50O1xuICAgICAgUmVhY3QyLnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGl0ZW1EYXRhMiA9IG1lbW9pemVkSXRlbURhdGE7XG4gICAgICAgIHNldEl0ZW1NYXAoKG1hcCkgPT4ge1xuICAgICAgICAgIGlmICghZWxlbWVudCkge1xuICAgICAgICAgICAgcmV0dXJuIG1hcDtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKCFtYXAuaGFzKGVsZW1lbnQpKSB7XG4gICAgICAgICAgICBtYXAuc2V0KGVsZW1lbnQsIHsgLi4uaXRlbURhdGEyLCBlbGVtZW50IH0pO1xuICAgICAgICAgICAgcmV0dXJuIG1hcC50b1NvcnRlZChzb3J0QnlEb2N1bWVudFBvc2l0aW9uKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIG1hcC5zZXQoZWxlbWVudCwgeyAuLi5pdGVtRGF0YTIsIGVsZW1lbnQgfSkudG9Tb3J0ZWQoc29ydEJ5RG9jdW1lbnRQb3NpdGlvbik7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgIHNldEl0ZW1NYXAoKG1hcCkgPT4ge1xuICAgICAgICAgICAgaWYgKCFlbGVtZW50IHx8ICFtYXAuaGFzKGVsZW1lbnQpKSB7XG4gICAgICAgICAgICAgIHJldHVybiBtYXA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtYXAuZGVsZXRlKGVsZW1lbnQpO1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBPcmRlcmVkRGljdChtYXApO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9O1xuICAgICAgfSwgW2VsZW1lbnQsIG1lbW9pemVkSXRlbURhdGEsIHNldEl0ZW1NYXBdKTtcbiAgICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4MihDb2xsZWN0aW9uSXRlbVNsb3RJbXBsLCB7IC4uLnsgW0lURU1fREFUQV9BVFRSXTogXCJcIiB9LCByZWY6IGNvbXBvc2VkUmVmcywgY2hpbGRyZW4gfSk7XG4gICAgfVxuICApO1xuICBDb2xsZWN0aW9uSXRlbVNsb3QuZGlzcGxheU5hbWUgPSBJVEVNX1NMT1RfTkFNRTtcbiAgZnVuY3Rpb24gdXNlSW5pdENvbGxlY3Rpb24oKSB7XG4gICAgcmV0dXJuIFJlYWN0Mi51c2VTdGF0ZShuZXcgT3JkZXJlZERpY3QoKSk7XG4gIH1cbiAgX19uYW1lKHVzZUluaXRDb2xsZWN0aW9uLCBcInVzZUluaXRDb2xsZWN0aW9uXCIpO1xuICBmdW5jdGlvbiB1c2VDb2xsZWN0aW9uKHNjb3BlKSB7XG4gICAgY29uc3QgeyBpdGVtTWFwIH0gPSB1c2VDb2xsZWN0aW9uQ29udGV4dChuYW1lICsgXCJDb2xsZWN0aW9uQ29uc3VtZXJcIiwgc2NvcGUpO1xuICAgIHJldHVybiBpdGVtTWFwO1xuICB9XG4gIF9fbmFtZSh1c2VDb2xsZWN0aW9uLCBcInVzZUNvbGxlY3Rpb25cIik7XG4gIGNvbnN0IGZ1bmN0aW9ucyA9IHtcbiAgICBjcmVhdGVDb2xsZWN0aW9uU2NvcGUsXG4gICAgdXNlQ29sbGVjdGlvbixcbiAgICB1c2VJbml0Q29sbGVjdGlvblxuICB9O1xuICByZXR1cm4gW1xuICAgIHsgUHJvdmlkZXI6IENvbGxlY3Rpb25Qcm92aWRlciwgU2xvdDogQ29sbGVjdGlvblNsb3QsIEl0ZW1TbG90OiBDb2xsZWN0aW9uSXRlbVNsb3QgfSxcbiAgICBmdW5jdGlvbnNcbiAgXTtcbn1cbl9fbmFtZShjcmVhdGVDb2xsZWN0aW9uMiwgXCJjcmVhdGVDb2xsZWN0aW9uXCIpO1xuZnVuY3Rpb24gc2hhbGxvd0VxdWFsKGEsIGIpIHtcbiAgaWYgKGEgPT09IGIpIHJldHVybiB0cnVlO1xuICBpZiAodHlwZW9mIGEgIT09IFwib2JqZWN0XCIgfHwgdHlwZW9mIGIgIT09IFwib2JqZWN0XCIpIHJldHVybiBmYWxzZTtcbiAgaWYgKGEgPT0gbnVsbCB8fCBiID09IG51bGwpIHJldHVybiBmYWxzZTtcbiAgY29uc3Qga2V5c0EgPSBPYmplY3Qua2V5cyhhKTtcbiAgY29uc3Qga2V5c0IgPSBPYmplY3Qua2V5cyhiKTtcbiAgaWYgKGtleXNBLmxlbmd0aCAhPT0ga2V5c0IubGVuZ3RoKSByZXR1cm4gZmFsc2U7XG4gIGZvciAoY29uc3Qga2V5IG9mIGtleXNBKSB7XG4gICAgaWYgKCFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoYiwga2V5KSkgcmV0dXJuIGZhbHNlO1xuICAgIGlmIChhW2tleV0gIT09IGJba2V5XSkgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB0cnVlO1xufVxuX19uYW1lKHNoYWxsb3dFcXVhbCwgXCJzaGFsbG93RXF1YWxcIik7XG5mdW5jdGlvbiBpc0VsZW1lbnRQcmVjZWRpbmcoYSwgYikge1xuICByZXR1cm4gISEoYi5jb21wYXJlRG9jdW1lbnRQb3NpdGlvbihhKSAmIE5vZGUuRE9DVU1FTlRfUE9TSVRJT05fUFJFQ0VESU5HKTtcbn1cbl9fbmFtZShpc0VsZW1lbnRQcmVjZWRpbmcsIFwiaXNFbGVtZW50UHJlY2VkaW5nXCIpO1xuZnVuY3Rpb24gc29ydEJ5RG9jdW1lbnRQb3NpdGlvbihhLCBiKSB7XG4gIHJldHVybiAhYVsxXS5lbGVtZW50IHx8ICFiWzFdLmVsZW1lbnQgPyAwIDogaXNFbGVtZW50UHJlY2VkaW5nKGFbMV0uZWxlbWVudCwgYlsxXS5lbGVtZW50KSA/IC0xIDogMTtcbn1cbl9fbmFtZShzb3J0QnlEb2N1bWVudFBvc2l0aW9uLCBcInNvcnRCeURvY3VtZW50UG9zaXRpb25cIik7XG5mdW5jdGlvbiBnZXRDaGlsZExpc3RPYnNlcnZlcihjYWxsYmFjaykge1xuICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKChtdXRhdGlvbnNMaXN0KSA9PiB7XG4gICAgZm9yIChjb25zdCBtdXRhdGlvbiBvZiBtdXRhdGlvbnNMaXN0KSB7XG4gICAgICBpZiAobXV0YXRpb24udHlwZSA9PT0gXCJjaGlsZExpc3RcIikge1xuICAgICAgICBjYWxsYmFjaygpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIG9ic2VydmVyO1xufVxuX19uYW1lKGdldENoaWxkTGlzdE9ic2VydmVyLCBcImdldENoaWxkTGlzdE9ic2VydmVyXCIpO1xuZXhwb3J0IHtcbiAgY3JlYXRlQ29sbGVjdGlvbixcbiAgY3JlYXRlQ29sbGVjdGlvbjIgYXMgdW5zdGFibGVfY3JlYXRlQ29sbGVjdGlvblxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4Lm1qcy5tYXBcbiIsIlwidXNlIGNsaWVudFwiO1xudmFyIF9fZGVmUHJvcCA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX25hbWUgPSAodGFyZ2V0LCB2YWx1ZSkgPT4gX19kZWZQcm9wKHRhcmdldCwgXCJuYW1lXCIsIHsgdmFsdWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSB9KTtcblxuLy8gc3JjL2RpcmVjdGlvbi50c3hcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG52YXIgRGlyZWN0aW9uQ29udGV4dCA9IFJlYWN0LmNyZWF0ZUNvbnRleHQodm9pZCAwKTtcbnZhciBEaXJlY3Rpb25Qcm92aWRlciA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKHByb3BzKSA9PiB7XG4gIGNvbnN0IHsgZGlyLCBjaGlsZHJlbiB9ID0gcHJvcHM7XG4gIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KERpcmVjdGlvbkNvbnRleHQuUHJvdmlkZXIsIHsgdmFsdWU6IGRpciwgY2hpbGRyZW4gfSk7XG59LCBcIkRpcmVjdGlvblByb3ZpZGVyXCIpO1xuZnVuY3Rpb24gdXNlRGlyZWN0aW9uKGxvY2FsRGlyKSB7XG4gIGNvbnN0IGdsb2JhbERpciA9IFJlYWN0LnVzZUNvbnRleHQoRGlyZWN0aW9uQ29udGV4dCk7XG4gIHJldHVybiBsb2NhbERpciB8fCBnbG9iYWxEaXIgfHwgXCJsdHJcIjtcbn1cbl9fbmFtZSh1c2VEaXJlY3Rpb24sIFwidXNlRGlyZWN0aW9uXCIpO1xudmFyIFByb3ZpZGVyID0gRGlyZWN0aW9uUHJvdmlkZXI7XG5leHBvcnQge1xuICBEaXJlY3Rpb25Qcm92aWRlcixcbiAgUHJvdmlkZXIsXG4gIHVzZURpcmVjdGlvblxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4Lm1qcy5tYXBcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFDQSxJQUFJQSxjQUFZLE9BQU87QUFDdkIsSUFBSUMsWUFBVSxRQUFRLFVBQVVELFlBQVUsUUFBUSxRQUFRO0NBQUU7Q0FBTyxjQUFjO0FBQUssQ0FBQzs7QUFTdkYsU0FBUyxpQkFBaUIsTUFBTTtDQUM5QixNQUFNLGdCQUFnQixPQUFPO0NBQzdCLE1BQU0sQ0FBQyx5QkFBeUIseUJBQXlCLG1CQUFtQixhQUFhO0NBQ3pGLE1BQU0sQ0FBQyx3QkFBd0Isd0JBQXdCLHdCQUNyRCxlQUNBO0VBQUUsZUFBZSxFQUFFLFNBQVMsS0FBSztFQUFHLHlCQUF5QixJQUFJLElBQUk7Q0FBRSxDQUN6RTtDQUNBLE1BQU0scUJBQXFDLDBCQUFRLFVBQVU7RUFDM0QsTUFBTSxFQUFFLE9BQU8sYUFBYTtFQUM1QixNQUFNLE1BQUEsYUFBWSxPQUFPLElBQUk7RUFDN0IsTUFBTSxVQUFBLGFBQWdCLHVCQUF1QixJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7RUFDeEQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksd0JBQXdCO0dBQUU7R0FBTztHQUFTLGVBQWU7R0FBSztFQUFTLENBQUM7Q0FDckcsR0FBRyxvQkFBb0I7Q0FDdkIsbUJBQW1CLGNBQWM7Q0FDakMsTUFBTSx1QkFBdUIsT0FBTztDQUNwQyxNQUFNLHFCQUFxQixXQUFXLG9CQUFvQjtDQUMxRCxNQUFNLGlCQUFBLGFBQXVCLFlBQzFCLE9BQU8saUJBQWlCO0VBQ3ZCLE1BQU0sRUFBRSxPQUFPLGFBQWE7RUFDNUIsTUFBTSxVQUFVLHFCQUFxQixzQkFBc0IsS0FBSztFQUNoRSxNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsUUFBUSxhQUFhO0VBQ3hFLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLG9CQUFvQjtHQUFFLEtBQUs7R0FBYztFQUFTLENBQUM7Q0FDaEYsQ0FDRjtDQUNBLGVBQWUsY0FBYztDQUM3QixNQUFNLGlCQUFpQixPQUFPO0NBQzlCLE1BQU0saUJBQWlCO0NBQ3ZCLE1BQU0seUJBQXlCLFdBQVcsY0FBYztDQUN4RCxNQUFNLHFCQUFBLGFBQTJCLFlBQzlCLE9BQU8saUJBQWlCO0VBQ3ZCLE1BQU0sRUFBRSxPQUFPLFVBQVUsR0FBRyxhQUFhO0VBQ3pDLE1BQU0sTUFBQSxhQUFZLE9BQU8sSUFBSTtFQUM3QixNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsR0FBRztFQUN0RCxNQUFNLFVBQVUscUJBQXFCLGdCQUFnQixLQUFLO0VBQzFELGFBQU0sZ0JBQWdCO0dBQ3BCLFFBQVEsUUFBUSxJQUFJLEtBQUs7SUFBRTtJQUFLLEdBQUc7R0FBUyxDQUFDO0dBQzdDLGFBQWEsS0FBSyxRQUFRLFFBQVEsT0FBTyxHQUFHO0VBQzlDLENBQUM7RUFDRCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSx3QkFBd0I7SUFBUSxpQkFBaUI7R0FBTSxLQUFLO0dBQWM7RUFBUyxDQUFDO0NBQ2pILENBQ0Y7Q0FDQSxtQkFBbUIsY0FBYztDQUNqQyxTQUFTLGNBQWMsT0FBTztFQUM1QixNQUFNLFVBQVUscUJBQXFCLE9BQU8sc0JBQXNCLEtBQUs7RUFXdkUsT0FBQSxhQVZ1QixrQkFBa0I7R0FDdkMsTUFBTSxpQkFBaUIsUUFBUSxjQUFjO0dBQzdDLElBQUksQ0FBQyxnQkFBZ0IsT0FBTyxDQUFDO0dBQzdCLE1BQU0sZUFBZSxNQUFNLEtBQUssZUFBZSxpQkFBaUIsSUFBSSxlQUFlLEVBQUUsQ0FBQztHQUt0RixPQUpjLE1BQU0sS0FBSyxRQUFRLFFBQVEsT0FBTyxDQUN2QixDQUFDLENBQUMsTUFDeEIsR0FBRyxNQUFNLGFBQWEsUUFBUSxFQUFFLElBQUksT0FBTyxJQUFJLGFBQWEsUUFBUSxFQUFFLElBQUksT0FBTyxDQUVsRTtFQUNwQixHQUFHLENBQUMsUUFBUSxlQUFlLFFBQVEsT0FBTyxDQUM1QjtDQUNoQjtDQUNBLFNBQU8sZUFBZSxlQUFlO0NBQ3JDLE9BQU87RUFDTDtHQUFFLFVBQVU7R0FBb0IsTUFBTTtHQUFnQixVQUFVO0VBQW1CO0VBQ25GO0VBQ0E7Q0FDRjtBQUNGO0FBQ0FDLFNBQU8sa0JBQWtCLGtCQUFrQjtBQVMzQyxJQUFJLGlDQUFpQyxJQUFJLFFBQVE7QUFDakQsSUFBSSxjQUFjLE1BQU0scUJBQXFCLElBQUk7Q0FDL0M7RUFDRSxTQUFPLE1BQU0sYUFBYTtDQUM1QjtDQUNBO0NBQ0EsWUFBWSxTQUFTO0VBQ25CLE1BQU0sT0FBTztFQUNiLEtBQUssUUFBUSxDQUFDLEdBQUcsTUFBTSxLQUFLLENBQUM7RUFDN0IsZUFBZSxJQUFJLE1BQU0sSUFBSTtDQUMvQjtDQUNBLElBQUksS0FBSyxPQUFPO0VBQ2QsSUFBSSxlQUFlLElBQUksSUFBSSxHQUFHO0dBQzVCLElBQUksS0FBSyxJQUFJLEdBQUcsR0FDZCxLQUFLLE1BQU0sS0FBSyxNQUFNLFFBQVEsR0FBRyxLQUFLO1FBRXRDLEtBQUssTUFBTSxLQUFLLEdBQUc7RUFFdkI7RUFDQSxNQUFNLElBQUksS0FBSyxLQUFLO0VBQ3BCLE9BQU87Q0FDVDtDQUNBLE9BQU8sT0FBTyxLQUFLLE9BQU87RUFDeEIsTUFBTSxNQUFNLEtBQUssSUFBSSxHQUFHO0VBQ3hCLE1BQU0sU0FBUyxLQUFLLE1BQU07RUFDMUIsTUFBTSxnQkFBZ0IsY0FBYyxLQUFLO0VBQ3pDLElBQUksY0FBYyxpQkFBaUIsSUFBSSxnQkFBZ0IsU0FBUztFQUNoRSxNQUFNLFlBQVksY0FBYyxLQUFLLGVBQWUsU0FBUyxLQUFLO0VBQ2xFLElBQUksY0FBYyxLQUFLLFFBQVEsT0FBTyxjQUFjLEtBQUssT0FBTyxLQUFLLGNBQWMsSUFBSTtHQUNyRixLQUFLLElBQUksS0FBSyxLQUFLO0dBQ25CLE9BQU87RUFDVDtFQUNBLE1BQU0sT0FBTyxLQUFLLFFBQVEsTUFBTSxJQUFJO0VBQ3BDLElBQUksZ0JBQWdCLEdBQ2xCO0VBRUYsTUFBTSxPQUFPLENBQUMsR0FBRyxLQUFLLEtBQUs7RUFDM0IsSUFBSTtFQUNKLElBQUksYUFBYTtFQUNqQixLQUFLLElBQUksSUFBSSxhQUFhLElBQUksTUFBTSxLQUNsQyxJQUFJLGdCQUFnQixHQUFHO0dBQ3JCLElBQUksVUFBVSxLQUFLO0dBQ25CLElBQUksS0FBSyxPQUFPLEtBQ2QsVUFBVSxLQUFLLElBQUk7R0FFckIsSUFBSSxLQUNGLEtBQUssT0FBTyxHQUFHO0dBRWpCLFlBQVksS0FBSyxJQUFJLE9BQU87R0FDNUIsS0FBSyxJQUFJLEtBQUssS0FBSztFQUNyQixPQUFPO0dBQ0wsSUFBSSxDQUFDLGNBQWMsS0FBSyxJQUFJLE9BQU8sS0FDakMsYUFBYTtHQUVmLE1BQU0sYUFBYSxLQUFLLGFBQWEsSUFBSSxJQUFJO0dBQzdDLE1BQU0sZUFBZTtHQUNyQixZQUFZLEtBQUssSUFBSSxVQUFVO0dBQy9CLEtBQUssT0FBTyxVQUFVO0dBQ3RCLEtBQUssSUFBSSxZQUFZLFlBQVk7RUFDbkM7RUFFRixPQUFPO0NBQ1Q7Q0FDQSxLQUFLLE9BQU8sS0FBSyxPQUFPO0VBQ3RCLE1BQU0sT0FBTyxJQUFJLGFBQWEsSUFBSTtFQUNsQyxLQUFLLE9BQU8sT0FBTyxLQUFLLEtBQUs7RUFDN0IsT0FBTztDQUNUO0NBQ0EsT0FBTyxLQUFLO0VBQ1YsTUFBTSxRQUFRLEtBQUssTUFBTSxRQUFRLEdBQUcsSUFBSTtFQUN4QyxJQUFJLFFBQVEsR0FDVjtFQUVGLE9BQU8sS0FBSyxRQUFRLEtBQUs7Q0FDM0I7Ozs7Q0FJQSxVQUFVLEtBQUssUUFBUSxPQUFPO0VBQzVCLE1BQU0sUUFBUSxLQUFLLE1BQU0sUUFBUSxHQUFHO0VBQ3BDLElBQUksVUFBVSxJQUNaLE9BQU87RUFFVCxPQUFPLEtBQUssT0FBTyxPQUFPLFFBQVEsS0FBSztDQUN6QztDQUNBLE1BQU0sS0FBSztFQUNULElBQUksUUFBUSxLQUFLLE1BQU0sUUFBUSxHQUFHO0VBQ2xDLFFBQVEsVUFBVSxNQUFNLFVBQVUsS0FBSyxPQUFPLElBQUksS0FBSyxRQUFRO0VBQy9ELElBQUksVUFBVSxJQUNaO0VBRUYsT0FBTyxLQUFLLFFBQVEsS0FBSztDQUMzQjs7OztDQUlBLFNBQVMsS0FBSyxRQUFRLE9BQU87RUFDM0IsTUFBTSxRQUFRLEtBQUssTUFBTSxRQUFRLEdBQUc7RUFDcEMsSUFBSSxVQUFVLElBQ1osT0FBTztFQUVULE9BQU8sS0FBSyxPQUFPLFFBQVEsR0FBRyxRQUFRLEtBQUs7Q0FDN0M7Q0FDQSxRQUFRO0VBQ04sT0FBTyxLQUFLLFFBQVEsQ0FBQztDQUN2QjtDQUNBLE9BQU87RUFDTCxPQUFPLEtBQUssUUFBUSxFQUFFO0NBQ3hCO0NBQ0EsUUFBUTtFQUNOLEtBQUssUUFBUSxDQUFDO0VBQ2QsT0FBTyxNQUFNLE1BQU07Q0FDckI7Q0FDQSxPQUFPLEtBQUs7RUFDVixNQUFNLFVBQVUsTUFBTSxPQUFPLEdBQUc7RUFDaEMsSUFBSSxTQUNGLEtBQUssTUFBTSxPQUFPLEtBQUssTUFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDO0VBRTlDLE9BQU87Q0FDVDtDQUNBLFNBQVMsT0FBTztFQUNkLE1BQU0sTUFBTSxLQUFLLE1BQU0sS0FBSztFQUM1QixJQUFJLFFBQVEsS0FBSyxHQUNmLE9BQU8sS0FBSyxPQUFPLEdBQUc7RUFFeEIsT0FBTztDQUNUO0NBQ0EsR0FBRyxPQUFPO0VBQ1IsTUFBTSxNQUFNLEdBQUcsS0FBSyxPQUFPLEtBQUs7RUFDaEMsSUFBSSxRQUFRLEtBQUssR0FDZixPQUFPLEtBQUssSUFBSSxHQUFHO0NBRXZCO0NBQ0EsUUFBUSxPQUFPO0VBQ2IsTUFBTSxNQUFNLEdBQUcsS0FBSyxPQUFPLEtBQUs7RUFDaEMsSUFBSSxRQUFRLEtBQUssR0FDZixPQUFPLENBQUMsS0FBSyxLQUFLLElBQUksR0FBRyxDQUFDO0NBRTlCO0NBQ0EsUUFBUSxLQUFLO0VBQ1gsT0FBTyxLQUFLLE1BQU0sUUFBUSxHQUFHO0NBQy9CO0NBQ0EsTUFBTSxPQUFPO0VBQ1gsT0FBTyxHQUFHLEtBQUssT0FBTyxLQUFLO0NBQzdCO0NBQ0EsS0FBSyxLQUFLLFFBQVE7RUFDaEIsTUFBTSxRQUFRLEtBQUssUUFBUSxHQUFHO0VBQzlCLElBQUksVUFBVSxJQUNaO0VBRUYsSUFBSSxPQUFPLFFBQVE7RUFDbkIsSUFBSSxPQUFPLEdBQUcsT0FBTztFQUNyQixJQUFJLFFBQVEsS0FBSyxNQUFNLE9BQU8sS0FBSyxPQUFPO0VBQzFDLE9BQU8sS0FBSyxHQUFHLElBQUk7Q0FDckI7Q0FDQSxRQUFRLEtBQUssUUFBUTtFQUNuQixNQUFNLFFBQVEsS0FBSyxRQUFRLEdBQUc7RUFDOUIsSUFBSSxVQUFVLElBQ1o7RUFFRixJQUFJLE9BQU8sUUFBUTtFQUNuQixJQUFJLE9BQU8sR0FBRyxPQUFPO0VBQ3JCLElBQUksUUFBUSxLQUFLLE1BQU0sT0FBTyxLQUFLLE9BQU87RUFDMUMsT0FBTyxLQUFLLE1BQU0sSUFBSTtDQUN4QjtDQUNBLEtBQUssV0FBVyxTQUFTO0VBQ3ZCLElBQUksUUFBUTtFQUNaLEtBQUssTUFBTSxTQUFTLE1BQU07R0FDeEIsSUFBSSxRQUFRLE1BQU0sV0FBVyxTQUFTO0lBQUM7SUFBTztJQUFPO0dBQUksQ0FBQyxHQUN4RCxPQUFPO0dBRVQ7RUFDRjtDQUVGO0NBQ0EsVUFBVSxXQUFXLFNBQVM7RUFDNUIsSUFBSSxRQUFRO0VBQ1osS0FBSyxNQUFNLFNBQVMsTUFBTTtHQUN4QixJQUFJLFFBQVEsTUFBTSxXQUFXLFNBQVM7SUFBQztJQUFPO0lBQU87R0FBSSxDQUFDLEdBQ3hELE9BQU87R0FFVDtFQUNGO0VBQ0EsT0FBTztDQUNUO0NBQ0EsT0FBTyxXQUFXLFNBQVM7RUFDekIsTUFBTSxVQUFVLENBQUM7RUFDakIsSUFBSSxRQUFRO0VBQ1osS0FBSyxNQUFNLFNBQVMsTUFBTTtHQUN4QixJQUFJLFFBQVEsTUFBTSxXQUFXLFNBQVM7SUFBQztJQUFPO0lBQU87R0FBSSxDQUFDLEdBQ3hELFFBQVEsS0FBSyxLQUFLO0dBRXBCO0VBQ0Y7RUFDQSxPQUFPLElBQUksYUFBYSxPQUFPO0NBQ2pDO0NBQ0EsSUFBSSxZQUFZLFNBQVM7RUFDdkIsTUFBTSxVQUFVLENBQUM7RUFDakIsSUFBSSxRQUFRO0VBQ1osS0FBSyxNQUFNLFNBQVMsTUFBTTtHQUN4QixRQUFRLEtBQUssQ0FBQyxNQUFNLElBQUksUUFBUSxNQUFNLFlBQVksU0FBUztJQUFDO0lBQU87SUFBTztHQUFJLENBQUMsQ0FBQyxDQUFDO0dBQ2pGO0VBQ0Y7RUFDQSxPQUFPLElBQUksYUFBYSxPQUFPO0NBQ2pDO0NBQ0EsT0FBTyxHQUFHLE1BQU07RUFDZCxNQUFNLENBQUMsWUFBWSxnQkFBZ0I7RUFDbkMsSUFBSSxRQUFRO0VBQ1osSUFBSSxjQUFjLGdCQUFnQixLQUFLLEdBQUcsQ0FBQztFQUMzQyxLQUFLLE1BQU0sU0FBUyxNQUFNO0dBQ3hCLElBQUksVUFBVSxLQUFLLEtBQUssV0FBVyxHQUNqQyxjQUFjO1FBRWQsY0FBYyxRQUFRLE1BQU0sWUFBWSxNQUFNO0lBQUM7SUFBYTtJQUFPO0lBQU87R0FBSSxDQUFDO0dBRWpGO0VBQ0Y7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxZQUFZLEdBQUcsTUFBTTtFQUNuQixNQUFNLENBQUMsWUFBWSxnQkFBZ0I7RUFDbkMsSUFBSSxjQUFjLGdCQUFnQixLQUFLLEdBQUcsRUFBRTtFQUM1QyxLQUFLLElBQUksUUFBUSxLQUFLLE9BQU8sR0FBRyxTQUFTLEdBQUcsU0FBUztHQUNuRCxNQUFNLFFBQVEsS0FBSyxHQUFHLEtBQUs7R0FDM0IsSUFBSSxVQUFVLEtBQUssT0FBTyxLQUFLLEtBQUssV0FBVyxHQUM3QyxjQUFjO1FBRWQsY0FBYyxRQUFRLE1BQU0sWUFBWSxNQUFNO0lBQUM7SUFBYTtJQUFPO0lBQU87R0FBSSxDQUFDO0VBRW5GO0VBQ0EsT0FBTztDQUNUO0NBQ0EsU0FBUyxXQUFXO0VBQ2xCLE1BQU0sVUFBVSxDQUFDLEdBQUcsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUztFQUNsRCxPQUFPLElBQUksYUFBYSxPQUFPO0NBQ2pDO0NBQ0EsYUFBYTtFQUNYLE1BQU0sV0FBVyxJQUFJLGFBQWE7RUFDbEMsS0FBSyxJQUFJLFFBQVEsS0FBSyxPQUFPLEdBQUcsU0FBUyxHQUFHLFNBQVM7R0FDbkQsTUFBTSxNQUFNLEtBQUssTUFBTSxLQUFLO0dBQzVCLE1BQU0sVUFBVSxLQUFLLElBQUksR0FBRztHQUM1QixTQUFTLElBQUksS0FBSyxPQUFPO0VBQzNCO0VBQ0EsT0FBTztDQUNUO0NBQ0EsVUFBVSxHQUFHLE1BQU07RUFDakIsTUFBTSxVQUFVLENBQUMsR0FBRyxLQUFLLFFBQVEsQ0FBQztFQUNsQyxRQUFRLE9BQU8sR0FBRyxJQUFJO0VBQ3RCLE9BQU8sSUFBSSxhQUFhLE9BQU87Q0FDakM7Q0FDQSxNQUFNLE9BQU8sS0FBSztFQUNoQixNQUFNLFNBQVMsSUFBSSxhQUFhO0VBQ2hDLElBQUksT0FBTyxLQUFLLE9BQU87RUFDdkIsSUFBSSxVQUFVLEtBQUssR0FDakIsT0FBTztFQUVULElBQUksUUFBUSxHQUNWLFFBQVEsUUFBUSxLQUFLO0VBRXZCLElBQUksUUFBUSxLQUFLLEtBQUssTUFBTSxHQUMxQixPQUFPLE1BQU07RUFFZixLQUFLLElBQUksUUFBUSxPQUFPLFNBQVMsTUFBTSxTQUFTO0dBQzlDLE1BQU0sTUFBTSxLQUFLLE1BQU0sS0FBSztHQUM1QixNQUFNLFVBQVUsS0FBSyxJQUFJLEdBQUc7R0FDNUIsT0FBTyxJQUFJLEtBQUssT0FBTztFQUN6QjtFQUNBLE9BQU87Q0FDVDtDQUNBLE1BQU0sV0FBVyxTQUFTO0VBQ3hCLElBQUksUUFBUTtFQUNaLEtBQUssTUFBTSxTQUFTLE1BQU07R0FDeEIsSUFBSSxDQUFDLFFBQVEsTUFBTSxXQUFXLFNBQVM7SUFBQztJQUFPO0lBQU87R0FBSSxDQUFDLEdBQ3pELE9BQU87R0FFVDtFQUNGO0VBQ0EsT0FBTztDQUNUO0NBQ0EsS0FBSyxXQUFXLFNBQVM7RUFDdkIsSUFBSSxRQUFRO0VBQ1osS0FBSyxNQUFNLFNBQVMsTUFBTTtHQUN4QixJQUFJLFFBQVEsTUFBTSxXQUFXLFNBQVM7SUFBQztJQUFPO0lBQU87R0FBSSxDQUFDLEdBQ3hELE9BQU87R0FFVDtFQUNGO0VBQ0EsT0FBTztDQUNUO0FBQ0Y7QUFDQSxTQUFTLEdBQUcsT0FBTyxPQUFPO0NBQ3hCLElBQUksUUFBUSxNQUFNLFdBQ2hCLE9BQU8sTUFBTSxVQUFVLEdBQUcsS0FBSyxPQUFPLEtBQUs7Q0FFN0MsTUFBTSxjQUFjLFlBQVksT0FBTyxLQUFLO0NBQzVDLE9BQU8sZ0JBQWdCLEtBQUssS0FBSyxJQUFJLE1BQU07QUFDN0M7QUFDQUEsU0FBTyxJQUFJLElBQUk7QUFDZixTQUFTLFlBQVksT0FBTyxPQUFPO0NBQ2pDLE1BQU0sU0FBUyxNQUFNO0NBQ3JCLE1BQU0sZ0JBQWdCLGNBQWMsS0FBSztDQUN6QyxNQUFNLGNBQWMsaUJBQWlCLElBQUksZ0JBQWdCLFNBQVM7Q0FDbEUsT0FBTyxjQUFjLEtBQUssZUFBZSxTQUFTLEtBQUs7QUFDekQ7QUFDQUEsU0FBTyxhQUFhLGFBQWE7QUFDakMsU0FBUyxjQUFjLFFBQVE7Q0FDN0IsT0FBTyxXQUFXLFVBQVUsV0FBVyxJQUFJLElBQUksS0FBSyxNQUFNLE1BQU07QUFDbEU7QUFDQUEsU0FBTyxlQUFlLGVBQWU7O0FBS3JDLFNBQVMsa0JBQWtCLE1BQU07Q0FDL0IsTUFBTSxnQkFBZ0IsT0FBTztDQUM3QixNQUFNLENBQUMseUJBQXlCLHlCQUF5QkMsbUJBQW9CLGFBQWE7Q0FDMUYsTUFBTSxDQUFDLDJCQUEyQix3QkFBd0Isd0JBQ3hELGVBQ0E7RUFDRSxtQkFBbUI7RUFDbkIsZUFBZSxFQUFFLFNBQVMsS0FBSztFQUMvQixxQkFBcUIsRUFBRSxTQUFTLEtBQUs7RUFDckMsU0FBUyxJQUFJLFlBQVk7RUFDekIsWUFBNEIsK0JBQWEsS0FBSyxHQUFHLFlBQVk7Q0FDL0QsQ0FDRjtDQUNBLE1BQU0scUJBQXFDLDBCQUFRLEVBQUUsT0FBTyxHQUFHLFlBQVk7RUFDekUsT0FBTyxRQUF3QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyx3QkFBd0I7R0FBRSxHQUFHO0dBQU87RUFBTSxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLGdCQUFnQixFQUFFLEdBQUcsTUFBTSxDQUFDO0NBQ3RJLEdBQUcsb0JBQW9CO0NBQ3ZCLG1CQUFtQixjQUFjO0NBQ2pDLE1BQU0saUJBQWlDLDBCQUFRLFVBQVU7RUFDdkQsTUFBTSxRQUFRLGtCQUFrQjtFQUNoQyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyx3QkFBd0I7R0FBRSxHQUFHO0dBQU87RUFBTSxDQUFDO0NBQ3pFLEdBQUcsZ0JBQWdCO0NBQ25CLGVBQWUsY0FBYyxnQkFBZ0I7Q0FDN0MsTUFBTSx5QkFBeUMsMEJBQVEsVUFBVTtFQUMvRCxNQUFNLEVBQUUsT0FBTyxVQUFVLFVBQVU7RUFDbkMsTUFBTSxNQUFBLGFBQWEsT0FBTyxJQUFJO0VBQzlCLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQUEsYUFBK0IsU0FDdkQsSUFDRjtFQUNBLE1BQU0sY0FBY0MsZ0JBQWlCLEtBQUssb0JBQW9CO0VBQzlELE1BQU0sQ0FBQyxTQUFTLGNBQWM7RUFDOUIsYUFBTyxnQkFBZ0I7R0FDckIsSUFBSSxDQUFDLG1CQUFtQjtHQUN4QixNQUFNLFdBQVcsMkJBQTJCLENBQzVDLENBQUM7R0FDRCxTQUFTLFFBQVEsbUJBQW1CO0lBQ2xDLFdBQVc7SUFDWCxTQUFTO0dBQ1gsQ0FBQztHQUNELGFBQWE7SUFDWCxTQUFTLFdBQVc7R0FDdEI7RUFDRixHQUFHLENBQUMsaUJBQWlCLENBQUM7RUFDdEIsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ3JCLDJCQUNBO0dBQ0U7R0FDQTtHQUNBO0dBQ0EsZUFBZTtHQUNmLHFCQUFxQjtHQUNyQjtHQUNBO0VBQ0YsQ0FDRjtDQUNGLEdBQUcsd0JBQXdCO0NBQzNCLHVCQUF1QixjQUFjLGdCQUFnQjtDQUNyRCxNQUFNLHVCQUF1QixPQUFPO0NBQ3BDLE1BQU0scUJBQXFCQyxXQUFZLG9CQUFvQjtDQUMzRCxNQUFNLGlCQUFBLGFBQXdCLFlBQzNCLE9BQU8saUJBQWlCO0VBQ3ZCLE1BQU0sRUFBRSxPQUFPLGFBQWE7RUFDNUIsTUFBTSxVQUFVLHFCQUFxQixzQkFBc0IsS0FBSztFQUNoRSxNQUFNLGVBQWVELGdCQUFpQixjQUFjLFFBQVEsYUFBYTtFQUN6RSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxvQkFBb0I7R0FBRSxLQUFLO0dBQWM7RUFBUyxDQUFDO0NBQ2pGLENBQ0Y7Q0FDQSxlQUFlLGNBQWM7Q0FDN0IsTUFBTSxpQkFBaUIsT0FBTztDQUM5QixNQUFNLGlCQUFpQjtDQUN2QixNQUFNLHlCQUF5QkMsV0FBWSxjQUFjO0NBQ3pELE1BQU0scUJBQUEsYUFBNEIsWUFDL0IsT0FBTyxpQkFBaUI7RUFDdkIsTUFBTSxFQUFFLE9BQU8sVUFBVSxHQUFHLGFBQWE7RUFDekMsTUFBTSxNQUFBLGFBQWEsT0FBTyxJQUFJO0VBQzlCLE1BQU0sQ0FBQyxTQUFTLGNBQUEsYUFBcUIsU0FBUyxJQUFJO0VBQ2xELE1BQU0sZUFBZUQsZ0JBQWlCLGNBQWMsS0FBSyxVQUFVO0VBRW5FLE1BQU0sRUFBRSxlQURRLHFCQUFxQixnQkFBZ0IsS0FDeEI7RUFDN0IsTUFBTSxjQUFBLGFBQXFCLE9BQU8sUUFBUTtFQUMxQyxJQUFJLENBQUMsYUFBYSxZQUFZLFNBQVMsUUFBUSxHQUM3QyxZQUFZLFVBQVU7RUFFeEIsTUFBTSxtQkFBbUIsWUFBWTtFQUNyQyxhQUFPLGdCQUFnQjtHQUNyQixNQUFNLFlBQVk7R0FDbEIsWUFBWSxRQUFRO0lBQ2xCLElBQUksQ0FBQyxTQUNILE9BQU87SUFFVCxJQUFJLENBQUMsSUFBSSxJQUFJLE9BQU8sR0FBRztLQUNyQixJQUFJLElBQUksU0FBUztNQUFFLEdBQUc7TUFBVztLQUFRLENBQUM7S0FDMUMsT0FBTyxJQUFJLFNBQVMsc0JBQXNCO0lBQzVDO0lBQ0EsT0FBTyxJQUFJLElBQUksU0FBUztLQUFFLEdBQUc7S0FBVztJQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsc0JBQXNCO0dBQ3BGLENBQUM7R0FDRCxhQUFhO0lBQ1gsWUFBWSxRQUFRO0tBQ2xCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxJQUFJLE9BQU8sR0FDOUIsT0FBTztLQUVULElBQUksT0FBTyxPQUFPO0tBQ2xCLE9BQU8sSUFBSSxZQUFZLEdBQUc7SUFDNUIsQ0FBQztHQUNIO0VBQ0YsR0FBRztHQUFDO0dBQVM7R0FBa0I7RUFBVSxDQUFDO0VBQzFDLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLHdCQUF3QjtJQUFRLGlCQUFpQjtHQUFNLEtBQUs7R0FBYztFQUFTLENBQUM7Q0FDbEgsQ0FDRjtDQUNBLG1CQUFtQixjQUFjO0NBQ2pDLFNBQVMsb0JBQW9CO0VBQzNCLE9BQUEsYUFBYyxTQUFTLElBQUksWUFBWSxDQUFDO0NBQzFDO0NBQ0EsU0FBTyxtQkFBbUIsbUJBQW1CO0NBQzdDLFNBQVMsY0FBYyxPQUFPO0VBQzVCLE1BQU0sRUFBRSxZQUFZLHFCQUFxQixPQUFPLHNCQUFzQixLQUFLO0VBQzNFLE9BQU87Q0FDVDtDQUNBLFNBQU8sZUFBZSxlQUFlO0NBTXJDLE9BQU8sQ0FDTDtFQUFFLFVBQVU7RUFBb0IsTUFBTTtFQUFnQixVQUFVO0NBQW1CLEdBQ25GO0VBTkE7RUFDQTtFQUNBO0NBSVEsQ0FDVjtBQUNGO0FBQ0FGLFNBQU8sbUJBQW1CLGtCQUFrQjtBQUM1QyxTQUFTLGFBQWEsR0FBRyxHQUFHO0NBQzFCLElBQUksTUFBTSxHQUFHLE9BQU87Q0FDcEIsSUFBSSxPQUFPLE1BQU0sWUFBWSxPQUFPLE1BQU0sVUFBVSxPQUFPO0NBQzNELElBQUksS0FBSyxRQUFRLEtBQUssTUFBTSxPQUFPO0NBQ25DLE1BQU0sUUFBUSxPQUFPLEtBQUssQ0FBQztDQUMzQixNQUFNLFFBQVEsT0FBTyxLQUFLLENBQUM7Q0FDM0IsSUFBSSxNQUFNLFdBQVcsTUFBTSxRQUFRLE9BQU87Q0FDMUMsS0FBSyxNQUFNLE9BQU8sT0FBTztFQUN2QixJQUFJLENBQUMsT0FBTyxVQUFVLGVBQWUsS0FBSyxHQUFHLEdBQUcsR0FBRyxPQUFPO0VBQzFELElBQUksRUFBRSxTQUFTLEVBQUUsTUFBTSxPQUFPO0NBQ2hDO0NBQ0EsT0FBTztBQUNUO0FBQ0FBLFNBQU8sY0FBYyxjQUFjO0FBQ25DLFNBQVMsbUJBQW1CLEdBQUcsR0FBRztDQUNoQyxPQUFPLENBQUMsRUFBRSxFQUFFLHdCQUF3QixDQUFDLElBQUksS0FBSztBQUNoRDtBQUNBQSxTQUFPLG9CQUFvQixvQkFBb0I7QUFDL0MsU0FBUyx1QkFBdUIsR0FBRyxHQUFHO0NBQ3BDLE9BQU8sQ0FBQyxFQUFFLEVBQUUsQ0FBQyxXQUFXLENBQUMsRUFBRSxFQUFFLENBQUMsVUFBVSxJQUFJLG1CQUFtQixFQUFFLEVBQUUsQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLE9BQU8sSUFBSSxLQUFLO0FBQ3BHO0FBQ0FBLFNBQU8sd0JBQXdCLHdCQUF3QjtBQUN2RCxTQUFTLHFCQUFxQixVQUFVO0NBU3RDLE9BQU8sSUFSYyxrQkFBa0Isa0JBQWtCO0VBQ3ZELEtBQUssTUFBTSxZQUFZLGVBQ3JCLElBQUksU0FBUyxTQUFTLGFBQWE7R0FDakMsU0FBUztHQUNUO0VBQ0Y7Q0FFSixDQUNjO0FBQ2hCO0FBQ0FBLFNBQU8sc0JBQXNCLHNCQUFzQjs7O0FDN2lCbkQsSUFBSSxZQUFZLE9BQU87QUFDdkIsSUFBSSxVQUFVLFFBQVEsVUFBVSxVQUFVLFFBQVEsUUFBUTtDQUFFO0NBQU8sY0FBYztBQUFLLENBQUM7QUFLdkYsSUFBSSxtQkFBQSxhQUF5QixjQUFjLEtBQUssQ0FBQztBQUtqRCxTQUFTLGFBQWEsVUFBVTtDQUM5QixNQUFNLFlBQUEsYUFBa0IsV0FBVyxnQkFBZ0I7Q0FDbkQsT0FBTyxZQUFZLGFBQWE7QUFDbEM7QUFDQSxPQUFPLGNBQWMsY0FBYyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDFdfQ==