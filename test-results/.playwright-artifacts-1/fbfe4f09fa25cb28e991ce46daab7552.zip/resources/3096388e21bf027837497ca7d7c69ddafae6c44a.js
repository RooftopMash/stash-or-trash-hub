import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SeoHelmet.tsx");const useEffect = __vite__cjsImport0_react["useEffect"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
var _s = $RefreshSig$();
const DEFAULT_TITLE = "SOT — Stash Or Trash | The Brand Barometer";
const DEFAULT_DESC = "SOT (Stash Or Trash) is the Brand Barometer — a CX/UX marketing & PR tool where the community delivers a live verdict on brands. Cast yours and keep your streak alive.";
const SITE_NAME = "SOT — Stash Or Trash";
function updateMetaTag(attributeName, attributeValue, content) {
	if (typeof document === "undefined") return;
	let element = document.querySelector(`meta[${attributeName}="${attributeValue}"]`);
	if (!content) {
		if (element) {
			element.remove();
		}
		return;
	}
	if (!element) {
		element = document.createElement("meta");
		element.setAttribute(attributeName, attributeValue);
		document.head.appendChild(element);
	}
	element.setAttribute("content", content);
}
function updateLinkTag(rel, href) {
	if (typeof document === "undefined") return;
	let element = document.querySelector(`link[rel="${rel}"]`);
	if (!href) {
		if (element) {
			element.remove();
		}
		return;
	}
	if (!element) {
		element = document.createElement("link");
		element.setAttribute("rel", rel);
		document.head.appendChild(element);
	}
	element.setAttribute("href", href);
}
/**
* React Helmet component for the SOT Brand Barometer app shell & views.
* Dynamically updates document title, standard meta descriptions, OpenGraph,
* Twitter card tags, and Schema.org JSON-LD structured data.
*/
export function SeoHelmet({ title, description = DEFAULT_DESC, keywords, canonicalUrl, ogType = "website", ogImage = "/apple-touch-icon.png", ogTitle, ogDescription, twitterCard = "summary_large_image", noIndex = false, structuredData }) {
	_s();
	const fullTitle = title ? title.includes("SOT") || title.includes("Brand Barometer") ? title : `${title} | SOT Brand Barometer` : DEFAULT_TITLE;
	const resolvedOgTitle = ogTitle || fullTitle;
	const resolvedOgDesc = ogDescription || description;
	useEffect(() => {
		if (typeof document === "undefined") return;
		// Document title
		document.title = fullTitle;
		// Standard meta tags
		updateMetaTag("name", "description", description);
		if (keywords && keywords.length > 0) {
			updateMetaTag("name", "keywords", keywords.join(", "));
		}
		if (noIndex) {
			updateMetaTag("name", "robots", "noindex, nofollow");
		} else {
			updateMetaTag("name", "robots", "index, follow");
		}
		// Canonical link
		const resolvedCanonical = canonicalUrl || (typeof window !== "undefined" ? window.location.origin + window.location.pathname : null);
		updateLinkTag("canonical", resolvedCanonical);
		// OpenGraph meta tags
		updateMetaTag("property", "og:title", resolvedOgTitle);
		updateMetaTag("property", "og:description", resolvedOgDesc);
		updateMetaTag("property", "og:type", ogType);
		updateMetaTag("property", "og:site_name", SITE_NAME);
		if (resolvedCanonical) {
			updateMetaTag("property", "og:url", resolvedCanonical);
		}
		if (ogImage) {
			const fullImageUrl = ogImage.startsWith("http") || typeof window === "undefined" ? ogImage : `${window.location.origin}${ogImage.startsWith("/") ? "" : "/"}${ogImage}`;
			updateMetaTag("property", "og:image", fullImageUrl);
		}
		// Twitter card tags
		updateMetaTag("name", "twitter:card", twitterCard);
		updateMetaTag("name", "twitter:title", resolvedOgTitle);
		updateMetaTag("name", "twitter:description", resolvedOgDesc);
		if (ogImage) {
			const fullImageUrl = ogImage.startsWith("http") || typeof window === "undefined" ? ogImage : `${window.location.origin}${ogImage.startsWith("/") ? "" : "/"}${ogImage}`;
			updateMetaTag("name", "twitter:image", fullImageUrl);
		}
		// JSON-LD Structured Data
		const scriptId = "sot-seo-jsonld";
		let scriptElement = document.getElementById(scriptId);
		if (structuredData) {
			if (!scriptElement) {
				scriptElement = document.createElement("script");
				scriptElement.id = scriptId;
				scriptElement.type = "application/ld+json";
				document.head.appendChild(scriptElement);
			}
			scriptElement.textContent = JSON.stringify(structuredData);
		} else if (scriptElement) {
			scriptElement.remove();
		}
	}, [
		fullTitle,
		description,
		keywords,
		canonicalUrl,
		ogType,
		ogImage,
		resolvedOgTitle,
		resolvedOgDesc,
		twitterCard,
		noIndex,
		structuredData
	]);
	return null;
}
_s(SeoHelmet, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = SeoHelmet;
export default SeoHelmet;
var _c;
$RefreshReg$(_c, "SeoHelmet");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SeoHelmet.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/SeoHelmet.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/SeoHelmet.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/SeoHelmet.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7O0FBZ0IxQixNQUFNLGdCQUFnQjtBQUN0QixNQUFNLGVBQ0o7QUFDRixNQUFNLFlBQVk7QUFFbEIsU0FBUyxjQUFjLGVBQW9DLGdCQUF3QixTQUF3QjtDQUN6RyxJQUFJLE9BQU8sYUFBYSxhQUFhO0NBRXJDLElBQUksVUFBVSxTQUFTLGNBQStCLFFBQVEsY0FBYyxJQUFJLGVBQWUsR0FBRztDQUNsRyxJQUFJLENBQUMsU0FBUztFQUNaLElBQUksU0FBUztHQUNYLFFBQVEsT0FBTztFQUNqQjtFQUNBO0NBQ0Y7Q0FFQSxJQUFJLENBQUMsU0FBUztFQUNaLFVBQVUsU0FBUyxjQUFjLE1BQU07RUFDdkMsUUFBUSxhQUFhLGVBQWUsY0FBYztFQUNsRCxTQUFTLEtBQUssWUFBWSxPQUFPO0NBQ25DO0NBQ0EsUUFBUSxhQUFhLFdBQVcsT0FBTztBQUN6QztBQUVBLFNBQVMsY0FBYyxLQUFhLE1BQXFCO0NBQ3ZELElBQUksT0FBTyxhQUFhLGFBQWE7Q0FFckMsSUFBSSxVQUFVLFNBQVMsY0FBK0IsYUFBYSxJQUFJLEdBQUc7Q0FDMUUsSUFBSSxDQUFDLE1BQU07RUFDVCxJQUFJLFNBQVM7R0FDWCxRQUFRLE9BQU87RUFDakI7RUFDQTtDQUNGO0NBRUEsSUFBSSxDQUFDLFNBQVM7RUFDWixVQUFVLFNBQVMsY0FBYyxNQUFNO0VBQ3ZDLFFBQVEsYUFBYSxPQUFPLEdBQUc7RUFDL0IsU0FBUyxLQUFLLFlBQVksT0FBTztDQUNuQztDQUNBLFFBQVEsYUFBYSxRQUFRLElBQUk7QUFDbkM7Ozs7OztBQU9BLE9BQU8sU0FBUyxVQUFVLEVBQ3hCLE9BQ0EsY0FBYyxjQUNkLFVBQ0EsY0FDQSxTQUFTLFdBQ1QsVUFBVSx5QkFDVixTQUNBLGVBQ0EsY0FBYyx1QkFDZCxVQUFVLE9BQ1Ysa0JBQ2lCOztDQUNqQixNQUFNLFlBQVksUUFDZCxNQUFNLFNBQVMsS0FBSyxLQUFLLE1BQU0sU0FBUyxpQkFBaUIsSUFDdkQsUUFDQSxHQUFHLE1BQU0sMEJBQ1g7Q0FFSixNQUFNLGtCQUFrQixXQUFXO0NBQ25DLE1BQU0saUJBQWlCLGlCQUFpQjtDQUV4QyxnQkFBZ0I7RUFDZCxJQUFJLE9BQU8sYUFBYSxhQUFhOztFQUdyQyxTQUFTLFFBQVE7O0VBR2pCLGNBQWMsUUFBUSxlQUFlLFdBQVc7RUFDaEQsSUFBSSxZQUFZLFNBQVMsU0FBUyxHQUFHO0dBQ25DLGNBQWMsUUFBUSxZQUFZLFNBQVMsS0FBSyxJQUFJLENBQUM7RUFDdkQ7RUFDQSxJQUFJLFNBQVM7R0FDWCxjQUFjLFFBQVEsVUFBVSxtQkFBbUI7RUFDckQsT0FBTztHQUNMLGNBQWMsUUFBUSxVQUFVLGVBQWU7RUFDakQ7O0VBR0EsTUFBTSxvQkFDSixpQkFBaUIsT0FBTyxXQUFXLGNBQWMsT0FBTyxTQUFTLFNBQVMsT0FBTyxTQUFTLFdBQVc7RUFDdkcsY0FBYyxhQUFhLGlCQUFpQjs7RUFHNUMsY0FBYyxZQUFZLFlBQVksZUFBZTtFQUNyRCxjQUFjLFlBQVksa0JBQWtCLGNBQWM7RUFDMUQsY0FBYyxZQUFZLFdBQVcsTUFBTTtFQUMzQyxjQUFjLFlBQVksZ0JBQWdCLFNBQVM7RUFDbkQsSUFBSSxtQkFBbUI7R0FDckIsY0FBYyxZQUFZLFVBQVUsaUJBQWlCO0VBQ3ZEO0VBQ0EsSUFBSSxTQUFTO0dBQ1gsTUFBTSxlQUNKLFFBQVEsV0FBVyxNQUFNLEtBQUssT0FBTyxXQUFXLGNBQzVDLFVBQ0EsR0FBRyxPQUFPLFNBQVMsU0FBUyxRQUFRLFdBQVcsR0FBRyxJQUFJLEtBQUssTUFBTTtHQUN2RSxjQUFjLFlBQVksWUFBWSxZQUFZO0VBQ3BEOztFQUdBLGNBQWMsUUFBUSxnQkFBZ0IsV0FBVztFQUNqRCxjQUFjLFFBQVEsaUJBQWlCLGVBQWU7RUFDdEQsY0FBYyxRQUFRLHVCQUF1QixjQUFjO0VBQzNELElBQUksU0FBUztHQUNYLE1BQU0sZUFDSixRQUFRLFdBQVcsTUFBTSxLQUFLLE9BQU8sV0FBVyxjQUM1QyxVQUNBLEdBQUcsT0FBTyxTQUFTLFNBQVMsUUFBUSxXQUFXLEdBQUcsSUFBSSxLQUFLLE1BQU07R0FDdkUsY0FBYyxRQUFRLGlCQUFpQixZQUFZO0VBQ3JEOztFQUdBLE1BQU0sV0FBVztFQUNqQixJQUFJLGdCQUFnQixTQUFTLGVBQWUsUUFBUTtFQUNwRCxJQUFJLGdCQUFnQjtHQUNsQixJQUFJLENBQUMsZUFBZTtJQUNsQixnQkFBZ0IsU0FBUyxjQUFjLFFBQVE7SUFDL0MsY0FBYyxLQUFLO0lBQ25CLGNBQWMsT0FBTztJQUNyQixTQUFTLEtBQUssWUFBWSxhQUFhO0dBQ3pDO0dBQ0EsY0FBYyxjQUFjLEtBQUssVUFBVSxjQUFjO0VBQzNELE9BQU8sSUFBSSxlQUFlO0dBQ3hCLGNBQWMsT0FBTztFQUN2QjtDQUNGLEdBQUc7RUFDRDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsQ0FBQztDQUVELE9BQU87QUFDVDs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTZW9IZWxtZXQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuXG5leHBvcnQgaW50ZXJmYWNlIFNlb0hlbG1ldFByb3BzIHtcbiAgdGl0bGU/OiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuICBrZXl3b3Jkcz86IHN0cmluZ1tdO1xuICBjYW5vbmljYWxVcmw/OiBzdHJpbmc7XG4gIG9nVHlwZT86IFwid2Vic2l0ZVwiIHwgXCJhcnRpY2xlXCIgfCBcInByb2ZpbGVcIiB8IFwicHJvZHVjdFwiO1xuICBvZ0ltYWdlPzogc3RyaW5nO1xuICBvZ1RpdGxlPzogc3RyaW5nO1xuICBvZ0Rlc2NyaXB0aW9uPzogc3RyaW5nO1xuICB0d2l0dGVyQ2FyZD86IFwic3VtbWFyeVwiIHwgXCJzdW1tYXJ5X2xhcmdlX2ltYWdlXCI7XG4gIG5vSW5kZXg/OiBib29sZWFuO1xuICBzdHJ1Y3R1cmVkRGF0YT86IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgQXJyYXk8UmVjb3JkPHN0cmluZywgdW5rbm93bj4+O1xufVxuXG5jb25zdCBERUZBVUxUX1RJVExFID0gXCJTT1Qg4oCUIFN0YXNoIE9yIFRyYXNoIHwgVGhlIEJyYW5kIEJhcm9tZXRlclwiO1xuY29uc3QgREVGQVVMVF9ERVNDID1cbiAgXCJTT1QgKFN0YXNoIE9yIFRyYXNoKSBpcyB0aGUgQnJhbmQgQmFyb21ldGVyIOKAlCBhIENYL1VYIG1hcmtldGluZyAmIFBSIHRvb2wgd2hlcmUgdGhlIGNvbW11bml0eSBkZWxpdmVycyBhIGxpdmUgdmVyZGljdCBvbiBicmFuZHMuIENhc3QgeW91cnMgYW5kIGtlZXAgeW91ciBzdHJlYWsgYWxpdmUuXCI7XG5jb25zdCBTSVRFX05BTUUgPSBcIlNPVCDigJQgU3Rhc2ggT3IgVHJhc2hcIjtcblxuZnVuY3Rpb24gdXBkYXRlTWV0YVRhZyhhdHRyaWJ1dGVOYW1lOiBcIm5hbWVcIiB8IFwicHJvcGVydHlcIiwgYXR0cmlidXRlVmFsdWU6IHN0cmluZywgY29udGVudDogc3RyaW5nIHwgbnVsbCkge1xuICBpZiAodHlwZW9mIGRvY3VtZW50ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm47XG5cbiAgbGV0IGVsZW1lbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yPEhUTUxNZXRhRWxlbWVudD4oYG1ldGFbJHthdHRyaWJ1dGVOYW1lfT1cIiR7YXR0cmlidXRlVmFsdWV9XCJdYCk7XG4gIGlmICghY29udGVudCkge1xuICAgIGlmIChlbGVtZW50KSB7XG4gICAgICBlbGVtZW50LnJlbW92ZSgpO1xuICAgIH1cbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAoIWVsZW1lbnQpIHtcbiAgICBlbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcIm1ldGFcIik7XG4gICAgZWxlbWVudC5zZXRBdHRyaWJ1dGUoYXR0cmlidXRlTmFtZSwgYXR0cmlidXRlVmFsdWUpO1xuICAgIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoZWxlbWVudCk7XG4gIH1cbiAgZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJjb250ZW50XCIsIGNvbnRlbnQpO1xufVxuXG5mdW5jdGlvbiB1cGRhdGVMaW5rVGFnKHJlbDogc3RyaW5nLCBocmVmOiBzdHJpbmcgfCBudWxsKSB7XG4gIGlmICh0eXBlb2YgZG9jdW1lbnQgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybjtcblxuICBsZXQgZWxlbWVudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3I8SFRNTExpbmtFbGVtZW50PihgbGlua1tyZWw9XCIke3JlbH1cIl1gKTtcbiAgaWYgKCFocmVmKSB7XG4gICAgaWYgKGVsZW1lbnQpIHtcbiAgICAgIGVsZW1lbnQucmVtb3ZlKCk7XG4gICAgfVxuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmICghZWxlbWVudCkge1xuICAgIGVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwibGlua1wiKTtcbiAgICBlbGVtZW50LnNldEF0dHJpYnV0ZShcInJlbFwiLCByZWwpO1xuICAgIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoZWxlbWVudCk7XG4gIH1cbiAgZWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJocmVmXCIsIGhyZWYpO1xufVxuXG4vKipcbiAqIFJlYWN0IEhlbG1ldCBjb21wb25lbnQgZm9yIHRoZSBTT1QgQnJhbmQgQmFyb21ldGVyIGFwcCBzaGVsbCAmIHZpZXdzLlxuICogRHluYW1pY2FsbHkgdXBkYXRlcyBkb2N1bWVudCB0aXRsZSwgc3RhbmRhcmQgbWV0YSBkZXNjcmlwdGlvbnMsIE9wZW5HcmFwaCxcbiAqIFR3aXR0ZXIgY2FyZCB0YWdzLCBhbmQgU2NoZW1hLm9yZyBKU09OLUxEIHN0cnVjdHVyZWQgZGF0YS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFNlb0hlbG1ldCh7XG4gIHRpdGxlLFxuICBkZXNjcmlwdGlvbiA9IERFRkFVTFRfREVTQyxcbiAga2V5d29yZHMsXG4gIGNhbm9uaWNhbFVybCxcbiAgb2dUeXBlID0gXCJ3ZWJzaXRlXCIsXG4gIG9nSW1hZ2UgPSBcIi9hcHBsZS10b3VjaC1pY29uLnBuZ1wiLFxuICBvZ1RpdGxlLFxuICBvZ0Rlc2NyaXB0aW9uLFxuICB0d2l0dGVyQ2FyZCA9IFwic3VtbWFyeV9sYXJnZV9pbWFnZVwiLFxuICBub0luZGV4ID0gZmFsc2UsXG4gIHN0cnVjdHVyZWREYXRhLFxufTogU2VvSGVsbWV0UHJvcHMpIHtcbiAgY29uc3QgZnVsbFRpdGxlID0gdGl0bGVcbiAgICA/IHRpdGxlLmluY2x1ZGVzKFwiU09UXCIpIHx8IHRpdGxlLmluY2x1ZGVzKFwiQnJhbmQgQmFyb21ldGVyXCIpXG4gICAgICA/IHRpdGxlXG4gICAgICA6IGAke3RpdGxlfSB8IFNPVCBCcmFuZCBCYXJvbWV0ZXJgXG4gICAgOiBERUZBVUxUX1RJVExFO1xuXG4gIGNvbnN0IHJlc29sdmVkT2dUaXRsZSA9IG9nVGl0bGUgfHwgZnVsbFRpdGxlO1xuICBjb25zdCByZXNvbHZlZE9nRGVzYyA9IG9nRGVzY3JpcHRpb24gfHwgZGVzY3JpcHRpb247XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAodHlwZW9mIGRvY3VtZW50ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm47XG5cbiAgICAvLyBEb2N1bWVudCB0aXRsZVxuICAgIGRvY3VtZW50LnRpdGxlID0gZnVsbFRpdGxlO1xuXG4gICAgLy8gU3RhbmRhcmQgbWV0YSB0YWdzXG4gICAgdXBkYXRlTWV0YVRhZyhcIm5hbWVcIiwgXCJkZXNjcmlwdGlvblwiLCBkZXNjcmlwdGlvbik7XG4gICAgaWYgKGtleXdvcmRzICYmIGtleXdvcmRzLmxlbmd0aCA+IDApIHtcbiAgICAgIHVwZGF0ZU1ldGFUYWcoXCJuYW1lXCIsIFwia2V5d29yZHNcIiwga2V5d29yZHMuam9pbihcIiwgXCIpKTtcbiAgICB9XG4gICAgaWYgKG5vSW5kZXgpIHtcbiAgICAgIHVwZGF0ZU1ldGFUYWcoXCJuYW1lXCIsIFwicm9ib3RzXCIsIFwibm9pbmRleCwgbm9mb2xsb3dcIik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHVwZGF0ZU1ldGFUYWcoXCJuYW1lXCIsIFwicm9ib3RzXCIsIFwiaW5kZXgsIGZvbGxvd1wiKTtcbiAgICB9XG5cbiAgICAvLyBDYW5vbmljYWwgbGlua1xuICAgIGNvbnN0IHJlc29sdmVkQ2Fub25pY2FsID1cbiAgICAgIGNhbm9uaWNhbFVybCB8fCAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiA/IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4gKyB3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUgOiBudWxsKTtcbiAgICB1cGRhdGVMaW5rVGFnKFwiY2Fub25pY2FsXCIsIHJlc29sdmVkQ2Fub25pY2FsKTtcblxuICAgIC8vIE9wZW5HcmFwaCBtZXRhIHRhZ3NcbiAgICB1cGRhdGVNZXRhVGFnKFwicHJvcGVydHlcIiwgXCJvZzp0aXRsZVwiLCByZXNvbHZlZE9nVGl0bGUpO1xuICAgIHVwZGF0ZU1ldGFUYWcoXCJwcm9wZXJ0eVwiLCBcIm9nOmRlc2NyaXB0aW9uXCIsIHJlc29sdmVkT2dEZXNjKTtcbiAgICB1cGRhdGVNZXRhVGFnKFwicHJvcGVydHlcIiwgXCJvZzp0eXBlXCIsIG9nVHlwZSk7XG4gICAgdXBkYXRlTWV0YVRhZyhcInByb3BlcnR5XCIsIFwib2c6c2l0ZV9uYW1lXCIsIFNJVEVfTkFNRSk7XG4gICAgaWYgKHJlc29sdmVkQ2Fub25pY2FsKSB7XG4gICAgICB1cGRhdGVNZXRhVGFnKFwicHJvcGVydHlcIiwgXCJvZzp1cmxcIiwgcmVzb2x2ZWRDYW5vbmljYWwpO1xuICAgIH1cbiAgICBpZiAob2dJbWFnZSkge1xuICAgICAgY29uc3QgZnVsbEltYWdlVXJsID1cbiAgICAgICAgb2dJbWFnZS5zdGFydHNXaXRoKFwiaHR0cFwiKSB8fCB0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiXG4gICAgICAgICAgPyBvZ0ltYWdlXG4gICAgICAgICAgOiBgJHt3aW5kb3cubG9jYXRpb24ub3JpZ2lufSR7b2dJbWFnZS5zdGFydHNXaXRoKFwiL1wiKSA/IFwiXCIgOiBcIi9cIn0ke29nSW1hZ2V9YDtcbiAgICAgIHVwZGF0ZU1ldGFUYWcoXCJwcm9wZXJ0eVwiLCBcIm9nOmltYWdlXCIsIGZ1bGxJbWFnZVVybCk7XG4gICAgfVxuXG4gICAgLy8gVHdpdHRlciBjYXJkIHRhZ3NcbiAgICB1cGRhdGVNZXRhVGFnKFwibmFtZVwiLCBcInR3aXR0ZXI6Y2FyZFwiLCB0d2l0dGVyQ2FyZCk7XG4gICAgdXBkYXRlTWV0YVRhZyhcIm5hbWVcIiwgXCJ0d2l0dGVyOnRpdGxlXCIsIHJlc29sdmVkT2dUaXRsZSk7XG4gICAgdXBkYXRlTWV0YVRhZyhcIm5hbWVcIiwgXCJ0d2l0dGVyOmRlc2NyaXB0aW9uXCIsIHJlc29sdmVkT2dEZXNjKTtcbiAgICBpZiAob2dJbWFnZSkge1xuICAgICAgY29uc3QgZnVsbEltYWdlVXJsID1cbiAgICAgICAgb2dJbWFnZS5zdGFydHNXaXRoKFwiaHR0cFwiKSB8fCB0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiXG4gICAgICAgICAgPyBvZ0ltYWdlXG4gICAgICAgICAgOiBgJHt3aW5kb3cubG9jYXRpb24ub3JpZ2lufSR7b2dJbWFnZS5zdGFydHNXaXRoKFwiL1wiKSA/IFwiXCIgOiBcIi9cIn0ke29nSW1hZ2V9YDtcbiAgICAgIHVwZGF0ZU1ldGFUYWcoXCJuYW1lXCIsIFwidHdpdHRlcjppbWFnZVwiLCBmdWxsSW1hZ2VVcmwpO1xuICAgIH1cblxuICAgIC8vIEpTT04tTEQgU3RydWN0dXJlZCBEYXRhXG4gICAgY29uc3Qgc2NyaXB0SWQgPSBcInNvdC1zZW8tanNvbmxkXCI7XG4gICAgbGV0IHNjcmlwdEVsZW1lbnQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChzY3JpcHRJZCkgYXMgSFRNTFNjcmlwdEVsZW1lbnQgfCBudWxsO1xuICAgIGlmIChzdHJ1Y3R1cmVkRGF0YSkge1xuICAgICAgaWYgKCFzY3JpcHRFbGVtZW50KSB7XG4gICAgICAgIHNjcmlwdEVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic2NyaXB0XCIpO1xuICAgICAgICBzY3JpcHRFbGVtZW50LmlkID0gc2NyaXB0SWQ7XG4gICAgICAgIHNjcmlwdEVsZW1lbnQudHlwZSA9IFwiYXBwbGljYXRpb24vbGQranNvblwiO1xuICAgICAgICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKHNjcmlwdEVsZW1lbnQpO1xuICAgICAgfVxuICAgICAgc2NyaXB0RWxlbWVudC50ZXh0Q29udGVudCA9IEpTT04uc3RyaW5naWZ5KHN0cnVjdHVyZWREYXRhKTtcbiAgICB9IGVsc2UgaWYgKHNjcmlwdEVsZW1lbnQpIHtcbiAgICAgIHNjcmlwdEVsZW1lbnQucmVtb3ZlKCk7XG4gICAgfVxuICB9LCBbXG4gICAgZnVsbFRpdGxlLFxuICAgIGRlc2NyaXB0aW9uLFxuICAgIGtleXdvcmRzLFxuICAgIGNhbm9uaWNhbFVybCxcbiAgICBvZ1R5cGUsXG4gICAgb2dJbWFnZSxcbiAgICByZXNvbHZlZE9nVGl0bGUsXG4gICAgcmVzb2x2ZWRPZ0Rlc2MsXG4gICAgdHdpdHRlckNhcmQsXG4gICAgbm9JbmRleCxcbiAgICBzdHJ1Y3R1cmVkRGF0YSxcbiAgXSk7XG5cbiAgcmV0dXJuIG51bGw7XG59XG5cbmV4cG9ydCBkZWZhdWx0IFNlb0hlbG1ldDtcbiJdfQ==