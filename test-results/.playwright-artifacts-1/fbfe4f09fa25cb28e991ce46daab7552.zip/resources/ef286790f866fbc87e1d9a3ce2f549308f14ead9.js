import { supabase } from "/src/integrations/supabase/client.ts";
import { createFirestoreBrand, getFirestoreBrands } from "/src/services/firestoreService.ts";
import { countryName, normalizeCountryCode } from "/src/lib/geo.ts";
export const ISO_TO_QID = {
	ZA: "Q258",
	US: "Q30",
	GB: "Q145",
	FR: "Q142",
	DE: "Q183",
	IT: "Q38",
	ES: "Q29",
	PT: "Q45",
	NL: "Q55",
	BR: "Q155",
	IN: "Q668",
	CN: "Q148",
	JP: "Q17",
	KR: "Q884",
	MX: "Q96",
	CA: "Q16",
	AU: "Q408",
	NG: "Q1033",
	KE: "Q114",
	EG: "Q79",
	MA: "Q1028",
	GH: "Q117",
	SN: "Q1041",
	ET: "Q115",
	TZ: "Q924",
	UG: "Q1036",
	RW: "Q1037",
	BW: "Q963",
	NA: "Q1030",
	ZW: "Q954",
	ZM: "Q953",
	MZ: "Q1029",
	AO: "Q916",
	CM: "Q1009",
	CI: "Q1008",
	DZ: "Q262",
	TN: "Q948",
	MU: "Q1027",
	LS: "Q1013",
	SZ: "Q1050",
	MW: "Q1020",
	CD: "Q974",
	CH: "Q39",
	SE: "Q34",
	NO: "Q20",
	DK: "Q35",
	FI: "Q33",
	IE: "Q27",
	BE: "Q31",
	AT: "Q40",
	PL: "Q36",
	GR: "Q41",
	TR: "Q43",
	RU: "Q159",
	UA: "Q212",
	CZ: "Q213",
	RO: "Q218",
	AR: "Q414",
	CL: "Q298",
	CO: "Q739",
	PE: "Q419",
	UY: "Q77",
	AE: "Q878",
	SA: "Q851",
	QA: "Q846",
	IL: "Q801",
	SG: "Q334",
	MY: "Q833",
	ID: "Q252",
	TH: "Q869",
	PH: "Q928",
	VN: "Q881",
	PK: "Q843",
	BD: "Q902",
	LK: "Q854",
	NZ: "Q664",
	HK: "Q8646",
	TW: "Q865"
};
export const SUPPORTED_IMPORT_COUNTRIES = [
	["ZA", "🇿🇦 South Africa"],
	["NG", "🇳🇬 Nigeria"],
	["KE", "🇰🇪 Kenya"],
	["GH", "🇬🇭 Ghana"],
	["EG", "🇪🇬 Egypt"],
	["MA", "🇲🇦 Morocco"],
	["ET", "🇪🇹 Ethiopia"],
	["SN", "🇸🇳 Senegal"],
	["TZ", "🇹🇿 Tanzania"],
	["UG", "🇺🇬 Uganda"],
	["RW", "🇷🇼 Rwanda"],
	["BW", "🇧🇼 Botswana"],
	["NA", "🇳🇦 Namibia"],
	["ZW", "🇿🇼 Zimbabwe"],
	["ZM", "🇿🇲 Zambia"],
	["LS", "🇱🇸 Lesotho"],
	["SZ", "🇸🇿 Eswatini"],
	["MZ", "🇲🇿 Mozambique"],
	["AO", "🇦🇴 Angola"],
	["CM", "🇨🇲 Cameroon"],
	["CI", "🇨🇮 Côte d'Ivoire"],
	["MU", "🇲🇺 Mauritius"],
	["US", "🇺🇸 United States"],
	["GB", "🇬🇧 United Kingdom"],
	["FR", "🇫🇷 France"],
	["DE", "🇩🇪 Germany"],
	["ES", "🇪🇸 Spain"],
	["PT", "🇵🇹 Portugal"],
	["IT", "🇮🇹 Italy"],
	["NL", "🇳🇱 Netherlands"],
	["CH", "🇨🇭 Switzerland"],
	["SE", "🇸🇪 Sweden"],
	["IE", "🇮🇪 Ireland"],
	["PL", "🇵🇱 Poland"],
	["TR", "🇹🇷 Türkiye"],
	["BR", "🇧🇷 Brazil"],
	["MX", "🇲🇽 Mexico"],
	["CA", "🇨🇦 Canada"],
	["AR", "🇦🇷 Argentina"],
	["CO", "🇨🇴 Colombia"],
	["CL", "🇨🇱 Chile"],
	["IN", "🇮🇳 India"],
	["CN", "🇨🇳 China"],
	["JP", "🇯🇵 Japan"],
	["KR", "🇰🇷 South Korea"],
	["AU", "🇦🇺 Australia"],
	["NZ", "🇳🇿 New Zealand"],
	["AE", "🇦🇪 United Arab Emirates"],
	["SA", "🇸🇦 Saudi Arabia"],
	["SG", "🇸🇬 Singapore"],
	["ID", "🇮🇩 Indonesia"],
	["MY", "🇲🇾 Malaysia"],
	["PH", "🇵🇭 Philippines"],
	["TH", "🇹🇭 Thailand"],
	["VN", "🇻🇳 Vietnam"]
];
const SPARQL_ENDPOINT = "https://query.wikidata.org/sparql";
const WIKIDATA_API = "https://www.wikidata.org/w/api.php";
const CANDIDATES_STORAGE_KEY = "sot-brand-import-candidates-v1";
const IMPORTED_BRANDS_STORAGE_KEY = "sot-imported-brands-v1";
/**
* Curated high-signal national & regional brands by ISO country code.
* Ensures instant, rich multi-country discovery even when Wikidata SPARQL throttles.
*/
const GLOBAL_COUNTRY_ATLAS = {
	ZA: [
		{
			name: "Capitec Bank",
			category: "Banking & Finance",
			domain: "capitecbank.co.za",
			description: "South African retail bank known for digital banking and accessible branches."
		},
		{
			name: "Shoprite",
			category: "Groceries & Supermarkets",
			domain: "shoprite.co.za",
			description: "Africa's largest supermarket retailer headquartered in Cape Town."
		},
		{
			name: "Checkers Sixty60",
			category: "Delivery & On-Demand",
			domain: "checkers.co.za",
			description: "On-demand 60-minute grocery delivery service across South Africa."
		},
		{
			name: "Woolworths South Africa",
			category: "Groceries & Fashion",
			domain: "woolworths.co.za",
			description: "Premium South African food, fashion, beauty, and homeware retailer."
		},
		{
			name: "MTN South Africa",
			category: "Telecoms",
			domain: "mtn.co.za",
			description: "Pan-African mobile telecommunications and fintech network."
		},
		{
			name: "Vodacom",
			category: "Telecoms",
			domain: "vodacom.co.za",
			description: "Leading South African mobile communications and M-Pesa operator."
		},
		{
			name: "First National Bank (FNB)",
			category: "Banking & Finance",
			domain: "fnb.co.za",
			description: "Innovative South African commercial and retail bank."
		},
		{
			name: "Standard Bank",
			category: "Banking & Finance",
			domain: "standardbank.co.za",
			description: "Africa's largest banking group by assets, founded in South Africa."
		},
		{
			name: "Nando's",
			category: "Food & Restaurants",
			domain: "nandos.co.za",
			description: "Iconic South African flame-grilled peri-peri chicken restaurant chain."
		},
		{
			name: "Takealot",
			category: "E-Commerce",
			domain: "takealot.com",
			description: "South Africa's leading online marketplace and logistics network."
		},
		{
			name: "Discovery",
			category: "Insurance & Healthcare",
			domain: "discovery.co.za",
			description: "Shared-value health insurance, Vitality rewards, and digital banking group."
		},
		{
			name: "Clickatell",
			category: "Technology",
			domain: "clickatell.com",
			description: "Chat commerce and mobile messaging pioneer founded in South Africa."
		},
		{
			name: "Pick n Pay",
			category: "Groceries & Supermarkets",
			domain: "pnp.co.za",
			description: "Major South African supermarket, clothing, and hypermarket chain."
		},
		{
			name: "Sasol",
			category: "Energy & Fuel",
			domain: "sasol.com",
			description: "Integrated energy and chemical company headquartered in Sandton."
		}
	],
	NG: [
		{
			name: "Flutterwave",
			category: "Fintech & Payments",
			domain: "flutterwave.com",
			description: "Pan-African payments technology company powering global commerce."
		},
		{
			name: "Paystack",
			category: "Fintech & Payments",
			domain: "paystack.com",
			description: "Modern online and offline payment gateway for African businesses."
		},
		{
			name: "Moniepoint",
			category: "Banking & Fintech",
			domain: "moniepoint.com",
			description: "All-in-one business banking, POS, and consumer payments platform in Nigeria."
		},
		{
			name: "GTCO (Guaranty Trust Bank)",
			category: "Banking & Finance",
			domain: "gtbank.com",
			description: "Leading Nigerian financial services institution."
		},
		{
			name: "Zenith Bank",
			category: "Banking & Finance",
			domain: "zenithbank.com",
			description: "Tier-1 Nigerian commercial and corporate bank."
		},
		{
			name: "Access Bank",
			category: "Banking & Finance",
			domain: "accessbankplc.com",
			description: "Multinational commercial bank headquartered in Lagos."
		},
		{
			name: "Dangote Group",
			category: "Manufacturing & FMCG",
			domain: "dangote.com",
			description: "West Africa's largest industrial conglomerate across cement, sugar, and energy."
		},
		{
			name: "Jumia Nigeria",
			category: "E-Commerce",
			domain: "jumia.com.ng",
			description: "Pan-African online retail marketplace and logistics service."
		},
		{
			name: "Air Peace",
			category: "Airlines & Travel",
			domain: "flyairpeace.com",
			description: "Largest private Nigerian airline serving domestic and international routes."
		},
		{
			name: "Kuda Bank",
			category: "Digital Banking",
			domain: "kuda.com",
			description: "Mobile-first digital challenger bank built for Nigerians."
		}
	],
	KE: [
		{
			name: "Safaricom (M-Pesa)",
			category: "Telecoms & Fintech",
			domain: "safaricom.co.ke",
			description: "Kenya's leading telecoms provider and pioneer of M-Pesa mobile money."
		},
		{
			name: "Equity Bank Kenya",
			category: "Banking & Finance",
			domain: "equitygroupholdings.com",
			description: "East Africa's largest banking group by customer base."
		},
		{
			name: "KCB Bank",
			category: "Banking & Finance",
			domain: "kcbgroup.com",
			description: "Premier East African commercial bank headquartered in Nairobi."
		},
		{
			name: "Kenya Airways",
			category: "Airlines & Travel",
			domain: "kenya-airways.com",
			description: "The Pride of Africa — flag carrier airline of Kenya."
		},
		{
			name: "Naivas Supermarket",
			category: "Groceries & Supermarkets",
			domain: "naivas.online",
			description: "Kenya's largest homegrown supermarket retail chain."
		},
		{
			name: "Java House",
			category: "Food & Coffee",
			domain: "javahouseafrica.com",
			description: "East Africa's leading coffee and casual dining restaurant brand."
		},
		{
			name: "Twiga Foods",
			category: "AgriTech & Retail",
			domain: "twigafoods.com",
			description: "B2B food distribution platform connecting farmers and vendors in Kenya."
		}
	],
	GH: [
		{
			name: "MTN Ghana",
			category: "Telecoms & MoMo",
			domain: "mtn.com.gh",
			description: "Market-leading telecommunications and Mobile Money operator in Ghana."
		},
		{
			name: "Ecobank",
			category: "Banking & Finance",
			domain: "ecobank.com",
			description: "Pan-African banking conglomerate with major operations across Ghana and West Africa."
		},
		{
			name: "GCB Bank",
			category: "Banking & Finance",
			domain: "gcbbank.com.gh",
			description: "Ghana's largest indigenous commercial bank."
		},
		{
			name: "Hubtel",
			category: "Fintech & Delivery",
			domain: "hubtel.com",
			description: "Ghanaian everyday payment, messaging, and quick-commerce super-app."
		},
		{
			name: "Kasapreko",
			category: "Beverages & FMCG",
			domain: "kasaprekogh.com",
			description: "Leading Ghanaian beverage manufacturer."
		},
		{
			name: "Melcom",
			category: "Retail & Department Stores",
			domain: "melcom.com",
			description: "Ghana's largest chain of retail department stores."
		}
	],
	EG: [
		{
			name: "Fawry",
			category: "Fintech & E-Payments",
			domain: "fawry.com",
			description: "Egypt's premier digital transformation and electronic payments network."
		},
		{
			name: "Commercial International Bank (CIB)",
			category: "Banking & Finance",
			domain: "cibeg.com",
			description: "Egypt's leading private-sector bank."
		},
		{
			name: "EgyptAir",
			category: "Airlines & Travel",
			domain: "egyptair.com",
			description: "State-owned flag carrier airline of Egypt."
		},
		{
			name: "Vodafone Egypt",
			category: "Telecoms",
			domain: "vodafone.com.eg",
			description: "Largest mobile network operator and Vodafone Cash provider in Egypt."
		},
		{
			name: "Swvl",
			category: "Mobility & Transit",
			domain: "swvl.com",
			description: "Tech-enabled mass transit and shared mobility platform born in Cairo."
		},
		{
			name: "Breadfast",
			category: "Quick Commerce",
			domain: "breadfast.com",
			description: "On-demand groceries, bakery, and household essentials delivery in Egypt."
		}
	],
	MA: [
		{
			name: "Royal Air Maroc",
			category: "Airlines & Travel",
			domain: "royalairmaroc.com",
			description: "National carrier airline of Morocco connecting Africa to the world."
		},
		{
			name: "Attijariwafa Bank",
			category: "Banking & Finance",
			domain: "attijariwafabank.com",
			description: "Leading banking and financial group in North and West Africa."
		},
		{
			name: "Maroc Telecom",
			category: "Telecoms",
			domain: "iam.ma",
			description: "Main telecommunications company in Morocco."
		},
		{
			name: "OCP Group",
			category: "Industry & Agriculture",
			domain: "ocpgroup.ma",
			description: "Global leader in plant nutrition and phosphate-based fertilizers."
		},
		{
			name: "Marjane",
			category: "Groceries & Hypermarkets",
			domain: "marjane.ma",
			description: "Morocco's leading hypermarket and retail chain."
		}
	],
	ET: [
		{
			name: "Ethiopian Airlines",
			category: "Airlines & Travel",
			domain: "ethiopianairlines.com",
			description: "Africa's largest airline by passengers, destinations, and fleet size."
		},
		{
			name: "Ethio Telecom (Telebirr)",
			category: "Telecoms & Fintech",
			domain: "ethiotelecom.et",
			description: "National telecommunications and Telebirr mobile money provider."
		},
		{
			name: "Commercial Bank of Ethiopia",
			category: "Banking & Finance",
			domain: "combanketh.et",
			description: "Largest commercial bank in Ethiopia."
		},
		{
			name: "Safaricom Ethiopia",
			category: "Telecoms",
			domain: "safaricom.et",
			description: "High-speed 4G/5G telecommunications and M-Pesa network in Ethiopia."
		}
	],
	SN: [
		{
			name: "Wave Mobile Money",
			category: "Fintech",
			domain: "wave.com",
			description: "Ultra-low-fee mobile money platform dominating Senegal and Francophone West Africa."
		},
		{
			name: "Sonatel (Orange Sénégal)",
			category: "Telecoms",
			domain: "sonatel.sn",
			description: "Senegal's premier telecommunications provider."
		},
		{
			name: "Air Sénégal",
			category: "Airlines & Travel",
			domain: "flyairsenegal.com",
			description: "Flag carrier airline of the Republic of Senegal."
		}
	],
	TZ: [
		{
			name: "CRDB Bank",
			category: "Banking & Finance",
			domain: "crdbbank.co.tz",
			description: "Leading commercial bank in Tanzania and East Africa."
		},
		{
			name: "NMB Bank Tanzania",
			category: "Banking & Finance",
			domain: "nmbbank.co.tz",
			description: "Major retail and agricultural bank across Tanzania."
		},
		{
			name: "Vodacom Tanzania",
			category: "Telecoms",
			domain: "vodacom.co.tz",
			description: "Leading wireless telecommunications and M-Pesa network in Tanzania."
		},
		{
			name: "Bakhresa Group (Azam)",
			category: "Food, Media & FMCG",
			domain: "bakhresa.com",
			description: "Iconic Tanzanian conglomerate behind Azam Food, beverages, and Azam TV."
		}
	],
	BW: [
		{
			name: "First National Bank Botswana",
			category: "Banking & Finance",
			domain: "fnbbotswana.co.bw",
			description: "Leading commercial and digital bank in Botswana."
		},
		{
			name: "Choppies",
			category: "Groceries & Supermarkets",
			domain: "choppies.co.bw",
			description: "Botswana-born multinational grocery and supermarket retailer."
		},
		{
			name: "Mascom Wireless",
			category: "Telecoms",
			domain: "mascom.bw",
			description: "Botswana's premier mobile telecommunications provider."
		},
		{
			name: "Air Botswana",
			category: "Airlines & Travel",
			domain: "airbotswana.co.bw",
			description: "National flag carrier airline of Botswana."
		}
	],
	NA: [
		{
			name: "Bank Windhoek",
			category: "Banking & Finance",
			domain: "bankwindhoek.com.na",
			description: "Flagship homegrown commercial bank of Namibia."
		},
		{
			name: "MTC Namibia",
			category: "Telecoms",
			domain: "mtc.com.na",
			description: "Mobile Telecommunications Limited — Namibia's leading network."
		},
		{
			name: "Namibia Breweries",
			category: "Beverages",
			domain: "nambrew.com",
			description: "Producers of Windhoek Lager and Tafel Lager."
		}
	],
	ZW: [
		{
			name: "Econet Wireless Zimbabwe",
			category: "Telecoms & EcoCash",
			domain: "econet.co.zw",
			description: "Zimbabwe's largest telecommunications and EcoCash fintech provider."
		},
		{
			name: "Delta Corporation",
			category: "Beverages & FMCG",
			domain: "delta.co.zw",
			description: "Leading beverage manufacturer in Zimbabwe."
		},
		{
			name: "CBZ Holdings",
			category: "Banking & Finance",
			domain: "cbz.co.zw",
			description: "Financial services group and commercial bank in Zimbabwe."
		},
		{
			name: "Innscor Africa (Simbisa)",
			category: "Food & Retail",
			domain: "simbisabrands.com",
			description: "Fast-food and consumer staples leader behind Chicken Inn and Pizza Inn."
		}
	],
	LS: [
		{
			name: "Vodacom Lesotho",
			category: "Telecoms & M-Pesa",
			domain: "vodacom.co.ls",
			description: "Leading telecommunications and M-Pesa provider in Lesotho."
		},
		{
			name: "Econet Telecom Lesotho",
			category: "Telecoms",
			domain: "etl.co.ls",
			description: "Integrated telecommunications operator in the Kingdom of Lesotho."
		},
		{
			name: "Standard Lesotho Bank",
			category: "Banking & Finance",
			domain: "standardlesothobank.co.ls",
			description: "Largest commercial bank in Lesotho."
		},
		{
			name: "Maluti Mountain Brewery",
			category: "Beverages",
			domain: "ab-inbev.com",
			description: "Lesotho's flagship beverage producer."
		}
	],
	US: [
		{
			name: "Apple",
			category: "Technology & Consumer Electronics",
			domain: "apple.com",
			description: "Maker of iPhone, Mac, iPad, Apple Watch, and consumer software ecosystems."
		},
		{
			name: "Amazon",
			category: "E-Commerce & Cloud",
			domain: "amazon.com",
			description: "Global e-commerce marketplace, Prime delivery, and cloud computing platform."
		},
		{
			name: "Nike",
			category: "Apparel & Footwear",
			domain: "nike.com",
			description: "World's largest supplier of athletic shoes and sports apparel."
		},
		{
			name: "Netflix",
			category: "Streaming & Entertainment",
			domain: "netflix.com",
			description: "Global subscription streaming service and production company."
		},
		{
			name: "Starbucks",
			category: "Food & Coffee",
			domain: "starbucks.com",
			description: "Multinational chain of coffeehouses and roastery reserves."
		},
		{
			name: "Tesla",
			category: "Automotive & Clean Energy",
			domain: "tesla.com",
			description: "Electric vehicles, battery energy storage, and Supercharger network."
		},
		{
			name: "Microsoft",
			category: "Technology & Software",
			domain: "microsoft.com",
			description: "Global software, Windows, Xbox, and Azure cloud leader."
		},
		{
			name: "Delta Air Lines",
			category: "Airlines & Travel",
			domain: "delta.com",
			description: "Major American airline serving domestic and international travellers."
		},
		{
			name: "Costco Wholesale",
			category: "Retail & Warehouse",
			domain: "costco.com",
			description: "Membership-only big-box warehouse club retail chain."
		},
		{
			name: "JPMorgan Chase",
			category: "Banking & Finance",
			domain: "chase.com",
			description: "Largest consumer and commercial bank in the United States."
		}
	],
	GB: [
		{
			name: "Revolut",
			category: "Fintech & Digital Banking",
			domain: "revolut.com",
			description: "Global financial super-app and digital bank headquartered in London."
		},
		{
			name: "Monzo",
			category: "Digital Banking",
			domain: "monzo.com",
			description: "App-based UK retail bank cherished for real-time spending insights."
		},
		{
			name: "Marks & Spencer (M&S)",
			category: "Retail & Groceries",
			domain: "marksandspencer.com",
			description: "Iconic British retailer of food, clothing, and home products."
		},
		{
			name: "Tesco",
			category: "Groceries & Supermarkets",
			domain: "tesco.com",
			description: "The UK's largest supermarket and grocery retail chain."
		},
		{
			name: "British Airways",
			category: "Airlines & Travel",
			domain: "britishairways.com",
			description: "Flag carrier airline of the United Kingdom."
		},
		{
			name: "Dyson",
			category: "Consumer Appliances",
			domain: "dyson.co.uk",
			description: "British engineering brand designing vacuum cleaners, air purifiers, and hair care."
		},
		{
			name: "Octopus Energy",
			category: "Clean Energy & Utilities",
			domain: "octopus.energy",
			description: "Customer-acclaimed renewable energy supplier headquartered in the UK."
		}
	],
	FR: [
		{
			name: "Louis Vuitton",
			category: "Luxury Fashion",
			domain: "louisvuitton.com",
			description: "French luxury fashion house and flagship maison of LVMH."
		},
		{
			name: "L'Oréal",
			category: "Beauty & Cosmetics",
			domain: "loreal.com",
			description: "World's largest cosmetics, skincare, and beauty company."
		},
		{
			name: "Carrefour",
			category: "Groceries & Hypermarkets",
			domain: "carrefour.fr",
			description: "French multinational retail and hypermarket corporation."
		},
		{
			name: "Air France",
			category: "Airlines & Travel",
			domain: "airfrance.com",
			description: "Flag carrier airline of France."
		},
		{
			name: "Decathlon",
			category: "Sports & Outdoor Retail",
			domain: "decathlon.fr",
			description: "World's largest sporting goods retailer, founded in France."
		},
		{
			name: "Danone",
			category: "Food & Beverages",
			domain: "danone.com",
			description: "Global dairy, plant-based nutrition, and bottled water company."
		}
	],
	DE: [
		{
			name: "Adidas",
			category: "Apparel & Sportswear",
			domain: "adidas.com",
			description: "German athletic footwear and sportswear giant."
		},
		{
			name: "BMW",
			category: "Automotive",
			domain: "bmw.com",
			description: "Bayerische Motoren Werke — luxury vehicles and motorcycles."
		},
		{
			name: "Mercedes-Benz",
			category: "Automotive",
			domain: "mercedes-benz.com",
			description: "German luxury and commercial vehicle automotive marque."
		},
		{
			name: "Lidl",
			category: "Groceries & Supermarkets",
			domain: "lidl.de",
			description: "International discount retailer operating over 12,000 stores."
		},
		{
			name: "N26",
			category: "Digital Banking",
			domain: "n26.com",
			description: "Berlin-based pan-European mobile bank."
		},
		{
			name: "Lufthansa",
			category: "Airlines & Travel",
			domain: "lufthansa.com",
			description: "Flag carrier and largest airline of Germany."
		}
	],
	ES: [
		{
			name: "Zara (Inditex)",
			category: "Fashion & Apparel",
			domain: "zara.com",
			description: "Spanish fast-fashion retail flagship of the Inditex Group."
		},
		{
			name: "Mercadona",
			category: "Groceries & Supermarkets",
			domain: "mercadona.es",
			description: "Spain's leading physical and online supermarket chain."
		},
		{
			name: "Banco Santander",
			category: "Banking & Finance",
			domain: "santander.com",
			description: "Spanish multinational financial services group."
		},
		{
			name: "Iberia",
			category: "Airlines & Travel",
			domain: "iberia.com",
			description: "Flag carrier airline of Spain based in Madrid."
		},
		{
			name: "Cabify",
			category: "Ride-Hailing & Mobility",
			domain: "cabify.com",
			description: "Spanish ride-sharing and urban mobility platform."
		}
	],
	PT: [
		{
			name: "TAP Air Portugal",
			category: "Airlines & Travel",
			domain: "flytap.com",
			description: "State-owned flag carrier airline of Portugal."
		},
		{
			name: "Continente (Sonae)",
			category: "Groceries & Supermarkets",
			domain: "continente.pt",
			description: "Portugal's largest hypermarket and supermarket chain."
		},
		{
			name: "Galp Energia",
			category: "Energy & Fuel",
			domain: "galp.com",
			description: "Portuguese multinational energy corporation."
		},
		{
			name: "Millennium bcp",
			category: "Banking & Finance",
			domain: "millenniumbcp.pt",
			description: "Largest private bank in Portugal."
		}
	],
	BR: [
		{
			name: "Nubank",
			category: "Digital Banking & Fintech",
			domain: "nubank.com.br",
			description: "Latin America's largest fintech bank serving over 100 million customers."
		},
		{
			name: "Mercado Livre",
			category: "E-Commerce & Fintech",
			domain: "mercadolivre.com.br",
			description: "Leading e-commerce and Mercado Pago ecosystem in Brazil."
		},
		{
			name: "iFood",
			category: "Food & Grocery Delivery",
			domain: "ifood.com.br",
			description: "Brazil's dominant online food ordering and delivery platform."
		},
		{
			name: "Natura &Co",
			category: "Beauty & Personal Care",
			domain: "natura.com.br",
			description: "Brazilian sustainable cosmetics and personal care powerhouse."
		},
		{
			name: "Itaú Unibanco",
			category: "Banking & Finance",
			domain: "itau.com.br",
			description: "Largest banking institution in Brazil and Latin America."
		}
	],
	IN: [
		{
			name: "Tata Group",
			category: "Conglomerate & Retail",
			domain: "tata.com",
			description: "India's largest conglomerate spanning automotive, tech, hospitality, and retail."
		},
		{
			name: "Reliance Jio",
			category: "Telecoms & Digital",
			domain: "jio.com",
			description: "India's largest mobile network operator and digital services platform."
		},
		{
			name: "Zomato",
			category: "Food Delivery & Quick Commerce",
			domain: "zomato.com",
			description: "Indian restaurant aggregator, food delivery, and Blinkit parent."
		},
		{
			name: "HDFC Bank",
			category: "Banking & Finance",
			domain: "hdfcbank.com",
			description: "India's largest private sector bank."
		},
		{
			name: "IndiGo",
			category: "Airlines & Travel",
			domain: "goindigo.in",
			description: "India's largest passenger airline by market share."
		}
	],
	JP: [
		{
			name: "Sony",
			category: "Consumer Electronics & Gaming",
			domain: "sony.com",
			description: "Japanese electronics, PlayStation gaming, and entertainment giant."
		},
		{
			name: "Toyota",
			category: "Automotive",
			domain: "toyota.com",
			description: "World's largest automotive manufacturer renowned for reliability."
		},
		{
			name: "Uniqlo (Fast Retailing)",
			category: "Fashion & Apparel",
			domain: "uniqlo.com",
			description: "Japanese casual wear designer, manufacturer, and global retailer."
		},
		{
			name: "Nintendo",
			category: "Gaming & Entertainment",
			domain: "nintendo.com",
			description: "Creator of Switch, Mario, and Zelda interactive entertainment."
		}
	],
	KR: [
		{
			name: "Samsung Electronics",
			category: "Technology & Electronics",
			domain: "samsung.com",
			description: "South Korean global leader in smartphones, TVs, and semiconductors."
		},
		{
			name: "Hyundai Motor",
			category: "Automotive",
			domain: "hyundai.com",
			description: "Global automaker pioneering electric IONIQ vehicles."
		},
		{
			name: "Coupang",
			category: "E-Commerce & Rocket Delivery",
			domain: "coupang.com",
			description: "South Korea's e-commerce leader famous for dawn Rocket Delivery."
		},
		{
			name: "Kakao",
			category: "Technology & Super-App",
			domain: "kakaocorp.com",
			description: "Operator of KakaoTalk, KakaoPay, and KakaoT mobility."
		}
	],
	AE: [
		{
			name: "Emirates",
			category: "Airlines & Aviation",
			domain: "emirates.com",
			description: "Global flag carrier airline based in Dubai."
		},
		{
			name: "Careem",
			category: "Super-App & Mobility",
			domain: "careem.com",
			description: "Middle East ride-hailing, food delivery, and digital payments super-app."
		},
		{
			name: "Noon",
			category: "E-Commerce",
			domain: "noon.com",
			description: "Middle East homegrown online shopping marketplace."
		},
		{
			name: "Etisalat (e&)",
			category: "Telecoms & Technology",
			domain: "eand.com",
			description: "Multinational UAE telecommunications and technology group."
		}
	],
	AU: [
		{
			name: "Woolworths Australia",
			category: "Groceries & Supermarkets",
			domain: "woolworths.com.au",
			description: "Australia's largest supermarket chain."
		},
		{
			name: "Commonwealth Bank (CommBank)",
			category: "Banking & Finance",
			domain: "commbank.com.au",
			description: "Australia's leading retail bank and banking app."
		},
		{
			name: "Qantas",
			category: "Airlines & Travel",
			domain: "qantas.com",
			description: "Flag carrier airline of Australia."
		},
		{
			name: "Canva",
			category: "Technology & Design",
			domain: "canva.com",
			description: "Australian-founded global visual communication and design platform."
		}
	]
};
function slugify(name) {
	return name.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60);
}
export function buildBrandInvitation(input) {
	const origin = typeof window === "undefined" ? "https://stashortrash.vercel.app" : window.location.origin;
	const brandUrl = `${origin}/brands/${input.slug}`;
	return `Subject: ${input.name} is now on SOT — Stash Or Trash\n\nHello ${input.name} team,\n\nWe have opened a live brand-rating page for ${input.name} on SOT — Stash Or Trash, the Consumer Brand Revolution built to turn everyday customer feedback into a credible reputation signal.\n\nYour page: ${brandUrl}\n${input.website ? `Website we found: ${input.website}\n` : ""}\nConsumers can now Stash or Trash brand experiences in public, and verified brand owners can claim their page, monitor sentiment, and respond directly through the platform.\n\nPlease create an account with your official company email, open the page above, and choose “Claim this brand” so our team can verify your ownership.\n\nRegards,\nSOT — Stash Or Trash\nThe Brand Barometer`;
}
function readLocalCandidates() {
	if (typeof window === "undefined") return [];
	try {
		const raw = window.localStorage.getItem(CANDIDATES_STORAGE_KEY);
		return raw ? JSON.parse(raw) : [];
	} catch {
		return [];
	}
}
function writeLocalCandidates(items) {
	if (typeof window === "undefined") return;
	try {
		window.localStorage.setItem(CANDIDATES_STORAGE_KEY, JSON.stringify(items));
	} catch {}
}
export function getLocalImportedBrands() {
	if (typeof window === "undefined") return [];
	try {
		const raw = window.localStorage.getItem(IMPORTED_BRANDS_STORAGE_KEY);
		return raw ? JSON.parse(raw) : [];
	} catch {
		return [];
	}
}
function saveLocalImportedBrands(brands) {
	if (typeof window === "undefined") return;
	try {
		window.localStorage.setItem(IMPORTED_BRANDS_STORAGE_KEY, JSON.stringify(brands));
	} catch {}
}
/**
* Single consolidated SPARQL query per country so Wikidata never rate-limits (429)
* or times out on 10 concurrent connections.
*/
function buildFastCountrySparql(qid, limit) {
	const fetchLimit = Math.min(250, Math.max(limit * 2, 40));
	return `
    SELECT ?item ?itemLabel ?desc ?logo ?website ?industryLabel ?sitelinks WHERE {
      {
        SELECT DISTINCT ?item ?sitelinks WHERE {
          VALUES ?cls { wd:Q4830453 wd:Q891723 wd:Q431289 wd:Q6881511 wd:Q783794 }
          ?item wdt:P31 ?cls ;
                wdt:P17 wd:${qid} ;
                wikibase:sitelinks ?sitelinks .
        }
        ORDER BY DESC(?sitelinks)
        LIMIT ${fetchLimit}
      }
      OPTIONAL { ?item wdt:P154 ?logo }
      OPTIONAL { ?item wdt:P856 ?website }
      OPTIONAL { ?item wdt:P452 ?industry . ?industry rdfs:label ?industryLabel FILTER(LANG(?industryLabel)="en") }
      OPTIONAL { ?item schema:description ?desc FILTER(LANG(?desc)="en") }
      SERVICE wikibase:label { bd:serviceParam wikibase:language "en,fr,es,pt,de" }
    }
    ORDER BY DESC(?sitelinks)
  `;
}
async function runSparqlQuery(query, timeoutMs = 8500) {
	const url = `${SPARQL_ENDPOINT}?origin=*&format=json&query=${encodeURIComponent(query)}`;
	const controller = new AbortController();
	const timer = setTimeout(() => controller.abort(), timeoutMs);
	try {
		const res = await fetch(url, {
			signal: controller.signal,
			headers: { Accept: "application/sparql-results+json" }
		});
		if (!res.ok) throw new Error(`Wikidata SPARQL returned ${res.status}`);
		const json = await res.json();
		return json.results?.bindings ?? [];
	} finally {
		clearTimeout(timer);
	}
}
async function resolveCountryQid(countryCode) {
	const code = countryCode.toUpperCase();
	if (ISO_TO_QID[code]) return ISO_TO_QID[code];
	try {
		const bindings = await runSparqlQuery(`SELECT ?country WHERE { ?country wdt:P297 "${code}". } LIMIT 1`, 5e3);
		return bindings[0]?.country?.value?.split("/").pop() ?? null;
	} catch {
		return null;
	}
}
/**
* Fast Wikidata Action API + Wikipedia search fallback for any country or keyword.
* Responds in <250ms and never hits SPARQL timeouts.
*/
async function searchWikidataEntitiesForCountry(countryCode, limit, searchQuery) {
	const cName = countryName(countryCode) || countryCode;
	const searchTerms = searchQuery?.trim() ? [searchQuery.trim(), `${searchQuery.trim()} ${cName}`] : [
		`${cName} bank`,
		`${cName} telecom`,
		`${cName} airline`,
		`${cName} supermarket`,
		`${cName} company`
	];
	const results = new Map();
	await Promise.allSettled(searchTerms.map(async (term) => {
		const url = `${WIKIDATA_API}?action=wbsearchentities&search=${encodeURIComponent(term)}&language=en&limit=12&format=json&origin=*`;
		const res = await fetch(url);
		if (!res.ok) return;
		const json = await res.json();
		for (const item of json.search ?? []) {
			const name = item.label?.trim() ?? "";
			const desc = (item.description ?? "").toLowerCase();
			if (!name || /^Q\d+$/i.test(name)) continue;
			// Filter out non-company/brand entities when doing general country discovery
			const looksLikeBrand = Boolean(searchQuery?.trim()) || desc.includes("company") || desc.includes("bank") || desc.includes("airline") || desc.includes("brand") || desc.includes("retail") || desc.includes("telecommunications") || desc.includes("supermarket") || desc.includes("enterprise") || desc.includes("corporation") || desc.includes("conglomerate") || desc.includes("chain") || desc.includes("manufacturer") || desc.includes("service");
			if (!looksLikeBrand) continue;
			const slug = slugify(name);
			if (!slug || results.has(item.id)) continue;
			let category = "Consumer Brand";
			if (desc.includes("bank") || desc.includes("financial") || desc.includes("fintech")) {
				category = "Banking & Finance";
			} else if (desc.includes("airline") || desc.includes("aviation")) {
				category = "Airlines & Travel";
			} else if (desc.includes("telecom")) {
				category = "Telecoms";
			} else if (desc.includes("supermarket") || desc.includes("retail") || desc.includes("grocery")) {
				category = "Retail & Supermarkets";
			} else if (desc.includes("food") || desc.includes("restaurant") || desc.includes("beverage")) {
				category = "Food & Beverages";
			} else if (desc.includes("tech") || desc.includes("software")) {
				category = "Technology";
			}
			results.set(item.id, {
				id: `wd-${item.id}`,
				source: "wikidata",
				source_id: item.id,
				name,
				slug,
				country: countryCode,
				category,
				description: item.description ?? `${name} (${cName})`,
				website: null,
				logo_url: null,
				status: "pending",
				created_at: new Date().toISOString()
			});
		}
	}));
	return [...results.values()].slice(0, limit);
}
/**
* Multi-engine brand discovery for any country in the world:
* 1. Curated Global Country Atlas (with verified domains & Clearbit logos)
* 2. Live Wikidata SPARQL query (with Wikimedia Commons P154 logos & official websites)
* 3. Live Wikidata Search API fallback (for countries/keywords where SPARQL is slow)
*/
export async function discoverBrandsForCountry(input) {
	const code = normalizeCountryCode(input.countryCode) || input.countryCode.toUpperCase();
	const limit = Math.max(1, Math.min(200, input.limit || 50));
	const queryFilter = input.searchQuery?.trim().toLowerCase() ?? "";
	const bySlug = new Map();
	const sourcesUsed = [];
	// 1. Seed from Global Country Atlas first so high-profile local brands with logos are always present
	const atlasBrands = GLOBAL_COUNTRY_ATLAS[code] ?? [];
	for (const b of atlasBrands) {
		if (queryFilter && !`${b.name} ${b.category} ${b.description}`.toLowerCase().includes(queryFilter)) {
			continue;
		}
		const slug = slugify(b.name);
		if (!slug) continue;
		bySlug.set(slug, {
			id: `atlas-${code}-${slug}`,
			source: "wikidata",
			source_id: `ATLAS_${code}_${slug.toUpperCase()}`,
			name: b.name,
			slug,
			country: code,
			category: b.category,
			description: b.description,
			website: `https://${b.domain}`,
			logo_url: `https://logo.clearbit.com/${b.domain}`,
			status: "pending",
			created_at: new Date().toISOString(),
			sitelinks: 500
		});
	}
	if (bySlug.size > 0) sourcesUsed.push("Global Country Atlas");
	// 2. Live Wikidata SPARQL query for the country
	try {
		const qid = await resolveCountryQid(code);
		if (qid) {
			const bindings = await runSparqlQuery(buildFastCountrySparql(qid, limit));
			if (bindings.length > 0) {
				sourcesUsed.push("Wikidata Knowledge Graph (SPARQL)");
			}
			for (const b of bindings) {
				const qUrl = b.item?.value ?? "";
				const sourceId = qUrl.split("/").pop() ?? "";
				const name = b.itemLabel?.value ?? "";
				if (!sourceId || !name || /^Q\d+$/i.test(name)) continue;
				if (queryFilter && !`${name} ${b.industryLabel?.value ?? ""} ${b.desc?.value ?? ""}`.toLowerCase().includes(queryFilter)) {
					continue;
				}
				const slug = slugify(name);
				if (!slug) continue;
				const existing = bySlug.get(slug);
				if (existing) {
					existing.category ??= b.industryLabel?.value ?? null;
					existing.description ??= b.desc?.value ?? null;
					existing.website ??= b.website?.value ?? null;
					existing.logo_url ??= b.logo?.value ?? null;
					continue;
				}
				let logoUrl = b.logo?.value ?? null;
				const websiteUrl = b.website?.value ?? null;
				if (!logoUrl && websiteUrl) {
					try {
						const host = new URL(websiteUrl).hostname.replace(/^www\./, "");
						logoUrl = `https://logo.clearbit.com/${host}`;
					} catch {}
				}
				bySlug.set(slug, {
					id: `wd-${sourceId}`,
					source: "wikidata",
					source_id: sourceId,
					name,
					slug,
					country: code,
					category: b.industryLabel?.value ?? "Consumer Brand",
					description: b.desc?.value ?? `${name} — ${countryName(code) || code}`,
					website: websiteUrl,
					logo_url: logoUrl,
					status: "pending",
					created_at: new Date().toISOString(),
					sitelinks: Number(b.sitelinks?.value ?? 10)
				});
			}
		}
	} catch {}
	// 3. Supplement with fast Wikidata Search API if needed or if a search query was entered
	if (bySlug.size < limit || queryFilter) {
		try {
			const apiResults = await searchWikidataEntitiesForCountry(code, limit, input.searchQuery);
			if (apiResults.length > 0) {
				sourcesUsed.push("Wikidata Live Search API");
			}
			for (const c of apiResults) {
				if (!bySlug.has(c.slug)) {
					bySlug.set(c.slug, {
						...c,
						sitelinks: 5
					});
				}
			}
		} catch {}
	}
	const candidates = [...bySlug.values()].sort((a, b) => b.sitelinks - a.sitelinks).slice(0, limit).map(({ sitelinks: _s, ...row }) => row);
	return {
		candidates,
		sourcesUsed
	};
}
export async function fetchBrandCandidates() {
	const local = readLocalCandidates().filter((c) => c.status === "pending");
	const bySlug = new Map();
	for (const c of local) bySlug.set(c.slug, c);
	try {
		const { data, error } = await supabase.from("brand_import_candidates").select("*").eq("status", "pending").order("created_at", { ascending: false }).limit(150);
		if (!error && data) {
			for (const row of data) {
				if (row.slug && !bySlug.has(row.slug)) {
					bySlug.set(row.slug, {
						id: String(row.id),
						source: row.source ?? "wikidata",
						source_id: row.source_id ?? String(row.id),
						name: row.name,
						slug: row.slug,
						country: row.country ?? "ZA",
						category: row.category ?? null,
						description: row.description ?? null,
						website: row.website ?? null,
						logo_url: row.logo_url ?? null,
						status: row.status ?? "pending",
						created_at: row.created_at
					});
				}
			}
		}
	} catch {}
	return [...bySlug.values()];
}
export async function importBrandsFromWikidata(input) {
	const { candidates, sourcesUsed } = await discoverBrandsForCountry(input);
	if (!candidates.length) {
		return {
			inserted: 0,
			skipped: 0,
			sourceSummary: "No new candidates found"
		};
	}
	const currentLocal = readLocalCandidates();
	const existingSlugs = new Set(currentLocal.map((c) => c.slug));
	let inserted = 0;
	let skipped = 0;
	for (const c of candidates) {
		if (existingSlugs.has(c.slug)) {
			skipped += 1;
		} else {
			existingSlugs.add(c.slug);
			currentLocal.unshift({
				...c,
				status: "pending"
			});
			inserted += 1;
		}
	}
	writeLocalCandidates(currentLocal);
	// Best-effort sync to Supabase if table & permissions exist
	try {
		const sbRows = candidates.map(({ id: _id, created_at: _ca, ...rest }) => rest);
		await supabase.from("brand_import_candidates").upsert(sbRows, {
			onConflict: "source,source_id",
			ignoreDuplicates: true
		});
	} catch {}
	return {
		inserted,
		skipped,
		sourceSummary: sourcesUsed.join(" + ") || "Wikidata"
	};
}
async function persistApprovedBrandRecord(cand, ownerId) {
	const cleanId = `brand-${cand.country.toLowerCase()}-${cand.slug}`.replace(/[^a-zA-Z0-9_-]/g, "-").slice(0, 96);
	// 1. Save to local imported brands store for immediate synchronous availability
	const localBrands = getLocalImportedBrands();
	if (!localBrands.some((b) => b.slug === cand.slug)) {
		localBrands.unshift({
			id: cleanId,
			name: cand.name,
			slug: cand.slug,
			country: cand.country,
			category: cand.category ?? "Consumer Brand",
			description: cand.description ?? `${cand.name} (${cand.country})`,
			website: cand.website,
			logo_url: cand.logo_url,
			owner_id: ownerId,
			verified: true,
			trust_score: 78,
			created_at: new Date().toISOString()
		});
		saveLocalImportedBrands(localBrands);
	}
	// 2. Save to Firestore `brands` collection (respecting firestore.rules schema)
	try {
		await createFirestoreBrand({
			name: cand.name.slice(0, 200),
			slug: cand.slug.slice(0, 200),
			country: (cand.country || "ZA").slice(0, 100),
			category: (cand.category || "Consumer Brand").slice(0, 100),
			description: (cand.description || `${cand.name} brand page`).slice(0, 2e3),
			website: cand.website || "",
			logoUrl: cand.logo_url || "",
			trustScore: 78,
			riskScore: 12,
			status: "active",
			isVerified: true,
			createdBy: ownerId
		}, cleanId);
	} catch {}
	// 3. Best-effort save to Supabase
	try {
		const { data: brand } = await supabase.from("brands").insert({
			owner_id: ownerId,
			name: cand.name,
			slug: cand.slug,
			description: cand.description,
			website: cand.website,
			category: cand.category,
			country: cand.country,
			logo_url: cand.logo_url
		}).select("id, name, slug, website").single();
		if (brand) {
			return {
				brandId: brand.id,
				name: brand.name,
				slug: brand.slug,
				website: brand.website
			};
		}
	} catch {}
	return {
		brandId: cleanId,
		name: cand.name,
		slug: cand.slug,
		website: cand.website
	};
}
export async function approveBrandCandidate(id, reviewerId) {
	const local = readLocalCandidates();
	let cand = local.find((c) => c.id === id || c.slug === id);
	if (!cand) {
		try {
			const { data } = await supabase.from("brand_import_candidates").select("*").eq("id", id).maybeSingle();
			if (data) {
				cand = {
					id: String(data.id),
					source: data.source,
					source_id: data.source_id ?? "",
					name: data.name,
					slug: data.slug,
					country: data.country ?? "ZA",
					category: data.category,
					description: data.description,
					website: data.website,
					logo_url: data.logo_url,
					status: data.status
				};
			}
		} catch {}
	}
	if (!cand) throw new Error("Candidate not found.");
	const approved = await persistApprovedBrandRecord(cand, reviewerId);
	const updatedLocal = local.map((c) => c.id === id || c.slug === cand.slug ? {
		...c,
		status: "approved"
	} : c);
	writeLocalCandidates(updatedLocal);
	try {
		await supabase.from("brand_import_candidates").update({
			status: "approved",
			reviewed_by: reviewerId
		}).eq("id", id);
	} catch {}
	return approved;
}
export async function rejectBrandCandidate(id, reviewerId) {
	const local = readLocalCandidates();
	const updated = local.map((c) => c.id === id ? {
		...c,
		status: "rejected"
	} : c);
	writeLocalCandidates(updated);
	try {
		await supabase.from("brand_import_candidates").update({
			status: "rejected",
			reviewed_by: reviewerId
		}).eq("id", id);
	} catch {}
}
export async function publishBrandsFromWikidata(input) {
	const { candidates, sourcesUsed } = await discoverBrandsForCountry({
		countryCode: input.countryCode,
		limit: input.limit,
		searchQuery: input.searchQuery
	});
	if (!candidates.length) {
		return {
			published: 0,
			skipped: 0,
			sourceSummary: "No matching brands found"
		};
	}
	const existingLocal = getLocalImportedBrands();
	const existingSlugs = new Set(existingLocal.map((b) => b.slug));
	try {
		const fsBrands = await getFirestoreBrands();
		for (const b of fsBrands) existingSlugs.add(b.slug);
	} catch {}
	let published = 0;
	let skipped = 0;
	for (const c of candidates) {
		if (existingSlugs.has(c.slug)) {
			skipped += 1;
			continue;
		}
		existingSlugs.add(c.slug);
		await persistApprovedBrandRecord(c, input.ownerId);
		published += 1;
	}
	return {
		published,
		skipped,
		sourceSummary: sourcesUsed.join(" + ") || "Wikidata"
	};
}
export async function publishPendingCandidates(ownerId) {
	const pending = await fetchBrandCandidates();
	if (!pending.length) return {
		published: 0,
		skipped: 0
	};
	let published = 0;
	let skipped = 0;
	for (const c of pending) {
		try {
			await persistApprovedBrandRecord(c, ownerId);
			published += 1;
		} catch {
			skipped += 1;
		}
	}
	const local = readLocalCandidates().map((c) => c.status === "pending" ? {
		...c,
		status: "approved"
	} : c);
	writeLocalCandidates(local);
	try {
		await supabase.from("brand_import_candidates").update({
			status: "approved",
			reviewed_by: ownerId
		}).eq("status", "pending");
	} catch {}
	return {
		published,
		skipped
	};
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxzQkFBc0IsMEJBQTBCO0FBQ3pELFNBQVMsYUFBYSw0QkFBNEI7QUFFbEQsT0FBTyxNQUFNLGFBQXFDO0NBQ2hELElBQUk7Q0FBUSxJQUFJO0NBQU8sSUFBSTtDQUFRLElBQUk7Q0FBUSxJQUFJO0NBQ25ELElBQUk7Q0FBTyxJQUFJO0NBQU8sSUFBSTtDQUFPLElBQUk7Q0FBTyxJQUFJO0NBQ2hELElBQUk7Q0FBUSxJQUFJO0NBQVEsSUFBSTtDQUFPLElBQUk7Q0FBUSxJQUFJO0NBQ25ELElBQUk7Q0FBTyxJQUFJO0NBQVEsSUFBSTtDQUFTLElBQUk7Q0FBUSxJQUFJO0NBQ3BELElBQUk7Q0FBUyxJQUFJO0NBQVEsSUFBSTtDQUFTLElBQUk7Q0FDMUMsSUFBSTtDQUFRLElBQUk7Q0FBUyxJQUFJO0NBQVMsSUFBSTtDQUFRLElBQUk7Q0FDdEQsSUFBSTtDQUFRLElBQUk7Q0FBUSxJQUFJO0NBQVMsSUFBSTtDQUFRLElBQUk7Q0FDckQsSUFBSTtDQUFTLElBQUk7Q0FBUSxJQUFJO0NBQVEsSUFBSTtDQUFTLElBQUk7Q0FDdEQsSUFBSTtDQUFTLElBQUk7Q0FBUyxJQUFJO0NBQzlCLElBQUk7Q0FBTyxJQUFJO0NBQU8sSUFBSTtDQUFPLElBQUk7Q0FBTyxJQUFJO0NBQ2hELElBQUk7Q0FBTyxJQUFJO0NBQU8sSUFBSTtDQUFPLElBQUk7Q0FBTyxJQUFJO0NBQ2hELElBQUk7Q0FBTyxJQUFJO0NBQVEsSUFBSTtDQUFRLElBQUk7Q0FBUSxJQUFJO0NBQ25ELElBQUk7Q0FBUSxJQUFJO0NBQVEsSUFBSTtDQUFRLElBQUk7Q0FBUSxJQUFJO0NBQ3BELElBQUk7Q0FBUSxJQUFJO0NBQVEsSUFBSTtDQUFRLElBQUk7Q0FBUSxJQUFJO0NBQ3BELElBQUk7Q0FBUSxJQUFJO0NBQVEsSUFBSTtDQUFRLElBQUk7Q0FBUSxJQUFJO0NBQ3BELElBQUk7Q0FBUSxJQUFJO0NBQVEsSUFBSTtDQUFRLElBQUk7Q0FBUSxJQUFJO0NBQ3BELElBQUk7QUFDTjtBQUVBLE9BQU8sTUFBTSw2QkFBeUU7Q0FDcEYsQ0FBQyxNQUFNLG1CQUFtQjtDQUMxQixDQUFDLE1BQU0sY0FBYztDQUNyQixDQUFDLE1BQU0sWUFBWTtDQUNuQixDQUFDLE1BQU0sWUFBWTtDQUNuQixDQUFDLE1BQU0sWUFBWTtDQUNuQixDQUFDLE1BQU0sY0FBYztDQUNyQixDQUFDLE1BQU0sZUFBZTtDQUN0QixDQUFDLE1BQU0sY0FBYztDQUNyQixDQUFDLE1BQU0sZUFBZTtDQUN0QixDQUFDLE1BQU0sYUFBYTtDQUNwQixDQUFDLE1BQU0sYUFBYTtDQUNwQixDQUFDLE1BQU0sZUFBZTtDQUN0QixDQUFDLE1BQU0sY0FBYztDQUNyQixDQUFDLE1BQU0sZUFBZTtDQUN0QixDQUFDLE1BQU0sYUFBYTtDQUNwQixDQUFDLE1BQU0sY0FBYztDQUNyQixDQUFDLE1BQU0sZUFBZTtDQUN0QixDQUFDLE1BQU0saUJBQWlCO0NBQ3hCLENBQUMsTUFBTSxhQUFhO0NBQ3BCLENBQUMsTUFBTSxlQUFlO0NBQ3RCLENBQUMsTUFBTSxvQkFBb0I7Q0FDM0IsQ0FBQyxNQUFNLGdCQUFnQjtDQUN2QixDQUFDLE1BQU0sb0JBQW9CO0NBQzNCLENBQUMsTUFBTSxxQkFBcUI7Q0FDNUIsQ0FBQyxNQUFNLGFBQWE7Q0FDcEIsQ0FBQyxNQUFNLGNBQWM7Q0FDckIsQ0FBQyxNQUFNLFlBQVk7Q0FDbkIsQ0FBQyxNQUFNLGVBQWU7Q0FDdEIsQ0FBQyxNQUFNLFlBQVk7Q0FDbkIsQ0FBQyxNQUFNLGtCQUFrQjtDQUN6QixDQUFDLE1BQU0sa0JBQWtCO0NBQ3pCLENBQUMsTUFBTSxhQUFhO0NBQ3BCLENBQUMsTUFBTSxjQUFjO0NBQ3JCLENBQUMsTUFBTSxhQUFhO0NBQ3BCLENBQUMsTUFBTSxjQUFjO0NBQ3JCLENBQUMsTUFBTSxhQUFhO0NBQ3BCLENBQUMsTUFBTSxhQUFhO0NBQ3BCLENBQUMsTUFBTSxhQUFhO0NBQ3BCLENBQUMsTUFBTSxnQkFBZ0I7Q0FDdkIsQ0FBQyxNQUFNLGVBQWU7Q0FDdEIsQ0FBQyxNQUFNLFlBQVk7Q0FDbkIsQ0FBQyxNQUFNLFlBQVk7Q0FDbkIsQ0FBQyxNQUFNLFlBQVk7Q0FDbkIsQ0FBQyxNQUFNLFlBQVk7Q0FDbkIsQ0FBQyxNQUFNLGtCQUFrQjtDQUN6QixDQUFDLE1BQU0sZ0JBQWdCO0NBQ3ZCLENBQUMsTUFBTSxrQkFBa0I7Q0FDekIsQ0FBQyxNQUFNLDJCQUEyQjtDQUNsQyxDQUFDLE1BQU0sbUJBQW1CO0NBQzFCLENBQUMsTUFBTSxnQkFBZ0I7Q0FDdkIsQ0FBQyxNQUFNLGdCQUFnQjtDQUN2QixDQUFDLE1BQU0sZUFBZTtDQUN0QixDQUFDLE1BQU0sa0JBQWtCO0NBQ3pCLENBQUMsTUFBTSxlQUFlO0NBQ3RCLENBQUMsTUFBTSxjQUFjO0FBQ3ZCO0FBRUEsTUFBTSxrQkFBa0I7QUFDeEIsTUFBTSxlQUFlO0FBRXJCLE1BQU0seUJBQXlCO0FBQy9CLE1BQU0sOEJBQThCOzs7OztBQXlDcEMsTUFBTSx1QkFBMkQ7Q0FDL0QsSUFBSTtFQUNGO0dBQUUsTUFBTTtHQUFnQixVQUFVO0dBQXFCLFFBQVE7R0FBcUIsYUFBYTtFQUErRTtFQUNoTDtHQUFFLE1BQU07R0FBWSxVQUFVO0dBQTRCLFFBQVE7R0FBa0IsYUFBYTtFQUFvRTtFQUNySztHQUFFLE1BQU07R0FBb0IsVUFBVTtHQUF3QixRQUFRO0dBQWtCLGFBQWE7RUFBb0U7RUFDeks7R0FBRSxNQUFNO0dBQTJCLFVBQVU7R0FBdUIsUUFBUTtHQUFvQixhQUFhO0VBQXNFO0VBQ25MO0dBQUUsTUFBTTtHQUFvQixVQUFVO0dBQVksUUFBUTtHQUFhLGFBQWE7RUFBNkQ7RUFDako7R0FBRSxNQUFNO0dBQVcsVUFBVTtHQUFZLFFBQVE7R0FBaUIsYUFBYTtFQUFtRTtFQUNsSjtHQUFFLE1BQU07R0FBNkIsVUFBVTtHQUFxQixRQUFRO0dBQWEsYUFBYTtFQUF1RDtFQUM3SjtHQUFFLE1BQU07R0FBaUIsVUFBVTtHQUFxQixRQUFRO0dBQXNCLGFBQWE7RUFBcUU7RUFDeEs7R0FBRSxNQUFNO0dBQVcsVUFBVTtHQUFzQixRQUFRO0dBQWdCLGFBQWE7RUFBeUU7RUFDaks7R0FBRSxNQUFNO0dBQVksVUFBVTtHQUFjLFFBQVE7R0FBZ0IsYUFBYTtFQUFtRTtFQUNwSjtHQUFFLE1BQU07R0FBYSxVQUFVO0dBQTBCLFFBQVE7R0FBbUIsYUFBYTtFQUE4RTtFQUMvSztHQUFFLE1BQU07R0FBYyxVQUFVO0dBQWMsUUFBUTtHQUFrQixhQUFhO0VBQXNFO0VBQzNKO0dBQUUsTUFBTTtHQUFjLFVBQVU7R0FBNEIsUUFBUTtHQUFhLGFBQWE7RUFBb0U7RUFDbEs7R0FBRSxNQUFNO0dBQVMsVUFBVTtHQUFpQixRQUFRO0dBQWEsYUFBYTtFQUFtRTtDQUNuSjtDQUNBLElBQUk7RUFDRjtHQUFFLE1BQU07R0FBZSxVQUFVO0dBQXNCLFFBQVE7R0FBbUIsYUFBYTtFQUFvRTtFQUNuSztHQUFFLE1BQU07R0FBWSxVQUFVO0dBQXNCLFFBQVE7R0FBZ0IsYUFBYTtFQUFvRTtFQUM3SjtHQUFFLE1BQU07R0FBYyxVQUFVO0dBQXFCLFFBQVE7R0FBa0IsYUFBYTtFQUErRTtFQUMzSztHQUFFLE1BQU07R0FBOEIsVUFBVTtHQUFxQixRQUFRO0dBQWMsYUFBYTtFQUFtRDtFQUMzSjtHQUFFLE1BQU07R0FBZSxVQUFVO0dBQXFCLFFBQVE7R0FBa0IsYUFBYTtFQUFpRDtFQUM5STtHQUFFLE1BQU07R0FBZSxVQUFVO0dBQXFCLFFBQVE7R0FBcUIsYUFBYTtFQUF3RDtFQUN4SjtHQUFFLE1BQU07R0FBaUIsVUFBVTtHQUF3QixRQUFRO0dBQWUsYUFBYTtFQUFrRjtFQUNqTDtHQUFFLE1BQU07R0FBaUIsVUFBVTtHQUFjLFFBQVE7R0FBZ0IsYUFBYTtFQUErRDtFQUNySjtHQUFFLE1BQU07R0FBYSxVQUFVO0dBQXFCLFFBQVE7R0FBbUIsYUFBYTtFQUE4RTtFQUMxSztHQUFFLE1BQU07R0FBYSxVQUFVO0dBQW1CLFFBQVE7R0FBWSxhQUFhO0VBQTREO0NBQ2pKO0NBQ0EsSUFBSTtFQUNGO0dBQUUsTUFBTTtHQUFzQixVQUFVO0dBQXNCLFFBQVE7R0FBbUIsYUFBYTtFQUF3RTtFQUM5SztHQUFFLE1BQU07R0FBcUIsVUFBVTtHQUFxQixRQUFRO0dBQTJCLGFBQWE7RUFBd0Q7RUFDcEs7R0FBRSxNQUFNO0dBQVksVUFBVTtHQUFxQixRQUFRO0dBQWdCLGFBQWE7RUFBaUU7RUFDeko7R0FBRSxNQUFNO0dBQWlCLFVBQVU7R0FBcUIsUUFBUTtHQUFxQixhQUFhO0VBQXVEO0VBQ3pKO0dBQUUsTUFBTTtHQUFzQixVQUFVO0dBQTRCLFFBQVE7R0FBaUIsYUFBYTtFQUFzRDtFQUNoSztHQUFFLE1BQU07R0FBYyxVQUFVO0dBQWlCLFFBQVE7R0FBdUIsYUFBYTtFQUFtRTtFQUNoSztHQUFFLE1BQU07R0FBZSxVQUFVO0dBQXFCLFFBQVE7R0FBa0IsYUFBYTtFQUEwRTtDQUN6SztDQUNBLElBQUk7RUFDRjtHQUFFLE1BQU07R0FBYSxVQUFVO0dBQW1CLFFBQVE7R0FBYyxhQUFhO0VBQXdFO0VBQzdKO0dBQUUsTUFBTTtHQUFXLFVBQVU7R0FBcUIsUUFBUTtHQUFlLGFBQWE7RUFBdUY7RUFDN0s7R0FBRSxNQUFNO0dBQVksVUFBVTtHQUFxQixRQUFRO0dBQWtCLGFBQWE7RUFBOEM7RUFDeEk7R0FBRSxNQUFNO0dBQVUsVUFBVTtHQUFzQixRQUFRO0dBQWMsYUFBYTtFQUFzRTtFQUMzSjtHQUFFLE1BQU07R0FBYSxVQUFVO0dBQW9CLFFBQVE7R0FBbUIsYUFBYTtFQUEwQztFQUNySTtHQUFFLE1BQU07R0FBVSxVQUFVO0dBQThCLFFBQVE7R0FBYyxhQUFhO0VBQXFEO0NBQ3BKO0NBQ0EsSUFBSTtFQUNGO0dBQUUsTUFBTTtHQUFTLFVBQVU7R0FBd0IsUUFBUTtHQUFhLGFBQWE7RUFBMEU7RUFDL0o7R0FBRSxNQUFNO0dBQXVDLFVBQVU7R0FBcUIsUUFBUTtHQUFhLGFBQWE7RUFBdUM7RUFDdko7R0FBRSxNQUFNO0dBQVksVUFBVTtHQUFxQixRQUFRO0dBQWdCLGFBQWE7RUFBNkM7RUFDckk7R0FBRSxNQUFNO0dBQWtCLFVBQVU7R0FBWSxRQUFRO0dBQW1CLGFBQWE7RUFBdUU7RUFDL0o7R0FBRSxNQUFNO0dBQVEsVUFBVTtHQUFzQixRQUFRO0dBQVksYUFBYTtFQUF3RTtFQUN6SjtHQUFFLE1BQU07R0FBYSxVQUFVO0dBQWtCLFFBQVE7R0FBaUIsYUFBYTtFQUEyRTtDQUNwSztDQUNBLElBQUk7RUFDRjtHQUFFLE1BQU07R0FBbUIsVUFBVTtHQUFxQixRQUFRO0dBQXFCLGFBQWE7RUFBc0U7RUFDMUs7R0FBRSxNQUFNO0dBQXFCLFVBQVU7R0FBcUIsUUFBUTtHQUF3QixhQUFhO0VBQWdFO0VBQ3pLO0dBQUUsTUFBTTtHQUFpQixVQUFVO0dBQVksUUFBUTtHQUFVLGFBQWE7RUFBOEM7RUFDNUg7R0FBRSxNQUFNO0dBQWEsVUFBVTtHQUEwQixRQUFRO0dBQWUsYUFBYTtFQUFvRTtFQUNqSztHQUFFLE1BQU07R0FBVyxVQUFVO0dBQTRCLFFBQVE7R0FBYyxhQUFhO0VBQWtEO0NBQ2hKO0NBQ0EsSUFBSTtFQUNGO0dBQUUsTUFBTTtHQUFzQixVQUFVO0dBQXFCLFFBQVE7R0FBeUIsYUFBYTtFQUF3RTtFQUNuTDtHQUFFLE1BQU07R0FBNEIsVUFBVTtHQUFzQixRQUFRO0dBQW1CLGFBQWE7RUFBa0U7RUFDOUs7R0FBRSxNQUFNO0dBQStCLFVBQVU7R0FBcUIsUUFBUTtHQUFpQixhQUFhO0VBQXVDO0VBQ25KO0dBQUUsTUFBTTtHQUFzQixVQUFVO0dBQVksUUFBUTtHQUFnQixhQUFhO0VBQXNFO0NBQ2pLO0NBQ0EsSUFBSTtFQUNGO0dBQUUsTUFBTTtHQUFxQixVQUFVO0dBQVcsUUFBUTtHQUFZLGFBQWE7RUFBc0Y7RUFDeks7R0FBRSxNQUFNO0dBQTRCLFVBQVU7R0FBWSxRQUFRO0dBQWMsYUFBYTtFQUFpRDtFQUM5STtHQUFFLE1BQU07R0FBZSxVQUFVO0dBQXFCLFFBQVE7R0FBcUIsYUFBYTtFQUFtRDtDQUNySjtDQUNBLElBQUk7RUFDRjtHQUFFLE1BQU07R0FBYSxVQUFVO0dBQXFCLFFBQVE7R0FBa0IsYUFBYTtFQUF1RDtFQUNsSjtHQUFFLE1BQU07R0FBcUIsVUFBVTtHQUFxQixRQUFRO0dBQWlCLGFBQWE7RUFBc0Q7RUFDeEo7R0FBRSxNQUFNO0dBQW9CLFVBQVU7R0FBWSxRQUFRO0dBQWlCLGFBQWE7RUFBc0U7RUFDOUo7R0FBRSxNQUFNO0dBQXlCLFVBQVU7R0FBc0IsUUFBUTtHQUFnQixhQUFhO0VBQTBFO0NBQ2xMO0NBQ0EsSUFBSTtFQUNGO0dBQUUsTUFBTTtHQUFnQyxVQUFVO0dBQXFCLFFBQVE7R0FBcUIsYUFBYTtFQUFtRDtFQUNwSztHQUFFLE1BQU07R0FBWSxVQUFVO0dBQTRCLFFBQVE7R0FBa0IsYUFBYTtFQUFnRTtFQUNqSztHQUFFLE1BQU07R0FBbUIsVUFBVTtHQUFZLFFBQVE7R0FBYSxhQUFhO0VBQXlEO0VBQzVJO0dBQUUsTUFBTTtHQUFnQixVQUFVO0dBQXFCLFFBQVE7R0FBcUIsYUFBYTtFQUE2QztDQUNoSjtDQUNBLElBQUk7RUFDRjtHQUFFLE1BQU07R0FBaUIsVUFBVTtHQUFxQixRQUFRO0dBQXVCLGFBQWE7RUFBaUQ7RUFDcko7R0FBRSxNQUFNO0dBQWUsVUFBVTtHQUFZLFFBQVE7R0FBYyxhQUFhO0VBQWlFO0VBQ2pKO0dBQUUsTUFBTTtHQUFxQixVQUFVO0dBQWEsUUFBUTtHQUFlLGFBQWE7RUFBK0M7Q0FDekk7Q0FDQSxJQUFJO0VBQ0Y7R0FBRSxNQUFNO0dBQTRCLFVBQVU7R0FBc0IsUUFBUTtHQUFnQixhQUFhO0VBQXNFO0VBQy9LO0dBQUUsTUFBTTtHQUFxQixVQUFVO0dBQW9CLFFBQVE7R0FBZSxhQUFhO0VBQTZDO0VBQzVJO0dBQUUsTUFBTTtHQUFnQixVQUFVO0dBQXFCLFFBQVE7R0FBYSxhQUFhO0VBQTREO0VBQ3JKO0dBQUUsTUFBTTtHQUE0QixVQUFVO0dBQWlCLFFBQVE7R0FBcUIsYUFBYTtFQUEwRTtDQUNyTDtDQUNBLElBQUk7RUFDRjtHQUFFLE1BQU07R0FBbUIsVUFBVTtHQUFxQixRQUFRO0dBQWlCLGFBQWE7RUFBNkQ7RUFDN0o7R0FBRSxNQUFNO0dBQTBCLFVBQVU7R0FBWSxRQUFRO0dBQWEsYUFBYTtFQUFvRTtFQUM5SjtHQUFFLE1BQU07R0FBeUIsVUFBVTtHQUFxQixRQUFRO0dBQTZCLGFBQWE7RUFBc0M7RUFDeEo7R0FBRSxNQUFNO0dBQTJCLFVBQVU7R0FBYSxRQUFRO0dBQWdCLGFBQWE7RUFBd0M7Q0FDekk7Q0FDQSxJQUFJO0VBQ0Y7R0FBRSxNQUFNO0dBQVMsVUFBVTtHQUFxQyxRQUFRO0dBQWEsYUFBYTtFQUE2RTtFQUMvSztHQUFFLE1BQU07R0FBVSxVQUFVO0dBQXNCLFFBQVE7R0FBYyxhQUFhO0VBQStFO0VBQ3BLO0dBQUUsTUFBTTtHQUFRLFVBQVU7R0FBc0IsUUFBUTtHQUFZLGFBQWE7RUFBaUU7RUFDbEo7R0FBRSxNQUFNO0dBQVcsVUFBVTtHQUE2QixRQUFRO0dBQWUsYUFBYTtFQUFnRTtFQUM5SjtHQUFFLE1BQU07R0FBYSxVQUFVO0dBQWlCLFFBQVE7R0FBaUIsYUFBYTtFQUE2RDtFQUNuSjtHQUFFLE1BQU07R0FBUyxVQUFVO0dBQTZCLFFBQVE7R0FBYSxhQUFhO0VBQXVFO0VBQ2pLO0dBQUUsTUFBTTtHQUFhLFVBQVU7R0FBeUIsUUFBUTtHQUFpQixhQUFhO0VBQTBEO0VBQ3hKO0dBQUUsTUFBTTtHQUFtQixVQUFVO0dBQXFCLFFBQVE7R0FBYSxhQUFhO0VBQXdFO0VBQ3BLO0dBQUUsTUFBTTtHQUFvQixVQUFVO0dBQXNCLFFBQVE7R0FBYyxhQUFhO0VBQXVEO0VBQ3RKO0dBQUUsTUFBTTtHQUFrQixVQUFVO0dBQXFCLFFBQVE7R0FBYSxhQUFhO0VBQTZEO0NBQzFKO0NBQ0EsSUFBSTtFQUNGO0dBQUUsTUFBTTtHQUFXLFVBQVU7R0FBNkIsUUFBUTtHQUFlLGFBQWE7RUFBdUU7RUFDcks7R0FBRSxNQUFNO0dBQVMsVUFBVTtHQUFtQixRQUFRO0dBQWEsYUFBYTtFQUFzRTtFQUN0SjtHQUFFLE1BQU07R0FBeUIsVUFBVTtHQUFzQixRQUFRO0dBQXVCLGFBQWE7RUFBZ0U7RUFDN0s7R0FBRSxNQUFNO0dBQVMsVUFBVTtHQUE0QixRQUFRO0dBQWEsYUFBYTtFQUF5RDtFQUNsSjtHQUFFLE1BQU07R0FBbUIsVUFBVTtHQUFxQixRQUFRO0dBQXNCLGFBQWE7RUFBOEM7RUFDbko7R0FBRSxNQUFNO0dBQVMsVUFBVTtHQUF1QixRQUFRO0dBQWUsYUFBYTtFQUFxRjtFQUMzSztHQUFFLE1BQU07R0FBa0IsVUFBVTtHQUE0QixRQUFRO0dBQWtCLGFBQWE7RUFBd0U7Q0FDakw7Q0FDQSxJQUFJO0VBQ0Y7R0FBRSxNQUFNO0dBQWlCLFVBQVU7R0FBa0IsUUFBUTtHQUFvQixhQUFhO0VBQTJEO0VBQ3pKO0dBQUUsTUFBTTtHQUFXLFVBQVU7R0FBc0IsUUFBUTtHQUFjLGFBQWE7RUFBMkQ7RUFDako7R0FBRSxNQUFNO0dBQWEsVUFBVTtHQUE0QixRQUFRO0dBQWdCLGFBQWE7RUFBMkQ7RUFDM0o7R0FBRSxNQUFNO0dBQWMsVUFBVTtHQUFxQixRQUFRO0dBQWlCLGFBQWE7RUFBa0M7RUFDN0g7R0FBRSxNQUFNO0dBQWEsVUFBVTtHQUEyQixRQUFRO0dBQWdCLGFBQWE7RUFBOEQ7RUFDN0o7R0FBRSxNQUFNO0dBQVUsVUFBVTtHQUFvQixRQUFRO0dBQWMsYUFBYTtFQUFrRTtDQUN2SjtDQUNBLElBQUk7RUFDRjtHQUFFLE1BQU07R0FBVSxVQUFVO0dBQXdCLFFBQVE7R0FBYyxhQUFhO0VBQWlEO0VBQ3hJO0dBQUUsTUFBTTtHQUFPLFVBQVU7R0FBYyxRQUFRO0dBQVcsYUFBYTtFQUE4RDtFQUNySTtHQUFFLE1BQU07R0FBaUIsVUFBVTtHQUFjLFFBQVE7R0FBcUIsYUFBYTtFQUEwRDtFQUNySjtHQUFFLE1BQU07R0FBUSxVQUFVO0dBQTRCLFFBQVE7R0FBVyxhQUFhO0VBQWdFO0VBQ3RKO0dBQUUsTUFBTTtHQUFPLFVBQVU7R0FBbUIsUUFBUTtHQUFXLGFBQWE7RUFBeUM7RUFDckg7R0FBRSxNQUFNO0dBQWEsVUFBVTtHQUFxQixRQUFRO0dBQWlCLGFBQWE7RUFBK0M7Q0FDM0k7Q0FDQSxJQUFJO0VBQ0Y7R0FBRSxNQUFNO0dBQWtCLFVBQVU7R0FBcUIsUUFBUTtHQUFZLGFBQWE7RUFBNkQ7RUFDdko7R0FBRSxNQUFNO0dBQWEsVUFBVTtHQUE0QixRQUFRO0dBQWdCLGFBQWE7RUFBeUQ7RUFDeko7R0FBRSxNQUFNO0dBQW1CLFVBQVU7R0FBcUIsUUFBUTtHQUFpQixhQUFhO0VBQWtEO0VBQ2xKO0dBQUUsTUFBTTtHQUFVLFVBQVU7R0FBcUIsUUFBUTtHQUFjLGFBQWE7RUFBaUQ7RUFDckk7R0FBRSxNQUFNO0dBQVUsVUFBVTtHQUEyQixRQUFRO0dBQWMsYUFBYTtFQUFvRDtDQUNoSjtDQUNBLElBQUk7RUFDRjtHQUFFLE1BQU07R0FBb0IsVUFBVTtHQUFxQixRQUFRO0dBQWMsYUFBYTtFQUFnRDtFQUM5STtHQUFFLE1BQU07R0FBc0IsVUFBVTtHQUE0QixRQUFRO0dBQWlCLGFBQWE7RUFBd0Q7RUFDbEs7R0FBRSxNQUFNO0dBQWdCLFVBQVU7R0FBaUIsUUFBUTtHQUFZLGFBQWE7RUFBK0M7RUFDbkk7R0FBRSxNQUFNO0dBQWtCLFVBQVU7R0FBcUIsUUFBUTtHQUFvQixhQUFhO0VBQW9DO0NBQ3hJO0NBQ0EsSUFBSTtFQUNGO0dBQUUsTUFBTTtHQUFVLFVBQVU7R0FBNkIsUUFBUTtHQUFpQixhQUFhO0VBQTJFO0VBQzFLO0dBQUUsTUFBTTtHQUFpQixVQUFVO0dBQXdCLFFBQVE7R0FBdUIsYUFBYTtFQUEyRDtFQUNsSztHQUFFLE1BQU07R0FBUyxVQUFVO0dBQTJCLFFBQVE7R0FBZ0IsYUFBYTtFQUFnRTtFQUMzSjtHQUFFLE1BQU07R0FBYyxVQUFVO0dBQTBCLFFBQVE7R0FBaUIsYUFBYTtFQUFnRTtFQUNoSztHQUFFLE1BQU07R0FBaUIsVUFBVTtHQUFxQixRQUFRO0dBQWUsYUFBYTtFQUEyRDtDQUN6SjtDQUNBLElBQUk7RUFDRjtHQUFFLE1BQU07R0FBYyxVQUFVO0dBQXlCLFFBQVE7R0FBWSxhQUFhO0VBQW1GO0VBQzdLO0dBQUUsTUFBTTtHQUFnQixVQUFVO0dBQXNCLFFBQVE7R0FBVyxhQUFhO0VBQXlFO0VBQ2pLO0dBQUUsTUFBTTtHQUFVLFVBQVU7R0FBa0MsUUFBUTtHQUFjLGFBQWE7RUFBbUU7RUFDcEs7R0FBRSxNQUFNO0dBQWEsVUFBVTtHQUFxQixRQUFRO0dBQWdCLGFBQWE7RUFBdUM7RUFDaEk7R0FBRSxNQUFNO0dBQVUsVUFBVTtHQUFxQixRQUFRO0dBQWUsYUFBYTtFQUFxRDtDQUM1STtDQUNBLElBQUk7RUFDRjtHQUFFLE1BQU07R0FBUSxVQUFVO0dBQWlDLFFBQVE7R0FBWSxhQUFhO0VBQXFFO0VBQ2pLO0dBQUUsTUFBTTtHQUFVLFVBQVU7R0FBYyxRQUFRO0dBQWMsYUFBYTtFQUFvRTtFQUNqSjtHQUFFLE1BQU07R0FBMkIsVUFBVTtHQUFxQixRQUFRO0dBQWMsYUFBYTtFQUFvRTtFQUN6SztHQUFFLE1BQU07R0FBWSxVQUFVO0dBQTBCLFFBQVE7R0FBZ0IsYUFBYTtFQUFpRTtDQUNoSztDQUNBLElBQUk7RUFDRjtHQUFFLE1BQU07R0FBdUIsVUFBVTtHQUE0QixRQUFRO0dBQWUsYUFBYTtFQUFzRTtFQUMvSztHQUFFLE1BQU07R0FBaUIsVUFBVTtHQUFjLFFBQVE7R0FBZSxhQUFhO0VBQXVEO0VBQzVJO0dBQUUsTUFBTTtHQUFXLFVBQVU7R0FBZ0MsUUFBUTtHQUFlLGFBQWE7RUFBbUU7RUFDcEs7R0FBRSxNQUFNO0dBQVMsVUFBVTtHQUEwQixRQUFRO0dBQWlCLGFBQWE7RUFBd0Q7Q0FDcko7Q0FDQSxJQUFJO0VBQ0Y7R0FBRSxNQUFNO0dBQVksVUFBVTtHQUF1QixRQUFRO0dBQWdCLGFBQWE7RUFBOEM7RUFDeEk7R0FBRSxNQUFNO0dBQVUsVUFBVTtHQUF3QixRQUFRO0dBQWMsYUFBYTtFQUEyRTtFQUNsSztHQUFFLE1BQU07R0FBUSxVQUFVO0dBQWMsUUFBUTtHQUFZLGFBQWE7RUFBcUQ7RUFDOUg7R0FBRSxNQUFNO0dBQWlCLFVBQVU7R0FBeUIsUUFBUTtHQUFZLGFBQWE7RUFBNkQ7Q0FDNUo7Q0FDQSxJQUFJO0VBQ0Y7R0FBRSxNQUFNO0dBQXdCLFVBQVU7R0FBNEIsUUFBUTtHQUFxQixhQUFhO0VBQXlDO0VBQ3pKO0dBQUUsTUFBTTtHQUFnQyxVQUFVO0dBQXFCLFFBQVE7R0FBbUIsYUFBYTtFQUFtRDtFQUNsSztHQUFFLE1BQU07R0FBVSxVQUFVO0dBQXFCLFFBQVE7R0FBYyxhQUFhO0VBQXFDO0VBQ3pIO0dBQUUsTUFBTTtHQUFTLFVBQVU7R0FBdUIsUUFBUTtHQUFhLGFBQWE7RUFBc0U7Q0FDNUo7QUFDRjtBQUVBLFNBQVMsUUFBUSxNQUFzQjtDQUNyQyxPQUFPLEtBQ0osWUFBWSxDQUFDLENBQ2IsS0FBSyxDQUFDLENBQ04sUUFBUSxlQUFlLEdBQUcsQ0FBQyxDQUMzQixRQUFRLFlBQVksRUFBRSxDQUFDLENBQ3ZCLE1BQU0sR0FBRyxFQUFFO0FBQ2hCO0FBRUEsT0FBTyxTQUFTLHFCQUFxQixPQUlsQztDQUNELE1BQU0sU0FDSixPQUFPLFdBQVcsY0FDZCxvQ0FDQSxPQUFPLFNBQVM7Q0FDdEIsTUFBTSxXQUFXLEdBQUcsT0FBTyxVQUFVLE1BQU07Q0FDM0MsT0FBTyxZQUFZLE1BQU0sS0FBSywyQ0FBMkMsTUFBTSxLQUFLLHdEQUF3RCxNQUFNLEtBQUssb0pBQW9KLFNBQVMsSUFBSSxNQUFNLFVBQVUscUJBQXFCLE1BQU0sUUFBUSxNQUFNLEdBQUc7QUFDdFg7QUFFQSxTQUFTLHNCQUFtQztDQUMxQyxJQUFJLE9BQU8sV0FBVyxhQUFhLE9BQU8sQ0FBQztDQUMzQyxJQUFJO0VBQ0YsTUFBTSxNQUFNLE9BQU8sYUFBYSxRQUFRLHNCQUFzQjtFQUM5RCxPQUFPLE1BQU8sS0FBSyxNQUFNLEdBQUcsSUFBb0IsQ0FBQztDQUNuRCxRQUFRO0VBQ04sT0FBTyxDQUFDO0NBQ1Y7QUFDRjtBQUVBLFNBQVMscUJBQXFCLE9BQW9CO0NBQ2hELElBQUksT0FBTyxXQUFXLGFBQWE7Q0FDbkMsSUFBSTtFQUNGLE9BQU8sYUFBYSxRQUFRLHdCQUF3QixLQUFLLFVBQVUsS0FBSyxDQUFDO0NBQzNFLFFBQVEsQ0FFUjtBQUNGO0FBaUJBLE9BQU8sU0FBUyx5QkFBK0M7Q0FDN0QsSUFBSSxPQUFPLFdBQVcsYUFBYSxPQUFPLENBQUM7Q0FDM0MsSUFBSTtFQUNGLE1BQU0sTUFBTSxPQUFPLGFBQWEsUUFBUSwyQkFBMkI7RUFDbkUsT0FBTyxNQUFPLEtBQUssTUFBTSxHQUFHLElBQTZCLENBQUM7Q0FDNUQsUUFBUTtFQUNOLE9BQU8sQ0FBQztDQUNWO0FBQ0Y7QUFFQSxTQUFTLHdCQUF3QixRQUE4QjtDQUM3RCxJQUFJLE9BQU8sV0FBVyxhQUFhO0NBQ25DLElBQUk7RUFDRixPQUFPLGFBQWEsUUFBUSw2QkFBNkIsS0FBSyxVQUFVLE1BQU0sQ0FBQztDQUNqRixRQUFRLENBRVI7QUFDRjs7Ozs7QUFNQSxTQUFTLHVCQUF1QixLQUFhLE9BQXVCO0NBQ2xFLE1BQU0sYUFBYSxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQztDQUN4RCxPQUFPOzs7Ozs7NkJBTW9CLElBQUk7Ozs7Z0JBSWpCLFdBQVc7Ozs7Ozs7Ozs7QUFVM0I7QUFFQSxlQUFlLGVBQWUsT0FBZSxZQUFZLE1BQXNCO0NBQzdFLE1BQU0sTUFBTSxHQUFHLGdCQUFnQiw4QkFBOEIsbUJBQW1CLEtBQUs7Q0FDckYsTUFBTSxhQUFhLElBQUksZ0JBQWdCO0NBQ3ZDLE1BQU0sUUFBUSxpQkFBaUIsV0FBVyxNQUFNLEdBQUcsU0FBUztDQUM1RCxJQUFJO0VBQ0YsTUFBTSxNQUFNLE1BQU0sTUFBTSxLQUFLO0dBQzNCLFFBQVEsV0FBVztHQUNuQixTQUFTLEVBQ1AsUUFBUSxrQ0FDVjtFQUNGLENBQUM7RUFDRCxJQUFJLENBQUMsSUFBSSxJQUFJLE1BQU0sSUFBSSxNQUFNLDRCQUE0QixJQUFJLFFBQVE7RUFDckUsTUFBTSxPQUFRLE1BQU0sSUFBSSxLQUFLO0VBQzdCLE9BQU8sS0FBSyxTQUFTLFlBQVksQ0FBQztDQUNwQyxVQUFVO0VBQ1IsYUFBYSxLQUFLO0NBQ3BCO0FBQ0Y7QUFFQSxlQUFlLGtCQUFrQixhQUE2QztDQUM1RSxNQUFNLE9BQU8sWUFBWSxZQUFZO0NBQ3JDLElBQUksV0FBVyxPQUFPLE9BQU8sV0FBVztDQUN4QyxJQUFJO0VBQ0YsTUFBTSxXQUFXLE1BQU0sZUFDckIsOENBQThDLEtBQUssZUFDbkQsR0FDRjtFQUNBLE9BQU8sU0FBUyxFQUFFLEVBQUUsU0FBUyxPQUFPLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxLQUFLO0NBQzFELFFBQVE7RUFDTixPQUFPO0NBQ1Q7QUFDRjs7Ozs7QUFNQSxlQUFlLGlDQUNiLGFBQ0EsT0FDQSxhQUNzQjtDQUN0QixNQUFNLFFBQVEsWUFBWSxXQUFXLEtBQUs7Q0FDMUMsTUFBTSxjQUFjLGFBQWEsS0FBSyxJQUNsQyxDQUFDLFlBQVksS0FBSyxHQUFHLEdBQUcsWUFBWSxLQUFLLEVBQUUsR0FBRyxPQUFPLElBQ3JEO0VBQ0UsR0FBRyxNQUFNO0VBQ1QsR0FBRyxNQUFNO0VBQ1QsR0FBRyxNQUFNO0VBQ1QsR0FBRyxNQUFNO0VBQ1QsR0FBRyxNQUFNO0NBQ1g7Q0FFSixNQUFNLFVBQVUsSUFBSSxJQUF1QjtDQUUzQyxNQUFNLFFBQVEsV0FDWixZQUFZLElBQUksT0FBTyxTQUFTO0VBQzlCLE1BQU0sTUFBTSxHQUFHLGFBQWEsa0NBQWtDLG1CQUM1RCxJQUNGLEVBQUU7RUFDRixNQUFNLE1BQU0sTUFBTSxNQUFNLEdBQUc7RUFDM0IsSUFBSSxDQUFDLElBQUksSUFBSTtFQUNiLE1BQU0sT0FBUSxNQUFNLElBQUksS0FBSztFQU83QixLQUFLLE1BQU0sUUFBUSxLQUFLLFVBQVUsQ0FBQyxHQUFHO0dBQ3BDLE1BQU0sT0FBTyxLQUFLLE9BQU8sS0FBSyxLQUFLO0dBQ25DLE1BQU0sUUFBUSxLQUFLLGVBQWUsR0FBRSxDQUFFLFlBQVk7R0FDbEQsSUFBSSxDQUFDLFFBQVEsVUFBVSxLQUFLLElBQUksR0FBRzs7R0FFbkMsTUFBTSxpQkFDSixRQUFRLGFBQWEsS0FBSyxDQUFDLEtBQzNCLEtBQUssU0FBUyxTQUFTLEtBQ3ZCLEtBQUssU0FBUyxNQUFNLEtBQ3BCLEtBQUssU0FBUyxTQUFTLEtBQ3ZCLEtBQUssU0FBUyxPQUFPLEtBQ3JCLEtBQUssU0FBUyxRQUFRLEtBQ3RCLEtBQUssU0FBUyxvQkFBb0IsS0FDbEMsS0FBSyxTQUFTLGFBQWEsS0FDM0IsS0FBSyxTQUFTLFlBQVksS0FDMUIsS0FBSyxTQUFTLGFBQWEsS0FDM0IsS0FBSyxTQUFTLGNBQWMsS0FDNUIsS0FBSyxTQUFTLE9BQU8sS0FDckIsS0FBSyxTQUFTLGNBQWMsS0FDNUIsS0FBSyxTQUFTLFNBQVM7R0FFekIsSUFBSSxDQUFDLGdCQUFnQjtHQUNyQixNQUFNLE9BQU8sUUFBUSxJQUFJO0dBQ3pCLElBQUksQ0FBQyxRQUFRLFFBQVEsSUFBSSxLQUFLLEVBQUUsR0FBRztHQUVuQyxJQUFJLFdBQVc7R0FDZixJQUFJLEtBQUssU0FBUyxNQUFNLEtBQUssS0FBSyxTQUFTLFdBQVcsS0FBSyxLQUFLLFNBQVMsU0FBUyxHQUFHO0lBQ25GLFdBQVc7R0FDYixPQUFPLElBQUksS0FBSyxTQUFTLFNBQVMsS0FBSyxLQUFLLFNBQVMsVUFBVSxHQUFHO0lBQ2hFLFdBQVc7R0FDYixPQUFPLElBQUksS0FBSyxTQUFTLFNBQVMsR0FBRztJQUNuQyxXQUFXO0dBQ2IsT0FBTyxJQUFJLEtBQUssU0FBUyxhQUFhLEtBQUssS0FBSyxTQUFTLFFBQVEsS0FBSyxLQUFLLFNBQVMsU0FBUyxHQUFHO0lBQzlGLFdBQVc7R0FDYixPQUFPLElBQUksS0FBSyxTQUFTLE1BQU0sS0FBSyxLQUFLLFNBQVMsWUFBWSxLQUFLLEtBQUssU0FBUyxVQUFVLEdBQUc7SUFDNUYsV0FBVztHQUNiLE9BQU8sSUFBSSxLQUFLLFNBQVMsTUFBTSxLQUFLLEtBQUssU0FBUyxVQUFVLEdBQUc7SUFDN0QsV0FBVztHQUNiO0dBRUEsUUFBUSxJQUFJLEtBQUssSUFBSTtJQUNuQixJQUFJLE1BQU0sS0FBSztJQUNmLFFBQVE7SUFDUixXQUFXLEtBQUs7SUFDaEI7SUFDQTtJQUNBLFNBQVM7SUFDVDtJQUNBLGFBQWEsS0FBSyxlQUFlLEdBQUcsS0FBSyxJQUFJLE1BQU07SUFDbkQsU0FBUztJQUNULFVBQVU7SUFDVixRQUFRO0lBQ1IsWUFBWSxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7R0FDckMsQ0FBQztFQUNIO0NBQ0YsQ0FBQyxDQUNIO0NBRUEsT0FBTyxDQUFDLEdBQUcsUUFBUSxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxLQUFLO0FBQzdDOzs7Ozs7O0FBUUEsT0FBTyxlQUFlLHlCQUF5QixPQUlpQjtDQUM5RCxNQUFNLE9BQU8scUJBQXFCLE1BQU0sV0FBVyxLQUFLLE1BQU0sWUFBWSxZQUFZO0NBQ3RGLE1BQU0sUUFBUSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksS0FBSyxNQUFNLFNBQVMsRUFBRSxDQUFDO0NBQzFELE1BQU0sY0FBYyxNQUFNLGFBQWEsS0FBSyxDQUFDLENBQUMsWUFBWSxLQUFLO0NBQy9ELE1BQU0sU0FBUyxJQUFJLElBQStDO0NBQ2xFLE1BQU0sY0FBd0IsQ0FBQzs7Q0FHL0IsTUFBTSxjQUFjLHFCQUFxQixTQUFTLENBQUM7Q0FDbkQsS0FBSyxNQUFNLEtBQUssYUFBYTtFQUMzQixJQUNFLGVBQ0EsQ0FBQyxHQUFHLEVBQUUsS0FBSyxHQUFHLEVBQUUsU0FBUyxHQUFHLEVBQUUsY0FBYyxZQUFZLENBQUMsQ0FBQyxTQUFTLFdBQVcsR0FDOUU7R0FDQTtFQUNGO0VBQ0EsTUFBTSxPQUFPLFFBQVEsRUFBRSxJQUFJO0VBQzNCLElBQUksQ0FBQyxNQUFNO0VBQ1gsT0FBTyxJQUFJLE1BQU07R0FDZixJQUFJLFNBQVMsS0FBSyxHQUFHO0dBQ3JCLFFBQVE7R0FDUixXQUFXLFNBQVMsS0FBSyxHQUFHLEtBQUssWUFBWTtHQUM3QyxNQUFNLEVBQUU7R0FDUjtHQUNBLFNBQVM7R0FDVCxVQUFVLEVBQUU7R0FDWixhQUFhLEVBQUU7R0FDZixTQUFTLFdBQVcsRUFBRTtHQUN0QixVQUFVLDZCQUE2QixFQUFFO0dBQ3pDLFFBQVE7R0FDUixZQUFZLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUNuQyxXQUFXO0VBQ2IsQ0FBQztDQUNIO0NBQ0EsSUFBSSxPQUFPLE9BQU8sR0FBRyxZQUFZLEtBQUssc0JBQXNCOztDQUc1RCxJQUFJO0VBQ0YsTUFBTSxNQUFNLE1BQU0sa0JBQWtCLElBQUk7RUFDeEMsSUFBSSxLQUFLO0dBQ1AsTUFBTSxXQUFXLE1BQU0sZUFBZSx1QkFBdUIsS0FBSyxLQUFLLENBQUM7R0FDeEUsSUFBSSxTQUFTLFNBQVMsR0FBRztJQUN2QixZQUFZLEtBQUssbUNBQW1DO0dBQ3REO0dBQ0EsS0FBSyxNQUFNLEtBQUssVUFBVTtJQUN4QixNQUFNLE9BQWUsRUFBRSxNQUFNLFNBQVM7SUFDdEMsTUFBTSxXQUFXLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxJQUFJLEtBQUs7SUFDMUMsTUFBTSxPQUFlLEVBQUUsV0FBVyxTQUFTO0lBQzNDLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxVQUFVLEtBQUssSUFBSSxHQUFHO0lBQ2hELElBQ0UsZUFDQSxDQUFDLEdBQUcsS0FBSyxHQUFHLEVBQUUsZUFBZSxTQUFTLEdBQUcsR0FBRyxFQUFFLE1BQU0sU0FBUyxLQUMxRCxZQUFZLENBQUMsQ0FDYixTQUFTLFdBQVcsR0FDdkI7S0FDQTtJQUNGO0lBQ0EsTUFBTSxPQUFPLFFBQVEsSUFBSTtJQUN6QixJQUFJLENBQUMsTUFBTTtJQUVYLE1BQU0sV0FBVyxPQUFPLElBQUksSUFBSTtJQUNoQyxJQUFJLFVBQVU7S0FDWixTQUFTLGFBQWEsRUFBRSxlQUFlLFNBQVM7S0FDaEQsU0FBUyxnQkFBZ0IsRUFBRSxNQUFNLFNBQVM7S0FDMUMsU0FBUyxZQUFZLEVBQUUsU0FBUyxTQUFTO0tBQ3pDLFNBQVMsYUFBYSxFQUFFLE1BQU0sU0FBUztLQUN2QztJQUNGO0lBRUEsSUFBSSxVQUF5QixFQUFFLE1BQU0sU0FBUztJQUM5QyxNQUFNLGFBQTRCLEVBQUUsU0FBUyxTQUFTO0lBQ3RELElBQUksQ0FBQyxXQUFXLFlBQVk7S0FDMUIsSUFBSTtNQUNGLE1BQU0sT0FBTyxJQUFJLElBQUksVUFBVSxDQUFDLENBQUMsU0FBUyxRQUFRLFVBQVUsRUFBRTtNQUM5RCxVQUFVLDZCQUE2QjtLQUN6QyxRQUFRLENBRVI7SUFDRjtJQUVBLE9BQU8sSUFBSSxNQUFNO0tBQ2YsSUFBSSxNQUFNO0tBQ1YsUUFBUTtLQUNSLFdBQVc7S0FDWDtLQUNBO0tBQ0EsU0FBUztLQUNULFVBQVUsRUFBRSxlQUFlLFNBQVM7S0FDcEMsYUFBYSxFQUFFLE1BQU0sU0FBUyxHQUFHLEtBQUssS0FBSyxZQUFZLElBQUksS0FBSztLQUNoRSxTQUFTO0tBQ1QsVUFBVTtLQUNWLFFBQVE7S0FDUixZQUFZLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtLQUNuQyxXQUFXLE9BQU8sRUFBRSxXQUFXLFNBQVMsRUFBRTtJQUM1QyxDQUFDO0dBQ0g7RUFDRjtDQUNGLFFBQVEsQ0FFUjs7Q0FHQSxJQUFJLE9BQU8sT0FBTyxTQUFTLGFBQWE7RUFDdEMsSUFBSTtHQUNGLE1BQU0sYUFBYSxNQUFNLGlDQUN2QixNQUNBLE9BQ0EsTUFBTSxXQUNSO0dBQ0EsSUFBSSxXQUFXLFNBQVMsR0FBRztJQUN6QixZQUFZLEtBQUssMEJBQTBCO0dBQzdDO0dBQ0EsS0FBSyxNQUFNLEtBQUssWUFBWTtJQUMxQixJQUFJLENBQUMsT0FBTyxJQUFJLEVBQUUsSUFBSSxHQUFHO0tBQ3ZCLE9BQU8sSUFBSSxFQUFFLE1BQU07TUFBRSxHQUFHO01BQUcsV0FBVztLQUFFLENBQUM7SUFDM0M7R0FDRjtFQUNGLFFBQVEsQ0FFUjtDQUNGO0NBRUEsTUFBTSxhQUFhLENBQUMsR0FBRyxPQUFPLE9BQU8sQ0FBQyxDQUFDLENBQ3BDLE1BQU0sR0FBRyxNQUFNLEVBQUUsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUN6QyxNQUFNLEdBQUcsS0FBSyxDQUFDLENBQ2YsS0FBSyxFQUFFLFdBQVcsSUFBSSxHQUFHLFVBQVUsR0FBRztDQUV6QyxPQUFPO0VBQUU7RUFBWTtDQUFZO0FBQ25DO0FBRUEsT0FBTyxlQUFlLHVCQUE2QztDQUNqRSxNQUFNLFFBQVEsb0JBQW9CLENBQUMsQ0FBQyxRQUFRLE1BQU0sRUFBRSxXQUFXLFNBQVM7Q0FDeEUsTUFBTSxTQUFTLElBQUksSUFBdUI7Q0FDMUMsS0FBSyxNQUFNLEtBQUssT0FBTyxPQUFPLElBQUksRUFBRSxNQUFNLENBQUM7Q0FFM0MsSUFBSTtFQUNGLE1BQU0sRUFBRSxNQUFNLFVBQVUsTUFBTSxTQUMzQixLQUFLLHlCQUFnQyxDQUFDLENBQ3RDLE9BQU8sR0FBRyxDQUFDLENBQ1gsR0FBRyxVQUFVLFNBQVMsQ0FBQyxDQUN2QixNQUFNLGNBQWMsRUFBRSxXQUFXLE1BQU0sQ0FBQyxDQUFDLENBQ3pDLE1BQU0sR0FBRztFQUNaLElBQUksQ0FBQyxTQUFTLE1BQU07R0FDbEIsS0FBSyxNQUFNLE9BQU8sTUFBZTtJQUMvQixJQUFJLElBQUksUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLElBQUksR0FBRztLQUNyQyxPQUFPLElBQUksSUFBSSxNQUFNO01BQ25CLElBQUksT0FBTyxJQUFJLEVBQUU7TUFDakIsUUFBUSxJQUFJLFVBQVU7TUFDdEIsV0FBVyxJQUFJLGFBQWEsT0FBTyxJQUFJLEVBQUU7TUFDekMsTUFBTSxJQUFJO01BQ1YsTUFBTSxJQUFJO01BQ1YsU0FBUyxJQUFJLFdBQVc7TUFDeEIsVUFBVSxJQUFJLFlBQVk7TUFDMUIsYUFBYSxJQUFJLGVBQWU7TUFDaEMsU0FBUyxJQUFJLFdBQVc7TUFDeEIsVUFBVSxJQUFJLFlBQVk7TUFDMUIsUUFBUSxJQUFJLFVBQVU7TUFDdEIsWUFBWSxJQUFJO0tBQ2xCLENBQUM7SUFDSDtHQUNGO0VBQ0Y7Q0FDRixRQUFRLENBRVI7Q0FFQSxPQUFPLENBQUMsR0FBRyxPQUFPLE9BQU8sQ0FBQztBQUM1QjtBQUVBLE9BQU8sZUFBZSx5QkFBeUIsT0FJYjtDQUNoQyxNQUFNLEVBQUUsWUFBWSxnQkFBZ0IsTUFBTSx5QkFBeUIsS0FBSztDQUN4RSxJQUFJLENBQUMsV0FBVyxRQUFRO0VBQ3RCLE9BQU87R0FBRSxVQUFVO0dBQUcsU0FBUztHQUFHLGVBQWU7RUFBMEI7Q0FDN0U7Q0FFQSxNQUFNLGVBQWUsb0JBQW9CO0NBQ3pDLE1BQU0sZ0JBQWdCLElBQUksSUFBSSxhQUFhLEtBQUssTUFBTSxFQUFFLElBQUksQ0FBQztDQUM3RCxJQUFJLFdBQVc7Q0FDZixJQUFJLFVBQVU7Q0FFZCxLQUFLLE1BQU0sS0FBSyxZQUFZO0VBQzFCLElBQUksY0FBYyxJQUFJLEVBQUUsSUFBSSxHQUFHO0dBQzdCLFdBQVc7RUFDYixPQUFPO0dBQ0wsY0FBYyxJQUFJLEVBQUUsSUFBSTtHQUN4QixhQUFhLFFBQVE7SUFBRSxHQUFHO0lBQUcsUUFBUTtHQUFVLENBQUM7R0FDaEQsWUFBWTtFQUNkO0NBQ0Y7Q0FDQSxxQkFBcUIsWUFBWTs7Q0FHakMsSUFBSTtFQUNGLE1BQU0sU0FBUyxXQUFXLEtBQUssRUFBRSxJQUFJLEtBQUssWUFBWSxLQUFLLEdBQUcsV0FBVyxJQUFJO0VBQzdFLE1BQU0sU0FDSCxLQUFLLHlCQUFnQyxDQUFDLENBQ3RDLE9BQU8sUUFBUTtHQUFFLFlBQVk7R0FBb0Isa0JBQWtCO0VBQUssQ0FBQztDQUM5RSxRQUFRLENBRVI7Q0FFQSxPQUFPO0VBQ0w7RUFDQTtFQUNBLGVBQWUsWUFBWSxLQUFLLEtBQUssS0FBSztDQUM1QztBQUNGO0FBRUEsZUFBZSwyQkFDYixNQVNBLFNBQ3dCO0NBQ3hCLE1BQU0sVUFBVSxTQUFTLEtBQUssUUFBUSxZQUFZLEVBQUUsR0FBRyxLQUFLLE9BQ3pELFFBQVEsbUJBQW1CLEdBQUcsQ0FBQyxDQUMvQixNQUFNLEdBQUcsRUFBRTs7Q0FHZCxNQUFNLGNBQWMsdUJBQXVCO0NBQzNDLElBQUksQ0FBQyxZQUFZLE1BQU0sTUFBTSxFQUFFLFNBQVMsS0FBSyxJQUFJLEdBQUc7RUFDbEQsWUFBWSxRQUFRO0dBQ2xCLElBQUk7R0FDSixNQUFNLEtBQUs7R0FDWCxNQUFNLEtBQUs7R0FDWCxTQUFTLEtBQUs7R0FDZCxVQUFVLEtBQUssWUFBWTtHQUMzQixhQUFhLEtBQUssZUFBZSxHQUFHLEtBQUssS0FBSyxJQUFJLEtBQUssUUFBUTtHQUMvRCxTQUFTLEtBQUs7R0FDZCxVQUFVLEtBQUs7R0FDZixVQUFVO0dBQ1YsVUFBVTtHQUNWLGFBQWE7R0FDYixZQUFZLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtFQUNyQyxDQUFDO0VBQ0Qsd0JBQXdCLFdBQVc7Q0FDckM7O0NBR0EsSUFBSTtFQUNGLE1BQU0scUJBQ0o7R0FDRSxNQUFNLEtBQUssS0FBSyxNQUFNLEdBQUcsR0FBRztHQUM1QixNQUFNLEtBQUssS0FBSyxNQUFNLEdBQUcsR0FBRztHQUM1QixVQUFVLEtBQUssV0FBVyxLQUFJLENBQUUsTUFBTSxHQUFHLEdBQUc7R0FDNUMsV0FBVyxLQUFLLFlBQVksaUJBQWdCLENBQUUsTUFBTSxHQUFHLEdBQUc7R0FDMUQsY0FBYyxLQUFLLGVBQWUsR0FBRyxLQUFLLEtBQUssYUFBWSxDQUFFLE1BQU0sR0FBRyxHQUFJO0dBQzFFLFNBQVMsS0FBSyxXQUFXO0dBQ3pCLFNBQVMsS0FBSyxZQUFZO0dBQzFCLFlBQVk7R0FDWixXQUFXO0dBQ1gsUUFBUTtHQUNSLFlBQVk7R0FDWixXQUFXO0VBQ2IsR0FDQSxPQUNGO0NBQ0YsUUFBUSxDQUVSOztDQUdBLElBQUk7RUFDRixNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sU0FDM0IsS0FBSyxRQUFRLENBQUMsQ0FDZCxPQUFPO0dBQ04sVUFBVTtHQUNWLE1BQU0sS0FBSztHQUNYLE1BQU0sS0FBSztHQUNYLGFBQWEsS0FBSztHQUNsQixTQUFTLEtBQUs7R0FDZCxVQUFVLEtBQUs7R0FDZixTQUFTLEtBQUs7R0FDZCxVQUFVLEtBQUs7RUFDakIsQ0FBQyxDQUFDLENBQ0QsT0FBTyx5QkFBeUIsQ0FBQyxDQUNqQyxPQUFPO0VBQ1YsSUFBSSxPQUFPO0dBQ1QsT0FBTztJQUNMLFNBQVMsTUFBTTtJQUNmLE1BQU0sTUFBTTtJQUNaLE1BQU0sTUFBTTtJQUNaLFNBQVMsTUFBTTtHQUNqQjtFQUNGO0NBQ0YsUUFBUSxDQUVSO0NBRUEsT0FBTztFQUNMLFNBQVM7RUFDVCxNQUFNLEtBQUs7RUFDWCxNQUFNLEtBQUs7RUFDWCxTQUFTLEtBQUs7Q0FDaEI7QUFDRjtBQUVBLE9BQU8sZUFBZSxzQkFDcEIsSUFDQSxZQUN3QjtDQUN4QixNQUFNLFFBQVEsb0JBQW9CO0NBQ2xDLElBQUksT0FBTyxNQUFNLE1BQU0sTUFBTSxFQUFFLE9BQU8sTUFBTSxFQUFFLFNBQVMsRUFBRTtDQUV6RCxJQUFJLENBQUMsTUFBTTtFQUNULElBQUk7R0FDRixNQUFNLEVBQUUsU0FBUyxNQUFNLFNBQ3BCLEtBQUsseUJBQXlCLENBQUMsQ0FDL0IsT0FBTyxHQUFHLENBQUMsQ0FDWCxHQUFHLE1BQU0sRUFBRSxDQUFDLENBQ1osWUFBWTtHQUNmLElBQUksTUFBTTtJQUNSLE9BQU87S0FDTCxJQUFJLE9BQU8sS0FBSyxFQUFFO0tBQ2xCLFFBQVEsS0FBSztLQUNiLFdBQVcsS0FBSyxhQUFhO0tBQzdCLE1BQU0sS0FBSztLQUNYLE1BQU0sS0FBSztLQUNYLFNBQVMsS0FBSyxXQUFXO0tBQ3pCLFVBQVUsS0FBSztLQUNmLGFBQWEsS0FBSztLQUNsQixTQUFTLEtBQUs7S0FDZCxVQUFVLEtBQUs7S0FDZixRQUFRLEtBQUs7SUFDZjtHQUNGO0VBQ0YsUUFBUSxDQUVSO0NBQ0Y7Q0FFQSxJQUFJLENBQUMsTUFBTSxNQUFNLElBQUksTUFBTSxzQkFBc0I7Q0FFakQsTUFBTSxXQUFXLE1BQU0sMkJBQTJCLE1BQU0sVUFBVTtDQUVsRSxNQUFNLGVBQWUsTUFBTSxLQUFLLE1BQzlCLEVBQUUsT0FBTyxNQUFNLEVBQUUsU0FBUyxLQUFNLE9BQU87RUFBRSxHQUFHO0VBQUcsUUFBUTtDQUFXLElBQUksQ0FDeEU7Q0FDQSxxQkFBcUIsWUFBWTtDQUVqQyxJQUFJO0VBQ0YsTUFBTSxTQUNILEtBQUsseUJBQXlCLENBQUMsQ0FDL0IsT0FBTztHQUFFLFFBQVE7R0FBWSxhQUFhO0VBQVcsQ0FBQyxDQUFDLENBQ3ZELEdBQUcsTUFBTSxFQUFFO0NBQ2hCLFFBQVEsQ0FFUjtDQUVBLE9BQU87QUFDVDtBQUVBLE9BQU8sZUFBZSxxQkFBcUIsSUFBWSxZQUFvQjtDQUN6RSxNQUFNLFFBQVEsb0JBQW9CO0NBQ2xDLE1BQU0sVUFBVSxNQUFNLEtBQUssTUFBTyxFQUFFLE9BQU8sS0FBSztFQUFFLEdBQUc7RUFBRyxRQUFRO0NBQVcsSUFBSSxDQUFFO0NBQ2pGLHFCQUFxQixPQUFPO0NBRTVCLElBQUk7RUFDRixNQUFNLFNBQ0gsS0FBSyx5QkFBeUIsQ0FBQyxDQUMvQixPQUFPO0dBQUUsUUFBUTtHQUFZLGFBQWE7RUFBVyxDQUFDLENBQUMsQ0FDdkQsR0FBRyxNQUFNLEVBQUU7Q0FDaEIsUUFBUSxDQUVSO0FBQ0Y7QUFRQSxPQUFPLGVBQWUsMEJBQTBCLE9BS2Y7Q0FDL0IsTUFBTSxFQUFFLFlBQVksZ0JBQWdCLE1BQU0seUJBQXlCO0VBQ2pFLGFBQWEsTUFBTTtFQUNuQixPQUFPLE1BQU07RUFDYixhQUFhLE1BQU07Q0FDckIsQ0FBQztDQUVELElBQUksQ0FBQyxXQUFXLFFBQVE7RUFDdEIsT0FBTztHQUFFLFdBQVc7R0FBRyxTQUFTO0dBQUcsZUFBZTtFQUEyQjtDQUMvRTtDQUVBLE1BQU0sZ0JBQWdCLHVCQUF1QjtDQUM3QyxNQUFNLGdCQUFnQixJQUFJLElBQUksY0FBYyxLQUFLLE1BQU0sRUFBRSxJQUFJLENBQUM7Q0FFOUQsSUFBSTtFQUNGLE1BQU0sV0FBVyxNQUFNLG1CQUFtQjtFQUMxQyxLQUFLLE1BQU0sS0FBSyxVQUFVLGNBQWMsSUFBSSxFQUFFLElBQUk7Q0FDcEQsUUFBUSxDQUVSO0NBRUEsSUFBSSxZQUFZO0NBQ2hCLElBQUksVUFBVTtDQUVkLEtBQUssTUFBTSxLQUFLLFlBQVk7RUFDMUIsSUFBSSxjQUFjLElBQUksRUFBRSxJQUFJLEdBQUc7R0FDN0IsV0FBVztHQUNYO0VBQ0Y7RUFDQSxjQUFjLElBQUksRUFBRSxJQUFJO0VBQ3hCLE1BQU0sMkJBQTJCLEdBQUcsTUFBTSxPQUFPO0VBQ2pELGFBQWE7Q0FDZjtDQUVBLE9BQU87RUFDTDtFQUNBO0VBQ0EsZUFBZSxZQUFZLEtBQUssS0FBSyxLQUFLO0NBQzVDO0FBQ0Y7QUFFQSxPQUFPLGVBQWUseUJBQ3BCLFNBQzhCO0NBQzlCLE1BQU0sVUFBVSxNQUFNLHFCQUFxQjtDQUMzQyxJQUFJLENBQUMsUUFBUSxRQUFRLE9BQU87RUFBRSxXQUFXO0VBQUcsU0FBUztDQUFFO0NBRXZELElBQUksWUFBWTtDQUNoQixJQUFJLFVBQVU7Q0FFZCxLQUFLLE1BQU0sS0FBSyxTQUFTO0VBQ3ZCLElBQUk7R0FDRixNQUFNLDJCQUEyQixHQUFHLE9BQU87R0FDM0MsYUFBYTtFQUNmLFFBQVE7R0FDTixXQUFXO0VBQ2I7Q0FDRjtDQUVBLE1BQU0sUUFBUSxvQkFBb0IsQ0FBQyxDQUFDLEtBQUssTUFDdkMsRUFBRSxXQUFXLFlBQVk7RUFBRSxHQUFHO0VBQUcsUUFBUTtDQUFXLElBQUksQ0FDMUQ7Q0FDQSxxQkFBcUIsS0FBSztDQUUxQixJQUFJO0VBQ0YsTUFBTSxTQUNILEtBQUsseUJBQXlCLENBQUMsQ0FDL0IsT0FBTztHQUFFLFFBQVE7R0FBWSxhQUFhO0VBQVEsQ0FBQyxDQUFDLENBQ3BELEdBQUcsVUFBVSxTQUFTO0NBQzNCLFFBQVEsQ0FFUjtDQUVBLE9BQU87RUFBRTtFQUFXO0NBQVE7QUFDOUIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsid2lraWRhdGEtaW1wb3J0LnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHN1cGFiYXNlIH0gZnJvbSBcIkAvaW50ZWdyYXRpb25zL3N1cGFiYXNlL2NsaWVudFwiO1xuaW1wb3J0IHsgY3JlYXRlRmlyZXN0b3JlQnJhbmQsIGdldEZpcmVzdG9yZUJyYW5kcyB9IGZyb20gXCJAL3NlcnZpY2VzL2ZpcmVzdG9yZVNlcnZpY2VcIjtcbmltcG9ydCB7IGNvdW50cnlOYW1lLCBub3JtYWxpemVDb3VudHJ5Q29kZSB9IGZyb20gXCJAL2xpYi9nZW9cIjtcblxuZXhwb3J0IGNvbnN0IElTT19UT19RSUQ6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gIFpBOiBcIlEyNThcIiwgVVM6IFwiUTMwXCIsIEdCOiBcIlExNDVcIiwgRlI6IFwiUTE0MlwiLCBERTogXCJRMTgzXCIsXG4gIElUOiBcIlEzOFwiLCBFUzogXCJRMjlcIiwgUFQ6IFwiUTQ1XCIsIE5MOiBcIlE1NVwiLCBCUjogXCJRMTU1XCIsXG4gIElOOiBcIlE2NjhcIiwgQ046IFwiUTE0OFwiLCBKUDogXCJRMTdcIiwgS1I6IFwiUTg4NFwiLCBNWDogXCJROTZcIixcbiAgQ0E6IFwiUTE2XCIsIEFVOiBcIlE0MDhcIiwgTkc6IFwiUTEwMzNcIiwgS0U6IFwiUTExNFwiLCBFRzogXCJRNzlcIixcbiAgTUE6IFwiUTEwMjhcIiwgR0g6IFwiUTExN1wiLCBTTjogXCJRMTA0MVwiLCBFVDogXCJRMTE1XCIsXG4gIFRaOiBcIlE5MjRcIiwgVUc6IFwiUTEwMzZcIiwgUlc6IFwiUTEwMzdcIiwgQlc6IFwiUTk2M1wiLCBOQTogXCJRMTAzMFwiLFxuICBaVzogXCJROTU0XCIsIFpNOiBcIlE5NTNcIiwgTVo6IFwiUTEwMjlcIiwgQU86IFwiUTkxNlwiLCBDTTogXCJRMTAwOVwiLFxuICBDSTogXCJRMTAwOFwiLCBEWjogXCJRMjYyXCIsIFROOiBcIlE5NDhcIiwgTVU6IFwiUTEwMjdcIiwgTFM6IFwiUTEwMTNcIixcbiAgU1o6IFwiUTEwNTBcIiwgTVc6IFwiUTEwMjBcIiwgQ0Q6IFwiUTk3NFwiLFxuICBDSDogXCJRMzlcIiwgU0U6IFwiUTM0XCIsIE5POiBcIlEyMFwiLCBESzogXCJRMzVcIiwgRkk6IFwiUTMzXCIsXG4gIElFOiBcIlEyN1wiLCBCRTogXCJRMzFcIiwgQVQ6IFwiUTQwXCIsIFBMOiBcIlEzNlwiLCBHUjogXCJRNDFcIixcbiAgVFI6IFwiUTQzXCIsIFJVOiBcIlExNTlcIiwgVUE6IFwiUTIxMlwiLCBDWjogXCJRMjEzXCIsIFJPOiBcIlEyMThcIixcbiAgQVI6IFwiUTQxNFwiLCBDTDogXCJRMjk4XCIsIENPOiBcIlE3MzlcIiwgUEU6IFwiUTQxOVwiLCBVWTogXCJRNzdcIixcbiAgQUU6IFwiUTg3OFwiLCBTQTogXCJRODUxXCIsIFFBOiBcIlE4NDZcIiwgSUw6IFwiUTgwMVwiLCBTRzogXCJRMzM0XCIsXG4gIE1ZOiBcIlE4MzNcIiwgSUQ6IFwiUTI1MlwiLCBUSDogXCJRODY5XCIsIFBIOiBcIlE5MjhcIiwgVk46IFwiUTg4MVwiLFxuICBQSzogXCJRODQzXCIsIEJEOiBcIlE5MDJcIiwgTEs6IFwiUTg1NFwiLCBOWjogXCJRNjY0XCIsIEhLOiBcIlE4NjQ2XCIsXG4gIFRXOiBcIlE4NjVcIixcbn07XG5cbmV4cG9ydCBjb25zdCBTVVBQT1JURURfSU1QT1JUX0NPVU5UUklFUzogUmVhZG9ubHlBcnJheTwgcmVhZG9ubHkgW3N0cmluZywgc3RyaW5nXSA+ID0gW1xuICBbXCJaQVwiLCBcIvCfh7/wn4emIFNvdXRoIEFmcmljYVwiXSxcbiAgW1wiTkdcIiwgXCLwn4ez8J+HrCBOaWdlcmlhXCJdLFxuICBbXCJLRVwiLCBcIvCfh7Dwn4eqIEtlbnlhXCJdLFxuICBbXCJHSFwiLCBcIvCfh6zwn4etIEdoYW5hXCJdLFxuICBbXCJFR1wiLCBcIvCfh6rwn4esIEVneXB0XCJdLFxuICBbXCJNQVwiLCBcIvCfh7Lwn4emIE1vcm9jY29cIl0sXG4gIFtcIkVUXCIsIFwi8J+HqvCfh7kgRXRoaW9waWFcIl0sXG4gIFtcIlNOXCIsIFwi8J+HuPCfh7MgU2VuZWdhbFwiXSxcbiAgW1wiVFpcIiwgXCLwn4e58J+HvyBUYW56YW5pYVwiXSxcbiAgW1wiVUdcIiwgXCLwn4e68J+HrCBVZ2FuZGFcIl0sXG4gIFtcIlJXXCIsIFwi8J+Ht/Cfh7wgUndhbmRhXCJdLFxuICBbXCJCV1wiLCBcIvCfh6fwn4e8IEJvdHN3YW5hXCJdLFxuICBbXCJOQVwiLCBcIvCfh7Pwn4emIE5hbWliaWFcIl0sXG4gIFtcIlpXXCIsIFwi8J+Hv/Cfh7wgWmltYmFid2VcIl0sXG4gIFtcIlpNXCIsIFwi8J+Hv/Cfh7IgWmFtYmlhXCJdLFxuICBbXCJMU1wiLCBcIvCfh7Hwn4e4IExlc290aG9cIl0sXG4gIFtcIlNaXCIsIFwi8J+HuPCfh78gRXN3YXRpbmlcIl0sXG4gIFtcIk1aXCIsIFwi8J+HsvCfh78gTW96YW1iaXF1ZVwiXSxcbiAgW1wiQU9cIiwgXCLwn4em8J+HtCBBbmdvbGFcIl0sXG4gIFtcIkNNXCIsIFwi8J+HqPCfh7IgQ2FtZXJvb25cIl0sXG4gIFtcIkNJXCIsIFwi8J+HqPCfh64gQ8O0dGUgZCdJdm9pcmVcIl0sXG4gIFtcIk1VXCIsIFwi8J+HsvCfh7ogTWF1cml0aXVzXCJdLFxuICBbXCJVU1wiLCBcIvCfh7rwn4e4IFVuaXRlZCBTdGF0ZXNcIl0sXG4gIFtcIkdCXCIsIFwi8J+HrPCfh6cgVW5pdGVkIEtpbmdkb21cIl0sXG4gIFtcIkZSXCIsIFwi8J+Hq/Cfh7cgRnJhbmNlXCJdLFxuICBbXCJERVwiLCBcIvCfh6nwn4eqIEdlcm1hbnlcIl0sXG4gIFtcIkVTXCIsIFwi8J+HqvCfh7ggU3BhaW5cIl0sXG4gIFtcIlBUXCIsIFwi8J+HtfCfh7kgUG9ydHVnYWxcIl0sXG4gIFtcIklUXCIsIFwi8J+HrvCfh7kgSXRhbHlcIl0sXG4gIFtcIk5MXCIsIFwi8J+Hs/Cfh7EgTmV0aGVybGFuZHNcIl0sXG4gIFtcIkNIXCIsIFwi8J+HqPCfh60gU3dpdHplcmxhbmRcIl0sXG4gIFtcIlNFXCIsIFwi8J+HuPCfh6ogU3dlZGVuXCJdLFxuICBbXCJJRVwiLCBcIvCfh67wn4eqIElyZWxhbmRcIl0sXG4gIFtcIlBMXCIsIFwi8J+HtfCfh7EgUG9sYW5kXCJdLFxuICBbXCJUUlwiLCBcIvCfh7nwn4e3IFTDvHJraXllXCJdLFxuICBbXCJCUlwiLCBcIvCfh6fwn4e3IEJyYXppbFwiXSxcbiAgW1wiTVhcIiwgXCLwn4ey8J+HvSBNZXhpY29cIl0sXG4gIFtcIkNBXCIsIFwi8J+HqPCfh6YgQ2FuYWRhXCJdLFxuICBbXCJBUlwiLCBcIvCfh6bwn4e3IEFyZ2VudGluYVwiXSxcbiAgW1wiQ09cIiwgXCLwn4eo8J+HtCBDb2xvbWJpYVwiXSxcbiAgW1wiQ0xcIiwgXCLwn4eo8J+HsSBDaGlsZVwiXSxcbiAgW1wiSU5cIiwgXCLwn4eu8J+HsyBJbmRpYVwiXSxcbiAgW1wiQ05cIiwgXCLwn4eo8J+HsyBDaGluYVwiXSxcbiAgW1wiSlBcIiwgXCLwn4ev8J+HtSBKYXBhblwiXSxcbiAgW1wiS1JcIiwgXCLwn4ew8J+HtyBTb3V0aCBLb3JlYVwiXSxcbiAgW1wiQVVcIiwgXCLwn4em8J+HuiBBdXN0cmFsaWFcIl0sXG4gIFtcIk5aXCIsIFwi8J+Hs/Cfh78gTmV3IFplYWxhbmRcIl0sXG4gIFtcIkFFXCIsIFwi8J+HpvCfh6ogVW5pdGVkIEFyYWIgRW1pcmF0ZXNcIl0sXG4gIFtcIlNBXCIsIFwi8J+HuPCfh6YgU2F1ZGkgQXJhYmlhXCJdLFxuICBbXCJTR1wiLCBcIvCfh7jwn4esIFNpbmdhcG9yZVwiXSxcbiAgW1wiSURcIiwgXCLwn4eu8J+HqSBJbmRvbmVzaWFcIl0sXG4gIFtcIk1ZXCIsIFwi8J+HsvCfh74gTWFsYXlzaWFcIl0sXG4gIFtcIlBIXCIsIFwi8J+HtfCfh60gUGhpbGlwcGluZXNcIl0sXG4gIFtcIlRIXCIsIFwi8J+HufCfh60gVGhhaWxhbmRcIl0sXG4gIFtcIlZOXCIsIFwi8J+Hu/Cfh7MgVmlldG5hbVwiXSxcbl0gYXMgY29uc3Q7XG5cbmNvbnN0IFNQQVJRTF9FTkRQT0lOVCA9IFwiaHR0cHM6Ly9xdWVyeS53aWtpZGF0YS5vcmcvc3BhcnFsXCI7XG5jb25zdCBXSUtJREFUQV9BUEkgPSBcImh0dHBzOi8vd3d3Lndpa2lkYXRhLm9yZy93L2FwaS5waHBcIjtcblxuY29uc3QgQ0FORElEQVRFU19TVE9SQUdFX0tFWSA9IFwic290LWJyYW5kLWltcG9ydC1jYW5kaWRhdGVzLXYxXCI7XG5jb25zdCBJTVBPUlRFRF9CUkFORFNfU1RPUkFHRV9LRVkgPSBcInNvdC1pbXBvcnRlZC1icmFuZHMtdjFcIjtcblxuZXhwb3J0IHR5cGUgV2lraWRhdGFJbXBvcnRSZXN1bHQgPSB7XG4gIGluc2VydGVkOiBudW1iZXI7XG4gIHNraXBwZWQ6IG51bWJlcjtcbiAgc291cmNlU3VtbWFyeT86IHN0cmluZztcbn07XG5cbmV4cG9ydCB0eXBlIEFwcHJvdmVkQnJhbmQgPSB7XG4gIGJyYW5kSWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBzbHVnOiBzdHJpbmc7XG4gIHdlYnNpdGU6IHN0cmluZyB8IG51bGw7XG59O1xuXG5leHBvcnQgdHlwZSBDYW5kaWRhdGUgPSB7XG4gIGlkOiBzdHJpbmc7XG4gIHNvdXJjZTogc3RyaW5nO1xuICBzb3VyY2VfaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBzbHVnOiBzdHJpbmc7XG4gIGNvdW50cnk6IHN0cmluZztcbiAgY2F0ZWdvcnk6IHN0cmluZyB8IG51bGw7XG4gIGRlc2NyaXB0aW9uOiBzdHJpbmcgfCBudWxsO1xuICB3ZWJzaXRlOiBzdHJpbmcgfCBudWxsO1xuICBsb2dvX3VybDogc3RyaW5nIHwgbnVsbDtcbiAgc3RhdHVzOiBzdHJpbmc7XG4gIGNyZWF0ZWRfYXQ/OiBzdHJpbmc7XG59O1xuXG50eXBlIENvdW50cnlTZWVkQnJhbmQgPSB7XG4gIG5hbWU6IHN0cmluZztcbiAgY2F0ZWdvcnk6IHN0cmluZztcbiAgZG9tYWluOiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG59O1xuXG4vKipcbiAqIEN1cmF0ZWQgaGlnaC1zaWduYWwgbmF0aW9uYWwgJiByZWdpb25hbCBicmFuZHMgYnkgSVNPIGNvdW50cnkgY29kZS5cbiAqIEVuc3VyZXMgaW5zdGFudCwgcmljaCBtdWx0aS1jb3VudHJ5IGRpc2NvdmVyeSBldmVuIHdoZW4gV2lraWRhdGEgU1BBUlFMIHRocm90dGxlcy5cbiAqL1xuY29uc3QgR0xPQkFMX0NPVU5UUllfQVRMQVM6IFJlY29yZDxzdHJpbmcsIENvdW50cnlTZWVkQnJhbmRbXT4gPSB7XG4gIFpBOiBbXG4gICAgeyBuYW1lOiBcIkNhcGl0ZWMgQmFua1wiLCBjYXRlZ29yeTogXCJCYW5raW5nICYgRmluYW5jZVwiLCBkb21haW46IFwiY2FwaXRlY2JhbmsuY28uemFcIiwgZGVzY3JpcHRpb246IFwiU291dGggQWZyaWNhbiByZXRhaWwgYmFuayBrbm93biBmb3IgZGlnaXRhbCBiYW5raW5nIGFuZCBhY2Nlc3NpYmxlIGJyYW5jaGVzLlwiIH0sXG4gICAgeyBuYW1lOiBcIlNob3ByaXRlXCIsIGNhdGVnb3J5OiBcIkdyb2NlcmllcyAmIFN1cGVybWFya2V0c1wiLCBkb21haW46IFwic2hvcHJpdGUuY28uemFcIiwgZGVzY3JpcHRpb246IFwiQWZyaWNhJ3MgbGFyZ2VzdCBzdXBlcm1hcmtldCByZXRhaWxlciBoZWFkcXVhcnRlcmVkIGluIENhcGUgVG93bi5cIiB9LFxuICAgIHsgbmFtZTogXCJDaGVja2VycyBTaXh0eTYwXCIsIGNhdGVnb3J5OiBcIkRlbGl2ZXJ5ICYgT24tRGVtYW5kXCIsIGRvbWFpbjogXCJjaGVja2Vycy5jby56YVwiLCBkZXNjcmlwdGlvbjogXCJPbi1kZW1hbmQgNjAtbWludXRlIGdyb2NlcnkgZGVsaXZlcnkgc2VydmljZSBhY3Jvc3MgU291dGggQWZyaWNhLlwiIH0sXG4gICAgeyBuYW1lOiBcIldvb2x3b3J0aHMgU291dGggQWZyaWNhXCIsIGNhdGVnb3J5OiBcIkdyb2NlcmllcyAmIEZhc2hpb25cIiwgZG9tYWluOiBcIndvb2x3b3J0aHMuY28uemFcIiwgZGVzY3JpcHRpb246IFwiUHJlbWl1bSBTb3V0aCBBZnJpY2FuIGZvb2QsIGZhc2hpb24sIGJlYXV0eSwgYW5kIGhvbWV3YXJlIHJldGFpbGVyLlwiIH0sXG4gICAgeyBuYW1lOiBcIk1UTiBTb3V0aCBBZnJpY2FcIiwgY2F0ZWdvcnk6IFwiVGVsZWNvbXNcIiwgZG9tYWluOiBcIm10bi5jby56YVwiLCBkZXNjcmlwdGlvbjogXCJQYW4tQWZyaWNhbiBtb2JpbGUgdGVsZWNvbW11bmljYXRpb25zIGFuZCBmaW50ZWNoIG5ldHdvcmsuXCIgfSxcbiAgICB7IG5hbWU6IFwiVm9kYWNvbVwiLCBjYXRlZ29yeTogXCJUZWxlY29tc1wiLCBkb21haW46IFwidm9kYWNvbS5jby56YVwiLCBkZXNjcmlwdGlvbjogXCJMZWFkaW5nIFNvdXRoIEFmcmljYW4gbW9iaWxlIGNvbW11bmljYXRpb25zIGFuZCBNLVBlc2Egb3BlcmF0b3IuXCIgfSxcbiAgICB7IG5hbWU6IFwiRmlyc3QgTmF0aW9uYWwgQmFuayAoRk5CKVwiLCBjYXRlZ29yeTogXCJCYW5raW5nICYgRmluYW5jZVwiLCBkb21haW46IFwiZm5iLmNvLnphXCIsIGRlc2NyaXB0aW9uOiBcIklubm92YXRpdmUgU291dGggQWZyaWNhbiBjb21tZXJjaWFsIGFuZCByZXRhaWwgYmFuay5cIiB9LFxuICAgIHsgbmFtZTogXCJTdGFuZGFyZCBCYW5rXCIsIGNhdGVnb3J5OiBcIkJhbmtpbmcgJiBGaW5hbmNlXCIsIGRvbWFpbjogXCJzdGFuZGFyZGJhbmsuY28uemFcIiwgZGVzY3JpcHRpb246IFwiQWZyaWNhJ3MgbGFyZ2VzdCBiYW5raW5nIGdyb3VwIGJ5IGFzc2V0cywgZm91bmRlZCBpbiBTb3V0aCBBZnJpY2EuXCIgfSxcbiAgICB7IG5hbWU6IFwiTmFuZG8nc1wiLCBjYXRlZ29yeTogXCJGb29kICYgUmVzdGF1cmFudHNcIiwgZG9tYWluOiBcIm5hbmRvcy5jby56YVwiLCBkZXNjcmlwdGlvbjogXCJJY29uaWMgU291dGggQWZyaWNhbiBmbGFtZS1ncmlsbGVkIHBlcmktcGVyaSBjaGlja2VuIHJlc3RhdXJhbnQgY2hhaW4uXCIgfSxcbiAgICB7IG5hbWU6IFwiVGFrZWFsb3RcIiwgY2F0ZWdvcnk6IFwiRS1Db21tZXJjZVwiLCBkb21haW46IFwidGFrZWFsb3QuY29tXCIsIGRlc2NyaXB0aW9uOiBcIlNvdXRoIEFmcmljYSdzIGxlYWRpbmcgb25saW5lIG1hcmtldHBsYWNlIGFuZCBsb2dpc3RpY3MgbmV0d29yay5cIiB9LFxuICAgIHsgbmFtZTogXCJEaXNjb3ZlcnlcIiwgY2F0ZWdvcnk6IFwiSW5zdXJhbmNlICYgSGVhbHRoY2FyZVwiLCBkb21haW46IFwiZGlzY292ZXJ5LmNvLnphXCIsIGRlc2NyaXB0aW9uOiBcIlNoYXJlZC12YWx1ZSBoZWFsdGggaW5zdXJhbmNlLCBWaXRhbGl0eSByZXdhcmRzLCBhbmQgZGlnaXRhbCBiYW5raW5nIGdyb3VwLlwiIH0sXG4gICAgeyBuYW1lOiBcIkNsaWNrYXRlbGxcIiwgY2F0ZWdvcnk6IFwiVGVjaG5vbG9neVwiLCBkb21haW46IFwiY2xpY2thdGVsbC5jb21cIiwgZGVzY3JpcHRpb246IFwiQ2hhdCBjb21tZXJjZSBhbmQgbW9iaWxlIG1lc3NhZ2luZyBwaW9uZWVyIGZvdW5kZWQgaW4gU291dGggQWZyaWNhLlwiIH0sXG4gICAgeyBuYW1lOiBcIlBpY2sgbiBQYXlcIiwgY2F0ZWdvcnk6IFwiR3JvY2VyaWVzICYgU3VwZXJtYXJrZXRzXCIsIGRvbWFpbjogXCJwbnAuY28uemFcIiwgZGVzY3JpcHRpb246IFwiTWFqb3IgU291dGggQWZyaWNhbiBzdXBlcm1hcmtldCwgY2xvdGhpbmcsIGFuZCBoeXBlcm1hcmtldCBjaGFpbi5cIiB9LFxuICAgIHsgbmFtZTogXCJTYXNvbFwiLCBjYXRlZ29yeTogXCJFbmVyZ3kgJiBGdWVsXCIsIGRvbWFpbjogXCJzYXNvbC5jb21cIiwgZGVzY3JpcHRpb246IFwiSW50ZWdyYXRlZCBlbmVyZ3kgYW5kIGNoZW1pY2FsIGNvbXBhbnkgaGVhZHF1YXJ0ZXJlZCBpbiBTYW5kdG9uLlwiIH0sXG4gIF0sXG4gIE5HOiBbXG4gICAgeyBuYW1lOiBcIkZsdXR0ZXJ3YXZlXCIsIGNhdGVnb3J5OiBcIkZpbnRlY2ggJiBQYXltZW50c1wiLCBkb21haW46IFwiZmx1dHRlcndhdmUuY29tXCIsIGRlc2NyaXB0aW9uOiBcIlBhbi1BZnJpY2FuIHBheW1lbnRzIHRlY2hub2xvZ3kgY29tcGFueSBwb3dlcmluZyBnbG9iYWwgY29tbWVyY2UuXCIgfSxcbiAgICB7IG5hbWU6IFwiUGF5c3RhY2tcIiwgY2F0ZWdvcnk6IFwiRmludGVjaCAmIFBheW1lbnRzXCIsIGRvbWFpbjogXCJwYXlzdGFjay5jb21cIiwgZGVzY3JpcHRpb246IFwiTW9kZXJuIG9ubGluZSBhbmQgb2ZmbGluZSBwYXltZW50IGdhdGV3YXkgZm9yIEFmcmljYW4gYnVzaW5lc3Nlcy5cIiB9LFxuICAgIHsgbmFtZTogXCJNb25pZXBvaW50XCIsIGNhdGVnb3J5OiBcIkJhbmtpbmcgJiBGaW50ZWNoXCIsIGRvbWFpbjogXCJtb25pZXBvaW50LmNvbVwiLCBkZXNjcmlwdGlvbjogXCJBbGwtaW4tb25lIGJ1c2luZXNzIGJhbmtpbmcsIFBPUywgYW5kIGNvbnN1bWVyIHBheW1lbnRzIHBsYXRmb3JtIGluIE5pZ2VyaWEuXCIgfSxcbiAgICB7IG5hbWU6IFwiR1RDTyAoR3VhcmFudHkgVHJ1c3QgQmFuaylcIiwgY2F0ZWdvcnk6IFwiQmFua2luZyAmIEZpbmFuY2VcIiwgZG9tYWluOiBcImd0YmFuay5jb21cIiwgZGVzY3JpcHRpb246IFwiTGVhZGluZyBOaWdlcmlhbiBmaW5hbmNpYWwgc2VydmljZXMgaW5zdGl0dXRpb24uXCIgfSxcbiAgICB7IG5hbWU6IFwiWmVuaXRoIEJhbmtcIiwgY2F0ZWdvcnk6IFwiQmFua2luZyAmIEZpbmFuY2VcIiwgZG9tYWluOiBcInplbml0aGJhbmsuY29tXCIsIGRlc2NyaXB0aW9uOiBcIlRpZXItMSBOaWdlcmlhbiBjb21tZXJjaWFsIGFuZCBjb3Jwb3JhdGUgYmFuay5cIiB9LFxuICAgIHsgbmFtZTogXCJBY2Nlc3MgQmFua1wiLCBjYXRlZ29yeTogXCJCYW5raW5nICYgRmluYW5jZVwiLCBkb21haW46IFwiYWNjZXNzYmFua3BsYy5jb21cIiwgZGVzY3JpcHRpb246IFwiTXVsdGluYXRpb25hbCBjb21tZXJjaWFsIGJhbmsgaGVhZHF1YXJ0ZXJlZCBpbiBMYWdvcy5cIiB9LFxuICAgIHsgbmFtZTogXCJEYW5nb3RlIEdyb3VwXCIsIGNhdGVnb3J5OiBcIk1hbnVmYWN0dXJpbmcgJiBGTUNHXCIsIGRvbWFpbjogXCJkYW5nb3RlLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJXZXN0IEFmcmljYSdzIGxhcmdlc3QgaW5kdXN0cmlhbCBjb25nbG9tZXJhdGUgYWNyb3NzIGNlbWVudCwgc3VnYXIsIGFuZCBlbmVyZ3kuXCIgfSxcbiAgICB7IG5hbWU6IFwiSnVtaWEgTmlnZXJpYVwiLCBjYXRlZ29yeTogXCJFLUNvbW1lcmNlXCIsIGRvbWFpbjogXCJqdW1pYS5jb20ubmdcIiwgZGVzY3JpcHRpb246IFwiUGFuLUFmcmljYW4gb25saW5lIHJldGFpbCBtYXJrZXRwbGFjZSBhbmQgbG9naXN0aWNzIHNlcnZpY2UuXCIgfSxcbiAgICB7IG5hbWU6IFwiQWlyIFBlYWNlXCIsIGNhdGVnb3J5OiBcIkFpcmxpbmVzICYgVHJhdmVsXCIsIGRvbWFpbjogXCJmbHlhaXJwZWFjZS5jb21cIiwgZGVzY3JpcHRpb246IFwiTGFyZ2VzdCBwcml2YXRlIE5pZ2VyaWFuIGFpcmxpbmUgc2VydmluZyBkb21lc3RpYyBhbmQgaW50ZXJuYXRpb25hbCByb3V0ZXMuXCIgfSxcbiAgICB7IG5hbWU6IFwiS3VkYSBCYW5rXCIsIGNhdGVnb3J5OiBcIkRpZ2l0YWwgQmFua2luZ1wiLCBkb21haW46IFwia3VkYS5jb21cIiwgZGVzY3JpcHRpb246IFwiTW9iaWxlLWZpcnN0IGRpZ2l0YWwgY2hhbGxlbmdlciBiYW5rIGJ1aWx0IGZvciBOaWdlcmlhbnMuXCIgfSxcbiAgXSxcbiAgS0U6IFtcbiAgICB7IG5hbWU6IFwiU2FmYXJpY29tIChNLVBlc2EpXCIsIGNhdGVnb3J5OiBcIlRlbGVjb21zICYgRmludGVjaFwiLCBkb21haW46IFwic2FmYXJpY29tLmNvLmtlXCIsIGRlc2NyaXB0aW9uOiBcIktlbnlhJ3MgbGVhZGluZyB0ZWxlY29tcyBwcm92aWRlciBhbmQgcGlvbmVlciBvZiBNLVBlc2EgbW9iaWxlIG1vbmV5LlwiIH0sXG4gICAgeyBuYW1lOiBcIkVxdWl0eSBCYW5rIEtlbnlhXCIsIGNhdGVnb3J5OiBcIkJhbmtpbmcgJiBGaW5hbmNlXCIsIGRvbWFpbjogXCJlcXVpdHlncm91cGhvbGRpbmdzLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJFYXN0IEFmcmljYSdzIGxhcmdlc3QgYmFua2luZyBncm91cCBieSBjdXN0b21lciBiYXNlLlwiIH0sXG4gICAgeyBuYW1lOiBcIktDQiBCYW5rXCIsIGNhdGVnb3J5OiBcIkJhbmtpbmcgJiBGaW5hbmNlXCIsIGRvbWFpbjogXCJrY2Jncm91cC5jb21cIiwgZGVzY3JpcHRpb246IFwiUHJlbWllciBFYXN0IEFmcmljYW4gY29tbWVyY2lhbCBiYW5rIGhlYWRxdWFydGVyZWQgaW4gTmFpcm9iaS5cIiB9LFxuICAgIHsgbmFtZTogXCJLZW55YSBBaXJ3YXlzXCIsIGNhdGVnb3J5OiBcIkFpcmxpbmVzICYgVHJhdmVsXCIsIGRvbWFpbjogXCJrZW55YS1haXJ3YXlzLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJUaGUgUHJpZGUgb2YgQWZyaWNhIOKAlCBmbGFnIGNhcnJpZXIgYWlybGluZSBvZiBLZW55YS5cIiB9LFxuICAgIHsgbmFtZTogXCJOYWl2YXMgU3VwZXJtYXJrZXRcIiwgY2F0ZWdvcnk6IFwiR3JvY2VyaWVzICYgU3VwZXJtYXJrZXRzXCIsIGRvbWFpbjogXCJuYWl2YXMub25saW5lXCIsIGRlc2NyaXB0aW9uOiBcIktlbnlhJ3MgbGFyZ2VzdCBob21lZ3Jvd24gc3VwZXJtYXJrZXQgcmV0YWlsIGNoYWluLlwiIH0sXG4gICAgeyBuYW1lOiBcIkphdmEgSG91c2VcIiwgY2F0ZWdvcnk6IFwiRm9vZCAmIENvZmZlZVwiLCBkb21haW46IFwiamF2YWhvdXNlYWZyaWNhLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJFYXN0IEFmcmljYSdzIGxlYWRpbmcgY29mZmVlIGFuZCBjYXN1YWwgZGluaW5nIHJlc3RhdXJhbnQgYnJhbmQuXCIgfSxcbiAgICB7IG5hbWU6IFwiVHdpZ2EgRm9vZHNcIiwgY2F0ZWdvcnk6IFwiQWdyaVRlY2ggJiBSZXRhaWxcIiwgZG9tYWluOiBcInR3aWdhZm9vZHMuY29tXCIsIGRlc2NyaXB0aW9uOiBcIkIyQiBmb29kIGRpc3RyaWJ1dGlvbiBwbGF0Zm9ybSBjb25uZWN0aW5nIGZhcm1lcnMgYW5kIHZlbmRvcnMgaW4gS2VueWEuXCIgfSxcbiAgXSxcbiAgR0g6IFtcbiAgICB7IG5hbWU6IFwiTVROIEdoYW5hXCIsIGNhdGVnb3J5OiBcIlRlbGVjb21zICYgTW9Nb1wiLCBkb21haW46IFwibXRuLmNvbS5naFwiLCBkZXNjcmlwdGlvbjogXCJNYXJrZXQtbGVhZGluZyB0ZWxlY29tbXVuaWNhdGlvbnMgYW5kIE1vYmlsZSBNb25leSBvcGVyYXRvciBpbiBHaGFuYS5cIiB9LFxuICAgIHsgbmFtZTogXCJFY29iYW5rXCIsIGNhdGVnb3J5OiBcIkJhbmtpbmcgJiBGaW5hbmNlXCIsIGRvbWFpbjogXCJlY29iYW5rLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJQYW4tQWZyaWNhbiBiYW5raW5nIGNvbmdsb21lcmF0ZSB3aXRoIG1ham9yIG9wZXJhdGlvbnMgYWNyb3NzIEdoYW5hIGFuZCBXZXN0IEFmcmljYS5cIiB9LFxuICAgIHsgbmFtZTogXCJHQ0IgQmFua1wiLCBjYXRlZ29yeTogXCJCYW5raW5nICYgRmluYW5jZVwiLCBkb21haW46IFwiZ2NiYmFuay5jb20uZ2hcIiwgZGVzY3JpcHRpb246IFwiR2hhbmEncyBsYXJnZXN0IGluZGlnZW5vdXMgY29tbWVyY2lhbCBiYW5rLlwiIH0sXG4gICAgeyBuYW1lOiBcIkh1YnRlbFwiLCBjYXRlZ29yeTogXCJGaW50ZWNoICYgRGVsaXZlcnlcIiwgZG9tYWluOiBcImh1YnRlbC5jb21cIiwgZGVzY3JpcHRpb246IFwiR2hhbmFpYW4gZXZlcnlkYXkgcGF5bWVudCwgbWVzc2FnaW5nLCBhbmQgcXVpY2stY29tbWVyY2Ugc3VwZXItYXBwLlwiIH0sXG4gICAgeyBuYW1lOiBcIkthc2FwcmVrb1wiLCBjYXRlZ29yeTogXCJCZXZlcmFnZXMgJiBGTUNHXCIsIGRvbWFpbjogXCJrYXNhcHJla29naC5jb21cIiwgZGVzY3JpcHRpb246IFwiTGVhZGluZyBHaGFuYWlhbiBiZXZlcmFnZSBtYW51ZmFjdHVyZXIuXCIgfSxcbiAgICB7IG5hbWU6IFwiTWVsY29tXCIsIGNhdGVnb3J5OiBcIlJldGFpbCAmIERlcGFydG1lbnQgU3RvcmVzXCIsIGRvbWFpbjogXCJtZWxjb20uY29tXCIsIGRlc2NyaXB0aW9uOiBcIkdoYW5hJ3MgbGFyZ2VzdCBjaGFpbiBvZiByZXRhaWwgZGVwYXJ0bWVudCBzdG9yZXMuXCIgfSxcbiAgXSxcbiAgRUc6IFtcbiAgICB7IG5hbWU6IFwiRmF3cnlcIiwgY2F0ZWdvcnk6IFwiRmludGVjaCAmIEUtUGF5bWVudHNcIiwgZG9tYWluOiBcImZhd3J5LmNvbVwiLCBkZXNjcmlwdGlvbjogXCJFZ3lwdCdzIHByZW1pZXIgZGlnaXRhbCB0cmFuc2Zvcm1hdGlvbiBhbmQgZWxlY3Ryb25pYyBwYXltZW50cyBuZXR3b3JrLlwiIH0sXG4gICAgeyBuYW1lOiBcIkNvbW1lcmNpYWwgSW50ZXJuYXRpb25hbCBCYW5rIChDSUIpXCIsIGNhdGVnb3J5OiBcIkJhbmtpbmcgJiBGaW5hbmNlXCIsIGRvbWFpbjogXCJjaWJlZy5jb21cIiwgZGVzY3JpcHRpb246IFwiRWd5cHQncyBsZWFkaW5nIHByaXZhdGUtc2VjdG9yIGJhbmsuXCIgfSxcbiAgICB7IG5hbWU6IFwiRWd5cHRBaXJcIiwgY2F0ZWdvcnk6IFwiQWlybGluZXMgJiBUcmF2ZWxcIiwgZG9tYWluOiBcImVneXB0YWlyLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJTdGF0ZS1vd25lZCBmbGFnIGNhcnJpZXIgYWlybGluZSBvZiBFZ3lwdC5cIiB9LFxuICAgIHsgbmFtZTogXCJWb2RhZm9uZSBFZ3lwdFwiLCBjYXRlZ29yeTogXCJUZWxlY29tc1wiLCBkb21haW46IFwidm9kYWZvbmUuY29tLmVnXCIsIGRlc2NyaXB0aW9uOiBcIkxhcmdlc3QgbW9iaWxlIG5ldHdvcmsgb3BlcmF0b3IgYW5kIFZvZGFmb25lIENhc2ggcHJvdmlkZXIgaW4gRWd5cHQuXCIgfSxcbiAgICB7IG5hbWU6IFwiU3d2bFwiLCBjYXRlZ29yeTogXCJNb2JpbGl0eSAmIFRyYW5zaXRcIiwgZG9tYWluOiBcInN3dmwuY29tXCIsIGRlc2NyaXB0aW9uOiBcIlRlY2gtZW5hYmxlZCBtYXNzIHRyYW5zaXQgYW5kIHNoYXJlZCBtb2JpbGl0eSBwbGF0Zm9ybSBib3JuIGluIENhaXJvLlwiIH0sXG4gICAgeyBuYW1lOiBcIkJyZWFkZmFzdFwiLCBjYXRlZ29yeTogXCJRdWljayBDb21tZXJjZVwiLCBkb21haW46IFwiYnJlYWRmYXN0LmNvbVwiLCBkZXNjcmlwdGlvbjogXCJPbi1kZW1hbmQgZ3JvY2VyaWVzLCBiYWtlcnksIGFuZCBob3VzZWhvbGQgZXNzZW50aWFscyBkZWxpdmVyeSBpbiBFZ3lwdC5cIiB9LFxuICBdLFxuICBNQTogW1xuICAgIHsgbmFtZTogXCJSb3lhbCBBaXIgTWFyb2NcIiwgY2F0ZWdvcnk6IFwiQWlybGluZXMgJiBUcmF2ZWxcIiwgZG9tYWluOiBcInJveWFsYWlybWFyb2MuY29tXCIsIGRlc2NyaXB0aW9uOiBcIk5hdGlvbmFsIGNhcnJpZXIgYWlybGluZSBvZiBNb3JvY2NvIGNvbm5lY3RpbmcgQWZyaWNhIHRvIHRoZSB3b3JsZC5cIiB9LFxuICAgIHsgbmFtZTogXCJBdHRpamFyaXdhZmEgQmFua1wiLCBjYXRlZ29yeTogXCJCYW5raW5nICYgRmluYW5jZVwiLCBkb21haW46IFwiYXR0aWphcml3YWZhYmFuay5jb21cIiwgZGVzY3JpcHRpb246IFwiTGVhZGluZyBiYW5raW5nIGFuZCBmaW5hbmNpYWwgZ3JvdXAgaW4gTm9ydGggYW5kIFdlc3QgQWZyaWNhLlwiIH0sXG4gICAgeyBuYW1lOiBcIk1hcm9jIFRlbGVjb21cIiwgY2F0ZWdvcnk6IFwiVGVsZWNvbXNcIiwgZG9tYWluOiBcImlhbS5tYVwiLCBkZXNjcmlwdGlvbjogXCJNYWluIHRlbGVjb21tdW5pY2F0aW9ucyBjb21wYW55IGluIE1vcm9jY28uXCIgfSxcbiAgICB7IG5hbWU6IFwiT0NQIEdyb3VwXCIsIGNhdGVnb3J5OiBcIkluZHVzdHJ5ICYgQWdyaWN1bHR1cmVcIiwgZG9tYWluOiBcIm9jcGdyb3VwLm1hXCIsIGRlc2NyaXB0aW9uOiBcIkdsb2JhbCBsZWFkZXIgaW4gcGxhbnQgbnV0cml0aW9uIGFuZCBwaG9zcGhhdGUtYmFzZWQgZmVydGlsaXplcnMuXCIgfSxcbiAgICB7IG5hbWU6IFwiTWFyamFuZVwiLCBjYXRlZ29yeTogXCJHcm9jZXJpZXMgJiBIeXBlcm1hcmtldHNcIiwgZG9tYWluOiBcIm1hcmphbmUubWFcIiwgZGVzY3JpcHRpb246IFwiTW9yb2NjbydzIGxlYWRpbmcgaHlwZXJtYXJrZXQgYW5kIHJldGFpbCBjaGFpbi5cIiB9LFxuICBdLFxuICBFVDogW1xuICAgIHsgbmFtZTogXCJFdGhpb3BpYW4gQWlybGluZXNcIiwgY2F0ZWdvcnk6IFwiQWlybGluZXMgJiBUcmF2ZWxcIiwgZG9tYWluOiBcImV0aGlvcGlhbmFpcmxpbmVzLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJBZnJpY2EncyBsYXJnZXN0IGFpcmxpbmUgYnkgcGFzc2VuZ2VycywgZGVzdGluYXRpb25zLCBhbmQgZmxlZXQgc2l6ZS5cIiB9LFxuICAgIHsgbmFtZTogXCJFdGhpbyBUZWxlY29tIChUZWxlYmlycilcIiwgY2F0ZWdvcnk6IFwiVGVsZWNvbXMgJiBGaW50ZWNoXCIsIGRvbWFpbjogXCJldGhpb3RlbGVjb20uZXRcIiwgZGVzY3JpcHRpb246IFwiTmF0aW9uYWwgdGVsZWNvbW11bmljYXRpb25zIGFuZCBUZWxlYmlyciBtb2JpbGUgbW9uZXkgcHJvdmlkZXIuXCIgfSxcbiAgICB7IG5hbWU6IFwiQ29tbWVyY2lhbCBCYW5rIG9mIEV0aGlvcGlhXCIsIGNhdGVnb3J5OiBcIkJhbmtpbmcgJiBGaW5hbmNlXCIsIGRvbWFpbjogXCJjb21iYW5rZXRoLmV0XCIsIGRlc2NyaXB0aW9uOiBcIkxhcmdlc3QgY29tbWVyY2lhbCBiYW5rIGluIEV0aGlvcGlhLlwiIH0sXG4gICAgeyBuYW1lOiBcIlNhZmFyaWNvbSBFdGhpb3BpYVwiLCBjYXRlZ29yeTogXCJUZWxlY29tc1wiLCBkb21haW46IFwic2FmYXJpY29tLmV0XCIsIGRlc2NyaXB0aW9uOiBcIkhpZ2gtc3BlZWQgNEcvNUcgdGVsZWNvbW11bmljYXRpb25zIGFuZCBNLVBlc2EgbmV0d29yayBpbiBFdGhpb3BpYS5cIiB9LFxuICBdLFxuICBTTjogW1xuICAgIHsgbmFtZTogXCJXYXZlIE1vYmlsZSBNb25leVwiLCBjYXRlZ29yeTogXCJGaW50ZWNoXCIsIGRvbWFpbjogXCJ3YXZlLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJVbHRyYS1sb3ctZmVlIG1vYmlsZSBtb25leSBwbGF0Zm9ybSBkb21pbmF0aW5nIFNlbmVnYWwgYW5kIEZyYW5jb3Bob25lIFdlc3QgQWZyaWNhLlwiIH0sXG4gICAgeyBuYW1lOiBcIlNvbmF0ZWwgKE9yYW5nZSBTw6luw6lnYWwpXCIsIGNhdGVnb3J5OiBcIlRlbGVjb21zXCIsIGRvbWFpbjogXCJzb25hdGVsLnNuXCIsIGRlc2NyaXB0aW9uOiBcIlNlbmVnYWwncyBwcmVtaWVyIHRlbGVjb21tdW5pY2F0aW9ucyBwcm92aWRlci5cIiB9LFxuICAgIHsgbmFtZTogXCJBaXIgU8OpbsOpZ2FsXCIsIGNhdGVnb3J5OiBcIkFpcmxpbmVzICYgVHJhdmVsXCIsIGRvbWFpbjogXCJmbHlhaXJzZW5lZ2FsLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJGbGFnIGNhcnJpZXIgYWlybGluZSBvZiB0aGUgUmVwdWJsaWMgb2YgU2VuZWdhbC5cIiB9LFxuICBdLFxuICBUWjogW1xuICAgIHsgbmFtZTogXCJDUkRCIEJhbmtcIiwgY2F0ZWdvcnk6IFwiQmFua2luZyAmIEZpbmFuY2VcIiwgZG9tYWluOiBcImNyZGJiYW5rLmNvLnR6XCIsIGRlc2NyaXB0aW9uOiBcIkxlYWRpbmcgY29tbWVyY2lhbCBiYW5rIGluIFRhbnphbmlhIGFuZCBFYXN0IEFmcmljYS5cIiB9LFxuICAgIHsgbmFtZTogXCJOTUIgQmFuayBUYW56YW5pYVwiLCBjYXRlZ29yeTogXCJCYW5raW5nICYgRmluYW5jZVwiLCBkb21haW46IFwibm1iYmFuay5jby50elwiLCBkZXNjcmlwdGlvbjogXCJNYWpvciByZXRhaWwgYW5kIGFncmljdWx0dXJhbCBiYW5rIGFjcm9zcyBUYW56YW5pYS5cIiB9LFxuICAgIHsgbmFtZTogXCJWb2RhY29tIFRhbnphbmlhXCIsIGNhdGVnb3J5OiBcIlRlbGVjb21zXCIsIGRvbWFpbjogXCJ2b2RhY29tLmNvLnR6XCIsIGRlc2NyaXB0aW9uOiBcIkxlYWRpbmcgd2lyZWxlc3MgdGVsZWNvbW11bmljYXRpb25zIGFuZCBNLVBlc2EgbmV0d29yayBpbiBUYW56YW5pYS5cIiB9LFxuICAgIHsgbmFtZTogXCJCYWtocmVzYSBHcm91cCAoQXphbSlcIiwgY2F0ZWdvcnk6IFwiRm9vZCwgTWVkaWEgJiBGTUNHXCIsIGRvbWFpbjogXCJiYWtocmVzYS5jb21cIiwgZGVzY3JpcHRpb246IFwiSWNvbmljIFRhbnphbmlhbiBjb25nbG9tZXJhdGUgYmVoaW5kIEF6YW0gRm9vZCwgYmV2ZXJhZ2VzLCBhbmQgQXphbSBUVi5cIiB9LFxuICBdLFxuICBCVzogW1xuICAgIHsgbmFtZTogXCJGaXJzdCBOYXRpb25hbCBCYW5rIEJvdHN3YW5hXCIsIGNhdGVnb3J5OiBcIkJhbmtpbmcgJiBGaW5hbmNlXCIsIGRvbWFpbjogXCJmbmJib3Rzd2FuYS5jby5id1wiLCBkZXNjcmlwdGlvbjogXCJMZWFkaW5nIGNvbW1lcmNpYWwgYW5kIGRpZ2l0YWwgYmFuayBpbiBCb3Rzd2FuYS5cIiB9LFxuICAgIHsgbmFtZTogXCJDaG9wcGllc1wiLCBjYXRlZ29yeTogXCJHcm9jZXJpZXMgJiBTdXBlcm1hcmtldHNcIiwgZG9tYWluOiBcImNob3BwaWVzLmNvLmJ3XCIsIGRlc2NyaXB0aW9uOiBcIkJvdHN3YW5hLWJvcm4gbXVsdGluYXRpb25hbCBncm9jZXJ5IGFuZCBzdXBlcm1hcmtldCByZXRhaWxlci5cIiB9LFxuICAgIHsgbmFtZTogXCJNYXNjb20gV2lyZWxlc3NcIiwgY2F0ZWdvcnk6IFwiVGVsZWNvbXNcIiwgZG9tYWluOiBcIm1hc2NvbS5id1wiLCBkZXNjcmlwdGlvbjogXCJCb3Rzd2FuYSdzIHByZW1pZXIgbW9iaWxlIHRlbGVjb21tdW5pY2F0aW9ucyBwcm92aWRlci5cIiB9LFxuICAgIHsgbmFtZTogXCJBaXIgQm90c3dhbmFcIiwgY2F0ZWdvcnk6IFwiQWlybGluZXMgJiBUcmF2ZWxcIiwgZG9tYWluOiBcImFpcmJvdHN3YW5hLmNvLmJ3XCIsIGRlc2NyaXB0aW9uOiBcIk5hdGlvbmFsIGZsYWcgY2FycmllciBhaXJsaW5lIG9mIEJvdHN3YW5hLlwiIH0sXG4gIF0sXG4gIE5BOiBbXG4gICAgeyBuYW1lOiBcIkJhbmsgV2luZGhvZWtcIiwgY2F0ZWdvcnk6IFwiQmFua2luZyAmIEZpbmFuY2VcIiwgZG9tYWluOiBcImJhbmt3aW5kaG9lay5jb20ubmFcIiwgZGVzY3JpcHRpb246IFwiRmxhZ3NoaXAgaG9tZWdyb3duIGNvbW1lcmNpYWwgYmFuayBvZiBOYW1pYmlhLlwiIH0sXG4gICAgeyBuYW1lOiBcIk1UQyBOYW1pYmlhXCIsIGNhdGVnb3J5OiBcIlRlbGVjb21zXCIsIGRvbWFpbjogXCJtdGMuY29tLm5hXCIsIGRlc2NyaXB0aW9uOiBcIk1vYmlsZSBUZWxlY29tbXVuaWNhdGlvbnMgTGltaXRlZCDigJQgTmFtaWJpYSdzIGxlYWRpbmcgbmV0d29yay5cIiB9LFxuICAgIHsgbmFtZTogXCJOYW1pYmlhIEJyZXdlcmllc1wiLCBjYXRlZ29yeTogXCJCZXZlcmFnZXNcIiwgZG9tYWluOiBcIm5hbWJyZXcuY29tXCIsIGRlc2NyaXB0aW9uOiBcIlByb2R1Y2VycyBvZiBXaW5kaG9layBMYWdlciBhbmQgVGFmZWwgTGFnZXIuXCIgfSxcbiAgXSxcbiAgWlc6IFtcbiAgICB7IG5hbWU6IFwiRWNvbmV0IFdpcmVsZXNzIFppbWJhYndlXCIsIGNhdGVnb3J5OiBcIlRlbGVjb21zICYgRWNvQ2FzaFwiLCBkb21haW46IFwiZWNvbmV0LmNvLnp3XCIsIGRlc2NyaXB0aW9uOiBcIlppbWJhYndlJ3MgbGFyZ2VzdCB0ZWxlY29tbXVuaWNhdGlvbnMgYW5kIEVjb0Nhc2ggZmludGVjaCBwcm92aWRlci5cIiB9LFxuICAgIHsgbmFtZTogXCJEZWx0YSBDb3Jwb3JhdGlvblwiLCBjYXRlZ29yeTogXCJCZXZlcmFnZXMgJiBGTUNHXCIsIGRvbWFpbjogXCJkZWx0YS5jby56d1wiLCBkZXNjcmlwdGlvbjogXCJMZWFkaW5nIGJldmVyYWdlIG1hbnVmYWN0dXJlciBpbiBaaW1iYWJ3ZS5cIiB9LFxuICAgIHsgbmFtZTogXCJDQlogSG9sZGluZ3NcIiwgY2F0ZWdvcnk6IFwiQmFua2luZyAmIEZpbmFuY2VcIiwgZG9tYWluOiBcImNiei5jby56d1wiLCBkZXNjcmlwdGlvbjogXCJGaW5hbmNpYWwgc2VydmljZXMgZ3JvdXAgYW5kIGNvbW1lcmNpYWwgYmFuayBpbiBaaW1iYWJ3ZS5cIiB9LFxuICAgIHsgbmFtZTogXCJJbm5zY29yIEFmcmljYSAoU2ltYmlzYSlcIiwgY2F0ZWdvcnk6IFwiRm9vZCAmIFJldGFpbFwiLCBkb21haW46IFwic2ltYmlzYWJyYW5kcy5jb21cIiwgZGVzY3JpcHRpb246IFwiRmFzdC1mb29kIGFuZCBjb25zdW1lciBzdGFwbGVzIGxlYWRlciBiZWhpbmQgQ2hpY2tlbiBJbm4gYW5kIFBpenphIElubi5cIiB9LFxuICBdLFxuICBMUzogW1xuICAgIHsgbmFtZTogXCJWb2RhY29tIExlc290aG9cIiwgY2F0ZWdvcnk6IFwiVGVsZWNvbXMgJiBNLVBlc2FcIiwgZG9tYWluOiBcInZvZGFjb20uY28ubHNcIiwgZGVzY3JpcHRpb246IFwiTGVhZGluZyB0ZWxlY29tbXVuaWNhdGlvbnMgYW5kIE0tUGVzYSBwcm92aWRlciBpbiBMZXNvdGhvLlwiIH0sXG4gICAgeyBuYW1lOiBcIkVjb25ldCBUZWxlY29tIExlc290aG9cIiwgY2F0ZWdvcnk6IFwiVGVsZWNvbXNcIiwgZG9tYWluOiBcImV0bC5jby5sc1wiLCBkZXNjcmlwdGlvbjogXCJJbnRlZ3JhdGVkIHRlbGVjb21tdW5pY2F0aW9ucyBvcGVyYXRvciBpbiB0aGUgS2luZ2RvbSBvZiBMZXNvdGhvLlwiIH0sXG4gICAgeyBuYW1lOiBcIlN0YW5kYXJkIExlc290aG8gQmFua1wiLCBjYXRlZ29yeTogXCJCYW5raW5nICYgRmluYW5jZVwiLCBkb21haW46IFwic3RhbmRhcmRsZXNvdGhvYmFuay5jby5sc1wiLCBkZXNjcmlwdGlvbjogXCJMYXJnZXN0IGNvbW1lcmNpYWwgYmFuayBpbiBMZXNvdGhvLlwiIH0sXG4gICAgeyBuYW1lOiBcIk1hbHV0aSBNb3VudGFpbiBCcmV3ZXJ5XCIsIGNhdGVnb3J5OiBcIkJldmVyYWdlc1wiLCBkb21haW46IFwiYWItaW5iZXYuY29tXCIsIGRlc2NyaXB0aW9uOiBcIkxlc290aG8ncyBmbGFnc2hpcCBiZXZlcmFnZSBwcm9kdWNlci5cIiB9LFxuICBdLFxuICBVUzogW1xuICAgIHsgbmFtZTogXCJBcHBsZVwiLCBjYXRlZ29yeTogXCJUZWNobm9sb2d5ICYgQ29uc3VtZXIgRWxlY3Ryb25pY3NcIiwgZG9tYWluOiBcImFwcGxlLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJNYWtlciBvZiBpUGhvbmUsIE1hYywgaVBhZCwgQXBwbGUgV2F0Y2gsIGFuZCBjb25zdW1lciBzb2Z0d2FyZSBlY29zeXN0ZW1zLlwiIH0sXG4gICAgeyBuYW1lOiBcIkFtYXpvblwiLCBjYXRlZ29yeTogXCJFLUNvbW1lcmNlICYgQ2xvdWRcIiwgZG9tYWluOiBcImFtYXpvbi5jb21cIiwgZGVzY3JpcHRpb246IFwiR2xvYmFsIGUtY29tbWVyY2UgbWFya2V0cGxhY2UsIFByaW1lIGRlbGl2ZXJ5LCBhbmQgY2xvdWQgY29tcHV0aW5nIHBsYXRmb3JtLlwiIH0sXG4gICAgeyBuYW1lOiBcIk5pa2VcIiwgY2F0ZWdvcnk6IFwiQXBwYXJlbCAmIEZvb3R3ZWFyXCIsIGRvbWFpbjogXCJuaWtlLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJXb3JsZCdzIGxhcmdlc3Qgc3VwcGxpZXIgb2YgYXRobGV0aWMgc2hvZXMgYW5kIHNwb3J0cyBhcHBhcmVsLlwiIH0sXG4gICAgeyBuYW1lOiBcIk5ldGZsaXhcIiwgY2F0ZWdvcnk6IFwiU3RyZWFtaW5nICYgRW50ZXJ0YWlubWVudFwiLCBkb21haW46IFwibmV0ZmxpeC5jb21cIiwgZGVzY3JpcHRpb246IFwiR2xvYmFsIHN1YnNjcmlwdGlvbiBzdHJlYW1pbmcgc2VydmljZSBhbmQgcHJvZHVjdGlvbiBjb21wYW55LlwiIH0sXG4gICAgeyBuYW1lOiBcIlN0YXJidWNrc1wiLCBjYXRlZ29yeTogXCJGb29kICYgQ29mZmVlXCIsIGRvbWFpbjogXCJzdGFyYnVja3MuY29tXCIsIGRlc2NyaXB0aW9uOiBcIk11bHRpbmF0aW9uYWwgY2hhaW4gb2YgY29mZmVlaG91c2VzIGFuZCByb2FzdGVyeSByZXNlcnZlcy5cIiB9LFxuICAgIHsgbmFtZTogXCJUZXNsYVwiLCBjYXRlZ29yeTogXCJBdXRvbW90aXZlICYgQ2xlYW4gRW5lcmd5XCIsIGRvbWFpbjogXCJ0ZXNsYS5jb21cIiwgZGVzY3JpcHRpb246IFwiRWxlY3RyaWMgdmVoaWNsZXMsIGJhdHRlcnkgZW5lcmd5IHN0b3JhZ2UsIGFuZCBTdXBlcmNoYXJnZXIgbmV0d29yay5cIiB9LFxuICAgIHsgbmFtZTogXCJNaWNyb3NvZnRcIiwgY2F0ZWdvcnk6IFwiVGVjaG5vbG9neSAmIFNvZnR3YXJlXCIsIGRvbWFpbjogXCJtaWNyb3NvZnQuY29tXCIsIGRlc2NyaXB0aW9uOiBcIkdsb2JhbCBzb2Z0d2FyZSwgV2luZG93cywgWGJveCwgYW5kIEF6dXJlIGNsb3VkIGxlYWRlci5cIiB9LFxuICAgIHsgbmFtZTogXCJEZWx0YSBBaXIgTGluZXNcIiwgY2F0ZWdvcnk6IFwiQWlybGluZXMgJiBUcmF2ZWxcIiwgZG9tYWluOiBcImRlbHRhLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJNYWpvciBBbWVyaWNhbiBhaXJsaW5lIHNlcnZpbmcgZG9tZXN0aWMgYW5kIGludGVybmF0aW9uYWwgdHJhdmVsbGVycy5cIiB9LFxuICAgIHsgbmFtZTogXCJDb3N0Y28gV2hvbGVzYWxlXCIsIGNhdGVnb3J5OiBcIlJldGFpbCAmIFdhcmVob3VzZVwiLCBkb21haW46IFwiY29zdGNvLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJNZW1iZXJzaGlwLW9ubHkgYmlnLWJveCB3YXJlaG91c2UgY2x1YiByZXRhaWwgY2hhaW4uXCIgfSxcbiAgICB7IG5hbWU6IFwiSlBNb3JnYW4gQ2hhc2VcIiwgY2F0ZWdvcnk6IFwiQmFua2luZyAmIEZpbmFuY2VcIiwgZG9tYWluOiBcImNoYXNlLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJMYXJnZXN0IGNvbnN1bWVyIGFuZCBjb21tZXJjaWFsIGJhbmsgaW4gdGhlIFVuaXRlZCBTdGF0ZXMuXCIgfSxcbiAgXSxcbiAgR0I6IFtcbiAgICB7IG5hbWU6IFwiUmV2b2x1dFwiLCBjYXRlZ29yeTogXCJGaW50ZWNoICYgRGlnaXRhbCBCYW5raW5nXCIsIGRvbWFpbjogXCJyZXZvbHV0LmNvbVwiLCBkZXNjcmlwdGlvbjogXCJHbG9iYWwgZmluYW5jaWFsIHN1cGVyLWFwcCBhbmQgZGlnaXRhbCBiYW5rIGhlYWRxdWFydGVyZWQgaW4gTG9uZG9uLlwiIH0sXG4gICAgeyBuYW1lOiBcIk1vbnpvXCIsIGNhdGVnb3J5OiBcIkRpZ2l0YWwgQmFua2luZ1wiLCBkb21haW46IFwibW9uem8uY29tXCIsIGRlc2NyaXB0aW9uOiBcIkFwcC1iYXNlZCBVSyByZXRhaWwgYmFuayBjaGVyaXNoZWQgZm9yIHJlYWwtdGltZSBzcGVuZGluZyBpbnNpZ2h0cy5cIiB9LFxuICAgIHsgbmFtZTogXCJNYXJrcyAmIFNwZW5jZXIgKE0mUylcIiwgY2F0ZWdvcnk6IFwiUmV0YWlsICYgR3JvY2VyaWVzXCIsIGRvbWFpbjogXCJtYXJrc2FuZHNwZW5jZXIuY29tXCIsIGRlc2NyaXB0aW9uOiBcIkljb25pYyBCcml0aXNoIHJldGFpbGVyIG9mIGZvb2QsIGNsb3RoaW5nLCBhbmQgaG9tZSBwcm9kdWN0cy5cIiB9LFxuICAgIHsgbmFtZTogXCJUZXNjb1wiLCBjYXRlZ29yeTogXCJHcm9jZXJpZXMgJiBTdXBlcm1hcmtldHNcIiwgZG9tYWluOiBcInRlc2NvLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJUaGUgVUsncyBsYXJnZXN0IHN1cGVybWFya2V0IGFuZCBncm9jZXJ5IHJldGFpbCBjaGFpbi5cIiB9LFxuICAgIHsgbmFtZTogXCJCcml0aXNoIEFpcndheXNcIiwgY2F0ZWdvcnk6IFwiQWlybGluZXMgJiBUcmF2ZWxcIiwgZG9tYWluOiBcImJyaXRpc2hhaXJ3YXlzLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJGbGFnIGNhcnJpZXIgYWlybGluZSBvZiB0aGUgVW5pdGVkIEtpbmdkb20uXCIgfSxcbiAgICB7IG5hbWU6IFwiRHlzb25cIiwgY2F0ZWdvcnk6IFwiQ29uc3VtZXIgQXBwbGlhbmNlc1wiLCBkb21haW46IFwiZHlzb24uY28udWtcIiwgZGVzY3JpcHRpb246IFwiQnJpdGlzaCBlbmdpbmVlcmluZyBicmFuZCBkZXNpZ25pbmcgdmFjdXVtIGNsZWFuZXJzLCBhaXIgcHVyaWZpZXJzLCBhbmQgaGFpciBjYXJlLlwiIH0sXG4gICAgeyBuYW1lOiBcIk9jdG9wdXMgRW5lcmd5XCIsIGNhdGVnb3J5OiBcIkNsZWFuIEVuZXJneSAmIFV0aWxpdGllc1wiLCBkb21haW46IFwib2N0b3B1cy5lbmVyZ3lcIiwgZGVzY3JpcHRpb246IFwiQ3VzdG9tZXItYWNjbGFpbWVkIHJlbmV3YWJsZSBlbmVyZ3kgc3VwcGxpZXIgaGVhZHF1YXJ0ZXJlZCBpbiB0aGUgVUsuXCIgfSxcbiAgXSxcbiAgRlI6IFtcbiAgICB7IG5hbWU6IFwiTG91aXMgVnVpdHRvblwiLCBjYXRlZ29yeTogXCJMdXh1cnkgRmFzaGlvblwiLCBkb21haW46IFwibG91aXN2dWl0dG9uLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJGcmVuY2ggbHV4dXJ5IGZhc2hpb24gaG91c2UgYW5kIGZsYWdzaGlwIG1haXNvbiBvZiBMVk1ILlwiIH0sXG4gICAgeyBuYW1lOiBcIkwnT3LDqWFsXCIsIGNhdGVnb3J5OiBcIkJlYXV0eSAmIENvc21ldGljc1wiLCBkb21haW46IFwibG9yZWFsLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJXb3JsZCdzIGxhcmdlc3QgY29zbWV0aWNzLCBza2luY2FyZSwgYW5kIGJlYXV0eSBjb21wYW55LlwiIH0sXG4gICAgeyBuYW1lOiBcIkNhcnJlZm91clwiLCBjYXRlZ29yeTogXCJHcm9jZXJpZXMgJiBIeXBlcm1hcmtldHNcIiwgZG9tYWluOiBcImNhcnJlZm91ci5mclwiLCBkZXNjcmlwdGlvbjogXCJGcmVuY2ggbXVsdGluYXRpb25hbCByZXRhaWwgYW5kIGh5cGVybWFya2V0IGNvcnBvcmF0aW9uLlwiIH0sXG4gICAgeyBuYW1lOiBcIkFpciBGcmFuY2VcIiwgY2F0ZWdvcnk6IFwiQWlybGluZXMgJiBUcmF2ZWxcIiwgZG9tYWluOiBcImFpcmZyYW5jZS5jb21cIiwgZGVzY3JpcHRpb246IFwiRmxhZyBjYXJyaWVyIGFpcmxpbmUgb2YgRnJhbmNlLlwiIH0sXG4gICAgeyBuYW1lOiBcIkRlY2F0aGxvblwiLCBjYXRlZ29yeTogXCJTcG9ydHMgJiBPdXRkb29yIFJldGFpbFwiLCBkb21haW46IFwiZGVjYXRobG9uLmZyXCIsIGRlc2NyaXB0aW9uOiBcIldvcmxkJ3MgbGFyZ2VzdCBzcG9ydGluZyBnb29kcyByZXRhaWxlciwgZm91bmRlZCBpbiBGcmFuY2UuXCIgfSxcbiAgICB7IG5hbWU6IFwiRGFub25lXCIsIGNhdGVnb3J5OiBcIkZvb2QgJiBCZXZlcmFnZXNcIiwgZG9tYWluOiBcImRhbm9uZS5jb21cIiwgZGVzY3JpcHRpb246IFwiR2xvYmFsIGRhaXJ5LCBwbGFudC1iYXNlZCBudXRyaXRpb24sIGFuZCBib3R0bGVkIHdhdGVyIGNvbXBhbnkuXCIgfSxcbiAgXSxcbiAgREU6IFtcbiAgICB7IG5hbWU6IFwiQWRpZGFzXCIsIGNhdGVnb3J5OiBcIkFwcGFyZWwgJiBTcG9ydHN3ZWFyXCIsIGRvbWFpbjogXCJhZGlkYXMuY29tXCIsIGRlc2NyaXB0aW9uOiBcIkdlcm1hbiBhdGhsZXRpYyBmb290d2VhciBhbmQgc3BvcnRzd2VhciBnaWFudC5cIiB9LFxuICAgIHsgbmFtZTogXCJCTVdcIiwgY2F0ZWdvcnk6IFwiQXV0b21vdGl2ZVwiLCBkb21haW46IFwiYm13LmNvbVwiLCBkZXNjcmlwdGlvbjogXCJCYXllcmlzY2hlIE1vdG9yZW4gV2Vya2Ug4oCUIGx1eHVyeSB2ZWhpY2xlcyBhbmQgbW90b3JjeWNsZXMuXCIgfSxcbiAgICB7IG5hbWU6IFwiTWVyY2VkZXMtQmVuelwiLCBjYXRlZ29yeTogXCJBdXRvbW90aXZlXCIsIGRvbWFpbjogXCJtZXJjZWRlcy1iZW56LmNvbVwiLCBkZXNjcmlwdGlvbjogXCJHZXJtYW4gbHV4dXJ5IGFuZCBjb21tZXJjaWFsIHZlaGljbGUgYXV0b21vdGl2ZSBtYXJxdWUuXCIgfSxcbiAgICB7IG5hbWU6IFwiTGlkbFwiLCBjYXRlZ29yeTogXCJHcm9jZXJpZXMgJiBTdXBlcm1hcmtldHNcIiwgZG9tYWluOiBcImxpZGwuZGVcIiwgZGVzY3JpcHRpb246IFwiSW50ZXJuYXRpb25hbCBkaXNjb3VudCByZXRhaWxlciBvcGVyYXRpbmcgb3ZlciAxMiwwMDAgc3RvcmVzLlwiIH0sXG4gICAgeyBuYW1lOiBcIk4yNlwiLCBjYXRlZ29yeTogXCJEaWdpdGFsIEJhbmtpbmdcIiwgZG9tYWluOiBcIm4yNi5jb21cIiwgZGVzY3JpcHRpb246IFwiQmVybGluLWJhc2VkIHBhbi1FdXJvcGVhbiBtb2JpbGUgYmFuay5cIiB9LFxuICAgIHsgbmFtZTogXCJMdWZ0aGFuc2FcIiwgY2F0ZWdvcnk6IFwiQWlybGluZXMgJiBUcmF2ZWxcIiwgZG9tYWluOiBcImx1ZnRoYW5zYS5jb21cIiwgZGVzY3JpcHRpb246IFwiRmxhZyBjYXJyaWVyIGFuZCBsYXJnZXN0IGFpcmxpbmUgb2YgR2VybWFueS5cIiB9LFxuICBdLFxuICBFUzogW1xuICAgIHsgbmFtZTogXCJaYXJhIChJbmRpdGV4KVwiLCBjYXRlZ29yeTogXCJGYXNoaW9uICYgQXBwYXJlbFwiLCBkb21haW46IFwiemFyYS5jb21cIiwgZGVzY3JpcHRpb246IFwiU3BhbmlzaCBmYXN0LWZhc2hpb24gcmV0YWlsIGZsYWdzaGlwIG9mIHRoZSBJbmRpdGV4IEdyb3VwLlwiIH0sXG4gICAgeyBuYW1lOiBcIk1lcmNhZG9uYVwiLCBjYXRlZ29yeTogXCJHcm9jZXJpZXMgJiBTdXBlcm1hcmtldHNcIiwgZG9tYWluOiBcIm1lcmNhZG9uYS5lc1wiLCBkZXNjcmlwdGlvbjogXCJTcGFpbidzIGxlYWRpbmcgcGh5c2ljYWwgYW5kIG9ubGluZSBzdXBlcm1hcmtldCBjaGFpbi5cIiB9LFxuICAgIHsgbmFtZTogXCJCYW5jbyBTYW50YW5kZXJcIiwgY2F0ZWdvcnk6IFwiQmFua2luZyAmIEZpbmFuY2VcIiwgZG9tYWluOiBcInNhbnRhbmRlci5jb21cIiwgZGVzY3JpcHRpb246IFwiU3BhbmlzaCBtdWx0aW5hdGlvbmFsIGZpbmFuY2lhbCBzZXJ2aWNlcyBncm91cC5cIiB9LFxuICAgIHsgbmFtZTogXCJJYmVyaWFcIiwgY2F0ZWdvcnk6IFwiQWlybGluZXMgJiBUcmF2ZWxcIiwgZG9tYWluOiBcImliZXJpYS5jb21cIiwgZGVzY3JpcHRpb246IFwiRmxhZyBjYXJyaWVyIGFpcmxpbmUgb2YgU3BhaW4gYmFzZWQgaW4gTWFkcmlkLlwiIH0sXG4gICAgeyBuYW1lOiBcIkNhYmlmeVwiLCBjYXRlZ29yeTogXCJSaWRlLUhhaWxpbmcgJiBNb2JpbGl0eVwiLCBkb21haW46IFwiY2FiaWZ5LmNvbVwiLCBkZXNjcmlwdGlvbjogXCJTcGFuaXNoIHJpZGUtc2hhcmluZyBhbmQgdXJiYW4gbW9iaWxpdHkgcGxhdGZvcm0uXCIgfSxcbiAgXSxcbiAgUFQ6IFtcbiAgICB7IG5hbWU6IFwiVEFQIEFpciBQb3J0dWdhbFwiLCBjYXRlZ29yeTogXCJBaXJsaW5lcyAmIFRyYXZlbFwiLCBkb21haW46IFwiZmx5dGFwLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJTdGF0ZS1vd25lZCBmbGFnIGNhcnJpZXIgYWlybGluZSBvZiBQb3J0dWdhbC5cIiB9LFxuICAgIHsgbmFtZTogXCJDb250aW5lbnRlIChTb25hZSlcIiwgY2F0ZWdvcnk6IFwiR3JvY2VyaWVzICYgU3VwZXJtYXJrZXRzXCIsIGRvbWFpbjogXCJjb250aW5lbnRlLnB0XCIsIGRlc2NyaXB0aW9uOiBcIlBvcnR1Z2FsJ3MgbGFyZ2VzdCBoeXBlcm1hcmtldCBhbmQgc3VwZXJtYXJrZXQgY2hhaW4uXCIgfSxcbiAgICB7IG5hbWU6IFwiR2FscCBFbmVyZ2lhXCIsIGNhdGVnb3J5OiBcIkVuZXJneSAmIEZ1ZWxcIiwgZG9tYWluOiBcImdhbHAuY29tXCIsIGRlc2NyaXB0aW9uOiBcIlBvcnR1Z3Vlc2UgbXVsdGluYXRpb25hbCBlbmVyZ3kgY29ycG9yYXRpb24uXCIgfSxcbiAgICB7IG5hbWU6IFwiTWlsbGVubml1bSBiY3BcIiwgY2F0ZWdvcnk6IFwiQmFua2luZyAmIEZpbmFuY2VcIiwgZG9tYWluOiBcIm1pbGxlbm5pdW1iY3AucHRcIiwgZGVzY3JpcHRpb246IFwiTGFyZ2VzdCBwcml2YXRlIGJhbmsgaW4gUG9ydHVnYWwuXCIgfSxcbiAgXSxcbiAgQlI6IFtcbiAgICB7IG5hbWU6IFwiTnViYW5rXCIsIGNhdGVnb3J5OiBcIkRpZ2l0YWwgQmFua2luZyAmIEZpbnRlY2hcIiwgZG9tYWluOiBcIm51YmFuay5jb20uYnJcIiwgZGVzY3JpcHRpb246IFwiTGF0aW4gQW1lcmljYSdzIGxhcmdlc3QgZmludGVjaCBiYW5rIHNlcnZpbmcgb3ZlciAxMDAgbWlsbGlvbiBjdXN0b21lcnMuXCIgfSxcbiAgICB7IG5hbWU6IFwiTWVyY2FkbyBMaXZyZVwiLCBjYXRlZ29yeTogXCJFLUNvbW1lcmNlICYgRmludGVjaFwiLCBkb21haW46IFwibWVyY2Fkb2xpdnJlLmNvbS5iclwiLCBkZXNjcmlwdGlvbjogXCJMZWFkaW5nIGUtY29tbWVyY2UgYW5kIE1lcmNhZG8gUGFnbyBlY29zeXN0ZW0gaW4gQnJhemlsLlwiIH0sXG4gICAgeyBuYW1lOiBcImlGb29kXCIsIGNhdGVnb3J5OiBcIkZvb2QgJiBHcm9jZXJ5IERlbGl2ZXJ5XCIsIGRvbWFpbjogXCJpZm9vZC5jb20uYnJcIiwgZGVzY3JpcHRpb246IFwiQnJhemlsJ3MgZG9taW5hbnQgb25saW5lIGZvb2Qgb3JkZXJpbmcgYW5kIGRlbGl2ZXJ5IHBsYXRmb3JtLlwiIH0sXG4gICAgeyBuYW1lOiBcIk5hdHVyYSAmQ29cIiwgY2F0ZWdvcnk6IFwiQmVhdXR5ICYgUGVyc29uYWwgQ2FyZVwiLCBkb21haW46IFwibmF0dXJhLmNvbS5iclwiLCBkZXNjcmlwdGlvbjogXCJCcmF6aWxpYW4gc3VzdGFpbmFibGUgY29zbWV0aWNzIGFuZCBwZXJzb25hbCBjYXJlIHBvd2VyaG91c2UuXCIgfSxcbiAgICB7IG5hbWU6IFwiSXRhw7ogVW5pYmFuY29cIiwgY2F0ZWdvcnk6IFwiQmFua2luZyAmIEZpbmFuY2VcIiwgZG9tYWluOiBcIml0YXUuY29tLmJyXCIsIGRlc2NyaXB0aW9uOiBcIkxhcmdlc3QgYmFua2luZyBpbnN0aXR1dGlvbiBpbiBCcmF6aWwgYW5kIExhdGluIEFtZXJpY2EuXCIgfSxcbiAgXSxcbiAgSU46IFtcbiAgICB7IG5hbWU6IFwiVGF0YSBHcm91cFwiLCBjYXRlZ29yeTogXCJDb25nbG9tZXJhdGUgJiBSZXRhaWxcIiwgZG9tYWluOiBcInRhdGEuY29tXCIsIGRlc2NyaXB0aW9uOiBcIkluZGlhJ3MgbGFyZ2VzdCBjb25nbG9tZXJhdGUgc3Bhbm5pbmcgYXV0b21vdGl2ZSwgdGVjaCwgaG9zcGl0YWxpdHksIGFuZCByZXRhaWwuXCIgfSxcbiAgICB7IG5hbWU6IFwiUmVsaWFuY2UgSmlvXCIsIGNhdGVnb3J5OiBcIlRlbGVjb21zICYgRGlnaXRhbFwiLCBkb21haW46IFwiamlvLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJJbmRpYSdzIGxhcmdlc3QgbW9iaWxlIG5ldHdvcmsgb3BlcmF0b3IgYW5kIGRpZ2l0YWwgc2VydmljZXMgcGxhdGZvcm0uXCIgfSxcbiAgICB7IG5hbWU6IFwiWm9tYXRvXCIsIGNhdGVnb3J5OiBcIkZvb2QgRGVsaXZlcnkgJiBRdWljayBDb21tZXJjZVwiLCBkb21haW46IFwiem9tYXRvLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJJbmRpYW4gcmVzdGF1cmFudCBhZ2dyZWdhdG9yLCBmb29kIGRlbGl2ZXJ5LCBhbmQgQmxpbmtpdCBwYXJlbnQuXCIgfSxcbiAgICB7IG5hbWU6IFwiSERGQyBCYW5rXCIsIGNhdGVnb3J5OiBcIkJhbmtpbmcgJiBGaW5hbmNlXCIsIGRvbWFpbjogXCJoZGZjYmFuay5jb21cIiwgZGVzY3JpcHRpb246IFwiSW5kaWEncyBsYXJnZXN0IHByaXZhdGUgc2VjdG9yIGJhbmsuXCIgfSxcbiAgICB7IG5hbWU6IFwiSW5kaUdvXCIsIGNhdGVnb3J5OiBcIkFpcmxpbmVzICYgVHJhdmVsXCIsIGRvbWFpbjogXCJnb2luZGlnby5pblwiLCBkZXNjcmlwdGlvbjogXCJJbmRpYSdzIGxhcmdlc3QgcGFzc2VuZ2VyIGFpcmxpbmUgYnkgbWFya2V0IHNoYXJlLlwiIH0sXG4gIF0sXG4gIEpQOiBbXG4gICAgeyBuYW1lOiBcIlNvbnlcIiwgY2F0ZWdvcnk6IFwiQ29uc3VtZXIgRWxlY3Ryb25pY3MgJiBHYW1pbmdcIiwgZG9tYWluOiBcInNvbnkuY29tXCIsIGRlc2NyaXB0aW9uOiBcIkphcGFuZXNlIGVsZWN0cm9uaWNzLCBQbGF5U3RhdGlvbiBnYW1pbmcsIGFuZCBlbnRlcnRhaW5tZW50IGdpYW50LlwiIH0sXG4gICAgeyBuYW1lOiBcIlRveW90YVwiLCBjYXRlZ29yeTogXCJBdXRvbW90aXZlXCIsIGRvbWFpbjogXCJ0b3lvdGEuY29tXCIsIGRlc2NyaXB0aW9uOiBcIldvcmxkJ3MgbGFyZ2VzdCBhdXRvbW90aXZlIG1hbnVmYWN0dXJlciByZW5vd25lZCBmb3IgcmVsaWFiaWxpdHkuXCIgfSxcbiAgICB7IG5hbWU6IFwiVW5pcWxvIChGYXN0IFJldGFpbGluZylcIiwgY2F0ZWdvcnk6IFwiRmFzaGlvbiAmIEFwcGFyZWxcIiwgZG9tYWluOiBcInVuaXFsby5jb21cIiwgZGVzY3JpcHRpb246IFwiSmFwYW5lc2UgY2FzdWFsIHdlYXIgZGVzaWduZXIsIG1hbnVmYWN0dXJlciwgYW5kIGdsb2JhbCByZXRhaWxlci5cIiB9LFxuICAgIHsgbmFtZTogXCJOaW50ZW5kb1wiLCBjYXRlZ29yeTogXCJHYW1pbmcgJiBFbnRlcnRhaW5tZW50XCIsIGRvbWFpbjogXCJuaW50ZW5kby5jb21cIiwgZGVzY3JpcHRpb246IFwiQ3JlYXRvciBvZiBTd2l0Y2gsIE1hcmlvLCBhbmQgWmVsZGEgaW50ZXJhY3RpdmUgZW50ZXJ0YWlubWVudC5cIiB9LFxuICBdLFxuICBLUjogW1xuICAgIHsgbmFtZTogXCJTYW1zdW5nIEVsZWN0cm9uaWNzXCIsIGNhdGVnb3J5OiBcIlRlY2hub2xvZ3kgJiBFbGVjdHJvbmljc1wiLCBkb21haW46IFwic2Ftc3VuZy5jb21cIiwgZGVzY3JpcHRpb246IFwiU291dGggS29yZWFuIGdsb2JhbCBsZWFkZXIgaW4gc21hcnRwaG9uZXMsIFRWcywgYW5kIHNlbWljb25kdWN0b3JzLlwiIH0sXG4gICAgeyBuYW1lOiBcIkh5dW5kYWkgTW90b3JcIiwgY2F0ZWdvcnk6IFwiQXV0b21vdGl2ZVwiLCBkb21haW46IFwiaHl1bmRhaS5jb21cIiwgZGVzY3JpcHRpb246IFwiR2xvYmFsIGF1dG9tYWtlciBwaW9uZWVyaW5nIGVsZWN0cmljIElPTklRIHZlaGljbGVzLlwiIH0sXG4gICAgeyBuYW1lOiBcIkNvdXBhbmdcIiwgY2F0ZWdvcnk6IFwiRS1Db21tZXJjZSAmIFJvY2tldCBEZWxpdmVyeVwiLCBkb21haW46IFwiY291cGFuZy5jb21cIiwgZGVzY3JpcHRpb246IFwiU291dGggS29yZWEncyBlLWNvbW1lcmNlIGxlYWRlciBmYW1vdXMgZm9yIGRhd24gUm9ja2V0IERlbGl2ZXJ5LlwiIH0sXG4gICAgeyBuYW1lOiBcIktha2FvXCIsIGNhdGVnb3J5OiBcIlRlY2hub2xvZ3kgJiBTdXBlci1BcHBcIiwgZG9tYWluOiBcImtha2FvY29ycC5jb21cIiwgZGVzY3JpcHRpb246IFwiT3BlcmF0b3Igb2YgS2FrYW9UYWxrLCBLYWthb1BheSwgYW5kIEtha2FvVCBtb2JpbGl0eS5cIiB9LFxuICBdLFxuICBBRTogW1xuICAgIHsgbmFtZTogXCJFbWlyYXRlc1wiLCBjYXRlZ29yeTogXCJBaXJsaW5lcyAmIEF2aWF0aW9uXCIsIGRvbWFpbjogXCJlbWlyYXRlcy5jb21cIiwgZGVzY3JpcHRpb246IFwiR2xvYmFsIGZsYWcgY2FycmllciBhaXJsaW5lIGJhc2VkIGluIER1YmFpLlwiIH0sXG4gICAgeyBuYW1lOiBcIkNhcmVlbVwiLCBjYXRlZ29yeTogXCJTdXBlci1BcHAgJiBNb2JpbGl0eVwiLCBkb21haW46IFwiY2FyZWVtLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJNaWRkbGUgRWFzdCByaWRlLWhhaWxpbmcsIGZvb2QgZGVsaXZlcnksIGFuZCBkaWdpdGFsIHBheW1lbnRzIHN1cGVyLWFwcC5cIiB9LFxuICAgIHsgbmFtZTogXCJOb29uXCIsIGNhdGVnb3J5OiBcIkUtQ29tbWVyY2VcIiwgZG9tYWluOiBcIm5vb24uY29tXCIsIGRlc2NyaXB0aW9uOiBcIk1pZGRsZSBFYXN0IGhvbWVncm93biBvbmxpbmUgc2hvcHBpbmcgbWFya2V0cGxhY2UuXCIgfSxcbiAgICB7IG5hbWU6IFwiRXRpc2FsYXQgKGUmKVwiLCBjYXRlZ29yeTogXCJUZWxlY29tcyAmIFRlY2hub2xvZ3lcIiwgZG9tYWluOiBcImVhbmQuY29tXCIsIGRlc2NyaXB0aW9uOiBcIk11bHRpbmF0aW9uYWwgVUFFIHRlbGVjb21tdW5pY2F0aW9ucyBhbmQgdGVjaG5vbG9neSBncm91cC5cIiB9LFxuICBdLFxuICBBVTogW1xuICAgIHsgbmFtZTogXCJXb29sd29ydGhzIEF1c3RyYWxpYVwiLCBjYXRlZ29yeTogXCJHcm9jZXJpZXMgJiBTdXBlcm1hcmtldHNcIiwgZG9tYWluOiBcIndvb2x3b3J0aHMuY29tLmF1XCIsIGRlc2NyaXB0aW9uOiBcIkF1c3RyYWxpYSdzIGxhcmdlc3Qgc3VwZXJtYXJrZXQgY2hhaW4uXCIgfSxcbiAgICB7IG5hbWU6IFwiQ29tbW9ud2VhbHRoIEJhbmsgKENvbW1CYW5rKVwiLCBjYXRlZ29yeTogXCJCYW5raW5nICYgRmluYW5jZVwiLCBkb21haW46IFwiY29tbWJhbmsuY29tLmF1XCIsIGRlc2NyaXB0aW9uOiBcIkF1c3RyYWxpYSdzIGxlYWRpbmcgcmV0YWlsIGJhbmsgYW5kIGJhbmtpbmcgYXBwLlwiIH0sXG4gICAgeyBuYW1lOiBcIlFhbnRhc1wiLCBjYXRlZ29yeTogXCJBaXJsaW5lcyAmIFRyYXZlbFwiLCBkb21haW46IFwicWFudGFzLmNvbVwiLCBkZXNjcmlwdGlvbjogXCJGbGFnIGNhcnJpZXIgYWlybGluZSBvZiBBdXN0cmFsaWEuXCIgfSxcbiAgICB7IG5hbWU6IFwiQ2FudmFcIiwgY2F0ZWdvcnk6IFwiVGVjaG5vbG9neSAmIERlc2lnblwiLCBkb21haW46IFwiY2FudmEuY29tXCIsIGRlc2NyaXB0aW9uOiBcIkF1c3RyYWxpYW4tZm91bmRlZCBnbG9iYWwgdmlzdWFsIGNvbW11bmljYXRpb24gYW5kIGRlc2lnbiBwbGF0Zm9ybS5cIiB9LFxuICBdLFxufTtcblxuZnVuY3Rpb24gc2x1Z2lmeShuYW1lOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gbmFtZVxuICAgIC50b0xvd2VyQ2FzZSgpXG4gICAgLnRyaW0oKVxuICAgIC5yZXBsYWNlKC9bXmEtejAtOV0rL2csIFwiLVwiKVxuICAgIC5yZXBsYWNlKC9eLSt8LSskL2csIFwiXCIpXG4gICAgLnNsaWNlKDAsIDYwKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkQnJhbmRJbnZpdGF0aW9uKGlucHV0OiB7XG4gIG5hbWU6IHN0cmluZztcbiAgc2x1Zzogc3RyaW5nO1xuICB3ZWJzaXRlPzogc3RyaW5nIHwgbnVsbDtcbn0pIHtcbiAgY29uc3Qgb3JpZ2luID1cbiAgICB0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiXG4gICAgICA/IFwiaHR0cHM6Ly9zdGFzaG9ydHJhc2gudmVyY2VsLmFwcFwiXG4gICAgICA6IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW47XG4gIGNvbnN0IGJyYW5kVXJsID0gYCR7b3JpZ2lufS9icmFuZHMvJHtpbnB1dC5zbHVnfWA7XG4gIHJldHVybiBgU3ViamVjdDogJHtpbnB1dC5uYW1lfSBpcyBub3cgb24gU09UIOKAlCBTdGFzaCBPciBUcmFzaFxcblxcbkhlbGxvICR7aW5wdXQubmFtZX0gdGVhbSxcXG5cXG5XZSBoYXZlIG9wZW5lZCBhIGxpdmUgYnJhbmQtcmF0aW5nIHBhZ2UgZm9yICR7aW5wdXQubmFtZX0gb24gU09UIOKAlCBTdGFzaCBPciBUcmFzaCwgdGhlIENvbnN1bWVyIEJyYW5kIFJldm9sdXRpb24gYnVpbHQgdG8gdHVybiBldmVyeWRheSBjdXN0b21lciBmZWVkYmFjayBpbnRvIGEgY3JlZGlibGUgcmVwdXRhdGlvbiBzaWduYWwuXFxuXFxuWW91ciBwYWdlOiAke2JyYW5kVXJsfVxcbiR7aW5wdXQud2Vic2l0ZSA/IGBXZWJzaXRlIHdlIGZvdW5kOiAke2lucHV0LndlYnNpdGV9XFxuYCA6IFwiXCJ9XFxuQ29uc3VtZXJzIGNhbiBub3cgU3Rhc2ggb3IgVHJhc2ggYnJhbmQgZXhwZXJpZW5jZXMgaW4gcHVibGljLCBhbmQgdmVyaWZpZWQgYnJhbmQgb3duZXJzIGNhbiBjbGFpbSB0aGVpciBwYWdlLCBtb25pdG9yIHNlbnRpbWVudCwgYW5kIHJlc3BvbmQgZGlyZWN0bHkgdGhyb3VnaCB0aGUgcGxhdGZvcm0uXFxuXFxuUGxlYXNlIGNyZWF0ZSBhbiBhY2NvdW50IHdpdGggeW91ciBvZmZpY2lhbCBjb21wYW55IGVtYWlsLCBvcGVuIHRoZSBwYWdlIGFib3ZlLCBhbmQgY2hvb3NlIOKAnENsYWltIHRoaXMgYnJhbmTigJ0gc28gb3VyIHRlYW0gY2FuIHZlcmlmeSB5b3VyIG93bmVyc2hpcC5cXG5cXG5SZWdhcmRzLFxcblNPVCDigJQgU3Rhc2ggT3IgVHJhc2hcXG5UaGUgQnJhbmQgQmFyb21ldGVyYDtcbn1cblxuZnVuY3Rpb24gcmVhZExvY2FsQ2FuZGlkYXRlcygpOiBDYW5kaWRhdGVbXSB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gW107XG4gIHRyeSB7XG4gICAgY29uc3QgcmF3ID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKENBTkRJREFURVNfU1RPUkFHRV9LRVkpO1xuICAgIHJldHVybiByYXcgPyAoSlNPTi5wYXJzZShyYXcpIGFzIENhbmRpZGF0ZVtdKSA6IFtdO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gW107XG4gIH1cbn1cblxuZnVuY3Rpb24gd3JpdGVMb2NhbENhbmRpZGF0ZXMoaXRlbXM6IENhbmRpZGF0ZVtdKSB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm47XG4gIHRyeSB7XG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKENBTkRJREFURVNfU1RPUkFHRV9LRVksIEpTT04uc3RyaW5naWZ5KGl0ZW1zKSk7XG4gIH0gY2F0Y2gge1xuICAgIC8qIGlnbm9yZSAqL1xuICB9XG59XG5cbmV4cG9ydCB0eXBlIExvY2FsSW1wb3J0ZWRCcmFuZCA9IHtcbiAgaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBzbHVnOiBzdHJpbmc7XG4gIGNvdW50cnk6IHN0cmluZztcbiAgY2F0ZWdvcnk6IHN0cmluZyB8IG51bGw7XG4gIGRlc2NyaXB0aW9uOiBzdHJpbmcgfCBudWxsO1xuICB3ZWJzaXRlOiBzdHJpbmcgfCBudWxsO1xuICBsb2dvX3VybDogc3RyaW5nIHwgbnVsbDtcbiAgb3duZXJfaWQ6IHN0cmluZyB8IG51bGw7XG4gIHZlcmlmaWVkOiBib29sZWFuO1xuICB0cnVzdF9zY29yZTogbnVtYmVyO1xuICBjcmVhdGVkX2F0OiBzdHJpbmc7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gZ2V0TG9jYWxJbXBvcnRlZEJyYW5kcygpOiBMb2NhbEltcG9ydGVkQnJhbmRbXSB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gW107XG4gIHRyeSB7XG4gICAgY29uc3QgcmF3ID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKElNUE9SVEVEX0JSQU5EU19TVE9SQUdFX0tFWSk7XG4gICAgcmV0dXJuIHJhdyA/IChKU09OLnBhcnNlKHJhdykgYXMgTG9jYWxJbXBvcnRlZEJyYW5kW10pIDogW107XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBbXTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzYXZlTG9jYWxJbXBvcnRlZEJyYW5kcyhicmFuZHM6IExvY2FsSW1wb3J0ZWRCcmFuZFtdKSB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm47XG4gIHRyeSB7XG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKElNUE9SVEVEX0JSQU5EU19TVE9SQUdFX0tFWSwgSlNPTi5zdHJpbmdpZnkoYnJhbmRzKSk7XG4gIH0gY2F0Y2gge1xuICAgIC8qIGlnbm9yZSAqL1xuICB9XG59XG5cbi8qKlxuICogU2luZ2xlIGNvbnNvbGlkYXRlZCBTUEFSUUwgcXVlcnkgcGVyIGNvdW50cnkgc28gV2lraWRhdGEgbmV2ZXIgcmF0ZS1saW1pdHMgKDQyOSlcbiAqIG9yIHRpbWVzIG91dCBvbiAxMCBjb25jdXJyZW50IGNvbm5lY3Rpb25zLlxuICovXG5mdW5jdGlvbiBidWlsZEZhc3RDb3VudHJ5U3BhcnFsKHFpZDogc3RyaW5nLCBsaW1pdDogbnVtYmVyKTogc3RyaW5nIHtcbiAgY29uc3QgZmV0Y2hMaW1pdCA9IE1hdGgubWluKDI1MCwgTWF0aC5tYXgobGltaXQgKiAyLCA0MCkpO1xuICByZXR1cm4gYFxuICAgIFNFTEVDVCA/aXRlbSA/aXRlbUxhYmVsID9kZXNjID9sb2dvID93ZWJzaXRlID9pbmR1c3RyeUxhYmVsID9zaXRlbGlua3MgV0hFUkUge1xuICAgICAge1xuICAgICAgICBTRUxFQ1QgRElTVElOQ1QgP2l0ZW0gP3NpdGVsaW5rcyBXSEVSRSB7XG4gICAgICAgICAgVkFMVUVTID9jbHMgeyB3ZDpRNDgzMDQ1MyB3ZDpRODkxNzIzIHdkOlE0MzEyODkgd2Q6UTY4ODE1MTEgd2Q6UTc4Mzc5NCB9XG4gICAgICAgICAgP2l0ZW0gd2R0OlAzMSA/Y2xzIDtcbiAgICAgICAgICAgICAgICB3ZHQ6UDE3IHdkOiR7cWlkfSA7XG4gICAgICAgICAgICAgICAgd2lraWJhc2U6c2l0ZWxpbmtzID9zaXRlbGlua3MgLlxuICAgICAgICB9XG4gICAgICAgIE9SREVSIEJZIERFU0MoP3NpdGVsaW5rcylcbiAgICAgICAgTElNSVQgJHtmZXRjaExpbWl0fVxuICAgICAgfVxuICAgICAgT1BUSU9OQUwgeyA/aXRlbSB3ZHQ6UDE1NCA/bG9nbyB9XG4gICAgICBPUFRJT05BTCB7ID9pdGVtIHdkdDpQODU2ID93ZWJzaXRlIH1cbiAgICAgIE9QVElPTkFMIHsgP2l0ZW0gd2R0OlA0NTIgP2luZHVzdHJ5IC4gP2luZHVzdHJ5IHJkZnM6bGFiZWwgP2luZHVzdHJ5TGFiZWwgRklMVEVSKExBTkcoP2luZHVzdHJ5TGFiZWwpPVwiZW5cIikgfVxuICAgICAgT1BUSU9OQUwgeyA/aXRlbSBzY2hlbWE6ZGVzY3JpcHRpb24gP2Rlc2MgRklMVEVSKExBTkcoP2Rlc2MpPVwiZW5cIikgfVxuICAgICAgU0VSVklDRSB3aWtpYmFzZTpsYWJlbCB7IGJkOnNlcnZpY2VQYXJhbSB3aWtpYmFzZTpsYW5ndWFnZSBcImVuLGZyLGVzLHB0LGRlXCIgfVxuICAgIH1cbiAgICBPUkRFUiBCWSBERVNDKD9zaXRlbGlua3MpXG4gIGA7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJ1blNwYXJxbFF1ZXJ5KHF1ZXJ5OiBzdHJpbmcsIHRpbWVvdXRNcyA9IDg1MDApOiBQcm9taXNlPGFueVtdPiB7XG4gIGNvbnN0IHVybCA9IGAke1NQQVJRTF9FTkRQT0lOVH0/b3JpZ2luPSomZm9ybWF0PWpzb24mcXVlcnk9JHtlbmNvZGVVUklDb21wb25lbnQocXVlcnkpfWA7XG4gIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiBjb250cm9sbGVyLmFib3J0KCksIHRpbWVvdXRNcyk7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsLCB7XG4gICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBBY2NlcHQ6IFwiYXBwbGljYXRpb24vc3BhcnFsLXJlc3VsdHMranNvblwiLFxuICAgICAgfSxcbiAgICB9KTtcbiAgICBpZiAoIXJlcy5vaykgdGhyb3cgbmV3IEVycm9yKGBXaWtpZGF0YSBTUEFSUUwgcmV0dXJuZWQgJHtyZXMuc3RhdHVzfWApO1xuICAgIGNvbnN0IGpzb24gPSAoYXdhaXQgcmVzLmpzb24oKSkgYXMgeyByZXN1bHRzPzogeyBiaW5kaW5ncz86IGFueVtdIH0gfTtcbiAgICByZXR1cm4ganNvbi5yZXN1bHRzPy5iaW5kaW5ncyA/PyBbXTtcbiAgfSBmaW5hbGx5IHtcbiAgICBjbGVhclRpbWVvdXQodGltZXIpO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlc29sdmVDb3VudHJ5UWlkKGNvdW50cnlDb2RlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgY29uc3QgY29kZSA9IGNvdW50cnlDb2RlLnRvVXBwZXJDYXNlKCk7XG4gIGlmIChJU09fVE9fUUlEW2NvZGVdKSByZXR1cm4gSVNPX1RPX1FJRFtjb2RlXTtcbiAgdHJ5IHtcbiAgICBjb25zdCBiaW5kaW5ncyA9IGF3YWl0IHJ1blNwYXJxbFF1ZXJ5KFxuICAgICAgYFNFTEVDVCA/Y291bnRyeSBXSEVSRSB7ID9jb3VudHJ5IHdkdDpQMjk3IFwiJHtjb2RlfVwiLiB9IExJTUlUIDFgLFxuICAgICAgNTAwMCxcbiAgICApO1xuICAgIHJldHVybiBiaW5kaW5nc1swXT8uY291bnRyeT8udmFsdWU/LnNwbGl0KFwiL1wiKS5wb3AoKSA/PyBudWxsO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG4vKipcbiAqIEZhc3QgV2lraWRhdGEgQWN0aW9uIEFQSSArIFdpa2lwZWRpYSBzZWFyY2ggZmFsbGJhY2sgZm9yIGFueSBjb3VudHJ5IG9yIGtleXdvcmQuXG4gKiBSZXNwb25kcyBpbiA8MjUwbXMgYW5kIG5ldmVyIGhpdHMgU1BBUlFMIHRpbWVvdXRzLlxuICovXG5hc3luYyBmdW5jdGlvbiBzZWFyY2hXaWtpZGF0YUVudGl0aWVzRm9yQ291bnRyeShcbiAgY291bnRyeUNvZGU6IHN0cmluZyxcbiAgbGltaXQ6IG51bWJlcixcbiAgc2VhcmNoUXVlcnk/OiBzdHJpbmcsXG4pOiBQcm9taXNlPENhbmRpZGF0ZVtdPiB7XG4gIGNvbnN0IGNOYW1lID0gY291bnRyeU5hbWUoY291bnRyeUNvZGUpIHx8IGNvdW50cnlDb2RlO1xuICBjb25zdCBzZWFyY2hUZXJtcyA9IHNlYXJjaFF1ZXJ5Py50cmltKClcbiAgICA/IFtzZWFyY2hRdWVyeS50cmltKCksIGAke3NlYXJjaFF1ZXJ5LnRyaW0oKX0gJHtjTmFtZX1gXVxuICAgIDogW1xuICAgICAgICBgJHtjTmFtZX0gYmFua2AsXG4gICAgICAgIGAke2NOYW1lfSB0ZWxlY29tYCxcbiAgICAgICAgYCR7Y05hbWV9IGFpcmxpbmVgLFxuICAgICAgICBgJHtjTmFtZX0gc3VwZXJtYXJrZXRgLFxuICAgICAgICBgJHtjTmFtZX0gY29tcGFueWAsXG4gICAgICBdO1xuXG4gIGNvbnN0IHJlc3VsdHMgPSBuZXcgTWFwPHN0cmluZywgQ2FuZGlkYXRlPigpO1xuXG4gIGF3YWl0IFByb21pc2UuYWxsU2V0dGxlZChcbiAgICBzZWFyY2hUZXJtcy5tYXAoYXN5bmMgKHRlcm0pID0+IHtcbiAgICAgIGNvbnN0IHVybCA9IGAke1dJS0lEQVRBX0FQSX0/YWN0aW9uPXdic2VhcmNoZW50aXRpZXMmc2VhcmNoPSR7ZW5jb2RlVVJJQ29tcG9uZW50KFxuICAgICAgICB0ZXJtLFxuICAgICAgKX0mbGFuZ3VhZ2U9ZW4mbGltaXQ9MTImZm9ybWF0PWpzb24mb3JpZ2luPSpgO1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsKTtcbiAgICAgIGlmICghcmVzLm9rKSByZXR1cm47XG4gICAgICBjb25zdCBqc29uID0gKGF3YWl0IHJlcy5qc29uKCkpIGFzIHtcbiAgICAgICAgc2VhcmNoPzogQXJyYXk8e1xuICAgICAgICAgIGlkOiBzdHJpbmc7XG4gICAgICAgICAgbGFiZWw/OiBzdHJpbmc7XG4gICAgICAgICAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gICAgICAgIH0+O1xuICAgICAgfTtcbiAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBqc29uLnNlYXJjaCA/PyBbXSkge1xuICAgICAgICBjb25zdCBuYW1lID0gaXRlbS5sYWJlbD8udHJpbSgpID8/IFwiXCI7XG4gICAgICAgIGNvbnN0IGRlc2MgPSAoaXRlbS5kZXNjcmlwdGlvbiA/PyBcIlwiKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICBpZiAoIW5hbWUgfHwgL15RXFxkKyQvaS50ZXN0KG5hbWUpKSBjb250aW51ZTtcbiAgICAgICAgLy8gRmlsdGVyIG91dCBub24tY29tcGFueS9icmFuZCBlbnRpdGllcyB3aGVuIGRvaW5nIGdlbmVyYWwgY291bnRyeSBkaXNjb3ZlcnlcbiAgICAgICAgY29uc3QgbG9va3NMaWtlQnJhbmQgPVxuICAgICAgICAgIEJvb2xlYW4oc2VhcmNoUXVlcnk/LnRyaW0oKSkgfHxcbiAgICAgICAgICBkZXNjLmluY2x1ZGVzKFwiY29tcGFueVwiKSB8fFxuICAgICAgICAgIGRlc2MuaW5jbHVkZXMoXCJiYW5rXCIpIHx8XG4gICAgICAgICAgZGVzYy5pbmNsdWRlcyhcImFpcmxpbmVcIikgfHxcbiAgICAgICAgICBkZXNjLmluY2x1ZGVzKFwiYnJhbmRcIikgfHxcbiAgICAgICAgICBkZXNjLmluY2x1ZGVzKFwicmV0YWlsXCIpIHx8XG4gICAgICAgICAgZGVzYy5pbmNsdWRlcyhcInRlbGVjb21tdW5pY2F0aW9uc1wiKSB8fFxuICAgICAgICAgIGRlc2MuaW5jbHVkZXMoXCJzdXBlcm1hcmtldFwiKSB8fFxuICAgICAgICAgIGRlc2MuaW5jbHVkZXMoXCJlbnRlcnByaXNlXCIpIHx8XG4gICAgICAgICAgZGVzYy5pbmNsdWRlcyhcImNvcnBvcmF0aW9uXCIpIHx8XG4gICAgICAgICAgZGVzYy5pbmNsdWRlcyhcImNvbmdsb21lcmF0ZVwiKSB8fFxuICAgICAgICAgIGRlc2MuaW5jbHVkZXMoXCJjaGFpblwiKSB8fFxuICAgICAgICAgIGRlc2MuaW5jbHVkZXMoXCJtYW51ZmFjdHVyZXJcIikgfHxcbiAgICAgICAgICBkZXNjLmluY2x1ZGVzKFwic2VydmljZVwiKTtcblxuICAgICAgICBpZiAoIWxvb2tzTGlrZUJyYW5kKSBjb250aW51ZTtcbiAgICAgICAgY29uc3Qgc2x1ZyA9IHNsdWdpZnkobmFtZSk7XG4gICAgICAgIGlmICghc2x1ZyB8fCByZXN1bHRzLmhhcyhpdGVtLmlkKSkgY29udGludWU7XG5cbiAgICAgICAgbGV0IGNhdGVnb3J5ID0gXCJDb25zdW1lciBCcmFuZFwiO1xuICAgICAgICBpZiAoZGVzYy5pbmNsdWRlcyhcImJhbmtcIikgfHwgZGVzYy5pbmNsdWRlcyhcImZpbmFuY2lhbFwiKSB8fCBkZXNjLmluY2x1ZGVzKFwiZmludGVjaFwiKSkge1xuICAgICAgICAgIGNhdGVnb3J5ID0gXCJCYW5raW5nICYgRmluYW5jZVwiO1xuICAgICAgICB9IGVsc2UgaWYgKGRlc2MuaW5jbHVkZXMoXCJhaXJsaW5lXCIpIHx8IGRlc2MuaW5jbHVkZXMoXCJhdmlhdGlvblwiKSkge1xuICAgICAgICAgIGNhdGVnb3J5ID0gXCJBaXJsaW5lcyAmIFRyYXZlbFwiO1xuICAgICAgICB9IGVsc2UgaWYgKGRlc2MuaW5jbHVkZXMoXCJ0ZWxlY29tXCIpKSB7XG4gICAgICAgICAgY2F0ZWdvcnkgPSBcIlRlbGVjb21zXCI7XG4gICAgICAgIH0gZWxzZSBpZiAoZGVzYy5pbmNsdWRlcyhcInN1cGVybWFya2V0XCIpIHx8IGRlc2MuaW5jbHVkZXMoXCJyZXRhaWxcIikgfHwgZGVzYy5pbmNsdWRlcyhcImdyb2NlcnlcIikpIHtcbiAgICAgICAgICBjYXRlZ29yeSA9IFwiUmV0YWlsICYgU3VwZXJtYXJrZXRzXCI7XG4gICAgICAgIH0gZWxzZSBpZiAoZGVzYy5pbmNsdWRlcyhcImZvb2RcIikgfHwgZGVzYy5pbmNsdWRlcyhcInJlc3RhdXJhbnRcIikgfHwgZGVzYy5pbmNsdWRlcyhcImJldmVyYWdlXCIpKSB7XG4gICAgICAgICAgY2F0ZWdvcnkgPSBcIkZvb2QgJiBCZXZlcmFnZXNcIjtcbiAgICAgICAgfSBlbHNlIGlmIChkZXNjLmluY2x1ZGVzKFwidGVjaFwiKSB8fCBkZXNjLmluY2x1ZGVzKFwic29mdHdhcmVcIikpIHtcbiAgICAgICAgICBjYXRlZ29yeSA9IFwiVGVjaG5vbG9neVwiO1xuICAgICAgICB9XG5cbiAgICAgICAgcmVzdWx0cy5zZXQoaXRlbS5pZCwge1xuICAgICAgICAgIGlkOiBgd2QtJHtpdGVtLmlkfWAsXG4gICAgICAgICAgc291cmNlOiBcIndpa2lkYXRhXCIsXG4gICAgICAgICAgc291cmNlX2lkOiBpdGVtLmlkLFxuICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgc2x1ZyxcbiAgICAgICAgICBjb3VudHJ5OiBjb3VudHJ5Q29kZSxcbiAgICAgICAgICBjYXRlZ29yeSxcbiAgICAgICAgICBkZXNjcmlwdGlvbjogaXRlbS5kZXNjcmlwdGlvbiA/PyBgJHtuYW1lfSAoJHtjTmFtZX0pYCxcbiAgICAgICAgICB3ZWJzaXRlOiBudWxsLFxuICAgICAgICAgIGxvZ29fdXJsOiBudWxsLFxuICAgICAgICAgIHN0YXR1czogXCJwZW5kaW5nXCIsXG4gICAgICAgICAgY3JlYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KSxcbiAgKTtcblxuICByZXR1cm4gWy4uLnJlc3VsdHMudmFsdWVzKCldLnNsaWNlKDAsIGxpbWl0KTtcbn1cblxuLyoqXG4gKiBNdWx0aS1lbmdpbmUgYnJhbmQgZGlzY292ZXJ5IGZvciBhbnkgY291bnRyeSBpbiB0aGUgd29ybGQ6XG4gKiAxLiBDdXJhdGVkIEdsb2JhbCBDb3VudHJ5IEF0bGFzICh3aXRoIHZlcmlmaWVkIGRvbWFpbnMgJiBDbGVhcmJpdCBsb2dvcylcbiAqIDIuIExpdmUgV2lraWRhdGEgU1BBUlFMIHF1ZXJ5ICh3aXRoIFdpa2ltZWRpYSBDb21tb25zIFAxNTQgbG9nb3MgJiBvZmZpY2lhbCB3ZWJzaXRlcylcbiAqIDMuIExpdmUgV2lraWRhdGEgU2VhcmNoIEFQSSBmYWxsYmFjayAoZm9yIGNvdW50cmllcy9rZXl3b3JkcyB3aGVyZSBTUEFSUUwgaXMgc2xvdylcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRpc2NvdmVyQnJhbmRzRm9yQ291bnRyeShpbnB1dDoge1xuICBjb3VudHJ5Q29kZTogc3RyaW5nO1xuICBsaW1pdDogbnVtYmVyO1xuICBzZWFyY2hRdWVyeT86IHN0cmluZztcbn0pOiBQcm9taXNlPHsgY2FuZGlkYXRlczogQ2FuZGlkYXRlW107IHNvdXJjZXNVc2VkOiBzdHJpbmdbXSB9PiB7XG4gIGNvbnN0IGNvZGUgPSBub3JtYWxpemVDb3VudHJ5Q29kZShpbnB1dC5jb3VudHJ5Q29kZSkgfHwgaW5wdXQuY291bnRyeUNvZGUudG9VcHBlckNhc2UoKTtcbiAgY29uc3QgbGltaXQgPSBNYXRoLm1heCgxLCBNYXRoLm1pbigyMDAsIGlucHV0LmxpbWl0IHx8IDUwKSk7XG4gIGNvbnN0IHF1ZXJ5RmlsdGVyID0gaW5wdXQuc2VhcmNoUXVlcnk/LnRyaW0oKS50b0xvd2VyQ2FzZSgpID8/IFwiXCI7XG4gIGNvbnN0IGJ5U2x1ZyA9IG5ldyBNYXA8c3RyaW5nLCBDYW5kaWRhdGUgJiB7IHNpdGVsaW5rczogbnVtYmVyIH0+KCk7XG4gIGNvbnN0IHNvdXJjZXNVc2VkOiBzdHJpbmdbXSA9IFtdO1xuXG4gIC8vIDEuIFNlZWQgZnJvbSBHbG9iYWwgQ291bnRyeSBBdGxhcyBmaXJzdCBzbyBoaWdoLXByb2ZpbGUgbG9jYWwgYnJhbmRzIHdpdGggbG9nb3MgYXJlIGFsd2F5cyBwcmVzZW50XG4gIGNvbnN0IGF0bGFzQnJhbmRzID0gR0xPQkFMX0NPVU5UUllfQVRMQVNbY29kZV0gPz8gW107XG4gIGZvciAoY29uc3QgYiBvZiBhdGxhc0JyYW5kcykge1xuICAgIGlmIChcbiAgICAgIHF1ZXJ5RmlsdGVyICYmXG4gICAgICAhYCR7Yi5uYW1lfSAke2IuY2F0ZWdvcnl9ICR7Yi5kZXNjcmlwdGlvbn1gLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocXVlcnlGaWx0ZXIpXG4gICAgKSB7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3Qgc2x1ZyA9IHNsdWdpZnkoYi5uYW1lKTtcbiAgICBpZiAoIXNsdWcpIGNvbnRpbnVlO1xuICAgIGJ5U2x1Zy5zZXQoc2x1Zywge1xuICAgICAgaWQ6IGBhdGxhcy0ke2NvZGV9LSR7c2x1Z31gLFxuICAgICAgc291cmNlOiBcIndpa2lkYXRhXCIsXG4gICAgICBzb3VyY2VfaWQ6IGBBVExBU18ke2NvZGV9XyR7c2x1Zy50b1VwcGVyQ2FzZSgpfWAsXG4gICAgICBuYW1lOiBiLm5hbWUsXG4gICAgICBzbHVnLFxuICAgICAgY291bnRyeTogY29kZSxcbiAgICAgIGNhdGVnb3J5OiBiLmNhdGVnb3J5LFxuICAgICAgZGVzY3JpcHRpb246IGIuZGVzY3JpcHRpb24sXG4gICAgICB3ZWJzaXRlOiBgaHR0cHM6Ly8ke2IuZG9tYWlufWAsXG4gICAgICBsb2dvX3VybDogYGh0dHBzOi8vbG9nby5jbGVhcmJpdC5jb20vJHtiLmRvbWFpbn1gLFxuICAgICAgc3RhdHVzOiBcInBlbmRpbmdcIixcbiAgICAgIGNyZWF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIHNpdGVsaW5rczogNTAwLFxuICAgIH0pO1xuICB9XG4gIGlmIChieVNsdWcuc2l6ZSA+IDApIHNvdXJjZXNVc2VkLnB1c2goXCJHbG9iYWwgQ291bnRyeSBBdGxhc1wiKTtcblxuICAvLyAyLiBMaXZlIFdpa2lkYXRhIFNQQVJRTCBxdWVyeSBmb3IgdGhlIGNvdW50cnlcbiAgdHJ5IHtcbiAgICBjb25zdCBxaWQgPSBhd2FpdCByZXNvbHZlQ291bnRyeVFpZChjb2RlKTtcbiAgICBpZiAocWlkKSB7XG4gICAgICBjb25zdCBiaW5kaW5ncyA9IGF3YWl0IHJ1blNwYXJxbFF1ZXJ5KGJ1aWxkRmFzdENvdW50cnlTcGFycWwocWlkLCBsaW1pdCkpO1xuICAgICAgaWYgKGJpbmRpbmdzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgc291cmNlc1VzZWQucHVzaChcIldpa2lkYXRhIEtub3dsZWRnZSBHcmFwaCAoU1BBUlFMKVwiKTtcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgYiBvZiBiaW5kaW5ncykge1xuICAgICAgICBjb25zdCBxVXJsOiBzdHJpbmcgPSBiLml0ZW0/LnZhbHVlID8/IFwiXCI7XG4gICAgICAgIGNvbnN0IHNvdXJjZUlkID0gcVVybC5zcGxpdChcIi9cIikucG9wKCkgPz8gXCJcIjtcbiAgICAgICAgY29uc3QgbmFtZTogc3RyaW5nID0gYi5pdGVtTGFiZWw/LnZhbHVlID8/IFwiXCI7XG4gICAgICAgIGlmICghc291cmNlSWQgfHwgIW5hbWUgfHwgL15RXFxkKyQvaS50ZXN0KG5hbWUpKSBjb250aW51ZTtcbiAgICAgICAgaWYgKFxuICAgICAgICAgIHF1ZXJ5RmlsdGVyICYmXG4gICAgICAgICAgIWAke25hbWV9ICR7Yi5pbmR1c3RyeUxhYmVsPy52YWx1ZSA/PyBcIlwifSAke2IuZGVzYz8udmFsdWUgPz8gXCJcIn1gXG4gICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxuICAgICAgICAgICAgLmluY2x1ZGVzKHF1ZXJ5RmlsdGVyKVxuICAgICAgICApIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzbHVnID0gc2x1Z2lmeShuYW1lKTtcbiAgICAgICAgaWYgKCFzbHVnKSBjb250aW51ZTtcblxuICAgICAgICBjb25zdCBleGlzdGluZyA9IGJ5U2x1Zy5nZXQoc2x1Zyk7XG4gICAgICAgIGlmIChleGlzdGluZykge1xuICAgICAgICAgIGV4aXN0aW5nLmNhdGVnb3J5ID8/PSBiLmluZHVzdHJ5TGFiZWw/LnZhbHVlID8/IG51bGw7XG4gICAgICAgICAgZXhpc3RpbmcuZGVzY3JpcHRpb24gPz89IGIuZGVzYz8udmFsdWUgPz8gbnVsbDtcbiAgICAgICAgICBleGlzdGluZy53ZWJzaXRlID8/PSBiLndlYnNpdGU/LnZhbHVlID8/IG51bGw7XG4gICAgICAgICAgZXhpc3RpbmcubG9nb191cmwgPz89IGIubG9nbz8udmFsdWUgPz8gbnVsbDtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBsb2dvVXJsOiBzdHJpbmcgfCBudWxsID0gYi5sb2dvPy52YWx1ZSA/PyBudWxsO1xuICAgICAgICBjb25zdCB3ZWJzaXRlVXJsOiBzdHJpbmcgfCBudWxsID0gYi53ZWJzaXRlPy52YWx1ZSA/PyBudWxsO1xuICAgICAgICBpZiAoIWxvZ29VcmwgJiYgd2Vic2l0ZVVybCkge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBob3N0ID0gbmV3IFVSTCh3ZWJzaXRlVXJsKS5ob3N0bmFtZS5yZXBsYWNlKC9ed3d3XFwuLywgXCJcIik7XG4gICAgICAgICAgICBsb2dvVXJsID0gYGh0dHBzOi8vbG9nby5jbGVhcmJpdC5jb20vJHtob3N0fWA7XG4gICAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAvKiBpZ25vcmUgKi9cbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBieVNsdWcuc2V0KHNsdWcsIHtcbiAgICAgICAgICBpZDogYHdkLSR7c291cmNlSWR9YCxcbiAgICAgICAgICBzb3VyY2U6IFwid2lraWRhdGFcIixcbiAgICAgICAgICBzb3VyY2VfaWQ6IHNvdXJjZUlkLFxuICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgc2x1ZyxcbiAgICAgICAgICBjb3VudHJ5OiBjb2RlLFxuICAgICAgICAgIGNhdGVnb3J5OiBiLmluZHVzdHJ5TGFiZWw/LnZhbHVlID8/IFwiQ29uc3VtZXIgQnJhbmRcIixcbiAgICAgICAgICBkZXNjcmlwdGlvbjogYi5kZXNjPy52YWx1ZSA/PyBgJHtuYW1lfSDigJQgJHtjb3VudHJ5TmFtZShjb2RlKSB8fCBjb2RlfWAsXG4gICAgICAgICAgd2Vic2l0ZTogd2Vic2l0ZVVybCxcbiAgICAgICAgICBsb2dvX3VybDogbG9nb1VybCxcbiAgICAgICAgICBzdGF0dXM6IFwicGVuZGluZ1wiLFxuICAgICAgICAgIGNyZWF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgICBzaXRlbGlua3M6IE51bWJlcihiLnNpdGVsaW5rcz8udmFsdWUgPz8gMTApLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gIH0gY2F0Y2gge1xuICAgIC8vIFNQQVJRTCB0aW1lZCBvdXQgb3IgdGhyb3R0bGVkIOKAlCBmYWxsYmFjayB0byBXaWtpZGF0YSBBY3Rpb24gQVBJIGJlbG93XG4gIH1cblxuICAvLyAzLiBTdXBwbGVtZW50IHdpdGggZmFzdCBXaWtpZGF0YSBTZWFyY2ggQVBJIGlmIG5lZWRlZCBvciBpZiBhIHNlYXJjaCBxdWVyeSB3YXMgZW50ZXJlZFxuICBpZiAoYnlTbHVnLnNpemUgPCBsaW1pdCB8fCBxdWVyeUZpbHRlcikge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBhcGlSZXN1bHRzID0gYXdhaXQgc2VhcmNoV2lraWRhdGFFbnRpdGllc0ZvckNvdW50cnkoXG4gICAgICAgIGNvZGUsXG4gICAgICAgIGxpbWl0LFxuICAgICAgICBpbnB1dC5zZWFyY2hRdWVyeSxcbiAgICAgICk7XG4gICAgICBpZiAoYXBpUmVzdWx0cy5sZW5ndGggPiAwKSB7XG4gICAgICAgIHNvdXJjZXNVc2VkLnB1c2goXCJXaWtpZGF0YSBMaXZlIFNlYXJjaCBBUElcIik7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IGMgb2YgYXBpUmVzdWx0cykge1xuICAgICAgICBpZiAoIWJ5U2x1Zy5oYXMoYy5zbHVnKSkge1xuICAgICAgICAgIGJ5U2x1Zy5zZXQoYy5zbHVnLCB7IC4uLmMsIHNpdGVsaW5rczogNSB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2gge1xuICAgICAgLyogaWdub3JlICovXG4gICAgfVxuICB9XG5cbiAgY29uc3QgY2FuZGlkYXRlcyA9IFsuLi5ieVNsdWcudmFsdWVzKCldXG4gICAgLnNvcnQoKGEsIGIpID0+IGIuc2l0ZWxpbmtzIC0gYS5zaXRlbGlua3MpXG4gICAgLnNsaWNlKDAsIGxpbWl0KVxuICAgIC5tYXAoKHsgc2l0ZWxpbmtzOiBfcywgLi4ucm93IH0pID0+IHJvdyk7XG5cbiAgcmV0dXJuIHsgY2FuZGlkYXRlcywgc291cmNlc1VzZWQgfTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQnJhbmRDYW5kaWRhdGVzKCk6IFByb21pc2U8Q2FuZGlkYXRlW10+IHtcbiAgY29uc3QgbG9jYWwgPSByZWFkTG9jYWxDYW5kaWRhdGVzKCkuZmlsdGVyKChjKSA9PiBjLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIpO1xuICBjb25zdCBieVNsdWcgPSBuZXcgTWFwPHN0cmluZywgQ2FuZGlkYXRlPigpO1xuICBmb3IgKGNvbnN0IGMgb2YgbG9jYWwpIGJ5U2x1Zy5zZXQoYy5zbHVnLCBjKTtcblxuICB0cnkge1xuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImJyYW5kX2ltcG9ydF9jYW5kaWRhdGVzXCIgYXMgYW55KVxuICAgICAgLnNlbGVjdChcIipcIilcbiAgICAgIC5lcShcInN0YXR1c1wiLCBcInBlbmRpbmdcIilcbiAgICAgIC5vcmRlcihcImNyZWF0ZWRfYXRcIiwgeyBhc2NlbmRpbmc6IGZhbHNlIH0pXG4gICAgICAubGltaXQoMTUwKTtcbiAgICBpZiAoIWVycm9yICYmIGRhdGEpIHtcbiAgICAgIGZvciAoY29uc3Qgcm93IG9mIGRhdGEgYXMgYW55W10pIHtcbiAgICAgICAgaWYgKHJvdy5zbHVnICYmICFieVNsdWcuaGFzKHJvdy5zbHVnKSkge1xuICAgICAgICAgIGJ5U2x1Zy5zZXQocm93LnNsdWcsIHtcbiAgICAgICAgICAgIGlkOiBTdHJpbmcocm93LmlkKSxcbiAgICAgICAgICAgIHNvdXJjZTogcm93LnNvdXJjZSA/PyBcIndpa2lkYXRhXCIsXG4gICAgICAgICAgICBzb3VyY2VfaWQ6IHJvdy5zb3VyY2VfaWQgPz8gU3RyaW5nKHJvdy5pZCksXG4gICAgICAgICAgICBuYW1lOiByb3cubmFtZSxcbiAgICAgICAgICAgIHNsdWc6IHJvdy5zbHVnLFxuICAgICAgICAgICAgY291bnRyeTogcm93LmNvdW50cnkgPz8gXCJaQVwiLFxuICAgICAgICAgICAgY2F0ZWdvcnk6IHJvdy5jYXRlZ29yeSA/PyBudWxsLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246IHJvdy5kZXNjcmlwdGlvbiA/PyBudWxsLFxuICAgICAgICAgICAgd2Vic2l0ZTogcm93LndlYnNpdGUgPz8gbnVsbCxcbiAgICAgICAgICAgIGxvZ29fdXJsOiByb3cubG9nb191cmwgPz8gbnVsbCxcbiAgICAgICAgICAgIHN0YXR1czogcm93LnN0YXR1cyA/PyBcInBlbmRpbmdcIixcbiAgICAgICAgICAgIGNyZWF0ZWRfYXQ6IHJvdy5jcmVhdGVkX2F0LFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9IGNhdGNoIHtcbiAgICAvKiBpZ25vcmUgKi9cbiAgfVxuXG4gIHJldHVybiBbLi4uYnlTbHVnLnZhbHVlcygpXTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGltcG9ydEJyYW5kc0Zyb21XaWtpZGF0YShpbnB1dDoge1xuICBjb3VudHJ5Q29kZTogc3RyaW5nO1xuICBsaW1pdDogbnVtYmVyO1xuICBzZWFyY2hRdWVyeT86IHN0cmluZztcbn0pOiBQcm9taXNlPFdpa2lkYXRhSW1wb3J0UmVzdWx0PiB7XG4gIGNvbnN0IHsgY2FuZGlkYXRlcywgc291cmNlc1VzZWQgfSA9IGF3YWl0IGRpc2NvdmVyQnJhbmRzRm9yQ291bnRyeShpbnB1dCk7XG4gIGlmICghY2FuZGlkYXRlcy5sZW5ndGgpIHtcbiAgICByZXR1cm4geyBpbnNlcnRlZDogMCwgc2tpcHBlZDogMCwgc291cmNlU3VtbWFyeTogXCJObyBuZXcgY2FuZGlkYXRlcyBmb3VuZFwiIH07XG4gIH1cblxuICBjb25zdCBjdXJyZW50TG9jYWwgPSByZWFkTG9jYWxDYW5kaWRhdGVzKCk7XG4gIGNvbnN0IGV4aXN0aW5nU2x1Z3MgPSBuZXcgU2V0KGN1cnJlbnRMb2NhbC5tYXAoKGMpID0+IGMuc2x1ZykpO1xuICBsZXQgaW5zZXJ0ZWQgPSAwO1xuICBsZXQgc2tpcHBlZCA9IDA7XG5cbiAgZm9yIChjb25zdCBjIG9mIGNhbmRpZGF0ZXMpIHtcbiAgICBpZiAoZXhpc3RpbmdTbHVncy5oYXMoYy5zbHVnKSkge1xuICAgICAgc2tpcHBlZCArPSAxO1xuICAgIH0gZWxzZSB7XG4gICAgICBleGlzdGluZ1NsdWdzLmFkZChjLnNsdWcpO1xuICAgICAgY3VycmVudExvY2FsLnVuc2hpZnQoeyAuLi5jLCBzdGF0dXM6IFwicGVuZGluZ1wiIH0pO1xuICAgICAgaW5zZXJ0ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgd3JpdGVMb2NhbENhbmRpZGF0ZXMoY3VycmVudExvY2FsKTtcblxuICAvLyBCZXN0LWVmZm9ydCBzeW5jIHRvIFN1cGFiYXNlIGlmIHRhYmxlICYgcGVybWlzc2lvbnMgZXhpc3RcbiAgdHJ5IHtcbiAgICBjb25zdCBzYlJvd3MgPSBjYW5kaWRhdGVzLm1hcCgoeyBpZDogX2lkLCBjcmVhdGVkX2F0OiBfY2EsIC4uLnJlc3QgfSkgPT4gcmVzdCk7XG4gICAgYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwiYnJhbmRfaW1wb3J0X2NhbmRpZGF0ZXNcIiBhcyBhbnkpXG4gICAgICAudXBzZXJ0KHNiUm93cywgeyBvbkNvbmZsaWN0OiBcInNvdXJjZSxzb3VyY2VfaWRcIiwgaWdub3JlRHVwbGljYXRlczogdHJ1ZSB9KTtcbiAgfSBjYXRjaCB7XG4gICAgLyogaWdub3JlIFN1cGFiYXNlIFJMUyBlcnJvciB3aGVuIHNpZ25lZCBpbiB2aWEgRmlyZWJhc2UgKi9cbiAgfVxuXG4gIHJldHVybiB7XG4gICAgaW5zZXJ0ZWQsXG4gICAgc2tpcHBlZCxcbiAgICBzb3VyY2VTdW1tYXJ5OiBzb3VyY2VzVXNlZC5qb2luKFwiICsgXCIpIHx8IFwiV2lraWRhdGFcIixcbiAgfTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcGVyc2lzdEFwcHJvdmVkQnJhbmRSZWNvcmQoXG4gIGNhbmQ6IHtcbiAgICBuYW1lOiBzdHJpbmc7XG4gICAgc2x1Zzogc3RyaW5nO1xuICAgIGNvdW50cnk6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nIHwgbnVsbDtcbiAgICBkZXNjcmlwdGlvbjogc3RyaW5nIHwgbnVsbDtcbiAgICB3ZWJzaXRlOiBzdHJpbmcgfCBudWxsO1xuICAgIGxvZ29fdXJsOiBzdHJpbmcgfCBudWxsO1xuICB9LFxuICBvd25lcklkOiBzdHJpbmcsXG4pOiBQcm9taXNlPEFwcHJvdmVkQnJhbmQ+IHtcbiAgY29uc3QgY2xlYW5JZCA9IGBicmFuZC0ke2NhbmQuY291bnRyeS50b0xvd2VyQ2FzZSgpfS0ke2NhbmQuc2x1Z31gXG4gICAgLnJlcGxhY2UoL1teYS16QS1aMC05Xy1dL2csIFwiLVwiKVxuICAgIC5zbGljZSgwLCA5Nik7XG5cbiAgLy8gMS4gU2F2ZSB0byBsb2NhbCBpbXBvcnRlZCBicmFuZHMgc3RvcmUgZm9yIGltbWVkaWF0ZSBzeW5jaHJvbm91cyBhdmFpbGFiaWxpdHlcbiAgY29uc3QgbG9jYWxCcmFuZHMgPSBnZXRMb2NhbEltcG9ydGVkQnJhbmRzKCk7XG4gIGlmICghbG9jYWxCcmFuZHMuc29tZSgoYikgPT4gYi5zbHVnID09PSBjYW5kLnNsdWcpKSB7XG4gICAgbG9jYWxCcmFuZHMudW5zaGlmdCh7XG4gICAgICBpZDogY2xlYW5JZCxcbiAgICAgIG5hbWU6IGNhbmQubmFtZSxcbiAgICAgIHNsdWc6IGNhbmQuc2x1ZyxcbiAgICAgIGNvdW50cnk6IGNhbmQuY291bnRyeSxcbiAgICAgIGNhdGVnb3J5OiBjYW5kLmNhdGVnb3J5ID8/IFwiQ29uc3VtZXIgQnJhbmRcIixcbiAgICAgIGRlc2NyaXB0aW9uOiBjYW5kLmRlc2NyaXB0aW9uID8/IGAke2NhbmQubmFtZX0gKCR7Y2FuZC5jb3VudHJ5fSlgLFxuICAgICAgd2Vic2l0ZTogY2FuZC53ZWJzaXRlLFxuICAgICAgbG9nb191cmw6IGNhbmQubG9nb191cmwsXG4gICAgICBvd25lcl9pZDogb3duZXJJZCxcbiAgICAgIHZlcmlmaWVkOiB0cnVlLFxuICAgICAgdHJ1c3Rfc2NvcmU6IDc4LFxuICAgICAgY3JlYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH0pO1xuICAgIHNhdmVMb2NhbEltcG9ydGVkQnJhbmRzKGxvY2FsQnJhbmRzKTtcbiAgfVxuXG4gIC8vIDIuIFNhdmUgdG8gRmlyZXN0b3JlIGBicmFuZHNgIGNvbGxlY3Rpb24gKHJlc3BlY3RpbmcgZmlyZXN0b3JlLnJ1bGVzIHNjaGVtYSlcbiAgdHJ5IHtcbiAgICBhd2FpdCBjcmVhdGVGaXJlc3RvcmVCcmFuZChcbiAgICAgIHtcbiAgICAgICAgbmFtZTogY2FuZC5uYW1lLnNsaWNlKDAsIDIwMCksXG4gICAgICAgIHNsdWc6IGNhbmQuc2x1Zy5zbGljZSgwLCAyMDApLFxuICAgICAgICBjb3VudHJ5OiAoY2FuZC5jb3VudHJ5IHx8IFwiWkFcIikuc2xpY2UoMCwgMTAwKSxcbiAgICAgICAgY2F0ZWdvcnk6IChjYW5kLmNhdGVnb3J5IHx8IFwiQ29uc3VtZXIgQnJhbmRcIikuc2xpY2UoMCwgMTAwKSxcbiAgICAgICAgZGVzY3JpcHRpb246IChjYW5kLmRlc2NyaXB0aW9uIHx8IGAke2NhbmQubmFtZX0gYnJhbmQgcGFnZWApLnNsaWNlKDAsIDIwMDApLFxuICAgICAgICB3ZWJzaXRlOiBjYW5kLndlYnNpdGUgfHwgXCJcIixcbiAgICAgICAgbG9nb1VybDogY2FuZC5sb2dvX3VybCB8fCBcIlwiLFxuICAgICAgICB0cnVzdFNjb3JlOiA3OCxcbiAgICAgICAgcmlza1Njb3JlOiAxMixcbiAgICAgICAgc3RhdHVzOiBcImFjdGl2ZVwiLFxuICAgICAgICBpc1ZlcmlmaWVkOiB0cnVlLFxuICAgICAgICBjcmVhdGVkQnk6IG93bmVySWQsXG4gICAgICB9LFxuICAgICAgY2xlYW5JZCxcbiAgICApO1xuICB9IGNhdGNoIHtcbiAgICAvKiBpZ25vcmUgaWYgdW5hdXRoZW50aWNhdGVkIG9yIG9mZmxpbmUgKi9cbiAgfVxuXG4gIC8vIDMuIEJlc3QtZWZmb3J0IHNhdmUgdG8gU3VwYWJhc2VcbiAgdHJ5IHtcbiAgICBjb25zdCB7IGRhdGE6IGJyYW5kIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJicmFuZHNcIilcbiAgICAgIC5pbnNlcnQoe1xuICAgICAgICBvd25lcl9pZDogb3duZXJJZCxcbiAgICAgICAgbmFtZTogY2FuZC5uYW1lLFxuICAgICAgICBzbHVnOiBjYW5kLnNsdWcsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBjYW5kLmRlc2NyaXB0aW9uLFxuICAgICAgICB3ZWJzaXRlOiBjYW5kLndlYnNpdGUsXG4gICAgICAgIGNhdGVnb3J5OiBjYW5kLmNhdGVnb3J5LFxuICAgICAgICBjb3VudHJ5OiBjYW5kLmNvdW50cnksXG4gICAgICAgIGxvZ29fdXJsOiBjYW5kLmxvZ29fdXJsLFxuICAgICAgfSlcbiAgICAgIC5zZWxlY3QoXCJpZCwgbmFtZSwgc2x1Zywgd2Vic2l0ZVwiKVxuICAgICAgLnNpbmdsZSgpO1xuICAgIGlmIChicmFuZCkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgYnJhbmRJZDogYnJhbmQuaWQsXG4gICAgICAgIG5hbWU6IGJyYW5kLm5hbWUsXG4gICAgICAgIHNsdWc6IGJyYW5kLnNsdWcsXG4gICAgICAgIHdlYnNpdGU6IGJyYW5kLndlYnNpdGUsXG4gICAgICB9O1xuICAgIH1cbiAgfSBjYXRjaCB7XG4gICAgLyogaWdub3JlICovXG4gIH1cblxuICByZXR1cm4ge1xuICAgIGJyYW5kSWQ6IGNsZWFuSWQsXG4gICAgbmFtZTogY2FuZC5uYW1lLFxuICAgIHNsdWc6IGNhbmQuc2x1ZyxcbiAgICB3ZWJzaXRlOiBjYW5kLndlYnNpdGUsXG4gIH07XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhcHByb3ZlQnJhbmRDYW5kaWRhdGUoXG4gIGlkOiBzdHJpbmcsXG4gIHJldmlld2VySWQ6IHN0cmluZyxcbik6IFByb21pc2U8QXBwcm92ZWRCcmFuZD4ge1xuICBjb25zdCBsb2NhbCA9IHJlYWRMb2NhbENhbmRpZGF0ZXMoKTtcbiAgbGV0IGNhbmQgPSBsb2NhbC5maW5kKChjKSA9PiBjLmlkID09PSBpZCB8fCBjLnNsdWcgPT09IGlkKTtcblxuICBpZiAoIWNhbmQpIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcImJyYW5kX2ltcG9ydF9jYW5kaWRhdGVzXCIpXG4gICAgICAgIC5zZWxlY3QoXCIqXCIpXG4gICAgICAgIC5lcShcImlkXCIsIGlkKVxuICAgICAgICAubWF5YmVTaW5nbGUoKTtcbiAgICAgIGlmIChkYXRhKSB7XG4gICAgICAgIGNhbmQgPSB7XG4gICAgICAgICAgaWQ6IFN0cmluZyhkYXRhLmlkKSxcbiAgICAgICAgICBzb3VyY2U6IGRhdGEuc291cmNlLFxuICAgICAgICAgIHNvdXJjZV9pZDogZGF0YS5zb3VyY2VfaWQgPz8gXCJcIixcbiAgICAgICAgICBuYW1lOiBkYXRhLm5hbWUsXG4gICAgICAgICAgc2x1ZzogZGF0YS5zbHVnLFxuICAgICAgICAgIGNvdW50cnk6IGRhdGEuY291bnRyeSA/PyBcIlpBXCIsXG4gICAgICAgICAgY2F0ZWdvcnk6IGRhdGEuY2F0ZWdvcnksXG4gICAgICAgICAgZGVzY3JpcHRpb246IGRhdGEuZGVzY3JpcHRpb24sXG4gICAgICAgICAgd2Vic2l0ZTogZGF0YS53ZWJzaXRlLFxuICAgICAgICAgIGxvZ29fdXJsOiBkYXRhLmxvZ29fdXJsLFxuICAgICAgICAgIHN0YXR1czogZGF0YS5zdGF0dXMsXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICAvKiBpZ25vcmUgKi9cbiAgICB9XG4gIH1cblxuICBpZiAoIWNhbmQpIHRocm93IG5ldyBFcnJvcihcIkNhbmRpZGF0ZSBub3QgZm91bmQuXCIpO1xuXG4gIGNvbnN0IGFwcHJvdmVkID0gYXdhaXQgcGVyc2lzdEFwcHJvdmVkQnJhbmRSZWNvcmQoY2FuZCwgcmV2aWV3ZXJJZCk7XG5cbiAgY29uc3QgdXBkYXRlZExvY2FsID0gbG9jYWwubWFwKChjKSA9PlxuICAgIGMuaWQgPT09IGlkIHx8IGMuc2x1ZyA9PT0gY2FuZCEuc2x1ZyA/IHsgLi4uYywgc3RhdHVzOiBcImFwcHJvdmVkXCIgfSA6IGMsXG4gICk7XG4gIHdyaXRlTG9jYWxDYW5kaWRhdGVzKHVwZGF0ZWRMb2NhbCk7XG5cbiAgdHJ5IHtcbiAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJicmFuZF9pbXBvcnRfY2FuZGlkYXRlc1wiKVxuICAgICAgLnVwZGF0ZSh7IHN0YXR1czogXCJhcHByb3ZlZFwiLCByZXZpZXdlZF9ieTogcmV2aWV3ZXJJZCB9KVxuICAgICAgLmVxKFwiaWRcIiwgaWQpO1xuICB9IGNhdGNoIHtcbiAgICAvKiBpZ25vcmUgKi9cbiAgfVxuXG4gIHJldHVybiBhcHByb3ZlZDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlamVjdEJyYW5kQ2FuZGlkYXRlKGlkOiBzdHJpbmcsIHJldmlld2VySWQ6IHN0cmluZykge1xuICBjb25zdCBsb2NhbCA9IHJlYWRMb2NhbENhbmRpZGF0ZXMoKTtcbiAgY29uc3QgdXBkYXRlZCA9IGxvY2FsLm1hcCgoYykgPT4gKGMuaWQgPT09IGlkID8geyAuLi5jLCBzdGF0dXM6IFwicmVqZWN0ZWRcIiB9IDogYykpO1xuICB3cml0ZUxvY2FsQ2FuZGlkYXRlcyh1cGRhdGVkKTtcblxuICB0cnkge1xuICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImJyYW5kX2ltcG9ydF9jYW5kaWRhdGVzXCIpXG4gICAgICAudXBkYXRlKHsgc3RhdHVzOiBcInJlamVjdGVkXCIsIHJldmlld2VkX2J5OiByZXZpZXdlcklkIH0pXG4gICAgICAuZXEoXCJpZFwiLCBpZCk7XG4gIH0gY2F0Y2gge1xuICAgIC8qIGlnbm9yZSAqL1xuICB9XG59XG5cbmV4cG9ydCB0eXBlIFB1Ymxpc2hCcmFuZHNSZXN1bHQgPSB7XG4gIHB1Ymxpc2hlZDogbnVtYmVyO1xuICBza2lwcGVkOiBudW1iZXI7XG4gIHNvdXJjZVN1bW1hcnk/OiBzdHJpbmc7XG59O1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHVibGlzaEJyYW5kc0Zyb21XaWtpZGF0YShpbnB1dDoge1xuICBjb3VudHJ5Q29kZTogc3RyaW5nO1xuICBsaW1pdDogbnVtYmVyO1xuICBvd25lcklkOiBzdHJpbmc7XG4gIHNlYXJjaFF1ZXJ5Pzogc3RyaW5nO1xufSk6IFByb21pc2U8UHVibGlzaEJyYW5kc1Jlc3VsdD4ge1xuICBjb25zdCB7IGNhbmRpZGF0ZXMsIHNvdXJjZXNVc2VkIH0gPSBhd2FpdCBkaXNjb3ZlckJyYW5kc0ZvckNvdW50cnkoe1xuICAgIGNvdW50cnlDb2RlOiBpbnB1dC5jb3VudHJ5Q29kZSxcbiAgICBsaW1pdDogaW5wdXQubGltaXQsXG4gICAgc2VhcmNoUXVlcnk6IGlucHV0LnNlYXJjaFF1ZXJ5LFxuICB9KTtcblxuICBpZiAoIWNhbmRpZGF0ZXMubGVuZ3RoKSB7XG4gICAgcmV0dXJuIHsgcHVibGlzaGVkOiAwLCBza2lwcGVkOiAwLCBzb3VyY2VTdW1tYXJ5OiBcIk5vIG1hdGNoaW5nIGJyYW5kcyBmb3VuZFwiIH07XG4gIH1cblxuICBjb25zdCBleGlzdGluZ0xvY2FsID0gZ2V0TG9jYWxJbXBvcnRlZEJyYW5kcygpO1xuICBjb25zdCBleGlzdGluZ1NsdWdzID0gbmV3IFNldChleGlzdGluZ0xvY2FsLm1hcCgoYikgPT4gYi5zbHVnKSk7XG5cbiAgdHJ5IHtcbiAgICBjb25zdCBmc0JyYW5kcyA9IGF3YWl0IGdldEZpcmVzdG9yZUJyYW5kcygpO1xuICAgIGZvciAoY29uc3QgYiBvZiBmc0JyYW5kcykgZXhpc3RpbmdTbHVncy5hZGQoYi5zbHVnKTtcbiAgfSBjYXRjaCB7XG4gICAgLyogaWdub3JlICovXG4gIH1cblxuICBsZXQgcHVibGlzaGVkID0gMDtcbiAgbGV0IHNraXBwZWQgPSAwO1xuXG4gIGZvciAoY29uc3QgYyBvZiBjYW5kaWRhdGVzKSB7XG4gICAgaWYgKGV4aXN0aW5nU2x1Z3MuaGFzKGMuc2x1ZykpIHtcbiAgICAgIHNraXBwZWQgKz0gMTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBleGlzdGluZ1NsdWdzLmFkZChjLnNsdWcpO1xuICAgIGF3YWl0IHBlcnNpc3RBcHByb3ZlZEJyYW5kUmVjb3JkKGMsIGlucHV0Lm93bmVySWQpO1xuICAgIHB1Ymxpc2hlZCArPSAxO1xuICB9XG5cbiAgcmV0dXJuIHtcbiAgICBwdWJsaXNoZWQsXG4gICAgc2tpcHBlZCxcbiAgICBzb3VyY2VTdW1tYXJ5OiBzb3VyY2VzVXNlZC5qb2luKFwiICsgXCIpIHx8IFwiV2lraWRhdGFcIixcbiAgfTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHB1Ymxpc2hQZW5kaW5nQ2FuZGlkYXRlcyhcbiAgb3duZXJJZDogc3RyaW5nLFxuKTogUHJvbWlzZTxQdWJsaXNoQnJhbmRzUmVzdWx0PiB7XG4gIGNvbnN0IHBlbmRpbmcgPSBhd2FpdCBmZXRjaEJyYW5kQ2FuZGlkYXRlcygpO1xuICBpZiAoIXBlbmRpbmcubGVuZ3RoKSByZXR1cm4geyBwdWJsaXNoZWQ6IDAsIHNraXBwZWQ6IDAgfTtcblxuICBsZXQgcHVibGlzaGVkID0gMDtcbiAgbGV0IHNraXBwZWQgPSAwO1xuXG4gIGZvciAoY29uc3QgYyBvZiBwZW5kaW5nKSB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHBlcnNpc3RBcHByb3ZlZEJyYW5kUmVjb3JkKGMsIG93bmVySWQpO1xuICAgICAgcHVibGlzaGVkICs9IDE7XG4gICAgfSBjYXRjaCB7XG4gICAgICBza2lwcGVkICs9IDE7XG4gICAgfVxuICB9XG5cbiAgY29uc3QgbG9jYWwgPSByZWFkTG9jYWxDYW5kaWRhdGVzKCkubWFwKChjKSA9PlxuICAgIGMuc3RhdHVzID09PSBcInBlbmRpbmdcIiA/IHsgLi4uYywgc3RhdHVzOiBcImFwcHJvdmVkXCIgfSA6IGMsXG4gICk7XG4gIHdyaXRlTG9jYWxDYW5kaWRhdGVzKGxvY2FsKTtcblxuICB0cnkge1xuICAgIGF3YWl0IHN1cGFiYXNlXG4gICAgICAuZnJvbShcImJyYW5kX2ltcG9ydF9jYW5kaWRhdGVzXCIpXG4gICAgICAudXBkYXRlKHsgc3RhdHVzOiBcImFwcHJvdmVkXCIsIHJldmlld2VkX2J5OiBvd25lcklkIH0pXG4gICAgICAuZXEoXCJzdGF0dXNcIiwgXCJwZW5kaW5nXCIpO1xuICB9IGNhdGNoIHtcbiAgICAvKiBpZ25vcmUgKi9cbiAgfVxuXG4gIHJldHVybiB7IHB1Ymxpc2hlZCwgc2tpcHBlZCB9O1xufVxuIl19