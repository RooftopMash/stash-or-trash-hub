const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { supabase } from "/src/integrations/supabase/client.ts";
var _s = $RefreshSig$();
export function useUnreadCount(userId) {
	_s();
	const [count, setCount] = useState(0);
	useEffect(() => {
		if (!userId) {
			setCount(0);
			return;
		}
		let mounted = true;
		const load = async () => {
			const { count: c } = await supabase.from("messages").select("id", {
				count: "exact",
				head: true
			}).eq("recipient_id", userId).is("read_at", null);
			if (mounted) setCount(c ?? 0);
		};
		load();
		const channel = supabase.channel(`unread-${userId}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "messages",
			filter: `recipient_id=eq.${userId}`
		}, () => load()).subscribe();
		return () => {
			mounted = false;
			supabase.removeChannel(channel);
		};
	}, [userId]);
	return count;
}
_s(useUnreadCount, "8FkJzHhZsFmVL5otHHrie84nHpk=");

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLGdCQUFnQjs7QUFFekIsT0FBTyxTQUFTLGVBQWUsUUFBbUM7O0NBQ2hFLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxDQUFDO0NBRXBDLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxRQUFRO0dBQ1gsU0FBUyxDQUFDO0dBQ1Y7RUFDRjtFQUNBLElBQUksVUFBVTtFQUVkLE1BQU0sT0FBTyxZQUFZO0dBQ3ZCLE1BQU0sRUFBRSxPQUFPLE1BQU0sTUFBTSxTQUN4QixLQUFLLFVBQVUsQ0FBQyxDQUNoQixPQUFPLE1BQU07SUFBRSxPQUFPO0lBQVMsTUFBTTtHQUFLLENBQUMsQ0FBQyxDQUM1QyxHQUFHLGdCQUFnQixNQUFNLENBQUMsQ0FDMUIsR0FBRyxXQUFXLElBQUk7R0FDckIsSUFBSSxTQUFTLFNBQVMsS0FBSyxDQUFDO0VBQzlCO0VBQ0EsS0FBSztFQUVMLE1BQU0sVUFBVSxTQUNiLFFBQVEsVUFBVSxRQUFRLENBQUMsQ0FDM0IsR0FDQyxvQkFDQTtHQUFFLE9BQU87R0FBSyxRQUFRO0dBQVUsT0FBTztHQUFZLFFBQVEsbUJBQW1CO0VBQVMsU0FDakYsS0FBSyxDQUNiLENBQUMsQ0FDQSxVQUFVO0VBRWIsYUFBYTtHQUNYLFVBQVU7R0FDVixTQUFTLGNBQWMsT0FBTztFQUNoQztDQUNGLEdBQUcsQ0FBQyxNQUFNLENBQUM7Q0FFWCxPQUFPO0FBQ1QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsidXNlVW5yZWFkQ291bnQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHN1cGFiYXNlIH0gZnJvbSBcIkAvaW50ZWdyYXRpb25zL3N1cGFiYXNlL2NsaWVudFwiO1xuXG5leHBvcnQgZnVuY3Rpb24gdXNlVW5yZWFkQ291bnQodXNlcklkOiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkKSB7XG4gIGNvbnN0IFtjb3VudCwgc2V0Q291bnRdID0gdXNlU3RhdGUoMCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXVzZXJJZCkge1xuICAgICAgc2V0Q291bnQoMCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGxldCBtb3VudGVkID0gdHJ1ZTtcblxuICAgIGNvbnN0IGxvYWQgPSBhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCB7IGNvdW50OiBjIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcIm1lc3NhZ2VzXCIpXG4gICAgICAgIC5zZWxlY3QoXCJpZFwiLCB7IGNvdW50OiBcImV4YWN0XCIsIGhlYWQ6IHRydWUgfSlcbiAgICAgICAgLmVxKFwicmVjaXBpZW50X2lkXCIsIHVzZXJJZClcbiAgICAgICAgLmlzKFwicmVhZF9hdFwiLCBudWxsKTtcbiAgICAgIGlmIChtb3VudGVkKSBzZXRDb3VudChjID8/IDApO1xuICAgIH07XG4gICAgbG9hZCgpO1xuXG4gICAgY29uc3QgY2hhbm5lbCA9IHN1cGFiYXNlXG4gICAgICAuY2hhbm5lbChgdW5yZWFkLSR7dXNlcklkfWApXG4gICAgICAub24oXG4gICAgICAgIFwicG9zdGdyZXNfY2hhbmdlc1wiLFxuICAgICAgICB7IGV2ZW50OiBcIipcIiwgc2NoZW1hOiBcInB1YmxpY1wiLCB0YWJsZTogXCJtZXNzYWdlc1wiLCBmaWx0ZXI6IGByZWNpcGllbnRfaWQ9ZXEuJHt1c2VySWR9YCB9LFxuICAgICAgICAoKSA9PiBsb2FkKCksXG4gICAgICApXG4gICAgICAuc3Vic2NyaWJlKCk7XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgbW91bnRlZCA9IGZhbHNlO1xuICAgICAgc3VwYWJhc2UucmVtb3ZlQ2hhbm5lbChjaGFubmVsKTtcbiAgICB9O1xuICB9LCBbdXNlcklkXSk7XG5cbiAgcmV0dXJuIGNvdW50O1xufVxuIl19