import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/UserProfile.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport24_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport24_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { useNavigate } from "/node_modules/@tanstack/react-router/dist/esm/index.dev.js?v=a8030269";
import { useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=a8030269";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=a8030269";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=a8030269";
import { useAuth } from "/src/hooks/useAuth.tsx";
import { useRoles } from "/src/hooks/useRoles.tsx";
import { getPublicProfile, updateMyProfile } from "/src/lib/social.ts";
import { getRegisteredBrandIdentity, setRegisteredBrandIdentity, getActiveDeskOperator, getBrandDeskOperators, switchActiveDeskOperator } from "/src/lib/brand-operators.ts";
import { isVerdictSoundEnabled, setVerdictSoundEnabled, playCoinSpinSound } from "/src/lib/verdict-sounds.ts";
import { isDeveloperCodeInspectionActive, toggleDeveloperCodeInspection } from "/src/lib/security-shield.ts";
import { APP_SUPPORTED_LOCALES } from "/src/lib/locale-app.ts";
import { switchAppLanguage } from "/src/components/LanguageSwitcher.tsx";
import { Avatar, AvatarFallback, AvatarImage } from "/src/components/ui/avatar.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { Textarea } from "/src/components/ui/textarea.tsx";
import { Switch } from "/src/components/ui/switch.tsx";
import { DropdownMenu, DropdownMenuContent, DropdownMenuGroup, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "/src/components/ui/dropdown-menu.tsx";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "/src/components/ui/dialog.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "/src/components/ui/tabs.tsx";
import { Bell, Building2, Check, Code, Coins, Copy, Globe, LayoutDashboard, Lock, LogOut, MessageCircle, Settings, Shield, ShieldCheck, User, Volume2 } from "/node_modules/.vite/deps/lucide-react.js?v=a8030269";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "/app/applet/src/components/UserProfile.tsx";
import __vite__cjsImport24_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
var _s = $RefreshSig$();
const ACCOUNT_PREFS_KEY = "sot_account_preferences_v1";
const DEFAULT_PREFS = {
	callRingAlerts: true,
	dmRequestFilter: "everyone",
	publicVoterLedger: true,
	defaultFeedFilter: "all"
};
export function getAccountPreferences() {
	if (typeof window === "undefined") return DEFAULT_PREFS;
	try {
		const raw = window.localStorage.getItem(ACCOUNT_PREFS_KEY);
		if (!raw) return DEFAULT_PREFS;
		return {
			...DEFAULT_PREFS,
			...JSON.parse(raw)
		};
	} catch {
		return DEFAULT_PREFS;
	}
}
export function saveAccountPreferences(prefs) {
	if (typeof window === "undefined") return;
	try {
		window.localStorage.setItem(ACCOUNT_PREFS_KEY, JSON.stringify(prefs));
		window.dispatchEvent(new CustomEvent("sot-account-prefs-updated", { detail: prefs }));
	} catch {}
}
/**
* Self-contained SVG data-URI avatars (< 300 chars each, adhering strictly to
* firebase-blueprint.json UserProfile.avatarUrl maxLength: 500 and Zero-Broken-Image policy).
*/
const PRESET_AVATARS = [
	{
		id: "gold-watchdog",
		label: "Gold Arbitrator",
		url: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><rect width="80" height="80" rx="40" fill="%230f172a"/><circle cx="40" cy="30" r="14" fill="%23d6a928"/><path d="M16 70c4-14 14-22 24-22s20 8 24 22" fill="%23d6a928"/></svg>`
	},
	{
		id: "emerald-stash",
		label: "Emerald Stash",
		url: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><rect width="80" height="80" rx="40" fill="%23064e3b"/><circle cx="40" cy="30" r="14" fill="%2334d399"/><path d="M16 70c4-14 14-22 24-22s20 8 24 22" fill="%2334d399"/></svg>`
	},
	{
		id: "royal-shield",
		label: "Cobalt Guardian",
		url: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><rect width="80" height="80" rx="40" fill="%231e3a8a"/><circle cx="40" cy="30" r="14" fill="%2393c5fd"/><path d="M16 70c4-14 14-22 24-22s20 8 24 22" fill="%2393c5fd"/></svg>`
	},
	{
		id: "crimson-critic",
		label: "Crimson Auditor",
		url: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><rect width="80" height="80" rx="40" fill="%237f1d1d"/><circle cx="40" cy="30" r="14" fill="%23fca5a5"/><path d="M16 70c4-14 14-22 24-22s20 8 24 22" fill="%23fca5a5"/></svg>`
	}
];
function getInitials(name) {
	const clean = name.trim();
	if (!clean) return "ST";
	const parts = clean.split(/\s+/).filter(Boolean);
	if (parts.length >= 2) {
		return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
	}
	return clean.slice(0, 2).toUpperCase();
}
export function UserProfile({ variant = "navbar", defaultSettingsOpen = false }) {
	_s();
	const { user, signOut } = useAuth();
	const { isAdmin, isDeveloper, persona, setPersona } = useRoles();
	const { t, i18n } = useTranslation();
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const [settingsOpen, setSettingsOpen] = useState(defaultSettingsOpen);
	const [activeTab, setActiveTab] = useState("profile");
	const [saving, setSaving] = useState(false);
	// Brand identity & operator state (strictly used when persona === "brand_owner")
	const [registeredBrand, setRegisteredBrandState] = useState(() => getRegisteredBrandIdentity());
	const [activeOperator, setActiveOperatorState] = useState(() => getActiveDeskOperator());
	const [operators, setOperatorsState] = useState(() => getBrandDeskOperators());
	// Form states for Personal Profile
	const [displayNameInput, setDisplayNameInput] = useState("");
	const [usernameInput, setUsernameInput] = useState("");
	const [bioInput, setBioInput] = useState("");
	const [avatarUrlInput, setAvatarUrlInput] = useState("");
	// Form states for Brand Profile (when persona === "brand_owner")
	const [brandNameInput, setBrandNameInput] = useState(registeredBrand.name);
	const [brandCategoryInput, setBrandCategoryInput] = useState(registeredBrand.category);
	const [brandWebsiteInput, setBrandWebsiteInput] = useState(registeredBrand.website);
	// Preferences state
	const [soundEnabled, setSoundEnabled] = useState(() => isVerdictSoundEnabled());
	const [prefs, setPrefs] = useState(() => getAccountPreferences());
	const { data: profile } = useQuery({
		queryKey: ["my-profile", user?.id],
		queryFn: () => getPublicProfile(user.id),
		enabled: !!user?.id
	});
	useEffect(() => {
		const syncBrandAndOps = () => {
			const nextBrand = getRegisteredBrandIdentity();
			setRegisteredBrandState(nextBrand);
			setBrandNameInput(nextBrand.name);
			setBrandCategoryInput(nextBrand.category);
			setBrandWebsiteInput(nextBrand.website);
			setActiveOperatorState(getActiveDeskOperator());
			setOperatorsState(getBrandDeskOperators());
		};
		window.addEventListener("sot-registered-brand-updated", syncBrandAndOps);
		window.addEventListener("sot-brand-operator-updated", syncBrandAndOps);
		return () => {
			window.removeEventListener("sot-registered-brand-updated", syncBrandAndOps);
			window.removeEventListener("sot-brand-operator-updated", syncBrandAndOps);
		};
	}, []);
	useEffect(() => {
		if (!user) return;
		const resolvedName = profile?.display_name || user.displayName || user.user_metadata?.display_name || user.email?.split("@")[0] || "Verified Voter";
		const resolvedUsername = profile?.username || (user.email ? user.email.split("@")[0].replace(/[^a-zA-Z0-9_.-]/g, "") : "voter");
		const resolvedBio = profile?.bio ?? "";
		const resolvedAvatar = profile?.avatar_url || user.photoURL || user.user_metadata?.avatar_url || "";
		setDisplayNameInput(resolvedName);
		setUsernameInput(resolvedUsername);
		setBioInput(resolvedBio);
		setAvatarUrlInput(resolvedAvatar);
	}, [user, profile]);
	if (!user) return null;
	const isBrandMode = persona === "brand_owner";
	const resolvedDisplayName = isBrandMode ? registeredBrand.name : profile?.display_name || user.displayName || user.user_metadata?.display_name || user.email?.split("@")[0] || "Verified Voter";
	const resolvedHandle = isBrandMode ? `OP-SEAT · ${activeOperator.name}` : `@${profile?.username || user.email?.split("@")[0] || "member"}`;
	const resolvedAvatarUrl = isBrandMode ? "" : profile?.avatar_url || user.photoURL || user.user_metadata?.avatar_url || "";
	const handleSaveProfileSettings = async () => {
		setSaving(true);
		try {
			if (isBrandMode) {
				if (!brandNameInput.trim()) {
					toast.error("Brand name cannot be empty.");
					setSaving(false);
					return;
				}
				const updatedBrand = setRegisteredBrandIdentity({
					name: brandNameInput.trim().slice(0, 120),
					category: brandCategoryInput.trim().slice(0, 80) || "Consumer Brand",
					website: brandWebsiteInput.trim().slice(0, 250)
				});
				setRegisteredBrandState(updatedBrand);
				toast.success(`Updated Brand Account settings for ${updatedBrand.name}.`);
			} else {
				const cleanName = displayNameInput.trim().slice(0, 60) || "Verified Voter";
				const cleanUsername = usernameInput.trim().replace(/^@+/, "").replace(/[^a-zA-Z0-9_.-]/g, "").slice(0, 50);
				const cleanBio = bioInput.trim().slice(0, 280);
				const cleanAvatar = avatarUrlInput.trim().slice(0, 500);
				await updateMyProfile({
					userId: user.id,
					display_name: cleanName,
					username: cleanUsername,
					bio: cleanBio,
					avatar_url: cleanAvatar
				});
				await queryClient.invalidateQueries({ queryKey: ["my-profile", user.id] });
				toast.success(t("social.profileSaved", { defaultValue: "Profile and avatar saved." }));
			}
			setSettingsOpen(false);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : t("social.profileSaveFailed", { defaultValue: "Could not save account settings." }));
		} finally {
			setSaving(false);
		}
	};
	const handleToggleSound = (checked) => {
		setSoundEnabled(checked);
		setVerdictSoundEnabled(checked);
		if (checked) {
			playCoinSpinSound();
			toast.success("Verdict & Zwepe Coin sound effects enabled.");
		} else {
			toast.info("Verdict sound effects muted.");
		}
	};
	const handleUpdatePrefs = (partial) => {
		const next = {
			...prefs,
			...partial
		};
		setPrefs(next);
		saveAccountPreferences(next);
		toast.success("Account preferences updated.");
	};
	const handleCopyAccountId = async () => {
		try {
			await navigator.clipboard.writeText(user.id);
			toast.success("Account ID copied to clipboard.");
		} catch {
			toast.info(`Account ID: ${user.id}`);
		}
	};
	const activeLangCode = (i18n.language || "en").split("-")[0];
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [variant === "navbar" ? /* @__PURE__ */ _jsxDEV(DropdownMenu, {
		"data-tsd-source": "/src/components/UserProfile.tsx:320:9",
		children: [/* @__PURE__ */ _jsxDEV(DropdownMenuTrigger, {
			asChild: true,
			"data-tsd-source": "/src/components/UserProfile.tsx:321:11",
			children: /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				"aria-label": "Open user profile and account settings",
				title: `${resolvedDisplayName} · Account & Settings`,
				className: cn("group relative inline-flex h-8 shrink-0 items-center gap-1.5 rounded-full p-0.5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#d6a928] cursor-pointer", isBrandMode ? "border border-[#d6a928]/70 bg-slate-950 text-[#f5d061] hover:border-[#d6a928]" : "border border-border bg-secondary/50 text-foreground hover:bg-secondary"),
				"data-tsd-source": "/src/components/UserProfile.tsx:322:13",
				children: [/* @__PURE__ */ _jsxDEV(Avatar, {
					className: "h-7 w-7 shrink-0",
					"data-tsd-source": "/src/components/UserProfile.tsx:333:15",
					children: [resolvedAvatarUrl ? /* @__PURE__ */ _jsxDEV(AvatarImage, {
						src: resolvedAvatarUrl,
						alt: resolvedDisplayName,
						referrerPolicy: "no-referrer",
						className: "object-cover",
						"data-tsd-source": "/src/components/UserProfile.tsx:335:19"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 335,
						columnNumber: 19
					}, this) : null, /* @__PURE__ */ _jsxDEV(AvatarFallback, {
						className: cn("text-[11px] font-extrabold tracking-tight", isBrandMode ? "bg-slate-900 text-[#d6a928]" : "bg-slate-950 text-[#d6a928] dark:bg-[#d6a928] dark:text-slate-950"),
						"data-tsd-source": "/src/components/UserProfile.tsx:342:17",
						children: getInitials(resolvedDisplayName)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 342,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 333,
					columnNumber: 15
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					"aria-hidden": "true",
					className: cn("absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full ring-2 ring-background", isDeveloper ? "bg-[#d6a928]" : isBrandMode ? "bg-[#d6a928]" : "bg-emerald-500"),
					"data-tsd-source": "/src/components/UserProfile.tsx:355:15"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 355,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 322,
				columnNumber: 13
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 321,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV(DropdownMenuContent, {
			align: "end",
			className: "w-72 p-2",
			"data-tsd-source": "/src/components/UserProfile.tsx:369:11",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: cn("flex items-center gap-3 rounded-lg p-2.5", isBrandMode ? "bg-slate-950 text-white border border-[#d6a928]/30" : "bg-secondary/50 text-foreground"),
					"data-tsd-source": "/src/components/UserProfile.tsx:371:13",
					children: [/* @__PURE__ */ _jsxDEV(Avatar, {
						className: "h-10 w-10 shrink-0 border border-[#d6a928]/40",
						"data-tsd-source": "/src/components/UserProfile.tsx:379:15",
						children: [resolvedAvatarUrl ? /* @__PURE__ */ _jsxDEV(AvatarImage, {
							src: resolvedAvatarUrl,
							alt: resolvedDisplayName,
							referrerPolicy: "no-referrer",
							className: "object-cover",
							"data-tsd-source": "/src/components/UserProfile.tsx:381:19"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 381,
							columnNumber: 19
						}, this) : null, /* @__PURE__ */ _jsxDEV(AvatarFallback, {
							className: cn("text-xs font-extrabold", isBrandMode ? "bg-slate-900 text-[#d6a928]" : "bg-slate-950 text-[#d6a928]"),
							"data-tsd-source": "/src/components/UserProfile.tsx:388:17",
							children: getInitials(resolvedDisplayName)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 388,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 379,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "min-w-0 flex-1",
						"data-tsd-source": "/src/components/UserProfile.tsx:399:15",
						children: [
							/* @__PURE__ */ _jsxDEV("p", {
								className: "truncate text-sm font-bold leading-tight",
								"data-tsd-source": "/src/components/UserProfile.tsx:400:17",
								children: resolvedDisplayName
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 400,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: cn("truncate text-xs", isBrandMode ? "text-[#f5d061]" : "text-muted-foreground"),
								"data-tsd-source": "/src/components/UserProfile.tsx:403:17",
								children: resolvedHandle
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 403,
								columnNumber: 17
							}, this),
							user.email && /* @__PURE__ */ _jsxDEV("p", {
								className: cn("truncate text-[11px]", isBrandMode ? "text-slate-400" : "text-muted-foreground/80"),
								"data-tsd-source": "/src/components/UserProfile.tsx:412:19",
								children: user.email
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 412,
								columnNumber: 19
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 399,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 371,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV(DropdownMenuSeparator, {
					className: "my-1.5",
					"data-tsd-source": "/src/components/UserProfile.tsx:424:13"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 424,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV(DropdownMenuGroup, {
					"data-tsd-source": "/src/components/UserProfile.tsx:427:13",
					children: [
						/* @__PURE__ */ _jsxDEV(DropdownMenuItem, {
							onClick: () => navigate({ to: "/profile" }),
							className: "cursor-pointer gap-2.5 py-2 text-xs font-semibold",
							"data-tsd-source": "/src/components/UserProfile.tsx:428:15",
							children: [isBrandMode ? /* @__PURE__ */ _jsxDEV(Building2, {
								className: "h-4 w-4 text-[#d6a928]",
								"data-tsd-source": "/src/components/UserProfile.tsx:433:19"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 433,
								columnNumber: 19
							}, this) : /* @__PURE__ */ _jsxDEV(User, {
								className: "h-4 w-4 text-emerald-600",
								"data-tsd-source": "/src/components/UserProfile.tsx:435:19"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 435,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								"data-tsd-source": "/src/components/UserProfile.tsx:437:17",
								children: isBrandMode ? "Brand Desk & Operator Roster" : t("nav.profile", { defaultValue: "My Profile" })
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 437,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 428,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(DropdownMenuItem, {
							onClick: () => navigate({ to: "/dashboard" }),
							className: "cursor-pointer gap-2.5 py-2 text-xs font-semibold",
							"data-tsd-source": "/src/components/UserProfile.tsx:444:15",
							children: [/* @__PURE__ */ _jsxDEV(LayoutDashboard, {
								className: "h-4 w-4 text-[#d6a928]",
								"data-tsd-source": "/src/components/UserProfile.tsx:448:17"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 448,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								"data-tsd-source": "/src/components/UserProfile.tsx:449:17",
								children: isBrandMode ? "Brand Command Suite" : t("nav.dashboard", { defaultValue: "My Voter Hub" })
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 449,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 444,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(DropdownMenuItem, {
							onClick: () => {
								setActiveTab("profile");
								setSettingsOpen(true);
							},
							className: "cursor-pointer gap-2.5 py-2 text-xs font-semibold",
							"data-tsd-source": "/src/components/UserProfile.tsx:456:15",
							children: [/* @__PURE__ */ _jsxDEV(Settings, {
								className: "h-4 w-4 text-foreground",
								"data-tsd-source": "/src/components/UserProfile.tsx:463:17"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 463,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								"data-tsd-source": "/src/components/UserProfile.tsx:464:17",
								children: "Account Settings & Avatar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 464,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 456,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(DropdownMenuItem, {
							onClick: () => {
								setActiveTab("preferences");
								setSettingsOpen(true);
							},
							className: "cursor-pointer gap-2.5 py-2 text-xs font-semibold",
							"data-tsd-source": "/src/components/UserProfile.tsx:467:15",
							children: [/* @__PURE__ */ _jsxDEV(Volume2, {
								className: "h-4 w-4 text-muted-foreground",
								"data-tsd-source": "/src/components/UserProfile.tsx:474:17"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 474,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								"data-tsd-source": "/src/components/UserProfile.tsx:475:17",
								children: "Audio, Calls & Language"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 475,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 467,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 427,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV(DropdownMenuSeparator, {
					className: "my-1.5",
					"data-tsd-source": "/src/components/UserProfile.tsx:479:13"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 479,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV(DropdownMenuGroup, {
					"data-tsd-source": "/src/components/UserProfile.tsx:482:13",
					children: [
						/* @__PURE__ */ _jsxDEV(DropdownMenuItem, {
							onClick: () => navigate({ to: "/messages" }),
							className: "cursor-pointer gap-2.5 py-1.5 text-xs",
							"data-tsd-source": "/src/components/UserProfile.tsx:483:15",
							children: [/* @__PURE__ */ _jsxDEV(MessageCircle, {
								className: "h-4 w-4 text-muted-foreground",
								"data-tsd-source": "/src/components/UserProfile.tsx:487:17"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 487,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								"data-tsd-source": "/src/components/UserProfile.tsx:488:17",
								children: t("nav.messages", { defaultValue: "Messages & SOT Calling" })
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 488,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 483,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(DropdownMenuItem, {
							onClick: () => navigate({ to: "/notifications" }),
							className: "cursor-pointer gap-2.5 py-1.5 text-xs",
							"data-tsd-source": "/src/components/UserProfile.tsx:490:15",
							children: [/* @__PURE__ */ _jsxDEV(Bell, {
								className: "h-4 w-4 text-muted-foreground",
								"data-tsd-source": "/src/components/UserProfile.tsx:494:17"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 494,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								"data-tsd-source": "/src/components/UserProfile.tsx:495:17",
								children: t("social.notifications", { defaultValue: "Notifications" })
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 495,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 490,
							columnNumber: 15
						}, this),
						isAdmin && /* @__PURE__ */ _jsxDEV(DropdownMenuItem, {
							onClick: () => navigate({ to: "/admin" }),
							className: "cursor-pointer gap-2.5 py-1.5 text-xs font-semibold",
							"data-tsd-source": "/src/components/UserProfile.tsx:498:17",
							children: [/* @__PURE__ */ _jsxDEV(Shield, {
								className: "h-4 w-4 text-[#d6a928]",
								"data-tsd-source": "/src/components/UserProfile.tsx:502:19"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 502,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								"data-tsd-source": "/src/components/UserProfile.tsx:503:19",
								children: t("nav.admin", { defaultValue: "Admin Verification Portal" })
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 503,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 498,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 482,
					columnNumber: 13
				}, this),
				isDeveloper && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
					/* @__PURE__ */ _jsxDEV(DropdownMenuSeparator, {
						className: "my-1.5",
						"data-tsd-source": "/src/components/UserProfile.tsx:511:17"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 511,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(DropdownMenuLabel, {
						className: "px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground",
						"data-tsd-source": "/src/components/UserProfile.tsx:512:17",
						children: "Developer Controls & Security Shield"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 512,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(DropdownMenuItem, {
						onClick: () => {
							const next = isBrandMode ? "consumer" : "brand_owner";
							setPersona(next);
							toast.info(next === "brand_owner" ? `Developer Preview: Viewing as Brand (${registeredBrand.name})` : "Developer Preview: Viewing as Personal User");
						},
						className: "cursor-pointer gap-2.5 rounded-md bg-secondary/70 py-2 text-xs font-bold",
						"data-tsd-source": "/src/components/UserProfile.tsx:515:17",
						children: isBrandMode ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Coins, {
							className: "h-4 w-4 text-emerald-600",
							"data-tsd-source": "/src/components/UserProfile.tsx:529:23"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 529,
							columnNumber: 23
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							"data-tsd-source": "/src/components/UserProfile.tsx:530:23",
							children: "DEV: Switch to Personal View"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 530,
							columnNumber: 23
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 528,
							columnNumber: 21
						}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Building2, {
							className: "h-4 w-4 text-[#d6a928]",
							"data-tsd-source": "/src/components/UserProfile.tsx:534:23"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 534,
							columnNumber: 23
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "truncate",
							"data-tsd-source": "/src/components/UserProfile.tsx:535:23",
							children: ["DEV: Switch to ", registeredBrand.name]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 535,
							columnNumber: 23
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 533,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 515,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(DropdownMenuItem, {
						onClick: () => {
							const current = isDeveloperCodeInspectionActive();
							toggleDeveloperCodeInspection(!current);
							toast.success(!current ? "Developer F12 / Code Inspection: Enabled for this session" : "Security Shield: F12 Blocked & Mobile Screen-Grab Shielded");
						},
						className: "cursor-pointer gap-2.5 rounded-md bg-secondary/40 py-2 text-xs font-semibold",
						"data-tsd-source": "/src/components/UserProfile.tsx:540:17",
						children: [/* @__PURE__ */ _jsxDEV(Code, {
							className: "h-4 w-4 text-[#d6a928]",
							"data-tsd-source": "/src/components/UserProfile.tsx:552:19"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 552,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							"data-tsd-source": "/src/components/UserProfile.tsx:553:19",
							children: ["F12 Code Viewing: ", isDeveloperCodeInspectionActive() ? "Allowed (Dev Mode)" : "Protected (Shield Active)"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 553,
							columnNumber: 19
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 540,
						columnNumber: 17
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 510,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ _jsxDEV(DropdownMenuSeparator, {
					className: "my-1.5",
					"data-tsd-source": "/src/components/UserProfile.tsx:560:13"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 560,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV(DropdownMenuItem, {
					onClick: () => void signOut(),
					className: "cursor-pointer gap-2.5 py-2 text-xs font-semibold text-destructive focus:text-destructive",
					"data-tsd-source": "/src/components/UserProfile.tsx:562:13",
					children: [/* @__PURE__ */ _jsxDEV(LogOut, {
						className: "h-4 w-4",
						"data-tsd-source": "/src/components/UserProfile.tsx:566:15"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 566,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						"data-tsd-source": "/src/components/UserProfile.tsx:567:15",
						children: t("nav.signOut", { defaultValue: "Sign out" })
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 567,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 562,
					columnNumber: 13
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 369,
			columnNumber: 11
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 320,
		columnNumber: 9
	}, this) : 
	/* Card variant for Profile or Dashboard embedding */
	/* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-wrap items-center justify-between gap-4 rounded-xl border border-border bg-card p-4",
		"data-tsd-source": "/src/components/UserProfile.tsx:573:9",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-3.5",
			"data-tsd-source": "/src/components/UserProfile.tsx:574:11",
			children: [/* @__PURE__ */ _jsxDEV(Avatar, {
				className: "h-12 w-12 border border-[#d6a928]/40",
				"data-tsd-source": "/src/components/UserProfile.tsx:575:13",
				children: [resolvedAvatarUrl ? /* @__PURE__ */ _jsxDEV(AvatarImage, {
					src: resolvedAvatarUrl,
					alt: resolvedDisplayName,
					referrerPolicy: "no-referrer",
					className: "object-cover",
					"data-tsd-source": "/src/components/UserProfile.tsx:577:17"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 577,
					columnNumber: 17
				}, this) : null, /* @__PURE__ */ _jsxDEV(AvatarFallback, {
					className: "bg-slate-950 text-sm font-extrabold text-[#d6a928]",
					"data-tsd-source": "/src/components/UserProfile.tsx:584:15",
					children: getInitials(resolvedDisplayName)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 584,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 575,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				"data-tsd-source": "/src/components/UserProfile.tsx:588:13",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-sm font-bold text-foreground",
					"data-tsd-source": "/src/components/UserProfile.tsx:589:15",
					children: resolvedDisplayName
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 589,
					columnNumber: 15
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-muted-foreground",
					"data-tsd-source": "/src/components/UserProfile.tsx:590:15",
					children: [resolvedHandle, user.email ? ` · ${user.email}` : ""]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 590,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 588,
				columnNumber: 13
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 574,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-2",
			"data-tsd-source": "/src/components/UserProfile.tsx:596:11",
			children: /* @__PURE__ */ _jsxDEV(Button, {
				size: "sm",
				variant: "outline",
				onClick: () => {
					setActiveTab("profile");
					setSettingsOpen(true);
				},
				className: "h-8 gap-1.5 text-xs font-semibold",
				"data-tsd-source": "/src/components/UserProfile.tsx:597:13",
				children: [/* @__PURE__ */ _jsxDEV(Settings, {
					className: "h-3.5 w-3.5",
					"data-tsd-source": "/src/components/UserProfile.tsx:606:15"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 606,
					columnNumber: 15
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					"data-tsd-source": "/src/components/UserProfile.tsx:607:15",
					children: "Account Settings"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 607,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 597,
				columnNumber: 13
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 596,
			columnNumber: 11
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 573,
		columnNumber: 9
	}, this), /* @__PURE__ */ _jsxDEV(Dialog, {
		open: settingsOpen,
		onOpenChange: setSettingsOpen,
		"data-tsd-source": "/src/components/UserProfile.tsx:614:7",
		children: /* @__PURE__ */ _jsxDEV(DialogContent, {
			className: "max-w-lg",
			"data-tsd-source": "/src/components/UserProfile.tsx:615:9",
			children: [/* @__PURE__ */ _jsxDEV(DialogHeader, {
				"data-tsd-source": "/src/components/UserProfile.tsx:616:11",
				children: [/* @__PURE__ */ _jsxDEV(DialogTitle, {
					className: "flex items-center gap-2 text-base font-bold",
					"data-tsd-source": "/src/components/UserProfile.tsx:617:13",
					children: [/* @__PURE__ */ _jsxDEV(Settings, {
						className: "h-4 w-4 text-[#d6a928]",
						"data-tsd-source": "/src/components/UserProfile.tsx:618:15"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 618,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						"data-tsd-source": "/src/components/UserProfile.tsx:619:15",
						children: isBrandMode ? `${registeredBrand.name} · Brand Account Settings` : "Personal Account & Profile Settings"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 619,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 617,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV(DialogDescription, {
					className: "text-xs",
					"data-tsd-source": "/src/components/UserProfile.tsx:625:13",
					children: isBrandMode ? "Manage your registered brand identity, corporate operator desk seat, and communication preferences." : "Customize your SOrT avatar, public voter profile, audio feedback, and privacy settings."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 625,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 616,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV(Tabs, {
				value: activeTab,
				onValueChange: (v) => setActiveTab(v),
				className: "w-full",
				"data-tsd-source": "/src/components/UserProfile.tsx:632:11",
				children: [
					/* @__PURE__ */ _jsxDEV(TabsList, {
						className: "grid w-full grid-cols-3",
						"data-tsd-source": "/src/components/UserProfile.tsx:637:13",
						children: [
							/* @__PURE__ */ _jsxDEV(TabsTrigger, {
								value: "profile",
								className: "text-xs font-semibold",
								"data-tsd-source": "/src/components/UserProfile.tsx:638:15",
								children: isBrandMode ? "Brand & Desk" : "Profile & Avatar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 638,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV(TabsTrigger, {
								value: "preferences",
								className: "text-xs font-semibold",
								"data-tsd-source": "/src/components/UserProfile.tsx:641:15",
								children: "Preferences"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 641,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV(TabsTrigger, {
								value: "security",
								className: "text-xs font-semibold",
								"data-tsd-source": "/src/components/UserProfile.tsx:644:15",
								children: "Privacy & Auth"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 644,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 637,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(TabsContent, {
						value: "profile",
						className: "mt-4 space-y-4",
						"data-tsd-source": "/src/components/UserProfile.tsx:650:13",
						children: [isBrandMode ? /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3.5",
							"data-tsd-source": "/src/components/UserProfile.tsx:652:17",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 text-xs text-muted-foreground",
									"data-tsd-source": "/src/components/UserProfile.tsx:653:19",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "font-semibold text-foreground",
										"data-tsd-source": "/src/components/UserProfile.tsx:654:21",
										children: "Strict Corporate Desk Isolation Active"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 654,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "mt-0.5",
										"data-tsd-source": "/src/components/UserProfile.tsx:657:21",
										children: [
											"Brand operators work strictly under corporate desk seats. Personal SOrT",
											" ",
											/* @__PURE__ */ _jsxDEV("code", {
												className: "font-mono",
												"data-tsd-source": "/src/components/UserProfile.tsx:659:23",
												children: "@"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 659,
												columnNumber: 23
											}, this),
											" profiles cannot be attached to this brand account."
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 657,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 653,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1.5",
									"data-tsd-source": "/src/components/UserProfile.tsx:664:19",
									children: [/* @__PURE__ */ _jsxDEV(Label, {
										htmlFor: "settings-brand-name",
										className: "text-xs font-semibold",
										"data-tsd-source": "/src/components/UserProfile.tsx:665:21",
										children: "Registered Brand Name"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 665,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV(Input, {
										id: "settings-brand-name",
										value: brandNameInput,
										maxLength: 120,
										onChange: (e) => setBrandNameInput(e.target.value),
										"data-tsd-source": "/src/components/UserProfile.tsx:668:21"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 668,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 664,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
									"data-tsd-source": "/src/components/UserProfile.tsx:676:19",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1.5",
										"data-tsd-source": "/src/components/UserProfile.tsx:677:21",
										children: [/* @__PURE__ */ _jsxDEV(Label, {
											htmlFor: "settings-brand-category",
											className: "text-xs font-semibold",
											"data-tsd-source": "/src/components/UserProfile.tsx:678:23",
											children: "Industry Category"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 678,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV(Input, {
											id: "settings-brand-category",
											value: brandCategoryInput,
											maxLength: 80,
											onChange: (e) => setBrandCategoryInput(e.target.value),
											"data-tsd-source": "/src/components/UserProfile.tsx:681:23"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 681,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 677,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1.5",
										"data-tsd-source": "/src/components/UserProfile.tsx:688:21",
										children: [/* @__PURE__ */ _jsxDEV(Label, {
											htmlFor: "settings-brand-website",
											className: "text-xs font-semibold",
											"data-tsd-source": "/src/components/UserProfile.tsx:689:23",
											children: "Official Website"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 689,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV(Input, {
											id: "settings-brand-website",
											value: brandWebsiteInput,
											maxLength: 250,
											placeholder: "https://...",
											onChange: (e) => setBrandWebsiteInput(e.target.value),
											"data-tsd-source": "/src/components/UserProfile.tsx:692:23"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 692,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 688,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 676,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1.5",
									"data-tsd-source": "/src/components/UserProfile.tsx:702:19",
									children: [/* @__PURE__ */ _jsxDEV(Label, {
										className: "text-xs font-semibold",
										"data-tsd-source": "/src/components/UserProfile.tsx:703:21",
										children: "Active Corporate Desk Seat (On Shift)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 703,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-1 gap-1.5",
										"data-tsd-source": "/src/components/UserProfile.tsx:706:21",
										children: operators.map((op) => {
											const isCurrent = op.id === activeOperator.id;
											return /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => {
													const switched = switchActiveDeskOperator(op.id);
													setActiveOperatorState(switched);
													toast.success(`Active desk handed over to ${switched.name}`);
												},
												className: cn("flex items-center justify-between rounded-lg border px-3 py-2 text-left text-xs transition cursor-pointer", isCurrent ? "border-[#d6a928] bg-slate-950 text-white" : "border-border bg-secondary/30 hover:bg-secondary/60"),
												"data-tsd-source": "/src/components/UserProfile.tsx:710:27",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													"data-tsd-source": "/src/components/UserProfile.tsx:725:29",
													children: [/* @__PURE__ */ _jsxDEV("p", {
														className: "font-bold",
														"data-tsd-source": "/src/components/UserProfile.tsx:726:31",
														children: op.name
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 726,
														columnNumber: 31
													}, this), /* @__PURE__ */ _jsxDEV("p", {
														className: cn("text-[11px]", isCurrent ? "text-slate-300" : "text-muted-foreground"),
														"data-tsd-source": "/src/components/UserProfile.tsx:727:31",
														children: [
															op.roleTitle,
															" · ",
															op.shiftLabel
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 727,
														columnNumber: 31
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 725,
													columnNumber: 29
												}, this), isCurrent && /* @__PURE__ */ _jsxDEV(Check, {
													className: "h-4 w-4 text-[#d6a928]",
													"data-tsd-source": "/src/components/UserProfile.tsx:736:43"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 736,
													columnNumber: 43
												}, this)]
											}, op.id, true, {
												fileName: _jsxFileName,
												lineNumber: 710,
												columnNumber: 27
											}, this);
										})
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 706,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 702,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 652,
							columnNumber: 17
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							"data-tsd-source": "/src/components/UserProfile.tsx:744:17",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-col gap-3 rounded-lg border border-border bg-secondary/30 p-3 sm:flex-row sm:items-center",
									"data-tsd-source": "/src/components/UserProfile.tsx:746:19",
									children: [/* @__PURE__ */ _jsxDEV(Avatar, {
										className: "h-14 w-14 shrink-0 border-2 border-[#d6a928]",
										"data-tsd-source": "/src/components/UserProfile.tsx:747:21",
										children: [avatarUrlInput ? /* @__PURE__ */ _jsxDEV(AvatarImage, {
											src: avatarUrlInput,
											alt: displayNameInput || "User avatar",
											referrerPolicy: "no-referrer",
											className: "object-cover",
											"data-tsd-source": "/src/components/UserProfile.tsx:749:25"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 749,
											columnNumber: 25
										}, this) : null, /* @__PURE__ */ _jsxDEV(AvatarFallback, {
											className: "bg-slate-950 text-base font-extrabold text-[#d6a928]",
											"data-tsd-source": "/src/components/UserProfile.tsx:756:23",
											children: getInitials(displayNameInput || resolvedDisplayName)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 756,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 747,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex-1 space-y-2",
										"data-tsd-source": "/src/components/UserProfile.tsx:761:21",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-semibold text-foreground",
											"data-tsd-source": "/src/components/UserProfile.tsx:762:23",
											children: "Select SOrT Emblem Avatar or Paste Image URL"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 762,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex flex-wrap items-center gap-2",
											"data-tsd-source": "/src/components/UserProfile.tsx:765:23",
											children: [PRESET_AVATARS.map((preset) => {
												const selected = avatarUrlInput === preset.url;
												return /* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													onClick: () => setAvatarUrlInput(preset.url),
													title: preset.label,
													className: cn("relative flex h-8 w-8 items-center justify-center rounded-full border-2 transition cursor-pointer", selected ? "border-[#d6a928] scale-105" : "border-transparent opacity-80 hover:opacity-100"),
													"data-tsd-source": "/src/components/UserProfile.tsx:769:29",
													children: /* @__PURE__ */ _jsxDEV("img", {
														src: preset.url,
														alt: preset.label,
														referrerPolicy: "no-referrer",
														className: "h-full w-full rounded-full object-cover",
														"data-tsd-source": "/src/components/UserProfile.tsx:781:31"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 781,
														columnNumber: 31
													}, this)
												}, preset.id, false, {
													fileName: _jsxFileName,
													lineNumber: 769,
													columnNumber: 29
												}, this);
											}), avatarUrlInput && /* @__PURE__ */ _jsxDEV(Button, {
												type: "button",
												variant: "ghost",
												size: "sm",
												onClick: () => setAvatarUrlInput(""),
												className: "h-7 px-2 text-[11px]",
												"data-tsd-source": "/src/components/UserProfile.tsx:791:27",
												children: "Use Initials"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 791,
												columnNumber: 27
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 765,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 761,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 746,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
									"data-tsd-source": "/src/components/UserProfile.tsx:805:19",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1.5",
										"data-tsd-source": "/src/components/UserProfile.tsx:806:21",
										children: [/* @__PURE__ */ _jsxDEV(Label, {
											htmlFor: "up-display-name",
											className: "text-xs font-semibold",
											"data-tsd-source": "/src/components/UserProfile.tsx:807:23",
											children: t("social.displayName", { defaultValue: "Display Name" })
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 807,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV(Input, {
											id: "up-display-name",
											value: displayNameInput,
											maxLength: 60,
											onChange: (e) => setDisplayNameInput(e.target.value),
											"data-tsd-source": "/src/components/UserProfile.tsx:810:23"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 810,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 806,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1.5",
										"data-tsd-source": "/src/components/UserProfile.tsx:817:21",
										children: [/* @__PURE__ */ _jsxDEV(Label, {
											htmlFor: "up-username",
											className: "text-xs font-semibold",
											"data-tsd-source": "/src/components/UserProfile.tsx:818:23",
											children: "Username Handle"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 818,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV(Input, {
											id: "up-username",
											value: usernameInput,
											maxLength: 50,
											placeholder: "username",
											onChange: (e) => setUsernameInput(e.target.value),
											"data-tsd-source": "/src/components/UserProfile.tsx:821:23"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 821,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 817,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 805,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1.5",
									"data-tsd-source": "/src/components/UserProfile.tsx:831:19",
									children: [/* @__PURE__ */ _jsxDEV(Label, {
										htmlFor: "up-bio",
										className: "text-xs font-semibold",
										"data-tsd-source": "/src/components/UserProfile.tsx:832:21",
										children: t("social.bio", { defaultValue: "Bio / Voter Statement" })
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 832,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV(Textarea, {
										id: "up-bio",
										rows: 2,
										value: bioInput,
										maxLength: 280,
										placeholder: t("social.bioPh", { defaultValue: "Tell the community what you stand for..." }),
										onChange: (e) => setBioInput(e.target.value),
										"data-tsd-source": "/src/components/UserProfile.tsx:835:21"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 835,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 831,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1.5",
									"data-tsd-source": "/src/components/UserProfile.tsx:847:19",
									children: [/* @__PURE__ */ _jsxDEV(Label, {
										htmlFor: "up-avatar-url",
										className: "text-xs font-semibold",
										"data-tsd-source": "/src/components/UserProfile.tsx:848:21",
										children: t("social.avatarUrl", { defaultValue: "Custom Avatar Image URL" })
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 848,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV(Input, {
										id: "up-avatar-url",
										value: avatarUrlInput,
										maxLength: 500,
										placeholder: "https://...",
										onChange: (e) => setAvatarUrlInput(e.target.value),
										"data-tsd-source": "/src/components/UserProfile.tsx:851:21"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 851,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 847,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 744,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV(DialogFooter, {
							className: "pt-2",
							"data-tsd-source": "/src/components/UserProfile.tsx:862:15",
							children: [/* @__PURE__ */ _jsxDEV(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => setSettingsOpen(false),
								"data-tsd-source": "/src/components/UserProfile.tsx:863:17",
								children: "Cancel"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 863,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV(Button, {
								size: "sm",
								onClick: () => void handleSaveProfileSettings(),
								disabled: saving,
								className: "bg-slate-950 text-[#d6a928] hover:bg-slate-900 font-bold",
								"data-tsd-source": "/src/components/UserProfile.tsx:866:17",
								children: saving ? "Saving..." : "Save Changes"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 866,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 862,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 650,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(TabsContent, {
						value: "preferences",
						className: "mt-4 space-y-4",
						"data-tsd-source": "/src/components/UserProfile.tsx:878:13",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							"data-tsd-source": "/src/components/UserProfile.tsx:879:15",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between rounded-lg border border-border p-3",
									"data-tsd-source": "/src/components/UserProfile.tsx:880:17",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-0.5 pr-3",
										"data-tsd-source": "/src/components/UserProfile.tsx:881:19",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-bold text-foreground",
											"data-tsd-source": "/src/components/UserProfile.tsx:882:21",
											children: "Verdict & Zwepe Coin Sound Effects"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 882,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-[11px] text-muted-foreground",
											"data-tsd-source": "/src/components/UserProfile.tsx:885:21",
											children: "Play audio effects when casting Stash/Trash verdicts or spinning coins."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 885,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 881,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV(Switch, {
										checked: soundEnabled,
										onCheckedChange: handleToggleSound,
										"data-tsd-source": "/src/components/UserProfile.tsx:889:19"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 889,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 880,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between rounded-lg border border-border p-3",
									"data-tsd-source": "/src/components/UserProfile.tsx:892:17",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-0.5 pr-3",
										"data-tsd-source": "/src/components/UserProfile.tsx:893:19",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-bold text-foreground",
											"data-tsd-source": "/src/components/UserProfile.tsx:894:21",
											children: "Incoming SOT Voice/Video Call Ring Banner"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 894,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-[11px] text-muted-foreground",
											"data-tsd-source": "/src/components/UserProfile.tsx:897:21",
											children: "Show real-time top alert banner for zero-phone-number SOT calls."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 897,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 893,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV(Switch, {
										checked: prefs.callRingAlerts,
										onCheckedChange: (checked) => handleUpdatePrefs({ callRingAlerts: checked }),
										"data-tsd-source": "/src/components/UserProfile.tsx:901:19"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 901,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 892,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2 rounded-lg border border-border p-3",
									"data-tsd-source": "/src/components/UserProfile.tsx:907:17",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-xs font-bold text-foreground",
										"data-tsd-source": "/src/components/UserProfile.tsx:908:19",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: "flex items-center gap-1.5",
											"data-tsd-source": "/src/components/UserProfile.tsx:909:21",
											children: [/* @__PURE__ */ _jsxDEV(Globe, {
												className: "h-3.5 w-3.5 text-[#d6a928]",
												"data-tsd-source": "/src/components/UserProfile.tsx:910:23"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 910,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												"data-tsd-source": "/src/components/UserProfile.tsx:911:23",
												children: [
													"Preferred Interface Language (",
													APP_SUPPORTED_LOCALES.length,
													" Languages)"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 911,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 909,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 908,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex flex-wrap gap-1.5 pt-1 max-h-48 overflow-y-auto pr-1",
										"data-tsd-source": "/src/components/UserProfile.tsx:914:19",
										children: APP_SUPPORTED_LOCALES.map((loc) => {
											const active = activeLangCode === loc.code;
											return /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => {
													void switchAppLanguage(i18n, loc.code);
													toast.success(`Switched language to ${loc.label}`);
												},
												className: cn("rounded-md px-2.5 py-1 text-xs font-semibold transition cursor-pointer", active ? "bg-slate-950 text-[#d6a928]" : "border border-border bg-secondary/40 text-foreground hover:bg-secondary"),
												"data-tsd-source": "/src/components/UserProfile.tsx:918:25",
												children: loc.label
											}, loc.code, false, {
												fileName: _jsxFileName,
												lineNumber: 918,
												columnNumber: 25
											}, this);
										})
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 914,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 907,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 879,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 878,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV(TabsContent, {
						value: "security",
						className: "mt-4 space-y-4",
						"data-tsd-source": "/src/components/UserProfile.tsx:942:13",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							"data-tsd-source": "/src/components/UserProfile.tsx:943:15",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "rounded-lg border border-border bg-secondary/30 p-3",
									"data-tsd-source": "/src/components/UserProfile.tsx:944:17",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between",
										"data-tsd-source": "/src/components/UserProfile.tsx:945:19",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											"data-tsd-source": "/src/components/UserProfile.tsx:946:21",
											children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, {
												className: "h-4 w-4 text-emerald-600",
												"data-tsd-source": "/src/components/UserProfile.tsx:947:23"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 947,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs font-bold text-foreground",
												"data-tsd-source": "/src/components/UserProfile.tsx:948:23",
												children: "Authenticated Session"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 948,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 946,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV(Button, {
											type: "button",
											variant: "outline",
											size: "sm",
											onClick: () => void handleCopyAccountId(),
											className: "h-7 gap-1 px-2 text-[11px]",
											"data-tsd-source": "/src/components/UserProfile.tsx:952:21",
											children: [/* @__PURE__ */ _jsxDEV(Copy, {
												className: "h-3 w-3",
												"data-tsd-source": "/src/components/UserProfile.tsx:959:23"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 959,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												"data-tsd-source": "/src/components/UserProfile.tsx:960:23",
												children: "Copy ID"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 960,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 952,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 945,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "mt-1 text-xs text-muted-foreground",
										"data-tsd-source": "/src/components/UserProfile.tsx:963:19",
										children: ["Signed in as ", /* @__PURE__ */ _jsxDEV("span", {
											className: "font-semibold text-foreground",
											"data-tsd-source": "/src/components/UserProfile.tsx:964:34",
											children: user.email || user.id
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 964,
											columnNumber: 34
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 963,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 944,
									columnNumber: 17
								}, this),
								!isBrandMode && /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between rounded-lg border border-border p-3",
									"data-tsd-source": "/src/components/UserProfile.tsx:969:19",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-0.5 pr-3",
										"data-tsd-source": "/src/components/UserProfile.tsx:970:21",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-bold text-foreground",
											"data-tsd-source": "/src/components/UserProfile.tsx:971:23",
											children: "Public Voter Ledger Visibility"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 971,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-[11px] text-muted-foreground",
											"data-tsd-source": "/src/components/UserProfile.tsx:974:23",
											children: "Display your Stash/Trash tally on your public community profile."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 974,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 970,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV(Switch, {
										checked: prefs.publicVoterLedger,
										onCheckedChange: (checked) => handleUpdatePrefs({ publicVoterLedger: checked }),
										"data-tsd-source": "/src/components/UserProfile.tsx:978:21"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 978,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 969,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between rounded-lg border border-border p-3",
									"data-tsd-source": "/src/components/UserProfile.tsx:987:17",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										"data-tsd-source": "/src/components/UserProfile.tsx:988:19",
										children: [/* @__PURE__ */ _jsxDEV(Lock, {
											className: "h-4 w-4 text-muted-foreground",
											"data-tsd-source": "/src/components/UserProfile.tsx:989:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 989,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											"data-tsd-source": "/src/components/UserProfile.tsx:990:21",
											children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs font-bold text-foreground",
												"data-tsd-source": "/src/components/UserProfile.tsx:991:23",
												children: "Sign Out of SOrT"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 991,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-[11px] text-muted-foreground",
												"data-tsd-source": "/src/components/UserProfile.tsx:992:23",
												children: "End your active session on this browser."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 992,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 990,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 988,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV(Button, {
										type: "button",
										variant: "destructive",
										size: "sm",
										onClick: () => {
											setSettingsOpen(false);
											void signOut();
										},
										className: "h-8 gap-1.5 text-xs font-semibold",
										"data-tsd-source": "/src/components/UserProfile.tsx:997:19",
										children: [/* @__PURE__ */ _jsxDEV(LogOut, {
											className: "h-3.5 w-3.5",
											"data-tsd-source": "/src/components/UserProfile.tsx:1007:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1007,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											"data-tsd-source": "/src/components/UserProfile.tsx:1008:21",
											children: "Sign out"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1008,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 997,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 987,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 943,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 942,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 632,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 615,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 614,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 318,
		columnNumber: 5
	}, this);
}
_s(UserProfile, "ptfafTg1B8EuaSK89YpVAOlMRo8=", false, function() {
	return [
		useAuth,
		useRoles,
		useTranslation,
		useNavigate,
		useQueryClient,
		useQuery
	];
});
_c = UserProfile;
var _c;
$RefreshReg$(_c, "UserProfile");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/UserProfile.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/UserProfile.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/UserProfile.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/UserProfile.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQ0EsNEJBQ0EsNEJBQ0EsdUJBQ0EsdUJBQ0EsZ0NBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQ0EsY0FDQSxxQkFDQSxtQkFDQSxrQkFDQSxtQkFDQSx1QkFDQSwyQkFDQTtBQUNBLFNBQ0EsUUFDQSxlQUNBLG1CQUNBLGNBQ0EsY0FDQSxtQkFDQTtBQUNBO0FBQ0EsU0FDQSxNQUNBLFdBQ0EsT0FDQSxNQUNBLE9BQ0EsTUFDQSxPQUNBLGlCQUNBLE1BQ0EsUUFDQSxlQUNBLFVBQ0EsUUFDQSxhQUNBLE1BQ0EsZUFDQTtBQUNBOzs7O0FBU0E7QUFFQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0E7QUFFQTtDQUNBO0NBQ0E7RUFDQTtFQUNBO0VBQ0E7R0FBQTtHQUFBO0VBQUE7Q0FDQTtFQUNBO0NBQ0E7QUFDQTtBQUVBO0NBQ0E7Q0FDQTtFQUNBO0VBQ0E7Q0FDQSxTQUVBO0FBQ0E7Ozs7O0FBTUE7Q0FDQTtFQUNBO0VBQ0E7RUFDQTtDQUNBO0NBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDQTtDQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0E7Q0FDQTtFQUNBO0VBQ0E7RUFDQTtDQUNBO0FBQ0E7QUFFQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0VBQ0E7Q0FDQTtDQUNBO0FBQ0E7QUFFQSw4QkFDQSxvQkFDQSwrQkFJQTs7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBRUE7Q0FDQTtDQUNBOztDQUdBO0NBQ0E7Q0FDQTs7Q0FHQTtDQUNBO0NBQ0E7Q0FDQTs7Q0FHQTtDQUNBO0NBQ0E7O0NBR0E7Q0FDQTtDQUVBO0VBQ0E7RUFDQTtFQUNBO0NBQ0E7Q0FFQTtFQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtHQUNBO0dBQ0E7RUFDQTtDQUNBO0NBRUE7RUFDQTtFQUNBLHFCQUNBLHlCQUNBLG9CQUNBLG9DQUNBLDZCQUNBO0VBQ0EseUJBQ0Esc0JBQ0E7RUFDQTtFQUNBLHVCQUNBO0VBRUE7RUFDQTtFQUNBO0VBQ0E7Q0FDQTtDQUVBO0NBRUE7Q0FFQSwwQ0FDQSx1QkFDQSx5QkFDQSxvQkFDQSxvQ0FDQSw2QkFDQTtDQUVBLHFDQUNBLHFDQUNBO0NBRUEsd0NBQ0EsS0FDQTtDQUVBO0VBQ0E7RUFDQTtHQUNBO0lBQ0E7S0FDQTtLQUNBO0tBQ0E7SUFDQTtJQUNBO0tBQ0E7S0FDQTtLQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0E7SUFDQTtJQUNBLG9DQUNBLE9BQ0EsbUJBQ0EsZ0NBQ0E7SUFDQTtJQUNBO0lBRUE7S0FDQTtLQUNBO0tBQ0E7S0FDQTtLQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0E7R0FDQTtFQUNBO0dBQ0EsWUFDQSx1QkFDQSxjQUNBLG1GQUNBO0VBQ0E7R0FDQTtFQUNBO0NBQ0E7Q0FFQTtFQUNBO0VBQ0E7RUFDQTtHQUNBO0dBQ0E7RUFDQTtHQUNBO0VBQ0E7Q0FDQTtDQUVBO0VBQ0E7R0FBQTtHQUFBO0VBQUE7RUFDQTtFQUNBO0VBQ0E7Q0FDQTtDQUVBO0VBQ0E7R0FDQTtHQUNBO0VBQ0E7R0FDQTtFQUNBO0NBQ0E7Q0FFQTtDQUVBLE9BQ0EsZ0RBQ0EsdUJBQ0E7RUFBQTtZQUFBLENBQ0E7R0FBQTtHQUFBO2FBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQSxjQUNBLGlNQUNBLGNBQ0Esa0ZBQ0EseUVBQ0E7SUFDQTtjQVZBLENBV0E7S0FBQTtLQUFBO2VBQUEsQ0FDQSxvQkFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7S0FBa0I7Ozs7Z0JBQ2xCLE1BQ0E7TUFDQSxjQUNBLDZDQUNBLGNBQ0EsZ0NBQ0EsbUVBQ0E7TUFDQTtnQkFDQTtLQUNBOzs7O2FBQ0E7Ozs7O2NBR0E7S0FDQTtLQUNBLGNBQ0EsbUZBQ0EsY0FDQSxpQkFDQSxjQUNBLGlCQUNBLGdCQUNBO0tBQ0E7SUFBYzs7OztZQUNkOzs7Ozs7RUFDQTs7OztZQUVBO0dBQUE7R0FBQTtHQUFBO2FBQUE7SUFFQTtLQUNBLGNBQ0EsNENBQ0EsY0FDQSx1REFDQSxpQ0FDQTtLQUNBO2VBUEEsQ0FRQTtNQUFBO01BQUE7Z0JBQUEsQ0FDQSxvQkFDQTtPQUNBO09BQ0E7T0FDQTtPQUNBO09BQ0E7TUFBa0I7Ozs7aUJBQ2xCLE1BQ0E7T0FDQSxjQUNBLDBCQUNBLGNBQ0EsZ0NBQ0EsNkJBQ0E7T0FDQTtpQkFDQTtNQUNBOzs7O2NBQ0E7Ozs7O2VBQ0E7TUFBQTtNQUFBO2dCQUFBO09BQ0E7UUFBQTtRQUFBO2tCQUNBO09BQ0E7Ozs7O09BQ0E7UUFDQSxjQUNBLG9CQUNBLHdEQUNBO1FBQ0E7a0JBQ0E7T0FDQTs7Ozs7T0FDQSxjQUNBO1FBQ0EsY0FDQSx3QkFDQSwyREFDQTtRQUNBO2tCQUNBO09BQ0E7Ozs7O01BRUE7Ozs7O2FBQ0E7Ozs7OztJQUVBO0tBQUE7S0FBQTtJQUFzRDs7Ozs7SUFHdEQ7S0FBQTtlQUFBO01BQ0E7T0FDQTtPQUNBO09BQ0E7aUJBSEEsQ0FJQSxjQUNBO1FBQUE7UUFBQTtPQUFnRTs7OztrQkFFaEU7UUFBQTtRQUFBO09BQTZEOzs7O2lCQUU3RDtRQUFBO2tCQUNBLGNBQ0EsaUNBQ0E7T0FDQTs7OztlQUNBOzs7Ozs7TUFFQTtPQUNBO09BQ0E7T0FDQTtpQkFIQSxDQUlBO1FBQUE7UUFBQTtPQUFvRTs7OztpQkFDcEU7UUFBQTtrQkFDQSxjQUNBLHdCQUNBO09BQ0E7Ozs7ZUFDQTs7Ozs7O01BRUE7T0FDQTtRQUNBO1FBQ0E7T0FDQTtPQUNBO09BQ0E7aUJBTkEsQ0FPQTtRQUFBO1FBQUE7T0FBOEQ7Ozs7aUJBQzlEO1FBQUE7a0JBQXFCO09BQUE7Ozs7ZUFDckI7Ozs7OztNQUVBO09BQ0E7UUFDQTtRQUNBO09BQ0E7T0FDQTtPQUNBO2lCQU5BLENBT0E7UUFBQTtRQUFBO09BQW1FOzs7O2lCQUNuRTtRQUFBO2tCQUFxQjtPQUFBOzs7O2VBQ3JCOzs7Ozs7S0FDQTs7Ozs7O0lBRUE7S0FBQTtLQUFBO0lBQXNEOzs7OztJQUd0RDtLQUFBO2VBQUE7TUFDQTtPQUNBO09BQ0E7T0FDQTtpQkFIQSxDQUlBO1FBQUE7UUFBQTtPQUF5RTs7OztpQkFDekU7UUFBQTtrQkFBcUI7T0FBQTs7OztlQUNyQjs7Ozs7O01BQ0E7T0FDQTtPQUNBO09BQ0E7aUJBSEEsQ0FJQTtRQUFBO1FBQUE7T0FBZ0U7Ozs7aUJBQ2hFO1FBQUE7a0JBQXFCO09BQUE7Ozs7ZUFDckI7Ozs7OztNQUNBLFdBQ0E7T0FDQTtPQUNBO09BQ0E7aUJBSEEsQ0FJQTtRQUFBO1FBQUE7T0FBNkQ7Ozs7aUJBQzdEO1FBQUE7a0JBQXVCO09BQUE7Ozs7ZUFDdkI7Ozs7OztLQUVBOzs7Ozs7SUFHQSxlQUNBO0tBQ0E7TUFBQTtNQUFBO0tBQTBEOzs7OztLQUMxRDtNQUFBO01BQUE7Z0JBQTZIO0tBRTdIOzs7OztLQUNBO01BQ0E7T0FDQTtPQUNBO09BQ0EsV0FDQSx5QkFDQSxrRUFDQSw2Q0FDQTtNQUNBO01BQ0E7TUFDQTtnQkFDQSxjQUNBLGdEQUNBO09BQUE7T0FBQTtNQUFrRTs7OztnQkFDbEU7T0FBQTtpQkFBMkI7TUFBQTs7OztjQUMzQjs7OztpQkFFQSxnREFDQTtPQUFBO09BQUE7TUFBb0U7Ozs7Z0JBQ3BFO09BQUE7T0FBQTtpQkFBQSxDQUFnRDs7Ozs7Y0FDaEQ7Ozs7O0tBRUE7Ozs7O0tBRUE7TUFDQTtPQUNBO09BQ0E7T0FDQSxjQUNBLFdBQ0EsOERBQ0EsNERBQ0E7TUFDQTtNQUNBO01BQ0E7Z0JBWEEsQ0FZQTtPQUFBO09BQUE7TUFBMkQ7Ozs7Z0JBQzNEO09BQUE7aUJBQUEsQ0FBdUIsc0JBQ3ZCLHNGQUNBOzs7OztjQUNBOzs7Ozs7SUFDQTs7Ozs7SUFHQTtLQUFBO0tBQUE7SUFBc0Q7Ozs7O0lBRXREO0tBQ0E7S0FDQTtLQUNBO2VBSEEsQ0FJQTtNQUFBO01BQUE7S0FBMEM7Ozs7ZUFDMUM7TUFBQTtnQkFBbUI7S0FBQTs7OzthQUNuQjs7Ozs7O0dBQ0E7Ozs7O1VBQ0E7Ozs7Ozs7Q0FHQTtFQUFBO0VBQUE7WUFBQSxDQUNBO0dBQUE7R0FBQTthQUFBLENBQ0E7SUFBQTtJQUFBO2NBQUEsQ0FDQSxvQkFDQTtLQUNBO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7SUFBZ0I7Ozs7ZUFDaEIsTUFDQTtLQUFBO0tBQUE7ZUFDQTtJQUNBOzs7O1lBQ0E7Ozs7O2FBQ0E7SUFBQTtjQUFBLENBQ0E7S0FBQTtLQUFBO2VBQStEO0lBQUE7Ozs7Y0FDL0Q7S0FBQTtLQUFBO2VBQUEsQ0FDQSxnQkFDQSxvQ0FDQTs7Ozs7WUFDQTs7Ozs7V0FDQTs7Ozs7WUFDQTtHQUFBO0dBQUE7YUFDQTtJQUNBO0lBQ0E7SUFDQTtLQUNBO0tBQ0E7SUFDQTtJQUNBO0lBQ0E7Y0FSQSxDQVNBO0tBQUE7S0FBQTtJQUFnRDs7OztjQUNoRDtLQUFBO2VBQW1CO0lBQUE7Ozs7WUFDbkI7Ozs7OztFQUNBOzs7O1VBQ0E7Ozs7O1dBSUE7RUFBQTtFQUFBO0VBQUE7WUFDQTtHQUFBO0dBQUE7YUFBQSxDQUNBO0lBQUE7Y0FBQSxDQUNBO0tBQUE7S0FBQTtlQUFBLENBQ0E7TUFBQTtNQUFBO0tBQTJEOzs7O2VBQzNEO01BQUE7Z0JBQ0EsY0FDQSxxREFDQTtLQUNBOzs7O2FBQ0E7Ozs7O2NBQ0E7S0FBQTtLQUFBO2VBQ0EsY0FDQSx3R0FDQTtJQUNBOzs7O1lBQ0E7Ozs7O2FBRUE7SUFDQTtJQUNBO0lBQ0E7SUFDQTtjQUpBO0tBS0E7TUFBQTtNQUFBO2dCQUFBO09BQ0E7UUFBQTtRQUFBO1FBQUE7a0JBQ0E7T0FDQTs7Ozs7T0FDQTtRQUFBO1FBQUE7UUFBQTtrQkFBZ0Y7T0FFaEY7Ozs7O09BQ0E7UUFBQTtRQUFBO1FBQUE7a0JBQTZFO09BRTdFOzs7OztNQUNBOzs7Ozs7S0FHQTtNQUFBO01BQUE7TUFBQTtnQkFBQSxDQUNBLGNBQ0E7T0FBQTtPQUFBO2lCQUFBO1FBQ0E7U0FBQTtTQUFBO21CQUFBLENBQ0E7VUFBQTtVQUFBO29CQUFnRTtTQUVoRTs7OzttQkFDQTtVQUFBO1VBQUE7b0JBQUE7V0FBeUM7V0FDekM7V0FDQTtZQUFBO1lBQUE7c0JBQWlEO1dBQUE7Ozs7O1dBQUE7VUFFakQ7Ozs7O2lCQUNBOzs7Ozs7UUFFQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQTtVQUFBO1VBQUE7VUFBQTtvQkFBMEY7U0FFMUY7Ozs7bUJBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1NBQW9COzs7O2lCQUNwQjs7Ozs7O1FBRUE7U0FBQTtTQUFBO21CQUFBLENBQ0E7VUFBQTtVQUFBO29CQUFBLENBQ0E7V0FBQTtXQUFBO1dBQUE7cUJBQWdHO1VBRWhHOzs7O29CQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtVQUFzQjs7OztrQkFDdEI7Ozs7O21CQUNBO1VBQUE7VUFBQTtvQkFBQSxDQUNBO1dBQUE7V0FBQTtXQUFBO3FCQUErRjtVQUUvRjs7OztvQkFDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtVQUFzQjs7OztrQkFDdEI7Ozs7O2lCQUNBOzs7Ozs7UUFFQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQTtVQUFBO1VBQUE7b0JBQTREO1NBRTVEOzs7O21CQUNBO1VBQUE7VUFBQTtvQkFDQTtXQUNBO1dBQ0EsT0FDQTtZQUVBO1lBQ0E7YUFDQTthQUNBO2FBQ0E7WUFDQTtZQUNBLGNBQ0EsNkdBQ0EsWUFDQSw2Q0FDQSxxREFDQTtZQUNBO3NCQWRBLENBZUE7YUFBQTt1QkFBQSxDQUNBO2NBQUE7Y0FBQTt3QkFBc0Q7YUFBQTs7Ozt1QkFDdEQ7Y0FDQSxjQUNBLGVBQ0Esc0RBQ0E7Y0FDQTt3QkFMQTtlQU1BO2VBQUE7ZUFBQTtjQUNBOzs7OztxQkFDQTs7Ozs7c0JBQ0E7YUFBQTthQUFBO1lBQW9GOzs7O29CQUNwRjtjQTFCQTs7OztrQkEwQkE7VUFFQTtTQUNBOzs7O2lCQUNBOzs7Ozs7T0FDQTs7Ozs7aUJBRUE7T0FBQTtPQUFBO2lCQUFBO1FBRUE7U0FBQTtTQUFBO21CQUFBLENBQ0E7VUFBQTtVQUFBO29CQUFBLENBQ0EsaUJBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1VBQXdCOzs7O3FCQUN4QixNQUNBO1dBQUE7V0FBQTtxQkFDQTtVQUNBOzs7O2tCQUNBOzs7OzttQkFFQTtVQUFBO1VBQUE7b0JBQUEsQ0FDQTtXQUFBO1dBQUE7cUJBQTBFO1VBRTFFOzs7O29CQUNBO1dBQUE7V0FBQTtxQkFBQSxDQUNBO1lBQ0E7WUFDQSxPQUNBO2FBRUE7YUFDQTthQUNBO2FBQ0EsY0FDQSxxR0FDQSxXQUNBLCtCQUNBLGlEQUNBO2FBQ0E7dUJBQ0E7Y0FDQTtjQUNBO2NBQ0E7Y0FDQTtjQUNBO2FBQThCOzs7OztZQUM5QixHQWpCQTs7OzttQkFpQkE7V0FFQSxJQUNBLGtCQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7WUFDQTtZQUNBO3NCQUEwQjtXQUUxQjs7OzttQkFFQTs7Ozs7a0JBQ0E7Ozs7O2lCQUNBOzs7Ozs7UUFFQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQTtVQUFBO1VBQUE7b0JBQUEsQ0FDQTtXQUFBO1dBQUE7V0FBQTtxQkFDQTtVQUNBOzs7O29CQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtVQUFzQjs7OztrQkFDdEI7Ozs7O21CQUNBO1VBQUE7VUFBQTtvQkFBQSxDQUNBO1dBQUE7V0FBQTtXQUFBO3FCQUFvRjtVQUVwRjs7OztvQkFDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtVQUFzQjs7OztrQkFDdEI7Ozs7O2lCQUNBOzs7Ozs7UUFFQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQTtVQUFBO1VBQUE7VUFBQTtvQkFDQTtTQUNBOzs7O21CQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQSxpQ0FDQSx5REFDQTtVQUNBO1VBQ0E7U0FBb0I7Ozs7aUJBQ3BCOzs7Ozs7UUFFQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQTtVQUFBO1VBQUE7VUFBQTtvQkFDQTtTQUNBOzs7O21CQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1NBQW9COzs7O2lCQUNwQjs7Ozs7O09BQ0E7Ozs7O2dCQUdBO09BQUE7T0FBQTtpQkFBQSxDQUNBO1FBQUE7UUFBQTtRQUFBO1FBQUE7a0JBQTBGO09BRTFGOzs7O2lCQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtrQkFDQTtPQUNBOzs7O2VBQ0E7Ozs7O2NBQ0E7Ozs7OztLQUdBO01BQUE7TUFBQTtNQUFBO2dCQUNBO09BQUE7T0FBQTtpQkFBQTtRQUNBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtvQkFBQSxDQUNBO1dBQUE7V0FBQTtxQkFBb0U7VUFFcEU7Ozs7b0JBQ0E7V0FBQTtXQUFBO3FCQUFvRTtVQUVwRTs7OztrQkFDQTs7Ozs7bUJBQ0E7VUFBQTtVQUFBO1VBQUE7U0FBcUY7Ozs7aUJBQ3JGOzs7Ozs7UUFFQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQTtVQUFBO1VBQUE7b0JBQUEsQ0FDQTtXQUFBO1dBQUE7cUJBQW9FO1VBRXBFOzs7O29CQUNBO1dBQUE7V0FBQTtxQkFBb0U7VUFFcEU7Ozs7a0JBQ0E7Ozs7O21CQUNBO1VBQ0E7VUFDQTtVQUNBO1NBQWtCOzs7O2lCQUNsQjs7Ozs7O1FBRUE7U0FBQTtTQUFBO21CQUFBLENBQ0E7VUFBQTtVQUFBO29CQUNBO1dBQUE7V0FBQTtxQkFBQSxDQUNBO1lBQUE7WUFBQTtXQUFvRTs7OztxQkFDcEU7WUFBQTtzQkFBQTthQUEyQjthQUFBO2FBQUE7WUFBQTs7Ozs7bUJBQzNCOzs7Ozs7U0FDQTs7OzttQkFDQTtVQUFBO1VBQUE7b0JBQ0E7V0FDQTtXQUNBLE9BQ0E7WUFFQTtZQUNBO2FBQ0E7YUFDQTtZQUNBO1lBQ0EsY0FDQSwwRUFDQSxTQUNBLGdDQUNBLHlFQUNBO1lBQ0E7c0JBQ0E7V0FDQSxHQWRBOzs7O2tCQWNBO1VBRUE7U0FDQTs7OztpQkFDQTs7Ozs7O09BQ0E7Ozs7OztLQUNBOzs7OztLQUdBO01BQUE7TUFBQTtNQUFBO2dCQUNBO09BQUE7T0FBQTtpQkFBQTtRQUNBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtvQkFBQSxDQUNBO1dBQUE7V0FBQTtxQkFBQSxDQUNBO1lBQUE7WUFBQTtXQUF3RTs7OztxQkFDeEU7WUFBQTtZQUFBO3NCQUF5RTtXQUV6RTs7OzttQkFDQTs7Ozs7b0JBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7cUJBTkEsQ0FPQTtZQUFBO1lBQUE7V0FBZ0Q7Ozs7cUJBQ2hEO1lBQUE7c0JBQTJCO1dBQUE7Ozs7bUJBQzNCOzs7OztrQkFDQTs7Ozs7bUJBQ0E7VUFBQTtVQUFBO29CQUFBLENBQW1FLGlCQUNuRTtXQUFBO1dBQUE7cUJBQWdGO1VBQUE7Ozs7a0JBQ2hGOzs7OztpQkFDQTs7Ozs7O1FBRUEsZ0JBQ0E7U0FBQTtTQUFBO21CQUFBLENBQ0E7VUFBQTtVQUFBO29CQUFBLENBQ0E7V0FBQTtXQUFBO3FCQUFzRTtVQUV0RTs7OztvQkFDQTtXQUFBO1dBQUE7cUJBQXNFO1VBRXRFOzs7O2tCQUNBOzs7OzttQkFDQTtVQUNBO1VBQ0EsOEJBQ0E7VUFFQTtTQUFvQjs7OztpQkFDcEI7Ozs7OztRQUdBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtvQkFBQSxDQUNBO1dBQUE7V0FBQTtVQUFvRTs7OztvQkFDcEU7V0FBQTtxQkFBQSxDQUNBO1lBQUE7WUFBQTtzQkFBc0U7V0FBQTs7OztxQkFDdEU7WUFBQTtZQUFBO3NCQUFzRTtXQUV0RTs7OzttQkFDQTs7Ozs7a0JBQ0E7Ozs7O21CQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7V0FDQTtXQUNBO1VBQ0E7VUFDQTtVQUNBO29CQVRBLENBVUE7V0FBQTtXQUFBO1VBQW9EOzs7O29CQUNwRDtXQUFBO3FCQUF5QjtVQUFBOzs7O2tCQUN6Qjs7Ozs7aUJBQ0E7Ozs7OztPQUNBOzs7Ozs7S0FDQTs7Ozs7SUFDQTs7Ozs7V0FDQTs7Ozs7O0NBQ0E7Ozs7U0FDQTs7Ozs7QUFFQSIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVXNlclByb2ZpbGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1yb3V0ZXJcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcbmltcG9ydCB7IHVzZVRyYW5zbGF0aW9uIH0gZnJvbSBcInJlYWN0LWkxOG5leHRcIjtcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSBcInNvbm5lclwiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCJAL2hvb2tzL3VzZUF1dGhcIjtcbmltcG9ydCB7IHVzZVJvbGVzIH0gZnJvbSBcIkAvaG9va3MvdXNlUm9sZXNcIjtcbmltcG9ydCB7IGdldFB1YmxpY1Byb2ZpbGUsIHVwZGF0ZU15UHJvZmlsZSB9IGZyb20gXCJAL2xpYi9zb2NpYWxcIjtcbmltcG9ydCB7XG4gIGdldFJlZ2lzdGVyZWRCcmFuZElkZW50aXR5LFxuICBzZXRSZWdpc3RlcmVkQnJhbmRJZGVudGl0eSxcbiAgZ2V0QWN0aXZlRGVza09wZXJhdG9yLFxuICBnZXRCcmFuZERlc2tPcGVyYXRvcnMsXG4gIHN3aXRjaEFjdGl2ZURlc2tPcGVyYXRvcixcbn0gZnJvbSBcIkAvbGliL2JyYW5kLW9wZXJhdG9yc1wiO1xuaW1wb3J0IHsgaXNWZXJkaWN0U291bmRFbmFibGVkLCBzZXRWZXJkaWN0U291bmRFbmFibGVkLCBwbGF5Q29pblNwaW5Tb3VuZCB9IGZyb20gXCJAL2xpYi92ZXJkaWN0LXNvdW5kc1wiO1xuaW1wb3J0IHsgaXNEZXZlbG9wZXJDb2RlSW5zcGVjdGlvbkFjdGl2ZSwgdG9nZ2xlRGV2ZWxvcGVyQ29kZUluc3BlY3Rpb24gfSBmcm9tIFwiQC9saWIvc2VjdXJpdHktc2hpZWxkXCI7XG5pbXBvcnQgeyBBUFBfU1VQUE9SVEVEX0xPQ0FMRVMgfSBmcm9tIFwiQC9saWIvbG9jYWxlLWFwcFwiO1xuaW1wb3J0IHsgc3dpdGNoQXBwTGFuZ3VhZ2UgfSBmcm9tIFwiQC9jb21wb25lbnRzL0xhbmd1YWdlU3dpdGNoZXJcIjtcbmltcG9ydCB7IEF2YXRhciwgQXZhdGFyRmFsbGJhY2ssIEF2YXRhckltYWdlIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9hdmF0YXJcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvaW5wdXRcIjtcbmltcG9ydCB7IExhYmVsIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9sYWJlbFwiO1xuaW1wb3J0IHsgVGV4dGFyZWEgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL3RleHRhcmVhXCI7XG5pbXBvcnQgeyBTd2l0Y2ggfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL3N3aXRjaFwiO1xuaW1wb3J0IHtcbiAgRHJvcGRvd25NZW51LFxuICBEcm9wZG93bk1lbnVDb250ZW50LFxuICBEcm9wZG93bk1lbnVHcm91cCxcbiAgRHJvcGRvd25NZW51SXRlbSxcbiAgRHJvcGRvd25NZW51TGFiZWwsXG4gIERyb3Bkb3duTWVudVNlcGFyYXRvcixcbiAgRHJvcGRvd25NZW51VHJpZ2dlcixcbn0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9kcm9wZG93bi1tZW51XCI7XG5pbXBvcnQge1xuICBEaWFsb2csXG4gIERpYWxvZ0NvbnRlbnQsXG4gIERpYWxvZ0Rlc2NyaXB0aW9uLFxuICBEaWFsb2dGb290ZXIsXG4gIERpYWxvZ0hlYWRlcixcbiAgRGlhbG9nVGl0bGUsXG59IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvZGlhbG9nXCI7XG5pbXBvcnQgeyBUYWJzLCBUYWJzQ29udGVudCwgVGFic0xpc3QsIFRhYnNUcmlnZ2VyIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS90YWJzXCI7XG5pbXBvcnQge1xuICBCZWxsLFxuICBCdWlsZGluZzIsXG4gIENoZWNrLFxuICBDb2RlLFxuICBDb2lucyxcbiAgQ29weSxcbiAgR2xvYmUsXG4gIExheW91dERhc2hib2FyZCxcbiAgTG9jayxcbiAgTG9nT3V0LFxuICBNZXNzYWdlQ2lyY2xlLFxuICBTZXR0aW5ncyxcbiAgU2hpZWxkLFxuICBTaGllbGRDaGVjayxcbiAgVXNlcixcbiAgVm9sdW1lMixcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcblxuZXhwb3J0IGludGVyZmFjZSBBY2NvdW50UHJlZmVyZW5jZXMge1xuICBjYWxsUmluZ0FsZXJ0czogYm9vbGVhbjtcbiAgZG1SZXF1ZXN0RmlsdGVyOiBcImV2ZXJ5b25lXCIgfCBcImNvbm5lY3Rpb25zXCI7XG4gIHB1YmxpY1ZvdGVyTGVkZ2VyOiBib29sZWFuO1xuICBkZWZhdWx0RmVlZEZpbHRlcjogXCJhbGxcIiB8IFwic3Rhc2hcIiB8IFwidHJhc2hcIjtcbn1cblxuY29uc3QgQUNDT1VOVF9QUkVGU19LRVkgPSBcInNvdF9hY2NvdW50X3ByZWZlcmVuY2VzX3YxXCI7XG5cbmNvbnN0IERFRkFVTFRfUFJFRlM6IEFjY291bnRQcmVmZXJlbmNlcyA9IHtcbiAgY2FsbFJpbmdBbGVydHM6IHRydWUsXG4gIGRtUmVxdWVzdEZpbHRlcjogXCJldmVyeW9uZVwiLFxuICBwdWJsaWNWb3RlckxlZGdlcjogdHJ1ZSxcbiAgZGVmYXVsdEZlZWRGaWx0ZXI6IFwiYWxsXCIsXG59O1xuXG5leHBvcnQgZnVuY3Rpb24gZ2V0QWNjb3VudFByZWZlcmVuY2VzKCk6IEFjY291bnRQcmVmZXJlbmNlcyB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gREVGQVVMVF9QUkVGUztcbiAgdHJ5IHtcbiAgICBjb25zdCByYXcgPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oQUNDT1VOVF9QUkVGU19LRVkpO1xuICAgIGlmICghcmF3KSByZXR1cm4gREVGQVVMVF9QUkVGUztcbiAgICByZXR1cm4geyAuLi5ERUZBVUxUX1BSRUZTLCAuLi4oSlNPTi5wYXJzZShyYXcpIGFzIFBhcnRpYWw8QWNjb3VudFByZWZlcmVuY2VzPikgfTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIERFRkFVTFRfUFJFRlM7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNhdmVBY2NvdW50UHJlZmVyZW5jZXMocHJlZnM6IEFjY291bnRQcmVmZXJlbmNlcykge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuO1xuICB0cnkge1xuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShBQ0NPVU5UX1BSRUZTX0tFWSwgSlNPTi5zdHJpbmdpZnkocHJlZnMpKTtcbiAgICB3aW5kb3cuZGlzcGF0Y2hFdmVudChuZXcgQ3VzdG9tRXZlbnQoXCJzb3QtYWNjb3VudC1wcmVmcy11cGRhdGVkXCIsIHsgZGV0YWlsOiBwcmVmcyB9KSk7XG4gIH0gY2F0Y2gge1xuICAgIC8vIGlnbm9yZSBzdG9yYWdlIGVycm9yc1xuICB9XG59XG5cbi8qKlxuICogU2VsZi1jb250YWluZWQgU1ZHIGRhdGEtVVJJIGF2YXRhcnMgKDwgMzAwIGNoYXJzIGVhY2gsIGFkaGVyaW5nIHN0cmljdGx5IHRvXG4gKiBmaXJlYmFzZS1ibHVlcHJpbnQuanNvbiBVc2VyUHJvZmlsZS5hdmF0YXJVcmwgbWF4TGVuZ3RoOiA1MDAgYW5kIFplcm8tQnJva2VuLUltYWdlIHBvbGljeSkuXG4gKi9cbmNvbnN0IFBSRVNFVF9BVkFUQVJTOiB7IGlkOiBzdHJpbmc7IGxhYmVsOiBzdHJpbmc7IHVybDogc3RyaW5nIH1bXSA9IFtcbiAge1xuICAgIGlkOiBcImdvbGQtd2F0Y2hkb2dcIixcbiAgICBsYWJlbDogXCJHb2xkIEFyYml0cmF0b3JcIixcbiAgICB1cmw6IGBkYXRhOmltYWdlL3N2Zyt4bWw7dXRmOCw8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2aWV3Qm94PVwiMCAwIDgwIDgwXCI+PHJlY3Qgd2lkdGg9XCI4MFwiIGhlaWdodD1cIjgwXCIgcng9XCI0MFwiIGZpbGw9XCIlMjMwZjE3MmFcIi8+PGNpcmNsZSBjeD1cIjQwXCIgY3k9XCIzMFwiIHI9XCIxNFwiIGZpbGw9XCIlMjNkNmE5MjhcIi8+PHBhdGggZD1cIk0xNiA3MGM0LTE0IDE0LTIyIDI0LTIyczIwIDggMjQgMjJcIiBmaWxsPVwiJTIzZDZhOTI4XCIvPjwvc3ZnPmAsXG4gIH0sXG4gIHtcbiAgICBpZDogXCJlbWVyYWxkLXN0YXNoXCIsXG4gICAgbGFiZWw6IFwiRW1lcmFsZCBTdGFzaFwiLFxuICAgIHVybDogYGRhdGE6aW1hZ2Uvc3ZnK3htbDt1dGY4LDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgODAgODBcIj48cmVjdCB3aWR0aD1cIjgwXCIgaGVpZ2h0PVwiODBcIiByeD1cIjQwXCIgZmlsbD1cIiUyMzA2NGUzYlwiLz48Y2lyY2xlIGN4PVwiNDBcIiBjeT1cIjMwXCIgcj1cIjE0XCIgZmlsbD1cIiUyMzM0ZDM5OVwiLz48cGF0aCBkPVwiTTE2IDcwYzQtMTQgMTQtMjIgMjQtMjJzMjAgOCAyNCAyMlwiIGZpbGw9XCIlMjMzNGQzOTlcIi8+PC9zdmc+YCxcbiAgfSxcbiAge1xuICAgIGlkOiBcInJveWFsLXNoaWVsZFwiLFxuICAgIGxhYmVsOiBcIkNvYmFsdCBHdWFyZGlhblwiLFxuICAgIHVybDogYGRhdGE6aW1hZ2Uvc3ZnK3htbDt1dGY4LDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgODAgODBcIj48cmVjdCB3aWR0aD1cIjgwXCIgaGVpZ2h0PVwiODBcIiByeD1cIjQwXCIgZmlsbD1cIiUyMzFlM2E4YVwiLz48Y2lyY2xlIGN4PVwiNDBcIiBjeT1cIjMwXCIgcj1cIjE0XCIgZmlsbD1cIiUyMzkzYzVmZFwiLz48cGF0aCBkPVwiTTE2IDcwYzQtMTQgMTQtMjIgMjQtMjJzMjAgOCAyNCAyMlwiIGZpbGw9XCIlMjM5M2M1ZmRcIi8+PC9zdmc+YCxcbiAgfSxcbiAge1xuICAgIGlkOiBcImNyaW1zb24tY3JpdGljXCIsXG4gICAgbGFiZWw6IFwiQ3JpbXNvbiBBdWRpdG9yXCIsXG4gICAgdXJsOiBgZGF0YTppbWFnZS9zdmcreG1sO3V0ZjgsPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCA4MCA4MFwiPjxyZWN0IHdpZHRoPVwiODBcIiBoZWlnaHQ9XCI4MFwiIHJ4PVwiNDBcIiBmaWxsPVwiJTIzN2YxZDFkXCIvPjxjaXJjbGUgY3g9XCI0MFwiIGN5PVwiMzBcIiByPVwiMTRcIiBmaWxsPVwiJTIzZmNhNWE1XCIvPjxwYXRoIGQ9XCJNMTYgNzBjNC0xNCAxNC0yMiAyNC0yMnMyMCA4IDI0IDIyXCIgZmlsbD1cIiUyM2ZjYTVhNVwiLz48L3N2Zz5gLFxuICB9LFxuXTtcblxuZnVuY3Rpb24gZ2V0SW5pdGlhbHMobmFtZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgY2xlYW4gPSBuYW1lLnRyaW0oKTtcbiAgaWYgKCFjbGVhbikgcmV0dXJuIFwiU1RcIjtcbiAgY29uc3QgcGFydHMgPSBjbGVhbi5zcGxpdCgvXFxzKy8pLmZpbHRlcihCb29sZWFuKTtcbiAgaWYgKHBhcnRzLmxlbmd0aCA+PSAyKSB7XG4gICAgcmV0dXJuIGAke3BhcnRzWzBdWzBdfSR7cGFydHNbMV1bMF19YC50b1VwcGVyQ2FzZSgpO1xuICB9XG4gIHJldHVybiBjbGVhbi5zbGljZSgwLCAyKS50b1VwcGVyQ2FzZSgpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gVXNlclByb2ZpbGUoe1xuICB2YXJpYW50ID0gXCJuYXZiYXJcIixcbiAgZGVmYXVsdFNldHRpbmdzT3BlbiA9IGZhbHNlLFxufToge1xuICB2YXJpYW50PzogXCJuYXZiYXJcIiB8IFwiY2FyZFwiO1xuICBkZWZhdWx0U2V0dGluZ3NPcGVuPzogYm9vbGVhbjtcbn0pIHtcbiAgY29uc3QgeyB1c2VyLCBzaWduT3V0IH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IHsgaXNBZG1pbiwgaXNEZXZlbG9wZXIsIHBlcnNvbmEsIHNldFBlcnNvbmEgfSA9IHVzZVJvbGVzKCk7XG4gIGNvbnN0IHsgdCwgaTE4biB9ID0gdXNlVHJhbnNsYXRpb24oKTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XG5cbiAgY29uc3QgW3NldHRpbmdzT3Blbiwgc2V0U2V0dGluZ3NPcGVuXSA9IHVzZVN0YXRlKGRlZmF1bHRTZXR0aW5nc09wZW4pO1xuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGU8XCJwcm9maWxlXCIgfCBcInByZWZlcmVuY2VzXCIgfCBcInNlY3VyaXR5XCI+KFwicHJvZmlsZVwiKTtcbiAgY29uc3QgW3NhdmluZywgc2V0U2F2aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyBCcmFuZCBpZGVudGl0eSAmIG9wZXJhdG9yIHN0YXRlIChzdHJpY3RseSB1c2VkIHdoZW4gcGVyc29uYSA9PT0gXCJicmFuZF9vd25lclwiKVxuICBjb25zdCBbcmVnaXN0ZXJlZEJyYW5kLCBzZXRSZWdpc3RlcmVkQnJhbmRTdGF0ZV0gPSB1c2VTdGF0ZSgoKSA9PiBnZXRSZWdpc3RlcmVkQnJhbmRJZGVudGl0eSgpKTtcbiAgY29uc3QgW2FjdGl2ZU9wZXJhdG9yLCBzZXRBY3RpdmVPcGVyYXRvclN0YXRlXSA9IHVzZVN0YXRlKCgpID0+IGdldEFjdGl2ZURlc2tPcGVyYXRvcigpKTtcbiAgY29uc3QgW29wZXJhdG9ycywgc2V0T3BlcmF0b3JzU3RhdGVdID0gdXNlU3RhdGUoKCkgPT4gZ2V0QnJhbmREZXNrT3BlcmF0b3JzKCkpO1xuXG4gIC8vIEZvcm0gc3RhdGVzIGZvciBQZXJzb25hbCBQcm9maWxlXG4gIGNvbnN0IFtkaXNwbGF5TmFtZUlucHV0LCBzZXREaXNwbGF5TmFtZUlucHV0XSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbdXNlcm5hbWVJbnB1dCwgc2V0VXNlcm5hbWVJbnB1dF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2Jpb0lucHV0LCBzZXRCaW9JbnB1dF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2F2YXRhclVybElucHV0LCBzZXRBdmF0YXJVcmxJbnB1dF0gPSB1c2VTdGF0ZShcIlwiKTtcblxuICAvLyBGb3JtIHN0YXRlcyBmb3IgQnJhbmQgUHJvZmlsZSAod2hlbiBwZXJzb25hID09PSBcImJyYW5kX293bmVyXCIpXG4gIGNvbnN0IFticmFuZE5hbWVJbnB1dCwgc2V0QnJhbmROYW1lSW5wdXRdID0gdXNlU3RhdGUocmVnaXN0ZXJlZEJyYW5kLm5hbWUpO1xuICBjb25zdCBbYnJhbmRDYXRlZ29yeUlucHV0LCBzZXRCcmFuZENhdGVnb3J5SW5wdXRdID0gdXNlU3RhdGUocmVnaXN0ZXJlZEJyYW5kLmNhdGVnb3J5KTtcbiAgY29uc3QgW2JyYW5kV2Vic2l0ZUlucHV0LCBzZXRCcmFuZFdlYnNpdGVJbnB1dF0gPSB1c2VTdGF0ZShyZWdpc3RlcmVkQnJhbmQud2Vic2l0ZSk7XG5cbiAgLy8gUHJlZmVyZW5jZXMgc3RhdGVcbiAgY29uc3QgW3NvdW5kRW5hYmxlZCwgc2V0U291bmRFbmFibGVkXSA9IHVzZVN0YXRlKCgpID0+IGlzVmVyZGljdFNvdW5kRW5hYmxlZCgpKTtcbiAgY29uc3QgW3ByZWZzLCBzZXRQcmVmc10gPSB1c2VTdGF0ZTxBY2NvdW50UHJlZmVyZW5jZXM+KCgpID0+IGdldEFjY291bnRQcmVmZXJlbmNlcygpKTtcblxuICBjb25zdCB7IGRhdGE6IHByb2ZpbGUgfSA9IHVzZVF1ZXJ5KHtcbiAgICBxdWVyeUtleTogW1wibXktcHJvZmlsZVwiLCB1c2VyPy5pZF0sXG4gICAgcXVlcnlGbjogKCkgPT4gZ2V0UHVibGljUHJvZmlsZSh1c2VyIS5pZCksXG4gICAgZW5hYmxlZDogISF1c2VyPy5pZCxcbiAgfSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBzeW5jQnJhbmRBbmRPcHMgPSAoKSA9PiB7XG4gICAgICBjb25zdCBuZXh0QnJhbmQgPSBnZXRSZWdpc3RlcmVkQnJhbmRJZGVudGl0eSgpO1xuICAgICAgc2V0UmVnaXN0ZXJlZEJyYW5kU3RhdGUobmV4dEJyYW5kKTtcbiAgICAgIHNldEJyYW5kTmFtZUlucHV0KG5leHRCcmFuZC5uYW1lKTtcbiAgICAgIHNldEJyYW5kQ2F0ZWdvcnlJbnB1dChuZXh0QnJhbmQuY2F0ZWdvcnkpO1xuICAgICAgc2V0QnJhbmRXZWJzaXRlSW5wdXQobmV4dEJyYW5kLndlYnNpdGUpO1xuICAgICAgc2V0QWN0aXZlT3BlcmF0b3JTdGF0ZShnZXRBY3RpdmVEZXNrT3BlcmF0b3IoKSk7XG4gICAgICBzZXRPcGVyYXRvcnNTdGF0ZShnZXRCcmFuZERlc2tPcGVyYXRvcnMoKSk7XG4gICAgfTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInNvdC1yZWdpc3RlcmVkLWJyYW5kLXVwZGF0ZWRcIiwgc3luY0JyYW5kQW5kT3BzKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInNvdC1icmFuZC1vcGVyYXRvci11cGRhdGVkXCIsIHN5bmNCcmFuZEFuZE9wcyk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwic290LXJlZ2lzdGVyZWQtYnJhbmQtdXBkYXRlZFwiLCBzeW5jQnJhbmRBbmRPcHMpO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJzb3QtYnJhbmQtb3BlcmF0b3ItdXBkYXRlZFwiLCBzeW5jQnJhbmRBbmRPcHMpO1xuICAgIH07XG4gIH0sIFtdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghdXNlcikgcmV0dXJuO1xuICAgIGNvbnN0IHJlc29sdmVkTmFtZSA9XG4gICAgICBwcm9maWxlPy5kaXNwbGF5X25hbWUgfHxcbiAgICAgIHVzZXIuZGlzcGxheU5hbWUgfHxcbiAgICAgIHVzZXIudXNlcl9tZXRhZGF0YT8uZGlzcGxheV9uYW1lIHx8XG4gICAgICB1c2VyLmVtYWlsPy5zcGxpdChcIkBcIilbMF0gfHxcbiAgICAgIFwiVmVyaWZpZWQgVm90ZXJcIjtcbiAgICBjb25zdCByZXNvbHZlZFVzZXJuYW1lID1cbiAgICAgIHByb2ZpbGU/LnVzZXJuYW1lIHx8XG4gICAgICAodXNlci5lbWFpbCA/IHVzZXIuZW1haWwuc3BsaXQoXCJAXCIpWzBdLnJlcGxhY2UoL1teYS16QS1aMC05Xy4tXS9nLCBcIlwiKSA6IFwidm90ZXJcIik7XG4gICAgY29uc3QgcmVzb2x2ZWRCaW8gPSBwcm9maWxlPy5iaW8gPz8gXCJcIjtcbiAgICBjb25zdCByZXNvbHZlZEF2YXRhciA9XG4gICAgICBwcm9maWxlPy5hdmF0YXJfdXJsIHx8IHVzZXIucGhvdG9VUkwgfHwgdXNlci51c2VyX21ldGFkYXRhPy5hdmF0YXJfdXJsIHx8IFwiXCI7XG5cbiAgICBzZXREaXNwbGF5TmFtZUlucHV0KHJlc29sdmVkTmFtZSk7XG4gICAgc2V0VXNlcm5hbWVJbnB1dChyZXNvbHZlZFVzZXJuYW1lKTtcbiAgICBzZXRCaW9JbnB1dChyZXNvbHZlZEJpbyk7XG4gICAgc2V0QXZhdGFyVXJsSW5wdXQocmVzb2x2ZWRBdmF0YXIpO1xuICB9LCBbdXNlciwgcHJvZmlsZV0pO1xuXG4gIGlmICghdXNlcikgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgaXNCcmFuZE1vZGUgPSBwZXJzb25hID09PSBcImJyYW5kX293bmVyXCI7XG5cbiAgY29uc3QgcmVzb2x2ZWREaXNwbGF5TmFtZSA9IGlzQnJhbmRNb2RlXG4gICAgPyByZWdpc3RlcmVkQnJhbmQubmFtZVxuICAgIDogcHJvZmlsZT8uZGlzcGxheV9uYW1lIHx8XG4gICAgICB1c2VyLmRpc3BsYXlOYW1lIHx8XG4gICAgICB1c2VyLnVzZXJfbWV0YWRhdGE/LmRpc3BsYXlfbmFtZSB8fFxuICAgICAgdXNlci5lbWFpbD8uc3BsaXQoXCJAXCIpWzBdIHx8XG4gICAgICBcIlZlcmlmaWVkIFZvdGVyXCI7XG5cbiAgY29uc3QgcmVzb2x2ZWRIYW5kbGUgPSBpc0JyYW5kTW9kZVxuICAgID8gYE9QLVNFQVQgwrcgJHthY3RpdmVPcGVyYXRvci5uYW1lfWBcbiAgICA6IGBAJHtwcm9maWxlPy51c2VybmFtZSB8fCB1c2VyLmVtYWlsPy5zcGxpdChcIkBcIilbMF0gfHwgXCJtZW1iZXJcIn1gO1xuXG4gIGNvbnN0IHJlc29sdmVkQXZhdGFyVXJsID0gaXNCcmFuZE1vZGVcbiAgICA/IFwiXCJcbiAgICA6IHByb2ZpbGU/LmF2YXRhcl91cmwgfHwgdXNlci5waG90b1VSTCB8fCB1c2VyLnVzZXJfbWV0YWRhdGE/LmF2YXRhcl91cmwgfHwgXCJcIjtcblxuICBjb25zdCBoYW5kbGVTYXZlUHJvZmlsZVNldHRpbmdzID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldFNhdmluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgaWYgKGlzQnJhbmRNb2RlKSB7XG4gICAgICAgIGlmICghYnJhbmROYW1lSW5wdXQudHJpbSgpKSB7XG4gICAgICAgICAgdG9hc3QuZXJyb3IoXCJCcmFuZCBuYW1lIGNhbm5vdCBiZSBlbXB0eS5cIik7XG4gICAgICAgICAgc2V0U2F2aW5nKGZhbHNlKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdXBkYXRlZEJyYW5kID0gc2V0UmVnaXN0ZXJlZEJyYW5kSWRlbnRpdHkoe1xuICAgICAgICAgIG5hbWU6IGJyYW5kTmFtZUlucHV0LnRyaW0oKS5zbGljZSgwLCAxMjApLFxuICAgICAgICAgIGNhdGVnb3J5OiBicmFuZENhdGVnb3J5SW5wdXQudHJpbSgpLnNsaWNlKDAsIDgwKSB8fCBcIkNvbnN1bWVyIEJyYW5kXCIsXG4gICAgICAgICAgd2Vic2l0ZTogYnJhbmRXZWJzaXRlSW5wdXQudHJpbSgpLnNsaWNlKDAsIDI1MCksXG4gICAgICAgIH0pO1xuICAgICAgICBzZXRSZWdpc3RlcmVkQnJhbmRTdGF0ZSh1cGRhdGVkQnJhbmQpO1xuICAgICAgICB0b2FzdC5zdWNjZXNzKGBVcGRhdGVkIEJyYW5kIEFjY291bnQgc2V0dGluZ3MgZm9yICR7dXBkYXRlZEJyYW5kLm5hbWV9LmApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgY2xlYW5OYW1lID0gZGlzcGxheU5hbWVJbnB1dC50cmltKCkuc2xpY2UoMCwgNjApIHx8IFwiVmVyaWZpZWQgVm90ZXJcIjtcbiAgICAgICAgY29uc3QgY2xlYW5Vc2VybmFtZSA9IHVzZXJuYW1lSW5wdXRcbiAgICAgICAgICAudHJpbSgpXG4gICAgICAgICAgLnJlcGxhY2UoL15AKy8sIFwiXCIpXG4gICAgICAgICAgLnJlcGxhY2UoL1teYS16QS1aMC05Xy4tXS9nLCBcIlwiKVxuICAgICAgICAgIC5zbGljZSgwLCA1MCk7XG4gICAgICAgIGNvbnN0IGNsZWFuQmlvID0gYmlvSW5wdXQudHJpbSgpLnNsaWNlKDAsIDI4MCk7XG4gICAgICAgIGNvbnN0IGNsZWFuQXZhdGFyID0gYXZhdGFyVXJsSW5wdXQudHJpbSgpLnNsaWNlKDAsIDUwMCk7XG5cbiAgICAgICAgYXdhaXQgdXBkYXRlTXlQcm9maWxlKHtcbiAgICAgICAgICB1c2VySWQ6IHVzZXIuaWQsXG4gICAgICAgICAgZGlzcGxheV9uYW1lOiBjbGVhbk5hbWUsXG4gICAgICAgICAgdXNlcm5hbWU6IGNsZWFuVXNlcm5hbWUsXG4gICAgICAgICAgYmlvOiBjbGVhbkJpbyxcbiAgICAgICAgICBhdmF0YXJfdXJsOiBjbGVhbkF2YXRhcixcbiAgICAgICAgfSk7XG4gICAgICAgIGF3YWl0IHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFtcIm15LXByb2ZpbGVcIiwgdXNlci5pZF0gfSk7XG4gICAgICAgIHRvYXN0LnN1Y2Nlc3ModChcInNvY2lhbC5wcm9maWxlU2F2ZWRcIiwgeyBkZWZhdWx0VmFsdWU6IFwiUHJvZmlsZSBhbmQgYXZhdGFyIHNhdmVkLlwiIH0pKTtcbiAgICAgIH1cbiAgICAgIHNldFNldHRpbmdzT3BlbihmYWxzZSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0b2FzdC5lcnJvcihcbiAgICAgICAgZXJyIGluc3RhbmNlb2YgRXJyb3JcbiAgICAgICAgICA/IGVyci5tZXNzYWdlXG4gICAgICAgICAgOiB0KFwic29jaWFsLnByb2ZpbGVTYXZlRmFpbGVkXCIsIHsgZGVmYXVsdFZhbHVlOiBcIkNvdWxkIG5vdCBzYXZlIGFjY291bnQgc2V0dGluZ3MuXCIgfSksXG4gICAgICApO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTYXZpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVUb2dnbGVTb3VuZCA9IChjaGVja2VkOiBib29sZWFuKSA9PiB7XG4gICAgc2V0U291bmRFbmFibGVkKGNoZWNrZWQpO1xuICAgIHNldFZlcmRpY3RTb3VuZEVuYWJsZWQoY2hlY2tlZCk7XG4gICAgaWYgKGNoZWNrZWQpIHtcbiAgICAgIHBsYXlDb2luU3BpblNvdW5kKCk7XG4gICAgICB0b2FzdC5zdWNjZXNzKFwiVmVyZGljdCAmIFp3ZXBlIENvaW4gc291bmQgZWZmZWN0cyBlbmFibGVkLlwiKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdG9hc3QuaW5mbyhcIlZlcmRpY3Qgc291bmQgZWZmZWN0cyBtdXRlZC5cIik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZVByZWZzID0gKHBhcnRpYWw6IFBhcnRpYWw8QWNjb3VudFByZWZlcmVuY2VzPikgPT4ge1xuICAgIGNvbnN0IG5leHQgPSB7IC4uLnByZWZzLCAuLi5wYXJ0aWFsIH07XG4gICAgc2V0UHJlZnMobmV4dCk7XG4gICAgc2F2ZUFjY291bnRQcmVmZXJlbmNlcyhuZXh0KTtcbiAgICB0b2FzdC5zdWNjZXNzKFwiQWNjb3VudCBwcmVmZXJlbmNlcyB1cGRhdGVkLlwiKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVDb3B5QWNjb3VudElkID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dCh1c2VyLmlkKTtcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJBY2NvdW50IElEIGNvcGllZCB0byBjbGlwYm9hcmQuXCIpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgdG9hc3QuaW5mbyhgQWNjb3VudCBJRDogJHt1c2VyLmlkfWApO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBhY3RpdmVMYW5nQ29kZSA9IChpMThuLmxhbmd1YWdlIHx8IFwiZW5cIikuc3BsaXQoXCItXCIpWzBdO1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHt2YXJpYW50ID09PSBcIm5hdmJhclwiID8gKFxuICAgICAgICA8RHJvcGRvd25NZW51PlxuICAgICAgICAgIDxEcm9wZG93bk1lbnVUcmlnZ2VyIGFzQ2hpbGQ+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiT3BlbiB1c2VyIHByb2ZpbGUgYW5kIGFjY291bnQgc2V0dGluZ3NcIlxuICAgICAgICAgICAgICB0aXRsZT17YCR7cmVzb2x2ZWREaXNwbGF5TmFtZX0gwrcgQWNjb3VudCAmIFNldHRpbmdzYH1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICBcImdyb3VwIHJlbGF0aXZlIGlubGluZS1mbGV4IGgtOCBzaHJpbmstMCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLWZ1bGwgcC0wLjUgdHJhbnNpdGlvbi1jb2xvcnMgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLVsjZDZhOTI4XSBjdXJzb3ItcG9pbnRlclwiLFxuICAgICAgICAgICAgICAgIGlzQnJhbmRNb2RlXG4gICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyIGJvcmRlci1bI2Q2YTkyOF0vNzAgYmctc2xhdGUtOTUwIHRleHQtWyNmNWQwNjFdIGhvdmVyOmJvcmRlci1bI2Q2YTkyOF1cIlxuICAgICAgICAgICAgICAgICAgOiBcImJvcmRlciBib3JkZXItYm9yZGVyIGJnLXNlY29uZGFyeS81MCB0ZXh0LWZvcmVncm91bmQgaG92ZXI6Ymctc2Vjb25kYXJ5XCIsXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxBdmF0YXIgY2xhc3NOYW1lPVwiaC03IHctNyBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgIHtyZXNvbHZlZEF2YXRhclVybCA/IChcbiAgICAgICAgICAgICAgICAgIDxBdmF0YXJJbWFnZVxuICAgICAgICAgICAgICAgICAgICBzcmM9e3Jlc29sdmVkQXZhdGFyVXJsfVxuICAgICAgICAgICAgICAgICAgICBhbHQ9e3Jlc29sdmVkRGlzcGxheU5hbWV9XG4gICAgICAgICAgICAgICAgICAgIHJlZmVycmVyUG9saWN5PVwibm8tcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJvYmplY3QtY292ZXJcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgICAgICA8QXZhdGFyRmFsbGJhY2tcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgIFwidGV4dC1bMTFweF0gZm9udC1leHRyYWJvbGQgdHJhY2tpbmctdGlnaHRcIixcbiAgICAgICAgICAgICAgICAgICAgaXNCcmFuZE1vZGVcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctc2xhdGUtOTAwIHRleHQtWyNkNmE5MjhdXCJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctc2xhdGUtOTUwIHRleHQtWyNkNmE5MjhdIGRhcms6YmctWyNkNmE5MjhdIGRhcms6dGV4dC1zbGF0ZS05NTBcIixcbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge2dldEluaXRpYWxzKHJlc29sdmVkRGlzcGxheU5hbWUpfVxuICAgICAgICAgICAgICAgIDwvQXZhdGFyRmFsbGJhY2s+XG4gICAgICAgICAgICAgIDwvQXZhdGFyPlxuXG4gICAgICAgICAgICAgIHsvKiBTdGF0dXMgaW5kaWNhdG9yIGRvdCAoR29sZCBmb3IgQnJhbmQgLyBEZXZlbG9wZXIsIEVtZXJhbGQgZm9yIFBlcnNvbmFsKSAqL31cbiAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICBcImFic29sdXRlIC1ib3R0b20tMC41IC1yaWdodC0wLjUgaC0yLjUgdy0yLjUgcm91bmRlZC1mdWxsIHJpbmctMiByaW5nLWJhY2tncm91bmRcIixcbiAgICAgICAgICAgICAgICAgIGlzRGV2ZWxvcGVyXG4gICAgICAgICAgICAgICAgICAgID8gXCJiZy1bI2Q2YTkyOF1cIlxuICAgICAgICAgICAgICAgICAgICA6IGlzQnJhbmRNb2RlXG4gICAgICAgICAgICAgICAgICAgICAgPyBcImJnLVsjZDZhOTI4XVwiXG4gICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWVtZXJhbGQtNTAwXCIsXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvRHJvcGRvd25NZW51VHJpZ2dlcj5cblxuICAgICAgICAgIDxEcm9wZG93bk1lbnVDb250ZW50IGFsaWduPVwiZW5kXCIgY2xhc3NOYW1lPVwidy03MiBwLTJcIj5cbiAgICAgICAgICAgIHsvKiBVc2VyIElkZW50aXR5IEhlYWRlciAqL31cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICBcImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHJvdW5kZWQtbGcgcC0yLjVcIixcbiAgICAgICAgICAgICAgICBpc0JyYW5kTW9kZVxuICAgICAgICAgICAgICAgICAgPyBcImJnLXNsYXRlLTk1MCB0ZXh0LXdoaXRlIGJvcmRlciBib3JkZXItWyNkNmE5MjhdLzMwXCJcbiAgICAgICAgICAgICAgICAgIDogXCJiZy1zZWNvbmRhcnkvNTAgdGV4dC1mb3JlZ3JvdW5kXCIsXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxBdmF0YXIgY2xhc3NOYW1lPVwiaC0xMCB3LTEwIHNocmluay0wIGJvcmRlciBib3JkZXItWyNkNmE5MjhdLzQwXCI+XG4gICAgICAgICAgICAgICAge3Jlc29sdmVkQXZhdGFyVXJsID8gKFxuICAgICAgICAgICAgICAgICAgPEF2YXRhckltYWdlXG4gICAgICAgICAgICAgICAgICAgIHNyYz17cmVzb2x2ZWRBdmF0YXJVcmx9XG4gICAgICAgICAgICAgICAgICAgIGFsdD17cmVzb2x2ZWREaXNwbGF5TmFtZX1cbiAgICAgICAgICAgICAgICAgICAgcmVmZXJyZXJQb2xpY3k9XCJuby1yZWZlcnJlclwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm9iamVjdC1jb3ZlclwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgICAgIDxBdmF0YXJGYWxsYmFja1xuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgXCJ0ZXh0LXhzIGZvbnQtZXh0cmFib2xkXCIsXG4gICAgICAgICAgICAgICAgICAgIGlzQnJhbmRNb2RlXG4gICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXNsYXRlLTkwMCB0ZXh0LVsjZDZhOTI4XVwiXG4gICAgICAgICAgICAgICAgICAgICAgOiBcImJnLXNsYXRlLTk1MCB0ZXh0LVsjZDZhOTI4XVwiLFxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7Z2V0SW5pdGlhbHMocmVzb2x2ZWREaXNwbGF5TmFtZSl9XG4gICAgICAgICAgICAgICAgPC9BdmF0YXJGYWxsYmFjaz5cbiAgICAgICAgICAgICAgPC9BdmF0YXI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0cnVuY2F0ZSB0ZXh0LXNtIGZvbnQtYm9sZCBsZWFkaW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICB7cmVzb2x2ZWREaXNwbGF5TmFtZX1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPHBcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgIFwidHJ1bmNhdGUgdGV4dC14c1wiLFxuICAgICAgICAgICAgICAgICAgICBpc0JyYW5kTW9kZSA/IFwidGV4dC1bI2Y1ZDA2MV1cIiA6IFwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIsXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtyZXNvbHZlZEhhbmRsZX1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAge3VzZXIuZW1haWwgJiYgKFxuICAgICAgICAgICAgICAgICAgPHBcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICBcInRydW5jYXRlIHRleHQtWzExcHhdXCIsXG4gICAgICAgICAgICAgICAgICAgICAgaXNCcmFuZE1vZGUgPyBcInRleHQtc2xhdGUtNDAwXCIgOiBcInRleHQtbXV0ZWQtZm9yZWdyb3VuZC84MFwiLFxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7dXNlci5lbWFpbH1cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8RHJvcGRvd25NZW51U2VwYXJhdG9yIGNsYXNzTmFtZT1cIm15LTEuNVwiIC8+XG5cbiAgICAgICAgICAgIHsvKiBQcmltYXJ5IFByb2ZpbGUgJiBIdWIgTmF2aWdhdGlvbiAqL31cbiAgICAgICAgICAgIDxEcm9wZG93bk1lbnVHcm91cD5cbiAgICAgICAgICAgICAgPERyb3Bkb3duTWVudUl0ZW1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSh7IHRvOiBcIi9wcm9maWxlXCIgfSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY3Vyc29yLXBvaW50ZXIgZ2FwLTIuNSBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7aXNCcmFuZE1vZGUgPyAoXG4gICAgICAgICAgICAgICAgICA8QnVpbGRpbmcyIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1bI2Q2YTkyOF1cIiAvPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8VXNlciBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtZW1lcmFsZC02MDBcIiAvPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNCcmFuZE1vZGVcbiAgICAgICAgICAgICAgICAgICAgPyBcIkJyYW5kIERlc2sgJiBPcGVyYXRvciBSb3N0ZXJcIlxuICAgICAgICAgICAgICAgICAgICA6IHQoXCJuYXYucHJvZmlsZVwiLCB7IGRlZmF1bHRWYWx1ZTogXCJNeSBQcm9maWxlXCIgfSl9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L0Ryb3Bkb3duTWVudUl0ZW0+XG5cbiAgICAgICAgICAgICAgPERyb3Bkb3duTWVudUl0ZW1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSh7IHRvOiBcIi9kYXNoYm9hcmRcIiB9KX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciBnYXAtMi41IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxMYXlvdXREYXNoYm9hcmQgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LVsjZDZhOTI4XVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICB7aXNCcmFuZE1vZGVcbiAgICAgICAgICAgICAgICAgICAgPyBcIkJyYW5kIENvbW1hbmQgU3VpdGVcIlxuICAgICAgICAgICAgICAgICAgICA6IHQoXCJuYXYuZGFzaGJvYXJkXCIsIHsgZGVmYXVsdFZhbHVlOiBcIk15IFZvdGVyIEh1YlwiIH0pfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVJdGVtPlxuXG4gICAgICAgICAgICAgIDxEcm9wZG93bk1lbnVJdGVtXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlVGFiKFwicHJvZmlsZVwiKTtcbiAgICAgICAgICAgICAgICAgIHNldFNldHRpbmdzT3Blbih0cnVlKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIGdhcC0yLjUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFNldHRpbmdzIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1mb3JlZ3JvdW5kXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5BY2NvdW50IFNldHRpbmdzICYgQXZhdGFyPC9zcGFuPlxuICAgICAgICAgICAgICA8L0Ryb3Bkb3duTWVudUl0ZW0+XG5cbiAgICAgICAgICAgICAgPERyb3Bkb3duTWVudUl0ZW1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBzZXRBY3RpdmVUYWIoXCJwcmVmZXJlbmNlc1wiKTtcbiAgICAgICAgICAgICAgICAgIHNldFNldHRpbmdzT3Blbih0cnVlKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIGdhcC0yLjUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFZvbHVtZTIgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkF1ZGlvLCBDYWxscyAmIExhbmd1YWdlPC9zcGFuPlxuICAgICAgICAgICAgICA8L0Ryb3Bkb3duTWVudUl0ZW0+XG4gICAgICAgICAgICA8L0Ryb3Bkb3duTWVudUdyb3VwPlxuXG4gICAgICAgICAgICA8RHJvcGRvd25NZW51U2VwYXJhdG9yIGNsYXNzTmFtZT1cIm15LTEuNVwiIC8+XG5cbiAgICAgICAgICAgIHsvKiBRdWljayBDb21tcyAmIEFkbWluICovfVxuICAgICAgICAgICAgPERyb3Bkb3duTWVudUdyb3VwPlxuICAgICAgICAgICAgICA8RHJvcGRvd25NZW51SXRlbVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKHsgdG86IFwiL21lc3NhZ2VzXCIgfSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY3Vyc29yLXBvaW50ZXIgZ2FwLTIuNSBweS0xLjUgdGV4dC14c1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8TWVzc2FnZUNpcmNsZSBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+e3QoXCJuYXYubWVzc2FnZXNcIiwgeyBkZWZhdWx0VmFsdWU6IFwiTWVzc2FnZXMgJiBTT1QgQ2FsbGluZ1wiIH0pfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVJdGVtPlxuICAgICAgICAgICAgICA8RHJvcGRvd25NZW51SXRlbVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKHsgdG86IFwiL25vdGlmaWNhdGlvbnNcIiB9KX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciBnYXAtMi41IHB5LTEuNSB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxCZWxsIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj57dChcInNvY2lhbC5ub3RpZmljYXRpb25zXCIsIHsgZGVmYXVsdFZhbHVlOiBcIk5vdGlmaWNhdGlvbnNcIiB9KX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvRHJvcGRvd25NZW51SXRlbT5cbiAgICAgICAgICAgICAge2lzQWRtaW4gJiYgKFxuICAgICAgICAgICAgICAgIDxEcm9wZG93bk1lbnVJdGVtXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSh7IHRvOiBcIi9hZG1pblwiIH0pfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY3Vyc29yLXBvaW50ZXIgZ2FwLTIuNSBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8U2hpZWxkIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1bI2Q2YTkyOF1cIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e3QoXCJuYXYuYWRtaW5cIiwgeyBkZWZhdWx0VmFsdWU6IFwiQWRtaW4gVmVyaWZpY2F0aW9uIFBvcnRhbFwiIH0pfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duTWVudUl0ZW0+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L0Ryb3Bkb3duTWVudUdyb3VwPlxuXG4gICAgICAgICAgICB7LyogREVWRUxPUEVSLU9OTFkgUFJFVklFVyAmIFNFQ1VSSVRZIFNXSVRDSEVSOiBTdHJpY3RseSBoaWRkZW4gZnJvbSBhbGwgcmVndWxhciBQZXJzb25hbCAmIEJyYW5kIHVzZXJzICovfVxuICAgICAgICAgICAge2lzRGV2ZWxvcGVyICYmIChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICA8RHJvcGRvd25NZW51U2VwYXJhdG9yIGNsYXNzTmFtZT1cIm15LTEuNVwiIC8+XG4gICAgICAgICAgICAgICAgPERyb3Bkb3duTWVudUxhYmVsIGNsYXNzTmFtZT1cInB4LTIgcHktMSB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgRGV2ZWxvcGVyIENvbnRyb2xzICYgU2VjdXJpdHkgU2hpZWxkXG4gICAgICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVMYWJlbD5cbiAgICAgICAgICAgICAgICA8RHJvcGRvd25NZW51SXRlbVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXh0ID0gaXNCcmFuZE1vZGUgPyBcImNvbnN1bWVyXCIgOiBcImJyYW5kX293bmVyXCI7XG4gICAgICAgICAgICAgICAgICAgIHNldFBlcnNvbmEobmV4dCk7XG4gICAgICAgICAgICAgICAgICAgIHRvYXN0LmluZm8oXG4gICAgICAgICAgICAgICAgICAgICAgbmV4dCA9PT0gXCJicmFuZF9vd25lclwiXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGBEZXZlbG9wZXIgUHJldmlldzogVmlld2luZyBhcyBCcmFuZCAoJHtyZWdpc3RlcmVkQnJhbmQubmFtZX0pYFxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcIkRldmVsb3BlciBQcmV2aWV3OiBWaWV3aW5nIGFzIFBlcnNvbmFsIFVzZXJcIixcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciBnYXAtMi41IHJvdW5kZWQtbWQgYmctc2Vjb25kYXJ5LzcwIHB5LTIgdGV4dC14cyBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtpc0JyYW5kTW9kZSA/IChcbiAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICA8Q29pbnMgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5ERVY6IFN3aXRjaCB0byBQZXJzb25hbCBWaWV3PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgPEJ1aWxkaW5nMiBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtWyNkNmE5MjhdXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPkRFVjogU3dpdGNoIHRvIHtyZWdpc3RlcmVkQnJhbmQubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duTWVudUl0ZW0+XG5cbiAgICAgICAgICAgICAgICA8RHJvcGRvd25NZW51SXRlbVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjdXJyZW50ID0gaXNEZXZlbG9wZXJDb2RlSW5zcGVjdGlvbkFjdGl2ZSgpO1xuICAgICAgICAgICAgICAgICAgICB0b2dnbGVEZXZlbG9wZXJDb2RlSW5zcGVjdGlvbighY3VycmVudCk7XG4gICAgICAgICAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoXG4gICAgICAgICAgICAgICAgICAgICAgIWN1cnJlbnRcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJEZXZlbG9wZXIgRjEyIC8gQ29kZSBJbnNwZWN0aW9uOiBFbmFibGVkIGZvciB0aGlzIHNlc3Npb25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlNlY3VyaXR5IFNoaWVsZDogRjEyIEJsb2NrZWQgJiBNb2JpbGUgU2NyZWVuLUdyYWIgU2hpZWxkZWRcIixcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciBnYXAtMi41IHJvdW5kZWQtbWQgYmctc2Vjb25kYXJ5LzQwIHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8Q29kZSBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtWyNkNmE5MjhdXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICBGMTIgQ29kZSBWaWV3aW5nOiB7aXNEZXZlbG9wZXJDb2RlSW5zcGVjdGlvbkFjdGl2ZSgpID8gXCJBbGxvd2VkIChEZXYgTW9kZSlcIiA6IFwiUHJvdGVjdGVkIChTaGllbGQgQWN0aXZlKVwifVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvRHJvcGRvd25NZW51SXRlbT5cbiAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICA8RHJvcGRvd25NZW51U2VwYXJhdG9yIGNsYXNzTmFtZT1cIm15LTEuNVwiIC8+XG5cbiAgICAgICAgICAgIDxEcm9wZG93bk1lbnVJdGVtXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHZvaWQgc2lnbk91dCgpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciBnYXAtMi41IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZGVzdHJ1Y3RpdmUgZm9jdXM6dGV4dC1kZXN0cnVjdGl2ZVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxMb2dPdXQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPnt0KFwibmF2LnNpZ25PdXRcIiwgeyBkZWZhdWx0VmFsdWU6IFwiU2lnbiBvdXRcIiB9KX08L3NwYW4+XG4gICAgICAgICAgICA8L0Ryb3Bkb3duTWVudUl0ZW0+XG4gICAgICAgICAgPC9Ecm9wZG93bk1lbnVDb250ZW50PlxuICAgICAgICA8L0Ryb3Bkb3duTWVudT5cbiAgICAgICkgOiAoXG4gICAgICAgIC8qIENhcmQgdmFyaWFudCBmb3IgUHJvZmlsZSBvciBEYXNoYm9hcmQgZW1iZWRkaW5nICovXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLWNhcmQgcC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMy41XCI+XG4gICAgICAgICAgICA8QXZhdGFyIGNsYXNzTmFtZT1cImgtMTIgdy0xMiBib3JkZXIgYm9yZGVyLVsjZDZhOTI4XS80MFwiPlxuICAgICAgICAgICAgICB7cmVzb2x2ZWRBdmF0YXJVcmwgPyAoXG4gICAgICAgICAgICAgICAgPEF2YXRhckltYWdlXG4gICAgICAgICAgICAgICAgICBzcmM9e3Jlc29sdmVkQXZhdGFyVXJsfVxuICAgICAgICAgICAgICAgICAgYWx0PXtyZXNvbHZlZERpc3BsYXlOYW1lfVxuICAgICAgICAgICAgICAgICAgcmVmZXJyZXJQb2xpY3k9XCJuby1yZWZlcnJlclwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJvYmplY3QtY292ZXJcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgICA8QXZhdGFyRmFsbGJhY2sgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHRleHQtc20gZm9udC1leHRyYWJvbGQgdGV4dC1bI2Q2YTkyOF1cIj5cbiAgICAgICAgICAgICAgICB7Z2V0SW5pdGlhbHMocmVzb2x2ZWREaXNwbGF5TmFtZSl9XG4gICAgICAgICAgICAgIDwvQXZhdGFyRmFsbGJhY2s+XG4gICAgICAgICAgICA8L0F2YXRhcj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWZvcmVncm91bmRcIj57cmVzb2x2ZWREaXNwbGF5TmFtZX08L2gzPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgIHtyZXNvbHZlZEhhbmRsZX1cbiAgICAgICAgICAgICAgICB7dXNlci5lbWFpbCA/IGAgwrcgJHt1c2VyLmVtYWlsfWAgOiBcIlwifVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgIHNldEFjdGl2ZVRhYihcInByb2ZpbGVcIik7XG4gICAgICAgICAgICAgICAgc2V0U2V0dGluZ3NPcGVuKHRydWUpO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggZ2FwLTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8U2V0dGluZ3MgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5BY2NvdW50IFNldHRpbmdzPC9zcGFuPlxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIEFjY291bnQgU2V0dGluZ3MgRGlhbG9nICovfVxuICAgICAgPERpYWxvZyBvcGVuPXtzZXR0aW5nc09wZW59IG9uT3BlbkNoYW5nZT17c2V0U2V0dGluZ3NPcGVufT5cbiAgICAgICAgPERpYWxvZ0NvbnRlbnQgY2xhc3NOYW1lPVwibWF4LXctbGdcIj5cbiAgICAgICAgICA8RGlhbG9nSGVhZGVyPlxuICAgICAgICAgICAgPERpYWxvZ1RpdGxlIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtYmFzZSBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgPFNldHRpbmdzIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1bI2Q2YTkyOF1cIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICB7aXNCcmFuZE1vZGVcbiAgICAgICAgICAgICAgICAgID8gYCR7cmVnaXN0ZXJlZEJyYW5kLm5hbWV9IMK3IEJyYW5kIEFjY291bnQgU2V0dGluZ3NgXG4gICAgICAgICAgICAgICAgICA6IFwiUGVyc29uYWwgQWNjb3VudCAmIFByb2ZpbGUgU2V0dGluZ3NcIn1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9EaWFsb2dUaXRsZT5cbiAgICAgICAgICAgIDxEaWFsb2dEZXNjcmlwdGlvbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIHtpc0JyYW5kTW9kZVxuICAgICAgICAgICAgICAgID8gXCJNYW5hZ2UgeW91ciByZWdpc3RlcmVkIGJyYW5kIGlkZW50aXR5LCBjb3Jwb3JhdGUgb3BlcmF0b3IgZGVzayBzZWF0LCBhbmQgY29tbXVuaWNhdGlvbiBwcmVmZXJlbmNlcy5cIlxuICAgICAgICAgICAgICAgIDogXCJDdXN0b21pemUgeW91ciBTT3JUIGF2YXRhciwgcHVibGljIHZvdGVyIHByb2ZpbGUsIGF1ZGlvIGZlZWRiYWNrLCBhbmQgcHJpdmFjeSBzZXR0aW5ncy5cIn1cbiAgICAgICAgICAgIDwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgICAgPC9EaWFsb2dIZWFkZXI+XG5cbiAgICAgICAgICA8VGFic1xuICAgICAgICAgICAgdmFsdWU9e2FjdGl2ZVRhYn1cbiAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2KSA9PiBzZXRBY3RpdmVUYWIodiBhcyBcInByb2ZpbGVcIiB8IFwicHJlZmVyZW5jZXNcIiB8IFwic2VjdXJpdHlcIil9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxUYWJzTGlzdCBjbGFzc05hbWU9XCJncmlkIHctZnVsbCBncmlkLWNvbHMtM1wiPlxuICAgICAgICAgICAgICA8VGFic1RyaWdnZXIgdmFsdWU9XCJwcm9maWxlXCIgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAge2lzQnJhbmRNb2RlID8gXCJCcmFuZCAmIERlc2tcIiA6IFwiUHJvZmlsZSAmIEF2YXRhclwifVxuICAgICAgICAgICAgICA8L1RhYnNUcmlnZ2VyPlxuICAgICAgICAgICAgICA8VGFic1RyaWdnZXIgdmFsdWU9XCJwcmVmZXJlbmNlc1wiIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgIFByZWZlcmVuY2VzXG4gICAgICAgICAgICAgIDwvVGFic1RyaWdnZXI+XG4gICAgICAgICAgICAgIDxUYWJzVHJpZ2dlciB2YWx1ZT1cInNlY3VyaXR5XCIgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgUHJpdmFjeSAmIEF1dGhcbiAgICAgICAgICAgICAgPC9UYWJzVHJpZ2dlcj5cbiAgICAgICAgICAgIDwvVGFic0xpc3Q+XG5cbiAgICAgICAgICAgIHsvKiBUQUIgMTogUFJPRklMRSAmIEFWQVRBUiAoT1IgQlJBTkQgJiBERVNLIEZPUiBCUkFORCBPV05FUlMpICovfVxuICAgICAgICAgICAgPFRhYnNDb250ZW50IHZhbHVlPVwicHJvZmlsZVwiIGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIHtpc0JyYW5kTW9kZSA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMy41XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgYmctYW1iZXItNTAwLzUgcC0zIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgU3RyaWN0IENvcnBvcmF0ZSBEZXNrIElzb2xhdGlvbiBBY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICBCcmFuZCBvcGVyYXRvcnMgd29yayBzdHJpY3RseSB1bmRlciBjb3Jwb3JhdGUgZGVzayBzZWF0cy4gUGVyc29uYWwgU09yVHtcIiBcIn1cbiAgICAgICAgICAgICAgICAgICAgICA8Y29kZSBjbGFzc05hbWU9XCJmb250LW1vbm9cIj5APC9jb2RlPiBwcm9maWxlcyBjYW5ub3QgYmUgYXR0YWNoZWQgdG8gdGhpcyBicmFuZFxuICAgICAgICAgICAgICAgICAgICAgIGFjY291bnQuXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwic2V0dGluZ3MtYnJhbmQtbmFtZVwiIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIFJlZ2lzdGVyZWQgQnJhbmQgTmFtZVxuICAgICAgICAgICAgICAgICAgICA8L0xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInNldHRpbmdzLWJyYW5kLW5hbWVcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXticmFuZE5hbWVJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezEyMH1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJyYW5kTmFtZUlucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTMgc206Z3JpZC1jb2xzLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwic2V0dGluZ3MtYnJhbmQtY2F0ZWdvcnlcIiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIEluZHVzdHJ5IENhdGVnb3J5XG4gICAgICAgICAgICAgICAgICAgICAgPC9MYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwic2V0dGluZ3MtYnJhbmQtY2F0ZWdvcnlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2JyYW5kQ2F0ZWdvcnlJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17ODB9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJyYW5kQ2F0ZWdvcnlJbnB1dChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cInNldHRpbmdzLWJyYW5kLXdlYnNpdGVcIiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIE9mZmljaWFsIFdlYnNpdGVcbiAgICAgICAgICAgICAgICAgICAgICA8L0xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJzZXR0aW5ncy1icmFuZC13ZWJzaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXticmFuZFdlYnNpdGVJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17MjUwfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJodHRwczovLy4uLlwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJyYW5kV2Vic2l0ZUlucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxMYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICBBY3RpdmUgQ29ycG9yYXRlIERlc2sgU2VhdCAoT24gU2hpZnQpXG4gICAgICAgICAgICAgICAgICAgIDwvTGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAge29wZXJhdG9ycy5tYXAoKG9wKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0N1cnJlbnQgPSBvcC5pZCA9PT0gYWN0aXZlT3BlcmF0b3IuaWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtvcC5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzd2l0Y2hlZCA9IHN3aXRjaEFjdGl2ZURlc2tPcGVyYXRvcihvcC5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVPcGVyYXRvclN0YXRlKHN3aXRjaGVkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoYEFjdGl2ZSBkZXNrIGhhbmRlZCBvdmVyIHRvICR7c3dpdGNoZWQubmFtZX1gKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiByb3VuZGVkLWxnIGJvcmRlciBweC0zIHB5LTIgdGV4dC1sZWZ0IHRleHQteHMgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNDdXJyZW50XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItWyNkNmE5MjhdIGJnLXNsYXRlLTk1MCB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci1ib3JkZXIgYmctc2Vjb25kYXJ5LzMwIGhvdmVyOmJnLXNlY29uZGFyeS82MFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+e29wLm5hbWV9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInRleHQtWzExcHhdXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNDdXJyZW50ID8gXCJ0ZXh0LXNsYXRlLTMwMFwiIDogXCJ0ZXh0LW11dGVkLWZvcmVncm91bmRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge29wLnJvbGVUaXRsZX0gwrcge29wLnNoaWZ0TGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzQ3VycmVudCAmJiA8Q2hlY2sgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LVsjZDZhOTI4XVwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgIHsvKiBBdmF0YXIgUHJldmlldyArIFByZXNldCBTZWxlY3RvciAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMyByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLXNlY29uZGFyeS8zMCBwLTMgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxBdmF0YXIgY2xhc3NOYW1lPVwiaC0xNCB3LTE0IHNocmluay0wIGJvcmRlci0yIGJvcmRlci1bI2Q2YTkyOF1cIj5cbiAgICAgICAgICAgICAgICAgICAgICB7YXZhdGFyVXJsSW5wdXQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8QXZhdGFySW1hZ2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXthdmF0YXJVcmxJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtkaXNwbGF5TmFtZUlucHV0IHx8IFwiVXNlciBhdmF0YXJcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVmZXJyZXJQb2xpY3k9XCJuby1yZWZlcnJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm9iamVjdC1jb3ZlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgIDxBdmF0YXJGYWxsYmFjayBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgdGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtWyNkNmE5MjhdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Z2V0SW5pdGlhbHMoZGlzcGxheU5hbWVJbnB1dCB8fCByZXNvbHZlZERpc3BsYXlOYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L0F2YXRhckZhbGxiYWNrPlxuICAgICAgICAgICAgICAgICAgICA8L0F2YXRhcj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgU09yVCBFbWJsZW0gQXZhdGFyIG9yIFBhc3RlIEltYWdlIFVSTFxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge1BSRVNFVF9BVkFUQVJTLm1hcCgocHJlc2V0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHNlbGVjdGVkID0gYXZhdGFyVXJsSW5wdXQgPT09IHByZXNldC51cmw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtwcmVzZXQuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEF2YXRhclVybElucHV0KHByZXNldC51cmwpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e3ByZXNldC5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwicmVsYXRpdmUgZmxleCBoLTggdy04IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgYm9yZGVyLTIgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItWyNkNmE5MjhdIHNjYWxlLTEwNVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCBvcGFjaXR5LTgwIGhvdmVyOm9wYWNpdHktMTAwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtwcmVzZXQudXJsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9e3ByZXNldC5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVmZXJyZXJQb2xpY3k9XCJuby1yZWZlcnJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtZnVsbCB3LWZ1bGwgcm91bmRlZC1mdWxsIG9iamVjdC1jb3ZlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgICB7YXZhdGFyVXJsSW5wdXQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEF2YXRhclVybElucHV0KFwiXCIpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtNyBweC0yIHRleHQtWzExcHhdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFVzZSBJbml0aWFsc1xuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtMyBzbTpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJ1cC1kaXNwbGF5LW5hbWVcIiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHt0KFwic29jaWFsLmRpc3BsYXlOYW1lXCIsIHsgZGVmYXVsdFZhbHVlOiBcIkRpc3BsYXkgTmFtZVwiIH0pfVxuICAgICAgICAgICAgICAgICAgICAgIDwvTGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInVwLWRpc3BsYXktbmFtZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZGlzcGxheU5hbWVJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17NjB9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldERpc3BsYXlOYW1lSW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJ1cC11c2VybmFtZVwiIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgVXNlcm5hbWUgSGFuZGxlXG4gICAgICAgICAgICAgICAgICAgICAgPC9MYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwidXAtdXNlcm5hbWVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VzZXJuYW1lSW5wdXR9XG4gICAgICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezUwfVxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJ1c2VybmFtZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFVzZXJuYW1lSW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJ1cC1iaW9cIiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7dChcInNvY2lhbC5iaW9cIiwgeyBkZWZhdWx0VmFsdWU6IFwiQmlvIC8gVm90ZXIgU3RhdGVtZW50XCIgfSl9XG4gICAgICAgICAgICAgICAgICAgIDwvTGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxUZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwidXAtYmlvXCJcbiAgICAgICAgICAgICAgICAgICAgICByb3dzPXsyfVxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtiaW9JbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezI4MH1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17dChcInNvY2lhbC5iaW9QaFwiLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU6IFwiVGVsbCB0aGUgY29tbXVuaXR5IHdoYXQgeW91IHN0YW5kIGZvci4uLlwiLFxuICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QmlvSW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJ1cC1hdmF0YXItdXJsXCIgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3QoXCJzb2NpYWwuYXZhdGFyVXJsXCIsIHsgZGVmYXVsdFZhbHVlOiBcIkN1c3RvbSBBdmF0YXIgSW1hZ2UgVVJMXCIgfSl9XG4gICAgICAgICAgICAgICAgICAgIDwvTGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwidXAtYXZhdGFyLXVybFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2F2YXRhclVybElucHV0fVxuICAgICAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17NTAwfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiaHR0cHM6Ly8uLi5cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QXZhdGFyVXJsSW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgPERpYWxvZ0Zvb3RlciBjbGFzc05hbWU9XCJwdC0yXCI+XG4gICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIHNpemU9XCJzbVwiIG9uQ2xpY2s9eygpID0+IHNldFNldHRpbmdzT3BlbihmYWxzZSl9PlxuICAgICAgICAgICAgICAgICAgQ2FuY2VsXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHZvaWQgaGFuZGxlU2F2ZVByb2ZpbGVTZXR0aW5ncygpfVxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3NhdmluZ31cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCB0ZXh0LVsjZDZhOTI4XSBob3ZlcjpiZy1zbGF0ZS05MDAgZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7c2F2aW5nID8gXCJTYXZpbmcuLi5cIiA6IFwiU2F2ZSBDaGFuZ2VzXCJ9XG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDwvRGlhbG9nRm9vdGVyPlxuICAgICAgICAgICAgPC9UYWJzQ29udGVudD5cblxuICAgICAgICAgICAgey8qIFRBQiAyOiBQUkVGRVJFTkNFUyAoQVVESU8sIENBTEwgQUxFUlRTLCBMQU5HVUFHRSkgKi99XG4gICAgICAgICAgICA8VGFic0NvbnRlbnQgdmFsdWU9XCJwcmVmZXJlbmNlc1wiIGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJvcmRlciBwLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0wLjUgcHItM1wiPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICBWZXJkaWN0ICYgWndlcGUgQ29pbiBTb3VuZCBFZmZlY3RzXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgUGxheSBhdWRpbyBlZmZlY3RzIHdoZW4gY2FzdGluZyBTdGFzaC9UcmFzaCB2ZXJkaWN0cyBvciBzcGlubmluZyBjb2lucy5cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8U3dpdGNoIGNoZWNrZWQ9e3NvdW5kRW5hYmxlZH0gb25DaGVja2VkQ2hhbmdlPXtoYW5kbGVUb2dnbGVTb3VuZH0gLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXIgcC0zXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMC41IHByLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgSW5jb21pbmcgU09UIFZvaWNlL1ZpZGVvIENhbGwgUmluZyBCYW5uZXJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICBTaG93IHJlYWwtdGltZSB0b3AgYWxlcnQgYmFubmVyIGZvciB6ZXJvLXBob25lLW51bWJlciBTT1QgY2FsbHMuXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPFN3aXRjaFxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtwcmVmcy5jYWxsUmluZ0FsZXJ0c31cbiAgICAgICAgICAgICAgICAgICAgb25DaGVja2VkQ2hhbmdlPXsoY2hlY2tlZCkgPT4gaGFuZGxlVXBkYXRlUHJlZnMoeyBjYWxsUmluZ0FsZXJ0czogY2hlY2tlZCB9KX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYm9yZGVyIHAtM1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyBmb250LWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8R2xvYmUgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgdGV4dC1bI2Q2YTkyOF1cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlByZWZlcnJlZCBJbnRlcmZhY2UgTGFuZ3VhZ2UgKHtBUFBfU1VQUE9SVEVEX0xPQ0FMRVMubGVuZ3RofSBMYW5ndWFnZXMpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTEuNSBwdC0xIG1heC1oLTQ4IG92ZXJmbG93LXktYXV0byBwci0xXCI+XG4gICAgICAgICAgICAgICAgICAgIHtBUFBfU1VQUE9SVEVEX0xPQ0FMRVMubWFwKChsb2MpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhY3RpdmUgPSBhY3RpdmVMYW5nQ29kZSA9PT0gbG9jLmNvZGU7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtsb2MuY29kZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b2lkIHN3aXRjaEFwcExhbmd1YWdlKGkxOG4sIGxvYy5jb2RlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b2FzdC5zdWNjZXNzKGBTd2l0Y2hlZCBsYW5ndWFnZSB0byAke2xvYy5sYWJlbH1gKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInJvdW5kZWQtbWQgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1zbGF0ZS05NTAgdGV4dC1bI2Q2YTkyOF1cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJvcmRlciBib3JkZXItYm9yZGVyIGJnLXNlY29uZGFyeS80MCB0ZXh0LWZvcmVncm91bmQgaG92ZXI6Ymctc2Vjb25kYXJ5XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtsb2MubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvVGFic0NvbnRlbnQ+XG5cbiAgICAgICAgICAgIHsvKiBUQUIgMzogUFJJVkFDWSAmIFNFQ1VSSVRZICovfVxuICAgICAgICAgICAgPFRhYnNDb250ZW50IHZhbHVlPVwic2VjdXJpdHlcIiBjbGFzc05hbWU9XCJtdC00IHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1zZWNvbmRhcnkvMzAgcC0zXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPFNoaWVsZENoZWNrIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1lbWVyYWxkLTYwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBBdXRoZW50aWNhdGVkIFNlc3Npb25cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBoYW5kbGVDb3B5QWNjb3VudElkKCl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC03IGdhcC0xIHB4LTIgdGV4dC1bMTFweF1cIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPENvcHkgY2xhc3NOYW1lPVwiaC0zIHctM1wiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+Q29weSBJRDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgU2lnbmVkIGluIGFzIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+e3VzZXIuZW1haWwgfHwgdXNlci5pZH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7IWlzQnJhbmRNb2RlICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXIgcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0wLjUgcHItM1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgUHVibGljIFZvdGVyIExlZGdlciBWaXNpYmlsaXR5XG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgRGlzcGxheSB5b3VyIFN0YXNoL1RyYXNoIHRhbGx5IG9uIHlvdXIgcHVibGljIGNvbW11bml0eSBwcm9maWxlLlxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxTd2l0Y2hcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtwcmVmcy5wdWJsaWNWb3RlckxlZGdlcn1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoZWNrZWRDaGFuZ2U9eyhjaGVja2VkKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlUHJlZnMoeyBwdWJsaWNWb3RlckxlZGdlcjogY2hlY2tlZCB9KVxuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYm9yZGVyIHAtM1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8TG9jayBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+U2lnbiBPdXQgb2YgU09yVDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIEVuZCB5b3VyIGFjdGl2ZSBzZXNzaW9uIG9uIHRoaXMgYnJvd3Nlci5cbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwiZGVzdHJ1Y3RpdmVcIlxuICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2V0dGluZ3NPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgICB2b2lkIHNpZ25PdXQoKTtcbiAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IGdhcC0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPExvZ091dCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlNpZ24gb3V0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9UYWJzQ29udGVudD5cbiAgICAgICAgICA8L1RhYnM+XG4gICAgICAgIDwvRGlhbG9nQ29udGVudD5cbiAgICAgIDwvRGlhbG9nPlxuICAgIDwvPlxuICApO1xufVxuIl0sImZpbGUiOiIvYXBwL2FwcGxldC9zcmMvY29tcG9uZW50cy9Vc2VyUHJvZmlsZS50c3gifQ==