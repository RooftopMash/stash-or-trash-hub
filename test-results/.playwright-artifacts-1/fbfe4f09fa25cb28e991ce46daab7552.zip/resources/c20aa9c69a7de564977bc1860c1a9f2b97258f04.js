import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/command.tsx");const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport0_react, 1);const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];"use client";
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { Command as CommandPrimitive } from "/node_modules/.vite/deps/cmdk.js?v=a8030269";
import { Search } from "/node_modules/.vite/deps/lucide-react.js?v=a8030269";
import { cn } from "/src/lib/utils.ts";
import { Dialog, DialogContent } from "/src/components/ui/dialog.tsx";
var _jsxFileName = "/app/applet/src/components/ui/command.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
const Command = React.forwardRef(_c = ({ className, ...props }, ref) => /* @__PURE__ */ _jsxDEV(CommandPrimitive, {
	ref,
	className: cn("flex h-full w-full flex-col overflow-hidden rounded-md bg-popover text-popover-foreground", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 15,
	columnNumber: 3
}, this));
_c2 = Command;
Command.displayName = CommandPrimitive.displayName;
const CommandDialog = ({ children, ...props }) => {
	return /* @__PURE__ */ _jsxDEV(Dialog, {
		...props,
		children: /* @__PURE__ */ _jsxDEV(DialogContent, {
			className: "overflow-hidden p-0",
			children: /* @__PURE__ */ _jsxDEV(Command, {
				className: "[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground [&_[cmdk-group]:not([hidden])_~[cmdk-group]]:pt-0 [&_[cmdk-group]]:px-2 [&_[cmdk-input-wrapper]_svg]:h-5 [&_[cmdk-input-wrapper]_svg]:w-5 [&_[cmdk-input]]:h-12 [&_[cmdk-item]]:px-2 [&_[cmdk-item]]:py-3 [&_[cmdk-item]_svg]:h-5 [&_[cmdk-item]_svg]:w-5",
				children
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 5
	}, this);
};
_c3 = CommandDialog;
const CommandInput = React.forwardRef(_c4 = ({ className, ...props }, ref) => /* @__PURE__ */ _jsxDEV("div", {
	className: "flex items-center border-b px-3",
	"cmdk-input-wrapper": "",
	children: [/* @__PURE__ */ _jsxDEV(Search, { className: "mr-2 h-4 w-4 shrink-0 opacity-50" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 43,
		columnNumber: 5
	}, this), /* @__PURE__ */ _jsxDEV(CommandPrimitive.Input, {
		ref,
		className: cn("flex h-10 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 44,
		columnNumber: 5
	}, this)]
}, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 42,
	columnNumber: 3
}, this));
_c5 = CommandInput;
CommandInput.displayName = CommandPrimitive.Input.displayName;
const CommandList = React.forwardRef(_c6 = ({ className, ...props }, ref) => /* @__PURE__ */ _jsxDEV(CommandPrimitive.List, {
	ref,
	className: cn("max-h-[300px] overflow-y-auto overflow-x-hidden", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 61,
	columnNumber: 3
}, this));
_c7 = CommandList;
CommandList.displayName = CommandPrimitive.List.displayName;
const CommandEmpty = React.forwardRef(_c8 = (props, ref) => /* @__PURE__ */ _jsxDEV(CommandPrimitive.Empty, {
	ref,
	className: "py-6 text-center text-sm",
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 74,
	columnNumber: 3
}, this));
_c9 = CommandEmpty;
CommandEmpty.displayName = CommandPrimitive.Empty.displayName;
const CommandGroup = React.forwardRef(_c10 = ({ className, ...props }, ref) => /* @__PURE__ */ _jsxDEV(CommandPrimitive.Group, {
	ref,
	className: cn("overflow-hidden p-1 text-foreground [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 83,
	columnNumber: 3
}, this));
_c11 = CommandGroup;
CommandGroup.displayName = CommandPrimitive.Group.displayName;
const CommandSeparator = React.forwardRef(_c12 = ({ className, ...props }, ref) => /* @__PURE__ */ _jsxDEV(CommandPrimitive.Separator, {
	ref,
	className: cn("-mx-1 h-px bg-border", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 99,
	columnNumber: 3
}, this));
_c13 = CommandSeparator;
CommandSeparator.displayName = CommandPrimitive.Separator.displayName;
const CommandItem = React.forwardRef(_c14 = ({ className, ...props }, ref) => /* @__PURE__ */ _jsxDEV(CommandPrimitive.Item, {
	ref,
	className: cn("relative flex cursor-default gap-2 select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none data-[disabled=true]:pointer-events-none data-[selected=true]:bg-accent data-[selected=true]:text-accent-foreground data-[disabled=true]:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 111,
	columnNumber: 3
}, this));
_c15 = CommandItem;
CommandItem.displayName = CommandPrimitive.Item.displayName;
const CommandShortcut = ({ className, ...props }) => {
	return /* @__PURE__ */ _jsxDEV("span", {
		className: cn("ml-auto text-xs tracking-widest text-muted-foreground", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 125,
		columnNumber: 5
	}, this);
};
_c16 = CommandShortcut;
CommandShortcut.displayName = "CommandShortcut";
export { Command, CommandDialog, CommandInput, CommandList, CommandEmpty, CommandGroup, CommandItem, CommandShortcut, CommandSeparator };
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16;
$RefreshReg$(_c, "Command$React.forwardRef");
$RefreshReg$(_c2, "Command");
$RefreshReg$(_c3, "CommandDialog");
$RefreshReg$(_c4, "CommandInput$React.forwardRef");
$RefreshReg$(_c5, "CommandInput");
$RefreshReg$(_c6, "CommandList$React.forwardRef");
$RefreshReg$(_c7, "CommandList");
$RefreshReg$(_c8, "CommandEmpty$React.forwardRef");
$RefreshReg$(_c9, "CommandEmpty");
$RefreshReg$(_c10, "CommandGroup$React.forwardRef");
$RefreshReg$(_c11, "CommandGroup");
$RefreshReg$(_c12, "CommandSeparator$React.forwardRef");
$RefreshReg$(_c13, "CommandSeparator");
$RefreshReg$(_c14, "CommandItem$React.forwardRef");
$RefreshReg$(_c15, "CommandItem");
$RefreshReg$(_c16, "CommandShortcut");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/command.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/ui/command.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/ui/command.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/ui/command.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUE7QUFFQSxZQUFZLFdBQVc7QUFFdkIsU0FBUyxXQUFXLHdCQUF3QjtBQUM1QyxTQUFTLGNBQWM7QUFFdkIsU0FBUyxVQUFVO0FBQ25CLFNBQVMsUUFBUSxxQkFBcUI7OztBQUV0QyxNQUFNLFVBQVUsTUFBTSxpQkFHbkIsRUFBRSxXQUFXLEdBQUcsU0FBUyxRQUMxQix3QkFBQyxrQkFBRDtDQUNPO0NBQ0wsV0FBVyxHQUNULDZGQUNBLFNBQ0Y7Q0FDQSxHQUFJO0FBQ0w7Ozs7UUFDRjs7QUFDRCxRQUFRLGNBQWMsaUJBQWlCO0FBRXZDLE1BQU0saUJBQWlCLEVBQUUsVUFBVSxHQUFHLFlBQXlCO0NBQzdELE9BQ0Usd0JBQUMsUUFBRDtFQUFRLEdBQUk7WUFDVix3QkFBQyxlQUFEO0dBQWUsV0FBVTthQUN2Qix3QkFBQyxTQUFEO0lBQVMsV0FBVTtJQUNoQjtHQUNNOzs7OztFQUNJOzs7OztDQUNUOzs7OztBQUVaOztBQUVBLE1BQU0sZUFBZSxNQUFNLGtCQUd4QixFQUFFLFdBQVcsR0FBRyxTQUFTLFFBQzFCLHdCQUFDLE9BQUQ7Q0FBSyxXQUFVO0NBQWtDLHNCQUFtQjtXQUFwRSxDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLG1DQUFvQzs7OztXQUN0RCx3QkFBQyxpQkFBaUIsT0FBbEI7RUFDTztFQUNMLFdBQVcsR0FDVCwwSkFDQSxTQUNGO0VBQ0EsR0FBSTtDQUNMOzs7O1NBQ0U7Ozs7O1FBQ047O0FBRUQsYUFBYSxjQUFjLGlCQUFpQixNQUFNO0FBRWxELE1BQU0sY0FBYyxNQUFNLGtCQUd2QixFQUFFLFdBQVcsR0FBRyxTQUFTLFFBQzFCLHdCQUFDLGlCQUFpQixNQUFsQjtDQUNPO0NBQ0wsV0FBVyxHQUFHLG1EQUFtRCxTQUFTO0NBQzFFLEdBQUk7QUFDTDs7OztRQUNGOztBQUVELFlBQVksY0FBYyxpQkFBaUIsS0FBSztBQUVoRCxNQUFNLGVBQWUsTUFBTSxrQkFHeEIsT0FBTyxRQUNSLHdCQUFDLGlCQUFpQixPQUFsQjtDQUE2QjtDQUFLLFdBQVU7Q0FBMkIsR0FBSTtBQUFROzs7O1FBQ3BGOztBQUVELGFBQWEsY0FBYyxpQkFBaUIsTUFBTTtBQUVsRCxNQUFNLGVBQWUsTUFBTSxtQkFHeEIsRUFBRSxXQUFXLEdBQUcsU0FBUyxRQUMxQix3QkFBQyxpQkFBaUIsT0FBbEI7Q0FDTztDQUNMLFdBQVcsR0FDVCwwTkFDQSxTQUNGO0NBQ0EsR0FBSTtBQUNMOzs7O1FBQ0Y7O0FBRUQsYUFBYSxjQUFjLGlCQUFpQixNQUFNO0FBRWxELE1BQU0sbUJBQW1CLE1BQU0sbUJBRzVCLEVBQUUsV0FBVyxHQUFHLFNBQVMsUUFDMUIsd0JBQUMsaUJBQWlCLFdBQWxCO0NBQ087Q0FDTCxXQUFXLEdBQUcsd0JBQXdCLFNBQVM7Q0FDL0MsR0FBSTtBQUNMOzs7O1FBQ0Y7O0FBQ0QsaUJBQWlCLGNBQWMsaUJBQWlCLFVBQVU7QUFFMUQsTUFBTSxjQUFjLE1BQU0sbUJBR3ZCLEVBQUUsV0FBVyxHQUFHLFNBQVMsUUFDMUIsd0JBQUMsaUJBQWlCLE1BQWxCO0NBQ087Q0FDTCxXQUFXLEdBQ1QsMlRBQ0EsU0FDRjtDQUNBLEdBQUk7QUFDTDs7OztRQUNGOztBQUVELFlBQVksY0FBYyxpQkFBaUIsS0FBSztBQUVoRCxNQUFNLG1CQUFtQixFQUFFLFdBQVcsR0FBRyxZQUFtRDtDQUMxRixPQUNFLHdCQUFDLFFBQUQ7RUFDRSxXQUFXLEdBQUcseURBQXlELFNBQVM7RUFDaEYsR0FBSTtDQUNMOzs7OztBQUVMOztBQUNBLGdCQUFnQixjQUFjO0FBRTlCLFNBQ0UsU0FDQSxlQUNBLGNBQ0EsYUFDQSxjQUNBLGNBQ0EsYUFDQSxpQkFDQSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJjb21tYW5kLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBjbGllbnRcIjtcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB0eXBlIERpYWxvZ1Byb3BzIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1kaWFsb2dcIjtcbmltcG9ydCB7IENvbW1hbmQgYXMgQ29tbWFuZFByaW1pdGl2ZSB9IGZyb20gXCJjbWRrXCI7XG5pbXBvcnQgeyBTZWFyY2ggfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5cbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5pbXBvcnQgeyBEaWFsb2csIERpYWxvZ0NvbnRlbnQgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2RpYWxvZ1wiO1xuXG5jb25zdCBDb21tYW5kID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgUmVhY3QuRWxlbWVudFJlZjx0eXBlb2YgQ29tbWFuZFByaW1pdGl2ZT4sXG4gIFJlYWN0LkNvbXBvbmVudFByb3BzV2l0aG91dFJlZjx0eXBlb2YgQ29tbWFuZFByaW1pdGl2ZT5cbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcbiAgPENvbW1hbmRQcmltaXRpdmVcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgXCJmbGV4IGgtZnVsbCB3LWZ1bGwgZmxleC1jb2wgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtbWQgYmctcG9wb3ZlciB0ZXh0LXBvcG92ZXItZm9yZWdyb3VuZFwiLFxuICAgICAgY2xhc3NOYW1lLFxuICAgICl9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKSk7XG5Db21tYW5kLmRpc3BsYXlOYW1lID0gQ29tbWFuZFByaW1pdGl2ZS5kaXNwbGF5TmFtZTtcblxuY29uc3QgQ29tbWFuZERpYWxvZyA9ICh7IGNoaWxkcmVuLCAuLi5wcm9wcyB9OiBEaWFsb2dQcm9wcykgPT4ge1xuICByZXR1cm4gKFxuICAgIDxEaWFsb2cgey4uLnByb3BzfT5cbiAgICAgIDxEaWFsb2dDb250ZW50IGNsYXNzTmFtZT1cIm92ZXJmbG93LWhpZGRlbiBwLTBcIj5cbiAgICAgICAgPENvbW1hbmQgY2xhc3NOYW1lPVwiWyZfW2NtZGstZ3JvdXAtaGVhZGluZ11dOnB4LTIgWyZfW2NtZGstZ3JvdXAtaGVhZGluZ11dOmZvbnQtbWVkaXVtIFsmX1tjbWRrLWdyb3VwLWhlYWRpbmddXTp0ZXh0LW11dGVkLWZvcmVncm91bmQgWyZfW2NtZGstZ3JvdXBdOm5vdChbaGlkZGVuXSlffltjbWRrLWdyb3VwXV06cHQtMCBbJl9bY21kay1ncm91cF1dOnB4LTIgWyZfW2NtZGstaW5wdXQtd3JhcHBlcl1fc3ZnXTpoLTUgWyZfW2NtZGstaW5wdXQtd3JhcHBlcl1fc3ZnXTp3LTUgWyZfW2NtZGstaW5wdXRdXTpoLTEyIFsmX1tjbWRrLWl0ZW1dXTpweC0yIFsmX1tjbWRrLWl0ZW1dXTpweS0zIFsmX1tjbWRrLWl0ZW1dX3N2Z106aC01IFsmX1tjbWRrLWl0ZW1dX3N2Z106dy01XCI+XG4gICAgICAgICAge2NoaWxkcmVufVxuICAgICAgICA8L0NvbW1hbmQ+XG4gICAgICA8L0RpYWxvZ0NvbnRlbnQ+XG4gICAgPC9EaWFsb2c+XG4gICk7XG59O1xuXG5jb25zdCBDb21tYW5kSW5wdXQgPSBSZWFjdC5mb3J3YXJkUmVmPFxuICBSZWFjdC5FbGVtZW50UmVmPHR5cGVvZiBDb21tYW5kUHJpbWl0aXZlLklucHV0PixcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBDb21tYW5kUHJpbWl0aXZlLklucHV0PlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGJvcmRlci1iIHB4LTNcIiBjbWRrLWlucHV0LXdyYXBwZXI9XCJcIj5cbiAgICA8U2VhcmNoIGNsYXNzTmFtZT1cIm1yLTIgaC00IHctNCBzaHJpbmstMCBvcGFjaXR5LTUwXCIgLz5cbiAgICA8Q29tbWFuZFByaW1pdGl2ZS5JbnB1dFxuICAgICAgcmVmPXtyZWZ9XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImZsZXggaC0xMCB3LWZ1bGwgcm91bmRlZC1tZCBiZy10cmFuc3BhcmVudCBweS0zIHRleHQtc20gb3V0bGluZS1ub25lIHBsYWNlaG9sZGVyOnRleHQtbXV0ZWQtZm9yZWdyb3VuZCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgZGlzYWJsZWQ6b3BhY2l0eS01MFwiLFxuICAgICAgICBjbGFzc05hbWUsXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIDwvZGl2PlxuKSk7XG5cbkNvbW1hbmRJbnB1dC5kaXNwbGF5TmFtZSA9IENvbW1hbmRQcmltaXRpdmUuSW5wdXQuZGlzcGxheU5hbWU7XG5cbmNvbnN0IENvbW1hbmRMaXN0ID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgUmVhY3QuRWxlbWVudFJlZjx0eXBlb2YgQ29tbWFuZFByaW1pdGl2ZS5MaXN0PixcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBDb21tYW5kUHJpbWl0aXZlLkxpc3Q+XG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDxDb21tYW5kUHJpbWl0aXZlLkxpc3RcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFwibWF4LWgtWzMwMHB4XSBvdmVyZmxvdy15LWF1dG8gb3ZlcmZsb3cteC1oaWRkZW5cIiwgY2xhc3NOYW1lKX1cbiAgICB7Li4ucHJvcHN9XG4gIC8+XG4pKTtcblxuQ29tbWFuZExpc3QuZGlzcGxheU5hbWUgPSBDb21tYW5kUHJpbWl0aXZlLkxpc3QuZGlzcGxheU5hbWU7XG5cbmNvbnN0IENvbW1hbmRFbXB0eSA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIFJlYWN0LkVsZW1lbnRSZWY8dHlwZW9mIENvbW1hbmRQcmltaXRpdmUuRW1wdHk+LFxuICBSZWFjdC5Db21wb25lbnRQcm9wc1dpdGhvdXRSZWY8dHlwZW9mIENvbW1hbmRQcmltaXRpdmUuRW1wdHk+XG4+KChwcm9wcywgcmVmKSA9PiAoXG4gIDxDb21tYW5kUHJpbWl0aXZlLkVtcHR5IHJlZj17cmVmfSBjbGFzc05hbWU9XCJweS02IHRleHQtY2VudGVyIHRleHQtc21cIiB7Li4ucHJvcHN9IC8+XG4pKTtcblxuQ29tbWFuZEVtcHR5LmRpc3BsYXlOYW1lID0gQ29tbWFuZFByaW1pdGl2ZS5FbXB0eS5kaXNwbGF5TmFtZTtcblxuY29uc3QgQ29tbWFuZEdyb3VwID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgUmVhY3QuRWxlbWVudFJlZjx0eXBlb2YgQ29tbWFuZFByaW1pdGl2ZS5Hcm91cD4sXG4gIFJlYWN0LkNvbXBvbmVudFByb3BzV2l0aG91dFJlZjx0eXBlb2YgQ29tbWFuZFByaW1pdGl2ZS5Hcm91cD5cbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcbiAgPENvbW1hbmRQcmltaXRpdmUuR3JvdXBcbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgXCJvdmVyZmxvdy1oaWRkZW4gcC0xIHRleHQtZm9yZWdyb3VuZCBbJl9bY21kay1ncm91cC1oZWFkaW5nXV06cHgtMiBbJl9bY21kay1ncm91cC1oZWFkaW5nXV06cHktMS41IFsmX1tjbWRrLWdyb3VwLWhlYWRpbmddXTp0ZXh0LXhzIFsmX1tjbWRrLWdyb3VwLWhlYWRpbmddXTpmb250LW1lZGl1bSBbJl9bY21kay1ncm91cC1oZWFkaW5nXV06dGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIsXG4gICAgICBjbGFzc05hbWUsXG4gICAgKX1cbiAgICB7Li4ucHJvcHN9XG4gIC8+XG4pKTtcblxuQ29tbWFuZEdyb3VwLmRpc3BsYXlOYW1lID0gQ29tbWFuZFByaW1pdGl2ZS5Hcm91cC5kaXNwbGF5TmFtZTtcblxuY29uc3QgQ29tbWFuZFNlcGFyYXRvciA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIFJlYWN0LkVsZW1lbnRSZWY8dHlwZW9mIENvbW1hbmRQcmltaXRpdmUuU2VwYXJhdG9yPixcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBDb21tYW5kUHJpbWl0aXZlLlNlcGFyYXRvcj5cbj4oKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9LCByZWYpID0+IChcbiAgPENvbW1hbmRQcmltaXRpdmUuU2VwYXJhdG9yXG4gICAgcmVmPXtyZWZ9XG4gICAgY2xhc3NOYW1lPXtjbihcIi1teC0xIGgtcHggYmctYm9yZGVyXCIsIGNsYXNzTmFtZSl9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKSk7XG5Db21tYW5kU2VwYXJhdG9yLmRpc3BsYXlOYW1lID0gQ29tbWFuZFByaW1pdGl2ZS5TZXBhcmF0b3IuZGlzcGxheU5hbWU7XG5cbmNvbnN0IENvbW1hbmRJdGVtID0gUmVhY3QuZm9yd2FyZFJlZjxcbiAgUmVhY3QuRWxlbWVudFJlZjx0eXBlb2YgQ29tbWFuZFByaW1pdGl2ZS5JdGVtPixcbiAgUmVhY3QuQ29tcG9uZW50UHJvcHNXaXRob3V0UmVmPHR5cGVvZiBDb21tYW5kUHJpbWl0aXZlLkl0ZW0+XG4+KCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfSwgcmVmKSA9PiAoXG4gIDxDb21tYW5kUHJpbWl0aXZlLkl0ZW1cbiAgICByZWY9e3JlZn1cbiAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgXCJyZWxhdGl2ZSBmbGV4IGN1cnNvci1kZWZhdWx0IGdhcC0yIHNlbGVjdC1ub25lIGl0ZW1zLWNlbnRlciByb3VuZGVkLXNtIHB4LTIgcHktMS41IHRleHQtc20gb3V0bGluZS1ub25lIGRhdGEtW2Rpc2FibGVkPXRydWVdOnBvaW50ZXItZXZlbnRzLW5vbmUgZGF0YS1bc2VsZWN0ZWQ9dHJ1ZV06YmctYWNjZW50IGRhdGEtW3NlbGVjdGVkPXRydWVdOnRleHQtYWNjZW50LWZvcmVncm91bmQgZGF0YS1bZGlzYWJsZWQ9dHJ1ZV06b3BhY2l0eS01MCBbJl9zdmddOnBvaW50ZXItZXZlbnRzLW5vbmUgWyZfc3ZnXTpzaXplLTQgWyZfc3ZnXTpzaHJpbmstMFwiLFxuICAgICAgY2xhc3NOYW1lLFxuICAgICl9XG4gICAgey4uLnByb3BzfVxuICAvPlxuKSk7XG5cbkNvbW1hbmRJdGVtLmRpc3BsYXlOYW1lID0gQ29tbWFuZFByaW1pdGl2ZS5JdGVtLmRpc3BsYXlOYW1lO1xuXG5jb25zdCBDb21tYW5kU2hvcnRjdXQgPSAoeyBjbGFzc05hbWUsIC4uLnByb3BzIH06IFJlYWN0LkhUTUxBdHRyaWJ1dGVzPEhUTUxTcGFuRWxlbWVudD4pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3BhblxuICAgICAgY2xhc3NOYW1lPXtjbihcIm1sLWF1dG8gdGV4dC14cyB0cmFja2luZy13aWRlc3QgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIsIGNsYXNzTmFtZSl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKTtcbn07XG5Db21tYW5kU2hvcnRjdXQuZGlzcGxheU5hbWUgPSBcIkNvbW1hbmRTaG9ydGN1dFwiO1xuXG5leHBvcnQge1xuICBDb21tYW5kLFxuICBDb21tYW5kRGlhbG9nLFxuICBDb21tYW5kSW5wdXQsXG4gIENvbW1hbmRMaXN0LFxuICBDb21tYW5kRW1wdHksXG4gIENvbW1hbmRHcm91cCxcbiAgQ29tbWFuZEl0ZW0sXG4gIENvbW1hbmRTaG9ydGN1dCxcbiAgQ29tbWFuZFNlcGFyYXRvcixcbn07XG4iXX0=