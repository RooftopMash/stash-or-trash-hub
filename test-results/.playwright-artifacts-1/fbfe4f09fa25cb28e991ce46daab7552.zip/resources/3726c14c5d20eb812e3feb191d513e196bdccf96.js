const entries = [
	[
		"KOO",
		"Tinned Fruit",
		"Agriculture & Food Production"
	],
	[
		"KOO",
		"Tinned/Canned Beans",
		"Agriculture & Food Production"
	],
	[
		"KOO",
		"Tinned Vegetables",
		"Agriculture & Food Production"
	],
	[
		"Black Cat",
		"Peanut Butter & Spreads",
		"Consumer Goods"
	],
	[
		"Jungle Oats",
		"Breakfast Cereals & Oats",
		"Consumer Goods"
	],
	[
		"Doom",
		"Insecticides & Repellents",
		"Consumer Goods"
	],
	[
		"Fatti's & Moni's",
		"Pasta",
		"Agriculture & Food Production"
	],
	[
		"All Gold",
		"Jams & Marmalade",
		"Agriculture & Food Production"
	],
	[
		"Energade",
		"Sports Drinks",
		"Sports & Recreation"
	],
	[
		"Bathu",
		"Sneakers & Footwear",
		"Fashion & Apparel"
	],
	[
		"Drip Footwear",
		"Sneakers & Footwear",
		"Fashion & Apparel"
	],
	[
		"Veldskoen",
		"Footwear",
		"Fashion & Apparel"
	],
	[
		"GALXBOY",
		"Streetwear & Apparel",
		"Fashion & Apparel"
	],
	[
		"TSHEPO Denim",
		"Denim & Apparel",
		"Fashion & Apparel"
	],
	[
		"S.P.C.C",
		"Streetwear & Apparel",
		"Fashion & Apparel"
	],
	[
		"Freedom of Movement",
		"Apparel",
		"Fashion & Apparel"
	],
	[
		"Loxion Kulca",
		"Streetwear & Apparel",
		"Fashion & Apparel"
	],
	[
		"MaXhosa Africa",
		"High Fashion & Designer",
		"Luxury & Premium"
	],
	[
		"Rich Mnisi",
		"High Fashion & Designer",
		"Luxury & Premium"
	],
	[
		"Thebe Magugu",
		"High Fashion & Designer",
		"Luxury & Premium"
	],
	[
		"Pichulik",
		"Jewellery & Accessories",
		"Fashion & Apparel"
	],
	[
		"Kirsten Goss",
		"Jewellery & Accessories",
		"Fashion & Apparel"
	],
	[
		"Bellaghy Leather",
		"Leather Accessories",
		"Fashion & Apparel"
	],
	[
		"First Ascent",
		"Technical Outerwear & Gear",
		"Sports & Recreation"
	],
	[
		"Cape Union Mart",
		"Outdoor Gear & Lifestyle",
		"Retail & E-commerce"
	],
	[
		"Hi-Tec SA",
		"Outdoor Footwear & Gear",
		"Sports & Recreation"
	],
	[
		"African Nature",
		"Safari & Lifestyle",
		"Travel, Tourism & Hospitality"
	],
	[
		"Jonsson Workwear",
		"Workwear",
		"Consumer Goods"
	],
	[
		"OTG Active",
		"Activewear & Fitness",
		"Sports & Recreation"
	],
	[
		"Viva Athletics",
		"Activewear & Fitness",
		"Sports & Recreation"
	],
	[
		"Mrs Ball's",
		"Chutney & Pantry",
		"Agriculture & Food Production"
	],
	[
		"Tastic",
		"Rice & Pantry Staples",
		"Agriculture & Food Production"
	],
	[
		"Beacon",
		"Snacks & Sweets",
		"Consumer Goods"
	],
	[
		"Sally Williams",
		"Snacks & Sweets",
		"Consumer Goods"
	],
	[
		"NikNaks",
		"Snacks & Sweets",
		"Consumer Goods"
	],
	[
		"Chappies",
		"Confectionery",
		"Consumer Goods"
	],
	[
		"Clover",
		"Dairy & Proteins",
		"Agriculture & Food Production"
	],
	[
		"Fair Cape",
		"Dairy",
		"Agriculture & Food Production"
	],
	[
		"Eskort",
		"Meat & Proteins",
		"Agriculture & Food Production"
	],
	[
		"Oros",
		"Soft Drinks & Juices",
		"Agriculture & Food Production"
	],
	[
		"Ceres",
		"Soft Drinks & Juices",
		"Agriculture & Food Production"
	],
	[
		"BOS Iced Tea",
		"Soft Drinks & Juices",
		"Agriculture & Food Production"
	],
	[
		"Amarula",
		"Spirits & Liqueurs",
		"Consumer Goods"
	],
	[
		"Inverroche Gin",
		"Spirits & Liqueurs",
		"Consumer Goods"
	],
	[
		"Musgrave Gin",
		"Spirits & Liqueurs",
		"Consumer Goods"
	],
	[
		"KWV",
		"Wine & Spirits",
		"Consumer Goods"
	],
	[
		"Castle Lager",
		"Beer",
		"Consumer Goods"
	],
	[
		"Savanna Cider",
		"Cider",
		"Consumer Goods"
	],
	[
		"Devil's Peak Beer",
		"Craft Beer",
		"Consumer Goods"
	],
	[
		"Africology",
		"Skincare & Body",
		"Beauty & Personal Care"
	],
	[
		"Portia M",
		"Skincare & Haircare",
		"Beauty & Personal Care"
	],
	[
		"Woolworths Beauty",
		"Beauty Retail",
		"Beauty & Personal Care"
	],
	[
		"Inuka",
		"Beauty & Personal Care",
		"Beauty & Personal Care"
	],
	[
		"Native Child",
		"Haircare",
		"Beauty & Personal Care"
	],
	[
		"AfroBotanics",
		"Haircare",
		"Beauty & Personal Care"
	],
	[
		"Ardmore",
		"Decor & Textiles",
		"Home, Furniture & Living"
	],
	[
		"Skinny laMinx",
		"Decor & Textiles",
		"Home, Furniture & Living"
	],
	[
		"Mash T Design",
		"Home Design",
		"Home, Furniture & Living"
	],
	[
		"Rain",
		"Home Fragrance & Bath",
		"Home, Furniture & Living"
	],
	[
		"Charlotte Rhys",
		"Home Fragrance & Bath",
		"Home, Furniture & Living"
	],
	[
		"Flickering Grace",
		"Home Fragrance & Bath",
		"Home, Furniture & Living"
	]
];
function slugifySeed(value) {
	return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}
const internationalEntries = [
	[
		"Dangote",
		"Conglomerate",
		"Business & Finance",
		"NG"
	],
	[
		"Jumia",
		"E-commerce",
		"Retail & E-commerce",
		"NG"
	],
	[
		"Safaricom",
		"Telecommunications",
		"Technology & Telecom",
		"KE"
	],
	[
		"M-PESA",
		"Mobile payments",
		"Technology & Telecom",
		"KE"
	],
	[
		"MTN",
		"Telecommunications",
		"Technology & Telecom",
		"GH"
	],
	[
		"Ethiopian Airlines",
		"Airline",
		"Travel, Tourism & Hospitality",
		"ET"
	],
	[
		"Emirates",
		"Airline",
		"Travel, Tourism & Hospitality",
		"AE"
	],
	[
		"Tata",
		"Conglomerate",
		"Business & Finance",
		"IN"
	],
	[
		"Infosys",
		"Technology services",
		"Technology & Telecom",
		"IN"
	],
	[
		"Toyota",
		"Automotive",
		"Automotive & Mobility",
		"JP"
	],
	[
		"Sony",
		"Electronics",
		"Technology & Telecom",
		"JP"
	],
	[
		"Samsung",
		"Electronics",
		"Technology & Telecom",
		"KR"
	],
	[
		"Alibaba",
		"E-commerce",
		"Retail & E-commerce",
		"CN"
	],
	[
		"L'Oréal",
		"Beauty",
		"Beauty & Personal Care",
		"FR"
	],
	[
		"IKEA",
		"Furniture",
		"Home, Furniture & Living",
		"SE"
	],
	[
		"Adidas",
		"Sportswear",
		"Fashion & Apparel",
		"DE"
	],
	[
		"LEGO",
		"Toys",
		"Consumer Goods",
		"DK"
	],
	[
		"Spotify",
		"Music streaming",
		"Media & Entertainment",
		"SE"
	],
	[
		"Natura",
		"Beauty",
		"Beauty & Personal Care",
		"BR"
	],
	[
		"Mercado Libre",
		"E-commerce",
		"Retail & E-commerce",
		"AR"
	],
	[
		"Coca-Cola",
		"Beverages",
		"Agriculture & Food Production",
		"US"
	],
	[
		"Microsoft",
		"Software",
		"Technology & Telecom",
		"US"
	],
	[
		"Shopify",
		"E-commerce software",
		"Technology & Telecom",
		"CA"
	],
	[
		"Canva",
		"Design software",
		"Technology & Telecom",
		"AU"
	],
	[
		"Zara",
		"Fashion retail",
		"Fashion & Apparel",
		"ES"
	],
	[
		"Nestlé",
		"Food & Beverage",
		"Agriculture & Food Production",
		"CH"
	],
	[
		"LVMH",
		"Luxury goods",
		"Luxury & Premium",
		"FR"
	],
	[
		"Heineken",
		"Beverages",
		"Consumer Goods",
		"NL"
	],
	[
		"Mercadona",
		"Supermarkets",
		"Retail & E-commerce",
		"ES"
	],
	[
		"Beko",
		"Home appliances",
		"Home, Furniture & Living",
		"TR"
	],
	[
		"MobiPay",
		"Mobile payments",
		"Technology & Telecom",
		"TZ"
	],
	[
		"Vodacom Tanzania",
		"Telecommunications",
		"Technology & Telecom",
		"TZ"
	],
	[
		"Zamtel",
		"Telecommunications",
		"Technology & Telecom",
		"ZM"
	],
	[
		"Shoprite Zambia",
		"Retail",
		"Retail & E-commerce",
		"ZM"
	],
	[
		"MTC Namibia",
		"Telecommunications",
		"Technology & Telecom",
		"NA"
	],
	[
		"First National Bank Namibia",
		"Banking",
		"Business & Finance",
		"NA"
	],
	[
		"AIB",
		"Banking",
		"Business & Finance",
		"IE"
	],
	[
		"Ryanair",
		"Airline",
		"Travel, Tourism & Hospitality",
		"IE"
	],
	[
		"H&M",
		"Fashion retail",
		"Fashion & Apparel",
		"SE"
	],
	[
		"Ericsson",
		"Telecommunications",
		"Technology & Telecom",
		"SE"
	],
	[
		"ABB",
		"Engineering",
		"Industrial & Manufacturing",
		"CH"
	],
	[
		"UBS",
		"Banking",
		"Business & Finance",
		"CH"
	],
	[
		"Sasol",
		"Energy and chemicals",
		"Energy & Utilities",
		"ZA"
	],
	[
		"Safaricom Ethiopia",
		"Telecommunications",
		"Technology & Telecom",
		"ET"
	],
	[
		"KCB Group",
		"Banking",
		"Business & Finance",
		"KE"
	],
	[
		"Airtel Africa",
		"Telecommunications",
		"Technology & Telecom",
		"UG"
	],
	[
		"Sonatel",
		"Telecommunications",
		"Technology & Telecom",
		"SN"
	],
	[
		"Maroc Telecom",
		"Telecommunications",
		"Technology & Telecom",
		"MA"
	],
	[
		"Gulf Air",
		"Airline",
		"Travel, Tourism & Hospitality",
		"BH"
	],
	[
		"Qatar Airways",
		"Airline",
		"Travel, Tourism & Hospitality",
		"QA"
	],
	[
		"Etisalat",
		"Telecommunications",
		"Technology & Telecom",
		"AE"
	],
	[
		"Grab",
		"Mobility and delivery",
		"Technology & Telecom",
		"SG"
	],
	[
		"Gojek",
		"Mobility and delivery",
		"Technology & Telecom",
		"ID"
	],
	[
		"Kia",
		"Automotive",
		"Automotive & Mobility",
		"KR"
	],
	[
		"Lotte",
		"Conglomerate",
		"Consumer Goods",
		"KR"
	],
	[
		"Panasonic",
		"Electronics",
		"Technology & Telecom",
		"JP"
	],
	[
		"Rakuten",
		"E-commerce",
		"Retail & E-commerce",
		"JP"
	],
	[
		"BharatPe",
		"Payments",
		"Technology & Telecom",
		"IN"
	],
	[
		"Wipro",
		"Technology services",
		"Technology & Telecom",
		"IN"
	],
	[
		"DHL",
		"Logistics",
		"Transport & Logistics",
		"DE"
	],
	[
		"Siemens",
		"Engineering",
		"Industrial & Manufacturing",
		"DE"
	],
	[
		"Danone",
		"Food & Beverage",
		"Agriculture & Food Production",
		"FR"
	],
	[
		"Carrefour",
		"Retail",
		"Retail & E-commerce",
		"FR"
	],
	[
		"Volvo",
		"Automotive",
		"Automotive & Mobility",
		"SE"
	],
	[
		"Maersk",
		"Shipping and logistics",
		"Transport & Logistics",
		"DK"
	],
	[
		"Klarna",
		"Payments",
		"Technology & Telecom",
		"SE"
	],
	[
		"Patagonia",
		"Outdoor apparel",
		"Fashion & Apparel",
		"US"
	],
	[
		"Nike",
		"Sportswear",
		"Fashion & Apparel",
		"US"
	],
	[
		"Tim Hortons",
		"Food service",
		"Travel, Tourism & Hospitality",
		"CA"
	],
	[
		"Qantas",
		"Airline",
		"Travel, Tourism & Hospitality",
		"AU"
	],
	[
		"Woolworths Australia",
		"Retail",
		"Retail & E-commerce",
		"AU"
	],
	[
		"Falabella",
		"Retail",
		"Retail & E-commerce",
		"CL"
	],
	[
		"Bancolombia",
		"Banking",
		"Business & Finance",
		"CO"
	],
	[
		"YPF",
		"Energy",
		"Energy & Utilities",
		"AR"
	],
	[
		"Havaianas",
		"Footwear",
		"Fashion & Apparel",
		"BR"
	],
	[
		"Pemex",
		"Energy",
		"Energy & Utilities",
		"MX"
	],
	[
		"Kcell",
		"Telecommunications",
		"Technology & Telecom",
		"KZ"
	],
	[
		"LOT Polish Airlines",
		"Airline",
		"Travel, Tourism & Hospitality",
		"PL"
	],
	[
		"Allegro",
		"E-commerce",
		"Retail & E-commerce",
		"PL"
	],
	[
		"Norsk Hydro",
		"Materials",
		"Industrial & Manufacturing",
		"NO"
	],
	[
		"Equinor",
		"Energy",
		"Energy & Utilities",
		"NO"
	],
	[
		"Telia",
		"Telecommunications",
		"Technology & Telecom",
		"SE"
	]
];
export const INTERNATIONAL_SEED_BRANDS = internationalEntries.map(([name, descriptor, category, country], index) => ({
	id: `seed-global-${index + 1}`,
	owner_id: "seed-catalog",
	name,
	slug: `${slugifySeed(name)}-${country.toLowerCase()}`,
	description: `${descriptor} brand from ${country}. Community verification is still open.`,
	logo_url: null,
	website: null,
	category,
	country,
	verified: false,
	trust_score: 0,
	created_at: "2026-09-09T00:00:00.000Z",
	signedLogoUrl: null,
	ownerName: "SOT catalog"
}));
export const SOUTH_AFRICAN_SEED_BRANDS = entries.map(([name, descriptor, category], index) => ({
	id: `seed-za-${index + 1}`,
	owner_id: "seed-catalog",
	name,
	slug: `${slugifySeed(name)}-za`,
	description: `${descriptor} brand catalogued for South Africa. Community verification is still open.`,
	logo_url: null,
	website: null,
	category,
	country: "ZA",
	verified: false,
	trust_score: 0,
	created_at: "2026-09-09T00:00:00.000Z",
	signedLogoUrl: null,
	ownerName: "SOT catalog"
}));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBRUEsTUFBTSxVQUFVO0NBQ2Q7RUFBQztFQUFPO0VBQWdCO0NBQStCO0NBQ3ZEO0VBQUM7RUFBTztFQUF1QjtDQUErQjtDQUM5RDtFQUFDO0VBQU87RUFBcUI7Q0FBK0I7Q0FDNUQ7RUFBQztFQUFhO0VBQTJCO0NBQWdCO0NBQ3pEO0VBQUM7RUFBZTtFQUE0QjtDQUFnQjtDQUM1RDtFQUFDO0VBQVE7RUFBNkI7Q0FBZ0I7Q0FDdEQ7RUFBQztFQUFvQjtFQUFTO0NBQStCO0NBQzdEO0VBQUM7RUFBWTtFQUFvQjtDQUErQjtDQUNoRTtFQUFDO0VBQVk7RUFBaUI7Q0FBcUI7Q0FDbkQ7RUFBQztFQUFTO0VBQXVCO0NBQW1CO0NBQ3BEO0VBQUM7RUFBaUI7RUFBdUI7Q0FBbUI7Q0FDNUQ7RUFBQztFQUFhO0VBQVk7Q0FBbUI7Q0FDN0M7RUFBQztFQUFXO0VBQXdCO0NBQW1CO0NBQ3ZEO0VBQUM7RUFBZ0I7RUFBbUI7Q0FBbUI7Q0FDdkQ7RUFBQztFQUFXO0VBQXdCO0NBQW1CO0NBQ3ZEO0VBQUM7RUFBdUI7RUFBVztDQUFtQjtDQUN0RDtFQUFDO0VBQWdCO0VBQXdCO0NBQW1CO0NBQzVEO0VBQUM7RUFBa0I7RUFBMkI7Q0FBa0I7Q0FDaEU7RUFBQztFQUFjO0VBQTJCO0NBQWtCO0NBQzVEO0VBQUM7RUFBZ0I7RUFBMkI7Q0FBa0I7Q0FDOUQ7RUFBQztFQUFZO0VBQTJCO0NBQW1CO0NBQzNEO0VBQUM7RUFBZ0I7RUFBMkI7Q0FBbUI7Q0FDL0Q7RUFBQztFQUFvQjtFQUF1QjtDQUFtQjtDQUMvRDtFQUFDO0VBQWdCO0VBQThCO0NBQXFCO0NBQ3BFO0VBQUM7RUFBbUI7RUFBNEI7Q0FBcUI7Q0FDckU7RUFBQztFQUFhO0VBQTJCO0NBQXFCO0NBQzlEO0VBQUM7RUFBa0I7RUFBc0I7Q0FBK0I7Q0FDeEU7RUFBQztFQUFvQjtFQUFZO0NBQWdCO0NBQ2pEO0VBQUM7RUFBYztFQUF3QjtDQUFxQjtDQUM1RDtFQUFDO0VBQWtCO0VBQXdCO0NBQXFCO0NBQ2hFO0VBQUM7RUFBYztFQUFvQjtDQUErQjtDQUNsRTtFQUFDO0VBQVU7RUFBeUI7Q0FBK0I7Q0FDbkU7RUFBQztFQUFVO0VBQW1CO0NBQWdCO0NBQzlDO0VBQUM7RUFBa0I7RUFBbUI7Q0FBZ0I7Q0FDdEQ7RUFBQztFQUFXO0VBQW1CO0NBQWdCO0NBQy9DO0VBQUM7RUFBWTtFQUFpQjtDQUFnQjtDQUM5QztFQUFDO0VBQVU7RUFBb0I7Q0FBK0I7Q0FDOUQ7RUFBQztFQUFhO0VBQVM7Q0FBK0I7Q0FDdEQ7RUFBQztFQUFVO0VBQW1CO0NBQStCO0NBQzdEO0VBQUM7RUFBUTtFQUF3QjtDQUErQjtDQUNoRTtFQUFDO0VBQVM7RUFBd0I7Q0FBK0I7Q0FDakU7RUFBQztFQUFnQjtFQUF3QjtDQUErQjtDQUN4RTtFQUFDO0VBQVc7RUFBc0I7Q0FBZ0I7Q0FDbEQ7RUFBQztFQUFrQjtFQUFzQjtDQUFnQjtDQUN6RDtFQUFDO0VBQWdCO0VBQXNCO0NBQWdCO0NBQ3ZEO0VBQUM7RUFBTztFQUFrQjtDQUFnQjtDQUMxQztFQUFDO0VBQWdCO0VBQVE7Q0FBZ0I7Q0FDekM7RUFBQztFQUFpQjtFQUFTO0NBQWdCO0NBQzNDO0VBQUM7RUFBcUI7RUFBYztDQUFnQjtDQUNwRDtFQUFDO0VBQWM7RUFBbUI7Q0FBd0I7Q0FDMUQ7RUFBQztFQUFZO0VBQXVCO0NBQXdCO0NBQzVEO0VBQUM7RUFBcUI7RUFBaUI7Q0FBd0I7Q0FDL0Q7RUFBQztFQUFTO0VBQTBCO0NBQXdCO0NBQzVEO0VBQUM7RUFBZ0I7RUFBWTtDQUF3QjtDQUNyRDtFQUFDO0VBQWdCO0VBQVk7Q0FBd0I7Q0FDckQ7RUFBQztFQUFXO0VBQW9CO0NBQTBCO0NBQzFEO0VBQUM7RUFBaUI7RUFBb0I7Q0FBMEI7Q0FDaEU7RUFBQztFQUFpQjtFQUFlO0NBQTBCO0NBQzNEO0VBQUM7RUFBUTtFQUF5QjtDQUEwQjtDQUM1RDtFQUFDO0VBQWtCO0VBQXlCO0NBQTBCO0NBQ3RFO0VBQUM7RUFBb0I7RUFBeUI7Q0FBMEI7QUFDMUU7QUFFQSxTQUFTLFlBQVksT0FBZTtDQUNsQyxPQUFPLE1BQ0osWUFBWSxDQUFDLENBQ2IsUUFBUSxlQUFlLEdBQUcsQ0FBQyxDQUMzQixRQUFRLFVBQVUsRUFBRTtBQUN6QjtBQUVBLE1BQU0sdUJBQXVCO0NBQzNCO0VBQUM7RUFBVztFQUFnQjtFQUFzQjtDQUFJO0NBQUc7RUFBQztFQUFTO0VBQWM7RUFBdUI7Q0FBSTtDQUFHO0VBQUM7RUFBYTtFQUFzQjtFQUF3QjtDQUFJO0NBQUc7RUFBQztFQUFVO0VBQW1CO0VBQXdCO0NBQUk7Q0FBRztFQUFDO0VBQU87RUFBc0I7RUFBd0I7Q0FBSTtDQUFHO0VBQUM7RUFBc0I7RUFBVztFQUFpQztDQUFJO0NBQUc7RUFBQztFQUFZO0VBQVc7RUFBaUM7Q0FBSTtDQUFHO0VBQUM7RUFBUTtFQUFnQjtFQUFzQjtDQUFJO0NBQUc7RUFBQztFQUFXO0VBQXVCO0VBQXdCO0NBQUk7Q0FBRztFQUFDO0VBQVU7RUFBYztFQUF5QjtDQUFJO0NBQUc7RUFBQztFQUFRO0VBQWU7RUFBd0I7Q0FBSTtDQUFHO0VBQUM7RUFBVztFQUFlO0VBQXdCO0NBQUk7Q0FBRztFQUFDO0VBQVc7RUFBYztFQUF1QjtDQUFJO0NBQUc7RUFBQztFQUFXO0VBQVU7RUFBMEI7Q0FBSTtDQUFHO0VBQUM7RUFBUTtFQUFhO0VBQTRCO0NBQUk7Q0FBRztFQUFDO0VBQVU7RUFBYztFQUFxQjtDQUFJO0NBQUc7RUFBQztFQUFRO0VBQVE7RUFBa0I7Q0FBSTtDQUFHO0VBQUM7RUFBVztFQUFtQjtFQUF5QjtDQUFJO0NBQUc7RUFBQztFQUFVO0VBQVU7RUFBMEI7Q0FBSTtDQUFHO0VBQUM7RUFBaUI7RUFBYztFQUF1QjtDQUFJO0NBQUc7RUFBQztFQUFhO0VBQWE7RUFBaUM7Q0FBSTtDQUFHO0VBQUM7RUFBYTtFQUFZO0VBQXdCO0NBQUk7Q0FBRztFQUFDO0VBQVc7RUFBdUI7RUFBd0I7Q0FBSTtDQUFHO0VBQUM7RUFBUztFQUFtQjtFQUF3QjtDQUFJO0NBQUc7RUFBQztFQUFRO0VBQWtCO0VBQXFCO0NBQUk7Q0FBRztFQUFDO0VBQVU7RUFBbUI7RUFBaUM7Q0FBSTtDQUFHO0VBQUM7RUFBUTtFQUFnQjtFQUFvQjtDQUFJO0NBQUc7RUFBQztFQUFZO0VBQWE7RUFBa0I7Q0FBSTtDQUFHO0VBQUM7RUFBYTtFQUFnQjtFQUF1QjtDQUFJO0NBQUc7RUFBQztFQUFRO0VBQW1CO0VBQTRCO0NBQUk7Q0FDeHVEO0VBQUM7RUFBVztFQUFtQjtFQUF3QjtDQUFJO0NBQUc7RUFBQztFQUFvQjtFQUFzQjtFQUF3QjtDQUFJO0NBQUc7RUFBQztFQUFVO0VBQXNCO0VBQXdCO0NBQUk7Q0FBRztFQUFDO0VBQW1CO0VBQVU7RUFBdUI7Q0FBSTtDQUFHO0VBQUM7RUFBZTtFQUFzQjtFQUF3QjtDQUFJO0NBQUc7RUFBQztFQUErQjtFQUFXO0VBQXNCO0NBQUk7Q0FBRztFQUFDO0VBQU87RUFBVztFQUFzQjtDQUFJO0NBQUc7RUFBQztFQUFXO0VBQVc7RUFBaUM7Q0FBSTtDQUFHO0VBQUM7RUFBTztFQUFrQjtFQUFxQjtDQUFJO0NBQUc7RUFBQztFQUFZO0VBQXNCO0VBQXdCO0NBQUk7Q0FBRztFQUFDO0VBQU87RUFBZTtFQUE4QjtDQUFJO0NBQUc7RUFBQztFQUFPO0VBQVc7RUFBc0I7Q0FBSTtDQUFHO0VBQUM7RUFBUztFQUF3QjtFQUFzQjtDQUFJO0NBQUc7RUFBQztFQUFzQjtFQUFzQjtFQUF3QjtDQUFJO0NBQUc7RUFBQztFQUFhO0VBQVc7RUFBc0I7Q0FBSTtDQUFHO0VBQUM7RUFBaUI7RUFBc0I7RUFBd0I7Q0FBSTtDQUFHO0VBQUM7RUFBVztFQUFzQjtFQUF3QjtDQUFJO0NBQUc7RUFBQztFQUFpQjtFQUFzQjtFQUF3QjtDQUFJO0NBQUc7RUFBQztFQUFZO0VBQVc7RUFBaUM7Q0FBSTtDQUFHO0VBQUM7RUFBaUI7RUFBVztFQUFpQztDQUFJO0NBQUc7RUFBQztFQUFZO0VBQXNCO0VBQXdCO0NBQUk7Q0FBRztFQUFDO0VBQVE7RUFBeUI7RUFBd0I7Q0FBSTtDQUFHO0VBQUM7RUFBUztFQUF5QjtFQUF3QjtDQUFJO0NBQUc7RUFBQztFQUFPO0VBQWM7RUFBeUI7Q0FBSTtDQUFHO0VBQUM7RUFBUztFQUFnQjtFQUFrQjtDQUFJO0NBQUc7RUFBQztFQUFhO0VBQWU7RUFBd0I7Q0FBSTtDQUFHO0VBQUM7RUFBVztFQUFjO0VBQXVCO0NBQUk7Q0FBRztFQUFDO0VBQVk7RUFBWTtFQUF3QjtDQUFJO0NBQUc7RUFBQztFQUFTO0VBQXVCO0VBQXdCO0NBQUk7Q0FBRztFQUFDO0VBQU87RUFBYTtFQUF5QjtDQUFJO0NBQUc7RUFBQztFQUFXO0VBQWU7RUFBOEI7Q0FBSTtDQUFHO0VBQUM7RUFBVTtFQUFtQjtFQUFpQztDQUFJO0NBQUc7RUFBQztFQUFhO0VBQVU7RUFBdUI7Q0FBSTtDQUFHO0VBQUM7RUFBUztFQUFjO0VBQXlCO0NBQUk7Q0FBRztFQUFDO0VBQVU7RUFBMEI7RUFBeUI7Q0FBSTtDQUFHO0VBQUM7RUFBVTtFQUFZO0VBQXdCO0NBQUk7Q0FBRztFQUFDO0VBQWE7RUFBbUI7RUFBcUI7Q0FBSTtDQUFHO0VBQUM7RUFBUTtFQUFjO0VBQXFCO0NBQUk7Q0FBRztFQUFDO0VBQWU7RUFBZ0I7RUFBaUM7Q0FBSTtDQUFHO0VBQUM7RUFBVTtFQUFXO0VBQWlDO0NBQUk7Q0FBRztFQUFDO0VBQXdCO0VBQVU7RUFBdUI7Q0FBSTtDQUFHO0VBQUM7RUFBYTtFQUFVO0VBQXVCO0NBQUk7Q0FBRztFQUFDO0VBQWU7RUFBVztFQUFzQjtDQUFJO0NBQUc7RUFBQztFQUFPO0VBQVU7RUFBc0I7Q0FBSTtDQUFHO0VBQUM7RUFBYTtFQUFZO0VBQXFCO0NBQUk7Q0FBRztFQUFDO0VBQVM7RUFBVTtFQUFzQjtDQUFJO0NBQUc7RUFBQztFQUFTO0VBQXNCO0VBQXdCO0NBQUk7Q0FBRztFQUFDO0VBQXVCO0VBQVc7RUFBaUM7Q0FBSTtDQUFHO0VBQUM7RUFBVztFQUFjO0VBQXVCO0NBQUk7Q0FBRztFQUFDO0VBQWU7RUFBYTtFQUE4QjtDQUFJO0NBQUc7RUFBQztFQUFXO0VBQVU7RUFBc0I7Q0FBSTtDQUFHO0VBQUM7RUFBUztFQUFzQjtFQUF3QjtDQUFJO0FBQ3ZtRztBQUVBLE9BQU8sTUFBTSw0QkFBcUMscUJBQXFCLEtBQUssQ0FBQyxNQUFNLFlBQVksVUFBVSxVQUFVLFdBQVc7Q0FDNUgsSUFBSSxlQUFlLFFBQVE7Q0FBSyxVQUFVO0NBQWdCO0NBQU0sTUFBTSxHQUFHLFlBQVksSUFBSSxFQUFFLEdBQUcsUUFBUSxZQUFZO0NBQUssYUFBYSxHQUFHLFdBQVcsY0FBYyxRQUFRO0NBQTBDLFVBQVU7Q0FBTSxTQUFTO0NBQU07Q0FBVTtDQUFTLFVBQVU7Q0FBTyxhQUFhO0NBQUcsWUFBWTtDQUE0QixlQUFlO0NBQU0sV0FBVztBQUMvVyxFQUFFO0FBRUYsT0FBTyxNQUFNLDRCQUFxQyxRQUFRLEtBQ3ZELENBQUMsTUFBTSxZQUFZLFdBQVcsV0FBVztDQUN4QyxJQUFJLFdBQVcsUUFBUTtDQUN2QixVQUFVO0NBQ1Y7Q0FDQSxNQUFNLEdBQUcsWUFBWSxJQUFJLEVBQUU7Q0FDM0IsYUFBYSxHQUFHLFdBQVc7Q0FDM0IsVUFBVTtDQUNWLFNBQVM7Q0FDVDtDQUNBLFNBQVM7Q0FDVCxVQUFVO0NBQ1YsYUFBYTtDQUNiLFlBQVk7Q0FDWixlQUFlO0NBQ2YsV0FBVztBQUNiLEVBQ0YiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsic2VlZC1icmFuZHMudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBCcmFuZCB9IGZyb20gXCJAL2xpYi9icmFuZHNcIjtcblxuY29uc3QgZW50cmllcyA9IFtcbiAgW1wiS09PXCIsIFwiVGlubmVkIEZydWl0XCIsIFwiQWdyaWN1bHR1cmUgJiBGb29kIFByb2R1Y3Rpb25cIl0sXG4gIFtcIktPT1wiLCBcIlRpbm5lZC9DYW5uZWQgQmVhbnNcIiwgXCJBZ3JpY3VsdHVyZSAmIEZvb2QgUHJvZHVjdGlvblwiXSxcbiAgW1wiS09PXCIsIFwiVGlubmVkIFZlZ2V0YWJsZXNcIiwgXCJBZ3JpY3VsdHVyZSAmIEZvb2QgUHJvZHVjdGlvblwiXSxcbiAgW1wiQmxhY2sgQ2F0XCIsIFwiUGVhbnV0IEJ1dHRlciAmIFNwcmVhZHNcIiwgXCJDb25zdW1lciBHb29kc1wiXSxcbiAgW1wiSnVuZ2xlIE9hdHNcIiwgXCJCcmVha2Zhc3QgQ2VyZWFscyAmIE9hdHNcIiwgXCJDb25zdW1lciBHb29kc1wiXSxcbiAgW1wiRG9vbVwiLCBcIkluc2VjdGljaWRlcyAmIFJlcGVsbGVudHNcIiwgXCJDb25zdW1lciBHb29kc1wiXSxcbiAgW1wiRmF0dGkncyAmIE1vbmknc1wiLCBcIlBhc3RhXCIsIFwiQWdyaWN1bHR1cmUgJiBGb29kIFByb2R1Y3Rpb25cIl0sXG4gIFtcIkFsbCBHb2xkXCIsIFwiSmFtcyAmIE1hcm1hbGFkZVwiLCBcIkFncmljdWx0dXJlICYgRm9vZCBQcm9kdWN0aW9uXCJdLFxuICBbXCJFbmVyZ2FkZVwiLCBcIlNwb3J0cyBEcmlua3NcIiwgXCJTcG9ydHMgJiBSZWNyZWF0aW9uXCJdLFxuICBbXCJCYXRodVwiLCBcIlNuZWFrZXJzICYgRm9vdHdlYXJcIiwgXCJGYXNoaW9uICYgQXBwYXJlbFwiXSxcbiAgW1wiRHJpcCBGb290d2VhclwiLCBcIlNuZWFrZXJzICYgRm9vdHdlYXJcIiwgXCJGYXNoaW9uICYgQXBwYXJlbFwiXSxcbiAgW1wiVmVsZHNrb2VuXCIsIFwiRm9vdHdlYXJcIiwgXCJGYXNoaW9uICYgQXBwYXJlbFwiXSxcbiAgW1wiR0FMWEJPWVwiLCBcIlN0cmVldHdlYXIgJiBBcHBhcmVsXCIsIFwiRmFzaGlvbiAmIEFwcGFyZWxcIl0sXG4gIFtcIlRTSEVQTyBEZW5pbVwiLCBcIkRlbmltICYgQXBwYXJlbFwiLCBcIkZhc2hpb24gJiBBcHBhcmVsXCJdLFxuICBbXCJTLlAuQy5DXCIsIFwiU3RyZWV0d2VhciAmIEFwcGFyZWxcIiwgXCJGYXNoaW9uICYgQXBwYXJlbFwiXSxcbiAgW1wiRnJlZWRvbSBvZiBNb3ZlbWVudFwiLCBcIkFwcGFyZWxcIiwgXCJGYXNoaW9uICYgQXBwYXJlbFwiXSxcbiAgW1wiTG94aW9uIEt1bGNhXCIsIFwiU3RyZWV0d2VhciAmIEFwcGFyZWxcIiwgXCJGYXNoaW9uICYgQXBwYXJlbFwiXSxcbiAgW1wiTWFYaG9zYSBBZnJpY2FcIiwgXCJIaWdoIEZhc2hpb24gJiBEZXNpZ25lclwiLCBcIkx1eHVyeSAmIFByZW1pdW1cIl0sXG4gIFtcIlJpY2ggTW5pc2lcIiwgXCJIaWdoIEZhc2hpb24gJiBEZXNpZ25lclwiLCBcIkx1eHVyeSAmIFByZW1pdW1cIl0sXG4gIFtcIlRoZWJlIE1hZ3VndVwiLCBcIkhpZ2ggRmFzaGlvbiAmIERlc2lnbmVyXCIsIFwiTHV4dXJ5ICYgUHJlbWl1bVwiXSxcbiAgW1wiUGljaHVsaWtcIiwgXCJKZXdlbGxlcnkgJiBBY2Nlc3Nvcmllc1wiLCBcIkZhc2hpb24gJiBBcHBhcmVsXCJdLFxuICBbXCJLaXJzdGVuIEdvc3NcIiwgXCJKZXdlbGxlcnkgJiBBY2Nlc3Nvcmllc1wiLCBcIkZhc2hpb24gJiBBcHBhcmVsXCJdLFxuICBbXCJCZWxsYWdoeSBMZWF0aGVyXCIsIFwiTGVhdGhlciBBY2Nlc3Nvcmllc1wiLCBcIkZhc2hpb24gJiBBcHBhcmVsXCJdLFxuICBbXCJGaXJzdCBBc2NlbnRcIiwgXCJUZWNobmljYWwgT3V0ZXJ3ZWFyICYgR2VhclwiLCBcIlNwb3J0cyAmIFJlY3JlYXRpb25cIl0sXG4gIFtcIkNhcGUgVW5pb24gTWFydFwiLCBcIk91dGRvb3IgR2VhciAmIExpZmVzdHlsZVwiLCBcIlJldGFpbCAmIEUtY29tbWVyY2VcIl0sXG4gIFtcIkhpLVRlYyBTQVwiLCBcIk91dGRvb3IgRm9vdHdlYXIgJiBHZWFyXCIsIFwiU3BvcnRzICYgUmVjcmVhdGlvblwiXSxcbiAgW1wiQWZyaWNhbiBOYXR1cmVcIiwgXCJTYWZhcmkgJiBMaWZlc3R5bGVcIiwgXCJUcmF2ZWwsIFRvdXJpc20gJiBIb3NwaXRhbGl0eVwiXSxcbiAgW1wiSm9uc3NvbiBXb3Jrd2VhclwiLCBcIldvcmt3ZWFyXCIsIFwiQ29uc3VtZXIgR29vZHNcIl0sXG4gIFtcIk9URyBBY3RpdmVcIiwgXCJBY3RpdmV3ZWFyICYgRml0bmVzc1wiLCBcIlNwb3J0cyAmIFJlY3JlYXRpb25cIl0sXG4gIFtcIlZpdmEgQXRobGV0aWNzXCIsIFwiQWN0aXZld2VhciAmIEZpdG5lc3NcIiwgXCJTcG9ydHMgJiBSZWNyZWF0aW9uXCJdLFxuICBbXCJNcnMgQmFsbCdzXCIsIFwiQ2h1dG5leSAmIFBhbnRyeVwiLCBcIkFncmljdWx0dXJlICYgRm9vZCBQcm9kdWN0aW9uXCJdLFxuICBbXCJUYXN0aWNcIiwgXCJSaWNlICYgUGFudHJ5IFN0YXBsZXNcIiwgXCJBZ3JpY3VsdHVyZSAmIEZvb2QgUHJvZHVjdGlvblwiXSxcbiAgW1wiQmVhY29uXCIsIFwiU25hY2tzICYgU3dlZXRzXCIsIFwiQ29uc3VtZXIgR29vZHNcIl0sXG4gIFtcIlNhbGx5IFdpbGxpYW1zXCIsIFwiU25hY2tzICYgU3dlZXRzXCIsIFwiQ29uc3VtZXIgR29vZHNcIl0sXG4gIFtcIk5pa05ha3NcIiwgXCJTbmFja3MgJiBTd2VldHNcIiwgXCJDb25zdW1lciBHb29kc1wiXSxcbiAgW1wiQ2hhcHBpZXNcIiwgXCJDb25mZWN0aW9uZXJ5XCIsIFwiQ29uc3VtZXIgR29vZHNcIl0sXG4gIFtcIkNsb3ZlclwiLCBcIkRhaXJ5ICYgUHJvdGVpbnNcIiwgXCJBZ3JpY3VsdHVyZSAmIEZvb2QgUHJvZHVjdGlvblwiXSxcbiAgW1wiRmFpciBDYXBlXCIsIFwiRGFpcnlcIiwgXCJBZ3JpY3VsdHVyZSAmIEZvb2QgUHJvZHVjdGlvblwiXSxcbiAgW1wiRXNrb3J0XCIsIFwiTWVhdCAmIFByb3RlaW5zXCIsIFwiQWdyaWN1bHR1cmUgJiBGb29kIFByb2R1Y3Rpb25cIl0sXG4gIFtcIk9yb3NcIiwgXCJTb2Z0IERyaW5rcyAmIEp1aWNlc1wiLCBcIkFncmljdWx0dXJlICYgRm9vZCBQcm9kdWN0aW9uXCJdLFxuICBbXCJDZXJlc1wiLCBcIlNvZnQgRHJpbmtzICYgSnVpY2VzXCIsIFwiQWdyaWN1bHR1cmUgJiBGb29kIFByb2R1Y3Rpb25cIl0sXG4gIFtcIkJPUyBJY2VkIFRlYVwiLCBcIlNvZnQgRHJpbmtzICYgSnVpY2VzXCIsIFwiQWdyaWN1bHR1cmUgJiBGb29kIFByb2R1Y3Rpb25cIl0sXG4gIFtcIkFtYXJ1bGFcIiwgXCJTcGlyaXRzICYgTGlxdWV1cnNcIiwgXCJDb25zdW1lciBHb29kc1wiXSxcbiAgW1wiSW52ZXJyb2NoZSBHaW5cIiwgXCJTcGlyaXRzICYgTGlxdWV1cnNcIiwgXCJDb25zdW1lciBHb29kc1wiXSxcbiAgW1wiTXVzZ3JhdmUgR2luXCIsIFwiU3Bpcml0cyAmIExpcXVldXJzXCIsIFwiQ29uc3VtZXIgR29vZHNcIl0sXG4gIFtcIktXVlwiLCBcIldpbmUgJiBTcGlyaXRzXCIsIFwiQ29uc3VtZXIgR29vZHNcIl0sXG4gIFtcIkNhc3RsZSBMYWdlclwiLCBcIkJlZXJcIiwgXCJDb25zdW1lciBHb29kc1wiXSxcbiAgW1wiU2F2YW5uYSBDaWRlclwiLCBcIkNpZGVyXCIsIFwiQ29uc3VtZXIgR29vZHNcIl0sXG4gIFtcIkRldmlsJ3MgUGVhayBCZWVyXCIsIFwiQ3JhZnQgQmVlclwiLCBcIkNvbnN1bWVyIEdvb2RzXCJdLFxuICBbXCJBZnJpY29sb2d5XCIsIFwiU2tpbmNhcmUgJiBCb2R5XCIsIFwiQmVhdXR5ICYgUGVyc29uYWwgQ2FyZVwiXSxcbiAgW1wiUG9ydGlhIE1cIiwgXCJTa2luY2FyZSAmIEhhaXJjYXJlXCIsIFwiQmVhdXR5ICYgUGVyc29uYWwgQ2FyZVwiXSxcbiAgW1wiV29vbHdvcnRocyBCZWF1dHlcIiwgXCJCZWF1dHkgUmV0YWlsXCIsIFwiQmVhdXR5ICYgUGVyc29uYWwgQ2FyZVwiXSxcbiAgW1wiSW51a2FcIiwgXCJCZWF1dHkgJiBQZXJzb25hbCBDYXJlXCIsIFwiQmVhdXR5ICYgUGVyc29uYWwgQ2FyZVwiXSxcbiAgW1wiTmF0aXZlIENoaWxkXCIsIFwiSGFpcmNhcmVcIiwgXCJCZWF1dHkgJiBQZXJzb25hbCBDYXJlXCJdLFxuICBbXCJBZnJvQm90YW5pY3NcIiwgXCJIYWlyY2FyZVwiLCBcIkJlYXV0eSAmIFBlcnNvbmFsIENhcmVcIl0sXG4gIFtcIkFyZG1vcmVcIiwgXCJEZWNvciAmIFRleHRpbGVzXCIsIFwiSG9tZSwgRnVybml0dXJlICYgTGl2aW5nXCJdLFxuICBbXCJTa2lubnkgbGFNaW54XCIsIFwiRGVjb3IgJiBUZXh0aWxlc1wiLCBcIkhvbWUsIEZ1cm5pdHVyZSAmIExpdmluZ1wiXSxcbiAgW1wiTWFzaCBUIERlc2lnblwiLCBcIkhvbWUgRGVzaWduXCIsIFwiSG9tZSwgRnVybml0dXJlICYgTGl2aW5nXCJdLFxuICBbXCJSYWluXCIsIFwiSG9tZSBGcmFncmFuY2UgJiBCYXRoXCIsIFwiSG9tZSwgRnVybml0dXJlICYgTGl2aW5nXCJdLFxuICBbXCJDaGFybG90dGUgUmh5c1wiLCBcIkhvbWUgRnJhZ3JhbmNlICYgQmF0aFwiLCBcIkhvbWUsIEZ1cm5pdHVyZSAmIExpdmluZ1wiXSxcbiAgW1wiRmxpY2tlcmluZyBHcmFjZVwiLCBcIkhvbWUgRnJhZ3JhbmNlICYgQmF0aFwiLCBcIkhvbWUsIEZ1cm5pdHVyZSAmIExpdmluZ1wiXSxcbl0gYXMgY29uc3Q7XG5cbmZ1bmN0aW9uIHNsdWdpZnlTZWVkKHZhbHVlOiBzdHJpbmcpIHtcbiAgcmV0dXJuIHZhbHVlXG4gICAgLnRvTG93ZXJDYXNlKClcbiAgICAucmVwbGFjZSgvW15hLXowLTldKy9nLCBcIi1cIilcbiAgICAucmVwbGFjZSgvXi18LSQvZywgXCJcIik7XG59XG5cbmNvbnN0IGludGVybmF0aW9uYWxFbnRyaWVzID0gW1xuICBbXCJEYW5nb3RlXCIsIFwiQ29uZ2xvbWVyYXRlXCIsIFwiQnVzaW5lc3MgJiBGaW5hbmNlXCIsIFwiTkdcIl0sIFtcIkp1bWlhXCIsIFwiRS1jb21tZXJjZVwiLCBcIlJldGFpbCAmIEUtY29tbWVyY2VcIiwgXCJOR1wiXSwgW1wiU2FmYXJpY29tXCIsIFwiVGVsZWNvbW11bmljYXRpb25zXCIsIFwiVGVjaG5vbG9neSAmIFRlbGVjb21cIiwgXCJLRVwiXSwgW1wiTS1QRVNBXCIsIFwiTW9iaWxlIHBheW1lbnRzXCIsIFwiVGVjaG5vbG9neSAmIFRlbGVjb21cIiwgXCJLRVwiXSwgW1wiTVROXCIsIFwiVGVsZWNvbW11bmljYXRpb25zXCIsIFwiVGVjaG5vbG9neSAmIFRlbGVjb21cIiwgXCJHSFwiXSwgW1wiRXRoaW9waWFuIEFpcmxpbmVzXCIsIFwiQWlybGluZVwiLCBcIlRyYXZlbCwgVG91cmlzbSAmIEhvc3BpdGFsaXR5XCIsIFwiRVRcIl0sIFtcIkVtaXJhdGVzXCIsIFwiQWlybGluZVwiLCBcIlRyYXZlbCwgVG91cmlzbSAmIEhvc3BpdGFsaXR5XCIsIFwiQUVcIl0sIFtcIlRhdGFcIiwgXCJDb25nbG9tZXJhdGVcIiwgXCJCdXNpbmVzcyAmIEZpbmFuY2VcIiwgXCJJTlwiXSwgW1wiSW5mb3N5c1wiLCBcIlRlY2hub2xvZ3kgc2VydmljZXNcIiwgXCJUZWNobm9sb2d5ICYgVGVsZWNvbVwiLCBcIklOXCJdLCBbXCJUb3lvdGFcIiwgXCJBdXRvbW90aXZlXCIsIFwiQXV0b21vdGl2ZSAmIE1vYmlsaXR5XCIsIFwiSlBcIl0sIFtcIlNvbnlcIiwgXCJFbGVjdHJvbmljc1wiLCBcIlRlY2hub2xvZ3kgJiBUZWxlY29tXCIsIFwiSlBcIl0sIFtcIlNhbXN1bmdcIiwgXCJFbGVjdHJvbmljc1wiLCBcIlRlY2hub2xvZ3kgJiBUZWxlY29tXCIsIFwiS1JcIl0sIFtcIkFsaWJhYmFcIiwgXCJFLWNvbW1lcmNlXCIsIFwiUmV0YWlsICYgRS1jb21tZXJjZVwiLCBcIkNOXCJdLCBbXCJMJ09yw6lhbFwiLCBcIkJlYXV0eVwiLCBcIkJlYXV0eSAmIFBlcnNvbmFsIENhcmVcIiwgXCJGUlwiXSwgW1wiSUtFQVwiLCBcIkZ1cm5pdHVyZVwiLCBcIkhvbWUsIEZ1cm5pdHVyZSAmIExpdmluZ1wiLCBcIlNFXCJdLCBbXCJBZGlkYXNcIiwgXCJTcG9ydHN3ZWFyXCIsIFwiRmFzaGlvbiAmIEFwcGFyZWxcIiwgXCJERVwiXSwgW1wiTEVHT1wiLCBcIlRveXNcIiwgXCJDb25zdW1lciBHb29kc1wiLCBcIkRLXCJdLCBbXCJTcG90aWZ5XCIsIFwiTXVzaWMgc3RyZWFtaW5nXCIsIFwiTWVkaWEgJiBFbnRlcnRhaW5tZW50XCIsIFwiU0VcIl0sIFtcIk5hdHVyYVwiLCBcIkJlYXV0eVwiLCBcIkJlYXV0eSAmIFBlcnNvbmFsIENhcmVcIiwgXCJCUlwiXSwgW1wiTWVyY2FkbyBMaWJyZVwiLCBcIkUtY29tbWVyY2VcIiwgXCJSZXRhaWwgJiBFLWNvbW1lcmNlXCIsIFwiQVJcIl0sIFtcIkNvY2EtQ29sYVwiLCBcIkJldmVyYWdlc1wiLCBcIkFncmljdWx0dXJlICYgRm9vZCBQcm9kdWN0aW9uXCIsIFwiVVNcIl0sIFtcIk1pY3Jvc29mdFwiLCBcIlNvZnR3YXJlXCIsIFwiVGVjaG5vbG9neSAmIFRlbGVjb21cIiwgXCJVU1wiXSwgW1wiU2hvcGlmeVwiLCBcIkUtY29tbWVyY2Ugc29mdHdhcmVcIiwgXCJUZWNobm9sb2d5ICYgVGVsZWNvbVwiLCBcIkNBXCJdLCBbXCJDYW52YVwiLCBcIkRlc2lnbiBzb2Z0d2FyZVwiLCBcIlRlY2hub2xvZ3kgJiBUZWxlY29tXCIsIFwiQVVcIl0sIFtcIlphcmFcIiwgXCJGYXNoaW9uIHJldGFpbFwiLCBcIkZhc2hpb24gJiBBcHBhcmVsXCIsIFwiRVNcIl0sIFtcIk5lc3Rsw6lcIiwgXCJGb29kICYgQmV2ZXJhZ2VcIiwgXCJBZ3JpY3VsdHVyZSAmIEZvb2QgUHJvZHVjdGlvblwiLCBcIkNIXCJdLCBbXCJMVk1IXCIsIFwiTHV4dXJ5IGdvb2RzXCIsIFwiTHV4dXJ5ICYgUHJlbWl1bVwiLCBcIkZSXCJdLCBbXCJIZWluZWtlblwiLCBcIkJldmVyYWdlc1wiLCBcIkNvbnN1bWVyIEdvb2RzXCIsIFwiTkxcIl0sIFtcIk1lcmNhZG9uYVwiLCBcIlN1cGVybWFya2V0c1wiLCBcIlJldGFpbCAmIEUtY29tbWVyY2VcIiwgXCJFU1wiXSwgW1wiQmVrb1wiLCBcIkhvbWUgYXBwbGlhbmNlc1wiLCBcIkhvbWUsIEZ1cm5pdHVyZSAmIExpdmluZ1wiLCBcIlRSXCJdLFxuICBbXCJNb2JpUGF5XCIsIFwiTW9iaWxlIHBheW1lbnRzXCIsIFwiVGVjaG5vbG9neSAmIFRlbGVjb21cIiwgXCJUWlwiXSwgW1wiVm9kYWNvbSBUYW56YW5pYVwiLCBcIlRlbGVjb21tdW5pY2F0aW9uc1wiLCBcIlRlY2hub2xvZ3kgJiBUZWxlY29tXCIsIFwiVFpcIl0sIFtcIlphbXRlbFwiLCBcIlRlbGVjb21tdW5pY2F0aW9uc1wiLCBcIlRlY2hub2xvZ3kgJiBUZWxlY29tXCIsIFwiWk1cIl0sIFtcIlNob3ByaXRlIFphbWJpYVwiLCBcIlJldGFpbFwiLCBcIlJldGFpbCAmIEUtY29tbWVyY2VcIiwgXCJaTVwiXSwgW1wiTVRDIE5hbWliaWFcIiwgXCJUZWxlY29tbXVuaWNhdGlvbnNcIiwgXCJUZWNobm9sb2d5ICYgVGVsZWNvbVwiLCBcIk5BXCJdLCBbXCJGaXJzdCBOYXRpb25hbCBCYW5rIE5hbWliaWFcIiwgXCJCYW5raW5nXCIsIFwiQnVzaW5lc3MgJiBGaW5hbmNlXCIsIFwiTkFcIl0sIFtcIkFJQlwiLCBcIkJhbmtpbmdcIiwgXCJCdXNpbmVzcyAmIEZpbmFuY2VcIiwgXCJJRVwiXSwgW1wiUnlhbmFpclwiLCBcIkFpcmxpbmVcIiwgXCJUcmF2ZWwsIFRvdXJpc20gJiBIb3NwaXRhbGl0eVwiLCBcIklFXCJdLCBbXCJIJk1cIiwgXCJGYXNoaW9uIHJldGFpbFwiLCBcIkZhc2hpb24gJiBBcHBhcmVsXCIsIFwiU0VcIl0sIFtcIkVyaWNzc29uXCIsIFwiVGVsZWNvbW11bmljYXRpb25zXCIsIFwiVGVjaG5vbG9neSAmIFRlbGVjb21cIiwgXCJTRVwiXSwgW1wiQUJCXCIsIFwiRW5naW5lZXJpbmdcIiwgXCJJbmR1c3RyaWFsICYgTWFudWZhY3R1cmluZ1wiLCBcIkNIXCJdLCBbXCJVQlNcIiwgXCJCYW5raW5nXCIsIFwiQnVzaW5lc3MgJiBGaW5hbmNlXCIsIFwiQ0hcIl0sIFtcIlNhc29sXCIsIFwiRW5lcmd5IGFuZCBjaGVtaWNhbHNcIiwgXCJFbmVyZ3kgJiBVdGlsaXRpZXNcIiwgXCJaQVwiXSwgW1wiU2FmYXJpY29tIEV0aGlvcGlhXCIsIFwiVGVsZWNvbW11bmljYXRpb25zXCIsIFwiVGVjaG5vbG9neSAmIFRlbGVjb21cIiwgXCJFVFwiXSwgW1wiS0NCIEdyb3VwXCIsIFwiQmFua2luZ1wiLCBcIkJ1c2luZXNzICYgRmluYW5jZVwiLCBcIktFXCJdLCBbXCJBaXJ0ZWwgQWZyaWNhXCIsIFwiVGVsZWNvbW11bmljYXRpb25zXCIsIFwiVGVjaG5vbG9neSAmIFRlbGVjb21cIiwgXCJVR1wiXSwgW1wiU29uYXRlbFwiLCBcIlRlbGVjb21tdW5pY2F0aW9uc1wiLCBcIlRlY2hub2xvZ3kgJiBUZWxlY29tXCIsIFwiU05cIl0sIFtcIk1hcm9jIFRlbGVjb21cIiwgXCJUZWxlY29tbXVuaWNhdGlvbnNcIiwgXCJUZWNobm9sb2d5ICYgVGVsZWNvbVwiLCBcIk1BXCJdLCBbXCJHdWxmIEFpclwiLCBcIkFpcmxpbmVcIiwgXCJUcmF2ZWwsIFRvdXJpc20gJiBIb3NwaXRhbGl0eVwiLCBcIkJIXCJdLCBbXCJRYXRhciBBaXJ3YXlzXCIsIFwiQWlybGluZVwiLCBcIlRyYXZlbCwgVG91cmlzbSAmIEhvc3BpdGFsaXR5XCIsIFwiUUFcIl0sIFtcIkV0aXNhbGF0XCIsIFwiVGVsZWNvbW11bmljYXRpb25zXCIsIFwiVGVjaG5vbG9neSAmIFRlbGVjb21cIiwgXCJBRVwiXSwgW1wiR3JhYlwiLCBcIk1vYmlsaXR5IGFuZCBkZWxpdmVyeVwiLCBcIlRlY2hub2xvZ3kgJiBUZWxlY29tXCIsIFwiU0dcIl0sIFtcIkdvamVrXCIsIFwiTW9iaWxpdHkgYW5kIGRlbGl2ZXJ5XCIsIFwiVGVjaG5vbG9neSAmIFRlbGVjb21cIiwgXCJJRFwiXSwgW1wiS2lhXCIsIFwiQXV0b21vdGl2ZVwiLCBcIkF1dG9tb3RpdmUgJiBNb2JpbGl0eVwiLCBcIktSXCJdLCBbXCJMb3R0ZVwiLCBcIkNvbmdsb21lcmF0ZVwiLCBcIkNvbnN1bWVyIEdvb2RzXCIsIFwiS1JcIl0sIFtcIlBhbmFzb25pY1wiLCBcIkVsZWN0cm9uaWNzXCIsIFwiVGVjaG5vbG9neSAmIFRlbGVjb21cIiwgXCJKUFwiXSwgW1wiUmFrdXRlblwiLCBcIkUtY29tbWVyY2VcIiwgXCJSZXRhaWwgJiBFLWNvbW1lcmNlXCIsIFwiSlBcIl0sIFtcIkJoYXJhdFBlXCIsIFwiUGF5bWVudHNcIiwgXCJUZWNobm9sb2d5ICYgVGVsZWNvbVwiLCBcIklOXCJdLCBbXCJXaXByb1wiLCBcIlRlY2hub2xvZ3kgc2VydmljZXNcIiwgXCJUZWNobm9sb2d5ICYgVGVsZWNvbVwiLCBcIklOXCJdLCBbXCJESExcIiwgXCJMb2dpc3RpY3NcIiwgXCJUcmFuc3BvcnQgJiBMb2dpc3RpY3NcIiwgXCJERVwiXSwgW1wiU2llbWVuc1wiLCBcIkVuZ2luZWVyaW5nXCIsIFwiSW5kdXN0cmlhbCAmIE1hbnVmYWN0dXJpbmdcIiwgXCJERVwiXSwgW1wiRGFub25lXCIsIFwiRm9vZCAmIEJldmVyYWdlXCIsIFwiQWdyaWN1bHR1cmUgJiBGb29kIFByb2R1Y3Rpb25cIiwgXCJGUlwiXSwgW1wiQ2FycmVmb3VyXCIsIFwiUmV0YWlsXCIsIFwiUmV0YWlsICYgRS1jb21tZXJjZVwiLCBcIkZSXCJdLCBbXCJWb2x2b1wiLCBcIkF1dG9tb3RpdmVcIiwgXCJBdXRvbW90aXZlICYgTW9iaWxpdHlcIiwgXCJTRVwiXSwgW1wiTWFlcnNrXCIsIFwiU2hpcHBpbmcgYW5kIGxvZ2lzdGljc1wiLCBcIlRyYW5zcG9ydCAmIExvZ2lzdGljc1wiLCBcIkRLXCJdLCBbXCJLbGFybmFcIiwgXCJQYXltZW50c1wiLCBcIlRlY2hub2xvZ3kgJiBUZWxlY29tXCIsIFwiU0VcIl0sIFtcIlBhdGFnb25pYVwiLCBcIk91dGRvb3IgYXBwYXJlbFwiLCBcIkZhc2hpb24gJiBBcHBhcmVsXCIsIFwiVVNcIl0sIFtcIk5pa2VcIiwgXCJTcG9ydHN3ZWFyXCIsIFwiRmFzaGlvbiAmIEFwcGFyZWxcIiwgXCJVU1wiXSwgW1wiVGltIEhvcnRvbnNcIiwgXCJGb29kIHNlcnZpY2VcIiwgXCJUcmF2ZWwsIFRvdXJpc20gJiBIb3NwaXRhbGl0eVwiLCBcIkNBXCJdLCBbXCJRYW50YXNcIiwgXCJBaXJsaW5lXCIsIFwiVHJhdmVsLCBUb3VyaXNtICYgSG9zcGl0YWxpdHlcIiwgXCJBVVwiXSwgW1wiV29vbHdvcnRocyBBdXN0cmFsaWFcIiwgXCJSZXRhaWxcIiwgXCJSZXRhaWwgJiBFLWNvbW1lcmNlXCIsIFwiQVVcIl0sIFtcIkZhbGFiZWxsYVwiLCBcIlJldGFpbFwiLCBcIlJldGFpbCAmIEUtY29tbWVyY2VcIiwgXCJDTFwiXSwgW1wiQmFuY29sb21iaWFcIiwgXCJCYW5raW5nXCIsIFwiQnVzaW5lc3MgJiBGaW5hbmNlXCIsIFwiQ09cIl0sIFtcIllQRlwiLCBcIkVuZXJneVwiLCBcIkVuZXJneSAmIFV0aWxpdGllc1wiLCBcIkFSXCJdLCBbXCJIYXZhaWFuYXNcIiwgXCJGb290d2VhclwiLCBcIkZhc2hpb24gJiBBcHBhcmVsXCIsIFwiQlJcIl0sIFtcIlBlbWV4XCIsIFwiRW5lcmd5XCIsIFwiRW5lcmd5ICYgVXRpbGl0aWVzXCIsIFwiTVhcIl0sIFtcIktjZWxsXCIsIFwiVGVsZWNvbW11bmljYXRpb25zXCIsIFwiVGVjaG5vbG9neSAmIFRlbGVjb21cIiwgXCJLWlwiXSwgW1wiTE9UIFBvbGlzaCBBaXJsaW5lc1wiLCBcIkFpcmxpbmVcIiwgXCJUcmF2ZWwsIFRvdXJpc20gJiBIb3NwaXRhbGl0eVwiLCBcIlBMXCJdLCBbXCJBbGxlZ3JvXCIsIFwiRS1jb21tZXJjZVwiLCBcIlJldGFpbCAmIEUtY29tbWVyY2VcIiwgXCJQTFwiXSwgW1wiTm9yc2sgSHlkcm9cIiwgXCJNYXRlcmlhbHNcIiwgXCJJbmR1c3RyaWFsICYgTWFudWZhY3R1cmluZ1wiLCBcIk5PXCJdLCBbXCJFcXVpbm9yXCIsIFwiRW5lcmd5XCIsIFwiRW5lcmd5ICYgVXRpbGl0aWVzXCIsIFwiTk9cIl0sIFtcIlRlbGlhXCIsIFwiVGVsZWNvbW11bmljYXRpb25zXCIsIFwiVGVjaG5vbG9neSAmIFRlbGVjb21cIiwgXCJTRVwiXSxcbl0gYXMgY29uc3Q7XG5cbmV4cG9ydCBjb25zdCBJTlRFUk5BVElPTkFMX1NFRURfQlJBTkRTOiBCcmFuZFtdID0gaW50ZXJuYXRpb25hbEVudHJpZXMubWFwKChbbmFtZSwgZGVzY3JpcHRvciwgY2F0ZWdvcnksIGNvdW50cnldLCBpbmRleCkgPT4gKHtcbiAgaWQ6IGBzZWVkLWdsb2JhbC0ke2luZGV4ICsgMX1gLCBvd25lcl9pZDogXCJzZWVkLWNhdGFsb2dcIiwgbmFtZSwgc2x1ZzogYCR7c2x1Z2lmeVNlZWQobmFtZSl9LSR7Y291bnRyeS50b0xvd2VyQ2FzZSgpfWAsIGRlc2NyaXB0aW9uOiBgJHtkZXNjcmlwdG9yfSBicmFuZCBmcm9tICR7Y291bnRyeX0uIENvbW11bml0eSB2ZXJpZmljYXRpb24gaXMgc3RpbGwgb3Blbi5gLCBsb2dvX3VybDogbnVsbCwgd2Vic2l0ZTogbnVsbCwgY2F0ZWdvcnksIGNvdW50cnksIHZlcmlmaWVkOiBmYWxzZSwgdHJ1c3Rfc2NvcmU6IDAsIGNyZWF0ZWRfYXQ6IFwiMjAyNi0wOS0wOVQwMDowMDowMC4wMDBaXCIsIHNpZ25lZExvZ29Vcmw6IG51bGwsIG93bmVyTmFtZTogXCJTT1QgY2F0YWxvZ1wiLFxufSkpO1xuXG5leHBvcnQgY29uc3QgU09VVEhfQUZSSUNBTl9TRUVEX0JSQU5EUzogQnJhbmRbXSA9IGVudHJpZXMubWFwKFxuICAoW25hbWUsIGRlc2NyaXB0b3IsIGNhdGVnb3J5XSwgaW5kZXgpID0+ICh7XG4gICAgaWQ6IGBzZWVkLXphLSR7aW5kZXggKyAxfWAsXG4gICAgb3duZXJfaWQ6IFwic2VlZC1jYXRhbG9nXCIsXG4gICAgbmFtZSxcbiAgICBzbHVnOiBgJHtzbHVnaWZ5U2VlZChuYW1lKX0temFgLFxuICAgIGRlc2NyaXB0aW9uOiBgJHtkZXNjcmlwdG9yfSBicmFuZCBjYXRhbG9ndWVkIGZvciBTb3V0aCBBZnJpY2EuIENvbW11bml0eSB2ZXJpZmljYXRpb24gaXMgc3RpbGwgb3Blbi5gLFxuICAgIGxvZ29fdXJsOiBudWxsLFxuICAgIHdlYnNpdGU6IG51bGwsXG4gICAgY2F0ZWdvcnksXG4gICAgY291bnRyeTogXCJaQVwiLFxuICAgIHZlcmlmaWVkOiBmYWxzZSxcbiAgICB0cnVzdF9zY29yZTogMCxcbiAgICBjcmVhdGVkX2F0OiBcIjIwMjYtMDktMDlUMDA6MDA6MDAuMDAwWlwiLFxuICAgIHNpZ25lZExvZ29Vcmw6IG51bGwsXG4gICAgb3duZXJOYW1lOiBcIlNPVCBjYXRhbG9nXCIsXG4gIH0pLFxuKTtcbiJdfQ==