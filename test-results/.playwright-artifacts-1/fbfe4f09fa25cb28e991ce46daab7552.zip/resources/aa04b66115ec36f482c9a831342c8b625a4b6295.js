//#region src/core/compat.ts
/**
* References
* - https://compat-table.github.io/compat-table/es6/
* - MDN
*/
let Feature = /* @__PURE__ */ function(Feature) {
	Feature[Feature["AggregateError"] = 1] = "AggregateError";
	Feature[Feature["ArrowFunction"] = 2] = "ArrowFunction";
	Feature[Feature["ErrorPrototypeStack"] = 4] = "ErrorPrototypeStack";
	Feature[Feature["ObjectAssign"] = 8] = "ObjectAssign";
	Feature[Feature["BigIntTypedArray"] = 16] = "BigIntTypedArray";
	Feature[Feature["RegExp"] = 32] = "RegExp";
	Feature[Feature["Temporal"] = 64] = "Temporal";
	return Feature;
}({});
//#endregion
//#region src/core/symbols.ts
const SYM_ASYNC_ITERATOR = Symbol.asyncIterator;
const SYM_HAS_INSTANCE = Symbol.hasInstance;
const SYM_IS_CONCAT_SPREADABLE = Symbol.isConcatSpreadable;
const SYM_ITERATOR = Symbol.iterator;
const SYM_MATCH = Symbol.match;
const SYM_MATCH_ALL = Symbol.matchAll;
const SYM_REPLACE = Symbol.replace;
const SYM_SEARCH = Symbol.search;
const SYM_SPECIES = Symbol.species;
const SYM_SPLIT = Symbol.split;
const SYM_TO_PRIMITIVE = Symbol.toPrimitive;
const SYM_TO_STRING_TAG = Symbol.toStringTag;
const SYM_UNSCOPABLES = Symbol.unscopables;
//#endregion
//#region src/core/constants.ts
const SYMBOL_STRING = {
	[0]: "Symbol.asyncIterator",
	[1]: "Symbol.hasInstance",
	[2]: "Symbol.isConcatSpreadable",
	[3]: "Symbol.iterator",
	[4]: "Symbol.match",
	[5]: "Symbol.matchAll",
	[6]: "Symbol.replace",
	[7]: "Symbol.search",
	[8]: "Symbol.species",
	[9]: "Symbol.split",
	[10]: "Symbol.toPrimitive",
	[11]: "Symbol.toStringTag",
	[12]: "Symbol.unscopables"
};
const INV_SYMBOL_REF = {
	[SYM_ASYNC_ITERATOR]: 0,
	[SYM_HAS_INSTANCE]: 1,
	[SYM_IS_CONCAT_SPREADABLE]: 2,
	[SYM_ITERATOR]: 3,
	[SYM_MATCH]: 4,
	[SYM_MATCH_ALL]: 5,
	[SYM_REPLACE]: 6,
	[SYM_SEARCH]: 7,
	[SYM_SPECIES]: 8,
	[SYM_SPLIT]: 9,
	[SYM_TO_PRIMITIVE]: 10,
	[SYM_TO_STRING_TAG]: 11,
	[SYM_UNSCOPABLES]: 12
};
const SYMBOL_REF = {
	[0]: SYM_ASYNC_ITERATOR,
	[1]: SYM_HAS_INSTANCE,
	[2]: SYM_IS_CONCAT_SPREADABLE,
	[3]: SYM_ITERATOR,
	[4]: SYM_MATCH,
	[5]: SYM_MATCH_ALL,
	[6]: SYM_REPLACE,
	[7]: SYM_SEARCH,
	[8]: SYM_SPECIES,
	[9]: SYM_SPLIT,
	[10]: SYM_TO_PRIMITIVE,
	[11]: SYM_TO_STRING_TAG,
	[12]: SYM_UNSCOPABLES
};
const CONSTANT_STRING = {
	[2]: "!0",
	[3]: "!1",
	[1]: "void 0",
	[0]: "null",
	[4]: "-0",
	[5]: "1/0",
	[6]: "-1/0",
	[7]: "0/0"
};
const CONSTANT_VAL = {
	[2]: true,
	[3]: false,
	[1]: void 0,
	[0]: null,
	[4]: -0,
	[5]: Number.POSITIVE_INFINITY,
	[6]: Number.NEGATIVE_INFINITY,
	[7]: NaN
};
const ERROR_CONSTRUCTOR_STRING = {
	[0]: "Error",
	[1]: "EvalError",
	[2]: "RangeError",
	[3]: "ReferenceError",
	[4]: "SyntaxError",
	[5]: "TypeError",
	[6]: "URIError"
};
const ERROR_CONSTRUCTOR = {
	[0]: Error,
	[1]: EvalError,
	[2]: RangeError,
	[3]: ReferenceError,
	[4]: SyntaxError,
	[5]: TypeError,
	[6]: URIError
};
//#endregion
//#region src/core/node.ts
function createSerovalNode(t, i, s, c, m, p, e, a, f, b, o, l) {
	return {
		t,
		i,
		s,
		c,
		m,
		p,
		e,
		a,
		f,
		b,
		o,
		l
	};
}
//#endregion
//#region src/core/literals.ts
function createConstantNode(value) {
	return createSerovalNode(2, void 0, value, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0);
}
const TRUE_NODE = /* @__PURE__ */ createConstantNode(2);
const FALSE_NODE = /* @__PURE__ */ createConstantNode(3);
const UNDEFINED_NODE = /* @__PURE__ */ createConstantNode(1);
const NULL_NODE = /* @__PURE__ */ createConstantNode(0);
const NEG_ZERO_NODE = /* @__PURE__ */ createConstantNode(4);
const INFINITY_NODE = /* @__PURE__ */ createConstantNode(5);
const NEG_INFINITY_NODE = /* @__PURE__ */ createConstantNode(6);
const NAN_NODE = /* @__PURE__ */ createConstantNode(7);
//#endregion
//#region src/core/string.ts
const MIN_JSON_STRINGIFY_LENGTH = 64;
const JSON_ESCAPE_DIFFERENCES = /[\x00-\x07\x0b\x0e-\x1f<\u2028\u2029\ud800-\udfff]/;
function serializeChar(str) {
	switch (str) {
		case "\"": return "\\\"";
		case "\\": return "\\\\";
		case "\n": return "\\n";
		case "\r": return "\\r";
		case "\b": return "\\b";
		case "	": return "\\t";
		case "\f": return "\\f";
		case "<": return "\\x3C";
		case "\u2028": return "\\u2028";
		case "\u2029": return "\\u2029";
		default: return;
	}
}
function serializeString(str) {
	if (str.length >= MIN_JSON_STRINGIFY_LENGTH && !JSON_ESCAPE_DIFFERENCES.test(str)) return JSON.stringify(str).slice(1, -1);
	let result = "";
	let lastPos = 0;
	let replacement;
	for (let i = 0, len = str.length; i < len; i++) {
		replacement = serializeChar(str[i]);
		if (replacement) {
			result += str.slice(lastPos, i) + replacement;
			lastPos = i + 1;
		}
	}
	if (lastPos === 0) result = str;
	else result += str.slice(lastPos);
	return result;
}
function deserializeReplacer(str) {
	switch (str) {
		case "\\\\": return "\\";
		case "\\\"": return "\"";
		case "\\n": return "\n";
		case "\\r": return "\r";
		case "\\b": return "\b";
		case "\\t": return "	";
		case "\\f": return "\f";
		case "\\x3C": return "<";
		case "\\u2028": return "\u2028";
		case "\\u2029": return "\u2029";
		default: return str;
	}
}
function deserializeString(str) {
	if (typeof str === "string" && !str.includes("\\")) return str;
	return str.replace(/(\\\\|\\"|\\n|\\r|\\b|\\t|\\f|\\u2028|\\u2029|\\x3C)/g, deserializeReplacer);
}
//#endregion
//#region src/core/errors.ts
const { toString: objectToString } = Object.prototype;
function getErrorMessageDev(type, cause) {
	if (cause instanceof Error) return `Seroval caught an error during the ${type} process.

${cause.name}
${cause.message}

- For more information, please check the "cause" property of this error.
- If you believe this is an error in Seroval, please submit an issue at https://github.com/lxsmnsyc/seroval/issues/new`;
	return `Seroval caught an error during the ${type} process.

"${objectToString.call(cause)}"

For more information, please check the "cause" property of this error.`;
}
const getErrorMessage = (type, cause) => getErrorMessageDev(type, cause);
var SerovalError = class extends Error {
	constructor(type, cause) {
		super(getErrorMessage(type, cause));
		this.cause = cause;
	}
};
var SerovalParserError = class extends SerovalError {
	constructor(cause) {
		super("parsing", cause);
	}
};
var SerovalSerializationError = class extends SerovalError {
	constructor(cause) {
		super("serialization", cause);
	}
};
var SerovalDeserializationError = class extends SerovalError {
	constructor(cause) {
		super("deserialization", cause);
	}
};
var SerovalUnsupportedTypeError = class extends Error {
	constructor(value) {
		super(`The value ${objectToString.call(value)} of type "${typeof value}" cannot be parsed/serialized.
      
There are few workarounds for this problem:
- Transform the value in a way that it can be serialized.
- If the reference is present on multiple runtimes (isomorphic), you can use the Reference API to map the references.`);
		this.value = value;
	}
};
var SerovalUnsupportedNodeError = class extends Error {
	constructor(node) {
		super("Unsupported node type \"" + node.t + "\".");
	}
};
var SerovalMissingPluginError = class extends Error {
	constructor(tag) {
		super("Missing plugin for tag \"" + tag + "\".");
	}
};
var SerovalMissingInstanceError = class extends Error {
	constructor(tag) {
		super("Missing \"" + tag + "\" instance.");
	}
};
var SerovalMissingReferenceError = class extends Error {
	constructor(value) {
		super("Missing reference for the value \"" + objectToString.call(value) + "\" of type \"" + typeof value + "\"");
		this.value = value;
	}
};
var SerovalMissingReferenceForIdError = class extends Error {
	constructor(id) {
		super("Missing reference for id \"" + serializeString(id) + "\"");
	}
};
var SerovalUnknownTypedArrayError = class extends Error {
	constructor(name) {
		super("Unknown TypedArray \"" + name + "\"");
	}
};
var SerovalMalformedNodeError = class extends Error {
	constructor(node) {
		super("Malformed node type \"" + node.t + "\".");
	}
};
var SerovalConflictedNodeIdError = class extends Error {
	constructor(node) {
		super("Conflicted node id \"" + node.i + "\".");
	}
};
var SerovalDepthLimitError = class extends Error {
	constructor(limit) {
		super("Depth limit of " + limit + " reached");
	}
};
//#endregion
//#region src/core/keys.ts
const REFERENCES_KEY = "__SEROVAL_REFS__";
const GLOBAL_CONTEXT_R = `self.\$R`;
function getCrossReferenceHeader(id) {
	if (id == null) return `${GLOBAL_CONTEXT_R}=${GLOBAL_CONTEXT_R}||[]`;
	return `(${GLOBAL_CONTEXT_R}=${GLOBAL_CONTEXT_R}||{})["${serializeString(id)}"]=[]`;
}
//#endregion
//#region src/core/reference.ts
const REFERENCE = /* @__PURE__ */ new Map();
const INV_REFERENCE = /* @__PURE__ */ new Map();
function createReference(id, value) {
	REFERENCE.set(value, id);
	INV_REFERENCE.set(id, value);
	return value;
}
function hasReferenceID(value) {
	return REFERENCE.has(value);
}
function hasReference(id) {
	return INV_REFERENCE.has(id);
}
function getReferenceID(value) {
	if (hasReferenceID(value)) return REFERENCE.get(value);
	throw new SerovalMissingReferenceError(value);
}
function getReference(id) {
	if (hasReference(id)) return INV_REFERENCE.get(id);
	throw new SerovalMissingReferenceForIdError(id);
}
if (typeof globalThis !== "undefined") Object.defineProperty(globalThis, REFERENCES_KEY, {
	value: INV_REFERENCE,
	configurable: true,
	writable: false,
	enumerable: false
});
else if (typeof window !== "undefined") Object.defineProperty(window, REFERENCES_KEY, {
	value: INV_REFERENCE,
	configurable: true,
	writable: false,
	enumerable: false
});
else if (typeof self !== "undefined") Object.defineProperty(self, REFERENCES_KEY, {
	value: INV_REFERENCE,
	configurable: true,
	writable: false,
	enumerable: false
});
else if (typeof global !== "undefined") Object.defineProperty(global, REFERENCES_KEY, {
	value: INV_REFERENCE,
	configurable: true,
	writable: false,
	enumerable: false
});
//#endregion
//#region src/core/utils/error.ts
function getErrorConstructor(error) {
	if (error instanceof EvalError) return 1;
	if (error instanceof RangeError) return 2;
	if (error instanceof ReferenceError) return 3;
	if (error instanceof SyntaxError) return 4;
	if (error instanceof TypeError) return 5;
	if (error instanceof URIError) return 6;
	return 0;
}
function getInitialErrorOptions(error) {
	const construct = ERROR_CONSTRUCTOR_STRING[getErrorConstructor(error)];
	if (error.name !== construct) return { name: error.name };
	if (error.constructor.name !== construct) return { name: error.constructor.name };
	return {};
}
function getErrorOptions(error, features) {
	let options = getInitialErrorOptions(error);
	const names = Object.getOwnPropertyNames(error);
	for (let i = 0, len = names.length, name; i < len; i++) {
		name = names[i];
		if (name !== "name" && name !== "message") {
			if (name === "stack") {
				if (features & 4) {
					options = options || {};
					options[name] = error[name];
				}
			} else {
				options = options || {};
				options[name] = error[name];
			}
		}
	}
	return options;
}
//#endregion
//#region src/core/utils/get-object-flag.ts
function getObjectFlag(obj) {
	if (Object.isFrozen(obj)) return 3;
	if (Object.isSealed(obj)) return 2;
	if (Object.isExtensible(obj)) return 0;
	return 1;
}
//#endregion
//#region src/core/base-primitives.ts
function createNumberNode(value) {
	switch (value) {
		case Number.POSITIVE_INFINITY: return INFINITY_NODE;
		case Number.NEGATIVE_INFINITY: return NEG_INFINITY_NODE;
	}
	if (value !== value) return NAN_NODE;
	if (Object.is(value, -0)) return NEG_ZERO_NODE;
	return createSerovalNode(0, void 0, value, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0);
}
function createStringNode(value) {
	return createSerovalNode(1, void 0, serializeString(value), void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0);
}
function createBigIntNode(current) {
	return createSerovalNode(3, void 0, "" + current, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0);
}
function createIndexedValueNode(id) {
	return createSerovalNode(4, id, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0);
}
function createDateNode(id, current) {
	const timestamp = current.valueOf();
	return createSerovalNode(5, id, timestamp !== timestamp ? "" : current.toISOString(), void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0);
}
function createTemporalNode(id, type, current) {
	return createSerovalNode(36, id, current.toString(), type, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0);
}
function createRegExpNode(id, current) {
	return createSerovalNode(6, id, void 0, serializeString(current.source), current.flags, void 0, void 0, void 0, void 0, void 0, void 0, void 0);
}
function createWKSymbolNode(id, current) {
	return createSerovalNode(17, id, INV_SYMBOL_REF[current], void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0);
}
function createReferenceNode(id, ref) {
	return createSerovalNode(18, id, serializeString(getReferenceID(ref)), void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0);
}
function createPluginNode(id, tag, value) {
	return createSerovalNode(25, id, value, serializeString(tag), void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0);
}
function createArrayNode(id, current, parsedItems) {
	return createSerovalNode(9, id, void 0, void 0, void 0, void 0, void 0, parsedItems, void 0, void 0, getObjectFlag(current), void 0);
}
function createBoxedNode(id, boxed) {
	return createSerovalNode(21, id, void 0, void 0, void 0, void 0, void 0, void 0, boxed, void 0, void 0, void 0);
}
const MAX_TYPED_ARRAY_LENGTH = 1e6;
function createTypedArrayNode(id, current, buffer) {
	if (current.length > MAX_TYPED_ARRAY_LENGTH) throw new SerovalUnsupportedTypeError(current);
	return createSerovalNode(15, id, void 0, current.constructor.name, void 0, void 0, void 0, void 0, buffer, current.byteOffset, void 0, current.length);
}
function createBigIntTypedArrayNode(id, current, buffer) {
	if (current.length > MAX_TYPED_ARRAY_LENGTH) throw new SerovalUnsupportedTypeError(current);
	return createSerovalNode(16, id, void 0, current.constructor.name, void 0, void 0, void 0, void 0, buffer, current.byteOffset, void 0, current.length);
}
function createDataViewNode(id, current, buffer) {
	if (current.byteLength > MAX_TYPED_ARRAY_LENGTH) throw new SerovalUnsupportedTypeError(current);
	return createSerovalNode(20, id, void 0, void 0, void 0, void 0, void 0, void 0, buffer, current.byteOffset, void 0, current.byteLength);
}
function createErrorNode(id, current, options) {
	return createSerovalNode(13, id, getErrorConstructor(current), void 0, serializeString(current.message), options, void 0, void 0, void 0, void 0, void 0, void 0);
}
function createAggregateErrorNode(id, current, options) {
	return createSerovalNode(14, id, getErrorConstructor(current), void 0, serializeString(current.message), options, void 0, void 0, void 0, void 0, void 0, void 0);
}
function createSetNode(id, items) {
	return createSerovalNode(7, id, void 0, void 0, void 0, void 0, void 0, items, void 0, void 0, void 0, void 0);
}
function createIteratorFactoryInstanceNode(factory, items) {
	return createSerovalNode(28, void 0, void 0, void 0, void 0, void 0, void 0, [factory, items], void 0, void 0, void 0, void 0);
}
function createAsyncIteratorFactoryInstanceNode(factory, items) {
	return createSerovalNode(30, void 0, void 0, void 0, void 0, void 0, void 0, [factory, items], void 0, void 0, void 0, void 0);
}
function createStreamConstructorNode(id, factory, sequence) {
	return createSerovalNode(31, id, void 0, void 0, void 0, void 0, void 0, sequence, factory, void 0, void 0, void 0);
}
function createStreamNextNode(id, parsed) {
	return createSerovalNode(32, id, void 0, void 0, void 0, void 0, void 0, void 0, parsed, void 0, void 0, void 0);
}
function createStreamThrowNode(id, parsed) {
	return createSerovalNode(33, id, void 0, void 0, void 0, void 0, void 0, void 0, parsed, void 0, void 0, void 0);
}
function createStreamReturnNode(id, parsed) {
	return createSerovalNode(34, id, void 0, void 0, void 0, void 0, void 0, void 0, parsed, void 0, void 0, void 0);
}
function createSequenceNode(id, sequence, throwAt, doneAt) {
	return createSerovalNode(35, id, throwAt, void 0, void 0, void 0, void 0, sequence, void 0, void 0, void 0, doneAt);
}
//#endregion
//#region src/core/opaque-reference.ts
/**
* An opaque reference allows hiding values from the serializer.
*/
var OpaqueReference = class {
	constructor(value, replacement) {
		this.value = value;
		this.replacement = replacement;
	}
};
//#endregion
//#region src/core/constructors.ts
const PROMISE_CONSTRUCTOR = () => {
	const resolver = {
		p: 0,
		s: 0,
		f: 0
	};
	resolver.p = new Promise((resolve, reject) => {
		resolver.s = resolve;
		resolver.f = reject;
	});
	return resolver;
};
const PROMISE_SUCCESS = (resolver, data) => {
	resolver.s(data);
	resolver.p.s = 1;
	resolver.p.v = data;
};
const PROMISE_FAILURE = (resolver, data) => {
	resolver.f(data);
	resolver.p.s = 2;
	resolver.p.v = data;
};
const SERIALIZED_PROMISE_CONSTRUCTOR = /* @__PURE__ */ PROMISE_CONSTRUCTOR.toString();
const SERIALIZED_PROMISE_SUCCESS = /* @__PURE__ */ PROMISE_SUCCESS.toString();
const SERIALIZED_PROMISE_FAILURE = /* @__PURE__ */ PROMISE_FAILURE.toString();
const STREAM_CONSTRUCTOR = () => {
	const buffer = [];
	const listeners = [];
	let alive = true;
	let success = false;
	let count = 0;
	const internal = {
		flush(value, mode, x) {
			for (x = 0; x < count; x++) {
				const listener = listeners[x];
				if (listener) listener[mode](value);
			}
		},
		up(listener, x, z, current) {
			for (x = 0, z = buffer.length; x < z; x++) {
				current = buffer[x];
				if (!alive && x === z - 1) listener[success ? "return" : "throw"](current);
				else listener.next(current);
			}
		},
		on(listener, temp = 0) {
			let subscribed = alive;
			if (alive) {
				for (temp = 0; temp < count; temp++) if (!listeners[temp]) break;
				if (temp === count) count++;
				listeners[temp] = listener;
			}
			internal.up(listener);
			return () => {
				if (alive && subscribed) {
					subscribed = false;
					listeners[temp] = void 0;
					while (count > 0 && !listeners[count - 1]) count--;
					listeners.length = count;
				}
			};
		}
	};
	return {
		__SEROVAL_STREAM__: true,
		on(listener) {
			return internal.on(listener);
		},
		next(value) {
			if (alive) {
				buffer.push(value);
				internal.flush(value, "next");
			}
		},
		throw(value) {
			if (alive) {
				buffer.push(value);
				internal.flush(value, "throw");
				alive = false;
				success = false;
				listeners.length = 0;
			}
		},
		return(value) {
			if (alive) {
				buffer.push(value);
				internal.flush(value, "return");
				alive = false;
				success = true;
				listeners.length = 0;
			}
		}
	};
};
const SERIALIZED_STREAM_CONSTRUCTOR = /* @__PURE__ */ STREAM_CONSTRUCTOR.toString();
const ITERATOR_CONSTRUCTOR = (symbol) => (sequence) => () => {
	let index = 0;
	const instance = {
		[symbol]() {
			return instance;
		},
		next() {
			if (index > sequence.d) return {
				done: true,
				value: void 0
			};
			const currentIndex = index++;
			const data = sequence.v[currentIndex];
			if (currentIndex === sequence.t) throw data;
			return {
				done: currentIndex === sequence.d,
				value: data
			};
		}
	};
	return instance;
};
const SERIALIZED_ITERATOR_CONSTRUCTOR = /* @__PURE__ */ ITERATOR_CONSTRUCTOR.toString();
const ASYNC_ITERATOR_CONSTRUCTOR = (symbol, createPromise) => (stream) => () => {
	let count = 0;
	let doneAt = -1;
	let isThrow = false;
	const buffer = [];
	const pending = [];
	const internal = { finalize(i = 0, len = pending.length) {
		for (; i < len; i++) pending[i].s({
			done: true,
			value: void 0
		});
	} };
	stream.on({
		next(value) {
			const temp = pending.shift();
			if (temp) temp.s({
				done: false,
				value
			});
			buffer.push(value);
		},
		throw(value) {
			const temp = pending.shift();
			if (temp) temp.f(value);
			internal.finalize();
			doneAt = buffer.length;
			isThrow = true;
			buffer.push(value);
		},
		return(value) {
			const temp = pending.shift();
			if (temp) temp.s({
				done: true,
				value
			});
			internal.finalize();
			doneAt = buffer.length;
			buffer.push(value);
		}
	});
	const instance = {
		[symbol]() {
			return instance;
		},
		next() {
			if (doneAt === -1) {
				const index = count++;
				if (index >= buffer.length) {
					const temp = createPromise();
					pending.push(temp);
					return temp.p;
				}
				return {
					done: false,
					value: buffer[index]
				};
			}
			if (count > doneAt) return {
				done: true,
				value: void 0
			};
			const index = count++;
			const value = buffer[index];
			if (index !== doneAt) return {
				done: false,
				value
			};
			if (isThrow) throw value;
			return {
				done: true,
				value
			};
		}
	};
	return instance;
};
const SERIALIZED_ASYNC_ITERATOR_CONSTRUCTOR = /* @__PURE__ */ ASYNC_ITERATOR_CONSTRUCTOR.toString();
const ARRAY_BUFFER_CONSTRUCTOR = (b64) => {
	const decoded = atob(b64);
	const length = decoded.length;
	const arr = new Uint8Array(length);
	for (let i = 0; i < length; i++) arr[i] = decoded.charCodeAt(i);
	return arr.buffer;
};
const SERIALIZED_ARRAY_BUFFER_CONSTRUCTOR = /* @__PURE__ */ ARRAY_BUFFER_CONSTRUCTOR.toString();
//#endregion
//#region src/core/sequence.ts
function isSequence(value) {
	return "__SEROVAL_SEQUENCE__" in value;
}
function createSequence(values, throwAt, doneAt) {
	return {
		__SEROVAL_SEQUENCE__: true,
		v: values,
		t: throwAt,
		d: doneAt
	};
}
function createSequenceFromIterable(source) {
	const values = [];
	let throwsAt = -1;
	let doneAt = -1;
	const iterator = source[SYM_ITERATOR]();
	while (true) try {
		const value = iterator.next();
		values.push(value.value);
		if (value.done) {
			doneAt = values.length - 1;
			break;
		}
	} catch (error) {
		throwsAt = values.length;
		values.push(error);
	}
	return createSequence(values, throwsAt, doneAt);
}
const createIterator = ITERATOR_CONSTRUCTOR(SYM_ITERATOR);
function sequenceToIterator(sequence) {
	return createIterator(sequence);
}
//#endregion
//#region src/core/special-reference.ts
const ITERATOR = {};
const ASYNC_ITERATOR = {};
/**
* Placeholder references
*/
const SPECIAL_REFS = {
	[0]: {},
	[1]: {},
	[2]: {},
	[3]: {},
	[4]: {},
	[5]: {}
};
const SPECIAL_REF_STRING = {
	[0]: "[]",
	[1]: SERIALIZED_PROMISE_CONSTRUCTOR,
	[2]: SERIALIZED_PROMISE_SUCCESS,
	[3]: SERIALIZED_PROMISE_FAILURE,
	[4]: SERIALIZED_STREAM_CONSTRUCTOR,
	[5]: SERIALIZED_ARRAY_BUFFER_CONSTRUCTOR
};
//#endregion
//#region src/core/stream.ts
function isStream(value) {
	return "__SEROVAL_STREAM__" in value;
}
function createStream() {
	return STREAM_CONSTRUCTOR();
}
function createStreamFromAsyncIterable(iterable, cleanups) {
	const stream = createStream();
	const iterator = iterable[SYM_ASYNC_ITERATOR]();
	let cancelled = false;
	let done = false;
	cleanups === null || cleanups === void 0 || cleanups.push(() => {
		if (!(done || cancelled)) {
			cancelled = true;
			Promise.resolve().then(() => {
				var _iterator$return;
				return (_iterator$return = iterator.return) === null || _iterator$return === void 0 ? void 0 : _iterator$return.call(iterator);
			}).catch(() => {});
		}
	});
	async function push() {
		try {
			while (!cancelled) {
				const value = await iterator.next();
				if (cancelled) return;
				if (value.done) {
					done = true;
					stream.return(value.value);
					break;
				}
				stream.next(value.value);
			}
		} catch (error) {
			done = true;
			if (!cancelled) stream.throw(error);
		}
	}
	push().catch(() => {});
	return stream;
}
const createAsyncIterable = ASYNC_ITERATOR_CONSTRUCTOR(SYM_ASYNC_ITERATOR, PROMISE_CONSTRUCTOR);
function streamToAsyncIterable(stream) {
	return createAsyncIterable(stream);
}
//#endregion
//#region src/core/utils/promise-to-result.ts
async function promiseToResult(current) {
	try {
		return [1, await current];
	} catch (e) {
		return [0, e];
	}
}
//#endregion
//#region src/core/context/parser.ts
function createBaseParserContext(mode, options) {
	var _options$compactArray;
	return {
		plugins: options.plugins,
		mode,
		marked: /* @__PURE__ */ new Set(),
		features: 127 ^ (options.disabledFeatures || 0),
		refs: options.refs || /* @__PURE__ */ new Map(),
		depthLimit: options.depthLimit || 1e3,
		compactArrayBufferViews: (_options$compactArray = options.compactArrayBufferViews) !== null && _options$compactArray !== void 0 ? _options$compactArray : false
	};
}
/**
* Ensures that the value (based on an identifier) has been visited by the parser.
* @param ctx
* @param id
*/
function markParserRef(ctx, id) {
	ctx.marked.add(id);
}
/**
* Creates an identifier for a value
* @param ctx
* @param current
*/
function createIndexForValue(ctx, current) {
	const id = ctx.refs.size;
	ctx.refs.set(current, id);
	return id;
}
function getNodeForIndexedValue(ctx, current) {
	const registeredId = ctx.refs.get(current);
	if (registeredId != null) {
		markParserRef(ctx, registeredId);
		return {
			type: 1,
			value: createIndexedValueNode(registeredId)
		};
	}
	return {
		type: 0,
		value: createIndexForValue(ctx, current)
	};
}
function getReferenceNode(ctx, current) {
	const indexed = getNodeForIndexedValue(ctx, current);
	if (indexed.type === 1) return indexed;
	if (hasReferenceID(current)) return {
		type: 2,
		value: createReferenceNode(indexed.value, current)
	};
	return indexed;
}
/**
* Parsing methods
*/
function parseWellKnownSymbol(ctx, current) {
	const ref = getReferenceNode(ctx, current);
	if (ref.type !== 0) return ref.value;
	if (current in INV_SYMBOL_REF) return createWKSymbolNode(ref.value, current);
	throw new SerovalUnsupportedTypeError(current);
}
function parseSpecialReference(ctx, ref) {
	const result = getNodeForIndexedValue(ctx, SPECIAL_REFS[ref]);
	if (result.type === 1) return result.value;
	return createSerovalNode(26, result.value, ref, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0);
}
function parseIteratorFactory(ctx) {
	const result = getNodeForIndexedValue(ctx, ITERATOR);
	if (result.type === 1) return result.value;
	return createSerovalNode(27, result.value, void 0, void 0, void 0, void 0, void 0, void 0, parseWellKnownSymbol(ctx, SYM_ITERATOR), void 0, void 0, void 0);
}
function parseAsyncIteratorFactory(ctx) {
	const result = getNodeForIndexedValue(ctx, ASYNC_ITERATOR);
	if (result.type === 1) return result.value;
	return createSerovalNode(29, result.value, void 0, void 0, void 0, void 0, void 0, [parseSpecialReference(ctx, 1), parseWellKnownSymbol(ctx, SYM_ASYNC_ITERATOR)], void 0, void 0, void 0, void 0);
}
function createObjectNode(id, current, empty, record) {
	return createSerovalNode(empty ? 11 : 10, id, void 0, void 0, void 0, record, void 0, void 0, void 0, void 0, getObjectFlag(current), void 0);
}
function createMapNode(ctx, id, k, v) {
	return createSerovalNode(8, id, void 0, void 0, void 0, void 0, {
		k,
		v
	}, void 0, parseSpecialReference(ctx, 0), void 0, void 0, void 0);
}
function createPromiseConstructorNode(ctx, id, resolver) {
	return createSerovalNode(22, id, resolver, void 0, void 0, void 0, void 0, void 0, parseSpecialReference(ctx, 1), void 0, void 0, void 0);
}
function getArrayBufferView(ctx, current) {
	if (!ctx.compactArrayBufferViews) return current;
	const buffer = new Uint8Array(current.buffer, current.byteOffset, current.byteLength).slice().buffer;
	const Constructor = current.constructor;
	return new Constructor(buffer);
}
function encodeArrayBuffer(current) {
	if (typeof Buffer !== "undefined") return Buffer.from(current).toString("base64");
	const bytes = new Uint8Array(current);
	if (typeof bytes.toBase64 === "function") return bytes.toBase64();
	let result = "";
	for (let i = 0, len = bytes.length; i < len; i++) result += String.fromCharCode(bytes[i]);
	return btoa(result);
}
function createArrayBufferNode(ctx, id, current) {
	return createSerovalNode(19, id, encodeArrayBuffer(current), void 0, void 0, void 0, void 0, void 0, parseSpecialReference(ctx, 5), void 0, void 0, void 0);
}
//#endregion
//#region src/core/context/async-parser.ts
function createAsyncParserContext(mode, options) {
	return {
		base: createBaseParserContext(mode, options),
		child: void 0
	};
}
var AsyncParsePluginContext = class {
	constructor(_p, depth) {
		this._p = _p;
		this.depth = depth;
	}
	parse(current) {
		return parseAsync(this._p, this.depth, current);
	}
};
async function parseItems$1(ctx, depth, current) {
	const nodes = [];
	for (let i = 0, len = current.length; i < len; i++) if (i in current) nodes[i] = await parseAsync(ctx, depth, current[i]);
	else nodes[i] = 0;
	return nodes;
}
async function parseArray$1(ctx, depth, id, current) {
	return createArrayNode(id, current, await parseItems$1(ctx, depth, current));
}
async function parseProperties$1(ctx, depth, properties) {
	const entries = Object.entries(properties);
	const keyNodes = [];
	const valueNodes = [];
	for (let i = 0, len = entries.length; i < len; i++) {
		keyNodes.push(serializeString(entries[i][0]));
		valueNodes.push(await parseAsync(ctx, depth, entries[i][1]));
	}
	if (SYM_ITERATOR in properties) {
		keyNodes.push(parseWellKnownSymbol(ctx.base, SYM_ITERATOR));
		valueNodes.push(createIteratorFactoryInstanceNode(parseIteratorFactory(ctx.base), await parseAsync(ctx, depth, createSequenceFromIterable(properties))));
	}
	if (SYM_ASYNC_ITERATOR in properties) {
		keyNodes.push(parseWellKnownSymbol(ctx.base, SYM_ASYNC_ITERATOR));
		valueNodes.push(createAsyncIteratorFactoryInstanceNode(parseAsyncIteratorFactory(ctx.base), await parseAsync(ctx, depth, createStreamFromAsyncIterable(properties))));
	}
	if (SYM_TO_STRING_TAG in properties) {
		keyNodes.push(parseWellKnownSymbol(ctx.base, SYM_TO_STRING_TAG));
		valueNodes.push(createStringNode(properties[SYM_TO_STRING_TAG]));
	}
	if (SYM_IS_CONCAT_SPREADABLE in properties) {
		keyNodes.push(parseWellKnownSymbol(ctx.base, SYM_IS_CONCAT_SPREADABLE));
		valueNodes.push(properties[SYM_IS_CONCAT_SPREADABLE] ? TRUE_NODE : FALSE_NODE);
	}
	return {
		k: keyNodes,
		v: valueNodes
	};
}
async function parsePlainObject$1(ctx, depth, id, current, empty) {
	return createObjectNode(id, current, empty, await parseProperties$1(ctx, depth, current));
}
async function parseBoxed$1(ctx, depth, id, current) {
	return createBoxedNode(id, await parseAsync(ctx, depth, current.valueOf()));
}
async function parseTypedArray$1(ctx, depth, id, current) {
	current = getArrayBufferView(ctx.base, current);
	return createTypedArrayNode(id, current, await parseAsync(ctx, depth, current.buffer));
}
async function parseBigIntTypedArray$1(ctx, depth, id, current) {
	current = getArrayBufferView(ctx.base, current);
	return createBigIntTypedArrayNode(id, current, await parseAsync(ctx, depth, current.buffer));
}
async function parseDataView$1(ctx, depth, id, current) {
	current = getArrayBufferView(ctx.base, current);
	return createDataViewNode(id, current, await parseAsync(ctx, depth, current.buffer));
}
async function parseError$1(ctx, depth, id, current) {
	const options = getErrorOptions(current, ctx.base.features);
	return createErrorNode(id, current, options ? await parseProperties$1(ctx, depth, options) : void 0);
}
async function parseAggregateError$1(ctx, depth, id, current) {
	const options = getErrorOptions(current, ctx.base.features);
	return createAggregateErrorNode(id, current, options ? await parseProperties$1(ctx, depth, options) : void 0);
}
async function parseMap$1(ctx, depth, id, current) {
	const keyNodes = [];
	const valueNodes = [];
	for (const [key, value] of current.entries()) {
		keyNodes.push(await parseAsync(ctx, depth, key));
		valueNodes.push(await parseAsync(ctx, depth, value));
	}
	return createMapNode(ctx.base, id, keyNodes, valueNodes);
}
async function parseSet$1(ctx, depth, id, current) {
	const items = [];
	for (const item of current.keys()) items.push(await parseAsync(ctx, depth, item));
	return createSetNode(id, items);
}
async function parsePlugin$1(ctx, depth, id, current) {
	const currentPlugins = ctx.base.plugins;
	if (currentPlugins) for (let i = 0, len = currentPlugins.length; i < len; i++) {
		const plugin = currentPlugins[i];
		if (plugin.parse.async && plugin.test(current)) return createPluginNode(id, plugin.tag, await plugin.parse.async(current, new AsyncParsePluginContext(ctx, depth), { id }));
	}
}
async function parsePromise$1(ctx, depth, id, current) {
	const [status, result] = await promiseToResult(current);
	return createSerovalNode(12, id, status, void 0, void 0, void 0, void 0, void 0, await parseAsync(ctx, depth, result), void 0, void 0, void 0);
}
function parseStreamHandle(depth, id, current, resolve, reject) {
	const sequence = [];
	const cleanup = current.on({
		next: (value) => {
			markParserRef(this.base, id);
			parseAsync(this, depth, value).then((data) => {
				sequence.push(createStreamNextNode(id, data));
			}, (data) => {
				reject(data);
				cleanup();
			});
		},
		throw: (value) => {
			markParserRef(this.base, id);
			parseAsync(this, depth, value).then((data) => {
				sequence.push(createStreamThrowNode(id, data));
				resolve(sequence);
				cleanup();
			}, (data) => {
				reject(data);
				cleanup();
			});
		},
		return: (value) => {
			markParserRef(this.base, id);
			parseAsync(this, depth, value).then((data) => {
				sequence.push(createStreamReturnNode(id, data));
				resolve(sequence);
				cleanup();
			}, (data) => {
				reject(data);
				cleanup();
			});
		}
	});
}
async function parseStream$1(ctx, depth, id, current) {
	return createStreamConstructorNode(id, parseSpecialReference(ctx.base, 4), await new Promise(parseStreamHandle.bind(ctx, depth, id, current)));
}
async function parseSequence$1(ctx, depth, id, current) {
	const nodes = [];
	for (let i = 0, len = current.v.length; i < len; i++) nodes[i] = await parseAsync(ctx, depth, current.v[i]);
	return createSequenceNode(id, nodes, current.t, current.d);
}
async function parseObjectAsync(ctx, depth, id, current) {
	if (Array.isArray(current)) return parseArray$1(ctx, depth, id, current);
	if (isStream(current)) return parseStream$1(ctx, depth, id, current);
	if (isSequence(current)) return parseSequence$1(ctx, depth, id, current);
	let currentClass = current.constructor;
	if (currentClass !== void 0 && typeof currentClass !== "function") {
		const proto = Object.getPrototypeOf(current);
		currentClass = proto === null ? void 0 : proto.constructor;
	}
	if (currentClass === OpaqueReference) return parseAsync(ctx, depth, current.replacement);
	const parsed = await parsePlugin$1(ctx, depth, id, current);
	if (parsed) return parsed;
	switch (currentClass) {
		case Object: return parsePlainObject$1(ctx, depth, id, current, false);
		case void 0: return parsePlainObject$1(ctx, depth, id, current, true);
		case Date: return createDateNode(id, current);
		case Error:
		case EvalError:
		case RangeError:
		case ReferenceError:
		case SyntaxError:
		case TypeError:
		case URIError: return parseError$1(ctx, depth, id, current);
		case Number:
		case Boolean:
		case String:
		case BigInt: return parseBoxed$1(ctx, depth, id, current);
		case ArrayBuffer: return createArrayBufferNode(ctx.base, id, current);
		case Int8Array:
		case Int16Array:
		case Int32Array:
		case Uint8Array:
		case Uint16Array:
		case Uint32Array:
		case Uint8ClampedArray:
		case Float32Array:
		case Float64Array: return parseTypedArray$1(ctx, depth, id, current);
		case DataView: return parseDataView$1(ctx, depth, id, current);
		case Map: return parseMap$1(ctx, depth, id, current);
		case Set: return parseSet$1(ctx, depth, id, current);
	}
	if (currentClass === Promise || current instanceof Promise) return parsePromise$1(ctx, depth, id, current);
	const currentFeatures = ctx.base.features;
	if (currentFeatures & 32 && currentClass === RegExp) return createRegExpNode(id, current);
	if (currentFeatures & 16) switch (currentClass) {
		case BigInt64Array:
		case BigUint64Array: return parseBigIntTypedArray$1(ctx, depth, id, current);
	}
	if (currentFeatures & 1 && typeof AggregateError !== "undefined" && (currentClass === AggregateError || current instanceof AggregateError)) return parseAggregateError$1(ctx, depth, id, current);
	if (currentFeatures & 64 && typeof Temporal !== "undefined") switch (currentClass) {
		case Temporal.Instant: return createTemporalNode(id, 0, current);
		case Temporal.Duration: return createTemporalNode(id, 1, current);
		case Temporal.PlainDate: return createTemporalNode(id, 2, current);
		case Temporal.PlainDateTime: return createTemporalNode(id, 3, current);
		case Temporal.PlainMonthDay: return createTemporalNode(id, 4, current);
		case Temporal.PlainTime: return createTemporalNode(id, 5, current);
		case Temporal.PlainYearMonth: return createTemporalNode(id, 6, current);
		case Temporal.ZonedDateTime: return createTemporalNode(id, 7, current);
	}
	if (current instanceof Error) return parseError$1(ctx, depth, id, current);
	if (SYM_ITERATOR in current || SYM_ASYNC_ITERATOR in current) return parsePlainObject$1(ctx, depth, id, current, !!currentClass);
	throw new SerovalUnsupportedTypeError(current);
}
async function parseFunctionAsync(ctx, depth, current) {
	const ref = getReferenceNode(ctx.base, current);
	if (ref.type !== 0) return ref.value;
	const plugin = await parsePlugin$1(ctx, depth, ref.value, current);
	if (plugin) return plugin;
	throw new SerovalUnsupportedTypeError(current);
}
async function parseAsync(ctx, depth, current) {
	if (depth >= ctx.base.depthLimit) throw new SerovalDepthLimitError(ctx.base.depthLimit);
	switch (typeof current) {
		case "boolean": return current ? TRUE_NODE : FALSE_NODE;
		case "undefined": return UNDEFINED_NODE;
		case "string": return createStringNode(current);
		case "number": return createNumberNode(current);
		case "bigint": return createBigIntNode(current);
		case "object":
			if (current) {
				const ref = getReferenceNode(ctx.base, current);
				return ref.type === 0 ? await parseObjectAsync(ctx, depth + 1, ref.value, current) : ref.value;
			}
			return NULL_NODE;
		case "symbol": return parseWellKnownSymbol(ctx.base, current);
		case "function": return parseFunctionAsync(ctx, depth, current);
		default: throw new SerovalUnsupportedTypeError(current);
	}
}
async function parseTopAsync(ctx, current) {
	try {
		return await parseAsync(ctx, 0, current);
	} catch (error) {
		throw error instanceof SerovalParserError ? error : new SerovalParserError(error);
	}
}
//#endregion
//#region src/core/plugin.ts
let SerovalMode = /* @__PURE__ */ function(SerovalMode) {
	SerovalMode[SerovalMode["Vanilla"] = 1] = "Vanilla";
	SerovalMode[SerovalMode["Cross"] = 2] = "Cross";
	return SerovalMode;
}({});
function createPlugin(plugin) {
	return plugin;
}
function dedupePlugins(deduped, plugins) {
	for (let i = 0, len = plugins.length; i < len; i++) {
		const current = plugins[i];
		if (!deduped.has(current)) {
			deduped.add(current);
			if (current.extends) dedupePlugins(deduped, current.extends);
		}
	}
}
function resolvePlugins(plugins) {
	if (plugins) {
		const deduped = /* @__PURE__ */ new Set();
		dedupePlugins(deduped, plugins);
		return [...deduped];
	}
}
//#endregion
//#region src/core/utils/typed-array.ts
function getTypedArrayConstructor(name) {
	switch (name) {
		case "Int8Array": return Int8Array;
		case "Int16Array": return Int16Array;
		case "Int32Array": return Int32Array;
		case "Uint8Array": return Uint8Array;
		case "Uint16Array": return Uint16Array;
		case "Uint32Array": return Uint32Array;
		case "Uint8ClampedArray": return Uint8ClampedArray;
		case "Float32Array": return Float32Array;
		case "Float64Array": return Float64Array;
		case "BigInt64Array": return BigInt64Array;
		case "BigUint64Array": return BigUint64Array;
		default: throw new SerovalUnknownTypedArrayError(name);
	}
}
//#endregion
//#region src/core/utils/valid-properties.ts
function isValidKey(key) {
	switch (key) {
		case "constructor":
		case "__proto__":
		case "prototype":
		case "__defineGetter__":
		case "__defineSetter__":
		case "__lookupGetter__":
		case "__lookupSetter__": return false;
		default: return true;
	}
}
function isValidSymbol(symbol) {
	switch (symbol) {
		case SYM_ASYNC_ITERATOR:
		case SYM_IS_CONCAT_SPREADABLE:
		case SYM_TO_STRING_TAG:
		case SYM_ITERATOR: return true;
		default: return false;
	}
}
//#endregion
//#region src/core/context/deserializer.ts
const DEFAULT_MAX_BASE64_LENGTH = 1e6;
const MIN_NATIVE_BASE64_LENGTH = 512;
const MAX_BIGINT_LENGTH = 1e4;
const MAX_REGEXP_SOURCE_LENGTH = 2e4;
function applyObjectFlag(obj, flag) {
	switch (flag) {
		case 3: return Object.freeze(obj);
		case 1: return Object.preventExtensions(obj);
		case 2: return Object.seal(obj);
		default: return obj;
	}
}
const DEFAULT_DEPTH_LIMIT = 1e3;
function createBaseDeserializerContext(mode, options) {
	var _options$maxBase64Len, _options$features;
	const maxBase64Length = (_options$maxBase64Len = options.maxBase64Length) !== null && _options$maxBase64Len !== void 0 ? _options$maxBase64Len : DEFAULT_MAX_BASE64_LENGTH;
	if (!Number.isSafeInteger(maxBase64Length) || maxBase64Length < 0) throw new RangeError("maxBase64Length must be a non-negative safe integer");
	const refs = options.refs || /* @__PURE__ */ new Map();
	if (!("types" in refs)) Object.assign(refs, { types: /* @__PURE__ */ new Map() });
	return {
		mode,
		plugins: options.plugins,
		refs,
		features: (_options$features = options.features) !== null && _options$features !== void 0 ? _options$features : 127 ^ (options.disabledFeatures || 0),
		depthLimit: options.depthLimit || DEFAULT_DEPTH_LIMIT,
		maxBase64Length
	};
}
function createVanillaDeserializerContext(options) {
	return {
		mode: 1,
		base: createBaseDeserializerContext(1, options),
		child: void 0,
		state: { marked: new Set(options.markedRefs) }
	};
}
function createCrossDeserializerContext(options) {
	return {
		mode: 2,
		base: createBaseDeserializerContext(2, options),
		child: void 0
	};
}
var DeserializePluginContext = class {
	constructor(_p, depth) {
		this._p = _p;
		this.depth = depth;
	}
	deserialize(node) {
		return deserialize$1(this._p, this.depth, node);
	}
};
function guardIndexedValue(ctx, id) {
	if (id < 0 || !Number.isFinite(id) || !Number.isInteger(id)) throw new SerovalMalformedNodeError({
		t: 4,
		i: id
	});
	if (ctx.refs.has(id)) throw new Error("Conflicted ref id: " + id);
}
function isThennable(value) {
	return !!value && typeof value === "object" && "then" in value && typeof value.then === "function";
}
function assignIndexedValueVanilla(ctx, id, value) {
	guardIndexedValue(ctx.base, id);
	if (ctx.state.marked.has(id)) ctx.base.refs.set(id, value);
	return value;
}
function assignIndexedValueCross(ctx, id, value) {
	guardIndexedValue(ctx.base, id);
	ctx.base.refs.set(id, value);
	return value;
}
function assignIndexedValue$1(ctx, id, value) {
	return ctx.mode === 1 ? assignIndexedValueVanilla(ctx, id, value) : assignIndexedValueCross(ctx, id, value);
}
function deserializeKnownValue(node, record, key) {
	if (Object.hasOwn(record, key)) return record[key];
	throw new SerovalMalformedNodeError(node);
}
function deserializeReference(ctx, node) {
	return assignIndexedValue$1(ctx, node.i, getReference(deserializeString(node.s)));
}
function deserializeArray(ctx, depth, node) {
	const items = node.a;
	const len = items.length;
	const result = assignIndexedValue$1(ctx, node.i, new Array(len));
	for (let i = 0, item; i < len; i++) {
		item = items[i];
		if (item) result[i] = deserialize$1(ctx, depth, item);
	}
	applyObjectFlag(result, node.o);
	return result;
}
function assignStringProperty(object, key, value) {
	if (isValidKey(key)) object[key] = value;
	else Object.defineProperty(object, key, {
		value,
		configurable: true,
		enumerable: true,
		writable: true
	});
}
function assignProperty(ctx, depth, object, key, value) {
	if (typeof key === "string") assignStringProperty(object, deserializeString(key), deserialize$1(ctx, depth, value));
	else {
		const actual = deserialize$1(ctx, depth, key);
		switch (typeof actual) {
			case "string":
				assignStringProperty(object, actual, deserialize$1(ctx, depth, value));
				break;
			case "symbol":
				if (isValidSymbol(actual)) object[actual] = deserialize$1(ctx, depth, value);
				break;
			default: throw new SerovalMalformedNodeError(key);
		}
	}
}
function assignNodeType(ctx, id, type) {
	ctx.base.refs.types.set(id, type);
}
function validateNodeType(ctx, node, id, type) {
	if (ctx.base.refs.types.get(id) !== type) throw new SerovalMalformedNodeError(node);
}
function deserializeProperties(ctx, depth, node, result) {
	const keys = node.k;
	if (keys.length > 0) for (let i = 0, vals = node.v, len = keys.length; i < len; i++) assignProperty(ctx, depth, result, keys[i], vals[i]);
	return result;
}
function deserializeObject(ctx, depth, node) {
	const result = assignIndexedValue$1(ctx, node.i, node.t === 10 ? {} : Object.create(null));
	deserializeProperties(ctx, depth, node.p, result);
	applyObjectFlag(result, node.o);
	return result;
}
function deserializeDate(ctx, node) {
	return assignIndexedValue$1(ctx, node.i, new Date(node.s));
}
function deserializeTemporal(ctx, node) {
	if (!(ctx.base.features & 64)) throw new SerovalUnsupportedNodeError(node);
	let value;
	switch (node.c) {
		case 0:
			value = Temporal.Instant.from(node.s);
			break;
		case 1:
			value = Temporal.Duration.from(node.s);
			break;
		case 2:
			value = Temporal.PlainDate.from(node.s);
			break;
		case 3:
			value = Temporal.PlainDateTime.from(node.s);
			break;
		case 4:
			value = Temporal.PlainMonthDay.from(node.s);
			break;
		case 5:
			value = Temporal.PlainTime.from(node.s);
			break;
		case 6:
			value = Temporal.PlainYearMonth.from(node.s);
			break;
		case 7:
			value = Temporal.ZonedDateTime.from(node.s);
			break;
		default: throw new SerovalMalformedNodeError(node);
	}
	return assignIndexedValue$1(ctx, node.i, value);
}
function deserializeRegExp(ctx, node) {
	if (ctx.base.features & 32) {
		const source = deserializeString(node.c);
		if (source.length > MAX_REGEXP_SOURCE_LENGTH) throw new SerovalMalformedNodeError(node);
		return assignIndexedValue$1(ctx, node.i, new RegExp(source, node.m));
	}
	throw new SerovalUnsupportedNodeError(node);
}
function deserializeSet(ctx, depth, node) {
	const result = assignIndexedValue$1(ctx, node.i, /* @__PURE__ */ new Set());
	for (let i = 0, items = node.a, len = items.length; i < len; i++) result.add(deserialize$1(ctx, depth, items[i]));
	return result;
}
function deserializeMap(ctx, depth, node) {
	const result = assignIndexedValue$1(ctx, node.i, /* @__PURE__ */ new Map());
	for (let i = 0, keys = node.e.k, vals = node.e.v, len = keys.length; i < len; i++) result.set(deserialize$1(ctx, depth, keys[i]), deserialize$1(ctx, depth, vals[i]));
	return result;
}
function deserializeArrayBuffer(ctx, node) {
	if (typeof node.s !== "string") throw new SerovalMalformedNodeError(node);
	if (node.s.length > ctx.base.maxBase64Length) throw new RangeError("ArrayBuffer exceeds maxBase64Length (" + ctx.base.maxBase64Length + ")");
	const source = deserializeString(node.s);
	let buffer;
	if (source.length < MIN_NATIVE_BASE64_LENGTH || typeof Buffer === "undefined") buffer = ARRAY_BUFFER_CONSTRUCTOR(source);
	else {
		const decoded = atob(source);
		buffer = new ArrayBuffer(decoded.length);
		Buffer.from(buffer).write(decoded, "latin1");
	}
	return assignIndexedValue$1(ctx, node.i, buffer);
}
function deserializeTypedArray(ctx, depth, node) {
	var _node$b;
	const construct = getTypedArrayConstructor(node.c);
	const source = deserialize$1(ctx, depth, node.f);
	if (!(source instanceof ArrayBuffer)) throw new SerovalMalformedNodeError(node);
	const offset = (_node$b = node.b) !== null && _node$b !== void 0 ? _node$b : 0;
	if (offset < 0 || offset > source.byteLength) throw new SerovalMalformedNodeError(node);
	return assignIndexedValue$1(ctx, node.i, new construct(source, offset, node.l));
}
function deserializeDataView(ctx, depth, node) {
	var _node$b2;
	const source = deserialize$1(ctx, depth, node.f);
	if (!(source instanceof ArrayBuffer)) throw new SerovalMalformedNodeError(node);
	const offset = (_node$b2 = node.b) !== null && _node$b2 !== void 0 ? _node$b2 : 0;
	if (offset < 0 || offset > source.byteLength) throw new SerovalMalformedNodeError(node);
	return assignIndexedValue$1(ctx, node.i, new DataView(source, offset, node.l));
}
function deserializeDictionary(ctx, depth, node, result) {
	if (node.p) {
		const fields = deserializeProperties(ctx, depth, node.p, {});
		Object.defineProperties(result, Object.getOwnPropertyDescriptors(fields));
	}
	return result;
}
function deserializeAggregateError(ctx, depth, node) {
	return deserializeDictionary(ctx, depth, node, assignIndexedValue$1(ctx, node.i, new AggregateError([], deserializeString(node.m))));
}
function deserializeError(ctx, depth, node) {
	const construct = deserializeKnownValue(node, ERROR_CONSTRUCTOR, node.s);
	return deserializeDictionary(ctx, depth, node, assignIndexedValue$1(ctx, node.i, new construct(deserializeString(node.m))));
}
function deserializePromise(ctx, depth, node) {
	const deferred = PROMISE_CONSTRUCTOR();
	const result = assignIndexedValue$1(ctx, node.i, deferred.p);
	const deserialized = deserialize$1(ctx, depth, node.f);
	if (isThennable(deserialized)) throw new SerovalMalformedNodeError(node.f);
	if (node.s) deferred.s(deserialized);
	else deferred.f(deserialized);
	return result;
}
function deserializeBoxed(ctx, depth, node) {
	return assignIndexedValue$1(ctx, node.i, Object(deserialize$1(ctx, depth, node.f)));
}
function deserializePlugin(ctx, depth, node) {
	const currentPlugins = ctx.base.plugins;
	if (currentPlugins) {
		const tag = deserializeString(node.c);
		for (let i = 0, len = currentPlugins.length; i < len; i++) {
			const plugin = currentPlugins[i];
			if (plugin.tag === tag) return assignIndexedValue$1(ctx, node.i, plugin.deserialize(node.s, new DeserializePluginContext(ctx, depth), { id: node.i }));
		}
	}
	throw new SerovalMissingPluginError(node.c);
}
function deserializePromiseConstructor(ctx, node) {
	const value = assignIndexedValue$1(ctx, node.i, assignIndexedValue$1(ctx, node.s, PROMISE_CONSTRUCTOR()).p);
	assignNodeType(ctx, node.s, 22);
	return value;
}
function deserializePromiseFulfill(ctx, depth, node) {
	const deferred = ctx.base.refs.get(node.i);
	if (deferred) {
		validateNodeType(ctx, node, node.i, 22);
		const deserialized = deserialize$1(ctx, depth, node.a[1]);
		if (isThennable(deserialized)) throw new SerovalMalformedNodeError(node.a[1]);
		if (node.t === 23) deferred.s(deserialized);
		else deferred.f(deserialized);
		return;
	}
	throw new SerovalMissingInstanceError("Promise");
}
function deserializeIteratorFactoryInstance(ctx, depth, node) {
	deserialize$1(ctx, depth, node.a[0]);
	const source = deserialize$1(ctx, depth, node.a[1]);
	validateNodeType(ctx, node, node.a[1].i, 35);
	if (!source) throw new SerovalMalformedNodeError(node.a[1]);
	return sequenceToIterator(source);
}
function deserializeAsyncIteratorFactoryInstance(ctx, depth, node) {
	deserialize$1(ctx, depth, node.a[0]);
	const source = deserialize$1(ctx, depth, node.a[1]);
	validateNodeType(ctx, node, node.a[1].i, 31);
	if (!source) throw new SerovalMalformedNodeError(node.a[1]);
	return streamToAsyncIterable(source);
}
function deserializeStreamConstructor(ctx, depth, node) {
	const result = assignIndexedValue$1(ctx, node.i, createStream());
	assignNodeType(ctx, node.i, 31);
	const items = node.a;
	const len = items.length;
	if (len) for (let i = 0; i < len; i++) deserialize$1(ctx, depth, items[i]);
	return result;
}
function deserializeStreamNext(ctx, depth, node) {
	const deferred = ctx.base.refs.get(node.i);
	if (deferred) {
		validateNodeType(ctx, node, node.i, 31);
		deferred.next(deserialize$1(ctx, depth, node.f));
		return;
	}
	throw new SerovalMissingInstanceError("Stream");
}
function deserializeStreamThrow(ctx, depth, node) {
	const deferred = ctx.base.refs.get(node.i);
	if (deferred) {
		validateNodeType(ctx, node, node.i, 31);
		deferred.throw(deserialize$1(ctx, depth, node.f));
		return;
	}
	throw new SerovalMissingInstanceError("Stream");
}
function deserializeStreamReturn(ctx, depth, node) {
	const deferred = ctx.base.refs.get(node.i);
	if (deferred) {
		validateNodeType(ctx, node, node.i, 31);
		deferred.return(deserialize$1(ctx, depth, node.f));
		return;
	}
	throw new SerovalMissingInstanceError("Stream");
}
function deserializeIteratorFactory(ctx, depth, node) {
	deserialize$1(ctx, depth, node.f);
}
function deserializeAsyncIteratorFactory(ctx, depth, node) {
	deserialize$1(ctx, depth, node.a[1]);
}
function deserializeSequence(ctx, depth, node) {
	const result = assignIndexedValue$1(ctx, node.i, createSequence([], node.s, node.l));
	assignNodeType(ctx, node.i, 35);
	for (let i = 0, len = node.a.length; i < len; i++) result.v[i] = deserialize$1(ctx, depth, node.a[i]);
	return result;
}
function deserialize$1(ctx, depth, node) {
	if (depth > ctx.base.depthLimit) throw new SerovalDepthLimitError(ctx.base.depthLimit);
	depth += 1;
	switch (node.t) {
		case 2: return deserializeKnownValue(node, CONSTANT_VAL, node.s);
		case 0: return Number(node.s);
		case 1: return deserializeString(String(node.s));
		case 3:
			if (String(node.s).length > MAX_BIGINT_LENGTH) throw new SerovalMalformedNodeError(node);
			return BigInt(node.s);
		case 4: return ctx.base.refs.get(node.i);
		case 18: return deserializeReference(ctx, node);
		case 9: return deserializeArray(ctx, depth, node);
		case 10:
		case 11: return deserializeObject(ctx, depth, node);
		case 5: return deserializeDate(ctx, node);
		case 6: return deserializeRegExp(ctx, node);
		case 7: return deserializeSet(ctx, depth, node);
		case 8: return deserializeMap(ctx, depth, node);
		case 19: return deserializeArrayBuffer(ctx, node);
		case 16:
		case 15: return deserializeTypedArray(ctx, depth, node);
		case 20: return deserializeDataView(ctx, depth, node);
		case 14: return deserializeAggregateError(ctx, depth, node);
		case 13: return deserializeError(ctx, depth, node);
		case 12: return deserializePromise(ctx, depth, node);
		case 17: return deserializeKnownValue(node, SYMBOL_REF, node.s);
		case 21: return deserializeBoxed(ctx, depth, node);
		case 25: return deserializePlugin(ctx, depth, node);
		case 22: return deserializePromiseConstructor(ctx, node);
		case 23:
		case 24: return deserializePromiseFulfill(ctx, depth, node);
		case 28: return deserializeIteratorFactoryInstance(ctx, depth, node);
		case 30: return deserializeAsyncIteratorFactoryInstance(ctx, depth, node);
		case 31: return deserializeStreamConstructor(ctx, depth, node);
		case 32: return deserializeStreamNext(ctx, depth, node);
		case 33: return deserializeStreamThrow(ctx, depth, node);
		case 34: return deserializeStreamReturn(ctx, depth, node);
		case 27: return deserializeIteratorFactory(ctx, depth, node);
		case 29: return deserializeAsyncIteratorFactory(ctx, depth, node);
		case 35: return deserializeSequence(ctx, depth, node);
		case 36: return deserializeTemporal(ctx, node);
		default: throw new SerovalUnsupportedNodeError(node);
	}
}
function deserializeTop(ctx, node) {
	try {
		return deserialize$1(ctx, 0, node);
	} catch (error) {
		throw new SerovalDeserializationError(error);
	}
}
//#endregion
//#region src/core/function-string.ts
const RETURN = () => T;
const SERIALIZED_RETURN = /* @__PURE__ */ RETURN.toString();
const IS_MODERN = /* @__PURE__ */ /=>/.test(SERIALIZED_RETURN);
function createFunction(parameters, body) {
	if (IS_MODERN) return (parameters.length === 1 ? parameters[0] : "(" + parameters.join(",") + ")") + "=>" + (body.startsWith("{") ? "(" + body + ")" : body);
	return "function(" + parameters.join(",") + "){return " + body + "}";
}
function createEffectfulFunction(parameters, body) {
	if (IS_MODERN) return (parameters.length === 1 ? parameters[0] : "(" + parameters.join(",") + ")") + "=>{" + body + "}";
	return "function(" + parameters.join(",") + "){" + body + "}";
}
//#endregion
//#region src/core/utils/get-identifier.ts
const REF_START_CHARS = "hjkmoquxzABCDEFGHIJKLNPQRTUVWXYZ$_";
const REF_START_CHARS_LEN = 34;
const REF_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789$_";
const REF_CHARS_LEN = 64;
function getIdentifier(index) {
	let mod = index % REF_START_CHARS_LEN;
	let ref = REF_START_CHARS[mod];
	index = (index - mod) / REF_START_CHARS_LEN;
	while (index > 0) {
		mod = index % REF_CHARS_LEN;
		ref += REF_CHARS[mod];
		index = (index - mod) / REF_CHARS_LEN;
	}
	return ref;
}
//#endregion
//#region src/core/utils/is-valid-identifier.ts
const IDENTIFIER_CHECK = /^[$A-Z_][0-9A-Z_$]*$/i;
function isValidIdentifier(name) {
	const char = name[0];
	return (char === "$" || char === "_" || char >= "A" && char <= "Z" || char >= "a" && char <= "z") && IDENTIFIER_CHECK.test(name);
}
//#endregion
//#region src/core/context/serializer.ts
function getAssignmentExpression(assignment) {
	switch (assignment.t) {
		case 0: return assignment.s + "=" + assignment.v;
		case 2: return assignment.s + ".set(" + assignment.k + "," + assignment.v + ")";
		case 1: return assignment.s + ".add(" + assignment.v + ")";
		case 3: return assignment.s + ".delete(" + assignment.k + ")";
		case 4: return "Object.defineProperty(" + assignment.s + ",\"__proto__\",{value:" + assignment.k + ",configurable:!0,enumerable:!0,writable:!0})";
	}
}
function mergeAssignments(assignments) {
	const newAssignments = [];
	let current = assignments[0];
	for (let i = 1, len = assignments.length, item, prev = current; i < len; i++) {
		item = assignments[i];
		if (item.t === 0 && item.v === prev.v) current = {
			t: 0,
			s: item.s,
			k: void 0,
			v: getAssignmentExpression(current)
		};
		else if (item.t === 2 && item.s === prev.s) current = {
			t: 2,
			s: getAssignmentExpression(current),
			k: item.k,
			v: item.v
		};
		else if (item.t === 1 && item.s === prev.s) current = {
			t: 1,
			s: getAssignmentExpression(current),
			k: void 0,
			v: item.v
		};
		else if (item.t === 3 && item.s === prev.s) current = {
			t: 3,
			s: getAssignmentExpression(current),
			k: item.k,
			v: void 0
		};
		else {
			newAssignments.push(current);
			current = item;
		}
		prev = item;
	}
	newAssignments.push(current);
	return newAssignments;
}
function resolveAssignments(assignments) {
	if (assignments.length) {
		let result = "";
		const merged = mergeAssignments(assignments);
		for (let i = 0, len = merged.length; i < len; i++) result += getAssignmentExpression(merged[i]) + ",";
		return result;
	}
}
const NULL_CONSTRUCTOR = "Object.create(null)";
const SET_CONSTRUCTOR = "new Set";
const MAP_CONSTRUCTOR = "new Map";
const PROMISE_RESOLVE = "Promise.resolve";
const PROMISE_REJECT = "Promise.reject";
const OBJECT_FLAG_CONSTRUCTOR = {
	[3]: "Object.freeze",
	[2]: "Object.seal",
	[1]: "Object.preventExtensions",
	[0]: void 0
};
function createBaseSerializerContext(mode, options) {
	return {
		mode,
		plugins: options.plugins,
		features: options.features,
		marked: new Set(options.markedRefs),
		stack: [],
		flags: [],
		assignments: []
	};
}
function createVanillaSerializerState() {
	return {
		valid: /* @__PURE__ */ new Map(),
		vars: []
	};
}
function createVanillaSerializerContext(options) {
	return {
		mode: 1,
		base: createBaseSerializerContext(1, options),
		state: createVanillaSerializerState(),
		child: void 0
	};
}
function createCrossSerializerContext(options) {
	return {
		mode: 2,
		base: createBaseSerializerContext(2, options),
		state: options,
		child: void 0
	};
}
var SerializePluginContext = class {
	constructor(_p) {
		this._p = _p;
	}
	serialize(node) {
		return serialize$1(this._p, node);
	}
};
/**
* Creates the reference param (identifier) from the given reference ID
* Calling this function means the value has been referenced somewhere
*/
function getVanillaRefParam(state, index) {
	/**
	* Creates a new reference ID from a given reference ID
	* This new reference ID means that the reference itself
	* has been referenced at least once, and is used to generate
	* the variables
	*/
	let actualIndex = state.valid.get(index);
	if (actualIndex == null) {
		actualIndex = state.valid.size;
		state.valid.set(index, actualIndex);
	}
	let identifier = state.vars[actualIndex];
	if (identifier == null) {
		identifier = getIdentifier(actualIndex);
		state.vars[actualIndex] = identifier;
	}
	return identifier;
}
function getCrossRefParam(id) {
	return "$R[" + id + "]";
}
/**
* Converts the ID of a reference into a identifier string
* that is used to refer to the object instance in the
* generated script.
*/
function getRefParam(ctx, id) {
	return ctx.mode === 1 ? getVanillaRefParam(ctx.state, id) : getCrossRefParam(id);
}
function markSerializerRef(ctx, id) {
	ctx.marked.add(id);
}
function isSerializerRefMarked(ctx, id) {
	return ctx.marked.has(id);
}
function pushObjectFlag(ctx, flag, id) {
	if (flag !== 0) {
		markSerializerRef(ctx.base, id);
		ctx.base.flags.push({
			type: flag,
			value: getRefParam(ctx, id)
		});
	}
}
function resolveFlags(ctx) {
	let result = "";
	for (let i = 0, current = ctx.flags, len = current.length; i < len; i++) {
		const flag = current[i];
		result += OBJECT_FLAG_CONSTRUCTOR[flag.type] + "(" + flag.value + "),";
	}
	return result;
}
function resolvePatches(ctx) {
	const assignments = resolveAssignments(ctx.assignments);
	const flags = resolveFlags(ctx);
	if (assignments) {
		if (flags) return assignments + flags;
		return assignments;
	}
	return flags;
}
/**
* Generates the inlined assignment for the reference
* This is different from the assignments array as this one
* signifies creation rather than mutation
*/
function createAssignment(ctx, source, value) {
	ctx.assignments.push({
		t: 0,
		s: source,
		k: void 0,
		v: value
	});
}
function createAddAssignment(ctx, ref, value) {
	ctx.base.assignments.push({
		t: 1,
		s: getRefParam(ctx, ref),
		k: void 0,
		v: value
	});
}
function createSetAssignment(ctx, ref, key, value) {
	ctx.base.assignments.push({
		t: 2,
		s: getRefParam(ctx, ref),
		k: key,
		v: value
	});
}
function createDeleteAssignment(ctx, ref, key) {
	ctx.base.assignments.push({
		t: 3,
		s: getRefParam(ctx, ref),
		k: key,
		v: void 0
	});
}
function createArrayAssign(ctx, ref, index, value) {
	createAssignment(ctx.base, getRefParam(ctx, ref) + "[" + index + "]", value);
}
function createObjectAssign(ctx, ref, key, value) {
	if (!isValidKey(key)) {
		ctx.base.assignments.push({
			t: 4,
			s: getRefParam(ctx, ref),
			k: value,
			v: void 0
		});
		return;
	}
	createAssignment(ctx.base, getRefParam(ctx, ref) + "." + key, value);
}
function createSequenceAssign(ctx, ref, index, value) {
	createAssignment(ctx.base, getRefParam(ctx, ref) + ".v[" + index + "]", value);
}
/**
* Checks if the value is in the stack. Stack here is a reference
* structure to know if a object is to be accessed in a TDZ.
*/
function isIndexedValueInStack(ctx, node) {
	return node.t === 4 && ctx.stack.includes(node.i);
}
/**
* Produces an assignment expression. `id` generates a reference
* parameter (through `getRefParam`) and has the option to
* return the reference parameter directly or assign a value to
* it.
*/
function assignIndexedValue(ctx, index, value) {
	if (ctx.mode === 1 && !isSerializerRefMarked(ctx.base, index)) return value;
	/**
	* In cross-reference, we have to assume that
	* every reference are going to be referenced
	* in the future, and so we need to store
	* all of it into the reference array.
	*
	* otherwise in vanilla, we only do this if it
	* is actually referenced
	*/
	return getRefParam(ctx, index) + "=" + value;
}
function serializeReference(node) {
	return "__SEROVAL_REFS__.get(\"" + node.s + "\")";
}
function serializeArrayItem(ctx, id, item, index) {
	if (item) {
		if (isIndexedValueInStack(ctx.base, item)) {
			markSerializerRef(ctx.base, id);
			createArrayAssign(ctx, id, index, getRefParam(ctx, item.i));
			return "";
		}
		return serialize$1(ctx, item);
	}
	return "";
}
function serializeArray(ctx, node) {
	const id = node.i;
	const list = node.a;
	const len = list.length;
	if (len > 0) {
		ctx.base.stack.push(id);
		let values = serializeArrayItem(ctx, id, list[0], 0);
		let isHoley = values === "";
		for (let i = 1, item; i < len; i++) {
			item = serializeArrayItem(ctx, id, list[i], i);
			values += "," + item;
			isHoley = item === "";
		}
		ctx.base.stack.pop();
		pushObjectFlag(ctx, node.o, node.i);
		return "[" + values + (isHoley ? ",]" : "]");
	}
	return "[]";
}
function serializeProperty(ctx, source, key, val) {
	if (typeof key === "string") {
		const check = Number(key);
		const isIdentifier = check >= 0 && check.toString() === key || isValidIdentifier(key);
		if (isIndexedValueInStack(ctx.base, val)) {
			const refParam = getRefParam(ctx, val.i);
			markSerializerRef(ctx.base, source.i);
			if (isIdentifier && check !== check) createObjectAssign(ctx, source.i, key, refParam);
			else createArrayAssign(ctx, source.i, isIdentifier ? key : "\"" + key + "\"", refParam);
			return "";
		}
		if (isValidKey(key)) return (isIdentifier ? key : "\"" + key + "\"") + ":" + serialize$1(ctx, val);
		return "[\"" + key + "\"]:" + serialize$1(ctx, val);
	}
	return "[" + serialize$1(ctx, key) + "]:" + serialize$1(ctx, val);
}
function serializeProperties(ctx, source, record) {
	const keys = record.k;
	const len = keys.length;
	if (len > 0) {
		const values = record.v;
		ctx.base.stack.push(source.i);
		let result = serializeProperty(ctx, source, keys[0], values[0]);
		for (let i = 1, item = result; i < len; i++) {
			item = serializeProperty(ctx, source, keys[i], values[i]);
			result += (item && result && ",") + item;
		}
		ctx.base.stack.pop();
		return "{" + result + "}";
	}
	return "{}";
}
function serializeObject(ctx, node) {
	pushObjectFlag(ctx, node.o, node.i);
	return serializeProperties(ctx, node, node.p);
}
function serializeWithObjectAssign(ctx, source, value, serialized) {
	const fields = serializeProperties(ctx, source, value);
	if (fields !== "{}") return "Object.assign(" + serialized + "," + fields + ")";
	return serialized;
}
function serializeStringKeyAssignment(ctx, source, mainAssignments, key, value) {
	const base = ctx.base;
	const serialized = serialize$1(ctx, value);
	const check = Number(key);
	const isIdentifier = check >= 0 && check.toString() === key || isValidIdentifier(key);
	if (isIndexedValueInStack(base, value)) {
		if (isIdentifier && check !== check) createObjectAssign(ctx, source.i, key, serialized);
		else createArrayAssign(ctx, source.i, isIdentifier ? key : "\"" + key + "\"", serialized);
	} else {
		const parentAssignment = base.assignments;
		base.assignments = mainAssignments;
		if (isIdentifier && check !== check) createObjectAssign(ctx, source.i, key, serialized);
		else createArrayAssign(ctx, source.i, isIdentifier ? key : "\"" + key + "\"", serialized);
		base.assignments = parentAssignment;
	}
}
function serializeAssignment(ctx, source, mainAssignments, key, value) {
	if (typeof key === "string") serializeStringKeyAssignment(ctx, source, mainAssignments, key, value);
	else {
		const base = ctx.base;
		const parent = base.stack;
		base.stack = [];
		const serialized = serialize$1(ctx, value);
		base.stack = parent;
		const parentAssignment = base.assignments;
		base.assignments = mainAssignments;
		createArrayAssign(ctx, source.i, serialize$1(ctx, key), serialized);
		base.assignments = parentAssignment;
	}
}
function serializeAssignments(ctx, source, node) {
	const keys = node.k;
	const len = keys.length;
	if (len > 0) {
		const mainAssignments = [];
		const values = node.v;
		ctx.base.stack.push(source.i);
		for (let i = 0; i < len; i++) serializeAssignment(ctx, source, mainAssignments, keys[i], values[i]);
		ctx.base.stack.pop();
		return resolveAssignments(mainAssignments);
	}
}
function serializeDictionary(ctx, node, init) {
	if (node.p) {
		const base = ctx.base;
		if (base.features & 8) init = serializeWithObjectAssign(ctx, node, node.p, init);
		else {
			markSerializerRef(base, node.i);
			const assignments = serializeAssignments(ctx, node, node.p);
			if (assignments) return "(" + assignIndexedValue(ctx, node.i, init) + "," + assignments + getRefParam(ctx, node.i) + ")";
		}
	}
	return init;
}
function serializeNullConstructor(ctx, node) {
	pushObjectFlag(ctx, node.o, node.i);
	return serializeDictionary(ctx, node, NULL_CONSTRUCTOR);
}
function serializeDate(node) {
	return "new Date(\"" + node.s + "\")";
}
const TEMPORAL_CONSTRUCTOR = {
	[0]: "Temporal.Instant",
	[1]: "Temporal.Duration",
	[2]: "Temporal.PlainDate",
	[3]: "Temporal.PlainDateTime",
	[4]: "Temporal.PlainMonthDay",
	[5]: "Temporal.PlainTime",
	[6]: "Temporal.PlainYearMonth",
	[7]: "Temporal.ZonedDateTime"
};
function serializeTemporal(ctx, node) {
	if (ctx.base.features & 64) return TEMPORAL_CONSTRUCTOR[node.c] + ".from(\"" + node.s + "\")";
	throw new SerovalUnsupportedNodeError(node);
}
function serializeRegExp(ctx, node) {
	if (ctx.base.features & 32) return "/" + deserializeString(node.c) + "/" + node.m;
	throw new SerovalUnsupportedNodeError(node);
}
function serializeSetItem(ctx, id, item) {
	const base = ctx.base;
	if (isIndexedValueInStack(base, item)) {
		markSerializerRef(base, id);
		createAddAssignment(ctx, id, getRefParam(ctx, item.i));
		return "";
	}
	return serialize$1(ctx, item);
}
function serializeSet(ctx, node) {
	let serialized = SET_CONSTRUCTOR;
	const items = node.a;
	const size = items.length;
	const id = node.i;
	if (size > 0) {
		ctx.base.stack.push(id);
		let result = serializeSetItem(ctx, id, items[0]);
		for (let i = 1, item = result; i < size; i++) {
			item = serializeSetItem(ctx, id, items[i]);
			result += (item && result && ",") + item;
		}
		ctx.base.stack.pop();
		if (result) serialized += "([" + result + "])";
	}
	return serialized;
}
function serializeMapEntry(ctx, id, key, val, sentinel) {
	const base = ctx.base;
	if (isIndexedValueInStack(base, key)) {
		const keyRef = getRefParam(ctx, key.i);
		markSerializerRef(base, id);
		if (isIndexedValueInStack(base, val)) {
			createSetAssignment(ctx, id, keyRef, getRefParam(ctx, val.i));
			return "";
		}
		if (val.t !== 4 && val.i != null && isSerializerRefMarked(base, val.i)) {
			const serialized = "(" + serialize$1(ctx, val) + ",[" + sentinel + "," + sentinel + "])";
			createSetAssignment(ctx, id, keyRef, getRefParam(ctx, val.i));
			createDeleteAssignment(ctx, id, sentinel);
			return serialized;
		}
		const parent = base.stack;
		base.stack = [];
		createSetAssignment(ctx, id, keyRef, serialize$1(ctx, val));
		base.stack = parent;
		return "";
	}
	if (isIndexedValueInStack(base, val)) {
		const valueRef = getRefParam(ctx, val.i);
		markSerializerRef(base, id);
		if (key.t !== 4 && key.i != null && isSerializerRefMarked(base, key.i)) {
			const serialized = "(" + serialize$1(ctx, key) + ",[" + sentinel + "," + sentinel + "])";
			createSetAssignment(ctx, id, getRefParam(ctx, key.i), valueRef);
			createDeleteAssignment(ctx, id, sentinel);
			return serialized;
		}
		const parent = base.stack;
		base.stack = [];
		createSetAssignment(ctx, id, serialize$1(ctx, key), valueRef);
		base.stack = parent;
		return "";
	}
	return "[" + serialize$1(ctx, key) + "," + serialize$1(ctx, val) + "]";
}
function serializeMap(ctx, node) {
	let serialized = MAP_CONSTRUCTOR;
	const keys = node.e.k;
	const size = keys.length;
	const id = node.i;
	const sentinel = node.f;
	const sentinelId = getRefParam(ctx, sentinel.i);
	const base = ctx.base;
	if (size > 0) {
		const vals = node.e.v;
		base.stack.push(id);
		let result = serializeMapEntry(ctx, id, keys[0], vals[0], sentinelId);
		for (let i = 1, item = result; i < size; i++) {
			item = serializeMapEntry(ctx, id, keys[i], vals[i], sentinelId);
			result += (item && result && ",") + item;
		}
		base.stack.pop();
		if (result) serialized += "([" + result + "])";
	}
	if (sentinel.t === 26) {
		markSerializerRef(base, sentinel.i);
		serialized = "(" + serialize$1(ctx, sentinel) + "," + serialized + ")";
	}
	return serialized;
}
function serializeArrayBuffer(ctx, node) {
	return getConstructor(ctx, node.f) + "(\"" + node.s + "\")";
}
function serializeTypedArray(ctx, node) {
	return "new " + node.c + "(" + serialize$1(ctx, node.f) + "," + node.b + "," + node.l + ")";
}
function serializeDataView(ctx, node) {
	return "new DataView(" + serialize$1(ctx, node.f) + "," + node.b + "," + node.l + ")";
}
function serializeAggregateError(ctx, node) {
	const id = node.i;
	ctx.base.stack.push(id);
	const serialized = serializeDictionary(ctx, node, "new AggregateError([],\"" + node.m + "\")");
	ctx.base.stack.pop();
	return serialized;
}
function serializeError(ctx, node) {
	return serializeDictionary(ctx, node, "new " + ERROR_CONSTRUCTOR_STRING[node.s] + "(\"" + node.m + "\")");
}
function serializePromise(ctx, node) {
	let serialized;
	const fulfilled = node.f;
	const id = node.i;
	const promiseConstructor = node.s ? PROMISE_RESOLVE : PROMISE_REJECT;
	const base = ctx.base;
	if (isIndexedValueInStack(base, fulfilled)) {
		const ref = getRefParam(ctx, fulfilled.i);
		serialized = promiseConstructor + (node.s ? "().then(" + createFunction([], ref) + ")" : "().catch(" + createEffectfulFunction([], "throw " + ref) + ")");
	} else {
		base.stack.push(id);
		const result = serialize$1(ctx, fulfilled);
		base.stack.pop();
		serialized = promiseConstructor + "(" + result + ")";
	}
	return serialized;
}
function serializeBoxed(ctx, node) {
	return "Object(" + serialize$1(ctx, node.f) + ")";
}
function getConstructor(ctx, node) {
	const current = serialize$1(ctx, node);
	return node.t === 4 ? current : "(" + current + ")";
}
function serializePromiseConstructor(ctx, node) {
	if (ctx.mode === 1) throw new SerovalUnsupportedNodeError(node);
	return "(" + assignIndexedValue(ctx, node.s, getConstructor(ctx, node.f) + "()") + ").p";
}
function serializePromiseResolve(ctx, node) {
	if (ctx.mode === 1) throw new SerovalUnsupportedNodeError(node);
	return getConstructor(ctx, node.a[0]) + "(" + getRefParam(ctx, node.i) + "," + serialize$1(ctx, node.a[1]) + ")";
}
function serializePromiseReject(ctx, node) {
	if (ctx.mode === 1) throw new SerovalUnsupportedNodeError(node);
	return getConstructor(ctx, node.a[0]) + "(" + getRefParam(ctx, node.i) + "," + serialize$1(ctx, node.a[1]) + ")";
}
function serializePlugin(ctx, node) {
	const currentPlugins = ctx.base.plugins;
	if (currentPlugins) for (let i = 0, len = currentPlugins.length; i < len; i++) {
		const plugin = currentPlugins[i];
		if (plugin.tag === node.c) {
			if (ctx.child == null) ctx.child = new SerializePluginContext(ctx);
			return plugin.serialize(node.s, ctx.child, { id: node.i });
		}
	}
	throw new SerovalMissingPluginError(node.c);
}
function serializeIteratorFactory(ctx, node) {
	let result = "";
	let initialized = false;
	if (node.f.t !== 4) {
		markSerializerRef(ctx.base, node.f.i);
		result = "(" + serialize$1(ctx, node.f) + ",";
		initialized = true;
	}
	result += assignIndexedValue(ctx, node.i, "(" + SERIALIZED_ITERATOR_CONSTRUCTOR + ")(" + getRefParam(ctx, node.f.i) + ")");
	if (initialized) result += ")";
	return result;
}
function serializeIteratorFactoryInstance(ctx, node) {
	return getConstructor(ctx, node.a[0]) + "(" + serialize$1(ctx, node.a[1]) + ")";
}
function serializeAsyncIteratorFactory(ctx, node) {
	const promise = node.a[0];
	const symbol = node.a[1];
	const base = ctx.base;
	let result = "";
	if (promise.t !== 4) {
		markSerializerRef(base, promise.i);
		result += "(" + serialize$1(ctx, promise);
	}
	if (symbol.t !== 4) {
		markSerializerRef(base, symbol.i);
		result += (result ? "," : "(") + serialize$1(ctx, symbol);
	}
	if (result) result += ",";
	const iterator = assignIndexedValue(ctx, node.i, "(" + SERIALIZED_ASYNC_ITERATOR_CONSTRUCTOR + ")(" + getRefParam(ctx, symbol.i) + "," + getRefParam(ctx, promise.i) + ")");
	if (result) return result + iterator + ")";
	return iterator;
}
function serializeAsyncIteratorFactoryInstance(ctx, node) {
	return getConstructor(ctx, node.a[0]) + "(" + serialize$1(ctx, node.a[1]) + ")";
}
function serializeStreamConstructor(ctx, node) {
	const result = assignIndexedValue(ctx, node.i, getConstructor(ctx, node.f) + "()");
	const len = node.a.length;
	if (len) {
		let values = serialize$1(ctx, node.a[0]);
		for (let i = 1; i < len; i++) values += "," + serialize$1(ctx, node.a[i]);
		return "(" + result + "," + values + "," + getRefParam(ctx, node.i) + ")";
	}
	return result;
}
function serializeStreamNext(ctx, node) {
	return getRefParam(ctx, node.i) + ".next(" + serialize$1(ctx, node.f) + ")";
}
function serializeStreamThrow(ctx, node) {
	return getRefParam(ctx, node.i) + ".throw(" + serialize$1(ctx, node.f) + ")";
}
function serializeStreamReturn(ctx, node) {
	return getRefParam(ctx, node.i) + ".return(" + serialize$1(ctx, node.f) + ")";
}
function serializeSequenceItem(ctx, id, index, item) {
	const base = ctx.base;
	if (isIndexedValueInStack(base, item)) {
		markSerializerRef(base, id);
		createSequenceAssign(ctx, id, index, getRefParam(ctx, item.i));
		return "";
	}
	return serialize$1(ctx, item);
}
function serializeSequence(ctx, node) {
	const items = node.a;
	const size = items.length;
	const id = node.i;
	if (size > 0) {
		ctx.base.stack.push(id);
		let result = serializeSequenceItem(ctx, id, 0, items[0]);
		for (let i = 1, item = result; i < size; i++) {
			item = serializeSequenceItem(ctx, id, i, items[i]);
			result += (item && result && ",") + item;
		}
		ctx.base.stack.pop();
		if (result) return "{__SEROVAL_SEQUENCE__:!0,v:[" + result + "],t:" + node.s + ",d:" + node.l + "}";
	}
	return "{__SEROVAL_SEQUENCE__:!0,v:[],t:-1,d:0}";
}
function serializeAssignable(ctx, node) {
	switch (node.t) {
		case 17: return SYMBOL_STRING[node.s];
		case 18: return serializeReference(node);
		case 9: return serializeArray(ctx, node);
		case 10: return serializeObject(ctx, node);
		case 11: return serializeNullConstructor(ctx, node);
		case 5: return serializeDate(node);
		case 6: return serializeRegExp(ctx, node);
		case 7: return serializeSet(ctx, node);
		case 8: return serializeMap(ctx, node);
		case 19: return serializeArrayBuffer(ctx, node);
		case 16:
		case 15: return serializeTypedArray(ctx, node);
		case 20: return serializeDataView(ctx, node);
		case 14: return serializeAggregateError(ctx, node);
		case 13: return serializeError(ctx, node);
		case 12: return serializePromise(ctx, node);
		case 21: return serializeBoxed(ctx, node);
		case 22: return serializePromiseConstructor(ctx, node);
		case 25: return serializePlugin(ctx, node);
		case 26: return SPECIAL_REF_STRING[node.s];
		case 35: return serializeSequence(ctx, node);
		case 36: return serializeTemporal(ctx, node);
		default: throw new SerovalUnsupportedNodeError(node);
	}
}
function serialize$1(ctx, node) {
	switch (node.t) {
		case 2: return CONSTANT_STRING[node.s];
		case 0: return "" + node.s;
		case 1: return "\"" + node.s + "\"";
		case 3: return node.s + "n";
		case 4: return getRefParam(ctx, node.i);
		case 23: return serializePromiseResolve(ctx, node);
		case 24: return serializePromiseReject(ctx, node);
		case 27: return serializeIteratorFactory(ctx, node);
		case 28: return serializeIteratorFactoryInstance(ctx, node);
		case 29: return serializeAsyncIteratorFactory(ctx, node);
		case 30: return serializeAsyncIteratorFactoryInstance(ctx, node);
		case 31: return serializeStreamConstructor(ctx, node);
		case 32: return serializeStreamNext(ctx, node);
		case 33: return serializeStreamThrow(ctx, node);
		case 34: return serializeStreamReturn(ctx, node);
		default: return assignIndexedValue(ctx, node.i, serializeAssignable(ctx, node));
	}
}
function serializeTopVanilla(ctx, tree) {
	const result = serialize$1(ctx, tree);
	if (tree.i != null && ctx.state.vars.length) {
		const patches = resolvePatches(ctx.base);
		let body = result;
		if (patches) {
			const index = getRefParam(ctx, tree.i);
			body = result + "," + patches + index;
			if (!result.startsWith(index + "=")) body = index + "=" + body;
			body = "(" + body + ")";
		}
		return "(" + createFunction(ctx.state.vars, body) + ")()";
	}
	if (tree.t === 10) return "(" + result + ")";
	return result;
}
function serializeTopCross(ctx, tree) {
	const result = serialize$1(ctx, tree);
	const id = tree.i;
	if (id == null) return result;
	const patches = resolvePatches(ctx.base);
	const ref = getRefParam(ctx, id);
	const scopeId = ctx.state.scopeId;
	const params = scopeId == null ? "" : "$R";
	const body = patches ? "(" + result + "," + patches + ref + ")" : result;
	if (params === "") {
		if (tree.t === 10 && !patches) return "(" + body + ")";
		return body;
	}
	const args = scopeId == null ? "()" : "($R[\"" + serializeString(scopeId) + "\"])";
	return "(" + createFunction([params], body) + ")" + args;
}
//#endregion
//#region src/core/context/sync-parser.ts
function createSyncParserContext(mode, options) {
	return {
		type: 1,
		base: createBaseParserContext(mode, options),
		child: void 0
	};
}
var SyncParsePluginContext = class {
	constructor(_p, depth) {
		this._p = _p;
		this.depth = depth;
	}
	parse(current) {
		return parseSOS(this._p, this.depth, current);
	}
};
var StreamParsePluginContext = class {
	constructor(_p, depth) {
		this._p = _p;
		this.depth = depth;
	}
	parse(current) {
		return parseSOS(this._p, this.depth, current);
	}
	parseWithError(current) {
		return parseWithError(this._p, this.depth, current);
	}
	isAlive() {
		return this._p.state.alive;
	}
	pushPendingState() {
		pushPendingState(this._p);
	}
	popPendingState() {
		popPendingState(this._p);
	}
	onParse(node) {
		onParse(this._p, node);
	}
	onError(error) {
		onError(this._p, error);
	}
	addCleanup(callback) {
		this._p.state.cleanups.push(callback);
	}
};
function createStreamParserState(options) {
	return {
		alive: true,
		pending: 0,
		initial: true,
		buffer: [],
		onParse: options.onParse,
		onError: options.onError,
		onDone: options.onDone,
		cleanups: []
	};
}
function createStreamParserContext(options) {
	return {
		type: 2,
		base: createBaseParserContext(2, options),
		state: createStreamParserState(options)
	};
}
function parseItems(ctx, depth, current) {
	const nodes = [];
	for (let i = 0, len = current.length; i < len; i++) if (i in current) nodes[i] = parseSOS(ctx, depth, current[i]);
	else nodes[i] = 0;
	return nodes;
}
function parseArray(ctx, depth, id, current) {
	return createArrayNode(id, current, parseItems(ctx, depth, current));
}
function parseProperties(ctx, depth, properties) {
	const entries = Object.entries(properties);
	const keyNodes = [];
	const valueNodes = [];
	for (let i = 0, len = entries.length; i < len; i++) {
		keyNodes.push(serializeString(entries[i][0]));
		valueNodes.push(parseSOS(ctx, depth, entries[i][1]));
	}
	if (SYM_ITERATOR in properties) {
		keyNodes.push(parseWellKnownSymbol(ctx.base, SYM_ITERATOR));
		valueNodes.push(createIteratorFactoryInstanceNode(parseIteratorFactory(ctx.base), parseSOS(ctx, depth, createSequenceFromIterable(properties))));
	}
	if (SYM_ASYNC_ITERATOR in properties) {
		keyNodes.push(parseWellKnownSymbol(ctx.base, SYM_ASYNC_ITERATOR));
		valueNodes.push(createAsyncIteratorFactoryInstanceNode(parseAsyncIteratorFactory(ctx.base), parseSOS(ctx, depth, ctx.type === 1 ? createStream() : createStreamFromAsyncIterable(properties, ctx.state.cleanups))));
	}
	if (SYM_TO_STRING_TAG in properties) {
		keyNodes.push(parseWellKnownSymbol(ctx.base, SYM_TO_STRING_TAG));
		valueNodes.push(createStringNode(properties[SYM_TO_STRING_TAG]));
	}
	if (SYM_IS_CONCAT_SPREADABLE in properties) {
		keyNodes.push(parseWellKnownSymbol(ctx.base, SYM_IS_CONCAT_SPREADABLE));
		valueNodes.push(properties[SYM_IS_CONCAT_SPREADABLE] ? TRUE_NODE : FALSE_NODE);
	}
	return {
		k: keyNodes,
		v: valueNodes
	};
}
function parsePlainObject(ctx, depth, id, current, empty) {
	return createObjectNode(id, current, empty, parseProperties(ctx, depth, current));
}
function parseBoxed(ctx, depth, id, current) {
	return createBoxedNode(id, parseSOS(ctx, depth, current.valueOf()));
}
function parseTypedArray(ctx, depth, id, current) {
	current = getArrayBufferView(ctx.base, current);
	return createTypedArrayNode(id, current, parseSOS(ctx, depth, current.buffer));
}
function parseBigIntTypedArray(ctx, depth, id, current) {
	current = getArrayBufferView(ctx.base, current);
	return createBigIntTypedArrayNode(id, current, parseSOS(ctx, depth, current.buffer));
}
function parseDataView(ctx, depth, id, current) {
	current = getArrayBufferView(ctx.base, current);
	return createDataViewNode(id, current, parseSOS(ctx, depth, current.buffer));
}
function parseError(ctx, depth, id, current) {
	const options = getErrorOptions(current, ctx.base.features);
	return createErrorNode(id, current, options ? parseProperties(ctx, depth, options) : void 0);
}
function parseAggregateError(ctx, depth, id, current) {
	const options = getErrorOptions(current, ctx.base.features);
	return createAggregateErrorNode(id, current, options ? parseProperties(ctx, depth, options) : void 0);
}
function parseMap(ctx, depth, id, current) {
	const keyNodes = [];
	const valueNodes = [];
	for (const [key, value] of current.entries()) {
		keyNodes.push(parseSOS(ctx, depth, key));
		valueNodes.push(parseSOS(ctx, depth, value));
	}
	return createMapNode(ctx.base, id, keyNodes, valueNodes);
}
function parseSet(ctx, depth, id, current) {
	const items = [];
	for (const item of current.keys()) items.push(parseSOS(ctx, depth, item));
	return createSetNode(id, items);
}
function parseStream(ctx, depth, id, current) {
	const result = createStreamConstructorNode(id, parseSpecialReference(ctx.base, 4), []);
	if (ctx.type === 1) return result;
	pushPendingState(ctx);
	current.on({
		next: (value) => {
			if (ctx.state.alive) {
				const parsed = parseWithError(ctx, depth, value);
				if (parsed) onParse(ctx, createStreamNextNode(id, parsed));
			}
		},
		throw: (value) => {
			if (ctx.state.alive) {
				const parsed = parseWithError(ctx, depth, value);
				if (parsed) onParse(ctx, createStreamThrowNode(id, parsed));
			}
			popPendingState(ctx);
		},
		return: (value) => {
			if (ctx.state.alive) {
				const parsed = parseWithError(ctx, depth, value);
				if (parsed) onParse(ctx, createStreamReturnNode(id, parsed));
			}
			popPendingState(ctx);
		}
	});
	return result;
}
function handlePromiseSuccess(id, depth, data) {
	if (this.state.alive) {
		const parsed = parseWithError(this, depth, data);
		if (parsed) onParse(this, createSerovalNode(23, id, void 0, void 0, void 0, void 0, void 0, [parseSpecialReference(this.base, 2), parsed], void 0, void 0, void 0, void 0));
		popPendingState(this);
	}
}
function handlePromiseFailure(id, depth, data) {
	if (this.state.alive) {
		const parsed = parseWithError(this, depth, data);
		if (parsed) onParse(this, createSerovalNode(24, id, void 0, void 0, void 0, void 0, void 0, [parseSpecialReference(this.base, 3), parsed], void 0, void 0, void 0, void 0));
	}
	popPendingState(this);
}
function parsePromise(ctx, depth, id, current) {
	const resolver = createIndexForValue(ctx.base, {});
	if (ctx.type === 2) {
		pushPendingState(ctx);
		current.then(handlePromiseSuccess.bind(ctx, resolver, depth), handlePromiseFailure.bind(ctx, resolver, depth));
	}
	return createPromiseConstructorNode(ctx.base, id, resolver);
}
function parsePluginSync(ctx, depth, id, current, currentPlugins) {
	for (let i = 0, len = currentPlugins.length; i < len; i++) {
		const plugin = currentPlugins[i];
		if (plugin.parse.sync && plugin.test(current)) return createPluginNode(id, plugin.tag, plugin.parse.sync(current, new SyncParsePluginContext(ctx, depth), { id }));
	}
}
function parsePluginStream(ctx, depth, id, current, currentPlugins) {
	for (let i = 0, len = currentPlugins.length; i < len; i++) {
		const plugin = currentPlugins[i];
		if (plugin.parse.stream && plugin.test(current)) return createPluginNode(id, plugin.tag, plugin.parse.stream(current, new StreamParsePluginContext(ctx, depth), { id }));
	}
}
function parsePlugin(ctx, depth, id, current) {
	const currentPlugins = ctx.base.plugins;
	if (currentPlugins) return ctx.type === 1 ? parsePluginSync(ctx, depth, id, current, currentPlugins) : parsePluginStream(ctx, depth, id, current, currentPlugins);
}
function parseSequence(ctx, depth, id, current) {
	const nodes = [];
	for (let i = 0, len = current.v.length; i < len; i++) nodes[i] = parseSOS(ctx, depth, current.v[i]);
	return createSequenceNode(id, nodes, current.t, current.d);
}
function parseObjectPhase2(ctx, depth, id, current, currentClass) {
	switch (currentClass) {
		case Object: return parsePlainObject(ctx, depth, id, current, false);
		case void 0: return parsePlainObject(ctx, depth, id, current, true);
		case Date: return createDateNode(id, current);
		case Error:
		case EvalError:
		case RangeError:
		case ReferenceError:
		case SyntaxError:
		case TypeError:
		case URIError: return parseError(ctx, depth, id, current);
		case Number:
		case Boolean:
		case String:
		case BigInt: return parseBoxed(ctx, depth, id, current);
		case ArrayBuffer: return createArrayBufferNode(ctx.base, id, current);
		case Int8Array:
		case Int16Array:
		case Int32Array:
		case Uint8Array:
		case Uint16Array:
		case Uint32Array:
		case Uint8ClampedArray:
		case Float32Array:
		case Float64Array: return parseTypedArray(ctx, depth, id, current);
		case DataView: return parseDataView(ctx, depth, id, current);
		case Map: return parseMap(ctx, depth, id, current);
		case Set: return parseSet(ctx, depth, id, current);
	}
	if (currentClass === Promise || current instanceof Promise) return parsePromise(ctx, depth, id, current);
	const currentFeatures = ctx.base.features;
	if (currentFeatures & 32 && currentClass === RegExp) return createRegExpNode(id, current);
	if (currentFeatures & 16) switch (currentClass) {
		case BigInt64Array:
		case BigUint64Array: return parseBigIntTypedArray(ctx, depth, id, current);
	}
	if (currentFeatures & 1 && typeof AggregateError !== "undefined" && (currentClass === AggregateError || current instanceof AggregateError)) return parseAggregateError(ctx, depth, id, current);
	if (currentFeatures & 64 && typeof Temporal !== "undefined") switch (currentClass) {
		case Temporal.Instant: return createTemporalNode(id, 0, current);
		case Temporal.Duration: return createTemporalNode(id, 1, current);
		case Temporal.PlainDate: return createTemporalNode(id, 2, current);
		case Temporal.PlainDateTime: return createTemporalNode(id, 3, current);
		case Temporal.PlainMonthDay: return createTemporalNode(id, 4, current);
		case Temporal.PlainTime: return createTemporalNode(id, 5, current);
		case Temporal.PlainYearMonth: return createTemporalNode(id, 6, current);
		case Temporal.ZonedDateTime: return createTemporalNode(id, 7, current);
	}
	if (current instanceof Error) return parseError(ctx, depth, id, current);
	if (SYM_ITERATOR in current || SYM_ASYNC_ITERATOR in current) return parsePlainObject(ctx, depth, id, current, !!currentClass);
	throw new SerovalUnsupportedTypeError(current);
}
function parseObject(ctx, depth, id, current) {
	if (Array.isArray(current)) return parseArray(ctx, depth, id, current);
	if (isStream(current)) return parseStream(ctx, depth, id, current);
	if (isSequence(current)) return parseSequence(ctx, depth, id, current);
	let currentClass = current.constructor;
	if (currentClass !== void 0 && typeof currentClass !== "function") {
		const proto = Object.getPrototypeOf(current);
		currentClass = proto === null ? void 0 : proto.constructor;
	}
	if (currentClass === OpaqueReference) return parseSOS(ctx, depth, current.replacement);
	const parsed = parsePlugin(ctx, depth, id, current);
	if (parsed) return parsed;
	return parseObjectPhase2(ctx, depth, id, current, currentClass);
}
function parseFunction(ctx, depth, current) {
	const ref = getReferenceNode(ctx.base, current);
	if (ref.type !== 0) return ref.value;
	const plugin = parsePlugin(ctx, depth, ref.value, current);
	if (plugin) return plugin;
	throw new SerovalUnsupportedTypeError(current);
}
function parseSOS(ctx, depth, current) {
	if (depth >= ctx.base.depthLimit) throw new SerovalDepthLimitError(ctx.base.depthLimit);
	switch (typeof current) {
		case "boolean": return current ? TRUE_NODE : FALSE_NODE;
		case "undefined": return UNDEFINED_NODE;
		case "string": return createStringNode(current);
		case "number": return createNumberNode(current);
		case "bigint": return createBigIntNode(current);
		case "object":
			if (current) {
				const ref = getReferenceNode(ctx.base, current);
				return ref.type === 0 ? parseObject(ctx, depth + 1, ref.value, current) : ref.value;
			}
			return NULL_NODE;
		case "symbol": return parseWellKnownSymbol(ctx.base, current);
		case "function": return parseFunction(ctx, depth, current);
		default: throw new SerovalUnsupportedTypeError(current);
	}
}
function parseTop(ctx, current) {
	try {
		return parseSOS(ctx, 0, current);
	} catch (error) {
		throw error instanceof SerovalParserError ? error : new SerovalParserError(error);
	}
}
function onParse(ctx, node) {
	if (ctx.state.initial) ctx.state.buffer.push(node);
	else onParseInternal(ctx, node, false);
}
function onError(ctx, error) {
	if (ctx.state.onError) ctx.state.onError(error);
	else throw error instanceof SerovalParserError ? error : new SerovalParserError(error);
}
function onDone(ctx) {
	if (ctx.state.onDone) ctx.state.onDone();
	for (let i = 0, len = ctx.state.cleanups.length; i < len; i++) ctx.state.cleanups[i]();
}
function onParseInternal(ctx, node, initial) {
	try {
		ctx.state.onParse(node, initial);
	} catch (error) {
		onError(ctx, error);
	}
}
function pushPendingState(ctx) {
	ctx.state.pending++;
}
function popPendingState(ctx) {
	if (--ctx.state.pending <= 0) onDone(ctx);
}
function parseWithError(ctx, depth, current) {
	try {
		return parseSOS(ctx, depth, current);
	} catch (err) {
		onError(ctx, err);
		return;
	}
}
function startStreamParse(ctx, current) {
	const parsed = parseWithError(ctx, 0, current);
	if (parsed) {
		onParseInternal(ctx, parsed, true);
		ctx.state.initial = false;
		flushStreamParse(ctx, ctx.state);
		if (ctx.state.pending <= 0) destroyStreamParse(ctx);
	}
}
function flushStreamParse(ctx, state) {
	for (let i = 0, len = state.buffer.length; i < len; i++) onParseInternal(ctx, state.buffer[i], false);
}
function destroyStreamParse(ctx) {
	if (ctx.state.alive) {
		onDone(ctx);
		ctx.state.alive = false;
	}
}
//#endregion
//#region src/core/cross/index.ts
function crossSerialize(source, options = {}) {
	const plugins = resolvePlugins(options.plugins);
	const ctx = createSyncParserContext(2, {
		compactArrayBufferViews: options.compactArrayBufferViews,
		plugins,
		disabledFeatures: options.disabledFeatures,
		refs: options.refs
	});
	const tree = parseTop(ctx, source);
	return serializeTopCross(createCrossSerializerContext({
		plugins,
		features: ctx.base.features,
		scopeId: options.scopeId,
		markedRefs: ctx.base.marked
	}), tree);
}
async function crossSerializeAsync(source, options = {}) {
	const plugins = resolvePlugins(options.plugins);
	const ctx = createAsyncParserContext(2, {
		compactArrayBufferViews: options.compactArrayBufferViews,
		plugins,
		disabledFeatures: options.disabledFeatures,
		refs: options.refs
	});
	const tree = await parseTopAsync(ctx, source);
	return serializeTopCross(createCrossSerializerContext({
		plugins,
		features: ctx.base.features,
		scopeId: options.scopeId,
		markedRefs: ctx.base.marked
	}), tree);
}
function toCrossJSON(source, options = {}) {
	const plugins = resolvePlugins(options.plugins);
	return parseTop(createSyncParserContext(2, {
		compactArrayBufferViews: options.compactArrayBufferViews,
		plugins,
		disabledFeatures: options.disabledFeatures,
		refs: options.refs
	}), source);
}
async function toCrossJSONAsync(source, options = {}) {
	const plugins = resolvePlugins(options.plugins);
	return await parseTopAsync(createAsyncParserContext(2, {
		compactArrayBufferViews: options.compactArrayBufferViews,
		plugins,
		disabledFeatures: options.disabledFeatures,
		refs: options.refs
	}), source);
}
function crossSerializeStream(source, options) {
	const plugins = resolvePlugins(options.plugins);
	const ctx = createStreamParserContext({
		compactArrayBufferViews: options.compactArrayBufferViews,
		plugins,
		refs: options.refs,
		disabledFeatures: options.disabledFeatures,
		onParse(node, initial) {
			const serial = createCrossSerializerContext({
				plugins,
				features: ctx.base.features,
				scopeId: options.scopeId,
				markedRefs: ctx.base.marked
			});
			let serialized;
			try {
				serialized = serializeTopCross(serial, node);
			} catch (err) {
				if (options.onError) options.onError(err);
				return;
			}
			options.onSerialize(serialized, initial);
		},
		onError: options.onError,
		onDone: options.onDone
	});
	startStreamParse(ctx, source);
	return destroyStreamParse.bind(null, ctx);
}
function toCrossJSONStream(source, options) {
	const plugins = resolvePlugins(options.plugins);
	const ctx = createStreamParserContext({
		compactArrayBufferViews: options.compactArrayBufferViews,
		plugins,
		refs: options.refs,
		disabledFeatures: options.disabledFeatures,
		depthLimit: options.depthLimit,
		onParse: options.onParse,
		onError: options.onError,
		onDone: options.onDone
	});
	startStreamParse(ctx, source);
	return destroyStreamParse.bind(null, ctx);
}
function fromCrossJSON(source, options) {
	const plugins = resolvePlugins(options.plugins);
	return deserializeTop(createCrossDeserializerContext({
		maxBase64Length: options.maxBase64Length,
		plugins,
		refs: options.refs,
		features: options.features,
		disabledFeatures: options.disabledFeatures,
		depthLimit: options.depthLimit
	}), source);
}
//#endregion
//#region src/core/Serializer.ts
var Serializer = class {
	constructor(options) {
		this.options = options;
		this.alive = true;
		this.flushed = false;
		this.done = false;
		this.pending = 0;
		this.cleanups = [];
		this.refs = /* @__PURE__ */ new Map();
		this.keys = /* @__PURE__ */ new Set();
		this.ids = 0;
		this.plugins = resolvePlugins(options.plugins);
	}
	write(key, value) {
		if (this.alive && !this.flushed) {
			this.pending++;
			this.keys.add(key);
			this.cleanups.push(crossSerializeStream(value, {
				plugins: this.plugins,
				scopeId: this.options.scopeId,
				refs: this.refs,
				disabledFeatures: this.options.disabledFeatures,
				compactArrayBufferViews: this.options.compactArrayBufferViews,
				onError: this.options.onError,
				onSerialize: (data, initial) => {
					if (this.alive) this.options.onData(initial ? this.options.globalIdentifier + "[\"" + serializeString(key) + "\"]=" + data : data);
				},
				onDone: () => {
					if (this.alive) {
						this.pending--;
						if (this.pending <= 0 && this.flushed && !this.done && this.options.onDone) {
							this.options.onDone();
							this.done = true;
						}
					}
				}
			}));
		}
	}
	getNextID() {
		while (this.keys.has("" + this.ids)) this.ids++;
		return "" + this.ids;
	}
	push(value) {
		const newID = this.getNextID();
		this.write(newID, value);
		return newID;
	}
	flush() {
		if (this.alive) {
			this.flushed = true;
			if (this.pending <= 0 && !this.done && this.options.onDone) {
				this.options.onDone();
				this.done = true;
			}
		}
	}
	close() {
		if (this.alive) {
			for (let i = 0, len = this.cleanups.length; i < len; i++) this.cleanups[i]();
			if (!this.done && this.options.onDone) {
				this.options.onDone();
				this.done = true;
			}
			this.alive = false;
		}
	}
};
//#endregion
//#region src/core/tree/index.ts
function serialize(source, options = {}) {
	const plugins = resolvePlugins(options.plugins);
	const ctx = createSyncParserContext(1, {
		compactArrayBufferViews: options.compactArrayBufferViews,
		plugins,
		disabledFeatures: options.disabledFeatures
	});
	const tree = parseTop(ctx, source);
	return serializeTopVanilla(createVanillaSerializerContext({
		plugins,
		features: ctx.base.features,
		markedRefs: ctx.base.marked
	}), tree);
}
async function serializeAsync(source, options = {}) {
	const plugins = resolvePlugins(options.plugins);
	const ctx = createAsyncParserContext(1, {
		compactArrayBufferViews: options.compactArrayBufferViews,
		plugins,
		disabledFeatures: options.disabledFeatures
	});
	const tree = await parseTopAsync(ctx, source);
	return serializeTopVanilla(createVanillaSerializerContext({
		plugins,
		features: ctx.base.features,
		markedRefs: ctx.base.marked
	}), tree);
}
function deserialize(source) {
	return (0, eval)(source);
}
function toJSON(source, options = {}) {
	const plugins = resolvePlugins(options.plugins);
	const ctx = createSyncParserContext(1, {
		compactArrayBufferViews: options.compactArrayBufferViews,
		plugins,
		disabledFeatures: options.disabledFeatures
	});
	return {
		t: parseTop(ctx, source),
		f: ctx.base.features,
		m: Array.from(ctx.base.marked)
	};
}
async function toJSONAsync(source, options = {}) {
	const plugins = resolvePlugins(options.plugins);
	const ctx = createAsyncParserContext(1, {
		compactArrayBufferViews: options.compactArrayBufferViews,
		plugins,
		disabledFeatures: options.disabledFeatures
	});
	return {
		t: await parseTopAsync(ctx, source),
		f: ctx.base.features,
		m: Array.from(ctx.base.marked)
	};
}
function compileJSON(source, options = {}) {
	return serializeTopVanilla(createVanillaSerializerContext({
		plugins: resolvePlugins(options.plugins),
		features: source.f,
		markedRefs: source.m
	}), source.t);
}
function fromJSON(source, options = {}) {
	var _source$f;
	const plugins = resolvePlugins(options.plugins);
	const disabledFeatures = options.disabledFeatures || 0;
	const sourceFeatures = (_source$f = source.f) !== null && _source$f !== void 0 ? _source$f : 127;
	return deserializeTop(createVanillaDeserializerContext({
		maxBase64Length: options.maxBase64Length,
		plugins,
		markedRefs: source.m,
		features: sourceFeatures & ~disabledFeatures,
		disabledFeatures
	}), source.t);
}
//#endregion
export { Feature, OpaqueReference, Serializer, SerovalConflictedNodeIdError, SerovalDepthLimitError, SerovalDeserializationError, SerovalError, SerovalMalformedNodeError, SerovalMissingInstanceError, SerovalMissingPluginError, SerovalMissingReferenceError, SerovalMissingReferenceForIdError, SerovalMode, SerovalParserError, SerovalSerializationError, SerovalUnknownTypedArrayError, SerovalUnsupportedNodeError, SerovalUnsupportedTypeError, compileJSON, createPlugin, createReference, createStream, crossSerialize, crossSerializeAsync, crossSerializeStream, deserialize, fromCrossJSON, fromJSON, getCrossReferenceHeader, isStream, resolvePlugins, serialize, serializeAsync, toCrossJSON, toCrossJSONAsync, toCrossJSONStream, toJSON, toJSONAsync };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzP3Y9YTgwMzAyNjkiXSwic291cmNlc0NvbnRlbnQiOlsiLy8jcmVnaW9uIHNyYy9jb3JlL2NvbXBhdC50c1xuLyoqXG4qIFJlZmVyZW5jZXNcbiogLSBodHRwczovL2NvbXBhdC10YWJsZS5naXRodWIuaW8vY29tcGF0LXRhYmxlL2VzNi9cbiogLSBNRE5cbiovXG5sZXQgRmVhdHVyZSA9IC8qIEBfX1BVUkVfXyAqLyBmdW5jdGlvbihGZWF0dXJlKSB7XG5cdEZlYXR1cmVbRmVhdHVyZVtcIkFnZ3JlZ2F0ZUVycm9yXCJdID0gMV0gPSBcIkFnZ3JlZ2F0ZUVycm9yXCI7XG5cdEZlYXR1cmVbRmVhdHVyZVtcIkFycm93RnVuY3Rpb25cIl0gPSAyXSA9IFwiQXJyb3dGdW5jdGlvblwiO1xuXHRGZWF0dXJlW0ZlYXR1cmVbXCJFcnJvclByb3RvdHlwZVN0YWNrXCJdID0gNF0gPSBcIkVycm9yUHJvdG90eXBlU3RhY2tcIjtcblx0RmVhdHVyZVtGZWF0dXJlW1wiT2JqZWN0QXNzaWduXCJdID0gOF0gPSBcIk9iamVjdEFzc2lnblwiO1xuXHRGZWF0dXJlW0ZlYXR1cmVbXCJCaWdJbnRUeXBlZEFycmF5XCJdID0gMTZdID0gXCJCaWdJbnRUeXBlZEFycmF5XCI7XG5cdEZlYXR1cmVbRmVhdHVyZVtcIlJlZ0V4cFwiXSA9IDMyXSA9IFwiUmVnRXhwXCI7XG5cdEZlYXR1cmVbRmVhdHVyZVtcIlRlbXBvcmFsXCJdID0gNjRdID0gXCJUZW1wb3JhbFwiO1xuXHRyZXR1cm4gRmVhdHVyZTtcbn0oe30pO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvc3ltYm9scy50c1xuY29uc3QgU1lNX0FTWU5DX0lURVJBVE9SID0gU3ltYm9sLmFzeW5jSXRlcmF0b3I7XG5jb25zdCBTWU1fSEFTX0lOU1RBTkNFID0gU3ltYm9sLmhhc0luc3RhbmNlO1xuY29uc3QgU1lNX0lTX0NPTkNBVF9TUFJFQURBQkxFID0gU3ltYm9sLmlzQ29uY2F0U3ByZWFkYWJsZTtcbmNvbnN0IFNZTV9JVEVSQVRPUiA9IFN5bWJvbC5pdGVyYXRvcjtcbmNvbnN0IFNZTV9NQVRDSCA9IFN5bWJvbC5tYXRjaDtcbmNvbnN0IFNZTV9NQVRDSF9BTEwgPSBTeW1ib2wubWF0Y2hBbGw7XG5jb25zdCBTWU1fUkVQTEFDRSA9IFN5bWJvbC5yZXBsYWNlO1xuY29uc3QgU1lNX1NFQVJDSCA9IFN5bWJvbC5zZWFyY2g7XG5jb25zdCBTWU1fU1BFQ0lFUyA9IFN5bWJvbC5zcGVjaWVzO1xuY29uc3QgU1lNX1NQTElUID0gU3ltYm9sLnNwbGl0O1xuY29uc3QgU1lNX1RPX1BSSU1JVElWRSA9IFN5bWJvbC50b1ByaW1pdGl2ZTtcbmNvbnN0IFNZTV9UT19TVFJJTkdfVEFHID0gU3ltYm9sLnRvU3RyaW5nVGFnO1xuY29uc3QgU1lNX1VOU0NPUEFCTEVTID0gU3ltYm9sLnVuc2NvcGFibGVzO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29uc3RhbnRzLnRzXG5jb25zdCBTWU1CT0xfU1RSSU5HID0ge1xuXHRbMF06IFwiU3ltYm9sLmFzeW5jSXRlcmF0b3JcIixcblx0WzFdOiBcIlN5bWJvbC5oYXNJbnN0YW5jZVwiLFxuXHRbMl06IFwiU3ltYm9sLmlzQ29uY2F0U3ByZWFkYWJsZVwiLFxuXHRbM106IFwiU3ltYm9sLml0ZXJhdG9yXCIsXG5cdFs0XTogXCJTeW1ib2wubWF0Y2hcIixcblx0WzVdOiBcIlN5bWJvbC5tYXRjaEFsbFwiLFxuXHRbNl06IFwiU3ltYm9sLnJlcGxhY2VcIixcblx0WzddOiBcIlN5bWJvbC5zZWFyY2hcIixcblx0WzhdOiBcIlN5bWJvbC5zcGVjaWVzXCIsXG5cdFs5XTogXCJTeW1ib2wuc3BsaXRcIixcblx0WzEwXTogXCJTeW1ib2wudG9QcmltaXRpdmVcIixcblx0WzExXTogXCJTeW1ib2wudG9TdHJpbmdUYWdcIixcblx0WzEyXTogXCJTeW1ib2wudW5zY29wYWJsZXNcIlxufTtcbmNvbnN0IElOVl9TWU1CT0xfUkVGID0ge1xuXHRbU1lNX0FTWU5DX0lURVJBVE9SXTogMCxcblx0W1NZTV9IQVNfSU5TVEFOQ0VdOiAxLFxuXHRbU1lNX0lTX0NPTkNBVF9TUFJFQURBQkxFXTogMixcblx0W1NZTV9JVEVSQVRPUl06IDMsXG5cdFtTWU1fTUFUQ0hdOiA0LFxuXHRbU1lNX01BVENIX0FMTF06IDUsXG5cdFtTWU1fUkVQTEFDRV06IDYsXG5cdFtTWU1fU0VBUkNIXTogNyxcblx0W1NZTV9TUEVDSUVTXTogOCxcblx0W1NZTV9TUExJVF06IDksXG5cdFtTWU1fVE9fUFJJTUlUSVZFXTogMTAsXG5cdFtTWU1fVE9fU1RSSU5HX1RBR106IDExLFxuXHRbU1lNX1VOU0NPUEFCTEVTXTogMTJcbn07XG5jb25zdCBTWU1CT0xfUkVGID0ge1xuXHRbMF06IFNZTV9BU1lOQ19JVEVSQVRPUixcblx0WzFdOiBTWU1fSEFTX0lOU1RBTkNFLFxuXHRbMl06IFNZTV9JU19DT05DQVRfU1BSRUFEQUJMRSxcblx0WzNdOiBTWU1fSVRFUkFUT1IsXG5cdFs0XTogU1lNX01BVENILFxuXHRbNV06IFNZTV9NQVRDSF9BTEwsXG5cdFs2XTogU1lNX1JFUExBQ0UsXG5cdFs3XTogU1lNX1NFQVJDSCxcblx0WzhdOiBTWU1fU1BFQ0lFUyxcblx0WzldOiBTWU1fU1BMSVQsXG5cdFsxMF06IFNZTV9UT19QUklNSVRJVkUsXG5cdFsxMV06IFNZTV9UT19TVFJJTkdfVEFHLFxuXHRbMTJdOiBTWU1fVU5TQ09QQUJMRVNcbn07XG5jb25zdCBDT05TVEFOVF9TVFJJTkcgPSB7XG5cdFsyXTogXCIhMFwiLFxuXHRbM106IFwiITFcIixcblx0WzFdOiBcInZvaWQgMFwiLFxuXHRbMF06IFwibnVsbFwiLFxuXHRbNF06IFwiLTBcIixcblx0WzVdOiBcIjEvMFwiLFxuXHRbNl06IFwiLTEvMFwiLFxuXHRbN106IFwiMC8wXCJcbn07XG5jb25zdCBDT05TVEFOVF9WQUwgPSB7XG5cdFsyXTogdHJ1ZSxcblx0WzNdOiBmYWxzZSxcblx0WzFdOiB2b2lkIDAsXG5cdFswXTogbnVsbCxcblx0WzRdOiAtMCxcblx0WzVdOiBOdW1iZXIuUE9TSVRJVkVfSU5GSU5JVFksXG5cdFs2XTogTnVtYmVyLk5FR0FUSVZFX0lORklOSVRZLFxuXHRbN106IE5hTlxufTtcbmNvbnN0IEVSUk9SX0NPTlNUUlVDVE9SX1NUUklORyA9IHtcblx0WzBdOiBcIkVycm9yXCIsXG5cdFsxXTogXCJFdmFsRXJyb3JcIixcblx0WzJdOiBcIlJhbmdlRXJyb3JcIixcblx0WzNdOiBcIlJlZmVyZW5jZUVycm9yXCIsXG5cdFs0XTogXCJTeW50YXhFcnJvclwiLFxuXHRbNV06IFwiVHlwZUVycm9yXCIsXG5cdFs2XTogXCJVUklFcnJvclwiXG59O1xuY29uc3QgRVJST1JfQ09OU1RSVUNUT1IgPSB7XG5cdFswXTogRXJyb3IsXG5cdFsxXTogRXZhbEVycm9yLFxuXHRbMl06IFJhbmdlRXJyb3IsXG5cdFszXTogUmVmZXJlbmNlRXJyb3IsXG5cdFs0XTogU3ludGF4RXJyb3IsXG5cdFs1XTogVHlwZUVycm9yLFxuXHRbNl06IFVSSUVycm9yXG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvbm9kZS50c1xuZnVuY3Rpb24gY3JlYXRlU2Vyb3ZhbE5vZGUodCwgaSwgcywgYywgbSwgcCwgZSwgYSwgZiwgYiwgbywgbCkge1xuXHRyZXR1cm4ge1xuXHRcdHQsXG5cdFx0aSxcblx0XHRzLFxuXHRcdGMsXG5cdFx0bSxcblx0XHRwLFxuXHRcdGUsXG5cdFx0YSxcblx0XHRmLFxuXHRcdGIsXG5cdFx0byxcblx0XHRsXG5cdH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9saXRlcmFscy50c1xuZnVuY3Rpb24gY3JlYXRlQ29uc3RhbnROb2RlKHZhbHVlKSB7XG5cdHJldHVybiBjcmVhdGVTZXJvdmFsTm9kZSgyLCB2b2lkIDAsIHZhbHVlLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwKTtcbn1cbmNvbnN0IFRSVUVfTk9ERSA9IC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVDb25zdGFudE5vZGUoMik7XG5jb25zdCBGQUxTRV9OT0RFID0gLyogQF9fUFVSRV9fICovIGNyZWF0ZUNvbnN0YW50Tm9kZSgzKTtcbmNvbnN0IFVOREVGSU5FRF9OT0RFID0gLyogQF9fUFVSRV9fICovIGNyZWF0ZUNvbnN0YW50Tm9kZSgxKTtcbmNvbnN0IE5VTExfTk9ERSA9IC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVDb25zdGFudE5vZGUoMCk7XG5jb25zdCBORUdfWkVST19OT0RFID0gLyogQF9fUFVSRV9fICovIGNyZWF0ZUNvbnN0YW50Tm9kZSg0KTtcbmNvbnN0IElORklOSVRZX05PREUgPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlQ29uc3RhbnROb2RlKDUpO1xuY29uc3QgTkVHX0lORklOSVRZX05PREUgPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlQ29uc3RhbnROb2RlKDYpO1xuY29uc3QgTkFOX05PREUgPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlQ29uc3RhbnROb2RlKDcpO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvc3RyaW5nLnRzXG5jb25zdCBNSU5fSlNPTl9TVFJJTkdJRllfTEVOR1RIID0gNjQ7XG5jb25zdCBKU09OX0VTQ0FQRV9ESUZGRVJFTkNFUyA9IC9bXFx4MDAtXFx4MDdcXHgwYlxceDBlLVxceDFmPFxcdTIwMjhcXHUyMDI5XFx1ZDgwMC1cXHVkZmZmXS87XG5mdW5jdGlvbiBzZXJpYWxpemVDaGFyKHN0cikge1xuXHRzd2l0Y2ggKHN0cikge1xuXHRcdGNhc2UgXCJcXFwiXCI6IHJldHVybiBcIlxcXFxcXFwiXCI7XG5cdFx0Y2FzZSBcIlxcXFxcIjogcmV0dXJuIFwiXFxcXFxcXFxcIjtcblx0XHRjYXNlIFwiXFxuXCI6IHJldHVybiBcIlxcXFxuXCI7XG5cdFx0Y2FzZSBcIlxcclwiOiByZXR1cm4gXCJcXFxcclwiO1xuXHRcdGNhc2UgXCJcXGJcIjogcmV0dXJuIFwiXFxcXGJcIjtcblx0XHRjYXNlIFwiXHRcIjogcmV0dXJuIFwiXFxcXHRcIjtcblx0XHRjYXNlIFwiXFxmXCI6IHJldHVybiBcIlxcXFxmXCI7XG5cdFx0Y2FzZSBcIjxcIjogcmV0dXJuIFwiXFxcXHgzQ1wiO1xuXHRcdGNhc2UgXCJcXHUyMDI4XCI6IHJldHVybiBcIlxcXFx1MjAyOFwiO1xuXHRcdGNhc2UgXCJcXHUyMDI5XCI6IHJldHVybiBcIlxcXFx1MjAyOVwiO1xuXHRcdGRlZmF1bHQ6IHJldHVybjtcblx0fVxufVxuZnVuY3Rpb24gc2VyaWFsaXplU3RyaW5nKHN0cikge1xuXHRpZiAoc3RyLmxlbmd0aCA+PSBNSU5fSlNPTl9TVFJJTkdJRllfTEVOR1RIICYmICFKU09OX0VTQ0FQRV9ESUZGRVJFTkNFUy50ZXN0KHN0cikpIHJldHVybiBKU09OLnN0cmluZ2lmeShzdHIpLnNsaWNlKDEsIC0xKTtcblx0bGV0IHJlc3VsdCA9IFwiXCI7XG5cdGxldCBsYXN0UG9zID0gMDtcblx0bGV0IHJlcGxhY2VtZW50O1xuXHRmb3IgKGxldCBpID0gMCwgbGVuID0gc3RyLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG5cdFx0cmVwbGFjZW1lbnQgPSBzZXJpYWxpemVDaGFyKHN0cltpXSk7XG5cdFx0aWYgKHJlcGxhY2VtZW50KSB7XG5cdFx0XHRyZXN1bHQgKz0gc3RyLnNsaWNlKGxhc3RQb3MsIGkpICsgcmVwbGFjZW1lbnQ7XG5cdFx0XHRsYXN0UG9zID0gaSArIDE7XG5cdFx0fVxuXHR9XG5cdGlmIChsYXN0UG9zID09PSAwKSByZXN1bHQgPSBzdHI7XG5cdGVsc2UgcmVzdWx0ICs9IHN0ci5zbGljZShsYXN0UG9zKTtcblx0cmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGRlc2VyaWFsaXplUmVwbGFjZXIoc3RyKSB7XG5cdHN3aXRjaCAoc3RyKSB7XG5cdFx0Y2FzZSBcIlxcXFxcXFxcXCI6IHJldHVybiBcIlxcXFxcIjtcblx0XHRjYXNlIFwiXFxcXFxcXCJcIjogcmV0dXJuIFwiXFxcIlwiO1xuXHRcdGNhc2UgXCJcXFxcblwiOiByZXR1cm4gXCJcXG5cIjtcblx0XHRjYXNlIFwiXFxcXHJcIjogcmV0dXJuIFwiXFxyXCI7XG5cdFx0Y2FzZSBcIlxcXFxiXCI6IHJldHVybiBcIlxcYlwiO1xuXHRcdGNhc2UgXCJcXFxcdFwiOiByZXR1cm4gXCJcdFwiO1xuXHRcdGNhc2UgXCJcXFxcZlwiOiByZXR1cm4gXCJcXGZcIjtcblx0XHRjYXNlIFwiXFxcXHgzQ1wiOiByZXR1cm4gXCI8XCI7XG5cdFx0Y2FzZSBcIlxcXFx1MjAyOFwiOiByZXR1cm4gXCJcXHUyMDI4XCI7XG5cdFx0Y2FzZSBcIlxcXFx1MjAyOVwiOiByZXR1cm4gXCJcXHUyMDI5XCI7XG5cdFx0ZGVmYXVsdDogcmV0dXJuIHN0cjtcblx0fVxufVxuZnVuY3Rpb24gZGVzZXJpYWxpemVTdHJpbmcoc3RyKSB7XG5cdGlmICh0eXBlb2Ygc3RyID09PSBcInN0cmluZ1wiICYmICFzdHIuaW5jbHVkZXMoXCJcXFxcXCIpKSByZXR1cm4gc3RyO1xuXHRyZXR1cm4gc3RyLnJlcGxhY2UoLyhcXFxcXFxcXHxcXFxcXCJ8XFxcXG58XFxcXHJ8XFxcXGJ8XFxcXHR8XFxcXGZ8XFxcXHUyMDI4fFxcXFx1MjAyOXxcXFxceDNDKS9nLCBkZXNlcmlhbGl6ZVJlcGxhY2VyKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2Vycm9ycy50c1xuY29uc3QgeyB0b1N0cmluZzogb2JqZWN0VG9TdHJpbmcgfSA9IE9iamVjdC5wcm90b3R5cGU7XG5mdW5jdGlvbiBnZXRFcnJvck1lc3NhZ2VEZXYodHlwZSwgY2F1c2UpIHtcblx0aWYgKGNhdXNlIGluc3RhbmNlb2YgRXJyb3IpIHJldHVybiBgU2Vyb3ZhbCBjYXVnaHQgYW4gZXJyb3IgZHVyaW5nIHRoZSAke3R5cGV9IHByb2Nlc3MuXG5cbiR7Y2F1c2UubmFtZX1cbiR7Y2F1c2UubWVzc2FnZX1cblxuLSBGb3IgbW9yZSBpbmZvcm1hdGlvbiwgcGxlYXNlIGNoZWNrIHRoZSBcImNhdXNlXCIgcHJvcGVydHkgb2YgdGhpcyBlcnJvci5cbi0gSWYgeW91IGJlbGlldmUgdGhpcyBpcyBhbiBlcnJvciBpbiBTZXJvdmFsLCBwbGVhc2Ugc3VibWl0IGFuIGlzc3VlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9seHNtbnN5Yy9zZXJvdmFsL2lzc3Vlcy9uZXdgO1xuXHRyZXR1cm4gYFNlcm92YWwgY2F1Z2h0IGFuIGVycm9yIGR1cmluZyB0aGUgJHt0eXBlfSBwcm9jZXNzLlxuXG5cIiR7b2JqZWN0VG9TdHJpbmcuY2FsbChjYXVzZSl9XCJcblxuRm9yIG1vcmUgaW5mb3JtYXRpb24sIHBsZWFzZSBjaGVjayB0aGUgXCJjYXVzZVwiIHByb3BlcnR5IG9mIHRoaXMgZXJyb3IuYDtcbn1cbmNvbnN0IGdldEVycm9yTWVzc2FnZSA9ICh0eXBlLCBjYXVzZSkgPT4gZ2V0RXJyb3JNZXNzYWdlRGV2KHR5cGUsIGNhdXNlKTtcbnZhciBTZXJvdmFsRXJyb3IgPSBjbGFzcyBleHRlbmRzIEVycm9yIHtcblx0Y29uc3RydWN0b3IodHlwZSwgY2F1c2UpIHtcblx0XHRzdXBlcihnZXRFcnJvck1lc3NhZ2UodHlwZSwgY2F1c2UpKTtcblx0XHR0aGlzLmNhdXNlID0gY2F1c2U7XG5cdH1cbn07XG52YXIgU2Vyb3ZhbFBhcnNlckVycm9yID0gY2xhc3MgZXh0ZW5kcyBTZXJvdmFsRXJyb3Ige1xuXHRjb25zdHJ1Y3RvcihjYXVzZSkge1xuXHRcdHN1cGVyKFwicGFyc2luZ1wiLCBjYXVzZSk7XG5cdH1cbn07XG52YXIgU2Vyb3ZhbFNlcmlhbGl6YXRpb25FcnJvciA9IGNsYXNzIGV4dGVuZHMgU2Vyb3ZhbEVycm9yIHtcblx0Y29uc3RydWN0b3IoY2F1c2UpIHtcblx0XHRzdXBlcihcInNlcmlhbGl6YXRpb25cIiwgY2F1c2UpO1xuXHR9XG59O1xudmFyIFNlcm92YWxEZXNlcmlhbGl6YXRpb25FcnJvciA9IGNsYXNzIGV4dGVuZHMgU2Vyb3ZhbEVycm9yIHtcblx0Y29uc3RydWN0b3IoY2F1c2UpIHtcblx0XHRzdXBlcihcImRlc2VyaWFsaXphdGlvblwiLCBjYXVzZSk7XG5cdH1cbn07XG52YXIgU2Vyb3ZhbFVuc3VwcG9ydGVkVHlwZUVycm9yID0gY2xhc3MgZXh0ZW5kcyBFcnJvciB7XG5cdGNvbnN0cnVjdG9yKHZhbHVlKSB7XG5cdFx0c3VwZXIoYFRoZSB2YWx1ZSAke29iamVjdFRvU3RyaW5nLmNhbGwodmFsdWUpfSBvZiB0eXBlIFwiJHt0eXBlb2YgdmFsdWV9XCIgY2Fubm90IGJlIHBhcnNlZC9zZXJpYWxpemVkLlxuICAgICAgXG5UaGVyZSBhcmUgZmV3IHdvcmthcm91bmRzIGZvciB0aGlzIHByb2JsZW06XG4tIFRyYW5zZm9ybSB0aGUgdmFsdWUgaW4gYSB3YXkgdGhhdCBpdCBjYW4gYmUgc2VyaWFsaXplZC5cbi0gSWYgdGhlIHJlZmVyZW5jZSBpcyBwcmVzZW50IG9uIG11bHRpcGxlIHJ1bnRpbWVzIChpc29tb3JwaGljKSwgeW91IGNhbiB1c2UgdGhlIFJlZmVyZW5jZSBBUEkgdG8gbWFwIHRoZSByZWZlcmVuY2VzLmApO1xuXHRcdHRoaXMudmFsdWUgPSB2YWx1ZTtcblx0fVxufTtcbnZhciBTZXJvdmFsVW5zdXBwb3J0ZWROb2RlRXJyb3IgPSBjbGFzcyBleHRlbmRzIEVycm9yIHtcblx0Y29uc3RydWN0b3Iobm9kZSkge1xuXHRcdHN1cGVyKFwiVW5zdXBwb3J0ZWQgbm9kZSB0eXBlIFxcXCJcIiArIG5vZGUudCArIFwiXFxcIi5cIik7XG5cdH1cbn07XG52YXIgU2Vyb3ZhbE1pc3NpbmdQbHVnaW5FcnJvciA9IGNsYXNzIGV4dGVuZHMgRXJyb3Ige1xuXHRjb25zdHJ1Y3Rvcih0YWcpIHtcblx0XHRzdXBlcihcIk1pc3NpbmcgcGx1Z2luIGZvciB0YWcgXFxcIlwiICsgdGFnICsgXCJcXFwiLlwiKTtcblx0fVxufTtcbnZhciBTZXJvdmFsTWlzc2luZ0luc3RhbmNlRXJyb3IgPSBjbGFzcyBleHRlbmRzIEVycm9yIHtcblx0Y29uc3RydWN0b3IodGFnKSB7XG5cdFx0c3VwZXIoXCJNaXNzaW5nIFxcXCJcIiArIHRhZyArIFwiXFxcIiBpbnN0YW5jZS5cIik7XG5cdH1cbn07XG52YXIgU2Vyb3ZhbE1pc3NpbmdSZWZlcmVuY2VFcnJvciA9IGNsYXNzIGV4dGVuZHMgRXJyb3Ige1xuXHRjb25zdHJ1Y3Rvcih2YWx1ZSkge1xuXHRcdHN1cGVyKFwiTWlzc2luZyByZWZlcmVuY2UgZm9yIHRoZSB2YWx1ZSBcXFwiXCIgKyBvYmplY3RUb1N0cmluZy5jYWxsKHZhbHVlKSArIFwiXFxcIiBvZiB0eXBlIFxcXCJcIiArIHR5cGVvZiB2YWx1ZSArIFwiXFxcIlwiKTtcblx0XHR0aGlzLnZhbHVlID0gdmFsdWU7XG5cdH1cbn07XG52YXIgU2Vyb3ZhbE1pc3NpbmdSZWZlcmVuY2VGb3JJZEVycm9yID0gY2xhc3MgZXh0ZW5kcyBFcnJvciB7XG5cdGNvbnN0cnVjdG9yKGlkKSB7XG5cdFx0c3VwZXIoXCJNaXNzaW5nIHJlZmVyZW5jZSBmb3IgaWQgXFxcIlwiICsgc2VyaWFsaXplU3RyaW5nKGlkKSArIFwiXFxcIlwiKTtcblx0fVxufTtcbnZhciBTZXJvdmFsVW5rbm93blR5cGVkQXJyYXlFcnJvciA9IGNsYXNzIGV4dGVuZHMgRXJyb3Ige1xuXHRjb25zdHJ1Y3RvcihuYW1lKSB7XG5cdFx0c3VwZXIoXCJVbmtub3duIFR5cGVkQXJyYXkgXFxcIlwiICsgbmFtZSArIFwiXFxcIlwiKTtcblx0fVxufTtcbnZhciBTZXJvdmFsTWFsZm9ybWVkTm9kZUVycm9yID0gY2xhc3MgZXh0ZW5kcyBFcnJvciB7XG5cdGNvbnN0cnVjdG9yKG5vZGUpIHtcblx0XHRzdXBlcihcIk1hbGZvcm1lZCBub2RlIHR5cGUgXFxcIlwiICsgbm9kZS50ICsgXCJcXFwiLlwiKTtcblx0fVxufTtcbnZhciBTZXJvdmFsQ29uZmxpY3RlZE5vZGVJZEVycm9yID0gY2xhc3MgZXh0ZW5kcyBFcnJvciB7XG5cdGNvbnN0cnVjdG9yKG5vZGUpIHtcblx0XHRzdXBlcihcIkNvbmZsaWN0ZWQgbm9kZSBpZCBcXFwiXCIgKyBub2RlLmkgKyBcIlxcXCIuXCIpO1xuXHR9XG59O1xudmFyIFNlcm92YWxEZXB0aExpbWl0RXJyb3IgPSBjbGFzcyBleHRlbmRzIEVycm9yIHtcblx0Y29uc3RydWN0b3IobGltaXQpIHtcblx0XHRzdXBlcihcIkRlcHRoIGxpbWl0IG9mIFwiICsgbGltaXQgKyBcIiByZWFjaGVkXCIpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUva2V5cy50c1xuY29uc3QgUkVGRVJFTkNFU19LRVkgPSBcIl9fU0VST1ZBTF9SRUZTX19cIjtcbmNvbnN0IEdMT0JBTF9DT05URVhUX1IgPSBgc2VsZi5cXCRSYDtcbmZ1bmN0aW9uIGdldENyb3NzUmVmZXJlbmNlSGVhZGVyKGlkKSB7XG5cdGlmIChpZCA9PSBudWxsKSByZXR1cm4gYCR7R0xPQkFMX0NPTlRFWFRfUn09JHtHTE9CQUxfQ09OVEVYVF9SfXx8W11gO1xuXHRyZXR1cm4gYCgke0dMT0JBTF9DT05URVhUX1J9PSR7R0xPQkFMX0NPTlRFWFRfUn18fHt9KVtcIiR7c2VyaWFsaXplU3RyaW5nKGlkKX1cIl09W11gO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvcmVmZXJlbmNlLnRzXG5jb25zdCBSRUZFUkVOQ0UgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuY29uc3QgSU5WX1JFRkVSRU5DRSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5mdW5jdGlvbiBjcmVhdGVSZWZlcmVuY2UoaWQsIHZhbHVlKSB7XG5cdFJFRkVSRU5DRS5zZXQodmFsdWUsIGlkKTtcblx0SU5WX1JFRkVSRU5DRS5zZXQoaWQsIHZhbHVlKTtcblx0cmV0dXJuIHZhbHVlO1xufVxuZnVuY3Rpb24gaGFzUmVmZXJlbmNlSUQodmFsdWUpIHtcblx0cmV0dXJuIFJFRkVSRU5DRS5oYXModmFsdWUpO1xufVxuZnVuY3Rpb24gaGFzUmVmZXJlbmNlKGlkKSB7XG5cdHJldHVybiBJTlZfUkVGRVJFTkNFLmhhcyhpZCk7XG59XG5mdW5jdGlvbiBnZXRSZWZlcmVuY2VJRCh2YWx1ZSkge1xuXHRpZiAoaGFzUmVmZXJlbmNlSUQodmFsdWUpKSByZXR1cm4gUkVGRVJFTkNFLmdldCh2YWx1ZSk7XG5cdHRocm93IG5ldyBTZXJvdmFsTWlzc2luZ1JlZmVyZW5jZUVycm9yKHZhbHVlKTtcbn1cbmZ1bmN0aW9uIGdldFJlZmVyZW5jZShpZCkge1xuXHRpZiAoaGFzUmVmZXJlbmNlKGlkKSkgcmV0dXJuIElOVl9SRUZFUkVOQ0UuZ2V0KGlkKTtcblx0dGhyb3cgbmV3IFNlcm92YWxNaXNzaW5nUmVmZXJlbmNlRm9ySWRFcnJvcihpZCk7XG59XG5pZiAodHlwZW9mIGdsb2JhbFRoaXMgIT09IFwidW5kZWZpbmVkXCIpIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShnbG9iYWxUaGlzLCBSRUZFUkVOQ0VTX0tFWSwge1xuXHR2YWx1ZTogSU5WX1JFRkVSRU5DRSxcblx0Y29uZmlndXJhYmxlOiB0cnVlLFxuXHR3cml0YWJsZTogZmFsc2UsXG5cdGVudW1lcmFibGU6IGZhbHNlXG59KTtcbmVsc2UgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIpIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh3aW5kb3csIFJFRkVSRU5DRVNfS0VZLCB7XG5cdHZhbHVlOiBJTlZfUkVGRVJFTkNFLFxuXHRjb25maWd1cmFibGU6IHRydWUsXG5cdHdyaXRhYmxlOiBmYWxzZSxcblx0ZW51bWVyYWJsZTogZmFsc2Vcbn0pO1xuZWxzZSBpZiAodHlwZW9mIHNlbGYgIT09IFwidW5kZWZpbmVkXCIpIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShzZWxmLCBSRUZFUkVOQ0VTX0tFWSwge1xuXHR2YWx1ZTogSU5WX1JFRkVSRU5DRSxcblx0Y29uZmlndXJhYmxlOiB0cnVlLFxuXHR3cml0YWJsZTogZmFsc2UsXG5cdGVudW1lcmFibGU6IGZhbHNlXG59KTtcbmVsc2UgaWYgKHR5cGVvZiBnbG9iYWwgIT09IFwidW5kZWZpbmVkXCIpIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShnbG9iYWwsIFJFRkVSRU5DRVNfS0VZLCB7XG5cdHZhbHVlOiBJTlZfUkVGRVJFTkNFLFxuXHRjb25maWd1cmFibGU6IHRydWUsXG5cdHdyaXRhYmxlOiBmYWxzZSxcblx0ZW51bWVyYWJsZTogZmFsc2Vcbn0pO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvdXRpbHMvZXJyb3IudHNcbmZ1bmN0aW9uIGdldEVycm9yQ29uc3RydWN0b3IoZXJyb3IpIHtcblx0aWYgKGVycm9yIGluc3RhbmNlb2YgRXZhbEVycm9yKSByZXR1cm4gMTtcblx0aWYgKGVycm9yIGluc3RhbmNlb2YgUmFuZ2VFcnJvcikgcmV0dXJuIDI7XG5cdGlmIChlcnJvciBpbnN0YW5jZW9mIFJlZmVyZW5jZUVycm9yKSByZXR1cm4gMztcblx0aWYgKGVycm9yIGluc3RhbmNlb2YgU3ludGF4RXJyb3IpIHJldHVybiA0O1xuXHRpZiAoZXJyb3IgaW5zdGFuY2VvZiBUeXBlRXJyb3IpIHJldHVybiA1O1xuXHRpZiAoZXJyb3IgaW5zdGFuY2VvZiBVUklFcnJvcikgcmV0dXJuIDY7XG5cdHJldHVybiAwO1xufVxuZnVuY3Rpb24gZ2V0SW5pdGlhbEVycm9yT3B0aW9ucyhlcnJvcikge1xuXHRjb25zdCBjb25zdHJ1Y3QgPSBFUlJPUl9DT05TVFJVQ1RPUl9TVFJJTkdbZ2V0RXJyb3JDb25zdHJ1Y3RvcihlcnJvcildO1xuXHRpZiAoZXJyb3IubmFtZSAhPT0gY29uc3RydWN0KSByZXR1cm4geyBuYW1lOiBlcnJvci5uYW1lIH07XG5cdGlmIChlcnJvci5jb25zdHJ1Y3Rvci5uYW1lICE9PSBjb25zdHJ1Y3QpIHJldHVybiB7IG5hbWU6IGVycm9yLmNvbnN0cnVjdG9yLm5hbWUgfTtcblx0cmV0dXJuIHt9O1xufVxuZnVuY3Rpb24gZ2V0RXJyb3JPcHRpb25zKGVycm9yLCBmZWF0dXJlcykge1xuXHRsZXQgb3B0aW9ucyA9IGdldEluaXRpYWxFcnJvck9wdGlvbnMoZXJyb3IpO1xuXHRjb25zdCBuYW1lcyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKGVycm9yKTtcblx0Zm9yIChsZXQgaSA9IDAsIGxlbiA9IG5hbWVzLmxlbmd0aCwgbmFtZTsgaSA8IGxlbjsgaSsrKSB7XG5cdFx0bmFtZSA9IG5hbWVzW2ldO1xuXHRcdGlmIChuYW1lICE9PSBcIm5hbWVcIiAmJiBuYW1lICE9PSBcIm1lc3NhZ2VcIikge1xuXHRcdFx0aWYgKG5hbWUgPT09IFwic3RhY2tcIikge1xuXHRcdFx0XHRpZiAoZmVhdHVyZXMgJiA0KSB7XG5cdFx0XHRcdFx0b3B0aW9ucyA9IG9wdGlvbnMgfHwge307XG5cdFx0XHRcdFx0b3B0aW9uc1tuYW1lXSA9IGVycm9yW25hbWVdO1xuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRvcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcblx0XHRcdFx0b3B0aW9uc1tuYW1lXSA9IGVycm9yW25hbWVdO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXHRyZXR1cm4gb3B0aW9ucztcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3V0aWxzL2dldC1vYmplY3QtZmxhZy50c1xuZnVuY3Rpb24gZ2V0T2JqZWN0RmxhZyhvYmopIHtcblx0aWYgKE9iamVjdC5pc0Zyb3plbihvYmopKSByZXR1cm4gMztcblx0aWYgKE9iamVjdC5pc1NlYWxlZChvYmopKSByZXR1cm4gMjtcblx0aWYgKE9iamVjdC5pc0V4dGVuc2libGUob2JqKSkgcmV0dXJuIDA7XG5cdHJldHVybiAxO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvYmFzZS1wcmltaXRpdmVzLnRzXG5mdW5jdGlvbiBjcmVhdGVOdW1iZXJOb2RlKHZhbHVlKSB7XG5cdHN3aXRjaCAodmFsdWUpIHtcblx0XHRjYXNlIE51bWJlci5QT1NJVElWRV9JTkZJTklUWTogcmV0dXJuIElORklOSVRZX05PREU7XG5cdFx0Y2FzZSBOdW1iZXIuTkVHQVRJVkVfSU5GSU5JVFk6IHJldHVybiBORUdfSU5GSU5JVFlfTk9ERTtcblx0fVxuXHRpZiAodmFsdWUgIT09IHZhbHVlKSByZXR1cm4gTkFOX05PREU7XG5cdGlmIChPYmplY3QuaXModmFsdWUsIC0wKSkgcmV0dXJuIE5FR19aRVJPX05PREU7XG5cdHJldHVybiBjcmVhdGVTZXJvdmFsTm9kZSgwLCB2b2lkIDAsIHZhbHVlLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVN0cmluZ05vZGUodmFsdWUpIHtcblx0cmV0dXJuIGNyZWF0ZVNlcm92YWxOb2RlKDEsIHZvaWQgMCwgc2VyaWFsaXplU3RyaW5nKHZhbHVlKSwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCk7XG59XG5mdW5jdGlvbiBjcmVhdGVCaWdJbnROb2RlKGN1cnJlbnQpIHtcblx0cmV0dXJuIGNyZWF0ZVNlcm92YWxOb2RlKDMsIHZvaWQgMCwgXCJcIiArIGN1cnJlbnQsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDApO1xufVxuZnVuY3Rpb24gY3JlYXRlSW5kZXhlZFZhbHVlTm9kZShpZCkge1xuXHRyZXR1cm4gY3JlYXRlU2Vyb3ZhbE5vZGUoNCwgaWQsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCk7XG59XG5mdW5jdGlvbiBjcmVhdGVEYXRlTm9kZShpZCwgY3VycmVudCkge1xuXHRjb25zdCB0aW1lc3RhbXAgPSBjdXJyZW50LnZhbHVlT2YoKTtcblx0cmV0dXJuIGNyZWF0ZVNlcm92YWxOb2RlKDUsIGlkLCB0aW1lc3RhbXAgIT09IHRpbWVzdGFtcCA/IFwiXCIgOiBjdXJyZW50LnRvSVNPU3RyaW5nKCksIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDApO1xufVxuZnVuY3Rpb24gY3JlYXRlVGVtcG9yYWxOb2RlKGlkLCB0eXBlLCBjdXJyZW50KSB7XG5cdHJldHVybiBjcmVhdGVTZXJvdmFsTm9kZSgzNiwgaWQsIGN1cnJlbnQudG9TdHJpbmcoKSwgdHlwZSwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDApO1xufVxuZnVuY3Rpb24gY3JlYXRlUmVnRXhwTm9kZShpZCwgY3VycmVudCkge1xuXHRyZXR1cm4gY3JlYXRlU2Vyb3ZhbE5vZGUoNiwgaWQsIHZvaWQgMCwgc2VyaWFsaXplU3RyaW5nKGN1cnJlbnQuc291cmNlKSwgY3VycmVudC5mbGFncywgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVdLU3ltYm9sTm9kZShpZCwgY3VycmVudCkge1xuXHRyZXR1cm4gY3JlYXRlU2Vyb3ZhbE5vZGUoMTcsIGlkLCBJTlZfU1lNQk9MX1JFRltjdXJyZW50XSwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCk7XG59XG5mdW5jdGlvbiBjcmVhdGVSZWZlcmVuY2VOb2RlKGlkLCByZWYpIHtcblx0cmV0dXJuIGNyZWF0ZVNlcm92YWxOb2RlKDE4LCBpZCwgc2VyaWFsaXplU3RyaW5nKGdldFJlZmVyZW5jZUlEKHJlZikpLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVBsdWdpbk5vZGUoaWQsIHRhZywgdmFsdWUpIHtcblx0cmV0dXJuIGNyZWF0ZVNlcm92YWxOb2RlKDI1LCBpZCwgdmFsdWUsIHNlcmlhbGl6ZVN0cmluZyh0YWcpLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCk7XG59XG5mdW5jdGlvbiBjcmVhdGVBcnJheU5vZGUoaWQsIGN1cnJlbnQsIHBhcnNlZEl0ZW1zKSB7XG5cdHJldHVybiBjcmVhdGVTZXJvdmFsTm9kZSg5LCBpZCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHBhcnNlZEl0ZW1zLCB2b2lkIDAsIHZvaWQgMCwgZ2V0T2JqZWN0RmxhZyhjdXJyZW50KSwgdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUJveGVkTm9kZShpZCwgYm94ZWQpIHtcblx0cmV0dXJuIGNyZWF0ZVNlcm92YWxOb2RlKDIxLCBpZCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgYm94ZWQsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDApO1xufVxuY29uc3QgTUFYX1RZUEVEX0FSUkFZX0xFTkdUSCA9IDFlNjtcbmZ1bmN0aW9uIGNyZWF0ZVR5cGVkQXJyYXlOb2RlKGlkLCBjdXJyZW50LCBidWZmZXIpIHtcblx0aWYgKGN1cnJlbnQubGVuZ3RoID4gTUFYX1RZUEVEX0FSUkFZX0xFTkdUSCkgdGhyb3cgbmV3IFNlcm92YWxVbnN1cHBvcnRlZFR5cGVFcnJvcihjdXJyZW50KTtcblx0cmV0dXJuIGNyZWF0ZVNlcm92YWxOb2RlKDE1LCBpZCwgdm9pZCAwLCBjdXJyZW50LmNvbnN0cnVjdG9yLm5hbWUsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgYnVmZmVyLCBjdXJyZW50LmJ5dGVPZmZzZXQsIHZvaWQgMCwgY3VycmVudC5sZW5ndGgpO1xufVxuZnVuY3Rpb24gY3JlYXRlQmlnSW50VHlwZWRBcnJheU5vZGUoaWQsIGN1cnJlbnQsIGJ1ZmZlcikge1xuXHRpZiAoY3VycmVudC5sZW5ndGggPiBNQVhfVFlQRURfQVJSQVlfTEVOR1RIKSB0aHJvdyBuZXcgU2Vyb3ZhbFVuc3VwcG9ydGVkVHlwZUVycm9yKGN1cnJlbnQpO1xuXHRyZXR1cm4gY3JlYXRlU2Vyb3ZhbE5vZGUoMTYsIGlkLCB2b2lkIDAsIGN1cnJlbnQuY29uc3RydWN0b3IubmFtZSwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBidWZmZXIsIGN1cnJlbnQuYnl0ZU9mZnNldCwgdm9pZCAwLCBjdXJyZW50Lmxlbmd0aCk7XG59XG5mdW5jdGlvbiBjcmVhdGVEYXRhVmlld05vZGUoaWQsIGN1cnJlbnQsIGJ1ZmZlcikge1xuXHRpZiAoY3VycmVudC5ieXRlTGVuZ3RoID4gTUFYX1RZUEVEX0FSUkFZX0xFTkdUSCkgdGhyb3cgbmV3IFNlcm92YWxVbnN1cHBvcnRlZFR5cGVFcnJvcihjdXJyZW50KTtcblx0cmV0dXJuIGNyZWF0ZVNlcm92YWxOb2RlKDIwLCBpZCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgYnVmZmVyLCBjdXJyZW50LmJ5dGVPZmZzZXQsIHZvaWQgMCwgY3VycmVudC5ieXRlTGVuZ3RoKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUVycm9yTm9kZShpZCwgY3VycmVudCwgb3B0aW9ucykge1xuXHRyZXR1cm4gY3JlYXRlU2Vyb3ZhbE5vZGUoMTMsIGlkLCBnZXRFcnJvckNvbnN0cnVjdG9yKGN1cnJlbnQpLCB2b2lkIDAsIHNlcmlhbGl6ZVN0cmluZyhjdXJyZW50Lm1lc3NhZ2UpLCBvcHRpb25zLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUFnZ3JlZ2F0ZUVycm9yTm9kZShpZCwgY3VycmVudCwgb3B0aW9ucykge1xuXHRyZXR1cm4gY3JlYXRlU2Vyb3ZhbE5vZGUoMTQsIGlkLCBnZXRFcnJvckNvbnN0cnVjdG9yKGN1cnJlbnQpLCB2b2lkIDAsIHNlcmlhbGl6ZVN0cmluZyhjdXJyZW50Lm1lc3NhZ2UpLCBvcHRpb25zLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVNldE5vZGUoaWQsIGl0ZW1zKSB7XG5cdHJldHVybiBjcmVhdGVTZXJvdmFsTm9kZSg3LCBpZCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIGl0ZW1zLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDApO1xufVxuZnVuY3Rpb24gY3JlYXRlSXRlcmF0b3JGYWN0b3J5SW5zdGFuY2VOb2RlKGZhY3RvcnksIGl0ZW1zKSB7XG5cdHJldHVybiBjcmVhdGVTZXJvdmFsTm9kZSgyOCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgW2ZhY3RvcnksIGl0ZW1zXSwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUFzeW5jSXRlcmF0b3JGYWN0b3J5SW5zdGFuY2VOb2RlKGZhY3RvcnksIGl0ZW1zKSB7XG5cdHJldHVybiBjcmVhdGVTZXJvdmFsTm9kZSgzMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgW2ZhY3RvcnksIGl0ZW1zXSwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVN0cmVhbUNvbnN0cnVjdG9yTm9kZShpZCwgZmFjdG9yeSwgc2VxdWVuY2UpIHtcblx0cmV0dXJuIGNyZWF0ZVNlcm92YWxOb2RlKDMxLCBpZCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHNlcXVlbmNlLCBmYWN0b3J5LCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVN0cmVhbU5leHROb2RlKGlkLCBwYXJzZWQpIHtcblx0cmV0dXJuIGNyZWF0ZVNlcm92YWxOb2RlKDMyLCBpZCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgcGFyc2VkLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVN0cmVhbVRocm93Tm9kZShpZCwgcGFyc2VkKSB7XG5cdHJldHVybiBjcmVhdGVTZXJvdmFsTm9kZSgzMywgaWQsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHBhcnNlZCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCk7XG59XG5mdW5jdGlvbiBjcmVhdGVTdHJlYW1SZXR1cm5Ob2RlKGlkLCBwYXJzZWQpIHtcblx0cmV0dXJuIGNyZWF0ZVNlcm92YWxOb2RlKDM0LCBpZCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgcGFyc2VkLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVNlcXVlbmNlTm9kZShpZCwgc2VxdWVuY2UsIHRocm93QXQsIGRvbmVBdCkge1xuXHRyZXR1cm4gY3JlYXRlU2Vyb3ZhbE5vZGUoMzUsIGlkLCB0aHJvd0F0LCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHNlcXVlbmNlLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBkb25lQXQpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvb3BhcXVlLXJlZmVyZW5jZS50c1xuLyoqXG4qIEFuIG9wYXF1ZSByZWZlcmVuY2UgYWxsb3dzIGhpZGluZyB2YWx1ZXMgZnJvbSB0aGUgc2VyaWFsaXplci5cbiovXG52YXIgT3BhcXVlUmVmZXJlbmNlID0gY2xhc3Mge1xuXHRjb25zdHJ1Y3Rvcih2YWx1ZSwgcmVwbGFjZW1lbnQpIHtcblx0XHR0aGlzLnZhbHVlID0gdmFsdWU7XG5cdFx0dGhpcy5yZXBsYWNlbWVudCA9IHJlcGxhY2VtZW50O1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29uc3RydWN0b3JzLnRzXG5jb25zdCBQUk9NSVNFX0NPTlNUUlVDVE9SID0gKCkgPT4ge1xuXHRjb25zdCByZXNvbHZlciA9IHtcblx0XHRwOiAwLFxuXHRcdHM6IDAsXG5cdFx0ZjogMFxuXHR9O1xuXHRyZXNvbHZlci5wID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdHJlc29sdmVyLnMgPSByZXNvbHZlO1xuXHRcdHJlc29sdmVyLmYgPSByZWplY3Q7XG5cdH0pO1xuXHRyZXR1cm4gcmVzb2x2ZXI7XG59O1xuY29uc3QgUFJPTUlTRV9TVUNDRVNTID0gKHJlc29sdmVyLCBkYXRhKSA9PiB7XG5cdHJlc29sdmVyLnMoZGF0YSk7XG5cdHJlc29sdmVyLnAucyA9IDE7XG5cdHJlc29sdmVyLnAudiA9IGRhdGE7XG59O1xuY29uc3QgUFJPTUlTRV9GQUlMVVJFID0gKHJlc29sdmVyLCBkYXRhKSA9PiB7XG5cdHJlc29sdmVyLmYoZGF0YSk7XG5cdHJlc29sdmVyLnAucyA9IDI7XG5cdHJlc29sdmVyLnAudiA9IGRhdGE7XG59O1xuY29uc3QgU0VSSUFMSVpFRF9QUk9NSVNFX0NPTlNUUlVDVE9SID0gLyogQF9fUFVSRV9fICovIFBST01JU0VfQ09OU1RSVUNUT1IudG9TdHJpbmcoKTtcbmNvbnN0IFNFUklBTElaRURfUFJPTUlTRV9TVUNDRVNTID0gLyogQF9fUFVSRV9fICovIFBST01JU0VfU1VDQ0VTUy50b1N0cmluZygpO1xuY29uc3QgU0VSSUFMSVpFRF9QUk9NSVNFX0ZBSUxVUkUgPSAvKiBAX19QVVJFX18gKi8gUFJPTUlTRV9GQUlMVVJFLnRvU3RyaW5nKCk7XG5jb25zdCBTVFJFQU1fQ09OU1RSVUNUT1IgPSAoKSA9PiB7XG5cdGNvbnN0IGJ1ZmZlciA9IFtdO1xuXHRjb25zdCBsaXN0ZW5lcnMgPSBbXTtcblx0bGV0IGFsaXZlID0gdHJ1ZTtcblx0bGV0IHN1Y2Nlc3MgPSBmYWxzZTtcblx0bGV0IGNvdW50ID0gMDtcblx0Y29uc3QgaW50ZXJuYWwgPSB7XG5cdFx0Zmx1c2godmFsdWUsIG1vZGUsIHgpIHtcblx0XHRcdGZvciAoeCA9IDA7IHggPCBjb3VudDsgeCsrKSB7XG5cdFx0XHRcdGNvbnN0IGxpc3RlbmVyID0gbGlzdGVuZXJzW3hdO1xuXHRcdFx0XHRpZiAobGlzdGVuZXIpIGxpc3RlbmVyW21vZGVdKHZhbHVlKTtcblx0XHRcdH1cblx0XHR9LFxuXHRcdHVwKGxpc3RlbmVyLCB4LCB6LCBjdXJyZW50KSB7XG5cdFx0XHRmb3IgKHggPSAwLCB6ID0gYnVmZmVyLmxlbmd0aDsgeCA8IHo7IHgrKykge1xuXHRcdFx0XHRjdXJyZW50ID0gYnVmZmVyW3hdO1xuXHRcdFx0XHRpZiAoIWFsaXZlICYmIHggPT09IHogLSAxKSBsaXN0ZW5lcltzdWNjZXNzID8gXCJyZXR1cm5cIiA6IFwidGhyb3dcIl0oY3VycmVudCk7XG5cdFx0XHRcdGVsc2UgbGlzdGVuZXIubmV4dChjdXJyZW50KTtcblx0XHRcdH1cblx0XHR9LFxuXHRcdG9uKGxpc3RlbmVyLCB0ZW1wID0gMCkge1xuXHRcdFx0bGV0IHN1YnNjcmliZWQgPSBhbGl2ZTtcblx0XHRcdGlmIChhbGl2ZSkge1xuXHRcdFx0XHRmb3IgKHRlbXAgPSAwOyB0ZW1wIDwgY291bnQ7IHRlbXArKykgaWYgKCFsaXN0ZW5lcnNbdGVtcF0pIGJyZWFrO1xuXHRcdFx0XHRpZiAodGVtcCA9PT0gY291bnQpIGNvdW50Kys7XG5cdFx0XHRcdGxpc3RlbmVyc1t0ZW1wXSA9IGxpc3RlbmVyO1xuXHRcdFx0fVxuXHRcdFx0aW50ZXJuYWwudXAobGlzdGVuZXIpO1xuXHRcdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdFx0aWYgKGFsaXZlICYmIHN1YnNjcmliZWQpIHtcblx0XHRcdFx0XHRzdWJzY3JpYmVkID0gZmFsc2U7XG5cdFx0XHRcdFx0bGlzdGVuZXJzW3RlbXBdID0gdm9pZCAwO1xuXHRcdFx0XHRcdHdoaWxlIChjb3VudCA+IDAgJiYgIWxpc3RlbmVyc1tjb3VudCAtIDFdKSBjb3VudC0tO1xuXHRcdFx0XHRcdGxpc3RlbmVycy5sZW5ndGggPSBjb3VudDtcblx0XHRcdFx0fVxuXHRcdFx0fTtcblx0XHR9XG5cdH07XG5cdHJldHVybiB7XG5cdFx0X19TRVJPVkFMX1NUUkVBTV9fOiB0cnVlLFxuXHRcdG9uKGxpc3RlbmVyKSB7XG5cdFx0XHRyZXR1cm4gaW50ZXJuYWwub24obGlzdGVuZXIpO1xuXHRcdH0sXG5cdFx0bmV4dCh2YWx1ZSkge1xuXHRcdFx0aWYgKGFsaXZlKSB7XG5cdFx0XHRcdGJ1ZmZlci5wdXNoKHZhbHVlKTtcblx0XHRcdFx0aW50ZXJuYWwuZmx1c2godmFsdWUsIFwibmV4dFwiKTtcblx0XHRcdH1cblx0XHR9LFxuXHRcdHRocm93KHZhbHVlKSB7XG5cdFx0XHRpZiAoYWxpdmUpIHtcblx0XHRcdFx0YnVmZmVyLnB1c2godmFsdWUpO1xuXHRcdFx0XHRpbnRlcm5hbC5mbHVzaCh2YWx1ZSwgXCJ0aHJvd1wiKTtcblx0XHRcdFx0YWxpdmUgPSBmYWxzZTtcblx0XHRcdFx0c3VjY2VzcyA9IGZhbHNlO1xuXHRcdFx0XHRsaXN0ZW5lcnMubGVuZ3RoID0gMDtcblx0XHRcdH1cblx0XHR9LFxuXHRcdHJldHVybih2YWx1ZSkge1xuXHRcdFx0aWYgKGFsaXZlKSB7XG5cdFx0XHRcdGJ1ZmZlci5wdXNoKHZhbHVlKTtcblx0XHRcdFx0aW50ZXJuYWwuZmx1c2godmFsdWUsIFwicmV0dXJuXCIpO1xuXHRcdFx0XHRhbGl2ZSA9IGZhbHNlO1xuXHRcdFx0XHRzdWNjZXNzID0gdHJ1ZTtcblx0XHRcdFx0bGlzdGVuZXJzLmxlbmd0aCA9IDA7XG5cdFx0XHR9XG5cdFx0fVxuXHR9O1xufTtcbmNvbnN0IFNFUklBTElaRURfU1RSRUFNX0NPTlNUUlVDVE9SID0gLyogQF9fUFVSRV9fICovIFNUUkVBTV9DT05TVFJVQ1RPUi50b1N0cmluZygpO1xuY29uc3QgSVRFUkFUT1JfQ09OU1RSVUNUT1IgPSAoc3ltYm9sKSA9PiAoc2VxdWVuY2UpID0+ICgpID0+IHtcblx0bGV0IGluZGV4ID0gMDtcblx0Y29uc3QgaW5zdGFuY2UgPSB7XG5cdFx0W3N5bWJvbF0oKSB7XG5cdFx0XHRyZXR1cm4gaW5zdGFuY2U7XG5cdFx0fSxcblx0XHRuZXh0KCkge1xuXHRcdFx0aWYgKGluZGV4ID4gc2VxdWVuY2UuZCkgcmV0dXJuIHtcblx0XHRcdFx0ZG9uZTogdHJ1ZSxcblx0XHRcdFx0dmFsdWU6IHZvaWQgMFxuXHRcdFx0fTtcblx0XHRcdGNvbnN0IGN1cnJlbnRJbmRleCA9IGluZGV4Kys7XG5cdFx0XHRjb25zdCBkYXRhID0gc2VxdWVuY2UudltjdXJyZW50SW5kZXhdO1xuXHRcdFx0aWYgKGN1cnJlbnRJbmRleCA9PT0gc2VxdWVuY2UudCkgdGhyb3cgZGF0YTtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGRvbmU6IGN1cnJlbnRJbmRleCA9PT0gc2VxdWVuY2UuZCxcblx0XHRcdFx0dmFsdWU6IGRhdGFcblx0XHRcdH07XG5cdFx0fVxuXHR9O1xuXHRyZXR1cm4gaW5zdGFuY2U7XG59O1xuY29uc3QgU0VSSUFMSVpFRF9JVEVSQVRPUl9DT05TVFJVQ1RPUiA9IC8qIEBfX1BVUkVfXyAqLyBJVEVSQVRPUl9DT05TVFJVQ1RPUi50b1N0cmluZygpO1xuY29uc3QgQVNZTkNfSVRFUkFUT1JfQ09OU1RSVUNUT1IgPSAoc3ltYm9sLCBjcmVhdGVQcm9taXNlKSA9PiAoc3RyZWFtKSA9PiAoKSA9PiB7XG5cdGxldCBjb3VudCA9IDA7XG5cdGxldCBkb25lQXQgPSAtMTtcblx0bGV0IGlzVGhyb3cgPSBmYWxzZTtcblx0Y29uc3QgYnVmZmVyID0gW107XG5cdGNvbnN0IHBlbmRpbmcgPSBbXTtcblx0Y29uc3QgaW50ZXJuYWwgPSB7IGZpbmFsaXplKGkgPSAwLCBsZW4gPSBwZW5kaW5nLmxlbmd0aCkge1xuXHRcdGZvciAoOyBpIDwgbGVuOyBpKyspIHBlbmRpbmdbaV0ucyh7XG5cdFx0XHRkb25lOiB0cnVlLFxuXHRcdFx0dmFsdWU6IHZvaWQgMFxuXHRcdH0pO1xuXHR9IH07XG5cdHN0cmVhbS5vbih7XG5cdFx0bmV4dCh2YWx1ZSkge1xuXHRcdFx0Y29uc3QgdGVtcCA9IHBlbmRpbmcuc2hpZnQoKTtcblx0XHRcdGlmICh0ZW1wKSB0ZW1wLnMoe1xuXHRcdFx0XHRkb25lOiBmYWxzZSxcblx0XHRcdFx0dmFsdWVcblx0XHRcdH0pO1xuXHRcdFx0YnVmZmVyLnB1c2godmFsdWUpO1xuXHRcdH0sXG5cdFx0dGhyb3codmFsdWUpIHtcblx0XHRcdGNvbnN0IHRlbXAgPSBwZW5kaW5nLnNoaWZ0KCk7XG5cdFx0XHRpZiAodGVtcCkgdGVtcC5mKHZhbHVlKTtcblx0XHRcdGludGVybmFsLmZpbmFsaXplKCk7XG5cdFx0XHRkb25lQXQgPSBidWZmZXIubGVuZ3RoO1xuXHRcdFx0aXNUaHJvdyA9IHRydWU7XG5cdFx0XHRidWZmZXIucHVzaCh2YWx1ZSk7XG5cdFx0fSxcblx0XHRyZXR1cm4odmFsdWUpIHtcblx0XHRcdGNvbnN0IHRlbXAgPSBwZW5kaW5nLnNoaWZ0KCk7XG5cdFx0XHRpZiAodGVtcCkgdGVtcC5zKHtcblx0XHRcdFx0ZG9uZTogdHJ1ZSxcblx0XHRcdFx0dmFsdWVcblx0XHRcdH0pO1xuXHRcdFx0aW50ZXJuYWwuZmluYWxpemUoKTtcblx0XHRcdGRvbmVBdCA9IGJ1ZmZlci5sZW5ndGg7XG5cdFx0XHRidWZmZXIucHVzaCh2YWx1ZSk7XG5cdFx0fVxuXHR9KTtcblx0Y29uc3QgaW5zdGFuY2UgPSB7XG5cdFx0W3N5bWJvbF0oKSB7XG5cdFx0XHRyZXR1cm4gaW5zdGFuY2U7XG5cdFx0fSxcblx0XHRuZXh0KCkge1xuXHRcdFx0aWYgKGRvbmVBdCA9PT0gLTEpIHtcblx0XHRcdFx0Y29uc3QgaW5kZXggPSBjb3VudCsrO1xuXHRcdFx0XHRpZiAoaW5kZXggPj0gYnVmZmVyLmxlbmd0aCkge1xuXHRcdFx0XHRcdGNvbnN0IHRlbXAgPSBjcmVhdGVQcm9taXNlKCk7XG5cdFx0XHRcdFx0cGVuZGluZy5wdXNoKHRlbXApO1xuXHRcdFx0XHRcdHJldHVybiB0ZW1wLnA7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRkb25lOiBmYWxzZSxcblx0XHRcdFx0XHR2YWx1ZTogYnVmZmVyW2luZGV4XVxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdFx0aWYgKGNvdW50ID4gZG9uZUF0KSByZXR1cm4ge1xuXHRcdFx0XHRkb25lOiB0cnVlLFxuXHRcdFx0XHR2YWx1ZTogdm9pZCAwXG5cdFx0XHR9O1xuXHRcdFx0Y29uc3QgaW5kZXggPSBjb3VudCsrO1xuXHRcdFx0Y29uc3QgdmFsdWUgPSBidWZmZXJbaW5kZXhdO1xuXHRcdFx0aWYgKGluZGV4ICE9PSBkb25lQXQpIHJldHVybiB7XG5cdFx0XHRcdGRvbmU6IGZhbHNlLFxuXHRcdFx0XHR2YWx1ZVxuXHRcdFx0fTtcblx0XHRcdGlmIChpc1Rocm93KSB0aHJvdyB2YWx1ZTtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGRvbmU6IHRydWUsXG5cdFx0XHRcdHZhbHVlXG5cdFx0XHR9O1xuXHRcdH1cblx0fTtcblx0cmV0dXJuIGluc3RhbmNlO1xufTtcbmNvbnN0IFNFUklBTElaRURfQVNZTkNfSVRFUkFUT1JfQ09OU1RSVUNUT1IgPSAvKiBAX19QVVJFX18gKi8gQVNZTkNfSVRFUkFUT1JfQ09OU1RSVUNUT1IudG9TdHJpbmcoKTtcbmNvbnN0IEFSUkFZX0JVRkZFUl9DT05TVFJVQ1RPUiA9IChiNjQpID0+IHtcblx0Y29uc3QgZGVjb2RlZCA9IGF0b2IoYjY0KTtcblx0Y29uc3QgbGVuZ3RoID0gZGVjb2RlZC5sZW5ndGg7XG5cdGNvbnN0IGFyciA9IG5ldyBVaW50OEFycmF5KGxlbmd0aCk7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgbGVuZ3RoOyBpKyspIGFycltpXSA9IGRlY29kZWQuY2hhckNvZGVBdChpKTtcblx0cmV0dXJuIGFyci5idWZmZXI7XG59O1xuY29uc3QgU0VSSUFMSVpFRF9BUlJBWV9CVUZGRVJfQ09OU1RSVUNUT1IgPSAvKiBAX19QVVJFX18gKi8gQVJSQVlfQlVGRkVSX0NPTlNUUlVDVE9SLnRvU3RyaW5nKCk7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9zZXF1ZW5jZS50c1xuZnVuY3Rpb24gaXNTZXF1ZW5jZSh2YWx1ZSkge1xuXHRyZXR1cm4gXCJfX1NFUk9WQUxfU0VRVUVOQ0VfX1wiIGluIHZhbHVlO1xufVxuZnVuY3Rpb24gY3JlYXRlU2VxdWVuY2UodmFsdWVzLCB0aHJvd0F0LCBkb25lQXQpIHtcblx0cmV0dXJuIHtcblx0XHRfX1NFUk9WQUxfU0VRVUVOQ0VfXzogdHJ1ZSxcblx0XHR2OiB2YWx1ZXMsXG5cdFx0dDogdGhyb3dBdCxcblx0XHRkOiBkb25lQXRcblx0fTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVNlcXVlbmNlRnJvbUl0ZXJhYmxlKHNvdXJjZSkge1xuXHRjb25zdCB2YWx1ZXMgPSBbXTtcblx0bGV0IHRocm93c0F0ID0gLTE7XG5cdGxldCBkb25lQXQgPSAtMTtcblx0Y29uc3QgaXRlcmF0b3IgPSBzb3VyY2VbU1lNX0lURVJBVE9SXSgpO1xuXHR3aGlsZSAodHJ1ZSkgdHJ5IHtcblx0XHRjb25zdCB2YWx1ZSA9IGl0ZXJhdG9yLm5leHQoKTtcblx0XHR2YWx1ZXMucHVzaCh2YWx1ZS52YWx1ZSk7XG5cdFx0aWYgKHZhbHVlLmRvbmUpIHtcblx0XHRcdGRvbmVBdCA9IHZhbHVlcy5sZW5ndGggLSAxO1xuXHRcdFx0YnJlYWs7XG5cdFx0fVxuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdHRocm93c0F0ID0gdmFsdWVzLmxlbmd0aDtcblx0XHR2YWx1ZXMucHVzaChlcnJvcik7XG5cdH1cblx0cmV0dXJuIGNyZWF0ZVNlcXVlbmNlKHZhbHVlcywgdGhyb3dzQXQsIGRvbmVBdCk7XG59XG5jb25zdCBjcmVhdGVJdGVyYXRvciA9IElURVJBVE9SX0NPTlNUUlVDVE9SKFNZTV9JVEVSQVRPUik7XG5mdW5jdGlvbiBzZXF1ZW5jZVRvSXRlcmF0b3Ioc2VxdWVuY2UpIHtcblx0cmV0dXJuIGNyZWF0ZUl0ZXJhdG9yKHNlcXVlbmNlKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3NwZWNpYWwtcmVmZXJlbmNlLnRzXG5jb25zdCBJVEVSQVRPUiA9IHt9O1xuY29uc3QgQVNZTkNfSVRFUkFUT1IgPSB7fTtcbi8qKlxuKiBQbGFjZWhvbGRlciByZWZlcmVuY2VzXG4qL1xuY29uc3QgU1BFQ0lBTF9SRUZTID0ge1xuXHRbMF06IHt9LFxuXHRbMV06IHt9LFxuXHRbMl06IHt9LFxuXHRbM106IHt9LFxuXHRbNF06IHt9LFxuXHRbNV06IHt9XG59O1xuY29uc3QgU1BFQ0lBTF9SRUZfU1RSSU5HID0ge1xuXHRbMF06IFwiW11cIixcblx0WzFdOiBTRVJJQUxJWkVEX1BST01JU0VfQ09OU1RSVUNUT1IsXG5cdFsyXTogU0VSSUFMSVpFRF9QUk9NSVNFX1NVQ0NFU1MsXG5cdFszXTogU0VSSUFMSVpFRF9QUk9NSVNFX0ZBSUxVUkUsXG5cdFs0XTogU0VSSUFMSVpFRF9TVFJFQU1fQ09OU1RSVUNUT1IsXG5cdFs1XTogU0VSSUFMSVpFRF9BUlJBWV9CVUZGRVJfQ09OU1RSVUNUT1Jcbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9zdHJlYW0udHNcbmZ1bmN0aW9uIGlzU3RyZWFtKHZhbHVlKSB7XG5cdHJldHVybiBcIl9fU0VST1ZBTF9TVFJFQU1fX1wiIGluIHZhbHVlO1xufVxuZnVuY3Rpb24gY3JlYXRlU3RyZWFtKCkge1xuXHRyZXR1cm4gU1RSRUFNX0NPTlNUUlVDVE9SKCk7XG59XG5mdW5jdGlvbiBjcmVhdGVTdHJlYW1Gcm9tQXN5bmNJdGVyYWJsZShpdGVyYWJsZSwgY2xlYW51cHMpIHtcblx0Y29uc3Qgc3RyZWFtID0gY3JlYXRlU3RyZWFtKCk7XG5cdGNvbnN0IGl0ZXJhdG9yID0gaXRlcmFibGVbU1lNX0FTWU5DX0lURVJBVE9SXSgpO1xuXHRsZXQgY2FuY2VsbGVkID0gZmFsc2U7XG5cdGxldCBkb25lID0gZmFsc2U7XG5cdGNsZWFudXBzID09PSBudWxsIHx8IGNsZWFudXBzID09PSB2b2lkIDAgfHwgY2xlYW51cHMucHVzaCgoKSA9PiB7XG5cdFx0aWYgKCEoZG9uZSB8fCBjYW5jZWxsZWQpKSB7XG5cdFx0XHRjYW5jZWxsZWQgPSB0cnVlO1xuXHRcdFx0UHJvbWlzZS5yZXNvbHZlKCkudGhlbigoKSA9PiB7XG5cdFx0XHRcdHZhciBfaXRlcmF0b3IkcmV0dXJuO1xuXHRcdFx0XHRyZXR1cm4gKF9pdGVyYXRvciRyZXR1cm4gPSBpdGVyYXRvci5yZXR1cm4pID09PSBudWxsIHx8IF9pdGVyYXRvciRyZXR1cm4gPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9pdGVyYXRvciRyZXR1cm4uY2FsbChpdGVyYXRvcik7XG5cdFx0XHR9KS5jYXRjaCgoKSA9PiB7fSk7XG5cdFx0fVxuXHR9KTtcblx0YXN5bmMgZnVuY3Rpb24gcHVzaCgpIHtcblx0XHR0cnkge1xuXHRcdFx0d2hpbGUgKCFjYW5jZWxsZWQpIHtcblx0XHRcdFx0Y29uc3QgdmFsdWUgPSBhd2FpdCBpdGVyYXRvci5uZXh0KCk7XG5cdFx0XHRcdGlmIChjYW5jZWxsZWQpIHJldHVybjtcblx0XHRcdFx0aWYgKHZhbHVlLmRvbmUpIHtcblx0XHRcdFx0XHRkb25lID0gdHJ1ZTtcblx0XHRcdFx0XHRzdHJlYW0ucmV0dXJuKHZhbHVlLnZhbHVlKTtcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0fVxuXHRcdFx0XHRzdHJlYW0ubmV4dCh2YWx1ZS52YWx1ZSk7XG5cdFx0XHR9XG5cdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdGRvbmUgPSB0cnVlO1xuXHRcdFx0aWYgKCFjYW5jZWxsZWQpIHN0cmVhbS50aHJvdyhlcnJvcik7XG5cdFx0fVxuXHR9XG5cdHB1c2goKS5jYXRjaCgoKSA9PiB7fSk7XG5cdHJldHVybiBzdHJlYW07XG59XG5jb25zdCBjcmVhdGVBc3luY0l0ZXJhYmxlID0gQVNZTkNfSVRFUkFUT1JfQ09OU1RSVUNUT1IoU1lNX0FTWU5DX0lURVJBVE9SLCBQUk9NSVNFX0NPTlNUUlVDVE9SKTtcbmZ1bmN0aW9uIHN0cmVhbVRvQXN5bmNJdGVyYWJsZShzdHJlYW0pIHtcblx0cmV0dXJuIGNyZWF0ZUFzeW5jSXRlcmFibGUoc3RyZWFtKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3V0aWxzL3Byb21pc2UtdG8tcmVzdWx0LnRzXG5hc3luYyBmdW5jdGlvbiBwcm9taXNlVG9SZXN1bHQoY3VycmVudCkge1xuXHR0cnkge1xuXHRcdHJldHVybiBbMSwgYXdhaXQgY3VycmVudF07XG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRyZXR1cm4gWzAsIGVdO1xuXHR9XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb250ZXh0L3BhcnNlci50c1xuZnVuY3Rpb24gY3JlYXRlQmFzZVBhcnNlckNvbnRleHQobW9kZSwgb3B0aW9ucykge1xuXHR2YXIgX29wdGlvbnMkY29tcGFjdEFycmF5O1xuXHRyZXR1cm4ge1xuXHRcdHBsdWdpbnM6IG9wdGlvbnMucGx1Z2lucyxcblx0XHRtb2RlLFxuXHRcdG1hcmtlZDogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSxcblx0XHRmZWF0dXJlczogMTI3IF4gKG9wdGlvbnMuZGlzYWJsZWRGZWF0dXJlcyB8fCAwKSxcblx0XHRyZWZzOiBvcHRpb25zLnJlZnMgfHwgLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSxcblx0XHRkZXB0aExpbWl0OiBvcHRpb25zLmRlcHRoTGltaXQgfHwgMWUzLFxuXHRcdGNvbXBhY3RBcnJheUJ1ZmZlclZpZXdzOiAoX29wdGlvbnMkY29tcGFjdEFycmF5ID0gb3B0aW9ucy5jb21wYWN0QXJyYXlCdWZmZXJWaWV3cykgIT09IG51bGwgJiYgX29wdGlvbnMkY29tcGFjdEFycmF5ICE9PSB2b2lkIDAgPyBfb3B0aW9ucyRjb21wYWN0QXJyYXkgOiBmYWxzZVxuXHR9O1xufVxuLyoqXG4qIEVuc3VyZXMgdGhhdCB0aGUgdmFsdWUgKGJhc2VkIG9uIGFuIGlkZW50aWZpZXIpIGhhcyBiZWVuIHZpc2l0ZWQgYnkgdGhlIHBhcnNlci5cbiogQHBhcmFtIGN0eFxuKiBAcGFyYW0gaWRcbiovXG5mdW5jdGlvbiBtYXJrUGFyc2VyUmVmKGN0eCwgaWQpIHtcblx0Y3R4Lm1hcmtlZC5hZGQoaWQpO1xufVxuLyoqXG4qIENyZWF0ZXMgYW4gaWRlbnRpZmllciBmb3IgYSB2YWx1ZVxuKiBAcGFyYW0gY3R4XG4qIEBwYXJhbSBjdXJyZW50XG4qL1xuZnVuY3Rpb24gY3JlYXRlSW5kZXhGb3JWYWx1ZShjdHgsIGN1cnJlbnQpIHtcblx0Y29uc3QgaWQgPSBjdHgucmVmcy5zaXplO1xuXHRjdHgucmVmcy5zZXQoY3VycmVudCwgaWQpO1xuXHRyZXR1cm4gaWQ7XG59XG5mdW5jdGlvbiBnZXROb2RlRm9ySW5kZXhlZFZhbHVlKGN0eCwgY3VycmVudCkge1xuXHRjb25zdCByZWdpc3RlcmVkSWQgPSBjdHgucmVmcy5nZXQoY3VycmVudCk7XG5cdGlmIChyZWdpc3RlcmVkSWQgIT0gbnVsbCkge1xuXHRcdG1hcmtQYXJzZXJSZWYoY3R4LCByZWdpc3RlcmVkSWQpO1xuXHRcdHJldHVybiB7XG5cdFx0XHR0eXBlOiAxLFxuXHRcdFx0dmFsdWU6IGNyZWF0ZUluZGV4ZWRWYWx1ZU5vZGUocmVnaXN0ZXJlZElkKVxuXHRcdH07XG5cdH1cblx0cmV0dXJuIHtcblx0XHR0eXBlOiAwLFxuXHRcdHZhbHVlOiBjcmVhdGVJbmRleEZvclZhbHVlKGN0eCwgY3VycmVudClcblx0fTtcbn1cbmZ1bmN0aW9uIGdldFJlZmVyZW5jZU5vZGUoY3R4LCBjdXJyZW50KSB7XG5cdGNvbnN0IGluZGV4ZWQgPSBnZXROb2RlRm9ySW5kZXhlZFZhbHVlKGN0eCwgY3VycmVudCk7XG5cdGlmIChpbmRleGVkLnR5cGUgPT09IDEpIHJldHVybiBpbmRleGVkO1xuXHRpZiAoaGFzUmVmZXJlbmNlSUQoY3VycmVudCkpIHJldHVybiB7XG5cdFx0dHlwZTogMixcblx0XHR2YWx1ZTogY3JlYXRlUmVmZXJlbmNlTm9kZShpbmRleGVkLnZhbHVlLCBjdXJyZW50KVxuXHR9O1xuXHRyZXR1cm4gaW5kZXhlZDtcbn1cbi8qKlxuKiBQYXJzaW5nIG1ldGhvZHNcbiovXG5mdW5jdGlvbiBwYXJzZVdlbGxLbm93blN5bWJvbChjdHgsIGN1cnJlbnQpIHtcblx0Y29uc3QgcmVmID0gZ2V0UmVmZXJlbmNlTm9kZShjdHgsIGN1cnJlbnQpO1xuXHRpZiAocmVmLnR5cGUgIT09IDApIHJldHVybiByZWYudmFsdWU7XG5cdGlmIChjdXJyZW50IGluIElOVl9TWU1CT0xfUkVGKSByZXR1cm4gY3JlYXRlV0tTeW1ib2xOb2RlKHJlZi52YWx1ZSwgY3VycmVudCk7XG5cdHRocm93IG5ldyBTZXJvdmFsVW5zdXBwb3J0ZWRUeXBlRXJyb3IoY3VycmVudCk7XG59XG5mdW5jdGlvbiBwYXJzZVNwZWNpYWxSZWZlcmVuY2UoY3R4LCByZWYpIHtcblx0Y29uc3QgcmVzdWx0ID0gZ2V0Tm9kZUZvckluZGV4ZWRWYWx1ZShjdHgsIFNQRUNJQUxfUkVGU1tyZWZdKTtcblx0aWYgKHJlc3VsdC50eXBlID09PSAxKSByZXR1cm4gcmVzdWx0LnZhbHVlO1xuXHRyZXR1cm4gY3JlYXRlU2Vyb3ZhbE5vZGUoMjYsIHJlc3VsdC52YWx1ZSwgcmVmLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIHBhcnNlSXRlcmF0b3JGYWN0b3J5KGN0eCkge1xuXHRjb25zdCByZXN1bHQgPSBnZXROb2RlRm9ySW5kZXhlZFZhbHVlKGN0eCwgSVRFUkFUT1IpO1xuXHRpZiAocmVzdWx0LnR5cGUgPT09IDEpIHJldHVybiByZXN1bHQudmFsdWU7XG5cdHJldHVybiBjcmVhdGVTZXJvdmFsTm9kZSgyNywgcmVzdWx0LnZhbHVlLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBwYXJzZVdlbGxLbm93blN5bWJvbChjdHgsIFNZTV9JVEVSQVRPUiksIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDApO1xufVxuZnVuY3Rpb24gcGFyc2VBc3luY0l0ZXJhdG9yRmFjdG9yeShjdHgpIHtcblx0Y29uc3QgcmVzdWx0ID0gZ2V0Tm9kZUZvckluZGV4ZWRWYWx1ZShjdHgsIEFTWU5DX0lURVJBVE9SKTtcblx0aWYgKHJlc3VsdC50eXBlID09PSAxKSByZXR1cm4gcmVzdWx0LnZhbHVlO1xuXHRyZXR1cm4gY3JlYXRlU2Vyb3ZhbE5vZGUoMjksIHJlc3VsdC52YWx1ZSwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIFtwYXJzZVNwZWNpYWxSZWZlcmVuY2UoY3R4LCAxKSwgcGFyc2VXZWxsS25vd25TeW1ib2woY3R4LCBTWU1fQVNZTkNfSVRFUkFUT1IpXSwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZU9iamVjdE5vZGUoaWQsIGN1cnJlbnQsIGVtcHR5LCByZWNvcmQpIHtcblx0cmV0dXJuIGNyZWF0ZVNlcm92YWxOb2RlKGVtcHR5ID8gMTEgOiAxMCwgaWQsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHJlY29yZCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBnZXRPYmplY3RGbGFnKGN1cnJlbnQpLCB2b2lkIDApO1xufVxuZnVuY3Rpb24gY3JlYXRlTWFwTm9kZShjdHgsIGlkLCBrLCB2KSB7XG5cdHJldHVybiBjcmVhdGVTZXJvdmFsTm9kZSg4LCBpZCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB7XG5cdFx0ayxcblx0XHR2XG5cdH0sIHZvaWQgMCwgcGFyc2VTcGVjaWFsUmVmZXJlbmNlKGN0eCwgMCksIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDApO1xufVxuZnVuY3Rpb24gY3JlYXRlUHJvbWlzZUNvbnN0cnVjdG9yTm9kZShjdHgsIGlkLCByZXNvbHZlcikge1xuXHRyZXR1cm4gY3JlYXRlU2Vyb3ZhbE5vZGUoMjIsIGlkLCByZXNvbHZlciwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHBhcnNlU3BlY2lhbFJlZmVyZW5jZShjdHgsIDEpLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIGdldEFycmF5QnVmZmVyVmlldyhjdHgsIGN1cnJlbnQpIHtcblx0aWYgKCFjdHguY29tcGFjdEFycmF5QnVmZmVyVmlld3MpIHJldHVybiBjdXJyZW50O1xuXHRjb25zdCBidWZmZXIgPSBuZXcgVWludDhBcnJheShjdXJyZW50LmJ1ZmZlciwgY3VycmVudC5ieXRlT2Zmc2V0LCBjdXJyZW50LmJ5dGVMZW5ndGgpLnNsaWNlKCkuYnVmZmVyO1xuXHRjb25zdCBDb25zdHJ1Y3RvciA9IGN1cnJlbnQuY29uc3RydWN0b3I7XG5cdHJldHVybiBuZXcgQ29uc3RydWN0b3IoYnVmZmVyKTtcbn1cbmZ1bmN0aW9uIGVuY29kZUFycmF5QnVmZmVyKGN1cnJlbnQpIHtcblx0aWYgKHR5cGVvZiBCdWZmZXIgIT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBCdWZmZXIuZnJvbShjdXJyZW50KS50b1N0cmluZyhcImJhc2U2NFwiKTtcblx0Y29uc3QgYnl0ZXMgPSBuZXcgVWludDhBcnJheShjdXJyZW50KTtcblx0aWYgKHR5cGVvZiBieXRlcy50b0Jhc2U2NCA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gYnl0ZXMudG9CYXNlNjQoKTtcblx0bGV0IHJlc3VsdCA9IFwiXCI7XG5cdGZvciAobGV0IGkgPSAwLCBsZW4gPSBieXRlcy5sZW5ndGg7IGkgPCBsZW47IGkrKykgcmVzdWx0ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYnl0ZXNbaV0pO1xuXHRyZXR1cm4gYnRvYShyZXN1bHQpO1xufVxuZnVuY3Rpb24gY3JlYXRlQXJyYXlCdWZmZXJOb2RlKGN0eCwgaWQsIGN1cnJlbnQpIHtcblx0cmV0dXJuIGNyZWF0ZVNlcm92YWxOb2RlKDE5LCBpZCwgZW5jb2RlQXJyYXlCdWZmZXIoY3VycmVudCksIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBwYXJzZVNwZWNpYWxSZWZlcmVuY2UoY3R4LCA1KSwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb250ZXh0L2FzeW5jLXBhcnNlci50c1xuZnVuY3Rpb24gY3JlYXRlQXN5bmNQYXJzZXJDb250ZXh0KG1vZGUsIG9wdGlvbnMpIHtcblx0cmV0dXJuIHtcblx0XHRiYXNlOiBjcmVhdGVCYXNlUGFyc2VyQ29udGV4dChtb2RlLCBvcHRpb25zKSxcblx0XHRjaGlsZDogdm9pZCAwXG5cdH07XG59XG52YXIgQXN5bmNQYXJzZVBsdWdpbkNvbnRleHQgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKF9wLCBkZXB0aCkge1xuXHRcdHRoaXMuX3AgPSBfcDtcblx0XHR0aGlzLmRlcHRoID0gZGVwdGg7XG5cdH1cblx0cGFyc2UoY3VycmVudCkge1xuXHRcdHJldHVybiBwYXJzZUFzeW5jKHRoaXMuX3AsIHRoaXMuZGVwdGgsIGN1cnJlbnQpO1xuXHR9XG59O1xuYXN5bmMgZnVuY3Rpb24gcGFyc2VJdGVtcyQxKGN0eCwgZGVwdGgsIGN1cnJlbnQpIHtcblx0Y29uc3Qgbm9kZXMgPSBbXTtcblx0Zm9yIChsZXQgaSA9IDAsIGxlbiA9IGN1cnJlbnQubGVuZ3RoOyBpIDwgbGVuOyBpKyspIGlmIChpIGluIGN1cnJlbnQpIG5vZGVzW2ldID0gYXdhaXQgcGFyc2VBc3luYyhjdHgsIGRlcHRoLCBjdXJyZW50W2ldKTtcblx0ZWxzZSBub2Rlc1tpXSA9IDA7XG5cdHJldHVybiBub2Rlcztcbn1cbmFzeW5jIGZ1bmN0aW9uIHBhcnNlQXJyYXkkMShjdHgsIGRlcHRoLCBpZCwgY3VycmVudCkge1xuXHRyZXR1cm4gY3JlYXRlQXJyYXlOb2RlKGlkLCBjdXJyZW50LCBhd2FpdCBwYXJzZUl0ZW1zJDEoY3R4LCBkZXB0aCwgY3VycmVudCkpO1xufVxuYXN5bmMgZnVuY3Rpb24gcGFyc2VQcm9wZXJ0aWVzJDEoY3R4LCBkZXB0aCwgcHJvcGVydGllcykge1xuXHRjb25zdCBlbnRyaWVzID0gT2JqZWN0LmVudHJpZXMocHJvcGVydGllcyk7XG5cdGNvbnN0IGtleU5vZGVzID0gW107XG5cdGNvbnN0IHZhbHVlTm9kZXMgPSBbXTtcblx0Zm9yIChsZXQgaSA9IDAsIGxlbiA9IGVudHJpZXMubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcblx0XHRrZXlOb2Rlcy5wdXNoKHNlcmlhbGl6ZVN0cmluZyhlbnRyaWVzW2ldWzBdKSk7XG5cdFx0dmFsdWVOb2Rlcy5wdXNoKGF3YWl0IHBhcnNlQXN5bmMoY3R4LCBkZXB0aCwgZW50cmllc1tpXVsxXSkpO1xuXHR9XG5cdGlmIChTWU1fSVRFUkFUT1IgaW4gcHJvcGVydGllcykge1xuXHRcdGtleU5vZGVzLnB1c2gocGFyc2VXZWxsS25vd25TeW1ib2woY3R4LmJhc2UsIFNZTV9JVEVSQVRPUikpO1xuXHRcdHZhbHVlTm9kZXMucHVzaChjcmVhdGVJdGVyYXRvckZhY3RvcnlJbnN0YW5jZU5vZGUocGFyc2VJdGVyYXRvckZhY3RvcnkoY3R4LmJhc2UpLCBhd2FpdCBwYXJzZUFzeW5jKGN0eCwgZGVwdGgsIGNyZWF0ZVNlcXVlbmNlRnJvbUl0ZXJhYmxlKHByb3BlcnRpZXMpKSkpO1xuXHR9XG5cdGlmIChTWU1fQVNZTkNfSVRFUkFUT1IgaW4gcHJvcGVydGllcykge1xuXHRcdGtleU5vZGVzLnB1c2gocGFyc2VXZWxsS25vd25TeW1ib2woY3R4LmJhc2UsIFNZTV9BU1lOQ19JVEVSQVRPUikpO1xuXHRcdHZhbHVlTm9kZXMucHVzaChjcmVhdGVBc3luY0l0ZXJhdG9yRmFjdG9yeUluc3RhbmNlTm9kZShwYXJzZUFzeW5jSXRlcmF0b3JGYWN0b3J5KGN0eC5iYXNlKSwgYXdhaXQgcGFyc2VBc3luYyhjdHgsIGRlcHRoLCBjcmVhdGVTdHJlYW1Gcm9tQXN5bmNJdGVyYWJsZShwcm9wZXJ0aWVzKSkpKTtcblx0fVxuXHRpZiAoU1lNX1RPX1NUUklOR19UQUcgaW4gcHJvcGVydGllcykge1xuXHRcdGtleU5vZGVzLnB1c2gocGFyc2VXZWxsS25vd25TeW1ib2woY3R4LmJhc2UsIFNZTV9UT19TVFJJTkdfVEFHKSk7XG5cdFx0dmFsdWVOb2Rlcy5wdXNoKGNyZWF0ZVN0cmluZ05vZGUocHJvcGVydGllc1tTWU1fVE9fU1RSSU5HX1RBR10pKTtcblx0fVxuXHRpZiAoU1lNX0lTX0NPTkNBVF9TUFJFQURBQkxFIGluIHByb3BlcnRpZXMpIHtcblx0XHRrZXlOb2Rlcy5wdXNoKHBhcnNlV2VsbEtub3duU3ltYm9sKGN0eC5iYXNlLCBTWU1fSVNfQ09OQ0FUX1NQUkVBREFCTEUpKTtcblx0XHR2YWx1ZU5vZGVzLnB1c2gocHJvcGVydGllc1tTWU1fSVNfQ09OQ0FUX1NQUkVBREFCTEVdID8gVFJVRV9OT0RFIDogRkFMU0VfTk9ERSk7XG5cdH1cblx0cmV0dXJuIHtcblx0XHRrOiBrZXlOb2Rlcyxcblx0XHR2OiB2YWx1ZU5vZGVzXG5cdH07XG59XG5hc3luYyBmdW5jdGlvbiBwYXJzZVBsYWluT2JqZWN0JDEoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQsIGVtcHR5KSB7XG5cdHJldHVybiBjcmVhdGVPYmplY3ROb2RlKGlkLCBjdXJyZW50LCBlbXB0eSwgYXdhaXQgcGFyc2VQcm9wZXJ0aWVzJDEoY3R4LCBkZXB0aCwgY3VycmVudCkpO1xufVxuYXN5bmMgZnVuY3Rpb24gcGFyc2VCb3hlZCQxKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KSB7XG5cdHJldHVybiBjcmVhdGVCb3hlZE5vZGUoaWQsIGF3YWl0IHBhcnNlQXN5bmMoY3R4LCBkZXB0aCwgY3VycmVudC52YWx1ZU9mKCkpKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHBhcnNlVHlwZWRBcnJheSQxKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KSB7XG5cdGN1cnJlbnQgPSBnZXRBcnJheUJ1ZmZlclZpZXcoY3R4LmJhc2UsIGN1cnJlbnQpO1xuXHRyZXR1cm4gY3JlYXRlVHlwZWRBcnJheU5vZGUoaWQsIGN1cnJlbnQsIGF3YWl0IHBhcnNlQXN5bmMoY3R4LCBkZXB0aCwgY3VycmVudC5idWZmZXIpKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHBhcnNlQmlnSW50VHlwZWRBcnJheSQxKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KSB7XG5cdGN1cnJlbnQgPSBnZXRBcnJheUJ1ZmZlclZpZXcoY3R4LmJhc2UsIGN1cnJlbnQpO1xuXHRyZXR1cm4gY3JlYXRlQmlnSW50VHlwZWRBcnJheU5vZGUoaWQsIGN1cnJlbnQsIGF3YWl0IHBhcnNlQXN5bmMoY3R4LCBkZXB0aCwgY3VycmVudC5idWZmZXIpKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHBhcnNlRGF0YVZpZXckMShjdHgsIGRlcHRoLCBpZCwgY3VycmVudCkge1xuXHRjdXJyZW50ID0gZ2V0QXJyYXlCdWZmZXJWaWV3KGN0eC5iYXNlLCBjdXJyZW50KTtcblx0cmV0dXJuIGNyZWF0ZURhdGFWaWV3Tm9kZShpZCwgY3VycmVudCwgYXdhaXQgcGFyc2VBc3luYyhjdHgsIGRlcHRoLCBjdXJyZW50LmJ1ZmZlcikpO1xufVxuYXN5bmMgZnVuY3Rpb24gcGFyc2VFcnJvciQxKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KSB7XG5cdGNvbnN0IG9wdGlvbnMgPSBnZXRFcnJvck9wdGlvbnMoY3VycmVudCwgY3R4LmJhc2UuZmVhdHVyZXMpO1xuXHRyZXR1cm4gY3JlYXRlRXJyb3JOb2RlKGlkLCBjdXJyZW50LCBvcHRpb25zID8gYXdhaXQgcGFyc2VQcm9wZXJ0aWVzJDEoY3R4LCBkZXB0aCwgb3B0aW9ucykgOiB2b2lkIDApO1xufVxuYXN5bmMgZnVuY3Rpb24gcGFyc2VBZ2dyZWdhdGVFcnJvciQxKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KSB7XG5cdGNvbnN0IG9wdGlvbnMgPSBnZXRFcnJvck9wdGlvbnMoY3VycmVudCwgY3R4LmJhc2UuZmVhdHVyZXMpO1xuXHRyZXR1cm4gY3JlYXRlQWdncmVnYXRlRXJyb3JOb2RlKGlkLCBjdXJyZW50LCBvcHRpb25zID8gYXdhaXQgcGFyc2VQcm9wZXJ0aWVzJDEoY3R4LCBkZXB0aCwgb3B0aW9ucykgOiB2b2lkIDApO1xufVxuYXN5bmMgZnVuY3Rpb24gcGFyc2VNYXAkMShjdHgsIGRlcHRoLCBpZCwgY3VycmVudCkge1xuXHRjb25zdCBrZXlOb2RlcyA9IFtdO1xuXHRjb25zdCB2YWx1ZU5vZGVzID0gW107XG5cdGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIGN1cnJlbnQuZW50cmllcygpKSB7XG5cdFx0a2V5Tm9kZXMucHVzaChhd2FpdCBwYXJzZUFzeW5jKGN0eCwgZGVwdGgsIGtleSkpO1xuXHRcdHZhbHVlTm9kZXMucHVzaChhd2FpdCBwYXJzZUFzeW5jKGN0eCwgZGVwdGgsIHZhbHVlKSk7XG5cdH1cblx0cmV0dXJuIGNyZWF0ZU1hcE5vZGUoY3R4LmJhc2UsIGlkLCBrZXlOb2RlcywgdmFsdWVOb2Rlcyk7XG59XG5hc3luYyBmdW5jdGlvbiBwYXJzZVNldCQxKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KSB7XG5cdGNvbnN0IGl0ZW1zID0gW107XG5cdGZvciAoY29uc3QgaXRlbSBvZiBjdXJyZW50LmtleXMoKSkgaXRlbXMucHVzaChhd2FpdCBwYXJzZUFzeW5jKGN0eCwgZGVwdGgsIGl0ZW0pKTtcblx0cmV0dXJuIGNyZWF0ZVNldE5vZGUoaWQsIGl0ZW1zKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHBhcnNlUGx1Z2luJDEoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpIHtcblx0Y29uc3QgY3VycmVudFBsdWdpbnMgPSBjdHguYmFzZS5wbHVnaW5zO1xuXHRpZiAoY3VycmVudFBsdWdpbnMpIGZvciAobGV0IGkgPSAwLCBsZW4gPSBjdXJyZW50UGx1Z2lucy5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuXHRcdGNvbnN0IHBsdWdpbiA9IGN1cnJlbnRQbHVnaW5zW2ldO1xuXHRcdGlmIChwbHVnaW4ucGFyc2UuYXN5bmMgJiYgcGx1Z2luLnRlc3QoY3VycmVudCkpIHJldHVybiBjcmVhdGVQbHVnaW5Ob2RlKGlkLCBwbHVnaW4udGFnLCBhd2FpdCBwbHVnaW4ucGFyc2UuYXN5bmMoY3VycmVudCwgbmV3IEFzeW5jUGFyc2VQbHVnaW5Db250ZXh0KGN0eCwgZGVwdGgpLCB7IGlkIH0pKTtcblx0fVxufVxuYXN5bmMgZnVuY3Rpb24gcGFyc2VQcm9taXNlJDEoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpIHtcblx0Y29uc3QgW3N0YXR1cywgcmVzdWx0XSA9IGF3YWl0IHByb21pc2VUb1Jlc3VsdChjdXJyZW50KTtcblx0cmV0dXJuIGNyZWF0ZVNlcm92YWxOb2RlKDEyLCBpZCwgc3RhdHVzLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgYXdhaXQgcGFyc2VBc3luYyhjdHgsIGRlcHRoLCByZXN1bHQpLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIHBhcnNlU3RyZWFtSGFuZGxlKGRlcHRoLCBpZCwgY3VycmVudCwgcmVzb2x2ZSwgcmVqZWN0KSB7XG5cdGNvbnN0IHNlcXVlbmNlID0gW107XG5cdGNvbnN0IGNsZWFudXAgPSBjdXJyZW50Lm9uKHtcblx0XHRuZXh0OiAodmFsdWUpID0+IHtcblx0XHRcdG1hcmtQYXJzZXJSZWYodGhpcy5iYXNlLCBpZCk7XG5cdFx0XHRwYXJzZUFzeW5jKHRoaXMsIGRlcHRoLCB2YWx1ZSkudGhlbigoZGF0YSkgPT4ge1xuXHRcdFx0XHRzZXF1ZW5jZS5wdXNoKGNyZWF0ZVN0cmVhbU5leHROb2RlKGlkLCBkYXRhKSk7XG5cdFx0XHR9LCAoZGF0YSkgPT4ge1xuXHRcdFx0XHRyZWplY3QoZGF0YSk7XG5cdFx0XHRcdGNsZWFudXAoKTtcblx0XHRcdH0pO1xuXHRcdH0sXG5cdFx0dGhyb3c6ICh2YWx1ZSkgPT4ge1xuXHRcdFx0bWFya1BhcnNlclJlZih0aGlzLmJhc2UsIGlkKTtcblx0XHRcdHBhcnNlQXN5bmModGhpcywgZGVwdGgsIHZhbHVlKS50aGVuKChkYXRhKSA9PiB7XG5cdFx0XHRcdHNlcXVlbmNlLnB1c2goY3JlYXRlU3RyZWFtVGhyb3dOb2RlKGlkLCBkYXRhKSk7XG5cdFx0XHRcdHJlc29sdmUoc2VxdWVuY2UpO1xuXHRcdFx0XHRjbGVhbnVwKCk7XG5cdFx0XHR9LCAoZGF0YSkgPT4ge1xuXHRcdFx0XHRyZWplY3QoZGF0YSk7XG5cdFx0XHRcdGNsZWFudXAoKTtcblx0XHRcdH0pO1xuXHRcdH0sXG5cdFx0cmV0dXJuOiAodmFsdWUpID0+IHtcblx0XHRcdG1hcmtQYXJzZXJSZWYodGhpcy5iYXNlLCBpZCk7XG5cdFx0XHRwYXJzZUFzeW5jKHRoaXMsIGRlcHRoLCB2YWx1ZSkudGhlbigoZGF0YSkgPT4ge1xuXHRcdFx0XHRzZXF1ZW5jZS5wdXNoKGNyZWF0ZVN0cmVhbVJldHVybk5vZGUoaWQsIGRhdGEpKTtcblx0XHRcdFx0cmVzb2x2ZShzZXF1ZW5jZSk7XG5cdFx0XHRcdGNsZWFudXAoKTtcblx0XHRcdH0sIChkYXRhKSA9PiB7XG5cdFx0XHRcdHJlamVjdChkYXRhKTtcblx0XHRcdFx0Y2xlYW51cCgpO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHR9KTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHBhcnNlU3RyZWFtJDEoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpIHtcblx0cmV0dXJuIGNyZWF0ZVN0cmVhbUNvbnN0cnVjdG9yTm9kZShpZCwgcGFyc2VTcGVjaWFsUmVmZXJlbmNlKGN0eC5iYXNlLCA0KSwgYXdhaXQgbmV3IFByb21pc2UocGFyc2VTdHJlYW1IYW5kbGUuYmluZChjdHgsIGRlcHRoLCBpZCwgY3VycmVudCkpKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHBhcnNlU2VxdWVuY2UkMShjdHgsIGRlcHRoLCBpZCwgY3VycmVudCkge1xuXHRjb25zdCBub2RlcyA9IFtdO1xuXHRmb3IgKGxldCBpID0gMCwgbGVuID0gY3VycmVudC52Lmxlbmd0aDsgaSA8IGxlbjsgaSsrKSBub2Rlc1tpXSA9IGF3YWl0IHBhcnNlQXN5bmMoY3R4LCBkZXB0aCwgY3VycmVudC52W2ldKTtcblx0cmV0dXJuIGNyZWF0ZVNlcXVlbmNlTm9kZShpZCwgbm9kZXMsIGN1cnJlbnQudCwgY3VycmVudC5kKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHBhcnNlT2JqZWN0QXN5bmMoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpIHtcblx0aWYgKEFycmF5LmlzQXJyYXkoY3VycmVudCkpIHJldHVybiBwYXJzZUFycmF5JDEoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpO1xuXHRpZiAoaXNTdHJlYW0oY3VycmVudCkpIHJldHVybiBwYXJzZVN0cmVhbSQxKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KTtcblx0aWYgKGlzU2VxdWVuY2UoY3VycmVudCkpIHJldHVybiBwYXJzZVNlcXVlbmNlJDEoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpO1xuXHRsZXQgY3VycmVudENsYXNzID0gY3VycmVudC5jb25zdHJ1Y3Rvcjtcblx0aWYgKGN1cnJlbnRDbGFzcyAhPT0gdm9pZCAwICYmIHR5cGVvZiBjdXJyZW50Q2xhc3MgIT09IFwiZnVuY3Rpb25cIikge1xuXHRcdGNvbnN0IHByb3RvID0gT2JqZWN0LmdldFByb3RvdHlwZU9mKGN1cnJlbnQpO1xuXHRcdGN1cnJlbnRDbGFzcyA9IHByb3RvID09PSBudWxsID8gdm9pZCAwIDogcHJvdG8uY29uc3RydWN0b3I7XG5cdH1cblx0aWYgKGN1cnJlbnRDbGFzcyA9PT0gT3BhcXVlUmVmZXJlbmNlKSByZXR1cm4gcGFyc2VBc3luYyhjdHgsIGRlcHRoLCBjdXJyZW50LnJlcGxhY2VtZW50KTtcblx0Y29uc3QgcGFyc2VkID0gYXdhaXQgcGFyc2VQbHVnaW4kMShjdHgsIGRlcHRoLCBpZCwgY3VycmVudCk7XG5cdGlmIChwYXJzZWQpIHJldHVybiBwYXJzZWQ7XG5cdHN3aXRjaCAoY3VycmVudENsYXNzKSB7XG5cdFx0Y2FzZSBPYmplY3Q6IHJldHVybiBwYXJzZVBsYWluT2JqZWN0JDEoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQsIGZhbHNlKTtcblx0XHRjYXNlIHZvaWQgMDogcmV0dXJuIHBhcnNlUGxhaW5PYmplY3QkMShjdHgsIGRlcHRoLCBpZCwgY3VycmVudCwgdHJ1ZSk7XG5cdFx0Y2FzZSBEYXRlOiByZXR1cm4gY3JlYXRlRGF0ZU5vZGUoaWQsIGN1cnJlbnQpO1xuXHRcdGNhc2UgRXJyb3I6XG5cdFx0Y2FzZSBFdmFsRXJyb3I6XG5cdFx0Y2FzZSBSYW5nZUVycm9yOlxuXHRcdGNhc2UgUmVmZXJlbmNlRXJyb3I6XG5cdFx0Y2FzZSBTeW50YXhFcnJvcjpcblx0XHRjYXNlIFR5cGVFcnJvcjpcblx0XHRjYXNlIFVSSUVycm9yOiByZXR1cm4gcGFyc2VFcnJvciQxKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KTtcblx0XHRjYXNlIE51bWJlcjpcblx0XHRjYXNlIEJvb2xlYW46XG5cdFx0Y2FzZSBTdHJpbmc6XG5cdFx0Y2FzZSBCaWdJbnQ6IHJldHVybiBwYXJzZUJveGVkJDEoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpO1xuXHRcdGNhc2UgQXJyYXlCdWZmZXI6IHJldHVybiBjcmVhdGVBcnJheUJ1ZmZlck5vZGUoY3R4LmJhc2UsIGlkLCBjdXJyZW50KTtcblx0XHRjYXNlIEludDhBcnJheTpcblx0XHRjYXNlIEludDE2QXJyYXk6XG5cdFx0Y2FzZSBJbnQzMkFycmF5OlxuXHRcdGNhc2UgVWludDhBcnJheTpcblx0XHRjYXNlIFVpbnQxNkFycmF5OlxuXHRcdGNhc2UgVWludDMyQXJyYXk6XG5cdFx0Y2FzZSBVaW50OENsYW1wZWRBcnJheTpcblx0XHRjYXNlIEZsb2F0MzJBcnJheTpcblx0XHRjYXNlIEZsb2F0NjRBcnJheTogcmV0dXJuIHBhcnNlVHlwZWRBcnJheSQxKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KTtcblx0XHRjYXNlIERhdGFWaWV3OiByZXR1cm4gcGFyc2VEYXRhVmlldyQxKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KTtcblx0XHRjYXNlIE1hcDogcmV0dXJuIHBhcnNlTWFwJDEoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpO1xuXHRcdGNhc2UgU2V0OiByZXR1cm4gcGFyc2VTZXQkMShjdHgsIGRlcHRoLCBpZCwgY3VycmVudCk7XG5cdH1cblx0aWYgKGN1cnJlbnRDbGFzcyA9PT0gUHJvbWlzZSB8fCBjdXJyZW50IGluc3RhbmNlb2YgUHJvbWlzZSkgcmV0dXJuIHBhcnNlUHJvbWlzZSQxKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KTtcblx0Y29uc3QgY3VycmVudEZlYXR1cmVzID0gY3R4LmJhc2UuZmVhdHVyZXM7XG5cdGlmIChjdXJyZW50RmVhdHVyZXMgJiAzMiAmJiBjdXJyZW50Q2xhc3MgPT09IFJlZ0V4cCkgcmV0dXJuIGNyZWF0ZVJlZ0V4cE5vZGUoaWQsIGN1cnJlbnQpO1xuXHRpZiAoY3VycmVudEZlYXR1cmVzICYgMTYpIHN3aXRjaCAoY3VycmVudENsYXNzKSB7XG5cdFx0Y2FzZSBCaWdJbnQ2NEFycmF5OlxuXHRcdGNhc2UgQmlnVWludDY0QXJyYXk6IHJldHVybiBwYXJzZUJpZ0ludFR5cGVkQXJyYXkkMShjdHgsIGRlcHRoLCBpZCwgY3VycmVudCk7XG5cdH1cblx0aWYgKGN1cnJlbnRGZWF0dXJlcyAmIDEgJiYgdHlwZW9mIEFnZ3JlZ2F0ZUVycm9yICE9PSBcInVuZGVmaW5lZFwiICYmIChjdXJyZW50Q2xhc3MgPT09IEFnZ3JlZ2F0ZUVycm9yIHx8IGN1cnJlbnQgaW5zdGFuY2VvZiBBZ2dyZWdhdGVFcnJvcikpIHJldHVybiBwYXJzZUFnZ3JlZ2F0ZUVycm9yJDEoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpO1xuXHRpZiAoY3VycmVudEZlYXR1cmVzICYgNjQgJiYgdHlwZW9mIFRlbXBvcmFsICE9PSBcInVuZGVmaW5lZFwiKSBzd2l0Y2ggKGN1cnJlbnRDbGFzcykge1xuXHRcdGNhc2UgVGVtcG9yYWwuSW5zdGFudDogcmV0dXJuIGNyZWF0ZVRlbXBvcmFsTm9kZShpZCwgMCwgY3VycmVudCk7XG5cdFx0Y2FzZSBUZW1wb3JhbC5EdXJhdGlvbjogcmV0dXJuIGNyZWF0ZVRlbXBvcmFsTm9kZShpZCwgMSwgY3VycmVudCk7XG5cdFx0Y2FzZSBUZW1wb3JhbC5QbGFpbkRhdGU6IHJldHVybiBjcmVhdGVUZW1wb3JhbE5vZGUoaWQsIDIsIGN1cnJlbnQpO1xuXHRcdGNhc2UgVGVtcG9yYWwuUGxhaW5EYXRlVGltZTogcmV0dXJuIGNyZWF0ZVRlbXBvcmFsTm9kZShpZCwgMywgY3VycmVudCk7XG5cdFx0Y2FzZSBUZW1wb3JhbC5QbGFpbk1vbnRoRGF5OiByZXR1cm4gY3JlYXRlVGVtcG9yYWxOb2RlKGlkLCA0LCBjdXJyZW50KTtcblx0XHRjYXNlIFRlbXBvcmFsLlBsYWluVGltZTogcmV0dXJuIGNyZWF0ZVRlbXBvcmFsTm9kZShpZCwgNSwgY3VycmVudCk7XG5cdFx0Y2FzZSBUZW1wb3JhbC5QbGFpblllYXJNb250aDogcmV0dXJuIGNyZWF0ZVRlbXBvcmFsTm9kZShpZCwgNiwgY3VycmVudCk7XG5cdFx0Y2FzZSBUZW1wb3JhbC5ab25lZERhdGVUaW1lOiByZXR1cm4gY3JlYXRlVGVtcG9yYWxOb2RlKGlkLCA3LCBjdXJyZW50KTtcblx0fVxuXHRpZiAoY3VycmVudCBpbnN0YW5jZW9mIEVycm9yKSByZXR1cm4gcGFyc2VFcnJvciQxKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KTtcblx0aWYgKFNZTV9JVEVSQVRPUiBpbiBjdXJyZW50IHx8IFNZTV9BU1lOQ19JVEVSQVRPUiBpbiBjdXJyZW50KSByZXR1cm4gcGFyc2VQbGFpbk9iamVjdCQxKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50LCAhIWN1cnJlbnRDbGFzcyk7XG5cdHRocm93IG5ldyBTZXJvdmFsVW5zdXBwb3J0ZWRUeXBlRXJyb3IoY3VycmVudCk7XG59XG5hc3luYyBmdW5jdGlvbiBwYXJzZUZ1bmN0aW9uQXN5bmMoY3R4LCBkZXB0aCwgY3VycmVudCkge1xuXHRjb25zdCByZWYgPSBnZXRSZWZlcmVuY2VOb2RlKGN0eC5iYXNlLCBjdXJyZW50KTtcblx0aWYgKHJlZi50eXBlICE9PSAwKSByZXR1cm4gcmVmLnZhbHVlO1xuXHRjb25zdCBwbHVnaW4gPSBhd2FpdCBwYXJzZVBsdWdpbiQxKGN0eCwgZGVwdGgsIHJlZi52YWx1ZSwgY3VycmVudCk7XG5cdGlmIChwbHVnaW4pIHJldHVybiBwbHVnaW47XG5cdHRocm93IG5ldyBTZXJvdmFsVW5zdXBwb3J0ZWRUeXBlRXJyb3IoY3VycmVudCk7XG59XG5hc3luYyBmdW5jdGlvbiBwYXJzZUFzeW5jKGN0eCwgZGVwdGgsIGN1cnJlbnQpIHtcblx0aWYgKGRlcHRoID49IGN0eC5iYXNlLmRlcHRoTGltaXQpIHRocm93IG5ldyBTZXJvdmFsRGVwdGhMaW1pdEVycm9yKGN0eC5iYXNlLmRlcHRoTGltaXQpO1xuXHRzd2l0Y2ggKHR5cGVvZiBjdXJyZW50KSB7XG5cdFx0Y2FzZSBcImJvb2xlYW5cIjogcmV0dXJuIGN1cnJlbnQgPyBUUlVFX05PREUgOiBGQUxTRV9OT0RFO1xuXHRcdGNhc2UgXCJ1bmRlZmluZWRcIjogcmV0dXJuIFVOREVGSU5FRF9OT0RFO1xuXHRcdGNhc2UgXCJzdHJpbmdcIjogcmV0dXJuIGNyZWF0ZVN0cmluZ05vZGUoY3VycmVudCk7XG5cdFx0Y2FzZSBcIm51bWJlclwiOiByZXR1cm4gY3JlYXRlTnVtYmVyTm9kZShjdXJyZW50KTtcblx0XHRjYXNlIFwiYmlnaW50XCI6IHJldHVybiBjcmVhdGVCaWdJbnROb2RlKGN1cnJlbnQpO1xuXHRcdGNhc2UgXCJvYmplY3RcIjpcblx0XHRcdGlmIChjdXJyZW50KSB7XG5cdFx0XHRcdGNvbnN0IHJlZiA9IGdldFJlZmVyZW5jZU5vZGUoY3R4LmJhc2UsIGN1cnJlbnQpO1xuXHRcdFx0XHRyZXR1cm4gcmVmLnR5cGUgPT09IDAgPyBhd2FpdCBwYXJzZU9iamVjdEFzeW5jKGN0eCwgZGVwdGggKyAxLCByZWYudmFsdWUsIGN1cnJlbnQpIDogcmVmLnZhbHVlO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIE5VTExfTk9ERTtcblx0XHRjYXNlIFwic3ltYm9sXCI6IHJldHVybiBwYXJzZVdlbGxLbm93blN5bWJvbChjdHguYmFzZSwgY3VycmVudCk7XG5cdFx0Y2FzZSBcImZ1bmN0aW9uXCI6IHJldHVybiBwYXJzZUZ1bmN0aW9uQXN5bmMoY3R4LCBkZXB0aCwgY3VycmVudCk7XG5cdFx0ZGVmYXVsdDogdGhyb3cgbmV3IFNlcm92YWxVbnN1cHBvcnRlZFR5cGVFcnJvcihjdXJyZW50KTtcblx0fVxufVxuYXN5bmMgZnVuY3Rpb24gcGFyc2VUb3BBc3luYyhjdHgsIGN1cnJlbnQpIHtcblx0dHJ5IHtcblx0XHRyZXR1cm4gYXdhaXQgcGFyc2VBc3luYyhjdHgsIDAsIGN1cnJlbnQpO1xuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdHRocm93IGVycm9yIGluc3RhbmNlb2YgU2Vyb3ZhbFBhcnNlckVycm9yID8gZXJyb3IgOiBuZXcgU2Vyb3ZhbFBhcnNlckVycm9yKGVycm9yKTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvcGx1Z2luLnRzXG5sZXQgU2Vyb3ZhbE1vZGUgPSAvKiBAX19QVVJFX18gKi8gZnVuY3Rpb24oU2Vyb3ZhbE1vZGUpIHtcblx0U2Vyb3ZhbE1vZGVbU2Vyb3ZhbE1vZGVbXCJWYW5pbGxhXCJdID0gMV0gPSBcIlZhbmlsbGFcIjtcblx0U2Vyb3ZhbE1vZGVbU2Vyb3ZhbE1vZGVbXCJDcm9zc1wiXSA9IDJdID0gXCJDcm9zc1wiO1xuXHRyZXR1cm4gU2Vyb3ZhbE1vZGU7XG59KHt9KTtcbmZ1bmN0aW9uIGNyZWF0ZVBsdWdpbihwbHVnaW4pIHtcblx0cmV0dXJuIHBsdWdpbjtcbn1cbmZ1bmN0aW9uIGRlZHVwZVBsdWdpbnMoZGVkdXBlZCwgcGx1Z2lucykge1xuXHRmb3IgKGxldCBpID0gMCwgbGVuID0gcGx1Z2lucy5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuXHRcdGNvbnN0IGN1cnJlbnQgPSBwbHVnaW5zW2ldO1xuXHRcdGlmICghZGVkdXBlZC5oYXMoY3VycmVudCkpIHtcblx0XHRcdGRlZHVwZWQuYWRkKGN1cnJlbnQpO1xuXHRcdFx0aWYgKGN1cnJlbnQuZXh0ZW5kcykgZGVkdXBlUGx1Z2lucyhkZWR1cGVkLCBjdXJyZW50LmV4dGVuZHMpO1xuXHRcdH1cblx0fVxufVxuZnVuY3Rpb24gcmVzb2x2ZVBsdWdpbnMocGx1Z2lucykge1xuXHRpZiAocGx1Z2lucykge1xuXHRcdGNvbnN0IGRlZHVwZWQgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdGRlZHVwZVBsdWdpbnMoZGVkdXBlZCwgcGx1Z2lucyk7XG5cdFx0cmV0dXJuIFsuLi5kZWR1cGVkXTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvdXRpbHMvdHlwZWQtYXJyYXkudHNcbmZ1bmN0aW9uIGdldFR5cGVkQXJyYXlDb25zdHJ1Y3RvcihuYW1lKSB7XG5cdHN3aXRjaCAobmFtZSkge1xuXHRcdGNhc2UgXCJJbnQ4QXJyYXlcIjogcmV0dXJuIEludDhBcnJheTtcblx0XHRjYXNlIFwiSW50MTZBcnJheVwiOiByZXR1cm4gSW50MTZBcnJheTtcblx0XHRjYXNlIFwiSW50MzJBcnJheVwiOiByZXR1cm4gSW50MzJBcnJheTtcblx0XHRjYXNlIFwiVWludDhBcnJheVwiOiByZXR1cm4gVWludDhBcnJheTtcblx0XHRjYXNlIFwiVWludDE2QXJyYXlcIjogcmV0dXJuIFVpbnQxNkFycmF5O1xuXHRcdGNhc2UgXCJVaW50MzJBcnJheVwiOiByZXR1cm4gVWludDMyQXJyYXk7XG5cdFx0Y2FzZSBcIlVpbnQ4Q2xhbXBlZEFycmF5XCI6IHJldHVybiBVaW50OENsYW1wZWRBcnJheTtcblx0XHRjYXNlIFwiRmxvYXQzMkFycmF5XCI6IHJldHVybiBGbG9hdDMyQXJyYXk7XG5cdFx0Y2FzZSBcIkZsb2F0NjRBcnJheVwiOiByZXR1cm4gRmxvYXQ2NEFycmF5O1xuXHRcdGNhc2UgXCJCaWdJbnQ2NEFycmF5XCI6IHJldHVybiBCaWdJbnQ2NEFycmF5O1xuXHRcdGNhc2UgXCJCaWdVaW50NjRBcnJheVwiOiByZXR1cm4gQmlnVWludDY0QXJyYXk7XG5cdFx0ZGVmYXVsdDogdGhyb3cgbmV3IFNlcm92YWxVbmtub3duVHlwZWRBcnJheUVycm9yKG5hbWUpO1xuXHR9XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS91dGlscy92YWxpZC1wcm9wZXJ0aWVzLnRzXG5mdW5jdGlvbiBpc1ZhbGlkS2V5KGtleSkge1xuXHRzd2l0Y2ggKGtleSkge1xuXHRcdGNhc2UgXCJjb25zdHJ1Y3RvclwiOlxuXHRcdGNhc2UgXCJfX3Byb3RvX19cIjpcblx0XHRjYXNlIFwicHJvdG90eXBlXCI6XG5cdFx0Y2FzZSBcIl9fZGVmaW5lR2V0dGVyX19cIjpcblx0XHRjYXNlIFwiX19kZWZpbmVTZXR0ZXJfX1wiOlxuXHRcdGNhc2UgXCJfX2xvb2t1cEdldHRlcl9fXCI6XG5cdFx0Y2FzZSBcIl9fbG9va3VwU2V0dGVyX19cIjogcmV0dXJuIGZhbHNlO1xuXHRcdGRlZmF1bHQ6IHJldHVybiB0cnVlO1xuXHR9XG59XG5mdW5jdGlvbiBpc1ZhbGlkU3ltYm9sKHN5bWJvbCkge1xuXHRzd2l0Y2ggKHN5bWJvbCkge1xuXHRcdGNhc2UgU1lNX0FTWU5DX0lURVJBVE9SOlxuXHRcdGNhc2UgU1lNX0lTX0NPTkNBVF9TUFJFQURBQkxFOlxuXHRcdGNhc2UgU1lNX1RPX1NUUklOR19UQUc6XG5cdFx0Y2FzZSBTWU1fSVRFUkFUT1I6IHJldHVybiB0cnVlO1xuXHRcdGRlZmF1bHQ6IHJldHVybiBmYWxzZTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29udGV4dC9kZXNlcmlhbGl6ZXIudHNcbmNvbnN0IERFRkFVTFRfTUFYX0JBU0U2NF9MRU5HVEggPSAxZTY7XG5jb25zdCBNSU5fTkFUSVZFX0JBU0U2NF9MRU5HVEggPSA1MTI7XG5jb25zdCBNQVhfQklHSU5UX0xFTkdUSCA9IDFlNDtcbmNvbnN0IE1BWF9SRUdFWFBfU09VUkNFX0xFTkdUSCA9IDJlNDtcbmZ1bmN0aW9uIGFwcGx5T2JqZWN0RmxhZyhvYmosIGZsYWcpIHtcblx0c3dpdGNoIChmbGFnKSB7XG5cdFx0Y2FzZSAzOiByZXR1cm4gT2JqZWN0LmZyZWV6ZShvYmopO1xuXHRcdGNhc2UgMTogcmV0dXJuIE9iamVjdC5wcmV2ZW50RXh0ZW5zaW9ucyhvYmopO1xuXHRcdGNhc2UgMjogcmV0dXJuIE9iamVjdC5zZWFsKG9iaik7XG5cdFx0ZGVmYXVsdDogcmV0dXJuIG9iajtcblx0fVxufVxuY29uc3QgREVGQVVMVF9ERVBUSF9MSU1JVCA9IDFlMztcbmZ1bmN0aW9uIGNyZWF0ZUJhc2VEZXNlcmlhbGl6ZXJDb250ZXh0KG1vZGUsIG9wdGlvbnMpIHtcblx0dmFyIF9vcHRpb25zJG1heEJhc2U2NExlbiwgX29wdGlvbnMkZmVhdHVyZXM7XG5cdGNvbnN0IG1heEJhc2U2NExlbmd0aCA9IChfb3B0aW9ucyRtYXhCYXNlNjRMZW4gPSBvcHRpb25zLm1heEJhc2U2NExlbmd0aCkgIT09IG51bGwgJiYgX29wdGlvbnMkbWF4QmFzZTY0TGVuICE9PSB2b2lkIDAgPyBfb3B0aW9ucyRtYXhCYXNlNjRMZW4gOiBERUZBVUxUX01BWF9CQVNFNjRfTEVOR1RIO1xuXHRpZiAoIU51bWJlci5pc1NhZmVJbnRlZ2VyKG1heEJhc2U2NExlbmd0aCkgfHwgbWF4QmFzZTY0TGVuZ3RoIDwgMCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoXCJtYXhCYXNlNjRMZW5ndGggbXVzdCBiZSBhIG5vbi1uZWdhdGl2ZSBzYWZlIGludGVnZXJcIik7XG5cdGNvbnN0IHJlZnMgPSBvcHRpb25zLnJlZnMgfHwgLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0aWYgKCEoXCJ0eXBlc1wiIGluIHJlZnMpKSBPYmplY3QuYXNzaWduKHJlZnMsIHsgdHlwZXM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCkgfSk7XG5cdHJldHVybiB7XG5cdFx0bW9kZSxcblx0XHRwbHVnaW5zOiBvcHRpb25zLnBsdWdpbnMsXG5cdFx0cmVmcyxcblx0XHRmZWF0dXJlczogKF9vcHRpb25zJGZlYXR1cmVzID0gb3B0aW9ucy5mZWF0dXJlcykgIT09IG51bGwgJiYgX29wdGlvbnMkZmVhdHVyZXMgIT09IHZvaWQgMCA/IF9vcHRpb25zJGZlYXR1cmVzIDogMTI3IF4gKG9wdGlvbnMuZGlzYWJsZWRGZWF0dXJlcyB8fCAwKSxcblx0XHRkZXB0aExpbWl0OiBvcHRpb25zLmRlcHRoTGltaXQgfHwgREVGQVVMVF9ERVBUSF9MSU1JVCxcblx0XHRtYXhCYXNlNjRMZW5ndGhcblx0fTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVZhbmlsbGFEZXNlcmlhbGl6ZXJDb250ZXh0KG9wdGlvbnMpIHtcblx0cmV0dXJuIHtcblx0XHRtb2RlOiAxLFxuXHRcdGJhc2U6IGNyZWF0ZUJhc2VEZXNlcmlhbGl6ZXJDb250ZXh0KDEsIG9wdGlvbnMpLFxuXHRcdGNoaWxkOiB2b2lkIDAsXG5cdFx0c3RhdGU6IHsgbWFya2VkOiBuZXcgU2V0KG9wdGlvbnMubWFya2VkUmVmcykgfVxuXHR9O1xufVxuZnVuY3Rpb24gY3JlYXRlQ3Jvc3NEZXNlcmlhbGl6ZXJDb250ZXh0KG9wdGlvbnMpIHtcblx0cmV0dXJuIHtcblx0XHRtb2RlOiAyLFxuXHRcdGJhc2U6IGNyZWF0ZUJhc2VEZXNlcmlhbGl6ZXJDb250ZXh0KDIsIG9wdGlvbnMpLFxuXHRcdGNoaWxkOiB2b2lkIDBcblx0fTtcbn1cbnZhciBEZXNlcmlhbGl6ZVBsdWdpbkNvbnRleHQgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKF9wLCBkZXB0aCkge1xuXHRcdHRoaXMuX3AgPSBfcDtcblx0XHR0aGlzLmRlcHRoID0gZGVwdGg7XG5cdH1cblx0ZGVzZXJpYWxpemUobm9kZSkge1xuXHRcdHJldHVybiBkZXNlcmlhbGl6ZSQxKHRoaXMuX3AsIHRoaXMuZGVwdGgsIG5vZGUpO1xuXHR9XG59O1xuZnVuY3Rpb24gZ3VhcmRJbmRleGVkVmFsdWUoY3R4LCBpZCkge1xuXHRpZiAoaWQgPCAwIHx8ICFOdW1iZXIuaXNGaW5pdGUoaWQpIHx8ICFOdW1iZXIuaXNJbnRlZ2VyKGlkKSkgdGhyb3cgbmV3IFNlcm92YWxNYWxmb3JtZWROb2RlRXJyb3Ioe1xuXHRcdHQ6IDQsXG5cdFx0aTogaWRcblx0fSk7XG5cdGlmIChjdHgucmVmcy5oYXMoaWQpKSB0aHJvdyBuZXcgRXJyb3IoXCJDb25mbGljdGVkIHJlZiBpZDogXCIgKyBpZCk7XG59XG5mdW5jdGlvbiBpc1RoZW5uYWJsZSh2YWx1ZSkge1xuXHRyZXR1cm4gISF2YWx1ZSAmJiB0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgXCJ0aGVuXCIgaW4gdmFsdWUgJiYgdHlwZW9mIHZhbHVlLnRoZW4gPT09IFwiZnVuY3Rpb25cIjtcbn1cbmZ1bmN0aW9uIGFzc2lnbkluZGV4ZWRWYWx1ZVZhbmlsbGEoY3R4LCBpZCwgdmFsdWUpIHtcblx0Z3VhcmRJbmRleGVkVmFsdWUoY3R4LmJhc2UsIGlkKTtcblx0aWYgKGN0eC5zdGF0ZS5tYXJrZWQuaGFzKGlkKSkgY3R4LmJhc2UucmVmcy5zZXQoaWQsIHZhbHVlKTtcblx0cmV0dXJuIHZhbHVlO1xufVxuZnVuY3Rpb24gYXNzaWduSW5kZXhlZFZhbHVlQ3Jvc3MoY3R4LCBpZCwgdmFsdWUpIHtcblx0Z3VhcmRJbmRleGVkVmFsdWUoY3R4LmJhc2UsIGlkKTtcblx0Y3R4LmJhc2UucmVmcy5zZXQoaWQsIHZhbHVlKTtcblx0cmV0dXJuIHZhbHVlO1xufVxuZnVuY3Rpb24gYXNzaWduSW5kZXhlZFZhbHVlJDEoY3R4LCBpZCwgdmFsdWUpIHtcblx0cmV0dXJuIGN0eC5tb2RlID09PSAxID8gYXNzaWduSW5kZXhlZFZhbHVlVmFuaWxsYShjdHgsIGlkLCB2YWx1ZSkgOiBhc3NpZ25JbmRleGVkVmFsdWVDcm9zcyhjdHgsIGlkLCB2YWx1ZSk7XG59XG5mdW5jdGlvbiBkZXNlcmlhbGl6ZUtub3duVmFsdWUobm9kZSwgcmVjb3JkLCBrZXkpIHtcblx0aWYgKE9iamVjdC5oYXNPd24ocmVjb3JkLCBrZXkpKSByZXR1cm4gcmVjb3JkW2tleV07XG5cdHRocm93IG5ldyBTZXJvdmFsTWFsZm9ybWVkTm9kZUVycm9yKG5vZGUpO1xufVxuZnVuY3Rpb24gZGVzZXJpYWxpemVSZWZlcmVuY2UoY3R4LCBub2RlKSB7XG5cdHJldHVybiBhc3NpZ25JbmRleGVkVmFsdWUkMShjdHgsIG5vZGUuaSwgZ2V0UmVmZXJlbmNlKGRlc2VyaWFsaXplU3RyaW5nKG5vZGUucykpKTtcbn1cbmZ1bmN0aW9uIGRlc2VyaWFsaXplQXJyYXkoY3R4LCBkZXB0aCwgbm9kZSkge1xuXHRjb25zdCBpdGVtcyA9IG5vZGUuYTtcblx0Y29uc3QgbGVuID0gaXRlbXMubGVuZ3RoO1xuXHRjb25zdCByZXN1bHQgPSBhc3NpZ25JbmRleGVkVmFsdWUkMShjdHgsIG5vZGUuaSwgbmV3IEFycmF5KGxlbikpO1xuXHRmb3IgKGxldCBpID0gMCwgaXRlbTsgaSA8IGxlbjsgaSsrKSB7XG5cdFx0aXRlbSA9IGl0ZW1zW2ldO1xuXHRcdGlmIChpdGVtKSByZXN1bHRbaV0gPSBkZXNlcmlhbGl6ZSQxKGN0eCwgZGVwdGgsIGl0ZW0pO1xuXHR9XG5cdGFwcGx5T2JqZWN0RmxhZyhyZXN1bHQsIG5vZGUubyk7XG5cdHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBhc3NpZ25TdHJpbmdQcm9wZXJ0eShvYmplY3QsIGtleSwgdmFsdWUpIHtcblx0aWYgKGlzVmFsaWRLZXkoa2V5KSkgb2JqZWN0W2tleV0gPSB2YWx1ZTtcblx0ZWxzZSBPYmplY3QuZGVmaW5lUHJvcGVydHkob2JqZWN0LCBrZXksIHtcblx0XHR2YWx1ZSxcblx0XHRjb25maWd1cmFibGU6IHRydWUsXG5cdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHR3cml0YWJsZTogdHJ1ZVxuXHR9KTtcbn1cbmZ1bmN0aW9uIGFzc2lnblByb3BlcnR5KGN0eCwgZGVwdGgsIG9iamVjdCwga2V5LCB2YWx1ZSkge1xuXHRpZiAodHlwZW9mIGtleSA9PT0gXCJzdHJpbmdcIikgYXNzaWduU3RyaW5nUHJvcGVydHkob2JqZWN0LCBkZXNlcmlhbGl6ZVN0cmluZyhrZXkpLCBkZXNlcmlhbGl6ZSQxKGN0eCwgZGVwdGgsIHZhbHVlKSk7XG5cdGVsc2Uge1xuXHRcdGNvbnN0IGFjdHVhbCA9IGRlc2VyaWFsaXplJDEoY3R4LCBkZXB0aCwga2V5KTtcblx0XHRzd2l0Y2ggKHR5cGVvZiBhY3R1YWwpIHtcblx0XHRcdGNhc2UgXCJzdHJpbmdcIjpcblx0XHRcdFx0YXNzaWduU3RyaW5nUHJvcGVydHkob2JqZWN0LCBhY3R1YWwsIGRlc2VyaWFsaXplJDEoY3R4LCBkZXB0aCwgdmFsdWUpKTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHRjYXNlIFwic3ltYm9sXCI6XG5cdFx0XHRcdGlmIChpc1ZhbGlkU3ltYm9sKGFjdHVhbCkpIG9iamVjdFthY3R1YWxdID0gZGVzZXJpYWxpemUkMShjdHgsIGRlcHRoLCB2YWx1ZSk7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0ZGVmYXVsdDogdGhyb3cgbmV3IFNlcm92YWxNYWxmb3JtZWROb2RlRXJyb3Ioa2V5KTtcblx0XHR9XG5cdH1cbn1cbmZ1bmN0aW9uIGFzc2lnbk5vZGVUeXBlKGN0eCwgaWQsIHR5cGUpIHtcblx0Y3R4LmJhc2UucmVmcy50eXBlcy5zZXQoaWQsIHR5cGUpO1xufVxuZnVuY3Rpb24gdmFsaWRhdGVOb2RlVHlwZShjdHgsIG5vZGUsIGlkLCB0eXBlKSB7XG5cdGlmIChjdHguYmFzZS5yZWZzLnR5cGVzLmdldChpZCkgIT09IHR5cGUpIHRocm93IG5ldyBTZXJvdmFsTWFsZm9ybWVkTm9kZUVycm9yKG5vZGUpO1xufVxuZnVuY3Rpb24gZGVzZXJpYWxpemVQcm9wZXJ0aWVzKGN0eCwgZGVwdGgsIG5vZGUsIHJlc3VsdCkge1xuXHRjb25zdCBrZXlzID0gbm9kZS5rO1xuXHRpZiAoa2V5cy5sZW5ndGggPiAwKSBmb3IgKGxldCBpID0gMCwgdmFscyA9IG5vZGUudiwgbGVuID0ga2V5cy5sZW5ndGg7IGkgPCBsZW47IGkrKykgYXNzaWduUHJvcGVydHkoY3R4LCBkZXB0aCwgcmVzdWx0LCBrZXlzW2ldLCB2YWxzW2ldKTtcblx0cmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGRlc2VyaWFsaXplT2JqZWN0KGN0eCwgZGVwdGgsIG5vZGUpIHtcblx0Y29uc3QgcmVzdWx0ID0gYXNzaWduSW5kZXhlZFZhbHVlJDEoY3R4LCBub2RlLmksIG5vZGUudCA9PT0gMTAgPyB7fSA6IE9iamVjdC5jcmVhdGUobnVsbCkpO1xuXHRkZXNlcmlhbGl6ZVByb3BlcnRpZXMoY3R4LCBkZXB0aCwgbm9kZS5wLCByZXN1bHQpO1xuXHRhcHBseU9iamVjdEZsYWcocmVzdWx0LCBub2RlLm8pO1xuXHRyZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gZGVzZXJpYWxpemVEYXRlKGN0eCwgbm9kZSkge1xuXHRyZXR1cm4gYXNzaWduSW5kZXhlZFZhbHVlJDEoY3R4LCBub2RlLmksIG5ldyBEYXRlKG5vZGUucykpO1xufVxuZnVuY3Rpb24gZGVzZXJpYWxpemVUZW1wb3JhbChjdHgsIG5vZGUpIHtcblx0aWYgKCEoY3R4LmJhc2UuZmVhdHVyZXMgJiA2NCkpIHRocm93IG5ldyBTZXJvdmFsVW5zdXBwb3J0ZWROb2RlRXJyb3Iobm9kZSk7XG5cdGxldCB2YWx1ZTtcblx0c3dpdGNoIChub2RlLmMpIHtcblx0XHRjYXNlIDA6XG5cdFx0XHR2YWx1ZSA9IFRlbXBvcmFsLkluc3RhbnQuZnJvbShub2RlLnMpO1xuXHRcdFx0YnJlYWs7XG5cdFx0Y2FzZSAxOlxuXHRcdFx0dmFsdWUgPSBUZW1wb3JhbC5EdXJhdGlvbi5mcm9tKG5vZGUucyk7XG5cdFx0XHRicmVhaztcblx0XHRjYXNlIDI6XG5cdFx0XHR2YWx1ZSA9IFRlbXBvcmFsLlBsYWluRGF0ZS5mcm9tKG5vZGUucyk7XG5cdFx0XHRicmVhaztcblx0XHRjYXNlIDM6XG5cdFx0XHR2YWx1ZSA9IFRlbXBvcmFsLlBsYWluRGF0ZVRpbWUuZnJvbShub2RlLnMpO1xuXHRcdFx0YnJlYWs7XG5cdFx0Y2FzZSA0OlxuXHRcdFx0dmFsdWUgPSBUZW1wb3JhbC5QbGFpbk1vbnRoRGF5LmZyb20obm9kZS5zKTtcblx0XHRcdGJyZWFrO1xuXHRcdGNhc2UgNTpcblx0XHRcdHZhbHVlID0gVGVtcG9yYWwuUGxhaW5UaW1lLmZyb20obm9kZS5zKTtcblx0XHRcdGJyZWFrO1xuXHRcdGNhc2UgNjpcblx0XHRcdHZhbHVlID0gVGVtcG9yYWwuUGxhaW5ZZWFyTW9udGguZnJvbShub2RlLnMpO1xuXHRcdFx0YnJlYWs7XG5cdFx0Y2FzZSA3OlxuXHRcdFx0dmFsdWUgPSBUZW1wb3JhbC5ab25lZERhdGVUaW1lLmZyb20obm9kZS5zKTtcblx0XHRcdGJyZWFrO1xuXHRcdGRlZmF1bHQ6IHRocm93IG5ldyBTZXJvdmFsTWFsZm9ybWVkTm9kZUVycm9yKG5vZGUpO1xuXHR9XG5cdHJldHVybiBhc3NpZ25JbmRleGVkVmFsdWUkMShjdHgsIG5vZGUuaSwgdmFsdWUpO1xufVxuZnVuY3Rpb24gZGVzZXJpYWxpemVSZWdFeHAoY3R4LCBub2RlKSB7XG5cdGlmIChjdHguYmFzZS5mZWF0dXJlcyAmIDMyKSB7XG5cdFx0Y29uc3Qgc291cmNlID0gZGVzZXJpYWxpemVTdHJpbmcobm9kZS5jKTtcblx0XHRpZiAoc291cmNlLmxlbmd0aCA+IE1BWF9SRUdFWFBfU09VUkNFX0xFTkdUSCkgdGhyb3cgbmV3IFNlcm92YWxNYWxmb3JtZWROb2RlRXJyb3Iobm9kZSk7XG5cdFx0cmV0dXJuIGFzc2lnbkluZGV4ZWRWYWx1ZSQxKGN0eCwgbm9kZS5pLCBuZXcgUmVnRXhwKHNvdXJjZSwgbm9kZS5tKSk7XG5cdH1cblx0dGhyb3cgbmV3IFNlcm92YWxVbnN1cHBvcnRlZE5vZGVFcnJvcihub2RlKTtcbn1cbmZ1bmN0aW9uIGRlc2VyaWFsaXplU2V0KGN0eCwgZGVwdGgsIG5vZGUpIHtcblx0Y29uc3QgcmVzdWx0ID0gYXNzaWduSW5kZXhlZFZhbHVlJDEoY3R4LCBub2RlLmksIC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCkpO1xuXHRmb3IgKGxldCBpID0gMCwgaXRlbXMgPSBub2RlLmEsIGxlbiA9IGl0ZW1zLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSByZXN1bHQuYWRkKGRlc2VyaWFsaXplJDEoY3R4LCBkZXB0aCwgaXRlbXNbaV0pKTtcblx0cmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGRlc2VyaWFsaXplTWFwKGN0eCwgZGVwdGgsIG5vZGUpIHtcblx0Y29uc3QgcmVzdWx0ID0gYXNzaWduSW5kZXhlZFZhbHVlJDEoY3R4LCBub2RlLmksIC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCkpO1xuXHRmb3IgKGxldCBpID0gMCwga2V5cyA9IG5vZGUuZS5rLCB2YWxzID0gbm9kZS5lLnYsIGxlbiA9IGtleXMubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHJlc3VsdC5zZXQoZGVzZXJpYWxpemUkMShjdHgsIGRlcHRoLCBrZXlzW2ldKSwgZGVzZXJpYWxpemUkMShjdHgsIGRlcHRoLCB2YWxzW2ldKSk7XG5cdHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBkZXNlcmlhbGl6ZUFycmF5QnVmZmVyKGN0eCwgbm9kZSkge1xuXHRpZiAodHlwZW9mIG5vZGUucyAhPT0gXCJzdHJpbmdcIikgdGhyb3cgbmV3IFNlcm92YWxNYWxmb3JtZWROb2RlRXJyb3Iobm9kZSk7XG5cdGlmIChub2RlLnMubGVuZ3RoID4gY3R4LmJhc2UubWF4QmFzZTY0TGVuZ3RoKSB0aHJvdyBuZXcgUmFuZ2VFcnJvcihcIkFycmF5QnVmZmVyIGV4Y2VlZHMgbWF4QmFzZTY0TGVuZ3RoIChcIiArIGN0eC5iYXNlLm1heEJhc2U2NExlbmd0aCArIFwiKVwiKTtcblx0Y29uc3Qgc291cmNlID0gZGVzZXJpYWxpemVTdHJpbmcobm9kZS5zKTtcblx0bGV0IGJ1ZmZlcjtcblx0aWYgKHNvdXJjZS5sZW5ndGggPCBNSU5fTkFUSVZFX0JBU0U2NF9MRU5HVEggfHwgdHlwZW9mIEJ1ZmZlciA9PT0gXCJ1bmRlZmluZWRcIikgYnVmZmVyID0gQVJSQVlfQlVGRkVSX0NPTlNUUlVDVE9SKHNvdXJjZSk7XG5cdGVsc2Uge1xuXHRcdGNvbnN0IGRlY29kZWQgPSBhdG9iKHNvdXJjZSk7XG5cdFx0YnVmZmVyID0gbmV3IEFycmF5QnVmZmVyKGRlY29kZWQubGVuZ3RoKTtcblx0XHRCdWZmZXIuZnJvbShidWZmZXIpLndyaXRlKGRlY29kZWQsIFwibGF0aW4xXCIpO1xuXHR9XG5cdHJldHVybiBhc3NpZ25JbmRleGVkVmFsdWUkMShjdHgsIG5vZGUuaSwgYnVmZmVyKTtcbn1cbmZ1bmN0aW9uIGRlc2VyaWFsaXplVHlwZWRBcnJheShjdHgsIGRlcHRoLCBub2RlKSB7XG5cdHZhciBfbm9kZSRiO1xuXHRjb25zdCBjb25zdHJ1Y3QgPSBnZXRUeXBlZEFycmF5Q29uc3RydWN0b3Iobm9kZS5jKTtcblx0Y29uc3Qgc291cmNlID0gZGVzZXJpYWxpemUkMShjdHgsIGRlcHRoLCBub2RlLmYpO1xuXHRpZiAoIShzb3VyY2UgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlcikpIHRocm93IG5ldyBTZXJvdmFsTWFsZm9ybWVkTm9kZUVycm9yKG5vZGUpO1xuXHRjb25zdCBvZmZzZXQgPSAoX25vZGUkYiA9IG5vZGUuYikgIT09IG51bGwgJiYgX25vZGUkYiAhPT0gdm9pZCAwID8gX25vZGUkYiA6IDA7XG5cdGlmIChvZmZzZXQgPCAwIHx8IG9mZnNldCA+IHNvdXJjZS5ieXRlTGVuZ3RoKSB0aHJvdyBuZXcgU2Vyb3ZhbE1hbGZvcm1lZE5vZGVFcnJvcihub2RlKTtcblx0cmV0dXJuIGFzc2lnbkluZGV4ZWRWYWx1ZSQxKGN0eCwgbm9kZS5pLCBuZXcgY29uc3RydWN0KHNvdXJjZSwgb2Zmc2V0LCBub2RlLmwpKTtcbn1cbmZ1bmN0aW9uIGRlc2VyaWFsaXplRGF0YVZpZXcoY3R4LCBkZXB0aCwgbm9kZSkge1xuXHR2YXIgX25vZGUkYjI7XG5cdGNvbnN0IHNvdXJjZSA9IGRlc2VyaWFsaXplJDEoY3R4LCBkZXB0aCwgbm9kZS5mKTtcblx0aWYgKCEoc291cmNlIGluc3RhbmNlb2YgQXJyYXlCdWZmZXIpKSB0aHJvdyBuZXcgU2Vyb3ZhbE1hbGZvcm1lZE5vZGVFcnJvcihub2RlKTtcblx0Y29uc3Qgb2Zmc2V0ID0gKF9ub2RlJGIyID0gbm9kZS5iKSAhPT0gbnVsbCAmJiBfbm9kZSRiMiAhPT0gdm9pZCAwID8gX25vZGUkYjIgOiAwO1xuXHRpZiAob2Zmc2V0IDwgMCB8fCBvZmZzZXQgPiBzb3VyY2UuYnl0ZUxlbmd0aCkgdGhyb3cgbmV3IFNlcm92YWxNYWxmb3JtZWROb2RlRXJyb3Iobm9kZSk7XG5cdHJldHVybiBhc3NpZ25JbmRleGVkVmFsdWUkMShjdHgsIG5vZGUuaSwgbmV3IERhdGFWaWV3KHNvdXJjZSwgb2Zmc2V0LCBub2RlLmwpKTtcbn1cbmZ1bmN0aW9uIGRlc2VyaWFsaXplRGljdGlvbmFyeShjdHgsIGRlcHRoLCBub2RlLCByZXN1bHQpIHtcblx0aWYgKG5vZGUucCkge1xuXHRcdGNvbnN0IGZpZWxkcyA9IGRlc2VyaWFsaXplUHJvcGVydGllcyhjdHgsIGRlcHRoLCBub2RlLnAsIHt9KTtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydGllcyhyZXN1bHQsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKGZpZWxkcykpO1xuXHR9XG5cdHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBkZXNlcmlhbGl6ZUFnZ3JlZ2F0ZUVycm9yKGN0eCwgZGVwdGgsIG5vZGUpIHtcblx0cmV0dXJuIGRlc2VyaWFsaXplRGljdGlvbmFyeShjdHgsIGRlcHRoLCBub2RlLCBhc3NpZ25JbmRleGVkVmFsdWUkMShjdHgsIG5vZGUuaSwgbmV3IEFnZ3JlZ2F0ZUVycm9yKFtdLCBkZXNlcmlhbGl6ZVN0cmluZyhub2RlLm0pKSkpO1xufVxuZnVuY3Rpb24gZGVzZXJpYWxpemVFcnJvcihjdHgsIGRlcHRoLCBub2RlKSB7XG5cdGNvbnN0IGNvbnN0cnVjdCA9IGRlc2VyaWFsaXplS25vd25WYWx1ZShub2RlLCBFUlJPUl9DT05TVFJVQ1RPUiwgbm9kZS5zKTtcblx0cmV0dXJuIGRlc2VyaWFsaXplRGljdGlvbmFyeShjdHgsIGRlcHRoLCBub2RlLCBhc3NpZ25JbmRleGVkVmFsdWUkMShjdHgsIG5vZGUuaSwgbmV3IGNvbnN0cnVjdChkZXNlcmlhbGl6ZVN0cmluZyhub2RlLm0pKSkpO1xufVxuZnVuY3Rpb24gZGVzZXJpYWxpemVQcm9taXNlKGN0eCwgZGVwdGgsIG5vZGUpIHtcblx0Y29uc3QgZGVmZXJyZWQgPSBQUk9NSVNFX0NPTlNUUlVDVE9SKCk7XG5cdGNvbnN0IHJlc3VsdCA9IGFzc2lnbkluZGV4ZWRWYWx1ZSQxKGN0eCwgbm9kZS5pLCBkZWZlcnJlZC5wKTtcblx0Y29uc3QgZGVzZXJpYWxpemVkID0gZGVzZXJpYWxpemUkMShjdHgsIGRlcHRoLCBub2RlLmYpO1xuXHRpZiAoaXNUaGVubmFibGUoZGVzZXJpYWxpemVkKSkgdGhyb3cgbmV3IFNlcm92YWxNYWxmb3JtZWROb2RlRXJyb3Iobm9kZS5mKTtcblx0aWYgKG5vZGUucykgZGVmZXJyZWQucyhkZXNlcmlhbGl6ZWQpO1xuXHRlbHNlIGRlZmVycmVkLmYoZGVzZXJpYWxpemVkKTtcblx0cmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGRlc2VyaWFsaXplQm94ZWQoY3R4LCBkZXB0aCwgbm9kZSkge1xuXHRyZXR1cm4gYXNzaWduSW5kZXhlZFZhbHVlJDEoY3R4LCBub2RlLmksIE9iamVjdChkZXNlcmlhbGl6ZSQxKGN0eCwgZGVwdGgsIG5vZGUuZikpKTtcbn1cbmZ1bmN0aW9uIGRlc2VyaWFsaXplUGx1Z2luKGN0eCwgZGVwdGgsIG5vZGUpIHtcblx0Y29uc3QgY3VycmVudFBsdWdpbnMgPSBjdHguYmFzZS5wbHVnaW5zO1xuXHRpZiAoY3VycmVudFBsdWdpbnMpIHtcblx0XHRjb25zdCB0YWcgPSBkZXNlcmlhbGl6ZVN0cmluZyhub2RlLmMpO1xuXHRcdGZvciAobGV0IGkgPSAwLCBsZW4gPSBjdXJyZW50UGx1Z2lucy5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuXHRcdFx0Y29uc3QgcGx1Z2luID0gY3VycmVudFBsdWdpbnNbaV07XG5cdFx0XHRpZiAocGx1Z2luLnRhZyA9PT0gdGFnKSByZXR1cm4gYXNzaWduSW5kZXhlZFZhbHVlJDEoY3R4LCBub2RlLmksIHBsdWdpbi5kZXNlcmlhbGl6ZShub2RlLnMsIG5ldyBEZXNlcmlhbGl6ZVBsdWdpbkNvbnRleHQoY3R4LCBkZXB0aCksIHsgaWQ6IG5vZGUuaSB9KSk7XG5cdFx0fVxuXHR9XG5cdHRocm93IG5ldyBTZXJvdmFsTWlzc2luZ1BsdWdpbkVycm9yKG5vZGUuYyk7XG59XG5mdW5jdGlvbiBkZXNlcmlhbGl6ZVByb21pc2VDb25zdHJ1Y3RvcihjdHgsIG5vZGUpIHtcblx0Y29uc3QgdmFsdWUgPSBhc3NpZ25JbmRleGVkVmFsdWUkMShjdHgsIG5vZGUuaSwgYXNzaWduSW5kZXhlZFZhbHVlJDEoY3R4LCBub2RlLnMsIFBST01JU0VfQ09OU1RSVUNUT1IoKSkucCk7XG5cdGFzc2lnbk5vZGVUeXBlKGN0eCwgbm9kZS5zLCAyMik7XG5cdHJldHVybiB2YWx1ZTtcbn1cbmZ1bmN0aW9uIGRlc2VyaWFsaXplUHJvbWlzZUZ1bGZpbGwoY3R4LCBkZXB0aCwgbm9kZSkge1xuXHRjb25zdCBkZWZlcnJlZCA9IGN0eC5iYXNlLnJlZnMuZ2V0KG5vZGUuaSk7XG5cdGlmIChkZWZlcnJlZCkge1xuXHRcdHZhbGlkYXRlTm9kZVR5cGUoY3R4LCBub2RlLCBub2RlLmksIDIyKTtcblx0XHRjb25zdCBkZXNlcmlhbGl6ZWQgPSBkZXNlcmlhbGl6ZSQxKGN0eCwgZGVwdGgsIG5vZGUuYVsxXSk7XG5cdFx0aWYgKGlzVGhlbm5hYmxlKGRlc2VyaWFsaXplZCkpIHRocm93IG5ldyBTZXJvdmFsTWFsZm9ybWVkTm9kZUVycm9yKG5vZGUuYVsxXSk7XG5cdFx0aWYgKG5vZGUudCA9PT0gMjMpIGRlZmVycmVkLnMoZGVzZXJpYWxpemVkKTtcblx0XHRlbHNlIGRlZmVycmVkLmYoZGVzZXJpYWxpemVkKTtcblx0XHRyZXR1cm47XG5cdH1cblx0dGhyb3cgbmV3IFNlcm92YWxNaXNzaW5nSW5zdGFuY2VFcnJvcihcIlByb21pc2VcIik7XG59XG5mdW5jdGlvbiBkZXNlcmlhbGl6ZUl0ZXJhdG9yRmFjdG9yeUluc3RhbmNlKGN0eCwgZGVwdGgsIG5vZGUpIHtcblx0ZGVzZXJpYWxpemUkMShjdHgsIGRlcHRoLCBub2RlLmFbMF0pO1xuXHRjb25zdCBzb3VyY2UgPSBkZXNlcmlhbGl6ZSQxKGN0eCwgZGVwdGgsIG5vZGUuYVsxXSk7XG5cdHZhbGlkYXRlTm9kZVR5cGUoY3R4LCBub2RlLCBub2RlLmFbMV0uaSwgMzUpO1xuXHRpZiAoIXNvdXJjZSkgdGhyb3cgbmV3IFNlcm92YWxNYWxmb3JtZWROb2RlRXJyb3Iobm9kZS5hWzFdKTtcblx0cmV0dXJuIHNlcXVlbmNlVG9JdGVyYXRvcihzb3VyY2UpO1xufVxuZnVuY3Rpb24gZGVzZXJpYWxpemVBc3luY0l0ZXJhdG9yRmFjdG9yeUluc3RhbmNlKGN0eCwgZGVwdGgsIG5vZGUpIHtcblx0ZGVzZXJpYWxpemUkMShjdHgsIGRlcHRoLCBub2RlLmFbMF0pO1xuXHRjb25zdCBzb3VyY2UgPSBkZXNlcmlhbGl6ZSQxKGN0eCwgZGVwdGgsIG5vZGUuYVsxXSk7XG5cdHZhbGlkYXRlTm9kZVR5cGUoY3R4LCBub2RlLCBub2RlLmFbMV0uaSwgMzEpO1xuXHRpZiAoIXNvdXJjZSkgdGhyb3cgbmV3IFNlcm92YWxNYWxmb3JtZWROb2RlRXJyb3Iobm9kZS5hWzFdKTtcblx0cmV0dXJuIHN0cmVhbVRvQXN5bmNJdGVyYWJsZShzb3VyY2UpO1xufVxuZnVuY3Rpb24gZGVzZXJpYWxpemVTdHJlYW1Db25zdHJ1Y3RvcihjdHgsIGRlcHRoLCBub2RlKSB7XG5cdGNvbnN0IHJlc3VsdCA9IGFzc2lnbkluZGV4ZWRWYWx1ZSQxKGN0eCwgbm9kZS5pLCBjcmVhdGVTdHJlYW0oKSk7XG5cdGFzc2lnbk5vZGVUeXBlKGN0eCwgbm9kZS5pLCAzMSk7XG5cdGNvbnN0IGl0ZW1zID0gbm9kZS5hO1xuXHRjb25zdCBsZW4gPSBpdGVtcy5sZW5ndGg7XG5cdGlmIChsZW4pIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspIGRlc2VyaWFsaXplJDEoY3R4LCBkZXB0aCwgaXRlbXNbaV0pO1xuXHRyZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gZGVzZXJpYWxpemVTdHJlYW1OZXh0KGN0eCwgZGVwdGgsIG5vZGUpIHtcblx0Y29uc3QgZGVmZXJyZWQgPSBjdHguYmFzZS5yZWZzLmdldChub2RlLmkpO1xuXHRpZiAoZGVmZXJyZWQpIHtcblx0XHR2YWxpZGF0ZU5vZGVUeXBlKGN0eCwgbm9kZSwgbm9kZS5pLCAzMSk7XG5cdFx0ZGVmZXJyZWQubmV4dChkZXNlcmlhbGl6ZSQxKGN0eCwgZGVwdGgsIG5vZGUuZikpO1xuXHRcdHJldHVybjtcblx0fVxuXHR0aHJvdyBuZXcgU2Vyb3ZhbE1pc3NpbmdJbnN0YW5jZUVycm9yKFwiU3RyZWFtXCIpO1xufVxuZnVuY3Rpb24gZGVzZXJpYWxpemVTdHJlYW1UaHJvdyhjdHgsIGRlcHRoLCBub2RlKSB7XG5cdGNvbnN0IGRlZmVycmVkID0gY3R4LmJhc2UucmVmcy5nZXQobm9kZS5pKTtcblx0aWYgKGRlZmVycmVkKSB7XG5cdFx0dmFsaWRhdGVOb2RlVHlwZShjdHgsIG5vZGUsIG5vZGUuaSwgMzEpO1xuXHRcdGRlZmVycmVkLnRocm93KGRlc2VyaWFsaXplJDEoY3R4LCBkZXB0aCwgbm9kZS5mKSk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdHRocm93IG5ldyBTZXJvdmFsTWlzc2luZ0luc3RhbmNlRXJyb3IoXCJTdHJlYW1cIik7XG59XG5mdW5jdGlvbiBkZXNlcmlhbGl6ZVN0cmVhbVJldHVybihjdHgsIGRlcHRoLCBub2RlKSB7XG5cdGNvbnN0IGRlZmVycmVkID0gY3R4LmJhc2UucmVmcy5nZXQobm9kZS5pKTtcblx0aWYgKGRlZmVycmVkKSB7XG5cdFx0dmFsaWRhdGVOb2RlVHlwZShjdHgsIG5vZGUsIG5vZGUuaSwgMzEpO1xuXHRcdGRlZmVycmVkLnJldHVybihkZXNlcmlhbGl6ZSQxKGN0eCwgZGVwdGgsIG5vZGUuZikpO1xuXHRcdHJldHVybjtcblx0fVxuXHR0aHJvdyBuZXcgU2Vyb3ZhbE1pc3NpbmdJbnN0YW5jZUVycm9yKFwiU3RyZWFtXCIpO1xufVxuZnVuY3Rpb24gZGVzZXJpYWxpemVJdGVyYXRvckZhY3RvcnkoY3R4LCBkZXB0aCwgbm9kZSkge1xuXHRkZXNlcmlhbGl6ZSQxKGN0eCwgZGVwdGgsIG5vZGUuZik7XG59XG5mdW5jdGlvbiBkZXNlcmlhbGl6ZUFzeW5jSXRlcmF0b3JGYWN0b3J5KGN0eCwgZGVwdGgsIG5vZGUpIHtcblx0ZGVzZXJpYWxpemUkMShjdHgsIGRlcHRoLCBub2RlLmFbMV0pO1xufVxuZnVuY3Rpb24gZGVzZXJpYWxpemVTZXF1ZW5jZShjdHgsIGRlcHRoLCBub2RlKSB7XG5cdGNvbnN0IHJlc3VsdCA9IGFzc2lnbkluZGV4ZWRWYWx1ZSQxKGN0eCwgbm9kZS5pLCBjcmVhdGVTZXF1ZW5jZShbXSwgbm9kZS5zLCBub2RlLmwpKTtcblx0YXNzaWduTm9kZVR5cGUoY3R4LCBub2RlLmksIDM1KTtcblx0Zm9yIChsZXQgaSA9IDAsIGxlbiA9IG5vZGUuYS5sZW5ndGg7IGkgPCBsZW47IGkrKykgcmVzdWx0LnZbaV0gPSBkZXNlcmlhbGl6ZSQxKGN0eCwgZGVwdGgsIG5vZGUuYVtpXSk7XG5cdHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBkZXNlcmlhbGl6ZSQxKGN0eCwgZGVwdGgsIG5vZGUpIHtcblx0aWYgKGRlcHRoID4gY3R4LmJhc2UuZGVwdGhMaW1pdCkgdGhyb3cgbmV3IFNlcm92YWxEZXB0aExpbWl0RXJyb3IoY3R4LmJhc2UuZGVwdGhMaW1pdCk7XG5cdGRlcHRoICs9IDE7XG5cdHN3aXRjaCAobm9kZS50KSB7XG5cdFx0Y2FzZSAyOiByZXR1cm4gZGVzZXJpYWxpemVLbm93blZhbHVlKG5vZGUsIENPTlNUQU5UX1ZBTCwgbm9kZS5zKTtcblx0XHRjYXNlIDA6IHJldHVybiBOdW1iZXIobm9kZS5zKTtcblx0XHRjYXNlIDE6IHJldHVybiBkZXNlcmlhbGl6ZVN0cmluZyhTdHJpbmcobm9kZS5zKSk7XG5cdFx0Y2FzZSAzOlxuXHRcdFx0aWYgKFN0cmluZyhub2RlLnMpLmxlbmd0aCA+IE1BWF9CSUdJTlRfTEVOR1RIKSB0aHJvdyBuZXcgU2Vyb3ZhbE1hbGZvcm1lZE5vZGVFcnJvcihub2RlKTtcblx0XHRcdHJldHVybiBCaWdJbnQobm9kZS5zKTtcblx0XHRjYXNlIDQ6IHJldHVybiBjdHguYmFzZS5yZWZzLmdldChub2RlLmkpO1xuXHRcdGNhc2UgMTg6IHJldHVybiBkZXNlcmlhbGl6ZVJlZmVyZW5jZShjdHgsIG5vZGUpO1xuXHRcdGNhc2UgOTogcmV0dXJuIGRlc2VyaWFsaXplQXJyYXkoY3R4LCBkZXB0aCwgbm9kZSk7XG5cdFx0Y2FzZSAxMDpcblx0XHRjYXNlIDExOiByZXR1cm4gZGVzZXJpYWxpemVPYmplY3QoY3R4LCBkZXB0aCwgbm9kZSk7XG5cdFx0Y2FzZSA1OiByZXR1cm4gZGVzZXJpYWxpemVEYXRlKGN0eCwgbm9kZSk7XG5cdFx0Y2FzZSA2OiByZXR1cm4gZGVzZXJpYWxpemVSZWdFeHAoY3R4LCBub2RlKTtcblx0XHRjYXNlIDc6IHJldHVybiBkZXNlcmlhbGl6ZVNldChjdHgsIGRlcHRoLCBub2RlKTtcblx0XHRjYXNlIDg6IHJldHVybiBkZXNlcmlhbGl6ZU1hcChjdHgsIGRlcHRoLCBub2RlKTtcblx0XHRjYXNlIDE5OiByZXR1cm4gZGVzZXJpYWxpemVBcnJheUJ1ZmZlcihjdHgsIG5vZGUpO1xuXHRcdGNhc2UgMTY6XG5cdFx0Y2FzZSAxNTogcmV0dXJuIGRlc2VyaWFsaXplVHlwZWRBcnJheShjdHgsIGRlcHRoLCBub2RlKTtcblx0XHRjYXNlIDIwOiByZXR1cm4gZGVzZXJpYWxpemVEYXRhVmlldyhjdHgsIGRlcHRoLCBub2RlKTtcblx0XHRjYXNlIDE0OiByZXR1cm4gZGVzZXJpYWxpemVBZ2dyZWdhdGVFcnJvcihjdHgsIGRlcHRoLCBub2RlKTtcblx0XHRjYXNlIDEzOiByZXR1cm4gZGVzZXJpYWxpemVFcnJvcihjdHgsIGRlcHRoLCBub2RlKTtcblx0XHRjYXNlIDEyOiByZXR1cm4gZGVzZXJpYWxpemVQcm9taXNlKGN0eCwgZGVwdGgsIG5vZGUpO1xuXHRcdGNhc2UgMTc6IHJldHVybiBkZXNlcmlhbGl6ZUtub3duVmFsdWUobm9kZSwgU1lNQk9MX1JFRiwgbm9kZS5zKTtcblx0XHRjYXNlIDIxOiByZXR1cm4gZGVzZXJpYWxpemVCb3hlZChjdHgsIGRlcHRoLCBub2RlKTtcblx0XHRjYXNlIDI1OiByZXR1cm4gZGVzZXJpYWxpemVQbHVnaW4oY3R4LCBkZXB0aCwgbm9kZSk7XG5cdFx0Y2FzZSAyMjogcmV0dXJuIGRlc2VyaWFsaXplUHJvbWlzZUNvbnN0cnVjdG9yKGN0eCwgbm9kZSk7XG5cdFx0Y2FzZSAyMzpcblx0XHRjYXNlIDI0OiByZXR1cm4gZGVzZXJpYWxpemVQcm9taXNlRnVsZmlsbChjdHgsIGRlcHRoLCBub2RlKTtcblx0XHRjYXNlIDI4OiByZXR1cm4gZGVzZXJpYWxpemVJdGVyYXRvckZhY3RvcnlJbnN0YW5jZShjdHgsIGRlcHRoLCBub2RlKTtcblx0XHRjYXNlIDMwOiByZXR1cm4gZGVzZXJpYWxpemVBc3luY0l0ZXJhdG9yRmFjdG9yeUluc3RhbmNlKGN0eCwgZGVwdGgsIG5vZGUpO1xuXHRcdGNhc2UgMzE6IHJldHVybiBkZXNlcmlhbGl6ZVN0cmVhbUNvbnN0cnVjdG9yKGN0eCwgZGVwdGgsIG5vZGUpO1xuXHRcdGNhc2UgMzI6IHJldHVybiBkZXNlcmlhbGl6ZVN0cmVhbU5leHQoY3R4LCBkZXB0aCwgbm9kZSk7XG5cdFx0Y2FzZSAzMzogcmV0dXJuIGRlc2VyaWFsaXplU3RyZWFtVGhyb3coY3R4LCBkZXB0aCwgbm9kZSk7XG5cdFx0Y2FzZSAzNDogcmV0dXJuIGRlc2VyaWFsaXplU3RyZWFtUmV0dXJuKGN0eCwgZGVwdGgsIG5vZGUpO1xuXHRcdGNhc2UgMjc6IHJldHVybiBkZXNlcmlhbGl6ZUl0ZXJhdG9yRmFjdG9yeShjdHgsIGRlcHRoLCBub2RlKTtcblx0XHRjYXNlIDI5OiByZXR1cm4gZGVzZXJpYWxpemVBc3luY0l0ZXJhdG9yRmFjdG9yeShjdHgsIGRlcHRoLCBub2RlKTtcblx0XHRjYXNlIDM1OiByZXR1cm4gZGVzZXJpYWxpemVTZXF1ZW5jZShjdHgsIGRlcHRoLCBub2RlKTtcblx0XHRjYXNlIDM2OiByZXR1cm4gZGVzZXJpYWxpemVUZW1wb3JhbChjdHgsIG5vZGUpO1xuXHRcdGRlZmF1bHQ6IHRocm93IG5ldyBTZXJvdmFsVW5zdXBwb3J0ZWROb2RlRXJyb3Iobm9kZSk7XG5cdH1cbn1cbmZ1bmN0aW9uIGRlc2VyaWFsaXplVG9wKGN0eCwgbm9kZSkge1xuXHR0cnkge1xuXHRcdHJldHVybiBkZXNlcmlhbGl6ZSQxKGN0eCwgMCwgbm9kZSk7XG5cdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0dGhyb3cgbmV3IFNlcm92YWxEZXNlcmlhbGl6YXRpb25FcnJvcihlcnJvcik7XG5cdH1cbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2Z1bmN0aW9uLXN0cmluZy50c1xuY29uc3QgUkVUVVJOID0gKCkgPT4gVDtcbmNvbnN0IFNFUklBTElaRURfUkVUVVJOID0gLyogQF9fUFVSRV9fICovIFJFVFVSTi50b1N0cmluZygpO1xuY29uc3QgSVNfTU9ERVJOID0gLyogQF9fUFVSRV9fICovIC89Pi8udGVzdChTRVJJQUxJWkVEX1JFVFVSTik7XG5mdW5jdGlvbiBjcmVhdGVGdW5jdGlvbihwYXJhbWV0ZXJzLCBib2R5KSB7XG5cdGlmIChJU19NT0RFUk4pIHJldHVybiAocGFyYW1ldGVycy5sZW5ndGggPT09IDEgPyBwYXJhbWV0ZXJzWzBdIDogXCIoXCIgKyBwYXJhbWV0ZXJzLmpvaW4oXCIsXCIpICsgXCIpXCIpICsgXCI9PlwiICsgKGJvZHkuc3RhcnRzV2l0aChcIntcIikgPyBcIihcIiArIGJvZHkgKyBcIilcIiA6IGJvZHkpO1xuXHRyZXR1cm4gXCJmdW5jdGlvbihcIiArIHBhcmFtZXRlcnMuam9pbihcIixcIikgKyBcIil7cmV0dXJuIFwiICsgYm9keSArIFwifVwiO1xufVxuZnVuY3Rpb24gY3JlYXRlRWZmZWN0ZnVsRnVuY3Rpb24ocGFyYW1ldGVycywgYm9keSkge1xuXHRpZiAoSVNfTU9ERVJOKSByZXR1cm4gKHBhcmFtZXRlcnMubGVuZ3RoID09PSAxID8gcGFyYW1ldGVyc1swXSA6IFwiKFwiICsgcGFyYW1ldGVycy5qb2luKFwiLFwiKSArIFwiKVwiKSArIFwiPT57XCIgKyBib2R5ICsgXCJ9XCI7XG5cdHJldHVybiBcImZ1bmN0aW9uKFwiICsgcGFyYW1ldGVycy5qb2luKFwiLFwiKSArIFwiKXtcIiArIGJvZHkgKyBcIn1cIjtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3V0aWxzL2dldC1pZGVudGlmaWVyLnRzXG5jb25zdCBSRUZfU1RBUlRfQ0hBUlMgPSBcImhqa21vcXV4ekFCQ0RFRkdISUpLTE5QUVJUVVZXWFlaJF9cIjtcbmNvbnN0IFJFRl9TVEFSVF9DSEFSU19MRU4gPSAzNDtcbmNvbnN0IFJFRl9DSEFSUyA9IFwiYWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXpBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWjAxMjM0NTY3ODkkX1wiO1xuY29uc3QgUkVGX0NIQVJTX0xFTiA9IDY0O1xuZnVuY3Rpb24gZ2V0SWRlbnRpZmllcihpbmRleCkge1xuXHRsZXQgbW9kID0gaW5kZXggJSBSRUZfU1RBUlRfQ0hBUlNfTEVOO1xuXHRsZXQgcmVmID0gUkVGX1NUQVJUX0NIQVJTW21vZF07XG5cdGluZGV4ID0gKGluZGV4IC0gbW9kKSAvIFJFRl9TVEFSVF9DSEFSU19MRU47XG5cdHdoaWxlIChpbmRleCA+IDApIHtcblx0XHRtb2QgPSBpbmRleCAlIFJFRl9DSEFSU19MRU47XG5cdFx0cmVmICs9IFJFRl9DSEFSU1ttb2RdO1xuXHRcdGluZGV4ID0gKGluZGV4IC0gbW9kKSAvIFJFRl9DSEFSU19MRU47XG5cdH1cblx0cmV0dXJuIHJlZjtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3V0aWxzL2lzLXZhbGlkLWlkZW50aWZpZXIudHNcbmNvbnN0IElERU5USUZJRVJfQ0hFQ0sgPSAvXlskQS1aX11bMC05QS1aXyRdKiQvaTtcbmZ1bmN0aW9uIGlzVmFsaWRJZGVudGlmaWVyKG5hbWUpIHtcblx0Y29uc3QgY2hhciA9IG5hbWVbMF07XG5cdHJldHVybiAoY2hhciA9PT0gXCIkXCIgfHwgY2hhciA9PT0gXCJfXCIgfHwgY2hhciA+PSBcIkFcIiAmJiBjaGFyIDw9IFwiWlwiIHx8IGNoYXIgPj0gXCJhXCIgJiYgY2hhciA8PSBcInpcIikgJiYgSURFTlRJRklFUl9DSEVDSy50ZXN0KG5hbWUpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29udGV4dC9zZXJpYWxpemVyLnRzXG5mdW5jdGlvbiBnZXRBc3NpZ25tZW50RXhwcmVzc2lvbihhc3NpZ25tZW50KSB7XG5cdHN3aXRjaCAoYXNzaWdubWVudC50KSB7XG5cdFx0Y2FzZSAwOiByZXR1cm4gYXNzaWdubWVudC5zICsgXCI9XCIgKyBhc3NpZ25tZW50LnY7XG5cdFx0Y2FzZSAyOiByZXR1cm4gYXNzaWdubWVudC5zICsgXCIuc2V0KFwiICsgYXNzaWdubWVudC5rICsgXCIsXCIgKyBhc3NpZ25tZW50LnYgKyBcIilcIjtcblx0XHRjYXNlIDE6IHJldHVybiBhc3NpZ25tZW50LnMgKyBcIi5hZGQoXCIgKyBhc3NpZ25tZW50LnYgKyBcIilcIjtcblx0XHRjYXNlIDM6IHJldHVybiBhc3NpZ25tZW50LnMgKyBcIi5kZWxldGUoXCIgKyBhc3NpZ25tZW50LmsgKyBcIilcIjtcblx0XHRjYXNlIDQ6IHJldHVybiBcIk9iamVjdC5kZWZpbmVQcm9wZXJ0eShcIiArIGFzc2lnbm1lbnQucyArIFwiLFxcXCJfX3Byb3RvX19cXFwiLHt2YWx1ZTpcIiArIGFzc2lnbm1lbnQuayArIFwiLGNvbmZpZ3VyYWJsZTohMCxlbnVtZXJhYmxlOiEwLHdyaXRhYmxlOiEwfSlcIjtcblx0fVxufVxuZnVuY3Rpb24gbWVyZ2VBc3NpZ25tZW50cyhhc3NpZ25tZW50cykge1xuXHRjb25zdCBuZXdBc3NpZ25tZW50cyA9IFtdO1xuXHRsZXQgY3VycmVudCA9IGFzc2lnbm1lbnRzWzBdO1xuXHRmb3IgKGxldCBpID0gMSwgbGVuID0gYXNzaWdubWVudHMubGVuZ3RoLCBpdGVtLCBwcmV2ID0gY3VycmVudDsgaSA8IGxlbjsgaSsrKSB7XG5cdFx0aXRlbSA9IGFzc2lnbm1lbnRzW2ldO1xuXHRcdGlmIChpdGVtLnQgPT09IDAgJiYgaXRlbS52ID09PSBwcmV2LnYpIGN1cnJlbnQgPSB7XG5cdFx0XHR0OiAwLFxuXHRcdFx0czogaXRlbS5zLFxuXHRcdFx0azogdm9pZCAwLFxuXHRcdFx0djogZ2V0QXNzaWdubWVudEV4cHJlc3Npb24oY3VycmVudClcblx0XHR9O1xuXHRcdGVsc2UgaWYgKGl0ZW0udCA9PT0gMiAmJiBpdGVtLnMgPT09IHByZXYucykgY3VycmVudCA9IHtcblx0XHRcdHQ6IDIsXG5cdFx0XHRzOiBnZXRBc3NpZ25tZW50RXhwcmVzc2lvbihjdXJyZW50KSxcblx0XHRcdGs6IGl0ZW0uayxcblx0XHRcdHY6IGl0ZW0udlxuXHRcdH07XG5cdFx0ZWxzZSBpZiAoaXRlbS50ID09PSAxICYmIGl0ZW0ucyA9PT0gcHJldi5zKSBjdXJyZW50ID0ge1xuXHRcdFx0dDogMSxcblx0XHRcdHM6IGdldEFzc2lnbm1lbnRFeHByZXNzaW9uKGN1cnJlbnQpLFxuXHRcdFx0azogdm9pZCAwLFxuXHRcdFx0djogaXRlbS52XG5cdFx0fTtcblx0XHRlbHNlIGlmIChpdGVtLnQgPT09IDMgJiYgaXRlbS5zID09PSBwcmV2LnMpIGN1cnJlbnQgPSB7XG5cdFx0XHR0OiAzLFxuXHRcdFx0czogZ2V0QXNzaWdubWVudEV4cHJlc3Npb24oY3VycmVudCksXG5cdFx0XHRrOiBpdGVtLmssXG5cdFx0XHR2OiB2b2lkIDBcblx0XHR9O1xuXHRcdGVsc2Uge1xuXHRcdFx0bmV3QXNzaWdubWVudHMucHVzaChjdXJyZW50KTtcblx0XHRcdGN1cnJlbnQgPSBpdGVtO1xuXHRcdH1cblx0XHRwcmV2ID0gaXRlbTtcblx0fVxuXHRuZXdBc3NpZ25tZW50cy5wdXNoKGN1cnJlbnQpO1xuXHRyZXR1cm4gbmV3QXNzaWdubWVudHM7XG59XG5mdW5jdGlvbiByZXNvbHZlQXNzaWdubWVudHMoYXNzaWdubWVudHMpIHtcblx0aWYgKGFzc2lnbm1lbnRzLmxlbmd0aCkge1xuXHRcdGxldCByZXN1bHQgPSBcIlwiO1xuXHRcdGNvbnN0IG1lcmdlZCA9IG1lcmdlQXNzaWdubWVudHMoYXNzaWdubWVudHMpO1xuXHRcdGZvciAobGV0IGkgPSAwLCBsZW4gPSBtZXJnZWQubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHJlc3VsdCArPSBnZXRBc3NpZ25tZW50RXhwcmVzc2lvbihtZXJnZWRbaV0pICsgXCIsXCI7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fVxufVxuY29uc3QgTlVMTF9DT05TVFJVQ1RPUiA9IFwiT2JqZWN0LmNyZWF0ZShudWxsKVwiO1xuY29uc3QgU0VUX0NPTlNUUlVDVE9SID0gXCJuZXcgU2V0XCI7XG5jb25zdCBNQVBfQ09OU1RSVUNUT1IgPSBcIm5ldyBNYXBcIjtcbmNvbnN0IFBST01JU0VfUkVTT0xWRSA9IFwiUHJvbWlzZS5yZXNvbHZlXCI7XG5jb25zdCBQUk9NSVNFX1JFSkVDVCA9IFwiUHJvbWlzZS5yZWplY3RcIjtcbmNvbnN0IE9CSkVDVF9GTEFHX0NPTlNUUlVDVE9SID0ge1xuXHRbM106IFwiT2JqZWN0LmZyZWV6ZVwiLFxuXHRbMl06IFwiT2JqZWN0LnNlYWxcIixcblx0WzFdOiBcIk9iamVjdC5wcmV2ZW50RXh0ZW5zaW9uc1wiLFxuXHRbMF06IHZvaWQgMFxufTtcbmZ1bmN0aW9uIGNyZWF0ZUJhc2VTZXJpYWxpemVyQ29udGV4dChtb2RlLCBvcHRpb25zKSB7XG5cdHJldHVybiB7XG5cdFx0bW9kZSxcblx0XHRwbHVnaW5zOiBvcHRpb25zLnBsdWdpbnMsXG5cdFx0ZmVhdHVyZXM6IG9wdGlvbnMuZmVhdHVyZXMsXG5cdFx0bWFya2VkOiBuZXcgU2V0KG9wdGlvbnMubWFya2VkUmVmcyksXG5cdFx0c3RhY2s6IFtdLFxuXHRcdGZsYWdzOiBbXSxcblx0XHRhc3NpZ25tZW50czogW11cblx0fTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVZhbmlsbGFTZXJpYWxpemVyU3RhdGUoKSB7XG5cdHJldHVybiB7XG5cdFx0dmFsaWQ6IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCksXG5cdFx0dmFyczogW11cblx0fTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVZhbmlsbGFTZXJpYWxpemVyQ29udGV4dChvcHRpb25zKSB7XG5cdHJldHVybiB7XG5cdFx0bW9kZTogMSxcblx0XHRiYXNlOiBjcmVhdGVCYXNlU2VyaWFsaXplckNvbnRleHQoMSwgb3B0aW9ucyksXG5cdFx0c3RhdGU6IGNyZWF0ZVZhbmlsbGFTZXJpYWxpemVyU3RhdGUoKSxcblx0XHRjaGlsZDogdm9pZCAwXG5cdH07XG59XG5mdW5jdGlvbiBjcmVhdGVDcm9zc1NlcmlhbGl6ZXJDb250ZXh0KG9wdGlvbnMpIHtcblx0cmV0dXJuIHtcblx0XHRtb2RlOiAyLFxuXHRcdGJhc2U6IGNyZWF0ZUJhc2VTZXJpYWxpemVyQ29udGV4dCgyLCBvcHRpb25zKSxcblx0XHRzdGF0ZTogb3B0aW9ucyxcblx0XHRjaGlsZDogdm9pZCAwXG5cdH07XG59XG52YXIgU2VyaWFsaXplUGx1Z2luQ29udGV4dCA9IGNsYXNzIHtcblx0Y29uc3RydWN0b3IoX3ApIHtcblx0XHR0aGlzLl9wID0gX3A7XG5cdH1cblx0c2VyaWFsaXplKG5vZGUpIHtcblx0XHRyZXR1cm4gc2VyaWFsaXplJDEodGhpcy5fcCwgbm9kZSk7XG5cdH1cbn07XG4vKipcbiogQ3JlYXRlcyB0aGUgcmVmZXJlbmNlIHBhcmFtIChpZGVudGlmaWVyKSBmcm9tIHRoZSBnaXZlbiByZWZlcmVuY2UgSURcbiogQ2FsbGluZyB0aGlzIGZ1bmN0aW9uIG1lYW5zIHRoZSB2YWx1ZSBoYXMgYmVlbiByZWZlcmVuY2VkIHNvbWV3aGVyZVxuKi9cbmZ1bmN0aW9uIGdldFZhbmlsbGFSZWZQYXJhbShzdGF0ZSwgaW5kZXgpIHtcblx0LyoqXG5cdCogQ3JlYXRlcyBhIG5ldyByZWZlcmVuY2UgSUQgZnJvbSBhIGdpdmVuIHJlZmVyZW5jZSBJRFxuXHQqIFRoaXMgbmV3IHJlZmVyZW5jZSBJRCBtZWFucyB0aGF0IHRoZSByZWZlcmVuY2UgaXRzZWxmXG5cdCogaGFzIGJlZW4gcmVmZXJlbmNlZCBhdCBsZWFzdCBvbmNlLCBhbmQgaXMgdXNlZCB0byBnZW5lcmF0ZVxuXHQqIHRoZSB2YXJpYWJsZXNcblx0Ki9cblx0bGV0IGFjdHVhbEluZGV4ID0gc3RhdGUudmFsaWQuZ2V0KGluZGV4KTtcblx0aWYgKGFjdHVhbEluZGV4ID09IG51bGwpIHtcblx0XHRhY3R1YWxJbmRleCA9IHN0YXRlLnZhbGlkLnNpemU7XG5cdFx0c3RhdGUudmFsaWQuc2V0KGluZGV4LCBhY3R1YWxJbmRleCk7XG5cdH1cblx0bGV0IGlkZW50aWZpZXIgPSBzdGF0ZS52YXJzW2FjdHVhbEluZGV4XTtcblx0aWYgKGlkZW50aWZpZXIgPT0gbnVsbCkge1xuXHRcdGlkZW50aWZpZXIgPSBnZXRJZGVudGlmaWVyKGFjdHVhbEluZGV4KTtcblx0XHRzdGF0ZS52YXJzW2FjdHVhbEluZGV4XSA9IGlkZW50aWZpZXI7XG5cdH1cblx0cmV0dXJuIGlkZW50aWZpZXI7XG59XG5mdW5jdGlvbiBnZXRDcm9zc1JlZlBhcmFtKGlkKSB7XG5cdHJldHVybiBcIiRSW1wiICsgaWQgKyBcIl1cIjtcbn1cbi8qKlxuKiBDb252ZXJ0cyB0aGUgSUQgb2YgYSByZWZlcmVuY2UgaW50byBhIGlkZW50aWZpZXIgc3RyaW5nXG4qIHRoYXQgaXMgdXNlZCB0byByZWZlciB0byB0aGUgb2JqZWN0IGluc3RhbmNlIGluIHRoZVxuKiBnZW5lcmF0ZWQgc2NyaXB0LlxuKi9cbmZ1bmN0aW9uIGdldFJlZlBhcmFtKGN0eCwgaWQpIHtcblx0cmV0dXJuIGN0eC5tb2RlID09PSAxID8gZ2V0VmFuaWxsYVJlZlBhcmFtKGN0eC5zdGF0ZSwgaWQpIDogZ2V0Q3Jvc3NSZWZQYXJhbShpZCk7XG59XG5mdW5jdGlvbiBtYXJrU2VyaWFsaXplclJlZihjdHgsIGlkKSB7XG5cdGN0eC5tYXJrZWQuYWRkKGlkKTtcbn1cbmZ1bmN0aW9uIGlzU2VyaWFsaXplclJlZk1hcmtlZChjdHgsIGlkKSB7XG5cdHJldHVybiBjdHgubWFya2VkLmhhcyhpZCk7XG59XG5mdW5jdGlvbiBwdXNoT2JqZWN0RmxhZyhjdHgsIGZsYWcsIGlkKSB7XG5cdGlmIChmbGFnICE9PSAwKSB7XG5cdFx0bWFya1NlcmlhbGl6ZXJSZWYoY3R4LmJhc2UsIGlkKTtcblx0XHRjdHguYmFzZS5mbGFncy5wdXNoKHtcblx0XHRcdHR5cGU6IGZsYWcsXG5cdFx0XHR2YWx1ZTogZ2V0UmVmUGFyYW0oY3R4LCBpZClcblx0XHR9KTtcblx0fVxufVxuZnVuY3Rpb24gcmVzb2x2ZUZsYWdzKGN0eCkge1xuXHRsZXQgcmVzdWx0ID0gXCJcIjtcblx0Zm9yIChsZXQgaSA9IDAsIGN1cnJlbnQgPSBjdHguZmxhZ3MsIGxlbiA9IGN1cnJlbnQubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcblx0XHRjb25zdCBmbGFnID0gY3VycmVudFtpXTtcblx0XHRyZXN1bHQgKz0gT0JKRUNUX0ZMQUdfQ09OU1RSVUNUT1JbZmxhZy50eXBlXSArIFwiKFwiICsgZmxhZy52YWx1ZSArIFwiKSxcIjtcblx0fVxuXHRyZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gcmVzb2x2ZVBhdGNoZXMoY3R4KSB7XG5cdGNvbnN0IGFzc2lnbm1lbnRzID0gcmVzb2x2ZUFzc2lnbm1lbnRzKGN0eC5hc3NpZ25tZW50cyk7XG5cdGNvbnN0IGZsYWdzID0gcmVzb2x2ZUZsYWdzKGN0eCk7XG5cdGlmIChhc3NpZ25tZW50cykge1xuXHRcdGlmIChmbGFncykgcmV0dXJuIGFzc2lnbm1lbnRzICsgZmxhZ3M7XG5cdFx0cmV0dXJuIGFzc2lnbm1lbnRzO1xuXHR9XG5cdHJldHVybiBmbGFncztcbn1cbi8qKlxuKiBHZW5lcmF0ZXMgdGhlIGlubGluZWQgYXNzaWdubWVudCBmb3IgdGhlIHJlZmVyZW5jZVxuKiBUaGlzIGlzIGRpZmZlcmVudCBmcm9tIHRoZSBhc3NpZ25tZW50cyBhcnJheSBhcyB0aGlzIG9uZVxuKiBzaWduaWZpZXMgY3JlYXRpb24gcmF0aGVyIHRoYW4gbXV0YXRpb25cbiovXG5mdW5jdGlvbiBjcmVhdGVBc3NpZ25tZW50KGN0eCwgc291cmNlLCB2YWx1ZSkge1xuXHRjdHguYXNzaWdubWVudHMucHVzaCh7XG5cdFx0dDogMCxcblx0XHRzOiBzb3VyY2UsXG5cdFx0azogdm9pZCAwLFxuXHRcdHY6IHZhbHVlXG5cdH0pO1xufVxuZnVuY3Rpb24gY3JlYXRlQWRkQXNzaWdubWVudChjdHgsIHJlZiwgdmFsdWUpIHtcblx0Y3R4LmJhc2UuYXNzaWdubWVudHMucHVzaCh7XG5cdFx0dDogMSxcblx0XHRzOiBnZXRSZWZQYXJhbShjdHgsIHJlZiksXG5cdFx0azogdm9pZCAwLFxuXHRcdHY6IHZhbHVlXG5cdH0pO1xufVxuZnVuY3Rpb24gY3JlYXRlU2V0QXNzaWdubWVudChjdHgsIHJlZiwga2V5LCB2YWx1ZSkge1xuXHRjdHguYmFzZS5hc3NpZ25tZW50cy5wdXNoKHtcblx0XHR0OiAyLFxuXHRcdHM6IGdldFJlZlBhcmFtKGN0eCwgcmVmKSxcblx0XHRrOiBrZXksXG5cdFx0djogdmFsdWVcblx0fSk7XG59XG5mdW5jdGlvbiBjcmVhdGVEZWxldGVBc3NpZ25tZW50KGN0eCwgcmVmLCBrZXkpIHtcblx0Y3R4LmJhc2UuYXNzaWdubWVudHMucHVzaCh7XG5cdFx0dDogMyxcblx0XHRzOiBnZXRSZWZQYXJhbShjdHgsIHJlZiksXG5cdFx0azoga2V5LFxuXHRcdHY6IHZvaWQgMFxuXHR9KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUFycmF5QXNzaWduKGN0eCwgcmVmLCBpbmRleCwgdmFsdWUpIHtcblx0Y3JlYXRlQXNzaWdubWVudChjdHguYmFzZSwgZ2V0UmVmUGFyYW0oY3R4LCByZWYpICsgXCJbXCIgKyBpbmRleCArIFwiXVwiLCB2YWx1ZSk7XG59XG5mdW5jdGlvbiBjcmVhdGVPYmplY3RBc3NpZ24oY3R4LCByZWYsIGtleSwgdmFsdWUpIHtcblx0aWYgKCFpc1ZhbGlkS2V5KGtleSkpIHtcblx0XHRjdHguYmFzZS5hc3NpZ25tZW50cy5wdXNoKHtcblx0XHRcdHQ6IDQsXG5cdFx0XHRzOiBnZXRSZWZQYXJhbShjdHgsIHJlZiksXG5cdFx0XHRrOiB2YWx1ZSxcblx0XHRcdHY6IHZvaWQgMFxuXHRcdH0pO1xuXHRcdHJldHVybjtcblx0fVxuXHRjcmVhdGVBc3NpZ25tZW50KGN0eC5iYXNlLCBnZXRSZWZQYXJhbShjdHgsIHJlZikgKyBcIi5cIiArIGtleSwgdmFsdWUpO1xufVxuZnVuY3Rpb24gY3JlYXRlU2VxdWVuY2VBc3NpZ24oY3R4LCByZWYsIGluZGV4LCB2YWx1ZSkge1xuXHRjcmVhdGVBc3NpZ25tZW50KGN0eC5iYXNlLCBnZXRSZWZQYXJhbShjdHgsIHJlZikgKyBcIi52W1wiICsgaW5kZXggKyBcIl1cIiwgdmFsdWUpO1xufVxuLyoqXG4qIENoZWNrcyBpZiB0aGUgdmFsdWUgaXMgaW4gdGhlIHN0YWNrLiBTdGFjayBoZXJlIGlzIGEgcmVmZXJlbmNlXG4qIHN0cnVjdHVyZSB0byBrbm93IGlmIGEgb2JqZWN0IGlzIHRvIGJlIGFjY2Vzc2VkIGluIGEgVERaLlxuKi9cbmZ1bmN0aW9uIGlzSW5kZXhlZFZhbHVlSW5TdGFjayhjdHgsIG5vZGUpIHtcblx0cmV0dXJuIG5vZGUudCA9PT0gNCAmJiBjdHguc3RhY2suaW5jbHVkZXMobm9kZS5pKTtcbn1cbi8qKlxuKiBQcm9kdWNlcyBhbiBhc3NpZ25tZW50IGV4cHJlc3Npb24uIGBpZGAgZ2VuZXJhdGVzIGEgcmVmZXJlbmNlXG4qIHBhcmFtZXRlciAodGhyb3VnaCBgZ2V0UmVmUGFyYW1gKSBhbmQgaGFzIHRoZSBvcHRpb24gdG9cbiogcmV0dXJuIHRoZSByZWZlcmVuY2UgcGFyYW1ldGVyIGRpcmVjdGx5IG9yIGFzc2lnbiBhIHZhbHVlIHRvXG4qIGl0LlxuKi9cbmZ1bmN0aW9uIGFzc2lnbkluZGV4ZWRWYWx1ZShjdHgsIGluZGV4LCB2YWx1ZSkge1xuXHRpZiAoY3R4Lm1vZGUgPT09IDEgJiYgIWlzU2VyaWFsaXplclJlZk1hcmtlZChjdHguYmFzZSwgaW5kZXgpKSByZXR1cm4gdmFsdWU7XG5cdC8qKlxuXHQqIEluIGNyb3NzLXJlZmVyZW5jZSwgd2UgaGF2ZSB0byBhc3N1bWUgdGhhdFxuXHQqIGV2ZXJ5IHJlZmVyZW5jZSBhcmUgZ29pbmcgdG8gYmUgcmVmZXJlbmNlZFxuXHQqIGluIHRoZSBmdXR1cmUsIGFuZCBzbyB3ZSBuZWVkIHRvIHN0b3JlXG5cdCogYWxsIG9mIGl0IGludG8gdGhlIHJlZmVyZW5jZSBhcnJheS5cblx0KlxuXHQqIG90aGVyd2lzZSBpbiB2YW5pbGxhLCB3ZSBvbmx5IGRvIHRoaXMgaWYgaXRcblx0KiBpcyBhY3R1YWxseSByZWZlcmVuY2VkXG5cdCovXG5cdHJldHVybiBnZXRSZWZQYXJhbShjdHgsIGluZGV4KSArIFwiPVwiICsgdmFsdWU7XG59XG5mdW5jdGlvbiBzZXJpYWxpemVSZWZlcmVuY2Uobm9kZSkge1xuXHRyZXR1cm4gXCJfX1NFUk9WQUxfUkVGU19fLmdldChcXFwiXCIgKyBub2RlLnMgKyBcIlxcXCIpXCI7XG59XG5mdW5jdGlvbiBzZXJpYWxpemVBcnJheUl0ZW0oY3R4LCBpZCwgaXRlbSwgaW5kZXgpIHtcblx0aWYgKGl0ZW0pIHtcblx0XHRpZiAoaXNJbmRleGVkVmFsdWVJblN0YWNrKGN0eC5iYXNlLCBpdGVtKSkge1xuXHRcdFx0bWFya1NlcmlhbGl6ZXJSZWYoY3R4LmJhc2UsIGlkKTtcblx0XHRcdGNyZWF0ZUFycmF5QXNzaWduKGN0eCwgaWQsIGluZGV4LCBnZXRSZWZQYXJhbShjdHgsIGl0ZW0uaSkpO1xuXHRcdFx0cmV0dXJuIFwiXCI7XG5cdFx0fVxuXHRcdHJldHVybiBzZXJpYWxpemUkMShjdHgsIGl0ZW0pO1xuXHR9XG5cdHJldHVybiBcIlwiO1xufVxuZnVuY3Rpb24gc2VyaWFsaXplQXJyYXkoY3R4LCBub2RlKSB7XG5cdGNvbnN0IGlkID0gbm9kZS5pO1xuXHRjb25zdCBsaXN0ID0gbm9kZS5hO1xuXHRjb25zdCBsZW4gPSBsaXN0Lmxlbmd0aDtcblx0aWYgKGxlbiA+IDApIHtcblx0XHRjdHguYmFzZS5zdGFjay5wdXNoKGlkKTtcblx0XHRsZXQgdmFsdWVzID0gc2VyaWFsaXplQXJyYXlJdGVtKGN0eCwgaWQsIGxpc3RbMF0sIDApO1xuXHRcdGxldCBpc0hvbGV5ID0gdmFsdWVzID09PSBcIlwiO1xuXHRcdGZvciAobGV0IGkgPSAxLCBpdGVtOyBpIDwgbGVuOyBpKyspIHtcblx0XHRcdGl0ZW0gPSBzZXJpYWxpemVBcnJheUl0ZW0oY3R4LCBpZCwgbGlzdFtpXSwgaSk7XG5cdFx0XHR2YWx1ZXMgKz0gXCIsXCIgKyBpdGVtO1xuXHRcdFx0aXNIb2xleSA9IGl0ZW0gPT09IFwiXCI7XG5cdFx0fVxuXHRcdGN0eC5iYXNlLnN0YWNrLnBvcCgpO1xuXHRcdHB1c2hPYmplY3RGbGFnKGN0eCwgbm9kZS5vLCBub2RlLmkpO1xuXHRcdHJldHVybiBcIltcIiArIHZhbHVlcyArIChpc0hvbGV5ID8gXCIsXVwiIDogXCJdXCIpO1xuXHR9XG5cdHJldHVybiBcIltdXCI7XG59XG5mdW5jdGlvbiBzZXJpYWxpemVQcm9wZXJ0eShjdHgsIHNvdXJjZSwga2V5LCB2YWwpIHtcblx0aWYgKHR5cGVvZiBrZXkgPT09IFwic3RyaW5nXCIpIHtcblx0XHRjb25zdCBjaGVjayA9IE51bWJlcihrZXkpO1xuXHRcdGNvbnN0IGlzSWRlbnRpZmllciA9IGNoZWNrID49IDAgJiYgY2hlY2sudG9TdHJpbmcoKSA9PT0ga2V5IHx8IGlzVmFsaWRJZGVudGlmaWVyKGtleSk7XG5cdFx0aWYgKGlzSW5kZXhlZFZhbHVlSW5TdGFjayhjdHguYmFzZSwgdmFsKSkge1xuXHRcdFx0Y29uc3QgcmVmUGFyYW0gPSBnZXRSZWZQYXJhbShjdHgsIHZhbC5pKTtcblx0XHRcdG1hcmtTZXJpYWxpemVyUmVmKGN0eC5iYXNlLCBzb3VyY2UuaSk7XG5cdFx0XHRpZiAoaXNJZGVudGlmaWVyICYmIGNoZWNrICE9PSBjaGVjaykgY3JlYXRlT2JqZWN0QXNzaWduKGN0eCwgc291cmNlLmksIGtleSwgcmVmUGFyYW0pO1xuXHRcdFx0ZWxzZSBjcmVhdGVBcnJheUFzc2lnbihjdHgsIHNvdXJjZS5pLCBpc0lkZW50aWZpZXIgPyBrZXkgOiBcIlxcXCJcIiArIGtleSArIFwiXFxcIlwiLCByZWZQYXJhbSk7XG5cdFx0XHRyZXR1cm4gXCJcIjtcblx0XHR9XG5cdFx0aWYgKGlzVmFsaWRLZXkoa2V5KSkgcmV0dXJuIChpc0lkZW50aWZpZXIgPyBrZXkgOiBcIlxcXCJcIiArIGtleSArIFwiXFxcIlwiKSArIFwiOlwiICsgc2VyaWFsaXplJDEoY3R4LCB2YWwpO1xuXHRcdHJldHVybiBcIltcXFwiXCIgKyBrZXkgKyBcIlxcXCJdOlwiICsgc2VyaWFsaXplJDEoY3R4LCB2YWwpO1xuXHR9XG5cdHJldHVybiBcIltcIiArIHNlcmlhbGl6ZSQxKGN0eCwga2V5KSArIFwiXTpcIiArIHNlcmlhbGl6ZSQxKGN0eCwgdmFsKTtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZVByb3BlcnRpZXMoY3R4LCBzb3VyY2UsIHJlY29yZCkge1xuXHRjb25zdCBrZXlzID0gcmVjb3JkLms7XG5cdGNvbnN0IGxlbiA9IGtleXMubGVuZ3RoO1xuXHRpZiAobGVuID4gMCkge1xuXHRcdGNvbnN0IHZhbHVlcyA9IHJlY29yZC52O1xuXHRcdGN0eC5iYXNlLnN0YWNrLnB1c2goc291cmNlLmkpO1xuXHRcdGxldCByZXN1bHQgPSBzZXJpYWxpemVQcm9wZXJ0eShjdHgsIHNvdXJjZSwga2V5c1swXSwgdmFsdWVzWzBdKTtcblx0XHRmb3IgKGxldCBpID0gMSwgaXRlbSA9IHJlc3VsdDsgaSA8IGxlbjsgaSsrKSB7XG5cdFx0XHRpdGVtID0gc2VyaWFsaXplUHJvcGVydHkoY3R4LCBzb3VyY2UsIGtleXNbaV0sIHZhbHVlc1tpXSk7XG5cdFx0XHRyZXN1bHQgKz0gKGl0ZW0gJiYgcmVzdWx0ICYmIFwiLFwiKSArIGl0ZW07XG5cdFx0fVxuXHRcdGN0eC5iYXNlLnN0YWNrLnBvcCgpO1xuXHRcdHJldHVybiBcIntcIiArIHJlc3VsdCArIFwifVwiO1xuXHR9XG5cdHJldHVybiBcInt9XCI7XG59XG5mdW5jdGlvbiBzZXJpYWxpemVPYmplY3QoY3R4LCBub2RlKSB7XG5cdHB1c2hPYmplY3RGbGFnKGN0eCwgbm9kZS5vLCBub2RlLmkpO1xuXHRyZXR1cm4gc2VyaWFsaXplUHJvcGVydGllcyhjdHgsIG5vZGUsIG5vZGUucCk7XG59XG5mdW5jdGlvbiBzZXJpYWxpemVXaXRoT2JqZWN0QXNzaWduKGN0eCwgc291cmNlLCB2YWx1ZSwgc2VyaWFsaXplZCkge1xuXHRjb25zdCBmaWVsZHMgPSBzZXJpYWxpemVQcm9wZXJ0aWVzKGN0eCwgc291cmNlLCB2YWx1ZSk7XG5cdGlmIChmaWVsZHMgIT09IFwie31cIikgcmV0dXJuIFwiT2JqZWN0LmFzc2lnbihcIiArIHNlcmlhbGl6ZWQgKyBcIixcIiArIGZpZWxkcyArIFwiKVwiO1xuXHRyZXR1cm4gc2VyaWFsaXplZDtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZVN0cmluZ0tleUFzc2lnbm1lbnQoY3R4LCBzb3VyY2UsIG1haW5Bc3NpZ25tZW50cywga2V5LCB2YWx1ZSkge1xuXHRjb25zdCBiYXNlID0gY3R4LmJhc2U7XG5cdGNvbnN0IHNlcmlhbGl6ZWQgPSBzZXJpYWxpemUkMShjdHgsIHZhbHVlKTtcblx0Y29uc3QgY2hlY2sgPSBOdW1iZXIoa2V5KTtcblx0Y29uc3QgaXNJZGVudGlmaWVyID0gY2hlY2sgPj0gMCAmJiBjaGVjay50b1N0cmluZygpID09PSBrZXkgfHwgaXNWYWxpZElkZW50aWZpZXIoa2V5KTtcblx0aWYgKGlzSW5kZXhlZFZhbHVlSW5TdGFjayhiYXNlLCB2YWx1ZSkpIHtcblx0XHRpZiAoaXNJZGVudGlmaWVyICYmIGNoZWNrICE9PSBjaGVjaykgY3JlYXRlT2JqZWN0QXNzaWduKGN0eCwgc291cmNlLmksIGtleSwgc2VyaWFsaXplZCk7XG5cdFx0ZWxzZSBjcmVhdGVBcnJheUFzc2lnbihjdHgsIHNvdXJjZS5pLCBpc0lkZW50aWZpZXIgPyBrZXkgOiBcIlxcXCJcIiArIGtleSArIFwiXFxcIlwiLCBzZXJpYWxpemVkKTtcblx0fSBlbHNlIHtcblx0XHRjb25zdCBwYXJlbnRBc3NpZ25tZW50ID0gYmFzZS5hc3NpZ25tZW50cztcblx0XHRiYXNlLmFzc2lnbm1lbnRzID0gbWFpbkFzc2lnbm1lbnRzO1xuXHRcdGlmIChpc0lkZW50aWZpZXIgJiYgY2hlY2sgIT09IGNoZWNrKSBjcmVhdGVPYmplY3RBc3NpZ24oY3R4LCBzb3VyY2UuaSwga2V5LCBzZXJpYWxpemVkKTtcblx0XHRlbHNlIGNyZWF0ZUFycmF5QXNzaWduKGN0eCwgc291cmNlLmksIGlzSWRlbnRpZmllciA/IGtleSA6IFwiXFxcIlwiICsga2V5ICsgXCJcXFwiXCIsIHNlcmlhbGl6ZWQpO1xuXHRcdGJhc2UuYXNzaWdubWVudHMgPSBwYXJlbnRBc3NpZ25tZW50O1xuXHR9XG59XG5mdW5jdGlvbiBzZXJpYWxpemVBc3NpZ25tZW50KGN0eCwgc291cmNlLCBtYWluQXNzaWdubWVudHMsIGtleSwgdmFsdWUpIHtcblx0aWYgKHR5cGVvZiBrZXkgPT09IFwic3RyaW5nXCIpIHNlcmlhbGl6ZVN0cmluZ0tleUFzc2lnbm1lbnQoY3R4LCBzb3VyY2UsIG1haW5Bc3NpZ25tZW50cywga2V5LCB2YWx1ZSk7XG5cdGVsc2Uge1xuXHRcdGNvbnN0IGJhc2UgPSBjdHguYmFzZTtcblx0XHRjb25zdCBwYXJlbnQgPSBiYXNlLnN0YWNrO1xuXHRcdGJhc2Uuc3RhY2sgPSBbXTtcblx0XHRjb25zdCBzZXJpYWxpemVkID0gc2VyaWFsaXplJDEoY3R4LCB2YWx1ZSk7XG5cdFx0YmFzZS5zdGFjayA9IHBhcmVudDtcblx0XHRjb25zdCBwYXJlbnRBc3NpZ25tZW50ID0gYmFzZS5hc3NpZ25tZW50cztcblx0XHRiYXNlLmFzc2lnbm1lbnRzID0gbWFpbkFzc2lnbm1lbnRzO1xuXHRcdGNyZWF0ZUFycmF5QXNzaWduKGN0eCwgc291cmNlLmksIHNlcmlhbGl6ZSQxKGN0eCwga2V5KSwgc2VyaWFsaXplZCk7XG5cdFx0YmFzZS5hc3NpZ25tZW50cyA9IHBhcmVudEFzc2lnbm1lbnQ7XG5cdH1cbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZUFzc2lnbm1lbnRzKGN0eCwgc291cmNlLCBub2RlKSB7XG5cdGNvbnN0IGtleXMgPSBub2RlLms7XG5cdGNvbnN0IGxlbiA9IGtleXMubGVuZ3RoO1xuXHRpZiAobGVuID4gMCkge1xuXHRcdGNvbnN0IG1haW5Bc3NpZ25tZW50cyA9IFtdO1xuXHRcdGNvbnN0IHZhbHVlcyA9IG5vZGUudjtcblx0XHRjdHguYmFzZS5zdGFjay5wdXNoKHNvdXJjZS5pKTtcblx0XHRmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSsrKSBzZXJpYWxpemVBc3NpZ25tZW50KGN0eCwgc291cmNlLCBtYWluQXNzaWdubWVudHMsIGtleXNbaV0sIHZhbHVlc1tpXSk7XG5cdFx0Y3R4LmJhc2Uuc3RhY2sucG9wKCk7XG5cdFx0cmV0dXJuIHJlc29sdmVBc3NpZ25tZW50cyhtYWluQXNzaWdubWVudHMpO1xuXHR9XG59XG5mdW5jdGlvbiBzZXJpYWxpemVEaWN0aW9uYXJ5KGN0eCwgbm9kZSwgaW5pdCkge1xuXHRpZiAobm9kZS5wKSB7XG5cdFx0Y29uc3QgYmFzZSA9IGN0eC5iYXNlO1xuXHRcdGlmIChiYXNlLmZlYXR1cmVzICYgOCkgaW5pdCA9IHNlcmlhbGl6ZVdpdGhPYmplY3RBc3NpZ24oY3R4LCBub2RlLCBub2RlLnAsIGluaXQpO1xuXHRcdGVsc2Uge1xuXHRcdFx0bWFya1NlcmlhbGl6ZXJSZWYoYmFzZSwgbm9kZS5pKTtcblx0XHRcdGNvbnN0IGFzc2lnbm1lbnRzID0gc2VyaWFsaXplQXNzaWdubWVudHMoY3R4LCBub2RlLCBub2RlLnApO1xuXHRcdFx0aWYgKGFzc2lnbm1lbnRzKSByZXR1cm4gXCIoXCIgKyBhc3NpZ25JbmRleGVkVmFsdWUoY3R4LCBub2RlLmksIGluaXQpICsgXCIsXCIgKyBhc3NpZ25tZW50cyArIGdldFJlZlBhcmFtKGN0eCwgbm9kZS5pKSArIFwiKVwiO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gaW5pdDtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZU51bGxDb25zdHJ1Y3RvcihjdHgsIG5vZGUpIHtcblx0cHVzaE9iamVjdEZsYWcoY3R4LCBub2RlLm8sIG5vZGUuaSk7XG5cdHJldHVybiBzZXJpYWxpemVEaWN0aW9uYXJ5KGN0eCwgbm9kZSwgTlVMTF9DT05TVFJVQ1RPUik7XG59XG5mdW5jdGlvbiBzZXJpYWxpemVEYXRlKG5vZGUpIHtcblx0cmV0dXJuIFwibmV3IERhdGUoXFxcIlwiICsgbm9kZS5zICsgXCJcXFwiKVwiO1xufVxuY29uc3QgVEVNUE9SQUxfQ09OU1RSVUNUT1IgPSB7XG5cdFswXTogXCJUZW1wb3JhbC5JbnN0YW50XCIsXG5cdFsxXTogXCJUZW1wb3JhbC5EdXJhdGlvblwiLFxuXHRbMl06IFwiVGVtcG9yYWwuUGxhaW5EYXRlXCIsXG5cdFszXTogXCJUZW1wb3JhbC5QbGFpbkRhdGVUaW1lXCIsXG5cdFs0XTogXCJUZW1wb3JhbC5QbGFpbk1vbnRoRGF5XCIsXG5cdFs1XTogXCJUZW1wb3JhbC5QbGFpblRpbWVcIixcblx0WzZdOiBcIlRlbXBvcmFsLlBsYWluWWVhck1vbnRoXCIsXG5cdFs3XTogXCJUZW1wb3JhbC5ab25lZERhdGVUaW1lXCJcbn07XG5mdW5jdGlvbiBzZXJpYWxpemVUZW1wb3JhbChjdHgsIG5vZGUpIHtcblx0aWYgKGN0eC5iYXNlLmZlYXR1cmVzICYgNjQpIHJldHVybiBURU1QT1JBTF9DT05TVFJVQ1RPUltub2RlLmNdICsgXCIuZnJvbShcXFwiXCIgKyBub2RlLnMgKyBcIlxcXCIpXCI7XG5cdHRocm93IG5ldyBTZXJvdmFsVW5zdXBwb3J0ZWROb2RlRXJyb3Iobm9kZSk7XG59XG5mdW5jdGlvbiBzZXJpYWxpemVSZWdFeHAoY3R4LCBub2RlKSB7XG5cdGlmIChjdHguYmFzZS5mZWF0dXJlcyAmIDMyKSByZXR1cm4gXCIvXCIgKyBkZXNlcmlhbGl6ZVN0cmluZyhub2RlLmMpICsgXCIvXCIgKyBub2RlLm07XG5cdHRocm93IG5ldyBTZXJvdmFsVW5zdXBwb3J0ZWROb2RlRXJyb3Iobm9kZSk7XG59XG5mdW5jdGlvbiBzZXJpYWxpemVTZXRJdGVtKGN0eCwgaWQsIGl0ZW0pIHtcblx0Y29uc3QgYmFzZSA9IGN0eC5iYXNlO1xuXHRpZiAoaXNJbmRleGVkVmFsdWVJblN0YWNrKGJhc2UsIGl0ZW0pKSB7XG5cdFx0bWFya1NlcmlhbGl6ZXJSZWYoYmFzZSwgaWQpO1xuXHRcdGNyZWF0ZUFkZEFzc2lnbm1lbnQoY3R4LCBpZCwgZ2V0UmVmUGFyYW0oY3R4LCBpdGVtLmkpKTtcblx0XHRyZXR1cm4gXCJcIjtcblx0fVxuXHRyZXR1cm4gc2VyaWFsaXplJDEoY3R4LCBpdGVtKTtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZVNldChjdHgsIG5vZGUpIHtcblx0bGV0IHNlcmlhbGl6ZWQgPSBTRVRfQ09OU1RSVUNUT1I7XG5cdGNvbnN0IGl0ZW1zID0gbm9kZS5hO1xuXHRjb25zdCBzaXplID0gaXRlbXMubGVuZ3RoO1xuXHRjb25zdCBpZCA9IG5vZGUuaTtcblx0aWYgKHNpemUgPiAwKSB7XG5cdFx0Y3R4LmJhc2Uuc3RhY2sucHVzaChpZCk7XG5cdFx0bGV0IHJlc3VsdCA9IHNlcmlhbGl6ZVNldEl0ZW0oY3R4LCBpZCwgaXRlbXNbMF0pO1xuXHRcdGZvciAobGV0IGkgPSAxLCBpdGVtID0gcmVzdWx0OyBpIDwgc2l6ZTsgaSsrKSB7XG5cdFx0XHRpdGVtID0gc2VyaWFsaXplU2V0SXRlbShjdHgsIGlkLCBpdGVtc1tpXSk7XG5cdFx0XHRyZXN1bHQgKz0gKGl0ZW0gJiYgcmVzdWx0ICYmIFwiLFwiKSArIGl0ZW07XG5cdFx0fVxuXHRcdGN0eC5iYXNlLnN0YWNrLnBvcCgpO1xuXHRcdGlmIChyZXN1bHQpIHNlcmlhbGl6ZWQgKz0gXCIoW1wiICsgcmVzdWx0ICsgXCJdKVwiO1xuXHR9XG5cdHJldHVybiBzZXJpYWxpemVkO1xufVxuZnVuY3Rpb24gc2VyaWFsaXplTWFwRW50cnkoY3R4LCBpZCwga2V5LCB2YWwsIHNlbnRpbmVsKSB7XG5cdGNvbnN0IGJhc2UgPSBjdHguYmFzZTtcblx0aWYgKGlzSW5kZXhlZFZhbHVlSW5TdGFjayhiYXNlLCBrZXkpKSB7XG5cdFx0Y29uc3Qga2V5UmVmID0gZ2V0UmVmUGFyYW0oY3R4LCBrZXkuaSk7XG5cdFx0bWFya1NlcmlhbGl6ZXJSZWYoYmFzZSwgaWQpO1xuXHRcdGlmIChpc0luZGV4ZWRWYWx1ZUluU3RhY2soYmFzZSwgdmFsKSkge1xuXHRcdFx0Y3JlYXRlU2V0QXNzaWdubWVudChjdHgsIGlkLCBrZXlSZWYsIGdldFJlZlBhcmFtKGN0eCwgdmFsLmkpKTtcblx0XHRcdHJldHVybiBcIlwiO1xuXHRcdH1cblx0XHRpZiAodmFsLnQgIT09IDQgJiYgdmFsLmkgIT0gbnVsbCAmJiBpc1NlcmlhbGl6ZXJSZWZNYXJrZWQoYmFzZSwgdmFsLmkpKSB7XG5cdFx0XHRjb25zdCBzZXJpYWxpemVkID0gXCIoXCIgKyBzZXJpYWxpemUkMShjdHgsIHZhbCkgKyBcIixbXCIgKyBzZW50aW5lbCArIFwiLFwiICsgc2VudGluZWwgKyBcIl0pXCI7XG5cdFx0XHRjcmVhdGVTZXRBc3NpZ25tZW50KGN0eCwgaWQsIGtleVJlZiwgZ2V0UmVmUGFyYW0oY3R4LCB2YWwuaSkpO1xuXHRcdFx0Y3JlYXRlRGVsZXRlQXNzaWdubWVudChjdHgsIGlkLCBzZW50aW5lbCk7XG5cdFx0XHRyZXR1cm4gc2VyaWFsaXplZDtcblx0XHR9XG5cdFx0Y29uc3QgcGFyZW50ID0gYmFzZS5zdGFjaztcblx0XHRiYXNlLnN0YWNrID0gW107XG5cdFx0Y3JlYXRlU2V0QXNzaWdubWVudChjdHgsIGlkLCBrZXlSZWYsIHNlcmlhbGl6ZSQxKGN0eCwgdmFsKSk7XG5cdFx0YmFzZS5zdGFjayA9IHBhcmVudDtcblx0XHRyZXR1cm4gXCJcIjtcblx0fVxuXHRpZiAoaXNJbmRleGVkVmFsdWVJblN0YWNrKGJhc2UsIHZhbCkpIHtcblx0XHRjb25zdCB2YWx1ZVJlZiA9IGdldFJlZlBhcmFtKGN0eCwgdmFsLmkpO1xuXHRcdG1hcmtTZXJpYWxpemVyUmVmKGJhc2UsIGlkKTtcblx0XHRpZiAoa2V5LnQgIT09IDQgJiYga2V5LmkgIT0gbnVsbCAmJiBpc1NlcmlhbGl6ZXJSZWZNYXJrZWQoYmFzZSwga2V5LmkpKSB7XG5cdFx0XHRjb25zdCBzZXJpYWxpemVkID0gXCIoXCIgKyBzZXJpYWxpemUkMShjdHgsIGtleSkgKyBcIixbXCIgKyBzZW50aW5lbCArIFwiLFwiICsgc2VudGluZWwgKyBcIl0pXCI7XG5cdFx0XHRjcmVhdGVTZXRBc3NpZ25tZW50KGN0eCwgaWQsIGdldFJlZlBhcmFtKGN0eCwga2V5LmkpLCB2YWx1ZVJlZik7XG5cdFx0XHRjcmVhdGVEZWxldGVBc3NpZ25tZW50KGN0eCwgaWQsIHNlbnRpbmVsKTtcblx0XHRcdHJldHVybiBzZXJpYWxpemVkO1xuXHRcdH1cblx0XHRjb25zdCBwYXJlbnQgPSBiYXNlLnN0YWNrO1xuXHRcdGJhc2Uuc3RhY2sgPSBbXTtcblx0XHRjcmVhdGVTZXRBc3NpZ25tZW50KGN0eCwgaWQsIHNlcmlhbGl6ZSQxKGN0eCwga2V5KSwgdmFsdWVSZWYpO1xuXHRcdGJhc2Uuc3RhY2sgPSBwYXJlbnQ7XG5cdFx0cmV0dXJuIFwiXCI7XG5cdH1cblx0cmV0dXJuIFwiW1wiICsgc2VyaWFsaXplJDEoY3R4LCBrZXkpICsgXCIsXCIgKyBzZXJpYWxpemUkMShjdHgsIHZhbCkgKyBcIl1cIjtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZU1hcChjdHgsIG5vZGUpIHtcblx0bGV0IHNlcmlhbGl6ZWQgPSBNQVBfQ09OU1RSVUNUT1I7XG5cdGNvbnN0IGtleXMgPSBub2RlLmUuaztcblx0Y29uc3Qgc2l6ZSA9IGtleXMubGVuZ3RoO1xuXHRjb25zdCBpZCA9IG5vZGUuaTtcblx0Y29uc3Qgc2VudGluZWwgPSBub2RlLmY7XG5cdGNvbnN0IHNlbnRpbmVsSWQgPSBnZXRSZWZQYXJhbShjdHgsIHNlbnRpbmVsLmkpO1xuXHRjb25zdCBiYXNlID0gY3R4LmJhc2U7XG5cdGlmIChzaXplID4gMCkge1xuXHRcdGNvbnN0IHZhbHMgPSBub2RlLmUudjtcblx0XHRiYXNlLnN0YWNrLnB1c2goaWQpO1xuXHRcdGxldCByZXN1bHQgPSBzZXJpYWxpemVNYXBFbnRyeShjdHgsIGlkLCBrZXlzWzBdLCB2YWxzWzBdLCBzZW50aW5lbElkKTtcblx0XHRmb3IgKGxldCBpID0gMSwgaXRlbSA9IHJlc3VsdDsgaSA8IHNpemU7IGkrKykge1xuXHRcdFx0aXRlbSA9IHNlcmlhbGl6ZU1hcEVudHJ5KGN0eCwgaWQsIGtleXNbaV0sIHZhbHNbaV0sIHNlbnRpbmVsSWQpO1xuXHRcdFx0cmVzdWx0ICs9IChpdGVtICYmIHJlc3VsdCAmJiBcIixcIikgKyBpdGVtO1xuXHRcdH1cblx0XHRiYXNlLnN0YWNrLnBvcCgpO1xuXHRcdGlmIChyZXN1bHQpIHNlcmlhbGl6ZWQgKz0gXCIoW1wiICsgcmVzdWx0ICsgXCJdKVwiO1xuXHR9XG5cdGlmIChzZW50aW5lbC50ID09PSAyNikge1xuXHRcdG1hcmtTZXJpYWxpemVyUmVmKGJhc2UsIHNlbnRpbmVsLmkpO1xuXHRcdHNlcmlhbGl6ZWQgPSBcIihcIiArIHNlcmlhbGl6ZSQxKGN0eCwgc2VudGluZWwpICsgXCIsXCIgKyBzZXJpYWxpemVkICsgXCIpXCI7XG5cdH1cblx0cmV0dXJuIHNlcmlhbGl6ZWQ7XG59XG5mdW5jdGlvbiBzZXJpYWxpemVBcnJheUJ1ZmZlcihjdHgsIG5vZGUpIHtcblx0cmV0dXJuIGdldENvbnN0cnVjdG9yKGN0eCwgbm9kZS5mKSArIFwiKFxcXCJcIiArIG5vZGUucyArIFwiXFxcIilcIjtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZVR5cGVkQXJyYXkoY3R4LCBub2RlKSB7XG5cdHJldHVybiBcIm5ldyBcIiArIG5vZGUuYyArIFwiKFwiICsgc2VyaWFsaXplJDEoY3R4LCBub2RlLmYpICsgXCIsXCIgKyBub2RlLmIgKyBcIixcIiArIG5vZGUubCArIFwiKVwiO1xufVxuZnVuY3Rpb24gc2VyaWFsaXplRGF0YVZpZXcoY3R4LCBub2RlKSB7XG5cdHJldHVybiBcIm5ldyBEYXRhVmlldyhcIiArIHNlcmlhbGl6ZSQxKGN0eCwgbm9kZS5mKSArIFwiLFwiICsgbm9kZS5iICsgXCIsXCIgKyBub2RlLmwgKyBcIilcIjtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZUFnZ3JlZ2F0ZUVycm9yKGN0eCwgbm9kZSkge1xuXHRjb25zdCBpZCA9IG5vZGUuaTtcblx0Y3R4LmJhc2Uuc3RhY2sucHVzaChpZCk7XG5cdGNvbnN0IHNlcmlhbGl6ZWQgPSBzZXJpYWxpemVEaWN0aW9uYXJ5KGN0eCwgbm9kZSwgXCJuZXcgQWdncmVnYXRlRXJyb3IoW10sXFxcIlwiICsgbm9kZS5tICsgXCJcXFwiKVwiKTtcblx0Y3R4LmJhc2Uuc3RhY2sucG9wKCk7XG5cdHJldHVybiBzZXJpYWxpemVkO1xufVxuZnVuY3Rpb24gc2VyaWFsaXplRXJyb3IoY3R4LCBub2RlKSB7XG5cdHJldHVybiBzZXJpYWxpemVEaWN0aW9uYXJ5KGN0eCwgbm9kZSwgXCJuZXcgXCIgKyBFUlJPUl9DT05TVFJVQ1RPUl9TVFJJTkdbbm9kZS5zXSArIFwiKFxcXCJcIiArIG5vZGUubSArIFwiXFxcIilcIik7XG59XG5mdW5jdGlvbiBzZXJpYWxpemVQcm9taXNlKGN0eCwgbm9kZSkge1xuXHRsZXQgc2VyaWFsaXplZDtcblx0Y29uc3QgZnVsZmlsbGVkID0gbm9kZS5mO1xuXHRjb25zdCBpZCA9IG5vZGUuaTtcblx0Y29uc3QgcHJvbWlzZUNvbnN0cnVjdG9yID0gbm9kZS5zID8gUFJPTUlTRV9SRVNPTFZFIDogUFJPTUlTRV9SRUpFQ1Q7XG5cdGNvbnN0IGJhc2UgPSBjdHguYmFzZTtcblx0aWYgKGlzSW5kZXhlZFZhbHVlSW5TdGFjayhiYXNlLCBmdWxmaWxsZWQpKSB7XG5cdFx0Y29uc3QgcmVmID0gZ2V0UmVmUGFyYW0oY3R4LCBmdWxmaWxsZWQuaSk7XG5cdFx0c2VyaWFsaXplZCA9IHByb21pc2VDb25zdHJ1Y3RvciArIChub2RlLnMgPyBcIigpLnRoZW4oXCIgKyBjcmVhdGVGdW5jdGlvbihbXSwgcmVmKSArIFwiKVwiIDogXCIoKS5jYXRjaChcIiArIGNyZWF0ZUVmZmVjdGZ1bEZ1bmN0aW9uKFtdLCBcInRocm93IFwiICsgcmVmKSArIFwiKVwiKTtcblx0fSBlbHNlIHtcblx0XHRiYXNlLnN0YWNrLnB1c2goaWQpO1xuXHRcdGNvbnN0IHJlc3VsdCA9IHNlcmlhbGl6ZSQxKGN0eCwgZnVsZmlsbGVkKTtcblx0XHRiYXNlLnN0YWNrLnBvcCgpO1xuXHRcdHNlcmlhbGl6ZWQgPSBwcm9taXNlQ29uc3RydWN0b3IgKyBcIihcIiArIHJlc3VsdCArIFwiKVwiO1xuXHR9XG5cdHJldHVybiBzZXJpYWxpemVkO1xufVxuZnVuY3Rpb24gc2VyaWFsaXplQm94ZWQoY3R4LCBub2RlKSB7XG5cdHJldHVybiBcIk9iamVjdChcIiArIHNlcmlhbGl6ZSQxKGN0eCwgbm9kZS5mKSArIFwiKVwiO1xufVxuZnVuY3Rpb24gZ2V0Q29uc3RydWN0b3IoY3R4LCBub2RlKSB7XG5cdGNvbnN0IGN1cnJlbnQgPSBzZXJpYWxpemUkMShjdHgsIG5vZGUpO1xuXHRyZXR1cm4gbm9kZS50ID09PSA0ID8gY3VycmVudCA6IFwiKFwiICsgY3VycmVudCArIFwiKVwiO1xufVxuZnVuY3Rpb24gc2VyaWFsaXplUHJvbWlzZUNvbnN0cnVjdG9yKGN0eCwgbm9kZSkge1xuXHRpZiAoY3R4Lm1vZGUgPT09IDEpIHRocm93IG5ldyBTZXJvdmFsVW5zdXBwb3J0ZWROb2RlRXJyb3Iobm9kZSk7XG5cdHJldHVybiBcIihcIiArIGFzc2lnbkluZGV4ZWRWYWx1ZShjdHgsIG5vZGUucywgZ2V0Q29uc3RydWN0b3IoY3R4LCBub2RlLmYpICsgXCIoKVwiKSArIFwiKS5wXCI7XG59XG5mdW5jdGlvbiBzZXJpYWxpemVQcm9taXNlUmVzb2x2ZShjdHgsIG5vZGUpIHtcblx0aWYgKGN0eC5tb2RlID09PSAxKSB0aHJvdyBuZXcgU2Vyb3ZhbFVuc3VwcG9ydGVkTm9kZUVycm9yKG5vZGUpO1xuXHRyZXR1cm4gZ2V0Q29uc3RydWN0b3IoY3R4LCBub2RlLmFbMF0pICsgXCIoXCIgKyBnZXRSZWZQYXJhbShjdHgsIG5vZGUuaSkgKyBcIixcIiArIHNlcmlhbGl6ZSQxKGN0eCwgbm9kZS5hWzFdKSArIFwiKVwiO1xufVxuZnVuY3Rpb24gc2VyaWFsaXplUHJvbWlzZVJlamVjdChjdHgsIG5vZGUpIHtcblx0aWYgKGN0eC5tb2RlID09PSAxKSB0aHJvdyBuZXcgU2Vyb3ZhbFVuc3VwcG9ydGVkTm9kZUVycm9yKG5vZGUpO1xuXHRyZXR1cm4gZ2V0Q29uc3RydWN0b3IoY3R4LCBub2RlLmFbMF0pICsgXCIoXCIgKyBnZXRSZWZQYXJhbShjdHgsIG5vZGUuaSkgKyBcIixcIiArIHNlcmlhbGl6ZSQxKGN0eCwgbm9kZS5hWzFdKSArIFwiKVwiO1xufVxuZnVuY3Rpb24gc2VyaWFsaXplUGx1Z2luKGN0eCwgbm9kZSkge1xuXHRjb25zdCBjdXJyZW50UGx1Z2lucyA9IGN0eC5iYXNlLnBsdWdpbnM7XG5cdGlmIChjdXJyZW50UGx1Z2lucykgZm9yIChsZXQgaSA9IDAsIGxlbiA9IGN1cnJlbnRQbHVnaW5zLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG5cdFx0Y29uc3QgcGx1Z2luID0gY3VycmVudFBsdWdpbnNbaV07XG5cdFx0aWYgKHBsdWdpbi50YWcgPT09IG5vZGUuYykge1xuXHRcdFx0aWYgKGN0eC5jaGlsZCA9PSBudWxsKSBjdHguY2hpbGQgPSBuZXcgU2VyaWFsaXplUGx1Z2luQ29udGV4dChjdHgpO1xuXHRcdFx0cmV0dXJuIHBsdWdpbi5zZXJpYWxpemUobm9kZS5zLCBjdHguY2hpbGQsIHsgaWQ6IG5vZGUuaSB9KTtcblx0XHR9XG5cdH1cblx0dGhyb3cgbmV3IFNlcm92YWxNaXNzaW5nUGx1Z2luRXJyb3Iobm9kZS5jKTtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZUl0ZXJhdG9yRmFjdG9yeShjdHgsIG5vZGUpIHtcblx0bGV0IHJlc3VsdCA9IFwiXCI7XG5cdGxldCBpbml0aWFsaXplZCA9IGZhbHNlO1xuXHRpZiAobm9kZS5mLnQgIT09IDQpIHtcblx0XHRtYXJrU2VyaWFsaXplclJlZihjdHguYmFzZSwgbm9kZS5mLmkpO1xuXHRcdHJlc3VsdCA9IFwiKFwiICsgc2VyaWFsaXplJDEoY3R4LCBub2RlLmYpICsgXCIsXCI7XG5cdFx0aW5pdGlhbGl6ZWQgPSB0cnVlO1xuXHR9XG5cdHJlc3VsdCArPSBhc3NpZ25JbmRleGVkVmFsdWUoY3R4LCBub2RlLmksIFwiKFwiICsgU0VSSUFMSVpFRF9JVEVSQVRPUl9DT05TVFJVQ1RPUiArIFwiKShcIiArIGdldFJlZlBhcmFtKGN0eCwgbm9kZS5mLmkpICsgXCIpXCIpO1xuXHRpZiAoaW5pdGlhbGl6ZWQpIHJlc3VsdCArPSBcIilcIjtcblx0cmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZUl0ZXJhdG9yRmFjdG9yeUluc3RhbmNlKGN0eCwgbm9kZSkge1xuXHRyZXR1cm4gZ2V0Q29uc3RydWN0b3IoY3R4LCBub2RlLmFbMF0pICsgXCIoXCIgKyBzZXJpYWxpemUkMShjdHgsIG5vZGUuYVsxXSkgKyBcIilcIjtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZUFzeW5jSXRlcmF0b3JGYWN0b3J5KGN0eCwgbm9kZSkge1xuXHRjb25zdCBwcm9taXNlID0gbm9kZS5hWzBdO1xuXHRjb25zdCBzeW1ib2wgPSBub2RlLmFbMV07XG5cdGNvbnN0IGJhc2UgPSBjdHguYmFzZTtcblx0bGV0IHJlc3VsdCA9IFwiXCI7XG5cdGlmIChwcm9taXNlLnQgIT09IDQpIHtcblx0XHRtYXJrU2VyaWFsaXplclJlZihiYXNlLCBwcm9taXNlLmkpO1xuXHRcdHJlc3VsdCArPSBcIihcIiArIHNlcmlhbGl6ZSQxKGN0eCwgcHJvbWlzZSk7XG5cdH1cblx0aWYgKHN5bWJvbC50ICE9PSA0KSB7XG5cdFx0bWFya1NlcmlhbGl6ZXJSZWYoYmFzZSwgc3ltYm9sLmkpO1xuXHRcdHJlc3VsdCArPSAocmVzdWx0ID8gXCIsXCIgOiBcIihcIikgKyBzZXJpYWxpemUkMShjdHgsIHN5bWJvbCk7XG5cdH1cblx0aWYgKHJlc3VsdCkgcmVzdWx0ICs9IFwiLFwiO1xuXHRjb25zdCBpdGVyYXRvciA9IGFzc2lnbkluZGV4ZWRWYWx1ZShjdHgsIG5vZGUuaSwgXCIoXCIgKyBTRVJJQUxJWkVEX0FTWU5DX0lURVJBVE9SX0NPTlNUUlVDVE9SICsgXCIpKFwiICsgZ2V0UmVmUGFyYW0oY3R4LCBzeW1ib2wuaSkgKyBcIixcIiArIGdldFJlZlBhcmFtKGN0eCwgcHJvbWlzZS5pKSArIFwiKVwiKTtcblx0aWYgKHJlc3VsdCkgcmV0dXJuIHJlc3VsdCArIGl0ZXJhdG9yICsgXCIpXCI7XG5cdHJldHVybiBpdGVyYXRvcjtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZUFzeW5jSXRlcmF0b3JGYWN0b3J5SW5zdGFuY2UoY3R4LCBub2RlKSB7XG5cdHJldHVybiBnZXRDb25zdHJ1Y3RvcihjdHgsIG5vZGUuYVswXSkgKyBcIihcIiArIHNlcmlhbGl6ZSQxKGN0eCwgbm9kZS5hWzFdKSArIFwiKVwiO1xufVxuZnVuY3Rpb24gc2VyaWFsaXplU3RyZWFtQ29uc3RydWN0b3IoY3R4LCBub2RlKSB7XG5cdGNvbnN0IHJlc3VsdCA9IGFzc2lnbkluZGV4ZWRWYWx1ZShjdHgsIG5vZGUuaSwgZ2V0Q29uc3RydWN0b3IoY3R4LCBub2RlLmYpICsgXCIoKVwiKTtcblx0Y29uc3QgbGVuID0gbm9kZS5hLmxlbmd0aDtcblx0aWYgKGxlbikge1xuXHRcdGxldCB2YWx1ZXMgPSBzZXJpYWxpemUkMShjdHgsIG5vZGUuYVswXSk7XG5cdFx0Zm9yIChsZXQgaSA9IDE7IGkgPCBsZW47IGkrKykgdmFsdWVzICs9IFwiLFwiICsgc2VyaWFsaXplJDEoY3R4LCBub2RlLmFbaV0pO1xuXHRcdHJldHVybiBcIihcIiArIHJlc3VsdCArIFwiLFwiICsgdmFsdWVzICsgXCIsXCIgKyBnZXRSZWZQYXJhbShjdHgsIG5vZGUuaSkgKyBcIilcIjtcblx0fVxuXHRyZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gc2VyaWFsaXplU3RyZWFtTmV4dChjdHgsIG5vZGUpIHtcblx0cmV0dXJuIGdldFJlZlBhcmFtKGN0eCwgbm9kZS5pKSArIFwiLm5leHQoXCIgKyBzZXJpYWxpemUkMShjdHgsIG5vZGUuZikgKyBcIilcIjtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZVN0cmVhbVRocm93KGN0eCwgbm9kZSkge1xuXHRyZXR1cm4gZ2V0UmVmUGFyYW0oY3R4LCBub2RlLmkpICsgXCIudGhyb3coXCIgKyBzZXJpYWxpemUkMShjdHgsIG5vZGUuZikgKyBcIilcIjtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZVN0cmVhbVJldHVybihjdHgsIG5vZGUpIHtcblx0cmV0dXJuIGdldFJlZlBhcmFtKGN0eCwgbm9kZS5pKSArIFwiLnJldHVybihcIiArIHNlcmlhbGl6ZSQxKGN0eCwgbm9kZS5mKSArIFwiKVwiO1xufVxuZnVuY3Rpb24gc2VyaWFsaXplU2VxdWVuY2VJdGVtKGN0eCwgaWQsIGluZGV4LCBpdGVtKSB7XG5cdGNvbnN0IGJhc2UgPSBjdHguYmFzZTtcblx0aWYgKGlzSW5kZXhlZFZhbHVlSW5TdGFjayhiYXNlLCBpdGVtKSkge1xuXHRcdG1hcmtTZXJpYWxpemVyUmVmKGJhc2UsIGlkKTtcblx0XHRjcmVhdGVTZXF1ZW5jZUFzc2lnbihjdHgsIGlkLCBpbmRleCwgZ2V0UmVmUGFyYW0oY3R4LCBpdGVtLmkpKTtcblx0XHRyZXR1cm4gXCJcIjtcblx0fVxuXHRyZXR1cm4gc2VyaWFsaXplJDEoY3R4LCBpdGVtKTtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZVNlcXVlbmNlKGN0eCwgbm9kZSkge1xuXHRjb25zdCBpdGVtcyA9IG5vZGUuYTtcblx0Y29uc3Qgc2l6ZSA9IGl0ZW1zLmxlbmd0aDtcblx0Y29uc3QgaWQgPSBub2RlLmk7XG5cdGlmIChzaXplID4gMCkge1xuXHRcdGN0eC5iYXNlLnN0YWNrLnB1c2goaWQpO1xuXHRcdGxldCByZXN1bHQgPSBzZXJpYWxpemVTZXF1ZW5jZUl0ZW0oY3R4LCBpZCwgMCwgaXRlbXNbMF0pO1xuXHRcdGZvciAobGV0IGkgPSAxLCBpdGVtID0gcmVzdWx0OyBpIDwgc2l6ZTsgaSsrKSB7XG5cdFx0XHRpdGVtID0gc2VyaWFsaXplU2VxdWVuY2VJdGVtKGN0eCwgaWQsIGksIGl0ZW1zW2ldKTtcblx0XHRcdHJlc3VsdCArPSAoaXRlbSAmJiByZXN1bHQgJiYgXCIsXCIpICsgaXRlbTtcblx0XHR9XG5cdFx0Y3R4LmJhc2Uuc3RhY2sucG9wKCk7XG5cdFx0aWYgKHJlc3VsdCkgcmV0dXJuIFwie19fU0VST1ZBTF9TRVFVRU5DRV9fOiEwLHY6W1wiICsgcmVzdWx0ICsgXCJdLHQ6XCIgKyBub2RlLnMgKyBcIixkOlwiICsgbm9kZS5sICsgXCJ9XCI7XG5cdH1cblx0cmV0dXJuIFwie19fU0VST1ZBTF9TRVFVRU5DRV9fOiEwLHY6W10sdDotMSxkOjB9XCI7XG59XG5mdW5jdGlvbiBzZXJpYWxpemVBc3NpZ25hYmxlKGN0eCwgbm9kZSkge1xuXHRzd2l0Y2ggKG5vZGUudCkge1xuXHRcdGNhc2UgMTc6IHJldHVybiBTWU1CT0xfU1RSSU5HW25vZGUuc107XG5cdFx0Y2FzZSAxODogcmV0dXJuIHNlcmlhbGl6ZVJlZmVyZW5jZShub2RlKTtcblx0XHRjYXNlIDk6IHJldHVybiBzZXJpYWxpemVBcnJheShjdHgsIG5vZGUpO1xuXHRcdGNhc2UgMTA6IHJldHVybiBzZXJpYWxpemVPYmplY3QoY3R4LCBub2RlKTtcblx0XHRjYXNlIDExOiByZXR1cm4gc2VyaWFsaXplTnVsbENvbnN0cnVjdG9yKGN0eCwgbm9kZSk7XG5cdFx0Y2FzZSA1OiByZXR1cm4gc2VyaWFsaXplRGF0ZShub2RlKTtcblx0XHRjYXNlIDY6IHJldHVybiBzZXJpYWxpemVSZWdFeHAoY3R4LCBub2RlKTtcblx0XHRjYXNlIDc6IHJldHVybiBzZXJpYWxpemVTZXQoY3R4LCBub2RlKTtcblx0XHRjYXNlIDg6IHJldHVybiBzZXJpYWxpemVNYXAoY3R4LCBub2RlKTtcblx0XHRjYXNlIDE5OiByZXR1cm4gc2VyaWFsaXplQXJyYXlCdWZmZXIoY3R4LCBub2RlKTtcblx0XHRjYXNlIDE2OlxuXHRcdGNhc2UgMTU6IHJldHVybiBzZXJpYWxpemVUeXBlZEFycmF5KGN0eCwgbm9kZSk7XG5cdFx0Y2FzZSAyMDogcmV0dXJuIHNlcmlhbGl6ZURhdGFWaWV3KGN0eCwgbm9kZSk7XG5cdFx0Y2FzZSAxNDogcmV0dXJuIHNlcmlhbGl6ZUFnZ3JlZ2F0ZUVycm9yKGN0eCwgbm9kZSk7XG5cdFx0Y2FzZSAxMzogcmV0dXJuIHNlcmlhbGl6ZUVycm9yKGN0eCwgbm9kZSk7XG5cdFx0Y2FzZSAxMjogcmV0dXJuIHNlcmlhbGl6ZVByb21pc2UoY3R4LCBub2RlKTtcblx0XHRjYXNlIDIxOiByZXR1cm4gc2VyaWFsaXplQm94ZWQoY3R4LCBub2RlKTtcblx0XHRjYXNlIDIyOiByZXR1cm4gc2VyaWFsaXplUHJvbWlzZUNvbnN0cnVjdG9yKGN0eCwgbm9kZSk7XG5cdFx0Y2FzZSAyNTogcmV0dXJuIHNlcmlhbGl6ZVBsdWdpbihjdHgsIG5vZGUpO1xuXHRcdGNhc2UgMjY6IHJldHVybiBTUEVDSUFMX1JFRl9TVFJJTkdbbm9kZS5zXTtcblx0XHRjYXNlIDM1OiByZXR1cm4gc2VyaWFsaXplU2VxdWVuY2UoY3R4LCBub2RlKTtcblx0XHRjYXNlIDM2OiByZXR1cm4gc2VyaWFsaXplVGVtcG9yYWwoY3R4LCBub2RlKTtcblx0XHRkZWZhdWx0OiB0aHJvdyBuZXcgU2Vyb3ZhbFVuc3VwcG9ydGVkTm9kZUVycm9yKG5vZGUpO1xuXHR9XG59XG5mdW5jdGlvbiBzZXJpYWxpemUkMShjdHgsIG5vZGUpIHtcblx0c3dpdGNoIChub2RlLnQpIHtcblx0XHRjYXNlIDI6IHJldHVybiBDT05TVEFOVF9TVFJJTkdbbm9kZS5zXTtcblx0XHRjYXNlIDA6IHJldHVybiBcIlwiICsgbm9kZS5zO1xuXHRcdGNhc2UgMTogcmV0dXJuIFwiXFxcIlwiICsgbm9kZS5zICsgXCJcXFwiXCI7XG5cdFx0Y2FzZSAzOiByZXR1cm4gbm9kZS5zICsgXCJuXCI7XG5cdFx0Y2FzZSA0OiByZXR1cm4gZ2V0UmVmUGFyYW0oY3R4LCBub2RlLmkpO1xuXHRcdGNhc2UgMjM6IHJldHVybiBzZXJpYWxpemVQcm9taXNlUmVzb2x2ZShjdHgsIG5vZGUpO1xuXHRcdGNhc2UgMjQ6IHJldHVybiBzZXJpYWxpemVQcm9taXNlUmVqZWN0KGN0eCwgbm9kZSk7XG5cdFx0Y2FzZSAyNzogcmV0dXJuIHNlcmlhbGl6ZUl0ZXJhdG9yRmFjdG9yeShjdHgsIG5vZGUpO1xuXHRcdGNhc2UgMjg6IHJldHVybiBzZXJpYWxpemVJdGVyYXRvckZhY3RvcnlJbnN0YW5jZShjdHgsIG5vZGUpO1xuXHRcdGNhc2UgMjk6IHJldHVybiBzZXJpYWxpemVBc3luY0l0ZXJhdG9yRmFjdG9yeShjdHgsIG5vZGUpO1xuXHRcdGNhc2UgMzA6IHJldHVybiBzZXJpYWxpemVBc3luY0l0ZXJhdG9yRmFjdG9yeUluc3RhbmNlKGN0eCwgbm9kZSk7XG5cdFx0Y2FzZSAzMTogcmV0dXJuIHNlcmlhbGl6ZVN0cmVhbUNvbnN0cnVjdG9yKGN0eCwgbm9kZSk7XG5cdFx0Y2FzZSAzMjogcmV0dXJuIHNlcmlhbGl6ZVN0cmVhbU5leHQoY3R4LCBub2RlKTtcblx0XHRjYXNlIDMzOiByZXR1cm4gc2VyaWFsaXplU3RyZWFtVGhyb3coY3R4LCBub2RlKTtcblx0XHRjYXNlIDM0OiByZXR1cm4gc2VyaWFsaXplU3RyZWFtUmV0dXJuKGN0eCwgbm9kZSk7XG5cdFx0ZGVmYXVsdDogcmV0dXJuIGFzc2lnbkluZGV4ZWRWYWx1ZShjdHgsIG5vZGUuaSwgc2VyaWFsaXplQXNzaWduYWJsZShjdHgsIG5vZGUpKTtcblx0fVxufVxuZnVuY3Rpb24gc2VyaWFsaXplVG9wVmFuaWxsYShjdHgsIHRyZWUpIHtcblx0Y29uc3QgcmVzdWx0ID0gc2VyaWFsaXplJDEoY3R4LCB0cmVlKTtcblx0aWYgKHRyZWUuaSAhPSBudWxsICYmIGN0eC5zdGF0ZS52YXJzLmxlbmd0aCkge1xuXHRcdGNvbnN0IHBhdGNoZXMgPSByZXNvbHZlUGF0Y2hlcyhjdHguYmFzZSk7XG5cdFx0bGV0IGJvZHkgPSByZXN1bHQ7XG5cdFx0aWYgKHBhdGNoZXMpIHtcblx0XHRcdGNvbnN0IGluZGV4ID0gZ2V0UmVmUGFyYW0oY3R4LCB0cmVlLmkpO1xuXHRcdFx0Ym9keSA9IHJlc3VsdCArIFwiLFwiICsgcGF0Y2hlcyArIGluZGV4O1xuXHRcdFx0aWYgKCFyZXN1bHQuc3RhcnRzV2l0aChpbmRleCArIFwiPVwiKSkgYm9keSA9IGluZGV4ICsgXCI9XCIgKyBib2R5O1xuXHRcdFx0Ym9keSA9IFwiKFwiICsgYm9keSArIFwiKVwiO1xuXHRcdH1cblx0XHRyZXR1cm4gXCIoXCIgKyBjcmVhdGVGdW5jdGlvbihjdHguc3RhdGUudmFycywgYm9keSkgKyBcIikoKVwiO1xuXHR9XG5cdGlmICh0cmVlLnQgPT09IDEwKSByZXR1cm4gXCIoXCIgKyByZXN1bHQgKyBcIilcIjtcblx0cmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZVRvcENyb3NzKGN0eCwgdHJlZSkge1xuXHRjb25zdCByZXN1bHQgPSBzZXJpYWxpemUkMShjdHgsIHRyZWUpO1xuXHRjb25zdCBpZCA9IHRyZWUuaTtcblx0aWYgKGlkID09IG51bGwpIHJldHVybiByZXN1bHQ7XG5cdGNvbnN0IHBhdGNoZXMgPSByZXNvbHZlUGF0Y2hlcyhjdHguYmFzZSk7XG5cdGNvbnN0IHJlZiA9IGdldFJlZlBhcmFtKGN0eCwgaWQpO1xuXHRjb25zdCBzY29wZUlkID0gY3R4LnN0YXRlLnNjb3BlSWQ7XG5cdGNvbnN0IHBhcmFtcyA9IHNjb3BlSWQgPT0gbnVsbCA/IFwiXCIgOiBcIiRSXCI7XG5cdGNvbnN0IGJvZHkgPSBwYXRjaGVzID8gXCIoXCIgKyByZXN1bHQgKyBcIixcIiArIHBhdGNoZXMgKyByZWYgKyBcIilcIiA6IHJlc3VsdDtcblx0aWYgKHBhcmFtcyA9PT0gXCJcIikge1xuXHRcdGlmICh0cmVlLnQgPT09IDEwICYmICFwYXRjaGVzKSByZXR1cm4gXCIoXCIgKyBib2R5ICsgXCIpXCI7XG5cdFx0cmV0dXJuIGJvZHk7XG5cdH1cblx0Y29uc3QgYXJncyA9IHNjb3BlSWQgPT0gbnVsbCA/IFwiKClcIiA6IFwiKCRSW1xcXCJcIiArIHNlcmlhbGl6ZVN0cmluZyhzY29wZUlkKSArIFwiXFxcIl0pXCI7XG5cdHJldHVybiBcIihcIiArIGNyZWF0ZUZ1bmN0aW9uKFtwYXJhbXNdLCBib2R5KSArIFwiKVwiICsgYXJncztcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2NvbnRleHQvc3luYy1wYXJzZXIudHNcbmZ1bmN0aW9uIGNyZWF0ZVN5bmNQYXJzZXJDb250ZXh0KG1vZGUsIG9wdGlvbnMpIHtcblx0cmV0dXJuIHtcblx0XHR0eXBlOiAxLFxuXHRcdGJhc2U6IGNyZWF0ZUJhc2VQYXJzZXJDb250ZXh0KG1vZGUsIG9wdGlvbnMpLFxuXHRcdGNoaWxkOiB2b2lkIDBcblx0fTtcbn1cbnZhciBTeW5jUGFyc2VQbHVnaW5Db250ZXh0ID0gY2xhc3Mge1xuXHRjb25zdHJ1Y3RvcihfcCwgZGVwdGgpIHtcblx0XHR0aGlzLl9wID0gX3A7XG5cdFx0dGhpcy5kZXB0aCA9IGRlcHRoO1xuXHR9XG5cdHBhcnNlKGN1cnJlbnQpIHtcblx0XHRyZXR1cm4gcGFyc2VTT1ModGhpcy5fcCwgdGhpcy5kZXB0aCwgY3VycmVudCk7XG5cdH1cbn07XG52YXIgU3RyZWFtUGFyc2VQbHVnaW5Db250ZXh0ID0gY2xhc3Mge1xuXHRjb25zdHJ1Y3RvcihfcCwgZGVwdGgpIHtcblx0XHR0aGlzLl9wID0gX3A7XG5cdFx0dGhpcy5kZXB0aCA9IGRlcHRoO1xuXHR9XG5cdHBhcnNlKGN1cnJlbnQpIHtcblx0XHRyZXR1cm4gcGFyc2VTT1ModGhpcy5fcCwgdGhpcy5kZXB0aCwgY3VycmVudCk7XG5cdH1cblx0cGFyc2VXaXRoRXJyb3IoY3VycmVudCkge1xuXHRcdHJldHVybiBwYXJzZVdpdGhFcnJvcih0aGlzLl9wLCB0aGlzLmRlcHRoLCBjdXJyZW50KTtcblx0fVxuXHRpc0FsaXZlKCkge1xuXHRcdHJldHVybiB0aGlzLl9wLnN0YXRlLmFsaXZlO1xuXHR9XG5cdHB1c2hQZW5kaW5nU3RhdGUoKSB7XG5cdFx0cHVzaFBlbmRpbmdTdGF0ZSh0aGlzLl9wKTtcblx0fVxuXHRwb3BQZW5kaW5nU3RhdGUoKSB7XG5cdFx0cG9wUGVuZGluZ1N0YXRlKHRoaXMuX3ApO1xuXHR9XG5cdG9uUGFyc2Uobm9kZSkge1xuXHRcdG9uUGFyc2UodGhpcy5fcCwgbm9kZSk7XG5cdH1cblx0b25FcnJvcihlcnJvcikge1xuXHRcdG9uRXJyb3IodGhpcy5fcCwgZXJyb3IpO1xuXHR9XG5cdGFkZENsZWFudXAoY2FsbGJhY2spIHtcblx0XHR0aGlzLl9wLnN0YXRlLmNsZWFudXBzLnB1c2goY2FsbGJhY2spO1xuXHR9XG59O1xuZnVuY3Rpb24gY3JlYXRlU3RyZWFtUGFyc2VyU3RhdGUob3B0aW9ucykge1xuXHRyZXR1cm4ge1xuXHRcdGFsaXZlOiB0cnVlLFxuXHRcdHBlbmRpbmc6IDAsXG5cdFx0aW5pdGlhbDogdHJ1ZSxcblx0XHRidWZmZXI6IFtdLFxuXHRcdG9uUGFyc2U6IG9wdGlvbnMub25QYXJzZSxcblx0XHRvbkVycm9yOiBvcHRpb25zLm9uRXJyb3IsXG5cdFx0b25Eb25lOiBvcHRpb25zLm9uRG9uZSxcblx0XHRjbGVhbnVwczogW11cblx0fTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVN0cmVhbVBhcnNlckNvbnRleHQob3B0aW9ucykge1xuXHRyZXR1cm4ge1xuXHRcdHR5cGU6IDIsXG5cdFx0YmFzZTogY3JlYXRlQmFzZVBhcnNlckNvbnRleHQoMiwgb3B0aW9ucyksXG5cdFx0c3RhdGU6IGNyZWF0ZVN0cmVhbVBhcnNlclN0YXRlKG9wdGlvbnMpXG5cdH07XG59XG5mdW5jdGlvbiBwYXJzZUl0ZW1zKGN0eCwgZGVwdGgsIGN1cnJlbnQpIHtcblx0Y29uc3Qgbm9kZXMgPSBbXTtcblx0Zm9yIChsZXQgaSA9IDAsIGxlbiA9IGN1cnJlbnQubGVuZ3RoOyBpIDwgbGVuOyBpKyspIGlmIChpIGluIGN1cnJlbnQpIG5vZGVzW2ldID0gcGFyc2VTT1MoY3R4LCBkZXB0aCwgY3VycmVudFtpXSk7XG5cdGVsc2Ugbm9kZXNbaV0gPSAwO1xuXHRyZXR1cm4gbm9kZXM7XG59XG5mdW5jdGlvbiBwYXJzZUFycmF5KGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KSB7XG5cdHJldHVybiBjcmVhdGVBcnJheU5vZGUoaWQsIGN1cnJlbnQsIHBhcnNlSXRlbXMoY3R4LCBkZXB0aCwgY3VycmVudCkpO1xufVxuZnVuY3Rpb24gcGFyc2VQcm9wZXJ0aWVzKGN0eCwgZGVwdGgsIHByb3BlcnRpZXMpIHtcblx0Y29uc3QgZW50cmllcyA9IE9iamVjdC5lbnRyaWVzKHByb3BlcnRpZXMpO1xuXHRjb25zdCBrZXlOb2RlcyA9IFtdO1xuXHRjb25zdCB2YWx1ZU5vZGVzID0gW107XG5cdGZvciAobGV0IGkgPSAwLCBsZW4gPSBlbnRyaWVzLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG5cdFx0a2V5Tm9kZXMucHVzaChzZXJpYWxpemVTdHJpbmcoZW50cmllc1tpXVswXSkpO1xuXHRcdHZhbHVlTm9kZXMucHVzaChwYXJzZVNPUyhjdHgsIGRlcHRoLCBlbnRyaWVzW2ldWzFdKSk7XG5cdH1cblx0aWYgKFNZTV9JVEVSQVRPUiBpbiBwcm9wZXJ0aWVzKSB7XG5cdFx0a2V5Tm9kZXMucHVzaChwYXJzZVdlbGxLbm93blN5bWJvbChjdHguYmFzZSwgU1lNX0lURVJBVE9SKSk7XG5cdFx0dmFsdWVOb2Rlcy5wdXNoKGNyZWF0ZUl0ZXJhdG9yRmFjdG9yeUluc3RhbmNlTm9kZShwYXJzZUl0ZXJhdG9yRmFjdG9yeShjdHguYmFzZSksIHBhcnNlU09TKGN0eCwgZGVwdGgsIGNyZWF0ZVNlcXVlbmNlRnJvbUl0ZXJhYmxlKHByb3BlcnRpZXMpKSkpO1xuXHR9XG5cdGlmIChTWU1fQVNZTkNfSVRFUkFUT1IgaW4gcHJvcGVydGllcykge1xuXHRcdGtleU5vZGVzLnB1c2gocGFyc2VXZWxsS25vd25TeW1ib2woY3R4LmJhc2UsIFNZTV9BU1lOQ19JVEVSQVRPUikpO1xuXHRcdHZhbHVlTm9kZXMucHVzaChjcmVhdGVBc3luY0l0ZXJhdG9yRmFjdG9yeUluc3RhbmNlTm9kZShwYXJzZUFzeW5jSXRlcmF0b3JGYWN0b3J5KGN0eC5iYXNlKSwgcGFyc2VTT1MoY3R4LCBkZXB0aCwgY3R4LnR5cGUgPT09IDEgPyBjcmVhdGVTdHJlYW0oKSA6IGNyZWF0ZVN0cmVhbUZyb21Bc3luY0l0ZXJhYmxlKHByb3BlcnRpZXMsIGN0eC5zdGF0ZS5jbGVhbnVwcykpKSk7XG5cdH1cblx0aWYgKFNZTV9UT19TVFJJTkdfVEFHIGluIHByb3BlcnRpZXMpIHtcblx0XHRrZXlOb2Rlcy5wdXNoKHBhcnNlV2VsbEtub3duU3ltYm9sKGN0eC5iYXNlLCBTWU1fVE9fU1RSSU5HX1RBRykpO1xuXHRcdHZhbHVlTm9kZXMucHVzaChjcmVhdGVTdHJpbmdOb2RlKHByb3BlcnRpZXNbU1lNX1RPX1NUUklOR19UQUddKSk7XG5cdH1cblx0aWYgKFNZTV9JU19DT05DQVRfU1BSRUFEQUJMRSBpbiBwcm9wZXJ0aWVzKSB7XG5cdFx0a2V5Tm9kZXMucHVzaChwYXJzZVdlbGxLbm93blN5bWJvbChjdHguYmFzZSwgU1lNX0lTX0NPTkNBVF9TUFJFQURBQkxFKSk7XG5cdFx0dmFsdWVOb2Rlcy5wdXNoKHByb3BlcnRpZXNbU1lNX0lTX0NPTkNBVF9TUFJFQURBQkxFXSA/IFRSVUVfTk9ERSA6IEZBTFNFX05PREUpO1xuXHR9XG5cdHJldHVybiB7XG5cdFx0azoga2V5Tm9kZXMsXG5cdFx0djogdmFsdWVOb2Rlc1xuXHR9O1xufVxuZnVuY3Rpb24gcGFyc2VQbGFpbk9iamVjdChjdHgsIGRlcHRoLCBpZCwgY3VycmVudCwgZW1wdHkpIHtcblx0cmV0dXJuIGNyZWF0ZU9iamVjdE5vZGUoaWQsIGN1cnJlbnQsIGVtcHR5LCBwYXJzZVByb3BlcnRpZXMoY3R4LCBkZXB0aCwgY3VycmVudCkpO1xufVxuZnVuY3Rpb24gcGFyc2VCb3hlZChjdHgsIGRlcHRoLCBpZCwgY3VycmVudCkge1xuXHRyZXR1cm4gY3JlYXRlQm94ZWROb2RlKGlkLCBwYXJzZVNPUyhjdHgsIGRlcHRoLCBjdXJyZW50LnZhbHVlT2YoKSkpO1xufVxuZnVuY3Rpb24gcGFyc2VUeXBlZEFycmF5KGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KSB7XG5cdGN1cnJlbnQgPSBnZXRBcnJheUJ1ZmZlclZpZXcoY3R4LmJhc2UsIGN1cnJlbnQpO1xuXHRyZXR1cm4gY3JlYXRlVHlwZWRBcnJheU5vZGUoaWQsIGN1cnJlbnQsIHBhcnNlU09TKGN0eCwgZGVwdGgsIGN1cnJlbnQuYnVmZmVyKSk7XG59XG5mdW5jdGlvbiBwYXJzZUJpZ0ludFR5cGVkQXJyYXkoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpIHtcblx0Y3VycmVudCA9IGdldEFycmF5QnVmZmVyVmlldyhjdHguYmFzZSwgY3VycmVudCk7XG5cdHJldHVybiBjcmVhdGVCaWdJbnRUeXBlZEFycmF5Tm9kZShpZCwgY3VycmVudCwgcGFyc2VTT1MoY3R4LCBkZXB0aCwgY3VycmVudC5idWZmZXIpKTtcbn1cbmZ1bmN0aW9uIHBhcnNlRGF0YVZpZXcoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpIHtcblx0Y3VycmVudCA9IGdldEFycmF5QnVmZmVyVmlldyhjdHguYmFzZSwgY3VycmVudCk7XG5cdHJldHVybiBjcmVhdGVEYXRhVmlld05vZGUoaWQsIGN1cnJlbnQsIHBhcnNlU09TKGN0eCwgZGVwdGgsIGN1cnJlbnQuYnVmZmVyKSk7XG59XG5mdW5jdGlvbiBwYXJzZUVycm9yKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KSB7XG5cdGNvbnN0IG9wdGlvbnMgPSBnZXRFcnJvck9wdGlvbnMoY3VycmVudCwgY3R4LmJhc2UuZmVhdHVyZXMpO1xuXHRyZXR1cm4gY3JlYXRlRXJyb3JOb2RlKGlkLCBjdXJyZW50LCBvcHRpb25zID8gcGFyc2VQcm9wZXJ0aWVzKGN0eCwgZGVwdGgsIG9wdGlvbnMpIDogdm9pZCAwKTtcbn1cbmZ1bmN0aW9uIHBhcnNlQWdncmVnYXRlRXJyb3IoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpIHtcblx0Y29uc3Qgb3B0aW9ucyA9IGdldEVycm9yT3B0aW9ucyhjdXJyZW50LCBjdHguYmFzZS5mZWF0dXJlcyk7XG5cdHJldHVybiBjcmVhdGVBZ2dyZWdhdGVFcnJvck5vZGUoaWQsIGN1cnJlbnQsIG9wdGlvbnMgPyBwYXJzZVByb3BlcnRpZXMoY3R4LCBkZXB0aCwgb3B0aW9ucykgOiB2b2lkIDApO1xufVxuZnVuY3Rpb24gcGFyc2VNYXAoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpIHtcblx0Y29uc3Qga2V5Tm9kZXMgPSBbXTtcblx0Y29uc3QgdmFsdWVOb2RlcyA9IFtdO1xuXHRmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBjdXJyZW50LmVudHJpZXMoKSkge1xuXHRcdGtleU5vZGVzLnB1c2gocGFyc2VTT1MoY3R4LCBkZXB0aCwga2V5KSk7XG5cdFx0dmFsdWVOb2Rlcy5wdXNoKHBhcnNlU09TKGN0eCwgZGVwdGgsIHZhbHVlKSk7XG5cdH1cblx0cmV0dXJuIGNyZWF0ZU1hcE5vZGUoY3R4LmJhc2UsIGlkLCBrZXlOb2RlcywgdmFsdWVOb2Rlcyk7XG59XG5mdW5jdGlvbiBwYXJzZVNldChjdHgsIGRlcHRoLCBpZCwgY3VycmVudCkge1xuXHRjb25zdCBpdGVtcyA9IFtdO1xuXHRmb3IgKGNvbnN0IGl0ZW0gb2YgY3VycmVudC5rZXlzKCkpIGl0ZW1zLnB1c2gocGFyc2VTT1MoY3R4LCBkZXB0aCwgaXRlbSkpO1xuXHRyZXR1cm4gY3JlYXRlU2V0Tm9kZShpZCwgaXRlbXMpO1xufVxuZnVuY3Rpb24gcGFyc2VTdHJlYW0oY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpIHtcblx0Y29uc3QgcmVzdWx0ID0gY3JlYXRlU3RyZWFtQ29uc3RydWN0b3JOb2RlKGlkLCBwYXJzZVNwZWNpYWxSZWZlcmVuY2UoY3R4LmJhc2UsIDQpLCBbXSk7XG5cdGlmIChjdHgudHlwZSA9PT0gMSkgcmV0dXJuIHJlc3VsdDtcblx0cHVzaFBlbmRpbmdTdGF0ZShjdHgpO1xuXHRjdXJyZW50Lm9uKHtcblx0XHRuZXh0OiAodmFsdWUpID0+IHtcblx0XHRcdGlmIChjdHguc3RhdGUuYWxpdmUpIHtcblx0XHRcdFx0Y29uc3QgcGFyc2VkID0gcGFyc2VXaXRoRXJyb3IoY3R4LCBkZXB0aCwgdmFsdWUpO1xuXHRcdFx0XHRpZiAocGFyc2VkKSBvblBhcnNlKGN0eCwgY3JlYXRlU3RyZWFtTmV4dE5vZGUoaWQsIHBhcnNlZCkpO1xuXHRcdFx0fVxuXHRcdH0sXG5cdFx0dGhyb3c6ICh2YWx1ZSkgPT4ge1xuXHRcdFx0aWYgKGN0eC5zdGF0ZS5hbGl2ZSkge1xuXHRcdFx0XHRjb25zdCBwYXJzZWQgPSBwYXJzZVdpdGhFcnJvcihjdHgsIGRlcHRoLCB2YWx1ZSk7XG5cdFx0XHRcdGlmIChwYXJzZWQpIG9uUGFyc2UoY3R4LCBjcmVhdGVTdHJlYW1UaHJvd05vZGUoaWQsIHBhcnNlZCkpO1xuXHRcdFx0fVxuXHRcdFx0cG9wUGVuZGluZ1N0YXRlKGN0eCk7XG5cdFx0fSxcblx0XHRyZXR1cm46ICh2YWx1ZSkgPT4ge1xuXHRcdFx0aWYgKGN0eC5zdGF0ZS5hbGl2ZSkge1xuXHRcdFx0XHRjb25zdCBwYXJzZWQgPSBwYXJzZVdpdGhFcnJvcihjdHgsIGRlcHRoLCB2YWx1ZSk7XG5cdFx0XHRcdGlmIChwYXJzZWQpIG9uUGFyc2UoY3R4LCBjcmVhdGVTdHJlYW1SZXR1cm5Ob2RlKGlkLCBwYXJzZWQpKTtcblx0XHRcdH1cblx0XHRcdHBvcFBlbmRpbmdTdGF0ZShjdHgpO1xuXHRcdH1cblx0fSk7XG5cdHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBoYW5kbGVQcm9taXNlU3VjY2VzcyhpZCwgZGVwdGgsIGRhdGEpIHtcblx0aWYgKHRoaXMuc3RhdGUuYWxpdmUpIHtcblx0XHRjb25zdCBwYXJzZWQgPSBwYXJzZVdpdGhFcnJvcih0aGlzLCBkZXB0aCwgZGF0YSk7XG5cdFx0aWYgKHBhcnNlZCkgb25QYXJzZSh0aGlzLCBjcmVhdGVTZXJvdmFsTm9kZSgyMywgaWQsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCBbcGFyc2VTcGVjaWFsUmVmZXJlbmNlKHRoaXMuYmFzZSwgMiksIHBhcnNlZF0sIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCkpO1xuXHRcdHBvcFBlbmRpbmdTdGF0ZSh0aGlzKTtcblx0fVxufVxuZnVuY3Rpb24gaGFuZGxlUHJvbWlzZUZhaWx1cmUoaWQsIGRlcHRoLCBkYXRhKSB7XG5cdGlmICh0aGlzLnN0YXRlLmFsaXZlKSB7XG5cdFx0Y29uc3QgcGFyc2VkID0gcGFyc2VXaXRoRXJyb3IodGhpcywgZGVwdGgsIGRhdGEpO1xuXHRcdGlmIChwYXJzZWQpIG9uUGFyc2UodGhpcywgY3JlYXRlU2Vyb3ZhbE5vZGUoMjQsIGlkLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDAsIHZvaWQgMCwgW3BhcnNlU3BlY2lhbFJlZmVyZW5jZSh0aGlzLmJhc2UsIDMpLCBwYXJzZWRdLCB2b2lkIDAsIHZvaWQgMCwgdm9pZCAwLCB2b2lkIDApKTtcblx0fVxuXHRwb3BQZW5kaW5nU3RhdGUodGhpcyk7XG59XG5mdW5jdGlvbiBwYXJzZVByb21pc2UoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpIHtcblx0Y29uc3QgcmVzb2x2ZXIgPSBjcmVhdGVJbmRleEZvclZhbHVlKGN0eC5iYXNlLCB7fSk7XG5cdGlmIChjdHgudHlwZSA9PT0gMikge1xuXHRcdHB1c2hQZW5kaW5nU3RhdGUoY3R4KTtcblx0XHRjdXJyZW50LnRoZW4oaGFuZGxlUHJvbWlzZVN1Y2Nlc3MuYmluZChjdHgsIHJlc29sdmVyLCBkZXB0aCksIGhhbmRsZVByb21pc2VGYWlsdXJlLmJpbmQoY3R4LCByZXNvbHZlciwgZGVwdGgpKTtcblx0fVxuXHRyZXR1cm4gY3JlYXRlUHJvbWlzZUNvbnN0cnVjdG9yTm9kZShjdHguYmFzZSwgaWQsIHJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIHBhcnNlUGx1Z2luU3luYyhjdHgsIGRlcHRoLCBpZCwgY3VycmVudCwgY3VycmVudFBsdWdpbnMpIHtcblx0Zm9yIChsZXQgaSA9IDAsIGxlbiA9IGN1cnJlbnRQbHVnaW5zLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG5cdFx0Y29uc3QgcGx1Z2luID0gY3VycmVudFBsdWdpbnNbaV07XG5cdFx0aWYgKHBsdWdpbi5wYXJzZS5zeW5jICYmIHBsdWdpbi50ZXN0KGN1cnJlbnQpKSByZXR1cm4gY3JlYXRlUGx1Z2luTm9kZShpZCwgcGx1Z2luLnRhZywgcGx1Z2luLnBhcnNlLnN5bmMoY3VycmVudCwgbmV3IFN5bmNQYXJzZVBsdWdpbkNvbnRleHQoY3R4LCBkZXB0aCksIHsgaWQgfSkpO1xuXHR9XG59XG5mdW5jdGlvbiBwYXJzZVBsdWdpblN0cmVhbShjdHgsIGRlcHRoLCBpZCwgY3VycmVudCwgY3VycmVudFBsdWdpbnMpIHtcblx0Zm9yIChsZXQgaSA9IDAsIGxlbiA9IGN1cnJlbnRQbHVnaW5zLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG5cdFx0Y29uc3QgcGx1Z2luID0gY3VycmVudFBsdWdpbnNbaV07XG5cdFx0aWYgKHBsdWdpbi5wYXJzZS5zdHJlYW0gJiYgcGx1Z2luLnRlc3QoY3VycmVudCkpIHJldHVybiBjcmVhdGVQbHVnaW5Ob2RlKGlkLCBwbHVnaW4udGFnLCBwbHVnaW4ucGFyc2Uuc3RyZWFtKGN1cnJlbnQsIG5ldyBTdHJlYW1QYXJzZVBsdWdpbkNvbnRleHQoY3R4LCBkZXB0aCksIHsgaWQgfSkpO1xuXHR9XG59XG5mdW5jdGlvbiBwYXJzZVBsdWdpbihjdHgsIGRlcHRoLCBpZCwgY3VycmVudCkge1xuXHRjb25zdCBjdXJyZW50UGx1Z2lucyA9IGN0eC5iYXNlLnBsdWdpbnM7XG5cdGlmIChjdXJyZW50UGx1Z2lucykgcmV0dXJuIGN0eC50eXBlID09PSAxID8gcGFyc2VQbHVnaW5TeW5jKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50LCBjdXJyZW50UGx1Z2lucykgOiBwYXJzZVBsdWdpblN0cmVhbShjdHgsIGRlcHRoLCBpZCwgY3VycmVudCwgY3VycmVudFBsdWdpbnMpO1xufVxuZnVuY3Rpb24gcGFyc2VTZXF1ZW5jZShjdHgsIGRlcHRoLCBpZCwgY3VycmVudCkge1xuXHRjb25zdCBub2RlcyA9IFtdO1xuXHRmb3IgKGxldCBpID0gMCwgbGVuID0gY3VycmVudC52Lmxlbmd0aDsgaSA8IGxlbjsgaSsrKSBub2Rlc1tpXSA9IHBhcnNlU09TKGN0eCwgZGVwdGgsIGN1cnJlbnQudltpXSk7XG5cdHJldHVybiBjcmVhdGVTZXF1ZW5jZU5vZGUoaWQsIG5vZGVzLCBjdXJyZW50LnQsIGN1cnJlbnQuZCk7XG59XG5mdW5jdGlvbiBwYXJzZU9iamVjdFBoYXNlMihjdHgsIGRlcHRoLCBpZCwgY3VycmVudCwgY3VycmVudENsYXNzKSB7XG5cdHN3aXRjaCAoY3VycmVudENsYXNzKSB7XG5cdFx0Y2FzZSBPYmplY3Q6IHJldHVybiBwYXJzZVBsYWluT2JqZWN0KGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50LCBmYWxzZSk7XG5cdFx0Y2FzZSB2b2lkIDA6IHJldHVybiBwYXJzZVBsYWluT2JqZWN0KGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50LCB0cnVlKTtcblx0XHRjYXNlIERhdGU6IHJldHVybiBjcmVhdGVEYXRlTm9kZShpZCwgY3VycmVudCk7XG5cdFx0Y2FzZSBFcnJvcjpcblx0XHRjYXNlIEV2YWxFcnJvcjpcblx0XHRjYXNlIFJhbmdlRXJyb3I6XG5cdFx0Y2FzZSBSZWZlcmVuY2VFcnJvcjpcblx0XHRjYXNlIFN5bnRheEVycm9yOlxuXHRcdGNhc2UgVHlwZUVycm9yOlxuXHRcdGNhc2UgVVJJRXJyb3I6IHJldHVybiBwYXJzZUVycm9yKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KTtcblx0XHRjYXNlIE51bWJlcjpcblx0XHRjYXNlIEJvb2xlYW46XG5cdFx0Y2FzZSBTdHJpbmc6XG5cdFx0Y2FzZSBCaWdJbnQ6IHJldHVybiBwYXJzZUJveGVkKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KTtcblx0XHRjYXNlIEFycmF5QnVmZmVyOiByZXR1cm4gY3JlYXRlQXJyYXlCdWZmZXJOb2RlKGN0eC5iYXNlLCBpZCwgY3VycmVudCk7XG5cdFx0Y2FzZSBJbnQ4QXJyYXk6XG5cdFx0Y2FzZSBJbnQxNkFycmF5OlxuXHRcdGNhc2UgSW50MzJBcnJheTpcblx0XHRjYXNlIFVpbnQ4QXJyYXk6XG5cdFx0Y2FzZSBVaW50MTZBcnJheTpcblx0XHRjYXNlIFVpbnQzMkFycmF5OlxuXHRcdGNhc2UgVWludDhDbGFtcGVkQXJyYXk6XG5cdFx0Y2FzZSBGbG9hdDMyQXJyYXk6XG5cdFx0Y2FzZSBGbG9hdDY0QXJyYXk6IHJldHVybiBwYXJzZVR5cGVkQXJyYXkoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpO1xuXHRcdGNhc2UgRGF0YVZpZXc6IHJldHVybiBwYXJzZURhdGFWaWV3KGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KTtcblx0XHRjYXNlIE1hcDogcmV0dXJuIHBhcnNlTWFwKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KTtcblx0XHRjYXNlIFNldDogcmV0dXJuIHBhcnNlU2V0KGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KTtcblx0fVxuXHRpZiAoY3VycmVudENsYXNzID09PSBQcm9taXNlIHx8IGN1cnJlbnQgaW5zdGFuY2VvZiBQcm9taXNlKSByZXR1cm4gcGFyc2VQcm9taXNlKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KTtcblx0Y29uc3QgY3VycmVudEZlYXR1cmVzID0gY3R4LmJhc2UuZmVhdHVyZXM7XG5cdGlmIChjdXJyZW50RmVhdHVyZXMgJiAzMiAmJiBjdXJyZW50Q2xhc3MgPT09IFJlZ0V4cCkgcmV0dXJuIGNyZWF0ZVJlZ0V4cE5vZGUoaWQsIGN1cnJlbnQpO1xuXHRpZiAoY3VycmVudEZlYXR1cmVzICYgMTYpIHN3aXRjaCAoY3VycmVudENsYXNzKSB7XG5cdFx0Y2FzZSBCaWdJbnQ2NEFycmF5OlxuXHRcdGNhc2UgQmlnVWludDY0QXJyYXk6IHJldHVybiBwYXJzZUJpZ0ludFR5cGVkQXJyYXkoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpO1xuXHR9XG5cdGlmIChjdXJyZW50RmVhdHVyZXMgJiAxICYmIHR5cGVvZiBBZ2dyZWdhdGVFcnJvciAhPT0gXCJ1bmRlZmluZWRcIiAmJiAoY3VycmVudENsYXNzID09PSBBZ2dyZWdhdGVFcnJvciB8fCBjdXJyZW50IGluc3RhbmNlb2YgQWdncmVnYXRlRXJyb3IpKSByZXR1cm4gcGFyc2VBZ2dyZWdhdGVFcnJvcihjdHgsIGRlcHRoLCBpZCwgY3VycmVudCk7XG5cdGlmIChjdXJyZW50RmVhdHVyZXMgJiA2NCAmJiB0eXBlb2YgVGVtcG9yYWwgIT09IFwidW5kZWZpbmVkXCIpIHN3aXRjaCAoY3VycmVudENsYXNzKSB7XG5cdFx0Y2FzZSBUZW1wb3JhbC5JbnN0YW50OiByZXR1cm4gY3JlYXRlVGVtcG9yYWxOb2RlKGlkLCAwLCBjdXJyZW50KTtcblx0XHRjYXNlIFRlbXBvcmFsLkR1cmF0aW9uOiByZXR1cm4gY3JlYXRlVGVtcG9yYWxOb2RlKGlkLCAxLCBjdXJyZW50KTtcblx0XHRjYXNlIFRlbXBvcmFsLlBsYWluRGF0ZTogcmV0dXJuIGNyZWF0ZVRlbXBvcmFsTm9kZShpZCwgMiwgY3VycmVudCk7XG5cdFx0Y2FzZSBUZW1wb3JhbC5QbGFpbkRhdGVUaW1lOiByZXR1cm4gY3JlYXRlVGVtcG9yYWxOb2RlKGlkLCAzLCBjdXJyZW50KTtcblx0XHRjYXNlIFRlbXBvcmFsLlBsYWluTW9udGhEYXk6IHJldHVybiBjcmVhdGVUZW1wb3JhbE5vZGUoaWQsIDQsIGN1cnJlbnQpO1xuXHRcdGNhc2UgVGVtcG9yYWwuUGxhaW5UaW1lOiByZXR1cm4gY3JlYXRlVGVtcG9yYWxOb2RlKGlkLCA1LCBjdXJyZW50KTtcblx0XHRjYXNlIFRlbXBvcmFsLlBsYWluWWVhck1vbnRoOiByZXR1cm4gY3JlYXRlVGVtcG9yYWxOb2RlKGlkLCA2LCBjdXJyZW50KTtcblx0XHRjYXNlIFRlbXBvcmFsLlpvbmVkRGF0ZVRpbWU6IHJldHVybiBjcmVhdGVUZW1wb3JhbE5vZGUoaWQsIDcsIGN1cnJlbnQpO1xuXHR9XG5cdGlmIChjdXJyZW50IGluc3RhbmNlb2YgRXJyb3IpIHJldHVybiBwYXJzZUVycm9yKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KTtcblx0aWYgKFNZTV9JVEVSQVRPUiBpbiBjdXJyZW50IHx8IFNZTV9BU1lOQ19JVEVSQVRPUiBpbiBjdXJyZW50KSByZXR1cm4gcGFyc2VQbGFpbk9iamVjdChjdHgsIGRlcHRoLCBpZCwgY3VycmVudCwgISFjdXJyZW50Q2xhc3MpO1xuXHR0aHJvdyBuZXcgU2Vyb3ZhbFVuc3VwcG9ydGVkVHlwZUVycm9yKGN1cnJlbnQpO1xufVxuZnVuY3Rpb24gcGFyc2VPYmplY3QoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpIHtcblx0aWYgKEFycmF5LmlzQXJyYXkoY3VycmVudCkpIHJldHVybiBwYXJzZUFycmF5KGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KTtcblx0aWYgKGlzU3RyZWFtKGN1cnJlbnQpKSByZXR1cm4gcGFyc2VTdHJlYW0oY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpO1xuXHRpZiAoaXNTZXF1ZW5jZShjdXJyZW50KSkgcmV0dXJuIHBhcnNlU2VxdWVuY2UoY3R4LCBkZXB0aCwgaWQsIGN1cnJlbnQpO1xuXHRsZXQgY3VycmVudENsYXNzID0gY3VycmVudC5jb25zdHJ1Y3Rvcjtcblx0aWYgKGN1cnJlbnRDbGFzcyAhPT0gdm9pZCAwICYmIHR5cGVvZiBjdXJyZW50Q2xhc3MgIT09IFwiZnVuY3Rpb25cIikge1xuXHRcdGNvbnN0IHByb3RvID0gT2JqZWN0LmdldFByb3RvdHlwZU9mKGN1cnJlbnQpO1xuXHRcdGN1cnJlbnRDbGFzcyA9IHByb3RvID09PSBudWxsID8gdm9pZCAwIDogcHJvdG8uY29uc3RydWN0b3I7XG5cdH1cblx0aWYgKGN1cnJlbnRDbGFzcyA9PT0gT3BhcXVlUmVmZXJlbmNlKSByZXR1cm4gcGFyc2VTT1MoY3R4LCBkZXB0aCwgY3VycmVudC5yZXBsYWNlbWVudCk7XG5cdGNvbnN0IHBhcnNlZCA9IHBhcnNlUGx1Z2luKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50KTtcblx0aWYgKHBhcnNlZCkgcmV0dXJuIHBhcnNlZDtcblx0cmV0dXJuIHBhcnNlT2JqZWN0UGhhc2UyKGN0eCwgZGVwdGgsIGlkLCBjdXJyZW50LCBjdXJyZW50Q2xhc3MpO1xufVxuZnVuY3Rpb24gcGFyc2VGdW5jdGlvbihjdHgsIGRlcHRoLCBjdXJyZW50KSB7XG5cdGNvbnN0IHJlZiA9IGdldFJlZmVyZW5jZU5vZGUoY3R4LmJhc2UsIGN1cnJlbnQpO1xuXHRpZiAocmVmLnR5cGUgIT09IDApIHJldHVybiByZWYudmFsdWU7XG5cdGNvbnN0IHBsdWdpbiA9IHBhcnNlUGx1Z2luKGN0eCwgZGVwdGgsIHJlZi52YWx1ZSwgY3VycmVudCk7XG5cdGlmIChwbHVnaW4pIHJldHVybiBwbHVnaW47XG5cdHRocm93IG5ldyBTZXJvdmFsVW5zdXBwb3J0ZWRUeXBlRXJyb3IoY3VycmVudCk7XG59XG5mdW5jdGlvbiBwYXJzZVNPUyhjdHgsIGRlcHRoLCBjdXJyZW50KSB7XG5cdGlmIChkZXB0aCA+PSBjdHguYmFzZS5kZXB0aExpbWl0KSB0aHJvdyBuZXcgU2Vyb3ZhbERlcHRoTGltaXRFcnJvcihjdHguYmFzZS5kZXB0aExpbWl0KTtcblx0c3dpdGNoICh0eXBlb2YgY3VycmVudCkge1xuXHRcdGNhc2UgXCJib29sZWFuXCI6IHJldHVybiBjdXJyZW50ID8gVFJVRV9OT0RFIDogRkFMU0VfTk9ERTtcblx0XHRjYXNlIFwidW5kZWZpbmVkXCI6IHJldHVybiBVTkRFRklORURfTk9ERTtcblx0XHRjYXNlIFwic3RyaW5nXCI6IHJldHVybiBjcmVhdGVTdHJpbmdOb2RlKGN1cnJlbnQpO1xuXHRcdGNhc2UgXCJudW1iZXJcIjogcmV0dXJuIGNyZWF0ZU51bWJlck5vZGUoY3VycmVudCk7XG5cdFx0Y2FzZSBcImJpZ2ludFwiOiByZXR1cm4gY3JlYXRlQmlnSW50Tm9kZShjdXJyZW50KTtcblx0XHRjYXNlIFwib2JqZWN0XCI6XG5cdFx0XHRpZiAoY3VycmVudCkge1xuXHRcdFx0XHRjb25zdCByZWYgPSBnZXRSZWZlcmVuY2VOb2RlKGN0eC5iYXNlLCBjdXJyZW50KTtcblx0XHRcdFx0cmV0dXJuIHJlZi50eXBlID09PSAwID8gcGFyc2VPYmplY3QoY3R4LCBkZXB0aCArIDEsIHJlZi52YWx1ZSwgY3VycmVudCkgOiByZWYudmFsdWU7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gTlVMTF9OT0RFO1xuXHRcdGNhc2UgXCJzeW1ib2xcIjogcmV0dXJuIHBhcnNlV2VsbEtub3duU3ltYm9sKGN0eC5iYXNlLCBjdXJyZW50KTtcblx0XHRjYXNlIFwiZnVuY3Rpb25cIjogcmV0dXJuIHBhcnNlRnVuY3Rpb24oY3R4LCBkZXB0aCwgY3VycmVudCk7XG5cdFx0ZGVmYXVsdDogdGhyb3cgbmV3IFNlcm92YWxVbnN1cHBvcnRlZFR5cGVFcnJvcihjdXJyZW50KTtcblx0fVxufVxuZnVuY3Rpb24gcGFyc2VUb3AoY3R4LCBjdXJyZW50KSB7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIHBhcnNlU09TKGN0eCwgMCwgY3VycmVudCk7XG5cdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0dGhyb3cgZXJyb3IgaW5zdGFuY2VvZiBTZXJvdmFsUGFyc2VyRXJyb3IgPyBlcnJvciA6IG5ldyBTZXJvdmFsUGFyc2VyRXJyb3IoZXJyb3IpO1xuXHR9XG59XG5mdW5jdGlvbiBvblBhcnNlKGN0eCwgbm9kZSkge1xuXHRpZiAoY3R4LnN0YXRlLmluaXRpYWwpIGN0eC5zdGF0ZS5idWZmZXIucHVzaChub2RlKTtcblx0ZWxzZSBvblBhcnNlSW50ZXJuYWwoY3R4LCBub2RlLCBmYWxzZSk7XG59XG5mdW5jdGlvbiBvbkVycm9yKGN0eCwgZXJyb3IpIHtcblx0aWYgKGN0eC5zdGF0ZS5vbkVycm9yKSBjdHguc3RhdGUub25FcnJvcihlcnJvcik7XG5cdGVsc2UgdGhyb3cgZXJyb3IgaW5zdGFuY2VvZiBTZXJvdmFsUGFyc2VyRXJyb3IgPyBlcnJvciA6IG5ldyBTZXJvdmFsUGFyc2VyRXJyb3IoZXJyb3IpO1xufVxuZnVuY3Rpb24gb25Eb25lKGN0eCkge1xuXHRpZiAoY3R4LnN0YXRlLm9uRG9uZSkgY3R4LnN0YXRlLm9uRG9uZSgpO1xuXHRmb3IgKGxldCBpID0gMCwgbGVuID0gY3R4LnN0YXRlLmNsZWFudXBzLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSBjdHguc3RhdGUuY2xlYW51cHNbaV0oKTtcbn1cbmZ1bmN0aW9uIG9uUGFyc2VJbnRlcm5hbChjdHgsIG5vZGUsIGluaXRpYWwpIHtcblx0dHJ5IHtcblx0XHRjdHguc3RhdGUub25QYXJzZShub2RlLCBpbml0aWFsKTtcblx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRvbkVycm9yKGN0eCwgZXJyb3IpO1xuXHR9XG59XG5mdW5jdGlvbiBwdXNoUGVuZGluZ1N0YXRlKGN0eCkge1xuXHRjdHguc3RhdGUucGVuZGluZysrO1xufVxuZnVuY3Rpb24gcG9wUGVuZGluZ1N0YXRlKGN0eCkge1xuXHRpZiAoLS1jdHguc3RhdGUucGVuZGluZyA8PSAwKSBvbkRvbmUoY3R4KTtcbn1cbmZ1bmN0aW9uIHBhcnNlV2l0aEVycm9yKGN0eCwgZGVwdGgsIGN1cnJlbnQpIHtcblx0dHJ5IHtcblx0XHRyZXR1cm4gcGFyc2VTT1MoY3R4LCBkZXB0aCwgY3VycmVudCk7XG5cdH0gY2F0Y2ggKGVycikge1xuXHRcdG9uRXJyb3IoY3R4LCBlcnIpO1xuXHRcdHJldHVybjtcblx0fVxufVxuZnVuY3Rpb24gc3RhcnRTdHJlYW1QYXJzZShjdHgsIGN1cnJlbnQpIHtcblx0Y29uc3QgcGFyc2VkID0gcGFyc2VXaXRoRXJyb3IoY3R4LCAwLCBjdXJyZW50KTtcblx0aWYgKHBhcnNlZCkge1xuXHRcdG9uUGFyc2VJbnRlcm5hbChjdHgsIHBhcnNlZCwgdHJ1ZSk7XG5cdFx0Y3R4LnN0YXRlLmluaXRpYWwgPSBmYWxzZTtcblx0XHRmbHVzaFN0cmVhbVBhcnNlKGN0eCwgY3R4LnN0YXRlKTtcblx0XHRpZiAoY3R4LnN0YXRlLnBlbmRpbmcgPD0gMCkgZGVzdHJveVN0cmVhbVBhcnNlKGN0eCk7XG5cdH1cbn1cbmZ1bmN0aW9uIGZsdXNoU3RyZWFtUGFyc2UoY3R4LCBzdGF0ZSkge1xuXHRmb3IgKGxldCBpID0gMCwgbGVuID0gc3RhdGUuYnVmZmVyLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSBvblBhcnNlSW50ZXJuYWwoY3R4LCBzdGF0ZS5idWZmZXJbaV0sIGZhbHNlKTtcbn1cbmZ1bmN0aW9uIGRlc3Ryb3lTdHJlYW1QYXJzZShjdHgpIHtcblx0aWYgKGN0eC5zdGF0ZS5hbGl2ZSkge1xuXHRcdG9uRG9uZShjdHgpO1xuXHRcdGN0eC5zdGF0ZS5hbGl2ZSA9IGZhbHNlO1xuXHR9XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jcm9zcy9pbmRleC50c1xuZnVuY3Rpb24gY3Jvc3NTZXJpYWxpemUoc291cmNlLCBvcHRpb25zID0ge30pIHtcblx0Y29uc3QgcGx1Z2lucyA9IHJlc29sdmVQbHVnaW5zKG9wdGlvbnMucGx1Z2lucyk7XG5cdGNvbnN0IGN0eCA9IGNyZWF0ZVN5bmNQYXJzZXJDb250ZXh0KDIsIHtcblx0XHRjb21wYWN0QXJyYXlCdWZmZXJWaWV3czogb3B0aW9ucy5jb21wYWN0QXJyYXlCdWZmZXJWaWV3cyxcblx0XHRwbHVnaW5zLFxuXHRcdGRpc2FibGVkRmVhdHVyZXM6IG9wdGlvbnMuZGlzYWJsZWRGZWF0dXJlcyxcblx0XHRyZWZzOiBvcHRpb25zLnJlZnNcblx0fSk7XG5cdGNvbnN0IHRyZWUgPSBwYXJzZVRvcChjdHgsIHNvdXJjZSk7XG5cdHJldHVybiBzZXJpYWxpemVUb3BDcm9zcyhjcmVhdGVDcm9zc1NlcmlhbGl6ZXJDb250ZXh0KHtcblx0XHRwbHVnaW5zLFxuXHRcdGZlYXR1cmVzOiBjdHguYmFzZS5mZWF0dXJlcyxcblx0XHRzY29wZUlkOiBvcHRpb25zLnNjb3BlSWQsXG5cdFx0bWFya2VkUmVmczogY3R4LmJhc2UubWFya2VkXG5cdH0pLCB0cmVlKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIGNyb3NzU2VyaWFsaXplQXN5bmMoc291cmNlLCBvcHRpb25zID0ge30pIHtcblx0Y29uc3QgcGx1Z2lucyA9IHJlc29sdmVQbHVnaW5zKG9wdGlvbnMucGx1Z2lucyk7XG5cdGNvbnN0IGN0eCA9IGNyZWF0ZUFzeW5jUGFyc2VyQ29udGV4dCgyLCB7XG5cdFx0Y29tcGFjdEFycmF5QnVmZmVyVmlld3M6IG9wdGlvbnMuY29tcGFjdEFycmF5QnVmZmVyVmlld3MsXG5cdFx0cGx1Z2lucyxcblx0XHRkaXNhYmxlZEZlYXR1cmVzOiBvcHRpb25zLmRpc2FibGVkRmVhdHVyZXMsXG5cdFx0cmVmczogb3B0aW9ucy5yZWZzXG5cdH0pO1xuXHRjb25zdCB0cmVlID0gYXdhaXQgcGFyc2VUb3BBc3luYyhjdHgsIHNvdXJjZSk7XG5cdHJldHVybiBzZXJpYWxpemVUb3BDcm9zcyhjcmVhdGVDcm9zc1NlcmlhbGl6ZXJDb250ZXh0KHtcblx0XHRwbHVnaW5zLFxuXHRcdGZlYXR1cmVzOiBjdHguYmFzZS5mZWF0dXJlcyxcblx0XHRzY29wZUlkOiBvcHRpb25zLnNjb3BlSWQsXG5cdFx0bWFya2VkUmVmczogY3R4LmJhc2UubWFya2VkXG5cdH0pLCB0cmVlKTtcbn1cbmZ1bmN0aW9uIHRvQ3Jvc3NKU09OKHNvdXJjZSwgb3B0aW9ucyA9IHt9KSB7XG5cdGNvbnN0IHBsdWdpbnMgPSByZXNvbHZlUGx1Z2lucyhvcHRpb25zLnBsdWdpbnMpO1xuXHRyZXR1cm4gcGFyc2VUb3AoY3JlYXRlU3luY1BhcnNlckNvbnRleHQoMiwge1xuXHRcdGNvbXBhY3RBcnJheUJ1ZmZlclZpZXdzOiBvcHRpb25zLmNvbXBhY3RBcnJheUJ1ZmZlclZpZXdzLFxuXHRcdHBsdWdpbnMsXG5cdFx0ZGlzYWJsZWRGZWF0dXJlczogb3B0aW9ucy5kaXNhYmxlZEZlYXR1cmVzLFxuXHRcdHJlZnM6IG9wdGlvbnMucmVmc1xuXHR9KSwgc291cmNlKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHRvQ3Jvc3NKU09OQXN5bmMoc291cmNlLCBvcHRpb25zID0ge30pIHtcblx0Y29uc3QgcGx1Z2lucyA9IHJlc29sdmVQbHVnaW5zKG9wdGlvbnMucGx1Z2lucyk7XG5cdHJldHVybiBhd2FpdCBwYXJzZVRvcEFzeW5jKGNyZWF0ZUFzeW5jUGFyc2VyQ29udGV4dCgyLCB7XG5cdFx0Y29tcGFjdEFycmF5QnVmZmVyVmlld3M6IG9wdGlvbnMuY29tcGFjdEFycmF5QnVmZmVyVmlld3MsXG5cdFx0cGx1Z2lucyxcblx0XHRkaXNhYmxlZEZlYXR1cmVzOiBvcHRpb25zLmRpc2FibGVkRmVhdHVyZXMsXG5cdFx0cmVmczogb3B0aW9ucy5yZWZzXG5cdH0pLCBzb3VyY2UpO1xufVxuZnVuY3Rpb24gY3Jvc3NTZXJpYWxpemVTdHJlYW0oc291cmNlLCBvcHRpb25zKSB7XG5cdGNvbnN0IHBsdWdpbnMgPSByZXNvbHZlUGx1Z2lucyhvcHRpb25zLnBsdWdpbnMpO1xuXHRjb25zdCBjdHggPSBjcmVhdGVTdHJlYW1QYXJzZXJDb250ZXh0KHtcblx0XHRjb21wYWN0QXJyYXlCdWZmZXJWaWV3czogb3B0aW9ucy5jb21wYWN0QXJyYXlCdWZmZXJWaWV3cyxcblx0XHRwbHVnaW5zLFxuXHRcdHJlZnM6IG9wdGlvbnMucmVmcyxcblx0XHRkaXNhYmxlZEZlYXR1cmVzOiBvcHRpb25zLmRpc2FibGVkRmVhdHVyZXMsXG5cdFx0b25QYXJzZShub2RlLCBpbml0aWFsKSB7XG5cdFx0XHRjb25zdCBzZXJpYWwgPSBjcmVhdGVDcm9zc1NlcmlhbGl6ZXJDb250ZXh0KHtcblx0XHRcdFx0cGx1Z2lucyxcblx0XHRcdFx0ZmVhdHVyZXM6IGN0eC5iYXNlLmZlYXR1cmVzLFxuXHRcdFx0XHRzY29wZUlkOiBvcHRpb25zLnNjb3BlSWQsXG5cdFx0XHRcdG1hcmtlZFJlZnM6IGN0eC5iYXNlLm1hcmtlZFxuXHRcdFx0fSk7XG5cdFx0XHRsZXQgc2VyaWFsaXplZDtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHNlcmlhbGl6ZWQgPSBzZXJpYWxpemVUb3BDcm9zcyhzZXJpYWwsIG5vZGUpO1xuXHRcdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRcdGlmIChvcHRpb25zLm9uRXJyb3IpIG9wdGlvbnMub25FcnJvcihlcnIpO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0XHRvcHRpb25zLm9uU2VyaWFsaXplKHNlcmlhbGl6ZWQsIGluaXRpYWwpO1xuXHRcdH0sXG5cdFx0b25FcnJvcjogb3B0aW9ucy5vbkVycm9yLFxuXHRcdG9uRG9uZTogb3B0aW9ucy5vbkRvbmVcblx0fSk7XG5cdHN0YXJ0U3RyZWFtUGFyc2UoY3R4LCBzb3VyY2UpO1xuXHRyZXR1cm4gZGVzdHJveVN0cmVhbVBhcnNlLmJpbmQobnVsbCwgY3R4KTtcbn1cbmZ1bmN0aW9uIHRvQ3Jvc3NKU09OU3RyZWFtKHNvdXJjZSwgb3B0aW9ucykge1xuXHRjb25zdCBwbHVnaW5zID0gcmVzb2x2ZVBsdWdpbnMob3B0aW9ucy5wbHVnaW5zKTtcblx0Y29uc3QgY3R4ID0gY3JlYXRlU3RyZWFtUGFyc2VyQ29udGV4dCh7XG5cdFx0Y29tcGFjdEFycmF5QnVmZmVyVmlld3M6IG9wdGlvbnMuY29tcGFjdEFycmF5QnVmZmVyVmlld3MsXG5cdFx0cGx1Z2lucyxcblx0XHRyZWZzOiBvcHRpb25zLnJlZnMsXG5cdFx0ZGlzYWJsZWRGZWF0dXJlczogb3B0aW9ucy5kaXNhYmxlZEZlYXR1cmVzLFxuXHRcdGRlcHRoTGltaXQ6IG9wdGlvbnMuZGVwdGhMaW1pdCxcblx0XHRvblBhcnNlOiBvcHRpb25zLm9uUGFyc2UsXG5cdFx0b25FcnJvcjogb3B0aW9ucy5vbkVycm9yLFxuXHRcdG9uRG9uZTogb3B0aW9ucy5vbkRvbmVcblx0fSk7XG5cdHN0YXJ0U3RyZWFtUGFyc2UoY3R4LCBzb3VyY2UpO1xuXHRyZXR1cm4gZGVzdHJveVN0cmVhbVBhcnNlLmJpbmQobnVsbCwgY3R4KTtcbn1cbmZ1bmN0aW9uIGZyb21Dcm9zc0pTT04oc291cmNlLCBvcHRpb25zKSB7XG5cdGNvbnN0IHBsdWdpbnMgPSByZXNvbHZlUGx1Z2lucyhvcHRpb25zLnBsdWdpbnMpO1xuXHRyZXR1cm4gZGVzZXJpYWxpemVUb3AoY3JlYXRlQ3Jvc3NEZXNlcmlhbGl6ZXJDb250ZXh0KHtcblx0XHRtYXhCYXNlNjRMZW5ndGg6IG9wdGlvbnMubWF4QmFzZTY0TGVuZ3RoLFxuXHRcdHBsdWdpbnMsXG5cdFx0cmVmczogb3B0aW9ucy5yZWZzLFxuXHRcdGZlYXR1cmVzOiBvcHRpb25zLmZlYXR1cmVzLFxuXHRcdGRpc2FibGVkRmVhdHVyZXM6IG9wdGlvbnMuZGlzYWJsZWRGZWF0dXJlcyxcblx0XHRkZXB0aExpbWl0OiBvcHRpb25zLmRlcHRoTGltaXRcblx0fSksIHNvdXJjZSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9TZXJpYWxpemVyLnRzXG52YXIgU2VyaWFsaXplciA9IGNsYXNzIHtcblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdHRoaXMub3B0aW9ucyA9IG9wdGlvbnM7XG5cdFx0dGhpcy5hbGl2ZSA9IHRydWU7XG5cdFx0dGhpcy5mbHVzaGVkID0gZmFsc2U7XG5cdFx0dGhpcy5kb25lID0gZmFsc2U7XG5cdFx0dGhpcy5wZW5kaW5nID0gMDtcblx0XHR0aGlzLmNsZWFudXBzID0gW107XG5cdFx0dGhpcy5yZWZzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHR0aGlzLmtleXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdHRoaXMuaWRzID0gMDtcblx0XHR0aGlzLnBsdWdpbnMgPSByZXNvbHZlUGx1Z2lucyhvcHRpb25zLnBsdWdpbnMpO1xuXHR9XG5cdHdyaXRlKGtleSwgdmFsdWUpIHtcblx0XHRpZiAodGhpcy5hbGl2ZSAmJiAhdGhpcy5mbHVzaGVkKSB7XG5cdFx0XHR0aGlzLnBlbmRpbmcrKztcblx0XHRcdHRoaXMua2V5cy5hZGQoa2V5KTtcblx0XHRcdHRoaXMuY2xlYW51cHMucHVzaChjcm9zc1NlcmlhbGl6ZVN0cmVhbSh2YWx1ZSwge1xuXHRcdFx0XHRwbHVnaW5zOiB0aGlzLnBsdWdpbnMsXG5cdFx0XHRcdHNjb3BlSWQ6IHRoaXMub3B0aW9ucy5zY29wZUlkLFxuXHRcdFx0XHRyZWZzOiB0aGlzLnJlZnMsXG5cdFx0XHRcdGRpc2FibGVkRmVhdHVyZXM6IHRoaXMub3B0aW9ucy5kaXNhYmxlZEZlYXR1cmVzLFxuXHRcdFx0XHRjb21wYWN0QXJyYXlCdWZmZXJWaWV3czogdGhpcy5vcHRpb25zLmNvbXBhY3RBcnJheUJ1ZmZlclZpZXdzLFxuXHRcdFx0XHRvbkVycm9yOiB0aGlzLm9wdGlvbnMub25FcnJvcixcblx0XHRcdFx0b25TZXJpYWxpemU6IChkYXRhLCBpbml0aWFsKSA9PiB7XG5cdFx0XHRcdFx0aWYgKHRoaXMuYWxpdmUpIHRoaXMub3B0aW9ucy5vbkRhdGEoaW5pdGlhbCA/IHRoaXMub3B0aW9ucy5nbG9iYWxJZGVudGlmaWVyICsgXCJbXFxcIlwiICsgc2VyaWFsaXplU3RyaW5nKGtleSkgKyBcIlxcXCJdPVwiICsgZGF0YSA6IGRhdGEpO1xuXHRcdFx0XHR9LFxuXHRcdFx0XHRvbkRvbmU6ICgpID0+IHtcblx0XHRcdFx0XHRpZiAodGhpcy5hbGl2ZSkge1xuXHRcdFx0XHRcdFx0dGhpcy5wZW5kaW5nLS07XG5cdFx0XHRcdFx0XHRpZiAodGhpcy5wZW5kaW5nIDw9IDAgJiYgdGhpcy5mbHVzaGVkICYmICF0aGlzLmRvbmUgJiYgdGhpcy5vcHRpb25zLm9uRG9uZSkge1xuXHRcdFx0XHRcdFx0XHR0aGlzLm9wdGlvbnMub25Eb25lKCk7XG5cdFx0XHRcdFx0XHRcdHRoaXMuZG9uZSA9IHRydWU7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9KSk7XG5cdFx0fVxuXHR9XG5cdGdldE5leHRJRCgpIHtcblx0XHR3aGlsZSAodGhpcy5rZXlzLmhhcyhcIlwiICsgdGhpcy5pZHMpKSB0aGlzLmlkcysrO1xuXHRcdHJldHVybiBcIlwiICsgdGhpcy5pZHM7XG5cdH1cblx0cHVzaCh2YWx1ZSkge1xuXHRcdGNvbnN0IG5ld0lEID0gdGhpcy5nZXROZXh0SUQoKTtcblx0XHR0aGlzLndyaXRlKG5ld0lELCB2YWx1ZSk7XG5cdFx0cmV0dXJuIG5ld0lEO1xuXHR9XG5cdGZsdXNoKCkge1xuXHRcdGlmICh0aGlzLmFsaXZlKSB7XG5cdFx0XHR0aGlzLmZsdXNoZWQgPSB0cnVlO1xuXHRcdFx0aWYgKHRoaXMucGVuZGluZyA8PSAwICYmICF0aGlzLmRvbmUgJiYgdGhpcy5vcHRpb25zLm9uRG9uZSkge1xuXHRcdFx0XHR0aGlzLm9wdGlvbnMub25Eb25lKCk7XG5cdFx0XHRcdHRoaXMuZG9uZSA9IHRydWU7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cdGNsb3NlKCkge1xuXHRcdGlmICh0aGlzLmFsaXZlKSB7XG5cdFx0XHRmb3IgKGxldCBpID0gMCwgbGVuID0gdGhpcy5jbGVhbnVwcy5sZW5ndGg7IGkgPCBsZW47IGkrKykgdGhpcy5jbGVhbnVwc1tpXSgpO1xuXHRcdFx0aWYgKCF0aGlzLmRvbmUgJiYgdGhpcy5vcHRpb25zLm9uRG9uZSkge1xuXHRcdFx0XHR0aGlzLm9wdGlvbnMub25Eb25lKCk7XG5cdFx0XHRcdHRoaXMuZG9uZSA9IHRydWU7XG5cdFx0XHR9XG5cdFx0XHR0aGlzLmFsaXZlID0gZmFsc2U7XG5cdFx0fVxuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvdHJlZS9pbmRleC50c1xuZnVuY3Rpb24gc2VyaWFsaXplKHNvdXJjZSwgb3B0aW9ucyA9IHt9KSB7XG5cdGNvbnN0IHBsdWdpbnMgPSByZXNvbHZlUGx1Z2lucyhvcHRpb25zLnBsdWdpbnMpO1xuXHRjb25zdCBjdHggPSBjcmVhdGVTeW5jUGFyc2VyQ29udGV4dCgxLCB7XG5cdFx0Y29tcGFjdEFycmF5QnVmZmVyVmlld3M6IG9wdGlvbnMuY29tcGFjdEFycmF5QnVmZmVyVmlld3MsXG5cdFx0cGx1Z2lucyxcblx0XHRkaXNhYmxlZEZlYXR1cmVzOiBvcHRpb25zLmRpc2FibGVkRmVhdHVyZXNcblx0fSk7XG5cdGNvbnN0IHRyZWUgPSBwYXJzZVRvcChjdHgsIHNvdXJjZSk7XG5cdHJldHVybiBzZXJpYWxpemVUb3BWYW5pbGxhKGNyZWF0ZVZhbmlsbGFTZXJpYWxpemVyQ29udGV4dCh7XG5cdFx0cGx1Z2lucyxcblx0XHRmZWF0dXJlczogY3R4LmJhc2UuZmVhdHVyZXMsXG5cdFx0bWFya2VkUmVmczogY3R4LmJhc2UubWFya2VkXG5cdH0pLCB0cmVlKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHNlcmlhbGl6ZUFzeW5jKHNvdXJjZSwgb3B0aW9ucyA9IHt9KSB7XG5cdGNvbnN0IHBsdWdpbnMgPSByZXNvbHZlUGx1Z2lucyhvcHRpb25zLnBsdWdpbnMpO1xuXHRjb25zdCBjdHggPSBjcmVhdGVBc3luY1BhcnNlckNvbnRleHQoMSwge1xuXHRcdGNvbXBhY3RBcnJheUJ1ZmZlclZpZXdzOiBvcHRpb25zLmNvbXBhY3RBcnJheUJ1ZmZlclZpZXdzLFxuXHRcdHBsdWdpbnMsXG5cdFx0ZGlzYWJsZWRGZWF0dXJlczogb3B0aW9ucy5kaXNhYmxlZEZlYXR1cmVzXG5cdH0pO1xuXHRjb25zdCB0cmVlID0gYXdhaXQgcGFyc2VUb3BBc3luYyhjdHgsIHNvdXJjZSk7XG5cdHJldHVybiBzZXJpYWxpemVUb3BWYW5pbGxhKGNyZWF0ZVZhbmlsbGFTZXJpYWxpemVyQ29udGV4dCh7XG5cdFx0cGx1Z2lucyxcblx0XHRmZWF0dXJlczogY3R4LmJhc2UuZmVhdHVyZXMsXG5cdFx0bWFya2VkUmVmczogY3R4LmJhc2UubWFya2VkXG5cdH0pLCB0cmVlKTtcbn1cbmZ1bmN0aW9uIGRlc2VyaWFsaXplKHNvdXJjZSkge1xuXHRyZXR1cm4gKDAsIGV2YWwpKHNvdXJjZSk7XG59XG5mdW5jdGlvbiB0b0pTT04oc291cmNlLCBvcHRpb25zID0ge30pIHtcblx0Y29uc3QgcGx1Z2lucyA9IHJlc29sdmVQbHVnaW5zKG9wdGlvbnMucGx1Z2lucyk7XG5cdGNvbnN0IGN0eCA9IGNyZWF0ZVN5bmNQYXJzZXJDb250ZXh0KDEsIHtcblx0XHRjb21wYWN0QXJyYXlCdWZmZXJWaWV3czogb3B0aW9ucy5jb21wYWN0QXJyYXlCdWZmZXJWaWV3cyxcblx0XHRwbHVnaW5zLFxuXHRcdGRpc2FibGVkRmVhdHVyZXM6IG9wdGlvbnMuZGlzYWJsZWRGZWF0dXJlc1xuXHR9KTtcblx0cmV0dXJuIHtcblx0XHR0OiBwYXJzZVRvcChjdHgsIHNvdXJjZSksXG5cdFx0ZjogY3R4LmJhc2UuZmVhdHVyZXMsXG5cdFx0bTogQXJyYXkuZnJvbShjdHguYmFzZS5tYXJrZWQpXG5cdH07XG59XG5hc3luYyBmdW5jdGlvbiB0b0pTT05Bc3luYyhzb3VyY2UsIG9wdGlvbnMgPSB7fSkge1xuXHRjb25zdCBwbHVnaW5zID0gcmVzb2x2ZVBsdWdpbnMob3B0aW9ucy5wbHVnaW5zKTtcblx0Y29uc3QgY3R4ID0gY3JlYXRlQXN5bmNQYXJzZXJDb250ZXh0KDEsIHtcblx0XHRjb21wYWN0QXJyYXlCdWZmZXJWaWV3czogb3B0aW9ucy5jb21wYWN0QXJyYXlCdWZmZXJWaWV3cyxcblx0XHRwbHVnaW5zLFxuXHRcdGRpc2FibGVkRmVhdHVyZXM6IG9wdGlvbnMuZGlzYWJsZWRGZWF0dXJlc1xuXHR9KTtcblx0cmV0dXJuIHtcblx0XHR0OiBhd2FpdCBwYXJzZVRvcEFzeW5jKGN0eCwgc291cmNlKSxcblx0XHRmOiBjdHguYmFzZS5mZWF0dXJlcyxcblx0XHRtOiBBcnJheS5mcm9tKGN0eC5iYXNlLm1hcmtlZClcblx0fTtcbn1cbmZ1bmN0aW9uIGNvbXBpbGVKU09OKHNvdXJjZSwgb3B0aW9ucyA9IHt9KSB7XG5cdHJldHVybiBzZXJpYWxpemVUb3BWYW5pbGxhKGNyZWF0ZVZhbmlsbGFTZXJpYWxpemVyQ29udGV4dCh7XG5cdFx0cGx1Z2luczogcmVzb2x2ZVBsdWdpbnMob3B0aW9ucy5wbHVnaW5zKSxcblx0XHRmZWF0dXJlczogc291cmNlLmYsXG5cdFx0bWFya2VkUmVmczogc291cmNlLm1cblx0fSksIHNvdXJjZS50KTtcbn1cbmZ1bmN0aW9uIGZyb21KU09OKHNvdXJjZSwgb3B0aW9ucyA9IHt9KSB7XG5cdHZhciBfc291cmNlJGY7XG5cdGNvbnN0IHBsdWdpbnMgPSByZXNvbHZlUGx1Z2lucyhvcHRpb25zLnBsdWdpbnMpO1xuXHRjb25zdCBkaXNhYmxlZEZlYXR1cmVzID0gb3B0aW9ucy5kaXNhYmxlZEZlYXR1cmVzIHx8IDA7XG5cdGNvbnN0IHNvdXJjZUZlYXR1cmVzID0gKF9zb3VyY2UkZiA9IHNvdXJjZS5mKSAhPT0gbnVsbCAmJiBfc291cmNlJGYgIT09IHZvaWQgMCA/IF9zb3VyY2UkZiA6IDEyNztcblx0cmV0dXJuIGRlc2VyaWFsaXplVG9wKGNyZWF0ZVZhbmlsbGFEZXNlcmlhbGl6ZXJDb250ZXh0KHtcblx0XHRtYXhCYXNlNjRMZW5ndGg6IG9wdGlvbnMubWF4QmFzZTY0TGVuZ3RoLFxuXHRcdHBsdWdpbnMsXG5cdFx0bWFya2VkUmVmczogc291cmNlLm0sXG5cdFx0ZmVhdHVyZXM6IHNvdXJjZUZlYXR1cmVzICYgfmRpc2FibGVkRmVhdHVyZXMsXG5cdFx0ZGlzYWJsZWRGZWF0dXJlc1xuXHR9KSwgc291cmNlLnQpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBGZWF0dXJlLCBPcGFxdWVSZWZlcmVuY2UsIFNlcmlhbGl6ZXIsIFNlcm92YWxDb25mbGljdGVkTm9kZUlkRXJyb3IsIFNlcm92YWxEZXB0aExpbWl0RXJyb3IsIFNlcm92YWxEZXNlcmlhbGl6YXRpb25FcnJvciwgU2Vyb3ZhbEVycm9yLCBTZXJvdmFsTWFsZm9ybWVkTm9kZUVycm9yLCBTZXJvdmFsTWlzc2luZ0luc3RhbmNlRXJyb3IsIFNlcm92YWxNaXNzaW5nUGx1Z2luRXJyb3IsIFNlcm92YWxNaXNzaW5nUmVmZXJlbmNlRXJyb3IsIFNlcm92YWxNaXNzaW5nUmVmZXJlbmNlRm9ySWRFcnJvciwgU2Vyb3ZhbE1vZGUsIFNlcm92YWxQYXJzZXJFcnJvciwgU2Vyb3ZhbFNlcmlhbGl6YXRpb25FcnJvciwgU2Vyb3ZhbFVua25vd25UeXBlZEFycmF5RXJyb3IsIFNlcm92YWxVbnN1cHBvcnRlZE5vZGVFcnJvciwgU2Vyb3ZhbFVuc3VwcG9ydGVkVHlwZUVycm9yLCBjb21waWxlSlNPTiwgY3JlYXRlUGx1Z2luLCBjcmVhdGVSZWZlcmVuY2UsIGNyZWF0ZVN0cmVhbSwgY3Jvc3NTZXJpYWxpemUsIGNyb3NzU2VyaWFsaXplQXN5bmMsIGNyb3NzU2VyaWFsaXplU3RyZWFtLCBkZXNlcmlhbGl6ZSwgZnJvbUNyb3NzSlNPTiwgZnJvbUpTT04sIGdldENyb3NzUmVmZXJlbmNlSGVhZGVyLCBpc1N0cmVhbSwgcmVzb2x2ZVBsdWdpbnMsIHNlcmlhbGl6ZSwgc2VyaWFsaXplQXN5bmMsIHRvQ3Jvc3NKU09OLCB0b0Nyb3NzSlNPTkFzeW5jLCB0b0Nyb3NzSlNPTlN0cmVhbSwgdG9KU09OLCB0b0pTT05Bc3luYyB9O1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUMxQixDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRztBQUNuRCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUNELEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNoRCxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUM7QUFDMUQsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDO0FBQ3hELENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUM7QUFDcEUsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO0FBQ3RELENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUM7QUFDL0QsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzNDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUMvQyxDQUFDLE1BQU0sQ0FBQyxPQUFPO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7QUFDM0IsS0FBSyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYTtBQUMvQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXO0FBQzNDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGtCQUFrQjtBQUMxRCxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUTtBQUNwQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUM5QixLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUTtBQUNyQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTztBQUNsQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNoQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTztBQUNsQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUM5QixLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXO0FBQzNDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVc7QUFDNUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVc7QUFDMUMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7QUFDN0IsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDcEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQztBQUMzQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXO0FBQzFCLENBQUM7QUFDRCxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDdkIsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ3hCLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUM7QUFDRCxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0I7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHdCQUF3QjtBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVc7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVTtBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7QUFDZixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0I7QUFDdkIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsaUJBQWlCO0FBQ3hCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQztBQUNELEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQztBQUNELEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQjtBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQztBQUNELEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDZixDQUFDO0FBQ0QsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVU7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUN4QixRQUFRLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0QsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztBQUM1QixRQUFRLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNuSDtBQUNBLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztBQUN2RCxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7QUFDeEQsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO0FBQzVELEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztBQUN2RCxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7QUFDM0QsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO0FBQzNELEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO0FBQy9ELEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztBQUN0RCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUMxQixLQUFLLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDcEMsS0FBSyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDcEYsUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM1QixDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUMxQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDakMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNO0FBQ2pCLENBQUM7QUFDRDtBQUNBLFFBQVEsQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNILENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLEdBQUcsQ0FBQyxXQUFXO0FBQ2hCLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVc7QUFDaEQsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQztBQUNELENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ2hDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUNsQyxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2Q7QUFDQSxRQUFRLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNqQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUc7QUFDckIsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUc7QUFDL0QsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUM7QUFDakc7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUMxQixLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTO0FBQ3JELFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN6QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU87O0FBRXZGLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSTtBQUNaLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTzs7QUFFZixDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUs7QUFDdkUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQ3ZILENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU87O0FBRTNELENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7O0FBRTlCLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN2RTtBQUNBLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3hFLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO0FBQ3ZDLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3BCLENBQUM7QUFDRCxDQUFDO0FBQ0QsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQztBQUNwRCxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDekIsQ0FBQztBQUNELENBQUM7QUFDRCxHQUFHLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDO0FBQzNELENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUMvQixDQUFDO0FBQ0QsQ0FBQztBQUNELEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUM7QUFDN0QsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2pDLENBQUM7QUFDRCxDQUFDO0FBQ0QsR0FBRyxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztBQUN0RCxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsVUFBVTtBQUN0RyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPO0FBQzFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsVUFBVTtBQUN4RCxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUN2SCxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNwQixDQUFDO0FBQ0QsQ0FBQztBQUNELEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7QUFDdEQsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BELENBQUM7QUFDRCxDQUFDO0FBQ0QsR0FBRyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztBQUNwRCxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEQsQ0FBQztBQUNELENBQUM7QUFDRCxHQUFHLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO0FBQ3RELENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDNUMsQ0FBQztBQUNELENBQUM7QUFDRCxHQUFHLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO0FBQ3ZELENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEgsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDcEIsQ0FBQztBQUNELENBQUM7QUFDRCxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO0FBQzVELENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkUsQ0FBQztBQUNELENBQUM7QUFDRCxHQUFHLENBQUMsNkJBQTZCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO0FBQ3hELENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDLENBQUM7QUFDRCxDQUFDO0FBQ0QsR0FBRyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztBQUNwRCxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEQsQ0FBQztBQUNELENBQUM7QUFDRCxHQUFHLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO0FBQ3ZELENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRCxDQUFDO0FBQ0QsQ0FBQztBQUNELEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7QUFDakQsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDL0MsQ0FBQztBQUNELENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUN4QixLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDO0FBQ3pDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQyxRQUFRLENBQUMsdUJBQXVCLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDckMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO0FBQzdCLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUMzQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDL0MsUUFBUSxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNwQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ3pCLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDN0IsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNiO0FBQ0EsUUFBUSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMvQixDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztBQUM1QjtBQUNBLFFBQVEsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDMUIsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7QUFDN0I7QUFDQSxRQUFRLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQy9CLENBQUMsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO0FBQ3ZELENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsQ0FBQyxLQUFLLENBQUM7QUFDOUM7QUFDQSxRQUFRLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQzFCLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO0FBQ25ELENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxFQUFFLENBQUM7QUFDaEQ7QUFDQSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDekYsQ0FBQyxLQUFLLENBQUMsQ0FBQyxhQUFhO0FBQ3JCLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSTtBQUNuQixDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUs7QUFDaEIsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQztBQUNGLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDdEYsQ0FBQyxLQUFLLENBQUMsQ0FBQyxhQUFhO0FBQ3JCLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSTtBQUNuQixDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUs7QUFDaEIsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQztBQUNGLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDbEYsQ0FBQyxLQUFLLENBQUMsQ0FBQyxhQUFhO0FBQ3JCLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSTtBQUNuQixDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUs7QUFDaEIsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQztBQUNGLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDdEYsQ0FBQyxLQUFLLENBQUMsQ0FBQyxhQUFhO0FBQ3JCLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSTtBQUNuQixDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUs7QUFDaEIsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztBQUMvQixRQUFRLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3pDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMxQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDOUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzNDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN6QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDeEMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNUO0FBQ0EsUUFBUSxDQUFDLHNCQUFzQixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDdkUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDMUQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsRixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDVjtBQUNBLFFBQVEsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDMUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxLQUFLLENBQUM7QUFDNUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDO0FBQ2hELENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekQsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQztBQUNGLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxPQUFPO0FBQ2Y7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztBQUN6QyxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzVCLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ25DLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ25DLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDVDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztBQUNuQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDakMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhO0FBQ3JELENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQjtBQUN6RCxDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUTtBQUNyQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhO0FBQy9DLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDbkg7QUFDQSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDakMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNwSTtBQUNBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNuQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUMxSDtBQUNBLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNwQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2hIO0FBQ0EsUUFBUSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNyQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNwQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUM5SjtBQUNBLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMvQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzNIO0FBQ0EsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDaEo7QUFDQSxRQUFRLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDekMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2xJO0FBQ0EsUUFBUSxDQUFDLG1CQUFtQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUMvSTtBQUNBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMxQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUM5SDtBQUNBLFFBQVEsQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDckk7QUFDQSxRQUFRLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3BDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNoSDtBQUNBLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUNsQyxRQUFRLENBQUMsb0JBQW9CLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDbkQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsT0FBTyxDQUFDO0FBQzVGLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7QUFDdko7QUFDQSxRQUFRLENBQUMsMEJBQTBCLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDekQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsT0FBTyxDQUFDO0FBQzVGLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7QUFDdko7QUFDQSxRQUFRLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDakQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsT0FBTyxDQUFDO0FBQ2hHLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztBQUN6STtBQUNBLFFBQVEsQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNsSztBQUNBLFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN4RCxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2xLO0FBQ0EsUUFBUSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNsQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDL0c7QUFDQSxRQUFRLENBQUMsaUNBQWlDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDM0QsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDL0g7QUFDQSxRQUFRLENBQUMsc0NBQXNDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDaEUsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDL0g7QUFDQSxRQUFRLENBQUMsMkJBQTJCLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUQsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDcEg7QUFDQSxRQUFRLENBQUMsb0JBQW9CLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDMUMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2pIO0FBQ0EsUUFBUSxDQUFDLHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzNDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNqSDtBQUNBLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM1QyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDakg7QUFDQSxRQUFRLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDM0QsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNwSDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQztBQUNwQyxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVO0FBQzlELENBQUM7QUFDRCxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDNUIsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDcEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFdBQVc7QUFDaEMsQ0FBQztBQUNELENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztBQUNoQyxLQUFLLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUNGLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9DLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ3RCLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ3JCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxNQUFNLENBQUMsUUFBUTtBQUNoQixDQUFDO0FBQ0QsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2pCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNwQixDQUFDO0FBQ0QsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2pCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNwQixDQUFDO0FBQ0QsS0FBSyxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNyRixLQUFLLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM3RSxLQUFLLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM3RSxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNqQixDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDcEIsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzlFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUN6QixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDcEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUM5QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDdkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRixDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLElBQUk7QUFDMUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0QsS0FBSyxDQUFDLDZCQUE2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNuRixLQUFLLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3RCxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRO0FBQ2xCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSTtBQUM5QyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxNQUFNLENBQUMsUUFBUTtBQUNoQixDQUFDO0FBQ0QsS0FBSyxDQUFDLCtCQUErQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN2RixLQUFLLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDcEIsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDMUQsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUk7QUFDYixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztBQUNYLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUs7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNqQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQ3JCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUTtBQUNsQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUs7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUs7QUFDM0IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRixDQUFDLE1BQU0sQ0FBQyxRQUFRO0FBQ2hCLENBQUM7QUFDRCxLQUFLLENBQUMscUNBQXFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ25HLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDMUIsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTTtBQUM5QixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO0FBQ25DLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUNoRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTTtBQUNsQixDQUFDO0FBQ0QsS0FBSyxDQUFDLG1DQUFtQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMvRixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztBQUM1QixRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzNCLENBQUMsTUFBTSxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSztBQUN2QztBQUNBLFFBQVEsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDakQsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxJQUFJO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFDRjtBQUNBLFFBQVEsQ0FBQywwQkFBMEIsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM1QyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztBQUMxQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1IsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDMUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQ3BCLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2hEO0FBQ0EsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsWUFBWSxDQUFDO0FBQ3pELFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN0QyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDO0FBQ2hDO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDO0FBQ3JDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUNkLENBQUM7QUFDRCxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQztBQUNELEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDhCQUE4QjtBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQywwQkFBMEI7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsMEJBQTBCO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDZCQUE2QjtBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUMxQixRQUFRLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3pCLENBQUMsTUFBTSxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSztBQUNyQztBQUNBLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUM7QUFDNUI7QUFDQSxRQUFRLENBQUMsNkJBQTZCLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDM0QsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUM5QixDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7QUFDaEQsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3RCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNqQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDbkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxNQUFNO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7QUFDbEksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTTtBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNkLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7QUFDdEMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQztBQUNELENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkO0FBQ0EsS0FBSyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQywwQkFBMEIsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLG1CQUFtQixDQUFDO0FBQy9GLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN2QyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUM7QUFDbkM7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztBQUMzQyxLQUFLLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN4QyxDQUFDLEdBQUcsQ0FBQztBQUNMLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUM7QUFDRDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztBQUNsQyxRQUFRLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDaEQsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFlBQVk7QUFDMUIsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU87QUFDMUIsQ0FBQyxDQUFDLElBQUk7QUFDTixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUN2QyxDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztBQUM1SixDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLE1BQU07QUFDaEYsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1QsQ0FBQztBQUNELFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDaEMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7QUFDbkI7QUFDQSxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDVCxDQUFDO0FBQ0QsUUFBUSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzNDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJO0FBQ3pCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQzFCLENBQUMsTUFBTSxDQUFDLEVBQUU7QUFDVjtBQUNBLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM5QyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQztBQUMzQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQztBQUNsQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLHNCQUFzQixDQUFDLFlBQVk7QUFDN0MsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPO0FBQ3pDLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3hDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3JELENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPO0FBQ3ZDLENBQUMsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPO0FBQ25ELENBQUMsQ0FBQztBQUNGLENBQUMsTUFBTSxDQUFDLE9BQU87QUFDZjtBQUNBLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDVixDQUFDO0FBQ0QsUUFBUSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzVDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzNDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSztBQUNyQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsY0FBYyxDQUFDLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDN0UsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLE9BQU8sQ0FBQztBQUMvQztBQUNBLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN6QyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM5RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDM0MsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUN4SDtBQUNBLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNuQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNyRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDM0MsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzVKO0FBQ0EsUUFBUSxDQUFDLHlCQUF5QixDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLENBQUMsY0FBYyxDQUFDO0FBQzNELENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSztBQUMzQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNuTTtBQUNBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN0RCxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDOUk7QUFDQSxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2xFO0FBQ0EsUUFBUSxDQUFDLDRCQUE0QixDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3pELENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDMUk7QUFDQSxRQUFRLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPO0FBQ2pELENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDckcsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVztBQUN4QyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQztBQUMvQjtBQUNBLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNwQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDbEYsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQztBQUN0QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDbEUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUYsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUNwQjtBQUNBLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNqRCxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDNUo7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO0FBQ3hDLFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNqRCxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDOUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNkLENBQUMsQ0FBQztBQUNGO0FBQ0EsR0FBRyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDcEMsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDZCxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNwQixDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDakQsQ0FBQztBQUNELENBQUM7QUFDRCxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDakQsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUgsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDYjtBQUNBLEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNyRCxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDN0U7QUFDQSxLQUFLLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDekQsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztBQUMzQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlELENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQzdELENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLGlDQUFpQyxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsMEJBQTBCLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFKLENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQztBQUNuRSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxzQ0FBc0MsQ0FBQyx5QkFBeUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLDZCQUE2QixDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2SyxDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDdEMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUM7QUFDbEUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztBQUNsRSxDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUM7QUFDekUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ2hGLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxLQUFLLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNsRSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMxRjtBQUNBLEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNyRCxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVFO0FBQ0EsS0FBSyxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzFELENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2hELENBQUMsTUFBTSxDQUFDLG9CQUFvQixDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3ZGO0FBQ0EsS0FBSyxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDaEUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDaEQsQ0FBQyxNQUFNLENBQUMsMEJBQTBCLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDN0Y7QUFDQSxLQUFLLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDaEQsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDckY7QUFDQSxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDckQsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7QUFDNUQsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDckc7QUFDQSxLQUFLLENBQUMsUUFBUSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM5RCxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztBQUM1RCxDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzlHO0FBQ0EsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25ELENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNsRCxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3RELENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUN6RDtBQUNBLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNuRCxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xGLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEM7QUFDQSxLQUFLLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDdEQsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU87QUFDeEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRixDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0ssQ0FBQztBQUNEO0FBQ0EsS0FBSyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3ZELENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDO0FBQ3hELENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUMvSTtBQUNBLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNoRSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7QUFDNUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNqRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xELENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNuRCxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsS0FBSyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3RELENBQUMsTUFBTSxDQUFDLDJCQUEyQixDQUFDLEVBQUUsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQy9JO0FBQ0EsS0FBSyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3hELENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVHLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQzNEO0FBQ0EsS0FBSyxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN6RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDekUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDckUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDekUsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVztBQUN2QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNwRSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUM7QUFDOUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVztBQUM1RCxDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7QUFDekYsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDNUQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUMxQixDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDeEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDdkUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMvQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUs7QUFDWixDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVM7QUFDaEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVO0FBQ2pCLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYztBQUNyQixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVc7QUFDbEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTO0FBQ2hCLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzdELENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTTtBQUNiLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTztBQUNkLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTTtBQUNiLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzNELENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDdkUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTO0FBQ2hCLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVTtBQUNqQixDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVU7QUFDakIsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVO0FBQ2pCLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVztBQUNsQixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVc7QUFDbEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUI7QUFDeEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZO0FBQ25CLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3RFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3RELENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMzRyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUTtBQUMxQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDMUYsQ0FBQyxFQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYTtBQUNwQixDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzlFLENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNsTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDcEYsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNsRSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ25FLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDcEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUN4RSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3hFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDcEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUN6RSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3hFLENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzNFLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQztBQUNqSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsT0FBTyxDQUFDO0FBQy9DO0FBQ0EsS0FBSyxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN2RCxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDaEQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLO0FBQ3JDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNuRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQzFCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxPQUFPLENBQUM7QUFDL0M7QUFDQSxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMvQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7QUFDeEYsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxVQUFVO0FBQ3pELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjO0FBQ3pDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUM7QUFDakQsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQztBQUNqRCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSztBQUNsRyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTO0FBQ25CLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQy9ELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDakUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsT0FBTyxDQUFDO0FBQ3pELENBQUM7QUFDRDtBQUNBLEtBQUssQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzNDLENBQUMsR0FBRyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQztBQUNuRixDQUFDO0FBQ0Q7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUMxQixHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3BELENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoRCxDQUFDLE1BQU0sQ0FBQyxXQUFXO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLFFBQVEsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDOUIsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkO0FBQ0EsUUFBUSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN6QyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7QUFDL0QsQ0FBQyxDQUFDO0FBQ0YsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNqQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUMzQyxDQUFDLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNqQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3JCLENBQUM7QUFDRDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7QUFDckMsUUFBUSxDQUFDLHdCQUF3QixDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3hDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUztBQUNwQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVTtBQUN0QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVTtBQUN0QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVTtBQUN0QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVztBQUN4QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVztBQUN4QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUI7QUFDcEQsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVk7QUFDMUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVk7QUFDMUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWE7QUFDNUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWM7QUFDOUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsNkJBQTZCLENBQUMsSUFBSSxDQUFDO0FBQ3hELENBQUM7QUFDRDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7QUFDMUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN6QixDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUNwQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDbEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGdCQUFnQixDQUFDO0FBQ3pCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQztBQUN6QixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsZ0JBQWdCLENBQUM7QUFDekIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUN2QyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDdEIsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMvQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCO0FBQ3pCLENBQUMsQ0FBQyxJQUFJLENBQUMsd0JBQXdCO0FBQy9CLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCO0FBQ3hCLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDaEMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ3ZCLENBQUM7QUFDRDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQztBQUN4QyxLQUFLLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDckMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ3BDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUM3QixLQUFLLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDcEMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNwQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDbkMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQztBQUM5QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUNqQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUc7QUFDckIsQ0FBQztBQUNEO0FBQ0EsS0FBSyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQy9CLFFBQVEsQ0FBQyw2QkFBNkIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN0RCxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVE7QUFDN0MsQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMseUJBQXlCO0FBQzNLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDL0ksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN2RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRixDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJO0FBQ04sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPO0FBQzFCLENBQUMsQ0FBQyxJQUFJO0FBQ04sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2SixDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUI7QUFDdkQsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxRQUFRLENBQUMsZ0NBQWdDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDakQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUM7QUFDRjtBQUNBLFFBQVEsQ0FBQyw4QkFBOEIsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNqRCxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLDZCQUE2QixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNqRCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2QsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNyQyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUNkLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3BCLENBQUM7QUFDRCxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDakQsQ0FBQztBQUNELENBQUM7QUFDRCxRQUFRLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDcEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQztBQUNsRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNsRTtBQUNBLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNuRztBQUNBLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNuRCxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDaEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzNELENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDYjtBQUNBLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNqRCxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDaEMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzdCLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDYjtBQUNBLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMseUJBQXlCLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUM1RztBQUNBLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNsRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUNuRCxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDO0FBQzFDO0FBQ0EsUUFBUSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3pDLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xGO0FBQ0EsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzVDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDckIsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTTtBQUN6QixDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNqRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDdkQsQ0FBQztBQUNELENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkO0FBQ0EsUUFBUSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2xELENBQUMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3pDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLEtBQUs7QUFDUCxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSTtBQUNwQixDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSTtBQUNsQixDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsUUFBUSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN4RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3BILENBQUMsSUFBSSxDQUFDO0FBQ04sQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQy9DLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMxRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDVCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hGLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNULENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMseUJBQXlCLENBQUMsR0FBRyxDQUFDO0FBQ3BELENBQUMsQ0FBQztBQUNGLENBQUM7QUFDRDtBQUNBLFFBQVEsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdkMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNsQztBQUNBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMvQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQztBQUNwRjtBQUNBLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN6RCxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3BCLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxSSxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2Q7QUFDQSxRQUFRLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDN0MsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzNGLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNsRCxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDZDtBQUNBLFFBQVEsQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDcEMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzRDtBQUNBLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN4QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLElBQUksQ0FBQztBQUMzRSxDQUFDLEdBQUcsQ0FBQyxLQUFLO0FBQ1YsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQy9DLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNSLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQztBQUNwRCxDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEQ7QUFDQSxRQUFRLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUM7QUFDekYsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RFLENBQUM7QUFDRCxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsSUFBSSxDQUFDO0FBQzVDO0FBQ0EsUUFBUSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMxQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDNUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEgsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkO0FBQ0EsUUFBUSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMxQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDNUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEssQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkO0FBQ0EsUUFBUSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzNDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUM7QUFDMUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3SSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxHQUFHLENBQUMsTUFBTTtBQUNYLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLE1BQU0sQ0FBQztBQUN6SCxDQUFDLElBQUksQ0FBQztBQUNOLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO0FBQzlCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztBQUMxQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM5QyxDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDakQ7QUFDQSxRQUFRLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakQsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDWixDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDakQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDO0FBQ2hGLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0UsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQztBQUN4RixDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hGO0FBQ0EsUUFBUSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQy9DLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFO0FBQ2IsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDakQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDO0FBQ2hGLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEYsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQztBQUN4RixDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9FO0FBQ0EsUUFBUSxDQUFDLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3pELENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5RCxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyx5QkFBeUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMzRSxDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkO0FBQ0EsUUFBUSxDQUFDLHlCQUF5QixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3JELENBQUMsTUFBTSxDQUFDLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckk7QUFDQSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDNUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDekUsQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUg7QUFDQSxRQUFRLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDOUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQzdELENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3ZELENBQUMsRUFBRSxDQUFDLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzNFLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO0FBQ3JDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO0FBQzlCLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDZDtBQUNBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM1QyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BGO0FBQ0EsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzdDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPO0FBQ3hDLENBQUMsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdELENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pKLENBQUMsQ0FBQztBQUNGLENBQUM7QUFDRCxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUM1QztBQUNBLFFBQVEsQ0FBQyw2QkFBNkIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsRCxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUcsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNoQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2I7QUFDQSxRQUFRLENBQUMseUJBQXlCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDckQsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUMzQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDekMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzRCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9FLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUM7QUFDN0MsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQztBQUMvQixDQUFDLENBQUMsTUFBTTtBQUNSLENBQUM7QUFDRCxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNqRDtBQUNBLFFBQVEsQ0FBQyxrQ0FBa0MsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM5RCxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRCxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQzdDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUQsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDO0FBQ2xDO0FBQ0EsUUFBUSxDQUFDLHVDQUF1QyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ25FLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BELENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDN0MsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1RCxDQUFDLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLENBQUM7QUFDckM7QUFDQSxRQUFRLENBQUMsNEJBQTRCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDeEQsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7QUFDakUsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNoQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3JCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU07QUFDekIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzRSxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2Q7QUFDQSxRQUFRLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakQsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUMzQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDekMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEQsQ0FBQyxDQUFDLE1BQU07QUFDUixDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDaEQ7QUFDQSxRQUFRLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbEQsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUMzQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDekMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLE1BQU07QUFDUixDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDaEQ7QUFDQSxRQUFRLENBQUMsdUJBQXVCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbkQsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUMzQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDekMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEQsQ0FBQyxDQUFDLE1BQU07QUFDUixDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDaEQ7QUFDQSxRQUFRLENBQUMsMEJBQTBCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdEQsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDbEM7QUFDQSxRQUFRLENBQUMsK0JBQStCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDM0QsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckM7QUFDQSxRQUFRLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDL0MsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckYsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNoQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEcsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkO0FBQ0EsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDekMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztBQUN2RixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNsRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDO0FBQzNGLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDakQsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ25ELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUNULENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNyRCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzNDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUM3QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2pELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDakQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ25ELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUNULENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQztBQUN6RCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDdkQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMseUJBQXlCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzdELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNwRCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDdEQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNqRSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDcEQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3JELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLDZCQUE2QixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMxRCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDVCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyx5QkFBeUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDN0QsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsa0NBQWtDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3RFLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLHVDQUF1QyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMzRSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyw0QkFBNEIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDaEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3pELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMxRCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDM0QsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsMEJBQTBCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzlELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLCtCQUErQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNuRSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDdkQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2hELENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLElBQUksQ0FBQztBQUN0RCxDQUFDO0FBQ0Q7QUFDQSxRQUFRLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ25DLENBQUMsR0FBRyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxLQUFLLENBQUM7QUFDOUMsQ0FBQztBQUNEO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO0FBQ25DLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDM0QsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztBQUM5RCxRQUFRLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzdKLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckU7QUFDQSxRQUFRLENBQUMsdUJBQXVCLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbkQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hILENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5RDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7QUFDeEMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDLENBQUM7QUFDNUQsS0FBSyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQzlCLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsOERBQThELENBQUMsQ0FBQyxDQUFDO0FBQ3BGLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDeEIsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM5QixDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsbUJBQW1CO0FBQ3RDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQztBQUMvQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUI7QUFDNUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsYUFBYTtBQUM3QixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUM7QUFDdkIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhO0FBQ3ZDLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxHQUFHO0FBQ1g7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQztBQUM3QyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxRQUFRLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUNqSTtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztBQUN0QyxRQUFRLENBQUMsdUJBQXVCLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDN0MsQ0FBQyxNQUFNLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDbEQsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pGLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1RCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0QsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuSixDQUFDO0FBQ0Q7QUFDQSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQzdCLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLE9BQU87QUFDckMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ3hELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUM7QUFDdEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUN4RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2pCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDYixDQUFDO0FBQ0QsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztBQUM3QixDQUFDLE1BQU0sQ0FBQyxjQUFjO0FBQ3RCO0FBQ0EsUUFBUSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsRUFBRSxDQUFDLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQztBQUM5QyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2RyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDZixDQUFDO0FBQ0Q7QUFDQSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM5QyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDakMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQ2pDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztBQUN6QyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7QUFDdkMsS0FBSyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNYLENBQUM7QUFDRCxRQUFRLENBQUMsMkJBQTJCLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDcEQsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSTtBQUNOLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTztBQUMxQixDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVE7QUFDNUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztBQUNyQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUM7QUFDRjtBQUNBLFFBQVEsQ0FBQyw4QkFBOEIsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNqRCxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMvQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsNEJBQTRCLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2QsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxRQUFRLENBQUMsNEJBQTRCLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDL0MsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU87QUFDaEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNkLENBQUMsQ0FBQztBQUNGO0FBQ0EsR0FBRyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDbkMsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDZCxDQUFDO0FBQ0QsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDbkMsQ0FBQztBQUNELENBQUM7QUFDRCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDO0FBQ3BFLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztBQUM1RCxDQUFDO0FBQ0QsUUFBUSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7QUFDckQsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztBQUNsRCxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztBQUNyRCxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDUCxDQUFDLENBQUM7QUFDRixDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztBQUN6QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUk7QUFDaEMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUNyQyxDQUFDO0FBQ0QsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQztBQUN6QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVO0FBQ3RDLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxVQUFVO0FBQ2xCO0FBQ0EsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQzlCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ25ELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUM7QUFDbEQsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNO0FBQ2xCLENBQUM7QUFDRCxRQUFRLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQzlCLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxDQUFDO0FBQ2pGO0FBQ0EsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO0FBQ25CO0FBQ0EsUUFBUSxDQUFDLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztBQUMxQjtBQUNBLFFBQVEsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDdkMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNqQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUk7QUFDYixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRTtBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUMzQixDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFFLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hFLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2Q7QUFDQSxRQUFRLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzdCLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQztBQUN4RCxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUM7QUFDaEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUN2QyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVc7QUFDcEIsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDYjtBQUNBLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUMzQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7QUFDdkQsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztBQUNqQyxDQUFDO0FBQ0QsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzlDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxRQUFRLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsUUFBUSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ25ELENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsUUFBUSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQy9DLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNBLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNuRCxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUM3RTtBQUNBLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNsRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxNQUFNO0FBQ1IsQ0FBQztBQUNELENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3JFO0FBQ0EsUUFBUSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3RELENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUMvRTtBQUNBLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQzFELENBQUM7QUFDRCxRQUFRLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDMUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2xEO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztBQUN0RCxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7QUFDdkQsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzVELENBQUMsQ0FBQyxFQUFFO0FBQ0osQ0FBQztBQUNELFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMvQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUM1RSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxLQUFLO0FBQ3JDLENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQztBQUNmLENBQUMsQ0FBQztBQUNGLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUM3QztBQUNBLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEQ7QUFDQSxRQUFRLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDbEQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUQsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDL0IsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNuQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDcEIsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTTtBQUN4QixDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztBQUN6QixDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1o7QUFDQSxRQUFRLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbEQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQztBQUN2RixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDeEYsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUMxRixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ3BHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDckQsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDbEU7QUFDQSxRQUFRLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDbEQsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN0QixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNO0FBQ3hCLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1RCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMzQyxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1o7QUFDQSxRQUFRLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3BDLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDOUM7QUFDQSxRQUFRLENBQUMseUJBQXlCLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDbkUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDdkQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9FLENBQUMsTUFBTSxDQUFDLFVBQVU7QUFDbEI7QUFDQSxRQUFRLENBQUMsNEJBQTRCLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDaEYsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSTtBQUN0QixDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzNDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUMxQixDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDO0FBQ3RGLENBQUMsRUFBRSxDQUFDLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxVQUFVLENBQUM7QUFDekYsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUM7QUFDM0YsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVc7QUFDM0MsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLGVBQWU7QUFDcEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ3pGLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO0FBQzNGLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0I7QUFDckMsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3ZFLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyw0QkFBNEIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDcEcsQ0FBQyxJQUFJLENBQUM7QUFDTixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUk7QUFDdkIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLO0FBQzNCLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ3JCLENBQUMsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXO0FBQzNDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxlQUFlO0FBQ3BDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUNyRSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCO0FBQ3JDLENBQUM7QUFDRDtBQUNBLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNqRCxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3BCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU07QUFDeEIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsZUFBZSxDQUFDO0FBQzVDLENBQUM7QUFDRDtBQUNBLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM5QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSTtBQUN2QixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2xGLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDOUQsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzSCxDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUNaO0FBQ0EsUUFBUSxDQUFDLHdCQUF3QixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzdDLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGdCQUFnQixDQUFDO0FBQ3hEO0FBQ0EsUUFBUSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM3QixDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDO0FBQ0EsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsYUFBYTtBQUM3QixDQUFDO0FBQ0QsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3RDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlGLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxJQUFJLENBQUM7QUFDNUM7QUFDQSxRQUFRLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3BDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xGLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxJQUFJLENBQUM7QUFDNUM7QUFDQSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDekMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSTtBQUN0QixDQUFDLEVBQUUsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUM3QixDQUFDLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4RCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUM5QjtBQUNBLFFBQVEsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxlQUFlO0FBQ2pDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDckIsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTTtBQUMxQixDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xCLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEQsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEQsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDM0MsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEQsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLFVBQVU7QUFDbEI7QUFDQSxRQUFRLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDeEQsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSTtBQUN0QixDQUFDLEVBQUUsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDN0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzRixDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUM1QyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVTtBQUNwQixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUs7QUFDM0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM3RCxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNyQixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDN0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzRixDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ2xFLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUM1QyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVTtBQUNwQixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUs7QUFDM0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUMvRCxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNyQixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2RTtBQUNBLFFBQVEsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxlQUFlO0FBQ2pDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU07QUFDekIsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsQixDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3hCLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDaEQsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSTtBQUN0QixDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7QUFDckIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUN2RSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUNsRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMzQyxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hELENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hFLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxVQUFVO0FBQ2xCO0FBQ0EsUUFBUSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3pDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUQ7QUFDQSxRQUFRLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDeEMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUY7QUFDQSxRQUFRLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdEMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RGO0FBQ0EsUUFBUSxDQUFDLHVCQUF1QixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzVDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbEIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO0FBQ3hCLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9GLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDckIsQ0FBQyxNQUFNLENBQUMsVUFBVTtBQUNsQjtBQUNBLFFBQVEsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbkMsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRztBQUNBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNyQyxDQUFDLEdBQUcsQ0FBQyxVQUFVO0FBQ2YsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN6QixDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xCLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLGNBQWM7QUFDckUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSTtBQUN0QixDQUFDLEVBQUUsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNKLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7QUFDckIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RELENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxVQUFVO0FBQ2xCO0FBQ0EsUUFBUSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNuQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRDtBQUNBLFFBQVEsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbkMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUN2QyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEQ7QUFDQSxRQUFRLENBQUMsMkJBQTJCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDaEQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxJQUFJLENBQUM7QUFDaEUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekY7QUFDQSxRQUFRLENBQUMsdUJBQXVCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDNUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxJQUFJLENBQUM7QUFDaEUsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pIO0FBQ0EsUUFBUSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzNDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsSUFBSSxDQUFDO0FBQ2hFLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqSDtBQUNBLFFBQVEsQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDcEMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU87QUFDeEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRixDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLENBQUM7QUFDckUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0QsQ0FBQyxDQUFDO0FBQ0YsQ0FBQztBQUNELENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzVDO0FBQ0EsUUFBUSxDQUFDLHdCQUF3QixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzdDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUN4QixDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNwQixDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLCtCQUErQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNILENBQUMsRUFBRSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDZDtBQUNBLFFBQVEsQ0FBQyxnQ0FBZ0MsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNyRCxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEY7QUFDQSxRQUFRLENBQUMsNkJBQTZCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbEQsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUk7QUFDdEIsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMzQyxDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUMzRCxDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMscUNBQXFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1SyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxNQUFNLENBQUMsUUFBUTtBQUNoQjtBQUNBLFFBQVEsQ0FBQyxxQ0FBcUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMxRCxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEY7QUFDQSxRQUFRLENBQUMsMEJBQTBCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDL0MsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25GLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQzFCLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNFLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2Q7QUFDQSxRQUFRLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDeEMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1RTtBQUNBLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN6QyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdFO0FBQ0EsUUFBUSxDQUFDLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUU7QUFDQSxRQUFRLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDckQsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSTtBQUN0QixDQUFDLEVBQUUsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUM3QixDQUFDLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUM5QjtBQUNBLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN0QyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3JCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU07QUFDMUIsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsQixDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztBQUN6QixDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFELENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQzNDLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JHLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakQ7QUFDQSxRQUFRLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDeEMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDO0FBQzFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDMUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUM1QyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDckQsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQztBQUNwQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzNDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDeEMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUN4QyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDakQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ1QsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2hELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUM5QyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDcEQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMzQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDN0MsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMzQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDeEQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUM1QyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUM5QyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDOUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsSUFBSSxDQUFDO0FBQ3RELENBQUM7QUFDRDtBQUNBLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2hDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsdUJBQXVCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3BELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNuRCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDckQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0NBQWdDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzdELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLDZCQUE2QixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMxRCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxxQ0FBcUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDbEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsMEJBQTBCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNoRCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDakQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2xELENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2pGLENBQUM7QUFDRDtBQUNBLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN4QyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3RDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDOUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0FBQzFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ25CLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDeEMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDakUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzRCxDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkO0FBQ0EsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3RDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDdEMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUM5QixDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0FBQ3pDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNqQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTztBQUNsQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ3pFLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hELENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUNiLENBQUM7QUFDRCxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkYsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUN6RDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDdkMsUUFBUSxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2hELENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZCxDQUFDLENBQUM7QUFDRjtBQUNBLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ25DLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ2QsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDcEIsQ0FBQztBQUNELENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQy9DLENBQUM7QUFDRCxDQUFDO0FBQ0QsR0FBRyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDckMsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDZCxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNwQixDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDL0MsQ0FBQztBQUNELENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3JELENBQUM7QUFDRCxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUs7QUFDNUIsQ0FBQztBQUNELENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO0FBQzNCLENBQUM7QUFDRCxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO0FBQzFCLENBQUM7QUFDRCxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUN4QixDQUFDO0FBQ0QsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3pCLENBQUM7QUFDRCxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7QUFDdkMsQ0FBQztBQUNELENBQUM7QUFDRCxRQUFRLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSTtBQUNiLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUk7QUFDZixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPO0FBQzFCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTztBQUMxQixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU07QUFDeEIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUM7QUFDRjtBQUNBLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM1QyxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMzQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsdUJBQXVCLENBQUMsT0FBTztBQUN4QyxDQUFDLENBQUM7QUFDRjtBQUNBLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDekMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsSCxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNiO0FBQ0EsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM3QyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3JFO0FBQ0EsUUFBUSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNqRCxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDO0FBQzNDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckQsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9DLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0RCxDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUM3RCxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxpQ0FBaUMsQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsMEJBQTBCLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xKLENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQztBQUNuRSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxzQ0FBc0MsQ0FBQyx5QkFBeUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsNkJBQTZCLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDck4sQ0FBQztBQUNELENBQUMsRUFBRSxDQUFDLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0FBQ2xFLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7QUFDbEUsQ0FBQztBQUNELENBQUMsRUFBRSxDQUFDLENBQUMsd0JBQXdCLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0FBQ3pFLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUNoRixDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzFELENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNsRjtBQUNBLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BFO0FBQ0EsUUFBUSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNsRCxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNoRCxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQy9FO0FBQ0EsUUFBUSxDQUFDLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3hELENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2hELENBQUMsTUFBTSxDQUFDLDBCQUEwQixDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDckY7QUFDQSxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2hELENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2hELENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDN0U7QUFDQSxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzdDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO0FBQzVELENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUM3RjtBQUNBLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN0RCxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztBQUM1RCxDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUN0RztBQUNBLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzlDLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUN6RDtBQUNBLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzFFLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEM7QUFDQSxRQUFRLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzlDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsMkJBQTJCLENBQUMsRUFBRSxDQUFDLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkYsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDbEMsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUM7QUFDdEIsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDcEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsb0JBQW9CLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDOUQsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQy9ELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQztBQUN2QixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsTUFBTSxDQUFDLE1BQU07QUFDZDtBQUNBLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMvQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDbEQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0ssQ0FBQyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUM7QUFDdkIsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLG9CQUFvQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQy9DLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNsRCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3SyxDQUFDO0FBQ0QsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDO0FBQ3RCO0FBQ0EsUUFBUSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMvQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNoSCxDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsNEJBQTRCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUM1RDtBQUNBLFFBQVEsQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDbEUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1RCxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwSyxDQUFDO0FBQ0Q7QUFDQSxRQUFRLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDcEUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1RCxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxSyxDQUFDO0FBQ0Q7QUFDQSxRQUFRLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzlDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPO0FBQ3hDLENBQUMsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsY0FBYyxDQUFDO0FBQ2xLO0FBQ0EsUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNoRCxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BHLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQzNEO0FBQ0EsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ2xFLENBQUMsTUFBTSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3RFLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDckUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMvQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUs7QUFDWixDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVM7QUFDaEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVO0FBQ2pCLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYztBQUNyQixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVc7QUFDbEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTO0FBQ2hCLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDM0QsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNO0FBQ2IsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPO0FBQ2QsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNO0FBQ2IsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUN6RCxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3ZFLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUztBQUNoQixDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVU7QUFDakIsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVO0FBQ2pCLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVTtBQUNqQixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVc7QUFDbEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXO0FBQ2xCLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCO0FBQ3hCLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWTtBQUNuQixDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3BFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDOUQsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNwRCxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3BELENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3pHLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRO0FBQzFDLENBQUMsRUFBRSxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMxRixDQUFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhO0FBQ3BCLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsTUFBTSxDQUFDLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUM1RSxDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNoTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDcEYsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNsRSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ25FLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDcEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUN4RSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3hFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDcEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUN6RSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3hFLENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDekUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUM7QUFDL0gsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLE9BQU8sQ0FBQztBQUMvQztBQUNBLFFBQVEsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDdkUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNuRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3ZFLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFdBQVc7QUFDdkMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDcEUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVc7QUFDNUQsQ0FBQztBQUNELENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDO0FBQ3ZGLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNwRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQzFCLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFlBQVksQ0FBQztBQUNoRTtBQUNBLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDNUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2hELENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSztBQUNyQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzNELENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDMUIsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLE9BQU8sQ0FBQztBQUMvQztBQUNBLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO0FBQ3hGLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsVUFBVTtBQUN6RCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYztBQUN6QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUM7QUFDakQsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQztBQUNqRCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ25ELENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUs7QUFDdkYsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUztBQUNuQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMvRCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUM1RCxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxPQUFPLENBQUM7QUFDekQsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNoQyxDQUFDLEdBQUcsQ0FBQztBQUNMLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQztBQUNuRixDQUFDO0FBQ0Q7QUFDQSxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzVCLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQ25ELENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDdkM7QUFDQSxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzdCLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7QUFDaEQsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQztBQUN2RjtBQUNBLFFBQVEsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDckIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDekMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkY7QUFDQSxRQUFRLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzdDLENBQUMsR0FBRyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNyQixDQUFDO0FBQ0Q7QUFDQSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3BCO0FBQ0EsUUFBUSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM5QixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQzFDO0FBQ0EsUUFBUSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM3QyxDQUFDLEdBQUcsQ0FBQztBQUNMLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxNQUFNO0FBQ1IsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3hDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMvQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDcEMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzNCLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUM7QUFDckQsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3RDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3RHO0FBQ0EsUUFBUSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSztBQUN6QixDQUFDO0FBQ0Q7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7QUFDL0IsUUFBUSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztBQUNoRCxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyx1QkFBdUI7QUFDMUQsQ0FBQyxDQUFDLE9BQU87QUFDVCxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCO0FBQzVDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDbkMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsNEJBQTRCLENBQUM7QUFDdkQsQ0FBQyxDQUFDLE9BQU87QUFDVCxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRO0FBQzdCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTztBQUMxQixDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1Y7QUFDQSxLQUFLLENBQUMsUUFBUSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6RCxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO0FBQ2hELENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsT0FBTyxDQUFDLHVCQUF1QjtBQUMxRCxDQUFDLENBQUMsT0FBTztBQUNULENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0I7QUFDNUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDOUMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsNEJBQTRCLENBQUM7QUFDdkQsQ0FBQyxDQUFDLE9BQU87QUFDVCxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRO0FBQzdCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTztBQUMxQixDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1Y7QUFDQSxRQUFRLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO0FBQ2hELENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QyxDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxPQUFPLENBQUMsdUJBQXVCO0FBQzFELENBQUMsQ0FBQyxPQUFPO0FBQ1QsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsT0FBTyxDQUFDLGdCQUFnQjtBQUM1QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDWjtBQUNBLEtBQUssQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RELENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7QUFDaEQsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4RCxDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxPQUFPLENBQUMsdUJBQXVCO0FBQzFELENBQUMsQ0FBQyxPQUFPO0FBQ1QsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsT0FBTyxDQUFDLGdCQUFnQjtBQUM1QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDWjtBQUNBLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMvQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO0FBQ2hELENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMseUJBQXlCLENBQUM7QUFDdkMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsT0FBTyxDQUFDLHVCQUF1QjtBQUMxRCxDQUFDLENBQUMsT0FBTztBQUNULENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSTtBQUNwQixDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCO0FBQzVDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsNEJBQTRCLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVE7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVU7QUFDakIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ1YsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMzQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTztBQUMxQixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDOUIsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUMxQztBQUNBLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM1QyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO0FBQ2hELENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMseUJBQXlCLENBQUM7QUFDdkMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsT0FBTyxDQUFDLHVCQUF1QjtBQUMxRCxDQUFDLENBQUMsT0FBTztBQUNULENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSTtBQUNwQixDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCO0FBQzVDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVTtBQUNoQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU87QUFDMUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPO0FBQzFCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUM5QixDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQzFDO0FBQ0EsUUFBUSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN4QyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO0FBQ2hELENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyw4QkFBOEIsQ0FBQztBQUN0RCxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsT0FBTyxDQUFDLGVBQWU7QUFDMUMsQ0FBQyxDQUFDLE9BQU87QUFDVCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUk7QUFDcEIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRO0FBQzVCLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0I7QUFDNUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1o7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztBQUM5QixHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDdkIsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDeEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDbkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDdEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDbkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7QUFDaEQsQ0FBQztBQUNELENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDbEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFnQjtBQUNuRCxDQUFDLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyx1QkFBdUI7QUFDakUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU87QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUN2SSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDbEYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQztBQUNGLENBQUM7QUFDRCxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNqRCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRztBQUN0QixDQUFDO0FBQ0QsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUMxQixDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDZCxDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQy9ELENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDcEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9FLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDcEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3JCLENBQUMsQ0FBQztBQUNGLENBQUM7QUFDRCxDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQzlCLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7QUFDaEQsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxPQUFPLENBQUMsdUJBQXVCO0FBQzFELENBQUMsQ0FBQyxPQUFPO0FBQ1QsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ25DLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLDhCQUE4QixDQUFDO0FBQzNELENBQUMsQ0FBQyxPQUFPO0FBQ1QsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUTtBQUM3QixDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1Y7QUFDQSxLQUFLLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEQsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztBQUNoRCxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyx1QkFBdUI7QUFDMUQsQ0FBQyxDQUFDLE9BQU87QUFDVCxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzlDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLDhCQUE4QixDQUFDO0FBQzNELENBQUMsQ0FBQyxPQUFPO0FBQ1QsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUTtBQUM3QixDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1Y7QUFDQSxRQUFRLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ3pCO0FBQ0EsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztBQUNoRCxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyx1QkFBdUI7QUFDMUQsQ0FBQyxDQUFDLE9BQU87QUFDVCxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVE7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNO0FBQy9CLENBQUMsQ0FBQztBQUNGO0FBQ0EsS0FBSyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pELENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7QUFDaEQsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxPQUFPLENBQUMsdUJBQXVCO0FBQzFELENBQUMsQ0FBQyxPQUFPO0FBQ1QsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUTtBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU07QUFDL0IsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxRQUFRLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyw4QkFBOEIsQ0FBQztBQUMzRCxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7QUFDMUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDZDtBQUNBLFFBQVEsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztBQUNoRCxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkQsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUNqRyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsZ0NBQWdDLENBQUM7QUFDeEQsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxlQUFlO0FBQzFDLENBQUMsQ0FBQyxPQUFPO0FBQ1QsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCO0FBQzlDLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2Q7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7In0=