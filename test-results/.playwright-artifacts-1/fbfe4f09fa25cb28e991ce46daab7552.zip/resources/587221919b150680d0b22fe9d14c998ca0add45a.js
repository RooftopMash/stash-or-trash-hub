import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/terms.tsx");const $$splitComponentImporter = () => import("/src/routes/terms.tsx?tsr-split=component");
import { lazyRouteComponent } from "/node_modules/@tanstack/react-router/dist/esm/index.dev.js?v=a8030269";
import { createFileRoute } from "/node_modules/@tanstack/react-router/dist/esm/index.dev.js?v=a8030269";
const TSRSplitComponent = (() => {
	const hot = import.meta.hot;
	const hotData = hot ? hot.data ??= {} : undefined;
	return hotData?.["tsr-split-component:component"] ?? lazyRouteComponent($$splitComponentImporter, "component");
})();
if (import.meta.hot) {
	(import.meta.hot.data ??= {})["tsr-split-component:component"] = TSRSplitComponent;
}
export const Route = createFileRoute("/terms")({ component: TSRSplitComponent });
const hot = import.meta.hot;
if (hot && typeof window !== "undefined") {
	hot.data ??= {};
	const tsrReactRefresh = window.__TSR_REACT_REFRESH__ ??= (() => {
		const ignoredExportsById = new Map();
		const previousGetIgnoredExports = window.__getReactRefreshIgnoredExports;
		window.__getReactRefreshIgnoredExports = (ctx) => {
			const ignoredExports = previousGetIgnoredExports?.(ctx) ?? [];
			const moduleIgnored = ignoredExportsById.get(ctx.id) ?? [];
			return [...ignoredExports, ...moduleIgnored];
		};
		return { ignoredExportsById };
	})();
	tsrReactRefresh.ignoredExportsById.set("/app/applet/src/routes/terms.tsx", ["Route"]);
}
export function TSRFastRefreshAnchor() {
	return null;
}
_c = TSRFastRefreshAnchor;
if (import.meta.hot) {
	const hot = import.meta.hot;
	const hotData = hot.data ??= {};
	const handleRouteUpdate = function handleRouteUpdate(routeId, newRoute) {
		const router = window.__TSR_ROUTER__;
		const oldRoute = router.routesById[routeId];
		if (!oldRoute) return;
		const generatedRouteOptionKeys = new Set([
			"id",
			"path",
			"getParentRoute"
		]);
		const generatedRouteOptions = {};
		generatedRouteOptionKeys.forEach((key) => {
			if (key in oldRoute.options) generatedRouteOptions[key] = oldRoute.options[key];
		});
		const preserveComponentIdentity = "shellComponent" in oldRoute.options === "shellComponent" in newRoute.options;
		const componentKeys = [
			"component",
			"shellComponent",
			"pendingComponent",
			"errorComponent",
			"notFoundComponent"
		];
		if (preserveComponentIdentity) componentKeys.forEach((key) => {
			if (key in oldRoute.options && key in newRoute.options) newRoute.options[key] = oldRoute.options[key];
		});
		const nextOptions = {
			...newRoute.options,
			...generatedRouteOptions
		};
		oldRoute.options = nextOptions;
		oldRoute.update(nextOptions);
		router._replaceRouteChunk(oldRoute, newRoute.lazyFn);
		router.setRoutes(router.buildRouteTree());
		syncHotRouteExport(oldRoute);
		router.resolvePathCache.clear();
		router._refreshRoute?.();
		function syncHotRouteExport(liveRoute) {
			newRoute.options = liveRoute.options;
			newRoute.parentRoute = liveRoute.parentRoute;
			newRoute._path = liveRoute._path;
			newRoute._id = liveRoute._id;
			newRoute._fullPath = liveRoute._fullPath;
			newRoute._to = liveRoute._to;
		}
	};
	const initialRouteId = "/terms" ?? hotData["tsr-route-id"];
	if (initialRouteId) {
		hotData["tsr-route-id"] = initialRouteId;
	}
	const existingRoute = typeof window !== "undefined" && initialRouteId ? window.__TSR_ROUTER__?.routesById?.[initialRouteId] : undefined;
	if (initialRouteId && existingRoute && existingRoute !== Route) {
		handleRouteUpdate(initialRouteId, Route);
		hotData["tsr-route-update-handled"] = Route;
	}
	hot.accept((newModule) => {
		if (Route && newModule && newModule.Route) {
			const routeId = hotData["tsr-route-id"] ?? "/terms";
			if (routeId) {
				hotData["tsr-route-id"] = routeId;
			}
			if (hotData["tsr-route-update-handled"] === newModule.Route) {
				delete hotData["tsr-route-update-handled"];
				return;
			}
			handleRouteUpdate(routeId, newModule.Route);
		}
	});
}
var _c;
$RefreshReg$(_c, "TSRFastRefreshAnchor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/terms.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/routes/terms.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/routes/terms.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/routes/terms.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7QUFBQSxTQUFBQSx1QkFBQTtBQUFBLE1BQUFDLDJCQUFBO0NBQUEsTUFBQUMsTUFBQUMsWUFBQUQ7Q0FBQSxNQUFBRSxVQUFBRixVQUFBRyxTQUFBLEtBQUFDO0NBQUEsT0FBQUYsVUFBQSxvQ0FBQUcsbUJBQUFDLDBCQUFBO0FBQUE7QUFBQSxJQUFBTCxZQUFBRCxLQUFBO0NBQUEsQ0FBQUMsWUFBQUQsSUFBQUcsU0FBQSx1Q0FBQUo7QUFBQTtBQUdBLGFBQUFRLFFBQUFULGdCQUFBLFlBQUFVLFdBQUFULGtCQUFBO0FBQUEsTUFBQUMsTUFBQUMsWUFBQUQ7QUFBQSxJQUFBQSxPQUFBLE9BQUFTLFdBQUE7Q0FBQVQsSUFBQUcsU0FBQTtDQUFBLE1BQUFPLGtCQUFBRCxPQUFBRSxpQ0FBQTtFQUFBLE1BQUFDLHFCQUFBLElBQUFDLElBQUE7RUFBQSxNQUFBQyw0QkFBQUwsT0FBQU07RUFBQU4sT0FBQU0sbUNBQUFDLFFBQUE7R0FBQSxNQUFBQyxpQkFBQUgsNEJBQUFFLEdBQUE7R0FBQSxNQUFBRSxnQkFBQU4sbUJBQUFPLElBQUFILElBQUFJLEVBQUE7R0FBQSxXQUFBSCxnQkFBQSxHQUFBQyxhQUFBO0VBQUE7RUFBQSxTQUFBTixtQkFBQTtDQUFBO0NBQUFGLGdCQUFBRSxtQkFBQVMsSUFBQTtBQUFBO0FBQUEsZ0JBQUFDLHVCQUFBO0NBQUE7QUFBQTs7QUFBQSxJQUFBckIsWUFBQUQsS0FBQTtDQUFBLE1BQUFBLE1BQUFDLFlBQUFEO0NBQUEsTUFBQUUsVUFBQUYsSUFBQUcsU0FBQTtDQUFBLE1BQUFvQixvQkFBQSxTQUFBQSxrQkFBQUMsU0FBQUMsVUFBQTtFQUFBLE1BQUFDLFNBQUFqQixPQUFBa0I7RUFBQSxNQUFBQyxXQUFBRixPQUFBRyxXQUFBTDtFQUFBLEtBQUFJLFVBQUE7RUFBQSxNQUFBRSwyQkFBQSxJQUFBQyxJQUFBO0dBQUE7R0FBQTtHQUFBO0VBQUE7RUFBQSxNQUFBQyx3QkFBQTtFQUFBRix5QkFBQUcsU0FBQUMsUUFBQTtHQUFBLElBQUFBLE9BQUFOLFNBQUFPLFNBQUFILHNCQUFBRSxPQUFBTixTQUFBTyxRQUFBRDtFQUFBO0VBQUEsTUFBQUUsNEJBQUEsb0JBQUFSLFNBQUFPLFlBQUEsb0JBQUFWLFNBQUFVO0VBQUEsTUFBQUUsZ0JBQUE7R0FBQTtHQUFBO0dBQUE7R0FBQTtHQUFBO0VBQUE7RUFBQSxJQUFBRCwyQkFBQUMsY0FBQUosU0FBQUMsUUFBQTtHQUFBLElBQUFBLE9BQUFOLFNBQUFPLFdBQUFELE9BQUFULFNBQUFVLFNBQUFWLFNBQUFVLFFBQUFELE9BQUFOLFNBQUFPLFFBQUFEO0VBQUE7RUFBQSxNQUFBSSxjQUFBO0dBQUEsR0FBQWIsU0FBQVU7R0FBQSxHQUFBSDtFQUFBO0VBQUFKLFNBQUFPLFVBQUFHO0VBQUFWLFNBQUFXLE9BQUFELFdBQUE7RUFBQVosT0FBQWMsbUJBQUFaLFVBQUFILFNBQUFnQixNQUFBO0VBQUFmLE9BQUFnQixVQUFBaEIsT0FBQWlCLGVBQUE7RUFBQUMsbUJBQUFoQixRQUFBO0VBQUFGLE9BQUFtQixpQkFBQUMsTUFBQTtFQUFBcEIsT0FBQXFCLGdCQUFBO0VBQUEsU0FBQUgsbUJBQUFJLFdBQUE7R0FBQXZCLFNBQUFVLFVBQUFhLFVBQUFiO0dBQUFWLFNBQUF3QixjQUFBRCxVQUFBQztHQUFBeEIsU0FBQXlCLFFBQUFGLFVBQUFFO0dBQUF6QixTQUFBMEIsTUFBQUgsVUFBQUc7R0FBQTFCLFNBQUEyQixZQUFBSixVQUFBSTtHQUFBM0IsU0FBQTRCLE1BQUFMLFVBQUFLO0VBQUE7Q0FBQTtDQUFBLE1BQUFDLGlCQUFBLFlBQUFwRCxRQUFBO0NBQUEsSUFBQW9ELGdCQUFBO0VBQUFwRCxRQUFBLGtCQUFBb0Q7Q0FBQTtDQUFBLE1BQUFDLGdCQUFBLE9BQUE5QyxXQUFBLGVBQUE2QyxpQkFBQTdDLE9BQUFrQixnQkFBQUUsYUFBQXlCLGtCQUFBbEQ7Q0FBQSxJQUFBa0Qsa0JBQUFDLG1DQUFBaEQsT0FBQTtFQUFBZ0Isa0JBQUErQixnQkFBQS9DLEtBQUE7RUFBQUwsUUFBQSw4QkFBQUs7Q0FBQTtDQUFBUCxJQUFBd0QsUUFBQUMsY0FBQTtFQUFBLElBQUFsRCxTQUFBa0QsdUJBQUFsRCxPQUFBO0dBQUEsTUFBQWlCLFVBQUF0QixRQUFBO0dBQUEsSUFBQXNCLFNBQUE7SUFBQXRCLFFBQUEsa0JBQUFzQjtHQUFBO0dBQUEsSUFBQXRCLFFBQUEsZ0NBQUF1RCxVQUFBbEQsT0FBQTtJQUFBLE9BQUFMLFFBQUE7SUFBQTtHQUFBO0dBQUFxQixrQkFBQUMsU0FBQWlDLFVBQUFsRCxLQUFBO0VBQUE7Q0FBQTtBQUFBIiwibmFtZXMiOlsiY3JlYXRlRmlsZVJvdXRlIiwiVFNSU3BsaXRDb21wb25lbnQiLCJob3QiLCJpbXBvcnQiLCJob3REYXRhIiwiZGF0YSIsInVuZGVmaW5lZCIsImxhenlSb3V0ZUNvbXBvbmVudCIsIiQkc3BsaXRDb21wb25lbnRJbXBvcnRlciIsIlJvdXRlIiwiY29tcG9uZW50Iiwid2luZG93IiwidHNyUmVhY3RSZWZyZXNoIiwiX19UU1JfUkVBQ1RfUkVGUkVTSF9fIiwiaWdub3JlZEV4cG9ydHNCeUlkIiwiTWFwIiwicHJldmlvdXNHZXRJZ25vcmVkRXhwb3J0cyIsIl9fZ2V0UmVhY3RSZWZyZXNoSWdub3JlZEV4cG9ydHMiLCJjdHgiLCJpZ25vcmVkRXhwb3J0cyIsIm1vZHVsZUlnbm9yZWQiLCJnZXQiLCJpZCIsInNldCIsIlRTUkZhc3RSZWZyZXNoQW5jaG9yIiwiaGFuZGxlUm91dGVVcGRhdGUiLCJyb3V0ZUlkIiwibmV3Um91dGUiLCJyb3V0ZXIiLCJfX1RTUl9ST1VURVJfXyIsIm9sZFJvdXRlIiwicm91dGVzQnlJZCIsImdlbmVyYXRlZFJvdXRlT3B0aW9uS2V5cyIsIlNldCIsImdlbmVyYXRlZFJvdXRlT3B0aW9ucyIsImZvckVhY2giLCJrZXkiLCJvcHRpb25zIiwicHJlc2VydmVDb21wb25lbnRJZGVudGl0eSIsImNvbXBvbmVudEtleXMiLCJuZXh0T3B0aW9ucyIsInVwZGF0ZSIsIl9yZXBsYWNlUm91dGVDaHVuayIsImxhenlGbiIsInNldFJvdXRlcyIsImJ1aWxkUm91dGVUcmVlIiwic3luY0hvdFJvdXRlRXhwb3J0IiwicmVzb2x2ZVBhdGhDYWNoZSIsImNsZWFyIiwiX3JlZnJlc2hSb3V0ZSIsImxpdmVSb3V0ZSIsInBhcmVudFJvdXRlIiwiX3BhdGgiLCJfaWQiLCJfZnVsbFBhdGgiLCJfdG8iLCJpbml0aWFsUm91dGVJZCIsImV4aXN0aW5nUm91dGUiLCJhY2NlcHQiLCJuZXdNb2R1bGUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsidGVybXMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUZpbGVSb3V0ZSB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtcm91dGVyXCI7XG5pbXBvcnQgeyBIZWFkZXIgfSBmcm9tIFwiQC9jb21wb25lbnRzL0hlYWRlclwiO1xuXG5leHBvcnQgY29uc3QgUm91dGUgPSBjcmVhdGVGaWxlUm91dGUoXCIvdGVybXNcIikoeyBjb21wb25lbnQ6IFRlcm1zUGFnZSB9KTtcblxuZnVuY3Rpb24gVGVybXNQYWdlKCkge1xuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW5cIj48SGVhZGVyIC8+PG1haW4gY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy0zeGwgcHgtNCBweS0xMFwiPjxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xOGVtXSB0ZXh0LXN0YXNoXCI+VGVybXMgb2Ygc2VydmljZSDCtyAyMDI2LTA5LTExPC9wPjxoMSBjbGFzc05hbWU9XCJtdC0yIGZvbnQtZGlzcGxheSB0ZXh0LTR4bCBmb250LWV4dHJhYm9sZFwiPkZhaXIgcGFydGljaXBhdGlvbiBhbmQgYWNjb3VudGFiaWxpdHk8L2gxPjxkaXYgY2xhc3NOYW1lPVwicHJvc2UgcHJvc2Utc20gbXQtOCBtYXgtdy1ub25lIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPjxwPlVzZSBTdGFzaCBvciBUcmFzaCBIdWIgdG8gc2hhcmUgaG9uZXN0IGV4cGVyaWVuY2VzLCBpZGVhcywgY29uY2VwdHMsIGludmVudGlvbnMsIGlubm92YXRpb25zLCBhbmQgYnJhbmQgZmVlZGJhY2suIERvIG5vdCBpbXBlcnNvbmF0ZSwgaGFyYXNzLCBkZWZhbWUsIG1hbmlwdWxhdGUgZXZpZGVuY2UsIG9yIHB1Ymxpc2ggdW5sYXdmdWwgY29udGVudC48L3A+PGgyPk1vZGVyYXRpb248L2gyPjxwPlN1Ym1pc3Npb25zIG1heSBiZSBjaGVja2VkIGJ5IGF1dG9tYXRlZCBzYWZldHkgc3lzdGVtcyBhbmQgaHVtYW4gcmV2aWV3ZXJzLiBXZSBtYXkgbGltaXQsIHJlbW92ZSwgb3IgaG9sZCBjb250ZW50IHdoaWxlIGFuIGFwcGVhbCBpcyByZXZpZXdlZC4gTm8gYXV0b21hdGVkIHN5c3RlbSBpcyBhIHN1YnN0aXR1dGUgZm9yIGV2aWRlbmNlIG9yIGR1ZSBwcm9jZXNzLjwvcD48aDI+QnJhbmQgY29tbXVuaWNhdGlvbjwvaDI+PHA+QnJhbmQgcmVzcG9uc2VzIGFuZCBBSS1hc3Npc3RlZCBhZHZpY2UgbXVzdCBiZSByZXZpZXdlZCBieSB0aGUgcmVzcG9uc2libGUgYnJhbmQuIFRoZSBzZXJ2aWNlIGRvZXMgbm90IGd1YXJhbnRlZSBhIGJyYW5kIHJlc3BvbnNlLCBjb21tZXJjaWFsIG91dGNvbWUsIG9yIHJhdGluZyByZXN1bHQuPC9wPjxoMj5BY2NvdW50IGNvbnRyb2w8L2gyPjxwPllvdSBhcmUgcmVzcG9uc2libGUgZm9yIHlvdXIgYWNjb3VudC4gWW91IG1heSByZXF1ZXN0IGRlbGV0aW9uLCByZXZva2UgY29ubmVjdGlvbnMsIGFuZCByZXBvcnQgb3IgYmxvY2sgdXNlcnMgdGhyb3VnaCB0aGUgYXBwLjwvcD48L2Rpdj48L21haW4+PC9kaXY+O1xufVxuIl0sImZpbGUiOiIvYXBwL2FwcGxldC9zcmMvcm91dGVzL3Rlcm1zLnRzeCJ9