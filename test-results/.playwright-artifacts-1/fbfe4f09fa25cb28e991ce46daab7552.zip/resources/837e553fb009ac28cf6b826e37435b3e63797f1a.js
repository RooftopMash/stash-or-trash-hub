import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/hashtags.$tag.tsx");const $$splitComponentImporter = () => import("/src/routes/hashtags.$tag.tsx?tsr-split=component");
const $$splitErrorComponentImporter = () => import("/src/routes/hashtags.$tag.tsx?tsr-split=errorComponent");
import { lazyRouteComponent } from "/node_modules/@tanstack/react-router/dist/esm/index.dev.js?v=a8030269";
import { createFileRoute } from "/node_modules/@tanstack/react-router/dist/esm/index.dev.js?v=a8030269";
const TSRSplitErrorComponent = (() => {
	const hot = import.meta.hot;
	const hotData = hot ? hot.data ??= {} : undefined;
	return hotData?.["tsr-split-component:errorComponent"] ?? lazyRouteComponent($$splitErrorComponentImporter, "errorComponent");
})();
if (import.meta.hot) {
	(import.meta.hot.data ??= {})["tsr-split-component:errorComponent"] = TSRSplitErrorComponent;
}
const TSRSplitComponent = (() => {
	const hot = import.meta.hot;
	const hotData = hot ? hot.data ??= {} : undefined;
	return hotData?.["tsr-split-component:component"] ?? lazyRouteComponent($$splitComponentImporter, "component");
})();
if (import.meta.hot) {
	(import.meta.hot.data ??= {})["tsr-split-component:component"] = TSRSplitComponent;
}
export const Route = createFileRoute("/hashtags/$tag")({
	head: () => ({ meta: [
		{ title: "Hashtag — SOT · Stash Or Trash" },
		{
			name: "description",
			content: "Every post carrying this hashtag, with the live community verdict on SOT — the Brand Barometer."
		},
		{
			property: "og:title",
			content: "Hashtag — SOT · Stash Or Trash"
		},
		{
			property: "og:description",
			content: "Every post carrying this hashtag, with the live community verdict on SOT."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	errorComponent: TSRSplitErrorComponent,
	component: TSRSplitComponent
});
const hot = import.meta.hot;
if (hot && typeof window !== "undefined") {
	hot.data ??= {};
	const tsrReactRefresh = window.__TSR_REACT_REFRESH__ ??= (() => {
		const ignoredExportsById = new Map();
		const previousGetIgnoredExports = window.__getReactRefreshIgnoredExports;
		window.__getReactRefreshIgnoredExports = (ctx) => {
			const ignoredExports = previousGetIgnoredExports?.(ctx) ?? [];
			const moduleIgnored = ignoredExportsById.get(ctx.id) ?? [];
			return [...ignoredExports, ...moduleIgnored];
		};
		return { ignoredExportsById };
	})();
	tsrReactRefresh.ignoredExportsById.set("/app/applet/src/routes/hashtags.$tag.tsx", ["Route"]);
}
export function TSRFastRefreshAnchor() {
	return null;
}
_c = TSRFastRefreshAnchor;
if (import.meta.hot) {
	const hot = import.meta.hot;
	const hotData = hot.data ??= {};
	const handleRouteUpdate = function handleRouteUpdate(routeId, newRoute) {
		const router = window.__TSR_ROUTER__;
		const oldRoute = router.routesById[routeId];
		if (!oldRoute) return;
		const generatedRouteOptionKeys = new Set([
			"id",
			"path",
			"getParentRoute"
		]);
		const generatedRouteOptions = {};
		generatedRouteOptionKeys.forEach((key) => {
			if (key in oldRoute.options) generatedRouteOptions[key] = oldRoute.options[key];
		});
		const preserveComponentIdentity = "shellComponent" in oldRoute.options === "shellComponent" in newRoute.options;
		const componentKeys = [
			"component",
			"shellComponent",
			"pendingComponent",
			"errorComponent",
			"notFoundComponent"
		];
		if (preserveComponentIdentity) componentKeys.forEach((key) => {
			if (key in oldRoute.options && key in newRoute.options) newRoute.options[key] = oldRoute.options[key];
		});
		const nextOptions = {
			...newRoute.options,
			...generatedRouteOptions
		};
		oldRoute.options = nextOptions;
		oldRoute.update(nextOptions);
		router._replaceRouteChunk(oldRoute, newRoute.lazyFn);
		router.setRoutes(router.buildRouteTree());
		syncHotRouteExport(oldRoute);
		router.resolvePathCache.clear();
		router._refreshRoute?.();
		function syncHotRouteExport(liveRoute) {
			newRoute.options = liveRoute.options;
			newRoute.parentRoute = liveRoute.parentRoute;
			newRoute._path = liveRoute._path;
			newRoute._id = liveRoute._id;
			newRoute._fullPath = liveRoute._fullPath;
			newRoute._to = liveRoute._to;
		}
	};
	const initialRouteId = "/hashtags/$tag" ?? hotData["tsr-route-id"];
	if (initialRouteId) {
		hotData["tsr-route-id"] = initialRouteId;
	}
	const existingRoute = typeof window !== "undefined" && initialRouteId ? window.__TSR_ROUTER__?.routesById?.[initialRouteId] : undefined;
	if (initialRouteId && existingRoute && existingRoute !== Route) {
		handleRouteUpdate(initialRouteId, Route);
		hotData["tsr-route-update-handled"] = Route;
	}
	hot.accept((newModule) => {
		if (Route && newModule && newModule.Route) {
			const routeId = hotData["tsr-route-id"] ?? "/hashtags/$tag";
			if (routeId) {
				hotData["tsr-route-id"] = routeId;
			}
			if (hotData["tsr-route-update-handled"] === newModule.Route) {
				delete hotData["tsr-route-update-handled"];
				return;
			}
			handleRouteUpdate(routeId, newModule.Route);
		}
	});
}
var _c;
$RefreshReg$(_c, "TSRFastRefreshAnchor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/hashtags.$tag.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/routes/hashtags.$tag.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/routes/hashtags.$tag.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/routes/hashtags.$tag.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7O0FBQUEsU0FBQUEsdUJBQUE7QUFBQSxNQUFBQyxnQ0FBQTtDQUFBLE1BQUFDLE1BQUFDLFlBQUFEO0NBQUEsTUFBQUUsVUFBQUYsVUFBQUcsU0FBQSxLQUFBQztDQUFBLE9BQUFGLFVBQUEseUNBQUFHLG1CQUFBQywrQkFBQTtBQUFBO0FBQUEsSUFBQUwsWUFBQUQsS0FBQTtDQUFBLENBQUFDLFlBQUFELElBQUFHLFNBQUEsNENBQUFKO0FBQUE7QUFBQSxNQUFBUSwyQkFBQTtDQUFBLE1BQUFQLE1BQUFDLFlBQUFEO0NBQUEsTUFBQUUsVUFBQUYsVUFBQUcsU0FBQSxLQUFBQztDQUFBLE9BQUFGLFVBQUEsb0NBQUFHLG1CQUFBRywwQkFBQTtBQUFBO0FBQUEsSUFBQVAsWUFBQUQsS0FBQTtDQUFBLENBQUFDLFlBQUFELElBQUFHLFNBQUEsdUNBQUFJO0FBQUE7QUFVQSxhQUFBRSxRQUFBWCxnQkFBQTtDQUNBWSxhQUFBLEVBQ0FDLE1BQUE7RUFDQSxFQUFBQyxPQUFBO0VBQ0E7R0FDQUMsTUFBQTtHQUNBQyxTQUNBO0VBQ0E7RUFDQTtHQUFBQyxVQUFBO0dBQUFELFNBQUE7RUFBQTtFQUNBO0dBQ0FDLFVBQUE7R0FDQUQsU0FBQTtFQUNBO0VBQ0E7R0FBQUMsVUFBQTtHQUFBRCxTQUFBO0VBQUE7RUFDQTtHQUFBRCxNQUFBO0dBQUFDLFNBQUE7RUFBQTtDQUFBLEVBRUE7Q0FDQUUsZ0JBQUFqQjtDQUNBa0IsV0FBQVY7QUFDQTtBQUFBLE1BQUFQLE1BQUFDLFlBQUFEO0FBQUEsSUFBQUEsT0FBQSxPQUFBa0IsV0FBQTtDQUFBbEIsSUFBQUcsU0FBQTtDQUFBLE1BQUFnQixrQkFBQUQsT0FBQUUsaUNBQUE7RUFBQSxNQUFBQyxxQkFBQSxJQUFBQyxJQUFBO0VBQUEsTUFBQUMsNEJBQUFMLE9BQUFNO0VBQUFOLE9BQUFNLG1DQUFBQyxRQUFBO0dBQUEsTUFBQUMsaUJBQUFILDRCQUFBRSxHQUFBO0dBQUEsTUFBQUUsZ0JBQUFOLG1CQUFBTyxJQUFBSCxJQUFBSSxFQUFBO0dBQUEsV0FBQUgsZ0JBQUEsR0FBQUMsYUFBQTtFQUFBO0VBQUEsU0FBQU4sbUJBQUE7Q0FBQTtDQUFBRixnQkFBQUUsbUJBQUFTLElBQUE7QUFBQTtBQUFBLGdCQUFBQyx1QkFBQTtDQUFBO0FBQUE7O0FBQUEsSUFBQTlCLFlBQUFELEtBQUE7Q0FBQSxNQUFBQSxNQUFBQyxZQUFBRDtDQUFBLE1BQUFFLFVBQUFGLElBQUFHLFNBQUE7Q0FBQSxNQUFBNkIsb0JBQUEsU0FBQUEsa0JBQUFDLFNBQUFDLFVBQUE7RUFBQSxNQUFBQyxTQUFBakIsT0FBQWtCO0VBQUEsTUFBQUMsV0FBQUYsT0FBQUcsV0FBQUw7RUFBQSxLQUFBSSxVQUFBO0VBQUEsTUFBQUUsMkJBQUEsSUFBQUMsSUFBQTtHQUFBO0dBQUE7R0FBQTtFQUFBO0VBQUEsTUFBQUMsd0JBQUE7RUFBQUYseUJBQUFHLFNBQUFDLFFBQUE7R0FBQSxJQUFBQSxPQUFBTixTQUFBTyxTQUFBSCxzQkFBQUUsT0FBQU4sU0FBQU8sUUFBQUQ7RUFBQTtFQUFBLE1BQUFFLDRCQUFBLG9CQUFBUixTQUFBTyxZQUFBLG9CQUFBVixTQUFBVTtFQUFBLE1BQUFFLGdCQUFBO0dBQUE7R0FBQTtHQUFBO0dBQUE7R0FBQTtFQUFBO0VBQUEsSUFBQUQsMkJBQUFDLGNBQUFKLFNBQUFDLFFBQUE7R0FBQSxJQUFBQSxPQUFBTixTQUFBTyxXQUFBRCxPQUFBVCxTQUFBVSxTQUFBVixTQUFBVSxRQUFBRCxPQUFBTixTQUFBTyxRQUFBRDtFQUFBO0VBQUEsTUFBQUksY0FBQTtHQUFBLEdBQUFiLFNBQUFVO0dBQUEsR0FBQUg7RUFBQTtFQUFBSixTQUFBTyxVQUFBRztFQUFBVixTQUFBVyxPQUFBRCxXQUFBO0VBQUFaLE9BQUFjLG1CQUFBWixVQUFBSCxTQUFBZ0IsTUFBQTtFQUFBZixPQUFBZ0IsVUFBQWhCLE9BQUFpQixlQUFBO0VBQUFDLG1CQUFBaEIsUUFBQTtFQUFBRixPQUFBbUIsaUJBQUFDLE1BQUE7RUFBQXBCLE9BQUFxQixnQkFBQTtFQUFBLFNBQUFILG1CQUFBSSxXQUFBO0dBQUF2QixTQUFBVSxVQUFBYSxVQUFBYjtHQUFBVixTQUFBd0IsY0FBQUQsVUFBQUM7R0FBQXhCLFNBQUF5QixRQUFBRixVQUFBRTtHQUFBekIsU0FBQTBCLE1BQUFILFVBQUFHO0dBQUExQixTQUFBMkIsWUFBQUosVUFBQUk7R0FBQTNCLFNBQUE0QixNQUFBTCxVQUFBSztFQUFBO0NBQUE7Q0FBQSxNQUFBQyxpQkFBQSxvQkFBQTdELFFBQUE7Q0FBQSxJQUFBNkQsZ0JBQUE7RUFBQTdELFFBQUEsa0JBQUE2RDtDQUFBO0NBQUEsTUFBQUMsZ0JBQUEsT0FBQTlDLFdBQUEsZUFBQTZDLGlCQUFBN0MsT0FBQWtCLGdCQUFBRSxhQUFBeUIsa0JBQUEzRDtDQUFBLElBQUEyRCxrQkFBQUMsbUNBQUF2RCxPQUFBO0VBQUF1QixrQkFBQStCLGdCQUFBdEQsS0FBQTtFQUFBUCxRQUFBLDhCQUFBTztDQUFBO0NBQUFULElBQUFpRSxRQUFBQyxjQUFBO0VBQUEsSUFBQXpELFNBQUF5RCx1QkFBQXpELE9BQUE7R0FBQSxNQUFBd0IsVUFBQS9CLFFBQUE7R0FBQSxJQUFBK0IsU0FBQTtJQUFBL0IsUUFBQSxrQkFBQStCO0dBQUE7R0FBQSxJQUFBL0IsUUFBQSxnQ0FBQWdFLFVBQUF6RCxPQUFBO0lBQUEsT0FBQVAsUUFBQTtJQUFBO0dBQUE7R0FBQThCLGtCQUFBQyxTQUFBaUMsVUFBQXpELEtBQUE7RUFBQTtDQUFBO0FBQUEiLCJuYW1lcyI6WyJjcmVhdGVGaWxlUm91dGUiLCJUU1JTcGxpdEVycm9yQ29tcG9uZW50IiwiaG90IiwiaW1wb3J0IiwiaG90RGF0YSIsImRhdGEiLCJ1bmRlZmluZWQiLCJsYXp5Um91dGVDb21wb25lbnQiLCIkJHNwbGl0RXJyb3JDb21wb25lbnRJbXBvcnRlciIsIlRTUlNwbGl0Q29tcG9uZW50IiwiJCRzcGxpdENvbXBvbmVudEltcG9ydGVyIiwiUm91dGUiLCJoZWFkIiwibWV0YSIsInRpdGxlIiwibmFtZSIsImNvbnRlbnQiLCJwcm9wZXJ0eSIsImVycm9yQ29tcG9uZW50IiwiY29tcG9uZW50Iiwid2luZG93IiwidHNyUmVhY3RSZWZyZXNoIiwiX19UU1JfUkVBQ1RfUkVGUkVTSF9fIiwiaWdub3JlZEV4cG9ydHNCeUlkIiwiTWFwIiwicHJldmlvdXNHZXRJZ25vcmVkRXhwb3J0cyIsIl9fZ2V0UmVhY3RSZWZyZXNoSWdub3JlZEV4cG9ydHMiLCJjdHgiLCJpZ25vcmVkRXhwb3J0cyIsIm1vZHVsZUlnbm9yZWQiLCJnZXQiLCJpZCIsInNldCIsIlRTUkZhc3RSZWZyZXNoQW5jaG9yIiwiaGFuZGxlUm91dGVVcGRhdGUiLCJyb3V0ZUlkIiwibmV3Um91dGUiLCJyb3V0ZXIiLCJfX1RTUl9ST1VURVJfXyIsIm9sZFJvdXRlIiwicm91dGVzQnlJZCIsImdlbmVyYXRlZFJvdXRlT3B0aW9uS2V5cyIsIlNldCIsImdlbmVyYXRlZFJvdXRlT3B0aW9ucyIsImZvckVhY2giLCJrZXkiLCJvcHRpb25zIiwicHJlc2VydmVDb21wb25lbnRJZGVudGl0eSIsImNvbXBvbmVudEtleXMiLCJuZXh0T3B0aW9ucyIsInVwZGF0ZSIsIl9yZXBsYWNlUm91dGVDaHVuayIsImxhenlGbiIsInNldFJvdXRlcyIsImJ1aWxkUm91dGVUcmVlIiwic3luY0hvdFJvdXRlRXhwb3J0IiwicmVzb2x2ZVBhdGhDYWNoZSIsImNsZWFyIiwiX3JlZnJlc2hSb3V0ZSIsImxpdmVSb3V0ZSIsInBhcmVudFJvdXRlIiwiX3BhdGgiLCJfaWQiLCJfZnVsbFBhdGgiLCJfdG8iLCJpbml0aWFsUm91dGVJZCIsImV4aXN0aW5nUm91dGUiLCJhY2NlcHQiLCJuZXdNb2R1bGUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiaGFzaHRhZ3MuJHRhZy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlRmlsZVJvdXRlLCBMaW5rIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1yb3V0ZXJcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5IH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xuaW1wb3J0IHsgdXNlVHJhbnNsYXRpb24gfSBmcm9tIFwicmVhY3QtaTE4bmV4dFwiO1xuaW1wb3J0IHsgSGVhZGVyIH0gZnJvbSBcIkAvY29tcG9uZW50cy9IZWFkZXJcIjtcbmltcG9ydCB7IEl0ZW1DYXJkIH0gZnJvbSBcIkAvY29tcG9uZW50cy9JdGVtQ2FyZFwiO1xuaW1wb3J0IHsgU2tlbGV0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL3NrZWxldG9uXCI7XG5pbXBvcnQgeyBnZXRJdGVtc0J5SGFzaHRhZywgZ2V0VHJlbmRpbmdIYXNodGFncyB9IGZyb20gXCJAL2xpYi9zb2NpYWxcIjtcbmltcG9ydCB7IGZldGNoRmVlZCB9IGZyb20gXCJAL2xpYi9zdGFzaFwiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCJAL2hvb2tzL3VzZUF1dGhcIjtcblxuZXhwb3J0IGNvbnN0IFJvdXRlID0gY3JlYXRlRmlsZVJvdXRlKFwiL2hhc2h0YWdzLyR0YWdcIikoe1xuICBoZWFkOiAoKSA9PiAoe1xuICAgIG1ldGE6IFtcbiAgICAgIHsgdGl0bGU6IFwiSGFzaHRhZyDigJQgU09UIMK3IFN0YXNoIE9yIFRyYXNoXCIgfSxcbiAgICAgIHtcbiAgICAgICAgbmFtZTogXCJkZXNjcmlwdGlvblwiLFxuICAgICAgICBjb250ZW50OlxuICAgICAgICAgIFwiRXZlcnkgcG9zdCBjYXJyeWluZyB0aGlzIGhhc2h0YWcsIHdpdGggdGhlIGxpdmUgY29tbXVuaXR5IHZlcmRpY3Qgb24gU09UIOKAlCB0aGUgQnJhbmQgQmFyb21ldGVyLlwiLFxuICAgICAgfSxcbiAgICAgIHsgcHJvcGVydHk6IFwib2c6dGl0bGVcIiwgY29udGVudDogXCJIYXNodGFnIOKAlCBTT1QgwrcgU3Rhc2ggT3IgVHJhc2hcIiB9LFxuICAgICAge1xuICAgICAgICBwcm9wZXJ0eTogXCJvZzpkZXNjcmlwdGlvblwiLFxuICAgICAgICBjb250ZW50OiBcIkV2ZXJ5IHBvc3QgY2FycnlpbmcgdGhpcyBoYXNodGFnLCB3aXRoIHRoZSBsaXZlIGNvbW11bml0eSB2ZXJkaWN0IG9uIFNPVC5cIixcbiAgICAgIH0sXG4gICAgICB7IHByb3BlcnR5OiBcIm9nOnR5cGVcIiwgY29udGVudDogXCJ3ZWJzaXRlXCIgfSxcbiAgICAgIHsgbmFtZTogXCJ0d2l0dGVyOmNhcmRcIiwgY29udGVudDogXCJzdW1tYXJ5XCIgfSxcbiAgICBdLFxuICB9KSxcbiAgZXJyb3JDb21wb25lbnQ6IEhhc2h0YWdFcnJvcixcbiAgY29tcG9uZW50OiBIYXNodGFnUGFnZSxcbn0pO1xuXG5mdW5jdGlvbiBIYXNodGFnUGFnZSgpIHtcbiAgY29uc3QgeyB0YWcgfSA9IFJvdXRlLnVzZVBhcmFtcygpO1xuICBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7XG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xuXG4gIGNvbnN0IHsgZGF0YTogdGFnZ2VkSWRzIH0gPSB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IFtcImhhc2h0YWctaXRlbS1pZHNcIiwgdGFnXSxcbiAgICBxdWVyeUZuOiAoKSA9PiBnZXRJdGVtc0J5SGFzaHRhZyh0YWcpLFxuICB9KTtcblxuICBjb25zdCB7IGRhdGE6IGFsbEl0ZW1zLCBpc0xvYWRpbmcsIHJlZmV0Y2ggfSA9IHVzZVF1ZXJ5KHtcbiAgICBxdWVyeUtleTogW1wiZmVlZFwiLCB1c2VyPy5pZCA/PyBcImFub25cIl0sXG4gICAgcXVlcnlGbjogKCkgPT4gZmV0Y2hGZWVkKHVzZXI/LmlkID8/IG51bGwpLFxuICB9KTtcblxuICBjb25zdCB7IGRhdGE6IHRyZW5kaW5nIH0gPSB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IFtcInRyZW5kaW5nLWhhc2h0YWdzXCJdLFxuICAgIHF1ZXJ5Rm46ICgpID0+IGdldFRyZW5kaW5nSGFzaHRhZ3MoOCksXG4gIH0pO1xuXG4gIGNvbnN0IGlkcyA9IG5ldyBTZXQoKHRhZ2dlZElkcyA/PyBbXSkubWFwKChyKSA9PiByLml0ZW1faWQpKTtcbiAgY29uc3QgbmVlZGxlID0gYCMke3RhZy50b0xvd2VyQ2FzZSgpfWA7XG4gIGNvbnN0IGl0ZW1zID0gKGFsbEl0ZW1zID8/IFtdKS5maWx0ZXIoXG4gICAgKGl0ZW0pID0+XG4gICAgICBpZHMuaGFzKGl0ZW0uaWQpIHx8XG4gICAgICBpdGVtLnRpdGxlPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKG5lZWRsZSkgfHxcbiAgICAgIGl0ZW0uZGVzY3JpcHRpb24/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMobmVlZGxlKSxcbiAgKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuXCI+XG4gICAgICA8SGVhZGVyIG9uUG9zdGVkPXsoKSA9PiByZWZldGNoKCl9IC8+XG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTN4bCBweC00IHB5LThcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LTR4bCBmb250LWV4dHJhYm9sZFwiPiN7dGFnfTwvaDE+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgIHt0KFwic29jaWFsLmhhc2h0YWdDb3VudFwiLCB7IGNvdW50OiBpdGVtcy5sZW5ndGggfSl9XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7aXNMb2FkaW5nID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICB7WzAsIDEsIDJdLm1hcCgoaSkgPT4gKFxuICAgICAgICAgICAgICA8U2tlbGV0b24ga2V5PXtpfSBjbGFzc05hbWU9XCJoLTY0IHctZnVsbCByb3VuZGVkLTJ4bFwiIC8+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IGl0ZW1zLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgIHtpdGVtcy5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgPEl0ZW1DYXJkIGtleT17aXRlbS5pZH0gaXRlbT17aXRlbX0gb25DaGFuZ2U9eygpID0+IHJlZmV0Y2goKX0gLz5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1kYXNoZWQgYm9yZGVyLWJvcmRlciBwLTggdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPnt0KFwic29jaWFsLmhhc2h0YWdFbXB0eVwiLCB7IHRhZyB9KX08L3A+XG4gICAgICAgICAgICB7dHJlbmRpbmcgJiYgdHJlbmRpbmcubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+e3QoXCJzb2NpYWwudHJ5U29tZXRoaW5nRWxzZVwiKX08L3A+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIGZsZXggZmxleC13cmFwIGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICB7dHJlbmRpbmcubWFwKChoKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtoLmlkfVxuICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL2hhc2h0YWdzLyR0YWdcIlxuICAgICAgICAgICAgICAgICAgICAgIHBhcmFtcz17eyB0YWc6IGgudGFnIH19XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItYm9yZGVyIHB4LTMgcHktMSB0ZXh0LXNtIGhvdmVyOmJnLXNlY29uZGFyeVwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAje2gudGFnfVxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9tYWluPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5mdW5jdGlvbiBIYXNodGFnRXJyb3IoKSB7XG4gIGNvbnN0IHsgdCB9ID0gdXNlVHJhbnNsYXRpb24oKTtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlblwiPlxuICAgICAgPEhlYWRlciAvPlxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwibXgtYXV0byBtYXgtdy0zeGwgcHgtNCBweS0xNiB0ZXh0LWNlbnRlciB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAge3QoXCJzb2NpYWwubG9hZEZhaWxlZFwiKX1cbiAgICAgIDwvbWFpbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL2FwcC9hcHBsZXQvc3JjL3JvdXRlcy9oYXNodGFncy4kdGFnLnRzeCJ9