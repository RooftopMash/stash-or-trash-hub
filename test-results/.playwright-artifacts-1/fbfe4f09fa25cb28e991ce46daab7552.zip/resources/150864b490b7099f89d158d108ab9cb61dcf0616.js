import { createStream } from "/node_modules/seroval/dist/dev/index.js?v=a8030269";
//#region src/ssr/serializer/rawStreamCodec.ts
function toBase64(bytes) {
	const chunks = [];
	for (let i = 0; i < bytes.length; i += 32768) chunks.push(String.fromCharCode.apply(null, bytes.subarray(i, i + 32768)));
	return btoa(chunks.join(""));
}
function fromBase64(value) {
	const binary = atob(value);
	const bytes = new Uint8Array(binary.length);
	for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
	return bytes;
}
const textDecoder = /* @__PURE__ */ new TextDecoder("utf-8", {
	fatal: true,
	ignoreBOM: true
});
/** `'t' + utf8` for a valid UTF-8 chunk, otherwise `'b' + base64`. */
function encodeText(value) {
	try {
		return "t" + textDecoder.decode(value);
	} catch {
		return "b" + toBase64(value);
	}
}
const textEncoder = /* @__PURE__ */ new TextEncoder();
function decodeText(value) {
	const data = value.slice(1);
	return value[0] === "t" ? textEncoder.encode(data) : fromBase64(data);
}
/**
* Pump a byte stream into a Seroval stream, one encoded chunk per read.
* Returns the Seroval stream and a `stop` function that cancels the reader
* without signalling the Seroval stream; the abort signal and read failures
* stop the pump and throw through the Seroval stream.
*/
function pumpEncodedStream(readable, encode, signal) {
	signal?.throwIfAborted();
	const stream = createStream();
	const reader = readable.getReader();
	let active = true;
	const release = () => {
		active = false;
		signal?.removeEventListener("abort", abort);
		reader.releaseLock();
	};
	const stop = (reason) => {
		if (!active) return false;
		reader.cancel(reason).catch(() => {});
		release();
		return true;
	};
	const abort = () => {
		if (stop(signal.reason)) stream.throw(signal.reason);
	};
	signal?.addEventListener("abort", abort);
	(async () => {
		try {
			while (active) {
				const { done, value } = await reader.read();
				if (!active) return;
				if (done) {
					release();
					stream.return(void 0);
					return;
				}
				stream.next(encode(value));
			}
		} catch (error) {
			if (stop(error)) stream.throw(error);
		}
	})();
	return [stream, stop];
}
/** Rebuild a byte stream from encoded Seroval stream chunks. */
function fromEncodedStream(source, decode) {
	let unsubscribe;
	let done = false;
	return new ReadableStream({
		start(controller) {
			const dispose = source.on({
				next(value) {
					if (done) return;
					try {
						controller.enqueue(decode(value));
					} catch (error) {
						done = true;
						const stop = unsubscribe;
						unsubscribe = void 0;
						stop?.();
						controller.error(error);
					}
				},
				throw(error) {
					if (!done) {
						done = true;
						unsubscribe = void 0;
						controller.error(error);
					}
				},
				return() {
					if (!done) {
						done = true;
						unsubscribe = void 0;
						controller.close();
					}
				}
			});
			if (done) dispose();
			else unsubscribe = dispose;
		},
		cancel() {
			const dispose = unsubscribe;
			unsubscribe = void 0;
			dispose?.();
		}
	});
}
//#endregion
export { decodeText, encodeText, fromBase64, fromEncodedStream, pumpEncodedStream, toBase64 };

                                          
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmF3U3RyZWFtQ29kZWMuanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3Nzci9zZXJpYWxpemVyL3Jhd1N0cmVhbUNvZGVjLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZVN0cmVhbSB9IGZyb20gJ3Nlcm92YWwnXG5cbi8vIFdlYi1vbmx5IHByaW1pdGl2ZXMgc2hhcmVkIGJ5IHRoZSBKU09OIGFuZCBTU1IgUmF3U3RyZWFtIHBsdWdpbnMuIFRoaXNcbi8vIG1vZHVsZSBpcyBwYXJ0IG9mIHRoZSBjbGllbnQgYnVuZGxlOiBpdCBtdXN0IG5vdCByZWZlcmVuY2UgYEJ1ZmZlcmAsIGFuZFxuLy8gdGhlIGVuY29kZSBhbmQgZGVjb2RlIGhhbHZlcyBtdXN0IHN0YXkgaW5kZXBlbmRlbnRseSB0cmVlLXNoYWtlYWJsZS5cblxuZXhwb3J0IGZ1bmN0aW9uIHRvQmFzZTY0KGJ5dGVzOiBVaW50OEFycmF5KSB7XG4gIGNvbnN0IGNodW5rczogQXJyYXk8c3RyaW5nPiA9IFtdXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYnl0ZXMubGVuZ3RoOyBpICs9IDB4ODAwMCkge1xuICAgIGNodW5rcy5wdXNoKFxuICAgICAgU3RyaW5nLmZyb21DaGFyQ29kZS5hcHBseShudWxsLCBieXRlcy5zdWJhcnJheShpLCBpICsgMHg4MDAwKSBhcyBhbnkpLFxuICAgIClcbiAgfVxuICByZXR1cm4gYnRvYShjaHVua3Muam9pbignJykpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBmcm9tQmFzZTY0KHZhbHVlOiBzdHJpbmcpIHtcbiAgY29uc3QgYmluYXJ5ID0gYXRvYih2YWx1ZSlcbiAgY29uc3QgYnl0ZXMgPSBuZXcgVWludDhBcnJheShiaW5hcnkubGVuZ3RoKVxuICBmb3IgKGxldCBpID0gMDsgaSA8IGJpbmFyeS5sZW5ndGg7IGkrKykge1xuICAgIGJ5dGVzW2ldID0gYmluYXJ5LmNoYXJDb2RlQXQoaSlcbiAgfVxuICByZXR1cm4gYnl0ZXNcbn1cblxuY29uc3QgdGV4dERlY29kZXIgPSAvKiBAX19QVVJFX18gKi8gbmV3IFRleHREZWNvZGVyKCd1dGYtOCcsIHtcbiAgZmF0YWw6IHRydWUsXG4gIGlnbm9yZUJPTTogdHJ1ZSxcbn0pXG5cbi8qKiBgJ3QnICsgdXRmOGAgZm9yIGEgdmFsaWQgVVRGLTggY2h1bmssIG90aGVyd2lzZSBgJ2InICsgYmFzZTY0YC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBlbmNvZGVUZXh0KHZhbHVlOiBVaW50OEFycmF5KSB7XG4gIHRyeSB7XG4gICAgcmV0dXJuICd0JyArIHRleHREZWNvZGVyLmRlY29kZSh2YWx1ZSlcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuICdiJyArIHRvQmFzZTY0KHZhbHVlKVxuICB9XG59XG5cbmNvbnN0IHRleHRFbmNvZGVyID0gLyogQF9fUFVSRV9fICovIG5ldyBUZXh0RW5jb2RlcigpXG5cbmV4cG9ydCBmdW5jdGlvbiBkZWNvZGVUZXh0KHZhbHVlOiBzdHJpbmcpIHtcbiAgY29uc3QgZGF0YSA9IHZhbHVlLnNsaWNlKDEpXG4gIHJldHVybiB2YWx1ZVswXSA9PT0gJ3QnID8gdGV4dEVuY29kZXIuZW5jb2RlKGRhdGEpIDogZnJvbUJhc2U2NChkYXRhKVxufVxuXG4vKipcbiAqIFB1bXAgYSBieXRlIHN0cmVhbSBpbnRvIGEgU2Vyb3ZhbCBzdHJlYW0sIG9uZSBlbmNvZGVkIGNodW5rIHBlciByZWFkLlxuICogUmV0dXJucyB0aGUgU2Vyb3ZhbCBzdHJlYW0gYW5kIGEgYHN0b3BgIGZ1bmN0aW9uIHRoYXQgY2FuY2VscyB0aGUgcmVhZGVyXG4gKiB3aXRob3V0IHNpZ25hbGxpbmcgdGhlIFNlcm92YWwgc3RyZWFtOyB0aGUgYWJvcnQgc2lnbmFsIGFuZCByZWFkIGZhaWx1cmVzXG4gKiBzdG9wIHRoZSBwdW1wIGFuZCB0aHJvdyB0aHJvdWdoIHRoZSBTZXJvdmFsIHN0cmVhbS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHB1bXBFbmNvZGVkU3RyZWFtKFxuICByZWFkYWJsZTogUmVhZGFibGVTdHJlYW08VWludDhBcnJheT4sXG4gIGVuY29kZTogKHZhbHVlOiBVaW50OEFycmF5KSA9PiBzdHJpbmcsXG4gIHNpZ25hbD86IEFib3J0U2lnbmFsLFxuKSB7XG4gIHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKVxuXG4gIGNvbnN0IHN0cmVhbSA9IGNyZWF0ZVN0cmVhbTxzdHJpbmcgfCB1bmRlZmluZWQ+KClcbiAgY29uc3QgcmVhZGVyID0gcmVhZGFibGUuZ2V0UmVhZGVyKClcbiAgbGV0IGFjdGl2ZSA9IHRydWVcblxuICBjb25zdCByZWxlYXNlID0gKCkgPT4ge1xuICAgIGFjdGl2ZSA9IGZhbHNlXG4gICAgc2lnbmFsPy5yZW1vdmVFdmVudExpc3RlbmVyKCdhYm9ydCcsIGFib3J0KVxuICAgIHJlYWRlci5yZWxlYXNlTG9jaygpXG4gIH1cbiAgY29uc3Qgc3RvcCA9IChyZWFzb24/OiB1bmtub3duKSA9PiB7XG4gICAgaWYgKCFhY3RpdmUpIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgICB2b2lkIHJlYWRlci5jYW5jZWwocmVhc29uKS5jYXRjaCgoKSA9PiB7fSlcbiAgICByZWxlYXNlKClcbiAgICByZXR1cm4gdHJ1ZVxuICB9XG4gIGNvbnN0IGFib3J0ID0gKCkgPT4ge1xuICAgIGlmIChzdG9wKHNpZ25hbCEucmVhc29uKSkge1xuICAgICAgc3RyZWFtLnRocm93KHNpZ25hbCEucmVhc29uKVxuICAgIH1cbiAgfVxuXG4gIHNpZ25hbD8uYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBhYm9ydClcbiAgOyhhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIHdoaWxlIChhY3RpdmUpIHtcbiAgICAgICAgY29uc3QgeyBkb25lLCB2YWx1ZSB9ID0gYXdhaXQgcmVhZGVyLnJlYWQoKVxuICAgICAgICBpZiAoIWFjdGl2ZSkge1xuICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG4gICAgICAgIGlmIChkb25lKSB7XG4gICAgICAgICAgcmVsZWFzZSgpXG4gICAgICAgICAgc3RyZWFtLnJldHVybih1bmRlZmluZWQpXG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cbiAgICAgICAgc3RyZWFtLm5leHQoZW5jb2RlKHZhbHVlKSlcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKHN0b3AoZXJyb3IpKSB7XG4gICAgICAgIHN0cmVhbS50aHJvdyhlcnJvcilcbiAgICAgIH1cbiAgICB9XG4gIH0pKClcblxuICByZXR1cm4gW3N0cmVhbSwgc3RvcF0gYXMgY29uc3Rcbn1cblxuLyoqIFJlYnVpbGQgYSBieXRlIHN0cmVhbSBmcm9tIGVuY29kZWQgU2Vyb3ZhbCBzdHJlYW0gY2h1bmtzLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZyb21FbmNvZGVkU3RyZWFtKFxuICBzb3VyY2U6IFJldHVyblR5cGU8dHlwZW9mIGNyZWF0ZVN0cmVhbTxzdHJpbmcgfCB1bmRlZmluZWQ+PixcbiAgZGVjb2RlOiAodmFsdWU6IHN0cmluZykgPT4gVWludDhBcnJheSxcbikge1xuICAvLyBEcm9wcGluZyB0aGUgZGlzcG9zZXIgYWZ0ZXIgYSB0ZXJtaW5hbCBldmVudCBsZXRzIFNlcm92YWwncyBidWZmZXIgYmVcbiAgLy8gY29sbGVjdGVkIHdoaWxlIGFwcGxpY2F0aW9uIGNvZGUgc3RpbGwgaG9sZHMgdGhlIGZpbmlzaGVkIHN0cmVhbS5cbiAgbGV0IHVuc3Vic2NyaWJlOiAoKCkgPT4gdm9pZCkgfCB1bmRlZmluZWRcbiAgbGV0IGRvbmUgPSBmYWxzZVxuXG4gIHJldHVybiBuZXcgUmVhZGFibGVTdHJlYW08VWludDhBcnJheT4oe1xuICAgIHN0YXJ0KGNvbnRyb2xsZXIpIHtcbiAgICAgIGNvbnN0IGRpc3Bvc2UgPSBzb3VyY2Uub24oe1xuICAgICAgICBuZXh0KHZhbHVlKSB7XG4gICAgICAgICAgaWYgKGRvbmUpIHtcbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICAgIH1cbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29udHJvbGxlci5lbnF1ZXVlKGRlY29kZSh2YWx1ZSEpKVxuICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAvLyBBIG1hbGZvcm1lZCBjaHVuayBmYWlscyB0aGlzIHN0cmVhbSBhbmQgYWJhbmRvbnMgdGhlIHNvdXJjZS5cbiAgICAgICAgICAgIGRvbmUgPSB0cnVlXG4gICAgICAgICAgICBjb25zdCBzdG9wID0gdW5zdWJzY3JpYmVcbiAgICAgICAgICAgIHVuc3Vic2NyaWJlID0gdW5kZWZpbmVkXG4gICAgICAgICAgICBzdG9wPy4oKVxuICAgICAgICAgICAgY29udHJvbGxlci5lcnJvcihlcnJvcilcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIHRocm93KGVycm9yKSB7XG4gICAgICAgICAgaWYgKCFkb25lKSB7XG4gICAgICAgICAgICBkb25lID0gdHJ1ZVxuICAgICAgICAgICAgdW5zdWJzY3JpYmUgPSB1bmRlZmluZWRcbiAgICAgICAgICAgIGNvbnRyb2xsZXIuZXJyb3IoZXJyb3IpXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICByZXR1cm4oKSB7XG4gICAgICAgICAgaWYgKCFkb25lKSB7XG4gICAgICAgICAgICBkb25lID0gdHJ1ZVxuICAgICAgICAgICAgdW5zdWJzY3JpYmUgPSB1bmRlZmluZWRcbiAgICAgICAgICAgIGNvbnRyb2xsZXIuY2xvc2UoKVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgIH0pXG4gICAgICBpZiAoZG9uZSkge1xuICAgICAgICBkaXNwb3NlKClcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHVuc3Vic2NyaWJlID0gZGlzcG9zZVxuICAgICAgfVxuICAgIH0sXG4gICAgY2FuY2VsKCkge1xuICAgICAgY29uc3QgZGlzcG9zZSA9IHVuc3Vic2NyaWJlXG4gICAgICB1bnN1YnNjcmliZSA9IHVuZGVmaW5lZFxuICAgICAgZGlzcG9zZT8uKClcbiAgICB9LFxuICB9KVxufVxuIl0sIm1hcHBpbmdzIjoiOztBQU1BLFNBQWdCLFNBQVMsT0FBbUI7Q0FDMUMsTUFBTSxTQUF3QixDQUFDO0NBQy9CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSyxPQUNyQyxPQUFPLEtBQ0wsT0FBTyxhQUFhLE1BQU0sTUFBTSxNQUFNLFNBQVMsR0FBRyxJQUFJLEtBQU0sQ0FBUSxDQUN0RTtDQUVGLE9BQU8sS0FBSyxPQUFPLEtBQUssRUFBRSxDQUFDO0FBQzdCO0FBRUEsU0FBZ0IsV0FBVyxPQUFlO0NBQ3hDLE1BQU0sU0FBUyxLQUFLLEtBQUs7Q0FDekIsTUFBTSxRQUFRLElBQUksV0FBVyxPQUFPLE1BQU07Q0FDMUMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxLQUNqQyxNQUFNLEtBQUssT0FBTyxXQUFXLENBQUM7Q0FFaEMsT0FBTztBQUNUO0FBRUEsTUFBTSw4QkFBOEIsSUFBSSxZQUFZLFNBQVM7Q0FDM0QsT0FBTztDQUNQLFdBQVc7QUFDYixDQUFDOztBQUdELFNBQWdCLFdBQVcsT0FBbUI7Q0FDNUMsSUFBSTtFQUNGLE9BQU8sTUFBTSxZQUFZLE9BQU8sS0FBSztDQUN2QyxRQUFRO0VBQ04sT0FBTyxNQUFNLFNBQVMsS0FBSztDQUM3QjtBQUNGO0FBRUEsTUFBTSw4QkFBOEIsSUFBSSxZQUFZO0FBRXBELFNBQWdCLFdBQVcsT0FBZTtDQUN4QyxNQUFNLE9BQU8sTUFBTSxNQUFNLENBQUM7Q0FDMUIsT0FBTyxNQUFNLE9BQU8sTUFBTSxZQUFZLE9BQU8sSUFBSSxJQUFJLFdBQVcsSUFBSTtBQUN0RTs7Ozs7OztBQVFBLFNBQWdCLGtCQUNkLFVBQ0EsUUFDQSxRQUNBO0NBQ0EsUUFBUSxlQUFlO0NBRXZCLE1BQU0sU0FBUyxhQUFpQztDQUNoRCxNQUFNLFNBQVMsU0FBUyxVQUFVO0NBQ2xDLElBQUksU0FBUztDQUViLE1BQU0sZ0JBQWdCO0VBQ3BCLFNBQVM7RUFDVCxRQUFRLG9CQUFvQixTQUFTLEtBQUs7RUFDMUMsT0FBTyxZQUFZO0NBQ3JCO0NBQ0EsTUFBTSxRQUFRLFdBQXFCO0VBQ2pDLElBQUksQ0FBQyxRQUNILE9BQU87RUFFVCxPQUFZLE9BQU8sTUFBTSxFQUFFLFlBQVksQ0FBQyxDQUFDO0VBQ3pDLFFBQVE7RUFDUixPQUFPO0NBQ1Q7Q0FDQSxNQUFNLGNBQWM7RUFDbEIsSUFBSSxLQUFLLE9BQVEsTUFBTSxHQUNyQixPQUFPLE1BQU0sT0FBUSxNQUFNO0NBRS9CO0NBRUEsUUFBUSxpQkFBaUIsU0FBUyxLQUFLO0NBQ3RDLENBQUMsWUFBWTtFQUNaLElBQUk7R0FDRixPQUFPLFFBQVE7SUFDYixNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sT0FBTyxLQUFLO0lBQzFDLElBQUksQ0FBQyxRQUNIO0lBRUYsSUFBSSxNQUFNO0tBQ1IsUUFBUTtLQUNSLE9BQU8sT0FBTyxLQUFBLENBQVM7S0FDdkI7SUFDRjtJQUNBLE9BQU8sS0FBSyxPQUFPLEtBQUssQ0FBQztHQUMzQjtFQUNGLFNBQVMsT0FBTztHQUNkLElBQUksS0FBSyxLQUFLLEdBQ1osT0FBTyxNQUFNLEtBQUs7RUFFdEI7Q0FDRixHQUFHO0NBRUgsT0FBTyxDQUFDLFFBQVEsSUFBSTtBQUN0Qjs7QUFHQSxTQUFnQixrQkFDZCxRQUNBLFFBQ0E7Q0FHQSxJQUFJO0NBQ0osSUFBSSxPQUFPO0NBRVgsT0FBTyxJQUFJLGVBQTJCO0VBQ3BDLE1BQU0sWUFBWTtHQUNoQixNQUFNLFVBQVUsT0FBTyxHQUFHO0lBQ3hCLEtBQUssT0FBTztLQUNWLElBQUksTUFDRjtLQUVGLElBQUk7TUFDRixXQUFXLFFBQVEsT0FBTyxLQUFNLENBQUM7S0FDbkMsU0FBUyxPQUFPO01BRWQsT0FBTztNQUNQLE1BQU0sT0FBTztNQUNiLGNBQWMsS0FBQTtNQUNkLE9BQU87TUFDUCxXQUFXLE1BQU0sS0FBSztLQUN4QjtJQUNGO0lBQ0EsTUFBTSxPQUFPO0tBQ1gsSUFBSSxDQUFDLE1BQU07TUFDVCxPQUFPO01BQ1AsY0FBYyxLQUFBO01BQ2QsV0FBVyxNQUFNLEtBQUs7S0FDeEI7SUFDRjtJQUNBLFNBQVM7S0FDUCxJQUFJLENBQUMsTUFBTTtNQUNULE9BQU87TUFDUCxjQUFjLEtBQUE7TUFDZCxXQUFXLE1BQU07S0FDbkI7SUFDRjtHQUNGLENBQUM7R0FDRCxJQUFJLE1BQ0YsUUFBUTtRQUVSLGNBQWM7RUFFbEI7RUFDQSxTQUFTO0dBQ1AsTUFBTSxVQUFVO0dBQ2hCLGNBQWMsS0FBQTtHQUNkLFVBQVU7RUFDWjtDQUNGLENBQUM7QUFDSCIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=