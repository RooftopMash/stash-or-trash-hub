"use client";
import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=a8030269";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=a8030269";
import { a as composeRefs } from "/node_modules/.vite/deps/dist-DIAF6ZLP.js?v=a8030269";
import { t as Primitive } from "/node_modules/.vite/deps/dist-uZEDRbDH.js?v=a8030269";
import { t as useId } from "/node_modules/.vite/deps/dist-CjPmzKtU.js?v=a8030269";
import { Content as DialogContent, Dialog, DialogOverlay, DialogPortal } from "/node_modules/.vite/deps/@radix-ui_react-dialog.js?v=a8030269";
//#region node_modules/cmdk/dist/chunk-NZJY6EH4.mjs
var U = 1;
var Y$1 = .9;
var H = .8;
var J = .17;
var p = .1;
var u = .999;
var $ = .9999;
var k$1 = .99;
var m = /[\\\/_+.#"@\[\(\{&]/;
var B$1 = /[\\\/_+.#"@\[\(\{&]/g;
var K$1 = /[\s-]/;
var X = /[\s-]/g;
function G(_, C, h, P, A, f, O) {
	if (f === C.length) return A === _.length ? U : k$1;
	var T = `${A},${f}`;
	if (O[T] !== void 0) return O[T];
	for (var L = P.charAt(f), c = h.indexOf(L, A), S = 0, E, N, R, M; c >= 0;) E = G(_, C, h, P, c + 1, f + 1, O), E > S && (c === A ? E *= U : m.test(_.charAt(c - 1)) ? (E *= H, R = _.slice(A, c - 1).match(B$1), R && A > 0 && (E *= Math.pow(u, R.length))) : K$1.test(_.charAt(c - 1)) ? (E *= Y$1, M = _.slice(A, c - 1).match(X), M && A > 0 && (E *= Math.pow(u, M.length))) : (E *= J, A > 0 && (E *= Math.pow(u, c - A))), _.charAt(c) !== C.charAt(f) && (E *= $)), (E < p && h.charAt(c - 1) === P.charAt(f + 1) || P.charAt(f + 1) === P.charAt(f) && h.charAt(c - 1) !== P.charAt(f)) && (N = G(_, C, h, P, c + 1, f + 2, O), N * p > E && (E = N * p)), E > S && (S = E), c = h.indexOf(L, c + 1);
	return O[T] = S, S;
}
function D(_) {
	return _.toLowerCase().replace(X, " ");
}
function W(_, C, h) {
	return _ = h && h.length > 0 ? `${_ + " " + h.join(" ")}` : _, G(_, C, D(_), D(C), 0, 0, {});
}
//#endregion
//#region node_modules/cmdk/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var N = "[cmdk-group=\"\"]";
var Y = "[cmdk-group-items=\"\"]";
var be = "[cmdk-group-heading=\"\"]";
var le = "[cmdk-item=\"\"]";
var ce = `${le}:not([aria-disabled="true"])`;
var Z = "cmdk-item-select";
var T = "data-value";
var Re = (r, o, n) => W(r, o, n);
var ue = import_react.createContext(void 0);
var K = () => import_react.useContext(ue);
var de = import_react.createContext(void 0);
var ee = () => import_react.useContext(de);
var fe = import_react.createContext(void 0);
var me = import_react.forwardRef((r, o) => {
	let n = L(() => {
		var e, a;
		return {
			search: "",
			value: (a = (e = r.value) != null ? e : r.defaultValue) != null ? a : "",
			selectedItemId: void 0,
			filtered: {
				count: 0,
				items: /* @__PURE__ */ new Map(),
				groups: /* @__PURE__ */ new Set()
			}
		};
	}), u = L(() => /* @__PURE__ */ new Set()), c = L(() => /* @__PURE__ */ new Map()), d = L(() => /* @__PURE__ */ new Map()), f = L(() => /* @__PURE__ */ new Set()), p = pe(r), { label: b, children: m, value: R, onValueChange: x, filter: C, shouldFilter: S, loop: A, disablePointerSelection: ge = !1, vimBindings: j = !0, ...O } = r, $ = useId(), q = useId(), _ = useId(), I = import_react.useRef(null), v = ke();
	k(() => {
		if (R !== void 0) {
			let e = R.trim();
			n.current.value = e, E.emit();
		}
	}, [R]), k(() => {
		v(6, ne);
	}, []);
	let E = import_react.useMemo(() => ({
		subscribe: (e) => (f.current.add(e), () => f.current.delete(e)),
		snapshot: () => n.current,
		setState: (e, a, s) => {
			var i, l, g, y;
			if (!Object.is(n.current[e], a)) {
				if (n.current[e] = a, e === "search") J(), z(), v(1, W);
				else if (e === "value") {
					if (document.activeElement.hasAttribute("cmdk-input") || document.activeElement.hasAttribute("cmdk-root")) {
						let h = document.getElementById(_);
						h ? h.focus() : (i = document.getElementById($)) == null || i.focus();
					}
					if (v(7, () => {
						var h;
						n.current.selectedItemId = (h = M()) == null ? void 0 : h.id, E.emit();
					}), s || v(5, ne), ((l = p.current) == null ? void 0 : l.value) !== void 0) {
						let h = a != null ? a : "";
						(y = (g = p.current).onValueChange) == null || y.call(g, h);
						return;
					}
				}
				E.emit();
			}
		},
		emit: () => {
			f.current.forEach((e) => e());
		}
	}), []), U = import_react.useMemo(() => ({
		value: (e, a, s) => {
			var i;
			a !== ((i = d.current.get(e)) == null ? void 0 : i.value) && (d.current.set(e, {
				value: a,
				keywords: s
			}), n.current.filtered.items.set(e, te(a, s)), v(2, () => {
				z(), E.emit();
			}));
		},
		item: (e, a) => (u.current.add(e), a && (c.current.has(a) ? c.current.get(a).add(e) : c.current.set(a, /* @__PURE__ */ new Set([e]))), v(3, () => {
			J(), z(), n.current.value || W(), E.emit();
		}), () => {
			d.current.delete(e), u.current.delete(e), n.current.filtered.items.delete(e);
			let s = M();
			v(4, () => {
				J(), (s == null ? void 0 : s.getAttribute("id")) === e && W(), E.emit();
			});
		}),
		group: (e) => (c.current.has(e) || c.current.set(e, /* @__PURE__ */ new Set()), () => {
			d.current.delete(e), c.current.delete(e);
		}),
		filter: () => p.current.shouldFilter,
		label: b || r["aria-label"],
		getDisablePointerSelection: () => p.current.disablePointerSelection,
		listId: $,
		inputId: _,
		labelId: q,
		listInnerRef: I
	}), []);
	function te(e, a) {
		var i, l;
		let s = (l = (i = p.current) == null ? void 0 : i.filter) != null ? l : Re;
		return e ? s(e, n.current.search, a) : 0;
	}
	function z() {
		if (!n.current.search || p.current.shouldFilter === !1) return;
		let e = n.current.filtered.items, a = [];
		n.current.filtered.groups.forEach((i) => {
			let l = c.current.get(i), g = 0;
			l.forEach((y) => {
				let h = e.get(y);
				g = Math.max(h, g);
			}), a.push([i, g]);
		});
		let s = I.current;
		V().sort((i, l) => {
			var h, F;
			let g = i.getAttribute("id"), y = l.getAttribute("id");
			return ((h = e.get(y)) != null ? h : 0) - ((F = e.get(g)) != null ? F : 0);
		}).forEach((i) => {
			let l = i.closest(Y);
			l ? l.appendChild(i.parentElement === l ? i : i.closest(`${Y} > *`)) : s.appendChild(i.parentElement === s ? i : i.closest(`${Y} > *`));
		}), a.sort((i, l) => l[1] - i[1]).forEach((i) => {
			var g;
			let l = (g = I.current) == null ? void 0 : g.querySelector(`${N}[${T}="${encodeURIComponent(i[0])}"]`);
			l?.parentElement.appendChild(l);
		});
	}
	function W() {
		let e = V().find((s) => s.getAttribute("aria-disabled") !== "true"), a = e == null ? void 0 : e.getAttribute(T);
		E.setState("value", a || void 0);
	}
	function J() {
		var a, s, i, l;
		if (!n.current.search || p.current.shouldFilter === !1) {
			n.current.filtered.count = u.current.size;
			return;
		}
		n.current.filtered.groups = /* @__PURE__ */ new Set();
		let e = 0;
		for (let g of u.current) {
			let F = te((s = (a = d.current.get(g)) == null ? void 0 : a.value) != null ? s : "", (l = (i = d.current.get(g)) == null ? void 0 : i.keywords) != null ? l : []);
			n.current.filtered.items.set(g, F), F > 0 && e++;
		}
		for (let [g, y] of c.current) for (let h of y) if (n.current.filtered.items.get(h) > 0) {
			n.current.filtered.groups.add(g);
			break;
		}
		n.current.filtered.count = e;
	}
	function ne() {
		var a, s, i;
		let e = M();
		e && (((a = e.parentElement) == null ? void 0 : a.firstChild) === e && ((i = (s = e.closest(N)) == null ? void 0 : s.querySelector(be)) == null || i.scrollIntoView({ block: "nearest" })), e.scrollIntoView({ block: "nearest" }));
	}
	function M() {
		var e;
		return (e = I.current) == null ? void 0 : e.querySelector(`${le}[aria-selected="true"]`);
	}
	function V() {
		var e;
		return Array.from(((e = I.current) == null ? void 0 : e.querySelectorAll(ce)) || []);
	}
	function X(e) {
		let s = V()[e];
		s && E.setState("value", s.getAttribute(T));
	}
	function Q(e) {
		var g;
		let a = M(), s = V(), i = s.findIndex((y) => y === a), l = s[i + e];
		(g = p.current) != null && g.loop && (l = i + e < 0 ? s[s.length - 1] : i + e === s.length ? s[0] : s[i + e]), l && E.setState("value", l.getAttribute(T));
	}
	function re(e) {
		let a = M(), s = a == null ? void 0 : a.closest(N), i;
		for (; s && !i;) s = e > 0 ? we(s, N) : De(s, N), i = s == null ? void 0 : s.querySelector(ce);
		i ? E.setState("value", i.getAttribute(T)) : Q(e);
	}
	let oe = () => X(V().length - 1), ie = (e) => {
		e.preventDefault(), e.metaKey ? oe() : e.altKey ? re(1) : Q(1);
	}, se = (e) => {
		e.preventDefault(), e.metaKey ? X(0) : e.altKey ? re(-1) : Q(-1);
	};
	return import_react.createElement(Primitive.div, {
		ref: o,
		tabIndex: -1,
		...O,
		"cmdk-root": "",
		onKeyDown: (e) => {
			var s;
			(s = O.onKeyDown) == null || s.call(O, e);
			let a = e.nativeEvent.isComposing || e.keyCode === 229;
			if (!(e.defaultPrevented || a)) switch (e.key) {
				case "n":
				case "j":
					j && e.ctrlKey && ie(e);
					break;
				case "ArrowDown":
					ie(e);
					break;
				case "p":
				case "k":
					j && e.ctrlKey && se(e);
					break;
				case "ArrowUp":
					se(e);
					break;
				case "Home":
					e.preventDefault(), X(0);
					break;
				case "End":
					e.preventDefault(), oe();
					break;
				case "Enter": {
					e.preventDefault();
					let i = M();
					if (i) {
						let l = new Event(Z);
						i.dispatchEvent(l);
					}
				}
			}
		}
	}, import_react.createElement("label", {
		"cmdk-label": "",
		htmlFor: U.inputId,
		id: U.labelId,
		style: Te
	}, b), B(r, (e) => import_react.createElement(de.Provider, { value: E }, import_react.createElement(ue.Provider, { value: U }, e))));
});
var he = import_react.forwardRef((r, o) => {
	var _, I;
	let n = useId(), u = import_react.useRef(null), c = import_react.useContext(fe), d = K(), f = pe(r), p = (I = (_ = f.current) == null ? void 0 : _.forceMount) != null ? I : c == null ? void 0 : c.forceMount;
	k(() => {
		if (!p) return d.item(n, c == null ? void 0 : c.id);
	}, [p]);
	let b = ve(n, u, [
		r.value,
		r.children,
		u
	], r.keywords), m = ee(), R = P((v) => v.value && v.value === b.current), x = P((v) => p || d.filter() === !1 ? !0 : v.search ? v.filtered.items.get(n) > 0 : !0);
	import_react.useEffect(() => {
		let v = u.current;
		if (!(!v || r.disabled)) return v.addEventListener(Z, C), () => v.removeEventListener(Z, C);
	}, [
		x,
		r.onSelect,
		r.disabled
	]);
	function C() {
		var v, E;
		S(), (E = (v = f.current).onSelect) == null || E.call(v, b.current);
	}
	function S() {
		m.setState("value", b.current, !0);
	}
	if (!x) return null;
	let { disabled: A, value: ge, onSelect: j, forceMount: O, keywords: $, ...q } = r;
	return import_react.createElement(Primitive.div, {
		ref: composeRefs(u, o),
		...q,
		id: n,
		"cmdk-item": "",
		role: "option",
		"aria-disabled": !!A,
		"aria-selected": !!R,
		"data-disabled": !!A,
		"data-selected": !!R,
		onPointerMove: A || d.getDisablePointerSelection() ? void 0 : S,
		onClick: A ? void 0 : C
	}, r.children);
});
var Ee = import_react.forwardRef((r, o) => {
	let { heading: n, children: u, forceMount: c, ...d } = r, f = useId(), p = import_react.useRef(null), b = import_react.useRef(null), m = useId(), R = K(), x = P((S) => c || R.filter() === !1 ? !0 : S.search ? S.filtered.groups.has(f) : !0);
	k(() => R.group(f), []), ve(f, p, [
		r.value,
		r.heading,
		b
	]);
	let C = import_react.useMemo(() => ({
		id: f,
		forceMount: c
	}), [c]);
	return import_react.createElement(Primitive.div, {
		ref: composeRefs(p, o),
		...d,
		"cmdk-group": "",
		role: "presentation",
		hidden: x ? void 0 : !0
	}, n && import_react.createElement("div", {
		ref: b,
		"cmdk-group-heading": "",
		"aria-hidden": !0,
		id: m
	}, n), B(r, (S) => import_react.createElement("div", {
		"cmdk-group-items": "",
		role: "group",
		"aria-labelledby": n ? m : void 0
	}, import_react.createElement(fe.Provider, { value: C }, S))));
});
var ye = import_react.forwardRef((r, o) => {
	let { alwaysRender: n, ...u } = r, c = import_react.useRef(null), d = P((f) => !f.search);
	return !n && !d ? null : import_react.createElement(Primitive.div, {
		ref: composeRefs(c, o),
		...u,
		"cmdk-separator": "",
		role: "separator"
	});
});
var Se = import_react.forwardRef((r, o) => {
	let { onValueChange: n, ...u } = r, c = r.value != null, d = ee(), f = P((m) => m.search), p = P((m) => m.selectedItemId), b = K();
	return import_react.useEffect(() => {
		r.value != null && d.setState("search", r.value);
	}, [r.value]), import_react.createElement(Primitive.input, {
		ref: o,
		...u,
		"cmdk-input": "",
		autoComplete: "off",
		autoCorrect: "off",
		spellCheck: !1,
		"aria-autocomplete": "list",
		role: "combobox",
		"aria-expanded": !0,
		"aria-controls": b.listId,
		"aria-labelledby": b.labelId,
		"aria-activedescendant": p,
		id: b.inputId,
		type: "text",
		value: c ? r.value : f,
		onChange: (m) => {
			c || d.setState("search", m.target.value), n?.(m.target.value);
		}
	});
});
var Ce = import_react.forwardRef((r, o) => {
	let { children: n, label: u = "Suggestions", ...c } = r, d = import_react.useRef(null), f = import_react.useRef(null), p = P((m) => m.selectedItemId), b = K();
	return import_react.useEffect(() => {
		if (f.current && d.current) {
			let m = f.current, R = d.current, x, C = new ResizeObserver(() => {
				x = requestAnimationFrame(() => {
					let S = m.offsetHeight;
					R.style.setProperty("--cmdk-list-height", S.toFixed(1) + "px");
				});
			});
			return C.observe(m), () => {
				cancelAnimationFrame(x), C.unobserve(m);
			};
		}
	}, []), import_react.createElement(Primitive.div, {
		ref: composeRefs(d, o),
		...c,
		"cmdk-list": "",
		role: "listbox",
		tabIndex: -1,
		"aria-activedescendant": p,
		"aria-label": u,
		id: b.listId
	}, B(r, (m) => import_react.createElement("div", {
		ref: composeRefs(f, b.listInnerRef),
		"cmdk-list-sizer": ""
	}, m)));
});
var xe = import_react.forwardRef((r, o) => {
	let { open: n, onOpenChange: u, overlayClassName: c, contentClassName: d, container: f, ...p } = r;
	return import_react.createElement(Dialog, {
		open: n,
		onOpenChange: u
	}, import_react.createElement(DialogPortal, { container: f }, import_react.createElement(DialogOverlay, {
		"cmdk-overlay": "",
		className: c
	}), import_react.createElement(DialogContent, {
		"aria-label": r.label,
		"cmdk-dialog": "",
		className: d
	}, import_react.createElement(me, {
		ref: o,
		...p
	}))));
});
var Ie = import_react.forwardRef((r, o) => P((u) => u.filtered.count === 0) ? import_react.createElement(Primitive.div, {
	ref: o,
	...r,
	"cmdk-empty": "",
	role: "presentation"
}) : null);
var Pe = import_react.forwardRef((r, o) => {
	let { progress: n, children: u, label: c = "Loading...", ...d } = r;
	return import_react.createElement(Primitive.div, {
		ref: o,
		...d,
		"cmdk-loading": "",
		role: "progressbar",
		"aria-valuenow": n,
		"aria-valuemin": 0,
		"aria-valuemax": 100,
		"aria-label": c
	}, B(r, (f) => import_react.createElement("div", { "aria-hidden": !0 }, f)));
});
var _e = Object.assign(me, {
	List: Ce,
	Item: he,
	Input: Se,
	Group: Ee,
	Separator: ye,
	Dialog: xe,
	Empty: Ie,
	Loading: Pe
});
function we(r, o) {
	let n = r.nextElementSibling;
	for (; n;) {
		if (n.matches(o)) return n;
		n = n.nextElementSibling;
	}
}
function De(r, o) {
	let n = r.previousElementSibling;
	for (; n;) {
		if (n.matches(o)) return n;
		n = n.previousElementSibling;
	}
}
function pe(r) {
	let o = import_react.useRef(r);
	return k(() => {
		o.current = r;
	}), o;
}
var k = typeof window == "undefined" ? import_react.useEffect : import_react.useLayoutEffect;
function L(r) {
	let o = import_react.useRef();
	return o.current === void 0 && (o.current = r()), o;
}
function P(r) {
	let o = ee(), n = () => r(o.snapshot());
	return import_react.useSyncExternalStore(o.subscribe, n, n);
}
function ve(r, o, n, u = []) {
	let c = import_react.useRef(), d = K();
	return k(() => {
		var b;
		let f = (() => {
			var m;
			for (let R of n) {
				if (typeof R == "string") return R.trim();
				if (typeof R == "object" && "current" in R) return R.current ? (m = R.current.textContent) == null ? void 0 : m.trim() : c.current;
			}
		})(), p = u.map((m) => m.trim());
		d.value(r, f, p), (b = o.current) == null || b.setAttribute(T, f), c.current = f;
	}), c;
}
var ke = () => {
	let [r, o] = import_react.useState(), n = L(() => /* @__PURE__ */ new Map());
	return k(() => {
		n.current.forEach((u) => u()), n.current = /* @__PURE__ */ new Map();
	}, [r]), (u, c) => {
		n.current.set(u, c), o({});
	};
};
function Me(r) {
	let o = r.type;
	return typeof o == "function" ? o(r.props) : "render" in o ? o.render(r.props) : r;
}
function B({ asChild: r, children: o }, n) {
	return r && import_react.isValidElement(o) ? import_react.cloneElement(Me(o), { ref: o.ref }, n(o.props.children)) : n(o);
}
var Te = {
	position: "absolute",
	width: "1px",
	height: "1px",
	padding: "0",
	margin: "-1px",
	overflow: "hidden",
	clip: "rect(0, 0, 0, 0)",
	whiteSpace: "nowrap",
	borderWidth: "0"
};
//#endregion
export { _e as Command, xe as CommandDialog, Ie as CommandEmpty, Ee as CommandGroup, Se as CommandInput, he as CommandItem, Ce as CommandList, Pe as CommandLoading, me as CommandRoot, ye as CommandSeparator, Re as defaultFilter, P as useCommandState };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY21kay5qcyIsIm5hbWVzIjpbIlkiLCJrIiwiQiIsIksiLCJhZSIsIkgiLCJEIiwiRyIsIncuUm9vdCIsIncuUG9ydGFsIiwidy5PdmVybGF5Iiwidy5Db250ZW50Il0sInNvdXJjZXMiOlsiLi4vLi4vY21kay9kaXN0L2NodW5rLU5aSlk2RUg0Lm1qcyIsIi4uLy4uL2NtZGsvZGlzdC9pbmRleC5tanMiXSwic291cmNlc0NvbnRlbnQiOlsidmFyIFU9MSxZPS45LEg9LjgsSj0uMTcscD0uMSx1PS45OTksJD0uOTk5OTt2YXIgaz0uOTksbT0vW1xcXFxcXC9fKy4jXCJAXFxbXFwoXFx7Jl0vLEI9L1tcXFxcXFwvXysuI1wiQFxcW1xcKFxceyZdL2csSz0vW1xccy1dLyxYPS9bXFxzLV0vZztmdW5jdGlvbiBHKF8sQyxoLFAsQSxmLE8pe2lmKGY9PT1DLmxlbmd0aClyZXR1cm4gQT09PV8ubGVuZ3RoP1U6azt2YXIgVD1gJHtBfSwke2Z9YDtpZihPW1RdIT09dm9pZCAwKXJldHVybiBPW1RdO2Zvcih2YXIgTD1QLmNoYXJBdChmKSxjPWguaW5kZXhPZihMLEEpLFM9MCxFLE4sUixNO2M+PTA7KUU9RyhfLEMsaCxQLGMrMSxmKzEsTyksRT5TJiYoYz09PUE/RSo9VTptLnRlc3QoXy5jaGFyQXQoYy0xKSk/KEUqPUgsUj1fLnNsaWNlKEEsYy0xKS5tYXRjaChCKSxSJiZBPjAmJihFKj1NYXRoLnBvdyh1LFIubGVuZ3RoKSkpOksudGVzdChfLmNoYXJBdChjLTEpKT8oRSo9WSxNPV8uc2xpY2UoQSxjLTEpLm1hdGNoKFgpLE0mJkE+MCYmKEUqPU1hdGgucG93KHUsTS5sZW5ndGgpKSk6KEUqPUosQT4wJiYoRSo9TWF0aC5wb3codSxjLUEpKSksXy5jaGFyQXQoYykhPT1DLmNoYXJBdChmKSYmKEUqPSQpKSwoRTxwJiZoLmNoYXJBdChjLTEpPT09UC5jaGFyQXQoZisxKXx8UC5jaGFyQXQoZisxKT09PVAuY2hhckF0KGYpJiZoLmNoYXJBdChjLTEpIT09UC5jaGFyQXQoZikpJiYoTj1HKF8sQyxoLFAsYysxLGYrMixPKSxOKnA+RSYmKEU9TipwKSksRT5TJiYoUz1FKSxjPWguaW5kZXhPZihMLGMrMSk7cmV0dXJuIE9bVF09UyxTfWZ1bmN0aW9uIEQoXyl7cmV0dXJuIF8udG9Mb3dlckNhc2UoKS5yZXBsYWNlKFgsXCIgXCIpfWZ1bmN0aW9uIFcoXyxDLGgpe3JldHVybiBfPWgmJmgubGVuZ3RoPjA/YCR7XytcIiBcIitoLmpvaW4oXCIgXCIpfWA6XyxHKF8sQyxEKF8pLEQoQyksMCwwLHt9KX1leHBvcnR7VyBhcyBhfTtcbiIsIlwidXNlIGNsaWVudFwiO2ltcG9ydHthIGFzIGFlfWZyb21cIi4vY2h1bmstTlpKWTZFSDQubWpzXCI7aW1wb3J0KmFzIHcgZnJvbVwiQHJhZGl4LXVpL3JlYWN0LWRpYWxvZ1wiO2ltcG9ydCphcyB0IGZyb21cInJlYWN0XCI7aW1wb3J0e1ByaW1pdGl2ZSBhcyBEfWZyb21cIkByYWRpeC11aS9yZWFjdC1wcmltaXRpdmVcIjtpbXBvcnR7dXNlSWQgYXMgSH1mcm9tXCJAcmFkaXgtdWkvcmVhY3QtaWRcIjtpbXBvcnR7Y29tcG9zZVJlZnMgYXMgR31mcm9tXCJAcmFkaXgtdWkvcmVhY3QtY29tcG9zZS1yZWZzXCI7dmFyIE49J1tjbWRrLWdyb3VwPVwiXCJdJyxZPSdbY21kay1ncm91cC1pdGVtcz1cIlwiXScsYmU9J1tjbWRrLWdyb3VwLWhlYWRpbmc9XCJcIl0nLGxlPSdbY21kay1pdGVtPVwiXCJdJyxjZT1gJHtsZX06bm90KFthcmlhLWRpc2FibGVkPVwidHJ1ZVwiXSlgLFo9XCJjbWRrLWl0ZW0tc2VsZWN0XCIsVD1cImRhdGEtdmFsdWVcIixSZT0ocixvLG4pPT5hZShyLG8sbiksdWU9dC5jcmVhdGVDb250ZXh0KHZvaWQgMCksSz0oKT0+dC51c2VDb250ZXh0KHVlKSxkZT10LmNyZWF0ZUNvbnRleHQodm9pZCAwKSxlZT0oKT0+dC51c2VDb250ZXh0KGRlKSxmZT10LmNyZWF0ZUNvbnRleHQodm9pZCAwKSxtZT10LmZvcndhcmRSZWYoKHIsbyk9PntsZXQgbj1MKCgpPT57dmFyIGUsYTtyZXR1cm57c2VhcmNoOlwiXCIsdmFsdWU6KGE9KGU9ci52YWx1ZSkhPW51bGw/ZTpyLmRlZmF1bHRWYWx1ZSkhPW51bGw/YTpcIlwiLHNlbGVjdGVkSXRlbUlkOnZvaWQgMCxmaWx0ZXJlZDp7Y291bnQ6MCxpdGVtczpuZXcgTWFwLGdyb3VwczpuZXcgU2V0fX19KSx1PUwoKCk9Pm5ldyBTZXQpLGM9TCgoKT0+bmV3IE1hcCksZD1MKCgpPT5uZXcgTWFwKSxmPUwoKCk9Pm5ldyBTZXQpLHA9cGUocikse2xhYmVsOmIsY2hpbGRyZW46bSx2YWx1ZTpSLG9uVmFsdWVDaGFuZ2U6eCxmaWx0ZXI6QyxzaG91bGRGaWx0ZXI6Uyxsb29wOkEsZGlzYWJsZVBvaW50ZXJTZWxlY3Rpb246Z2U9ITEsdmltQmluZGluZ3M6aj0hMCwuLi5PfT1yLCQ9SCgpLHE9SCgpLF89SCgpLEk9dC51c2VSZWYobnVsbCksdj1rZSgpO2soKCk9PntpZihSIT09dm9pZCAwKXtsZXQgZT1SLnRyaW0oKTtuLmN1cnJlbnQudmFsdWU9ZSxFLmVtaXQoKX19LFtSXSksaygoKT0+e3YoNixuZSl9LFtdKTtsZXQgRT10LnVzZU1lbW8oKCk9Pih7c3Vic2NyaWJlOmU9PihmLmN1cnJlbnQuYWRkKGUpLCgpPT5mLmN1cnJlbnQuZGVsZXRlKGUpKSxzbmFwc2hvdDooKT0+bi5jdXJyZW50LHNldFN0YXRlOihlLGEscyk9Pnt2YXIgaSxsLGcseTtpZighT2JqZWN0LmlzKG4uY3VycmVudFtlXSxhKSl7aWYobi5jdXJyZW50W2VdPWEsZT09PVwic2VhcmNoXCIpSigpLHooKSx2KDEsVyk7ZWxzZSBpZihlPT09XCJ2YWx1ZVwiKXtpZihkb2N1bWVudC5hY3RpdmVFbGVtZW50Lmhhc0F0dHJpYnV0ZShcImNtZGstaW5wdXRcIil8fGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQuaGFzQXR0cmlidXRlKFwiY21kay1yb290XCIpKXtsZXQgaD1kb2N1bWVudC5nZXRFbGVtZW50QnlJZChfKTtoP2guZm9jdXMoKTooaT1kb2N1bWVudC5nZXRFbGVtZW50QnlJZCgkKSk9PW51bGx8fGkuZm9jdXMoKX1pZih2KDcsKCk9Pnt2YXIgaDtuLmN1cnJlbnQuc2VsZWN0ZWRJdGVtSWQ9KGg9TSgpKT09bnVsbD92b2lkIDA6aC5pZCxFLmVtaXQoKX0pLHN8fHYoNSxuZSksKChsPXAuY3VycmVudCk9PW51bGw/dm9pZCAwOmwudmFsdWUpIT09dm9pZCAwKXtsZXQgaD1hIT1udWxsP2E6XCJcIjsoeT0oZz1wLmN1cnJlbnQpLm9uVmFsdWVDaGFuZ2UpPT1udWxsfHx5LmNhbGwoZyxoKTtyZXR1cm59fUUuZW1pdCgpfX0sZW1pdDooKT0+e2YuY3VycmVudC5mb3JFYWNoKGU9PmUoKSl9fSksW10pLFU9dC51c2VNZW1vKCgpPT4oe3ZhbHVlOihlLGEscyk9Pnt2YXIgaTthIT09KChpPWQuY3VycmVudC5nZXQoZSkpPT1udWxsP3ZvaWQgMDppLnZhbHVlKSYmKGQuY3VycmVudC5zZXQoZSx7dmFsdWU6YSxrZXl3b3JkczpzfSksbi5jdXJyZW50LmZpbHRlcmVkLml0ZW1zLnNldChlLHRlKGEscykpLHYoMiwoKT0+e3ooKSxFLmVtaXQoKX0pKX0saXRlbTooZSxhKT0+KHUuY3VycmVudC5hZGQoZSksYSYmKGMuY3VycmVudC5oYXMoYSk/Yy5jdXJyZW50LmdldChhKS5hZGQoZSk6Yy5jdXJyZW50LnNldChhLG5ldyBTZXQoW2VdKSkpLHYoMywoKT0+e0ooKSx6KCksbi5jdXJyZW50LnZhbHVlfHxXKCksRS5lbWl0KCl9KSwoKT0+e2QuY3VycmVudC5kZWxldGUoZSksdS5jdXJyZW50LmRlbGV0ZShlKSxuLmN1cnJlbnQuZmlsdGVyZWQuaXRlbXMuZGVsZXRlKGUpO2xldCBzPU0oKTt2KDQsKCk9PntKKCksKHM9PW51bGw/dm9pZCAwOnMuZ2V0QXR0cmlidXRlKFwiaWRcIikpPT09ZSYmVygpLEUuZW1pdCgpfSl9KSxncm91cDplPT4oYy5jdXJyZW50LmhhcyhlKXx8Yy5jdXJyZW50LnNldChlLG5ldyBTZXQpLCgpPT57ZC5jdXJyZW50LmRlbGV0ZShlKSxjLmN1cnJlbnQuZGVsZXRlKGUpfSksZmlsdGVyOigpPT5wLmN1cnJlbnQuc2hvdWxkRmlsdGVyLGxhYmVsOmJ8fHJbXCJhcmlhLWxhYmVsXCJdLGdldERpc2FibGVQb2ludGVyU2VsZWN0aW9uOigpPT5wLmN1cnJlbnQuZGlzYWJsZVBvaW50ZXJTZWxlY3Rpb24sbGlzdElkOiQsaW5wdXRJZDpfLGxhYmVsSWQ6cSxsaXN0SW5uZXJSZWY6SX0pLFtdKTtmdW5jdGlvbiB0ZShlLGEpe3ZhciBpLGw7bGV0IHM9KGw9KGk9cC5jdXJyZW50KT09bnVsbD92b2lkIDA6aS5maWx0ZXIpIT1udWxsP2w6UmU7cmV0dXJuIGU/cyhlLG4uY3VycmVudC5zZWFyY2gsYSk6MH1mdW5jdGlvbiB6KCl7aWYoIW4uY3VycmVudC5zZWFyY2h8fHAuY3VycmVudC5zaG91bGRGaWx0ZXI9PT0hMSlyZXR1cm47bGV0IGU9bi5jdXJyZW50LmZpbHRlcmVkLml0ZW1zLGE9W107bi5jdXJyZW50LmZpbHRlcmVkLmdyb3Vwcy5mb3JFYWNoKGk9PntsZXQgbD1jLmN1cnJlbnQuZ2V0KGkpLGc9MDtsLmZvckVhY2goeT0+e2xldCBoPWUuZ2V0KHkpO2c9TWF0aC5tYXgoaCxnKX0pLGEucHVzaChbaSxnXSl9KTtsZXQgcz1JLmN1cnJlbnQ7VigpLnNvcnQoKGksbCk9Pnt2YXIgaCxGO2xldCBnPWkuZ2V0QXR0cmlidXRlKFwiaWRcIikseT1sLmdldEF0dHJpYnV0ZShcImlkXCIpO3JldHVybigoaD1lLmdldCh5KSkhPW51bGw/aDowKS0oKEY9ZS5nZXQoZykpIT1udWxsP0Y6MCl9KS5mb3JFYWNoKGk9PntsZXQgbD1pLmNsb3Nlc3QoWSk7bD9sLmFwcGVuZENoaWxkKGkucGFyZW50RWxlbWVudD09PWw/aTppLmNsb3Nlc3QoYCR7WX0gPiAqYCkpOnMuYXBwZW5kQ2hpbGQoaS5wYXJlbnRFbGVtZW50PT09cz9pOmkuY2xvc2VzdChgJHtZfSA+ICpgKSl9KSxhLnNvcnQoKGksbCk9PmxbMV0taVsxXSkuZm9yRWFjaChpPT57dmFyIGc7bGV0IGw9KGc9SS5jdXJyZW50KT09bnVsbD92b2lkIDA6Zy5xdWVyeVNlbGVjdG9yKGAke059WyR7VH09XCIke2VuY29kZVVSSUNvbXBvbmVudChpWzBdKX1cIl1gKTtsPT1udWxsfHxsLnBhcmVudEVsZW1lbnQuYXBwZW5kQ2hpbGQobCl9KX1mdW5jdGlvbiBXKCl7bGV0IGU9VigpLmZpbmQocz0+cy5nZXRBdHRyaWJ1dGUoXCJhcmlhLWRpc2FibGVkXCIpIT09XCJ0cnVlXCIpLGE9ZT09bnVsbD92b2lkIDA6ZS5nZXRBdHRyaWJ1dGUoVCk7RS5zZXRTdGF0ZShcInZhbHVlXCIsYXx8dm9pZCAwKX1mdW5jdGlvbiBKKCl7dmFyIGEscyxpLGw7aWYoIW4uY3VycmVudC5zZWFyY2h8fHAuY3VycmVudC5zaG91bGRGaWx0ZXI9PT0hMSl7bi5jdXJyZW50LmZpbHRlcmVkLmNvdW50PXUuY3VycmVudC5zaXplO3JldHVybn1uLmN1cnJlbnQuZmlsdGVyZWQuZ3JvdXBzPW5ldyBTZXQ7bGV0IGU9MDtmb3IobGV0IGcgb2YgdS5jdXJyZW50KXtsZXQgeT0ocz0oYT1kLmN1cnJlbnQuZ2V0KGcpKT09bnVsbD92b2lkIDA6YS52YWx1ZSkhPW51bGw/czpcIlwiLGg9KGw9KGk9ZC5jdXJyZW50LmdldChnKSk9PW51bGw/dm9pZCAwOmkua2V5d29yZHMpIT1udWxsP2w6W10sRj10ZSh5LGgpO24uY3VycmVudC5maWx0ZXJlZC5pdGVtcy5zZXQoZyxGKSxGPjAmJmUrK31mb3IobGV0W2cseV1vZiBjLmN1cnJlbnQpZm9yKGxldCBoIG9mIHkpaWYobi5jdXJyZW50LmZpbHRlcmVkLml0ZW1zLmdldChoKT4wKXtuLmN1cnJlbnQuZmlsdGVyZWQuZ3JvdXBzLmFkZChnKTticmVha31uLmN1cnJlbnQuZmlsdGVyZWQuY291bnQ9ZX1mdW5jdGlvbiBuZSgpe3ZhciBhLHMsaTtsZXQgZT1NKCk7ZSYmKCgoYT1lLnBhcmVudEVsZW1lbnQpPT1udWxsP3ZvaWQgMDphLmZpcnN0Q2hpbGQpPT09ZSYmKChpPShzPWUuY2xvc2VzdChOKSk9PW51bGw/dm9pZCAwOnMucXVlcnlTZWxlY3RvcihiZSkpPT1udWxsfHxpLnNjcm9sbEludG9WaWV3KHtibG9jazpcIm5lYXJlc3RcIn0pKSxlLnNjcm9sbEludG9WaWV3KHtibG9jazpcIm5lYXJlc3RcIn0pKX1mdW5jdGlvbiBNKCl7dmFyIGU7cmV0dXJuKGU9SS5jdXJyZW50KT09bnVsbD92b2lkIDA6ZS5xdWVyeVNlbGVjdG9yKGAke2xlfVthcmlhLXNlbGVjdGVkPVwidHJ1ZVwiXWApfWZ1bmN0aW9uIFYoKXt2YXIgZTtyZXR1cm4gQXJyYXkuZnJvbSgoKGU9SS5jdXJyZW50KT09bnVsbD92b2lkIDA6ZS5xdWVyeVNlbGVjdG9yQWxsKGNlKSl8fFtdKX1mdW5jdGlvbiBYKGUpe2xldCBzPVYoKVtlXTtzJiZFLnNldFN0YXRlKFwidmFsdWVcIixzLmdldEF0dHJpYnV0ZShUKSl9ZnVuY3Rpb24gUShlKXt2YXIgZztsZXQgYT1NKCkscz1WKCksaT1zLmZpbmRJbmRleCh5PT55PT09YSksbD1zW2krZV07KGc9cC5jdXJyZW50KSE9bnVsbCYmZy5sb29wJiYobD1pK2U8MD9zW3MubGVuZ3RoLTFdOmkrZT09PXMubGVuZ3RoP3NbMF06c1tpK2VdKSxsJiZFLnNldFN0YXRlKFwidmFsdWVcIixsLmdldEF0dHJpYnV0ZShUKSl9ZnVuY3Rpb24gcmUoZSl7bGV0IGE9TSgpLHM9YT09bnVsbD92b2lkIDA6YS5jbG9zZXN0KE4pLGk7Zm9yKDtzJiYhaTspcz1lPjA/d2UocyxOKTpEZShzLE4pLGk9cz09bnVsbD92b2lkIDA6cy5xdWVyeVNlbGVjdG9yKGNlKTtpP0Uuc2V0U3RhdGUoXCJ2YWx1ZVwiLGkuZ2V0QXR0cmlidXRlKFQpKTpRKGUpfWxldCBvZT0oKT0+WChWKCkubGVuZ3RoLTEpLGllPWU9PntlLnByZXZlbnREZWZhdWx0KCksZS5tZXRhS2V5P29lKCk6ZS5hbHRLZXk/cmUoMSk6USgxKX0sc2U9ZT0+e2UucHJldmVudERlZmF1bHQoKSxlLm1ldGFLZXk/WCgwKTplLmFsdEtleT9yZSgtMSk6USgtMSl9O3JldHVybiB0LmNyZWF0ZUVsZW1lbnQoRC5kaXYse3JlZjpvLHRhYkluZGV4Oi0xLC4uLk8sXCJjbWRrLXJvb3RcIjpcIlwiLG9uS2V5RG93bjplPT57dmFyIHM7KHM9Ty5vbktleURvd24pPT1udWxsfHxzLmNhbGwoTyxlKTtsZXQgYT1lLm5hdGl2ZUV2ZW50LmlzQ29tcG9zaW5nfHxlLmtleUNvZGU9PT0yMjk7aWYoIShlLmRlZmF1bHRQcmV2ZW50ZWR8fGEpKXN3aXRjaChlLmtleSl7Y2FzZVwiblwiOmNhc2VcImpcIjp7aiYmZS5jdHJsS2V5JiZpZShlKTticmVha31jYXNlXCJBcnJvd0Rvd25cIjp7aWUoZSk7YnJlYWt9Y2FzZVwicFwiOmNhc2VcImtcIjp7aiYmZS5jdHJsS2V5JiZzZShlKTticmVha31jYXNlXCJBcnJvd1VwXCI6e3NlKGUpO2JyZWFrfWNhc2VcIkhvbWVcIjp7ZS5wcmV2ZW50RGVmYXVsdCgpLFgoMCk7YnJlYWt9Y2FzZVwiRW5kXCI6e2UucHJldmVudERlZmF1bHQoKSxvZSgpO2JyZWFrfWNhc2VcIkVudGVyXCI6e2UucHJldmVudERlZmF1bHQoKTtsZXQgaT1NKCk7aWYoaSl7bGV0IGw9bmV3IEV2ZW50KFopO2kuZGlzcGF0Y2hFdmVudChsKX19fX19LHQuY3JlYXRlRWxlbWVudChcImxhYmVsXCIse1wiY21kay1sYWJlbFwiOlwiXCIsaHRtbEZvcjpVLmlucHV0SWQsaWQ6VS5sYWJlbElkLHN0eWxlOlRlfSxiKSxCKHIsZT0+dC5jcmVhdGVFbGVtZW50KGRlLlByb3ZpZGVyLHt2YWx1ZTpFfSx0LmNyZWF0ZUVsZW1lbnQodWUuUHJvdmlkZXIse3ZhbHVlOlV9LGUpKSkpfSksaGU9dC5mb3J3YXJkUmVmKChyLG8pPT57dmFyIF8sSTtsZXQgbj1IKCksdT10LnVzZVJlZihudWxsKSxjPXQudXNlQ29udGV4dChmZSksZD1LKCksZj1wZShyKSxwPShJPShfPWYuY3VycmVudCk9PW51bGw/dm9pZCAwOl8uZm9yY2VNb3VudCkhPW51bGw/STpjPT1udWxsP3ZvaWQgMDpjLmZvcmNlTW91bnQ7aygoKT0+e2lmKCFwKXJldHVybiBkLml0ZW0obixjPT1udWxsP3ZvaWQgMDpjLmlkKX0sW3BdKTtsZXQgYj12ZShuLHUsW3IudmFsdWUsci5jaGlsZHJlbix1XSxyLmtleXdvcmRzKSxtPWVlKCksUj1QKHY9PnYudmFsdWUmJnYudmFsdWU9PT1iLmN1cnJlbnQpLHg9UCh2PT5wfHxkLmZpbHRlcigpPT09ITE/ITA6di5zZWFyY2g/di5maWx0ZXJlZC5pdGVtcy5nZXQobik+MDohMCk7dC51c2VFZmZlY3QoKCk9PntsZXQgdj11LmN1cnJlbnQ7aWYoISghdnx8ci5kaXNhYmxlZCkpcmV0dXJuIHYuYWRkRXZlbnRMaXN0ZW5lcihaLEMpLCgpPT52LnJlbW92ZUV2ZW50TGlzdGVuZXIoWixDKX0sW3gsci5vblNlbGVjdCxyLmRpc2FibGVkXSk7ZnVuY3Rpb24gQygpe3ZhciB2LEU7UygpLChFPSh2PWYuY3VycmVudCkub25TZWxlY3QpPT1udWxsfHxFLmNhbGwodixiLmN1cnJlbnQpfWZ1bmN0aW9uIFMoKXttLnNldFN0YXRlKFwidmFsdWVcIixiLmN1cnJlbnQsITApfWlmKCF4KXJldHVybiBudWxsO2xldHtkaXNhYmxlZDpBLHZhbHVlOmdlLG9uU2VsZWN0OmosZm9yY2VNb3VudDpPLGtleXdvcmRzOiQsLi4ucX09cjtyZXR1cm4gdC5jcmVhdGVFbGVtZW50KEQuZGl2LHtyZWY6Ryh1LG8pLC4uLnEsaWQ6bixcImNtZGstaXRlbVwiOlwiXCIscm9sZTpcIm9wdGlvblwiLFwiYXJpYS1kaXNhYmxlZFwiOiEhQSxcImFyaWEtc2VsZWN0ZWRcIjohIVIsXCJkYXRhLWRpc2FibGVkXCI6ISFBLFwiZGF0YS1zZWxlY3RlZFwiOiEhUixvblBvaW50ZXJNb3ZlOkF8fGQuZ2V0RGlzYWJsZVBvaW50ZXJTZWxlY3Rpb24oKT92b2lkIDA6UyxvbkNsaWNrOkE/dm9pZCAwOkN9LHIuY2hpbGRyZW4pfSksRWU9dC5mb3J3YXJkUmVmKChyLG8pPT57bGV0e2hlYWRpbmc6bixjaGlsZHJlbjp1LGZvcmNlTW91bnQ6YywuLi5kfT1yLGY9SCgpLHA9dC51c2VSZWYobnVsbCksYj10LnVzZVJlZihudWxsKSxtPUgoKSxSPUsoKSx4PVAoUz0+Y3x8Ui5maWx0ZXIoKT09PSExPyEwOlMuc2VhcmNoP1MuZmlsdGVyZWQuZ3JvdXBzLmhhcyhmKTohMCk7aygoKT0+Ui5ncm91cChmKSxbXSksdmUoZixwLFtyLnZhbHVlLHIuaGVhZGluZyxiXSk7bGV0IEM9dC51c2VNZW1vKCgpPT4oe2lkOmYsZm9yY2VNb3VudDpjfSksW2NdKTtyZXR1cm4gdC5jcmVhdGVFbGVtZW50KEQuZGl2LHtyZWY6RyhwLG8pLC4uLmQsXCJjbWRrLWdyb3VwXCI6XCJcIixyb2xlOlwicHJlc2VudGF0aW9uXCIsaGlkZGVuOng/dm9pZCAwOiEwfSxuJiZ0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIix7cmVmOmIsXCJjbWRrLWdyb3VwLWhlYWRpbmdcIjpcIlwiLFwiYXJpYS1oaWRkZW5cIjohMCxpZDptfSxuKSxCKHIsUz0+dC5jcmVhdGVFbGVtZW50KFwiZGl2XCIse1wiY21kay1ncm91cC1pdGVtc1wiOlwiXCIscm9sZTpcImdyb3VwXCIsXCJhcmlhLWxhYmVsbGVkYnlcIjpuP206dm9pZCAwfSx0LmNyZWF0ZUVsZW1lbnQoZmUuUHJvdmlkZXIse3ZhbHVlOkN9LFMpKSkpfSkseWU9dC5mb3J3YXJkUmVmKChyLG8pPT57bGV0e2Fsd2F5c1JlbmRlcjpuLC4uLnV9PXIsYz10LnVzZVJlZihudWxsKSxkPVAoZj0+IWYuc2VhcmNoKTtyZXR1cm4hbiYmIWQ/bnVsbDp0LmNyZWF0ZUVsZW1lbnQoRC5kaXYse3JlZjpHKGMsbyksLi4udSxcImNtZGstc2VwYXJhdG9yXCI6XCJcIixyb2xlOlwic2VwYXJhdG9yXCJ9KX0pLFNlPXQuZm9yd2FyZFJlZigocixvKT0+e2xldHtvblZhbHVlQ2hhbmdlOm4sLi4udX09cixjPXIudmFsdWUhPW51bGwsZD1lZSgpLGY9UChtPT5tLnNlYXJjaCkscD1QKG09Pm0uc2VsZWN0ZWRJdGVtSWQpLGI9SygpO3JldHVybiB0LnVzZUVmZmVjdCgoKT0+e3IudmFsdWUhPW51bGwmJmQuc2V0U3RhdGUoXCJzZWFyY2hcIixyLnZhbHVlKX0sW3IudmFsdWVdKSx0LmNyZWF0ZUVsZW1lbnQoRC5pbnB1dCx7cmVmOm8sLi4udSxcImNtZGstaW5wdXRcIjpcIlwiLGF1dG9Db21wbGV0ZTpcIm9mZlwiLGF1dG9Db3JyZWN0Olwib2ZmXCIsc3BlbGxDaGVjazohMSxcImFyaWEtYXV0b2NvbXBsZXRlXCI6XCJsaXN0XCIscm9sZTpcImNvbWJvYm94XCIsXCJhcmlhLWV4cGFuZGVkXCI6ITAsXCJhcmlhLWNvbnRyb2xzXCI6Yi5saXN0SWQsXCJhcmlhLWxhYmVsbGVkYnlcIjpiLmxhYmVsSWQsXCJhcmlhLWFjdGl2ZWRlc2NlbmRhbnRcIjpwLGlkOmIuaW5wdXRJZCx0eXBlOlwidGV4dFwiLHZhbHVlOmM/ci52YWx1ZTpmLG9uQ2hhbmdlOm09PntjfHxkLnNldFN0YXRlKFwic2VhcmNoXCIsbS50YXJnZXQudmFsdWUpLG49PW51bGx8fG4obS50YXJnZXQudmFsdWUpfX0pfSksQ2U9dC5mb3J3YXJkUmVmKChyLG8pPT57bGV0e2NoaWxkcmVuOm4sbGFiZWw6dT1cIlN1Z2dlc3Rpb25zXCIsLi4uY309cixkPXQudXNlUmVmKG51bGwpLGY9dC51c2VSZWYobnVsbCkscD1QKG09Pm0uc2VsZWN0ZWRJdGVtSWQpLGI9SygpO3JldHVybiB0LnVzZUVmZmVjdCgoKT0+e2lmKGYuY3VycmVudCYmZC5jdXJyZW50KXtsZXQgbT1mLmN1cnJlbnQsUj1kLmN1cnJlbnQseCxDPW5ldyBSZXNpemVPYnNlcnZlcigoKT0+e3g9cmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpPT57bGV0IFM9bS5vZmZzZXRIZWlnaHQ7Ui5zdHlsZS5zZXRQcm9wZXJ0eShcIi0tY21kay1saXN0LWhlaWdodFwiLFMudG9GaXhlZCgxKStcInB4XCIpfSl9KTtyZXR1cm4gQy5vYnNlcnZlKG0pLCgpPT57Y2FuY2VsQW5pbWF0aW9uRnJhbWUoeCksQy51bm9ic2VydmUobSl9fX0sW10pLHQuY3JlYXRlRWxlbWVudChELmRpdix7cmVmOkcoZCxvKSwuLi5jLFwiY21kay1saXN0XCI6XCJcIixyb2xlOlwibGlzdGJveFwiLHRhYkluZGV4Oi0xLFwiYXJpYS1hY3RpdmVkZXNjZW5kYW50XCI6cCxcImFyaWEtbGFiZWxcIjp1LGlkOmIubGlzdElkfSxCKHIsbT0+dC5jcmVhdGVFbGVtZW50KFwiZGl2XCIse3JlZjpHKGYsYi5saXN0SW5uZXJSZWYpLFwiY21kay1saXN0LXNpemVyXCI6XCJcIn0sbSkpKX0pLHhlPXQuZm9yd2FyZFJlZigocixvKT0+e2xldHtvcGVuOm4sb25PcGVuQ2hhbmdlOnUsb3ZlcmxheUNsYXNzTmFtZTpjLGNvbnRlbnRDbGFzc05hbWU6ZCxjb250YWluZXI6ZiwuLi5wfT1yO3JldHVybiB0LmNyZWF0ZUVsZW1lbnQody5Sb290LHtvcGVuOm4sb25PcGVuQ2hhbmdlOnV9LHQuY3JlYXRlRWxlbWVudCh3LlBvcnRhbCx7Y29udGFpbmVyOmZ9LHQuY3JlYXRlRWxlbWVudCh3Lk92ZXJsYXkse1wiY21kay1vdmVybGF5XCI6XCJcIixjbGFzc05hbWU6Y30pLHQuY3JlYXRlRWxlbWVudCh3LkNvbnRlbnQse1wiYXJpYS1sYWJlbFwiOnIubGFiZWwsXCJjbWRrLWRpYWxvZ1wiOlwiXCIsY2xhc3NOYW1lOmR9LHQuY3JlYXRlRWxlbWVudChtZSx7cmVmOm8sLi4ucH0pKSkpfSksSWU9dC5mb3J3YXJkUmVmKChyLG8pPT5QKHU9PnUuZmlsdGVyZWQuY291bnQ9PT0wKT90LmNyZWF0ZUVsZW1lbnQoRC5kaXYse3JlZjpvLC4uLnIsXCJjbWRrLWVtcHR5XCI6XCJcIixyb2xlOlwicHJlc2VudGF0aW9uXCJ9KTpudWxsKSxQZT10LmZvcndhcmRSZWYoKHIsbyk9PntsZXR7cHJvZ3Jlc3M6bixjaGlsZHJlbjp1LGxhYmVsOmM9XCJMb2FkaW5nLi4uXCIsLi4uZH09cjtyZXR1cm4gdC5jcmVhdGVFbGVtZW50KEQuZGl2LHtyZWY6bywuLi5kLFwiY21kay1sb2FkaW5nXCI6XCJcIixyb2xlOlwicHJvZ3Jlc3NiYXJcIixcImFyaWEtdmFsdWVub3dcIjpuLFwiYXJpYS12YWx1ZW1pblwiOjAsXCJhcmlhLXZhbHVlbWF4XCI6MTAwLFwiYXJpYS1sYWJlbFwiOmN9LEIocixmPT50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIix7XCJhcmlhLWhpZGRlblwiOiEwfSxmKSkpfSksX2U9T2JqZWN0LmFzc2lnbihtZSx7TGlzdDpDZSxJdGVtOmhlLElucHV0OlNlLEdyb3VwOkVlLFNlcGFyYXRvcjp5ZSxEaWFsb2c6eGUsRW1wdHk6SWUsTG9hZGluZzpQZX0pO2Z1bmN0aW9uIHdlKHIsbyl7bGV0IG49ci5uZXh0RWxlbWVudFNpYmxpbmc7Zm9yKDtuOyl7aWYobi5tYXRjaGVzKG8pKXJldHVybiBuO249bi5uZXh0RWxlbWVudFNpYmxpbmd9fWZ1bmN0aW9uIERlKHIsbyl7bGV0IG49ci5wcmV2aW91c0VsZW1lbnRTaWJsaW5nO2Zvcig7bjspe2lmKG4ubWF0Y2hlcyhvKSlyZXR1cm4gbjtuPW4ucHJldmlvdXNFbGVtZW50U2libGluZ319ZnVuY3Rpb24gcGUocil7bGV0IG89dC51c2VSZWYocik7cmV0dXJuIGsoKCk9PntvLmN1cnJlbnQ9cn0pLG99dmFyIGs9dHlwZW9mIHdpbmRvdz09XCJ1bmRlZmluZWRcIj90LnVzZUVmZmVjdDp0LnVzZUxheW91dEVmZmVjdDtmdW5jdGlvbiBMKHIpe2xldCBvPXQudXNlUmVmKCk7cmV0dXJuIG8uY3VycmVudD09PXZvaWQgMCYmKG8uY3VycmVudD1yKCkpLG99ZnVuY3Rpb24gUChyKXtsZXQgbz1lZSgpLG49KCk9PnIoby5zbmFwc2hvdCgpKTtyZXR1cm4gdC51c2VTeW5jRXh0ZXJuYWxTdG9yZShvLnN1YnNjcmliZSxuLG4pfWZ1bmN0aW9uIHZlKHIsbyxuLHU9W10pe2xldCBjPXQudXNlUmVmKCksZD1LKCk7cmV0dXJuIGsoKCk9Pnt2YXIgYjtsZXQgZj0oKCk9Pnt2YXIgbTtmb3IobGV0IFIgb2Ygbil7aWYodHlwZW9mIFI9PVwic3RyaW5nXCIpcmV0dXJuIFIudHJpbSgpO2lmKHR5cGVvZiBSPT1cIm9iamVjdFwiJiZcImN1cnJlbnRcImluIFIpcmV0dXJuIFIuY3VycmVudD8obT1SLmN1cnJlbnQudGV4dENvbnRlbnQpPT1udWxsP3ZvaWQgMDptLnRyaW0oKTpjLmN1cnJlbnR9fSkoKSxwPXUubWFwKG09Pm0udHJpbSgpKTtkLnZhbHVlKHIsZixwKSwoYj1vLmN1cnJlbnQpPT1udWxsfHxiLnNldEF0dHJpYnV0ZShULGYpLGMuY3VycmVudD1mfSksY312YXIga2U9KCk9PntsZXRbcixvXT10LnVzZVN0YXRlKCksbj1MKCgpPT5uZXcgTWFwKTtyZXR1cm4gaygoKT0+e24uY3VycmVudC5mb3JFYWNoKHU9PnUoKSksbi5jdXJyZW50PW5ldyBNYXB9LFtyXSksKHUsYyk9PntuLmN1cnJlbnQuc2V0KHUsYyksbyh7fSl9fTtmdW5jdGlvbiBNZShyKXtsZXQgbz1yLnR5cGU7cmV0dXJuIHR5cGVvZiBvPT1cImZ1bmN0aW9uXCI/byhyLnByb3BzKTpcInJlbmRlclwiaW4gbz9vLnJlbmRlcihyLnByb3BzKTpyfWZ1bmN0aW9uIEIoe2FzQ2hpbGQ6cixjaGlsZHJlbjpvfSxuKXtyZXR1cm4gciYmdC5pc1ZhbGlkRWxlbWVudChvKT90LmNsb25lRWxlbWVudChNZShvKSx7cmVmOm8ucmVmfSxuKG8ucHJvcHMuY2hpbGRyZW4pKTpuKG8pfXZhciBUZT17cG9zaXRpb246XCJhYnNvbHV0ZVwiLHdpZHRoOlwiMXB4XCIsaGVpZ2h0OlwiMXB4XCIscGFkZGluZzpcIjBcIixtYXJnaW46XCItMXB4XCIsb3ZlcmZsb3c6XCJoaWRkZW5cIixjbGlwOlwicmVjdCgwLCAwLCAwLCAwKVwiLHdoaXRlU3BhY2U6XCJub3dyYXBcIixib3JkZXJXaWR0aDpcIjBcIn07ZXhwb3J0e19lIGFzIENvbW1hbmQseGUgYXMgQ29tbWFuZERpYWxvZyxJZSBhcyBDb21tYW5kRW1wdHksRWUgYXMgQ29tbWFuZEdyb3VwLFNlIGFzIENvbW1hbmRJbnB1dCxoZSBhcyBDb21tYW5kSXRlbSxDZSBhcyBDb21tYW5kTGlzdCxQZSBhcyBDb21tYW5kTG9hZGluZyxtZSBhcyBDb21tYW5kUm9vdCx5ZSBhcyBDb21tYW5kU2VwYXJhdG9yLFJlIGFzIGRlZmF1bHRGaWx0ZXIsUCBhcyB1c2VDb21tYW5kU3RhdGV9O1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUksSUFBRTtBQUFFQSxJQUFBQSxNQUFFO0FBQUcsSUFBQSxJQUFFO0FBQUcsSUFBQSxJQUFFO0FBQUksSUFBQSxJQUFFO0FBQUcsSUFBQSxJQUFFO0FBQUssSUFBQSxJQUFFO0FBQU0sSUFBSUMsTUFBRTtBQUFJLElBQUEsSUFBRTtBQUFzQkMsSUFBQUEsTUFBRTtBQUF1QkMsSUFBQUEsTUFBRTtBQUFRLElBQUEsSUFBRTtBQUFTLFNBQVMsRUFBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFO0NBQUMsSUFBRyxNQUFJLEVBQUUsUUFBTyxPQUFPLE1BQUksRUFBRSxTQUFPLElBQUVGO0NBQUUsSUFBSSxJQUFFLEdBQUcsRUFBRSxHQUFHO0NBQUksSUFBRyxFQUFFLE9BQUssS0FBSyxHQUFFLE9BQU8sRUFBRTtDQUFHLEtBQUksSUFBSSxJQUFFLEVBQUUsT0FBTyxDQUFDLEdBQUUsSUFBRSxFQUFFLFFBQVEsR0FBRSxDQUFDLEdBQUUsSUFBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsS0FBRyxJQUFHLElBQUUsRUFBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLElBQUUsR0FBRSxJQUFFLEdBQUUsQ0FBQyxHQUFFLElBQUUsTUFBSSxNQUFJLElBQUUsS0FBRyxJQUFFLEVBQUUsS0FBSyxFQUFFLE9BQU8sSUFBRSxDQUFDLENBQUMsS0FBRyxLQUFHLEdBQUUsSUFBRSxFQUFFLE1BQU0sR0FBRSxJQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU1DLEdBQUMsR0FBRSxLQUFHLElBQUUsTUFBSSxLQUFHLEtBQUssSUFBSSxHQUFFLEVBQUUsTUFBTSxNQUFJQyxJQUFFLEtBQUssRUFBRSxPQUFPLElBQUUsQ0FBQyxDQUFDLEtBQUcsS0FBR0gsS0FBRSxJQUFFLEVBQUUsTUFBTSxHQUFFLElBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUUsS0FBRyxJQUFFLE1BQUksS0FBRyxLQUFLLElBQUksR0FBRSxFQUFFLE1BQU0sT0FBSyxLQUFHLEdBQUUsSUFBRSxNQUFJLEtBQUcsS0FBSyxJQUFJLEdBQUUsSUFBRSxDQUFDLEtBQUksRUFBRSxPQUFPLENBQUMsTUFBSSxFQUFFLE9BQU8sQ0FBQyxNQUFJLEtBQUcsTUFBSyxJQUFFLEtBQUcsRUFBRSxPQUFPLElBQUUsQ0FBQyxNQUFJLEVBQUUsT0FBTyxJQUFFLENBQUMsS0FBRyxFQUFFLE9BQU8sSUFBRSxDQUFDLE1BQUksRUFBRSxPQUFPLENBQUMsS0FBRyxFQUFFLE9BQU8sSUFBRSxDQUFDLE1BQUksRUFBRSxPQUFPLENBQUMsT0FBSyxJQUFFLEVBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxJQUFFLEdBQUUsSUFBRSxHQUFFLENBQUMsR0FBRSxJQUFFLElBQUUsTUFBSSxJQUFFLElBQUUsS0FBSSxJQUFFLE1BQUksSUFBRSxJQUFHLElBQUUsRUFBRSxRQUFRLEdBQUUsSUFBRSxDQUFDO0NBQUUsT0FBTyxFQUFFLEtBQUcsR0FBRTtBQUFDO0FBQUMsU0FBUyxFQUFFLEdBQUU7Q0FBQyxPQUFPLEVBQUUsWUFBWSxDQUFDLENBQUMsUUFBUSxHQUFFLEdBQUc7QUFBQztBQUFDLFNBQVMsRUFBRSxHQUFFLEdBQUUsR0FBRTtDQUFDLE9BQU8sSUFBRSxLQUFHLEVBQUUsU0FBTyxJQUFFLEdBQUcsSUFBRSxNQUFJLEVBQUUsS0FBSyxHQUFHLE1BQUksR0FBRSxFQUFFLEdBQUUsR0FBRSxFQUFFLENBQUMsR0FBRSxFQUFFLENBQUMsR0FBRSxHQUFFLEdBQUUsQ0FBQyxDQUFDO0FBQUM7Ozs7QUNBbm5CLElBQUksSUFBRTtBQUFrQixJQUFBLElBQUU7QUFBd0IsSUFBQSxLQUFHO0FBQTBCLElBQUEsS0FBRztBQUFpQixJQUFBLEtBQUcsR0FBRyxHQUFHO0FBQThCLElBQUEsSUFBRTtBQUFtQixJQUFBLElBQUU7QUFBYSxJQUFBLE1BQUksR0FBRSxHQUFFLE1BQUlJLEVBQUcsR0FBRSxHQUFFLENBQUM7QUFBRSxJQUFBLEtBQUEsYUFBSyxjQUFjLEtBQUssQ0FBQztBQUFFLElBQUEsVUFBQSxhQUFRLFdBQVcsRUFBRTtBQUFFLElBQUEsS0FBQSxhQUFLLGNBQWMsS0FBSyxDQUFDO0FBQUUsSUFBQSxXQUFBLGFBQVMsV0FBVyxFQUFFO0FBQUUsSUFBQSxLQUFBLGFBQUssY0FBYyxLQUFLLENBQUM7QUFBRSxJQUFBLEtBQUEsYUFBSyxZQUFZLEdBQUUsTUFBSTtDQUFDLElBQUksSUFBRSxRQUFNO0VBQUMsSUFBSSxHQUFFO0VBQUUsT0FBTTtHQUFDLFFBQU87R0FBRyxRQUFPLEtBQUcsSUFBRSxFQUFFLFVBQVEsT0FBSyxJQUFFLEVBQUUsaUJBQWUsT0FBSyxJQUFFO0dBQUcsZ0JBQWUsS0FBSztHQUFFLFVBQVM7SUFBQyxPQUFNO0lBQUUsdUJBQU0sSUFBSSxJQUFFO0lBQUUsd0JBQU8sSUFBSSxJQUFFO0dBQUM7RUFBQztDQUFDLENBQUMsR0FBRSxJQUFFLHdCQUFNLElBQUksSUFBRSxDQUFDLEdBQUUsSUFBRSx3QkFBTSxJQUFJLElBQUUsQ0FBQyxHQUFFLElBQUUsd0JBQU0sSUFBSSxJQUFFLENBQUMsR0FBRSxJQUFFLHdCQUFNLElBQUksSUFBRSxDQUFDLEdBQUUsSUFBRSxHQUFHLENBQUMsR0FBRSxFQUFDLE9BQU0sR0FBRSxVQUFTLEdBQUUsT0FBTSxHQUFFLGVBQWMsR0FBRSxRQUFPLEdBQUUsY0FBYSxHQUFFLE1BQUssR0FBRSx5QkFBd0IsS0FBRyxDQUFDLEdBQUUsYUFBWSxJQUFFLENBQUMsR0FBRSxHQUFHLE1BQUcsR0FBRSxJQUFFQyxNQUFFLEdBQUUsSUFBRUEsTUFBRSxHQUFFLElBQUVBLE1BQUUsR0FBRSxJQUFBLGFBQUksT0FBTyxJQUFJLEdBQUUsSUFBRSxHQUFHO0NBQUUsUUFBTTtFQUFDLElBQUcsTUFBSSxLQUFLLEdBQUU7R0FBQyxJQUFJLElBQUUsRUFBRSxLQUFLO0dBQUUsRUFBRSxRQUFRLFFBQU0sR0FBRSxFQUFFLEtBQUs7RUFBQztDQUFDLEdBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRSxRQUFNO0VBQUMsRUFBRSxHQUFFLEVBQUU7Q0FBQyxHQUFFLENBQUMsQ0FBQztDQUFFLElBQUksSUFBQSxhQUFJLGVBQWE7RUFBQyxZQUFVLE9BQUksRUFBRSxRQUFRLElBQUksQ0FBQyxTQUFNLEVBQUUsUUFBUSxPQUFPLENBQUM7RUFBRyxnQkFBYSxFQUFFO0VBQVEsV0FBVSxHQUFFLEdBQUUsTUFBSTtHQUFDLElBQUksR0FBRSxHQUFFLEdBQUU7R0FBRSxJQUFHLENBQUMsT0FBTyxHQUFHLEVBQUUsUUFBUSxJQUFHLENBQUMsR0FBRTtJQUFDLElBQUcsRUFBRSxRQUFRLEtBQUcsR0FBRSxNQUFJLFVBQVMsRUFBRSxHQUFFLEVBQUUsR0FBRSxFQUFFLEdBQUUsQ0FBQztTQUFPLElBQUcsTUFBSSxTQUFRO0tBQUMsSUFBRyxTQUFTLGNBQWMsYUFBYSxZQUFZLEtBQUcsU0FBUyxjQUFjLGFBQWEsV0FBVyxHQUFFO01BQUMsSUFBSSxJQUFFLFNBQVMsZUFBZSxDQUFDO01BQUUsSUFBRSxFQUFFLE1BQU0sS0FBRyxJQUFFLFNBQVMsZUFBZSxDQUFDLE1BQUksUUFBTSxFQUFFLE1BQU07S0FBQztLQUFDLElBQUcsRUFBRSxTQUFNO01BQUMsSUFBSTtNQUFFLEVBQUUsUUFBUSxrQkFBZ0IsSUFBRSxFQUFFLE1BQUksT0FBSyxLQUFLLElBQUUsRUFBRSxJQUFHLEVBQUUsS0FBSztLQUFDLENBQUMsR0FBRSxLQUFHLEVBQUUsR0FBRSxFQUFFLEtBQUksSUFBRSxFQUFFLFlBQVUsT0FBSyxLQUFLLElBQUUsRUFBRSxXQUFTLEtBQUssR0FBRTtNQUFDLElBQUksSUFBRSxLQUFHLE9BQUssSUFBRTtNQUFHLENBQUMsS0FBRyxJQUFFLEVBQUUsUUFBQSxDQUFTLGtCQUFnQixRQUFNLEVBQUUsS0FBSyxHQUFFLENBQUM7TUFBRTtLQUFNO0lBQUM7SUFBQyxFQUFFLEtBQUs7R0FBQztFQUFDO0VBQUUsWUFBUztHQUFDLEVBQUUsUUFBUSxTQUFRLE1BQUcsRUFBRSxDQUFDO0VBQUM7Q0FBQyxJQUFHLENBQUMsQ0FBQyxHQUFFLElBQUEsYUFBSSxlQUFhO0VBQUMsUUFBTyxHQUFFLEdBQUUsTUFBSTtHQUFDLElBQUk7R0FBRSxRQUFNLElBQUUsRUFBRSxRQUFRLElBQUksQ0FBQyxNQUFJLE9BQUssS0FBSyxJQUFFLEVBQUUsV0FBUyxFQUFFLFFBQVEsSUFBSSxHQUFFO0lBQUMsT0FBTTtJQUFFLFVBQVM7R0FBQyxDQUFDLEdBQUUsRUFBRSxRQUFRLFNBQVMsTUFBTSxJQUFJLEdBQUUsR0FBRyxHQUFFLENBQUMsQ0FBQyxHQUFFLEVBQUUsU0FBTTtJQUFDLEVBQUUsR0FBRSxFQUFFLEtBQUs7R0FBQyxDQUFDO0VBQUU7RUFBRSxPQUFNLEdBQUUsT0FBSyxFQUFFLFFBQVEsSUFBSSxDQUFDLEdBQUUsTUFBSSxFQUFFLFFBQVEsSUFBSSxDQUFDLElBQUUsRUFBRSxRQUFRLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUUsRUFBRSxRQUFRLElBQUksbUJBQUUsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBRyxFQUFFLFNBQU07R0FBQyxFQUFFLEdBQUUsRUFBRSxHQUFFLEVBQUUsUUFBUSxTQUFPLEVBQUUsR0FBRSxFQUFFLEtBQUs7RUFBQyxDQUFDLFNBQU07R0FBQyxFQUFFLFFBQVEsT0FBTyxDQUFDLEdBQUUsRUFBRSxRQUFRLE9BQU8sQ0FBQyxHQUFFLEVBQUUsUUFBUSxTQUFTLE1BQU0sT0FBTyxDQUFDO0dBQUUsSUFBSSxJQUFFLEVBQUU7R0FBRSxFQUFFLFNBQU07SUFBQyxFQUFFLElBQUcsS0FBRyxPQUFLLEtBQUssSUFBRSxFQUFFLGFBQWEsSUFBSSxPQUFLLEtBQUcsRUFBRSxHQUFFLEVBQUUsS0FBSztHQUFDLENBQUM7RUFBQztFQUFHLFFBQU0sT0FBSSxFQUFFLFFBQVEsSUFBSSxDQUFDLEtBQUcsRUFBRSxRQUFRLElBQUksbUJBQUUsSUFBSSxJQUFFLENBQUMsU0FBTTtHQUFDLEVBQUUsUUFBUSxPQUFPLENBQUMsR0FBRSxFQUFFLFFBQVEsT0FBTyxDQUFDO0VBQUM7RUFBRyxjQUFXLEVBQUUsUUFBUTtFQUFhLE9BQU0sS0FBRyxFQUFFO0VBQWMsa0NBQStCLEVBQUUsUUFBUTtFQUF3QixRQUFPO0VBQUUsU0FBUTtFQUFFLFNBQVE7RUFBRSxjQUFhO0NBQUMsSUFBRyxDQUFDLENBQUM7Q0FBRSxTQUFTLEdBQUcsR0FBRSxHQUFFO0VBQUMsSUFBSSxHQUFFO0VBQUUsSUFBSSxLQUFHLEtBQUcsSUFBRSxFQUFFLFlBQVUsT0FBSyxLQUFLLElBQUUsRUFBRSxXQUFTLE9BQUssSUFBRTtFQUFHLE9BQU8sSUFBRSxFQUFFLEdBQUUsRUFBRSxRQUFRLFFBQU8sQ0FBQyxJQUFFO0NBQUM7Q0FBQyxTQUFTLElBQUc7RUFBQyxJQUFHLENBQUMsRUFBRSxRQUFRLFVBQVEsRUFBRSxRQUFRLGlCQUFlLENBQUMsR0FBRTtFQUFPLElBQUksSUFBRSxFQUFFLFFBQVEsU0FBUyxPQUFNLElBQUUsQ0FBQztFQUFFLEVBQUUsUUFBUSxTQUFTLE9BQU8sU0FBUSxNQUFHO0dBQUMsSUFBSSxJQUFFLEVBQUUsUUFBUSxJQUFJLENBQUMsR0FBRSxJQUFFO0dBQUUsRUFBRSxTQUFRLE1BQUc7SUFBQyxJQUFJLElBQUUsRUFBRSxJQUFJLENBQUM7SUFBRSxJQUFFLEtBQUssSUFBSSxHQUFFLENBQUM7R0FBQyxDQUFDLEdBQUUsRUFBRSxLQUFLLENBQUMsR0FBRSxDQUFDLENBQUM7RUFBQyxDQUFDO0VBQUUsSUFBSSxJQUFFLEVBQUU7RUFBUSxFQUFFLENBQUMsQ0FBQyxNQUFNLEdBQUUsTUFBSTtHQUFDLElBQUksR0FBRTtHQUFFLElBQUksSUFBRSxFQUFFLGFBQWEsSUFBSSxHQUFFLElBQUUsRUFBRSxhQUFhLElBQUk7R0FBRSxTQUFRLElBQUUsRUFBRSxJQUFJLENBQUMsTUFBSSxPQUFLLElBQUUsT0FBSyxJQUFFLEVBQUUsSUFBSSxDQUFDLE1BQUksT0FBSyxJQUFFO0VBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUSxNQUFHO0dBQUMsSUFBSSxJQUFFLEVBQUUsUUFBUSxDQUFDO0dBQUUsSUFBRSxFQUFFLFlBQVksRUFBRSxrQkFBZ0IsSUFBRSxJQUFFLEVBQUUsUUFBUSxHQUFHLEVBQUUsS0FBSyxDQUFDLElBQUUsRUFBRSxZQUFZLEVBQUUsa0JBQWdCLElBQUUsSUFBRSxFQUFFLFFBQVEsR0FBRyxFQUFFLEtBQUssQ0FBQztFQUFDLENBQUMsR0FBRSxFQUFFLE1BQU0sR0FBRSxNQUFJLEVBQUUsS0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDLFNBQVEsTUFBRztHQUFDLElBQUk7R0FBRSxJQUFJLEtBQUcsSUFBRSxFQUFFLFlBQVUsT0FBSyxLQUFLLElBQUUsRUFBRSxjQUFjLEdBQUcsRUFBRSxHQUFHLEVBQUUsSUFBSSxtQkFBbUIsRUFBRSxFQUFFLEVBQUUsR0FBRztHQUFFLEdBQVcsY0FBYyxZQUFZLENBQUM7RUFBQyxDQUFDO0NBQUM7Q0FBQyxTQUFTLElBQUc7RUFBQyxJQUFJLElBQUUsRUFBRSxDQUFDLENBQUMsTUFBSyxNQUFHLEVBQUUsYUFBYSxlQUFlLE1BQUksTUFBTSxHQUFFLElBQUUsS0FBRyxPQUFLLEtBQUssSUFBRSxFQUFFLGFBQWEsQ0FBQztFQUFFLEVBQUUsU0FBUyxTQUFRLEtBQUcsS0FBSyxDQUFDO0NBQUM7Q0FBQyxTQUFTLElBQUc7RUFBQyxJQUFJLEdBQUUsR0FBRSxHQUFFO0VBQUUsSUFBRyxDQUFDLEVBQUUsUUFBUSxVQUFRLEVBQUUsUUFBUSxpQkFBZSxDQUFDLEdBQUU7R0FBQyxFQUFFLFFBQVEsU0FBUyxRQUFNLEVBQUUsUUFBUTtHQUFLO0VBQU07RUFBQyxFQUFFLFFBQVEsU0FBUyx5QkFBTyxJQUFJLElBQUU7RUFBRSxJQUFJLElBQUU7RUFBRSxLQUFJLElBQUksS0FBSyxFQUFFLFNBQVE7R0FBQyxJQUE2SCxJQUFFLElBQXhILEtBQUcsSUFBRSxFQUFFLFFBQVEsSUFBSSxDQUFDLE1BQUksT0FBSyxLQUFLLElBQUUsRUFBRSxVQUFRLE9BQUssSUFBRSxLQUFNLEtBQUcsSUFBRSxFQUFFLFFBQVEsSUFBSSxDQUFDLE1BQUksT0FBSyxLQUFLLElBQUUsRUFBRSxhQUFXLE9BQUssSUFBRSxDQUFDLENBQVU7R0FBRSxFQUFFLFFBQVEsU0FBUyxNQUFNLElBQUksR0FBRSxDQUFDLEdBQUUsSUFBRSxLQUFHO0VBQUc7RUFBQyxLQUFJLElBQUcsQ0FBQyxHQUFFLE1BQUssRUFBRSxTQUFRLEtBQUksSUFBSSxLQUFLLEdBQUUsSUFBRyxFQUFFLFFBQVEsU0FBUyxNQUFNLElBQUksQ0FBQyxJQUFFLEdBQUU7R0FBQyxFQUFFLFFBQVEsU0FBUyxPQUFPLElBQUksQ0FBQztHQUFFO0VBQUs7RUFBQyxFQUFFLFFBQVEsU0FBUyxRQUFNO0NBQUM7Q0FBQyxTQUFTLEtBQUk7RUFBQyxJQUFJLEdBQUUsR0FBRTtFQUFFLElBQUksSUFBRSxFQUFFO0VBQUUsUUFBTSxJQUFFLEVBQUUsa0JBQWdCLE9BQUssS0FBSyxJQUFFLEVBQUUsZ0JBQWMsT0FBSyxLQUFHLElBQUUsRUFBRSxRQUFRLENBQUMsTUFBSSxPQUFLLEtBQUssSUFBRSxFQUFFLGNBQWMsRUFBRSxNQUFJLFFBQU0sRUFBRSxlQUFlLEVBQUMsT0FBTSxVQUFTLENBQUMsSUFBRyxFQUFFLGVBQWUsRUFBQyxPQUFNLFVBQVMsQ0FBQztDQUFFO0NBQUMsU0FBUyxJQUFHO0VBQUMsSUFBSTtFQUFFLFFBQU8sSUFBRSxFQUFFLFlBQVUsT0FBSyxLQUFLLElBQUUsRUFBRSxjQUFjLEdBQUcsR0FBRyx1QkFBdUI7Q0FBQztDQUFDLFNBQVMsSUFBRztFQUFDLElBQUk7RUFBRSxPQUFPLE1BQU0sT0FBTyxJQUFFLEVBQUUsWUFBVSxPQUFLLEtBQUssSUFBRSxFQUFFLGlCQUFpQixFQUFFLE1BQUksQ0FBQyxDQUFDO0NBQUM7Q0FBQyxTQUFTLEVBQUUsR0FBRTtFQUFDLElBQUksSUFBRSxFQUFFLENBQUMsQ0FBQztFQUFHLEtBQUcsRUFBRSxTQUFTLFNBQVEsRUFBRSxhQUFhLENBQUMsQ0FBQztDQUFDO0NBQUMsU0FBUyxFQUFFLEdBQUU7RUFBQyxJQUFJO0VBQUUsSUFBSSxJQUFFLEVBQUUsR0FBRSxJQUFFLEVBQUUsR0FBRSxJQUFFLEVBQUUsV0FBVSxNQUFHLE1BQUksQ0FBQyxHQUFFLElBQUUsRUFBRSxJQUFFO0VBQUcsQ0FBQyxJQUFFLEVBQUUsWUFBVSxRQUFNLEVBQUUsU0FBTyxJQUFFLElBQUUsSUFBRSxJQUFFLEVBQUUsRUFBRSxTQUFPLEtBQUcsSUFBRSxNQUFJLEVBQUUsU0FBTyxFQUFFLEtBQUcsRUFBRSxJQUFFLEtBQUksS0FBRyxFQUFFLFNBQVMsU0FBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDO0NBQUM7Q0FBQyxTQUFTLEdBQUcsR0FBRTtFQUFDLElBQUksSUFBRSxFQUFFLEdBQUUsSUFBRSxLQUFHLE9BQUssS0FBSyxJQUFFLEVBQUUsUUFBUSxDQUFDLEdBQUU7RUFBRSxPQUFLLEtBQUcsQ0FBQyxJQUFHLElBQUUsSUFBRSxJQUFFLEdBQUcsR0FBRSxDQUFDLElBQUUsR0FBRyxHQUFFLENBQUMsR0FBRSxJQUFFLEtBQUcsT0FBSyxLQUFLLElBQUUsRUFBRSxjQUFjLEVBQUU7RUFBRSxJQUFFLEVBQUUsU0FBUyxTQUFRLEVBQUUsYUFBYSxDQUFDLENBQUMsSUFBRSxFQUFFLENBQUM7Q0FBQztDQUFDLElBQUksV0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDLFNBQU8sQ0FBQyxHQUFFLE1BQUcsTUFBRztFQUFDLEVBQUUsZUFBZSxHQUFFLEVBQUUsVUFBUSxHQUFHLElBQUUsRUFBRSxTQUFPLEdBQUcsQ0FBQyxJQUFFLEVBQUUsQ0FBQztDQUFDLEdBQUUsTUFBRyxNQUFHO0VBQUMsRUFBRSxlQUFlLEdBQUUsRUFBRSxVQUFRLEVBQUUsQ0FBQyxJQUFFLEVBQUUsU0FBTyxHQUFHLEVBQUUsSUFBRSxFQUFFLEVBQUU7Q0FBQztDQUFFLE9BQUEsYUFBUyxjQUFjQyxVQUFFLEtBQUk7RUFBQyxLQUFJO0VBQUUsVUFBUztFQUFHLEdBQUc7RUFBRSxhQUFZO0VBQUcsWUFBVSxNQUFHO0dBQUMsSUFBSTtHQUFFLENBQUMsSUFBRSxFQUFFLGNBQVksUUFBTSxFQUFFLEtBQUssR0FBRSxDQUFDO0dBQUUsSUFBSSxJQUFFLEVBQUUsWUFBWSxlQUFhLEVBQUUsWUFBVTtHQUFJLElBQUcsRUFBRSxFQUFFLG9CQUFrQixJQUFHLFFBQU8sRUFBRSxLQUFUO0lBQWMsS0FBSTtJQUFJLEtBQUk7S0FBSyxLQUFHLEVBQUUsV0FBUyxHQUFHLENBQUM7S0FBRTtJQUFNLEtBQUk7S0FBYSxHQUFHLENBQUM7S0FBRTtJQUFNLEtBQUk7SUFBSSxLQUFJO0tBQUssS0FBRyxFQUFFLFdBQVMsR0FBRyxDQUFDO0tBQUU7SUFBTSxLQUFJO0tBQVcsR0FBRyxDQUFDO0tBQUU7SUFBTSxLQUFJO0tBQVEsRUFBRSxlQUFlLEdBQUUsRUFBRSxDQUFDO0tBQUU7SUFBTSxLQUFJO0tBQU8sRUFBRSxlQUFlLEdBQUUsR0FBRztLQUFFO0lBQU0sS0FBSSxTQUFRO0tBQUMsRUFBRSxlQUFlO0tBQUUsSUFBSSxJQUFFLEVBQUU7S0FBRSxJQUFHLEdBQUU7TUFBQyxJQUFJLElBQUUsSUFBSSxNQUFNLENBQUM7TUFBRSxFQUFFLGNBQWMsQ0FBQztLQUFDO0lBQUM7R0FBQztFQUFDO0NBQUMsR0FBQSxhQUFJLGNBQWMsU0FBUTtFQUFDLGNBQWE7RUFBRyxTQUFRLEVBQUU7RUFBUSxJQUFHLEVBQUU7RUFBUSxPQUFNO0NBQUUsR0FBRSxDQUFDLEdBQUUsRUFBRSxJQUFFLE1BQUEsYUFBSyxjQUFjLEdBQUcsVUFBUyxFQUFDLE9BQU0sRUFBQyxHQUFBLGFBQUksY0FBYyxHQUFHLFVBQVMsRUFBQyxPQUFNLEVBQUMsR0FBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQUMsQ0FBQztBQUFFLElBQUEsS0FBQSxhQUFLLFlBQVksR0FBRSxNQUFJO0NBQUMsSUFBSSxHQUFFO0NBQUUsSUFBSSxJQUFFRCxNQUFFLEdBQUUsSUFBQSxhQUFJLE9BQU8sSUFBSSxHQUFFLElBQUEsYUFBSSxXQUFXLEVBQUUsR0FBRSxJQUFFLEVBQUUsR0FBRSxJQUFFLEdBQUcsQ0FBQyxHQUFFLEtBQUcsS0FBRyxJQUFFLEVBQUUsWUFBVSxPQUFLLEtBQUssSUFBRSxFQUFFLGVBQWEsT0FBSyxJQUFFLEtBQUcsT0FBSyxLQUFLLElBQUUsRUFBRTtDQUFXLFFBQU07RUFBQyxJQUFHLENBQUMsR0FBRSxPQUFPLEVBQUUsS0FBSyxHQUFFLEtBQUcsT0FBSyxLQUFLLElBQUUsRUFBRSxFQUFFO0NBQUMsR0FBRSxDQUFDLENBQUMsQ0FBQztDQUFFLElBQUksSUFBRSxHQUFHLEdBQUUsR0FBRTtFQUFDLEVBQUU7RUFBTSxFQUFFO0VBQVM7Q0FBQyxHQUFFLEVBQUUsUUFBUSxHQUFFLElBQUUsR0FBRyxHQUFFLElBQUUsR0FBRSxNQUFHLEVBQUUsU0FBTyxFQUFFLFVBQVEsRUFBRSxPQUFPLEdBQUUsSUFBRSxHQUFFLE1BQUcsS0FBRyxFQUFFLE9BQU8sTUFBSSxDQUFDLElBQUUsQ0FBQyxJQUFFLEVBQUUsU0FBTyxFQUFFLFNBQVMsTUFBTSxJQUFJLENBQUMsSUFBRSxJQUFFLENBQUMsQ0FBQztDQUFFLGFBQUUsZ0JBQWM7RUFBQyxJQUFJLElBQUUsRUFBRTtFQUFRLElBQUcsRUFBRSxDQUFDLEtBQUcsRUFBRSxXQUFVLE9BQU8sRUFBRSxpQkFBaUIsR0FBRSxDQUFDLFNBQU0sRUFBRSxvQkFBb0IsR0FBRSxDQUFDO0NBQUMsR0FBRTtFQUFDO0VBQUUsRUFBRTtFQUFTLEVBQUU7Q0FBUSxDQUFDO0NBQUUsU0FBUyxJQUFHO0VBQUMsSUFBSSxHQUFFO0VBQUUsRUFBRSxJQUFHLEtBQUcsSUFBRSxFQUFFLFFBQUEsQ0FBUyxhQUFXLFFBQU0sRUFBRSxLQUFLLEdBQUUsRUFBRSxPQUFPO0NBQUM7Q0FBQyxTQUFTLElBQUc7RUFBQyxFQUFFLFNBQVMsU0FBUSxFQUFFLFNBQVEsQ0FBQyxDQUFDO0NBQUM7Q0FBQyxJQUFHLENBQUMsR0FBRSxPQUFPO0NBQUssSUFBRyxFQUFDLFVBQVMsR0FBRSxPQUFNLElBQUcsVUFBUyxHQUFFLFlBQVcsR0FBRSxVQUFTLEdBQUUsR0FBRyxNQUFHO0NBQUUsT0FBQSxhQUFTLGNBQWNDLFVBQUUsS0FBSTtFQUFDLEtBQUlDLFlBQUUsR0FBRSxDQUFDO0VBQUUsR0FBRztFQUFFLElBQUc7RUFBRSxhQUFZO0VBQUcsTUFBSztFQUFTLGlCQUFnQixDQUFDLENBQUM7RUFBRSxpQkFBZ0IsQ0FBQyxDQUFDO0VBQUUsaUJBQWdCLENBQUMsQ0FBQztFQUFFLGlCQUFnQixDQUFDLENBQUM7RUFBRSxlQUFjLEtBQUcsRUFBRSwyQkFBMkIsSUFBRSxLQUFLLElBQUU7RUFBRSxTQUFRLElBQUUsS0FBSyxJQUFFO0NBQUMsR0FBRSxFQUFFLFFBQVE7QUFBQyxDQUFDO0FBQUUsSUFBQSxLQUFBLGFBQUssWUFBWSxHQUFFLE1BQUk7Q0FBQyxJQUFHLEVBQUMsU0FBUSxHQUFFLFVBQVMsR0FBRSxZQUFXLEdBQUUsR0FBRyxNQUFHLEdBQUUsSUFBRUYsTUFBRSxHQUFFLElBQUEsYUFBSSxPQUFPLElBQUksR0FBRSxJQUFBLGFBQUksT0FBTyxJQUFJLEdBQUUsSUFBRUEsTUFBRSxHQUFFLElBQUUsRUFBRSxHQUFFLElBQUUsR0FBRSxNQUFHLEtBQUcsRUFBRSxPQUFPLE1BQUksQ0FBQyxJQUFFLENBQUMsSUFBRSxFQUFFLFNBQU8sRUFBRSxTQUFTLE9BQU8sSUFBSSxDQUFDLElBQUUsQ0FBQyxDQUFDO0NBQUUsUUFBTSxFQUFFLE1BQU0sQ0FBQyxHQUFFLENBQUMsQ0FBQyxHQUFFLEdBQUcsR0FBRSxHQUFFO0VBQUMsRUFBRTtFQUFNLEVBQUU7RUFBUTtDQUFDLENBQUM7Q0FBRSxJQUFJLElBQUEsYUFBSSxlQUFhO0VBQUMsSUFBRztFQUFFLFlBQVc7Q0FBQyxJQUFHLENBQUMsQ0FBQyxDQUFDO0NBQUUsT0FBQSxhQUFTLGNBQWNDLFVBQUUsS0FBSTtFQUFDLEtBQUlDLFlBQUUsR0FBRSxDQUFDO0VBQUUsR0FBRztFQUFFLGNBQWE7RUFBRyxNQUFLO0VBQWUsUUFBTyxJQUFFLEtBQUssSUFBRSxDQUFDO0NBQUMsR0FBRSxLQUFBLGFBQUssY0FBYyxPQUFNO0VBQUMsS0FBSTtFQUFFLHNCQUFxQjtFQUFHLGVBQWMsQ0FBQztFQUFFLElBQUc7Q0FBQyxHQUFFLENBQUMsR0FBRSxFQUFFLElBQUUsTUFBQSxhQUFLLGNBQWMsT0FBTTtFQUFDLG9CQUFtQjtFQUFHLE1BQUs7RUFBUSxtQkFBa0IsSUFBRSxJQUFFLEtBQUs7Q0FBQyxHQUFBLGFBQUksY0FBYyxHQUFHLFVBQVMsRUFBQyxPQUFNLEVBQUMsR0FBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQUMsQ0FBQztBQUFFLElBQUEsS0FBQSxhQUFLLFlBQVksR0FBRSxNQUFJO0NBQUMsSUFBRyxFQUFDLGNBQWEsR0FBRSxHQUFHLE1BQUcsR0FBRSxJQUFBLGFBQUksT0FBTyxJQUFJLEdBQUUsSUFBRSxHQUFFLE1BQUcsQ0FBQyxFQUFFLE1BQU07Q0FBRSxPQUFNLENBQUMsS0FBRyxDQUFDLElBQUUsT0FBQSxhQUFPLGNBQWNELFVBQUUsS0FBSTtFQUFDLEtBQUlDLFlBQUUsR0FBRSxDQUFDO0VBQUUsR0FBRztFQUFFLGtCQUFpQjtFQUFHLE1BQUs7Q0FBVyxDQUFDO0FBQUMsQ0FBQztBQUFFLElBQUEsS0FBQSxhQUFLLFlBQVksR0FBRSxNQUFJO0NBQUMsSUFBRyxFQUFDLGVBQWMsR0FBRSxHQUFHLE1BQUcsR0FBRSxJQUFFLEVBQUUsU0FBTyxNQUFLLElBQUUsR0FBRyxHQUFFLElBQUUsR0FBRSxNQUFHLEVBQUUsTUFBTSxHQUFFLElBQUUsR0FBRSxNQUFHLEVBQUUsY0FBYyxHQUFFLElBQUUsRUFBRTtDQUFFLE9BQUEsYUFBUyxnQkFBYztFQUFDLEVBQUUsU0FBTyxRQUFNLEVBQUUsU0FBUyxVQUFTLEVBQUUsS0FBSztDQUFDLEdBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxHQUFBLGFBQUksY0FBY0QsVUFBRSxPQUFNO0VBQUMsS0FBSTtFQUFFLEdBQUc7RUFBRSxjQUFhO0VBQUcsY0FBYTtFQUFNLGFBQVk7RUFBTSxZQUFXLENBQUM7RUFBRSxxQkFBb0I7RUFBTyxNQUFLO0VBQVcsaUJBQWdCLENBQUM7RUFBRSxpQkFBZ0IsRUFBRTtFQUFPLG1CQUFrQixFQUFFO0VBQVEseUJBQXdCO0VBQUUsSUFBRyxFQUFFO0VBQVEsTUFBSztFQUFPLE9BQU0sSUFBRSxFQUFFLFFBQU07RUFBRSxXQUFTLE1BQUc7R0FBQyxLQUFHLEVBQUUsU0FBUyxVQUFTLEVBQUUsT0FBTyxLQUFLLEdBQUUsSUFBVyxFQUFFLE9BQU8sS0FBSztFQUFDO0NBQUMsQ0FBQztBQUFDLENBQUM7QUFBRSxJQUFBLEtBQUEsYUFBSyxZQUFZLEdBQUUsTUFBSTtDQUFDLElBQUcsRUFBQyxVQUFTLEdBQUUsT0FBTSxJQUFFLGVBQWMsR0FBRyxNQUFHLEdBQUUsSUFBQSxhQUFJLE9BQU8sSUFBSSxHQUFFLElBQUEsYUFBSSxPQUFPLElBQUksR0FBRSxJQUFFLEdBQUUsTUFBRyxFQUFFLGNBQWMsR0FBRSxJQUFFLEVBQUU7Q0FBRSxPQUFBLGFBQVMsZ0JBQWM7RUFBQyxJQUFHLEVBQUUsV0FBUyxFQUFFLFNBQVE7R0FBQyxJQUFJLElBQUUsRUFBRSxTQUFRLElBQUUsRUFBRSxTQUFRLEdBQUUsSUFBRSxJQUFJLHFCQUFtQjtJQUFDLElBQUUsNEJBQTBCO0tBQUMsSUFBSSxJQUFFLEVBQUU7S0FBYSxFQUFFLE1BQU0sWUFBWSxzQkFBcUIsRUFBRSxRQUFRLENBQUMsSUFBRSxJQUFJO0lBQUMsQ0FBQztHQUFDLENBQUM7R0FBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLFNBQU07SUFBQyxxQkFBcUIsQ0FBQyxHQUFFLEVBQUUsVUFBVSxDQUFDO0dBQUM7RUFBQztDQUFDLEdBQUUsQ0FBQyxDQUFDLEdBQUEsYUFBSSxjQUFjQSxVQUFFLEtBQUk7RUFBQyxLQUFJQyxZQUFFLEdBQUUsQ0FBQztFQUFFLEdBQUc7RUFBRSxhQUFZO0VBQUcsTUFBSztFQUFVLFVBQVM7RUFBRyx5QkFBd0I7RUFBRSxjQUFhO0VBQUUsSUFBRyxFQUFFO0NBQU0sR0FBRSxFQUFFLElBQUUsTUFBQSxhQUFLLGNBQWMsT0FBTTtFQUFDLEtBQUlBLFlBQUUsR0FBRSxFQUFFLFlBQVk7RUFBRSxtQkFBa0I7Q0FBRSxHQUFFLENBQUMsQ0FBQyxDQUFDO0FBQUMsQ0FBQztBQUFFLElBQUEsS0FBQSxhQUFLLFlBQVksR0FBRSxNQUFJO0NBQUMsSUFBRyxFQUFDLE1BQUssR0FBRSxjQUFhLEdBQUUsa0JBQWlCLEdBQUUsa0JBQWlCLEdBQUUsV0FBVSxHQUFFLEdBQUcsTUFBRztDQUFFLE9BQUEsYUFBUyxjQUFjQyxRQUFPO0VBQUMsTUFBSztFQUFFLGNBQWE7Q0FBQyxHQUFBLGFBQUksY0FBY0MsY0FBUyxFQUFDLFdBQVUsRUFBQyxHQUFBLGFBQUksY0FBY0MsZUFBVTtFQUFDLGdCQUFlO0VBQUcsV0FBVTtDQUFDLENBQUMsR0FBQSxhQUFJLGNBQWNDLGVBQVU7RUFBQyxjQUFhLEVBQUU7RUFBTSxlQUFjO0VBQUcsV0FBVTtDQUFDLEdBQUEsYUFBSSxjQUFjLElBQUc7RUFBQyxLQUFJO0VBQUUsR0FBRztDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFBQyxDQUFDO0FBQUUsSUFBQSxLQUFBLGFBQUssWUFBWSxHQUFFLE1BQUksR0FBRSxNQUFHLEVBQUUsU0FBUyxVQUFRLENBQUMsSUFBQSxhQUFJLGNBQWNMLFVBQUUsS0FBSTtDQUFDLEtBQUk7Q0FBRSxHQUFHO0NBQUUsY0FBYTtDQUFHLE1BQUs7QUFBYyxDQUFDLElBQUUsSUFBSTtBQUFFLElBQUEsS0FBQSxhQUFLLFlBQVksR0FBRSxNQUFJO0NBQUMsSUFBRyxFQUFDLFVBQVMsR0FBRSxVQUFTLEdBQUUsT0FBTSxJQUFFLGNBQWEsR0FBRyxNQUFHO0NBQUUsT0FBQSxhQUFTLGNBQWNBLFVBQUUsS0FBSTtFQUFDLEtBQUk7RUFBRSxHQUFHO0VBQUUsZ0JBQWU7RUFBRyxNQUFLO0VBQWMsaUJBQWdCO0VBQUUsaUJBQWdCO0VBQUUsaUJBQWdCO0VBQUksY0FBYTtDQUFDLEdBQUUsRUFBRSxJQUFFLE1BQUEsYUFBSyxjQUFjLE9BQU0sRUFBQyxlQUFjLENBQUMsRUFBQyxHQUFFLENBQUMsQ0FBQyxDQUFDO0FBQUMsQ0FBQztBQUFFLElBQUEsS0FBRyxPQUFPLE9BQU8sSUFBRztDQUFDLE1BQUs7Q0FBRyxNQUFLO0NBQUcsT0FBTTtDQUFHLE9BQU07Q0FBRyxXQUFVO0NBQUcsUUFBTztDQUFHLE9BQU07Q0FBRyxTQUFRO0FBQUUsQ0FBQztBQUFFLFNBQVMsR0FBRyxHQUFFLEdBQUU7Q0FBQyxJQUFJLElBQUUsRUFBRTtDQUFtQixPQUFLLElBQUc7RUFBQyxJQUFHLEVBQUUsUUFBUSxDQUFDLEdBQUUsT0FBTztFQUFFLElBQUUsRUFBRTtDQUFrQjtBQUFDO0FBQUMsU0FBUyxHQUFHLEdBQUUsR0FBRTtDQUFDLElBQUksSUFBRSxFQUFFO0NBQXVCLE9BQUssSUFBRztFQUFDLElBQUcsRUFBRSxRQUFRLENBQUMsR0FBRSxPQUFPO0VBQUUsSUFBRSxFQUFFO0NBQXNCO0FBQUM7QUFBQyxTQUFTLEdBQUcsR0FBRTtDQUFDLElBQUksSUFBQSxhQUFJLE9BQU8sQ0FBQztDQUFFLE9BQU8sUUFBTTtFQUFDLEVBQUUsVUFBUTtDQUFDLENBQUMsR0FBRTtBQUFDO0FBQUMsSUFBSSxJQUFFLE9BQU8sVUFBUSxjQUFBLGFBQWMsWUFBQSxhQUFZO0FBQWdCLFNBQVMsRUFBRSxHQUFFO0NBQUMsSUFBSSxJQUFBLGFBQUksT0FBTztDQUFFLE9BQU8sRUFBRSxZQUFVLEtBQUssTUFBSSxFQUFFLFVBQVEsRUFBRSxJQUFHO0FBQUM7QUFBQyxTQUFTLEVBQUUsR0FBRTtDQUFDLElBQUksSUFBRSxHQUFHLEdBQUUsVUFBTSxFQUFFLEVBQUUsU0FBUyxDQUFDO0NBQUUsT0FBQSxhQUFTLHFCQUFxQixFQUFFLFdBQVUsR0FBRSxDQUFDO0FBQUM7QUFBQyxTQUFTLEdBQUcsR0FBRSxHQUFFLEdBQUUsSUFBRSxDQUFDLEdBQUU7Q0FBQyxJQUFJLElBQUEsYUFBSSxPQUFPLEdBQUUsSUFBRSxFQUFFO0NBQUUsT0FBTyxRQUFNO0VBQUMsSUFBSTtFQUFFLElBQUksV0FBTztHQUFDLElBQUk7R0FBRSxLQUFJLElBQUksS0FBSyxHQUFFO0lBQUMsSUFBRyxPQUFPLEtBQUcsVUFBUyxPQUFPLEVBQUUsS0FBSztJQUFFLElBQUcsT0FBTyxLQUFHLFlBQVUsYUFBWSxHQUFFLE9BQU8sRUFBRSxXQUFTLElBQUUsRUFBRSxRQUFRLGdCQUFjLE9BQUssS0FBSyxJQUFFLEVBQUUsS0FBSyxJQUFFLEVBQUU7R0FBTztFQUFDLEVBQUEsQ0FBRyxHQUFFLElBQUUsRUFBRSxLQUFJLE1BQUcsRUFBRSxLQUFLLENBQUM7RUFBRSxFQUFFLE1BQU0sR0FBRSxHQUFFLENBQUMsSUFBRyxJQUFFLEVBQUUsWUFBVSxRQUFNLEVBQUUsYUFBYSxHQUFFLENBQUMsR0FBRSxFQUFFLFVBQVE7Q0FBQyxDQUFDLEdBQUU7QUFBQztBQUFDLElBQUksV0FBTztDQUFDLElBQUcsQ0FBQyxHQUFFLEtBQUEsYUFBSyxTQUFTLEdBQUUsSUFBRSx3QkFBTSxJQUFJLElBQUUsQ0FBQztDQUFFLE9BQU8sUUFBTTtFQUFDLEVBQUUsUUFBUSxTQUFRLE1BQUcsRUFBRSxDQUFDLEdBQUUsRUFBRSwwQkFBUSxJQUFJLElBQUU7Q0FBQyxHQUFFLENBQUMsQ0FBQyxDQUFDLElBQUcsR0FBRSxNQUFJO0VBQUMsRUFBRSxRQUFRLElBQUksR0FBRSxDQUFDLEdBQUUsRUFBRSxDQUFDLENBQUM7Q0FBQztBQUFDO0FBQUUsU0FBUyxHQUFHLEdBQUU7Q0FBQyxJQUFJLElBQUUsRUFBRTtDQUFLLE9BQU8sT0FBTyxLQUFHLGFBQVcsRUFBRSxFQUFFLEtBQUssSUFBRSxZQUFXLElBQUUsRUFBRSxPQUFPLEVBQUUsS0FBSyxJQUFFO0FBQUM7QUFBQyxTQUFTLEVBQUUsRUFBQyxTQUFRLEdBQUUsVUFBUyxLQUFHLEdBQUU7Q0FBQyxPQUFPLEtBQUEsYUFBSyxlQUFlLENBQUMsSUFBQSxhQUFJLGFBQWEsR0FBRyxDQUFDLEdBQUUsRUFBQyxLQUFJLEVBQUUsSUFBRyxHQUFFLEVBQUUsRUFBRSxNQUFNLFFBQVEsQ0FBQyxJQUFFLEVBQUUsQ0FBQztBQUFDO0FBQUMsSUFBSSxLQUFHO0NBQUMsVUFBUztDQUFXLE9BQU07Q0FBTSxRQUFPO0NBQU0sU0FBUTtDQUFJLFFBQU87Q0FBTyxVQUFTO0NBQVMsTUFBSztDQUFtQixZQUFXO0NBQVMsYUFBWTtBQUFHIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMV19