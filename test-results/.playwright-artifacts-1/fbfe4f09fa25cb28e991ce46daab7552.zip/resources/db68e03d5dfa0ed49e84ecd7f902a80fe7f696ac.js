import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Header.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport20_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport20_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { Link, useNavigate } from "/node_modules/@tanstack/react-router/dist/esm/index.dev.js?v=a8030269";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=a8030269";
import { useAuth } from "/src/hooks/useAuth.tsx";
import { useRoles } from "/src/hooks/useRoles.tsx";
import { useUnreadCount } from "/src/hooks/useUnreadCount.tsx";
import { useUnreadNotifications } from "/src/hooks/useUnreadNotifications.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { SubmitDialog } from "/src/components/SubmitDialog.tsx";
import { ProductScannerModal } from "/src/components/ProductScannerModal.tsx";
import { LiveBroadcastModal } from "/src/components/LiveBroadcastModal.tsx";
import { MessengerPrivateCallModal } from "/src/components/MessengerPrivateCallModal.tsx";
import { TopLanguageStrip } from "/src/components/LanguageSwitcher.tsx";
import { UserProfile, getAccountPreferences } from "/src/components/UserProfile.tsx";
import { PWAInstallButton } from "/src/components/PWAInstallButton.tsx";
import { Bell, Building2, Coins, LayoutDashboard, MessageCircle, Shield, Scan, PhoneIncoming, PhoneOff } from "/node_modules/.vite/deps/lucide-react.js?v=a8030269";
import { SotWordmark } from "/src/components/SotWordmark.tsx";
import { getRegisteredBrandIdentity } from "/src/lib/brand-operators.ts";
import { supabase } from "/src/integrations/supabase/client.ts";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "/app/applet/src/components/Header.tsx";
import __vite__cjsImport20_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
var _s = $RefreshSig$();
export function Header({ onPosted }) {
	_s();
	const { user, loading } = useAuth();
	const { isAdmin, isDeveloper, isBrand, persona, setPersona } = useRoles();
	const [registeredBrandName, setRegisteredBrandName] = useState(() => getRegisteredBrandIdentity().name);
	const { t } = useTranslation();
	const navigate = useNavigate();
	const unread = useUnreadCount(user?.id);
	const unreadNotifs = useUnreadNotifications(user?.id);
	useEffect(() => {
		const syncBrand = () => setRegisteredBrandName(getRegisteredBrandIdentity().name);
		window.addEventListener("sot-registered-brand-updated", syncBrand);
		window.addEventListener("sot-brand-operator-updated", syncBrand);
		return () => {
			window.removeEventListener("sot-registered-brand-updated", syncBrand);
			window.removeEventListener("sot-brand-operator-updated", syncBrand);
		};
	}, []);
	const [scannerOpen, setScannerOpen] = useState(false);
	const [liveStudioOpen, setLiveStudioOpen] = useState(false);
	const [incomingCall, setIncomingCall] = useState(null);
	const [activeCallRoom, setActiveCallRoom] = useState(undefined);
	const [activeCallMode, setActiveCallMode] = useState("video_call");
	const [activeCallPartner, setActiveCallPartner] = useState(undefined);
	const [submitDialogOpen, setSubmitDialogOpen] = useState(false);
	// Private 1-on-1 Messenger Call states
	const [messengerCallOpen, setMessengerCallOpen] = useState(false);
	const [messengerCallSession, setMessengerCallSession] = useState(null);
	// Listen for real-time Brand-to-User and User-to-User incoming calls on SOT
	useEffect(() => {
		if (typeof window === "undefined") return;
		const handleIncoming = (payload) => {
			if (!payload || !payload.roomChannel) return;
			if (!getAccountPreferences().callRingAlerts) return;
			// Show ring banner if targeted to this user, or if testing in another tab
			if (!user?.id || payload.recipientId === user.id || payload.callerId !== user.id) {
				setIncomingCall(payload);
			}
		};
		let bc = null;
		if (typeof BroadcastChannel !== "undefined") {
			bc = new BroadcastChannel("sot-call-ring");
			bc.onmessage = (ev) => handleIncoming(ev.data);
		}
		const chan = supabase.channel("sot-call-ring").on("broadcast", { event: "incoming-call" }, ({ payload }) => {
			if (payload) handleIncoming(payload);
		}).subscribe();
		return () => {
			bc?.close();
			void supabase.removeChannel(chan);
		};
	}, [user?.id]);
	const [prefilledPost, setPrefilledPost] = useState(null);
	const handleApplyFromScanner = (params) => {
		setPrefilledPost(params);
		setSubmitDialogOpen(true);
	};
	return /* @__PURE__ */ _jsxDEV("header", {
		suppressHydrationWarning: true,
		className: "sticky top-0 z-40 w-full border-b border-border/70 bg-background/95 backdrop-blur-xl",
		"data-tsd-source": "/src/components/Header.tsx:114:5",
		children: [
			/* @__PURE__ */ _jsxDEV(TopLanguageStrip, { "data-tsd-source": "/src/components/Header.tsx:119:7" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 119,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mx-auto flex h-14 w-full max-w-[1440px] items-center justify-between gap-2 px-3 sm:px-5 lg:px-6",
				"data-tsd-source": "/src/components/Header.tsx:122:7",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex min-w-0 flex-1 items-center gap-2.5 lg:gap-4",
					"data-tsd-source": "/src/components/Header.tsx:123:9",
					children: [/* @__PURE__ */ _jsxDEV(Link, {
						to: "/",
						className: "group flex shrink-0 items-center gap-2 whitespace-nowrap",
						"data-tsd-source": "/src/components/Header.tsx:124:11",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							"aria-label": "SOrT — Stash Or Trash logo",
							className: "flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-foreground text-xs font-extrabold tracking-[-0.12em] text-background shadow-sm transition-transform group-hover:scale-105",
							"data-tsd-source": "/src/components/Header.tsx:125:13",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-stash",
									"data-tsd-source": "/src/components/Header.tsx:129:15",
									children: "S"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 129,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									"data-tsd-source": "/src/components/Header.tsx:130:15",
									children: "O"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 130,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-trash",
									"data-tsd-source": "/src/components/Header.tsx:131:15",
									children: "r"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 131,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									"data-tsd-source": "/src/components/Header.tsx:132:15",
									children: "T"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 132,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(SotWordmark, {
							className: "hidden xl:inline-flex text-base whitespace-nowrap",
							"data-tsd-source": "/src/components/Header.tsx:134:13"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("nav", {
						className: "flex min-w-0 items-center gap-0.5 overflow-x-auto text-xs font-semibold no-scrollbar sm:gap-1",
						"data-tsd-source": "/src/components/Header.tsx:137:11",
						children: [
							/* @__PURE__ */ _jsxDEV(Link, {
								to: "/",
								className: "shrink-0 whitespace-nowrap rounded-md px-2 py-1 text-muted-foreground transition-colors hover:bg-secondary/60 hover:text-foreground [&.active]:bg-secondary [&.active]:text-foreground",
								"data-tsd-source": "/src/components/Header.tsx:138:13",
								children: t("nav.home", { defaultValue: "Home" })
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(Link, {
								to: "/feed",
								className: "shrink-0 whitespace-nowrap rounded-md px-2 py-1 text-muted-foreground transition-colors hover:bg-secondary/60 hover:text-foreground [&.active]:bg-secondary [&.active]:text-foreground",
								"data-tsd-source": "/src/components/Header.tsx:144:13",
								children: t("nav.feed", { defaultValue: "Feed" })
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 13
							}, this),
							persona !== "brand_owner" && /* @__PURE__ */ _jsxDEV(Link, {
								to: "/scan",
								className: "flex shrink-0 items-center gap-1 whitespace-nowrap rounded-md px-2 py-1 text-muted-foreground transition-colors hover:bg-secondary/60 hover:text-foreground [&.active]:bg-secondary [&.active]:text-foreground",
								"data-tsd-source": "/src/components/Header.tsx:151:15",
								children: [/* @__PURE__ */ _jsxDEV(Scan, {
									className: "h-3 w-3 shrink-0 text-[#d6a928]",
									"data-tsd-source": "/src/components/Header.tsx:155:17"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 155,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									"data-tsd-source": "/src/components/Header.tsx:156:17",
									children: t("nav.scan", { defaultValue: "Scan" })
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 156,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 151,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV(Link, {
								to: "/brands",
								className: "shrink-0 whitespace-nowrap rounded-md px-2 py-1 text-muted-foreground transition-colors hover:bg-secondary/60 hover:text-foreground [&.active]:bg-secondary [&.active]:text-foreground",
								"data-tsd-source": "/src/components/Header.tsx:159:13",
								children: t("nav.brands", { defaultValue: "Brands" })
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 159,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(Link, {
								to: "/awards",
								className: "shrink-0 whitespace-nowrap rounded-md px-2 py-1 text-muted-foreground transition-colors hover:bg-secondary/60 hover:text-foreground [&.active]:bg-secondary [&.active]:text-foreground",
								"data-tsd-source": "/src/components/Header.tsx:165:13",
								children: t("nav.awards", { defaultValue: "Awards" })
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 165,
								columnNumber: 13
							}, this),
							user && /* @__PURE__ */ _jsxDEV(Link, {
								to: "/dashboard",
								className: "flex shrink-0 items-center gap-1 whitespace-nowrap rounded-md px-2 py-1 text-muted-foreground transition-colors hover:bg-secondary/60 hover:text-foreground [&.active]:bg-secondary [&.active]:text-foreground",
								"data-tsd-source": "/src/components/Header.tsx:172:15",
								children: [/* @__PURE__ */ _jsxDEV(LayoutDashboard, {
									className: "h-3 w-3 shrink-0 text-[#d6a928]",
									"data-tsd-source": "/src/components/Header.tsx:176:17"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 176,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									"data-tsd-source": "/src/components/Header.tsx:177:17",
									children: persona === "brand_owner" ? "Brand Suite" : t("nav.dashboard", { defaultValue: "My Hub" })
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 177,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 172,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 123,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex shrink-0 items-center gap-1.5",
					"data-tsd-source": "/src/components/Header.tsx:187:9",
					children: [
						isDeveloper && /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => {
								const next = persona === "brand_owner" ? "consumer" : "brand_owner";
								setPersona(next);
							},
							title: "Developer-Only View Switcher (Also available inside your UserProfile menu)",
							className: cn("hidden xl:inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[11px] font-black transition cursor-pointer whitespace-nowrap", persona === "brand_owner" ? "border-[#d6a928] bg-slate-950 text-[#f5d061]" : "border-emerald-600/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300"),
							"data-tsd-source": "/src/components/Header.tsx:190:13",
							children: persona === "brand_owner" ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Building2, {
								className: "h-3 w-3 text-[#d6a928]",
								"data-tsd-source": "/src/components/Header.tsx:206:19"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 206,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "max-w-[100px] truncate",
								"data-tsd-source": "/src/components/Header.tsx:207:19",
								children: ["DEV: ", registeredBrandName]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 207,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 205,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Coins, {
								className: "h-3 w-3 text-[#d6a928]",
								"data-tsd-source": "/src/components/Header.tsx:211:19"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								"data-tsd-source": "/src/components/Header.tsx:212:19",
								children: "DEV: Personal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 212,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 210,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							variant: "ghost",
							size: "icon",
							onClick: () => {
								if (isAdmin) {
									navigate({ to: "/admin" });
								} else if (isBrand) {
									navigate({ to: "/dashboard" });
								} else {
									navigate({ to: "/scan" });
								}
							},
							"aria-label": t("nav.shield", { defaultValue: "Authenticity & Safety Shield" }),
							title: isAdmin ? "Admin & Brand Verification Portal" : isBrand ? "Brand Dashboard & Safety Shield" : "Brand Authenticity & Safety Shield",
							className: "relative h-8 w-8 shrink-0 text-foreground transition-colors hover:text-primary",
							"data-tsd-source": "/src/components/Header.tsx:219:11",
							children: /* @__PURE__ */ _jsxDEV(Shield, {
								className: "h-4 w-4 text-[#d6a928]",
								"data-tsd-source": "/src/components/Header.tsx:241:13"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 241,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 219,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(PWAInstallButton, { "data-tsd-source": "/src/components/Header.tsx:244:11" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 244,
							columnNumber: 11
						}, this),
						loading ? null : user ? /* @__PURE__ */ _jsxDEV("div", {
							className: "flex shrink-0 items-center gap-1.5",
							"data-tsd-source": "/src/components/Header.tsx:247:13",
							children: [
								/* @__PURE__ */ _jsxDEV(Button, {
									variant: "ghost",
									size: "icon",
									className: "relative h-8 w-8 shrink-0",
									onClick: () => navigate({ to: "/notifications" }),
									"aria-label": t("social.notifications", { defaultValue: "Notifications" }),
									title: t("social.notifications", { defaultValue: "Notifications" }),
									"data-tsd-source": "/src/components/Header.tsx:248:15",
									children: [/* @__PURE__ */ _jsxDEV(Bell, {
										className: "h-4 w-4",
										"data-tsd-source": "/src/components/Header.tsx:256:17"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 256,
										columnNumber: 17
									}, this), unreadNotifs > 0 && /* @__PURE__ */ _jsxDEV("span", {
										className: "absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-trash px-1 text-[10px] font-bold text-trash-foreground",
										"data-tsd-source": "/src/components/Header.tsx:258:19",
										children: unreadNotifs > 99 ? "99+" : unreadNotifs
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 258,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 248,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Button, {
									variant: "ghost",
									size: "icon",
									className: "relative h-8 w-8 shrink-0",
									onClick: () => navigate({ to: "/messages" }),
									"aria-label": t("nav.messages", { defaultValue: "Messages & Calling" }),
									title: t("nav.messages", { defaultValue: "Messages & Voice/Video Calls" }),
									"data-tsd-source": "/src/components/Header.tsx:263:15",
									children: [/* @__PURE__ */ _jsxDEV(MessageCircle, {
										className: "h-4 w-4",
										"data-tsd-source": "/src/components/Header.tsx:271:17"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 271,
										columnNumber: 17
									}, this), unread > 0 && /* @__PURE__ */ _jsxDEV("span", {
										className: "absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-trash px-1 text-[10px] font-bold text-white",
										"data-tsd-source": "/src/components/Header.tsx:273:19",
										children: unread > 99 ? "99+" : unread
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 273,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 263,
									columnNumber: 15
								}, this),
								persona !== "brand_owner" && /* @__PURE__ */ _jsxDEV(SubmitDialog, {
									onPosted,
									"data-tsd-source": "/src/components/Header.tsx:278:45"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 278,
									columnNumber: 45
								}, this),
								/* @__PURE__ */ _jsxDEV(UserProfile, {
									variant: "navbar",
									"data-tsd-source": "/src/components/Header.tsx:279:15"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 279,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 247,
							columnNumber: 13
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "flex shrink-0 items-center gap-1",
							"data-tsd-source": "/src/components/Header.tsx:282:13",
							children: [/* @__PURE__ */ _jsxDEV(Button, {
								variant: "ghost",
								size: "sm",
								className: "h-8 shrink-0 whitespace-nowrap px-2.5 text-xs font-semibold",
								onClick: () => navigate({ to: "/auth" }),
								"data-tsd-source": "/src/components/Header.tsx:283:15",
								children: t("nav.signIn", { defaultValue: "Sign in" })
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 283,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Button, {
								size: "sm",
								className: "h-8 shrink-0 whitespace-nowrap bg-slate-950 px-2.5 text-xs font-bold text-[#d6a928] hover:bg-slate-900",
								onClick: () => navigate({
									to: "/auth",
									search: { tab: "signup" }
								}),
								"data-tsd-source": "/src/components/Header.tsx:291:15",
								children: t("nav.signUp", { defaultValue: "Sign up" })
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 291,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 282,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 187,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 122,
				columnNumber: 7
			}, this),
			incomingCall && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-emerald-950 text-white border-b border-emerald-500/40 px-4 py-2.5 shadow-lg",
				"data-tsd-source": "/src/components/Header.tsx:305:9",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3",
					"data-tsd-source": "/src/components/Header.tsx:306:11",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2.5 text-xs sm:text-sm",
						"data-tsd-source": "/src/components/Header.tsx:307:13",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500 text-slate-950 animate-bounce",
							"data-tsd-source": "/src/components/Header.tsx:308:15",
							children: /* @__PURE__ */ _jsxDEV(PhoneIncoming, {
								className: "h-4 w-4",
								"data-tsd-source": "/src/components/Header.tsx:309:17"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 309,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 308,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							"data-tsd-source": "/src/components/Header.tsx:311:15",
							children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "font-display font-extrabold",
								"data-tsd-source": "/src/components/Header.tsx:312:17",
								children: [
									"Incoming ",
									incomingCall.mode === "voice_call" ? "Voice Call" : "Video Call",
									" from",
									" ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[#f5d061]",
										"data-tsd-source": "/src/components/Header.tsx:314:19",
										children: incomingCall.callerName
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 314,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 312,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-emerald-200",
								"data-tsd-source": "/src/components/Header.tsx:316:17",
								children: incomingCall.callDirection === "brand_to_user" ? `Brand Owner reaching out on SOT regarding ${incomingCall.brandName} (${incomingCall.topic})` : `Direct SOT User-to-User Call · Room: ${incomingCall.roomChannel}`
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 316,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 311,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 307,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						"data-tsd-source": "/src/components/Header.tsx:323:13",
						children: [/* @__PURE__ */ _jsxDEV(Button, {
							size: "sm",
							onClick: () => {
								setMessengerCallSession({
									roomChannel: incomingCall.roomChannel,
									partnerId: incomingCall.callerId,
									partnerName: incomingCall.callerName,
									isBrandCall: incomingCall.callDirection === "brand_to_user" || incomingCall.callDirection === "user_to_brand",
									brandName: incomingCall.brandName,
									mode: incomingCall.mode === "video_call" ? "video" : "voice",
									callDirection: incomingCall.callDirection
								});
								setIncomingCall(null);
								setMessengerCallOpen(true);
							},
							className: "h-8 gap-1.5 bg-emerald-500 text-slate-950 hover:bg-emerald-400 font-extrabold text-xs",
							"data-tsd-source": "/src/components/Header.tsx:324:15",
							children: [/* @__PURE__ */ _jsxDEV(PhoneIncoming, {
								className: "h-3.5 w-3.5",
								"data-tsd-source": "/src/components/Header.tsx:341:17"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 341,
								columnNumber: 17
							}, this), " Answer Private Call"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 324,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => setIncomingCall(null),
							className: "h-8 gap-1 border-white/30 bg-transparent text-white hover:bg-white/10 text-xs",
							"data-tsd-source": "/src/components/Header.tsx:343:15",
							children: [/* @__PURE__ */ _jsxDEV(PhoneOff, {
								className: "h-3.5 w-3.5",
								"data-tsd-source": "/src/components/Header.tsx:349:17"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 349,
								columnNumber: 17
							}, this), " Decline"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 343,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 323,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 306,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 305,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(ProductScannerModal, {
				open: scannerOpen,
				onOpenChange: setScannerOpen,
				onApplyToPost: handleApplyFromScanner,
				"data-tsd-source": "/src/components/Header.tsx:357:7"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 357,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(MessengerPrivateCallModal, {
				open: messengerCallOpen,
				onOpenChange: setMessengerCallOpen,
				session: messengerCallSession,
				onCallEnded: () => setMessengerCallSession(null),
				"data-tsd-source": "/src/components/Header.tsx:364:7"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 364,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(LiveBroadcastModal, {
				open: liveStudioOpen,
				onOpenChange: setLiveStudioOpen,
				brandName: activeCallPartner || "Direct User / Brand Call",
				defaultMode: activeCallMode,
				customRoomChannel: activeCallRoom,
				callDirection: isBrand ? "brand_to_user" : "user_to_user",
				"data-tsd-source": "/src/components/Header.tsx:372:7"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 372,
				columnNumber: 7
			}, this),
			prefilledPost && /* @__PURE__ */ _jsxDEV(SubmitDialog, {
				open: submitDialogOpen,
				onOpenChange: setSubmitDialogOpen,
				defaultBrandId: prefilledPost.matchedBrandId,
				initialValues: {
					title: `${prefilledPost.brandName} ${prefilledPost.productName || ""}`.trim(),
					description: `Brand: ${prefilledPost.brandName} | Corporate Owner: ${prefilledPost.brandOwner}\n${prefilledPost.scanResult.brandInfo.parentCompanyContext}\n[Forensic Authenticity Score: ${prefilledPost.scanResult.authenticity.score}% - ${prefilledPost.scanResult.authenticity.badgeLabel}]`,
					category: prefilledPost.category,
					file: prefilledPost.file || null,
					aiScanResult: prefilledPost.scanResult
				},
				onPosted,
				"data-tsd-source": "/src/components/Header.tsx:383:9"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 383,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 114,
		columnNumber: 5
	}, this);
}
_s(Header, "a6RoMFoIiHyHy/JILPIfRMGu8+k=", false, function() {
	return [
		useAuth,
		useRoles,
		useTranslation,
		useNavigate,
		useUnreadCount,
		useUnreadNotifications
	];
});
_c = Header;
var _c;
$RefreshReg$(_c, "Header");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Header.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/Header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/Header.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/Header.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQ0EsaUNBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBOzs7O0FBRUE7O0NBQ0E7Q0FDQTtDQUNBLHFFQUNBLGlDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0dBQ0E7R0FDQTtFQUNBO0NBQ0E7Q0FFQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTs7Q0FHQTtDQUNBOztDQUdBO0VBQ0E7RUFFQTtHQUNBO0dBQ0E7O0dBRUE7SUFDQTtHQUNBO0VBQ0E7RUFFQTtFQUNBO0dBQ0E7R0FDQTtFQUNBO0VBRUEsc0JBQ0EseUJBQ0E7R0FDQTtFQUNBLEdBQ0E7RUFFQTtHQUNBO0dBQ0E7RUFDQTtDQUNBO0NBQ0EsbURBUUE7Q0FFQSwyQ0FRQTtFQUNBO0VBQ0E7Q0FDQTtDQUVBLE9BQ0E7RUFDQTtFQUNBO0VBQ0E7WUFIQTtHQUtBLGtHQUF3Qjs7Ozs7R0FHeEI7SUFBQTtJQUFBO2NBQUEsQ0FDQTtLQUFBO0tBQUE7ZUFBQSxDQUNBO01BQUE7TUFBQTtNQUFBO2dCQUFBLENBQ0E7T0FDQTtPQUNBO09BQ0E7aUJBSEE7UUFJQTtTQUFBO1NBQUE7bUJBQTBDO1FBQUE7Ozs7O1FBQzFDO1NBQUE7bUJBQW1CO1FBQUE7Ozs7O1FBQ25CO1NBQUE7U0FBQTttQkFBMEM7UUFBQTs7Ozs7UUFDMUM7U0FBQTttQkFBbUI7UUFBQTs7Ozs7T0FDbkI7Ozs7O2dCQUNBO09BQUE7T0FBQTtNQUF1Rjs7OztjQUN2Rjs7Ozs7ZUFFQTtNQUFBO01BQUE7Z0JBQUE7T0FDQTtRQUNBO1FBQ0E7UUFDQTtrQkFDQTtPQUNBOzs7OztPQUNBO1FBQ0E7UUFDQTtRQUNBO2tCQUNBO09BQ0E7Ozs7O09BQ0EsNkJBQ0E7UUFDQTtRQUNBO1FBQ0E7a0JBSEEsQ0FJQTtTQUFBO1NBQUE7UUFBa0U7Ozs7a0JBQ2xFO1NBQUE7bUJBQXFCO1FBQUE7Ozs7Z0JBQ3JCOzs7Ozs7T0FFQTtRQUNBO1FBQ0E7UUFDQTtrQkFDQTtPQUNBOzs7OztPQUNBO1FBQ0E7UUFDQTtRQUNBO2tCQUNBO09BQ0E7Ozs7O09BQ0EsUUFDQTtRQUNBO1FBQ0E7UUFDQTtrQkFIQSxDQUlBO1NBQUE7U0FBQTtRQUE2RTs7OztrQkFDN0U7U0FBQTttQkFDQSw0QkFDQSxnQkFDQTtRQUNBOzs7O2dCQUNBOzs7Ozs7TUFFQTs7Ozs7YUFDQTs7Ozs7Y0FFQTtLQUFBO0tBQUE7ZUFBQTtNQUVBLGVBQ0E7T0FDQTtPQUNBO1FBQ0E7UUFDQTtPQUNBO09BQ0E7T0FDQSxjQUNBLDJJQUNBLDRCQUNBLGlEQUNBLGdGQUNBO09BQ0E7aUJBQ0EsNEJBQ0EsZ0RBQ0E7UUFBQTtRQUFBO09BQWdFOzs7O2lCQUNoRTtRQUFBO1FBQUE7a0JBQUEsQ0FBMEQ7Ozs7O2VBQzFEOzs7O2tCQUVBLGdEQUNBO1FBQUE7UUFBQTtPQUE0RDs7OztpQkFDNUQ7UUFBQTtrQkFBdUI7T0FBQTs7OztlQUN2Qjs7Ozs7TUFFQTs7Ozs7TUFJQTtPQUNBO09BQ0E7T0FDQTtRQUNBO1NBQ0E7UUFDQTtTQUNBO1FBQ0E7U0FDQTtRQUNBO09BQ0E7T0FDQTtPQUNBLE9BQ0EsVUFDQSxzQ0FDQSxVQUNBLG9DQUNBO09BRUE7T0FDQTtpQkFDQTtRQUFBO1FBQUE7T0FBdUQ7Ozs7O01BQ3ZEOzs7OztNQUVBLG1HQUE0Qjs7Ozs7TUFFNUIsd0JBQ0E7T0FBQTtPQUFBO2lCQUFBO1FBQ0E7U0FDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7U0FDQTttQkFQQSxDQVFBO1VBQUE7VUFBQTtTQUEwQzs7OzttQkFDMUMsb0JBQ0E7VUFBQTtVQUFBO29CQUNBO1NBQ0E7Ozs7aUJBRUE7Ozs7OztRQUNBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7bUJBUEEsQ0FRQTtVQUFBO1VBQUE7U0FBbUQ7Ozs7bUJBQ25ELGNBQ0E7VUFBQTtVQUFBO29CQUNBO1NBQ0E7Ozs7aUJBRUE7Ozs7OztRQUNBO1NBQUE7U0FBQTtRQUE4RTs7Ozs7UUFDOUU7U0FBQTtTQUFBO1FBQTRDOzs7OztPQUM1Qzs7Ozs7aUJBRUE7T0FBQTtPQUFBO2lCQUFBLENBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO2tCQUNBO09BQ0E7Ozs7aUJBQ0E7UUFDQTtRQUNBO1FBQ0E7U0FBQTtTQUFBO1FBQUE7UUFDQTtrQkFDQTtPQUNBOzs7O2VBQ0E7Ozs7OztLQUVBOzs7OztZQUNBOzs7Ozs7R0FHQSxnQkFDQTtJQUFBO0lBQUE7Y0FDQTtLQUFBO0tBQUE7ZUFBQSxDQUNBO01BQUE7TUFBQTtnQkFBQSxDQUNBO09BQUE7T0FBQTtpQkFDQTtRQUFBO1FBQUE7T0FBbUQ7Ozs7O01BQ25EOzs7O2dCQUNBO09BQUE7aUJBQUEsQ0FDQTtRQUFBO1FBQUE7a0JBQUE7U0FBMEQ7U0FDMUQ7U0FBQTtTQUFBO1NBQ0E7VUFBQTtVQUFBO29CQUFrRDtTQUFBOzs7OztRQUNsRDs7Ozs7aUJBQ0E7UUFBQTtRQUFBO2tCQUNBLGlEQUNBLGdHQUNBO09BQ0E7Ozs7ZUFDQTs7Ozs7Y0FDQTs7Ozs7ZUFDQTtNQUFBO01BQUE7Z0JBQUEsQ0FDQTtPQUNBO09BQ0E7UUFDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1FBQ0E7UUFDQTtRQUNBO09BQ0E7T0FDQTtPQUNBO2lCQWhCQSxDQWlCQTtRQUFBO1FBQUE7T0FBdUQ7Ozs7aUJBQUEsc0JBQ3ZEOzs7OztnQkFDQTtPQUNBO09BQ0E7T0FDQTtPQUNBO09BQ0E7aUJBTEEsQ0FNQTtRQUFBO1FBQUE7T0FBa0Q7Ozs7aUJBQUEsVUFDbEQ7Ozs7O2NBQ0E7Ozs7O2FBQ0E7Ozs7OztHQUNBOzs7OztHQUlBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FBTTs7Ozs7R0FHTjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FBTTs7Ozs7R0FHTjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQU07Ozs7O0dBR04saUJBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtLQUNBO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FBUTs7Ozs7RUFFUjs7Ozs7O0FBRUEiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkhlYWRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXJvdXRlclwiO1xuaW1wb3J0IHsgdXNlVHJhbnNsYXRpb24gfSBmcm9tIFwicmVhY3QtaTE4bmV4dFwiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCJAL2hvb2tzL3VzZUF1dGhcIjtcbmltcG9ydCB7IHVzZVJvbGVzIH0gZnJvbSBcIkAvaG9va3MvdXNlUm9sZXNcIjtcbmltcG9ydCB7IHVzZVVucmVhZENvdW50IH0gZnJvbSBcIkAvaG9va3MvdXNlVW5yZWFkQ291bnRcIjtcbmltcG9ydCB7IHVzZVVucmVhZE5vdGlmaWNhdGlvbnMgfSBmcm9tIFwiQC9ob29rcy91c2VVbnJlYWROb3RpZmljYXRpb25zXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuaW1wb3J0IHsgU3VibWl0RGlhbG9nIH0gZnJvbSBcIkAvY29tcG9uZW50cy9TdWJtaXREaWFsb2dcIjtcbmltcG9ydCB7IFByb2R1Y3RTY2FubmVyTW9kYWwgfSBmcm9tIFwiQC9jb21wb25lbnRzL1Byb2R1Y3RTY2FubmVyTW9kYWxcIjtcbmltcG9ydCB7IExpdmVCcm9hZGNhc3RNb2RhbCwgdHlwZSBJbmNvbWluZ1NvdENhbGxQYXlsb2FkIH0gZnJvbSBcIkAvY29tcG9uZW50cy9MaXZlQnJvYWRjYXN0TW9kYWxcIjtcbmltcG9ydCB7XG4gIE1lc3NlbmdlclByaXZhdGVDYWxsTW9kYWwsXG4gIHR5cGUgTWVzc2VuZ2VyQ2FsbFNlc3Npb24sXG59IGZyb20gXCJAL2NvbXBvbmVudHMvTWVzc2VuZ2VyUHJpdmF0ZUNhbGxNb2RhbFwiO1xuaW1wb3J0IHsgTGFuZ3VhZ2VTd2l0Y2hlciwgVG9wTGFuZ3VhZ2VTdHJpcCB9IGZyb20gXCJAL2NvbXBvbmVudHMvTGFuZ3VhZ2VTd2l0Y2hlclwiO1xuaW1wb3J0IHsgVXNlclByb2ZpbGUsIGdldEFjY291bnRQcmVmZXJlbmNlcyB9IGZyb20gXCJAL2NvbXBvbmVudHMvVXNlclByb2ZpbGVcIjtcbmltcG9ydCB7IFBXQUluc3RhbGxCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL1BXQUluc3RhbGxCdXR0b25cIjtcbmltcG9ydCB7IEJlbGwsIEJ1aWxkaW5nMiwgQ29pbnMsIExheW91dERhc2hib2FyZCwgTWVzc2FnZUNpcmNsZSwgU2hpZWxkLCBTY2FuLCBQaG9uZUluY29taW5nLCBQaG9uZU9mZiB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IFNvdFdvcmRtYXJrIH0gZnJvbSBcIkAvY29tcG9uZW50cy9Tb3RXb3JkbWFya1wiO1xuaW1wb3J0IHsgZ2V0UmVnaXN0ZXJlZEJyYW5kSWRlbnRpdHkgfSBmcm9tIFwiQC9saWIvYnJhbmQtb3BlcmF0b3JzXCI7XG5pbXBvcnQgeyBzdXBhYmFzZSB9IGZyb20gXCJAL2ludGVncmF0aW9ucy9zdXBhYmFzZS9jbGllbnRcIjtcbmltcG9ydCB0eXBlIHsgQWlTY2FuUmVzdWx0IH0gZnJvbSBcIkAvbGliL2FpLXNjYW5uZXJcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBIZWFkZXIoeyBvblBvc3RlZCB9OiB7IG9uUG9zdGVkPzogKCkgPT4gdm9pZCB9KSB7XG4gIGNvbnN0IHsgdXNlciwgbG9hZGluZyB9ID0gdXNlQXV0aCgpO1xuICBjb25zdCB7IGlzQWRtaW4sIGlzRGV2ZWxvcGVyLCBpc0JyYW5kLCBwZXJzb25hLCBzZXRQZXJzb25hIH0gPSB1c2VSb2xlcygpO1xuICBjb25zdCBbcmVnaXN0ZXJlZEJyYW5kTmFtZSwgc2V0UmVnaXN0ZXJlZEJyYW5kTmFtZV0gPSB1c2VTdGF0ZShcbiAgICAoKSA9PiBnZXRSZWdpc3RlcmVkQnJhbmRJZGVudGl0eSgpLm5hbWUsXG4gICk7XG4gIGNvbnN0IHsgdCB9ID0gdXNlVHJhbnNsYXRpb24oKTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICBjb25zdCB1bnJlYWQgPSB1c2VVbnJlYWRDb3VudCh1c2VyPy5pZCk7XG4gIGNvbnN0IHVucmVhZE5vdGlmcyA9IHVzZVVucmVhZE5vdGlmaWNhdGlvbnModXNlcj8uaWQpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgc3luY0JyYW5kID0gKCkgPT4gc2V0UmVnaXN0ZXJlZEJyYW5kTmFtZShnZXRSZWdpc3RlcmVkQnJhbmRJZGVudGl0eSgpLm5hbWUpO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwic290LXJlZ2lzdGVyZWQtYnJhbmQtdXBkYXRlZFwiLCBzeW5jQnJhbmQpO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwic290LWJyYW5kLW9wZXJhdG9yLXVwZGF0ZWRcIiwgc3luY0JyYW5kKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJzb3QtcmVnaXN0ZXJlZC1icmFuZC11cGRhdGVkXCIsIHN5bmNCcmFuZCk7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInNvdC1icmFuZC1vcGVyYXRvci11cGRhdGVkXCIsIHN5bmNCcmFuZCk7XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IFtzY2FubmVyT3Blbiwgc2V0U2Nhbm5lck9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbbGl2ZVN0dWRpb09wZW4sIHNldExpdmVTdHVkaW9PcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2luY29taW5nQ2FsbCwgc2V0SW5jb21pbmdDYWxsXSA9IHVzZVN0YXRlPEluY29taW5nU290Q2FsbFBheWxvYWQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2FjdGl2ZUNhbGxSb29tLCBzZXRBY3RpdmVDYWxsUm9vbV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG4gIGNvbnN0IFthY3RpdmVDYWxsTW9kZSwgc2V0QWN0aXZlQ2FsbE1vZGVdID0gdXNlU3RhdGU8XCJicm9hZGNhc3RcIiB8IFwidmlkZW9fY2FsbFwiIHwgXCJ2b2ljZV9jYWxsXCI+KFwidmlkZW9fY2FsbFwiKTtcbiAgY29uc3QgW2FjdGl2ZUNhbGxQYXJ0bmVyLCBzZXRBY3RpdmVDYWxsUGFydG5lcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG4gIGNvbnN0IFtzdWJtaXREaWFsb2dPcGVuLCBzZXRTdWJtaXREaWFsb2dPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyBQcml2YXRlIDEtb24tMSBNZXNzZW5nZXIgQ2FsbCBzdGF0ZXNcbiAgY29uc3QgW21lc3NlbmdlckNhbGxPcGVuLCBzZXRNZXNzZW5nZXJDYWxsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFttZXNzZW5nZXJDYWxsU2Vzc2lvbiwgc2V0TWVzc2VuZ2VyQ2FsbFNlc3Npb25dID0gdXNlU3RhdGU8TWVzc2VuZ2VyQ2FsbFNlc3Npb24gfCBudWxsPihudWxsKTtcblxuICAvLyBMaXN0ZW4gZm9yIHJlYWwtdGltZSBCcmFuZC10by1Vc2VyIGFuZCBVc2VyLXRvLVVzZXIgaW5jb21pbmcgY2FsbHMgb24gU09UXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybjtcblxuICAgIGNvbnN0IGhhbmRsZUluY29taW5nID0gKHBheWxvYWQ6IEluY29taW5nU290Q2FsbFBheWxvYWQpID0+IHtcbiAgICAgIGlmICghcGF5bG9hZCB8fCAhcGF5bG9hZC5yb29tQ2hhbm5lbCkgcmV0dXJuO1xuICAgICAgaWYgKCFnZXRBY2NvdW50UHJlZmVyZW5jZXMoKS5jYWxsUmluZ0FsZXJ0cykgcmV0dXJuO1xuICAgICAgLy8gU2hvdyByaW5nIGJhbm5lciBpZiB0YXJnZXRlZCB0byB0aGlzIHVzZXIsIG9yIGlmIHRlc3RpbmcgaW4gYW5vdGhlciB0YWJcbiAgICAgIGlmICghdXNlcj8uaWQgfHwgcGF5bG9hZC5yZWNpcGllbnRJZCA9PT0gdXNlci5pZCB8fCBwYXlsb2FkLmNhbGxlcklkICE9PSB1c2VyLmlkKSB7XG4gICAgICAgIHNldEluY29taW5nQ2FsbChwYXlsb2FkKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgbGV0IGJjOiBCcm9hZGNhc3RDaGFubmVsIHwgbnVsbCA9IG51bGw7XG4gICAgaWYgKHR5cGVvZiBCcm9hZGNhc3RDaGFubmVsICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICBiYyA9IG5ldyBCcm9hZGNhc3RDaGFubmVsKFwic290LWNhbGwtcmluZ1wiKTtcbiAgICAgIGJjLm9ubWVzc2FnZSA9IChldikgPT4gaGFuZGxlSW5jb21pbmcoZXYuZGF0YSBhcyBJbmNvbWluZ1NvdENhbGxQYXlsb2FkKTtcbiAgICB9XG5cbiAgICBjb25zdCBjaGFuID0gc3VwYWJhc2VcbiAgICAgIC5jaGFubmVsKFwic290LWNhbGwtcmluZ1wiKVxuICAgICAgLm9uKFwiYnJvYWRjYXN0XCIsIHsgZXZlbnQ6IFwiaW5jb21pbmctY2FsbFwiIH0sICh7IHBheWxvYWQgfSkgPT4ge1xuICAgICAgICBpZiAocGF5bG9hZCkgaGFuZGxlSW5jb21pbmcocGF5bG9hZCBhcyBJbmNvbWluZ1NvdENhbGxQYXlsb2FkKTtcbiAgICAgIH0pXG4gICAgICAuc3Vic2NyaWJlKCk7XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgYmM/LmNsb3NlKCk7XG4gICAgICB2b2lkIHN1cGFiYXNlLnJlbW92ZUNoYW5uZWwoY2hhbik7XG4gICAgfTtcbiAgfSwgW3VzZXI/LmlkXSk7XG4gIGNvbnN0IFtwcmVmaWxsZWRQb3N0LCBzZXRQcmVmaWxsZWRQb3N0XSA9IHVzZVN0YXRlPHtcbiAgICBicmFuZE5hbWU6IHN0cmluZztcbiAgICBicmFuZE93bmVyOiBzdHJpbmc7XG4gICAgcHJvZHVjdE5hbWU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIG1hdGNoZWRCcmFuZElkPzogc3RyaW5nO1xuICAgIGZpbGU/OiBGaWxlIHwgbnVsbDtcbiAgICBzY2FuUmVzdWx0OiBBaVNjYW5SZXN1bHQ7XG4gIH0gfCBudWxsPihudWxsKTtcblxuICBjb25zdCBoYW5kbGVBcHBseUZyb21TY2FubmVyID0gKHBhcmFtczoge1xuICAgIGJyYW5kTmFtZTogc3RyaW5nO1xuICAgIGJyYW5kT3duZXI6IHN0cmluZztcbiAgICBwcm9kdWN0TmFtZTogc3RyaW5nO1xuICAgIGNhdGVnb3J5OiBzdHJpbmc7XG4gICAgbWF0Y2hlZEJyYW5kSWQ/OiBzdHJpbmc7XG4gICAgZmlsZT86IEZpbGUgfCBudWxsO1xuICAgIHNjYW5SZXN1bHQ6IEFpU2NhblJlc3VsdDtcbiAgfSkgPT4ge1xuICAgIHNldFByZWZpbGxlZFBvc3QocGFyYW1zKTtcbiAgICBzZXRTdWJtaXREaWFsb2dPcGVuKHRydWUpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGhlYWRlclxuICAgICAgc3VwcHJlc3NIeWRyYXRpb25XYXJuaW5nXG4gICAgICBjbGFzc05hbWU9XCJzdGlja3kgdG9wLTAgei00MCB3LWZ1bGwgYm9yZGVyLWIgYm9yZGVyLWJvcmRlci83MCBiZy1iYWNrZ3JvdW5kLzk1IGJhY2tkcm9wLWJsdXIteGxcIlxuICAgID5cbiAgICAgIHsvKiBUb3AgTGFuZ3VhZ2UgU3dpdGNoZXIgU3RyaXAgZm9yIHN1cHBvcnRlZCBsb2NhbGVzIGluIHNyYy9saWIvbG9jYWxlLWFwcC50cyAqL31cbiAgICAgIDxUb3BMYW5ndWFnZVN0cmlwIC8+XG5cbiAgICAgIHsvKiBDb21wYWN0IFNpbmdsZS1MaW5lIE5hdmJhciDigJQgZXZlcnl0aGluZyBmaXRzIGNsZWFubHkgb24gb25lIGxpbmUgd2l0aCB6ZXJvIHdyYXBwaW5nICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIGZsZXggaC0xNCB3LWZ1bGwgbWF4LXctWzE0NDBweF0gaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiBweC0zIHNtOnB4LTUgbGc6cHgtNlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLXctMCBmbGV4LTEgaXRlbXMtY2VudGVyIGdhcC0yLjUgbGc6Z2FwLTRcIj5cbiAgICAgICAgICA8TGluayB0bz1cIi9cIiBjbGFzc05hbWU9XCJncm91cCBmbGV4IHNocmluay0wIGl0ZW1zLWNlbnRlciBnYXAtMiB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlNPclQg4oCUIFN0YXNoIE9yIFRyYXNoIGxvZ29cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGgtOCB3LTggc2hyaW5rLTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1mb3JlZ3JvdW5kIHRleHQteHMgZm9udC1leHRyYWJvbGQgdHJhY2tpbmctWy0wLjEyZW1dIHRleHQtYmFja2dyb3VuZCBzaGFkb3ctc20gdHJhbnNpdGlvbi10cmFuc2Zvcm0gZ3JvdXAtaG92ZXI6c2NhbGUtMTA1XCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zdGFzaFwiPlM8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuPk88L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtdHJhc2hcIj5yPC9zcGFuPlxuICAgICAgICAgICAgICA8c3Bhbj5UPC9zcGFuPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPFNvdFdvcmRtYXJrIGNsYXNzTmFtZT1cImhpZGRlbiB4bDppbmxpbmUtZmxleCB0ZXh0LWJhc2Ugd2hpdGVzcGFjZS1ub3dyYXBcIiAvPlxuICAgICAgICAgIDwvTGluaz5cblxuICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiZmxleCBtaW4tdy0wIGl0ZW1zLWNlbnRlciBnYXAtMC41IG92ZXJmbG93LXgtYXV0byB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgbm8tc2Nyb2xsYmFyIHNtOmdhcC0xXCI+XG4gICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICB0bz1cIi9cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzaHJpbmstMCB3aGl0ZXNwYWNlLW5vd3JhcCByb3VuZGVkLW1kIHB4LTIgcHktMSB0ZXh0LW11dGVkLWZvcmVncm91bmQgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6Ymctc2Vjb25kYXJ5LzYwIGhvdmVyOnRleHQtZm9yZWdyb3VuZCBbJi5hY3RpdmVdOmJnLXNlY29uZGFyeSBbJi5hY3RpdmVdOnRleHQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHt0KFwibmF2LmhvbWVcIiwgeyBkZWZhdWx0VmFsdWU6IFwiSG9tZVwiIH0pfVxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgdG89XCIvZmVlZFwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNocmluay0wIHdoaXRlc3BhY2Utbm93cmFwIHJvdW5kZWQtbWQgcHgtMiBweS0xIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCB0cmFuc2l0aW9uLWNvbG9ycyBob3ZlcjpiZy1zZWNvbmRhcnkvNjAgaG92ZXI6dGV4dC1mb3JlZ3JvdW5kIFsmLmFjdGl2ZV06Ymctc2Vjb25kYXJ5IFsmLmFjdGl2ZV06dGV4dC1mb3JlZ3JvdW5kXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3QoXCJuYXYuZmVlZFwiLCB7IGRlZmF1bHRWYWx1ZTogXCJGZWVkXCIgfSl9XG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICB7cGVyc29uYSAhPT0gXCJicmFuZF9vd25lclwiICYmIChcbiAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICB0bz1cIi9zY2FuXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHNocmluay0wIGl0ZW1zLWNlbnRlciBnYXAtMSB3aGl0ZXNwYWNlLW5vd3JhcCByb3VuZGVkLW1kIHB4LTIgcHktMSB0ZXh0LW11dGVkLWZvcmVncm91bmQgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6Ymctc2Vjb25kYXJ5LzYwIGhvdmVyOnRleHQtZm9yZWdyb3VuZCBbJi5hY3RpdmVdOmJnLXNlY29uZGFyeSBbJi5hY3RpdmVdOnRleHQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8U2NhbiBjbGFzc05hbWU9XCJoLTMgdy0zIHNocmluay0wIHRleHQtWyNkNmE5MjhdXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj57dChcIm5hdi5zY2FuXCIsIHsgZGVmYXVsdFZhbHVlOiBcIlNjYW5cIiB9KX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICB0bz1cIi9icmFuZHNcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzaHJpbmstMCB3aGl0ZXNwYWNlLW5vd3JhcCByb3VuZGVkLW1kIHB4LTIgcHktMSB0ZXh0LW11dGVkLWZvcmVncm91bmQgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6Ymctc2Vjb25kYXJ5LzYwIGhvdmVyOnRleHQtZm9yZWdyb3VuZCBbJi5hY3RpdmVdOmJnLXNlY29uZGFyeSBbJi5hY3RpdmVdOnRleHQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHt0KFwibmF2LmJyYW5kc1wiLCB7IGRlZmF1bHRWYWx1ZTogXCJCcmFuZHNcIiB9KX1cbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgIHRvPVwiL2F3YXJkc1wiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNocmluay0wIHdoaXRlc3BhY2Utbm93cmFwIHJvdW5kZWQtbWQgcHgtMiBweS0xIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCB0cmFuc2l0aW9uLWNvbG9ycyBob3ZlcjpiZy1zZWNvbmRhcnkvNjAgaG92ZXI6dGV4dC1mb3JlZ3JvdW5kIFsmLmFjdGl2ZV06Ymctc2Vjb25kYXJ5IFsmLmFjdGl2ZV06dGV4dC1mb3JlZ3JvdW5kXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3QoXCJuYXYuYXdhcmRzXCIsIHsgZGVmYXVsdFZhbHVlOiBcIkF3YXJkc1wiIH0pfVxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAge3VzZXIgJiYgKFxuICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgIHRvPVwiL2Rhc2hib2FyZFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBzaHJpbmstMCBpdGVtcy1jZW50ZXIgZ2FwLTEgd2hpdGVzcGFjZS1ub3dyYXAgcm91bmRlZC1tZCBweC0yIHB5LTEgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJnLXNlY29uZGFyeS82MCBob3Zlcjp0ZXh0LWZvcmVncm91bmQgWyYuYWN0aXZlXTpiZy1zZWNvbmRhcnkgWyYuYWN0aXZlXTp0ZXh0LWZvcmVncm91bmRcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPExheW91dERhc2hib2FyZCBjbGFzc05hbWU9XCJoLTMgdy0zIHNocmluay0wIHRleHQtWyNkNmE5MjhdXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtwZXJzb25hID09PSBcImJyYW5kX293bmVyXCJcbiAgICAgICAgICAgICAgICAgICAgPyBcIkJyYW5kIFN1aXRlXCJcbiAgICAgICAgICAgICAgICAgICAgOiB0KFwibmF2LmRhc2hib2FyZFwiLCB7IGRlZmF1bHRWYWx1ZTogXCJNeSBIdWJcIiB9KX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9uYXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzaHJpbmstMCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgIHsvKiBERVZFTE9QRVItT05MWSBQUkVWSUVXIFNXSVRDSEVSOiBIaWRkZW4gZnJvbSBhbGwgUGVyc29uYWwgVXNlcnMgJiBCcmFuZCBPd25lcnMgKi99XG4gICAgICAgICAge2lzRGV2ZWxvcGVyICYmIChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBuZXh0ID0gcGVyc29uYSA9PT0gXCJicmFuZF9vd25lclwiID8gXCJjb25zdW1lclwiIDogXCJicmFuZF9vd25lclwiO1xuICAgICAgICAgICAgICAgIHNldFBlcnNvbmEobmV4dCk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIHRpdGxlPVwiRGV2ZWxvcGVyLU9ubHkgVmlldyBTd2l0Y2hlciAoQWxzbyBhdmFpbGFibGUgaW5zaWRlIHlvdXIgVXNlclByb2ZpbGUgbWVudSlcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgIFwiaGlkZGVuIHhsOmlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSByb3VuZGVkLW1kIGJvcmRlciBweC0yIHB5LTEgdGV4dC1bMTFweF0gZm9udC1ibGFjayB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyIHdoaXRlc3BhY2Utbm93cmFwXCIsXG4gICAgICAgICAgICAgICAgcGVyc29uYSA9PT0gXCJicmFuZF9vd25lclwiXG4gICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLVsjZDZhOTI4XSBiZy1zbGF0ZS05NTAgdGV4dC1bI2Y1ZDA2MV1cIlxuICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci1lbWVyYWxkLTYwMC80MCBiZy1lbWVyYWxkLTUwMC8xMCB0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTMwMFwiLFxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7cGVyc29uYSA9PT0gXCJicmFuZF9vd25lclwiID8gKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8QnVpbGRpbmcyIGNsYXNzTmFtZT1cImgtMyB3LTMgdGV4dC1bI2Q2YTkyOF1cIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF4LXctWzEwMHB4XSB0cnVuY2F0ZVwiPkRFVjoge3JlZ2lzdGVyZWRCcmFuZE5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8Q29pbnMgY2xhc3NOYW1lPVwiaC0zIHctMyB0ZXh0LVsjZDZhOTI4XVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5ERVY6IFBlcnNvbmFsPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBBdXRoZW50aWNpdHkgJiBTYWZldHkgU2hpZWxkIEljb24gKi99XG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcbiAgICAgICAgICAgIHNpemU9XCJpY29uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgaWYgKGlzQWRtaW4pIHtcbiAgICAgICAgICAgICAgICBuYXZpZ2F0ZSh7IHRvOiBcIi9hZG1pblwiIH0pO1xuICAgICAgICAgICAgICB9IGVsc2UgaWYgKGlzQnJhbmQpIHtcbiAgICAgICAgICAgICAgICBuYXZpZ2F0ZSh7IHRvOiBcIi9kYXNoYm9hcmRcIiB9KTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBuYXZpZ2F0ZSh7IHRvOiBcIi9zY2FuXCIgfSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBhcmlhLWxhYmVsPXt0KFwibmF2LnNoaWVsZFwiLCB7IGRlZmF1bHRWYWx1ZTogXCJBdXRoZW50aWNpdHkgJiBTYWZldHkgU2hpZWxkXCIgfSl9XG4gICAgICAgICAgICB0aXRsZT17XG4gICAgICAgICAgICAgIGlzQWRtaW5cbiAgICAgICAgICAgICAgICA/IFwiQWRtaW4gJiBCcmFuZCBWZXJpZmljYXRpb24gUG9ydGFsXCJcbiAgICAgICAgICAgICAgICA6IGlzQnJhbmRcbiAgICAgICAgICAgICAgICAgID8gXCJCcmFuZCBEYXNoYm9hcmQgJiBTYWZldHkgU2hpZWxkXCJcbiAgICAgICAgICAgICAgICAgIDogXCJCcmFuZCBBdXRoZW50aWNpdHkgJiBTYWZldHkgU2hpZWxkXCJcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtOCB3LTggc2hyaW5rLTAgdGV4dC1mb3JlZ3JvdW5kIHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOnRleHQtcHJpbWFyeVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFNoaWVsZCBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtWyNkNmE5MjhdXCIgLz5cbiAgICAgICAgICA8L0J1dHRvbj5cblxuICAgICAgICAgIDxQV0FJbnN0YWxsQnV0dG9uIC8+XG5cbiAgICAgICAgICB7bG9hZGluZyA/IG51bGwgOiB1c2VyID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNocmluay0wIGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgICAgICAgIHNpemU9XCJpY29uXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBoLTggdy04IHNocmluay0wXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSh7IHRvOiBcIi9ub3RpZmljYXRpb25zXCIgfSl9XG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17dChcInNvY2lhbC5ub3RpZmljYXRpb25zXCIsIHsgZGVmYXVsdFZhbHVlOiBcIk5vdGlmaWNhdGlvbnNcIiB9KX1cbiAgICAgICAgICAgICAgICB0aXRsZT17dChcInNvY2lhbC5ub3RpZmljYXRpb25zXCIsIHsgZGVmYXVsdFZhbHVlOiBcIk5vdGlmaWNhdGlvbnNcIiB9KX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxCZWxsIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgIHt1bnJlYWROb3RpZnMgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIC1yaWdodC0wLjUgLXRvcC0wLjUgZmxleCBoLTQgbWluLXctNCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLXRyYXNoIHB4LTEgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtdHJhc2gtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICB7dW5yZWFkTm90aWZzID4gOTkgPyBcIjk5K1wiIDogdW5yZWFkTm90aWZzfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcbiAgICAgICAgICAgICAgICBzaXplPVwiaWNvblwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgaC04IHctOCBzaHJpbmstMFwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoeyB0bzogXCIvbWVzc2FnZXNcIiB9KX1cbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXt0KFwibmF2Lm1lc3NhZ2VzXCIsIHsgZGVmYXVsdFZhbHVlOiBcIk1lc3NhZ2VzICYgQ2FsbGluZ1wiIH0pfVxuICAgICAgICAgICAgICAgIHRpdGxlPXt0KFwibmF2Lm1lc3NhZ2VzXCIsIHsgZGVmYXVsdFZhbHVlOiBcIk1lc3NhZ2VzICYgVm9pY2UvVmlkZW8gQ2FsbHNcIiB9KX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxNZXNzYWdlQ2lyY2xlIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgIHt1bnJlYWQgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIC1yaWdodC0wLjUgLXRvcC0wLjUgZmxleCBoLTQgbWluLXctNCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLXRyYXNoIHB4LTEgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAge3VucmVhZCA+IDk5ID8gXCI5OStcIiA6IHVucmVhZH1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAge3BlcnNvbmEgIT09IFwiYnJhbmRfb3duZXJcIiAmJiA8U3VibWl0RGlhbG9nIG9uUG9zdGVkPXtvblBvc3RlZH0gLz59XG4gICAgICAgICAgICAgIDxVc2VyUHJvZmlsZSB2YXJpYW50PVwibmF2YmFyXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc2hyaW5rLTAgaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHNocmluay0wIHdoaXRlc3BhY2Utbm93cmFwIHB4LTIuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKHsgdG86IFwiL2F1dGhcIiB9KX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHt0KFwibmF2LnNpZ25JblwiLCB7IGRlZmF1bHRWYWx1ZTogXCJTaWduIGluXCIgfSl9XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggc2hyaW5rLTAgd2hpdGVzcGFjZS1ub3dyYXAgYmctc2xhdGUtOTUwIHB4LTIuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LVsjZDZhOTI4XSBob3ZlcjpiZy1zbGF0ZS05MDBcIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKHsgdG86IFwiL2F1dGhcIiwgc2VhcmNoOiB7IHRhYjogXCJzaWdudXBcIiB9IH0pfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3QoXCJuYXYuc2lnblVwXCIsIHsgZGVmYXVsdFZhbHVlOiBcIlNpZ24gdXBcIiB9KX1cbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUmVhbC1UaW1lIEluY29taW5nIEJyYW5kLXRvLVVzZXIgLyBVc2VyLXRvLVVzZXIgQ2FsbCBBbGVydCBCYW5uZXIgKi99XG4gICAgICB7aW5jb21pbmdDYWxsICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTk1MCB0ZXh0LXdoaXRlIGJvcmRlci1iIGJvcmRlci1lbWVyYWxkLTUwMC80MCBweC00IHB5LTIuNSBzaGFkb3ctbGdcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gZmxleCBtYXgtdy02eGwgZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSB0ZXh0LXhzIHNtOnRleHQtc21cIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBoLTggdy04IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC01MDAgdGV4dC1zbGF0ZS05NTAgYW5pbWF0ZS1ib3VuY2VcIj5cbiAgICAgICAgICAgICAgICA8UGhvbmVJbmNvbWluZyBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSBmb250LWV4dHJhYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgSW5jb21pbmcge2luY29taW5nQ2FsbC5tb2RlID09PSBcInZvaWNlX2NhbGxcIiA/IFwiVm9pY2UgQ2FsbFwiIDogXCJWaWRlbyBDYWxsXCJ9IGZyb217XCIgXCJ9XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjZjVkMDYxXVwiPntpbmNvbWluZ0NhbGwuY2FsbGVyTmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZW1lcmFsZC0yMDBcIj5cbiAgICAgICAgICAgICAgICAgIHtpbmNvbWluZ0NhbGwuY2FsbERpcmVjdGlvbiA9PT0gXCJicmFuZF90b191c2VyXCJcbiAgICAgICAgICAgICAgICAgICAgPyBgQnJhbmQgT3duZXIgcmVhY2hpbmcgb3V0IG9uIFNPVCByZWdhcmRpbmcgJHtpbmNvbWluZ0NhbGwuYnJhbmROYW1lfSAoJHtpbmNvbWluZ0NhbGwudG9waWN9KWBcbiAgICAgICAgICAgICAgICAgICAgOiBgRGlyZWN0IFNPVCBVc2VyLXRvLVVzZXIgQ2FsbCDCtyBSb29tOiAke2luY29taW5nQ2FsbC5yb29tQ2hhbm5lbH1gfVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgc2V0TWVzc2VuZ2VyQ2FsbFNlc3Npb24oe1xuICAgICAgICAgICAgICAgICAgICByb29tQ2hhbm5lbDogaW5jb21pbmdDYWxsLnJvb21DaGFubmVsLFxuICAgICAgICAgICAgICAgICAgICBwYXJ0bmVySWQ6IGluY29taW5nQ2FsbC5jYWxsZXJJZCxcbiAgICAgICAgICAgICAgICAgICAgcGFydG5lck5hbWU6IGluY29taW5nQ2FsbC5jYWxsZXJOYW1lLFxuICAgICAgICAgICAgICAgICAgICBpc0JyYW5kQ2FsbDogaW5jb21pbmdDYWxsLmNhbGxEaXJlY3Rpb24gPT09IFwiYnJhbmRfdG9fdXNlclwiIHx8IGluY29taW5nQ2FsbC5jYWxsRGlyZWN0aW9uID09PSBcInVzZXJfdG9fYnJhbmRcIixcbiAgICAgICAgICAgICAgICAgICAgYnJhbmROYW1lOiBpbmNvbWluZ0NhbGwuYnJhbmROYW1lLFxuICAgICAgICAgICAgICAgICAgICBtb2RlOiBpbmNvbWluZ0NhbGwubW9kZSA9PT0gXCJ2aWRlb19jYWxsXCIgPyBcInZpZGVvXCIgOiBcInZvaWNlXCIsXG4gICAgICAgICAgICAgICAgICAgIGNhbGxEaXJlY3Rpb246IGluY29taW5nQ2FsbC5jYWxsRGlyZWN0aW9uLFxuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICBzZXRJbmNvbWluZ0NhbGwobnVsbCk7XG4gICAgICAgICAgICAgICAgICBzZXRNZXNzZW5nZXJDYWxsT3Blbih0cnVlKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOCBnYXAtMS41IGJnLWVtZXJhbGQtNTAwIHRleHQtc2xhdGUtOTUwIGhvdmVyOmJnLWVtZXJhbGQtNDAwIGZvbnQtZXh0cmFib2xkIHRleHQteHNcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFBob25lSW5jb21pbmcgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPiBBbnN3ZXIgUHJpdmF0ZSBDYWxsXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SW5jb21pbmdDYWxsKG51bGwpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOCBnYXAtMSBib3JkZXItd2hpdGUvMzAgYmctdHJhbnNwYXJlbnQgdGV4dC13aGl0ZSBob3ZlcjpiZy13aGl0ZS8xMCB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxQaG9uZU9mZiBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+IERlY2xpbmVcbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogR2xvYmFsIFByb2R1Y3QgU2Nhbm5lciBNb2RhbCAqL31cbiAgICAgIDxQcm9kdWN0U2Nhbm5lck1vZGFsXG4gICAgICAgIG9wZW49e3NjYW5uZXJPcGVufVxuICAgICAgICBvbk9wZW5DaGFuZ2U9e3NldFNjYW5uZXJPcGVufVxuICAgICAgICBvbkFwcGx5VG9Qb3N0PXtoYW5kbGVBcHBseUZyb21TY2FubmVyfVxuICAgICAgLz5cblxuICAgICAgey8qIE1lc3Nlbmdlci1TdHlsZSBQcml2YXRlIDEtb24tMSBDYWxsIFdpbmRvdyAqL31cbiAgICAgIDxNZXNzZW5nZXJQcml2YXRlQ2FsbE1vZGFsXG4gICAgICAgIG9wZW49e21lc3NlbmdlckNhbGxPcGVufVxuICAgICAgICBvbk9wZW5DaGFuZ2U9e3NldE1lc3NlbmdlckNhbGxPcGVufVxuICAgICAgICBzZXNzaW9uPXttZXNzZW5nZXJDYWxsU2Vzc2lvbn1cbiAgICAgICAgb25DYWxsRW5kZWQ9eygpID0+IHNldE1lc3NlbmdlckNhbGxTZXNzaW9uKG51bGwpfVxuICAgICAgLz5cblxuICAgICAgey8qIEdsb2JhbCBWb2ljZSAvIFZpZGVvIENhbGwgJiBMaXZlIFNpdHVhdGlvbiBCcm9hZGNhc3QgTW9kYWwgKi99XG4gICAgICA8TGl2ZUJyb2FkY2FzdE1vZGFsXG4gICAgICAgIG9wZW49e2xpdmVTdHVkaW9PcGVufVxuICAgICAgICBvbk9wZW5DaGFuZ2U9e3NldExpdmVTdHVkaW9PcGVufVxuICAgICAgICBicmFuZE5hbWU9e2FjdGl2ZUNhbGxQYXJ0bmVyIHx8IFwiRGlyZWN0IFVzZXIgLyBCcmFuZCBDYWxsXCJ9XG4gICAgICAgIGRlZmF1bHRNb2RlPXthY3RpdmVDYWxsTW9kZX1cbiAgICAgICAgY3VzdG9tUm9vbUNoYW5uZWw9e2FjdGl2ZUNhbGxSb29tfVxuICAgICAgICBjYWxsRGlyZWN0aW9uPXtpc0JyYW5kID8gXCJicmFuZF90b191c2VyXCIgOiBcInVzZXJfdG9fdXNlclwifVxuICAgICAgLz5cblxuICAgICAgey8qIFN1Ym1pdCBEaWFsb2cgb3BlbmVkIHdpdGggcHJlZmlsbGVkIHNjYW5uZXIgZGF0YSAqL31cbiAgICAgIHtwcmVmaWxsZWRQb3N0ICYmIChcbiAgICAgICAgPFN1Ym1pdERpYWxvZ1xuICAgICAgICAgIG9wZW49e3N1Ym1pdERpYWxvZ09wZW59XG4gICAgICAgICAgb25PcGVuQ2hhbmdlPXtzZXRTdWJtaXREaWFsb2dPcGVufVxuICAgICAgICAgIGRlZmF1bHRCcmFuZElkPXtwcmVmaWxsZWRQb3N0Lm1hdGNoZWRCcmFuZElkfVxuICAgICAgICAgIGluaXRpYWxWYWx1ZXM9e3tcbiAgICAgICAgICAgIHRpdGxlOiBgJHtwcmVmaWxsZWRQb3N0LmJyYW5kTmFtZX0gJHtwcmVmaWxsZWRQb3N0LnByb2R1Y3ROYW1lIHx8IFwiXCJ9YC50cmltKCksXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogYEJyYW5kOiAke3ByZWZpbGxlZFBvc3QuYnJhbmROYW1lfSB8IENvcnBvcmF0ZSBPd25lcjogJHtwcmVmaWxsZWRQb3N0LmJyYW5kT3duZXJ9XFxuJHtwcmVmaWxsZWRQb3N0LnNjYW5SZXN1bHQuYnJhbmRJbmZvLnBhcmVudENvbXBhbnlDb250ZXh0fVxcbltGb3JlbnNpYyBBdXRoZW50aWNpdHkgU2NvcmU6ICR7cHJlZmlsbGVkUG9zdC5zY2FuUmVzdWx0LmF1dGhlbnRpY2l0eS5zY29yZX0lIC0gJHtwcmVmaWxsZWRQb3N0LnNjYW5SZXN1bHQuYXV0aGVudGljaXR5LmJhZGdlTGFiZWx9XWAsXG4gICAgICAgICAgICBjYXRlZ29yeTogcHJlZmlsbGVkUG9zdC5jYXRlZ29yeSxcbiAgICAgICAgICAgIGZpbGU6IHByZWZpbGxlZFBvc3QuZmlsZSB8fCBudWxsLFxuICAgICAgICAgICAgYWlTY2FuUmVzdWx0OiBwcmVmaWxsZWRQb3N0LnNjYW5SZXN1bHQsXG4gICAgICAgICAgfX1cbiAgICAgICAgICBvblBvc3RlZD17b25Qb3N0ZWR9XG4gICAgICAgIC8+XG4gICAgICApfVxuICAgIDwvaGVhZGVyPlxuICApO1xufVxuIl0sImZpbGUiOiIvYXBwL2FwcGxldC9zcmMvY29tcG9uZW50cy9IZWFkZXIudHN4In0=