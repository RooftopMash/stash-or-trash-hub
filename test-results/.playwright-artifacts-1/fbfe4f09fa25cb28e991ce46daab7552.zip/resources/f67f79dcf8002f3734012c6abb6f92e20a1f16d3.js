import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "TSS_DEV_SERVER": "true", "TSS_DEV_SSR_STYLES_BASEPATH": "/", "TSS_DEV_SSR_STYLES_ENABLED": "true", "TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false", "TSS_INLINE_CSS_ENABLED": "false", "TSS_ROUTER_BASEPATH": "", "TSS_SERVER_FN_BASE": "/_serverFn/", "TSS_SHELL": "false", "VITE_SUPABASE_PROJECT_ID": "ypbyouaddkdfuhfpnguu", "VITE_SUPABASE_PUBLISHABLE_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlwYnlvdWFkZGtkZnVoZnBuZ3V1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM1OTY0OTgsImV4cCI6MjA5OTE3MjQ5OH0.IEHBd2gZuTpIvedgDPpytWxeoDUglcWIsZctl5Z9TvI", "VITE_SUPABASE_URL": "https://ypbyouaddkdfuhfpnguu.supabase.co"};/**
* Production Frontend Security Shield
* - Silences console logs, warnings, traces, and raw stack dumps in production builds
* - Scrubs sensitive tokens, stack traces, and internal file paths from any runtime error messages
* - Prevents accidental exposure of internal state on global window properties
*/
const SENSITIVE_PATTERNS = [
	/AIza[0-9A-Za-z_-]{35}/g,
	/eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g,
	/(?:postgres|postgresql|mysql|mongodb(?:\+srv)?):\/\/[^\s"']+/gi,
	/(?:file|webpack|vite|rolldown):\/\/\/[^\s)]+/gi,
	/\bat\s+[^\n]+?\([^)]+:\d+:\d+\)/g
];
export function sanitizePublicMessage(input) {
	const raw = input instanceof Error ? input.message : typeof input === "string" ? input : "An unexpected error occurred.";
	let cleaned = raw;
	for (const pattern of SENSITIVE_PATTERNS) {
		cleaned = cleaned.replace(pattern, "[redacted]");
	}
	return cleaned.slice(0, 240);
}
let shieldInstalled = false;
const DEV_OVERRIDE_KEY = "sot_developer_code_inspect_v1";
export function isDeveloperCodeInspectionActive() {
	if (typeof window === "undefined") return false;
	try {
		return window.localStorage.getItem(DEV_OVERRIDE_KEY) === "true";
	} catch {
		return false;
	}
}
export function toggleDeveloperCodeInspection(enabled) {
	if (typeof window === "undefined") return;
	try {
		if (enabled) {
			window.localStorage.setItem(DEV_OVERRIDE_KEY, "true");
		} else {
			window.localStorage.removeItem(DEV_OVERRIDE_KEY);
		}
	} catch {}
}
export function installProductionSecurityShield() {
	if (typeof window === "undefined" || shieldInstalled) return;
	shieldInstalled = true;
	const metaEnv = typeof import.meta !== "undefined" && import.meta.env ? import.meta.env : {};
	const isProd = metaEnv.PROD ?? false;
	// 1. Console & Debugger Scrubbing in Production
	if (isProd) {
		const noop = () => undefined;
		try {
			window.console.log = noop;
			window.console.debug = noop;
			window.console.info = noop;
			window.console.warn = noop;
			window.console.trace = noop;
			window.console.table = noop;
			window.console.dir = noop;
			window.console.error = () => undefined;
		} catch {}
		// Remove any dev/bundler global hooks if present
		try {
			const win = window;
			delete win.__REACT_DEVTOOLS_GLOBAL_HOOK__;
			delete win.__TANSTACK_ROUTER_DEVTOOLS__;
		} catch {}
	}
	// 2. F12 and Code Viewing Options / Anti-Inspection Shield
	const handleKeyDown = (e) => {
		if (isDeveloperCodeInspectionActive()) return;
		// F12 key (DevTools shortcut)
		if (e.key === "F12" || e.keyCode === 123) {
			e.preventDefault();
			e.stopPropagation();
			return;
		}
		// Ctrl+Shift+I / Cmd+Opt+I (Inspect Element)
		// Ctrl+Shift+J / Cmd+Opt+J (Console)
		// Ctrl+Shift+C / Cmd+Opt+C (Element picker)
		if ((e.ctrlKey || e.metaKey) && e.shiftKey && [
			"I",
			"i",
			"J",
			"j",
			"C",
			"c"
		].includes(e.key)) {
			e.preventDefault();
			e.stopPropagation();
			return;
		}
		// Ctrl+U / Cmd+U (View Page Source)
		if ((e.ctrlKey || e.metaKey) && (e.key === "u" || e.key === "U")) {
			e.preventDefault();
			e.stopPropagation();
			return;
		}
		// Ctrl+S / Cmd+S (Save Page HTML)
		if ((e.ctrlKey || e.metaKey) && (e.key === "s" || e.key === "S")) {
			e.preventDefault();
			e.stopPropagation();
			return;
		}
	};
	window.addEventListener("keydown", handleKeyDown, { capture: true });
	// 3. Mobile Anti-Screen Grab & Touch Callout Protection
	try {
		document.documentElement.classList.add("sot-shield-active");
		if (document.body) {
			document.body.classList.add("sot-shield-active");
		}
	} catch {}
	// Prevent right-click and mobile long-press context menu (blocks "Inspect Element", "View Source", "Save Image As")
	const handleContextMenu = (e) => {
		if (isDeveloperCodeInspectionActive()) return;
		// Allow right click inside text input fields for copy/paste
		const target = e.target;
		if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) {
			return;
		}
		e.preventDefault();
	};
	window.addEventListener("contextmenu", handleContextMenu, { capture: true });
	// Prevent drag-to-save on mobile and desktop
	const handleDragStart = (e) => {
		const target = e.target;
		if (target && (target.tagName === "IMG" || target.tagName === "VIDEO")) {
			e.preventDefault();
		}
	};
	window.addEventListener("dragstart", handleDragStart, { capture: true });
	// 4. Privacy Shield on Mobile Screen Capture / App Switcher
	// When mobile OS captures snapshot for app switcher or screen-recording is active,
	// apply a blur veil to protect personal conversations and proprietary brand analytics
	const handleVisibilityChange = () => {
		if (document.visibilityState === "hidden") {
			document.body?.classList.add("sot-privacy-blur");
		} else {
			document.body?.classList.remove("sot-privacy-blur");
		}
	};
	document.addEventListener("visibilitychange", handleVisibilityChange);
	window.addEventListener("blur", () => {
		document.body?.classList.add("sot-privacy-blur");
	});
	window.addEventListener("focus", () => {
		document.body?.classList.remove("sot-privacy-blur");
	});
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7O0FBT0EsTUFBTSxxQkFBcUI7Q0FDekI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGO0FBRUEsT0FBTyxTQUFTLHNCQUFzQixPQUF3QjtDQUM1RCxNQUFNLE1BQ0osaUJBQWlCLFFBQ2IsTUFBTSxVQUNOLE9BQU8sVUFBVSxXQUNmLFFBQ0E7Q0FFUixJQUFJLFVBQVU7Q0FDZCxLQUFLLE1BQU0sV0FBVyxvQkFBb0I7RUFDeEMsVUFBVSxRQUFRLFFBQVEsU0FBUyxZQUFZO0NBQ2pEO0NBQ0EsT0FBTyxRQUFRLE1BQU0sR0FBRyxHQUFHO0FBQzdCO0FBRUEsSUFBSSxrQkFBa0I7QUFFdEIsTUFBTSxtQkFBbUI7QUFFekIsT0FBTyxTQUFTLGtDQUEyQztDQUN6RCxJQUFJLE9BQU8sV0FBVyxhQUFhLE9BQU87Q0FDMUMsSUFBSTtFQUNGLE9BQU8sT0FBTyxhQUFhLFFBQVEsZ0JBQWdCLE1BQU07Q0FDM0QsUUFBUTtFQUNOLE9BQU87Q0FDVDtBQUNGO0FBRUEsT0FBTyxTQUFTLDhCQUE4QixTQUF3QjtDQUNwRSxJQUFJLE9BQU8sV0FBVyxhQUFhO0NBQ25DLElBQUk7RUFDRixJQUFJLFNBQVM7R0FDWCxPQUFPLGFBQWEsUUFBUSxrQkFBa0IsTUFBTTtFQUN0RCxPQUFPO0dBQ0wsT0FBTyxhQUFhLFdBQVcsZ0JBQWdCO0VBQ2pEO0NBQ0YsUUFBUSxDQUVSO0FBQ0Y7QUFFQSxPQUFPLFNBQVMsa0NBQXdDO0NBQ3RELElBQUksT0FBTyxXQUFXLGVBQWUsaUJBQWlCO0NBQ3RELGtCQUFrQjtDQUVsQixNQUFNLFVBQVcsT0FBTyxnQkFBZ0IsZUFBZ0IsWUFBb0IsTUFBUSxZQUFvQixNQUFNLENBQUM7Q0FDL0csTUFBTSxTQUFTLFFBQVEsUUFBUTs7Q0FHL0IsSUFBSSxRQUFRO0VBQ1YsTUFBTSxhQUFhO0VBQ25CLElBQUk7R0FDRixPQUFPLFFBQVEsTUFBTTtHQUNyQixPQUFPLFFBQVEsUUFBUTtHQUN2QixPQUFPLFFBQVEsT0FBTztHQUN0QixPQUFPLFFBQVEsT0FBTztHQUN0QixPQUFPLFFBQVEsUUFBUTtHQUN2QixPQUFPLFFBQVEsUUFBUTtHQUN2QixPQUFPLFFBQVEsTUFBTTtHQUNyQixPQUFPLFFBQVEsY0FBYztFQUMvQixRQUFRLENBRVI7O0VBR0EsSUFBSTtHQUNGLE1BQU0sTUFBTTtHQUNaLE9BQU8sSUFBSTtHQUNYLE9BQU8sSUFBSTtFQUNiLFFBQVEsQ0FFUjtDQUNGOztDQUdBLE1BQU0saUJBQWlCLE1BQXFCO0VBQzFDLElBQUksZ0NBQWdDLEdBQUc7O0VBR3ZDLElBQUksRUFBRSxRQUFRLFNBQVMsRUFBRSxZQUFZLEtBQUs7R0FDeEMsRUFBRSxlQUFlO0dBQ2pCLEVBQUUsZ0JBQWdCO0dBQ2xCO0VBQ0Y7Ozs7RUFLQSxLQUNHLEVBQUUsV0FBVyxFQUFFLFlBQ2hCLEVBQUUsWUFDRjtHQUFDO0dBQUs7R0FBSztHQUFLO0dBQUs7R0FBSztFQUFHLENBQUMsQ0FBQyxTQUFTLEVBQUUsR0FBRyxHQUM3QztHQUNBLEVBQUUsZUFBZTtHQUNqQixFQUFFLGdCQUFnQjtHQUNsQjtFQUNGOztFQUdBLEtBQUssRUFBRSxXQUFXLEVBQUUsYUFBYSxFQUFFLFFBQVEsT0FBTyxFQUFFLFFBQVEsTUFBTTtHQUNoRSxFQUFFLGVBQWU7R0FDakIsRUFBRSxnQkFBZ0I7R0FDbEI7RUFDRjs7RUFHQSxLQUFLLEVBQUUsV0FBVyxFQUFFLGFBQWEsRUFBRSxRQUFRLE9BQU8sRUFBRSxRQUFRLE1BQU07R0FDaEUsRUFBRSxlQUFlO0dBQ2pCLEVBQUUsZ0JBQWdCO0dBQ2xCO0VBQ0Y7Q0FDRjtDQUVBLE9BQU8saUJBQWlCLFdBQVcsZUFBZSxFQUFFLFNBQVMsS0FBSyxDQUFDOztDQUduRSxJQUFJO0VBQ0YsU0FBUyxnQkFBZ0IsVUFBVSxJQUFJLG1CQUFtQjtFQUMxRCxJQUFJLFNBQVMsTUFBTTtHQUNqQixTQUFTLEtBQUssVUFBVSxJQUFJLG1CQUFtQjtFQUNqRDtDQUNGLFFBQVEsQ0FFUjs7Q0FHQSxNQUFNLHFCQUFxQixNQUFrQjtFQUMzQyxJQUFJLGdDQUFnQyxHQUFHOztFQUV2QyxNQUFNLFNBQVMsRUFBRTtFQUNqQixJQUFJLFdBQVcsT0FBTyxZQUFZLFdBQVcsT0FBTyxZQUFZLGNBQWMsT0FBTyxvQkFBb0I7R0FDdkc7RUFDRjtFQUNBLEVBQUUsZUFBZTtDQUNuQjtDQUNBLE9BQU8saUJBQWlCLGVBQWUsbUJBQW1CLEVBQUUsU0FBUyxLQUFLLENBQUM7O0NBRzNFLE1BQU0sbUJBQW1CLE1BQWlCO0VBQ3hDLE1BQU0sU0FBUyxFQUFFO0VBQ2pCLElBQUksV0FBVyxPQUFPLFlBQVksU0FBUyxPQUFPLFlBQVksVUFBVTtHQUN0RSxFQUFFLGVBQWU7RUFDbkI7Q0FDRjtDQUNBLE9BQU8saUJBQWlCLGFBQWEsaUJBQWlCLEVBQUUsU0FBUyxLQUFLLENBQUM7Ozs7Q0FLdkUsTUFBTSwrQkFBK0I7RUFDbkMsSUFBSSxTQUFTLG9CQUFvQixVQUFVO0dBQ3pDLFNBQVMsTUFBTSxVQUFVLElBQUksa0JBQWtCO0VBQ2pELE9BQU87R0FDTCxTQUFTLE1BQU0sVUFBVSxPQUFPLGtCQUFrQjtFQUNwRDtDQUNGO0NBQ0EsU0FBUyxpQkFBaUIsb0JBQW9CLHNCQUFzQjtDQUVwRSxPQUFPLGlCQUFpQixjQUFjO0VBQ3BDLFNBQVMsTUFBTSxVQUFVLElBQUksa0JBQWtCO0NBQ2pELENBQUM7Q0FFRCxPQUFPLGlCQUFpQixlQUFlO0VBQ3JDLFNBQVMsTUFBTSxVQUFVLE9BQU8sa0JBQWtCO0NBQ3BELENBQUM7QUFDSCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJzZWN1cml0eS1zaGllbGQudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBQcm9kdWN0aW9uIEZyb250ZW5kIFNlY3VyaXR5IFNoaWVsZFxuICogLSBTaWxlbmNlcyBjb25zb2xlIGxvZ3MsIHdhcm5pbmdzLCB0cmFjZXMsIGFuZCByYXcgc3RhY2sgZHVtcHMgaW4gcHJvZHVjdGlvbiBidWlsZHNcbiAqIC0gU2NydWJzIHNlbnNpdGl2ZSB0b2tlbnMsIHN0YWNrIHRyYWNlcywgYW5kIGludGVybmFsIGZpbGUgcGF0aHMgZnJvbSBhbnkgcnVudGltZSBlcnJvciBtZXNzYWdlc1xuICogLSBQcmV2ZW50cyBhY2NpZGVudGFsIGV4cG9zdXJlIG9mIGludGVybmFsIHN0YXRlIG9uIGdsb2JhbCB3aW5kb3cgcHJvcGVydGllc1xuICovXG5cbmNvbnN0IFNFTlNJVElWRV9QQVRURVJOUyA9IFtcbiAgL0FJemFbMC05QS1aYS16Xy1dezM1fS9nLFxuICAvZXlKW0EtWmEtejAtOV8tXXsxMCx9XFwuW0EtWmEtejAtOV8tXXsxMCx9XFwuW0EtWmEtejAtOV8tXXsxMCx9L2csXG4gIC8oPzpwb3N0Z3Jlc3xwb3N0Z3Jlc3FsfG15c3FsfG1vbmdvZGIoPzpcXCtzcnYpPyk6XFwvXFwvW15cXHNcIiddKy9naSxcbiAgLyg/OmZpbGV8d2VicGFja3x2aXRlfHJvbGxkb3duKTpcXC9cXC9cXC9bXlxccyldKy9naSxcbiAgL1xcYmF0XFxzK1teXFxuXSs/XFwoW14pXSs6XFxkKzpcXGQrXFwpL2csXG5dO1xuXG5leHBvcnQgZnVuY3Rpb24gc2FuaXRpemVQdWJsaWNNZXNzYWdlKGlucHV0OiB1bmtub3duKTogc3RyaW5nIHtcbiAgY29uc3QgcmF3ID1cbiAgICBpbnB1dCBpbnN0YW5jZW9mIEVycm9yXG4gICAgICA/IGlucHV0Lm1lc3NhZ2VcbiAgICAgIDogdHlwZW9mIGlucHV0ID09PSBcInN0cmluZ1wiXG4gICAgICAgID8gaW5wdXRcbiAgICAgICAgOiBcIkFuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWQuXCI7XG5cbiAgbGV0IGNsZWFuZWQgPSByYXc7XG4gIGZvciAoY29uc3QgcGF0dGVybiBvZiBTRU5TSVRJVkVfUEFUVEVSTlMpIHtcbiAgICBjbGVhbmVkID0gY2xlYW5lZC5yZXBsYWNlKHBhdHRlcm4sIFwiW3JlZGFjdGVkXVwiKTtcbiAgfVxuICByZXR1cm4gY2xlYW5lZC5zbGljZSgwLCAyNDApO1xufVxuXG5sZXQgc2hpZWxkSW5zdGFsbGVkID0gZmFsc2U7XG5cbmNvbnN0IERFVl9PVkVSUklERV9LRVkgPSBcInNvdF9kZXZlbG9wZXJfY29kZV9pbnNwZWN0X3YxXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0RldmVsb3BlckNvZGVJbnNwZWN0aW9uQWN0aXZlKCk6IGJvb2xlYW4ge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIGZhbHNlO1xuICB0cnkge1xuICAgIHJldHVybiB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oREVWX09WRVJSSURFX0tFWSkgPT09IFwidHJ1ZVwiO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRvZ2dsZURldmVsb3BlckNvZGVJbnNwZWN0aW9uKGVuYWJsZWQ6IGJvb2xlYW4pOiB2b2lkIHtcbiAgaWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybjtcbiAgdHJ5IHtcbiAgICBpZiAoZW5hYmxlZCkge1xuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKERFVl9PVkVSUklERV9LRVksIFwidHJ1ZVwiKTtcbiAgICB9IGVsc2Uge1xuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKERFVl9PVkVSUklERV9LRVkpO1xuICAgIH1cbiAgfSBjYXRjaCB7XG4gICAgLy8gSWdub3JlIHN0b3JhZ2UgZXJyb3JzXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGluc3RhbGxQcm9kdWN0aW9uU2VjdXJpdHlTaGllbGQoKTogdm9pZCB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiIHx8IHNoaWVsZEluc3RhbGxlZCkgcmV0dXJuO1xuICBzaGllbGRJbnN0YWxsZWQgPSB0cnVlO1xuXG4gIGNvbnN0IG1ldGFFbnYgPSAodHlwZW9mIGltcG9ydC5tZXRhICE9PSBcInVuZGVmaW5lZFwiICYmIChpbXBvcnQubWV0YSBhcyBhbnkpLmVudikgPyAoaW1wb3J0Lm1ldGEgYXMgYW55KS5lbnYgOiB7fTtcbiAgY29uc3QgaXNQcm9kID0gbWV0YUVudi5QUk9EID8/IGZhbHNlO1xuXG4gIC8vIDEuIENvbnNvbGUgJiBEZWJ1Z2dlciBTY3J1YmJpbmcgaW4gUHJvZHVjdGlvblxuICBpZiAoaXNQcm9kKSB7XG4gICAgY29uc3Qgbm9vcCA9ICgpID0+IHVuZGVmaW5lZDtcbiAgICB0cnkge1xuICAgICAgd2luZG93LmNvbnNvbGUubG9nID0gbm9vcDtcbiAgICAgIHdpbmRvdy5jb25zb2xlLmRlYnVnID0gbm9vcDtcbiAgICAgIHdpbmRvdy5jb25zb2xlLmluZm8gPSBub29wO1xuICAgICAgd2luZG93LmNvbnNvbGUud2FybiA9IG5vb3A7XG4gICAgICB3aW5kb3cuY29uc29sZS50cmFjZSA9IG5vb3A7XG4gICAgICB3aW5kb3cuY29uc29sZS50YWJsZSA9IG5vb3A7XG4gICAgICB3aW5kb3cuY29uc29sZS5kaXIgPSBub29wO1xuICAgICAgd2luZG93LmNvbnNvbGUuZXJyb3IgPSAoKSA9PiB1bmRlZmluZWQ7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBJZ25vcmUgcmVhZC1vbmx5IGNvbnNvbGUgZGVzY3JpcHRvcnMgaW4gcmVzdHJpY3RlZCBlbnZpcm9ubWVudHNcbiAgICB9XG5cbiAgICAvLyBSZW1vdmUgYW55IGRldi9idW5kbGVyIGdsb2JhbCBob29rcyBpZiBwcmVzZW50XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHdpbiA9IHdpbmRvdyBhcyB1bmtub3duIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgZGVsZXRlIHdpbi5fX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX187XG4gICAgICBkZWxldGUgd2luLl9fVEFOU1RBQ0tfUk9VVEVSX0RFVlRPT0xTX187XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBJZ25vcmUgbm9uLWNvbmZpZ3VyYWJsZSBnbG9iYWxzXG4gICAgfVxuICB9XG5cbiAgLy8gMi4gRjEyIGFuZCBDb2RlIFZpZXdpbmcgT3B0aW9ucyAvIEFudGktSW5zcGVjdGlvbiBTaGllbGRcbiAgY29uc3QgaGFuZGxlS2V5RG93biA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgaWYgKGlzRGV2ZWxvcGVyQ29kZUluc3BlY3Rpb25BY3RpdmUoKSkgcmV0dXJuO1xuXG4gICAgLy8gRjEyIGtleSAoRGV2VG9vbHMgc2hvcnRjdXQpXG4gICAgaWYgKGUua2V5ID09PSBcIkYxMlwiIHx8IGUua2V5Q29kZSA9PT0gMTIzKSB7XG4gICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIEN0cmwrU2hpZnQrSSAvIENtZCtPcHQrSSAoSW5zcGVjdCBFbGVtZW50KVxuICAgIC8vIEN0cmwrU2hpZnQrSiAvIENtZCtPcHQrSiAoQ29uc29sZSlcbiAgICAvLyBDdHJsK1NoaWZ0K0MgLyBDbWQrT3B0K0MgKEVsZW1lbnQgcGlja2VyKVxuICAgIGlmIChcbiAgICAgIChlLmN0cmxLZXkgfHwgZS5tZXRhS2V5KSAmJlxuICAgICAgZS5zaGlmdEtleSAmJlxuICAgICAgW1wiSVwiLCBcImlcIiwgXCJKXCIsIFwialwiLCBcIkNcIiwgXCJjXCJdLmluY2x1ZGVzKGUua2V5KVxuICAgICkge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBDdHJsK1UgLyBDbWQrVSAoVmlldyBQYWdlIFNvdXJjZSlcbiAgICBpZiAoKGUuY3RybEtleSB8fCBlLm1ldGFLZXkpICYmIChlLmtleSA9PT0gXCJ1XCIgfHwgZS5rZXkgPT09IFwiVVwiKSkge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBDdHJsK1MgLyBDbWQrUyAoU2F2ZSBQYWdlIEhUTUwpXG4gICAgaWYgKChlLmN0cmxLZXkgfHwgZS5tZXRhS2V5KSAmJiAoZS5rZXkgPT09IFwic1wiIHx8IGUua2V5ID09PSBcIlNcIikpIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICB9O1xuXG4gIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBoYW5kbGVLZXlEb3duLCB7IGNhcHR1cmU6IHRydWUgfSk7XG5cbiAgLy8gMy4gTW9iaWxlIEFudGktU2NyZWVuIEdyYWIgJiBUb3VjaCBDYWxsb3V0IFByb3RlY3Rpb25cbiAgdHJ5IHtcbiAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xhc3NMaXN0LmFkZChcInNvdC1zaGllbGQtYWN0aXZlXCIpO1xuICAgIGlmIChkb2N1bWVudC5ib2R5KSB7XG4gICAgICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5hZGQoXCJzb3Qtc2hpZWxkLWFjdGl2ZVwiKTtcbiAgICB9XG4gIH0gY2F0Y2gge1xuICAgIC8vIElnbm9yZSBET00gZXhjZXB0aW9uXG4gIH1cblxuICAvLyBQcmV2ZW50IHJpZ2h0LWNsaWNrIGFuZCBtb2JpbGUgbG9uZy1wcmVzcyBjb250ZXh0IG1lbnUgKGJsb2NrcyBcIkluc3BlY3QgRWxlbWVudFwiLCBcIlZpZXcgU291cmNlXCIsIFwiU2F2ZSBJbWFnZSBBc1wiKVxuICBjb25zdCBoYW5kbGVDb250ZXh0TWVudSA9IChlOiBNb3VzZUV2ZW50KSA9PiB7XG4gICAgaWYgKGlzRGV2ZWxvcGVyQ29kZUluc3BlY3Rpb25BY3RpdmUoKSkgcmV0dXJuO1xuICAgIC8vIEFsbG93IHJpZ2h0IGNsaWNrIGluc2lkZSB0ZXh0IGlucHV0IGZpZWxkcyBmb3IgY29weS9wYXN0ZVxuICAgIGNvbnN0IHRhcmdldCA9IGUudGFyZ2V0IGFzIEhUTUxFbGVtZW50IHwgbnVsbDtcbiAgICBpZiAodGFyZ2V0ICYmICh0YXJnZXQudGFnTmFtZSA9PT0gXCJJTlBVVFwiIHx8IHRhcmdldC50YWdOYW1lID09PSBcIlRFWFRBUkVBXCIgfHwgdGFyZ2V0LmlzQ29udGVudEVkaXRhYmxlKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIH07XG4gIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwiY29udGV4dG1lbnVcIiwgaGFuZGxlQ29udGV4dE1lbnUsIHsgY2FwdHVyZTogdHJ1ZSB9KTtcblxuICAvLyBQcmV2ZW50IGRyYWctdG8tc2F2ZSBvbiBtb2JpbGUgYW5kIGRlc2t0b3BcbiAgY29uc3QgaGFuZGxlRHJhZ1N0YXJ0ID0gKGU6IERyYWdFdmVudCkgPT4ge1xuICAgIGNvbnN0IHRhcmdldCA9IGUudGFyZ2V0IGFzIEhUTUxFbGVtZW50IHwgbnVsbDtcbiAgICBpZiAodGFyZ2V0ICYmICh0YXJnZXQudGFnTmFtZSA9PT0gXCJJTUdcIiB8fCB0YXJnZXQudGFnTmFtZSA9PT0gXCJWSURFT1wiKSkge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIH1cbiAgfTtcbiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJkcmFnc3RhcnRcIiwgaGFuZGxlRHJhZ1N0YXJ0LCB7IGNhcHR1cmU6IHRydWUgfSk7XG5cbiAgLy8gNC4gUHJpdmFjeSBTaGllbGQgb24gTW9iaWxlIFNjcmVlbiBDYXB0dXJlIC8gQXBwIFN3aXRjaGVyXG4gIC8vIFdoZW4gbW9iaWxlIE9TIGNhcHR1cmVzIHNuYXBzaG90IGZvciBhcHAgc3dpdGNoZXIgb3Igc2NyZWVuLXJlY29yZGluZyBpcyBhY3RpdmUsXG4gIC8vIGFwcGx5IGEgYmx1ciB2ZWlsIHRvIHByb3RlY3QgcGVyc29uYWwgY29udmVyc2F0aW9ucyBhbmQgcHJvcHJpZXRhcnkgYnJhbmQgYW5hbHl0aWNzXG4gIGNvbnN0IGhhbmRsZVZpc2liaWxpdHlDaGFuZ2UgPSAoKSA9PiB7XG4gICAgaWYgKGRvY3VtZW50LnZpc2liaWxpdHlTdGF0ZSA9PT0gXCJoaWRkZW5cIikge1xuICAgICAgZG9jdW1lbnQuYm9keT8uY2xhc3NMaXN0LmFkZChcInNvdC1wcml2YWN5LWJsdXJcIik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGRvY3VtZW50LmJvZHk/LmNsYXNzTGlzdC5yZW1vdmUoXCJzb3QtcHJpdmFjeS1ibHVyXCIpO1xuICAgIH1cbiAgfTtcbiAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInZpc2liaWxpdHljaGFuZ2VcIiwgaGFuZGxlVmlzaWJpbGl0eUNoYW5nZSk7XG5cbiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJibHVyXCIsICgpID0+IHtcbiAgICBkb2N1bWVudC5ib2R5Py5jbGFzc0xpc3QuYWRkKFwic290LXByaXZhY3ktYmx1clwiKTtcbiAgfSk7XG5cbiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJmb2N1c1wiLCAoKSA9PiB7XG4gICAgZG9jdW1lbnQuYm9keT8uY2xhc3NMaXN0LnJlbW92ZShcInNvdC1wcml2YWN5LWJsdXJcIik7XG4gIH0pO1xufVxuIl19