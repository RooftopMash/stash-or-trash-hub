import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=a8030269";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=a8030269";
import { t as require_react_dom } from "/node_modules/.vite/deps/react-dom.js?v=a8030269";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/react_jsx-runtime.js?v=a8030269";
import { t as createContextScope } from "/node_modules/.vite/deps/dist-Dic5YkbB.js?v=a8030269";
import { t as useCallbackRef } from "/node_modules/.vite/deps/dist-BEvKR6kC.js?v=a8030269";
import { t as useLayoutEffect2 } from "/node_modules/.vite/deps/dist-qLH82T-0.js?v=a8030269";
import { o as useComposedRefs } from "/node_modules/.vite/deps/dist-DIAF6ZLP.js?v=a8030269";
import { t as Primitive } from "/node_modules/.vite/deps/dist-uZEDRbDH.js?v=a8030269";
import { t as useSize } from "/node_modules/.vite/deps/dist-BdAkthKF.js?v=a8030269";
//#region node_modules/@floating-ui/utils/dist/floating-ui.utils.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/**
* Custom positioning reference element.
* @see https://floating-ui.com/docs/virtual-elements
*/
var sides = [
	"top",
	"right",
	"bottom",
	"left"
];
var min = Math.min;
var max = Math.max;
var round = Math.round;
var floor = Math.floor;
var createCoords = (v) => ({
	x: v,
	y: v
});
var oppositeSideMap = {
	left: "right",
	right: "left",
	bottom: "top",
	top: "bottom"
};
function clamp(start, value, end) {
	return max(start, min(value, end));
}
function evaluate(value, param) {
	return typeof value === "function" ? value(param) : value;
}
function getSide(placement) {
	return placement.split("-")[0];
}
function getAlignment(placement) {
	return placement.split("-")[1];
}
function getOppositeAxis(axis) {
	return axis === "x" ? "y" : "x";
}
function getAxisLength(axis) {
	return axis === "y" ? "height" : "width";
}
function getSideAxis(placement) {
	const firstChar = placement[0];
	return firstChar === "t" || firstChar === "b" ? "y" : "x";
}
function getAlignmentAxis(placement) {
	return getOppositeAxis(getSideAxis(placement));
}
function getAlignmentSides(placement, rects, rtl) {
	if (rtl === void 0) rtl = false;
	const alignment = getAlignment(placement);
	const alignmentAxis = getAlignmentAxis(placement);
	const length = getAxisLength(alignmentAxis);
	let mainAlignmentSide = alignmentAxis === "x" ? alignment === (rtl ? "end" : "start") ? "right" : "left" : alignment === "start" ? "bottom" : "top";
	if (rects.reference[length] > rects.floating[length]) mainAlignmentSide = getOppositePlacement(mainAlignmentSide);
	return [mainAlignmentSide, getOppositePlacement(mainAlignmentSide)];
}
function getExpandedPlacements(placement) {
	const oppositePlacement = getOppositePlacement(placement);
	return [
		getOppositeAlignmentPlacement(placement),
		oppositePlacement,
		getOppositeAlignmentPlacement(oppositePlacement)
	];
}
function getOppositeAlignmentPlacement(placement) {
	return placement.includes("start") ? placement.replace("start", "end") : placement.replace("end", "start");
}
var lrPlacement = ["left", "right"];
var rlPlacement = ["right", "left"];
var tbPlacement = ["top", "bottom"];
var btPlacement = ["bottom", "top"];
function getSideList(side, isStart, rtl) {
	switch (side) {
		case "top":
		case "bottom":
			if (rtl) return isStart ? rlPlacement : lrPlacement;
			return isStart ? lrPlacement : rlPlacement;
		case "left":
		case "right": return isStart ? tbPlacement : btPlacement;
		default: return [];
	}
}
function getOppositeAxisPlacements(placement, flipAlignment, direction, rtl) {
	const alignment = getAlignment(placement);
	let list = getSideList(getSide(placement), direction === "start", rtl);
	if (alignment) {
		list = list.map((side) => side + "-" + alignment);
		if (flipAlignment) list = list.concat(list.map(getOppositeAlignmentPlacement));
	}
	return list;
}
function getOppositePlacement(placement) {
	const side = getSide(placement);
	return oppositeSideMap[side] + placement.slice(side.length);
}
function expandPaddingObject(padding) {
	var _padding$top, _padding$right, _padding$bottom, _padding$left;
	return {
		top: (_padding$top = padding.top) != null ? _padding$top : 0,
		right: (_padding$right = padding.right) != null ? _padding$right : 0,
		bottom: (_padding$bottom = padding.bottom) != null ? _padding$bottom : 0,
		left: (_padding$left = padding.left) != null ? _padding$left : 0
	};
}
function getPaddingObject(padding) {
	return typeof padding !== "number" ? expandPaddingObject(padding) : {
		top: padding,
		right: padding,
		bottom: padding,
		left: padding
	};
}
function rectToClientRect(rect) {
	const { x, y, width, height } = rect;
	return {
		width,
		height,
		top: y,
		left: x,
		right: x + width,
		bottom: y + height,
		x,
		y
	};
}
//#endregion
//#region node_modules/@floating-ui/core/dist/floating-ui.core.mjs
function computeCoordsFromPlacement(_ref, placement, rtl) {
	let { reference, floating } = _ref;
	const sideAxis = getSideAxis(placement);
	const alignmentAxis = getAlignmentAxis(placement);
	const alignLength = getAxisLength(alignmentAxis);
	const side = getSide(placement);
	const isVertical = sideAxis === "y";
	const commonX = reference.x + reference.width / 2 - floating.width / 2;
	const commonY = reference.y + reference.height / 2 - floating.height / 2;
	const commonAlign = reference[alignLength] / 2 - floating[alignLength] / 2;
	let coords;
	switch (side) {
		case "top":
			coords = {
				x: commonX,
				y: reference.y - floating.height
			};
			break;
		case "bottom":
			coords = {
				x: commonX,
				y: reference.y + reference.height
			};
			break;
		case "right":
			coords = {
				x: reference.x + reference.width,
				y: commonY
			};
			break;
		case "left":
			coords = {
				x: reference.x - floating.width,
				y: commonY
			};
			break;
		default: coords = {
			x: reference.x,
			y: reference.y
		};
	}
	const alignment = getAlignment(placement);
	if (alignment) coords[alignmentAxis] += commonAlign * (alignment === "end" ? 1 : -1) * (rtl && isVertical ? -1 : 1);
	return coords;
}
/**
* Resolves with an object of overflow side offsets that determine how much the
* element is overflowing a given clipping boundary on each side.
* - positive = overflowing the boundary by that number of pixels
* - negative = how many pixels left before it will overflow
* - 0 = lies flush with the boundary
* @see https://floating-ui.com/docs/detectOverflow
*/
async function detectOverflow(state, options) {
	var _await$platform$isEle;
	if (options === void 0) options = {};
	const { x, y, platform, rects, elements, strategy } = state;
	const { boundary = "clippingAncestors", rootBoundary = "viewport", elementContext = "floating", altBoundary = false, padding = 0 } = evaluate(options, state);
	const paddingObject = getPaddingObject(padding);
	const element = elements[altBoundary ? elementContext === "floating" ? "reference" : "floating" : elementContext];
	const clippingClientRect = rectToClientRect(await platform.getClippingRect({
		element: ((_await$platform$isEle = await (platform.isElement == null ? void 0 : platform.isElement(element))) != null ? _await$platform$isEle : true) ? element : element.contextElement || await (platform.getDocumentElement == null ? void 0 : platform.getDocumentElement(elements.floating)),
		boundary,
		rootBoundary,
		strategy
	}));
	const rect = elementContext === "floating" ? {
		x,
		y,
		width: rects.floating.width,
		height: rects.floating.height
	} : rects.reference;
	const offsetParent = await (platform.getOffsetParent == null ? void 0 : platform.getOffsetParent(elements.floating));
	const offsetScale = await (platform.isElement == null ? void 0 : platform.isElement(offsetParent)) && await (platform.getScale == null ? void 0 : platform.getScale(offsetParent)) || {
		x: 1,
		y: 1
	};
	const elementClientRect = rectToClientRect(platform.convertOffsetParentRelativeRectToViewportRelativeRect ? await platform.convertOffsetParentRelativeRectToViewportRelativeRect({
		elements,
		rect,
		offsetParent,
		strategy
	}) : rect);
	return {
		top: (clippingClientRect.top - elementClientRect.top + paddingObject.top) / offsetScale.y,
		bottom: (elementClientRect.bottom - clippingClientRect.bottom + paddingObject.bottom) / offsetScale.y,
		left: (clippingClientRect.left - elementClientRect.left + paddingObject.left) / offsetScale.x,
		right: (elementClientRect.right - clippingClientRect.right + paddingObject.right) / offsetScale.x
	};
}
var MAX_RESET_COUNT = 50;
/**
* Computes the `x` and `y` coordinates that will place the floating element
* next to a given reference element.
*
* This export does not have any `platform` interface logic. You will need to
* write one for the platform you are using Floating UI with.
*/
var computePosition$1 = async (reference, floating, config) => {
	const { placement = "bottom", strategy = "absolute", middleware = [], platform } = config;
	const platformWithDetectOverflow = platform.detectOverflow ? platform : {
		...platform,
		detectOverflow
	};
	const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(floating));
	let rects = await platform.getElementRects({
		reference,
		floating,
		strategy
	});
	let { x, y } = computeCoordsFromPlacement(rects, placement, rtl);
	let statefulPlacement = placement;
	let resetCount = 0;
	const middlewareData = {};
	for (let i = 0; i < middleware.length; i++) {
		const currentMiddleware = middleware[i];
		if (!currentMiddleware) continue;
		const { name, fn } = currentMiddleware;
		const { x: nextX, y: nextY, data, reset } = await fn({
			x,
			y,
			initialPlacement: placement,
			placement: statefulPlacement,
			strategy,
			middlewareData,
			rects,
			platform: platformWithDetectOverflow,
			elements: {
				reference,
				floating
			}
		});
		x = nextX != null ? nextX : x;
		y = nextY != null ? nextY : y;
		middlewareData[name] = {
			...middlewareData[name],
			...data
		};
		if (reset && resetCount < MAX_RESET_COUNT) {
			resetCount++;
			if (typeof reset === "object") {
				if (reset.placement) statefulPlacement = reset.placement;
				if (reset.rects) rects = reset.rects === true ? await platform.getElementRects({
					reference,
					floating,
					strategy
				}) : reset.rects;
				({x, y} = computeCoordsFromPlacement(rects, statefulPlacement, rtl));
			}
			i = -1;
		}
	}
	return {
		x,
		y,
		placement: statefulPlacement,
		strategy,
		middlewareData
	};
};
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow$3 = (options) => ({
	name: "arrow",
	options,
	async fn(state) {
		const { x, y, placement, rects, platform, elements, middlewareData } = state;
		const { element, padding = 0 } = evaluate(options, state) || {};
		if (element == null) return {};
		const paddingObject = getPaddingObject(padding);
		const coords = {
			x,
			y
		};
		const axis = getAlignmentAxis(placement);
		const length = getAxisLength(axis);
		const arrowDimensions = await platform.getDimensions(element);
		const isYAxis = axis === "y";
		const minProp = isYAxis ? "top" : "left";
		const maxProp = isYAxis ? "bottom" : "right";
		const clientProp = isYAxis ? "clientHeight" : "clientWidth";
		const endDiff = rects.reference[length] + rects.reference[axis] - coords[axis] - rects.floating[length];
		const startDiff = coords[axis] - rects.reference[axis];
		const arrowOffsetParent = await (platform.getOffsetParent == null ? void 0 : platform.getOffsetParent(element));
		let clientSize = arrowOffsetParent ? arrowOffsetParent[clientProp] : 0;
		if (!clientSize || !await (platform.isElement == null ? void 0 : platform.isElement(arrowOffsetParent))) clientSize = elements.floating[clientProp] || rects.floating[length];
		const centerToReference = endDiff / 2 - startDiff / 2;
		const largestPossiblePadding = clientSize / 2 - arrowDimensions[length] / 2 - 1;
		const minPadding = min(paddingObject[minProp], largestPossiblePadding);
		const maxPadding = min(paddingObject[maxProp], largestPossiblePadding);
		const max = clientSize - arrowDimensions[length] - maxPadding;
		const center = clientSize / 2 - arrowDimensions[length] / 2 + centerToReference;
		const offset = clamp(minPadding, center, max);
		const shouldAddOffset = !middlewareData.arrow && getAlignment(placement) != null && center !== offset && rects.reference[length] / 2 - (center < minPadding ? minPadding : maxPadding) - arrowDimensions[length] / 2 < 0;
		const alignmentOffset = shouldAddOffset ? center < minPadding ? center - minPadding : center - max : 0;
		return {
			[axis]: coords[axis] + alignmentOffset,
			data: {
				[axis]: offset,
				centerOffset: center - offset - alignmentOffset,
				...shouldAddOffset && { alignmentOffset }
			},
			reset: shouldAddOffset
		};
	}
});
/**
* Optimizes the visibility of the floating element by flipping the `placement`
* in order to keep it in view when the preferred placement(s) will overflow the
* clipping boundary. Alternative to `autoPlacement`.
* @see https://floating-ui.com/docs/flip
*/
var flip$2 = function(options) {
	if (options === void 0) options = {};
	return {
		name: "flip",
		options,
		async fn(state) {
			var _middlewareData$arrow, _middlewareData$flip;
			const { placement, middlewareData, rects, initialPlacement, platform, elements } = state;
			const { mainAxis: checkMainAxis = true, crossAxis: checkCrossAxis = true, fallbackPlacements: specifiedFallbackPlacements, fallbackStrategy = "bestFit", fallbackAxisSideDirection = "none", flipAlignment = true, ...detectOverflowOptions } = evaluate(options, state);
			if ((_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) return {};
			const side = getSide(placement);
			const initialSideAxis = getSideAxis(initialPlacement);
			const isBasePlacement = getSide(initialPlacement) === initialPlacement;
			const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating));
			const fallbackPlacements = specifiedFallbackPlacements || (isBasePlacement || !flipAlignment ? [getOppositePlacement(initialPlacement)] : getExpandedPlacements(initialPlacement));
			const hasFallbackAxisSideDirection = fallbackAxisSideDirection !== "none";
			if (!specifiedFallbackPlacements && hasFallbackAxisSideDirection) fallbackPlacements.push(...getOppositeAxisPlacements(initialPlacement, flipAlignment, fallbackAxisSideDirection, rtl));
			const placements = [initialPlacement, ...fallbackPlacements];
			const overflow = await platform.detectOverflow(state, detectOverflowOptions);
			const overflows = [];
			let overflowsData = ((_middlewareData$flip = middlewareData.flip) == null ? void 0 : _middlewareData$flip.overflows) || [];
			if (checkMainAxis) overflows.push(overflow[side]);
			if (checkCrossAxis) {
				const sides = getAlignmentSides(placement, rects, rtl);
				overflows.push(overflow[sides[0]], overflow[sides[1]]);
			}
			overflowsData = [...overflowsData, {
				placement,
				overflows
			}];
			if (!overflows.every((side) => side <= 0)) {
				var _middlewareData$flip2, _overflowsData$filter;
				const nextIndex = (((_middlewareData$flip2 = middlewareData.flip) == null ? void 0 : _middlewareData$flip2.index) || 0) + 1;
				const nextPlacement = placements[nextIndex];
				if (nextPlacement) {
					if (!(checkCrossAxis === "alignment" ? initialSideAxis !== getSideAxis(nextPlacement) : false) || overflowsData.every((d) => getSideAxis(d.placement) === initialSideAxis ? d.overflows[0] > 0 : true)) return {
						data: {
							index: nextIndex,
							overflows: overflowsData
						},
						reset: { placement: nextPlacement }
					};
				}
				let resetPlacement = (_overflowsData$filter = overflowsData.filter((d) => d.overflows[0] <= 0).sort((a, b) => a.overflows[1] - b.overflows[1])[0]) == null ? void 0 : _overflowsData$filter.placement;
				if (!resetPlacement) switch (fallbackStrategy) {
					case "bestFit": {
						var _overflowsData$filter2;
						const placement = (_overflowsData$filter2 = overflowsData.filter((d) => {
							if (hasFallbackAxisSideDirection) {
								const currentSideAxis = getSideAxis(d.placement);
								return currentSideAxis === initialSideAxis || currentSideAxis === "y";
							}
							return true;
						}).map((d) => [d.placement, d.overflows.filter((overflow) => overflow > 0).reduce((acc, overflow) => acc + overflow, 0)]).sort((a, b) => a[1] - b[1])[0]) == null ? void 0 : _overflowsData$filter2[0];
						if (placement) resetPlacement = placement;
						break;
					}
					case "initialPlacement": resetPlacement = initialPlacement;
				}
				if (placement !== resetPlacement) return { reset: { placement: resetPlacement } };
			}
			return {};
		}
	};
};
function getSideOffsets(overflow, rect) {
	return {
		top: overflow.top - rect.height,
		right: overflow.right - rect.width,
		bottom: overflow.bottom - rect.height,
		left: overflow.left - rect.width
	};
}
function isAnySideFullyClipped(overflow) {
	return sides.some((side) => overflow[side] >= 0);
}
/**
* Provides data to hide the floating element in applicable situations, such as
* when it is not in the same clipping context as the reference element.
* @see https://floating-ui.com/docs/hide
*/
var hide$2 = function(options) {
	if (options === void 0) options = {};
	return {
		name: "hide",
		options,
		async fn(state) {
			const { rects, platform } = state;
			const { strategy = "referenceHidden", ...detectOverflowOptions } = evaluate(options, state);
			switch (strategy) {
				case "referenceHidden": {
					const offsets = getSideOffsets(await platform.detectOverflow(state, {
						...detectOverflowOptions,
						elementContext: "reference"
					}), rects.reference);
					return { data: {
						referenceHiddenOffsets: offsets,
						referenceHidden: isAnySideFullyClipped(offsets)
					} };
				}
				case "escaped": {
					const offsets = getSideOffsets(await platform.detectOverflow(state, {
						...detectOverflowOptions,
						altBoundary: true
					}), rects.floating);
					return { data: {
						escapedOffsets: offsets,
						escaped: isAnySideFullyClipped(offsets)
					} };
				}
				default: return {};
			}
		}
	};
};
var originSides = /*#__PURE__*/ new Set(["left", "top"]);
async function convertValueToCoords(state, options) {
	const { placement, platform, elements } = state;
	const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating));
	const side = getSide(placement);
	const alignment = getAlignment(placement);
	const isVertical = getSideAxis(placement) === "y";
	const mainAxisMulti = originSides.has(side) ? -1 : 1;
	const crossAxisMulti = rtl && isVertical ? -1 : 1;
	const rawValue = evaluate(options, state);
	let { mainAxis, crossAxis, alignmentAxis } = typeof rawValue === "number" ? {
		mainAxis: rawValue,
		crossAxis: 0,
		alignmentAxis: null
	} : {
		mainAxis: rawValue.mainAxis || 0,
		crossAxis: rawValue.crossAxis || 0,
		alignmentAxis: rawValue.alignmentAxis
	};
	if (alignment && typeof alignmentAxis === "number") crossAxis = alignment === "end" ? alignmentAxis * -1 : alignmentAxis;
	return isVertical ? {
		x: crossAxis * crossAxisMulti,
		y: mainAxis * mainAxisMulti
	} : {
		x: mainAxis * mainAxisMulti,
		y: crossAxis * crossAxisMulti
	};
}
/**
* Modifies the placement by translating the floating element along the
* specified axes.
* A number (shorthand for `mainAxis` or distance), or an axes configuration
* object may be passed.
* @see https://floating-ui.com/docs/offset
*/
var offset$2 = function(options) {
	if (options === void 0) options = 0;
	return {
		name: "offset",
		options,
		async fn(state) {
			var _middlewareData$offse, _middlewareData$arrow;
			const { x, y, placement, middlewareData } = state;
			const diffCoords = await convertValueToCoords(state, options);
			if (placement === ((_middlewareData$offse = middlewareData.offset) == null ? void 0 : _middlewareData$offse.placement) && (_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) return {};
			return {
				x: x + diffCoords.x,
				y: y + diffCoords.y,
				data: {
					...diffCoords,
					placement
				}
			};
		}
	};
};
/**
* Optimizes the visibility of the floating element by shifting it in order to
* keep it in view when it will overflow the clipping boundary.
* @see https://floating-ui.com/docs/shift
*/
var shift$2 = function(options) {
	if (options === void 0) options = {};
	return {
		name: "shift",
		options,
		async fn(state) {
			const { x, y, placement, platform } = state;
			const { mainAxis: checkMainAxis = true, crossAxis: checkCrossAxis = false, limiter = { fn: (_ref) => {
				let { x, y } = _ref;
				return {
					x,
					y
				};
			} }, ...detectOverflowOptions } = evaluate(options, state);
			const coords = {
				x,
				y
			};
			const overflow = await platform.detectOverflow(state, detectOverflowOptions);
			const crossAxis = getSideAxis(placement);
			const mainAxis = getOppositeAxis(crossAxis);
			let mainAxisCoord = coords[mainAxis];
			let crossAxisCoord = coords[crossAxis];
			const clampCoord = (axis, coord) => clamp(coord + overflow[axis === "y" ? "top" : "left"], coord, coord - overflow[axis === "y" ? "bottom" : "right"]);
			if (checkMainAxis) mainAxisCoord = clampCoord(mainAxis, mainAxisCoord);
			if (checkCrossAxis) crossAxisCoord = clampCoord(crossAxis, crossAxisCoord);
			const limitedCoords = limiter.fn({
				...state,
				[mainAxis]: mainAxisCoord,
				[crossAxis]: crossAxisCoord
			});
			return {
				...limitedCoords,
				data: {
					x: limitedCoords.x - x,
					y: limitedCoords.y - y,
					enabled: {
						[mainAxis]: checkMainAxis,
						[crossAxis]: checkCrossAxis
					}
				}
			};
		}
	};
};
/**
* Built-in `limiter` that will stop `shift()` at a certain point.
*/
var limitShift$2 = function(options) {
	if (options === void 0) options = {};
	return {
		options,
		fn(state) {
			var _rawOffset$mainAxis, _rawOffset$crossAxis;
			const { x, y, placement, rects, middlewareData } = state;
			const { offset = 0, mainAxis: checkMainAxis = true, crossAxis: checkCrossAxis = true } = evaluate(options, state);
			const coords = {
				x,
				y
			};
			const crossAxis = getSideAxis(placement);
			const mainAxis = getOppositeAxis(crossAxis);
			let mainAxisCoord = coords[mainAxis];
			let crossAxisCoord = coords[crossAxis];
			const rawOffset = evaluate(offset, state);
			const computedOffset = typeof rawOffset === "number" ? {
				mainAxis: rawOffset,
				crossAxis: 0
			} : {
				mainAxis: (_rawOffset$mainAxis = rawOffset.mainAxis) != null ? _rawOffset$mainAxis : 0,
				crossAxis: (_rawOffset$crossAxis = rawOffset.crossAxis) != null ? _rawOffset$crossAxis : 0
			};
			if (checkMainAxis) {
				const len = mainAxis === "y" ? "height" : "width";
				const limitMin = rects.reference[mainAxis] - rects.floating[len] + computedOffset.mainAxis;
				const limitMax = rects.reference[mainAxis] + rects.reference[len] - computedOffset.mainAxis;
				if (mainAxisCoord < limitMin) mainAxisCoord = limitMin;
				else if (mainAxisCoord > limitMax) mainAxisCoord = limitMax;
			}
			if (checkCrossAxis) {
				var _middlewareData$offse, _middlewareData$offse2;
				const len = mainAxis === "y" ? "width" : "height";
				const isOriginSide = originSides.has(getSide(placement));
				const limitMin = rects.reference[crossAxis] - rects.floating[len] + (isOriginSide ? ((_middlewareData$offse = middlewareData.offset) == null ? void 0 : _middlewareData$offse[crossAxis]) || 0 : 0) + (isOriginSide ? 0 : computedOffset.crossAxis);
				const limitMax = rects.reference[crossAxis] + rects.reference[len] + (isOriginSide ? 0 : ((_middlewareData$offse2 = middlewareData.offset) == null ? void 0 : _middlewareData$offse2[crossAxis]) || 0) - (isOriginSide ? computedOffset.crossAxis : 0);
				if (crossAxisCoord < limitMin) crossAxisCoord = limitMin;
				else if (crossAxisCoord > limitMax) crossAxisCoord = limitMax;
			}
			return {
				[mainAxis]: mainAxisCoord,
				[crossAxis]: crossAxisCoord
			};
		}
	};
};
/**
* Provides data that allows you to change the size of the floating element —
* for instance, prevent it from overflowing the clipping boundary or match the
* width of the reference element.
* @see https://floating-ui.com/docs/size
*/
var size$2 = function(options) {
	if (options === void 0) options = {};
	return {
		name: "size",
		options,
		async fn(state) {
			const { placement, rects, platform, elements } = state;
			const { apply = () => {}, ...detectOverflowOptions } = evaluate(options, state);
			const overflow = await platform.detectOverflow(state, detectOverflowOptions);
			const side = getSide(placement);
			const alignment = getAlignment(placement);
			const isYAxis = getSideAxis(placement) === "y";
			const { width, height } = rects.floating;
			let heightSide;
			let widthSide;
			if (side === "top" || side === "bottom") {
				heightSide = side;
				widthSide = alignment === (await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating)) ? "start" : "end") ? "left" : "right";
			} else {
				widthSide = side;
				heightSide = alignment === "end" ? "top" : "bottom";
			}
			const maximumClippingHeight = height - overflow.top - overflow.bottom;
			const maximumClippingWidth = width - overflow.left - overflow.right;
			const overflowAvailableHeight = min(height - overflow[heightSide], maximumClippingHeight);
			const overflowAvailableWidth = min(width - overflow[widthSide], maximumClippingWidth);
			const shiftData = state.middlewareData.shift;
			const noShift = !shiftData;
			let availableHeight = overflowAvailableHeight;
			let availableWidth = overflowAvailableWidth;
			if (shiftData != null && shiftData.enabled.x) availableWidth = maximumClippingWidth;
			if (shiftData != null && shiftData.enabled.y) availableHeight = maximumClippingHeight;
			if (noShift && !alignment) {
				if (isYAxis) availableWidth = width - 2 * max(overflow.left, overflow.right);
				else availableHeight = height - 2 * max(overflow.top, overflow.bottom);
			}
			await apply({
				...state,
				availableWidth,
				availableHeight
			});
			const nextDimensions = await platform.getDimensions(elements.floating);
			if (width !== nextDimensions.width || height !== nextDimensions.height) return { reset: { rects: true } };
			return {};
		}
	};
};
//#endregion
//#region node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs
function hasWindow() {
	return typeof window !== "undefined";
}
function getNodeName(node) {
	if (isNode(node)) return (node.nodeName || "").toLowerCase();
	return "#document";
}
function getWindow(node) {
	var _node$ownerDocument;
	return (node == null || (_node$ownerDocument = node.ownerDocument) == null ? void 0 : _node$ownerDocument.defaultView) || window;
}
function getDocumentElement(node) {
	var _ref;
	return (_ref = (isNode(node) ? node.ownerDocument : node.document) || window.document) == null ? void 0 : _ref.documentElement;
}
function isNode(value) {
	if (!hasWindow()) return false;
	return value instanceof Node || value instanceof getWindow(value).Node;
}
function isElement(value) {
	if (!hasWindow()) return false;
	return value instanceof Element || value instanceof getWindow(value).Element;
}
function isHTMLElement(value) {
	if (!hasWindow()) return false;
	return value instanceof HTMLElement || value instanceof getWindow(value).HTMLElement;
}
function isShadowRoot(value) {
	if (!hasWindow() || typeof ShadowRoot === "undefined") return false;
	return value instanceof ShadowRoot || value instanceof getWindow(value).ShadowRoot;
}
function isOverflowElement(element) {
	const { overflow, overflowX, overflowY, display } = getComputedStyle$1(element);
	return /auto|scroll|overlay|hidden|clip/.test(overflow + overflowY + overflowX) && display !== "inline" && display !== "contents";
}
function isTableElement(element) {
	return /^(table|td|th)$/.test(getNodeName(element));
}
function isTopLayer(element) {
	try {
		if (element.matches(":popover-open")) return true;
	} catch (_e) {}
	try {
		return element.matches(":modal");
	} catch (_e) {
		return false;
	}
}
var willChangeRe = /transform|translate|scale|rotate|perspective|filter/;
var containRe = /paint|layout|strict|content/;
var isNotNone = (value) => !!value && value !== "none";
var isWebKitValue;
function isContainingBlock(elementOrCss) {
	const css = isElement(elementOrCss) ? getComputedStyle$1(elementOrCss) : elementOrCss;
	return isNotNone(css.transform) || isNotNone(css.translate) || isNotNone(css.scale) || isNotNone(css.rotate) || isNotNone(css.perspective) || !isWebKit() && (isNotNone(css.backdropFilter) || isNotNone(css.filter)) || willChangeRe.test(css.willChange || "") || containRe.test(css.contain || "");
}
function getContainingBlock(element) {
	let currentNode = getParentNode(element);
	while (isHTMLElement(currentNode) && !isLastTraversableNode(currentNode)) {
		if (isContainingBlock(currentNode)) return currentNode;
		else if (isTopLayer(currentNode)) return null;
		currentNode = getParentNode(currentNode);
	}
	return null;
}
function isWebKit() {
	if (isWebKitValue == null) isWebKitValue = typeof CSS !== "undefined" && CSS.supports && CSS.supports("-webkit-backdrop-filter", "none");
	return isWebKitValue;
}
function isLastTraversableNode(node) {
	return /^(html|body|#document)$/.test(getNodeName(node));
}
function getComputedStyle$1(element) {
	return getWindow(element).getComputedStyle(element);
}
function getNodeScroll(element) {
	if (isElement(element)) return {
		scrollLeft: element.scrollLeft,
		scrollTop: element.scrollTop
	};
	return {
		scrollLeft: element.scrollX,
		scrollTop: element.scrollY
	};
}
function getParentNode(node) {
	if (getNodeName(node) === "html") return node;
	const result = node.assignedSlot || node.parentNode || isShadowRoot(node) && node.host || getDocumentElement(node);
	return isShadowRoot(result) ? result.host : result;
}
function getNearestOverflowAncestor(node) {
	const parentNode = getParentNode(node);
	if (isLastTraversableNode(parentNode)) return (node.ownerDocument || node).body;
	if (isHTMLElement(parentNode) && isOverflowElement(parentNode)) return parentNode;
	return getNearestOverflowAncestor(parentNode);
}
function getOverflowAncestors(node, list, traverseIframes) {
	var _node$ownerDocument2;
	if (list === void 0) list = [];
	if (traverseIframes === void 0) traverseIframes = true;
	const scrollableAncestor = getNearestOverflowAncestor(node);
	const isBody = scrollableAncestor === ((_node$ownerDocument2 = node.ownerDocument) == null ? void 0 : _node$ownerDocument2.body);
	const win = getWindow(scrollableAncestor);
	if (isBody) {
		const frameElement = getFrameElement(win);
		return list.concat(win, win.visualViewport || [], isOverflowElement(scrollableAncestor) ? scrollableAncestor : [], frameElement && traverseIframes ? getOverflowAncestors(frameElement) : []);
	} else return list.concat(scrollableAncestor, getOverflowAncestors(scrollableAncestor, [], traverseIframes));
}
function getFrameElement(win) {
	return win.parent && Object.getPrototypeOf(win.parent) ? win.frameElement : null;
}
//#endregion
//#region node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs
function getCssDimensions(element) {
	const css = getComputedStyle$1(element);
	let width = parseFloat(css.width) || 0;
	let height = parseFloat(css.height) || 0;
	const hasOffset = isHTMLElement(element);
	const offsetWidth = hasOffset ? element.offsetWidth : width;
	const offsetHeight = hasOffset ? element.offsetHeight : height;
	const shouldFallback = round(width) !== offsetWidth || round(height) !== offsetHeight;
	if (shouldFallback) {
		width = offsetWidth;
		height = offsetHeight;
	}
	return {
		width,
		height,
		$: shouldFallback
	};
}
function unwrapElement(element) {
	return !isElement(element) ? element.contextElement : element;
}
function getScale(element) {
	const domElement = unwrapElement(element);
	if (!isHTMLElement(domElement)) return createCoords(1);
	const rect = domElement.getBoundingClientRect();
	const { width, height, $ } = getCssDimensions(domElement);
	let x = ($ ? round(rect.width) : rect.width) / width;
	let y = ($ ? round(rect.height) : rect.height) / height;
	if (!x || !Number.isFinite(x)) x = 1;
	if (!y || !Number.isFinite(y)) y = 1;
	return {
		x,
		y
	};
}
var noOffsets = /*#__PURE__*/ createCoords(0);
function getVisualOffsets(element) {
	const win = getWindow(element);
	if (!isWebKit() || !win.visualViewport) return noOffsets;
	return {
		x: win.visualViewport.offsetLeft,
		y: win.visualViewport.offsetTop
	};
}
function shouldAddVisualOffsets(element, isFixed, floatingOffsetParent) {
	if (isFixed === void 0) isFixed = false;
	return !!floatingOffsetParent && isFixed && floatingOffsetParent === getWindow(element);
}
function getBoundingClientRect(element, includeScale, isFixedStrategy, offsetParent) {
	if (includeScale === void 0) includeScale = false;
	if (isFixedStrategy === void 0) isFixedStrategy = false;
	const clientRect = element.getBoundingClientRect();
	const domElement = unwrapElement(element);
	let scale = createCoords(1);
	if (includeScale) {
		if (offsetParent) {
			if (isElement(offsetParent)) scale = getScale(offsetParent);
		} else scale = getScale(element);
	}
	const visualOffsets = shouldAddVisualOffsets(domElement, isFixedStrategy, offsetParent) ? getVisualOffsets(domElement) : createCoords(0);
	let x = (clientRect.left + visualOffsets.x) / scale.x;
	let y = (clientRect.top + visualOffsets.y) / scale.y;
	let width = clientRect.width / scale.x;
	let height = clientRect.height / scale.y;
	if (domElement && offsetParent) {
		const win = getWindow(domElement);
		const offsetWin = isElement(offsetParent) ? getWindow(offsetParent) : offsetParent;
		let currentWin = win;
		let currentIFrame = getFrameElement(currentWin);
		while (currentIFrame && offsetWin !== currentWin) {
			const iframeScale = getScale(currentIFrame);
			const iframeRect = currentIFrame.getBoundingClientRect();
			const css = getComputedStyle$1(currentIFrame);
			const left = iframeRect.left + (currentIFrame.clientLeft + parseFloat(css.paddingLeft)) * iframeScale.x;
			const top = iframeRect.top + (currentIFrame.clientTop + parseFloat(css.paddingTop)) * iframeScale.y;
			x *= iframeScale.x;
			y *= iframeScale.y;
			width *= iframeScale.x;
			height *= iframeScale.y;
			x += left;
			y += top;
			currentWin = getWindow(currentIFrame);
			currentIFrame = getFrameElement(currentWin);
		}
	}
	return rectToClientRect({
		width,
		height,
		x,
		y
	});
}
function getWindowScrollBarX(element, rect) {
	const leftScroll = getNodeScroll(element).scrollLeft;
	if (!rect) return getBoundingClientRect(getDocumentElement(element)).left + leftScroll;
	return rect.left + leftScroll;
}
function getHTMLOffset(documentElement, scroll) {
	const htmlRect = documentElement.getBoundingClientRect();
	return {
		x: htmlRect.left + scroll.scrollLeft - getWindowScrollBarX(documentElement, htmlRect),
		y: htmlRect.top + scroll.scrollTop
	};
}
function convertOffsetParentRelativeRectToViewportRelativeRect(_ref) {
	let { elements, rect, offsetParent, strategy } = _ref;
	const isFixed = strategy === "fixed";
	const documentElement = getDocumentElement(offsetParent);
	const topLayer = elements ? isTopLayer(elements.floating) : false;
	if (offsetParent === documentElement || topLayer && isFixed) return rect;
	let scroll = {
		scrollLeft: 0,
		scrollTop: 0
	};
	let scale = createCoords(1);
	const offsets = createCoords(0);
	const isOffsetParentAnElement = isHTMLElement(offsetParent);
	if (isOffsetParentAnElement || !isFixed) {
		if (getNodeName(offsetParent) !== "body" || isOverflowElement(documentElement)) scroll = getNodeScroll(offsetParent);
		if (isOffsetParentAnElement) {
			const offsetRect = getBoundingClientRect(offsetParent);
			scale = getScale(offsetParent);
			offsets.x = offsetRect.x + offsetParent.clientLeft;
			offsets.y = offsetRect.y + offsetParent.clientTop;
		}
	}
	const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
	return {
		width: rect.width * scale.x,
		height: rect.height * scale.y,
		x: rect.x * scale.x - scroll.scrollLeft * scale.x + offsets.x + htmlOffset.x,
		y: rect.y * scale.y - scroll.scrollTop * scale.y + offsets.y + htmlOffset.y
	};
}
function getClientRects(element) {
	return element.getClientRects ? Array.from(element.getClientRects()) : [];
}
function getDocumentRect(html) {
	const scroll = getNodeScroll(html);
	const body = html.ownerDocument.body;
	const width = max(html.scrollWidth, html.clientWidth, body.scrollWidth, body.clientWidth);
	const height = max(html.scrollHeight, html.clientHeight, body.scrollHeight, body.clientHeight);
	let x = -scroll.scrollLeft + getWindowScrollBarX(html);
	const y = -scroll.scrollTop;
	if (getComputedStyle$1(body).direction === "rtl") x += max(html.clientWidth, body.clientWidth) - width;
	return {
		width,
		height,
		x,
		y
	};
}
var SCROLLBAR_MAX = 25;
function getViewportRect(element, strategy, rootBoundary) {
	if (rootBoundary === void 0) rootBoundary = "viewport";
	const isLayoutViewport = rootBoundary === "layoutViewport";
	const win = getWindow(element);
	const html = getDocumentElement(element);
	const visualViewport = win.visualViewport;
	let width = html.clientWidth;
	let height = html.clientHeight;
	let x = 0;
	let y = 0;
	if (visualViewport) {
		const layoutRelativeClientCoords = !isWebKit() || strategy === "fixed";
		if (isLayoutViewport) {
			if (!layoutRelativeClientCoords) {
				x = -visualViewport.offsetLeft;
				y = -visualViewport.offsetTop;
			}
		} else {
			width = visualViewport.width;
			height = visualViewport.height;
			if (layoutRelativeClientCoords) {
				x = visualViewport.offsetLeft;
				y = visualViewport.offsetTop;
			}
		}
	}
	if (getWindowScrollBarX(html) <= 0) {
		const doc = html.ownerDocument;
		const body = doc.body;
		const bodyStyles = getComputedStyle(body);
		const bodyMarginInline = doc.compatMode === "CSS1Compat" ? parseFloat(bodyStyles.marginLeft) + parseFloat(bodyStyles.marginRight) || 0 : 0;
		const reservedWidth = Math.abs(html.clientWidth - body.clientWidth - bodyMarginInline);
		const gutter = getComputedStyle(html).scrollbarGutter === "stable both-edges" ? reservedWidth / 2 : reservedWidth;
		if (gutter <= SCROLLBAR_MAX) width -= gutter;
	}
	return {
		width,
		height,
		x,
		y
	};
}
function getInnerBoundingClientRect(element, strategy) {
	const clientRect = getBoundingClientRect(element, true, strategy === "fixed");
	const top = clientRect.top + element.clientTop;
	const left = clientRect.left + element.clientLeft;
	const scale = getScale(element);
	return {
		width: element.clientWidth * scale.x,
		height: element.clientHeight * scale.y,
		x: left * scale.x,
		y: top * scale.y
	};
}
function getClientRectFromClippingAncestor(element, clippingAncestor, strategy) {
	let rect;
	if (clippingAncestor === "viewport" || clippingAncestor === "layoutViewport") rect = getViewportRect(element, strategy, clippingAncestor);
	else if (clippingAncestor === "document") rect = getDocumentRect(getDocumentElement(element));
	else if (isElement(clippingAncestor)) rect = getInnerBoundingClientRect(clippingAncestor, strategy);
	else {
		const visualOffsets = getVisualOffsets(element);
		rect = {
			x: clippingAncestor.x - visualOffsets.x,
			y: clippingAncestor.y - visualOffsets.y,
			width: clippingAncestor.width,
			height: clippingAncestor.height
		};
	}
	return rectToClientRect(rect);
}
function getClippingElementAncestors(element, cache) {
	const cachedResult = cache.get(element);
	if (cachedResult) return cachedResult;
	let result = getOverflowAncestors(element, [], false).filter((el) => isElement(el) && getNodeName(el) !== "body");
	let lastKeptComputedStyle = null;
	const elementIsFixed = getComputedStyle$1(element).position === "fixed";
	let currentNode = elementIsFixed ? getParentNode(element) : element;
	while (isElement(currentNode) && !isLastTraversableNode(currentNode)) {
		const computedStyle = getComputedStyle$1(currentNode);
		const currentNodeIsContaining = isContainingBlock(currentNode);
		const lastPosition = lastKeptComputedStyle ? lastKeptComputedStyle.position : elementIsFixed ? "fixed" : "";
		if (!currentNodeIsContaining && (lastPosition === "fixed" || lastPosition === "absolute" && computedStyle.position === "static")) result = result.filter((ancestor) => ancestor !== currentNode);
		else lastKeptComputedStyle = computedStyle;
		currentNode = getParentNode(currentNode);
	}
	cache.set(element, result);
	return result;
}
function getClippingRect(_ref) {
	let { element, boundary, rootBoundary, strategy } = _ref;
	const clippingAncestors = [...boundary === "clippingAncestors" ? isTopLayer(element) ? [] : getClippingElementAncestors(element, this._c) : [].concat(boundary), rootBoundary];
	const firstRect = getClientRectFromClippingAncestor(element, clippingAncestors[0], strategy);
	let top = firstRect.top;
	let right = firstRect.right;
	let bottom = firstRect.bottom;
	let left = firstRect.left;
	for (let i = 1; i < clippingAncestors.length; i++) {
		const rect = getClientRectFromClippingAncestor(element, clippingAncestors[i], strategy);
		top = max(rect.top, top);
		right = min(rect.right, right);
		bottom = min(rect.bottom, bottom);
		left = max(rect.left, left);
	}
	return {
		width: right - left,
		height: bottom - top,
		x: left,
		y: top
	};
}
function getDimensions(element) {
	const { width, height } = getCssDimensions(element);
	return {
		width,
		height
	};
}
function getRectRelativeToOffsetParent(element, offsetParent, strategy) {
	const isOffsetParentAnElement = isHTMLElement(offsetParent);
	const documentElement = getDocumentElement(offsetParent);
	const isFixed = strategy === "fixed";
	const rect = getBoundingClientRect(element, true, isFixed, offsetParent);
	let scroll = {
		scrollLeft: 0,
		scrollTop: 0
	};
	const offsets = createCoords(0);
	if (isOffsetParentAnElement || !isFixed) {
		if (getNodeName(offsetParent) !== "body" || isOverflowElement(documentElement)) scroll = getNodeScroll(offsetParent);
		if (isOffsetParentAnElement) {
			const offsetRect = getBoundingClientRect(offsetParent, true, isFixed, offsetParent);
			offsets.x = offsetRect.x + offsetParent.clientLeft;
			offsets.y = offsetRect.y + offsetParent.clientTop;
		}
	}
	if (!isOffsetParentAnElement && documentElement) offsets.x = getWindowScrollBarX(documentElement);
	const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
	return {
		x: rect.left + scroll.scrollLeft - offsets.x - htmlOffset.x,
		y: rect.top + scroll.scrollTop - offsets.y - htmlOffset.y,
		width: rect.width,
		height: rect.height
	};
}
function isStaticPositioned(element) {
	return getComputedStyle$1(element).position === "static";
}
function getTrueOffsetParent(element, polyfill) {
	if (!isHTMLElement(element) || getComputedStyle$1(element).position === "fixed") return null;
	if (polyfill) return polyfill(element);
	let rawOffsetParent = element.offsetParent;
	if (getDocumentElement(element) === rawOffsetParent) rawOffsetParent = rawOffsetParent.ownerDocument.body;
	return rawOffsetParent;
}
function getOffsetParent(element, polyfill) {
	const win = getWindow(element);
	if (isTopLayer(element)) return win;
	if (!isHTMLElement(element)) {
		let svgOffsetParent = getParentNode(element);
		while (svgOffsetParent && !isLastTraversableNode(svgOffsetParent)) {
			if (isElement(svgOffsetParent) && !isStaticPositioned(svgOffsetParent)) return svgOffsetParent;
			svgOffsetParent = getParentNode(svgOffsetParent);
		}
		return win;
	}
	let offsetParent = getTrueOffsetParent(element, polyfill);
	while (offsetParent && isTableElement(offsetParent) && isStaticPositioned(offsetParent)) offsetParent = getTrueOffsetParent(offsetParent, polyfill);
	if (offsetParent && isLastTraversableNode(offsetParent) && isStaticPositioned(offsetParent) && !isContainingBlock(offsetParent)) return win;
	return offsetParent || getContainingBlock(element) || win;
}
var getElementRects = async function(data) {
	const getOffsetParentFn = this.getOffsetParent || getOffsetParent;
	const getDimensionsFn = this.getDimensions;
	const floatingDimensions = await getDimensionsFn(data.floating);
	return {
		reference: getRectRelativeToOffsetParent(data.reference, await getOffsetParentFn(data.floating), data.strategy),
		floating: {
			x: 0,
			y: 0,
			width: floatingDimensions.width,
			height: floatingDimensions.height
		}
	};
};
function isRTL(element) {
	return getComputedStyle$1(element).direction === "rtl";
}
var platform = {
	convertOffsetParentRelativeRectToViewportRelativeRect,
	getDocumentElement,
	getClippingRect,
	getOffsetParent,
	getElementRects,
	getClientRects,
	getDimensions,
	getScale,
	isElement,
	isRTL
};
function rectsAreEqual(a, b) {
	return a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height;
}
function observeMove(element, onMove, ancestorResize) {
	let io = null;
	let timeoutId;
	const root = getDocumentElement(element);
	function cleanup() {
		var _io;
		clearTimeout(timeoutId);
		(_io = io) == null || _io.disconnect();
		io = null;
	}
	function refresh(skip, threshold) {
		if (skip === void 0) skip = false;
		if (threshold === void 0) threshold = 1;
		cleanup();
		const elementRectForRootMargin = element.getBoundingClientRect();
		const { left, top, width, height } = elementRectForRootMargin;
		if (!skip) onMove();
		if (!width || !height) return;
		const insetTop = floor(top);
		const insetRight = floor(root.clientWidth - (left + width));
		const insetBottom = floor(root.clientHeight - (top + height));
		const insetLeft = floor(left);
		const options = {
			rootMargin: -insetTop + "px " + -insetRight + "px " + -insetBottom + "px " + -insetLeft + "px",
			threshold: max(0, min(1, threshold)) || 1
		};
		let isFirstUpdate = true;
		function handleObserve(entries) {
			const ratio = entries[0].intersectionRatio;
			if (!rectsAreEqual(elementRectForRootMargin, element.getBoundingClientRect())) return refresh();
			if (ratio !== threshold) {
				if (!isFirstUpdate) return refresh();
				if (!ratio) timeoutId = setTimeout(() => {
					refresh(false, 1e-7);
				}, 1e3);
				else refresh(false, ratio);
			}
			isFirstUpdate = false;
		}
		try {
			io = new IntersectionObserver(handleObserve, {
				...options,
				root: root.ownerDocument
			});
		} catch (_e) {
			io = new IntersectionObserver(handleObserve, options);
		}
		io.observe(element);
	}
	const win = getWindow(element);
	const handleResize = () => refresh(ancestorResize);
	win.addEventListener("resize", handleResize);
	refresh(true);
	return () => {
		win.removeEventListener("resize", handleResize);
		cleanup();
	};
}
/**
* Automatically updates the position of the floating element when necessary.
* Should only be called when the floating element is mounted on the DOM or
* visible on the screen.
* @returns cleanup function that should be invoked when the floating element is
* removed from the DOM or hidden from the screen.
* @see https://floating-ui.com/docs/autoUpdate
*/
function autoUpdate(reference, floating, update, options) {
	if (options === void 0) options = {};
	const { ancestorScroll = true, ancestorResize = true, elementResize = typeof ResizeObserver === "function", layoutShift = typeof IntersectionObserver === "function", animationFrame = false } = options;
	const referenceEl = unwrapElement(reference);
	const ancestors = ancestorScroll || ancestorResize ? [...referenceEl ? getOverflowAncestors(referenceEl) : [], ...floating ? getOverflowAncestors(floating) : []] : [];
	ancestors.forEach((ancestor) => {
		ancestorScroll && ancestor.addEventListener("scroll", update);
		ancestorResize && ancestor.addEventListener("resize", update);
	});
	const cleanupIo = referenceEl && layoutShift ? observeMove(referenceEl, update, ancestorResize) : null;
	let reobserveFrame = -1;
	let resizeObserver = null;
	if (elementResize) {
		resizeObserver = new ResizeObserver((_ref) => {
			let [firstEntry] = _ref;
			if (firstEntry && firstEntry.target === referenceEl && resizeObserver && floating) {
				resizeObserver.unobserve(floating);
				cancelAnimationFrame(reobserveFrame);
				reobserveFrame = requestAnimationFrame(() => {
					var _resizeObserver;
					(_resizeObserver = resizeObserver) == null || _resizeObserver.observe(floating);
				});
			}
			update();
		});
		if (referenceEl && !animationFrame) resizeObserver.observe(referenceEl);
		if (floating) resizeObserver.observe(floating);
	}
	let frameId;
	let prevRefRect = animationFrame ? getBoundingClientRect(reference) : null;
	if (animationFrame) frameLoop();
	function frameLoop() {
		const nextRefRect = getBoundingClientRect(reference);
		if (prevRefRect && !rectsAreEqual(prevRefRect, nextRefRect)) update();
		prevRefRect = nextRefRect;
		frameId = requestAnimationFrame(frameLoop);
	}
	update();
	return () => {
		var _resizeObserver2;
		ancestors.forEach((ancestor) => {
			ancestorScroll && ancestor.removeEventListener("scroll", update);
			ancestorResize && ancestor.removeEventListener("resize", update);
		});
		cleanupIo?.();
		(_resizeObserver2 = resizeObserver) == null || _resizeObserver2.disconnect();
		resizeObserver = null;
		if (animationFrame) cancelAnimationFrame(frameId);
	};
}
/**
* Modifies the placement by translating the floating element along the
* specified axes.
* A number (shorthand for `mainAxis` or distance), or an axes configuration
* object may be passed.
* @see https://floating-ui.com/docs/offset
*/
var offset$1 = offset$2;
/**
* Optimizes the visibility of the floating element by shifting it in order to
* keep it in view when it will overflow the clipping boundary.
* @see https://floating-ui.com/docs/shift
*/
var shift$1 = shift$2;
/**
* Optimizes the visibility of the floating element by flipping the `placement`
* in order to keep it in view when the preferred placement(s) will overflow the
* clipping boundary. Alternative to `autoPlacement`.
* @see https://floating-ui.com/docs/flip
*/
var flip$1 = flip$2;
/**
* Provides data that allows you to change the size of the floating element —
* for instance, prevent it from overflowing the clipping boundary or match the
* width of the reference element.
* @see https://floating-ui.com/docs/size
*/
var size$1 = size$2;
/**
* Provides data to hide the floating element in applicable situations, such as
* when it is not in the same clipping context as the reference element.
* @see https://floating-ui.com/docs/hide
*/
var hide$1 = hide$2;
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow$2 = arrow$3;
/**
* Built-in `limiter` that will stop `shift()` at a certain point.
*/
var limitShift$1 = limitShift$2;
/**
* Computes the `x` and `y` coordinates that will place the floating element
* next to a given reference element.
*/
var computePosition = (reference, floating, options) => {
	const cache = /* @__PURE__ */ new Map();
	const mergedOptions = options != null ? options : {};
	const platformWithCache = {
		...platform,
		...mergedOptions.platform,
		_c: cache
	};
	return computePosition$1(reference, floating, {
		...mergedOptions,
		platform: platformWithCache
	});
};
//#endregion
//#region node_modules/@floating-ui/react-dom/dist/floating-ui.react-dom.mjs
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
var index = typeof document !== "undefined" ? import_react.useLayoutEffect : function noop() {};
function deepEqual(a, b) {
	if (a === b) return true;
	if (typeof a !== typeof b) return false;
	if (typeof a === "function" && a.toString() === b.toString()) return true;
	let length;
	let i;
	let keys;
	if (a && b && typeof a === "object") {
		if (Array.isArray(a)) {
			length = a.length;
			if (length !== b.length) return false;
			for (i = length; i-- !== 0;) if (!deepEqual(a[i], b[i])) return false;
			return true;
		}
		keys = Object.keys(a);
		length = keys.length;
		if (length !== Object.keys(b).length) return false;
		for (i = length; i-- !== 0;) if (!{}.hasOwnProperty.call(b, keys[i])) return false;
		for (i = length; i-- !== 0;) {
			const key = keys[i];
			if (key === "_owner" && a.$$typeof) continue;
			if (!deepEqual(a[key], b[key])) return false;
		}
		return true;
	}
	return a !== a && b !== b;
}
function getDPR(element) {
	if (typeof window === "undefined") return 1;
	return (element.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function roundByDPR(element, value) {
	const dpr = getDPR(element);
	return Math.round(value * dpr) / dpr;
}
function useLatestRef(value) {
	const ref = import_react.useRef(value);
	index(() => {
		ref.current = value;
	});
	return ref;
}
/**
* Provides data to position a floating element.
* @see https://floating-ui.com/docs/useFloating
*/
function useFloating(options) {
	if (options === void 0) options = {};
	const { placement = "bottom", strategy = "absolute", middleware = [], platform, elements: { reference: externalReference, floating: externalFloating } = {}, transform = true, whileElementsMounted, open } = options;
	const [data, setData] = import_react.useState({
		x: 0,
		y: 0,
		strategy,
		placement,
		middlewareData: {},
		isPositioned: false
	});
	const [latestMiddleware, setLatestMiddleware] = import_react.useState(middleware);
	if (!deepEqual(latestMiddleware, middleware)) setLatestMiddleware(middleware);
	const [_reference, _setReference] = import_react.useState(null);
	const [_floating, _setFloating] = import_react.useState(null);
	const setReference = import_react.useCallback((node) => {
		if (node !== referenceRef.current) {
			referenceRef.current = node;
			_setReference(node);
		}
	}, []);
	const setFloating = import_react.useCallback((node) => {
		if (node !== floatingRef.current) {
			floatingRef.current = node;
			_setFloating(node);
		}
	}, []);
	const referenceEl = externalReference || _reference;
	const floatingEl = externalFloating || _floating;
	const referenceRef = import_react.useRef(null);
	const floatingRef = import_react.useRef(null);
	const dataRef = import_react.useRef(data);
	const hasWhileElementsMounted = whileElementsMounted != null;
	const whileElementsMountedRef = useLatestRef(whileElementsMounted);
	const platformRef = useLatestRef(platform);
	const openRef = useLatestRef(open);
	const update = import_react.useCallback(() => {
		if (!referenceRef.current || !floatingRef.current) return;
		const config = {
			placement,
			strategy,
			middleware: latestMiddleware
		};
		if (platformRef.current) config.platform = platformRef.current;
		computePosition(referenceRef.current, floatingRef.current, config).then((data) => {
			const fullData = {
				...data,
				isPositioned: openRef.current !== false
			};
			if (isMountedRef.current && !deepEqual(dataRef.current, fullData)) {
				dataRef.current = fullData;
				import_react_dom.flushSync(() => {
					setData(fullData);
				});
			}
		});
	}, [
		latestMiddleware,
		placement,
		strategy,
		platformRef,
		openRef
	]);
	index(() => {
		if (open === false && dataRef.current.isPositioned) {
			dataRef.current.isPositioned = false;
			setData((data) => ({
				...data,
				isPositioned: false
			}));
		}
	}, [open]);
	const isMountedRef = import_react.useRef(false);
	index(() => {
		isMountedRef.current = true;
		return () => {
			isMountedRef.current = false;
		};
	}, []);
	index(() => {
		if (referenceEl) referenceRef.current = referenceEl;
		if (floatingEl) floatingRef.current = floatingEl;
		if (referenceEl && floatingEl) {
			if (whileElementsMountedRef.current) return whileElementsMountedRef.current(referenceEl, floatingEl, update);
			update();
		}
	}, [
		referenceEl,
		floatingEl,
		update,
		whileElementsMountedRef,
		hasWhileElementsMounted
	]);
	const refs = import_react.useMemo(() => ({
		reference: referenceRef,
		floating: floatingRef,
		setReference,
		setFloating
	}), [setReference, setFloating]);
	const elements = import_react.useMemo(() => ({
		reference: referenceEl,
		floating: floatingEl
	}), [referenceEl, floatingEl]);
	const floatingStyles = import_react.useMemo(() => {
		const initialStyles = {
			position: strategy,
			left: 0,
			top: 0
		};
		if (!elements.floating) return initialStyles;
		const x = roundByDPR(elements.floating, data.x);
		const y = roundByDPR(elements.floating, data.y);
		if (transform) return {
			...initialStyles,
			transform: "translate(" + x + "px, " + y + "px)",
			...getDPR(elements.floating) >= 1.5 && { willChange: "transform" }
		};
		return {
			position: strategy,
			left: x,
			top: y
		};
	}, [
		strategy,
		transform,
		elements.floating,
		data.x,
		data.y
	]);
	return import_react.useMemo(() => ({
		...data,
		update,
		refs,
		elements,
		floatingStyles
	}), [
		data,
		update,
		refs,
		elements,
		floatingStyles
	]);
}
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* This wraps the core `arrow` middleware to allow React refs as the element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow$1 = (options) => {
	function isRef(value) {
		return {}.hasOwnProperty.call(value, "current");
	}
	return {
		name: "arrow",
		options,
		fn(state) {
			const { element, padding } = typeof options === "function" ? options(state) : options;
			if (element && isRef(element)) {
				if (element.current != null) return arrow$2({
					element: element.current,
					padding
				}).fn(state);
				return {};
			}
			if (element) return arrow$2({
				element,
				padding
			}).fn(state);
			return {};
		}
	};
};
/**
* Modifies the placement by translating the floating element along the
* specified axes.
* A number (shorthand for `mainAxis` or distance), or an axes configuration
* object may be passed.
* @see https://floating-ui.com/docs/offset
*/
var offset = (options, deps) => {
	const result = offset$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Optimizes the visibility of the floating element by shifting it in order to
* keep it in view when it will overflow the clipping boundary.
* @see https://floating-ui.com/docs/shift
*/
var shift = (options, deps) => {
	const result = shift$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Built-in `limiter` that will stop `shift()` at a certain point.
*/
var limitShift = (options, deps) => {
	return {
		fn: limitShift$1(options).fn,
		options: [options, deps]
	};
};
/**
* Optimizes the visibility of the floating element by flipping the `placement`
* in order to keep it in view when the preferred placement(s) will overflow the
* clipping boundary. Alternative to `autoPlacement`.
* @see https://floating-ui.com/docs/flip
*/
var flip = (options, deps) => {
	const result = flip$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Provides data that allows you to change the size of the floating element —
* for instance, prevent it from overflowing the clipping boundary or match the
* width of the reference element.
* @see https://floating-ui.com/docs/size
*/
var size = (options, deps) => {
	const result = size$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Provides data to hide the floating element in applicable situations, such as
* when it is not in the same clipping context as the reference element.
* @see https://floating-ui.com/docs/hide
*/
var hide = (options, deps) => {
	const result = hide$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* This wraps the core `arrow` middleware to allow React refs as the element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow = (options, deps) => {
	const result = arrow$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
//#endregion
//#region node_modules/@radix-ui/react-arrow/dist/index.mjs
var import_jsx_runtime = require_jsx_runtime();
var __defProp$1 = Object.defineProperty;
var __name$1 = (target, value) => __defProp$1(target, "name", {
	value,
	configurable: true
});
var Root = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function Arrow2(props, forwardedRef) {
	const { children, width = 10, height = 5, ...arrowProps } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.svg, {
		...arrowProps,
		ref: forwardedRef,
		width,
		height,
		viewBox: "0 0 30 10",
		preserveAspectRatio: "none",
		children: props.asChild ? children : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", { points: "0,0 30,0 15,10" })
	});
}, "Arrow"));
//#endregion
//#region node_modules/@radix-ui/react-popper/dist/index.mjs
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", {
	value,
	configurable: true
});
var POPPER_NAME = "Popper";
var [createPopperContext, createPopperScope] = createContextScope(POPPER_NAME);
var [PopperProvider, usePopperContext] = createPopperContext(POPPER_NAME);
var Popper = /* @__PURE__ */ __name((props) => {
	const { __scopePopper, children } = props;
	const [anchor, setAnchor] = import_react.useState(null);
	const [placementState, setPlacementState] = import_react.useState(void 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopperProvider, {
		scope: __scopePopper,
		anchor,
		onAnchorChange: setAnchor,
		placementState,
		setPlacementState,
		children
	});
}, "Popper");
var ANCHOR_NAME = "PopperAnchor";
var PopperAnchor = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function PopperAnchor2(props, forwardedRef) {
	const { __scopePopper, virtualRef, ...anchorProps } = props;
	const context = usePopperContext(ANCHOR_NAME, __scopePopper);
	const ref = import_react.useRef(null);
	const onAnchorChange = context.onAnchorChange;
	const callbackRef = import_react.useCallback((node) => {
		ref.current = node;
		if (node) onAnchorChange(node);
	}, [onAnchorChange]);
	const composedRefs = useComposedRefs(forwardedRef, callbackRef);
	const anchorRef = import_react.useRef(null);
	import_react.useEffect(() => {
		if (!virtualRef) return;
		const previousAnchor = anchorRef.current;
		anchorRef.current = virtualRef.current;
		if (previousAnchor !== anchorRef.current) onAnchorChange(anchorRef.current);
	});
	const sideAndAlign = context.placementState && getSideAndAlignFromPlacement(context.placementState);
	const placedSide = sideAndAlign?.[0];
	const placedAlign = sideAndAlign?.[1];
	return virtualRef ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		"data-radix-popper-side": placedSide,
		"data-radix-popper-align": placedAlign,
		...anchorProps,
		ref: composedRefs
	});
}, "PopperAnchor"));
var CONTENT_NAME = "PopperContent";
var [PopperContentProvider, useContentContext] = createPopperContext(CONTENT_NAME);
var PopperContent = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function PopperContent2(props, forwardedRef) {
	const { __scopePopper, side = "bottom", sideOffset = 0, align = "center", alignOffset = 0, arrowPadding = 0, avoidCollisions = true, collisionBoundary = [], collisionPadding: collisionPaddingProp = 0, sticky = "partial", hideWhenDetached = false, updatePositionStrategy = "optimized", onPlaced, ...contentProps } = props;
	const context = usePopperContext(CONTENT_NAME, __scopePopper);
	const [content, setContent] = import_react.useState(null);
	const composedRefs = useComposedRefs(forwardedRef, setContent);
	const [arrow$4, setArrow] = import_react.useState(null);
	const arrowSize = useSize(arrow$4);
	const arrowWidth = arrowSize?.width ?? 0;
	const arrowHeight = arrowSize?.height ?? 0;
	const desiredPlacement = side + (align !== "center" ? "-" + align : "");
	const collisionPadding = typeof collisionPaddingProp === "number" ? collisionPaddingProp : {
		top: 0,
		right: 0,
		bottom: 0,
		left: 0,
		...collisionPaddingProp
	};
	const boundary = Array.isArray(collisionBoundary) ? collisionBoundary : [collisionBoundary];
	const hasExplicitBoundaries = boundary.length > 0;
	const detectOverflowOptions = {
		padding: collisionPadding,
		boundary: boundary.filter(isNotNull),
		altBoundary: hasExplicitBoundaries
	};
	const { refs, floatingStyles, placement, isPositioned, middlewareData } = useFloating({
		strategy: "fixed",
		placement: desiredPlacement,
		whileElementsMounted: /* @__PURE__ */ __name((...args) => {
			return autoUpdate(...args, { animationFrame: updatePositionStrategy === "always" });
		}, "whileElementsMounted"),
		elements: { reference: context.anchor },
		middleware: [
			offset({
				mainAxis: sideOffset + arrowHeight,
				alignmentAxis: alignOffset
			}),
			avoidCollisions && shift({
				mainAxis: true,
				crossAxis: false,
				limiter: sticky === "partial" ? limitShift() : void 0,
				...detectOverflowOptions
			}),
			avoidCollisions && flip({ ...detectOverflowOptions }),
			size({
				...detectOverflowOptions,
				apply: /* @__PURE__ */ __name(({ elements, rects, availableWidth, availableHeight }) => {
					const { width: anchorWidth, height: anchorHeight } = rects.reference;
					const contentStyle = elements.floating.style;
					contentStyle.setProperty("--radix-popper-available-width", `${availableWidth}px`);
					contentStyle.setProperty("--radix-popper-available-height", `${availableHeight}px`);
					contentStyle.setProperty("--radix-popper-anchor-width", `${anchorWidth}px`);
					contentStyle.setProperty("--radix-popper-anchor-height", `${anchorHeight}px`);
				}, "apply")
			}),
			arrow$4 && arrow({
				element: arrow$4,
				padding: arrowPadding
			}),
			transformOrigin({
				arrowWidth,
				arrowHeight
			}),
			hideWhenDetached && hide({
				strategy: "referenceHidden",
				...detectOverflowOptions,
				boundary: hasExplicitBoundaries ? detectOverflowOptions.boundary : void 0
			})
		]
	});
	const setPlacementState = context.setPlacementState;
	useLayoutEffect2(() => {
		setPlacementState(placement);
		return () => {
			setPlacementState(void 0);
		};
	}, [placement, setPlacementState]);
	const [placedSide, placedAlign] = getSideAndAlignFromPlacement(placement);
	const handlePlaced = useCallbackRef(onPlaced);
	useLayoutEffect2(() => {
		if (isPositioned) handlePlaced?.();
	}, [isPositioned, handlePlaced]);
	const arrowX = middlewareData.arrow?.x;
	const arrowY = middlewareData.arrow?.y;
	const cannotCenterArrow = middlewareData.arrow?.centerOffset !== 0;
	const [contentZIndex, setContentZIndex] = import_react.useState();
	useLayoutEffect2(() => {
		if (content) setContentZIndex(window.getComputedStyle(content).zIndex);
	}, [content]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: refs.setFloating,
		"data-radix-popper-content-wrapper": "",
		style: {
			...floatingStyles,
			transform: isPositioned ? floatingStyles.transform : "translate(0, -200%)",
			minWidth: "max-content",
			zIndex: contentZIndex,
			"--radix-popper-transform-origin": [middlewareData.transformOrigin?.x, middlewareData.transformOrigin?.y].join(" "),
			...middlewareData.hide?.referenceHidden && {
				visibility: "hidden",
				pointerEvents: "none"
			}
		},
		dir: props.dir,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopperContentProvider, {
			scope: __scopePopper,
			placedSide,
			placedAlign,
			onArrowChange: setArrow,
			arrowX,
			arrowY,
			shouldHideArrow: cannotCenterArrow,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
				"data-side": placedSide,
				"data-align": placedAlign,
				...contentProps,
				ref: composedRefs,
				style: {
					...contentProps.style,
					animation: !isPositioned ? "none" : contentProps.style?.animation
				}
			})
		})
	});
}, "PopperContent"));
var ARROW_NAME = "PopperArrow";
var OPPOSITE_SIDE = {
	top: "bottom",
	right: "left",
	bottom: "top",
	left: "right"
};
var PopperArrow = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function PopperArrow2(props, forwardedRef) {
	const { __scopePopper, ...arrowProps } = props;
	const contentContext = useContentContext(ARROW_NAME, __scopePopper);
	const baseSide = OPPOSITE_SIDE[contentContext.placedSide];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		ref: contentContext.onArrowChange,
		style: {
			position: "absolute",
			left: contentContext.arrowX,
			top: contentContext.arrowY,
			[baseSide]: 0,
			transformOrigin: {
				top: "",
				right: "0 0",
				bottom: "center 0",
				left: "100% 0"
			}[contentContext.placedSide],
			transform: {
				top: "translateY(100%)",
				right: "translateY(50%) rotate(90deg) translateX(-50%)",
				bottom: `rotate(180deg)`,
				left: "translateY(50%) rotate(-90deg) translateX(50%)"
			}[contentContext.placedSide],
			visibility: contentContext.shouldHideArrow ? "hidden" : void 0
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
			...arrowProps,
			ref: forwardedRef,
			style: {
				...arrowProps.style,
				display: "block"
			}
		})
	});
}, "PopperArrow"));
function isNotNull(value) {
	return value !== null;
}
__name(isNotNull, "isNotNull");
var transformOrigin = /* @__PURE__ */ __name((options) => ({
	name: "transformOrigin",
	options,
	fn(data) {
		const { placement, rects, middlewareData } = data;
		const isArrowHidden = middlewareData.arrow?.centerOffset !== 0;
		const arrowWidth = isArrowHidden ? 0 : options.arrowWidth;
		const arrowHeight = isArrowHidden ? 0 : options.arrowHeight;
		const [placedSide, placedAlign] = getSideAndAlignFromPlacement(placement);
		const noArrowAlign = {
			start: "0%",
			center: "50%",
			end: "100%"
		}[placedAlign];
		const arrowXCenter = (middlewareData.arrow?.x ?? 0) + arrowWidth / 2;
		const arrowYCenter = (middlewareData.arrow?.y ?? 0) + arrowHeight / 2;
		let x = "";
		let y = "";
		if (placedSide === "bottom") {
			x = isArrowHidden ? noArrowAlign : `${arrowXCenter}px`;
			y = `${-arrowHeight}px`;
		} else if (placedSide === "top") {
			x = isArrowHidden ? noArrowAlign : `${arrowXCenter}px`;
			y = `${rects.floating.height + arrowHeight}px`;
		} else if (placedSide === "right") {
			x = `${-arrowHeight}px`;
			y = isArrowHidden ? noArrowAlign : `${arrowYCenter}px`;
		} else if (placedSide === "left") {
			x = `${rects.floating.width + arrowHeight}px`;
			y = isArrowHidden ? noArrowAlign : `${arrowYCenter}px`;
		}
		return { data: {
			x,
			y
		} };
	}
}), "transformOrigin");
function getSideAndAlignFromPlacement(placement) {
	const [side, align = "center"] = placement.split("-");
	return [side, align];
}
__name(getSideAndAlignFromPlacement, "getSideAndAlignFromPlacement");
var Root2 = Popper;
var Anchor = PopperAnchor;
var Content = PopperContent;
var Arrow = PopperArrow;
//#endregion
export { createPopperScope as a, Root2 as i, Arrow as n, Content as r, Anchor as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlzdC1RQ2xYVXNUci5qcyIsIm5hbWVzIjpbImNvbXB1dGVQb3NpdGlvbiIsImFycm93IiwiZmxpcCIsImhpZGUiLCJvZmZzZXQiLCJzaGlmdCIsImxpbWl0U2hpZnQiLCJzaXplIiwiZ2V0Q29tcHV0ZWRTdHlsZSIsIm9mZnNldCIsIm9mZnNldCQxIiwic2hpZnQiLCJzaGlmdCQxIiwiZmxpcCIsImZsaXAkMSIsInNpemUiLCJzaXplJDEiLCJoaWRlIiwiaGlkZSQxIiwiYXJyb3ciLCJhcnJvdyQxIiwibGltaXRTaGlmdCIsImxpbWl0U2hpZnQkMSIsInVzZUxheW91dEVmZmVjdCIsIl9fZGVmUHJvcCIsIl9fbmFtZSIsIkFycm93IiwiYXJyb3ciLCJmbG9hdGluZ1VJYXJyb3ciLCJBcnJvd1ByaW1pdGl2ZS5Sb290Il0sInNvdXJjZXMiOlsiLi4vLi4vQGZsb2F0aW5nLXVpL3V0aWxzL2Rpc3QvZmxvYXRpbmctdWkudXRpbHMubWpzIiwiLi4vLi4vQGZsb2F0aW5nLXVpL2NvcmUvZGlzdC9mbG9hdGluZy11aS5jb3JlLm1qcyIsIi4uLy4uL0BmbG9hdGluZy11aS91dGlscy9kaXN0L2Zsb2F0aW5nLXVpLnV0aWxzLmRvbS5tanMiLCIuLi8uLi9AZmxvYXRpbmctdWkvZG9tL2Rpc3QvZmxvYXRpbmctdWkuZG9tLm1qcyIsIi4uLy4uL0BmbG9hdGluZy11aS9yZWFjdC1kb20vZGlzdC9mbG9hdGluZy11aS5yZWFjdC1kb20ubWpzIiwiLi4vLi4vQHJhZGl4LXVpL3JlYWN0LWFycm93L2Rpc3QvaW5kZXgubWpzIiwiLi4vLi4vQHJhZGl4LXVpL3JlYWN0LXBvcHBlci9kaXN0L2luZGV4Lm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEN1c3RvbSBwb3NpdGlvbmluZyByZWZlcmVuY2UgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy92aXJ0dWFsLWVsZW1lbnRzXG4gKi9cblxuY29uc3Qgc2lkZXMgPSBbJ3RvcCcsICdyaWdodCcsICdib3R0b20nLCAnbGVmdCddO1xuY29uc3QgYWxpZ25tZW50cyA9IFsnc3RhcnQnLCAnZW5kJ107XG5jb25zdCBwbGFjZW1lbnRzID0gLyojX19QVVJFX18qL3NpZGVzLnJlZHVjZSgoYWNjLCBzaWRlKSA9PiBhY2MuY29uY2F0KHNpZGUsIHNpZGUgKyBcIi1cIiArIGFsaWdubWVudHNbMF0sIHNpZGUgKyBcIi1cIiArIGFsaWdubWVudHNbMV0pLCBbXSk7XG5jb25zdCBtaW4gPSBNYXRoLm1pbjtcbmNvbnN0IG1heCA9IE1hdGgubWF4O1xuY29uc3Qgcm91bmQgPSBNYXRoLnJvdW5kO1xuY29uc3QgZmxvb3IgPSBNYXRoLmZsb29yO1xuY29uc3QgY3JlYXRlQ29vcmRzID0gdiA9PiAoe1xuICB4OiB2LFxuICB5OiB2XG59KTtcbmNvbnN0IG9wcG9zaXRlU2lkZU1hcCA9IHtcbiAgbGVmdDogJ3JpZ2h0JyxcbiAgcmlnaHQ6ICdsZWZ0JyxcbiAgYm90dG9tOiAndG9wJyxcbiAgdG9wOiAnYm90dG9tJ1xufTtcbmZ1bmN0aW9uIGNsYW1wKHN0YXJ0LCB2YWx1ZSwgZW5kKSB7XG4gIHJldHVybiBtYXgoc3RhcnQsIG1pbih2YWx1ZSwgZW5kKSk7XG59XG5mdW5jdGlvbiBldmFsdWF0ZSh2YWx1ZSwgcGFyYW0pIHtcbiAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gJ2Z1bmN0aW9uJyA/IHZhbHVlKHBhcmFtKSA6IHZhbHVlO1xufVxuZnVuY3Rpb24gZ2V0U2lkZShwbGFjZW1lbnQpIHtcbiAgcmV0dXJuIHBsYWNlbWVudC5zcGxpdCgnLScpWzBdO1xufVxuZnVuY3Rpb24gZ2V0QWxpZ25tZW50KHBsYWNlbWVudCkge1xuICByZXR1cm4gcGxhY2VtZW50LnNwbGl0KCctJylbMV07XG59XG5mdW5jdGlvbiBnZXRPcHBvc2l0ZUF4aXMoYXhpcykge1xuICByZXR1cm4gYXhpcyA9PT0gJ3gnID8gJ3knIDogJ3gnO1xufVxuZnVuY3Rpb24gZ2V0QXhpc0xlbmd0aChheGlzKSB7XG4gIHJldHVybiBheGlzID09PSAneScgPyAnaGVpZ2h0JyA6ICd3aWR0aCc7XG59XG5mdW5jdGlvbiBnZXRTaWRlQXhpcyhwbGFjZW1lbnQpIHtcbiAgY29uc3QgZmlyc3RDaGFyID0gcGxhY2VtZW50WzBdO1xuICByZXR1cm4gZmlyc3RDaGFyID09PSAndCcgfHwgZmlyc3RDaGFyID09PSAnYicgPyAneScgOiAneCc7XG59XG5mdW5jdGlvbiBnZXRBbGlnbm1lbnRBeGlzKHBsYWNlbWVudCkge1xuICByZXR1cm4gZ2V0T3Bwb3NpdGVBeGlzKGdldFNpZGVBeGlzKHBsYWNlbWVudCkpO1xufVxuZnVuY3Rpb24gZ2V0QWxpZ25tZW50U2lkZXMocGxhY2VtZW50LCByZWN0cywgcnRsKSB7XG4gIGlmIChydGwgPT09IHZvaWQgMCkge1xuICAgIHJ0bCA9IGZhbHNlO1xuICB9XG4gIGNvbnN0IGFsaWdubWVudCA9IGdldEFsaWdubWVudChwbGFjZW1lbnQpO1xuICBjb25zdCBhbGlnbm1lbnRBeGlzID0gZ2V0QWxpZ25tZW50QXhpcyhwbGFjZW1lbnQpO1xuICBjb25zdCBsZW5ndGggPSBnZXRBeGlzTGVuZ3RoKGFsaWdubWVudEF4aXMpO1xuICBsZXQgbWFpbkFsaWdubWVudFNpZGUgPSBhbGlnbm1lbnRBeGlzID09PSAneCcgPyBhbGlnbm1lbnQgPT09IChydGwgPyAnZW5kJyA6ICdzdGFydCcpID8gJ3JpZ2h0JyA6ICdsZWZ0JyA6IGFsaWdubWVudCA9PT0gJ3N0YXJ0JyA/ICdib3R0b20nIDogJ3RvcCc7XG4gIGlmIChyZWN0cy5yZWZlcmVuY2VbbGVuZ3RoXSA+IHJlY3RzLmZsb2F0aW5nW2xlbmd0aF0pIHtcbiAgICBtYWluQWxpZ25tZW50U2lkZSA9IGdldE9wcG9zaXRlUGxhY2VtZW50KG1haW5BbGlnbm1lbnRTaWRlKTtcbiAgfVxuICByZXR1cm4gW21haW5BbGlnbm1lbnRTaWRlLCBnZXRPcHBvc2l0ZVBsYWNlbWVudChtYWluQWxpZ25tZW50U2lkZSldO1xufVxuZnVuY3Rpb24gZ2V0RXhwYW5kZWRQbGFjZW1lbnRzKHBsYWNlbWVudCkge1xuICBjb25zdCBvcHBvc2l0ZVBsYWNlbWVudCA9IGdldE9wcG9zaXRlUGxhY2VtZW50KHBsYWNlbWVudCk7XG4gIHJldHVybiBbZ2V0T3Bwb3NpdGVBbGlnbm1lbnRQbGFjZW1lbnQocGxhY2VtZW50KSwgb3Bwb3NpdGVQbGFjZW1lbnQsIGdldE9wcG9zaXRlQWxpZ25tZW50UGxhY2VtZW50KG9wcG9zaXRlUGxhY2VtZW50KV07XG59XG5mdW5jdGlvbiBnZXRPcHBvc2l0ZUFsaWdubWVudFBsYWNlbWVudChwbGFjZW1lbnQpIHtcbiAgcmV0dXJuIHBsYWNlbWVudC5pbmNsdWRlcygnc3RhcnQnKSA/IHBsYWNlbWVudC5yZXBsYWNlKCdzdGFydCcsICdlbmQnKSA6IHBsYWNlbWVudC5yZXBsYWNlKCdlbmQnLCAnc3RhcnQnKTtcbn1cbmNvbnN0IGxyUGxhY2VtZW50ID0gWydsZWZ0JywgJ3JpZ2h0J107XG5jb25zdCBybFBsYWNlbWVudCA9IFsncmlnaHQnLCAnbGVmdCddO1xuY29uc3QgdGJQbGFjZW1lbnQgPSBbJ3RvcCcsICdib3R0b20nXTtcbmNvbnN0IGJ0UGxhY2VtZW50ID0gWydib3R0b20nLCAndG9wJ107XG5mdW5jdGlvbiBnZXRTaWRlTGlzdChzaWRlLCBpc1N0YXJ0LCBydGwpIHtcbiAgc3dpdGNoIChzaWRlKSB7XG4gICAgY2FzZSAndG9wJzpcbiAgICBjYXNlICdib3R0b20nOlxuICAgICAgaWYgKHJ0bCkgcmV0dXJuIGlzU3RhcnQgPyBybFBsYWNlbWVudCA6IGxyUGxhY2VtZW50O1xuICAgICAgcmV0dXJuIGlzU3RhcnQgPyBsclBsYWNlbWVudCA6IHJsUGxhY2VtZW50O1xuICAgIGNhc2UgJ2xlZnQnOlxuICAgIGNhc2UgJ3JpZ2h0JzpcbiAgICAgIHJldHVybiBpc1N0YXJ0ID8gdGJQbGFjZW1lbnQgOiBidFBsYWNlbWVudDtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIFtdO1xuICB9XG59XG5mdW5jdGlvbiBnZXRPcHBvc2l0ZUF4aXNQbGFjZW1lbnRzKHBsYWNlbWVudCwgZmxpcEFsaWdubWVudCwgZGlyZWN0aW9uLCBydGwpIHtcbiAgY29uc3QgYWxpZ25tZW50ID0gZ2V0QWxpZ25tZW50KHBsYWNlbWVudCk7XG4gIGxldCBsaXN0ID0gZ2V0U2lkZUxpc3QoZ2V0U2lkZShwbGFjZW1lbnQpLCBkaXJlY3Rpb24gPT09ICdzdGFydCcsIHJ0bCk7XG4gIGlmIChhbGlnbm1lbnQpIHtcbiAgICBsaXN0ID0gbGlzdC5tYXAoc2lkZSA9PiBzaWRlICsgXCItXCIgKyBhbGlnbm1lbnQpO1xuICAgIGlmIChmbGlwQWxpZ25tZW50KSB7XG4gICAgICBsaXN0ID0gbGlzdC5jb25jYXQobGlzdC5tYXAoZ2V0T3Bwb3NpdGVBbGlnbm1lbnRQbGFjZW1lbnQpKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGxpc3Q7XG59XG5mdW5jdGlvbiBnZXRPcHBvc2l0ZVBsYWNlbWVudChwbGFjZW1lbnQpIHtcbiAgY29uc3Qgc2lkZSA9IGdldFNpZGUocGxhY2VtZW50KTtcbiAgcmV0dXJuIG9wcG9zaXRlU2lkZU1hcFtzaWRlXSArIHBsYWNlbWVudC5zbGljZShzaWRlLmxlbmd0aCk7XG59XG5mdW5jdGlvbiBleHBhbmRQYWRkaW5nT2JqZWN0KHBhZGRpbmcpIHtcbiAgdmFyIF9wYWRkaW5nJHRvcCwgX3BhZGRpbmckcmlnaHQsIF9wYWRkaW5nJGJvdHRvbSwgX3BhZGRpbmckbGVmdDtcbiAgcmV0dXJuIHtcbiAgICB0b3A6IChfcGFkZGluZyR0b3AgPSBwYWRkaW5nLnRvcCkgIT0gbnVsbCA/IF9wYWRkaW5nJHRvcCA6IDAsXG4gICAgcmlnaHQ6IChfcGFkZGluZyRyaWdodCA9IHBhZGRpbmcucmlnaHQpICE9IG51bGwgPyBfcGFkZGluZyRyaWdodCA6IDAsXG4gICAgYm90dG9tOiAoX3BhZGRpbmckYm90dG9tID0gcGFkZGluZy5ib3R0b20pICE9IG51bGwgPyBfcGFkZGluZyRib3R0b20gOiAwLFxuICAgIGxlZnQ6IChfcGFkZGluZyRsZWZ0ID0gcGFkZGluZy5sZWZ0KSAhPSBudWxsID8gX3BhZGRpbmckbGVmdCA6IDBcbiAgfTtcbn1cbmZ1bmN0aW9uIGdldFBhZGRpbmdPYmplY3QocGFkZGluZykge1xuICByZXR1cm4gdHlwZW9mIHBhZGRpbmcgIT09ICdudW1iZXInID8gZXhwYW5kUGFkZGluZ09iamVjdChwYWRkaW5nKSA6IHtcbiAgICB0b3A6IHBhZGRpbmcsXG4gICAgcmlnaHQ6IHBhZGRpbmcsXG4gICAgYm90dG9tOiBwYWRkaW5nLFxuICAgIGxlZnQ6IHBhZGRpbmdcbiAgfTtcbn1cbmZ1bmN0aW9uIHJlY3RUb0NsaWVudFJlY3QocmVjdCkge1xuICBjb25zdCB7XG4gICAgeCxcbiAgICB5LFxuICAgIHdpZHRoLFxuICAgIGhlaWdodFxuICB9ID0gcmVjdDtcbiAgcmV0dXJuIHtcbiAgICB3aWR0aCxcbiAgICBoZWlnaHQsXG4gICAgdG9wOiB5LFxuICAgIGxlZnQ6IHgsXG4gICAgcmlnaHQ6IHggKyB3aWR0aCxcbiAgICBib3R0b206IHkgKyBoZWlnaHQsXG4gICAgeCxcbiAgICB5XG4gIH07XG59XG5cbmV4cG9ydCB7IGFsaWdubWVudHMsIGNsYW1wLCBjcmVhdGVDb29yZHMsIGV2YWx1YXRlLCBleHBhbmRQYWRkaW5nT2JqZWN0LCBmbG9vciwgZ2V0QWxpZ25tZW50LCBnZXRBbGlnbm1lbnRBeGlzLCBnZXRBbGlnbm1lbnRTaWRlcywgZ2V0QXhpc0xlbmd0aCwgZ2V0RXhwYW5kZWRQbGFjZW1lbnRzLCBnZXRPcHBvc2l0ZUFsaWdubWVudFBsYWNlbWVudCwgZ2V0T3Bwb3NpdGVBeGlzLCBnZXRPcHBvc2l0ZUF4aXNQbGFjZW1lbnRzLCBnZXRPcHBvc2l0ZVBsYWNlbWVudCwgZ2V0UGFkZGluZ09iamVjdCwgZ2V0U2lkZSwgZ2V0U2lkZUF4aXMsIG1heCwgbWluLCBwbGFjZW1lbnRzLCByZWN0VG9DbGllbnRSZWN0LCByb3VuZCwgc2lkZXMgfTtcbiIsImltcG9ydCB7IGdldFNpZGVBeGlzLCBnZXRBbGlnbm1lbnRBeGlzLCBnZXRBeGlzTGVuZ3RoLCBnZXRTaWRlLCBnZXRBbGlnbm1lbnQsIGV2YWx1YXRlLCBnZXRQYWRkaW5nT2JqZWN0LCByZWN0VG9DbGllbnRSZWN0LCBtaW4sIGNsYW1wLCBwbGFjZW1lbnRzLCBnZXRBbGlnbm1lbnRTaWRlcywgZ2V0T3Bwb3NpdGVBbGlnbm1lbnRQbGFjZW1lbnQsIGdldE9wcG9zaXRlUGxhY2VtZW50LCBnZXRFeHBhbmRlZFBsYWNlbWVudHMsIGdldE9wcG9zaXRlQXhpc1BsYWNlbWVudHMsIHNpZGVzLCBtYXgsIGdldE9wcG9zaXRlQXhpcyB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscyc7XG5leHBvcnQgeyByZWN0VG9DbGllbnRSZWN0IH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzJztcblxuZnVuY3Rpb24gY29tcHV0ZUNvb3Jkc0Zyb21QbGFjZW1lbnQoX3JlZiwgcGxhY2VtZW50LCBydGwpIHtcbiAgbGV0IHtcbiAgICByZWZlcmVuY2UsXG4gICAgZmxvYXRpbmdcbiAgfSA9IF9yZWY7XG4gIGNvbnN0IHNpZGVBeGlzID0gZ2V0U2lkZUF4aXMocGxhY2VtZW50KTtcbiAgY29uc3QgYWxpZ25tZW50QXhpcyA9IGdldEFsaWdubWVudEF4aXMocGxhY2VtZW50KTtcbiAgY29uc3QgYWxpZ25MZW5ndGggPSBnZXRBeGlzTGVuZ3RoKGFsaWdubWVudEF4aXMpO1xuICBjb25zdCBzaWRlID0gZ2V0U2lkZShwbGFjZW1lbnQpO1xuICBjb25zdCBpc1ZlcnRpY2FsID0gc2lkZUF4aXMgPT09ICd5JztcbiAgY29uc3QgY29tbW9uWCA9IHJlZmVyZW5jZS54ICsgcmVmZXJlbmNlLndpZHRoIC8gMiAtIGZsb2F0aW5nLndpZHRoIC8gMjtcbiAgY29uc3QgY29tbW9uWSA9IHJlZmVyZW5jZS55ICsgcmVmZXJlbmNlLmhlaWdodCAvIDIgLSBmbG9hdGluZy5oZWlnaHQgLyAyO1xuICBjb25zdCBjb21tb25BbGlnbiA9IHJlZmVyZW5jZVthbGlnbkxlbmd0aF0gLyAyIC0gZmxvYXRpbmdbYWxpZ25MZW5ndGhdIC8gMjtcbiAgbGV0IGNvb3JkcztcbiAgc3dpdGNoIChzaWRlKSB7XG4gICAgY2FzZSAndG9wJzpcbiAgICAgIGNvb3JkcyA9IHtcbiAgICAgICAgeDogY29tbW9uWCxcbiAgICAgICAgeTogcmVmZXJlbmNlLnkgLSBmbG9hdGluZy5oZWlnaHRcbiAgICAgIH07XG4gICAgICBicmVhaztcbiAgICBjYXNlICdib3R0b20nOlxuICAgICAgY29vcmRzID0ge1xuICAgICAgICB4OiBjb21tb25YLFxuICAgICAgICB5OiByZWZlcmVuY2UueSArIHJlZmVyZW5jZS5oZWlnaHRcbiAgICAgIH07XG4gICAgICBicmVhaztcbiAgICBjYXNlICdyaWdodCc6XG4gICAgICBjb29yZHMgPSB7XG4gICAgICAgIHg6IHJlZmVyZW5jZS54ICsgcmVmZXJlbmNlLndpZHRoLFxuICAgICAgICB5OiBjb21tb25ZXG4gICAgICB9O1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnbGVmdCc6XG4gICAgICBjb29yZHMgPSB7XG4gICAgICAgIHg6IHJlZmVyZW5jZS54IC0gZmxvYXRpbmcud2lkdGgsXG4gICAgICAgIHk6IGNvbW1vbllcbiAgICAgIH07XG4gICAgICBicmVhaztcbiAgICBkZWZhdWx0OlxuICAgICAgY29vcmRzID0ge1xuICAgICAgICB4OiByZWZlcmVuY2UueCxcbiAgICAgICAgeTogcmVmZXJlbmNlLnlcbiAgICAgIH07XG4gIH1cbiAgY29uc3QgYWxpZ25tZW50ID0gZ2V0QWxpZ25tZW50KHBsYWNlbWVudCk7XG4gIGlmIChhbGlnbm1lbnQpIHtcbiAgICBjb29yZHNbYWxpZ25tZW50QXhpc10gKz0gY29tbW9uQWxpZ24gKiAoYWxpZ25tZW50ID09PSAnZW5kJyA/IDEgOiAtMSkgKiAocnRsICYmIGlzVmVydGljYWwgPyAtMSA6IDEpO1xuICB9XG4gIHJldHVybiBjb29yZHM7XG59XG5cbi8qKlxuICogUmVzb2x2ZXMgd2l0aCBhbiBvYmplY3Qgb2Ygb3ZlcmZsb3cgc2lkZSBvZmZzZXRzIHRoYXQgZGV0ZXJtaW5lIGhvdyBtdWNoIHRoZVxuICogZWxlbWVudCBpcyBvdmVyZmxvd2luZyBhIGdpdmVuIGNsaXBwaW5nIGJvdW5kYXJ5IG9uIGVhY2ggc2lkZS5cbiAqIC0gcG9zaXRpdmUgPSBvdmVyZmxvd2luZyB0aGUgYm91bmRhcnkgYnkgdGhhdCBudW1iZXIgb2YgcGl4ZWxzXG4gKiAtIG5lZ2F0aXZlID0gaG93IG1hbnkgcGl4ZWxzIGxlZnQgYmVmb3JlIGl0IHdpbGwgb3ZlcmZsb3dcbiAqIC0gMCA9IGxpZXMgZmx1c2ggd2l0aCB0aGUgYm91bmRhcnlcbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9kZXRlY3RPdmVyZmxvd1xuICovXG5hc3luYyBmdW5jdGlvbiBkZXRlY3RPdmVyZmxvdyhzdGF0ZSwgb3B0aW9ucykge1xuICB2YXIgX2F3YWl0JHBsYXRmb3JtJGlzRWxlO1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG4gIGNvbnN0IHtcbiAgICB4LFxuICAgIHksXG4gICAgcGxhdGZvcm0sXG4gICAgcmVjdHMsXG4gICAgZWxlbWVudHMsXG4gICAgc3RyYXRlZ3lcbiAgfSA9IHN0YXRlO1xuICBjb25zdCB7XG4gICAgYm91bmRhcnkgPSAnY2xpcHBpbmdBbmNlc3RvcnMnLFxuICAgIHJvb3RCb3VuZGFyeSA9ICd2aWV3cG9ydCcsXG4gICAgZWxlbWVudENvbnRleHQgPSAnZmxvYXRpbmcnLFxuICAgIGFsdEJvdW5kYXJ5ID0gZmFsc2UsXG4gICAgcGFkZGluZyA9IDBcbiAgfSA9IGV2YWx1YXRlKG9wdGlvbnMsIHN0YXRlKTtcbiAgY29uc3QgcGFkZGluZ09iamVjdCA9IGdldFBhZGRpbmdPYmplY3QocGFkZGluZyk7XG4gIGNvbnN0IGFsdENvbnRleHQgPSBlbGVtZW50Q29udGV4dCA9PT0gJ2Zsb2F0aW5nJyA/ICdyZWZlcmVuY2UnIDogJ2Zsb2F0aW5nJztcbiAgY29uc3QgZWxlbWVudCA9IGVsZW1lbnRzW2FsdEJvdW5kYXJ5ID8gYWx0Q29udGV4dCA6IGVsZW1lbnRDb250ZXh0XTtcbiAgY29uc3QgY2xpcHBpbmdDbGllbnRSZWN0ID0gcmVjdFRvQ2xpZW50UmVjdChhd2FpdCBwbGF0Zm9ybS5nZXRDbGlwcGluZ1JlY3Qoe1xuICAgIGVsZW1lbnQ6ICgoX2F3YWl0JHBsYXRmb3JtJGlzRWxlID0gYXdhaXQgKHBsYXRmb3JtLmlzRWxlbWVudCA9PSBudWxsID8gdm9pZCAwIDogcGxhdGZvcm0uaXNFbGVtZW50KGVsZW1lbnQpKSkgIT0gbnVsbCA/IF9hd2FpdCRwbGF0Zm9ybSRpc0VsZSA6IHRydWUpID8gZWxlbWVudCA6IGVsZW1lbnQuY29udGV4dEVsZW1lbnQgfHwgKGF3YWl0IChwbGF0Zm9ybS5nZXREb2N1bWVudEVsZW1lbnQgPT0gbnVsbCA/IHZvaWQgMCA6IHBsYXRmb3JtLmdldERvY3VtZW50RWxlbWVudChlbGVtZW50cy5mbG9hdGluZykpKSxcbiAgICBib3VuZGFyeSxcbiAgICByb290Qm91bmRhcnksXG4gICAgc3RyYXRlZ3lcbiAgfSkpO1xuICBjb25zdCByZWN0ID0gZWxlbWVudENvbnRleHQgPT09ICdmbG9hdGluZycgPyB7XG4gICAgeCxcbiAgICB5LFxuICAgIHdpZHRoOiByZWN0cy5mbG9hdGluZy53aWR0aCxcbiAgICBoZWlnaHQ6IHJlY3RzLmZsb2F0aW5nLmhlaWdodFxuICB9IDogcmVjdHMucmVmZXJlbmNlO1xuICBjb25zdCBvZmZzZXRQYXJlbnQgPSBhd2FpdCAocGxhdGZvcm0uZ2V0T2Zmc2V0UGFyZW50ID09IG51bGwgPyB2b2lkIDAgOiBwbGF0Zm9ybS5nZXRPZmZzZXRQYXJlbnQoZWxlbWVudHMuZmxvYXRpbmcpKTtcbiAgY29uc3Qgb2Zmc2V0U2NhbGUgPSAoYXdhaXQgKHBsYXRmb3JtLmlzRWxlbWVudCA9PSBudWxsID8gdm9pZCAwIDogcGxhdGZvcm0uaXNFbGVtZW50KG9mZnNldFBhcmVudCkpKSAmJiAoYXdhaXQgKHBsYXRmb3JtLmdldFNjYWxlID09IG51bGwgPyB2b2lkIDAgOiBwbGF0Zm9ybS5nZXRTY2FsZShvZmZzZXRQYXJlbnQpKSkgfHwge1xuICAgIHg6IDEsXG4gICAgeTogMVxuICB9O1xuICBjb25zdCBlbGVtZW50Q2xpZW50UmVjdCA9IHJlY3RUb0NsaWVudFJlY3QocGxhdGZvcm0uY29udmVydE9mZnNldFBhcmVudFJlbGF0aXZlUmVjdFRvVmlld3BvcnRSZWxhdGl2ZVJlY3QgPyBhd2FpdCBwbGF0Zm9ybS5jb252ZXJ0T2Zmc2V0UGFyZW50UmVsYXRpdmVSZWN0VG9WaWV3cG9ydFJlbGF0aXZlUmVjdCh7XG4gICAgZWxlbWVudHMsXG4gICAgcmVjdCxcbiAgICBvZmZzZXRQYXJlbnQsXG4gICAgc3RyYXRlZ3lcbiAgfSkgOiByZWN0KTtcbiAgcmV0dXJuIHtcbiAgICB0b3A6IChjbGlwcGluZ0NsaWVudFJlY3QudG9wIC0gZWxlbWVudENsaWVudFJlY3QudG9wICsgcGFkZGluZ09iamVjdC50b3ApIC8gb2Zmc2V0U2NhbGUueSxcbiAgICBib3R0b206IChlbGVtZW50Q2xpZW50UmVjdC5ib3R0b20gLSBjbGlwcGluZ0NsaWVudFJlY3QuYm90dG9tICsgcGFkZGluZ09iamVjdC5ib3R0b20pIC8gb2Zmc2V0U2NhbGUueSxcbiAgICBsZWZ0OiAoY2xpcHBpbmdDbGllbnRSZWN0LmxlZnQgLSBlbGVtZW50Q2xpZW50UmVjdC5sZWZ0ICsgcGFkZGluZ09iamVjdC5sZWZ0KSAvIG9mZnNldFNjYWxlLngsXG4gICAgcmlnaHQ6IChlbGVtZW50Q2xpZW50UmVjdC5yaWdodCAtIGNsaXBwaW5nQ2xpZW50UmVjdC5yaWdodCArIHBhZGRpbmdPYmplY3QucmlnaHQpIC8gb2Zmc2V0U2NhbGUueFxuICB9O1xufVxuXG4vLyBNYXhpbXVtIG51bWJlciBvZiByZXNldHMgdGhhdCBjYW4gb2NjdXIgYmVmb3JlIGJhaWxpbmcgdG8gYXZvaWQgaW5maW5pdGUgcmVzZXQgbG9vcHMuXG5jb25zdCBNQVhfUkVTRVRfQ09VTlQgPSA1MDtcblxuLyoqXG4gKiBDb21wdXRlcyB0aGUgYHhgIGFuZCBgeWAgY29vcmRpbmF0ZXMgdGhhdCB3aWxsIHBsYWNlIHRoZSBmbG9hdGluZyBlbGVtZW50XG4gKiBuZXh0IHRvIGEgZ2l2ZW4gcmVmZXJlbmNlIGVsZW1lbnQuXG4gKlxuICogVGhpcyBleHBvcnQgZG9lcyBub3QgaGF2ZSBhbnkgYHBsYXRmb3JtYCBpbnRlcmZhY2UgbG9naWMuIFlvdSB3aWxsIG5lZWQgdG9cbiAqIHdyaXRlIG9uZSBmb3IgdGhlIHBsYXRmb3JtIHlvdSBhcmUgdXNpbmcgRmxvYXRpbmcgVUkgd2l0aC5cbiAqL1xuY29uc3QgY29tcHV0ZVBvc2l0aW9uID0gYXN5bmMgKHJlZmVyZW5jZSwgZmxvYXRpbmcsIGNvbmZpZykgPT4ge1xuICBjb25zdCB7XG4gICAgcGxhY2VtZW50ID0gJ2JvdHRvbScsXG4gICAgc3RyYXRlZ3kgPSAnYWJzb2x1dGUnLFxuICAgIG1pZGRsZXdhcmUgPSBbXSxcbiAgICBwbGF0Zm9ybVxuICB9ID0gY29uZmlnO1xuICBjb25zdCBwbGF0Zm9ybVdpdGhEZXRlY3RPdmVyZmxvdyA9IHBsYXRmb3JtLmRldGVjdE92ZXJmbG93ID8gcGxhdGZvcm0gOiB7XG4gICAgLi4ucGxhdGZvcm0sXG4gICAgZGV0ZWN0T3ZlcmZsb3dcbiAgfTtcbiAgY29uc3QgcnRsID0gYXdhaXQgKHBsYXRmb3JtLmlzUlRMID09IG51bGwgPyB2b2lkIDAgOiBwbGF0Zm9ybS5pc1JUTChmbG9hdGluZykpO1xuICBsZXQgcmVjdHMgPSBhd2FpdCBwbGF0Zm9ybS5nZXRFbGVtZW50UmVjdHMoe1xuICAgIHJlZmVyZW5jZSxcbiAgICBmbG9hdGluZyxcbiAgICBzdHJhdGVneVxuICB9KTtcbiAgbGV0IHtcbiAgICB4LFxuICAgIHlcbiAgfSA9IGNvbXB1dGVDb29yZHNGcm9tUGxhY2VtZW50KHJlY3RzLCBwbGFjZW1lbnQsIHJ0bCk7XG4gIGxldCBzdGF0ZWZ1bFBsYWNlbWVudCA9IHBsYWNlbWVudDtcbiAgbGV0IHJlc2V0Q291bnQgPSAwO1xuICBjb25zdCBtaWRkbGV3YXJlRGF0YSA9IHt9O1xuICBmb3IgKGxldCBpID0gMDsgaSA8IG1pZGRsZXdhcmUubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBjdXJyZW50TWlkZGxld2FyZSA9IG1pZGRsZXdhcmVbaV07XG4gICAgaWYgKCFjdXJyZW50TWlkZGxld2FyZSkge1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbnN0IHtcbiAgICAgIG5hbWUsXG4gICAgICBmblxuICAgIH0gPSBjdXJyZW50TWlkZGxld2FyZTtcbiAgICBjb25zdCB7XG4gICAgICB4OiBuZXh0WCxcbiAgICAgIHk6IG5leHRZLFxuICAgICAgZGF0YSxcbiAgICAgIHJlc2V0XG4gICAgfSA9IGF3YWl0IGZuKHtcbiAgICAgIHgsXG4gICAgICB5LFxuICAgICAgaW5pdGlhbFBsYWNlbWVudDogcGxhY2VtZW50LFxuICAgICAgcGxhY2VtZW50OiBzdGF0ZWZ1bFBsYWNlbWVudCxcbiAgICAgIHN0cmF0ZWd5LFxuICAgICAgbWlkZGxld2FyZURhdGEsXG4gICAgICByZWN0cyxcbiAgICAgIHBsYXRmb3JtOiBwbGF0Zm9ybVdpdGhEZXRlY3RPdmVyZmxvdyxcbiAgICAgIGVsZW1lbnRzOiB7XG4gICAgICAgIHJlZmVyZW5jZSxcbiAgICAgICAgZmxvYXRpbmdcbiAgICAgIH1cbiAgICB9KTtcbiAgICB4ID0gbmV4dFggIT0gbnVsbCA/IG5leHRYIDogeDtcbiAgICB5ID0gbmV4dFkgIT0gbnVsbCA/IG5leHRZIDogeTtcbiAgICBtaWRkbGV3YXJlRGF0YVtuYW1lXSA9IHtcbiAgICAgIC4uLm1pZGRsZXdhcmVEYXRhW25hbWVdLFxuICAgICAgLi4uZGF0YVxuICAgIH07XG4gICAgaWYgKHJlc2V0ICYmIHJlc2V0Q291bnQgPCBNQVhfUkVTRVRfQ09VTlQpIHtcbiAgICAgIHJlc2V0Q291bnQrKztcbiAgICAgIGlmICh0eXBlb2YgcmVzZXQgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIGlmIChyZXNldC5wbGFjZW1lbnQpIHtcbiAgICAgICAgICBzdGF0ZWZ1bFBsYWNlbWVudCA9IHJlc2V0LnBsYWNlbWVudDtcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVzZXQucmVjdHMpIHtcbiAgICAgICAgICByZWN0cyA9IHJlc2V0LnJlY3RzID09PSB0cnVlID8gYXdhaXQgcGxhdGZvcm0uZ2V0RWxlbWVudFJlY3RzKHtcbiAgICAgICAgICAgIHJlZmVyZW5jZSxcbiAgICAgICAgICAgIGZsb2F0aW5nLFxuICAgICAgICAgICAgc3RyYXRlZ3lcbiAgICAgICAgICB9KSA6IHJlc2V0LnJlY3RzO1xuICAgICAgICB9XG4gICAgICAgICh7XG4gICAgICAgICAgeCxcbiAgICAgICAgICB5XG4gICAgICAgIH0gPSBjb21wdXRlQ29vcmRzRnJvbVBsYWNlbWVudChyZWN0cywgc3RhdGVmdWxQbGFjZW1lbnQsIHJ0bCkpO1xuICAgICAgfVxuICAgICAgaSA9IC0xO1xuICAgIH1cbiAgfVxuICByZXR1cm4ge1xuICAgIHgsXG4gICAgeSxcbiAgICBwbGFjZW1lbnQ6IHN0YXRlZnVsUGxhY2VtZW50LFxuICAgIHN0cmF0ZWd5LFxuICAgIG1pZGRsZXdhcmVEYXRhXG4gIH07XG59O1xuXG4vKipcbiAqIFByb3ZpZGVzIGRhdGEgdG8gcG9zaXRpb24gYW4gaW5uZXIgZWxlbWVudCBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBzbyB0aGF0IGl0XG4gKiBhcHBlYXJzIGNlbnRlcmVkIHRvIHRoZSByZWZlcmVuY2UgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9hcnJvd1xuICovXG5jb25zdCBhcnJvdyA9IG9wdGlvbnMgPT4gKHtcbiAgbmFtZTogJ2Fycm93JyxcbiAgb3B0aW9ucyxcbiAgYXN5bmMgZm4oc3RhdGUpIHtcbiAgICBjb25zdCB7XG4gICAgICB4LFxuICAgICAgeSxcbiAgICAgIHBsYWNlbWVudCxcbiAgICAgIHJlY3RzLFxuICAgICAgcGxhdGZvcm0sXG4gICAgICBlbGVtZW50cyxcbiAgICAgIG1pZGRsZXdhcmVEYXRhXG4gICAgfSA9IHN0YXRlO1xuICAgIC8vIFNpbmNlIGBlbGVtZW50YCBpcyByZXF1aXJlZCwgd2UgZG9uJ3QgUGFydGlhbDw+IHRoZSB0eXBlLlxuICAgIGNvbnN0IHtcbiAgICAgIGVsZW1lbnQsXG4gICAgICBwYWRkaW5nID0gMFxuICAgIH0gPSBldmFsdWF0ZShvcHRpb25zLCBzdGF0ZSkgfHwge307XG4gICAgaWYgKGVsZW1lbnQgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbiAgICBjb25zdCBwYWRkaW5nT2JqZWN0ID0gZ2V0UGFkZGluZ09iamVjdChwYWRkaW5nKTtcbiAgICBjb25zdCBjb29yZHMgPSB7XG4gICAgICB4LFxuICAgICAgeVxuICAgIH07XG4gICAgY29uc3QgYXhpcyA9IGdldEFsaWdubWVudEF4aXMocGxhY2VtZW50KTtcbiAgICBjb25zdCBsZW5ndGggPSBnZXRBeGlzTGVuZ3RoKGF4aXMpO1xuICAgIGNvbnN0IGFycm93RGltZW5zaW9ucyA9IGF3YWl0IHBsYXRmb3JtLmdldERpbWVuc2lvbnMoZWxlbWVudCk7XG4gICAgY29uc3QgaXNZQXhpcyA9IGF4aXMgPT09ICd5JztcbiAgICBjb25zdCBtaW5Qcm9wID0gaXNZQXhpcyA/ICd0b3AnIDogJ2xlZnQnO1xuICAgIGNvbnN0IG1heFByb3AgPSBpc1lBeGlzID8gJ2JvdHRvbScgOiAncmlnaHQnO1xuICAgIGNvbnN0IGNsaWVudFByb3AgPSBpc1lBeGlzID8gJ2NsaWVudEhlaWdodCcgOiAnY2xpZW50V2lkdGgnO1xuICAgIGNvbnN0IGVuZERpZmYgPSByZWN0cy5yZWZlcmVuY2VbbGVuZ3RoXSArIHJlY3RzLnJlZmVyZW5jZVtheGlzXSAtIGNvb3Jkc1theGlzXSAtIHJlY3RzLmZsb2F0aW5nW2xlbmd0aF07XG4gICAgY29uc3Qgc3RhcnREaWZmID0gY29vcmRzW2F4aXNdIC0gcmVjdHMucmVmZXJlbmNlW2F4aXNdO1xuICAgIGNvbnN0IGFycm93T2Zmc2V0UGFyZW50ID0gYXdhaXQgKHBsYXRmb3JtLmdldE9mZnNldFBhcmVudCA9PSBudWxsID8gdm9pZCAwIDogcGxhdGZvcm0uZ2V0T2Zmc2V0UGFyZW50KGVsZW1lbnQpKTtcbiAgICBsZXQgY2xpZW50U2l6ZSA9IGFycm93T2Zmc2V0UGFyZW50ID8gYXJyb3dPZmZzZXRQYXJlbnRbY2xpZW50UHJvcF0gOiAwO1xuXG4gICAgLy8gRE9NIHBsYXRmb3JtIGNhbiByZXR1cm4gYHdpbmRvd2AgYXMgdGhlIGBvZmZzZXRQYXJlbnRgLlxuICAgIGlmICghY2xpZW50U2l6ZSB8fCAhKGF3YWl0IChwbGF0Zm9ybS5pc0VsZW1lbnQgPT0gbnVsbCA/IHZvaWQgMCA6IHBsYXRmb3JtLmlzRWxlbWVudChhcnJvd09mZnNldFBhcmVudCkpKSkge1xuICAgICAgY2xpZW50U2l6ZSA9IGVsZW1lbnRzLmZsb2F0aW5nW2NsaWVudFByb3BdIHx8IHJlY3RzLmZsb2F0aW5nW2xlbmd0aF07XG4gICAgfVxuICAgIGNvbnN0IGNlbnRlclRvUmVmZXJlbmNlID0gZW5kRGlmZiAvIDIgLSBzdGFydERpZmYgLyAyO1xuXG4gICAgLy8gSWYgdGhlIHBhZGRpbmcgaXMgbGFyZ2UgZW5vdWdoIHRoYXQgaXQgY2F1c2VzIHRoZSBhcnJvdyB0byBubyBsb25nZXIgYmVcbiAgICAvLyBjZW50ZXJlZCwgbW9kaWZ5IHRoZSBwYWRkaW5nIHNvIHRoYXQgaXQgaXMgY2VudGVyZWQuXG4gICAgY29uc3QgbGFyZ2VzdFBvc3NpYmxlUGFkZGluZyA9IGNsaWVudFNpemUgLyAyIC0gYXJyb3dEaW1lbnNpb25zW2xlbmd0aF0gLyAyIC0gMTtcbiAgICBjb25zdCBtaW5QYWRkaW5nID0gbWluKHBhZGRpbmdPYmplY3RbbWluUHJvcF0sIGxhcmdlc3RQb3NzaWJsZVBhZGRpbmcpO1xuICAgIGNvbnN0IG1heFBhZGRpbmcgPSBtaW4ocGFkZGluZ09iamVjdFttYXhQcm9wXSwgbGFyZ2VzdFBvc3NpYmxlUGFkZGluZyk7XG5cbiAgICAvLyBNYWtlIHN1cmUgdGhlIGFycm93IGRvZXNuJ3Qgb3ZlcmZsb3cgdGhlIGZsb2F0aW5nIGVsZW1lbnQgaWYgdGhlIGNlbnRlclxuICAgIC8vIHBvaW50IGlzIG91dHNpZGUgdGhlIGZsb2F0aW5nIGVsZW1lbnQncyBib3VuZHMuXG4gICAgY29uc3QgbWF4ID0gY2xpZW50U2l6ZSAtIGFycm93RGltZW5zaW9uc1tsZW5ndGhdIC0gbWF4UGFkZGluZztcbiAgICBjb25zdCBjZW50ZXIgPSBjbGllbnRTaXplIC8gMiAtIGFycm93RGltZW5zaW9uc1tsZW5ndGhdIC8gMiArIGNlbnRlclRvUmVmZXJlbmNlO1xuICAgIGNvbnN0IG9mZnNldCA9IGNsYW1wKG1pblBhZGRpbmcsIGNlbnRlciwgbWF4KTtcblxuICAgIC8vIElmIHRoZSByZWZlcmVuY2UgaXMgc21hbGwgZW5vdWdoIHRoYXQgdGhlIGFycm93J3MgcGFkZGluZyBjYXVzZXMgaXQgdG9cbiAgICAvLyB0byBwb2ludCB0byBub3RoaW5nIGZvciBhbiBhbGlnbmVkIHBsYWNlbWVudCwgYWRqdXN0IHRoZSBvZmZzZXQgb2YgdGhlXG4gICAgLy8gZmxvYXRpbmcgZWxlbWVudCBpdHNlbGYuIFRvIGVuc3VyZSBgc2hpZnQoKWAgY29udGludWVzIHRvIHRha2UgYWN0aW9uLFxuICAgIC8vIGEgc2luZ2xlIHJlc2V0IGlzIHBlcmZvcm1lZCB3aGVuIHRoaXMgaXMgdHJ1ZS5cbiAgICBjb25zdCBzaG91bGRBZGRPZmZzZXQgPSAhbWlkZGxld2FyZURhdGEuYXJyb3cgJiYgZ2V0QWxpZ25tZW50KHBsYWNlbWVudCkgIT0gbnVsbCAmJiBjZW50ZXIgIT09IG9mZnNldCAmJiByZWN0cy5yZWZlcmVuY2VbbGVuZ3RoXSAvIDIgLSAoY2VudGVyIDwgbWluUGFkZGluZyA/IG1pblBhZGRpbmcgOiBtYXhQYWRkaW5nKSAtIGFycm93RGltZW5zaW9uc1tsZW5ndGhdIC8gMiA8IDA7XG4gICAgY29uc3QgYWxpZ25tZW50T2Zmc2V0ID0gc2hvdWxkQWRkT2Zmc2V0ID8gY2VudGVyIDwgbWluUGFkZGluZyA/IGNlbnRlciAtIG1pblBhZGRpbmcgOiBjZW50ZXIgLSBtYXggOiAwO1xuICAgIHJldHVybiB7XG4gICAgICBbYXhpc106IGNvb3Jkc1theGlzXSArIGFsaWdubWVudE9mZnNldCxcbiAgICAgIGRhdGE6IHtcbiAgICAgICAgW2F4aXNdOiBvZmZzZXQsXG4gICAgICAgIGNlbnRlck9mZnNldDogY2VudGVyIC0gb2Zmc2V0IC0gYWxpZ25tZW50T2Zmc2V0LFxuICAgICAgICAuLi4oc2hvdWxkQWRkT2Zmc2V0ICYmIHtcbiAgICAgICAgICBhbGlnbm1lbnRPZmZzZXRcbiAgICAgICAgfSlcbiAgICAgIH0sXG4gICAgICByZXNldDogc2hvdWxkQWRkT2Zmc2V0XG4gICAgfTtcbiAgfVxufSk7XG5cbmZ1bmN0aW9uIGdldFBsYWNlbWVudExpc3QoYWxpZ25tZW50LCBhdXRvQWxpZ25tZW50LCBhbGxvd2VkUGxhY2VtZW50cykge1xuICBjb25zdCBhbGxvd2VkUGxhY2VtZW50c1NvcnRlZEJ5QWxpZ25tZW50ID0gYWxpZ25tZW50ID8gWy4uLmFsbG93ZWRQbGFjZW1lbnRzLmZpbHRlcihwbGFjZW1lbnQgPT4gZ2V0QWxpZ25tZW50KHBsYWNlbWVudCkgPT09IGFsaWdubWVudCksIC4uLmFsbG93ZWRQbGFjZW1lbnRzLmZpbHRlcihwbGFjZW1lbnQgPT4gZ2V0QWxpZ25tZW50KHBsYWNlbWVudCkgIT09IGFsaWdubWVudCldIDogYWxsb3dlZFBsYWNlbWVudHMuZmlsdGVyKHBsYWNlbWVudCA9PiBnZXRTaWRlKHBsYWNlbWVudCkgPT09IHBsYWNlbWVudCk7XG4gIHJldHVybiBhbGxvd2VkUGxhY2VtZW50c1NvcnRlZEJ5QWxpZ25tZW50LmZpbHRlcihwbGFjZW1lbnQgPT4ge1xuICAgIGlmIChhbGlnbm1lbnQpIHtcbiAgICAgIHJldHVybiBnZXRBbGlnbm1lbnQocGxhY2VtZW50KSA9PT0gYWxpZ25tZW50IHx8IChhdXRvQWxpZ25tZW50ID8gZ2V0T3Bwb3NpdGVBbGlnbm1lbnRQbGFjZW1lbnQocGxhY2VtZW50KSAhPT0gcGxhY2VtZW50IDogZmFsc2UpO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSk7XG59XG4vKipcbiAqIE9wdGltaXplcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBieSBjaG9vc2luZyB0aGUgcGxhY2VtZW50XG4gKiB0aGF0IGhhcyB0aGUgbW9zdCBzcGFjZSBhdmFpbGFibGUgYXV0b21hdGljYWxseSwgd2l0aG91dCBuZWVkaW5nIHRvIHNwZWNpZnkgYVxuICogcHJlZmVycmVkIHBsYWNlbWVudC4gQWx0ZXJuYXRpdmUgdG8gYGZsaXBgLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2F1dG9QbGFjZW1lbnRcbiAqL1xuY29uc3QgYXV0b1BsYWNlbWVudCA9IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBuYW1lOiAnYXV0b1BsYWNlbWVudCcsXG4gICAgb3B0aW9ucyxcbiAgICBhc3luYyBmbihzdGF0ZSkge1xuICAgICAgdmFyIF9taWRkbGV3YXJlRGF0YSRhdXRvUCwgX21pZGRsZXdhcmVEYXRhJGF1dG9QMiwgX3BsYWNlbWVudHNUaGF0Rml0T25FO1xuICAgICAgY29uc3Qge1xuICAgICAgICByZWN0cyxcbiAgICAgICAgbWlkZGxld2FyZURhdGEsXG4gICAgICAgIHBsYWNlbWVudCxcbiAgICAgICAgcGxhdGZvcm0sXG4gICAgICAgIGVsZW1lbnRzXG4gICAgICB9ID0gc3RhdGU7XG4gICAgICBjb25zdCB7XG4gICAgICAgIGNyb3NzQXhpcyA9IGZhbHNlLFxuICAgICAgICBhbGlnbm1lbnQsXG4gICAgICAgIGFsbG93ZWRQbGFjZW1lbnRzID0gcGxhY2VtZW50cyxcbiAgICAgICAgYXV0b0FsaWdubWVudCA9IHRydWUsXG4gICAgICAgIC4uLmRldGVjdE92ZXJmbG93T3B0aW9uc1xuICAgICAgfSA9IGV2YWx1YXRlKG9wdGlvbnMsIHN0YXRlKTtcbiAgICAgIGNvbnN0IHBsYWNlbWVudHMkMSA9IGFsaWdubWVudCAhPT0gdW5kZWZpbmVkIHx8IGFsbG93ZWRQbGFjZW1lbnRzID09PSBwbGFjZW1lbnRzID8gZ2V0UGxhY2VtZW50TGlzdChhbGlnbm1lbnQgfHwgbnVsbCwgYXV0b0FsaWdubWVudCwgYWxsb3dlZFBsYWNlbWVudHMpIDogYWxsb3dlZFBsYWNlbWVudHM7XG4gICAgICBjb25zdCBjdXJyZW50SW5kZXggPSAoKF9taWRkbGV3YXJlRGF0YSRhdXRvUCA9IG1pZGRsZXdhcmVEYXRhLmF1dG9QbGFjZW1lbnQpID09IG51bGwgPyB2b2lkIDAgOiBfbWlkZGxld2FyZURhdGEkYXV0b1AuaW5kZXgpIHx8IDA7XG4gICAgICBjb25zdCBjdXJyZW50UGxhY2VtZW50ID0gcGxhY2VtZW50cyQxW2N1cnJlbnRJbmRleF07XG4gICAgICBpZiAoY3VycmVudFBsYWNlbWVudCA9PSBudWxsKSB7XG4gICAgICAgIHJldHVybiB7fTtcbiAgICAgIH1cblxuICAgICAgLy8gTWFrZSBgY29tcHV0ZUNvb3Jkc2Agc3RhcnQgZnJvbSB0aGUgcmlnaHQgcGxhY2UuXG4gICAgICBpZiAocGxhY2VtZW50ICE9PSBjdXJyZW50UGxhY2VtZW50KSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgcmVzZXQ6IHtcbiAgICAgICAgICAgIHBsYWNlbWVudDogcGxhY2VtZW50cyQxWzBdXG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgY29uc3Qgb3ZlcmZsb3cgPSBhd2FpdCBwbGF0Zm9ybS5kZXRlY3RPdmVyZmxvdyhzdGF0ZSwgZGV0ZWN0T3ZlcmZsb3dPcHRpb25zKTtcbiAgICAgIGNvbnN0IGFsaWdubWVudFNpZGVzID0gZ2V0QWxpZ25tZW50U2lkZXMoY3VycmVudFBsYWNlbWVudCwgcmVjdHMsIGF3YWl0IChwbGF0Zm9ybS5pc1JUTCA9PSBudWxsID8gdm9pZCAwIDogcGxhdGZvcm0uaXNSVEwoZWxlbWVudHMuZmxvYXRpbmcpKSk7XG4gICAgICBjb25zdCBjdXJyZW50T3ZlcmZsb3dzID0gW292ZXJmbG93W2dldFNpZGUoY3VycmVudFBsYWNlbWVudCldLCBvdmVyZmxvd1thbGlnbm1lbnRTaWRlc1swXV0sIG92ZXJmbG93W2FsaWdubWVudFNpZGVzWzFdXV07XG4gICAgICBjb25zdCBhbGxPdmVyZmxvd3MgPSBbLi4uKCgoX21pZGRsZXdhcmVEYXRhJGF1dG9QMiA9IG1pZGRsZXdhcmVEYXRhLmF1dG9QbGFjZW1lbnQpID09IG51bGwgPyB2b2lkIDAgOiBfbWlkZGxld2FyZURhdGEkYXV0b1AyLm92ZXJmbG93cykgfHwgW10pLCB7XG4gICAgICAgIHBsYWNlbWVudDogY3VycmVudFBsYWNlbWVudCxcbiAgICAgICAgb3ZlcmZsb3dzOiBjdXJyZW50T3ZlcmZsb3dzXG4gICAgICB9XTtcbiAgICAgIGNvbnN0IG5leHRQbGFjZW1lbnQgPSBwbGFjZW1lbnRzJDFbY3VycmVudEluZGV4ICsgMV07XG5cbiAgICAgIC8vIFRoZXJlIGFyZSBtb3JlIHBsYWNlbWVudHMgdG8gY2hlY2suXG4gICAgICBpZiAobmV4dFBsYWNlbWVudCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgIGluZGV4OiBjdXJyZW50SW5kZXggKyAxLFxuICAgICAgICAgICAgb3ZlcmZsb3dzOiBhbGxPdmVyZmxvd3NcbiAgICAgICAgICB9LFxuICAgICAgICAgIHJlc2V0OiB7XG4gICAgICAgICAgICBwbGFjZW1lbnQ6IG5leHRQbGFjZW1lbnRcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBjb25zdCBwbGFjZW1lbnRzU29ydGVkQnlNb3N0U3BhY2UgPSBhbGxPdmVyZmxvd3MubWFwKGQgPT4ge1xuICAgICAgICBjb25zdCBhbGlnbm1lbnQgPSBnZXRBbGlnbm1lbnQoZC5wbGFjZW1lbnQpO1xuICAgICAgICByZXR1cm4gW2QucGxhY2VtZW50LCBhbGlnbm1lbnQgJiYgY3Jvc3NBeGlzID9cbiAgICAgICAgLy8gQ2hlY2sgYWxvbmcgdGhlIG1haW5BeGlzIGFuZCBtYWluIGNyb3NzQXhpcyBzaWRlLlxuICAgICAgICBkLm92ZXJmbG93cy5zbGljZSgwLCAyKS5yZWR1Y2UoKGFjYywgdikgPT4gYWNjICsgdiwgMCkgOlxuICAgICAgICAvLyBDaGVjayBvbmx5IHRoZSBtYWluQXhpcy5cbiAgICAgICAgZC5vdmVyZmxvd3NbMF0sIGQub3ZlcmZsb3dzXTtcbiAgICAgIH0pLnNvcnQoKGEsIGIpID0+IGFbMV0gLSBiWzFdKTtcbiAgICAgIGNvbnN0IHBsYWNlbWVudHNUaGF0Rml0T25FYWNoU2lkZSA9IHBsYWNlbWVudHNTb3J0ZWRCeU1vc3RTcGFjZS5maWx0ZXIoZCA9PiBkWzJdLnNsaWNlKDAsXG4gICAgICAvLyBBbGlnbmVkIHBsYWNlbWVudHMgc2hvdWxkIG5vdCBjaGVjayB0aGVpciBvcHBvc2l0ZSBjcm9zc0F4aXNcbiAgICAgIC8vIHNpZGUuXG4gICAgICBnZXRBbGlnbm1lbnQoZFswXSkgPyAyIDogMykuZXZlcnkodiA9PiB2IDw9IDApKTtcbiAgICAgIGNvbnN0IHJlc2V0UGxhY2VtZW50ID0gKChfcGxhY2VtZW50c1RoYXRGaXRPbkUgPSBwbGFjZW1lbnRzVGhhdEZpdE9uRWFjaFNpZGVbMF0pID09IG51bGwgPyB2b2lkIDAgOiBfcGxhY2VtZW50c1RoYXRGaXRPbkVbMF0pIHx8IHBsYWNlbWVudHNTb3J0ZWRCeU1vc3RTcGFjZVswXVswXTtcbiAgICAgIGlmIChyZXNldFBsYWNlbWVudCAhPT0gcGxhY2VtZW50KSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgaW5kZXg6IGN1cnJlbnRJbmRleCArIDEsXG4gICAgICAgICAgICBvdmVyZmxvd3M6IGFsbE92ZXJmbG93c1xuICAgICAgICAgIH0sXG4gICAgICAgICAgcmVzZXQ6IHtcbiAgICAgICAgICAgIHBsYWNlbWVudDogcmVzZXRQbGFjZW1lbnRcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICByZXR1cm4ge307XG4gICAgfVxuICB9O1xufTtcblxuLyoqXG4gKiBPcHRpbWl6ZXMgdGhlIHZpc2liaWxpdHkgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQgYnkgZmxpcHBpbmcgdGhlIGBwbGFjZW1lbnRgXG4gKiBpbiBvcmRlciB0byBrZWVwIGl0IGluIHZpZXcgd2hlbiB0aGUgcHJlZmVycmVkIHBsYWNlbWVudChzKSB3aWxsIG92ZXJmbG93IHRoZVxuICogY2xpcHBpbmcgYm91bmRhcnkuIEFsdGVybmF0aXZlIHRvIGBhdXRvUGxhY2VtZW50YC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9mbGlwXG4gKi9cbmNvbnN0IGZsaXAgPSBmdW5jdGlvbiAob3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG4gIHJldHVybiB7XG4gICAgbmFtZTogJ2ZsaXAnLFxuICAgIG9wdGlvbnMsXG4gICAgYXN5bmMgZm4oc3RhdGUpIHtcbiAgICAgIHZhciBfbWlkZGxld2FyZURhdGEkYXJyb3csIF9taWRkbGV3YXJlRGF0YSRmbGlwO1xuICAgICAgY29uc3Qge1xuICAgICAgICBwbGFjZW1lbnQsXG4gICAgICAgIG1pZGRsZXdhcmVEYXRhLFxuICAgICAgICByZWN0cyxcbiAgICAgICAgaW5pdGlhbFBsYWNlbWVudCxcbiAgICAgICAgcGxhdGZvcm0sXG4gICAgICAgIGVsZW1lbnRzXG4gICAgICB9ID0gc3RhdGU7XG4gICAgICBjb25zdCB7XG4gICAgICAgIG1haW5BeGlzOiBjaGVja01haW5BeGlzID0gdHJ1ZSxcbiAgICAgICAgY3Jvc3NBeGlzOiBjaGVja0Nyb3NzQXhpcyA9IHRydWUsXG4gICAgICAgIGZhbGxiYWNrUGxhY2VtZW50czogc3BlY2lmaWVkRmFsbGJhY2tQbGFjZW1lbnRzLFxuICAgICAgICBmYWxsYmFja1N0cmF0ZWd5ID0gJ2Jlc3RGaXQnLFxuICAgICAgICBmYWxsYmFja0F4aXNTaWRlRGlyZWN0aW9uID0gJ25vbmUnLFxuICAgICAgICBmbGlwQWxpZ25tZW50ID0gdHJ1ZSxcbiAgICAgICAgLi4uZGV0ZWN0T3ZlcmZsb3dPcHRpb25zXG4gICAgICB9ID0gZXZhbHVhdGUob3B0aW9ucywgc3RhdGUpO1xuXG4gICAgICAvLyBJZiBhIHJlc2V0IGJ5IHRoZSBhcnJvdyB3YXMgY2F1c2VkIGR1ZSB0byBhbiBhbGlnbm1lbnQgb2Zmc2V0IGJlaW5nXG4gICAgICAvLyBhZGRlZCwgd2Ugc2hvdWxkIHNraXAgYW55IGxvZ2ljIG5vdyBzaW5jZSBgZmxpcCgpYCBoYXMgYWxyZWFkeSBkb25lIGl0c1xuICAgICAgLy8gd29yay5cbiAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9mbG9hdGluZy11aS9mbG9hdGluZy11aS9pc3N1ZXMvMjU0OSNpc3N1ZWNvbW1lbnQtMTcxOTYwMTY0M1xuICAgICAgaWYgKChfbWlkZGxld2FyZURhdGEkYXJyb3cgPSBtaWRkbGV3YXJlRGF0YS5hcnJvdykgIT0gbnVsbCAmJiBfbWlkZGxld2FyZURhdGEkYXJyb3cuYWxpZ25tZW50T2Zmc2V0KSB7XG4gICAgICAgIHJldHVybiB7fTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHNpZGUgPSBnZXRTaWRlKHBsYWNlbWVudCk7XG4gICAgICBjb25zdCBpbml0aWFsU2lkZUF4aXMgPSBnZXRTaWRlQXhpcyhpbml0aWFsUGxhY2VtZW50KTtcbiAgICAgIGNvbnN0IGlzQmFzZVBsYWNlbWVudCA9IGdldFNpZGUoaW5pdGlhbFBsYWNlbWVudCkgPT09IGluaXRpYWxQbGFjZW1lbnQ7XG4gICAgICBjb25zdCBydGwgPSBhd2FpdCAocGxhdGZvcm0uaXNSVEwgPT0gbnVsbCA/IHZvaWQgMCA6IHBsYXRmb3JtLmlzUlRMKGVsZW1lbnRzLmZsb2F0aW5nKSk7XG4gICAgICBjb25zdCBmYWxsYmFja1BsYWNlbWVudHMgPSBzcGVjaWZpZWRGYWxsYmFja1BsYWNlbWVudHMgfHwgKGlzQmFzZVBsYWNlbWVudCB8fCAhZmxpcEFsaWdubWVudCA/IFtnZXRPcHBvc2l0ZVBsYWNlbWVudChpbml0aWFsUGxhY2VtZW50KV0gOiBnZXRFeHBhbmRlZFBsYWNlbWVudHMoaW5pdGlhbFBsYWNlbWVudCkpO1xuICAgICAgY29uc3QgaGFzRmFsbGJhY2tBeGlzU2lkZURpcmVjdGlvbiA9IGZhbGxiYWNrQXhpc1NpZGVEaXJlY3Rpb24gIT09ICdub25lJztcbiAgICAgIGlmICghc3BlY2lmaWVkRmFsbGJhY2tQbGFjZW1lbnRzICYmIGhhc0ZhbGxiYWNrQXhpc1NpZGVEaXJlY3Rpb24pIHtcbiAgICAgICAgZmFsbGJhY2tQbGFjZW1lbnRzLnB1c2goLi4uZ2V0T3Bwb3NpdGVBeGlzUGxhY2VtZW50cyhpbml0aWFsUGxhY2VtZW50LCBmbGlwQWxpZ25tZW50LCBmYWxsYmFja0F4aXNTaWRlRGlyZWN0aW9uLCBydGwpKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHBsYWNlbWVudHMgPSBbaW5pdGlhbFBsYWNlbWVudCwgLi4uZmFsbGJhY2tQbGFjZW1lbnRzXTtcbiAgICAgIGNvbnN0IG92ZXJmbG93ID0gYXdhaXQgcGxhdGZvcm0uZGV0ZWN0T3ZlcmZsb3coc3RhdGUsIGRldGVjdE92ZXJmbG93T3B0aW9ucyk7XG4gICAgICBjb25zdCBvdmVyZmxvd3MgPSBbXTtcbiAgICAgIGxldCBvdmVyZmxvd3NEYXRhID0gKChfbWlkZGxld2FyZURhdGEkZmxpcCA9IG1pZGRsZXdhcmVEYXRhLmZsaXApID09IG51bGwgPyB2b2lkIDAgOiBfbWlkZGxld2FyZURhdGEkZmxpcC5vdmVyZmxvd3MpIHx8IFtdO1xuICAgICAgaWYgKGNoZWNrTWFpbkF4aXMpIHtcbiAgICAgICAgb3ZlcmZsb3dzLnB1c2gob3ZlcmZsb3dbc2lkZV0pO1xuICAgICAgfVxuICAgICAgaWYgKGNoZWNrQ3Jvc3NBeGlzKSB7XG4gICAgICAgIGNvbnN0IHNpZGVzID0gZ2V0QWxpZ25tZW50U2lkZXMocGxhY2VtZW50LCByZWN0cywgcnRsKTtcbiAgICAgICAgb3ZlcmZsb3dzLnB1c2gob3ZlcmZsb3dbc2lkZXNbMF1dLCBvdmVyZmxvd1tzaWRlc1sxXV0pO1xuICAgICAgfVxuICAgICAgb3ZlcmZsb3dzRGF0YSA9IFsuLi5vdmVyZmxvd3NEYXRhLCB7XG4gICAgICAgIHBsYWNlbWVudCxcbiAgICAgICAgb3ZlcmZsb3dzXG4gICAgICB9XTtcblxuICAgICAgLy8gT25lIG9yIG1vcmUgc2lkZXMgaXMgb3ZlcmZsb3dpbmcuXG4gICAgICBpZiAoIW92ZXJmbG93cy5ldmVyeShzaWRlID0+IHNpZGUgPD0gMCkpIHtcbiAgICAgICAgdmFyIF9taWRkbGV3YXJlRGF0YSRmbGlwMiwgX292ZXJmbG93c0RhdGEkZmlsdGVyO1xuICAgICAgICBjb25zdCBuZXh0SW5kZXggPSAoKChfbWlkZGxld2FyZURhdGEkZmxpcDIgPSBtaWRkbGV3YXJlRGF0YS5mbGlwKSA9PSBudWxsID8gdm9pZCAwIDogX21pZGRsZXdhcmVEYXRhJGZsaXAyLmluZGV4KSB8fCAwKSArIDE7XG4gICAgICAgIGNvbnN0IG5leHRQbGFjZW1lbnQgPSBwbGFjZW1lbnRzW25leHRJbmRleF07XG4gICAgICAgIGlmIChuZXh0UGxhY2VtZW50KSB7XG4gICAgICAgICAgY29uc3QgaWdub3JlQ3Jvc3NBeGlzT3ZlcmZsb3cgPSBjaGVja0Nyb3NzQXhpcyA9PT0gJ2FsaWdubWVudCcgPyBpbml0aWFsU2lkZUF4aXMgIT09IGdldFNpZGVBeGlzKG5leHRQbGFjZW1lbnQpIDogZmFsc2U7XG4gICAgICAgICAgaWYgKCFpZ25vcmVDcm9zc0F4aXNPdmVyZmxvdyB8fFxuICAgICAgICAgIC8vIFdlIGxlYXZlIHRoZSBjdXJyZW50IG1haW4gYXhpcyBvbmx5IGlmIGV2ZXJ5IHBsYWNlbWVudCBvbiB0aGF0IGF4aXNcbiAgICAgICAgICAvLyBvdmVyZmxvd3MgdGhlIG1haW4gYXhpcy5cbiAgICAgICAgICBvdmVyZmxvd3NEYXRhLmV2ZXJ5KGQgPT4gZ2V0U2lkZUF4aXMoZC5wbGFjZW1lbnQpID09PSBpbml0aWFsU2lkZUF4aXMgPyBkLm92ZXJmbG93c1swXSA+IDAgOiB0cnVlKSkge1xuICAgICAgICAgICAgLy8gVHJ5IG5leHQgcGxhY2VtZW50IGFuZCByZS1ydW4gdGhlIGxpZmVjeWNsZS5cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICBpbmRleDogbmV4dEluZGV4LFxuICAgICAgICAgICAgICAgIG92ZXJmbG93czogb3ZlcmZsb3dzRGF0YVxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICByZXNldDoge1xuICAgICAgICAgICAgICAgIHBsYWNlbWVudDogbmV4dFBsYWNlbWVudFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEZpcnN0LCBmaW5kIHRoZSBjYW5kaWRhdGVzIHRoYXQgZml0IG9uIHRoZSBtYWluQXhpcyBzaWRlIG9mIG92ZXJmbG93LFxuICAgICAgICAvLyB0aGVuIGZpbmQgdGhlIHBsYWNlbWVudCB0aGF0IGZpdHMgdGhlIGJlc3Qgb24gdGhlIG1haW4gY3Jvc3NBeGlzIHNpZGUuXG4gICAgICAgIGxldCByZXNldFBsYWNlbWVudCA9IChfb3ZlcmZsb3dzRGF0YSRmaWx0ZXIgPSBvdmVyZmxvd3NEYXRhLmZpbHRlcihkID0+IGQub3ZlcmZsb3dzWzBdIDw9IDApLnNvcnQoKGEsIGIpID0+IGEub3ZlcmZsb3dzWzFdIC0gYi5vdmVyZmxvd3NbMV0pWzBdKSA9PSBudWxsID8gdm9pZCAwIDogX292ZXJmbG93c0RhdGEkZmlsdGVyLnBsYWNlbWVudDtcblxuICAgICAgICAvLyBPdGhlcndpc2UgZmFsbGJhY2suXG4gICAgICAgIGlmICghcmVzZXRQbGFjZW1lbnQpIHtcbiAgICAgICAgICBzd2l0Y2ggKGZhbGxiYWNrU3RyYXRlZ3kpIHtcbiAgICAgICAgICAgIGNhc2UgJ2Jlc3RGaXQnOlxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdmFyIF9vdmVyZmxvd3NEYXRhJGZpbHRlcjI7XG4gICAgICAgICAgICAgICAgY29uc3QgcGxhY2VtZW50ID0gKF9vdmVyZmxvd3NEYXRhJGZpbHRlcjIgPSBvdmVyZmxvd3NEYXRhLmZpbHRlcihkID0+IHtcbiAgICAgICAgICAgICAgICAgIGlmIChoYXNGYWxsYmFja0F4aXNTaWRlRGlyZWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRTaWRlQXhpcyA9IGdldFNpZGVBeGlzKGQucGxhY2VtZW50KTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGN1cnJlbnRTaWRlQXhpcyA9PT0gaW5pdGlhbFNpZGVBeGlzIHx8XG4gICAgICAgICAgICAgICAgICAgIC8vIENyZWF0ZSBhIGJpYXMgdG8gdGhlIGB5YCBzaWRlIGF4aXMgZHVlIHRvIGhvcml6b250YWxcbiAgICAgICAgICAgICAgICAgICAgLy8gcmVhZGluZyBkaXJlY3Rpb25zIGZhdm9yaW5nIGdyZWF0ZXIgd2lkdGguXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnRTaWRlQXhpcyA9PT0gJ3knO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgICAgfSkubWFwKGQgPT4gW2QucGxhY2VtZW50LCBkLm92ZXJmbG93cy5maWx0ZXIob3ZlcmZsb3cgPT4gb3ZlcmZsb3cgPiAwKS5yZWR1Y2UoKGFjYywgb3ZlcmZsb3cpID0+IGFjYyArIG92ZXJmbG93LCAwKV0pLnNvcnQoKGEsIGIpID0+IGFbMV0gLSBiWzFdKVswXSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9vdmVyZmxvd3NEYXRhJGZpbHRlcjJbMF07XG4gICAgICAgICAgICAgICAgaWYgKHBsYWNlbWVudCkge1xuICAgICAgICAgICAgICAgICAgcmVzZXRQbGFjZW1lbnQgPSBwbGFjZW1lbnQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlICdpbml0aWFsUGxhY2VtZW50JzpcbiAgICAgICAgICAgICAgcmVzZXRQbGFjZW1lbnQgPSBpbml0aWFsUGxhY2VtZW50O1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHBsYWNlbWVudCAhPT0gcmVzZXRQbGFjZW1lbnQpIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVzZXQ6IHtcbiAgICAgICAgICAgICAgcGxhY2VtZW50OiByZXNldFBsYWNlbWVudFxuICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiB7fTtcbiAgICB9XG4gIH07XG59O1xuXG5mdW5jdGlvbiBnZXRTaWRlT2Zmc2V0cyhvdmVyZmxvdywgcmVjdCkge1xuICByZXR1cm4ge1xuICAgIHRvcDogb3ZlcmZsb3cudG9wIC0gcmVjdC5oZWlnaHQsXG4gICAgcmlnaHQ6IG92ZXJmbG93LnJpZ2h0IC0gcmVjdC53aWR0aCxcbiAgICBib3R0b206IG92ZXJmbG93LmJvdHRvbSAtIHJlY3QuaGVpZ2h0LFxuICAgIGxlZnQ6IG92ZXJmbG93LmxlZnQgLSByZWN0LndpZHRoXG4gIH07XG59XG5mdW5jdGlvbiBpc0FueVNpZGVGdWxseUNsaXBwZWQob3ZlcmZsb3cpIHtcbiAgcmV0dXJuIHNpZGVzLnNvbWUoc2lkZSA9PiBvdmVyZmxvd1tzaWRlXSA+PSAwKTtcbn1cbi8qKlxuICogUHJvdmlkZXMgZGF0YSB0byBoaWRlIHRoZSBmbG9hdGluZyBlbGVtZW50IGluIGFwcGxpY2FibGUgc2l0dWF0aW9ucywgc3VjaCBhc1xuICogd2hlbiBpdCBpcyBub3QgaW4gdGhlIHNhbWUgY2xpcHBpbmcgY29udGV4dCBhcyB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvaGlkZVxuICovXG5jb25zdCBoaWRlID0gZnVuY3Rpb24gKG9wdGlvbnMpIHtcbiAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkge1xuICAgIG9wdGlvbnMgPSB7fTtcbiAgfVxuICByZXR1cm4ge1xuICAgIG5hbWU6ICdoaWRlJyxcbiAgICBvcHRpb25zLFxuICAgIGFzeW5jIGZuKHN0YXRlKSB7XG4gICAgICBjb25zdCB7XG4gICAgICAgIHJlY3RzLFxuICAgICAgICBwbGF0Zm9ybVxuICAgICAgfSA9IHN0YXRlO1xuICAgICAgY29uc3Qge1xuICAgICAgICBzdHJhdGVneSA9ICdyZWZlcmVuY2VIaWRkZW4nLFxuICAgICAgICAuLi5kZXRlY3RPdmVyZmxvd09wdGlvbnNcbiAgICAgIH0gPSBldmFsdWF0ZShvcHRpb25zLCBzdGF0ZSk7XG4gICAgICBzd2l0Y2ggKHN0cmF0ZWd5KSB7XG4gICAgICAgIGNhc2UgJ3JlZmVyZW5jZUhpZGRlbic6XG4gICAgICAgICAge1xuICAgICAgICAgICAgY29uc3Qgb3ZlcmZsb3cgPSBhd2FpdCBwbGF0Zm9ybS5kZXRlY3RPdmVyZmxvdyhzdGF0ZSwge1xuICAgICAgICAgICAgICAuLi5kZXRlY3RPdmVyZmxvd09wdGlvbnMsXG4gICAgICAgICAgICAgIGVsZW1lbnRDb250ZXh0OiAncmVmZXJlbmNlJ1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBjb25zdCBvZmZzZXRzID0gZ2V0U2lkZU9mZnNldHMob3ZlcmZsb3csIHJlY3RzLnJlZmVyZW5jZSk7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgcmVmZXJlbmNlSGlkZGVuT2Zmc2V0czogb2Zmc2V0cyxcbiAgICAgICAgICAgICAgICByZWZlcmVuY2VIaWRkZW46IGlzQW55U2lkZUZ1bGx5Q2xpcHBlZChvZmZzZXRzKVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgY2FzZSAnZXNjYXBlZCc6XG4gICAgICAgICAge1xuICAgICAgICAgICAgY29uc3Qgb3ZlcmZsb3cgPSBhd2FpdCBwbGF0Zm9ybS5kZXRlY3RPdmVyZmxvdyhzdGF0ZSwge1xuICAgICAgICAgICAgICAuLi5kZXRlY3RPdmVyZmxvd09wdGlvbnMsXG4gICAgICAgICAgICAgIGFsdEJvdW5kYXJ5OiB0cnVlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNvbnN0IG9mZnNldHMgPSBnZXRTaWRlT2Zmc2V0cyhvdmVyZmxvdywgcmVjdHMuZmxvYXRpbmcpO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgIGVzY2FwZWRPZmZzZXRzOiBvZmZzZXRzLFxuICAgICAgICAgICAgICAgIGVzY2FwZWQ6IGlzQW55U2lkZUZ1bGx5Q2xpcHBlZChvZmZzZXRzKVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICB7XG4gICAgICAgICAgICByZXR1cm4ge307XG4gICAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfTtcbn07XG5cbmZ1bmN0aW9uIGdldEJvdW5kaW5nUmVjdChyZWN0cykge1xuICBjb25zdCBtaW5YID0gbWluKC4uLnJlY3RzLm1hcChyZWN0ID0+IHJlY3QubGVmdCkpO1xuICBjb25zdCBtaW5ZID0gbWluKC4uLnJlY3RzLm1hcChyZWN0ID0+IHJlY3QudG9wKSk7XG4gIGNvbnN0IG1heFggPSBtYXgoLi4ucmVjdHMubWFwKHJlY3QgPT4gcmVjdC5yaWdodCkpO1xuICBjb25zdCBtYXhZID0gbWF4KC4uLnJlY3RzLm1hcChyZWN0ID0+IHJlY3QuYm90dG9tKSk7XG4gIHJldHVybiB7XG4gICAgeDogbWluWCxcbiAgICB5OiBtaW5ZLFxuICAgIHdpZHRoOiBtYXhYIC0gbWluWCxcbiAgICBoZWlnaHQ6IG1heFkgLSBtaW5ZXG4gIH07XG59XG5mdW5jdGlvbiBnZXRSZWN0c0J5TGluZShyZWN0cykge1xuICBjb25zdCBzb3J0ZWRSZWN0cyA9IHJlY3RzLnNsaWNlKCkuc29ydCgoYSwgYikgPT4gYS55IC0gYi55KTtcbiAgY29uc3QgZ3JvdXBzID0gW107XG4gIGxldCBwcmV2UmVjdCA9IG51bGw7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgc29ydGVkUmVjdHMubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCByZWN0ID0gc29ydGVkUmVjdHNbaV07XG4gICAgaWYgKCFwcmV2UmVjdCB8fCByZWN0LnkgLSBwcmV2UmVjdC55ID4gcHJldlJlY3QuaGVpZ2h0IC8gMikge1xuICAgICAgZ3JvdXBzLnB1c2goW3JlY3RdKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZ3JvdXBzW2dyb3Vwcy5sZW5ndGggLSAxXS5wdXNoKHJlY3QpO1xuICAgIH1cbiAgICBwcmV2UmVjdCA9IHJlY3Q7XG4gIH1cbiAgcmV0dXJuIGdyb3Vwcy5tYXAocmVjdCA9PiByZWN0VG9DbGllbnRSZWN0KGdldEJvdW5kaW5nUmVjdChyZWN0KSkpO1xufVxuLyoqXG4gKiBQcm92aWRlcyBpbXByb3ZlZCBwb3NpdGlvbmluZyBmb3IgaW5saW5lIHJlZmVyZW5jZSBlbGVtZW50cyB0aGF0IGNhbiBzcGFuXG4gKiBvdmVyIG11bHRpcGxlIGxpbmVzLCBzdWNoIGFzIGh5cGVybGlua3Mgb3IgcmFuZ2Ugc2VsZWN0aW9ucy5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9pbmxpbmVcbiAqL1xuY29uc3QgaW5saW5lID0gZnVuY3Rpb24gKG9wdGlvbnMpIHtcbiAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkge1xuICAgIG9wdGlvbnMgPSB7fTtcbiAgfVxuICByZXR1cm4ge1xuICAgIG5hbWU6ICdpbmxpbmUnLFxuICAgIG9wdGlvbnMsXG4gICAgYXN5bmMgZm4oc3RhdGUpIHtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgcGxhY2VtZW50LFxuICAgICAgICBlbGVtZW50cyxcbiAgICAgICAgcmVjdHMsXG4gICAgICAgIHBsYXRmb3JtLFxuICAgICAgICBzdHJhdGVneVxuICAgICAgfSA9IHN0YXRlO1xuICAgICAgLy8gQSBNb3VzZUV2ZW50J3MgY2xpZW50e1gsWX0gY29vcmRzIGNhbiBiZSB1cCB0byAyIHBpeGVscyBvZmYgYVxuICAgICAgLy8gQ2xpZW50UmVjdCdzIGJvdW5kcywgZGVzcGl0ZSB0aGUgZXZlbnQgbGlzdGVuZXIgYmVpbmcgdHJpZ2dlcmVkLiBBXG4gICAgICAvLyBwYWRkaW5nIG9mIDIgc2VlbXMgdG8gaGFuZGxlIHRoaXMgaXNzdWUuXG4gICAgICBjb25zdCB7XG4gICAgICAgIHBhZGRpbmcgPSAyLFxuICAgICAgICB4LFxuICAgICAgICB5XG4gICAgICB9ID0gZXZhbHVhdGUob3B0aW9ucywgc3RhdGUpO1xuICAgICAgY29uc3QgbmF0aXZlQ2xpZW50UmVjdHMgPSBBcnJheS5mcm9tKChhd2FpdCAocGxhdGZvcm0uZ2V0Q2xpZW50UmVjdHMgPT0gbnVsbCA/IHZvaWQgMCA6IHBsYXRmb3JtLmdldENsaWVudFJlY3RzKGVsZW1lbnRzLnJlZmVyZW5jZSkpKSB8fCBbXSk7XG5cbiAgICAgIC8vIE5vIHJlY3RzIChlLmcuIGEgaGlkZGVuIG9yIGRldGFjaGVkIHJlZmVyZW5jZSwgb3IgYSBjb2xsYXBzZWQgcmFuZ2UpIOKAlFxuICAgICAgLy8ga2VlcCB0aGUgZXhpc3RpbmcgcmVmZXJlbmNlIHJlY3QgcmF0aGVyIHRoYW4gcmVzZXR0aW5nIHRvIGFuIGludmFsaWRcbiAgICAgIC8vIG9uZSB3aXRoIG5vbi1maW5pdGUgdmFsdWVzLlxuICAgICAgaWYgKCFuYXRpdmVDbGllbnRSZWN0cy5sZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuIHt9O1xuICAgICAgfVxuICAgICAgY29uc3QgY2xpZW50UmVjdHMgPSBnZXRSZWN0c0J5TGluZShuYXRpdmVDbGllbnRSZWN0cyk7XG4gICAgICBjb25zdCBmYWxsYmFjayA9IHJlY3RUb0NsaWVudFJlY3QoZ2V0Qm91bmRpbmdSZWN0KG5hdGl2ZUNsaWVudFJlY3RzKSk7XG4gICAgICBjb25zdCBwYWRkaW5nT2JqZWN0ID0gZ2V0UGFkZGluZ09iamVjdChwYWRkaW5nKTtcbiAgICAgIGZ1bmN0aW9uIGdldEJvdW5kaW5nQ2xpZW50UmVjdCgpIHtcbiAgICAgICAgLy8gVGhlcmUgYXJlIHR3byByZWN0cyBhbmQgdGhleSBhcmUgZGlzam9pbmVkLlxuICAgICAgICBpZiAoY2xpZW50UmVjdHMubGVuZ3RoID09PSAyICYmIChjbGllbnRSZWN0c1swXS5sZWZ0ID4gY2xpZW50UmVjdHNbMV0ucmlnaHQgfHwgY2xpZW50UmVjdHNbMV0ubGVmdCA+IGNsaWVudFJlY3RzWzBdLnJpZ2h0KSAmJiB4ICE9IG51bGwgJiYgeSAhPSBudWxsKSB7XG4gICAgICAgICAgLy8gRmluZCB0aGUgZmlyc3QgcmVjdCBpbiB3aGljaCB0aGUgcG9pbnQgaXMgZnVsbHkgaW5zaWRlLlxuICAgICAgICAgIHJldHVybiBjbGllbnRSZWN0cy5maW5kKHJlY3QgPT4geCA+IHJlY3QubGVmdCAtIHBhZGRpbmdPYmplY3QubGVmdCAmJiB4IDwgcmVjdC5yaWdodCArIHBhZGRpbmdPYmplY3QucmlnaHQgJiYgeSA+IHJlY3QudG9wIC0gcGFkZGluZ09iamVjdC50b3AgJiYgeSA8IHJlY3QuYm90dG9tICsgcGFkZGluZ09iamVjdC5ib3R0b20pIHx8IGZhbGxiYWNrO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gVGhlcmUgYXJlIDIgb3IgbW9yZSBjb25uZWN0ZWQgcmVjdHMuXG4gICAgICAgIGlmIChjbGllbnRSZWN0cy5sZW5ndGggPj0gMikge1xuICAgICAgICAgIGlmIChnZXRTaWRlQXhpcyhwbGFjZW1lbnQpID09PSAneScpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpcnN0UmVjdCA9IGNsaWVudFJlY3RzWzBdO1xuICAgICAgICAgICAgY29uc3QgbGFzdFJlY3QgPSBjbGllbnRSZWN0c1tjbGllbnRSZWN0cy5sZW5ndGggLSAxXTtcbiAgICAgICAgICAgIGNvbnN0IGlzVG9wID0gZ2V0U2lkZShwbGFjZW1lbnQpID09PSAndG9wJztcbiAgICAgICAgICAgIGNvbnN0IHRvcCA9IGZpcnN0UmVjdC50b3A7XG4gICAgICAgICAgICBjb25zdCBib3R0b20gPSBsYXN0UmVjdC5ib3R0b207XG4gICAgICAgICAgICBjb25zdCBsZWZ0ID0gaXNUb3AgPyBmaXJzdFJlY3QubGVmdCA6IGxhc3RSZWN0LmxlZnQ7XG4gICAgICAgICAgICBjb25zdCByaWdodCA9IGlzVG9wID8gZmlyc3RSZWN0LnJpZ2h0IDogbGFzdFJlY3QucmlnaHQ7XG4gICAgICAgICAgICByZXR1cm4gcmVjdFRvQ2xpZW50UmVjdCh7XG4gICAgICAgICAgICAgIHg6IGxlZnQsXG4gICAgICAgICAgICAgIHk6IHRvcCxcbiAgICAgICAgICAgICAgd2lkdGg6IHJpZ2h0IC0gbGVmdCxcbiAgICAgICAgICAgICAgaGVpZ2h0OiBib3R0b20gLSB0b3BcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBpc0xlZnRTaWRlID0gZ2V0U2lkZShwbGFjZW1lbnQpID09PSAnbGVmdCc7XG4gICAgICAgICAgY29uc3QgbWF4UmlnaHQgPSBtYXgoLi4uY2xpZW50UmVjdHMubWFwKHJlY3QgPT4gcmVjdC5yaWdodCkpO1xuICAgICAgICAgIGNvbnN0IG1pbkxlZnQgPSBtaW4oLi4uY2xpZW50UmVjdHMubWFwKHJlY3QgPT4gcmVjdC5sZWZ0KSk7XG4gICAgICAgICAgY29uc3QgbWVhc3VyZVJlY3RzID0gY2xpZW50UmVjdHMuZmlsdGVyKHJlY3QgPT4gaXNMZWZ0U2lkZSA/IHJlY3QubGVmdCA9PT0gbWluTGVmdCA6IHJlY3QucmlnaHQgPT09IG1heFJpZ2h0KTtcbiAgICAgICAgICBjb25zdCB0b3AgPSBtZWFzdXJlUmVjdHNbMF0udG9wO1xuICAgICAgICAgIGNvbnN0IGJvdHRvbSA9IG1lYXN1cmVSZWN0c1ttZWFzdXJlUmVjdHMubGVuZ3RoIC0gMV0uYm90dG9tO1xuICAgICAgICAgIHJldHVybiByZWN0VG9DbGllbnRSZWN0KHtcbiAgICAgICAgICAgIHg6IG1pbkxlZnQsXG4gICAgICAgICAgICB5OiB0b3AsXG4gICAgICAgICAgICB3aWR0aDogbWF4UmlnaHQgLSBtaW5MZWZ0LFxuICAgICAgICAgICAgaGVpZ2h0OiBib3R0b20gLSB0b3BcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsbGJhY2s7XG4gICAgICB9XG4gICAgICBjb25zdCByZXNldFJlY3RzID0gYXdhaXQgcGxhdGZvcm0uZ2V0RWxlbWVudFJlY3RzKHtcbiAgICAgICAgcmVmZXJlbmNlOiB7XG4gICAgICAgICAgZ2V0Qm91bmRpbmdDbGllbnRSZWN0XG4gICAgICAgIH0sXG4gICAgICAgIGZsb2F0aW5nOiBlbGVtZW50cy5mbG9hdGluZyxcbiAgICAgICAgc3RyYXRlZ3lcbiAgICAgIH0pO1xuICAgICAgaWYgKHJlY3RzLnJlZmVyZW5jZS54ICE9PSByZXNldFJlY3RzLnJlZmVyZW5jZS54IHx8IHJlY3RzLnJlZmVyZW5jZS55ICE9PSByZXNldFJlY3RzLnJlZmVyZW5jZS55IHx8IHJlY3RzLnJlZmVyZW5jZS53aWR0aCAhPT0gcmVzZXRSZWN0cy5yZWZlcmVuY2Uud2lkdGggfHwgcmVjdHMucmVmZXJlbmNlLmhlaWdodCAhPT0gcmVzZXRSZWN0cy5yZWZlcmVuY2UuaGVpZ2h0KSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgcmVzZXQ6IHtcbiAgICAgICAgICAgIHJlY3RzOiByZXNldFJlY3RzXG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbiAgfTtcbn07XG5cbmNvbnN0IG9yaWdpblNpZGVzID0gLyojX19QVVJFX18qL25ldyBTZXQoWydsZWZ0JywgJ3RvcCddKTtcblxuLy8gRm9yIHR5cGUgYmFja3dhcmRzLWNvbXBhdGliaWxpdHksIHRoZSBgT2Zmc2V0T3B0aW9uc2AgdHlwZSB3YXMgYWxzb1xuLy8gRGVyaXZhYmxlLlxuXG5hc3luYyBmdW5jdGlvbiBjb252ZXJ0VmFsdWVUb0Nvb3JkcyhzdGF0ZSwgb3B0aW9ucykge1xuICBjb25zdCB7XG4gICAgcGxhY2VtZW50LFxuICAgIHBsYXRmb3JtLFxuICAgIGVsZW1lbnRzXG4gIH0gPSBzdGF0ZTtcbiAgY29uc3QgcnRsID0gYXdhaXQgKHBsYXRmb3JtLmlzUlRMID09IG51bGwgPyB2b2lkIDAgOiBwbGF0Zm9ybS5pc1JUTChlbGVtZW50cy5mbG9hdGluZykpO1xuICBjb25zdCBzaWRlID0gZ2V0U2lkZShwbGFjZW1lbnQpO1xuICBjb25zdCBhbGlnbm1lbnQgPSBnZXRBbGlnbm1lbnQocGxhY2VtZW50KTtcbiAgY29uc3QgaXNWZXJ0aWNhbCA9IGdldFNpZGVBeGlzKHBsYWNlbWVudCkgPT09ICd5JztcbiAgY29uc3QgbWFpbkF4aXNNdWx0aSA9IG9yaWdpblNpZGVzLmhhcyhzaWRlKSA/IC0xIDogMTtcbiAgY29uc3QgY3Jvc3NBeGlzTXVsdGkgPSBydGwgJiYgaXNWZXJ0aWNhbCA/IC0xIDogMTtcbiAgY29uc3QgcmF3VmFsdWUgPSBldmFsdWF0ZShvcHRpb25zLCBzdGF0ZSk7XG5cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHByZWZlci1jb25zdFxuICBsZXQge1xuICAgIG1haW5BeGlzLFxuICAgIGNyb3NzQXhpcyxcbiAgICBhbGlnbm1lbnRBeGlzXG4gIH0gPSB0eXBlb2YgcmF3VmFsdWUgPT09ICdudW1iZXInID8ge1xuICAgIG1haW5BeGlzOiByYXdWYWx1ZSxcbiAgICBjcm9zc0F4aXM6IDAsXG4gICAgYWxpZ25tZW50QXhpczogbnVsbFxuICB9IDoge1xuICAgIG1haW5BeGlzOiByYXdWYWx1ZS5tYWluQXhpcyB8fCAwLFxuICAgIGNyb3NzQXhpczogcmF3VmFsdWUuY3Jvc3NBeGlzIHx8IDAsXG4gICAgYWxpZ25tZW50QXhpczogcmF3VmFsdWUuYWxpZ25tZW50QXhpc1xuICB9O1xuICBpZiAoYWxpZ25tZW50ICYmIHR5cGVvZiBhbGlnbm1lbnRBeGlzID09PSAnbnVtYmVyJykge1xuICAgIGNyb3NzQXhpcyA9IGFsaWdubWVudCA9PT0gJ2VuZCcgPyBhbGlnbm1lbnRBeGlzICogLTEgOiBhbGlnbm1lbnRBeGlzO1xuICB9XG4gIHJldHVybiBpc1ZlcnRpY2FsID8ge1xuICAgIHg6IGNyb3NzQXhpcyAqIGNyb3NzQXhpc011bHRpLFxuICAgIHk6IG1haW5BeGlzICogbWFpbkF4aXNNdWx0aVxuICB9IDoge1xuICAgIHg6IG1haW5BeGlzICogbWFpbkF4aXNNdWx0aSxcbiAgICB5OiBjcm9zc0F4aXMgKiBjcm9zc0F4aXNNdWx0aVxuICB9O1xufVxuXG4vKipcbiAqIE1vZGlmaWVzIHRoZSBwbGFjZW1lbnQgYnkgdHJhbnNsYXRpbmcgdGhlIGZsb2F0aW5nIGVsZW1lbnQgYWxvbmcgdGhlXG4gKiBzcGVjaWZpZWQgYXhlcy5cbiAqIEEgbnVtYmVyIChzaG9ydGhhbmQgZm9yIGBtYWluQXhpc2Agb3IgZGlzdGFuY2UpLCBvciBhbiBheGVzIGNvbmZpZ3VyYXRpb25cbiAqIG9iamVjdCBtYXkgYmUgcGFzc2VkLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL29mZnNldFxuICovXG5jb25zdCBvZmZzZXQgPSBmdW5jdGlvbiAob3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IDA7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBuYW1lOiAnb2Zmc2V0JyxcbiAgICBvcHRpb25zLFxuICAgIGFzeW5jIGZuKHN0YXRlKSB7XG4gICAgICB2YXIgX21pZGRsZXdhcmVEYXRhJG9mZnNlLCBfbWlkZGxld2FyZURhdGEkYXJyb3c7XG4gICAgICBjb25zdCB7XG4gICAgICAgIHgsXG4gICAgICAgIHksXG4gICAgICAgIHBsYWNlbWVudCxcbiAgICAgICAgbWlkZGxld2FyZURhdGFcbiAgICAgIH0gPSBzdGF0ZTtcbiAgICAgIGNvbnN0IGRpZmZDb29yZHMgPSBhd2FpdCBjb252ZXJ0VmFsdWVUb0Nvb3JkcyhzdGF0ZSwgb3B0aW9ucyk7XG5cbiAgICAgIC8vIElmIHRoZSBwbGFjZW1lbnQgaXMgdGhlIHNhbWUgYW5kIHRoZSBhcnJvdyBjYXVzZWQgYW4gYWxpZ25tZW50IG9mZnNldFxuICAgICAgLy8gdGhlbiB3ZSBkb24ndCBuZWVkIHRvIGNoYW5nZSB0aGUgcG9zaXRpb25pbmcgY29vcmRpbmF0ZXMuXG4gICAgICBpZiAocGxhY2VtZW50ID09PSAoKF9taWRkbGV3YXJlRGF0YSRvZmZzZSA9IG1pZGRsZXdhcmVEYXRhLm9mZnNldCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9taWRkbGV3YXJlRGF0YSRvZmZzZS5wbGFjZW1lbnQpICYmIChfbWlkZGxld2FyZURhdGEkYXJyb3cgPSBtaWRkbGV3YXJlRGF0YS5hcnJvdykgIT0gbnVsbCAmJiBfbWlkZGxld2FyZURhdGEkYXJyb3cuYWxpZ25tZW50T2Zmc2V0KSB7XG4gICAgICAgIHJldHVybiB7fTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7XG4gICAgICAgIHg6IHggKyBkaWZmQ29vcmRzLngsXG4gICAgICAgIHk6IHkgKyBkaWZmQ29vcmRzLnksXG4gICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAuLi5kaWZmQ29vcmRzLFxuICAgICAgICAgIHBsYWNlbWVudFxuICAgICAgICB9XG4gICAgICB9O1xuICAgIH1cbiAgfTtcbn07XG5cbi8qKlxuICogT3B0aW1pemVzIHRoZSB2aXNpYmlsaXR5IG9mIHRoZSBmbG9hdGluZyBlbGVtZW50IGJ5IHNoaWZ0aW5nIGl0IGluIG9yZGVyIHRvXG4gKiBrZWVwIGl0IGluIHZpZXcgd2hlbiBpdCB3aWxsIG92ZXJmbG93IHRoZSBjbGlwcGluZyBib3VuZGFyeS5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9zaGlmdFxuICovXG5jb25zdCBzaGlmdCA9IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBuYW1lOiAnc2hpZnQnLFxuICAgIG9wdGlvbnMsXG4gICAgYXN5bmMgZm4oc3RhdGUpIHtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgeCxcbiAgICAgICAgeSxcbiAgICAgICAgcGxhY2VtZW50LFxuICAgICAgICBwbGF0Zm9ybVxuICAgICAgfSA9IHN0YXRlO1xuICAgICAgY29uc3Qge1xuICAgICAgICBtYWluQXhpczogY2hlY2tNYWluQXhpcyA9IHRydWUsXG4gICAgICAgIGNyb3NzQXhpczogY2hlY2tDcm9zc0F4aXMgPSBmYWxzZSxcbiAgICAgICAgbGltaXRlciA9IHtcbiAgICAgICAgICBmbjogX3JlZiA9PiB7XG4gICAgICAgICAgICBsZXQge1xuICAgICAgICAgICAgICB4LFxuICAgICAgICAgICAgICB5XG4gICAgICAgICAgICB9ID0gX3JlZjtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgIHgsXG4gICAgICAgICAgICAgIHlcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICAuLi5kZXRlY3RPdmVyZmxvd09wdGlvbnNcbiAgICAgIH0gPSBldmFsdWF0ZShvcHRpb25zLCBzdGF0ZSk7XG4gICAgICBjb25zdCBjb29yZHMgPSB7XG4gICAgICAgIHgsXG4gICAgICAgIHlcbiAgICAgIH07XG4gICAgICBjb25zdCBvdmVyZmxvdyA9IGF3YWl0IHBsYXRmb3JtLmRldGVjdE92ZXJmbG93KHN0YXRlLCBkZXRlY3RPdmVyZmxvd09wdGlvbnMpO1xuICAgICAgY29uc3QgY3Jvc3NBeGlzID0gZ2V0U2lkZUF4aXMocGxhY2VtZW50KTtcbiAgICAgIGNvbnN0IG1haW5BeGlzID0gZ2V0T3Bwb3NpdGVBeGlzKGNyb3NzQXhpcyk7XG4gICAgICBsZXQgbWFpbkF4aXNDb29yZCA9IGNvb3Jkc1ttYWluQXhpc107XG4gICAgICBsZXQgY3Jvc3NBeGlzQ29vcmQgPSBjb29yZHNbY3Jvc3NBeGlzXTtcbiAgICAgIGNvbnN0IGNsYW1wQ29vcmQgPSAoYXhpcywgY29vcmQpID0+IGNsYW1wKGNvb3JkICsgb3ZlcmZsb3dbYXhpcyA9PT0gJ3knID8gJ3RvcCcgOiAnbGVmdCddLCBjb29yZCwgY29vcmQgLSBvdmVyZmxvd1theGlzID09PSAneScgPyAnYm90dG9tJyA6ICdyaWdodCddKTtcbiAgICAgIGlmIChjaGVja01haW5BeGlzKSB7XG4gICAgICAgIG1haW5BeGlzQ29vcmQgPSBjbGFtcENvb3JkKG1haW5BeGlzLCBtYWluQXhpc0Nvb3JkKTtcbiAgICAgIH1cbiAgICAgIGlmIChjaGVja0Nyb3NzQXhpcykge1xuICAgICAgICBjcm9zc0F4aXNDb29yZCA9IGNsYW1wQ29vcmQoY3Jvc3NBeGlzLCBjcm9zc0F4aXNDb29yZCk7XG4gICAgICB9XG4gICAgICBjb25zdCBsaW1pdGVkQ29vcmRzID0gbGltaXRlci5mbih7XG4gICAgICAgIC4uLnN0YXRlLFxuICAgICAgICBbbWFpbkF4aXNdOiBtYWluQXhpc0Nvb3JkLFxuICAgICAgICBbY3Jvc3NBeGlzXTogY3Jvc3NBeGlzQ29vcmRcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4ubGltaXRlZENvb3JkcyxcbiAgICAgICAgZGF0YToge1xuICAgICAgICAgIHg6IGxpbWl0ZWRDb29yZHMueCAtIHgsXG4gICAgICAgICAgeTogbGltaXRlZENvb3Jkcy55IC0geSxcbiAgICAgICAgICBlbmFibGVkOiB7XG4gICAgICAgICAgICBbbWFpbkF4aXNdOiBjaGVja01haW5BeGlzLFxuICAgICAgICAgICAgW2Nyb3NzQXhpc106IGNoZWNrQ3Jvc3NBeGlzXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9O1xuICAgIH1cbiAgfTtcbn07XG4vKipcbiAqIEJ1aWx0LWluIGBsaW1pdGVyYCB0aGF0IHdpbGwgc3RvcCBgc2hpZnQoKWAgYXQgYSBjZXJ0YWluIHBvaW50LlxuICovXG5jb25zdCBsaW1pdFNoaWZ0ID0gZnVuY3Rpb24gKG9wdGlvbnMpIHtcbiAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkge1xuICAgIG9wdGlvbnMgPSB7fTtcbiAgfVxuICByZXR1cm4ge1xuICAgIG9wdGlvbnMsXG4gICAgZm4oc3RhdGUpIHtcbiAgICAgIHZhciBfcmF3T2Zmc2V0JG1haW5BeGlzLCBfcmF3T2Zmc2V0JGNyb3NzQXhpcztcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgeCxcbiAgICAgICAgeSxcbiAgICAgICAgcGxhY2VtZW50LFxuICAgICAgICByZWN0cyxcbiAgICAgICAgbWlkZGxld2FyZURhdGFcbiAgICAgIH0gPSBzdGF0ZTtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgb2Zmc2V0ID0gMCxcbiAgICAgICAgbWFpbkF4aXM6IGNoZWNrTWFpbkF4aXMgPSB0cnVlLFxuICAgICAgICBjcm9zc0F4aXM6IGNoZWNrQ3Jvc3NBeGlzID0gdHJ1ZVxuICAgICAgfSA9IGV2YWx1YXRlKG9wdGlvbnMsIHN0YXRlKTtcbiAgICAgIGNvbnN0IGNvb3JkcyA9IHtcbiAgICAgICAgeCxcbiAgICAgICAgeVxuICAgICAgfTtcbiAgICAgIGNvbnN0IGNyb3NzQXhpcyA9IGdldFNpZGVBeGlzKHBsYWNlbWVudCk7XG4gICAgICBjb25zdCBtYWluQXhpcyA9IGdldE9wcG9zaXRlQXhpcyhjcm9zc0F4aXMpO1xuICAgICAgbGV0IG1haW5BeGlzQ29vcmQgPSBjb29yZHNbbWFpbkF4aXNdO1xuICAgICAgbGV0IGNyb3NzQXhpc0Nvb3JkID0gY29vcmRzW2Nyb3NzQXhpc107XG4gICAgICBjb25zdCByYXdPZmZzZXQgPSBldmFsdWF0ZShvZmZzZXQsIHN0YXRlKTtcbiAgICAgIGNvbnN0IGNvbXB1dGVkT2Zmc2V0ID0gdHlwZW9mIHJhd09mZnNldCA9PT0gJ251bWJlcicgPyB7XG4gICAgICAgIG1haW5BeGlzOiByYXdPZmZzZXQsXG4gICAgICAgIGNyb3NzQXhpczogMFxuICAgICAgfSA6IHtcbiAgICAgICAgbWFpbkF4aXM6IChfcmF3T2Zmc2V0JG1haW5BeGlzID0gcmF3T2Zmc2V0Lm1haW5BeGlzKSAhPSBudWxsID8gX3Jhd09mZnNldCRtYWluQXhpcyA6IDAsXG4gICAgICAgIGNyb3NzQXhpczogKF9yYXdPZmZzZXQkY3Jvc3NBeGlzID0gcmF3T2Zmc2V0LmNyb3NzQXhpcykgIT0gbnVsbCA/IF9yYXdPZmZzZXQkY3Jvc3NBeGlzIDogMFxuICAgICAgfTtcbiAgICAgIGlmIChjaGVja01haW5BeGlzKSB7XG4gICAgICAgIGNvbnN0IGxlbiA9IG1haW5BeGlzID09PSAneScgPyAnaGVpZ2h0JyA6ICd3aWR0aCc7XG4gICAgICAgIGNvbnN0IGxpbWl0TWluID0gcmVjdHMucmVmZXJlbmNlW21haW5BeGlzXSAtIHJlY3RzLmZsb2F0aW5nW2xlbl0gKyBjb21wdXRlZE9mZnNldC5tYWluQXhpcztcbiAgICAgICAgY29uc3QgbGltaXRNYXggPSByZWN0cy5yZWZlcmVuY2VbbWFpbkF4aXNdICsgcmVjdHMucmVmZXJlbmNlW2xlbl0gLSBjb21wdXRlZE9mZnNldC5tYWluQXhpcztcbiAgICAgICAgaWYgKG1haW5BeGlzQ29vcmQgPCBsaW1pdE1pbikge1xuICAgICAgICAgIG1haW5BeGlzQ29vcmQgPSBsaW1pdE1pbjtcbiAgICAgICAgfSBlbHNlIGlmIChtYWluQXhpc0Nvb3JkID4gbGltaXRNYXgpIHtcbiAgICAgICAgICBtYWluQXhpc0Nvb3JkID0gbGltaXRNYXg7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChjaGVja0Nyb3NzQXhpcykge1xuICAgICAgICB2YXIgX21pZGRsZXdhcmVEYXRhJG9mZnNlLCBfbWlkZGxld2FyZURhdGEkb2Zmc2UyO1xuICAgICAgICBjb25zdCBsZW4gPSBtYWluQXhpcyA9PT0gJ3knID8gJ3dpZHRoJyA6ICdoZWlnaHQnO1xuICAgICAgICBjb25zdCBpc09yaWdpblNpZGUgPSBvcmlnaW5TaWRlcy5oYXMoZ2V0U2lkZShwbGFjZW1lbnQpKTtcbiAgICAgICAgY29uc3QgbGltaXRNaW4gPSByZWN0cy5yZWZlcmVuY2VbY3Jvc3NBeGlzXSAtIHJlY3RzLmZsb2F0aW5nW2xlbl0gKyAoaXNPcmlnaW5TaWRlID8gKChfbWlkZGxld2FyZURhdGEkb2Zmc2UgPSBtaWRkbGV3YXJlRGF0YS5vZmZzZXQpID09IG51bGwgPyB2b2lkIDAgOiBfbWlkZGxld2FyZURhdGEkb2Zmc2VbY3Jvc3NBeGlzXSkgfHwgMCA6IDApICsgKGlzT3JpZ2luU2lkZSA/IDAgOiBjb21wdXRlZE9mZnNldC5jcm9zc0F4aXMpO1xuICAgICAgICBjb25zdCBsaW1pdE1heCA9IHJlY3RzLnJlZmVyZW5jZVtjcm9zc0F4aXNdICsgcmVjdHMucmVmZXJlbmNlW2xlbl0gKyAoaXNPcmlnaW5TaWRlID8gMCA6ICgoX21pZGRsZXdhcmVEYXRhJG9mZnNlMiA9IG1pZGRsZXdhcmVEYXRhLm9mZnNldCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9taWRkbGV3YXJlRGF0YSRvZmZzZTJbY3Jvc3NBeGlzXSkgfHwgMCkgLSAoaXNPcmlnaW5TaWRlID8gY29tcHV0ZWRPZmZzZXQuY3Jvc3NBeGlzIDogMCk7XG4gICAgICAgIGlmIChjcm9zc0F4aXNDb29yZCA8IGxpbWl0TWluKSB7XG4gICAgICAgICAgY3Jvc3NBeGlzQ29vcmQgPSBsaW1pdE1pbjtcbiAgICAgICAgfSBlbHNlIGlmIChjcm9zc0F4aXNDb29yZCA+IGxpbWl0TWF4KSB7XG4gICAgICAgICAgY3Jvc3NBeGlzQ29vcmQgPSBsaW1pdE1heDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgW21haW5BeGlzXTogbWFpbkF4aXNDb29yZCxcbiAgICAgICAgW2Nyb3NzQXhpc106IGNyb3NzQXhpc0Nvb3JkXG4gICAgICB9O1xuICAgIH1cbiAgfTtcbn07XG5cbi8vIE1ldGhvZCBzeW50YXgga2VlcHMgY2FsbGJhY2sgcGFyYW1ldGVycyBiaXZhcmlhbnQsIGJ1dCBleHByZXNzaW5nIHRoZVxuLy8gZXhwbGljaXQgYHwgdW5kZWZpbmVkYCByZXF1aXJlZCBieSBgZXhhY3RPcHRpb25hbFByb3BlcnR5VHlwZXNgIG5lZWRzXG4vLyBwcm9wZXJ0eSBzeW50YXgsIHdoaWNoIGlzIGNvbnRyYXZhcmlhbnQgdW5kZXIgYHN0cmljdEZ1bmN0aW9uVHlwZXNgLlxuLy8gRXh0cmFjdGluZyB0aGUgZnVuY3Rpb24gZnJvbSBhIG1ldGhvZCBwb3NpdGlvbiByZXN0b3JlcyB0aGF0IGJpdmFyaWFuY2Ugc29cbi8vIGNvbnN1bWVycyBjYW4gc3RpbGwgYXNzaWduIGNhbGxiYWNrcyB3aXRoIG5hcnJvd2VyIHBhcmFtZXRlciB0eXBlcy5cblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRoYXQgYWxsb3dzIHlvdSB0byBjaGFuZ2UgdGhlIHNpemUgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQg4oCUXG4gKiBmb3IgaW5zdGFuY2UsIHByZXZlbnQgaXQgZnJvbSBvdmVyZmxvd2luZyB0aGUgY2xpcHBpbmcgYm91bmRhcnkgb3IgbWF0Y2ggdGhlXG4gKiB3aWR0aCBvZiB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3Mvc2l6ZVxuICovXG5jb25zdCBzaXplID0gZnVuY3Rpb24gKG9wdGlvbnMpIHtcbiAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkge1xuICAgIG9wdGlvbnMgPSB7fTtcbiAgfVxuICByZXR1cm4ge1xuICAgIG5hbWU6ICdzaXplJyxcbiAgICBvcHRpb25zLFxuICAgIGFzeW5jIGZuKHN0YXRlKSB7XG4gICAgICBjb25zdCB7XG4gICAgICAgIHBsYWNlbWVudCxcbiAgICAgICAgcmVjdHMsXG4gICAgICAgIHBsYXRmb3JtLFxuICAgICAgICBlbGVtZW50c1xuICAgICAgfSA9IHN0YXRlO1xuICAgICAgY29uc3Qge1xuICAgICAgICBhcHBseSA9ICgpID0+IHt9LFxuICAgICAgICAuLi5kZXRlY3RPdmVyZmxvd09wdGlvbnNcbiAgICAgIH0gPSBldmFsdWF0ZShvcHRpb25zLCBzdGF0ZSk7XG4gICAgICBjb25zdCBvdmVyZmxvdyA9IGF3YWl0IHBsYXRmb3JtLmRldGVjdE92ZXJmbG93KHN0YXRlLCBkZXRlY3RPdmVyZmxvd09wdGlvbnMpO1xuICAgICAgY29uc3Qgc2lkZSA9IGdldFNpZGUocGxhY2VtZW50KTtcbiAgICAgIGNvbnN0IGFsaWdubWVudCA9IGdldEFsaWdubWVudChwbGFjZW1lbnQpO1xuICAgICAgY29uc3QgaXNZQXhpcyA9IGdldFNpZGVBeGlzKHBsYWNlbWVudCkgPT09ICd5JztcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgd2lkdGgsXG4gICAgICAgIGhlaWdodFxuICAgICAgfSA9IHJlY3RzLmZsb2F0aW5nO1xuICAgICAgbGV0IGhlaWdodFNpZGU7XG4gICAgICBsZXQgd2lkdGhTaWRlO1xuICAgICAgaWYgKHNpZGUgPT09ICd0b3AnIHx8IHNpZGUgPT09ICdib3R0b20nKSB7XG4gICAgICAgIGhlaWdodFNpZGUgPSBzaWRlO1xuICAgICAgICB3aWR0aFNpZGUgPSBhbGlnbm1lbnQgPT09ICgoYXdhaXQgKHBsYXRmb3JtLmlzUlRMID09IG51bGwgPyB2b2lkIDAgOiBwbGF0Zm9ybS5pc1JUTChlbGVtZW50cy5mbG9hdGluZykpKSA/ICdzdGFydCcgOiAnZW5kJykgPyAnbGVmdCcgOiAncmlnaHQnO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgd2lkdGhTaWRlID0gc2lkZTtcbiAgICAgICAgaGVpZ2h0U2lkZSA9IGFsaWdubWVudCA9PT0gJ2VuZCcgPyAndG9wJyA6ICdib3R0b20nO1xuICAgICAgfVxuICAgICAgY29uc3QgbWF4aW11bUNsaXBwaW5nSGVpZ2h0ID0gaGVpZ2h0IC0gb3ZlcmZsb3cudG9wIC0gb3ZlcmZsb3cuYm90dG9tO1xuICAgICAgY29uc3QgbWF4aW11bUNsaXBwaW5nV2lkdGggPSB3aWR0aCAtIG92ZXJmbG93LmxlZnQgLSBvdmVyZmxvdy5yaWdodDtcbiAgICAgIGNvbnN0IG92ZXJmbG93QXZhaWxhYmxlSGVpZ2h0ID0gbWluKGhlaWdodCAtIG92ZXJmbG93W2hlaWdodFNpZGVdLCBtYXhpbXVtQ2xpcHBpbmdIZWlnaHQpO1xuICAgICAgY29uc3Qgb3ZlcmZsb3dBdmFpbGFibGVXaWR0aCA9IG1pbih3aWR0aCAtIG92ZXJmbG93W3dpZHRoU2lkZV0sIG1heGltdW1DbGlwcGluZ1dpZHRoKTtcbiAgICAgIGNvbnN0IHNoaWZ0RGF0YSA9IHN0YXRlLm1pZGRsZXdhcmVEYXRhLnNoaWZ0O1xuICAgICAgY29uc3Qgbm9TaGlmdCA9ICFzaGlmdERhdGE7XG4gICAgICBsZXQgYXZhaWxhYmxlSGVpZ2h0ID0gb3ZlcmZsb3dBdmFpbGFibGVIZWlnaHQ7XG4gICAgICBsZXQgYXZhaWxhYmxlV2lkdGggPSBvdmVyZmxvd0F2YWlsYWJsZVdpZHRoO1xuICAgICAgaWYgKHNoaWZ0RGF0YSAhPSBudWxsICYmIHNoaWZ0RGF0YS5lbmFibGVkLngpIHtcbiAgICAgICAgYXZhaWxhYmxlV2lkdGggPSBtYXhpbXVtQ2xpcHBpbmdXaWR0aDtcbiAgICAgIH1cbiAgICAgIGlmIChzaGlmdERhdGEgIT0gbnVsbCAmJiBzaGlmdERhdGEuZW5hYmxlZC55KSB7XG4gICAgICAgIGF2YWlsYWJsZUhlaWdodCA9IG1heGltdW1DbGlwcGluZ0hlaWdodDtcbiAgICAgIH1cbiAgICAgIGlmIChub1NoaWZ0ICYmICFhbGlnbm1lbnQpIHtcbiAgICAgICAgaWYgKGlzWUF4aXMpIHtcbiAgICAgICAgICBhdmFpbGFibGVXaWR0aCA9IHdpZHRoIC0gMiAqIG1heChvdmVyZmxvdy5sZWZ0LCBvdmVyZmxvdy5yaWdodCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgYXZhaWxhYmxlSGVpZ2h0ID0gaGVpZ2h0IC0gMiAqIG1heChvdmVyZmxvdy50b3AsIG92ZXJmbG93LmJvdHRvbSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGF3YWl0IGFwcGx5KHtcbiAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgIGF2YWlsYWJsZVdpZHRoLFxuICAgICAgICBhdmFpbGFibGVIZWlnaHRcbiAgICAgIH0pO1xuICAgICAgY29uc3QgbmV4dERpbWVuc2lvbnMgPSBhd2FpdCBwbGF0Zm9ybS5nZXREaW1lbnNpb25zKGVsZW1lbnRzLmZsb2F0aW5nKTtcbiAgICAgIGlmICh3aWR0aCAhPT0gbmV4dERpbWVuc2lvbnMud2lkdGggfHwgaGVpZ2h0ICE9PSBuZXh0RGltZW5zaW9ucy5oZWlnaHQpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICByZXNldDoge1xuICAgICAgICAgICAgcmVjdHM6IHRydWVcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICByZXR1cm4ge307XG4gICAgfVxuICB9O1xufTtcblxuZXhwb3J0IHsgYXJyb3csIGF1dG9QbGFjZW1lbnQsIGNvbXB1dGVQb3NpdGlvbiwgZGV0ZWN0T3ZlcmZsb3csIGZsaXAsIGhpZGUsIGlubGluZSwgbGltaXRTaGlmdCwgb2Zmc2V0LCBzaGlmdCwgc2l6ZSB9O1xuIiwiZnVuY3Rpb24gaGFzV2luZG93KCkge1xuICByZXR1cm4gdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCc7XG59XG5mdW5jdGlvbiBnZXROb2RlTmFtZShub2RlKSB7XG4gIGlmIChpc05vZGUobm9kZSkpIHtcbiAgICByZXR1cm4gKG5vZGUubm9kZU5hbWUgfHwgJycpLnRvTG93ZXJDYXNlKCk7XG4gIH1cbiAgLy8gTW9ja2VkIG5vZGVzIGluIHRlc3RpbmcgZW52aXJvbm1lbnRzIG1heSBub3QgYmUgaW5zdGFuY2VzIG9mIE5vZGUuIEJ5XG4gIC8vIHJldHVybmluZyBgI2RvY3VtZW50YCBhbiBpbmZpbml0ZSBsb29wIHdvbid0IG9jY3VyLlxuICAvLyBodHRwczovL2dpdGh1Yi5jb20vZmxvYXRpbmctdWkvZmxvYXRpbmctdWkvaXNzdWVzLzIzMTdcbiAgcmV0dXJuICcjZG9jdW1lbnQnO1xufVxuZnVuY3Rpb24gZ2V0V2luZG93KG5vZGUpIHtcbiAgdmFyIF9ub2RlJG93bmVyRG9jdW1lbnQ7XG4gIHJldHVybiAobm9kZSA9PSBudWxsIHx8IChfbm9kZSRvd25lckRvY3VtZW50ID0gbm9kZS5vd25lckRvY3VtZW50KSA9PSBudWxsID8gdm9pZCAwIDogX25vZGUkb3duZXJEb2N1bWVudC5kZWZhdWx0VmlldykgfHwgd2luZG93O1xufVxuZnVuY3Rpb24gZ2V0RG9jdW1lbnRFbGVtZW50KG5vZGUpIHtcbiAgdmFyIF9yZWY7XG4gIHJldHVybiAoX3JlZiA9IChpc05vZGUobm9kZSkgPyBub2RlLm93bmVyRG9jdW1lbnQgOiBub2RlLmRvY3VtZW50KSB8fCB3aW5kb3cuZG9jdW1lbnQpID09IG51bGwgPyB2b2lkIDAgOiBfcmVmLmRvY3VtZW50RWxlbWVudDtcbn1cbmZ1bmN0aW9uIGlzTm9kZSh2YWx1ZSkge1xuICBpZiAoIWhhc1dpbmRvdygpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIE5vZGUgfHwgdmFsdWUgaW5zdGFuY2VvZiBnZXRXaW5kb3codmFsdWUpLk5vZGU7XG59XG5mdW5jdGlvbiBpc0VsZW1lbnQodmFsdWUpIHtcbiAgaWYgKCFoYXNXaW5kb3coKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBFbGVtZW50IHx8IHZhbHVlIGluc3RhbmNlb2YgZ2V0V2luZG93KHZhbHVlKS5FbGVtZW50O1xufVxuZnVuY3Rpb24gaXNIVE1MRWxlbWVudCh2YWx1ZSkge1xuICBpZiAoIWhhc1dpbmRvdygpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIEhUTUxFbGVtZW50IHx8IHZhbHVlIGluc3RhbmNlb2YgZ2V0V2luZG93KHZhbHVlKS5IVE1MRWxlbWVudDtcbn1cbmZ1bmN0aW9uIGlzU2hhZG93Um9vdCh2YWx1ZSkge1xuICBpZiAoIWhhc1dpbmRvdygpIHx8IHR5cGVvZiBTaGFkb3dSb290ID09PSAndW5kZWZpbmVkJykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBTaGFkb3dSb290IHx8IHZhbHVlIGluc3RhbmNlb2YgZ2V0V2luZG93KHZhbHVlKS5TaGFkb3dSb290O1xufVxuZnVuY3Rpb24gaXNPdmVyZmxvd0VsZW1lbnQoZWxlbWVudCkge1xuICBjb25zdCB7XG4gICAgb3ZlcmZsb3csXG4gICAgb3ZlcmZsb3dYLFxuICAgIG92ZXJmbG93WSxcbiAgICBkaXNwbGF5XG4gIH0gPSBnZXRDb21wdXRlZFN0eWxlKGVsZW1lbnQpO1xuICByZXR1cm4gL2F1dG98c2Nyb2xsfG92ZXJsYXl8aGlkZGVufGNsaXAvLnRlc3Qob3ZlcmZsb3cgKyBvdmVyZmxvd1kgKyBvdmVyZmxvd1gpICYmIGRpc3BsYXkgIT09ICdpbmxpbmUnICYmIGRpc3BsYXkgIT09ICdjb250ZW50cyc7XG59XG5mdW5jdGlvbiBpc1RhYmxlRWxlbWVudChlbGVtZW50KSB7XG4gIHJldHVybiAvXih0YWJsZXx0ZHx0aCkkLy50ZXN0KGdldE5vZGVOYW1lKGVsZW1lbnQpKTtcbn1cbmZ1bmN0aW9uIGlzVG9wTGF5ZXIoZWxlbWVudCkge1xuICB0cnkge1xuICAgIGlmIChlbGVtZW50Lm1hdGNoZXMoJzpwb3BvdmVyLW9wZW4nKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9IGNhdGNoIChfZSkge1xuICAgIC8vIG5vLW9wXG4gIH1cbiAgdHJ5IHtcbiAgICByZXR1cm4gZWxlbWVudC5tYXRjaGVzKCc6bW9kYWwnKTtcbiAgfSBjYXRjaCAoX2UpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cbmNvbnN0IHdpbGxDaGFuZ2VSZSA9IC90cmFuc2Zvcm18dHJhbnNsYXRlfHNjYWxlfHJvdGF0ZXxwZXJzcGVjdGl2ZXxmaWx0ZXIvO1xuY29uc3QgY29udGFpblJlID0gL3BhaW50fGxheW91dHxzdHJpY3R8Y29udGVudC87XG5jb25zdCBpc05vdE5vbmUgPSB2YWx1ZSA9PiAhIXZhbHVlICYmIHZhbHVlICE9PSAnbm9uZSc7XG5sZXQgaXNXZWJLaXRWYWx1ZTtcbmZ1bmN0aW9uIGlzQ29udGFpbmluZ0Jsb2NrKGVsZW1lbnRPckNzcykge1xuICBjb25zdCBjc3MgPSBpc0VsZW1lbnQoZWxlbWVudE9yQ3NzKSA/IGdldENvbXB1dGVkU3R5bGUoZWxlbWVudE9yQ3NzKSA6IGVsZW1lbnRPckNzcztcblxuICAvLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9DU1MvQ29udGFpbmluZ19ibG9jayNpZGVudGlmeWluZ190aGVfY29udGFpbmluZ19ibG9ja1xuICAvLyBodHRwczovL2RyYWZ0cy5jc3N3Zy5vcmcvY3NzLXRyYW5zZm9ybXMtMi8jaW5kaXZpZHVhbC10cmFuc2Zvcm1zXG4gIHJldHVybiBpc05vdE5vbmUoY3NzLnRyYW5zZm9ybSkgfHwgaXNOb3ROb25lKGNzcy50cmFuc2xhdGUpIHx8IGlzTm90Tm9uZShjc3Muc2NhbGUpIHx8IGlzTm90Tm9uZShjc3Mucm90YXRlKSB8fCBpc05vdE5vbmUoY3NzLnBlcnNwZWN0aXZlKSB8fCAhaXNXZWJLaXQoKSAmJiAoaXNOb3ROb25lKGNzcy5iYWNrZHJvcEZpbHRlcikgfHwgaXNOb3ROb25lKGNzcy5maWx0ZXIpKSB8fCB3aWxsQ2hhbmdlUmUudGVzdChjc3Mud2lsbENoYW5nZSB8fCAnJykgfHwgY29udGFpblJlLnRlc3QoY3NzLmNvbnRhaW4gfHwgJycpO1xufVxuZnVuY3Rpb24gZ2V0Q29udGFpbmluZ0Jsb2NrKGVsZW1lbnQpIHtcbiAgbGV0IGN1cnJlbnROb2RlID0gZ2V0UGFyZW50Tm9kZShlbGVtZW50KTtcbiAgd2hpbGUgKGlzSFRNTEVsZW1lbnQoY3VycmVudE5vZGUpICYmICFpc0xhc3RUcmF2ZXJzYWJsZU5vZGUoY3VycmVudE5vZGUpKSB7XG4gICAgaWYgKGlzQ29udGFpbmluZ0Jsb2NrKGN1cnJlbnROb2RlKSkge1xuICAgICAgcmV0dXJuIGN1cnJlbnROb2RlO1xuICAgIH0gZWxzZSBpZiAoaXNUb3BMYXllcihjdXJyZW50Tm9kZSkpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjdXJyZW50Tm9kZSA9IGdldFBhcmVudE5vZGUoY3VycmVudE5vZGUpO1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gaXNXZWJLaXQoKSB7XG4gIGlmIChpc1dlYktpdFZhbHVlID09IG51bGwpIHtcbiAgICBpc1dlYktpdFZhbHVlID0gdHlwZW9mIENTUyAhPT0gJ3VuZGVmaW5lZCcgJiYgQ1NTLnN1cHBvcnRzICYmIENTUy5zdXBwb3J0cygnLXdlYmtpdC1iYWNrZHJvcC1maWx0ZXInLCAnbm9uZScpO1xuICB9XG4gIHJldHVybiBpc1dlYktpdFZhbHVlO1xufVxuZnVuY3Rpb24gaXNMYXN0VHJhdmVyc2FibGVOb2RlKG5vZGUpIHtcbiAgcmV0dXJuIC9eKGh0bWx8Ym9keXwjZG9jdW1lbnQpJC8udGVzdChnZXROb2RlTmFtZShub2RlKSk7XG59XG5mdW5jdGlvbiBnZXRDb21wdXRlZFN0eWxlKGVsZW1lbnQpIHtcbiAgcmV0dXJuIGdldFdpbmRvdyhlbGVtZW50KS5nZXRDb21wdXRlZFN0eWxlKGVsZW1lbnQpO1xufVxuZnVuY3Rpb24gZ2V0Tm9kZVNjcm9sbChlbGVtZW50KSB7XG4gIGlmIChpc0VsZW1lbnQoZWxlbWVudCkpIHtcbiAgICByZXR1cm4ge1xuICAgICAgc2Nyb2xsTGVmdDogZWxlbWVudC5zY3JvbGxMZWZ0LFxuICAgICAgc2Nyb2xsVG9wOiBlbGVtZW50LnNjcm9sbFRvcFxuICAgIH07XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBzY3JvbGxMZWZ0OiBlbGVtZW50LnNjcm9sbFgsXG4gICAgc2Nyb2xsVG9wOiBlbGVtZW50LnNjcm9sbFlcbiAgfTtcbn1cbmZ1bmN0aW9uIGdldFBhcmVudE5vZGUobm9kZSkge1xuICBpZiAoZ2V0Tm9kZU5hbWUobm9kZSkgPT09ICdodG1sJykge1xuICAgIHJldHVybiBub2RlO1xuICB9XG4gIGNvbnN0IHJlc3VsdCA9XG4gIC8vIFN0ZXAgaW50byB0aGUgc2hhZG93IERPTSBvZiB0aGUgcGFyZW50IG9mIGEgc2xvdHRlZCBub2RlLlxuICBub2RlLmFzc2lnbmVkU2xvdCB8fFxuICAvLyBET00gRWxlbWVudCBkZXRlY3RlZC5cbiAgbm9kZS5wYXJlbnROb2RlIHx8XG4gIC8vIFNoYWRvd1Jvb3QgZGV0ZWN0ZWQuXG4gIGlzU2hhZG93Um9vdChub2RlKSAmJiBub2RlLmhvc3QgfHxcbiAgLy8gRmFsbGJhY2suXG4gIGdldERvY3VtZW50RWxlbWVudChub2RlKTtcbiAgcmV0dXJuIGlzU2hhZG93Um9vdChyZXN1bHQpID8gcmVzdWx0Lmhvc3QgOiByZXN1bHQ7XG59XG5mdW5jdGlvbiBnZXROZWFyZXN0T3ZlcmZsb3dBbmNlc3Rvcihub2RlKSB7XG4gIGNvbnN0IHBhcmVudE5vZGUgPSBnZXRQYXJlbnROb2RlKG5vZGUpO1xuICBpZiAoaXNMYXN0VHJhdmVyc2FibGVOb2RlKHBhcmVudE5vZGUpKSB7XG4gICAgcmV0dXJuIChub2RlLm93bmVyRG9jdW1lbnQgfHwgbm9kZSkuYm9keTtcbiAgfVxuICBpZiAoaXNIVE1MRWxlbWVudChwYXJlbnROb2RlKSAmJiBpc092ZXJmbG93RWxlbWVudChwYXJlbnROb2RlKSkge1xuICAgIHJldHVybiBwYXJlbnROb2RlO1xuICB9XG4gIHJldHVybiBnZXROZWFyZXN0T3ZlcmZsb3dBbmNlc3RvcihwYXJlbnROb2RlKTtcbn1cbmZ1bmN0aW9uIGdldE92ZXJmbG93QW5jZXN0b3JzKG5vZGUsIGxpc3QsIHRyYXZlcnNlSWZyYW1lcykge1xuICB2YXIgX25vZGUkb3duZXJEb2N1bWVudDI7XG4gIGlmIChsaXN0ID09PSB2b2lkIDApIHtcbiAgICBsaXN0ID0gW107XG4gIH1cbiAgaWYgKHRyYXZlcnNlSWZyYW1lcyA9PT0gdm9pZCAwKSB7XG4gICAgdHJhdmVyc2VJZnJhbWVzID0gdHJ1ZTtcbiAgfVxuICBjb25zdCBzY3JvbGxhYmxlQW5jZXN0b3IgPSBnZXROZWFyZXN0T3ZlcmZsb3dBbmNlc3Rvcihub2RlKTtcbiAgY29uc3QgaXNCb2R5ID0gc2Nyb2xsYWJsZUFuY2VzdG9yID09PSAoKF9ub2RlJG93bmVyRG9jdW1lbnQyID0gbm9kZS5vd25lckRvY3VtZW50KSA9PSBudWxsID8gdm9pZCAwIDogX25vZGUkb3duZXJEb2N1bWVudDIuYm9keSk7XG4gIGNvbnN0IHdpbiA9IGdldFdpbmRvdyhzY3JvbGxhYmxlQW5jZXN0b3IpO1xuICBpZiAoaXNCb2R5KSB7XG4gICAgY29uc3QgZnJhbWVFbGVtZW50ID0gZ2V0RnJhbWVFbGVtZW50KHdpbik7XG4gICAgcmV0dXJuIGxpc3QuY29uY2F0KHdpbiwgd2luLnZpc3VhbFZpZXdwb3J0IHx8IFtdLCBpc092ZXJmbG93RWxlbWVudChzY3JvbGxhYmxlQW5jZXN0b3IpID8gc2Nyb2xsYWJsZUFuY2VzdG9yIDogW10sIGZyYW1lRWxlbWVudCAmJiB0cmF2ZXJzZUlmcmFtZXMgPyBnZXRPdmVyZmxvd0FuY2VzdG9ycyhmcmFtZUVsZW1lbnQpIDogW10pO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiBsaXN0LmNvbmNhdChzY3JvbGxhYmxlQW5jZXN0b3IsIGdldE92ZXJmbG93QW5jZXN0b3JzKHNjcm9sbGFibGVBbmNlc3RvciwgW10sIHRyYXZlcnNlSWZyYW1lcykpO1xuICB9XG59XG5mdW5jdGlvbiBnZXRGcmFtZUVsZW1lbnQod2luKSB7XG4gIHJldHVybiB3aW4ucGFyZW50ICYmIE9iamVjdC5nZXRQcm90b3R5cGVPZih3aW4ucGFyZW50KSA/IHdpbi5mcmFtZUVsZW1lbnQgOiBudWxsO1xufVxuXG5leHBvcnQgeyBnZXRDb21wdXRlZFN0eWxlLCBnZXRDb250YWluaW5nQmxvY2ssIGdldERvY3VtZW50RWxlbWVudCwgZ2V0RnJhbWVFbGVtZW50LCBnZXROZWFyZXN0T3ZlcmZsb3dBbmNlc3RvciwgZ2V0Tm9kZU5hbWUsIGdldE5vZGVTY3JvbGwsIGdldE92ZXJmbG93QW5jZXN0b3JzLCBnZXRQYXJlbnROb2RlLCBnZXRXaW5kb3csIGlzQ29udGFpbmluZ0Jsb2NrLCBpc0VsZW1lbnQsIGlzSFRNTEVsZW1lbnQsIGlzTGFzdFRyYXZlcnNhYmxlTm9kZSwgaXNOb2RlLCBpc092ZXJmbG93RWxlbWVudCwgaXNTaGFkb3dSb290LCBpc1RhYmxlRWxlbWVudCwgaXNUb3BMYXllciwgaXNXZWJLaXQgfTtcbiIsImltcG9ydCB7IHJlY3RUb0NsaWVudFJlY3QsIGFycm93IGFzIGFycm93JDEsIGF1dG9QbGFjZW1lbnQgYXMgYXV0b1BsYWNlbWVudCQxLCBkZXRlY3RPdmVyZmxvdyBhcyBkZXRlY3RPdmVyZmxvdyQxLCBmbGlwIGFzIGZsaXAkMSwgaGlkZSBhcyBoaWRlJDEsIGlubGluZSBhcyBpbmxpbmUkMSwgbGltaXRTaGlmdCBhcyBsaW1pdFNoaWZ0JDEsIG9mZnNldCBhcyBvZmZzZXQkMSwgc2hpZnQgYXMgc2hpZnQkMSwgc2l6ZSBhcyBzaXplJDEsIGNvbXB1dGVQb3NpdGlvbiBhcyBjb21wdXRlUG9zaXRpb24kMSB9IGZyb20gJ0BmbG9hdGluZy11aS9jb3JlJztcbmltcG9ydCB7IHJvdW5kLCBjcmVhdGVDb29yZHMsIG1heCwgbWluLCBmbG9vciB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscyc7XG5pbXBvcnQgeyBnZXRDb21wdXRlZFN0eWxlIGFzIGdldENvbXB1dGVkU3R5bGUkMSwgaXNIVE1MRWxlbWVudCwgaXNFbGVtZW50LCBnZXRXaW5kb3csIGlzV2ViS2l0LCBnZXRGcmFtZUVsZW1lbnQsIGdldE5vZGVTY3JvbGwsIGdldERvY3VtZW50RWxlbWVudCwgaXNUb3BMYXllciwgZ2V0Tm9kZU5hbWUsIGlzT3ZlcmZsb3dFbGVtZW50LCBnZXRPdmVyZmxvd0FuY2VzdG9ycywgZ2V0UGFyZW50Tm9kZSwgaXNMYXN0VHJhdmVyc2FibGVOb2RlLCBpc0NvbnRhaW5pbmdCbG9jaywgaXNUYWJsZUVsZW1lbnQsIGdldENvbnRhaW5pbmdCbG9jayB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuZXhwb3J0IHsgZ2V0T3ZlcmZsb3dBbmNlc3RvcnMgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcblxuZnVuY3Rpb24gZ2V0Q3NzRGltZW5zaW9ucyhlbGVtZW50KSB7XG4gIGNvbnN0IGNzcyA9IGdldENvbXB1dGVkU3R5bGUkMShlbGVtZW50KTtcbiAgLy8gSW4gdGVzdGluZyBlbnZpcm9ubWVudHMsIHRoZSBgd2lkdGhgIGFuZCBgaGVpZ2h0YCBwcm9wZXJ0aWVzIGFyZSBlbXB0eVxuICAvLyBzdHJpbmdzIGZvciBTVkcgZWxlbWVudHMsIHJldHVybmluZyBOYU4uIEZhbGxiYWNrIHRvIGAwYCBpbiB0aGlzIGNhc2UuXG4gIGxldCB3aWR0aCA9IHBhcnNlRmxvYXQoY3NzLndpZHRoKSB8fCAwO1xuICBsZXQgaGVpZ2h0ID0gcGFyc2VGbG9hdChjc3MuaGVpZ2h0KSB8fCAwO1xuICBjb25zdCBoYXNPZmZzZXQgPSBpc0hUTUxFbGVtZW50KGVsZW1lbnQpO1xuICBjb25zdCBvZmZzZXRXaWR0aCA9IGhhc09mZnNldCA/IGVsZW1lbnQub2Zmc2V0V2lkdGggOiB3aWR0aDtcbiAgY29uc3Qgb2Zmc2V0SGVpZ2h0ID0gaGFzT2Zmc2V0ID8gZWxlbWVudC5vZmZzZXRIZWlnaHQgOiBoZWlnaHQ7XG4gIGNvbnN0IHNob3VsZEZhbGxiYWNrID0gcm91bmQod2lkdGgpICE9PSBvZmZzZXRXaWR0aCB8fCByb3VuZChoZWlnaHQpICE9PSBvZmZzZXRIZWlnaHQ7XG4gIGlmIChzaG91bGRGYWxsYmFjaykge1xuICAgIHdpZHRoID0gb2Zmc2V0V2lkdGg7XG4gICAgaGVpZ2h0ID0gb2Zmc2V0SGVpZ2h0O1xuICB9XG4gIHJldHVybiB7XG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0LFxuICAgICQ6IHNob3VsZEZhbGxiYWNrXG4gIH07XG59XG5cbmZ1bmN0aW9uIHVud3JhcEVsZW1lbnQoZWxlbWVudCkge1xuICByZXR1cm4gIWlzRWxlbWVudChlbGVtZW50KSA/IGVsZW1lbnQuY29udGV4dEVsZW1lbnQgOiBlbGVtZW50O1xufVxuXG5mdW5jdGlvbiBnZXRTY2FsZShlbGVtZW50KSB7XG4gIGNvbnN0IGRvbUVsZW1lbnQgPSB1bndyYXBFbGVtZW50KGVsZW1lbnQpO1xuICBpZiAoIWlzSFRNTEVsZW1lbnQoZG9tRWxlbWVudCkpIHtcbiAgICByZXR1cm4gY3JlYXRlQ29vcmRzKDEpO1xuICB9XG4gIGNvbnN0IHJlY3QgPSBkb21FbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICBjb25zdCB7XG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0LFxuICAgICRcbiAgfSA9IGdldENzc0RpbWVuc2lvbnMoZG9tRWxlbWVudCk7XG4gIGxldCB4ID0gKCQgPyByb3VuZChyZWN0LndpZHRoKSA6IHJlY3Qud2lkdGgpIC8gd2lkdGg7XG4gIGxldCB5ID0gKCQgPyByb3VuZChyZWN0LmhlaWdodCkgOiByZWN0LmhlaWdodCkgLyBoZWlnaHQ7XG5cbiAgLy8gMCwgTmFOLCBvciBJbmZpbml0eSBzaG91bGQgYWx3YXlzIGZhbGxiYWNrIHRvIDEuXG5cbiAgaWYgKCF4IHx8ICFOdW1iZXIuaXNGaW5pdGUoeCkpIHtcbiAgICB4ID0gMTtcbiAgfVxuICBpZiAoIXkgfHwgIU51bWJlci5pc0Zpbml0ZSh5KSkge1xuICAgIHkgPSAxO1xuICB9XG4gIHJldHVybiB7XG4gICAgeCxcbiAgICB5XG4gIH07XG59XG5cbmNvbnN0IG5vT2Zmc2V0cyA9IC8qI19fUFVSRV9fKi9jcmVhdGVDb29yZHMoMCk7XG5mdW5jdGlvbiBnZXRWaXN1YWxPZmZzZXRzKGVsZW1lbnQpIHtcbiAgY29uc3Qgd2luID0gZ2V0V2luZG93KGVsZW1lbnQpO1xuICBpZiAoIWlzV2ViS2l0KCkgfHwgIXdpbi52aXN1YWxWaWV3cG9ydCkge1xuICAgIHJldHVybiBub09mZnNldHM7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB4OiB3aW4udmlzdWFsVmlld3BvcnQub2Zmc2V0TGVmdCxcbiAgICB5OiB3aW4udmlzdWFsVmlld3BvcnQub2Zmc2V0VG9wXG4gIH07XG59XG5mdW5jdGlvbiBzaG91bGRBZGRWaXN1YWxPZmZzZXRzKGVsZW1lbnQsIGlzRml4ZWQsIGZsb2F0aW5nT2Zmc2V0UGFyZW50KSB7XG4gIGlmIChpc0ZpeGVkID09PSB2b2lkIDApIHtcbiAgICBpc0ZpeGVkID0gZmFsc2U7XG4gIH1cbiAgcmV0dXJuICEhZmxvYXRpbmdPZmZzZXRQYXJlbnQgJiYgaXNGaXhlZCAmJiBmbG9hdGluZ09mZnNldFBhcmVudCA9PT0gZ2V0V2luZG93KGVsZW1lbnQpO1xufVxuXG5mdW5jdGlvbiBnZXRCb3VuZGluZ0NsaWVudFJlY3QoZWxlbWVudCwgaW5jbHVkZVNjYWxlLCBpc0ZpeGVkU3RyYXRlZ3ksIG9mZnNldFBhcmVudCkge1xuICBpZiAoaW5jbHVkZVNjYWxlID09PSB2b2lkIDApIHtcbiAgICBpbmNsdWRlU2NhbGUgPSBmYWxzZTtcbiAgfVxuICBpZiAoaXNGaXhlZFN0cmF0ZWd5ID09PSB2b2lkIDApIHtcbiAgICBpc0ZpeGVkU3RyYXRlZ3kgPSBmYWxzZTtcbiAgfVxuICBjb25zdCBjbGllbnRSZWN0ID0gZWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgY29uc3QgZG9tRWxlbWVudCA9IHVud3JhcEVsZW1lbnQoZWxlbWVudCk7XG4gIGxldCBzY2FsZSA9IGNyZWF0ZUNvb3JkcygxKTtcbiAgaWYgKGluY2x1ZGVTY2FsZSkge1xuICAgIGlmIChvZmZzZXRQYXJlbnQpIHtcbiAgICAgIGlmIChpc0VsZW1lbnQob2Zmc2V0UGFyZW50KSkge1xuICAgICAgICBzY2FsZSA9IGdldFNjYWxlKG9mZnNldFBhcmVudCk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHNjYWxlID0gZ2V0U2NhbGUoZWxlbWVudCk7XG4gICAgfVxuICB9XG4gIGNvbnN0IHZpc3VhbE9mZnNldHMgPSBzaG91bGRBZGRWaXN1YWxPZmZzZXRzKGRvbUVsZW1lbnQsIGlzRml4ZWRTdHJhdGVneSwgb2Zmc2V0UGFyZW50KSA/IGdldFZpc3VhbE9mZnNldHMoZG9tRWxlbWVudCkgOiBjcmVhdGVDb29yZHMoMCk7XG4gIGxldCB4ID0gKGNsaWVudFJlY3QubGVmdCArIHZpc3VhbE9mZnNldHMueCkgLyBzY2FsZS54O1xuICBsZXQgeSA9IChjbGllbnRSZWN0LnRvcCArIHZpc3VhbE9mZnNldHMueSkgLyBzY2FsZS55O1xuICBsZXQgd2lkdGggPSBjbGllbnRSZWN0LndpZHRoIC8gc2NhbGUueDtcbiAgbGV0IGhlaWdodCA9IGNsaWVudFJlY3QuaGVpZ2h0IC8gc2NhbGUueTtcbiAgaWYgKGRvbUVsZW1lbnQgJiYgb2Zmc2V0UGFyZW50KSB7XG4gICAgY29uc3Qgd2luID0gZ2V0V2luZG93KGRvbUVsZW1lbnQpO1xuICAgIGNvbnN0IG9mZnNldFdpbiA9IGlzRWxlbWVudChvZmZzZXRQYXJlbnQpID8gZ2V0V2luZG93KG9mZnNldFBhcmVudCkgOiBvZmZzZXRQYXJlbnQ7XG4gICAgbGV0IGN1cnJlbnRXaW4gPSB3aW47XG4gICAgbGV0IGN1cnJlbnRJRnJhbWUgPSBnZXRGcmFtZUVsZW1lbnQoY3VycmVudFdpbik7XG4gICAgd2hpbGUgKGN1cnJlbnRJRnJhbWUgJiYgb2Zmc2V0V2luICE9PSBjdXJyZW50V2luKSB7XG4gICAgICBjb25zdCBpZnJhbWVTY2FsZSA9IGdldFNjYWxlKGN1cnJlbnRJRnJhbWUpO1xuICAgICAgY29uc3QgaWZyYW1lUmVjdCA9IGN1cnJlbnRJRnJhbWUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICBjb25zdCBjc3MgPSBnZXRDb21wdXRlZFN0eWxlJDEoY3VycmVudElGcmFtZSk7XG4gICAgICBjb25zdCBsZWZ0ID0gaWZyYW1lUmVjdC5sZWZ0ICsgKGN1cnJlbnRJRnJhbWUuY2xpZW50TGVmdCArIHBhcnNlRmxvYXQoY3NzLnBhZGRpbmdMZWZ0KSkgKiBpZnJhbWVTY2FsZS54O1xuICAgICAgY29uc3QgdG9wID0gaWZyYW1lUmVjdC50b3AgKyAoY3VycmVudElGcmFtZS5jbGllbnRUb3AgKyBwYXJzZUZsb2F0KGNzcy5wYWRkaW5nVG9wKSkgKiBpZnJhbWVTY2FsZS55O1xuICAgICAgeCAqPSBpZnJhbWVTY2FsZS54O1xuICAgICAgeSAqPSBpZnJhbWVTY2FsZS55O1xuICAgICAgd2lkdGggKj0gaWZyYW1lU2NhbGUueDtcbiAgICAgIGhlaWdodCAqPSBpZnJhbWVTY2FsZS55O1xuICAgICAgeCArPSBsZWZ0O1xuICAgICAgeSArPSB0b3A7XG4gICAgICBjdXJyZW50V2luID0gZ2V0V2luZG93KGN1cnJlbnRJRnJhbWUpO1xuICAgICAgY3VycmVudElGcmFtZSA9IGdldEZyYW1lRWxlbWVudChjdXJyZW50V2luKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlY3RUb0NsaWVudFJlY3Qoe1xuICAgIHdpZHRoLFxuICAgIGhlaWdodCxcbiAgICB4LFxuICAgIHlcbiAgfSk7XG59XG5cbi8vIElmIDxodG1sPiBoYXMgYSBDU1Mgd2lkdGggZ3JlYXRlciB0aGFuIHRoZSB2aWV3cG9ydCwgdGhlbiB0aGlzIHdpbGwgYmVcbi8vIGluY29ycmVjdCBmb3IgUlRMLlxuZnVuY3Rpb24gZ2V0V2luZG93U2Nyb2xsQmFyWChlbGVtZW50LCByZWN0KSB7XG4gIGNvbnN0IGxlZnRTY3JvbGwgPSBnZXROb2RlU2Nyb2xsKGVsZW1lbnQpLnNjcm9sbExlZnQ7XG4gIGlmICghcmVjdCkge1xuICAgIHJldHVybiBnZXRCb3VuZGluZ0NsaWVudFJlY3QoZ2V0RG9jdW1lbnRFbGVtZW50KGVsZW1lbnQpKS5sZWZ0ICsgbGVmdFNjcm9sbDtcbiAgfVxuICByZXR1cm4gcmVjdC5sZWZ0ICsgbGVmdFNjcm9sbDtcbn1cblxuZnVuY3Rpb24gZ2V0SFRNTE9mZnNldChkb2N1bWVudEVsZW1lbnQsIHNjcm9sbCkge1xuICBjb25zdCBodG1sUmVjdCA9IGRvY3VtZW50RWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgY29uc3QgeCA9IGh0bWxSZWN0LmxlZnQgKyBzY3JvbGwuc2Nyb2xsTGVmdCAtIGdldFdpbmRvd1Njcm9sbEJhclgoZG9jdW1lbnRFbGVtZW50LCBodG1sUmVjdCk7XG4gIGNvbnN0IHkgPSBodG1sUmVjdC50b3AgKyBzY3JvbGwuc2Nyb2xsVG9wO1xuICByZXR1cm4ge1xuICAgIHgsXG4gICAgeVxuICB9O1xufVxuXG5mdW5jdGlvbiBjb252ZXJ0T2Zmc2V0UGFyZW50UmVsYXRpdmVSZWN0VG9WaWV3cG9ydFJlbGF0aXZlUmVjdChfcmVmKSB7XG4gIGxldCB7XG4gICAgZWxlbWVudHMsXG4gICAgcmVjdCxcbiAgICBvZmZzZXRQYXJlbnQsXG4gICAgc3RyYXRlZ3lcbiAgfSA9IF9yZWY7XG4gIGNvbnN0IGlzRml4ZWQgPSBzdHJhdGVneSA9PT0gJ2ZpeGVkJztcbiAgY29uc3QgZG9jdW1lbnRFbGVtZW50ID0gZ2V0RG9jdW1lbnRFbGVtZW50KG9mZnNldFBhcmVudCk7XG4gIGNvbnN0IHRvcExheWVyID0gZWxlbWVudHMgPyBpc1RvcExheWVyKGVsZW1lbnRzLmZsb2F0aW5nKSA6IGZhbHNlO1xuICBpZiAob2Zmc2V0UGFyZW50ID09PSBkb2N1bWVudEVsZW1lbnQgfHwgdG9wTGF5ZXIgJiYgaXNGaXhlZCkge1xuICAgIHJldHVybiByZWN0O1xuICB9XG4gIGxldCBzY3JvbGwgPSB7XG4gICAgc2Nyb2xsTGVmdDogMCxcbiAgICBzY3JvbGxUb3A6IDBcbiAgfTtcbiAgbGV0IHNjYWxlID0gY3JlYXRlQ29vcmRzKDEpO1xuICBjb25zdCBvZmZzZXRzID0gY3JlYXRlQ29vcmRzKDApO1xuICBjb25zdCBpc09mZnNldFBhcmVudEFuRWxlbWVudCA9IGlzSFRNTEVsZW1lbnQob2Zmc2V0UGFyZW50KTtcbiAgaWYgKGlzT2Zmc2V0UGFyZW50QW5FbGVtZW50IHx8ICFpc0ZpeGVkKSB7XG4gICAgaWYgKGdldE5vZGVOYW1lKG9mZnNldFBhcmVudCkgIT09ICdib2R5JyB8fCBpc092ZXJmbG93RWxlbWVudChkb2N1bWVudEVsZW1lbnQpKSB7XG4gICAgICBzY3JvbGwgPSBnZXROb2RlU2Nyb2xsKG9mZnNldFBhcmVudCk7XG4gICAgfVxuICAgIGlmIChpc09mZnNldFBhcmVudEFuRWxlbWVudCkge1xuICAgICAgY29uc3Qgb2Zmc2V0UmVjdCA9IGdldEJvdW5kaW5nQ2xpZW50UmVjdChvZmZzZXRQYXJlbnQpO1xuICAgICAgc2NhbGUgPSBnZXRTY2FsZShvZmZzZXRQYXJlbnQpO1xuICAgICAgb2Zmc2V0cy54ID0gb2Zmc2V0UmVjdC54ICsgb2Zmc2V0UGFyZW50LmNsaWVudExlZnQ7XG4gICAgICBvZmZzZXRzLnkgPSBvZmZzZXRSZWN0LnkgKyBvZmZzZXRQYXJlbnQuY2xpZW50VG9wO1xuICAgIH1cbiAgfVxuICBjb25zdCBodG1sT2Zmc2V0ID0gZG9jdW1lbnRFbGVtZW50ICYmICFpc09mZnNldFBhcmVudEFuRWxlbWVudCAmJiAhaXNGaXhlZCA/IGdldEhUTUxPZmZzZXQoZG9jdW1lbnRFbGVtZW50LCBzY3JvbGwpIDogY3JlYXRlQ29vcmRzKDApO1xuICByZXR1cm4ge1xuICAgIHdpZHRoOiByZWN0LndpZHRoICogc2NhbGUueCxcbiAgICBoZWlnaHQ6IHJlY3QuaGVpZ2h0ICogc2NhbGUueSxcbiAgICB4OiByZWN0LnggKiBzY2FsZS54IC0gc2Nyb2xsLnNjcm9sbExlZnQgKiBzY2FsZS54ICsgb2Zmc2V0cy54ICsgaHRtbE9mZnNldC54LFxuICAgIHk6IHJlY3QueSAqIHNjYWxlLnkgLSBzY3JvbGwuc2Nyb2xsVG9wICogc2NhbGUueSArIG9mZnNldHMueSArIGh0bWxPZmZzZXQueVxuICB9O1xufVxuXG5mdW5jdGlvbiBnZXRDbGllbnRSZWN0cyhlbGVtZW50KSB7XG4gIHJldHVybiBlbGVtZW50LmdldENsaWVudFJlY3RzID8gQXJyYXkuZnJvbShlbGVtZW50LmdldENsaWVudFJlY3RzKCkpIDogW107XG59XG5cbi8vIEdldHMgdGhlIGVudGlyZSBzaXplIG9mIHRoZSBzY3JvbGxhYmxlIGRvY3VtZW50IGFyZWEsIGV2ZW4gZXh0ZW5kaW5nIG91dHNpZGVcbi8vIG9mIHRoZSBgPGh0bWw+YCBhbmQgYDxib2R5PmAgcmVjdCBib3VuZHMgaWYgaG9yaXpvbnRhbGx5IHNjcm9sbGFibGUuXG5mdW5jdGlvbiBnZXREb2N1bWVudFJlY3QoaHRtbCkge1xuICBjb25zdCBzY3JvbGwgPSBnZXROb2RlU2Nyb2xsKGh0bWwpO1xuICBjb25zdCBib2R5ID0gaHRtbC5vd25lckRvY3VtZW50LmJvZHk7XG4gIGNvbnN0IHdpZHRoID0gbWF4KGh0bWwuc2Nyb2xsV2lkdGgsIGh0bWwuY2xpZW50V2lkdGgsIGJvZHkuc2Nyb2xsV2lkdGgsIGJvZHkuY2xpZW50V2lkdGgpO1xuICBjb25zdCBoZWlnaHQgPSBtYXgoaHRtbC5zY3JvbGxIZWlnaHQsIGh0bWwuY2xpZW50SGVpZ2h0LCBib2R5LnNjcm9sbEhlaWdodCwgYm9keS5jbGllbnRIZWlnaHQpO1xuICBsZXQgeCA9IC1zY3JvbGwuc2Nyb2xsTGVmdCArIGdldFdpbmRvd1Njcm9sbEJhclgoaHRtbCk7XG4gIGNvbnN0IHkgPSAtc2Nyb2xsLnNjcm9sbFRvcDtcbiAgaWYgKGdldENvbXB1dGVkU3R5bGUkMShib2R5KS5kaXJlY3Rpb24gPT09ICdydGwnKSB7XG4gICAgeCArPSBtYXgoaHRtbC5jbGllbnRXaWR0aCwgYm9keS5jbGllbnRXaWR0aCkgLSB3aWR0aDtcbiAgfVxuICByZXR1cm4ge1xuICAgIHdpZHRoLFxuICAgIGhlaWdodCxcbiAgICB4LFxuICAgIHlcbiAgfTtcbn1cblxuLy8gU2FmZXR5IGNoZWNrOiBlbnN1cmUgdGhlIHNjcm9sbGJhciBzcGFjZSBpcyByZWFzb25hYmxlIGluIGNhc2UgdGhpc1xuLy8gY2FsY3VsYXRpb24gaXMgYWZmZWN0ZWQgYnkgdW51c3VhbCBzdHlsZXMuXG4vLyBNb3N0IHNjcm9sbGJhcnMgbGVhdmUgMTUtMThweCBvZiBzcGFjZS5cbmNvbnN0IFNDUk9MTEJBUl9NQVggPSAyNTtcbmZ1bmN0aW9uIGdldFZpZXdwb3J0UmVjdChlbGVtZW50LCBzdHJhdGVneSwgcm9vdEJvdW5kYXJ5KSB7XG4gIGlmIChyb290Qm91bmRhcnkgPT09IHZvaWQgMCkge1xuICAgIHJvb3RCb3VuZGFyeSA9ICd2aWV3cG9ydCc7XG4gIH1cbiAgY29uc3QgaXNMYXlvdXRWaWV3cG9ydCA9IHJvb3RCb3VuZGFyeSA9PT0gJ2xheW91dFZpZXdwb3J0JztcbiAgY29uc3Qgd2luID0gZ2V0V2luZG93KGVsZW1lbnQpO1xuICBjb25zdCBodG1sID0gZ2V0RG9jdW1lbnRFbGVtZW50KGVsZW1lbnQpO1xuICBjb25zdCB2aXN1YWxWaWV3cG9ydCA9IHdpbi52aXN1YWxWaWV3cG9ydDtcbiAgbGV0IHdpZHRoID0gaHRtbC5jbGllbnRXaWR0aDtcbiAgbGV0IGhlaWdodCA9IGh0bWwuY2xpZW50SGVpZ2h0O1xuICBsZXQgeCA9IDA7XG4gIGxldCB5ID0gMDtcbiAgaWYgKHZpc3VhbFZpZXdwb3J0KSB7XG4gICAgLy8gQ2xpZW50IGNvb3JkaW5hdGVzIGFyZSByZWxhdGl2ZSB0byB0aGUgbGF5b3V0IHZpZXdwb3J0LCBleGNlcHQgaW5cbiAgICAvLyBXZWJLaXQgd2l0aCBhbiBgYWJzb2x1dGVgIHN0cmF0ZWd5LCB3aGVyZSB0aGV5IGFyZSByZWxhdGl2ZSB0byB0aGVcbiAgICAvLyB2aXN1YWwgdmlld3BvcnQuXG4gICAgY29uc3QgbGF5b3V0UmVsYXRpdmVDbGllbnRDb29yZHMgPSAhaXNXZWJLaXQoKSB8fCBzdHJhdGVneSA9PT0gJ2ZpeGVkJztcbiAgICBpZiAoaXNMYXlvdXRWaWV3cG9ydCkge1xuICAgICAgaWYgKCFsYXlvdXRSZWxhdGl2ZUNsaWVudENvb3Jkcykge1xuICAgICAgICB4ID0gLXZpc3VhbFZpZXdwb3J0Lm9mZnNldExlZnQ7XG4gICAgICAgIHkgPSAtdmlzdWFsVmlld3BvcnQub2Zmc2V0VG9wO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB3aWR0aCA9IHZpc3VhbFZpZXdwb3J0LndpZHRoO1xuICAgICAgaGVpZ2h0ID0gdmlzdWFsVmlld3BvcnQuaGVpZ2h0O1xuICAgICAgaWYgKGxheW91dFJlbGF0aXZlQ2xpZW50Q29vcmRzKSB7XG4gICAgICAgIHggPSB2aXN1YWxWaWV3cG9ydC5vZmZzZXRMZWZ0O1xuICAgICAgICB5ID0gdmlzdWFsVmlld3BvcnQub2Zmc2V0VG9wO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBjb25zdCB3aW5kb3dTY3JvbGxiYXJYID0gZ2V0V2luZG93U2Nyb2xsQmFyWChodG1sKTtcbiAgLy8gYHNjcm9sbGJhci1ndXR0ZXI6IHN0YWJsZWAgb24gdGhlIDxodG1sPiByZXNlcnZlcyBndXR0ZXIgc3BhY2UgdGhhdCBzaHJpbmtzXG4gIC8vIHRoZSB2aXN1YWwgd2lkdGggYnV0IGlzbid0IHJlZmxlY3RlZCBpbiBgaHRtbC5jbGllbnRXaWR0aGAsIHNvIHN1YnRyYWN0IGl0LlxuICAvLyBPbmx5IHRoZSBpbmxpbmUtZW5kIChyaWdodCkgZ3V0dGVyIGNhbiBob2xkIHRoZSBzY3JvbGxiYXI7IGBib3RoLWVkZ2VzYCBhbHNvXG4gIC8vIHJlc2VydmVzIGFuIGVtcHR5IGlubGluZS1zdGFydCBndXR0ZXIgdGhhdCBjbGlwcyBub3RoaW5nLCBzbyBleGNsdWRlIGp1c3RcbiAgLy8gdGhlIG9uZSBzY3JvbGxiYXItc2lkZSBndXR0ZXIg4oCUIGhhbHZlIHRoZSBtZWFzdXJlZCAodHdvLWd1dHRlcikgdG90YWwuIEFcbiAgLy8gbGVmdC1zaWRlIHNjcm9sbGJhciAoYHdpbmRvd1Njcm9sbGJhclggPiAwYCkgaXMgYWxyZWFkeSBoYW5kbGVkIGJ5XG4gIC8vIGBnZXRIVE1MT2Zmc2V0YC9gdmlzdWFsVmlld3BvcnQud2lkdGhgOyBza2lwIGl0IGhlcmUuXG4gIGlmICh3aW5kb3dTY3JvbGxiYXJYIDw9IDApIHtcbiAgICBjb25zdCBkb2MgPSBodG1sLm93bmVyRG9jdW1lbnQ7XG4gICAgY29uc3QgYm9keSA9IGRvYy5ib2R5O1xuICAgIGNvbnN0IGJvZHlTdHlsZXMgPSBnZXRDb21wdXRlZFN0eWxlKGJvZHkpO1xuICAgIGNvbnN0IGJvZHlNYXJnaW5JbmxpbmUgPSBkb2MuY29tcGF0TW9kZSA9PT0gJ0NTUzFDb21wYXQnID8gcGFyc2VGbG9hdChib2R5U3R5bGVzLm1hcmdpbkxlZnQpICsgcGFyc2VGbG9hdChib2R5U3R5bGVzLm1hcmdpblJpZ2h0KSB8fCAwIDogMDtcbiAgICBjb25zdCByZXNlcnZlZFdpZHRoID0gTWF0aC5hYnMoaHRtbC5jbGllbnRXaWR0aCAtIGJvZHkuY2xpZW50V2lkdGggLSBib2R5TWFyZ2luSW5saW5lKTtcbiAgICBjb25zdCBndXR0ZXIgPSBnZXRDb21wdXRlZFN0eWxlKGh0bWwpLnNjcm9sbGJhckd1dHRlciA9PT0gJ3N0YWJsZSBib3RoLWVkZ2VzJyA/IHJlc2VydmVkV2lkdGggLyAyIDogcmVzZXJ2ZWRXaWR0aDtcbiAgICBpZiAoZ3V0dGVyIDw9IFNDUk9MTEJBUl9NQVgpIHtcbiAgICAgIHdpZHRoIC09IGd1dHRlcjtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB3aWR0aCxcbiAgICBoZWlnaHQsXG4gICAgeCxcbiAgICB5XG4gIH07XG59XG5cbi8vIFJldHVybnMgdGhlIGlubmVyIGNsaWVudCByZWN0LCBzdWJ0cmFjdGluZyBzY3JvbGxiYXJzIGlmIHByZXNlbnQuXG5mdW5jdGlvbiBnZXRJbm5lckJvdW5kaW5nQ2xpZW50UmVjdChlbGVtZW50LCBzdHJhdGVneSkge1xuICBjb25zdCBjbGllbnRSZWN0ID0gZ2V0Qm91bmRpbmdDbGllbnRSZWN0KGVsZW1lbnQsIHRydWUsIHN0cmF0ZWd5ID09PSAnZml4ZWQnKTtcbiAgY29uc3QgdG9wID0gY2xpZW50UmVjdC50b3AgKyBlbGVtZW50LmNsaWVudFRvcDtcbiAgY29uc3QgbGVmdCA9IGNsaWVudFJlY3QubGVmdCArIGVsZW1lbnQuY2xpZW50TGVmdDtcbiAgY29uc3Qgc2NhbGUgPSBnZXRTY2FsZShlbGVtZW50KTtcbiAgY29uc3Qgd2lkdGggPSBlbGVtZW50LmNsaWVudFdpZHRoICogc2NhbGUueDtcbiAgY29uc3QgaGVpZ2h0ID0gZWxlbWVudC5jbGllbnRIZWlnaHQgKiBzY2FsZS55O1xuICBjb25zdCB4ID0gbGVmdCAqIHNjYWxlLng7XG4gIGNvbnN0IHkgPSB0b3AgKiBzY2FsZS55O1xuICByZXR1cm4ge1xuICAgIHdpZHRoLFxuICAgIGhlaWdodCxcbiAgICB4LFxuICAgIHlcbiAgfTtcbn1cbmZ1bmN0aW9uIGdldENsaWVudFJlY3RGcm9tQ2xpcHBpbmdBbmNlc3RvcihlbGVtZW50LCBjbGlwcGluZ0FuY2VzdG9yLCBzdHJhdGVneSkge1xuICBsZXQgcmVjdDtcbiAgaWYgKGNsaXBwaW5nQW5jZXN0b3IgPT09ICd2aWV3cG9ydCcgfHwgY2xpcHBpbmdBbmNlc3RvciA9PT0gJ2xheW91dFZpZXdwb3J0Jykge1xuICAgIHJlY3QgPSBnZXRWaWV3cG9ydFJlY3QoZWxlbWVudCwgc3RyYXRlZ3ksIGNsaXBwaW5nQW5jZXN0b3IpO1xuICB9IGVsc2UgaWYgKGNsaXBwaW5nQW5jZXN0b3IgPT09ICdkb2N1bWVudCcpIHtcbiAgICByZWN0ID0gZ2V0RG9jdW1lbnRSZWN0KGdldERvY3VtZW50RWxlbWVudChlbGVtZW50KSk7XG4gIH0gZWxzZSBpZiAoaXNFbGVtZW50KGNsaXBwaW5nQW5jZXN0b3IpKSB7XG4gICAgcmVjdCA9IGdldElubmVyQm91bmRpbmdDbGllbnRSZWN0KGNsaXBwaW5nQW5jZXN0b3IsIHN0cmF0ZWd5KTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCB2aXN1YWxPZmZzZXRzID0gZ2V0VmlzdWFsT2Zmc2V0cyhlbGVtZW50KTtcbiAgICByZWN0ID0ge1xuICAgICAgeDogY2xpcHBpbmdBbmNlc3Rvci54IC0gdmlzdWFsT2Zmc2V0cy54LFxuICAgICAgeTogY2xpcHBpbmdBbmNlc3Rvci55IC0gdmlzdWFsT2Zmc2V0cy55LFxuICAgICAgd2lkdGg6IGNsaXBwaW5nQW5jZXN0b3Iud2lkdGgsXG4gICAgICBoZWlnaHQ6IGNsaXBwaW5nQW5jZXN0b3IuaGVpZ2h0XG4gICAgfTtcbiAgfVxuICByZXR1cm4gcmVjdFRvQ2xpZW50UmVjdChyZWN0KTtcbn1cblxuLy8gQSBcImNsaXBwaW5nIGFuY2VzdG9yXCIgaXMgYW4gYG92ZXJmbG93YCBlbGVtZW50IHdpdGggdGhlIGNoYXJhY3RlcmlzdGljIG9mXG4vLyBjbGlwcGluZyAob3IgaGlkaW5nKSBjaGlsZCBlbGVtZW50cy4gVGhpcyByZXR1cm5zIGFsbCBjbGlwcGluZyBhbmNlc3RvcnNcbi8vIG9mIHRoZSBnaXZlbiBlbGVtZW50IHVwIHRoZSB0cmVlLlxuZnVuY3Rpb24gZ2V0Q2xpcHBpbmdFbGVtZW50QW5jZXN0b3JzKGVsZW1lbnQsIGNhY2hlKSB7XG4gIGNvbnN0IGNhY2hlZFJlc3VsdCA9IGNhY2hlLmdldChlbGVtZW50KTtcbiAgaWYgKGNhY2hlZFJlc3VsdCkge1xuICAgIHJldHVybiBjYWNoZWRSZXN1bHQ7XG4gIH1cbiAgbGV0IHJlc3VsdCA9IGdldE92ZXJmbG93QW5jZXN0b3JzKGVsZW1lbnQsIFtdLCBmYWxzZSkuZmlsdGVyKGVsID0+IGlzRWxlbWVudChlbCkgJiYgZ2V0Tm9kZU5hbWUoZWwpICE9PSAnYm9keScpO1xuICBsZXQgbGFzdEtlcHRDb21wdXRlZFN0eWxlID0gbnVsbDtcbiAgY29uc3QgZWxlbWVudElzRml4ZWQgPSBnZXRDb21wdXRlZFN0eWxlJDEoZWxlbWVudCkucG9zaXRpb24gPT09ICdmaXhlZCc7XG4gIGxldCBjdXJyZW50Tm9kZSA9IGVsZW1lbnRJc0ZpeGVkID8gZ2V0UGFyZW50Tm9kZShlbGVtZW50KSA6IGVsZW1lbnQ7XG5cbiAgLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQ1NTL0NvbnRhaW5pbmdfYmxvY2sjaWRlbnRpZnlpbmdfdGhlX2NvbnRhaW5pbmdfYmxvY2tcbiAgd2hpbGUgKGlzRWxlbWVudChjdXJyZW50Tm9kZSkgJiYgIWlzTGFzdFRyYXZlcnNhYmxlTm9kZShjdXJyZW50Tm9kZSkpIHtcbiAgICBjb25zdCBjb21wdXRlZFN0eWxlID0gZ2V0Q29tcHV0ZWRTdHlsZSQxKGN1cnJlbnROb2RlKTtcbiAgICBjb25zdCBjdXJyZW50Tm9kZUlzQ29udGFpbmluZyA9IGlzQ29udGFpbmluZ0Jsb2NrKGN1cnJlbnROb2RlKTtcbiAgICAvLyBQb3NpdGlvbiBvZiB0aGUgY29udGFpbmluZyBibG9jayBjaGFpbiBiZWxvdyB0aGUgY3VycmVudCBub2RlLiBBIGZpeGVkXG4gICAgLy8gZWxlbWVudCB3aG9zZSBjb250YWluaW5nIGJsb2NrIGhhc24ndCBiZWVuIGZvdW5kIHlldCBpcyBhIGZpeGVkIGNoYWluLlxuICAgIGNvbnN0IGxhc3RQb3NpdGlvbiA9IGxhc3RLZXB0Q29tcHV0ZWRTdHlsZSA/IGxhc3RLZXB0Q29tcHV0ZWRTdHlsZS5wb3NpdGlvbiA6IGVsZW1lbnRJc0ZpeGVkID8gJ2ZpeGVkJyA6ICcnO1xuXG4gICAgLy8gQSBub24tY29udGFpbmluZyBhbmNlc3RvciBkb2VzIG5vdCBjbGlwIHRoZSBlbGVtZW50IHdoZW4gdGhlIGNoYWluXG4gICAgLy8gYmVsb3cgaXQgZXNjYXBlcyBpdDogYSBmaXhlZCBjaGFpbiBlc2NhcGVzIGFsbCBhbmNlc3RvcnMgdXAgdG8gdGhlXG4gICAgLy8gbmV4dCBjb250YWluaW5nIGJsb2NrLCBhbiBhYnNvbHV0ZSBjaGFpbiBlc2NhcGVzIHN0YXRpYyBhbmNlc3RvcnMuXG4gICAgY29uc3Qgc2hvdWxkRHJvcEN1cnJlbnROb2RlID0gIWN1cnJlbnROb2RlSXNDb250YWluaW5nICYmIChsYXN0UG9zaXRpb24gPT09ICdmaXhlZCcgfHwgbGFzdFBvc2l0aW9uID09PSAnYWJzb2x1dGUnICYmIGNvbXB1dGVkU3R5bGUucG9zaXRpb24gPT09ICdzdGF0aWMnKTtcbiAgICBpZiAoc2hvdWxkRHJvcEN1cnJlbnROb2RlKSB7XG4gICAgICAvLyBEcm9wIG5vbi1jb250YWluaW5nIGJsb2Nrcy5cbiAgICAgIHJlc3VsdCA9IHJlc3VsdC5maWx0ZXIoYW5jZXN0b3IgPT4gYW5jZXN0b3IgIT09IGN1cnJlbnROb2RlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gVGhlIGtlcHQgbm9kZSBjYXJyaWVzIHRoZSBjaGFpbiBwb3NpdGlvbiBmb3IgdGhlIG5leHQgaXRlcmF0aW9uLlxuICAgICAgbGFzdEtlcHRDb21wdXRlZFN0eWxlID0gY29tcHV0ZWRTdHlsZTtcbiAgICB9XG4gICAgY3VycmVudE5vZGUgPSBnZXRQYXJlbnROb2RlKGN1cnJlbnROb2RlKTtcbiAgfVxuICBjYWNoZS5zZXQoZWxlbWVudCwgcmVzdWx0KTtcbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuLy8gR2V0cyB0aGUgbWF4aW11bSBhcmVhIHRoYXQgdGhlIGVsZW1lbnQgaXMgdmlzaWJsZSBpbiBkdWUgdG8gYW55IG51bWJlciBvZlxuLy8gY2xpcHBpbmcgYW5jZXN0b3JzLlxuZnVuY3Rpb24gZ2V0Q2xpcHBpbmdSZWN0KF9yZWYpIHtcbiAgbGV0IHtcbiAgICBlbGVtZW50LFxuICAgIGJvdW5kYXJ5LFxuICAgIHJvb3RCb3VuZGFyeSxcbiAgICBzdHJhdGVneVxuICB9ID0gX3JlZjtcbiAgY29uc3QgZWxlbWVudENsaXBwaW5nQW5jZXN0b3JzID0gYm91bmRhcnkgPT09ICdjbGlwcGluZ0FuY2VzdG9ycycgPyBpc1RvcExheWVyKGVsZW1lbnQpID8gW10gOiBnZXRDbGlwcGluZ0VsZW1lbnRBbmNlc3RvcnMoZWxlbWVudCwgdGhpcy5fYykgOiBbXS5jb25jYXQoYm91bmRhcnkpO1xuICBjb25zdCBjbGlwcGluZ0FuY2VzdG9ycyA9IFsuLi5lbGVtZW50Q2xpcHBpbmdBbmNlc3RvcnMsIHJvb3RCb3VuZGFyeV07XG4gIGNvbnN0IGZpcnN0UmVjdCA9IGdldENsaWVudFJlY3RGcm9tQ2xpcHBpbmdBbmNlc3RvcihlbGVtZW50LCBjbGlwcGluZ0FuY2VzdG9yc1swXSwgc3RyYXRlZ3kpO1xuICBsZXQgdG9wID0gZmlyc3RSZWN0LnRvcDtcbiAgbGV0IHJpZ2h0ID0gZmlyc3RSZWN0LnJpZ2h0O1xuICBsZXQgYm90dG9tID0gZmlyc3RSZWN0LmJvdHRvbTtcbiAgbGV0IGxlZnQgPSBmaXJzdFJlY3QubGVmdDtcbiAgZm9yIChsZXQgaSA9IDE7IGkgPCBjbGlwcGluZ0FuY2VzdG9ycy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IHJlY3QgPSBnZXRDbGllbnRSZWN0RnJvbUNsaXBwaW5nQW5jZXN0b3IoZWxlbWVudCwgY2xpcHBpbmdBbmNlc3RvcnNbaV0sIHN0cmF0ZWd5KTtcbiAgICB0b3AgPSBtYXgocmVjdC50b3AsIHRvcCk7XG4gICAgcmlnaHQgPSBtaW4ocmVjdC5yaWdodCwgcmlnaHQpO1xuICAgIGJvdHRvbSA9IG1pbihyZWN0LmJvdHRvbSwgYm90dG9tKTtcbiAgICBsZWZ0ID0gbWF4KHJlY3QubGVmdCwgbGVmdCk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB3aWR0aDogcmlnaHQgLSBsZWZ0LFxuICAgIGhlaWdodDogYm90dG9tIC0gdG9wLFxuICAgIHg6IGxlZnQsXG4gICAgeTogdG9wXG4gIH07XG59XG5cbmZ1bmN0aW9uIGdldERpbWVuc2lvbnMoZWxlbWVudCkge1xuICBjb25zdCB7XG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0XG4gIH0gPSBnZXRDc3NEaW1lbnNpb25zKGVsZW1lbnQpO1xuICByZXR1cm4ge1xuICAgIHdpZHRoLFxuICAgIGhlaWdodFxuICB9O1xufVxuXG5mdW5jdGlvbiBnZXRSZWN0UmVsYXRpdmVUb09mZnNldFBhcmVudChlbGVtZW50LCBvZmZzZXRQYXJlbnQsIHN0cmF0ZWd5KSB7XG4gIGNvbnN0IGlzT2Zmc2V0UGFyZW50QW5FbGVtZW50ID0gaXNIVE1MRWxlbWVudChvZmZzZXRQYXJlbnQpO1xuICBjb25zdCBkb2N1bWVudEVsZW1lbnQgPSBnZXREb2N1bWVudEVsZW1lbnQob2Zmc2V0UGFyZW50KTtcbiAgY29uc3QgaXNGaXhlZCA9IHN0cmF0ZWd5ID09PSAnZml4ZWQnO1xuICBjb25zdCByZWN0ID0gZ2V0Qm91bmRpbmdDbGllbnRSZWN0KGVsZW1lbnQsIHRydWUsIGlzRml4ZWQsIG9mZnNldFBhcmVudCk7XG4gIGxldCBzY3JvbGwgPSB7XG4gICAgc2Nyb2xsTGVmdDogMCxcbiAgICBzY3JvbGxUb3A6IDBcbiAgfTtcbiAgY29uc3Qgb2Zmc2V0cyA9IGNyZWF0ZUNvb3JkcygwKTtcbiAgaWYgKGlzT2Zmc2V0UGFyZW50QW5FbGVtZW50IHx8ICFpc0ZpeGVkKSB7XG4gICAgaWYgKGdldE5vZGVOYW1lKG9mZnNldFBhcmVudCkgIT09ICdib2R5JyB8fCBpc092ZXJmbG93RWxlbWVudChkb2N1bWVudEVsZW1lbnQpKSB7XG4gICAgICBzY3JvbGwgPSBnZXROb2RlU2Nyb2xsKG9mZnNldFBhcmVudCk7XG4gICAgfVxuICAgIGlmIChpc09mZnNldFBhcmVudEFuRWxlbWVudCkge1xuICAgICAgY29uc3Qgb2Zmc2V0UmVjdCA9IGdldEJvdW5kaW5nQ2xpZW50UmVjdChvZmZzZXRQYXJlbnQsIHRydWUsIGlzRml4ZWQsIG9mZnNldFBhcmVudCk7XG4gICAgICBvZmZzZXRzLnggPSBvZmZzZXRSZWN0LnggKyBvZmZzZXRQYXJlbnQuY2xpZW50TGVmdDtcbiAgICAgIG9mZnNldHMueSA9IG9mZnNldFJlY3QueSArIG9mZnNldFBhcmVudC5jbGllbnRUb3A7XG4gICAgfVxuICB9XG5cbiAgLy8gSWYgdGhlIDxib2R5PiBzY3JvbGxiYXIgYXBwZWFycyBvbiB0aGUgbGVmdCAoZS5nLiBSVEwgc3lzdGVtcykuIFVzZVxuICAvLyBGaXJlZm94IHdpdGggbGF5b3V0LnNjcm9sbGJhci5zaWRlID0gMyBpbiBhYm91dDpjb25maWcgdG8gdGVzdCB0aGlzLlxuICBpZiAoIWlzT2Zmc2V0UGFyZW50QW5FbGVtZW50ICYmIGRvY3VtZW50RWxlbWVudCkge1xuICAgIG9mZnNldHMueCA9IGdldFdpbmRvd1Njcm9sbEJhclgoZG9jdW1lbnRFbGVtZW50KTtcbiAgfVxuICBjb25zdCBodG1sT2Zmc2V0ID0gZG9jdW1lbnRFbGVtZW50ICYmICFpc09mZnNldFBhcmVudEFuRWxlbWVudCAmJiAhaXNGaXhlZCA/IGdldEhUTUxPZmZzZXQoZG9jdW1lbnRFbGVtZW50LCBzY3JvbGwpIDogY3JlYXRlQ29vcmRzKDApO1xuICBjb25zdCB4ID0gcmVjdC5sZWZ0ICsgc2Nyb2xsLnNjcm9sbExlZnQgLSBvZmZzZXRzLnggLSBodG1sT2Zmc2V0Lng7XG4gIGNvbnN0IHkgPSByZWN0LnRvcCArIHNjcm9sbC5zY3JvbGxUb3AgLSBvZmZzZXRzLnkgLSBodG1sT2Zmc2V0Lnk7XG4gIHJldHVybiB7XG4gICAgeCxcbiAgICB5LFxuICAgIHdpZHRoOiByZWN0LndpZHRoLFxuICAgIGhlaWdodDogcmVjdC5oZWlnaHRcbiAgfTtcbn1cblxuZnVuY3Rpb24gaXNTdGF0aWNQb3NpdGlvbmVkKGVsZW1lbnQpIHtcbiAgcmV0dXJuIGdldENvbXB1dGVkU3R5bGUkMShlbGVtZW50KS5wb3NpdGlvbiA9PT0gJ3N0YXRpYyc7XG59XG5cbmZ1bmN0aW9uIGdldFRydWVPZmZzZXRQYXJlbnQoZWxlbWVudCwgcG9seWZpbGwpIHtcbiAgaWYgKCFpc0hUTUxFbGVtZW50KGVsZW1lbnQpIHx8IGdldENvbXB1dGVkU3R5bGUkMShlbGVtZW50KS5wb3NpdGlvbiA9PT0gJ2ZpeGVkJykge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGlmIChwb2x5ZmlsbCkge1xuICAgIHJldHVybiBwb2x5ZmlsbChlbGVtZW50KTtcbiAgfVxuICBsZXQgcmF3T2Zmc2V0UGFyZW50ID0gZWxlbWVudC5vZmZzZXRQYXJlbnQ7XG5cbiAgLy8gRmlyZWZveCByZXR1cm5zIHRoZSA8aHRtbD4gZWxlbWVudCBhcyB0aGUgb2Zmc2V0UGFyZW50IGlmIGl0J3Mgbm9uLXN0YXRpYyxcbiAgLy8gd2hpbGUgQ2hyb21lIGFuZCBTYWZhcmkgcmV0dXJuIHRoZSA8Ym9keT4gZWxlbWVudC4gVGhlIDxib2R5PiBlbGVtZW50IG11c3RcbiAgLy8gYmUgdXNlZCB0byBwZXJmb3JtIHRoZSBjb3JyZWN0IGNhbGN1bGF0aW9ucyBldmVuIGlmIHRoZSA8aHRtbD4gZWxlbWVudCBpc1xuICAvLyBub24tc3RhdGljLlxuICBpZiAoZ2V0RG9jdW1lbnRFbGVtZW50KGVsZW1lbnQpID09PSByYXdPZmZzZXRQYXJlbnQpIHtcbiAgICByYXdPZmZzZXRQYXJlbnQgPSByYXdPZmZzZXRQYXJlbnQub3duZXJEb2N1bWVudC5ib2R5O1xuICB9XG4gIHJldHVybiByYXdPZmZzZXRQYXJlbnQ7XG59XG5cbi8vIEdldHMgdGhlIGNsb3Nlc3QgYW5jZXN0b3IgcG9zaXRpb25lZCBlbGVtZW50LiBIYW5kbGVzIHNvbWUgZWRnZSBjYXNlcyxcbi8vIHN1Y2ggYXMgdGFibGUgYW5jZXN0b3JzIGFuZCBjcm9zcyBicm93c2VyIGJ1Z3MuXG5mdW5jdGlvbiBnZXRPZmZzZXRQYXJlbnQoZWxlbWVudCwgcG9seWZpbGwpIHtcbiAgY29uc3Qgd2luID0gZ2V0V2luZG93KGVsZW1lbnQpO1xuICBpZiAoaXNUb3BMYXllcihlbGVtZW50KSkge1xuICAgIHJldHVybiB3aW47XG4gIH1cbiAgaWYgKCFpc0hUTUxFbGVtZW50KGVsZW1lbnQpKSB7XG4gICAgbGV0IHN2Z09mZnNldFBhcmVudCA9IGdldFBhcmVudE5vZGUoZWxlbWVudCk7XG4gICAgd2hpbGUgKHN2Z09mZnNldFBhcmVudCAmJiAhaXNMYXN0VHJhdmVyc2FibGVOb2RlKHN2Z09mZnNldFBhcmVudCkpIHtcbiAgICAgIGlmIChpc0VsZW1lbnQoc3ZnT2Zmc2V0UGFyZW50KSAmJiAhaXNTdGF0aWNQb3NpdGlvbmVkKHN2Z09mZnNldFBhcmVudCkpIHtcbiAgICAgICAgcmV0dXJuIHN2Z09mZnNldFBhcmVudDtcbiAgICAgIH1cbiAgICAgIHN2Z09mZnNldFBhcmVudCA9IGdldFBhcmVudE5vZGUoc3ZnT2Zmc2V0UGFyZW50KTtcbiAgICB9XG4gICAgcmV0dXJuIHdpbjtcbiAgfVxuICBsZXQgb2Zmc2V0UGFyZW50ID0gZ2V0VHJ1ZU9mZnNldFBhcmVudChlbGVtZW50LCBwb2x5ZmlsbCk7XG4gIHdoaWxlIChvZmZzZXRQYXJlbnQgJiYgaXNUYWJsZUVsZW1lbnQob2Zmc2V0UGFyZW50KSAmJiBpc1N0YXRpY1Bvc2l0aW9uZWQob2Zmc2V0UGFyZW50KSkge1xuICAgIG9mZnNldFBhcmVudCA9IGdldFRydWVPZmZzZXRQYXJlbnQob2Zmc2V0UGFyZW50LCBwb2x5ZmlsbCk7XG4gIH1cbiAgaWYgKG9mZnNldFBhcmVudCAmJiBpc0xhc3RUcmF2ZXJzYWJsZU5vZGUob2Zmc2V0UGFyZW50KSAmJiBpc1N0YXRpY1Bvc2l0aW9uZWQob2Zmc2V0UGFyZW50KSAmJiAhaXNDb250YWluaW5nQmxvY2sob2Zmc2V0UGFyZW50KSkge1xuICAgIHJldHVybiB3aW47XG4gIH1cbiAgcmV0dXJuIG9mZnNldFBhcmVudCB8fCBnZXRDb250YWluaW5nQmxvY2soZWxlbWVudCkgfHwgd2luO1xufVxuXG5jb25zdCBnZXRFbGVtZW50UmVjdHMgPSBhc3luYyBmdW5jdGlvbiAoZGF0YSkge1xuICBjb25zdCBnZXRPZmZzZXRQYXJlbnRGbiA9IHRoaXMuZ2V0T2Zmc2V0UGFyZW50IHx8IGdldE9mZnNldFBhcmVudDtcbiAgY29uc3QgZ2V0RGltZW5zaW9uc0ZuID0gdGhpcy5nZXREaW1lbnNpb25zO1xuICBjb25zdCBmbG9hdGluZ0RpbWVuc2lvbnMgPSBhd2FpdCBnZXREaW1lbnNpb25zRm4oZGF0YS5mbG9hdGluZyk7XG4gIHJldHVybiB7XG4gICAgcmVmZXJlbmNlOiBnZXRSZWN0UmVsYXRpdmVUb09mZnNldFBhcmVudChkYXRhLnJlZmVyZW5jZSwgYXdhaXQgZ2V0T2Zmc2V0UGFyZW50Rm4oZGF0YS5mbG9hdGluZyksIGRhdGEuc3RyYXRlZ3kpLFxuICAgIGZsb2F0aW5nOiB7XG4gICAgICB4OiAwLFxuICAgICAgeTogMCxcbiAgICAgIHdpZHRoOiBmbG9hdGluZ0RpbWVuc2lvbnMud2lkdGgsXG4gICAgICBoZWlnaHQ6IGZsb2F0aW5nRGltZW5zaW9ucy5oZWlnaHRcbiAgICB9XG4gIH07XG59O1xuXG5mdW5jdGlvbiBpc1JUTChlbGVtZW50KSB7XG4gIHJldHVybiBnZXRDb21wdXRlZFN0eWxlJDEoZWxlbWVudCkuZGlyZWN0aW9uID09PSAncnRsJztcbn1cblxuY29uc3QgcGxhdGZvcm0gPSB7XG4gIGNvbnZlcnRPZmZzZXRQYXJlbnRSZWxhdGl2ZVJlY3RUb1ZpZXdwb3J0UmVsYXRpdmVSZWN0LFxuICBnZXREb2N1bWVudEVsZW1lbnQsXG4gIGdldENsaXBwaW5nUmVjdCxcbiAgZ2V0T2Zmc2V0UGFyZW50LFxuICBnZXRFbGVtZW50UmVjdHMsXG4gIGdldENsaWVudFJlY3RzLFxuICBnZXREaW1lbnNpb25zLFxuICBnZXRTY2FsZSxcbiAgaXNFbGVtZW50LFxuICBpc1JUTFxufTtcblxuZnVuY3Rpb24gcmVjdHNBcmVFcXVhbChhLCBiKSB7XG4gIHJldHVybiBhLnggPT09IGIueCAmJiBhLnkgPT09IGIueSAmJiBhLndpZHRoID09PSBiLndpZHRoICYmIGEuaGVpZ2h0ID09PSBiLmhlaWdodDtcbn1cblxuLy8gaHR0cHM6Ly9zYW10aG9yLmF1LzIwMjEvb2JzZXJ2aW5nLWRvbS9cbmZ1bmN0aW9uIG9ic2VydmVNb3ZlKGVsZW1lbnQsIG9uTW92ZSwgYW5jZXN0b3JSZXNpemUpIHtcbiAgbGV0IGlvID0gbnVsbDtcbiAgbGV0IHRpbWVvdXRJZDtcbiAgY29uc3Qgcm9vdCA9IGdldERvY3VtZW50RWxlbWVudChlbGVtZW50KTtcbiAgZnVuY3Rpb24gY2xlYW51cCgpIHtcbiAgICB2YXIgX2lvO1xuICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuICAgIChfaW8gPSBpbykgPT0gbnVsbCB8fCBfaW8uZGlzY29ubmVjdCgpO1xuICAgIGlvID0gbnVsbDtcbiAgfVxuICBmdW5jdGlvbiByZWZyZXNoKHNraXAsIHRocmVzaG9sZCkge1xuICAgIGlmIChza2lwID09PSB2b2lkIDApIHtcbiAgICAgIHNraXAgPSBmYWxzZTtcbiAgICB9XG4gICAgaWYgKHRocmVzaG9sZCA9PT0gdm9pZCAwKSB7XG4gICAgICB0aHJlc2hvbGQgPSAxO1xuICAgIH1cbiAgICBjbGVhbnVwKCk7XG4gICAgY29uc3QgZWxlbWVudFJlY3RGb3JSb290TWFyZ2luID0gZWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBjb25zdCB7XG4gICAgICBsZWZ0LFxuICAgICAgdG9wLFxuICAgICAgd2lkdGgsXG4gICAgICBoZWlnaHRcbiAgICB9ID0gZWxlbWVudFJlY3RGb3JSb290TWFyZ2luO1xuICAgIGlmICghc2tpcCkge1xuICAgICAgb25Nb3ZlKCk7XG4gICAgfVxuICAgIGlmICghd2lkdGggfHwgIWhlaWdodCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBpbnNldFRvcCA9IGZsb29yKHRvcCk7XG4gICAgY29uc3QgaW5zZXRSaWdodCA9IGZsb29yKHJvb3QuY2xpZW50V2lkdGggLSAobGVmdCArIHdpZHRoKSk7XG4gICAgY29uc3QgaW5zZXRCb3R0b20gPSBmbG9vcihyb290LmNsaWVudEhlaWdodCAtICh0b3AgKyBoZWlnaHQpKTtcbiAgICBjb25zdCBpbnNldExlZnQgPSBmbG9vcihsZWZ0KTtcbiAgICBjb25zdCByb290TWFyZ2luID0gLWluc2V0VG9wICsgXCJweCBcIiArIC1pbnNldFJpZ2h0ICsgXCJweCBcIiArIC1pbnNldEJvdHRvbSArIFwicHggXCIgKyAtaW5zZXRMZWZ0ICsgXCJweFwiO1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICByb290TWFyZ2luLFxuICAgICAgdGhyZXNob2xkOiBtYXgoMCwgbWluKDEsIHRocmVzaG9sZCkpIHx8IDFcbiAgICB9O1xuICAgIGxldCBpc0ZpcnN0VXBkYXRlID0gdHJ1ZTtcbiAgICBmdW5jdGlvbiBoYW5kbGVPYnNlcnZlKGVudHJpZXMpIHtcbiAgICAgIGNvbnN0IHJhdGlvID0gZW50cmllc1swXS5pbnRlcnNlY3Rpb25SYXRpbztcblxuICAgICAgLy8gVGhlIGVudHJ5IGlzIGEgc25hcHNob3QsIHNvIHRoZSByZWZlcmVuY2UgbWF5IGhhdmUgbW92ZWQgc2luY2UgdGhlXG4gICAgICAvLyBpbnRlcnNlY3Rpb24gd2FzIGNvbXB1dGVkICh1bmRlciBwZXJmb3JtYW5jZSBjb25zdHJhaW50cywgb3IgYmV0d2VlblxuICAgICAgLy8gY29uc2VjdXRpdmUgZnJhbWVzIG9mIGEgbXVsdGktZnJhbWUgbGF5b3V0IHNoaWZ0KS4gVGhlIHJlcG9ydGVkIHJhdGlvXG4gICAgICAvLyBhbmQgdGhlIG9ic2VydmVkIGFyZWEgYXJlIHN0YWxlIGluIHRoYXQgY2FzZSBhbmQgY2Fubm90IGJlIHRydXN0ZWQgdG9cbiAgICAgIC8vIGRldGVjdCBzdWJzZXF1ZW50IG1vdmVtZW50LCBzbyByZWZyZXNoIHJlZ2FyZGxlc3Mgb2YgdGhlIHJhdGlvLlxuICAgICAgaWYgKCFyZWN0c0FyZUVxdWFsKGVsZW1lbnRSZWN0Rm9yUm9vdE1hcmdpbiwgZWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSkpIHtcbiAgICAgICAgcmV0dXJuIHJlZnJlc2goKTtcbiAgICAgIH1cbiAgICAgIGlmIChyYXRpbyAhPT0gdGhyZXNob2xkKSB7XG4gICAgICAgIGlmICghaXNGaXJzdFVwZGF0ZSkge1xuICAgICAgICAgIHJldHVybiByZWZyZXNoKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFyYXRpbykge1xuICAgICAgICAgIC8vIElmIHRoZSByZWZlcmVuY2UgaXMgY2xpcHBlZCBpbiBwbGFjZSwgdGhlIHJhdGlvIGlzIDAuIFRocm90dGxlXG4gICAgICAgICAgLy8gdGhlIHJlZnJlc2ggdG8gcHJldmVudCBhbiBpbmZpbml0ZSBsb29wIG9mIHVwZGF0ZXMuXG4gICAgICAgICAgdGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICByZWZyZXNoKGZhbHNlLCAxZS03KTtcbiAgICAgICAgICB9LCAxMDAwKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZWZyZXNoKGZhbHNlLCByYXRpbyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlzRmlyc3RVcGRhdGUgPSBmYWxzZTtcbiAgICB9XG5cbiAgICAvLyBPbGRlciBicm93c2VycyBkb24ndCBzdXBwb3J0IGEgYGRvY3VtZW50YCBhcyB0aGUgcm9vdCBhbmQgd2lsbCB0aHJvdyBhblxuICAgIC8vIGVycm9yLlxuICAgIHRyeSB7XG4gICAgICBpbyA9IG5ldyBJbnRlcnNlY3Rpb25PYnNlcnZlcihoYW5kbGVPYnNlcnZlLCB7XG4gICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgIC8vIEhhbmRsZSA8aWZyYW1lPnNcbiAgICAgICAgcm9vdDogcm9vdC5vd25lckRvY3VtZW50XG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChfZSkge1xuICAgICAgaW8gPSBuZXcgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIoaGFuZGxlT2JzZXJ2ZSwgb3B0aW9ucyk7XG4gICAgfVxuICAgIGlvLm9ic2VydmUoZWxlbWVudCk7XG4gIH1cbiAgY29uc3Qgd2luID0gZ2V0V2luZG93KGVsZW1lbnQpO1xuICAvLyBUaGUgd2luZG93IGlzIGEgcmVzaXplIGFuY2VzdG9yLCBzbyB3aGVuIGBhbmNlc3RvclJlc2l6ZWAgaXMgZW5hYmxlZCBpdHNcbiAgLy8gbGlzdGVuZXIgYWxyZWFkeSBydW5zIHRoZSB1cGRhdGUgb24gcmVzaXplLiBIZXJlIHdlIG9ubHkgbmVlZCB0byByZWJ1aWxkXG4gIC8vIHRoZSBgSW50ZXJzZWN0aW9uT2JzZXJ2ZXJgIGZvciB0aGUgbmV3IHJvb3Qgc2l6ZSwgc2tpcHBpbmcgYSByZWR1bmRhbnRcbiAgLy8gdXBkYXRlLiBXaGVuIGBhbmNlc3RvclJlc2l6ZWAgaXMgZGlzYWJsZWQsIHRoaXMgYmVjb21lcyB0aGUgc29sZSB1cGRhdGUuXG4gIGNvbnN0IGhhbmRsZVJlc2l6ZSA9ICgpID0+IHJlZnJlc2goYW5jZXN0b3JSZXNpemUpO1xuICB3aW4uYWRkRXZlbnRMaXN0ZW5lcigncmVzaXplJywgaGFuZGxlUmVzaXplKTtcbiAgcmVmcmVzaCh0cnVlKTtcbiAgcmV0dXJuICgpID0+IHtcbiAgICB3aW4ucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgaGFuZGxlUmVzaXplKTtcbiAgICBjbGVhbnVwKCk7XG4gIH07XG59XG5cbi8qKlxuICogQXV0b21hdGljYWxseSB1cGRhdGVzIHRoZSBwb3NpdGlvbiBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCB3aGVuIG5lY2Vzc2FyeS5cbiAqIFNob3VsZCBvbmx5IGJlIGNhbGxlZCB3aGVuIHRoZSBmbG9hdGluZyBlbGVtZW50IGlzIG1vdW50ZWQgb24gdGhlIERPTSBvclxuICogdmlzaWJsZSBvbiB0aGUgc2NyZWVuLlxuICogQHJldHVybnMgY2xlYW51cCBmdW5jdGlvbiB0aGF0IHNob3VsZCBiZSBpbnZva2VkIHdoZW4gdGhlIGZsb2F0aW5nIGVsZW1lbnQgaXNcbiAqIHJlbW92ZWQgZnJvbSB0aGUgRE9NIG9yIGhpZGRlbiBmcm9tIHRoZSBzY3JlZW4uXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvYXV0b1VwZGF0ZVxuICovXG5mdW5jdGlvbiBhdXRvVXBkYXRlKHJlZmVyZW5jZSwgZmxvYXRpbmcsIHVwZGF0ZSwgb3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG4gIGNvbnN0IHtcbiAgICBhbmNlc3RvclNjcm9sbCA9IHRydWUsXG4gICAgYW5jZXN0b3JSZXNpemUgPSB0cnVlLFxuICAgIGVsZW1lbnRSZXNpemUgPSB0eXBlb2YgUmVzaXplT2JzZXJ2ZXIgPT09ICdmdW5jdGlvbicsXG4gICAgbGF5b3V0U2hpZnQgPSB0eXBlb2YgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIgPT09ICdmdW5jdGlvbicsXG4gICAgYW5pbWF0aW9uRnJhbWUgPSBmYWxzZVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgcmVmZXJlbmNlRWwgPSB1bndyYXBFbGVtZW50KHJlZmVyZW5jZSk7XG4gIGNvbnN0IGFuY2VzdG9ycyA9IGFuY2VzdG9yU2Nyb2xsIHx8IGFuY2VzdG9yUmVzaXplID8gWy4uLihyZWZlcmVuY2VFbCA/IGdldE92ZXJmbG93QW5jZXN0b3JzKHJlZmVyZW5jZUVsKSA6IFtdKSwgLi4uKGZsb2F0aW5nID8gZ2V0T3ZlcmZsb3dBbmNlc3RvcnMoZmxvYXRpbmcpIDogW10pXSA6IFtdO1xuICBhbmNlc3RvcnMuZm9yRWFjaChhbmNlc3RvciA9PiB7XG4gICAgYW5jZXN0b3JTY3JvbGwgJiYgYW5jZXN0b3IuYWRkRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgdXBkYXRlKTtcbiAgICBhbmNlc3RvclJlc2l6ZSAmJiBhbmNlc3Rvci5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCB1cGRhdGUpO1xuICB9KTtcbiAgY29uc3QgY2xlYW51cElvID0gcmVmZXJlbmNlRWwgJiYgbGF5b3V0U2hpZnQgPyBvYnNlcnZlTW92ZShyZWZlcmVuY2VFbCwgdXBkYXRlLCBhbmNlc3RvclJlc2l6ZSkgOiBudWxsO1xuICBsZXQgcmVvYnNlcnZlRnJhbWUgPSAtMTtcbiAgbGV0IHJlc2l6ZU9ic2VydmVyID0gbnVsbDtcbiAgaWYgKGVsZW1lbnRSZXNpemUpIHtcbiAgICByZXNpemVPYnNlcnZlciA9IG5ldyBSZXNpemVPYnNlcnZlcihfcmVmID0+IHtcbiAgICAgIGxldCBbZmlyc3RFbnRyeV0gPSBfcmVmO1xuICAgICAgaWYgKGZpcnN0RW50cnkgJiYgZmlyc3RFbnRyeS50YXJnZXQgPT09IHJlZmVyZW5jZUVsICYmIHJlc2l6ZU9ic2VydmVyICYmIGZsb2F0aW5nKSB7XG4gICAgICAgIC8vIFByZXZlbnQgdXBkYXRlIGxvb3BzIHdoZW4gdXNpbmcgdGhlIGBzaXplYCBtaWRkbGV3YXJlLlxuICAgICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vZmxvYXRpbmctdWkvZmxvYXRpbmctdWkvaXNzdWVzLzE3NDBcbiAgICAgICAgcmVzaXplT2JzZXJ2ZXIudW5vYnNlcnZlKGZsb2F0aW5nKTtcbiAgICAgICAgY2FuY2VsQW5pbWF0aW9uRnJhbWUocmVvYnNlcnZlRnJhbWUpO1xuICAgICAgICByZW9ic2VydmVGcmFtZSA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgICAgICAgdmFyIF9yZXNpemVPYnNlcnZlcjtcbiAgICAgICAgICAoX3Jlc2l6ZU9ic2VydmVyID0gcmVzaXplT2JzZXJ2ZXIpID09IG51bGwgfHwgX3Jlc2l6ZU9ic2VydmVyLm9ic2VydmUoZmxvYXRpbmcpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHVwZGF0ZSgpO1xuICAgIH0pO1xuICAgIGlmIChyZWZlcmVuY2VFbCAmJiAhYW5pbWF0aW9uRnJhbWUpIHtcbiAgICAgIHJlc2l6ZU9ic2VydmVyLm9ic2VydmUocmVmZXJlbmNlRWwpO1xuICAgIH1cbiAgICBpZiAoZmxvYXRpbmcpIHtcbiAgICAgIHJlc2l6ZU9ic2VydmVyLm9ic2VydmUoZmxvYXRpbmcpO1xuICAgIH1cbiAgfVxuICBsZXQgZnJhbWVJZDtcbiAgbGV0IHByZXZSZWZSZWN0ID0gYW5pbWF0aW9uRnJhbWUgPyBnZXRCb3VuZGluZ0NsaWVudFJlY3QocmVmZXJlbmNlKSA6IG51bGw7XG4gIGlmIChhbmltYXRpb25GcmFtZSkge1xuICAgIGZyYW1lTG9vcCgpO1xuICB9XG4gIGZ1bmN0aW9uIGZyYW1lTG9vcCgpIHtcbiAgICBjb25zdCBuZXh0UmVmUmVjdCA9IGdldEJvdW5kaW5nQ2xpZW50UmVjdChyZWZlcmVuY2UpO1xuICAgIGlmIChwcmV2UmVmUmVjdCAmJiAhcmVjdHNBcmVFcXVhbChwcmV2UmVmUmVjdCwgbmV4dFJlZlJlY3QpKSB7XG4gICAgICB1cGRhdGUoKTtcbiAgICB9XG4gICAgcHJldlJlZlJlY3QgPSBuZXh0UmVmUmVjdDtcbiAgICBmcmFtZUlkID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKGZyYW1lTG9vcCk7XG4gIH1cbiAgdXBkYXRlKCk7XG4gIHJldHVybiAoKSA9PiB7XG4gICAgdmFyIF9yZXNpemVPYnNlcnZlcjI7XG4gICAgYW5jZXN0b3JzLmZvckVhY2goYW5jZXN0b3IgPT4ge1xuICAgICAgYW5jZXN0b3JTY3JvbGwgJiYgYW5jZXN0b3IucmVtb3ZlRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgdXBkYXRlKTtcbiAgICAgIGFuY2VzdG9yUmVzaXplICYmIGFuY2VzdG9yLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHVwZGF0ZSk7XG4gICAgfSk7XG4gICAgY2xlYW51cElvID09IG51bGwgfHwgY2xlYW51cElvKCk7XG4gICAgKF9yZXNpemVPYnNlcnZlcjIgPSByZXNpemVPYnNlcnZlcikgPT0gbnVsbCB8fCBfcmVzaXplT2JzZXJ2ZXIyLmRpc2Nvbm5lY3QoKTtcbiAgICByZXNpemVPYnNlcnZlciA9IG51bGw7XG4gICAgaWYgKGFuaW1hdGlvbkZyYW1lKSB7XG4gICAgICBjYW5jZWxBbmltYXRpb25GcmFtZShmcmFtZUlkKTtcbiAgICB9XG4gIH07XG59XG5cbi8qKlxuICogUmVzb2x2ZXMgd2l0aCBhbiBvYmplY3Qgb2Ygb3ZlcmZsb3cgc2lkZSBvZmZzZXRzIHRoYXQgZGV0ZXJtaW5lIGhvdyBtdWNoIHRoZVxuICogZWxlbWVudCBpcyBvdmVyZmxvd2luZyBhIGdpdmVuIGNsaXBwaW5nIGJvdW5kYXJ5IG9uIGVhY2ggc2lkZS5cbiAqIC0gcG9zaXRpdmUgPSBvdmVyZmxvd2luZyB0aGUgYm91bmRhcnkgYnkgdGhhdCBudW1iZXIgb2YgcGl4ZWxzXG4gKiAtIG5lZ2F0aXZlID0gaG93IG1hbnkgcGl4ZWxzIGxlZnQgYmVmb3JlIGl0IHdpbGwgb3ZlcmZsb3dcbiAqIC0gMCA9IGxpZXMgZmx1c2ggd2l0aCB0aGUgYm91bmRhcnlcbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9kZXRlY3RPdmVyZmxvd1xuICovXG5jb25zdCBkZXRlY3RPdmVyZmxvdyA9IGRldGVjdE92ZXJmbG93JDE7XG5cbi8qKlxuICogTW9kaWZpZXMgdGhlIHBsYWNlbWVudCBieSB0cmFuc2xhdGluZyB0aGUgZmxvYXRpbmcgZWxlbWVudCBhbG9uZyB0aGVcbiAqIHNwZWNpZmllZCBheGVzLlxuICogQSBudW1iZXIgKHNob3J0aGFuZCBmb3IgYG1haW5BeGlzYCBvciBkaXN0YW5jZSksIG9yIGFuIGF4ZXMgY29uZmlndXJhdGlvblxuICogb2JqZWN0IG1heSBiZSBwYXNzZWQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3Mvb2Zmc2V0XG4gKi9cbmNvbnN0IG9mZnNldCA9IG9mZnNldCQxO1xuXG4vKipcbiAqIE9wdGltaXplcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBieSBjaG9vc2luZyB0aGUgcGxhY2VtZW50XG4gKiB0aGF0IGhhcyB0aGUgbW9zdCBzcGFjZSBhdmFpbGFibGUgYXV0b21hdGljYWxseSwgd2l0aG91dCBuZWVkaW5nIHRvIHNwZWNpZnkgYVxuICogcHJlZmVycmVkIHBsYWNlbWVudC4gQWx0ZXJuYXRpdmUgdG8gYGZsaXBgLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2F1dG9QbGFjZW1lbnRcbiAqL1xuY29uc3QgYXV0b1BsYWNlbWVudCA9IGF1dG9QbGFjZW1lbnQkMTtcblxuLyoqXG4gKiBPcHRpbWl6ZXMgdGhlIHZpc2liaWxpdHkgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQgYnkgc2hpZnRpbmcgaXQgaW4gb3JkZXIgdG9cbiAqIGtlZXAgaXQgaW4gdmlldyB3aGVuIGl0IHdpbGwgb3ZlcmZsb3cgdGhlIGNsaXBwaW5nIGJvdW5kYXJ5LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL3NoaWZ0XG4gKi9cbmNvbnN0IHNoaWZ0ID0gc2hpZnQkMTtcblxuLyoqXG4gKiBPcHRpbWl6ZXMgdGhlIHZpc2liaWxpdHkgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQgYnkgZmxpcHBpbmcgdGhlIGBwbGFjZW1lbnRgXG4gKiBpbiBvcmRlciB0byBrZWVwIGl0IGluIHZpZXcgd2hlbiB0aGUgcHJlZmVycmVkIHBsYWNlbWVudChzKSB3aWxsIG92ZXJmbG93IHRoZVxuICogY2xpcHBpbmcgYm91bmRhcnkuIEFsdGVybmF0aXZlIHRvIGBhdXRvUGxhY2VtZW50YC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9mbGlwXG4gKi9cbmNvbnN0IGZsaXAgPSBmbGlwJDE7XG5cbi8qKlxuICogUHJvdmlkZXMgZGF0YSB0aGF0IGFsbG93cyB5b3UgdG8gY2hhbmdlIHRoZSBzaXplIG9mIHRoZSBmbG9hdGluZyBlbGVtZW50IOKAlFxuICogZm9yIGluc3RhbmNlLCBwcmV2ZW50IGl0IGZyb20gb3ZlcmZsb3dpbmcgdGhlIGNsaXBwaW5nIGJvdW5kYXJ5IG9yIG1hdGNoIHRoZVxuICogd2lkdGggb2YgdGhlIHJlZmVyZW5jZSBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL3NpemVcbiAqL1xuY29uc3Qgc2l6ZSA9IHNpemUkMTtcblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRvIGhpZGUgdGhlIGZsb2F0aW5nIGVsZW1lbnQgaW4gYXBwbGljYWJsZSBzaXR1YXRpb25zLCBzdWNoIGFzXG4gKiB3aGVuIGl0IGlzIG5vdCBpbiB0aGUgc2FtZSBjbGlwcGluZyBjb250ZXh0IGFzIHRoZSByZWZlcmVuY2UgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9oaWRlXG4gKi9cbmNvbnN0IGhpZGUgPSBoaWRlJDE7XG5cbi8qKlxuICogUHJvdmlkZXMgZGF0YSB0byBwb3NpdGlvbiBhbiBpbm5lciBlbGVtZW50IG9mIHRoZSBmbG9hdGluZyBlbGVtZW50IHNvIHRoYXQgaXRcbiAqIGFwcGVhcnMgY2VudGVyZWQgdG8gdGhlIHJlZmVyZW5jZSBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2Fycm93XG4gKi9cbmNvbnN0IGFycm93ID0gYXJyb3ckMTtcblxuLyoqXG4gKiBQcm92aWRlcyBpbXByb3ZlZCBwb3NpdGlvbmluZyBmb3IgaW5saW5lIHJlZmVyZW5jZSBlbGVtZW50cyB0aGF0IGNhbiBzcGFuXG4gKiBvdmVyIG11bHRpcGxlIGxpbmVzLCBzdWNoIGFzIGh5cGVybGlua3Mgb3IgcmFuZ2Ugc2VsZWN0aW9ucy5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9pbmxpbmVcbiAqL1xuY29uc3QgaW5saW5lID0gaW5saW5lJDE7XG5cbi8qKlxuICogQnVpbHQtaW4gYGxpbWl0ZXJgIHRoYXQgd2lsbCBzdG9wIGBzaGlmdCgpYCBhdCBhIGNlcnRhaW4gcG9pbnQuXG4gKi9cbmNvbnN0IGxpbWl0U2hpZnQgPSBsaW1pdFNoaWZ0JDE7XG5cbi8qKlxuICogQ29tcHV0ZXMgdGhlIGB4YCBhbmQgYHlgIGNvb3JkaW5hdGVzIHRoYXQgd2lsbCBwbGFjZSB0aGUgZmxvYXRpbmcgZWxlbWVudFxuICogbmV4dCB0byBhIGdpdmVuIHJlZmVyZW5jZSBlbGVtZW50LlxuICovXG5jb25zdCBjb21wdXRlUG9zaXRpb24gPSAocmVmZXJlbmNlLCBmbG9hdGluZywgb3B0aW9ucykgPT4ge1xuICAvLyBUaGlzIGNhY2hlcyB0aGUgZXhwZW5zaXZlIGBnZXRDbGlwcGluZ0VsZW1lbnRBbmNlc3RvcnNgIGZ1bmN0aW9uIHNvIHRoYXRcbiAgLy8gbXVsdGlwbGUgbGlmZWN5Y2xlIHJlc2V0cyByZS11c2UgdGhlIHNhbWUgcmVzdWx0LiBJdCBvbmx5IGxpdmVzIGZvciBhXG4gIC8vIHNpbmdsZSBjYWxsLiBJZiBvdGhlciBmdW5jdGlvbnMgYmVjb21lIGV4cGVuc2l2ZSwgd2UgY2FuIGFkZCB0aGVtIGFzIHdlbGwuXG4gIGNvbnN0IGNhY2hlID0gbmV3IE1hcCgpO1xuICBjb25zdCBtZXJnZWRPcHRpb25zID0gb3B0aW9ucyAhPSBudWxsID8gb3B0aW9ucyA6IHt9O1xuICBjb25zdCBwbGF0Zm9ybVdpdGhDYWNoZSA9IHtcbiAgICAuLi5wbGF0Zm9ybSxcbiAgICAuLi5tZXJnZWRPcHRpb25zLnBsYXRmb3JtLFxuICAgIF9jOiBjYWNoZVxuICB9O1xuICByZXR1cm4gY29tcHV0ZVBvc2l0aW9uJDEocmVmZXJlbmNlLCBmbG9hdGluZywge1xuICAgIC4uLm1lcmdlZE9wdGlvbnMsXG4gICAgcGxhdGZvcm06IHBsYXRmb3JtV2l0aENhY2hlXG4gIH0pO1xufTtcblxuZXhwb3J0IHsgYXJyb3csIGF1dG9QbGFjZW1lbnQsIGF1dG9VcGRhdGUsIGNvbXB1dGVQb3NpdGlvbiwgZGV0ZWN0T3ZlcmZsb3csIGZsaXAsIGhpZGUsIGlubGluZSwgbGltaXRTaGlmdCwgb2Zmc2V0LCBwbGF0Zm9ybSwgc2hpZnQsIHNpemUgfTtcbiIsImltcG9ydCB7IGNvbXB1dGVQb3NpdGlvbiwgYXJyb3cgYXMgYXJyb3ckMiwgYXV0b1BsYWNlbWVudCBhcyBhdXRvUGxhY2VtZW50JDEsIGZsaXAgYXMgZmxpcCQxLCBoaWRlIGFzIGhpZGUkMSwgaW5saW5lIGFzIGlubGluZSQxLCBsaW1pdFNoaWZ0IGFzIGxpbWl0U2hpZnQkMSwgb2Zmc2V0IGFzIG9mZnNldCQxLCBzaGlmdCBhcyBzaGlmdCQxLCBzaXplIGFzIHNpemUkMSB9IGZyb20gJ0BmbG9hdGluZy11aS9kb20nO1xuZXhwb3J0IHsgYXV0b1VwZGF0ZSwgY29tcHV0ZVBvc2l0aW9uLCBkZXRlY3RPdmVyZmxvdywgZ2V0T3ZlcmZsb3dBbmNlc3RvcnMsIHBsYXRmb3JtIH0gZnJvbSAnQGZsb2F0aW5nLXVpL2RvbSc7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VMYXlvdXRFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgKiBhcyBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20nO1xuXG52YXIgaXNDbGllbnQgPSB0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnO1xuXG52YXIgbm9vcCA9IGZ1bmN0aW9uIG5vb3AoKSB7fTtcbnZhciBpbmRleCA9IGlzQ2xpZW50ID8gdXNlTGF5b3V0RWZmZWN0IDogbm9vcDtcblxuLy8gRm9yayBvZiBgZmFzdC1kZWVwLWVxdWFsYCB0aGF0IG9ubHkgZG9lcyB0aGUgY29tcGFyaXNvbnMgd2UgbmVlZCBhbmQgY29tcGFyZXNcbi8vIGZ1bmN0aW9uc1xuZnVuY3Rpb24gZGVlcEVxdWFsKGEsIGIpIHtcbiAgaWYgKGEgPT09IGIpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBpZiAodHlwZW9mIGEgIT09IHR5cGVvZiBiKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmICh0eXBlb2YgYSA9PT0gJ2Z1bmN0aW9uJyAmJiBhLnRvU3RyaW5nKCkgPT09IGIudG9TdHJpbmcoKSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGxldCBsZW5ndGg7XG4gIGxldCBpO1xuICBsZXQga2V5cztcbiAgaWYgKGEgJiYgYiAmJiB0eXBlb2YgYSA9PT0gJ29iamVjdCcpIHtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShhKSkge1xuICAgICAgbGVuZ3RoID0gYS5sZW5ndGg7XG4gICAgICBpZiAobGVuZ3RoICE9PSBiLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuICAgICAgZm9yIChpID0gbGVuZ3RoOyBpLS0gIT09IDA7KSB7XG4gICAgICAgIGlmICghZGVlcEVxdWFsKGFbaV0sIGJbaV0pKSB7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAga2V5cyA9IE9iamVjdC5rZXlzKGEpO1xuICAgIGxlbmd0aCA9IGtleXMubGVuZ3RoO1xuICAgIGlmIChsZW5ndGggIT09IE9iamVjdC5rZXlzKGIpLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBmb3IgKGkgPSBsZW5ndGg7IGktLSAhPT0gMDspIHtcbiAgICAgIGlmICghe30uaGFzT3duUHJvcGVydHkuY2FsbChiLCBrZXlzW2ldKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuICAgIGZvciAoaSA9IGxlbmd0aDsgaS0tICE9PSAwOykge1xuICAgICAgY29uc3Qga2V5ID0ga2V5c1tpXTtcbiAgICAgIGlmIChrZXkgPT09ICdfb3duZXInICYmIGEuJCR0eXBlb2YpIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBpZiAoIWRlZXBFcXVhbChhW2tleV0sIGJba2V5XSkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICByZXR1cm4gYSAhPT0gYSAmJiBiICE9PSBiO1xufVxuXG5mdW5jdGlvbiBnZXREUFIoZWxlbWVudCkge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4gMTtcbiAgfVxuICBjb25zdCB3aW4gPSBlbGVtZW50Lm93bmVyRG9jdW1lbnQuZGVmYXVsdFZpZXcgfHwgd2luZG93O1xuICByZXR1cm4gd2luLmRldmljZVBpeGVsUmF0aW8gfHwgMTtcbn1cblxuZnVuY3Rpb24gcm91bmRCeURQUihlbGVtZW50LCB2YWx1ZSkge1xuICBjb25zdCBkcHIgPSBnZXREUFIoZWxlbWVudCk7XG4gIHJldHVybiBNYXRoLnJvdW5kKHZhbHVlICogZHByKSAvIGRwcjtcbn1cblxuZnVuY3Rpb24gdXNlTGF0ZXN0UmVmKHZhbHVlKSB7XG4gIGNvbnN0IHJlZiA9IFJlYWN0LnVzZVJlZih2YWx1ZSk7XG4gIGluZGV4KCgpID0+IHtcbiAgICByZWYuY3VycmVudCA9IHZhbHVlO1xuICB9KTtcbiAgcmV0dXJuIHJlZjtcbn1cblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRvIHBvc2l0aW9uIGEgZmxvYXRpbmcgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy91c2VGbG9hdGluZ1xuICovXG5mdW5jdGlvbiB1c2VGbG9hdGluZyhvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgY29uc3Qge1xuICAgIHBsYWNlbWVudCA9ICdib3R0b20nLFxuICAgIHN0cmF0ZWd5ID0gJ2Fic29sdXRlJyxcbiAgICBtaWRkbGV3YXJlID0gW10sXG4gICAgcGxhdGZvcm0sXG4gICAgZWxlbWVudHM6IHtcbiAgICAgIHJlZmVyZW5jZTogZXh0ZXJuYWxSZWZlcmVuY2UsXG4gICAgICBmbG9hdGluZzogZXh0ZXJuYWxGbG9hdGluZ1xuICAgIH0gPSB7fSxcbiAgICB0cmFuc2Zvcm0gPSB0cnVlLFxuICAgIHdoaWxlRWxlbWVudHNNb3VudGVkLFxuICAgIG9wZW5cbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IFtkYXRhLCBzZXREYXRhXSA9IFJlYWN0LnVzZVN0YXRlKHtcbiAgICB4OiAwLFxuICAgIHk6IDAsXG4gICAgc3RyYXRlZ3ksXG4gICAgcGxhY2VtZW50LFxuICAgIG1pZGRsZXdhcmVEYXRhOiB7fSxcbiAgICBpc1Bvc2l0aW9uZWQ6IGZhbHNlXG4gIH0pO1xuICBjb25zdCBbbGF0ZXN0TWlkZGxld2FyZSwgc2V0TGF0ZXN0TWlkZGxld2FyZV0gPSBSZWFjdC51c2VTdGF0ZShtaWRkbGV3YXJlKTtcbiAgaWYgKCFkZWVwRXF1YWwobGF0ZXN0TWlkZGxld2FyZSwgbWlkZGxld2FyZSkpIHtcbiAgICBzZXRMYXRlc3RNaWRkbGV3YXJlKG1pZGRsZXdhcmUpO1xuICB9XG4gIGNvbnN0IFtfcmVmZXJlbmNlLCBfc2V0UmVmZXJlbmNlXSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbX2Zsb2F0aW5nLCBfc2V0RmxvYXRpbmddID0gUmVhY3QudXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IHNldFJlZmVyZW5jZSA9IFJlYWN0LnVzZUNhbGxiYWNrKG5vZGUgPT4ge1xuICAgIGlmIChub2RlICE9PSByZWZlcmVuY2VSZWYuY3VycmVudCkge1xuICAgICAgcmVmZXJlbmNlUmVmLmN1cnJlbnQgPSBub2RlO1xuICAgICAgX3NldFJlZmVyZW5jZShub2RlKTtcbiAgICB9XG4gIH0sIFtdKTtcbiAgY29uc3Qgc2V0RmxvYXRpbmcgPSBSZWFjdC51c2VDYWxsYmFjayhub2RlID0+IHtcbiAgICBpZiAobm9kZSAhPT0gZmxvYXRpbmdSZWYuY3VycmVudCkge1xuICAgICAgZmxvYXRpbmdSZWYuY3VycmVudCA9IG5vZGU7XG4gICAgICBfc2V0RmxvYXRpbmcobm9kZSk7XG4gICAgfVxuICB9LCBbXSk7XG4gIGNvbnN0IHJlZmVyZW5jZUVsID0gZXh0ZXJuYWxSZWZlcmVuY2UgfHwgX3JlZmVyZW5jZTtcbiAgY29uc3QgZmxvYXRpbmdFbCA9IGV4dGVybmFsRmxvYXRpbmcgfHwgX2Zsb2F0aW5nO1xuICBjb25zdCByZWZlcmVuY2VSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IGZsb2F0aW5nUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBkYXRhUmVmID0gUmVhY3QudXNlUmVmKGRhdGEpO1xuICBjb25zdCBoYXNXaGlsZUVsZW1lbnRzTW91bnRlZCA9IHdoaWxlRWxlbWVudHNNb3VudGVkICE9IG51bGw7XG4gIGNvbnN0IHdoaWxlRWxlbWVudHNNb3VudGVkUmVmID0gdXNlTGF0ZXN0UmVmKHdoaWxlRWxlbWVudHNNb3VudGVkKTtcbiAgY29uc3QgcGxhdGZvcm1SZWYgPSB1c2VMYXRlc3RSZWYocGxhdGZvcm0pO1xuICBjb25zdCBvcGVuUmVmID0gdXNlTGF0ZXN0UmVmKG9wZW4pO1xuICBjb25zdCB1cGRhdGUgPSBSZWFjdC51c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKCFyZWZlcmVuY2VSZWYuY3VycmVudCB8fCAhZmxvYXRpbmdSZWYuY3VycmVudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjb25maWcgPSB7XG4gICAgICBwbGFjZW1lbnQsXG4gICAgICBzdHJhdGVneSxcbiAgICAgIG1pZGRsZXdhcmU6IGxhdGVzdE1pZGRsZXdhcmVcbiAgICB9O1xuICAgIGlmIChwbGF0Zm9ybVJlZi5jdXJyZW50KSB7XG4gICAgICBjb25maWcucGxhdGZvcm0gPSBwbGF0Zm9ybVJlZi5jdXJyZW50O1xuICAgIH1cbiAgICBjb21wdXRlUG9zaXRpb24ocmVmZXJlbmNlUmVmLmN1cnJlbnQsIGZsb2F0aW5nUmVmLmN1cnJlbnQsIGNvbmZpZykudGhlbihkYXRhID0+IHtcbiAgICAgIGNvbnN0IGZ1bGxEYXRhID0ge1xuICAgICAgICAuLi5kYXRhLFxuICAgICAgICAvLyBUaGUgZmxvYXRpbmcgZWxlbWVudCdzIHBvc2l0aW9uIG1heSBiZSByZWNvbXB1dGVkIHdoaWxlIGl0J3MgY2xvc2VkXG4gICAgICAgIC8vIGJ1dCBzdGlsbCBtb3VudGVkIChzdWNoIGFzIHdoZW4gdHJhbnNpdGlvbmluZyBvdXQpLiBUbyBlbnN1cmVcbiAgICAgICAgLy8gYGlzUG9zaXRpb25lZGAgd2lsbCBiZSBgZmFsc2VgIGluaXRpYWxseSBvbiB0aGUgbmV4dCBvcGVuLCBhdm9pZFxuICAgICAgICAvLyBzZXR0aW5nIGl0IHRvIGB0cnVlYCB3aGVuIGBvcGVuID09PSBmYWxzZWAgKG11c3QgYmUgc3BlY2lmaWVkKS5cbiAgICAgICAgaXNQb3NpdGlvbmVkOiBvcGVuUmVmLmN1cnJlbnQgIT09IGZhbHNlXG4gICAgICB9O1xuICAgICAgaWYgKGlzTW91bnRlZFJlZi5jdXJyZW50ICYmICFkZWVwRXF1YWwoZGF0YVJlZi5jdXJyZW50LCBmdWxsRGF0YSkpIHtcbiAgICAgICAgZGF0YVJlZi5jdXJyZW50ID0gZnVsbERhdGE7XG4gICAgICAgIFJlYWN0RE9NLmZsdXNoU3luYygoKSA9PiB7XG4gICAgICAgICAgc2V0RGF0YShmdWxsRGF0YSk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pO1xuICB9LCBbbGF0ZXN0TWlkZGxld2FyZSwgcGxhY2VtZW50LCBzdHJhdGVneSwgcGxhdGZvcm1SZWYsIG9wZW5SZWZdKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGlmIChvcGVuID09PSBmYWxzZSAmJiBkYXRhUmVmLmN1cnJlbnQuaXNQb3NpdGlvbmVkKSB7XG4gICAgICBkYXRhUmVmLmN1cnJlbnQuaXNQb3NpdGlvbmVkID0gZmFsc2U7XG4gICAgICBzZXREYXRhKGRhdGEgPT4gKHtcbiAgICAgICAgLi4uZGF0YSxcbiAgICAgICAgaXNQb3NpdGlvbmVkOiBmYWxzZVxuICAgICAgfSkpO1xuICAgIH1cbiAgfSwgW29wZW5dKTtcbiAgY29uc3QgaXNNb3VudGVkUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGlzTW91bnRlZFJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaXNNb3VudGVkUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICB9O1xuICB9LCBbXSk7XG4gIGluZGV4KCgpID0+IHtcbiAgICBpZiAocmVmZXJlbmNlRWwpIHJlZmVyZW5jZVJlZi5jdXJyZW50ID0gcmVmZXJlbmNlRWw7XG4gICAgaWYgKGZsb2F0aW5nRWwpIGZsb2F0aW5nUmVmLmN1cnJlbnQgPSBmbG9hdGluZ0VsO1xuICAgIGlmIChyZWZlcmVuY2VFbCAmJiBmbG9hdGluZ0VsKSB7XG4gICAgICBpZiAod2hpbGVFbGVtZW50c01vdW50ZWRSZWYuY3VycmVudCkge1xuICAgICAgICByZXR1cm4gd2hpbGVFbGVtZW50c01vdW50ZWRSZWYuY3VycmVudChyZWZlcmVuY2VFbCwgZmxvYXRpbmdFbCwgdXBkYXRlKTtcbiAgICAgIH1cbiAgICAgIHVwZGF0ZSgpO1xuICAgIH1cbiAgfSwgW3JlZmVyZW5jZUVsLCBmbG9hdGluZ0VsLCB1cGRhdGUsIHdoaWxlRWxlbWVudHNNb3VudGVkUmVmLCBoYXNXaGlsZUVsZW1lbnRzTW91bnRlZF0pO1xuICBjb25zdCByZWZzID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIHJlZmVyZW5jZTogcmVmZXJlbmNlUmVmLFxuICAgIGZsb2F0aW5nOiBmbG9hdGluZ1JlZixcbiAgICBzZXRSZWZlcmVuY2UsXG4gICAgc2V0RmxvYXRpbmdcbiAgfSksIFtzZXRSZWZlcmVuY2UsIHNldEZsb2F0aW5nXSk7XG4gIGNvbnN0IGVsZW1lbnRzID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIHJlZmVyZW5jZTogcmVmZXJlbmNlRWwsXG4gICAgZmxvYXRpbmc6IGZsb2F0aW5nRWxcbiAgfSksIFtyZWZlcmVuY2VFbCwgZmxvYXRpbmdFbF0pO1xuICBjb25zdCBmbG9hdGluZ1N0eWxlcyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIGNvbnN0IGluaXRpYWxTdHlsZXMgPSB7XG4gICAgICBwb3NpdGlvbjogc3RyYXRlZ3ksXG4gICAgICBsZWZ0OiAwLFxuICAgICAgdG9wOiAwXG4gICAgfTtcbiAgICBpZiAoIWVsZW1lbnRzLmZsb2F0aW5nKSB7XG4gICAgICByZXR1cm4gaW5pdGlhbFN0eWxlcztcbiAgICB9XG4gICAgY29uc3QgeCA9IHJvdW5kQnlEUFIoZWxlbWVudHMuZmxvYXRpbmcsIGRhdGEueCk7XG4gICAgY29uc3QgeSA9IHJvdW5kQnlEUFIoZWxlbWVudHMuZmxvYXRpbmcsIGRhdGEueSk7XG4gICAgaWYgKHRyYW5zZm9ybSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uaW5pdGlhbFN0eWxlcyxcbiAgICAgICAgdHJhbnNmb3JtOiBcInRyYW5zbGF0ZShcIiArIHggKyBcInB4LCBcIiArIHkgKyBcInB4KVwiLFxuICAgICAgICAuLi4oZ2V0RFBSKGVsZW1lbnRzLmZsb2F0aW5nKSA+PSAxLjUgJiYge1xuICAgICAgICAgIHdpbGxDaGFuZ2U6ICd0cmFuc2Zvcm0nXG4gICAgICAgIH0pXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgcG9zaXRpb246IHN0cmF0ZWd5LFxuICAgICAgbGVmdDogeCxcbiAgICAgIHRvcDogeVxuICAgIH07XG4gIH0sIFtzdHJhdGVneSwgdHJhbnNmb3JtLCBlbGVtZW50cy5mbG9hdGluZywgZGF0YS54LCBkYXRhLnldKTtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICAuLi5kYXRhLFxuICAgIHVwZGF0ZSxcbiAgICByZWZzLFxuICAgIGVsZW1lbnRzLFxuICAgIGZsb2F0aW5nU3R5bGVzXG4gIH0pLCBbZGF0YSwgdXBkYXRlLCByZWZzLCBlbGVtZW50cywgZmxvYXRpbmdTdHlsZXNdKTtcbn1cblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRvIHBvc2l0aW9uIGFuIGlubmVyIGVsZW1lbnQgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQgc28gdGhhdCBpdFxuICogYXBwZWFycyBjZW50ZXJlZCB0byB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBUaGlzIHdyYXBzIHRoZSBjb3JlIGBhcnJvd2AgbWlkZGxld2FyZSB0byBhbGxvdyBSZWFjdCByZWZzIGFzIHRoZSBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2Fycm93XG4gKi9cbmNvbnN0IGFycm93JDEgPSBvcHRpb25zID0+IHtcbiAgZnVuY3Rpb24gaXNSZWYodmFsdWUpIHtcbiAgICByZXR1cm4ge30uaGFzT3duUHJvcGVydHkuY2FsbCh2YWx1ZSwgJ2N1cnJlbnQnKTtcbiAgfVxuICByZXR1cm4ge1xuICAgIG5hbWU6ICdhcnJvdycsXG4gICAgb3B0aW9ucyxcbiAgICBmbihzdGF0ZSkge1xuICAgICAgY29uc3Qge1xuICAgICAgICBlbGVtZW50LFxuICAgICAgICBwYWRkaW5nXG4gICAgICB9ID0gdHlwZW9mIG9wdGlvbnMgPT09ICdmdW5jdGlvbicgPyBvcHRpb25zKHN0YXRlKSA6IG9wdGlvbnM7XG4gICAgICBpZiAoZWxlbWVudCAmJiBpc1JlZihlbGVtZW50KSkge1xuICAgICAgICBpZiAoZWxlbWVudC5jdXJyZW50ICE9IG51bGwpIHtcbiAgICAgICAgICByZXR1cm4gYXJyb3ckMih7XG4gICAgICAgICAgICBlbGVtZW50OiBlbGVtZW50LmN1cnJlbnQsXG4gICAgICAgICAgICBwYWRkaW5nXG4gICAgICAgICAgfSkuZm4oc3RhdGUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7fTtcbiAgICAgIH1cbiAgICAgIGlmIChlbGVtZW50KSB7XG4gICAgICAgIHJldHVybiBhcnJvdyQyKHtcbiAgICAgICAgICBlbGVtZW50LFxuICAgICAgICAgIHBhZGRpbmdcbiAgICAgICAgfSkuZm4oc3RhdGUpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbiAgfTtcbn07XG5cbi8qKlxuICogTW9kaWZpZXMgdGhlIHBsYWNlbWVudCBieSB0cmFuc2xhdGluZyB0aGUgZmxvYXRpbmcgZWxlbWVudCBhbG9uZyB0aGVcbiAqIHNwZWNpZmllZCBheGVzLlxuICogQSBudW1iZXIgKHNob3J0aGFuZCBmb3IgYG1haW5BeGlzYCBvciBkaXN0YW5jZSksIG9yIGFuIGF4ZXMgY29uZmlndXJhdGlvblxuICogb2JqZWN0IG1heSBiZSBwYXNzZWQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3Mvb2Zmc2V0XG4gKi9cbmNvbnN0IG9mZnNldCA9IChvcHRpb25zLCBkZXBzKSA9PiB7XG4gIGNvbnN0IHJlc3VsdCA9IG9mZnNldCQxKG9wdGlvbnMpO1xuICByZXR1cm4ge1xuICAgIG5hbWU6IHJlc3VsdC5uYW1lLFxuICAgIGZuOiByZXN1bHQuZm4sXG4gICAgb3B0aW9uczogW29wdGlvbnMsIGRlcHNdXG4gIH07XG59O1xuXG4vKipcbiAqIE9wdGltaXplcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBieSBzaGlmdGluZyBpdCBpbiBvcmRlciB0b1xuICoga2VlcCBpdCBpbiB2aWV3IHdoZW4gaXQgd2lsbCBvdmVyZmxvdyB0aGUgY2xpcHBpbmcgYm91bmRhcnkuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3Mvc2hpZnRcbiAqL1xuY29uc3Qgc2hpZnQgPSAob3B0aW9ucywgZGVwcykgPT4ge1xuICBjb25zdCByZXN1bHQgPSBzaGlmdCQxKG9wdGlvbnMpO1xuICByZXR1cm4ge1xuICAgIG5hbWU6IHJlc3VsdC5uYW1lLFxuICAgIGZuOiByZXN1bHQuZm4sXG4gICAgb3B0aW9uczogW29wdGlvbnMsIGRlcHNdXG4gIH07XG59O1xuXG4vKipcbiAqIEJ1aWx0LWluIGBsaW1pdGVyYCB0aGF0IHdpbGwgc3RvcCBgc2hpZnQoKWAgYXQgYSBjZXJ0YWluIHBvaW50LlxuICovXG5jb25zdCBsaW1pdFNoaWZ0ID0gKG9wdGlvbnMsIGRlcHMpID0+IHtcbiAgY29uc3QgcmVzdWx0ID0gbGltaXRTaGlmdCQxKG9wdGlvbnMpO1xuICByZXR1cm4ge1xuICAgIGZuOiByZXN1bHQuZm4sXG4gICAgb3B0aW9uczogW29wdGlvbnMsIGRlcHNdXG4gIH07XG59O1xuXG4vKipcbiAqIE9wdGltaXplcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBieSBmbGlwcGluZyB0aGUgYHBsYWNlbWVudGBcbiAqIGluIG9yZGVyIHRvIGtlZXAgaXQgaW4gdmlldyB3aGVuIHRoZSBwcmVmZXJyZWQgcGxhY2VtZW50KHMpIHdpbGwgb3ZlcmZsb3cgdGhlXG4gKiBjbGlwcGluZyBib3VuZGFyeS4gQWx0ZXJuYXRpdmUgdG8gYGF1dG9QbGFjZW1lbnRgLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2ZsaXBcbiAqL1xuY29uc3QgZmxpcCA9IChvcHRpb25zLCBkZXBzKSA9PiB7XG4gIGNvbnN0IHJlc3VsdCA9IGZsaXAkMShvcHRpb25zKTtcbiAgcmV0dXJuIHtcbiAgICBuYW1lOiByZXN1bHQubmFtZSxcbiAgICBmbjogcmVzdWx0LmZuLFxuICAgIG9wdGlvbnM6IFtvcHRpb25zLCBkZXBzXVxuICB9O1xufTtcblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRoYXQgYWxsb3dzIHlvdSB0byBjaGFuZ2UgdGhlIHNpemUgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQg4oCUXG4gKiBmb3IgaW5zdGFuY2UsIHByZXZlbnQgaXQgZnJvbSBvdmVyZmxvd2luZyB0aGUgY2xpcHBpbmcgYm91bmRhcnkgb3IgbWF0Y2ggdGhlXG4gKiB3aWR0aCBvZiB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3Mvc2l6ZVxuICovXG5jb25zdCBzaXplID0gKG9wdGlvbnMsIGRlcHMpID0+IHtcbiAgY29uc3QgcmVzdWx0ID0gc2l6ZSQxKG9wdGlvbnMpO1xuICByZXR1cm4ge1xuICAgIG5hbWU6IHJlc3VsdC5uYW1lLFxuICAgIGZuOiByZXN1bHQuZm4sXG4gICAgb3B0aW9uczogW29wdGlvbnMsIGRlcHNdXG4gIH07XG59O1xuXG4vKipcbiAqIE9wdGltaXplcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBieSBjaG9vc2luZyB0aGUgcGxhY2VtZW50XG4gKiB0aGF0IGhhcyB0aGUgbW9zdCBzcGFjZSBhdmFpbGFibGUgYXV0b21hdGljYWxseSwgd2l0aG91dCBuZWVkaW5nIHRvIHNwZWNpZnkgYVxuICogcHJlZmVycmVkIHBsYWNlbWVudC4gQWx0ZXJuYXRpdmUgdG8gYGZsaXBgLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2F1dG9QbGFjZW1lbnRcbiAqL1xuY29uc3QgYXV0b1BsYWNlbWVudCA9IChvcHRpb25zLCBkZXBzKSA9PiB7XG4gIGNvbnN0IHJlc3VsdCA9IGF1dG9QbGFjZW1lbnQkMShvcHRpb25zKTtcbiAgcmV0dXJuIHtcbiAgICBuYW1lOiByZXN1bHQubmFtZSxcbiAgICBmbjogcmVzdWx0LmZuLFxuICAgIG9wdGlvbnM6IFtvcHRpb25zLCBkZXBzXVxuICB9O1xufTtcblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRvIGhpZGUgdGhlIGZsb2F0aW5nIGVsZW1lbnQgaW4gYXBwbGljYWJsZSBzaXR1YXRpb25zLCBzdWNoIGFzXG4gKiB3aGVuIGl0IGlzIG5vdCBpbiB0aGUgc2FtZSBjbGlwcGluZyBjb250ZXh0IGFzIHRoZSByZWZlcmVuY2UgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9oaWRlXG4gKi9cbmNvbnN0IGhpZGUgPSAob3B0aW9ucywgZGVwcykgPT4ge1xuICBjb25zdCByZXN1bHQgPSBoaWRlJDEob3B0aW9ucyk7XG4gIHJldHVybiB7XG4gICAgbmFtZTogcmVzdWx0Lm5hbWUsXG4gICAgZm46IHJlc3VsdC5mbixcbiAgICBvcHRpb25zOiBbb3B0aW9ucywgZGVwc11cbiAgfTtcbn07XG5cbi8qKlxuICogUHJvdmlkZXMgaW1wcm92ZWQgcG9zaXRpb25pbmcgZm9yIGlubGluZSByZWZlcmVuY2UgZWxlbWVudHMgdGhhdCBjYW4gc3BhblxuICogb3ZlciBtdWx0aXBsZSBsaW5lcywgc3VjaCBhcyBoeXBlcmxpbmtzIG9yIHJhbmdlIHNlbGVjdGlvbnMuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvaW5saW5lXG4gKi9cbmNvbnN0IGlubGluZSA9IChvcHRpb25zLCBkZXBzKSA9PiB7XG4gIGNvbnN0IHJlc3VsdCA9IGlubGluZSQxKG9wdGlvbnMpO1xuICByZXR1cm4ge1xuICAgIG5hbWU6IHJlc3VsdC5uYW1lLFxuICAgIGZuOiByZXN1bHQuZm4sXG4gICAgb3B0aW9uczogW29wdGlvbnMsIGRlcHNdXG4gIH07XG59O1xuXG4vKipcbiAqIFByb3ZpZGVzIGRhdGEgdG8gcG9zaXRpb24gYW4gaW5uZXIgZWxlbWVudCBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBzbyB0aGF0IGl0XG4gKiBhcHBlYXJzIGNlbnRlcmVkIHRvIHRoZSByZWZlcmVuY2UgZWxlbWVudC5cbiAqIFRoaXMgd3JhcHMgdGhlIGNvcmUgYGFycm93YCBtaWRkbGV3YXJlIHRvIGFsbG93IFJlYWN0IHJlZnMgYXMgdGhlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvYXJyb3dcbiAqL1xuY29uc3QgYXJyb3cgPSAob3B0aW9ucywgZGVwcykgPT4ge1xuICBjb25zdCByZXN1bHQgPSBhcnJvdyQxKG9wdGlvbnMpO1xuICByZXR1cm4ge1xuICAgIG5hbWU6IHJlc3VsdC5uYW1lLFxuICAgIGZuOiByZXN1bHQuZm4sXG4gICAgb3B0aW9uczogW29wdGlvbnMsIGRlcHNdXG4gIH07XG59O1xuXG5leHBvcnQgeyBhcnJvdywgYXV0b1BsYWNlbWVudCwgZmxpcCwgaGlkZSwgaW5saW5lLCBsaW1pdFNoaWZ0LCBvZmZzZXQsIHNoaWZ0LCBzaXplLCB1c2VGbG9hdGluZyB9O1xuIiwidmFyIF9fZGVmUHJvcCA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX25hbWUgPSAodGFyZ2V0LCB2YWx1ZSkgPT4gX19kZWZQcm9wKHRhcmdldCwgXCJuYW1lXCIsIHsgdmFsdWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSB9KTtcblxuLy8gc3JjL2Fycm93LnRzeFxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBQcmltaXRpdmUgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXByaW1pdGl2ZVwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG52YXIgQXJyb3cgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBBcnJvdzIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHsgY2hpbGRyZW4sIHdpZHRoID0gMTAsIGhlaWdodCA9IDUsIC4uLmFycm93UHJvcHMgfSA9IHByb3BzO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgUHJpbWl0aXZlLnN2ZyxcbiAgICAgIHtcbiAgICAgICAgLi4uYXJyb3dQcm9wcyxcbiAgICAgICAgcmVmOiBmb3J3YXJkZWRSZWYsXG4gICAgICAgIHdpZHRoLFxuICAgICAgICBoZWlnaHQsXG4gICAgICAgIHZpZXdCb3g6IFwiMCAwIDMwIDEwXCIsXG4gICAgICAgIHByZXNlcnZlQXNwZWN0UmF0aW86IFwibm9uZVwiLFxuICAgICAgICBjaGlsZHJlbjogcHJvcHMuYXNDaGlsZCA/IGNoaWxkcmVuIDogLyogQF9fUFVSRV9fICovIGpzeChcInBvbHlnb25cIiwgeyBwb2ludHM6IFwiMCwwIDMwLDAgMTUsMTBcIiB9KVxuICAgICAgfVxuICAgICk7XG4gIH0sIFwiQXJyb3dcIilcbik7XG52YXIgUm9vdCA9IEFycm93O1xuZXhwb3J0IHtcbiAgQXJyb3csXG4gIFJvb3Rcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5tanMubWFwXG4iLCJcInVzZSBjbGllbnRcIjtcbnZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19uYW1lID0gKHRhcmdldCwgdmFsdWUpID0+IF9fZGVmUHJvcCh0YXJnZXQsIFwibmFtZVwiLCB7IHZhbHVlLCBjb25maWd1cmFibGU6IHRydWUgfSk7XG5cbi8vIHNyYy9wb3BwZXIudHN4XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7XG4gIHVzZUZsb2F0aW5nLFxuICBhdXRvVXBkYXRlLFxuICBvZmZzZXQsXG4gIHNoaWZ0LFxuICBsaW1pdFNoaWZ0LFxuICBoaWRlLFxuICBhcnJvdyBhcyBmbG9hdGluZ1VJYXJyb3csXG4gIGZsaXAsXG4gIHNpemVcbn0gZnJvbSBcIkBmbG9hdGluZy11aS9yZWFjdC1kb21cIjtcbmltcG9ydCAqIGFzIEFycm93UHJpbWl0aXZlIGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtYXJyb3dcIjtcbmltcG9ydCB7IHVzZUNvbXBvc2VkUmVmcyB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtY29tcG9zZS1yZWZzXCI7XG5pbXBvcnQgeyBjcmVhdGVDb250ZXh0U2NvcGUgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LWNvbnRleHRcIjtcbmltcG9ydCB7IFByaW1pdGl2ZSB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtcHJpbWl0aXZlXCI7XG5pbXBvcnQgeyB1c2VDYWxsYmFja1JlZiB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtdXNlLWNhbGxiYWNrLXJlZlwiO1xuaW1wb3J0IHsgdXNlTGF5b3V0RWZmZWN0IH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC11c2UtbGF5b3V0LWVmZmVjdFwiO1xuaW1wb3J0IHsgdXNlU2l6ZSB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtdXNlLXNpemVcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xudmFyIFNJREVfT1BUSU9OUyA9IFtcInRvcFwiLCBcInJpZ2h0XCIsIFwiYm90dG9tXCIsIFwibGVmdFwiXTtcbnZhciBBTElHTl9PUFRJT05TID0gW1wic3RhcnRcIiwgXCJjZW50ZXJcIiwgXCJlbmRcIl07XG52YXIgUE9QUEVSX05BTUUgPSBcIlBvcHBlclwiO1xudmFyIFtjcmVhdGVQb3BwZXJDb250ZXh0LCBjcmVhdGVQb3BwZXJTY29wZV0gPSBjcmVhdGVDb250ZXh0U2NvcGUoUE9QUEVSX05BTUUpO1xudmFyIFtQb3BwZXJQcm92aWRlciwgdXNlUG9wcGVyQ29udGV4dF0gPSBjcmVhdGVQb3BwZXJDb250ZXh0KFBPUFBFUl9OQU1FKTtcbnZhciBQb3BwZXIgPSAvKiBAX19QVVJFX18gKi8gX19uYW1lKChwcm9wcykgPT4ge1xuICBjb25zdCB7IF9fc2NvcGVQb3BwZXIsIGNoaWxkcmVuIH0gPSBwcm9wcztcbiAgY29uc3QgW2FuY2hvciwgc2V0QW5jaG9yXSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbcGxhY2VtZW50U3RhdGUsIHNldFBsYWNlbWVudFN0YXRlXSA9IFJlYWN0LnVzZVN0YXRlKHZvaWQgMCk7XG4gIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgIFBvcHBlclByb3ZpZGVyLFxuICAgIHtcbiAgICAgIHNjb3BlOiBfX3Njb3BlUG9wcGVyLFxuICAgICAgYW5jaG9yLFxuICAgICAgb25BbmNob3JDaGFuZ2U6IHNldEFuY2hvcixcbiAgICAgIHBsYWNlbWVudFN0YXRlLFxuICAgICAgc2V0UGxhY2VtZW50U3RhdGUsXG4gICAgICBjaGlsZHJlblxuICAgIH1cbiAgKTtcbn0sIFwiUG9wcGVyXCIpO1xudmFyIEFOQ0hPUl9OQU1FID0gXCJQb3BwZXJBbmNob3JcIjtcbnZhciBQb3BwZXJBbmNob3IgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBQb3BwZXJBbmNob3IyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCB7IF9fc2NvcGVQb3BwZXIsIHZpcnR1YWxSZWYsIC4uLmFuY2hvclByb3BzIH0gPSBwcm9wcztcbiAgICBjb25zdCBjb250ZXh0ID0gdXNlUG9wcGVyQ29udGV4dChBTkNIT1JfTkFNRSwgX19zY29wZVBvcHBlcik7XG4gICAgY29uc3QgcmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICAgIGNvbnN0IG9uQW5jaG9yQ2hhbmdlID0gY29udGV4dC5vbkFuY2hvckNoYW5nZTtcbiAgICBjb25zdCBjYWxsYmFja1JlZiA9IFJlYWN0LnVzZUNhbGxiYWNrKFxuICAgICAgKG5vZGUpID0+IHtcbiAgICAgICAgcmVmLmN1cnJlbnQgPSBub2RlO1xuICAgICAgICBpZiAobm9kZSkge1xuICAgICAgICAgIG9uQW5jaG9yQ2hhbmdlKG5vZGUpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgW29uQW5jaG9yQ2hhbmdlXVxuICAgICk7XG4gICAgY29uc3QgY29tcG9zZWRSZWZzID0gdXNlQ29tcG9zZWRSZWZzKGZvcndhcmRlZFJlZiwgY2FsbGJhY2tSZWYpO1xuICAgIGNvbnN0IGFuY2hvclJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgaWYgKCF2aXJ0dWFsUmVmKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHByZXZpb3VzQW5jaG9yID0gYW5jaG9yUmVmLmN1cnJlbnQ7XG4gICAgICBhbmNob3JSZWYuY3VycmVudCA9IHZpcnR1YWxSZWYuY3VycmVudDtcbiAgICAgIGlmIChwcmV2aW91c0FuY2hvciAhPT0gYW5jaG9yUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgb25BbmNob3JDaGFuZ2UoYW5jaG9yUmVmLmN1cnJlbnQpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIGNvbnN0IHNpZGVBbmRBbGlnbiA9IGNvbnRleHQucGxhY2VtZW50U3RhdGUgJiYgZ2V0U2lkZUFuZEFsaWduRnJvbVBsYWNlbWVudChjb250ZXh0LnBsYWNlbWVudFN0YXRlKTtcbiAgICBjb25zdCBwbGFjZWRTaWRlID0gc2lkZUFuZEFsaWduPy5bMF07XG4gICAgY29uc3QgcGxhY2VkQWxpZ24gPSBzaWRlQW5kQWxpZ24/LlsxXTtcbiAgICByZXR1cm4gdmlydHVhbFJlZiA/IG51bGwgOiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgUHJpbWl0aXZlLmRpdixcbiAgICAgIHtcbiAgICAgICAgXCJkYXRhLXJhZGl4LXBvcHBlci1zaWRlXCI6IHBsYWNlZFNpZGUsXG4gICAgICAgIFwiZGF0YS1yYWRpeC1wb3BwZXItYWxpZ25cIjogcGxhY2VkQWxpZ24sXG4gICAgICAgIC4uLmFuY2hvclByb3BzLFxuICAgICAgICByZWY6IGNvbXBvc2VkUmVmc1xuICAgICAgfVxuICAgICk7XG4gIH0sIFwiUG9wcGVyQW5jaG9yXCIpXG4pO1xudmFyIENPTlRFTlRfTkFNRSA9IFwiUG9wcGVyQ29udGVudFwiO1xudmFyIFtQb3BwZXJDb250ZW50UHJvdmlkZXIsIHVzZUNvbnRlbnRDb250ZXh0XSA9IGNyZWF0ZVBvcHBlckNvbnRleHQoQ09OVEVOVF9OQU1FKTtcbnZhciBQb3BwZXJDb250ZW50ID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gUG9wcGVyQ29udGVudDIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHtcbiAgICAgIF9fc2NvcGVQb3BwZXIsXG4gICAgICBzaWRlID0gXCJib3R0b21cIixcbiAgICAgIHNpZGVPZmZzZXQgPSAwLFxuICAgICAgYWxpZ24gPSBcImNlbnRlclwiLFxuICAgICAgYWxpZ25PZmZzZXQgPSAwLFxuICAgICAgYXJyb3dQYWRkaW5nID0gMCxcbiAgICAgIGF2b2lkQ29sbGlzaW9ucyA9IHRydWUsXG4gICAgICBjb2xsaXNpb25Cb3VuZGFyeSA9IFtdLFxuICAgICAgY29sbGlzaW9uUGFkZGluZzogY29sbGlzaW9uUGFkZGluZ1Byb3AgPSAwLFxuICAgICAgc3RpY2t5ID0gXCJwYXJ0aWFsXCIsXG4gICAgICBoaWRlV2hlbkRldGFjaGVkID0gZmFsc2UsXG4gICAgICB1cGRhdGVQb3NpdGlvblN0cmF0ZWd5ID0gXCJvcHRpbWl6ZWRcIixcbiAgICAgIG9uUGxhY2VkLFxuICAgICAgLi4uY29udGVudFByb3BzXG4gICAgfSA9IHByb3BzO1xuICAgIGNvbnN0IGNvbnRleHQgPSB1c2VQb3BwZXJDb250ZXh0KENPTlRFTlRfTkFNRSwgX19zY29wZVBvcHBlcik7XG4gICAgY29uc3QgW2NvbnRlbnQsIHNldENvbnRlbnRdID0gUmVhY3QudXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgY29tcG9zZWRSZWZzID0gdXNlQ29tcG9zZWRSZWZzKGZvcndhcmRlZFJlZiwgc2V0Q29udGVudCk7XG4gICAgY29uc3QgW2Fycm93LCBzZXRBcnJvd10gPSBSZWFjdC51c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBhcnJvd1NpemUgPSB1c2VTaXplKGFycm93KTtcbiAgICBjb25zdCBhcnJvd1dpZHRoID0gYXJyb3dTaXplPy53aWR0aCA/PyAwO1xuICAgIGNvbnN0IGFycm93SGVpZ2h0ID0gYXJyb3dTaXplPy5oZWlnaHQgPz8gMDtcbiAgICBjb25zdCBkZXNpcmVkUGxhY2VtZW50ID0gc2lkZSArIChhbGlnbiAhPT0gXCJjZW50ZXJcIiA/IFwiLVwiICsgYWxpZ24gOiBcIlwiKTtcbiAgICBjb25zdCBjb2xsaXNpb25QYWRkaW5nID0gdHlwZW9mIGNvbGxpc2lvblBhZGRpbmdQcm9wID09PSBcIm51bWJlclwiID8gY29sbGlzaW9uUGFkZGluZ1Byb3AgOiB7IHRvcDogMCwgcmlnaHQ6IDAsIGJvdHRvbTogMCwgbGVmdDogMCwgLi4uY29sbGlzaW9uUGFkZGluZ1Byb3AgfTtcbiAgICBjb25zdCBib3VuZGFyeSA9IEFycmF5LmlzQXJyYXkoY29sbGlzaW9uQm91bmRhcnkpID8gY29sbGlzaW9uQm91bmRhcnkgOiBbY29sbGlzaW9uQm91bmRhcnldO1xuICAgIGNvbnN0IGhhc0V4cGxpY2l0Qm91bmRhcmllcyA9IGJvdW5kYXJ5Lmxlbmd0aCA+IDA7XG4gICAgY29uc3QgZGV0ZWN0T3ZlcmZsb3dPcHRpb25zID0ge1xuICAgICAgcGFkZGluZzogY29sbGlzaW9uUGFkZGluZyxcbiAgICAgIGJvdW5kYXJ5OiBib3VuZGFyeS5maWx0ZXIoaXNOb3ROdWxsKSxcbiAgICAgIC8vIHdpdGggYHN0cmF0ZWd5OiAnZml4ZWQnYCwgdGhpcyBpcyB0aGUgb25seSB3YXkgdG8gZ2V0IGl0IHRvIHJlc3BlY3QgYm91bmRhcmllc1xuICAgICAgYWx0Qm91bmRhcnk6IGhhc0V4cGxpY2l0Qm91bmRhcmllc1xuICAgIH07XG4gICAgY29uc3QgeyByZWZzLCBmbG9hdGluZ1N0eWxlcywgcGxhY2VtZW50LCBpc1Bvc2l0aW9uZWQsIG1pZGRsZXdhcmVEYXRhIH0gPSB1c2VGbG9hdGluZyh7XG4gICAgICAvLyBkZWZhdWx0IHRvIGBmaXhlZGAgc3RyYXRlZ3kgc28gdXNlcnMgZG9uJ3QgaGF2ZSB0byBwaWNrIGFuZCB3ZSBhbHNvIGF2b2lkIGZvY3VzIHNjcm9sbCBpc3N1ZXNcbiAgICAgIHN0cmF0ZWd5OiBcImZpeGVkXCIsXG4gICAgICBwbGFjZW1lbnQ6IGRlc2lyZWRQbGFjZW1lbnQsXG4gICAgICB3aGlsZUVsZW1lbnRzTW91bnRlZDogLyogQF9fUFVSRV9fICovIF9fbmFtZSgoLi4uYXJncykgPT4ge1xuICAgICAgICBjb25zdCBjbGVhbnVwID0gYXV0b1VwZGF0ZSguLi5hcmdzLCB7XG4gICAgICAgICAgYW5pbWF0aW9uRnJhbWU6IHVwZGF0ZVBvc2l0aW9uU3RyYXRlZ3kgPT09IFwiYWx3YXlzXCJcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBjbGVhbnVwO1xuICAgICAgfSwgXCJ3aGlsZUVsZW1lbnRzTW91bnRlZFwiKSxcbiAgICAgIGVsZW1lbnRzOiB7XG4gICAgICAgIHJlZmVyZW5jZTogY29udGV4dC5hbmNob3JcbiAgICAgIH0sXG4gICAgICBtaWRkbGV3YXJlOiBbXG4gICAgICAgIG9mZnNldCh7IG1haW5BeGlzOiBzaWRlT2Zmc2V0ICsgYXJyb3dIZWlnaHQsIGFsaWdubWVudEF4aXM6IGFsaWduT2Zmc2V0IH0pLFxuICAgICAgICBhdm9pZENvbGxpc2lvbnMgJiYgc2hpZnQoe1xuICAgICAgICAgIG1haW5BeGlzOiB0cnVlLFxuICAgICAgICAgIGNyb3NzQXhpczogZmFsc2UsXG4gICAgICAgICAgbGltaXRlcjogc3RpY2t5ID09PSBcInBhcnRpYWxcIiA/IGxpbWl0U2hpZnQoKSA6IHZvaWQgMCxcbiAgICAgICAgICAuLi5kZXRlY3RPdmVyZmxvd09wdGlvbnNcbiAgICAgICAgfSksXG4gICAgICAgIGF2b2lkQ29sbGlzaW9ucyAmJiBmbGlwKHsgLi4uZGV0ZWN0T3ZlcmZsb3dPcHRpb25zIH0pLFxuICAgICAgICBzaXplKHtcbiAgICAgICAgICAuLi5kZXRlY3RPdmVyZmxvd09wdGlvbnMsXG4gICAgICAgICAgYXBwbHk6IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKHsgZWxlbWVudHMsIHJlY3RzLCBhdmFpbGFibGVXaWR0aCwgYXZhaWxhYmxlSGVpZ2h0IH0pID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHsgd2lkdGg6IGFuY2hvcldpZHRoLCBoZWlnaHQ6IGFuY2hvckhlaWdodCB9ID0gcmVjdHMucmVmZXJlbmNlO1xuICAgICAgICAgICAgY29uc3QgY29udGVudFN0eWxlID0gZWxlbWVudHMuZmxvYXRpbmcuc3R5bGU7XG4gICAgICAgICAgICBjb250ZW50U3R5bGUuc2V0UHJvcGVydHkoXCItLXJhZGl4LXBvcHBlci1hdmFpbGFibGUtd2lkdGhcIiwgYCR7YXZhaWxhYmxlV2lkdGh9cHhgKTtcbiAgICAgICAgICAgIGNvbnRlbnRTdHlsZS5zZXRQcm9wZXJ0eShcIi0tcmFkaXgtcG9wcGVyLWF2YWlsYWJsZS1oZWlnaHRcIiwgYCR7YXZhaWxhYmxlSGVpZ2h0fXB4YCk7XG4gICAgICAgICAgICBjb250ZW50U3R5bGUuc2V0UHJvcGVydHkoXCItLXJhZGl4LXBvcHBlci1hbmNob3Itd2lkdGhcIiwgYCR7YW5jaG9yV2lkdGh9cHhgKTtcbiAgICAgICAgICAgIGNvbnRlbnRTdHlsZS5zZXRQcm9wZXJ0eShcIi0tcmFkaXgtcG9wcGVyLWFuY2hvci1oZWlnaHRcIiwgYCR7YW5jaG9ySGVpZ2h0fXB4YCk7XG4gICAgICAgICAgfSwgXCJhcHBseVwiKVxuICAgICAgICB9KSxcbiAgICAgICAgYXJyb3cgJiYgZmxvYXRpbmdVSWFycm93KHsgZWxlbWVudDogYXJyb3csIHBhZGRpbmc6IGFycm93UGFkZGluZyB9KSxcbiAgICAgICAgdHJhbnNmb3JtT3JpZ2luKHsgYXJyb3dXaWR0aCwgYXJyb3dIZWlnaHQgfSksXG4gICAgICAgIGhpZGVXaGVuRGV0YWNoZWQgJiYgaGlkZSh7XG4gICAgICAgICAgc3RyYXRlZ3k6IFwicmVmZXJlbmNlSGlkZGVuXCIsXG4gICAgICAgICAgLi4uZGV0ZWN0T3ZlcmZsb3dPcHRpb25zLFxuICAgICAgICAgIC8vIGBoaWRlYCBkZXRlY3RzIHdoZXRoZXIgdGhlIGFuY2hvciAocmVmZXJlbmNlKSBpcyBjbGlwcGVkLCBzbyB3aGVuXG4gICAgICAgICAgLy8gbm8gZXhwbGljaXQgYGNvbGxpc2lvbkJvdW5kYXJ5YCBpcyBzZXQgd2UgZmFsbCBiYWNrIHRvIEZsb2F0aW5nXG4gICAgICAgICAgLy8gVUkncyBkZWZhdWx0IGNsaXBwaW5nIGFuY2VzdG9ycyAoZS5nLiBhIHNjcm9sbGFibGUgbWVudSkuIFRoaXNcbiAgICAgICAgICAvLyBsZXRzIGFuIG9jY2x1ZGVkIHN1Ym1lbnUgaGlkZSBvbmNlIGl0cyBhbmNob3Igc2Nyb2xscyBvdXQgb2Ygdmlld1xuICAgICAgICAgIC8vICgjMzIzNykuIFRoZSBjb2xsaXNpb24vc2l6ZSBtaWRkbGV3YXJlcyBkZWxpYmVyYXRlbHkga2VlcCB0aGVcbiAgICAgICAgICAvLyB2aWV3cG9ydC1iYXNlZCBkZWZhdWx0IHRvIGF2b2lkIGNsYW1waW5nIGNvbnRlbnQgcmVuZGVyZWQgaW5zaWRlXG4gICAgICAgICAgLy8gdHJhbnNmb3JtZWQgb3Igb3ZlcmZsb3ctY2xpcHBpbmcgcG9ydGFsIGNvbnRhaW5lcnMuXG4gICAgICAgICAgYm91bmRhcnk6IGhhc0V4cGxpY2l0Qm91bmRhcmllcyA/IGRldGVjdE92ZXJmbG93T3B0aW9ucy5ib3VuZGFyeSA6IHZvaWQgMFxuICAgICAgICB9KVxuICAgICAgXVxuICAgIH0pO1xuICAgIGNvbnN0IHNldFBsYWNlbWVudFN0YXRlID0gY29udGV4dC5zZXRQbGFjZW1lbnRTdGF0ZTtcbiAgICB1c2VMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgc2V0UGxhY2VtZW50U3RhdGUocGxhY2VtZW50KTtcbiAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgIHNldFBsYWNlbWVudFN0YXRlKHZvaWQgMCk7XG4gICAgICB9O1xuICAgIH0sIFtwbGFjZW1lbnQsIHNldFBsYWNlbWVudFN0YXRlXSk7XG4gICAgY29uc3QgW3BsYWNlZFNpZGUsIHBsYWNlZEFsaWduXSA9IGdldFNpZGVBbmRBbGlnbkZyb21QbGFjZW1lbnQocGxhY2VtZW50KTtcbiAgICBjb25zdCBoYW5kbGVQbGFjZWQgPSB1c2VDYWxsYmFja1JlZihvblBsYWNlZCk7XG4gICAgdXNlTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAgIGlmIChpc1Bvc2l0aW9uZWQpIHtcbiAgICAgICAgaGFuZGxlUGxhY2VkPy4oKTtcbiAgICAgIH1cbiAgICB9LCBbaXNQb3NpdGlvbmVkLCBoYW5kbGVQbGFjZWRdKTtcbiAgICBjb25zdCBhcnJvd1ggPSBtaWRkbGV3YXJlRGF0YS5hcnJvdz8ueDtcbiAgICBjb25zdCBhcnJvd1kgPSBtaWRkbGV3YXJlRGF0YS5hcnJvdz8ueTtcbiAgICBjb25zdCBjYW5ub3RDZW50ZXJBcnJvdyA9IG1pZGRsZXdhcmVEYXRhLmFycm93Py5jZW50ZXJPZmZzZXQgIT09IDA7XG4gICAgY29uc3QgW2NvbnRlbnRaSW5kZXgsIHNldENvbnRlbnRaSW5kZXhdID0gUmVhY3QudXNlU3RhdGUoKTtcbiAgICB1c2VMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgaWYgKGNvbnRlbnQpIHNldENvbnRlbnRaSW5kZXgod2luZG93LmdldENvbXB1dGVkU3R5bGUoY29udGVudCkuekluZGV4KTtcbiAgICB9LCBbY29udGVudF0pO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgXCJkaXZcIixcbiAgICAgIHtcbiAgICAgICAgcmVmOiByZWZzLnNldEZsb2F0aW5nLFxuICAgICAgICBcImRhdGEtcmFkaXgtcG9wcGVyLWNvbnRlbnQtd3JhcHBlclwiOiBcIlwiLFxuICAgICAgICBzdHlsZToge1xuICAgICAgICAgIC4uLmZsb2F0aW5nU3R5bGVzLFxuICAgICAgICAgIHRyYW5zZm9ybTogaXNQb3NpdGlvbmVkID8gZmxvYXRpbmdTdHlsZXMudHJhbnNmb3JtIDogXCJ0cmFuc2xhdGUoMCwgLTIwMCUpXCIsXG4gICAgICAgICAgLy8ga2VlcCBvZmYgdGhlIHBhZ2Ugd2hlbiBtZWFzdXJpbmdcbiAgICAgICAgICBtaW5XaWR0aDogXCJtYXgtY29udGVudFwiLFxuICAgICAgICAgIHpJbmRleDogY29udGVudFpJbmRleCxcbiAgICAgICAgICBcIi0tcmFkaXgtcG9wcGVyLXRyYW5zZm9ybS1vcmlnaW5cIjogW1xuICAgICAgICAgICAgbWlkZGxld2FyZURhdGEudHJhbnNmb3JtT3JpZ2luPy54LFxuICAgICAgICAgICAgbWlkZGxld2FyZURhdGEudHJhbnNmb3JtT3JpZ2luPy55XG4gICAgICAgICAgXS5qb2luKFwiIFwiKSxcbiAgICAgICAgICAvLyBoaWRlIHRoZSBjb250ZW50IGlmIHVzaW5nIHRoZSBoaWRlIG1pZGRsZXdhcmUgYW5kIHNob3VsZCBiZSBoaWRkZW5cbiAgICAgICAgICAvLyBzZXQgdmlzaWJpbGl0eSB0byBoaWRkZW4gYW5kIGRpc2FibGUgcG9pbnRlciBldmVudHMgc28gdGhlIFVJIGJlaGF2ZXNcbiAgICAgICAgICAvLyBhcyBpZiB0aGUgUG9wcGVyQ29udGVudCBpc24ndCB0aGVyZSBhdCBhbGxcbiAgICAgICAgICAuLi5taWRkbGV3YXJlRGF0YS5oaWRlPy5yZWZlcmVuY2VIaWRkZW4gJiYge1xuICAgICAgICAgICAgdmlzaWJpbGl0eTogXCJoaWRkZW5cIixcbiAgICAgICAgICAgIHBvaW50ZXJFdmVudHM6IFwibm9uZVwiXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBkaXI6IHByb3BzLmRpcixcbiAgICAgICAgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgICAgICAgUG9wcGVyQ29udGVudFByb3ZpZGVyLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHNjb3BlOiBfX3Njb3BlUG9wcGVyLFxuICAgICAgICAgICAgcGxhY2VkU2lkZSxcbiAgICAgICAgICAgIHBsYWNlZEFsaWduLFxuICAgICAgICAgICAgb25BcnJvd0NoYW5nZTogc2V0QXJyb3csXG4gICAgICAgICAgICBhcnJvd1gsXG4gICAgICAgICAgICBhcnJvd1ksXG4gICAgICAgICAgICBzaG91bGRIaWRlQXJyb3c6IGNhbm5vdENlbnRlckFycm93LFxuICAgICAgICAgICAgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgICAgICAgICAgIFByaW1pdGl2ZS5kaXYsXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBcImRhdGEtc2lkZVwiOiBwbGFjZWRTaWRlLFxuICAgICAgICAgICAgICAgIFwiZGF0YS1hbGlnblwiOiBwbGFjZWRBbGlnbixcbiAgICAgICAgICAgICAgICAuLi5jb250ZW50UHJvcHMsXG4gICAgICAgICAgICAgICAgcmVmOiBjb21wb3NlZFJlZnMsXG4gICAgICAgICAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICAgICAgICAgIC4uLmNvbnRlbnRQcm9wcy5zdHlsZSxcbiAgICAgICAgICAgICAgICAgIC8vIGlmIHRoZSBQb3BwZXJDb250ZW50IGhhc24ndCBiZWVuIHBsYWNlZCB5ZXQgKG5vdCBhbGxcbiAgICAgICAgICAgICAgICAgIC8vIG1lYXN1cmVtZW50cyBkb25lKSB3ZSBwcmV2ZW50IGFuaW1hdGlvbnMgc28gdGhhdCB1c2VycydcbiAgICAgICAgICAgICAgICAgIC8vIGFuaW1hdGlvbnMgZG9uJ3Qga2ljayBpbiB0b28gZWFybHkgZnJvbSB0aGUgd3Jvbmcgc2lkZXMuXG4gICAgICAgICAgICAgICAgICBhbmltYXRpb246ICFpc1Bvc2l0aW9uZWQgPyBcIm5vbmVcIiA6IGNvbnRlbnRQcm9wcy5zdHlsZT8uYW5pbWF0aW9uXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG4gICAgICAgICAgfVxuICAgICAgICApXG4gICAgICB9XG4gICAgKTtcbiAgfSwgXCJQb3BwZXJDb250ZW50XCIpXG4pO1xudmFyIEFSUk9XX05BTUUgPSBcIlBvcHBlckFycm93XCI7XG52YXIgT1BQT1NJVEVfU0lERSA9IHtcbiAgdG9wOiBcImJvdHRvbVwiLFxuICByaWdodDogXCJsZWZ0XCIsXG4gIGJvdHRvbTogXCJ0b3BcIixcbiAgbGVmdDogXCJyaWdodFwiXG59O1xudmFyIFBvcHBlckFycm93ID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gUG9wcGVyQXJyb3cyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCB7IF9fc2NvcGVQb3BwZXIsIC4uLmFycm93UHJvcHMgfSA9IHByb3BzO1xuICAgIGNvbnN0IGNvbnRlbnRDb250ZXh0ID0gdXNlQ29udGVudENvbnRleHQoQVJST1dfTkFNRSwgX19zY29wZVBvcHBlcik7XG4gICAgY29uc3QgYmFzZVNpZGUgPSBPUFBPU0lURV9TSURFW2NvbnRlbnRDb250ZXh0LnBsYWNlZFNpZGVdO1xuICAgIHJldHVybiAoXG4gICAgICAvLyB3ZSBoYXZlIHRvIHVzZSBhbiBleHRyYSB3cmFwcGVyIGJlY2F1c2UgYFJlc2l6ZU9ic2VydmVyYCAodXNlZCBieSBgdXNlU2l6ZWApXG4gICAgICAvLyBkb2Vzbid0IHJlcG9ydCBzaXplIGFzIHdlJ2QgZXhwZWN0IG9uIFNWRyBlbGVtZW50cy5cbiAgICAgIC8vIGl0IHJlcG9ydHMgdGhlaXIgYm91bmRpbmcgYm94IHdoaWNoIGlzIGVmZmVjdGl2ZWx5IHRoZSBsYXJnZXN0IHBhdGggaW5zaWRlIHRoZSBTVkcuXG4gICAgICAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgICBcInNwYW5cIixcbiAgICAgICAge1xuICAgICAgICAgIHJlZjogY29udGVudENvbnRleHQub25BcnJvd0NoYW5nZSxcbiAgICAgICAgICBzdHlsZToge1xuICAgICAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcbiAgICAgICAgICAgIGxlZnQ6IGNvbnRlbnRDb250ZXh0LmFycm93WCxcbiAgICAgICAgICAgIHRvcDogY29udGVudENvbnRleHQuYXJyb3dZLFxuICAgICAgICAgICAgW2Jhc2VTaWRlXTogMCxcbiAgICAgICAgICAgIHRyYW5zZm9ybU9yaWdpbjoge1xuICAgICAgICAgICAgICB0b3A6IFwiXCIsXG4gICAgICAgICAgICAgIHJpZ2h0OiBcIjAgMFwiLFxuICAgICAgICAgICAgICBib3R0b206IFwiY2VudGVyIDBcIixcbiAgICAgICAgICAgICAgbGVmdDogXCIxMDAlIDBcIlxuICAgICAgICAgICAgfVtjb250ZW50Q29udGV4dC5wbGFjZWRTaWRlXSxcbiAgICAgICAgICAgIHRyYW5zZm9ybToge1xuICAgICAgICAgICAgICB0b3A6IFwidHJhbnNsYXRlWSgxMDAlKVwiLFxuICAgICAgICAgICAgICByaWdodDogXCJ0cmFuc2xhdGVZKDUwJSkgcm90YXRlKDkwZGVnKSB0cmFuc2xhdGVYKC01MCUpXCIsXG4gICAgICAgICAgICAgIGJvdHRvbTogYHJvdGF0ZSgxODBkZWcpYCxcbiAgICAgICAgICAgICAgbGVmdDogXCJ0cmFuc2xhdGVZKDUwJSkgcm90YXRlKC05MGRlZykgdHJhbnNsYXRlWCg1MCUpXCJcbiAgICAgICAgICAgIH1bY29udGVudENvbnRleHQucGxhY2VkU2lkZV0sXG4gICAgICAgICAgICB2aXNpYmlsaXR5OiBjb250ZW50Q29udGV4dC5zaG91bGRIaWRlQXJyb3cgPyBcImhpZGRlblwiIDogdm9pZCAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgICAgICAgIEFycm93UHJpbWl0aXZlLlJvb3QsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIC4uLmFycm93UHJvcHMsXG4gICAgICAgICAgICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgICAgICAgICAgICBzdHlsZToge1xuICAgICAgICAgICAgICAgIC4uLmFycm93UHJvcHMuc3R5bGUsXG4gICAgICAgICAgICAgICAgLy8gZW5zdXJlcyB0aGUgZWxlbWVudCBjYW4gYmUgbWVhc3VyZWQgY29ycmVjdGx5IChtb3N0bHkgZm9yIGlmIFNWRylcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImJsb2NrXCJcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIClcbiAgICAgICAgfVxuICAgICAgKVxuICAgICk7XG4gIH0sIFwiUG9wcGVyQXJyb3dcIilcbik7XG5mdW5jdGlvbiBpc05vdE51bGwodmFsdWUpIHtcbiAgcmV0dXJuIHZhbHVlICE9PSBudWxsO1xufVxuX19uYW1lKGlzTm90TnVsbCwgXCJpc05vdE51bGxcIik7XG52YXIgdHJhbnNmb3JtT3JpZ2luID0gLyogQF9fUFVSRV9fICovIF9fbmFtZSgob3B0aW9ucykgPT4gKHtcbiAgbmFtZTogXCJ0cmFuc2Zvcm1PcmlnaW5cIixcbiAgb3B0aW9ucyxcbiAgZm4oZGF0YSkge1xuICAgIGNvbnN0IHsgcGxhY2VtZW50LCByZWN0cywgbWlkZGxld2FyZURhdGEgfSA9IGRhdGE7XG4gICAgY29uc3QgY2Fubm90Q2VudGVyQXJyb3cgPSBtaWRkbGV3YXJlRGF0YS5hcnJvdz8uY2VudGVyT2Zmc2V0ICE9PSAwO1xuICAgIGNvbnN0IGlzQXJyb3dIaWRkZW4gPSBjYW5ub3RDZW50ZXJBcnJvdztcbiAgICBjb25zdCBhcnJvd1dpZHRoID0gaXNBcnJvd0hpZGRlbiA/IDAgOiBvcHRpb25zLmFycm93V2lkdGg7XG4gICAgY29uc3QgYXJyb3dIZWlnaHQgPSBpc0Fycm93SGlkZGVuID8gMCA6IG9wdGlvbnMuYXJyb3dIZWlnaHQ7XG4gICAgY29uc3QgW3BsYWNlZFNpZGUsIHBsYWNlZEFsaWduXSA9IGdldFNpZGVBbmRBbGlnbkZyb21QbGFjZW1lbnQocGxhY2VtZW50KTtcbiAgICBjb25zdCBub0Fycm93QWxpZ24gPSB7IHN0YXJ0OiBcIjAlXCIsIGNlbnRlcjogXCI1MCVcIiwgZW5kOiBcIjEwMCVcIiB9W3BsYWNlZEFsaWduXTtcbiAgICBjb25zdCBhcnJvd1hDZW50ZXIgPSAobWlkZGxld2FyZURhdGEuYXJyb3c/LnggPz8gMCkgKyBhcnJvd1dpZHRoIC8gMjtcbiAgICBjb25zdCBhcnJvd1lDZW50ZXIgPSAobWlkZGxld2FyZURhdGEuYXJyb3c/LnkgPz8gMCkgKyBhcnJvd0hlaWdodCAvIDI7XG4gICAgbGV0IHggPSBcIlwiO1xuICAgIGxldCB5ID0gXCJcIjtcbiAgICBpZiAocGxhY2VkU2lkZSA9PT0gXCJib3R0b21cIikge1xuICAgICAgeCA9IGlzQXJyb3dIaWRkZW4gPyBub0Fycm93QWxpZ24gOiBgJHthcnJvd1hDZW50ZXJ9cHhgO1xuICAgICAgeSA9IGAkey1hcnJvd0hlaWdodH1weGA7XG4gICAgfSBlbHNlIGlmIChwbGFjZWRTaWRlID09PSBcInRvcFwiKSB7XG4gICAgICB4ID0gaXNBcnJvd0hpZGRlbiA/IG5vQXJyb3dBbGlnbiA6IGAke2Fycm93WENlbnRlcn1weGA7XG4gICAgICB5ID0gYCR7cmVjdHMuZmxvYXRpbmcuaGVpZ2h0ICsgYXJyb3dIZWlnaHR9cHhgO1xuICAgIH0gZWxzZSBpZiAocGxhY2VkU2lkZSA9PT0gXCJyaWdodFwiKSB7XG4gICAgICB4ID0gYCR7LWFycm93SGVpZ2h0fXB4YDtcbiAgICAgIHkgPSBpc0Fycm93SGlkZGVuID8gbm9BcnJvd0FsaWduIDogYCR7YXJyb3dZQ2VudGVyfXB4YDtcbiAgICB9IGVsc2UgaWYgKHBsYWNlZFNpZGUgPT09IFwibGVmdFwiKSB7XG4gICAgICB4ID0gYCR7cmVjdHMuZmxvYXRpbmcud2lkdGggKyBhcnJvd0hlaWdodH1weGA7XG4gICAgICB5ID0gaXNBcnJvd0hpZGRlbiA/IG5vQXJyb3dBbGlnbiA6IGAke2Fycm93WUNlbnRlcn1weGA7XG4gICAgfVxuICAgIHJldHVybiB7IGRhdGE6IHsgeCwgeSB9IH07XG4gIH1cbn0pLCBcInRyYW5zZm9ybU9yaWdpblwiKTtcbmZ1bmN0aW9uIGdldFNpZGVBbmRBbGlnbkZyb21QbGFjZW1lbnQocGxhY2VtZW50KSB7XG4gIGNvbnN0IFtzaWRlLCBhbGlnbiA9IFwiY2VudGVyXCJdID0gcGxhY2VtZW50LnNwbGl0KFwiLVwiKTtcbiAgcmV0dXJuIFtzaWRlLCBhbGlnbl07XG59XG5fX25hbWUoZ2V0U2lkZUFuZEFsaWduRnJvbVBsYWNlbWVudCwgXCJnZXRTaWRlQW5kQWxpZ25Gcm9tUGxhY2VtZW50XCIpO1xudmFyIFJvb3QyID0gUG9wcGVyO1xudmFyIEFuY2hvciA9IFBvcHBlckFuY2hvcjtcbnZhciBDb250ZW50ID0gUG9wcGVyQ29udGVudDtcbnZhciBBcnJvdyA9IFBvcHBlckFycm93O1xuZXhwb3J0IHtcbiAgQUxJR05fT1BUSU9OUyxcbiAgQW5jaG9yLFxuICBBcnJvdyxcbiAgQ29udGVudCxcbiAgUG9wcGVyLFxuICBQb3BwZXJBbmNob3IsXG4gIFBvcHBlckFycm93LFxuICBQb3BwZXJDb250ZW50LFxuICBSb290MiBhcyBSb290LFxuICBTSURFX09QVElPTlMsXG4gIGNyZWF0ZVBvcHBlclNjb3BlXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXgubWpzLm1hcFxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBS0EsSUFBTSxRQUFRO0NBQUM7Q0FBTztDQUFTO0NBQVU7QUFBTTtBQUcvQyxJQUFNLE1BQU0sS0FBSztBQUNqQixJQUFNLE1BQU0sS0FBSztBQUNqQixJQUFNLFFBQVEsS0FBSztBQUNuQixJQUFNLFFBQVEsS0FBSztBQUNuQixJQUFNLGdCQUFlLE9BQU07Q0FDekIsR0FBRztDQUNILEdBQUc7QUFDTDtBQUNBLElBQU0sa0JBQWtCO0NBQ3RCLE1BQU07Q0FDTixPQUFPO0NBQ1AsUUFBUTtDQUNSLEtBQUs7QUFDUDtBQUNBLFNBQVMsTUFBTSxPQUFPLE9BQU8sS0FBSztDQUNoQyxPQUFPLElBQUksT0FBTyxJQUFJLE9BQU8sR0FBRyxDQUFDO0FBQ25DO0FBQ0EsU0FBUyxTQUFTLE9BQU8sT0FBTztDQUM5QixPQUFPLE9BQU8sVUFBVSxhQUFhLE1BQU0sS0FBSyxJQUFJO0FBQ3REO0FBQ0EsU0FBUyxRQUFRLFdBQVc7Q0FDMUIsT0FBTyxVQUFVLE1BQU0sR0FBRyxDQUFDLENBQUM7QUFDOUI7QUFDQSxTQUFTLGFBQWEsV0FBVztDQUMvQixPQUFPLFVBQVUsTUFBTSxHQUFHLENBQUMsQ0FBQztBQUM5QjtBQUNBLFNBQVMsZ0JBQWdCLE1BQU07Q0FDN0IsT0FBTyxTQUFTLE1BQU0sTUFBTTtBQUM5QjtBQUNBLFNBQVMsY0FBYyxNQUFNO0NBQzNCLE9BQU8sU0FBUyxNQUFNLFdBQVc7QUFDbkM7QUFDQSxTQUFTLFlBQVksV0FBVztDQUM5QixNQUFNLFlBQVksVUFBVTtDQUM1QixPQUFPLGNBQWMsT0FBTyxjQUFjLE1BQU0sTUFBTTtBQUN4RDtBQUNBLFNBQVMsaUJBQWlCLFdBQVc7Q0FDbkMsT0FBTyxnQkFBZ0IsWUFBWSxTQUFTLENBQUM7QUFDL0M7QUFDQSxTQUFTLGtCQUFrQixXQUFXLE9BQU8sS0FBSztDQUNoRCxJQUFJLFFBQVEsS0FBSyxHQUNmLE1BQU07Q0FFUixNQUFNLFlBQVksYUFBYSxTQUFTO0NBQ3hDLE1BQU0sZ0JBQWdCLGlCQUFpQixTQUFTO0NBQ2hELE1BQU0sU0FBUyxjQUFjLGFBQWE7Q0FDMUMsSUFBSSxvQkFBb0Isa0JBQWtCLE1BQU0sZUFBZSxNQUFNLFFBQVEsV0FBVyxVQUFVLFNBQVMsY0FBYyxVQUFVLFdBQVc7Q0FDOUksSUFBSSxNQUFNLFVBQVUsVUFBVSxNQUFNLFNBQVMsU0FDM0Msb0JBQW9CLHFCQUFxQixpQkFBaUI7Q0FFNUQsT0FBTyxDQUFDLG1CQUFtQixxQkFBcUIsaUJBQWlCLENBQUM7QUFDcEU7QUFDQSxTQUFTLHNCQUFzQixXQUFXO0NBQ3hDLE1BQU0sb0JBQW9CLHFCQUFxQixTQUFTO0NBQ3hELE9BQU87RUFBQyw4QkFBOEIsU0FBUztFQUFHO0VBQW1CLDhCQUE4QixpQkFBaUI7Q0FBQztBQUN2SDtBQUNBLFNBQVMsOEJBQThCLFdBQVc7Q0FDaEQsT0FBTyxVQUFVLFNBQVMsT0FBTyxJQUFJLFVBQVUsUUFBUSxTQUFTLEtBQUssSUFBSSxVQUFVLFFBQVEsT0FBTyxPQUFPO0FBQzNHO0FBQ0EsSUFBTSxjQUFjLENBQUMsUUFBUSxPQUFPO0FBQ3BDLElBQU0sY0FBYyxDQUFDLFNBQVMsTUFBTTtBQUNwQyxJQUFNLGNBQWMsQ0FBQyxPQUFPLFFBQVE7QUFDcEMsSUFBTSxjQUFjLENBQUMsVUFBVSxLQUFLO0FBQ3BDLFNBQVMsWUFBWSxNQUFNLFNBQVMsS0FBSztDQUN2QyxRQUFRLE1BQVI7RUFDRSxLQUFLO0VBQ0wsS0FBSztHQUNILElBQUksS0FBSyxPQUFPLFVBQVUsY0FBYztHQUN4QyxPQUFPLFVBQVUsY0FBYztFQUNqQyxLQUFLO0VBQ0wsS0FBSyxTQUNILE9BQU8sVUFBVSxjQUFjO0VBQ2pDLFNBQ0UsT0FBTyxDQUFDO0NBQ1o7QUFDRjtBQUNBLFNBQVMsMEJBQTBCLFdBQVcsZUFBZSxXQUFXLEtBQUs7Q0FDM0UsTUFBTSxZQUFZLGFBQWEsU0FBUztDQUN4QyxJQUFJLE9BQU8sWUFBWSxRQUFRLFNBQVMsR0FBRyxjQUFjLFNBQVMsR0FBRztDQUNyRSxJQUFJLFdBQVc7RUFDYixPQUFPLEtBQUssS0FBSSxTQUFRLE9BQU8sTUFBTSxTQUFTO0VBQzlDLElBQUksZUFDRixPQUFPLEtBQUssT0FBTyxLQUFLLElBQUksNkJBQTZCLENBQUM7Q0FFOUQ7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLHFCQUFxQixXQUFXO0NBQ3ZDLE1BQU0sT0FBTyxRQUFRLFNBQVM7Q0FDOUIsT0FBTyxnQkFBZ0IsUUFBUSxVQUFVLE1BQU0sS0FBSyxNQUFNO0FBQzVEO0FBQ0EsU0FBUyxvQkFBb0IsU0FBUztDQUNwQyxJQUFJLGNBQWMsZ0JBQWdCLGlCQUFpQjtDQUNuRCxPQUFPO0VBQ0wsTUFBTSxlQUFlLFFBQVEsUUFBUSxPQUFPLGVBQWU7RUFDM0QsUUFBUSxpQkFBaUIsUUFBUSxVQUFVLE9BQU8saUJBQWlCO0VBQ25FLFNBQVMsa0JBQWtCLFFBQVEsV0FBVyxPQUFPLGtCQUFrQjtFQUN2RSxPQUFPLGdCQUFnQixRQUFRLFNBQVMsT0FBTyxnQkFBZ0I7Q0FDakU7QUFDRjtBQUNBLFNBQVMsaUJBQWlCLFNBQVM7Q0FDakMsT0FBTyxPQUFPLFlBQVksV0FBVyxvQkFBb0IsT0FBTyxJQUFJO0VBQ2xFLEtBQUs7RUFDTCxPQUFPO0VBQ1AsUUFBUTtFQUNSLE1BQU07Q0FDUjtBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsTUFBTTtDQUM5QixNQUFNLEVBQ0osR0FDQSxHQUNBLE9BQ0EsV0FDRTtDQUNKLE9BQU87RUFDTDtFQUNBO0VBQ0EsS0FBSztFQUNMLE1BQU07RUFDTixPQUFPLElBQUk7RUFDWCxRQUFRLElBQUk7RUFDWjtFQUNBO0NBQ0Y7QUFDRjs7O0FDbElBLFNBQVMsMkJBQTJCLE1BQU0sV0FBVyxLQUFLO0NBQ3hELElBQUksRUFDRixXQUNBLGFBQ0U7Q0FDSixNQUFNLFdBQVcsWUFBWSxTQUFTO0NBQ3RDLE1BQU0sZ0JBQWdCLGlCQUFpQixTQUFTO0NBQ2hELE1BQU0sY0FBYyxjQUFjLGFBQWE7Q0FDL0MsTUFBTSxPQUFPLFFBQVEsU0FBUztDQUM5QixNQUFNLGFBQWEsYUFBYTtDQUNoQyxNQUFNLFVBQVUsVUFBVSxJQUFJLFVBQVUsUUFBUSxJQUFJLFNBQVMsUUFBUTtDQUNyRSxNQUFNLFVBQVUsVUFBVSxJQUFJLFVBQVUsU0FBUyxJQUFJLFNBQVMsU0FBUztDQUN2RSxNQUFNLGNBQWMsVUFBVSxlQUFlLElBQUksU0FBUyxlQUFlO0NBQ3pFLElBQUk7Q0FDSixRQUFRLE1BQVI7RUFDRSxLQUFLO0dBQ0gsU0FBUztJQUNQLEdBQUc7SUFDSCxHQUFHLFVBQVUsSUFBSSxTQUFTO0dBQzVCO0dBQ0E7RUFDRixLQUFLO0dBQ0gsU0FBUztJQUNQLEdBQUc7SUFDSCxHQUFHLFVBQVUsSUFBSSxVQUFVO0dBQzdCO0dBQ0E7RUFDRixLQUFLO0dBQ0gsU0FBUztJQUNQLEdBQUcsVUFBVSxJQUFJLFVBQVU7SUFDM0IsR0FBRztHQUNMO0dBQ0E7RUFDRixLQUFLO0dBQ0gsU0FBUztJQUNQLEdBQUcsVUFBVSxJQUFJLFNBQVM7SUFDMUIsR0FBRztHQUNMO0dBQ0E7RUFDRixTQUNFLFNBQVM7R0FDUCxHQUFHLFVBQVU7R0FDYixHQUFHLFVBQVU7RUFDZjtDQUNKO0NBQ0EsTUFBTSxZQUFZLGFBQWEsU0FBUztDQUN4QyxJQUFJLFdBQ0YsT0FBTyxrQkFBa0IsZUFBZSxjQUFjLFFBQVEsSUFBSSxPQUFPLE9BQU8sYUFBYSxLQUFLO0NBRXBHLE9BQU87QUFDVDs7Ozs7Ozs7O0FBVUEsZUFBZSxlQUFlLE9BQU8sU0FBUztDQUM1QyxJQUFJO0NBQ0osSUFBSSxZQUFZLEtBQUssR0FDbkIsVUFBVSxDQUFDO0NBRWIsTUFBTSxFQUNKLEdBQ0EsR0FDQSxVQUNBLE9BQ0EsVUFDQSxhQUNFO0NBQ0osTUFBTSxFQUNKLFdBQVcscUJBQ1gsZUFBZSxZQUNmLGlCQUFpQixZQUNqQixjQUFjLE9BQ2QsVUFBVSxNQUNSLFNBQVMsU0FBUyxLQUFLO0NBQzNCLE1BQU0sZ0JBQWdCLGlCQUFpQixPQUFPO0NBRTlDLE1BQU0sVUFBVSxTQUFTLGNBRE4sbUJBQW1CLGFBQWEsY0FBYyxhQUNiO0NBQ3BELE1BQU0scUJBQXFCLGlCQUFpQixNQUFNLFNBQVMsZ0JBQWdCO0VBQ3pFLFdBQVcsd0JBQXdCLE9BQU8sU0FBUyxhQUFhLE9BQU8sS0FBSyxJQUFJLFNBQVMsVUFBVSxPQUFPLE9BQU8sT0FBTyx3QkFBd0IsUUFBUSxVQUFVLFFBQVEsa0JBQW1CLE9BQU8sU0FBUyxzQkFBc0IsT0FBTyxLQUFLLElBQUksU0FBUyxtQkFBbUIsU0FBUyxRQUFRO0VBQ2hTO0VBQ0E7RUFDQTtDQUNGLENBQUMsQ0FBQztDQUNGLE1BQU0sT0FBTyxtQkFBbUIsYUFBYTtFQUMzQztFQUNBO0VBQ0EsT0FBTyxNQUFNLFNBQVM7RUFDdEIsUUFBUSxNQUFNLFNBQVM7Q0FDekIsSUFBSSxNQUFNO0NBQ1YsTUFBTSxlQUFlLE9BQU8sU0FBUyxtQkFBbUIsT0FBTyxLQUFLLElBQUksU0FBUyxnQkFBZ0IsU0FBUyxRQUFRO0NBQ2xILE1BQU0sY0FBZSxPQUFPLFNBQVMsYUFBYSxPQUFPLEtBQUssSUFBSSxTQUFTLFVBQVUsWUFBWSxNQUFRLE9BQU8sU0FBUyxZQUFZLE9BQU8sS0FBSyxJQUFJLFNBQVMsU0FBUyxZQUFZLE1BQU87RUFDeEwsR0FBRztFQUNILEdBQUc7Q0FDTDtDQUNBLE1BQU0sb0JBQW9CLGlCQUFpQixTQUFTLHdEQUF3RCxNQUFNLFNBQVMsc0RBQXNEO0VBQy9LO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsQ0FBQyxJQUFJLElBQUk7Q0FDVCxPQUFPO0VBQ0wsTUFBTSxtQkFBbUIsTUFBTSxrQkFBa0IsTUFBTSxjQUFjLE9BQU8sWUFBWTtFQUN4RixTQUFTLGtCQUFrQixTQUFTLG1CQUFtQixTQUFTLGNBQWMsVUFBVSxZQUFZO0VBQ3BHLE9BQU8sbUJBQW1CLE9BQU8sa0JBQWtCLE9BQU8sY0FBYyxRQUFRLFlBQVk7RUFDNUYsUUFBUSxrQkFBa0IsUUFBUSxtQkFBbUIsUUFBUSxjQUFjLFNBQVMsWUFBWTtDQUNsRztBQUNGO0FBR0EsSUFBTSxrQkFBa0I7Ozs7Ozs7O0FBU3hCLElBQU1BLG9CQUFrQixPQUFPLFdBQVcsVUFBVSxXQUFXO0NBQzdELE1BQU0sRUFDSixZQUFZLFVBQ1osV0FBVyxZQUNYLGFBQWEsQ0FBQyxHQUNkLGFBQ0U7Q0FDSixNQUFNLDZCQUE2QixTQUFTLGlCQUFpQixXQUFXO0VBQ3RFLEdBQUc7RUFDSDtDQUNGO0NBQ0EsTUFBTSxNQUFNLE9BQU8sU0FBUyxTQUFTLE9BQU8sS0FBSyxJQUFJLFNBQVMsTUFBTSxRQUFRO0NBQzVFLElBQUksUUFBUSxNQUFNLFNBQVMsZ0JBQWdCO0VBQ3pDO0VBQ0E7RUFDQTtDQUNGLENBQUM7Q0FDRCxJQUFJLEVBQ0YsR0FDQSxNQUNFLDJCQUEyQixPQUFPLFdBQVcsR0FBRztDQUNwRCxJQUFJLG9CQUFvQjtDQUN4QixJQUFJLGFBQWE7Q0FDakIsTUFBTSxpQkFBaUIsQ0FBQztDQUN4QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksV0FBVyxRQUFRLEtBQUs7RUFDMUMsTUFBTSxvQkFBb0IsV0FBVztFQUNyQyxJQUFJLENBQUMsbUJBQ0g7RUFFRixNQUFNLEVBQ0osTUFDQSxPQUNFO0VBQ0osTUFBTSxFQUNKLEdBQUcsT0FDSCxHQUFHLE9BQ0gsTUFDQSxVQUNFLE1BQU0sR0FBRztHQUNYO0dBQ0E7R0FDQSxrQkFBa0I7R0FDbEIsV0FBVztHQUNYO0dBQ0E7R0FDQTtHQUNBLFVBQVU7R0FDVixVQUFVO0lBQ1I7SUFDQTtHQUNGO0VBQ0YsQ0FBQztFQUNELElBQUksU0FBUyxPQUFPLFFBQVE7RUFDNUIsSUFBSSxTQUFTLE9BQU8sUUFBUTtFQUM1QixlQUFlLFFBQVE7R0FDckIsR0FBRyxlQUFlO0dBQ2xCLEdBQUc7RUFDTDtFQUNBLElBQUksU0FBUyxhQUFhLGlCQUFpQjtHQUN6QztHQUNBLElBQUksT0FBTyxVQUFVLFVBQVU7SUFDN0IsSUFBSSxNQUFNLFdBQ1Isb0JBQW9CLE1BQU07SUFFNUIsSUFBSSxNQUFNLE9BQ1IsUUFBUSxNQUFNLFVBQVUsT0FBTyxNQUFNLFNBQVMsZ0JBQWdCO0tBQzVEO0tBQ0E7S0FDQTtJQUNGLENBQUMsSUFBSSxNQUFNO0lBRWIsQ0FBQyxDQUNDLEdBQ0EsS0FDRSwyQkFBMkIsT0FBTyxtQkFBbUIsR0FBRztHQUM5RDtHQUNBLElBQUk7RUFDTjtDQUNGO0NBQ0EsT0FBTztFQUNMO0VBQ0E7RUFDQSxXQUFXO0VBQ1g7RUFDQTtDQUNGO0FBQ0Y7Ozs7OztBQU9BLElBQU1DLFdBQVEsYUFBWTtDQUN4QixNQUFNO0NBQ047Q0FDQSxNQUFNLEdBQUcsT0FBTztFQUNkLE1BQU0sRUFDSixHQUNBLEdBQ0EsV0FDQSxPQUNBLFVBQ0EsVUFDQSxtQkFDRTtFQUVKLE1BQU0sRUFDSixTQUNBLFVBQVUsTUFDUixTQUFTLFNBQVMsS0FBSyxLQUFLLENBQUM7RUFDakMsSUFBSSxXQUFXLE1BQ2IsT0FBTyxDQUFDO0VBRVYsTUFBTSxnQkFBZ0IsaUJBQWlCLE9BQU87RUFDOUMsTUFBTSxTQUFTO0dBQ2I7R0FDQTtFQUNGO0VBQ0EsTUFBTSxPQUFPLGlCQUFpQixTQUFTO0VBQ3ZDLE1BQU0sU0FBUyxjQUFjLElBQUk7RUFDakMsTUFBTSxrQkFBa0IsTUFBTSxTQUFTLGNBQWMsT0FBTztFQUM1RCxNQUFNLFVBQVUsU0FBUztFQUN6QixNQUFNLFVBQVUsVUFBVSxRQUFRO0VBQ2xDLE1BQU0sVUFBVSxVQUFVLFdBQVc7RUFDckMsTUFBTSxhQUFhLFVBQVUsaUJBQWlCO0VBQzlDLE1BQU0sVUFBVSxNQUFNLFVBQVUsVUFBVSxNQUFNLFVBQVUsUUFBUSxPQUFPLFFBQVEsTUFBTSxTQUFTO0VBQ2hHLE1BQU0sWUFBWSxPQUFPLFFBQVEsTUFBTSxVQUFVO0VBQ2pELE1BQU0sb0JBQW9CLE9BQU8sU0FBUyxtQkFBbUIsT0FBTyxLQUFLLElBQUksU0FBUyxnQkFBZ0IsT0FBTztFQUM3RyxJQUFJLGFBQWEsb0JBQW9CLGtCQUFrQixjQUFjO0VBR3JFLElBQUksQ0FBQyxjQUFjLENBQUUsT0FBTyxTQUFTLGFBQWEsT0FBTyxLQUFLLElBQUksU0FBUyxVQUFVLGlCQUFpQixJQUNwRyxhQUFhLFNBQVMsU0FBUyxlQUFlLE1BQU0sU0FBUztFQUUvRCxNQUFNLG9CQUFvQixVQUFVLElBQUksWUFBWTtFQUlwRCxNQUFNLHlCQUF5QixhQUFhLElBQUksZ0JBQWdCLFVBQVUsSUFBSTtFQUM5RSxNQUFNLGFBQWEsSUFBSSxjQUFjLFVBQVUsc0JBQXNCO0VBQ3JFLE1BQU0sYUFBYSxJQUFJLGNBQWMsVUFBVSxzQkFBc0I7RUFJckUsTUFBTSxNQUFNLGFBQWEsZ0JBQWdCLFVBQVU7RUFDbkQsTUFBTSxTQUFTLGFBQWEsSUFBSSxnQkFBZ0IsVUFBVSxJQUFJO0VBQzlELE1BQU0sU0FBUyxNQUFNLFlBQVksUUFBUSxHQUFHO0VBTTVDLE1BQU0sa0JBQWtCLENBQUMsZUFBZSxTQUFTLGFBQWEsU0FBUyxLQUFLLFFBQVEsV0FBVyxVQUFVLE1BQU0sVUFBVSxVQUFVLEtBQUssU0FBUyxhQUFhLGFBQWEsY0FBYyxnQkFBZ0IsVUFBVSxJQUFJO0VBQ3ZOLE1BQU0sa0JBQWtCLGtCQUFrQixTQUFTLGFBQWEsU0FBUyxhQUFhLFNBQVMsTUFBTTtFQUNyRyxPQUFPO0lBQ0osT0FBTyxPQUFPLFFBQVE7R0FDdkIsTUFBTTtLQUNILE9BQU87SUFDUixjQUFjLFNBQVMsU0FBUztJQUNoQyxHQUFJLG1CQUFtQixFQUNyQixnQkFDRjtHQUNGO0dBQ0EsT0FBTztFQUNUO0NBQ0Y7QUFDRjs7Ozs7OztBQStHQSxJQUFNQyxTQUFPLFNBQVUsU0FBUztDQUM5QixJQUFJLFlBQVksS0FBSyxHQUNuQixVQUFVLENBQUM7Q0FFYixPQUFPO0VBQ0wsTUFBTTtFQUNOO0VBQ0EsTUFBTSxHQUFHLE9BQU87R0FDZCxJQUFJLHVCQUF1QjtHQUMzQixNQUFNLEVBQ0osV0FDQSxnQkFDQSxPQUNBLGtCQUNBLFVBQ0EsYUFDRTtHQUNKLE1BQU0sRUFDSixVQUFVLGdCQUFnQixNQUMxQixXQUFXLGlCQUFpQixNQUM1QixvQkFBb0IsNkJBQ3BCLG1CQUFtQixXQUNuQiw0QkFBNEIsUUFDNUIsZ0JBQWdCLE1BQ2hCLEdBQUcsMEJBQ0QsU0FBUyxTQUFTLEtBQUs7R0FNM0IsS0FBSyx3QkFBd0IsZUFBZSxVQUFVLFFBQVEsc0JBQXNCLGlCQUNsRixPQUFPLENBQUM7R0FFVixNQUFNLE9BQU8sUUFBUSxTQUFTO0dBQzlCLE1BQU0sa0JBQWtCLFlBQVksZ0JBQWdCO0dBQ3BELE1BQU0sa0JBQWtCLFFBQVEsZ0JBQWdCLE1BQU07R0FDdEQsTUFBTSxNQUFNLE9BQU8sU0FBUyxTQUFTLE9BQU8sS0FBSyxJQUFJLFNBQVMsTUFBTSxTQUFTLFFBQVE7R0FDckYsTUFBTSxxQkFBcUIsZ0NBQWdDLG1CQUFtQixDQUFDLGdCQUFnQixDQUFDLHFCQUFxQixnQkFBZ0IsQ0FBQyxJQUFJLHNCQUFzQixnQkFBZ0I7R0FDaEwsTUFBTSwrQkFBK0IsOEJBQThCO0dBQ25FLElBQUksQ0FBQywrQkFBK0IsOEJBQ2xDLG1CQUFtQixLQUFLLEdBQUcsMEJBQTBCLGtCQUFrQixlQUFlLDJCQUEyQixHQUFHLENBQUM7R0FFdkgsTUFBTSxhQUFhLENBQUMsa0JBQWtCLEdBQUcsa0JBQWtCO0dBQzNELE1BQU0sV0FBVyxNQUFNLFNBQVMsZUFBZSxPQUFPLHFCQUFxQjtHQUMzRSxNQUFNLFlBQVksQ0FBQztHQUNuQixJQUFJLGtCQUFrQix1QkFBdUIsZUFBZSxTQUFTLE9BQU8sS0FBSyxJQUFJLHFCQUFxQixjQUFjLENBQUM7R0FDekgsSUFBSSxlQUNGLFVBQVUsS0FBSyxTQUFTLEtBQUs7R0FFL0IsSUFBSSxnQkFBZ0I7SUFDbEIsTUFBTSxRQUFRLGtCQUFrQixXQUFXLE9BQU8sR0FBRztJQUNyRCxVQUFVLEtBQUssU0FBUyxNQUFNLEtBQUssU0FBUyxNQUFNLEdBQUc7R0FDdkQ7R0FDQSxnQkFBZ0IsQ0FBQyxHQUFHLGVBQWU7SUFDakM7SUFDQTtHQUNGLENBQUM7R0FHRCxJQUFJLENBQUMsVUFBVSxPQUFNLFNBQVEsUUFBUSxDQUFDLEdBQUc7SUFDdkMsSUFBSSx1QkFBdUI7SUFDM0IsTUFBTSxlQUFlLHdCQUF3QixlQUFlLFNBQVMsT0FBTyxLQUFLLElBQUksc0JBQXNCLFVBQVUsS0FBSztJQUMxSCxNQUFNLGdCQUFnQixXQUFXO0lBQ2pDLElBQUksZUFFRTtTQUFBLEVBRDRCLG1CQUFtQixjQUFjLG9CQUFvQixZQUFZLGFBQWEsSUFBSSxVQUlsSCxjQUFjLE9BQU0sTUFBSyxZQUFZLEVBQUUsU0FBUyxNQUFNLGtCQUFrQixFQUFFLFVBQVUsS0FBSyxJQUFJLElBQUksR0FFL0YsT0FBTztNQUNMLE1BQU07T0FDSixPQUFPO09BQ1AsV0FBVztNQUNiO01BQ0EsT0FBTyxFQUNMLFdBQVcsY0FDYjtLQUNGO0lBQUE7SUFNSixJQUFJLGtCQUFrQix3QkFBd0IsY0FBYyxRQUFPLE1BQUssRUFBRSxVQUFVLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sRUFBRSxVQUFVLEtBQUssRUFBRSxVQUFVLEVBQUUsQ0FBQyxDQUFDLE9BQU8sT0FBTyxLQUFLLElBQUksc0JBQXNCO0lBRzFMLElBQUksQ0FBQyxnQkFDSCxRQUFRLGtCQUFSO0tBQ0UsS0FBSyxXQUNIO01BQ0UsSUFBSTtNQUNKLE1BQU0sYUFBYSx5QkFBeUIsY0FBYyxRQUFPLE1BQUs7T0FDcEUsSUFBSSw4QkFBOEI7UUFDaEMsTUFBTSxrQkFBa0IsWUFBWSxFQUFFLFNBQVM7UUFDL0MsT0FBTyxvQkFBb0IsbUJBRzNCLG9CQUFvQjtPQUN0QjtPQUNBLE9BQU87TUFDVCxDQUFDLENBQUMsQ0FBQyxLQUFJLE1BQUssQ0FBQyxFQUFFLFdBQVcsRUFBRSxVQUFVLFFBQU8sYUFBWSxXQUFXLENBQUMsQ0FBQyxDQUFDLFFBQVEsS0FBSyxhQUFhLE1BQU0sVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUMsT0FBTyxPQUFPLEtBQUssSUFBSSx1QkFBdUI7TUFDaE0sSUFBSSxXQUNGLGlCQUFpQjtNQUVuQjtLQUNGO0tBQ0YsS0FBSyxvQkFDSCxpQkFBaUI7SUFFckI7SUFFRixJQUFJLGNBQWMsZ0JBQ2hCLE9BQU8sRUFDTCxPQUFPLEVBQ0wsV0FBVyxlQUNiLEVBQ0Y7R0FFSjtHQUNBLE9BQU8sQ0FBQztFQUNWO0NBQ0Y7QUFDRjtBQUVBLFNBQVMsZUFBZSxVQUFVLE1BQU07Q0FDdEMsT0FBTztFQUNMLEtBQUssU0FBUyxNQUFNLEtBQUs7RUFDekIsT0FBTyxTQUFTLFFBQVEsS0FBSztFQUM3QixRQUFRLFNBQVMsU0FBUyxLQUFLO0VBQy9CLE1BQU0sU0FBUyxPQUFPLEtBQUs7Q0FDN0I7QUFDRjtBQUNBLFNBQVMsc0JBQXNCLFVBQVU7Q0FDdkMsT0FBTyxNQUFNLE1BQUssU0FBUSxTQUFTLFNBQVMsQ0FBQztBQUMvQzs7Ozs7O0FBTUEsSUFBTUMsU0FBTyxTQUFVLFNBQVM7Q0FDOUIsSUFBSSxZQUFZLEtBQUssR0FDbkIsVUFBVSxDQUFDO0NBRWIsT0FBTztFQUNMLE1BQU07RUFDTjtFQUNBLE1BQU0sR0FBRyxPQUFPO0dBQ2QsTUFBTSxFQUNKLE9BQ0EsYUFDRTtHQUNKLE1BQU0sRUFDSixXQUFXLG1CQUNYLEdBQUcsMEJBQ0QsU0FBUyxTQUFTLEtBQUs7R0FDM0IsUUFBUSxVQUFSO0lBQ0UsS0FBSyxtQkFDSDtLQUtFLE1BQU0sVUFBVSxlQUFlLE1BSlIsU0FBUyxlQUFlLE9BQU87TUFDcEQsR0FBRztNQUNILGdCQUFnQjtLQUNsQixDQUFDLEdBQ3dDLE1BQU0sU0FBUztLQUN4RCxPQUFPLEVBQ0wsTUFBTTtNQUNKLHdCQUF3QjtNQUN4QixpQkFBaUIsc0JBQXNCLE9BQU87S0FDaEQsRUFDRjtJQUNGO0lBQ0YsS0FBSyxXQUNIO0tBS0UsTUFBTSxVQUFVLGVBQWUsTUFKUixTQUFTLGVBQWUsT0FBTztNQUNwRCxHQUFHO01BQ0gsYUFBYTtLQUNmLENBQUMsR0FDd0MsTUFBTSxRQUFRO0tBQ3ZELE9BQU8sRUFDTCxNQUFNO01BQ0osZ0JBQWdCO01BQ2hCLFNBQVMsc0JBQXNCLE9BQU87S0FDeEMsRUFDRjtJQUNGO0lBQ0YsU0FFSSxPQUFPLENBQUM7R0FFZDtFQUNGO0NBQ0Y7QUFDRjtBQThIQSxJQUFNLDRCQUEyQixJQUFJLElBQUksQ0FBQyxRQUFRLEtBQUssQ0FBQztBQUt4RCxlQUFlLHFCQUFxQixPQUFPLFNBQVM7Q0FDbEQsTUFBTSxFQUNKLFdBQ0EsVUFDQSxhQUNFO0NBQ0osTUFBTSxNQUFNLE9BQU8sU0FBUyxTQUFTLE9BQU8sS0FBSyxJQUFJLFNBQVMsTUFBTSxTQUFTLFFBQVE7Q0FDckYsTUFBTSxPQUFPLFFBQVEsU0FBUztDQUM5QixNQUFNLFlBQVksYUFBYSxTQUFTO0NBQ3hDLE1BQU0sYUFBYSxZQUFZLFNBQVMsTUFBTTtDQUM5QyxNQUFNLGdCQUFnQixZQUFZLElBQUksSUFBSSxJQUFJLEtBQUs7Q0FDbkQsTUFBTSxpQkFBaUIsT0FBTyxhQUFhLEtBQUs7Q0FDaEQsTUFBTSxXQUFXLFNBQVMsU0FBUyxLQUFLO0NBR3hDLElBQUksRUFDRixVQUNBLFdBQ0Esa0JBQ0UsT0FBTyxhQUFhLFdBQVc7RUFDakMsVUFBVTtFQUNWLFdBQVc7RUFDWCxlQUFlO0NBQ2pCLElBQUk7RUFDRixVQUFVLFNBQVMsWUFBWTtFQUMvQixXQUFXLFNBQVMsYUFBYTtFQUNqQyxlQUFlLFNBQVM7Q0FDMUI7Q0FDQSxJQUFJLGFBQWEsT0FBTyxrQkFBa0IsVUFDeEMsWUFBWSxjQUFjLFFBQVEsZ0JBQWdCLEtBQUs7Q0FFekQsT0FBTyxhQUFhO0VBQ2xCLEdBQUcsWUFBWTtFQUNmLEdBQUcsV0FBVztDQUNoQixJQUFJO0VBQ0YsR0FBRyxXQUFXO0VBQ2QsR0FBRyxZQUFZO0NBQ2pCO0FBQ0Y7Ozs7Ozs7O0FBU0EsSUFBTUMsV0FBUyxTQUFVLFNBQVM7Q0FDaEMsSUFBSSxZQUFZLEtBQUssR0FDbkIsVUFBVTtDQUVaLE9BQU87RUFDTCxNQUFNO0VBQ047RUFDQSxNQUFNLEdBQUcsT0FBTztHQUNkLElBQUksdUJBQXVCO0dBQzNCLE1BQU0sRUFDSixHQUNBLEdBQ0EsV0FDQSxtQkFDRTtHQUNKLE1BQU0sYUFBYSxNQUFNLHFCQUFxQixPQUFPLE9BQU87R0FJNUQsSUFBSSxnQkFBZ0Isd0JBQXdCLGVBQWUsV0FBVyxPQUFPLEtBQUssSUFBSSxzQkFBc0IsZUFBZSx3QkFBd0IsZUFBZSxVQUFVLFFBQVEsc0JBQXNCLGlCQUN4TSxPQUFPLENBQUM7R0FFVixPQUFPO0lBQ0wsR0FBRyxJQUFJLFdBQVc7SUFDbEIsR0FBRyxJQUFJLFdBQVc7SUFDbEIsTUFBTTtLQUNKLEdBQUc7S0FDSDtJQUNGO0dBQ0Y7RUFDRjtDQUNGO0FBQ0Y7Ozs7OztBQU9BLElBQU1DLFVBQVEsU0FBVSxTQUFTO0NBQy9CLElBQUksWUFBWSxLQUFLLEdBQ25CLFVBQVUsQ0FBQztDQUViLE9BQU87RUFDTCxNQUFNO0VBQ047RUFDQSxNQUFNLEdBQUcsT0FBTztHQUNkLE1BQU0sRUFDSixHQUNBLEdBQ0EsV0FDQSxhQUNFO0dBQ0osTUFBTSxFQUNKLFVBQVUsZ0JBQWdCLE1BQzFCLFdBQVcsaUJBQWlCLE9BQzVCLFVBQVUsRUFDUixLQUFJLFNBQVE7SUFDVixJQUFJLEVBQ0YsR0FDQSxNQUNFO0lBQ0osT0FBTztLQUNMO0tBQ0E7SUFDRjtHQUNGLEVBQ0YsR0FDQSxHQUFHLDBCQUNELFNBQVMsU0FBUyxLQUFLO0dBQzNCLE1BQU0sU0FBUztJQUNiO0lBQ0E7R0FDRjtHQUNBLE1BQU0sV0FBVyxNQUFNLFNBQVMsZUFBZSxPQUFPLHFCQUFxQjtHQUMzRSxNQUFNLFlBQVksWUFBWSxTQUFTO0dBQ3ZDLE1BQU0sV0FBVyxnQkFBZ0IsU0FBUztHQUMxQyxJQUFJLGdCQUFnQixPQUFPO0dBQzNCLElBQUksaUJBQWlCLE9BQU87R0FDNUIsTUFBTSxjQUFjLE1BQU0sVUFBVSxNQUFNLFFBQVEsU0FBUyxTQUFTLE1BQU0sUUFBUSxTQUFTLE9BQU8sUUFBUSxTQUFTLFNBQVMsTUFBTSxXQUFXLFFBQVE7R0FDckosSUFBSSxlQUNGLGdCQUFnQixXQUFXLFVBQVUsYUFBYTtHQUVwRCxJQUFJLGdCQUNGLGlCQUFpQixXQUFXLFdBQVcsY0FBYztHQUV2RCxNQUFNLGdCQUFnQixRQUFRLEdBQUc7SUFDL0IsR0FBRztLQUNGLFdBQVc7S0FDWCxZQUFZO0dBQ2YsQ0FBQztHQUNELE9BQU87SUFDTCxHQUFHO0lBQ0gsTUFBTTtLQUNKLEdBQUcsY0FBYyxJQUFJO0tBQ3JCLEdBQUcsY0FBYyxJQUFJO0tBQ3JCLFNBQVM7T0FDTixXQUFXO09BQ1gsWUFBWTtLQUNmO0lBQ0Y7R0FDRjtFQUNGO0NBQ0Y7QUFDRjs7OztBQUlBLElBQU1DLGVBQWEsU0FBVSxTQUFTO0NBQ3BDLElBQUksWUFBWSxLQUFLLEdBQ25CLFVBQVUsQ0FBQztDQUViLE9BQU87RUFDTDtFQUNBLEdBQUcsT0FBTztHQUNSLElBQUkscUJBQXFCO0dBQ3pCLE1BQU0sRUFDSixHQUNBLEdBQ0EsV0FDQSxPQUNBLG1CQUNFO0dBQ0osTUFBTSxFQUNKLFNBQVMsR0FDVCxVQUFVLGdCQUFnQixNQUMxQixXQUFXLGlCQUFpQixTQUMxQixTQUFTLFNBQVMsS0FBSztHQUMzQixNQUFNLFNBQVM7SUFDYjtJQUNBO0dBQ0Y7R0FDQSxNQUFNLFlBQVksWUFBWSxTQUFTO0dBQ3ZDLE1BQU0sV0FBVyxnQkFBZ0IsU0FBUztHQUMxQyxJQUFJLGdCQUFnQixPQUFPO0dBQzNCLElBQUksaUJBQWlCLE9BQU87R0FDNUIsTUFBTSxZQUFZLFNBQVMsUUFBUSxLQUFLO0dBQ3hDLE1BQU0saUJBQWlCLE9BQU8sY0FBYyxXQUFXO0lBQ3JELFVBQVU7SUFDVixXQUFXO0dBQ2IsSUFBSTtJQUNGLFdBQVcsc0JBQXNCLFVBQVUsYUFBYSxPQUFPLHNCQUFzQjtJQUNyRixZQUFZLHVCQUF1QixVQUFVLGNBQWMsT0FBTyx1QkFBdUI7R0FDM0Y7R0FDQSxJQUFJLGVBQWU7SUFDakIsTUFBTSxNQUFNLGFBQWEsTUFBTSxXQUFXO0lBQzFDLE1BQU0sV0FBVyxNQUFNLFVBQVUsWUFBWSxNQUFNLFNBQVMsT0FBTyxlQUFlO0lBQ2xGLE1BQU0sV0FBVyxNQUFNLFVBQVUsWUFBWSxNQUFNLFVBQVUsT0FBTyxlQUFlO0lBQ25GLElBQUksZ0JBQWdCLFVBQ2xCLGdCQUFnQjtTQUNYLElBQUksZ0JBQWdCLFVBQ3pCLGdCQUFnQjtHQUVwQjtHQUNBLElBQUksZ0JBQWdCO0lBQ2xCLElBQUksdUJBQXVCO0lBQzNCLE1BQU0sTUFBTSxhQUFhLE1BQU0sVUFBVTtJQUN6QyxNQUFNLGVBQWUsWUFBWSxJQUFJLFFBQVEsU0FBUyxDQUFDO0lBQ3ZELE1BQU0sV0FBVyxNQUFNLFVBQVUsYUFBYSxNQUFNLFNBQVMsUUFBUSxpQkFBaUIsd0JBQXdCLGVBQWUsV0FBVyxPQUFPLEtBQUssSUFBSSxzQkFBc0IsZUFBZSxJQUFJLE1BQU0sZUFBZSxJQUFJLGVBQWU7SUFDek8sTUFBTSxXQUFXLE1BQU0sVUFBVSxhQUFhLE1BQU0sVUFBVSxRQUFRLGVBQWUsTUFBTSx5QkFBeUIsZUFBZSxXQUFXLE9BQU8sS0FBSyxJQUFJLHVCQUF1QixlQUFlLE1BQU0sZUFBZSxlQUFlLFlBQVk7SUFDcFAsSUFBSSxpQkFBaUIsVUFDbkIsaUJBQWlCO1NBQ1osSUFBSSxpQkFBaUIsVUFDMUIsaUJBQWlCO0dBRXJCO0dBQ0EsT0FBTztLQUNKLFdBQVc7S0FDWCxZQUFZO0dBQ2Y7RUFDRjtDQUNGO0FBQ0Y7Ozs7Ozs7QUFjQSxJQUFNQyxTQUFPLFNBQVUsU0FBUztDQUM5QixJQUFJLFlBQVksS0FBSyxHQUNuQixVQUFVLENBQUM7Q0FFYixPQUFPO0VBQ0wsTUFBTTtFQUNOO0VBQ0EsTUFBTSxHQUFHLE9BQU87R0FDZCxNQUFNLEVBQ0osV0FDQSxPQUNBLFVBQ0EsYUFDRTtHQUNKLE1BQU0sRUFDSixjQUFjLENBQUMsR0FDZixHQUFHLDBCQUNELFNBQVMsU0FBUyxLQUFLO0dBQzNCLE1BQU0sV0FBVyxNQUFNLFNBQVMsZUFBZSxPQUFPLHFCQUFxQjtHQUMzRSxNQUFNLE9BQU8sUUFBUSxTQUFTO0dBQzlCLE1BQU0sWUFBWSxhQUFhLFNBQVM7R0FDeEMsTUFBTSxVQUFVLFlBQVksU0FBUyxNQUFNO0dBQzNDLE1BQU0sRUFDSixPQUNBLFdBQ0UsTUFBTTtHQUNWLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSSxTQUFTLFNBQVMsU0FBUyxVQUFVO0lBQ3ZDLGFBQWE7SUFDYixZQUFZLGVBQWdCLE9BQU8sU0FBUyxTQUFTLE9BQU8sS0FBSyxJQUFJLFNBQVMsTUFBTSxTQUFTLFFBQVEsS0FBTSxVQUFVLFNBQVMsU0FBUztHQUN6SSxPQUFPO0lBQ0wsWUFBWTtJQUNaLGFBQWEsY0FBYyxRQUFRLFFBQVE7R0FDN0M7R0FDQSxNQUFNLHdCQUF3QixTQUFTLFNBQVMsTUFBTSxTQUFTO0dBQy9ELE1BQU0sdUJBQXVCLFFBQVEsU0FBUyxPQUFPLFNBQVM7R0FDOUQsTUFBTSwwQkFBMEIsSUFBSSxTQUFTLFNBQVMsYUFBYSxxQkFBcUI7R0FDeEYsTUFBTSx5QkFBeUIsSUFBSSxRQUFRLFNBQVMsWUFBWSxvQkFBb0I7R0FDcEYsTUFBTSxZQUFZLE1BQU0sZUFBZTtHQUN2QyxNQUFNLFVBQVUsQ0FBQztHQUNqQixJQUFJLGtCQUFrQjtHQUN0QixJQUFJLGlCQUFpQjtHQUNyQixJQUFJLGFBQWEsUUFBUSxVQUFVLFFBQVEsR0FDekMsaUJBQWlCO0dBRW5CLElBQUksYUFBYSxRQUFRLFVBQVUsUUFBUSxHQUN6QyxrQkFBa0I7R0FFcEIsSUFBSSxXQUFXLENBQUMsV0FBVztJQUN6QixJQUFJLFNBQ0YsaUJBQWlCLFFBQVEsSUFBSSxJQUFJLFNBQVMsTUFBTSxTQUFTLEtBQUs7U0FFOUQsa0JBQWtCLFNBQVMsSUFBSSxJQUFJLFNBQVMsS0FBSyxTQUFTLE1BQU07R0FFcEU7R0FDQSxNQUFNLE1BQU07SUFDVixHQUFHO0lBQ0g7SUFDQTtHQUNGLENBQUM7R0FDRCxNQUFNLGlCQUFpQixNQUFNLFNBQVMsY0FBYyxTQUFTLFFBQVE7R0FDckUsSUFBSSxVQUFVLGVBQWUsU0FBUyxXQUFXLGVBQWUsUUFDOUQsT0FBTyxFQUNMLE9BQU8sRUFDTCxPQUFPLEtBQ1QsRUFDRjtHQUVGLE9BQU8sQ0FBQztFQUNWO0NBQ0Y7QUFDRjs7O0FDM2dDQSxTQUFTLFlBQVk7Q0FDbkIsT0FBTyxPQUFPLFdBQVc7QUFDM0I7QUFDQSxTQUFTLFlBQVksTUFBTTtDQUN6QixJQUFJLE9BQU8sSUFBSSxHQUNiLFFBQVEsS0FBSyxZQUFZLEdBQUEsQ0FBSSxZQUFZO0NBSzNDLE9BQU87QUFDVDtBQUNBLFNBQVMsVUFBVSxNQUFNO0NBQ3ZCLElBQUk7Q0FDSixRQUFRLFFBQVEsU0FBUyxzQkFBc0IsS0FBSyxrQkFBa0IsT0FBTyxLQUFLLElBQUksb0JBQW9CLGdCQUFnQjtBQUM1SDtBQUNBLFNBQVMsbUJBQW1CLE1BQU07Q0FDaEMsSUFBSTtDQUNKLFFBQVEsUUFBUSxPQUFPLElBQUksSUFBSSxLQUFLLGdCQUFnQixLQUFLLGFBQWEsT0FBTyxhQUFhLE9BQU8sS0FBSyxJQUFJLEtBQUs7QUFDakg7QUFDQSxTQUFTLE9BQU8sT0FBTztDQUNyQixJQUFJLENBQUMsVUFBVSxHQUNiLE9BQU87Q0FFVCxPQUFPLGlCQUFpQixRQUFRLGlCQUFpQixVQUFVLEtBQUssQ0FBQyxDQUFDO0FBQ3BFO0FBQ0EsU0FBUyxVQUFVLE9BQU87Q0FDeEIsSUFBSSxDQUFDLFVBQVUsR0FDYixPQUFPO0NBRVQsT0FBTyxpQkFBaUIsV0FBVyxpQkFBaUIsVUFBVSxLQUFLLENBQUMsQ0FBQztBQUN2RTtBQUNBLFNBQVMsY0FBYyxPQUFPO0NBQzVCLElBQUksQ0FBQyxVQUFVLEdBQ2IsT0FBTztDQUVULE9BQU8saUJBQWlCLGVBQWUsaUJBQWlCLFVBQVUsS0FBSyxDQUFDLENBQUM7QUFDM0U7QUFDQSxTQUFTLGFBQWEsT0FBTztDQUMzQixJQUFJLENBQUMsVUFBVSxLQUFLLE9BQU8sZUFBZSxhQUN4QyxPQUFPO0NBRVQsT0FBTyxpQkFBaUIsY0FBYyxpQkFBaUIsVUFBVSxLQUFLLENBQUMsQ0FBQztBQUMxRTtBQUNBLFNBQVMsa0JBQWtCLFNBQVM7Q0FDbEMsTUFBTSxFQUNKLFVBQ0EsV0FDQSxXQUNBLFlBQ0VDLG1CQUFpQixPQUFPO0NBQzVCLE9BQU8sa0NBQWtDLEtBQUssV0FBVyxZQUFZLFNBQVMsS0FBSyxZQUFZLFlBQVksWUFBWTtBQUN6SDtBQUNBLFNBQVMsZUFBZSxTQUFTO0NBQy9CLE9BQU8sa0JBQWtCLEtBQUssWUFBWSxPQUFPLENBQUM7QUFDcEQ7QUFDQSxTQUFTLFdBQVcsU0FBUztDQUMzQixJQUFJO0VBQ0YsSUFBSSxRQUFRLFFBQVEsZUFBZSxHQUNqQyxPQUFPO0NBRVgsU0FBUyxJQUFJLENBRWI7Q0FDQSxJQUFJO0VBQ0YsT0FBTyxRQUFRLFFBQVEsUUFBUTtDQUNqQyxTQUFTLElBQUk7RUFDWCxPQUFPO0NBQ1Q7QUFDRjtBQUNBLElBQU0sZUFBZTtBQUNyQixJQUFNLFlBQVk7QUFDbEIsSUFBTSxhQUFZLFVBQVMsQ0FBQyxDQUFDLFNBQVMsVUFBVTtBQUNoRCxJQUFJO0FBQ0osU0FBUyxrQkFBa0IsY0FBYztDQUN2QyxNQUFNLE1BQU0sVUFBVSxZQUFZLElBQUlBLG1CQUFpQixZQUFZLElBQUk7Q0FJdkUsT0FBTyxVQUFVLElBQUksU0FBUyxLQUFLLFVBQVUsSUFBSSxTQUFTLEtBQUssVUFBVSxJQUFJLEtBQUssS0FBSyxVQUFVLElBQUksTUFBTSxLQUFLLFVBQVUsSUFBSSxXQUFXLEtBQUssQ0FBQyxTQUFTLE1BQU0sVUFBVSxJQUFJLGNBQWMsS0FBSyxVQUFVLElBQUksTUFBTSxNQUFNLGFBQWEsS0FBSyxJQUFJLGNBQWMsRUFBRSxLQUFLLFVBQVUsS0FBSyxJQUFJLFdBQVcsRUFBRTtBQUN0UztBQUNBLFNBQVMsbUJBQW1CLFNBQVM7Q0FDbkMsSUFBSSxjQUFjLGNBQWMsT0FBTztDQUN2QyxPQUFPLGNBQWMsV0FBVyxLQUFLLENBQUMsc0JBQXNCLFdBQVcsR0FBRztFQUN4RSxJQUFJLGtCQUFrQixXQUFXLEdBQy9CLE9BQU87T0FDRixJQUFJLFdBQVcsV0FBVyxHQUMvQixPQUFPO0VBRVQsY0FBYyxjQUFjLFdBQVc7Q0FDekM7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLFdBQVc7Q0FDbEIsSUFBSSxpQkFBaUIsTUFDbkIsZ0JBQWdCLE9BQU8sUUFBUSxlQUFlLElBQUksWUFBWSxJQUFJLFNBQVMsMkJBQTJCLE1BQU07Q0FFOUcsT0FBTztBQUNUO0FBQ0EsU0FBUyxzQkFBc0IsTUFBTTtDQUNuQyxPQUFPLDBCQUEwQixLQUFLLFlBQVksSUFBSSxDQUFDO0FBQ3pEO0FBQ0EsU0FBU0EsbUJBQWlCLFNBQVM7Q0FDakMsT0FBTyxVQUFVLE9BQU8sQ0FBQyxDQUFDLGlCQUFpQixPQUFPO0FBQ3BEO0FBQ0EsU0FBUyxjQUFjLFNBQVM7Q0FDOUIsSUFBSSxVQUFVLE9BQU8sR0FDbkIsT0FBTztFQUNMLFlBQVksUUFBUTtFQUNwQixXQUFXLFFBQVE7Q0FDckI7Q0FFRixPQUFPO0VBQ0wsWUFBWSxRQUFRO0VBQ3BCLFdBQVcsUUFBUTtDQUNyQjtBQUNGO0FBQ0EsU0FBUyxjQUFjLE1BQU07Q0FDM0IsSUFBSSxZQUFZLElBQUksTUFBTSxRQUN4QixPQUFPO0NBRVQsTUFBTSxTQUVOLEtBQUssZ0JBRUwsS0FBSyxjQUVMLGFBQWEsSUFBSSxLQUFLLEtBQUssUUFFM0IsbUJBQW1CLElBQUk7Q0FDdkIsT0FBTyxhQUFhLE1BQU0sSUFBSSxPQUFPLE9BQU87QUFDOUM7QUFDQSxTQUFTLDJCQUEyQixNQUFNO0NBQ3hDLE1BQU0sYUFBYSxjQUFjLElBQUk7Q0FDckMsSUFBSSxzQkFBc0IsVUFBVSxHQUNsQyxRQUFRLEtBQUssaUJBQWlCLEtBQUEsQ0FBTTtDQUV0QyxJQUFJLGNBQWMsVUFBVSxLQUFLLGtCQUFrQixVQUFVLEdBQzNELE9BQU87Q0FFVCxPQUFPLDJCQUEyQixVQUFVO0FBQzlDO0FBQ0EsU0FBUyxxQkFBcUIsTUFBTSxNQUFNLGlCQUFpQjtDQUN6RCxJQUFJO0NBQ0osSUFBSSxTQUFTLEtBQUssR0FDaEIsT0FBTyxDQUFDO0NBRVYsSUFBSSxvQkFBb0IsS0FBSyxHQUMzQixrQkFBa0I7Q0FFcEIsTUFBTSxxQkFBcUIsMkJBQTJCLElBQUk7Q0FDMUQsTUFBTSxTQUFTLHlCQUF5Qix1QkFBdUIsS0FBSyxrQkFBa0IsT0FBTyxLQUFLLElBQUkscUJBQXFCO0NBQzNILE1BQU0sTUFBTSxVQUFVLGtCQUFrQjtDQUN4QyxJQUFJLFFBQVE7RUFDVixNQUFNLGVBQWUsZ0JBQWdCLEdBQUc7RUFDeEMsT0FBTyxLQUFLLE9BQU8sS0FBSyxJQUFJLGtCQUFrQixDQUFDLEdBQUcsa0JBQWtCLGtCQUFrQixJQUFJLHFCQUFxQixDQUFDLEdBQUcsZ0JBQWdCLGtCQUFrQixxQkFBcUIsWUFBWSxJQUFJLENBQUMsQ0FBQztDQUM5TCxPQUNFLE9BQU8sS0FBSyxPQUFPLG9CQUFvQixxQkFBcUIsb0JBQW9CLENBQUMsR0FBRyxlQUFlLENBQUM7QUFFeEc7QUFDQSxTQUFTLGdCQUFnQixLQUFLO0NBQzVCLE9BQU8sSUFBSSxVQUFVLE9BQU8sZUFBZSxJQUFJLE1BQU0sSUFBSSxJQUFJLGVBQWU7QUFDOUU7OztBQzdKQSxTQUFTLGlCQUFpQixTQUFTO0NBQ2pDLE1BQU0sTUFBTSxtQkFBbUIsT0FBTztDQUd0QyxJQUFJLFFBQVEsV0FBVyxJQUFJLEtBQUssS0FBSztDQUNyQyxJQUFJLFNBQVMsV0FBVyxJQUFJLE1BQU0sS0FBSztDQUN2QyxNQUFNLFlBQVksY0FBYyxPQUFPO0NBQ3ZDLE1BQU0sY0FBYyxZQUFZLFFBQVEsY0FBYztDQUN0RCxNQUFNLGVBQWUsWUFBWSxRQUFRLGVBQWU7Q0FDeEQsTUFBTSxpQkFBaUIsTUFBTSxLQUFLLE1BQU0sZUFBZSxNQUFNLE1BQU0sTUFBTTtDQUN6RSxJQUFJLGdCQUFnQjtFQUNsQixRQUFRO0VBQ1IsU0FBUztDQUNYO0NBQ0EsT0FBTztFQUNMO0VBQ0E7RUFDQSxHQUFHO0NBQ0w7QUFDRjtBQUVBLFNBQVMsY0FBYyxTQUFTO0NBQzlCLE9BQU8sQ0FBQyxVQUFVLE9BQU8sSUFBSSxRQUFRLGlCQUFpQjtBQUN4RDtBQUVBLFNBQVMsU0FBUyxTQUFTO0NBQ3pCLE1BQU0sYUFBYSxjQUFjLE9BQU87Q0FDeEMsSUFBSSxDQUFDLGNBQWMsVUFBVSxHQUMzQixPQUFPLGFBQWEsQ0FBQztDQUV2QixNQUFNLE9BQU8sV0FBVyxzQkFBc0I7Q0FDOUMsTUFBTSxFQUNKLE9BQ0EsUUFDQSxNQUNFLGlCQUFpQixVQUFVO0NBQy9CLElBQUksS0FBSyxJQUFJLE1BQU0sS0FBSyxLQUFLLElBQUksS0FBSyxTQUFTO0NBQy9DLElBQUksS0FBSyxJQUFJLE1BQU0sS0FBSyxNQUFNLElBQUksS0FBSyxVQUFVO0NBSWpELElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxTQUFTLENBQUMsR0FDMUIsSUFBSTtDQUVOLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxTQUFTLENBQUMsR0FDMUIsSUFBSTtDQUVOLE9BQU87RUFDTDtFQUNBO0NBQ0Y7QUFDRjtBQUVBLElBQU0sWUFBeUIsMkJBQWEsQ0FBQztBQUM3QyxTQUFTLGlCQUFpQixTQUFTO0NBQ2pDLE1BQU0sTUFBTSxVQUFVLE9BQU87Q0FDN0IsSUFBSSxDQUFDLFNBQVMsS0FBSyxDQUFDLElBQUksZ0JBQ3RCLE9BQU87Q0FFVCxPQUFPO0VBQ0wsR0FBRyxJQUFJLGVBQWU7RUFDdEIsR0FBRyxJQUFJLGVBQWU7Q0FDeEI7QUFDRjtBQUNBLFNBQVMsdUJBQXVCLFNBQVMsU0FBUyxzQkFBc0I7Q0FDdEUsSUFBSSxZQUFZLEtBQUssR0FDbkIsVUFBVTtDQUVaLE9BQU8sQ0FBQyxDQUFDLHdCQUF3QixXQUFXLHlCQUF5QixVQUFVLE9BQU87QUFDeEY7QUFFQSxTQUFTLHNCQUFzQixTQUFTLGNBQWMsaUJBQWlCLGNBQWM7Q0FDbkYsSUFBSSxpQkFBaUIsS0FBSyxHQUN4QixlQUFlO0NBRWpCLElBQUksb0JBQW9CLEtBQUssR0FDM0Isa0JBQWtCO0NBRXBCLE1BQU0sYUFBYSxRQUFRLHNCQUFzQjtDQUNqRCxNQUFNLGFBQWEsY0FBYyxPQUFPO0NBQ3hDLElBQUksUUFBUSxhQUFhLENBQUM7Q0FDMUIsSUFBSSxjQUFjO0VBQ2hCLElBQUksY0FDRTtPQUFBLFVBQVUsWUFBWSxHQUN4QixRQUFRLFNBQVMsWUFBWTtFQUFBLE9BRy9CLFFBQVEsU0FBUyxPQUFPO0NBRTVCO0NBQ0EsTUFBTSxnQkFBZ0IsdUJBQXVCLFlBQVksaUJBQWlCLFlBQVksSUFBSSxpQkFBaUIsVUFBVSxJQUFJLGFBQWEsQ0FBQztDQUN2SSxJQUFJLEtBQUssV0FBVyxPQUFPLGNBQWMsS0FBSyxNQUFNO0NBQ3BELElBQUksS0FBSyxXQUFXLE1BQU0sY0FBYyxLQUFLLE1BQU07Q0FDbkQsSUFBSSxRQUFRLFdBQVcsUUFBUSxNQUFNO0NBQ3JDLElBQUksU0FBUyxXQUFXLFNBQVMsTUFBTTtDQUN2QyxJQUFJLGNBQWMsY0FBYztFQUM5QixNQUFNLE1BQU0sVUFBVSxVQUFVO0VBQ2hDLE1BQU0sWUFBWSxVQUFVLFlBQVksSUFBSSxVQUFVLFlBQVksSUFBSTtFQUN0RSxJQUFJLGFBQWE7RUFDakIsSUFBSSxnQkFBZ0IsZ0JBQWdCLFVBQVU7RUFDOUMsT0FBTyxpQkFBaUIsY0FBYyxZQUFZO0dBQ2hELE1BQU0sY0FBYyxTQUFTLGFBQWE7R0FDMUMsTUFBTSxhQUFhLGNBQWMsc0JBQXNCO0dBQ3ZELE1BQU0sTUFBTSxtQkFBbUIsYUFBYTtHQUM1QyxNQUFNLE9BQU8sV0FBVyxRQUFRLGNBQWMsYUFBYSxXQUFXLElBQUksV0FBVyxLQUFLLFlBQVk7R0FDdEcsTUFBTSxNQUFNLFdBQVcsT0FBTyxjQUFjLFlBQVksV0FBVyxJQUFJLFVBQVUsS0FBSyxZQUFZO0dBQ2xHLEtBQUssWUFBWTtHQUNqQixLQUFLLFlBQVk7R0FDakIsU0FBUyxZQUFZO0dBQ3JCLFVBQVUsWUFBWTtHQUN0QixLQUFLO0dBQ0wsS0FBSztHQUNMLGFBQWEsVUFBVSxhQUFhO0dBQ3BDLGdCQUFnQixnQkFBZ0IsVUFBVTtFQUM1QztDQUNGO0NBQ0EsT0FBTyxpQkFBaUI7RUFDdEI7RUFDQTtFQUNBO0VBQ0E7Q0FDRixDQUFDO0FBQ0g7QUFJQSxTQUFTLG9CQUFvQixTQUFTLE1BQU07Q0FDMUMsTUFBTSxhQUFhLGNBQWMsT0FBTyxDQUFDLENBQUM7Q0FDMUMsSUFBSSxDQUFDLE1BQ0gsT0FBTyxzQkFBc0IsbUJBQW1CLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTztDQUVuRSxPQUFPLEtBQUssT0FBTztBQUNyQjtBQUVBLFNBQVMsY0FBYyxpQkFBaUIsUUFBUTtDQUM5QyxNQUFNLFdBQVcsZ0JBQWdCLHNCQUFzQjtDQUd2RCxPQUFPO0VBQ0wsR0FIUSxTQUFTLE9BQU8sT0FBTyxhQUFhLG9CQUFvQixpQkFBaUIsUUFBUTtFQUl6RixHQUhRLFNBQVMsTUFBTSxPQUFPO0NBSWhDO0FBQ0Y7QUFFQSxTQUFTLHNEQUFzRCxNQUFNO0NBQ25FLElBQUksRUFDRixVQUNBLE1BQ0EsY0FDQSxhQUNFO0NBQ0osTUFBTSxVQUFVLGFBQWE7Q0FDN0IsTUFBTSxrQkFBa0IsbUJBQW1CLFlBQVk7Q0FDdkQsTUFBTSxXQUFXLFdBQVcsV0FBVyxTQUFTLFFBQVEsSUFBSTtDQUM1RCxJQUFJLGlCQUFpQixtQkFBbUIsWUFBWSxTQUNsRCxPQUFPO0NBRVQsSUFBSSxTQUFTO0VBQ1gsWUFBWTtFQUNaLFdBQVc7Q0FDYjtDQUNBLElBQUksUUFBUSxhQUFhLENBQUM7Q0FDMUIsTUFBTSxVQUFVLGFBQWEsQ0FBQztDQUM5QixNQUFNLDBCQUEwQixjQUFjLFlBQVk7Q0FDMUQsSUFBSSwyQkFBMkIsQ0FBQyxTQUFTO0VBQ3ZDLElBQUksWUFBWSxZQUFZLE1BQU0sVUFBVSxrQkFBa0IsZUFBZSxHQUMzRSxTQUFTLGNBQWMsWUFBWTtFQUVyQyxJQUFJLHlCQUF5QjtHQUMzQixNQUFNLGFBQWEsc0JBQXNCLFlBQVk7R0FDckQsUUFBUSxTQUFTLFlBQVk7R0FDN0IsUUFBUSxJQUFJLFdBQVcsSUFBSSxhQUFhO0dBQ3hDLFFBQVEsSUFBSSxXQUFXLElBQUksYUFBYTtFQUMxQztDQUNGO0NBQ0EsTUFBTSxhQUFhLG1CQUFtQixDQUFDLDJCQUEyQixDQUFDLFVBQVUsY0FBYyxpQkFBaUIsTUFBTSxJQUFJLGFBQWEsQ0FBQztDQUNwSSxPQUFPO0VBQ0wsT0FBTyxLQUFLLFFBQVEsTUFBTTtFQUMxQixRQUFRLEtBQUssU0FBUyxNQUFNO0VBQzVCLEdBQUcsS0FBSyxJQUFJLE1BQU0sSUFBSSxPQUFPLGFBQWEsTUFBTSxJQUFJLFFBQVEsSUFBSSxXQUFXO0VBQzNFLEdBQUcsS0FBSyxJQUFJLE1BQU0sSUFBSSxPQUFPLFlBQVksTUFBTSxJQUFJLFFBQVEsSUFBSSxXQUFXO0NBQzVFO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsU0FBUztDQUMvQixPQUFPLFFBQVEsaUJBQWlCLE1BQU0sS0FBSyxRQUFRLGVBQWUsQ0FBQyxJQUFJLENBQUM7QUFDMUU7QUFJQSxTQUFTLGdCQUFnQixNQUFNO0NBQzdCLE1BQU0sU0FBUyxjQUFjLElBQUk7Q0FDakMsTUFBTSxPQUFPLEtBQUssY0FBYztDQUNoQyxNQUFNLFFBQVEsSUFBSSxLQUFLLGFBQWEsS0FBSyxhQUFhLEtBQUssYUFBYSxLQUFLLFdBQVc7Q0FDeEYsTUFBTSxTQUFTLElBQUksS0FBSyxjQUFjLEtBQUssY0FBYyxLQUFLLGNBQWMsS0FBSyxZQUFZO0NBQzdGLElBQUksSUFBSSxDQUFDLE9BQU8sYUFBYSxvQkFBb0IsSUFBSTtDQUNyRCxNQUFNLElBQUksQ0FBQyxPQUFPO0NBQ2xCLElBQUksbUJBQW1CLElBQUksQ0FBQyxDQUFDLGNBQWMsT0FDekMsS0FBSyxJQUFJLEtBQUssYUFBYSxLQUFLLFdBQVcsSUFBSTtDQUVqRCxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBS0EsSUFBTSxnQkFBZ0I7QUFDdEIsU0FBUyxnQkFBZ0IsU0FBUyxVQUFVLGNBQWM7Q0FDeEQsSUFBSSxpQkFBaUIsS0FBSyxHQUN4QixlQUFlO0NBRWpCLE1BQU0sbUJBQW1CLGlCQUFpQjtDQUMxQyxNQUFNLE1BQU0sVUFBVSxPQUFPO0NBQzdCLE1BQU0sT0FBTyxtQkFBbUIsT0FBTztDQUN2QyxNQUFNLGlCQUFpQixJQUFJO0NBQzNCLElBQUksUUFBUSxLQUFLO0NBQ2pCLElBQUksU0FBUyxLQUFLO0NBQ2xCLElBQUksSUFBSTtDQUNSLElBQUksSUFBSTtDQUNSLElBQUksZ0JBQWdCO0VBSWxCLE1BQU0sNkJBQTZCLENBQUMsU0FBUyxLQUFLLGFBQWE7RUFDL0QsSUFBSSxrQkFDRTtPQUFBLENBQUMsNEJBQTRCO0lBQy9CLElBQUksQ0FBQyxlQUFlO0lBQ3BCLElBQUksQ0FBQyxlQUFlO0dBQ3RCO1NBQ0s7R0FDTCxRQUFRLGVBQWU7R0FDdkIsU0FBUyxlQUFlO0dBQ3hCLElBQUksNEJBQTRCO0lBQzlCLElBQUksZUFBZTtJQUNuQixJQUFJLGVBQWU7R0FDckI7RUFDRjtDQUNGO0NBU0EsSUFSeUIsb0JBQW9CLElBUTFCLEtBQUssR0FBRztFQUN6QixNQUFNLE1BQU0sS0FBSztFQUNqQixNQUFNLE9BQU8sSUFBSTtFQUNqQixNQUFNLGFBQWEsaUJBQWlCLElBQUk7RUFDeEMsTUFBTSxtQkFBbUIsSUFBSSxlQUFlLGVBQWUsV0FBVyxXQUFXLFVBQVUsSUFBSSxXQUFXLFdBQVcsV0FBVyxLQUFLLElBQUk7RUFDekksTUFBTSxnQkFBZ0IsS0FBSyxJQUFJLEtBQUssY0FBYyxLQUFLLGNBQWMsZ0JBQWdCO0VBQ3JGLE1BQU0sU0FBUyxpQkFBaUIsSUFBSSxDQUFDLENBQUMsb0JBQW9CLHNCQUFzQixnQkFBZ0IsSUFBSTtFQUNwRyxJQUFJLFVBQVUsZUFDWixTQUFTO0NBRWI7Q0FDQSxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBR0EsU0FBUywyQkFBMkIsU0FBUyxVQUFVO0NBQ3JELE1BQU0sYUFBYSxzQkFBc0IsU0FBUyxNQUFNLGFBQWEsT0FBTztDQUM1RSxNQUFNLE1BQU0sV0FBVyxNQUFNLFFBQVE7Q0FDckMsTUFBTSxPQUFPLFdBQVcsT0FBTyxRQUFRO0NBQ3ZDLE1BQU0sUUFBUSxTQUFTLE9BQU87Q0FLOUIsT0FBTztFQUNMLE9BTFksUUFBUSxjQUFjLE1BQU07RUFNeEMsUUFMYSxRQUFRLGVBQWUsTUFBTTtFQU0xQyxHQUxRLE9BQU8sTUFBTTtFQU1yQixHQUxRLE1BQU0sTUFBTTtDQU10QjtBQUNGO0FBQ0EsU0FBUyxrQ0FBa0MsU0FBUyxrQkFBa0IsVUFBVTtDQUM5RSxJQUFJO0NBQ0osSUFBSSxxQkFBcUIsY0FBYyxxQkFBcUIsa0JBQzFELE9BQU8sZ0JBQWdCLFNBQVMsVUFBVSxnQkFBZ0I7TUFDckQsSUFBSSxxQkFBcUIsWUFDOUIsT0FBTyxnQkFBZ0IsbUJBQW1CLE9BQU8sQ0FBQztNQUM3QyxJQUFJLFVBQVUsZ0JBQWdCLEdBQ25DLE9BQU8sMkJBQTJCLGtCQUFrQixRQUFRO01BQ3ZEO0VBQ0wsTUFBTSxnQkFBZ0IsaUJBQWlCLE9BQU87RUFDOUMsT0FBTztHQUNMLEdBQUcsaUJBQWlCLElBQUksY0FBYztHQUN0QyxHQUFHLGlCQUFpQixJQUFJLGNBQWM7R0FDdEMsT0FBTyxpQkFBaUI7R0FDeEIsUUFBUSxpQkFBaUI7RUFDM0I7Q0FDRjtDQUNBLE9BQU8saUJBQWlCLElBQUk7QUFDOUI7QUFLQSxTQUFTLDRCQUE0QixTQUFTLE9BQU87Q0FDbkQsTUFBTSxlQUFlLE1BQU0sSUFBSSxPQUFPO0NBQ3RDLElBQUksY0FDRixPQUFPO0NBRVQsSUFBSSxTQUFTLHFCQUFxQixTQUFTLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxRQUFPLE9BQU0sVUFBVSxFQUFFLEtBQUssWUFBWSxFQUFFLE1BQU0sTUFBTTtDQUM5RyxJQUFJLHdCQUF3QjtDQUM1QixNQUFNLGlCQUFpQixtQkFBbUIsT0FBTyxDQUFDLENBQUMsYUFBYTtDQUNoRSxJQUFJLGNBQWMsaUJBQWlCLGNBQWMsT0FBTyxJQUFJO0NBRzVELE9BQU8sVUFBVSxXQUFXLEtBQUssQ0FBQyxzQkFBc0IsV0FBVyxHQUFHO0VBQ3BFLE1BQU0sZ0JBQWdCLG1CQUFtQixXQUFXO0VBQ3BELE1BQU0sMEJBQTBCLGtCQUFrQixXQUFXO0VBRzdELE1BQU0sZUFBZSx3QkFBd0Isc0JBQXNCLFdBQVcsaUJBQWlCLFVBQVU7RUFNekcsSUFEOEIsQ0FBQyw0QkFBNEIsaUJBQWlCLFdBQVcsaUJBQWlCLGNBQWMsY0FBYyxhQUFhLFdBRy9JLFNBQVMsT0FBTyxRQUFPLGFBQVksYUFBYSxXQUFXO09BRzNELHdCQUF3QjtFQUUxQixjQUFjLGNBQWMsV0FBVztDQUN6QztDQUNBLE1BQU0sSUFBSSxTQUFTLE1BQU07Q0FDekIsT0FBTztBQUNUO0FBSUEsU0FBUyxnQkFBZ0IsTUFBTTtDQUM3QixJQUFJLEVBQ0YsU0FDQSxVQUNBLGNBQ0EsYUFDRTtDQUVKLE1BQU0sb0JBQW9CLENBQUMsR0FETSxhQUFhLHNCQUFzQixXQUFXLE9BQU8sSUFBSSxDQUFDLElBQUksNEJBQTRCLFNBQVMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxRQUFRLEdBQ3pHLFlBQVk7Q0FDcEUsTUFBTSxZQUFZLGtDQUFrQyxTQUFTLGtCQUFrQixJQUFJLFFBQVE7Q0FDM0YsSUFBSSxNQUFNLFVBQVU7Q0FDcEIsSUFBSSxRQUFRLFVBQVU7Q0FDdEIsSUFBSSxTQUFTLFVBQVU7Q0FDdkIsSUFBSSxPQUFPLFVBQVU7Q0FDckIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGtCQUFrQixRQUFRLEtBQUs7RUFDakQsTUFBTSxPQUFPLGtDQUFrQyxTQUFTLGtCQUFrQixJQUFJLFFBQVE7RUFDdEYsTUFBTSxJQUFJLEtBQUssS0FBSyxHQUFHO0VBQ3ZCLFFBQVEsSUFBSSxLQUFLLE9BQU8sS0FBSztFQUM3QixTQUFTLElBQUksS0FBSyxRQUFRLE1BQU07RUFDaEMsT0FBTyxJQUFJLEtBQUssTUFBTSxJQUFJO0NBQzVCO0NBQ0EsT0FBTztFQUNMLE9BQU8sUUFBUTtFQUNmLFFBQVEsU0FBUztFQUNqQixHQUFHO0VBQ0gsR0FBRztDQUNMO0FBQ0Y7QUFFQSxTQUFTLGNBQWMsU0FBUztDQUM5QixNQUFNLEVBQ0osT0FDQSxXQUNFLGlCQUFpQixPQUFPO0NBQzVCLE9BQU87RUFDTDtFQUNBO0NBQ0Y7QUFDRjtBQUVBLFNBQVMsOEJBQThCLFNBQVMsY0FBYyxVQUFVO0NBQ3RFLE1BQU0sMEJBQTBCLGNBQWMsWUFBWTtDQUMxRCxNQUFNLGtCQUFrQixtQkFBbUIsWUFBWTtDQUN2RCxNQUFNLFVBQVUsYUFBYTtDQUM3QixNQUFNLE9BQU8sc0JBQXNCLFNBQVMsTUFBTSxTQUFTLFlBQVk7Q0FDdkUsSUFBSSxTQUFTO0VBQ1gsWUFBWTtFQUNaLFdBQVc7Q0FDYjtDQUNBLE1BQU0sVUFBVSxhQUFhLENBQUM7Q0FDOUIsSUFBSSwyQkFBMkIsQ0FBQyxTQUFTO0VBQ3ZDLElBQUksWUFBWSxZQUFZLE1BQU0sVUFBVSxrQkFBa0IsZUFBZSxHQUMzRSxTQUFTLGNBQWMsWUFBWTtFQUVyQyxJQUFJLHlCQUF5QjtHQUMzQixNQUFNLGFBQWEsc0JBQXNCLGNBQWMsTUFBTSxTQUFTLFlBQVk7R0FDbEYsUUFBUSxJQUFJLFdBQVcsSUFBSSxhQUFhO0dBQ3hDLFFBQVEsSUFBSSxXQUFXLElBQUksYUFBYTtFQUMxQztDQUNGO0NBSUEsSUFBSSxDQUFDLDJCQUEyQixpQkFDOUIsUUFBUSxJQUFJLG9CQUFvQixlQUFlO0NBRWpELE1BQU0sYUFBYSxtQkFBbUIsQ0FBQywyQkFBMkIsQ0FBQyxVQUFVLGNBQWMsaUJBQWlCLE1BQU0sSUFBSSxhQUFhLENBQUM7Q0FHcEksT0FBTztFQUNMLEdBSFEsS0FBSyxPQUFPLE9BQU8sYUFBYSxRQUFRLElBQUksV0FBVztFQUkvRCxHQUhRLEtBQUssTUFBTSxPQUFPLFlBQVksUUFBUSxJQUFJLFdBQVc7RUFJN0QsT0FBTyxLQUFLO0VBQ1osUUFBUSxLQUFLO0NBQ2Y7QUFDRjtBQUVBLFNBQVMsbUJBQW1CLFNBQVM7Q0FDbkMsT0FBTyxtQkFBbUIsT0FBTyxDQUFDLENBQUMsYUFBYTtBQUNsRDtBQUVBLFNBQVMsb0JBQW9CLFNBQVMsVUFBVTtDQUM5QyxJQUFJLENBQUMsY0FBYyxPQUFPLEtBQUssbUJBQW1CLE9BQU8sQ0FBQyxDQUFDLGFBQWEsU0FDdEUsT0FBTztDQUVULElBQUksVUFDRixPQUFPLFNBQVMsT0FBTztDQUV6QixJQUFJLGtCQUFrQixRQUFRO0NBTTlCLElBQUksbUJBQW1CLE9BQU8sTUFBTSxpQkFDbEMsa0JBQWtCLGdCQUFnQixjQUFjO0NBRWxELE9BQU87QUFDVDtBQUlBLFNBQVMsZ0JBQWdCLFNBQVMsVUFBVTtDQUMxQyxNQUFNLE1BQU0sVUFBVSxPQUFPO0NBQzdCLElBQUksV0FBVyxPQUFPLEdBQ3BCLE9BQU87Q0FFVCxJQUFJLENBQUMsY0FBYyxPQUFPLEdBQUc7RUFDM0IsSUFBSSxrQkFBa0IsY0FBYyxPQUFPO0VBQzNDLE9BQU8sbUJBQW1CLENBQUMsc0JBQXNCLGVBQWUsR0FBRztHQUNqRSxJQUFJLFVBQVUsZUFBZSxLQUFLLENBQUMsbUJBQW1CLGVBQWUsR0FDbkUsT0FBTztHQUVULGtCQUFrQixjQUFjLGVBQWU7RUFDakQ7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLGVBQWUsb0JBQW9CLFNBQVMsUUFBUTtDQUN4RCxPQUFPLGdCQUFnQixlQUFlLFlBQVksS0FBSyxtQkFBbUIsWUFBWSxHQUNwRixlQUFlLG9CQUFvQixjQUFjLFFBQVE7Q0FFM0QsSUFBSSxnQkFBZ0Isc0JBQXNCLFlBQVksS0FBSyxtQkFBbUIsWUFBWSxLQUFLLENBQUMsa0JBQWtCLFlBQVksR0FDNUgsT0FBTztDQUVULE9BQU8sZ0JBQWdCLG1CQUFtQixPQUFPLEtBQUs7QUFDeEQ7QUFFQSxJQUFNLGtCQUFrQixlQUFnQixNQUFNO0NBQzVDLE1BQU0sb0JBQW9CLEtBQUssbUJBQW1CO0NBQ2xELE1BQU0sa0JBQWtCLEtBQUs7Q0FDN0IsTUFBTSxxQkFBcUIsTUFBTSxnQkFBZ0IsS0FBSyxRQUFRO0NBQzlELE9BQU87RUFDTCxXQUFXLDhCQUE4QixLQUFLLFdBQVcsTUFBTSxrQkFBa0IsS0FBSyxRQUFRLEdBQUcsS0FBSyxRQUFRO0VBQzlHLFVBQVU7R0FDUixHQUFHO0dBQ0gsR0FBRztHQUNILE9BQU8sbUJBQW1CO0dBQzFCLFFBQVEsbUJBQW1CO0VBQzdCO0NBQ0Y7QUFDRjtBQUVBLFNBQVMsTUFBTSxTQUFTO0NBQ3RCLE9BQU8sbUJBQW1CLE9BQU8sQ0FBQyxDQUFDLGNBQWM7QUFDbkQ7QUFFQSxJQUFNLFdBQVc7Q0FDZjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGO0FBRUEsU0FBUyxjQUFjLEdBQUcsR0FBRztDQUMzQixPQUFPLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFO0FBQzdFO0FBR0EsU0FBUyxZQUFZLFNBQVMsUUFBUSxnQkFBZ0I7Q0FDcEQsSUFBSSxLQUFLO0NBQ1QsSUFBSTtDQUNKLE1BQU0sT0FBTyxtQkFBbUIsT0FBTztDQUN2QyxTQUFTLFVBQVU7RUFDakIsSUFBSTtFQUNKLGFBQWEsU0FBUztFQUN0QixDQUFDLE1BQU0sT0FBTyxRQUFRLElBQUksV0FBVztFQUNyQyxLQUFLO0NBQ1A7Q0FDQSxTQUFTLFFBQVEsTUFBTSxXQUFXO0VBQ2hDLElBQUksU0FBUyxLQUFLLEdBQ2hCLE9BQU87RUFFVCxJQUFJLGNBQWMsS0FBSyxHQUNyQixZQUFZO0VBRWQsUUFBUTtFQUNSLE1BQU0sMkJBQTJCLFFBQVEsc0JBQXNCO0VBQy9ELE1BQU0sRUFDSixNQUNBLEtBQ0EsT0FDQSxXQUNFO0VBQ0osSUFBSSxDQUFDLE1BQ0gsT0FBTztFQUVULElBQUksQ0FBQyxTQUFTLENBQUMsUUFDYjtFQUVGLE1BQU0sV0FBVyxNQUFNLEdBQUc7RUFDMUIsTUFBTSxhQUFhLE1BQU0sS0FBSyxlQUFlLE9BQU8sTUFBTTtFQUMxRCxNQUFNLGNBQWMsTUFBTSxLQUFLLGdCQUFnQixNQUFNLE9BQU87RUFDNUQsTUFBTSxZQUFZLE1BQU0sSUFBSTtFQUU1QixNQUFNLFVBQVU7R0FDZCxZQUZpQixDQUFDLFdBQVcsUUFBUSxDQUFDLGFBQWEsUUFBUSxDQUFDLGNBQWMsUUFBUSxDQUFDLFlBQVk7R0FHL0YsV0FBVyxJQUFJLEdBQUcsSUFBSSxHQUFHLFNBQVMsQ0FBQyxLQUFLO0VBQzFDO0VBQ0EsSUFBSSxnQkFBZ0I7RUFDcEIsU0FBUyxjQUFjLFNBQVM7R0FDOUIsTUFBTSxRQUFRLFFBQVEsRUFBRSxDQUFDO0dBT3pCLElBQUksQ0FBQyxjQUFjLDBCQUEwQixRQUFRLHNCQUFzQixDQUFDLEdBQzFFLE9BQU8sUUFBUTtHQUVqQixJQUFJLFVBQVUsV0FBVztJQUN2QixJQUFJLENBQUMsZUFDSCxPQUFPLFFBQVE7SUFFakIsSUFBSSxDQUFDLE9BR0gsWUFBWSxpQkFBaUI7S0FDM0IsUUFBUSxPQUFPLElBQUk7SUFDckIsR0FBRyxHQUFJO1NBRVAsUUFBUSxPQUFPLEtBQUs7R0FFeEI7R0FDQSxnQkFBZ0I7RUFDbEI7RUFJQSxJQUFJO0dBQ0YsS0FBSyxJQUFJLHFCQUFxQixlQUFlO0lBQzNDLEdBQUc7SUFFSCxNQUFNLEtBQUs7R0FDYixDQUFDO0VBQ0gsU0FBUyxJQUFJO0dBQ1gsS0FBSyxJQUFJLHFCQUFxQixlQUFlLE9BQU87RUFDdEQ7RUFDQSxHQUFHLFFBQVEsT0FBTztDQUNwQjtDQUNBLE1BQU0sTUFBTSxVQUFVLE9BQU87Q0FLN0IsTUFBTSxxQkFBcUIsUUFBUSxjQUFjO0NBQ2pELElBQUksaUJBQWlCLFVBQVUsWUFBWTtDQUMzQyxRQUFRLElBQUk7Q0FDWixhQUFhO0VBQ1gsSUFBSSxvQkFBb0IsVUFBVSxZQUFZO0VBQzlDLFFBQVE7Q0FDVjtBQUNGOzs7Ozs7Ozs7QUFVQSxTQUFTLFdBQVcsV0FBVyxVQUFVLFFBQVEsU0FBUztDQUN4RCxJQUFJLFlBQVksS0FBSyxHQUNuQixVQUFVLENBQUM7Q0FFYixNQUFNLEVBQ0osaUJBQWlCLE1BQ2pCLGlCQUFpQixNQUNqQixnQkFBZ0IsT0FBTyxtQkFBbUIsWUFDMUMsY0FBYyxPQUFPLHlCQUF5QixZQUM5QyxpQkFBaUIsVUFDZjtDQUNKLE1BQU0sY0FBYyxjQUFjLFNBQVM7Q0FDM0MsTUFBTSxZQUFZLGtCQUFrQixpQkFBaUIsQ0FBQyxHQUFJLGNBQWMscUJBQXFCLFdBQVcsSUFBSSxDQUFDLEdBQUksR0FBSSxXQUFXLHFCQUFxQixRQUFRLElBQUksQ0FBQyxDQUFFLElBQUksQ0FBQztDQUN6SyxVQUFVLFNBQVEsYUFBWTtFQUM1QixrQkFBa0IsU0FBUyxpQkFBaUIsVUFBVSxNQUFNO0VBQzVELGtCQUFrQixTQUFTLGlCQUFpQixVQUFVLE1BQU07Q0FDOUQsQ0FBQztDQUNELE1BQU0sWUFBWSxlQUFlLGNBQWMsWUFBWSxhQUFhLFFBQVEsY0FBYyxJQUFJO0NBQ2xHLElBQUksaUJBQWlCO0NBQ3JCLElBQUksaUJBQWlCO0NBQ3JCLElBQUksZUFBZTtFQUNqQixpQkFBaUIsSUFBSSxnQkFBZSxTQUFRO0dBQzFDLElBQUksQ0FBQyxjQUFjO0dBQ25CLElBQUksY0FBYyxXQUFXLFdBQVcsZUFBZSxrQkFBa0IsVUFBVTtJQUdqRixlQUFlLFVBQVUsUUFBUTtJQUNqQyxxQkFBcUIsY0FBYztJQUNuQyxpQkFBaUIsNEJBQTRCO0tBQzNDLElBQUk7S0FDSixDQUFDLGtCQUFrQixtQkFBbUIsUUFBUSxnQkFBZ0IsUUFBUSxRQUFRO0lBQ2hGLENBQUM7R0FDSDtHQUNBLE9BQU87RUFDVCxDQUFDO0VBQ0QsSUFBSSxlQUFlLENBQUMsZ0JBQ2xCLGVBQWUsUUFBUSxXQUFXO0VBRXBDLElBQUksVUFDRixlQUFlLFFBQVEsUUFBUTtDQUVuQztDQUNBLElBQUk7Q0FDSixJQUFJLGNBQWMsaUJBQWlCLHNCQUFzQixTQUFTLElBQUk7Q0FDdEUsSUFBSSxnQkFDRixVQUFVO0NBRVosU0FBUyxZQUFZO0VBQ25CLE1BQU0sY0FBYyxzQkFBc0IsU0FBUztFQUNuRCxJQUFJLGVBQWUsQ0FBQyxjQUFjLGFBQWEsV0FBVyxHQUN4RCxPQUFPO0VBRVQsY0FBYztFQUNkLFVBQVUsc0JBQXNCLFNBQVM7Q0FDM0M7Q0FDQSxPQUFPO0NBQ1AsYUFBYTtFQUNYLElBQUk7RUFDSixVQUFVLFNBQVEsYUFBWTtHQUM1QixrQkFBa0IsU0FBUyxvQkFBb0IsVUFBVSxNQUFNO0dBQy9ELGtCQUFrQixTQUFTLG9CQUFvQixVQUFVLE1BQU07RUFDakUsQ0FBQztFQUNELFlBQStCO0VBQy9CLENBQUMsbUJBQW1CLG1CQUFtQixRQUFRLGlCQUFpQixXQUFXO0VBQzNFLGlCQUFpQjtFQUNqQixJQUFJLGdCQUNGLHFCQUFxQixPQUFPO0NBRWhDO0FBQ0Y7Ozs7Ozs7O0FBbUJBLElBQU1DLFdBQVNDOzs7Ozs7QUFlZixJQUFNQyxVQUFRQzs7Ozs7OztBQVFkLElBQU1DLFNBQU9DOzs7Ozs7O0FBUWIsSUFBTUMsU0FBT0M7Ozs7OztBQU9iLElBQU1DLFNBQU9DOzs7Ozs7QUFPYixJQUFNQyxVQUFRQzs7OztBQVlkLElBQU1DLGVBQWFDOzs7OztBQU1uQixJQUFNLG1CQUFtQixXQUFXLFVBQVUsWUFBWTtDQUl4RCxNQUFNLHdCQUFRLElBQUksSUFBSTtDQUN0QixNQUFNLGdCQUFnQixXQUFXLE9BQU8sVUFBVSxDQUFDO0NBQ25ELE1BQU0sb0JBQW9CO0VBQ3hCLEdBQUc7RUFDSCxHQUFHLGNBQWM7RUFDakIsSUFBSTtDQUNOO0NBQ0EsT0FBTyxrQkFBa0IsV0FBVyxVQUFVO0VBQzVDLEdBQUc7RUFDSCxVQUFVO0NBQ1osQ0FBQztBQUNIOzs7O0FDendCQSxJQUFJLFFBSFcsT0FBTyxhQUFhLGNBR1pDLGFBQUFBLGtCQUFrQixTQURyQixPQUFPLENBQUM7QUFLNUIsU0FBUyxVQUFVLEdBQUcsR0FBRztDQUN2QixJQUFJLE1BQU0sR0FDUixPQUFPO0NBRVQsSUFBSSxPQUFPLE1BQU0sT0FBTyxHQUN0QixPQUFPO0NBRVQsSUFBSSxPQUFPLE1BQU0sY0FBYyxFQUFFLFNBQVMsTUFBTSxFQUFFLFNBQVMsR0FDekQsT0FBTztDQUVULElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUksS0FBSyxLQUFLLE9BQU8sTUFBTSxVQUFVO0VBQ25DLElBQUksTUFBTSxRQUFRLENBQUMsR0FBRztHQUNwQixTQUFTLEVBQUU7R0FDWCxJQUFJLFdBQVcsRUFBRSxRQUFRLE9BQU87R0FDaEMsS0FBSyxJQUFJLFFBQVEsUUFBUSxJQUN2QixJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksRUFBRSxFQUFFLEdBQ3ZCLE9BQU87R0FHWCxPQUFPO0VBQ1Q7RUFDQSxPQUFPLE9BQU8sS0FBSyxDQUFDO0VBQ3BCLFNBQVMsS0FBSztFQUNkLElBQUksV0FBVyxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFDNUIsT0FBTztFQUVULEtBQUssSUFBSSxRQUFRLFFBQVEsSUFDdkIsSUFBSSxDQUFDLENBQUMsRUFBRSxlQUFlLEtBQUssR0FBRyxLQUFLLEVBQUUsR0FDcEMsT0FBTztFQUdYLEtBQUssSUFBSSxRQUFRLFFBQVEsSUFBSTtHQUMzQixNQUFNLE1BQU0sS0FBSztHQUNqQixJQUFJLFFBQVEsWUFBWSxFQUFFLFVBQ3hCO0dBRUYsSUFBSSxDQUFDLFVBQVUsRUFBRSxNQUFNLEVBQUUsSUFBSSxHQUMzQixPQUFPO0VBRVg7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxPQUFPLE1BQU0sS0FBSyxNQUFNO0FBQzFCO0FBRUEsU0FBUyxPQUFPLFNBQVM7Q0FDdkIsSUFBSSxPQUFPLFdBQVcsYUFDcEIsT0FBTztDQUdULFFBRFksUUFBUSxjQUFjLGVBQWUsT0FBQSxDQUN0QyxvQkFBb0I7QUFDakM7QUFFQSxTQUFTLFdBQVcsU0FBUyxPQUFPO0NBQ2xDLE1BQU0sTUFBTSxPQUFPLE9BQU87Q0FDMUIsT0FBTyxLQUFLLE1BQU0sUUFBUSxHQUFHLElBQUk7QUFDbkM7QUFFQSxTQUFTLGFBQWEsT0FBTztDQUMzQixNQUFNLE1BQUEsYUFBWSxPQUFPLEtBQUs7Q0FDOUIsWUFBWTtFQUNWLElBQUksVUFBVTtDQUNoQixDQUFDO0NBQ0QsT0FBTztBQUNUOzs7OztBQU1BLFNBQVMsWUFBWSxTQUFTO0NBQzVCLElBQUksWUFBWSxLQUFLLEdBQ25CLFVBQVUsQ0FBQztDQUViLE1BQU0sRUFDSixZQUFZLFVBQ1osV0FBVyxZQUNYLGFBQWEsQ0FBQyxHQUNkLFVBQ0EsVUFBVSxFQUNSLFdBQVcsbUJBQ1gsVUFBVSxxQkFDUixDQUFDLEdBQ0wsWUFBWSxNQUNaLHNCQUNBLFNBQ0U7Q0FDSixNQUFNLENBQUMsTUFBTSxXQUFBLGFBQWlCLFNBQVM7RUFDckMsR0FBRztFQUNILEdBQUc7RUFDSDtFQUNBO0VBQ0EsZ0JBQWdCLENBQUM7RUFDakIsY0FBYztDQUNoQixDQUFDO0NBQ0QsTUFBTSxDQUFDLGtCQUFrQix1QkFBQSxhQUE2QixTQUFTLFVBQVU7Q0FDekUsSUFBSSxDQUFDLFVBQVUsa0JBQWtCLFVBQVUsR0FDekMsb0JBQW9CLFVBQVU7Q0FFaEMsTUFBTSxDQUFDLFlBQVksaUJBQUEsYUFBdUIsU0FBUyxJQUFJO0NBQ3ZELE1BQU0sQ0FBQyxXQUFXLGdCQUFBLGFBQXNCLFNBQVMsSUFBSTtDQUNyRCxNQUFNLGVBQUEsYUFBcUIsYUFBWSxTQUFRO0VBQzdDLElBQUksU0FBUyxhQUFhLFNBQVM7R0FDakMsYUFBYSxVQUFVO0dBQ3ZCLGNBQWMsSUFBSTtFQUNwQjtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBQ0wsTUFBTSxjQUFBLGFBQW9CLGFBQVksU0FBUTtFQUM1QyxJQUFJLFNBQVMsWUFBWSxTQUFTO0dBQ2hDLFlBQVksVUFBVTtHQUN0QixhQUFhLElBQUk7RUFDbkI7Q0FDRixHQUFHLENBQUMsQ0FBQztDQUNMLE1BQU0sY0FBYyxxQkFBcUI7Q0FDekMsTUFBTSxhQUFhLG9CQUFvQjtDQUN2QyxNQUFNLGVBQUEsYUFBcUIsT0FBTyxJQUFJO0NBQ3RDLE1BQU0sY0FBQSxhQUFvQixPQUFPLElBQUk7Q0FDckMsTUFBTSxVQUFBLGFBQWdCLE9BQU8sSUFBSTtDQUNqQyxNQUFNLDBCQUEwQix3QkFBd0I7Q0FDeEQsTUFBTSwwQkFBMEIsYUFBYSxvQkFBb0I7Q0FDakUsTUFBTSxjQUFjLGFBQWEsUUFBUTtDQUN6QyxNQUFNLFVBQVUsYUFBYSxJQUFJO0NBQ2pDLE1BQU0sU0FBQSxhQUFlLGtCQUFrQjtFQUNyQyxJQUFJLENBQUMsYUFBYSxXQUFXLENBQUMsWUFBWSxTQUN4QztFQUVGLE1BQU0sU0FBUztHQUNiO0dBQ0E7R0FDQSxZQUFZO0VBQ2Q7RUFDQSxJQUFJLFlBQVksU0FDZCxPQUFPLFdBQVcsWUFBWTtFQUVoQyxnQkFBZ0IsYUFBYSxTQUFTLFlBQVksU0FBUyxNQUFNLENBQUMsQ0FBQyxNQUFLLFNBQVE7R0FDOUUsTUFBTSxXQUFXO0lBQ2YsR0FBRztJQUtILGNBQWMsUUFBUSxZQUFZO0dBQ3BDO0dBQ0EsSUFBSSxhQUFhLFdBQVcsQ0FBQyxVQUFVLFFBQVEsU0FBUyxRQUFRLEdBQUc7SUFDakUsUUFBUSxVQUFVO0lBQ2xCLGlCQUFTLGdCQUFnQjtLQUN2QixRQUFRLFFBQVE7SUFDbEIsQ0FBQztHQUNIO0VBQ0YsQ0FBQztDQUNILEdBQUc7RUFBQztFQUFrQjtFQUFXO0VBQVU7RUFBYTtDQUFPLENBQUM7Q0FDaEUsWUFBWTtFQUNWLElBQUksU0FBUyxTQUFTLFFBQVEsUUFBUSxjQUFjO0dBQ2xELFFBQVEsUUFBUSxlQUFlO0dBQy9CLFNBQVEsVUFBUztJQUNmLEdBQUc7SUFDSCxjQUFjO0dBQ2hCLEVBQUU7RUFDSjtDQUNGLEdBQUcsQ0FBQyxJQUFJLENBQUM7Q0FDVCxNQUFNLGVBQUEsYUFBcUIsT0FBTyxLQUFLO0NBQ3ZDLFlBQVk7RUFDVixhQUFhLFVBQVU7RUFDdkIsYUFBYTtHQUNYLGFBQWEsVUFBVTtFQUN6QjtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBQ0wsWUFBWTtFQUNWLElBQUksYUFBYSxhQUFhLFVBQVU7RUFDeEMsSUFBSSxZQUFZLFlBQVksVUFBVTtFQUN0QyxJQUFJLGVBQWUsWUFBWTtHQUM3QixJQUFJLHdCQUF3QixTQUMxQixPQUFPLHdCQUF3QixRQUFRLGFBQWEsWUFBWSxNQUFNO0dBRXhFLE9BQU87RUFDVDtDQUNGLEdBQUc7RUFBQztFQUFhO0VBQVk7RUFBUTtFQUF5QjtDQUF1QixDQUFDO0NBQ3RGLE1BQU0sT0FBQSxhQUFhLGVBQWU7RUFDaEMsV0FBVztFQUNYLFVBQVU7RUFDVjtFQUNBO0NBQ0YsSUFBSSxDQUFDLGNBQWMsV0FBVyxDQUFDO0NBQy9CLE1BQU0sV0FBQSxhQUFpQixlQUFlO0VBQ3BDLFdBQVc7RUFDWCxVQUFVO0NBQ1osSUFBSSxDQUFDLGFBQWEsVUFBVSxDQUFDO0NBQzdCLE1BQU0saUJBQUEsYUFBdUIsY0FBYztFQUN6QyxNQUFNLGdCQUFnQjtHQUNwQixVQUFVO0dBQ1YsTUFBTTtHQUNOLEtBQUs7RUFDUDtFQUNBLElBQUksQ0FBQyxTQUFTLFVBQ1osT0FBTztFQUVULE1BQU0sSUFBSSxXQUFXLFNBQVMsVUFBVSxLQUFLLENBQUM7RUFDOUMsTUFBTSxJQUFJLFdBQVcsU0FBUyxVQUFVLEtBQUssQ0FBQztFQUM5QyxJQUFJLFdBQ0YsT0FBTztHQUNMLEdBQUc7R0FDSCxXQUFXLGVBQWUsSUFBSSxTQUFTLElBQUk7R0FDM0MsR0FBSSxPQUFPLFNBQVMsUUFBUSxLQUFLLE9BQU8sRUFDdEMsWUFBWSxZQUNkO0VBQ0Y7RUFFRixPQUFPO0dBQ0wsVUFBVTtHQUNWLE1BQU07R0FDTixLQUFLO0VBQ1A7Q0FDRixHQUFHO0VBQUM7RUFBVTtFQUFXLFNBQVM7RUFBVSxLQUFLO0VBQUcsS0FBSztDQUFDLENBQUM7Q0FDM0QsT0FBQSxhQUFhLGVBQWU7RUFDMUIsR0FBRztFQUNIO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsSUFBSTtFQUFDO0VBQU07RUFBUTtFQUFNO0VBQVU7Q0FBYyxDQUFDO0FBQ3BEOzs7Ozs7O0FBUUEsSUFBTSxXQUFVLFlBQVc7Q0FDekIsU0FBUyxNQUFNLE9BQU87RUFDcEIsT0FBTyxDQUFDLEVBQUUsZUFBZSxLQUFLLE9BQU8sU0FBUztDQUNoRDtDQUNBLE9BQU87RUFDTCxNQUFNO0VBQ047RUFDQSxHQUFHLE9BQU87R0FDUixNQUFNLEVBQ0osU0FDQSxZQUNFLE9BQU8sWUFBWSxhQUFhLFFBQVEsS0FBSyxJQUFJO0dBQ3JELElBQUksV0FBVyxNQUFNLE9BQU8sR0FBRztJQUM3QixJQUFJLFFBQVEsV0FBVyxNQUNyQixPQUFPLFFBQVE7S0FDYixTQUFTLFFBQVE7S0FDakI7SUFDRixDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUs7SUFFYixPQUFPLENBQUM7R0FDVjtHQUNBLElBQUksU0FDRixPQUFPLFFBQVE7SUFDYjtJQUNBO0dBQ0YsQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLO0dBRWIsT0FBTyxDQUFDO0VBQ1Y7Q0FDRjtBQUNGOzs7Ozs7OztBQVNBLElBQU0sVUFBVSxTQUFTLFNBQVM7Q0FDaEMsTUFBTSxTQUFTLFNBQVMsT0FBTztDQUMvQixPQUFPO0VBQ0wsTUFBTSxPQUFPO0VBQ2IsSUFBSSxPQUFPO0VBQ1gsU0FBUyxDQUFDLFNBQVMsSUFBSTtDQUN6QjtBQUNGOzs7Ozs7QUFPQSxJQUFNLFNBQVMsU0FBUyxTQUFTO0NBQy9CLE1BQU0sU0FBUyxRQUFRLE9BQU87Q0FDOUIsT0FBTztFQUNMLE1BQU0sT0FBTztFQUNiLElBQUksT0FBTztFQUNYLFNBQVMsQ0FBQyxTQUFTLElBQUk7Q0FDekI7QUFDRjs7OztBQUtBLElBQU0sY0FBYyxTQUFTLFNBQVM7Q0FFcEMsT0FBTztFQUNMLElBRmEsYUFBYSxPQUVqQixDQUFDLENBQUM7RUFDWCxTQUFTLENBQUMsU0FBUyxJQUFJO0NBQ3pCO0FBQ0Y7Ozs7Ozs7QUFRQSxJQUFNLFFBQVEsU0FBUyxTQUFTO0NBQzlCLE1BQU0sU0FBUyxPQUFPLE9BQU87Q0FDN0IsT0FBTztFQUNMLE1BQU0sT0FBTztFQUNiLElBQUksT0FBTztFQUNYLFNBQVMsQ0FBQyxTQUFTLElBQUk7Q0FDekI7QUFDRjs7Ozs7OztBQVFBLElBQU0sUUFBUSxTQUFTLFNBQVM7Q0FDOUIsTUFBTSxTQUFTLE9BQU8sT0FBTztDQUM3QixPQUFPO0VBQ0wsTUFBTSxPQUFPO0VBQ2IsSUFBSSxPQUFPO0VBQ1gsU0FBUyxDQUFDLFNBQVMsSUFBSTtDQUN6QjtBQUNGOzs7Ozs7QUFzQkEsSUFBTSxRQUFRLFNBQVMsU0FBUztDQUM5QixNQUFNLFNBQVMsT0FBTyxPQUFPO0NBQzdCLE9BQU87RUFDTCxNQUFNLE9BQU87RUFDYixJQUFJLE9BQU87RUFDWCxTQUFTLENBQUMsU0FBUyxJQUFJO0NBQ3pCO0FBQ0Y7Ozs7Ozs7QUFzQkEsSUFBTSxTQUFTLFNBQVMsU0FBUztDQUMvQixNQUFNLFNBQVMsUUFBUSxPQUFPO0NBQzlCLE9BQU87RUFDTCxNQUFNLE9BQU87RUFDYixJQUFJLE9BQU87RUFDWCxTQUFTLENBQUMsU0FBUyxJQUFJO0NBQ3pCO0FBQ0Y7Ozs7QUNuWkEsSUFBSUMsY0FBWSxPQUFPO0FBQ3ZCLElBQUlDLFlBQVUsUUFBUSxVQUFVRCxZQUFVLFFBQVEsUUFBUTtDQUFFO0NBQU8sY0FBYztBQUFLLENBQUM7QUF1QnZGLElBQUksT0FBT0UsZ0JBakJpQixhQUFNLFdBQ2hCLHlCQUFPLFNBQVMsT0FBTyxPQUFPLGNBQWM7Q0FDMUQsTUFBTSxFQUFFLFVBQVUsUUFBUSxJQUFJLFNBQVMsR0FBRyxHQUFHLGVBQWU7Q0FDNUQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ3JCLFVBQVUsS0FDVjtFQUNFLEdBQUc7RUFDSCxLQUFLO0VBQ0w7RUFDQTtFQUNBLFNBQVM7RUFDVCxxQkFBcUI7RUFDckIsVUFBVSxNQUFNLFVBQVUsV0FBMkIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksV0FBVyxFQUFFLFFBQVEsaUJBQWlCLENBQUM7Q0FDbEcsQ0FDRjtBQUNGLEdBQUcsT0FBTyxDQUVEQTs7O0FDdkJYLElBQUksWUFBWSxPQUFPO0FBQ3ZCLElBQUksVUFBVSxRQUFRLFVBQVUsVUFBVSxRQUFRLFFBQVE7Q0FBRTtDQUFPLGNBQWM7QUFBSyxDQUFDO0FBeUJ2RixJQUFJLGNBQWM7QUFDbEIsSUFBSSxDQUFDLHFCQUFxQixxQkFBcUIsbUJBQW1CLFdBQVc7QUFDN0UsSUFBSSxDQUFDLGdCQUFnQixvQkFBb0Isb0JBQW9CLFdBQVc7QUFDeEUsSUFBSSxTQUF5Qix3QkFBUSxVQUFVO0NBQzdDLE1BQU0sRUFBRSxlQUFlLGFBQWE7Q0FDcEMsTUFBTSxDQUFDLFFBQVEsYUFBQSxhQUFtQixTQUFTLElBQUk7Q0FDL0MsTUFBTSxDQUFDLGdCQUFnQixxQkFBQSxhQUEyQixTQUFTLEtBQUssQ0FBQztDQUNqRSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDckIsZ0JBQ0E7RUFDRSxPQUFPO0VBQ1A7RUFDQSxnQkFBZ0I7RUFDaEI7RUFDQTtFQUNBO0NBQ0YsQ0FDRjtBQUNGLEdBQUcsUUFBUTtBQUNYLElBQUksY0FBYztBQUNsQixJQUFJLGVBQStCLDZCQUFNLFdBQ3ZCLHVCQUFPLFNBQVMsY0FBYyxPQUFPLGNBQWM7Q0FDakUsTUFBTSxFQUFFLGVBQWUsWUFBWSxHQUFHLGdCQUFnQjtDQUN0RCxNQUFNLFVBQVUsaUJBQWlCLGFBQWEsYUFBYTtDQUMzRCxNQUFNLE1BQUEsYUFBWSxPQUFPLElBQUk7Q0FDN0IsTUFBTSxpQkFBaUIsUUFBUTtDQUMvQixNQUFNLGNBQUEsYUFBb0IsYUFDdkIsU0FBUztFQUNSLElBQUksVUFBVTtFQUNkLElBQUksTUFDRixlQUFlLElBQUk7Q0FFdkIsR0FDQSxDQUFDLGNBQWMsQ0FDakI7Q0FDQSxNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsV0FBVztDQUM5RCxNQUFNLFlBQUEsYUFBa0IsT0FBTyxJQUFJO0NBQ25DLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksQ0FBQyxZQUNIO0VBRUYsTUFBTSxpQkFBaUIsVUFBVTtFQUNqQyxVQUFVLFVBQVUsV0FBVztFQUMvQixJQUFJLG1CQUFtQixVQUFVLFNBQy9CLGVBQWUsVUFBVSxPQUFPO0NBRXBDLENBQUM7Q0FDRCxNQUFNLGVBQWUsUUFBUSxrQkFBa0IsNkJBQTZCLFFBQVEsY0FBYztDQUNsRyxNQUFNLGFBQWEsZUFBZTtDQUNsQyxNQUFNLGNBQWMsZUFBZTtDQUNuQyxPQUFPLGFBQWEsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ3pDLFVBQVUsS0FDVjtFQUNFLDBCQUEwQjtFQUMxQiwyQkFBMkI7RUFDM0IsR0FBRztFQUNILEtBQUs7Q0FDUCxDQUNGO0FBQ0YsR0FBRyxjQUFjLENBQ25CO0FBQ0EsSUFBSSxlQUFlO0FBQ25CLElBQUksQ0FBQyx1QkFBdUIscUJBQXFCLG9CQUFvQixZQUFZO0FBQ2pGLElBQUksZ0JBQWdDLDZCQUFNLFdBQ3hCLHVCQUFPLFNBQVMsZUFBZSxPQUFPLGNBQWM7Q0FDbEUsTUFBTSxFQUNKLGVBQ0EsT0FBTyxVQUNQLGFBQWEsR0FDYixRQUFRLFVBQ1IsY0FBYyxHQUNkLGVBQWUsR0FDZixrQkFBa0IsTUFDbEIsb0JBQW9CLENBQUMsR0FDckIsa0JBQWtCLHVCQUF1QixHQUN6QyxTQUFTLFdBQ1QsbUJBQW1CLE9BQ25CLHlCQUF5QixhQUN6QixVQUNBLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLFVBQVUsaUJBQWlCLGNBQWMsYUFBYTtDQUM1RCxNQUFNLENBQUMsU0FBUyxjQUFBLGFBQW9CLFNBQVMsSUFBSTtDQUNqRCxNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsVUFBVTtDQUM3RCxNQUFNLENBQUNDLFNBQU8sWUFBQSxhQUFrQixTQUFTLElBQUk7Q0FDN0MsTUFBTSxZQUFZLFFBQVFBLE9BQUs7Q0FDL0IsTUFBTSxhQUFhLFdBQVcsU0FBUztDQUN2QyxNQUFNLGNBQWMsV0FBVyxVQUFVO0NBQ3pDLE1BQU0sbUJBQW1CLFFBQVEsVUFBVSxXQUFXLE1BQU0sUUFBUTtDQUNwRSxNQUFNLG1CQUFtQixPQUFPLHlCQUF5QixXQUFXLHVCQUF1QjtFQUFFLEtBQUs7RUFBRyxPQUFPO0VBQUcsUUFBUTtFQUFHLE1BQU07RUFBRyxHQUFHO0NBQXFCO0NBQzNKLE1BQU0sV0FBVyxNQUFNLFFBQVEsaUJBQWlCLElBQUksb0JBQW9CLENBQUMsaUJBQWlCO0NBQzFGLE1BQU0sd0JBQXdCLFNBQVMsU0FBUztDQUNoRCxNQUFNLHdCQUF3QjtFQUM1QixTQUFTO0VBQ1QsVUFBVSxTQUFTLE9BQU8sU0FBUztFQUVuQyxhQUFhO0NBQ2Y7Q0FDQSxNQUFNLEVBQUUsTUFBTSxnQkFBZ0IsV0FBVyxjQUFjLG1CQUFtQixZQUFZO0VBRXBGLFVBQVU7RUFDVixXQUFXO0VBQ1gsc0JBQXNDLHdCQUFRLEdBQUcsU0FBUztHQUl4RCxPQUhnQixXQUFXLEdBQUcsTUFBTSxFQUNsQyxnQkFBZ0IsMkJBQTJCLFNBQzdDLENBQ2E7RUFDZixHQUFHLHNCQUFzQjtFQUN6QixVQUFVLEVBQ1IsV0FBVyxRQUFRLE9BQ3JCO0VBQ0EsWUFBWTtHQUNWLE9BQU87SUFBRSxVQUFVLGFBQWE7SUFBYSxlQUFlO0dBQVksQ0FBQztHQUN6RSxtQkFBbUIsTUFBTTtJQUN2QixVQUFVO0lBQ1YsV0FBVztJQUNYLFNBQVMsV0FBVyxZQUFZLFdBQVcsSUFBSSxLQUFLO0lBQ3BELEdBQUc7R0FDTCxDQUFDO0dBQ0QsbUJBQW1CLEtBQUssRUFBRSxHQUFHLHNCQUFzQixDQUFDO0dBQ3BELEtBQUs7SUFDSCxHQUFHO0lBQ0gsT0FBdUIsd0JBQVEsRUFBRSxVQUFVLE9BQU8sZ0JBQWdCLHNCQUFzQjtLQUN0RixNQUFNLEVBQUUsT0FBTyxhQUFhLFFBQVEsaUJBQWlCLE1BQU07S0FDM0QsTUFBTSxlQUFlLFNBQVMsU0FBUztLQUN2QyxhQUFhLFlBQVksa0NBQWtDLEdBQUcsZUFBZSxHQUFHO0tBQ2hGLGFBQWEsWUFBWSxtQ0FBbUMsR0FBRyxnQkFBZ0IsR0FBRztLQUNsRixhQUFhLFlBQVksK0JBQStCLEdBQUcsWUFBWSxHQUFHO0tBQzFFLGFBQWEsWUFBWSxnQ0FBZ0MsR0FBRyxhQUFhLEdBQUc7SUFDOUUsR0FBRyxPQUFPO0dBQ1osQ0FBQztHQUNEQSxXQUFTQyxNQUFnQjtJQUFFLFNBQVNEO0lBQU8sU0FBUztHQUFhLENBQUM7R0FDbEUsZ0JBQWdCO0lBQUU7SUFBWTtHQUFZLENBQUM7R0FDM0Msb0JBQW9CLEtBQUs7SUFDdkIsVUFBVTtJQUNWLEdBQUc7SUFRSCxVQUFVLHdCQUF3QixzQkFBc0IsV0FBVyxLQUFLO0dBQzFFLENBQUM7RUFDSDtDQUNGLENBQUM7Q0FDRCxNQUFNLG9CQUFvQixRQUFRO0NBQ2xDLHVCQUFzQjtFQUNwQixrQkFBa0IsU0FBUztFQUMzQixhQUFhO0dBQ1gsa0JBQWtCLEtBQUssQ0FBQztFQUMxQjtDQUNGLEdBQUcsQ0FBQyxXQUFXLGlCQUFpQixDQUFDO0NBQ2pDLE1BQU0sQ0FBQyxZQUFZLGVBQWUsNkJBQTZCLFNBQVM7Q0FDeEUsTUFBTSxlQUFlLGVBQWUsUUFBUTtDQUM1Qyx1QkFBc0I7RUFDcEIsSUFBSSxjQUNGLGVBQWU7Q0FFbkIsR0FBRyxDQUFDLGNBQWMsWUFBWSxDQUFDO0NBQy9CLE1BQU0sU0FBUyxlQUFlLE9BQU87Q0FDckMsTUFBTSxTQUFTLGVBQWUsT0FBTztDQUNyQyxNQUFNLG9CQUFvQixlQUFlLE9BQU8saUJBQWlCO0NBQ2pFLE1BQU0sQ0FBQyxlQUFlLG9CQUFBLGFBQTBCLFNBQVM7Q0FDekQsdUJBQXNCO0VBQ3BCLElBQUksU0FBUyxpQkFBaUIsT0FBTyxpQkFBaUIsT0FBTyxDQUFDLENBQUMsTUFBTTtDQUN2RSxHQUFHLENBQUMsT0FBTyxDQUFDO0NBQ1osT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ3JCLE9BQ0E7RUFDRSxLQUFLLEtBQUs7RUFDVixxQ0FBcUM7RUFDckMsT0FBTztHQUNMLEdBQUc7R0FDSCxXQUFXLGVBQWUsZUFBZSxZQUFZO0dBRXJELFVBQVU7R0FDVixRQUFRO0dBQ1IsbUNBQW1DLENBQ2pDLGVBQWUsaUJBQWlCLEdBQ2hDLGVBQWUsaUJBQWlCLENBQ2xDLENBQUMsQ0FBQyxLQUFLLEdBQUc7R0FJVixHQUFHLGVBQWUsTUFBTSxtQkFBbUI7SUFDekMsWUFBWTtJQUNaLGVBQWU7R0FDakI7RUFDRjtFQUNBLEtBQUssTUFBTTtFQUNYLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUN4Qix1QkFDQTtHQUNFLE9BQU87R0FDUDtHQUNBO0dBQ0EsZUFBZTtHQUNmO0dBQ0E7R0FDQSxpQkFBaUI7R0FDakIsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ3hCLFVBQVUsS0FDVjtJQUNFLGFBQWE7SUFDYixjQUFjO0lBQ2QsR0FBRztJQUNILEtBQUs7SUFDTCxPQUFPO0tBQ0wsR0FBRyxhQUFhO0tBSWhCLFdBQVcsQ0FBQyxlQUFlLFNBQVMsYUFBYSxPQUFPO0lBQzFEO0dBQ0YsQ0FDRjtFQUNGLENBQ0Y7Q0FDRixDQUNGO0FBQ0YsR0FBRyxlQUFlLENBQ3BCO0FBQ0EsSUFBSSxhQUFhO0FBQ2pCLElBQUksZ0JBQWdCO0NBQ2xCLEtBQUs7Q0FDTCxPQUFPO0NBQ1AsUUFBUTtDQUNSLE1BQU07QUFDUjtBQUNBLElBQUksY0FBOEIsNkJBQU0sV0FDdEIsdUJBQU8sU0FBUyxhQUFhLE9BQU8sY0FBYztDQUNoRSxNQUFNLEVBQUUsZUFBZSxHQUFHLGVBQWU7Q0FDekMsTUFBTSxpQkFBaUIsa0JBQWtCLFlBQVksYUFBYTtDQUNsRSxNQUFNLFdBQVcsY0FBYyxlQUFlO0NBQzlDLE9BSWtCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUNkLFFBQ0E7RUFDRSxLQUFLLGVBQWU7RUFDcEIsT0FBTztHQUNMLFVBQVU7R0FDVixNQUFNLGVBQWU7R0FDckIsS0FBSyxlQUFlO0lBQ25CLFdBQVc7R0FDWixpQkFBaUI7SUFDZixLQUFLO0lBQ0wsT0FBTztJQUNQLFFBQVE7SUFDUixNQUFNO0dBQ1IsRUFBRSxlQUFlO0dBQ2pCLFdBQVc7SUFDVCxLQUFLO0lBQ0wsT0FBTztJQUNQLFFBQVE7SUFDUixNQUFNO0dBQ1IsRUFBRSxlQUFlO0dBQ2pCLFlBQVksZUFBZSxrQkFBa0IsV0FBVyxLQUFLO0VBQy9EO0VBQ0EsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ3hCRSxNQUNBO0dBQ0UsR0FBRztHQUNILEtBQUs7R0FDTCxPQUFPO0lBQ0wsR0FBRyxXQUFXO0lBRWQsU0FBUztHQUNYO0VBQ0YsQ0FDRjtDQUNGLENBQ0Y7QUFFSixHQUFHLGFBQWEsQ0FDbEI7QUFDQSxTQUFTLFVBQVUsT0FBTztDQUN4QixPQUFPLFVBQVU7QUFDbkI7QUFDQSxPQUFPLFdBQVcsV0FBVztBQUM3QixJQUFJLGtCQUFrQyx3QkFBUSxhQUFhO0NBQ3pELE1BQU07Q0FDTjtDQUNBLEdBQUcsTUFBTTtFQUNQLE1BQU0sRUFBRSxXQUFXLE9BQU8sbUJBQW1CO0VBRTdDLE1BQU0sZ0JBRG9CLGVBQWUsT0FBTyxpQkFBaUI7RUFFakUsTUFBTSxhQUFhLGdCQUFnQixJQUFJLFFBQVE7RUFDL0MsTUFBTSxjQUFjLGdCQUFnQixJQUFJLFFBQVE7RUFDaEQsTUFBTSxDQUFDLFlBQVksZUFBZSw2QkFBNkIsU0FBUztFQUN4RSxNQUFNLGVBQWU7R0FBRSxPQUFPO0dBQU0sUUFBUTtHQUFPLEtBQUs7RUFBTyxFQUFFO0VBQ2pFLE1BQU0sZ0JBQWdCLGVBQWUsT0FBTyxLQUFLLEtBQUssYUFBYTtFQUNuRSxNQUFNLGdCQUFnQixlQUFlLE9BQU8sS0FBSyxLQUFLLGNBQWM7RUFDcEUsSUFBSSxJQUFJO0VBQ1IsSUFBSSxJQUFJO0VBQ1IsSUFBSSxlQUFlLFVBQVU7R0FDM0IsSUFBSSxnQkFBZ0IsZUFBZSxHQUFHLGFBQWE7R0FDbkQsSUFBSSxHQUFHLENBQUMsWUFBWTtFQUN0QixPQUFPLElBQUksZUFBZSxPQUFPO0dBQy9CLElBQUksZ0JBQWdCLGVBQWUsR0FBRyxhQUFhO0dBQ25ELElBQUksR0FBRyxNQUFNLFNBQVMsU0FBUyxZQUFZO0VBQzdDLE9BQU8sSUFBSSxlQUFlLFNBQVM7R0FDakMsSUFBSSxHQUFHLENBQUMsWUFBWTtHQUNwQixJQUFJLGdCQUFnQixlQUFlLEdBQUcsYUFBYTtFQUNyRCxPQUFPLElBQUksZUFBZSxRQUFRO0dBQ2hDLElBQUksR0FBRyxNQUFNLFNBQVMsUUFBUSxZQUFZO0dBQzFDLElBQUksZ0JBQWdCLGVBQWUsR0FBRyxhQUFhO0VBQ3JEO0VBQ0EsT0FBTyxFQUFFLE1BQU07R0FBRTtHQUFHO0VBQUUsRUFBRTtDQUMxQjtBQUNGLElBQUksaUJBQWlCO0FBQ3JCLFNBQVMsNkJBQTZCLFdBQVc7Q0FDL0MsTUFBTSxDQUFDLE1BQU0sUUFBUSxZQUFZLFVBQVUsTUFBTSxHQUFHO0NBQ3BELE9BQU8sQ0FBQyxNQUFNLEtBQUs7QUFDckI7QUFDQSxPQUFPLDhCQUE4Qiw4QkFBOEI7QUFDbkUsSUFBSSxRQUFRO0FBQ1osSUFBSSxTQUFTO0FBQ2IsSUFBSSxVQUFVO0FBQ2QsSUFBSSxRQUFRIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDZdfQ==