import { t as __commonJSMin } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=a8030269";
//#region node_modules/jsqr/dist/jsQR.js
var require_jsQR = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function webpackUniversalModuleDefinition(root, factory) {
		if (typeof exports === "object" && typeof module === "object") module.exports = factory();
		else if (typeof define === "function" && define.amd) define([], factory);
		else if (typeof exports === "object") exports["jsQR"] = factory();
		else root["jsQR"] = factory();
	})(typeof self !== "undefined" ? self : exports, function() {
		return (function(modules) {
			var installedModules = {};
			function __webpack_require__(moduleId) {
				if (installedModules[moduleId]) return installedModules[moduleId].exports;
				var module$1 = installedModules[moduleId] = {
					i: moduleId,
					l: false,
					exports: {}
				};
				modules[moduleId].call(module$1.exports, module$1, module$1.exports, __webpack_require__);
				module$1.l = true;
				return module$1.exports;
			}
			__webpack_require__.m = modules;
			__webpack_require__.c = installedModules;
			__webpack_require__.d = function(exports$1, name, getter) {
				if (!__webpack_require__.o(exports$1, name)) Object.defineProperty(exports$1, name, {
					configurable: false,
					enumerable: true,
					get: getter
				});
			};
			__webpack_require__.n = function(module$2) {
				var getter = module$2 && module$2.__esModule ? function getDefault() {
					return module$2["default"];
				} : function getModuleExports() {
					return module$2;
				};
				__webpack_require__.d(getter, "a", getter);
				return getter;
			};
			__webpack_require__.o = function(object, property) {
				return Object.prototype.hasOwnProperty.call(object, property);
			};
			__webpack_require__.p = "";
			return __webpack_require__(__webpack_require__.s = 3);
		})([
			(function(module$3, exports$2, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$2, "__esModule", { value: true });
				exports$2.BitMatrix = function() {
					function BitMatrix(data, width) {
						this.width = width;
						this.height = data.length / width;
						this.data = data;
					}
					BitMatrix.createEmpty = function(width, height) {
						return new BitMatrix(new Uint8ClampedArray(width * height), width);
					};
					BitMatrix.prototype.get = function(x, y) {
						if (x < 0 || x >= this.width || y < 0 || y >= this.height) return false;
						return !!this.data[y * this.width + x];
					};
					BitMatrix.prototype.set = function(x, y, v) {
						this.data[y * this.width + x] = v ? 1 : 0;
					};
					BitMatrix.prototype.setRegion = function(left, top, width, height, v) {
						for (var y = top; y < top + height; y++) for (var x = left; x < left + width; x++) this.set(x, y, !!v);
					};
					return BitMatrix;
				}();
			}),
			(function(module$4, exports$3, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$3, "__esModule", { value: true });
				var GenericGFPoly_1 = __webpack_require__(2);
				function addOrSubtractGF(a, b) {
					return a ^ b;
				}
				exports$3.addOrSubtractGF = addOrSubtractGF;
				exports$3.default = function() {
					function GenericGF(primitive, size, genBase) {
						this.primitive = primitive;
						this.size = size;
						this.generatorBase = genBase;
						this.expTable = new Array(this.size);
						this.logTable = new Array(this.size);
						var x = 1;
						for (var i = 0; i < this.size; i++) {
							this.expTable[i] = x;
							x = x * 2;
							if (x >= this.size) x = (x ^ this.primitive) & this.size - 1;
						}
						for (var i = 0; i < this.size - 1; i++) this.logTable[this.expTable[i]] = i;
						this.zero = new GenericGFPoly_1.default(this, Uint8ClampedArray.from([0]));
						this.one = new GenericGFPoly_1.default(this, Uint8ClampedArray.from([1]));
					}
					GenericGF.prototype.multiply = function(a, b) {
						if (a === 0 || b === 0) return 0;
						return this.expTable[(this.logTable[a] + this.logTable[b]) % (this.size - 1)];
					};
					GenericGF.prototype.inverse = function(a) {
						if (a === 0) throw new Error("Can't invert 0");
						return this.expTable[this.size - this.logTable[a] - 1];
					};
					GenericGF.prototype.buildMonomial = function(degree, coefficient) {
						if (degree < 0) throw new Error("Invalid monomial degree less than 0");
						if (coefficient === 0) return this.zero;
						var coefficients = new Uint8ClampedArray(degree + 1);
						coefficients[0] = coefficient;
						return new GenericGFPoly_1.default(this, coefficients);
					};
					GenericGF.prototype.log = function(a) {
						if (a === 0) throw new Error("Can't take log(0)");
						return this.logTable[a];
					};
					GenericGF.prototype.exp = function(a) {
						return this.expTable[a];
					};
					return GenericGF;
				}();
			}),
			(function(module$5, exports$4, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$4, "__esModule", { value: true });
				var GenericGF_1 = __webpack_require__(1);
				exports$4.default = function() {
					function GenericGFPoly(field, coefficients) {
						if (coefficients.length === 0) throw new Error("No coefficients.");
						this.field = field;
						var coefficientsLength = coefficients.length;
						if (coefficientsLength > 1 && coefficients[0] === 0) {
							var firstNonZero = 1;
							while (firstNonZero < coefficientsLength && coefficients[firstNonZero] === 0) firstNonZero++;
							if (firstNonZero === coefficientsLength) this.coefficients = field.zero.coefficients;
							else {
								this.coefficients = new Uint8ClampedArray(coefficientsLength - firstNonZero);
								for (var i = 0; i < this.coefficients.length; i++) this.coefficients[i] = coefficients[firstNonZero + i];
							}
						} else this.coefficients = coefficients;
					}
					GenericGFPoly.prototype.degree = function() {
						return this.coefficients.length - 1;
					};
					GenericGFPoly.prototype.isZero = function() {
						return this.coefficients[0] === 0;
					};
					GenericGFPoly.prototype.getCoefficient = function(degree) {
						return this.coefficients[this.coefficients.length - 1 - degree];
					};
					GenericGFPoly.prototype.addOrSubtract = function(other) {
						var _a;
						if (this.isZero()) return other;
						if (other.isZero()) return this;
						var smallerCoefficients = this.coefficients;
						var largerCoefficients = other.coefficients;
						if (smallerCoefficients.length > largerCoefficients.length) _a = [largerCoefficients, smallerCoefficients], smallerCoefficients = _a[0], largerCoefficients = _a[1];
						var sumDiff = new Uint8ClampedArray(largerCoefficients.length);
						var lengthDiff = largerCoefficients.length - smallerCoefficients.length;
						for (var i = 0; i < lengthDiff; i++) sumDiff[i] = largerCoefficients[i];
						for (var i = lengthDiff; i < largerCoefficients.length; i++) sumDiff[i] = GenericGF_1.addOrSubtractGF(smallerCoefficients[i - lengthDiff], largerCoefficients[i]);
						return new GenericGFPoly(this.field, sumDiff);
					};
					GenericGFPoly.prototype.multiply = function(scalar) {
						if (scalar === 0) return this.field.zero;
						if (scalar === 1) return this;
						var size = this.coefficients.length;
						var product = new Uint8ClampedArray(size);
						for (var i = 0; i < size; i++) product[i] = this.field.multiply(this.coefficients[i], scalar);
						return new GenericGFPoly(this.field, product);
					};
					GenericGFPoly.prototype.multiplyPoly = function(other) {
						if (this.isZero() || other.isZero()) return this.field.zero;
						var aCoefficients = this.coefficients;
						var aLength = aCoefficients.length;
						var bCoefficients = other.coefficients;
						var bLength = bCoefficients.length;
						var product = new Uint8ClampedArray(aLength + bLength - 1);
						for (var i = 0; i < aLength; i++) {
							var aCoeff = aCoefficients[i];
							for (var j = 0; j < bLength; j++) product[i + j] = GenericGF_1.addOrSubtractGF(product[i + j], this.field.multiply(aCoeff, bCoefficients[j]));
						}
						return new GenericGFPoly(this.field, product);
					};
					GenericGFPoly.prototype.multiplyByMonomial = function(degree, coefficient) {
						if (degree < 0) throw new Error("Invalid degree less than 0");
						if (coefficient === 0) return this.field.zero;
						var size = this.coefficients.length;
						var product = new Uint8ClampedArray(size + degree);
						for (var i = 0; i < size; i++) product[i] = this.field.multiply(this.coefficients[i], coefficient);
						return new GenericGFPoly(this.field, product);
					};
					GenericGFPoly.prototype.evaluateAt = function(a) {
						var result = 0;
						if (a === 0) return this.getCoefficient(0);
						var size = this.coefficients.length;
						if (a === 1) {
							this.coefficients.forEach(function(coefficient) {
								result = GenericGF_1.addOrSubtractGF(result, coefficient);
							});
							return result;
						}
						result = this.coefficients[0];
						for (var i = 1; i < size; i++) result = GenericGF_1.addOrSubtractGF(this.field.multiply(a, result), this.coefficients[i]);
						return result;
					};
					return GenericGFPoly;
				}();
			}),
			(function(module$6, exports$5, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$5, "__esModule", { value: true });
				var binarizer_1 = __webpack_require__(4);
				var decoder_1 = __webpack_require__(5);
				var extractor_1 = __webpack_require__(11);
				var locator_1 = __webpack_require__(12);
				function scan(matrix) {
					var locations = locator_1.locate(matrix);
					if (!locations) return null;
					for (var _i = 0, locations_1 = locations; _i < locations_1.length; _i++) {
						var location_1 = locations_1[_i];
						var extracted = extractor_1.extract(matrix, location_1);
						var decoded = decoder_1.decode(extracted.matrix);
						if (decoded) return {
							binaryData: decoded.bytes,
							data: decoded.text,
							chunks: decoded.chunks,
							version: decoded.version,
							location: {
								topRightCorner: extracted.mappingFunction(location_1.dimension, 0),
								topLeftCorner: extracted.mappingFunction(0, 0),
								bottomRightCorner: extracted.mappingFunction(location_1.dimension, location_1.dimension),
								bottomLeftCorner: extracted.mappingFunction(0, location_1.dimension),
								topRightFinderPattern: location_1.topRight,
								topLeftFinderPattern: location_1.topLeft,
								bottomLeftFinderPattern: location_1.bottomLeft,
								bottomRightAlignmentPattern: location_1.alignmentPattern
							}
						};
					}
					return null;
				}
				var defaultOptions = { inversionAttempts: "attemptBoth" };
				function jsQR(data, width, height, providedOptions) {
					if (providedOptions === void 0) providedOptions = {};
					var options = defaultOptions;
					Object.keys(options || {}).forEach(function(opt) {
						options[opt] = providedOptions[opt] || options[opt];
					});
					var shouldInvert = options.inversionAttempts === "attemptBoth" || options.inversionAttempts === "invertFirst";
					var tryInvertedFirst = options.inversionAttempts === "onlyInvert" || options.inversionAttempts === "invertFirst";
					var _a = binarizer_1.binarize(data, width, height, shouldInvert), binarized = _a.binarized, inverted = _a.inverted;
					var result = scan(tryInvertedFirst ? inverted : binarized);
					if (!result && (options.inversionAttempts === "attemptBoth" || options.inversionAttempts === "invertFirst")) result = scan(tryInvertedFirst ? binarized : inverted);
					return result;
				}
				jsQR.default = jsQR;
				exports$5.default = jsQR;
			}),
			(function(module$7, exports$6, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$6, "__esModule", { value: true });
				var BitMatrix_1 = __webpack_require__(0);
				var REGION_SIZE = 8;
				var MIN_DYNAMIC_RANGE = 24;
				function numBetween(value, min, max) {
					return value < min ? min : value > max ? max : value;
				}
				var Matrix = function() {
					function Matrix(width, height) {
						this.width = width;
						this.data = new Uint8ClampedArray(width * height);
					}
					Matrix.prototype.get = function(x, y) {
						return this.data[y * this.width + x];
					};
					Matrix.prototype.set = function(x, y, value) {
						this.data[y * this.width + x] = value;
					};
					return Matrix;
				}();
				function binarize(data, width, height, returnInverted) {
					if (data.length !== width * height * 4) throw new Error("Malformed data passed to binarizer.");
					var greyscalePixels = new Matrix(width, height);
					for (var x = 0; x < width; x++) for (var y = 0; y < height; y++) {
						var r = data[(y * width + x) * 4 + 0];
						var g = data[(y * width + x) * 4 + 1];
						var b = data[(y * width + x) * 4 + 2];
						greyscalePixels.set(x, y, .2126 * r + .7152 * g + .0722 * b);
					}
					var horizontalRegionCount = Math.ceil(width / REGION_SIZE);
					var verticalRegionCount = Math.ceil(height / REGION_SIZE);
					var blackPoints = new Matrix(horizontalRegionCount, verticalRegionCount);
					for (var verticalRegion = 0; verticalRegion < verticalRegionCount; verticalRegion++) for (var hortizontalRegion = 0; hortizontalRegion < horizontalRegionCount; hortizontalRegion++) {
						var sum = 0;
						var min = Infinity;
						var max = 0;
						for (var y = 0; y < REGION_SIZE; y++) for (var x = 0; x < REGION_SIZE; x++) {
							var pixelLumosity = greyscalePixels.get(hortizontalRegion * REGION_SIZE + x, verticalRegion * REGION_SIZE + y);
							sum += pixelLumosity;
							min = Math.min(min, pixelLumosity);
							max = Math.max(max, pixelLumosity);
						}
						var average = sum / Math.pow(REGION_SIZE, 2);
						if (max - min <= MIN_DYNAMIC_RANGE) {
							average = min / 2;
							if (verticalRegion > 0 && hortizontalRegion > 0) {
								var averageNeighborBlackPoint = (blackPoints.get(hortizontalRegion, verticalRegion - 1) + 2 * blackPoints.get(hortizontalRegion - 1, verticalRegion) + blackPoints.get(hortizontalRegion - 1, verticalRegion - 1)) / 4;
								if (min < averageNeighborBlackPoint) average = averageNeighborBlackPoint;
							}
						}
						blackPoints.set(hortizontalRegion, verticalRegion, average);
					}
					var binarized = BitMatrix_1.BitMatrix.createEmpty(width, height);
					var inverted = null;
					if (returnInverted) inverted = BitMatrix_1.BitMatrix.createEmpty(width, height);
					for (var verticalRegion = 0; verticalRegion < verticalRegionCount; verticalRegion++) for (var hortizontalRegion = 0; hortizontalRegion < horizontalRegionCount; hortizontalRegion++) {
						var left = numBetween(hortizontalRegion, 2, horizontalRegionCount - 3);
						var top_1 = numBetween(verticalRegion, 2, verticalRegionCount - 3);
						var sum = 0;
						for (var xRegion = -2; xRegion <= 2; xRegion++) for (var yRegion = -2; yRegion <= 2; yRegion++) sum += blackPoints.get(left + xRegion, top_1 + yRegion);
						var threshold = sum / 25;
						for (var xRegion = 0; xRegion < REGION_SIZE; xRegion++) for (var yRegion = 0; yRegion < REGION_SIZE; yRegion++) {
							var x = hortizontalRegion * REGION_SIZE + xRegion;
							var y = verticalRegion * REGION_SIZE + yRegion;
							var lum = greyscalePixels.get(x, y);
							binarized.set(x, y, lum <= threshold);
							if (returnInverted) inverted.set(x, y, !(lum <= threshold));
						}
					}
					if (returnInverted) return {
						binarized,
						inverted
					};
					return { binarized };
				}
				exports$6.binarize = binarize;
			}),
			(function(module$8, exports$7, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$7, "__esModule", { value: true });
				var BitMatrix_1 = __webpack_require__(0);
				var decodeData_1 = __webpack_require__(6);
				var reedsolomon_1 = __webpack_require__(9);
				var version_1 = __webpack_require__(10);
				function numBitsDiffering(x, y) {
					var z = x ^ y;
					var bitCount = 0;
					while (z) {
						bitCount++;
						z &= z - 1;
					}
					return bitCount;
				}
				function pushBit(bit, byte) {
					return byte << 1 | bit;
				}
				var FORMAT_INFO_TABLE = [
					{
						bits: 21522,
						formatInfo: {
							errorCorrectionLevel: 1,
							dataMask: 0
						}
					},
					{
						bits: 20773,
						formatInfo: {
							errorCorrectionLevel: 1,
							dataMask: 1
						}
					},
					{
						bits: 24188,
						formatInfo: {
							errorCorrectionLevel: 1,
							dataMask: 2
						}
					},
					{
						bits: 23371,
						formatInfo: {
							errorCorrectionLevel: 1,
							dataMask: 3
						}
					},
					{
						bits: 17913,
						formatInfo: {
							errorCorrectionLevel: 1,
							dataMask: 4
						}
					},
					{
						bits: 16590,
						formatInfo: {
							errorCorrectionLevel: 1,
							dataMask: 5
						}
					},
					{
						bits: 20375,
						formatInfo: {
							errorCorrectionLevel: 1,
							dataMask: 6
						}
					},
					{
						bits: 19104,
						formatInfo: {
							errorCorrectionLevel: 1,
							dataMask: 7
						}
					},
					{
						bits: 30660,
						formatInfo: {
							errorCorrectionLevel: 0,
							dataMask: 0
						}
					},
					{
						bits: 29427,
						formatInfo: {
							errorCorrectionLevel: 0,
							dataMask: 1
						}
					},
					{
						bits: 32170,
						formatInfo: {
							errorCorrectionLevel: 0,
							dataMask: 2
						}
					},
					{
						bits: 30877,
						formatInfo: {
							errorCorrectionLevel: 0,
							dataMask: 3
						}
					},
					{
						bits: 26159,
						formatInfo: {
							errorCorrectionLevel: 0,
							dataMask: 4
						}
					},
					{
						bits: 25368,
						formatInfo: {
							errorCorrectionLevel: 0,
							dataMask: 5
						}
					},
					{
						bits: 27713,
						formatInfo: {
							errorCorrectionLevel: 0,
							dataMask: 6
						}
					},
					{
						bits: 26998,
						formatInfo: {
							errorCorrectionLevel: 0,
							dataMask: 7
						}
					},
					{
						bits: 5769,
						formatInfo: {
							errorCorrectionLevel: 3,
							dataMask: 0
						}
					},
					{
						bits: 5054,
						formatInfo: {
							errorCorrectionLevel: 3,
							dataMask: 1
						}
					},
					{
						bits: 7399,
						formatInfo: {
							errorCorrectionLevel: 3,
							dataMask: 2
						}
					},
					{
						bits: 6608,
						formatInfo: {
							errorCorrectionLevel: 3,
							dataMask: 3
						}
					},
					{
						bits: 1890,
						formatInfo: {
							errorCorrectionLevel: 3,
							dataMask: 4
						}
					},
					{
						bits: 597,
						formatInfo: {
							errorCorrectionLevel: 3,
							dataMask: 5
						}
					},
					{
						bits: 3340,
						formatInfo: {
							errorCorrectionLevel: 3,
							dataMask: 6
						}
					},
					{
						bits: 2107,
						formatInfo: {
							errorCorrectionLevel: 3,
							dataMask: 7
						}
					},
					{
						bits: 13663,
						formatInfo: {
							errorCorrectionLevel: 2,
							dataMask: 0
						}
					},
					{
						bits: 12392,
						formatInfo: {
							errorCorrectionLevel: 2,
							dataMask: 1
						}
					},
					{
						bits: 16177,
						formatInfo: {
							errorCorrectionLevel: 2,
							dataMask: 2
						}
					},
					{
						bits: 14854,
						formatInfo: {
							errorCorrectionLevel: 2,
							dataMask: 3
						}
					},
					{
						bits: 9396,
						formatInfo: {
							errorCorrectionLevel: 2,
							dataMask: 4
						}
					},
					{
						bits: 8579,
						formatInfo: {
							errorCorrectionLevel: 2,
							dataMask: 5
						}
					},
					{
						bits: 11994,
						formatInfo: {
							errorCorrectionLevel: 2,
							dataMask: 6
						}
					},
					{
						bits: 11245,
						formatInfo: {
							errorCorrectionLevel: 2,
							dataMask: 7
						}
					}
				];
				var DATA_MASKS = [
					function(p) {
						return (p.y + p.x) % 2 === 0;
					},
					function(p) {
						return p.y % 2 === 0;
					},
					function(p) {
						return p.x % 3 === 0;
					},
					function(p) {
						return (p.y + p.x) % 3 === 0;
					},
					function(p) {
						return (Math.floor(p.y / 2) + Math.floor(p.x / 3)) % 2 === 0;
					},
					function(p) {
						return p.x * p.y % 2 + p.x * p.y % 3 === 0;
					},
					function(p) {
						return (p.y * p.x % 2 + p.y * p.x % 3) % 2 === 0;
					},
					function(p) {
						return ((p.y + p.x) % 2 + p.y * p.x % 3) % 2 === 0;
					}
				];
				function buildFunctionPatternMask(version) {
					var dimension = 17 + 4 * version.versionNumber;
					var matrix = BitMatrix_1.BitMatrix.createEmpty(dimension, dimension);
					matrix.setRegion(0, 0, 9, 9, true);
					matrix.setRegion(dimension - 8, 0, 8, 9, true);
					matrix.setRegion(0, dimension - 8, 9, 8, true);
					for (var _i = 0, _a = version.alignmentPatternCenters; _i < _a.length; _i++) {
						var x = _a[_i];
						for (var _b = 0, _c = version.alignmentPatternCenters; _b < _c.length; _b++) {
							var y = _c[_b];
							if (!(x === 6 && y === 6 || x === 6 && y === dimension - 7 || x === dimension - 7 && y === 6)) matrix.setRegion(x - 2, y - 2, 5, 5, true);
						}
					}
					matrix.setRegion(6, 9, 1, dimension - 17, true);
					matrix.setRegion(9, 6, dimension - 17, 1, true);
					if (version.versionNumber > 6) {
						matrix.setRegion(dimension - 11, 0, 3, 6, true);
						matrix.setRegion(0, dimension - 11, 6, 3, true);
					}
					return matrix;
				}
				function readCodewords(matrix, version, formatInfo) {
					var dataMask = DATA_MASKS[formatInfo.dataMask];
					var dimension = matrix.height;
					var functionPatternMask = buildFunctionPatternMask(version);
					var codewords = [];
					var currentByte = 0;
					var bitsRead = 0;
					var readingUp = true;
					for (var columnIndex = dimension - 1; columnIndex > 0; columnIndex -= 2) {
						if (columnIndex === 6) columnIndex--;
						for (var i = 0; i < dimension; i++) {
							var y = readingUp ? dimension - 1 - i : i;
							for (var columnOffset = 0; columnOffset < 2; columnOffset++) {
								var x = columnIndex - columnOffset;
								if (!functionPatternMask.get(x, y)) {
									bitsRead++;
									var bit = matrix.get(x, y);
									if (dataMask({
										y,
										x
									})) bit = !bit;
									currentByte = pushBit(bit, currentByte);
									if (bitsRead === 8) {
										codewords.push(currentByte);
										bitsRead = 0;
										currentByte = 0;
									}
								}
							}
						}
						readingUp = !readingUp;
					}
					return codewords;
				}
				function readVersion(matrix) {
					var dimension = matrix.height;
					var provisionalVersion = Math.floor((dimension - 17) / 4);
					if (provisionalVersion <= 6) return version_1.VERSIONS[provisionalVersion - 1];
					var topRightVersionBits = 0;
					for (var y = 5; y >= 0; y--) for (var x = dimension - 9; x >= dimension - 11; x--) topRightVersionBits = pushBit(matrix.get(x, y), topRightVersionBits);
					var bottomLeftVersionBits = 0;
					for (var x = 5; x >= 0; x--) for (var y = dimension - 9; y >= dimension - 11; y--) bottomLeftVersionBits = pushBit(matrix.get(x, y), bottomLeftVersionBits);
					var bestDifference = Infinity;
					var bestVersion;
					for (var _i = 0, VERSIONS_1 = version_1.VERSIONS; _i < VERSIONS_1.length; _i++) {
						var version = VERSIONS_1[_i];
						if (version.infoBits === topRightVersionBits || version.infoBits === bottomLeftVersionBits) return version;
						var difference = numBitsDiffering(topRightVersionBits, version.infoBits);
						if (difference < bestDifference) {
							bestVersion = version;
							bestDifference = difference;
						}
						difference = numBitsDiffering(bottomLeftVersionBits, version.infoBits);
						if (difference < bestDifference) {
							bestVersion = version;
							bestDifference = difference;
						}
					}
					if (bestDifference <= 3) return bestVersion;
				}
				function readFormatInformation(matrix) {
					var topLeftFormatInfoBits = 0;
					for (var x = 0; x <= 8; x++) if (x !== 6) topLeftFormatInfoBits = pushBit(matrix.get(x, 8), topLeftFormatInfoBits);
					for (var y = 7; y >= 0; y--) if (y !== 6) topLeftFormatInfoBits = pushBit(matrix.get(8, y), topLeftFormatInfoBits);
					var dimension = matrix.height;
					var topRightBottomRightFormatInfoBits = 0;
					for (var y = dimension - 1; y >= dimension - 7; y--) topRightBottomRightFormatInfoBits = pushBit(matrix.get(8, y), topRightBottomRightFormatInfoBits);
					for (var x = dimension - 8; x < dimension; x++) topRightBottomRightFormatInfoBits = pushBit(matrix.get(x, 8), topRightBottomRightFormatInfoBits);
					var bestDifference = Infinity;
					var bestFormatInfo = null;
					for (var _i = 0, FORMAT_INFO_TABLE_1 = FORMAT_INFO_TABLE; _i < FORMAT_INFO_TABLE_1.length; _i++) {
						var _a = FORMAT_INFO_TABLE_1[_i], bits = _a.bits, formatInfo = _a.formatInfo;
						if (bits === topLeftFormatInfoBits || bits === topRightBottomRightFormatInfoBits) return formatInfo;
						var difference = numBitsDiffering(topLeftFormatInfoBits, bits);
						if (difference < bestDifference) {
							bestFormatInfo = formatInfo;
							bestDifference = difference;
						}
						if (topLeftFormatInfoBits !== topRightBottomRightFormatInfoBits) {
							difference = numBitsDiffering(topRightBottomRightFormatInfoBits, bits);
							if (difference < bestDifference) {
								bestFormatInfo = formatInfo;
								bestDifference = difference;
							}
						}
					}
					if (bestDifference <= 3) return bestFormatInfo;
					return null;
				}
				function getDataBlocks(codewords, version, ecLevel) {
					var ecInfo = version.errorCorrectionLevels[ecLevel];
					var dataBlocks = [];
					var totalCodewords = 0;
					ecInfo.ecBlocks.forEach(function(block) {
						for (var i = 0; i < block.numBlocks; i++) {
							dataBlocks.push({
								numDataCodewords: block.dataCodewordsPerBlock,
								codewords: []
							});
							totalCodewords += block.dataCodewordsPerBlock + ecInfo.ecCodewordsPerBlock;
						}
					});
					if (codewords.length < totalCodewords) return null;
					codewords = codewords.slice(0, totalCodewords);
					var shortBlockSize = ecInfo.ecBlocks[0].dataCodewordsPerBlock;
					for (var i = 0; i < shortBlockSize; i++) for (var _i = 0, dataBlocks_1 = dataBlocks; _i < dataBlocks_1.length; _i++) {
						var dataBlock = dataBlocks_1[_i];
						dataBlock.codewords.push(codewords.shift());
					}
					if (ecInfo.ecBlocks.length > 1) {
						var smallBlockCount = ecInfo.ecBlocks[0].numBlocks;
						var largeBlockCount = ecInfo.ecBlocks[1].numBlocks;
						for (var i = 0; i < largeBlockCount; i++) dataBlocks[smallBlockCount + i].codewords.push(codewords.shift());
					}
					while (codewords.length > 0) for (var _a = 0, dataBlocks_2 = dataBlocks; _a < dataBlocks_2.length; _a++) {
						var dataBlock = dataBlocks_2[_a];
						dataBlock.codewords.push(codewords.shift());
					}
					return dataBlocks;
				}
				function decodeMatrix(matrix) {
					var version = readVersion(matrix);
					if (!version) return null;
					var formatInfo = readFormatInformation(matrix);
					if (!formatInfo) return null;
					var dataBlocks = getDataBlocks(readCodewords(matrix, version, formatInfo), version, formatInfo.errorCorrectionLevel);
					if (!dataBlocks) return null;
					var totalBytes = dataBlocks.reduce(function(a, b) {
						return a + b.numDataCodewords;
					}, 0);
					var resultBytes = new Uint8ClampedArray(totalBytes);
					var resultIndex = 0;
					for (var _i = 0, dataBlocks_3 = dataBlocks; _i < dataBlocks_3.length; _i++) {
						var dataBlock = dataBlocks_3[_i];
						var correctedBytes = reedsolomon_1.decode(dataBlock.codewords, dataBlock.codewords.length - dataBlock.numDataCodewords);
						if (!correctedBytes) return null;
						for (var i = 0; i < dataBlock.numDataCodewords; i++) resultBytes[resultIndex++] = correctedBytes[i];
					}
					try {
						return decodeData_1.decode(resultBytes, version.versionNumber);
					} catch (_a) {
						return null;
					}
				}
				function decode(matrix) {
					if (matrix == null) return null;
					var result = decodeMatrix(matrix);
					if (result) return result;
					for (var x = 0; x < matrix.width; x++) for (var y = x + 1; y < matrix.height; y++) if (matrix.get(x, y) !== matrix.get(y, x)) {
						matrix.set(x, y, !matrix.get(x, y));
						matrix.set(y, x, !matrix.get(y, x));
					}
					return decodeMatrix(matrix);
				}
				exports$7.decode = decode;
			}),
			(function(module$9, exports$8, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$8, "__esModule", { value: true });
				var BitStream_1 = __webpack_require__(7);
				var shiftJISTable_1 = __webpack_require__(8);
				var Mode;
				(function(Mode) {
					Mode["Numeric"] = "numeric";
					Mode["Alphanumeric"] = "alphanumeric";
					Mode["Byte"] = "byte";
					Mode["Kanji"] = "kanji";
					Mode["ECI"] = "eci";
				})(Mode = exports$8.Mode || (exports$8.Mode = {}));
				var ModeByte;
				(function(ModeByte) {
					ModeByte[ModeByte["Terminator"] = 0] = "Terminator";
					ModeByte[ModeByte["Numeric"] = 1] = "Numeric";
					ModeByte[ModeByte["Alphanumeric"] = 2] = "Alphanumeric";
					ModeByte[ModeByte["Byte"] = 4] = "Byte";
					ModeByte[ModeByte["Kanji"] = 8] = "Kanji";
					ModeByte[ModeByte["ECI"] = 7] = "ECI";
				})(ModeByte || (ModeByte = {}));
				function decodeNumeric(stream, size) {
					var bytes = [];
					var text = "";
					var characterCountSize = [
						10,
						12,
						14
					][size];
					var length = stream.readBits(characterCountSize);
					while (length >= 3) {
						var num = stream.readBits(10);
						if (num >= 1e3) throw new Error("Invalid numeric value above 999");
						var a = Math.floor(num / 100);
						var b = Math.floor(num / 10) % 10;
						var c = num % 10;
						bytes.push(48 + a, 48 + b, 48 + c);
						text += a.toString() + b.toString() + c.toString();
						length -= 3;
					}
					if (length === 2) {
						var num = stream.readBits(7);
						if (num >= 100) throw new Error("Invalid numeric value above 99");
						var a = Math.floor(num / 10);
						var b = num % 10;
						bytes.push(48 + a, 48 + b);
						text += a.toString() + b.toString();
					} else if (length === 1) {
						var num = stream.readBits(4);
						if (num >= 10) throw new Error("Invalid numeric value above 9");
						bytes.push(48 + num);
						text += num.toString();
					}
					return {
						bytes,
						text
					};
				}
				var AlphanumericCharacterCodes = [
					"0",
					"1",
					"2",
					"3",
					"4",
					"5",
					"6",
					"7",
					"8",
					"9",
					"A",
					"B",
					"C",
					"D",
					"E",
					"F",
					"G",
					"H",
					"I",
					"J",
					"K",
					"L",
					"M",
					"N",
					"O",
					"P",
					"Q",
					"R",
					"S",
					"T",
					"U",
					"V",
					"W",
					"X",
					"Y",
					"Z",
					" ",
					"$",
					"%",
					"*",
					"+",
					"-",
					".",
					"/",
					":"
				];
				function decodeAlphanumeric(stream, size) {
					var bytes = [];
					var text = "";
					var characterCountSize = [
						9,
						11,
						13
					][size];
					var length = stream.readBits(characterCountSize);
					while (length >= 2) {
						var v = stream.readBits(11);
						var a = Math.floor(v / 45);
						var b = v % 45;
						bytes.push(AlphanumericCharacterCodes[a].charCodeAt(0), AlphanumericCharacterCodes[b].charCodeAt(0));
						text += AlphanumericCharacterCodes[a] + AlphanumericCharacterCodes[b];
						length -= 2;
					}
					if (length === 1) {
						var a = stream.readBits(6);
						bytes.push(AlphanumericCharacterCodes[a].charCodeAt(0));
						text += AlphanumericCharacterCodes[a];
					}
					return {
						bytes,
						text
					};
				}
				function decodeByte(stream, size) {
					var bytes = [];
					var text = "";
					var characterCountSize = [
						8,
						16,
						16
					][size];
					var length = stream.readBits(characterCountSize);
					for (var i = 0; i < length; i++) {
						var b = stream.readBits(8);
						bytes.push(b);
					}
					try {
						text += decodeURIComponent(bytes.map(function(b) {
							return "%" + ("0" + b.toString(16)).substr(-2);
						}).join(""));
					} catch (_a) {}
					return {
						bytes,
						text
					};
				}
				function decodeKanji(stream, size) {
					var bytes = [];
					var text = "";
					var characterCountSize = [
						8,
						10,
						12
					][size];
					var length = stream.readBits(characterCountSize);
					for (var i = 0; i < length; i++) {
						var k = stream.readBits(13);
						var c = Math.floor(k / 192) << 8 | k % 192;
						if (c < 7936) c += 33088;
						else c += 49472;
						bytes.push(c >> 8, c & 255);
						text += String.fromCharCode(shiftJISTable_1.shiftJISTable[c]);
					}
					return {
						bytes,
						text
					};
				}
				function decode(data, version) {
					var _a, _b, _c, _d;
					var stream = new BitStream_1.BitStream(data);
					var size = version <= 9 ? 0 : version <= 26 ? 1 : 2;
					var result = {
						text: "",
						bytes: [],
						chunks: [],
						version
					};
					while (stream.available() >= 4) {
						var mode = stream.readBits(4);
						if (mode === ModeByte.Terminator) return result;
						else if (mode === ModeByte.ECI) {
							if (stream.readBits(1) === 0) result.chunks.push({
								type: Mode.ECI,
								assignmentNumber: stream.readBits(7)
							});
							else if (stream.readBits(1) === 0) result.chunks.push({
								type: Mode.ECI,
								assignmentNumber: stream.readBits(14)
							});
							else if (stream.readBits(1) === 0) result.chunks.push({
								type: Mode.ECI,
								assignmentNumber: stream.readBits(21)
							});
							else result.chunks.push({
								type: Mode.ECI,
								assignmentNumber: -1
							});
						} else if (mode === ModeByte.Numeric) {
							var numericResult = decodeNumeric(stream, size);
							result.text += numericResult.text;
							(_a = result.bytes).push.apply(_a, numericResult.bytes);
							result.chunks.push({
								type: Mode.Numeric,
								text: numericResult.text
							});
						} else if (mode === ModeByte.Alphanumeric) {
							var alphanumericResult = decodeAlphanumeric(stream, size);
							result.text += alphanumericResult.text;
							(_b = result.bytes).push.apply(_b, alphanumericResult.bytes);
							result.chunks.push({
								type: Mode.Alphanumeric,
								text: alphanumericResult.text
							});
						} else if (mode === ModeByte.Byte) {
							var byteResult = decodeByte(stream, size);
							result.text += byteResult.text;
							(_c = result.bytes).push.apply(_c, byteResult.bytes);
							result.chunks.push({
								type: Mode.Byte,
								bytes: byteResult.bytes,
								text: byteResult.text
							});
						} else if (mode === ModeByte.Kanji) {
							var kanjiResult = decodeKanji(stream, size);
							result.text += kanjiResult.text;
							(_d = result.bytes).push.apply(_d, kanjiResult.bytes);
							result.chunks.push({
								type: Mode.Kanji,
								bytes: kanjiResult.bytes,
								text: kanjiResult.text
							});
						}
					}
					if (stream.available() === 0 || stream.readBits(stream.available()) === 0) return result;
				}
				exports$8.decode = decode;
			}),
			(function(module$10, exports$9, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$9, "__esModule", { value: true });
				exports$9.BitStream = function() {
					function BitStream(bytes) {
						this.byteOffset = 0;
						this.bitOffset = 0;
						this.bytes = bytes;
					}
					BitStream.prototype.readBits = function(numBits) {
						if (numBits < 1 || numBits > 32 || numBits > this.available()) throw new Error("Cannot read " + numBits.toString() + " bits");
						var result = 0;
						if (this.bitOffset > 0) {
							var bitsLeft = 8 - this.bitOffset;
							var toRead = numBits < bitsLeft ? numBits : bitsLeft;
							var bitsToNotRead = bitsLeft - toRead;
							var mask = 255 >> 8 - toRead << bitsToNotRead;
							result = (this.bytes[this.byteOffset] & mask) >> bitsToNotRead;
							numBits -= toRead;
							this.bitOffset += toRead;
							if (this.bitOffset === 8) {
								this.bitOffset = 0;
								this.byteOffset++;
							}
						}
						if (numBits > 0) {
							while (numBits >= 8) {
								result = result << 8 | this.bytes[this.byteOffset] & 255;
								this.byteOffset++;
								numBits -= 8;
							}
							if (numBits > 0) {
								var bitsToNotRead = 8 - numBits;
								var mask = 255 >> bitsToNotRead << bitsToNotRead;
								result = result << numBits | (this.bytes[this.byteOffset] & mask) >> bitsToNotRead;
								this.bitOffset += numBits;
							}
						}
						return result;
					};
					BitStream.prototype.available = function() {
						return 8 * (this.bytes.length - this.byteOffset) - this.bitOffset;
					};
					return BitStream;
				}();
			}),
			(function(module$11, exports$10, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$10, "__esModule", { value: true });
				exports$10.shiftJISTable = {
					32: 32,
					33: 33,
					34: 34,
					35: 35,
					36: 36,
					37: 37,
					38: 38,
					39: 39,
					40: 40,
					41: 41,
					42: 42,
					43: 43,
					44: 44,
					45: 45,
					46: 46,
					47: 47,
					48: 48,
					49: 49,
					50: 50,
					51: 51,
					52: 52,
					53: 53,
					54: 54,
					55: 55,
					56: 56,
					57: 57,
					58: 58,
					59: 59,
					60: 60,
					61: 61,
					62: 62,
					63: 63,
					64: 64,
					65: 65,
					66: 66,
					67: 67,
					68: 68,
					69: 69,
					70: 70,
					71: 71,
					72: 72,
					73: 73,
					74: 74,
					75: 75,
					76: 76,
					77: 77,
					78: 78,
					79: 79,
					80: 80,
					81: 81,
					82: 82,
					83: 83,
					84: 84,
					85: 85,
					86: 86,
					87: 87,
					88: 88,
					89: 89,
					90: 90,
					91: 91,
					92: 165,
					93: 93,
					94: 94,
					95: 95,
					96: 96,
					97: 97,
					98: 98,
					99: 99,
					100: 100,
					101: 101,
					102: 102,
					103: 103,
					104: 104,
					105: 105,
					106: 106,
					107: 107,
					108: 108,
					109: 109,
					110: 110,
					111: 111,
					112: 112,
					113: 113,
					114: 114,
					115: 115,
					116: 116,
					117: 117,
					118: 118,
					119: 119,
					120: 120,
					121: 121,
					122: 122,
					123: 123,
					124: 124,
					125: 125,
					126: 8254,
					33088: 12288,
					33089: 12289,
					33090: 12290,
					33091: 65292,
					33092: 65294,
					33093: 12539,
					33094: 65306,
					33095: 65307,
					33096: 65311,
					33097: 65281,
					33098: 12443,
					33099: 12444,
					33100: 180,
					33101: 65344,
					33102: 168,
					33103: 65342,
					33104: 65507,
					33105: 65343,
					33106: 12541,
					33107: 12542,
					33108: 12445,
					33109: 12446,
					33110: 12291,
					33111: 20189,
					33112: 12293,
					33113: 12294,
					33114: 12295,
					33115: 12540,
					33116: 8213,
					33117: 8208,
					33118: 65295,
					33119: 92,
					33120: 12316,
					33121: 8214,
					33122: 65372,
					33123: 8230,
					33124: 8229,
					33125: 8216,
					33126: 8217,
					33127: 8220,
					33128: 8221,
					33129: 65288,
					33130: 65289,
					33131: 12308,
					33132: 12309,
					33133: 65339,
					33134: 65341,
					33135: 65371,
					33136: 65373,
					33137: 12296,
					33138: 12297,
					33139: 12298,
					33140: 12299,
					33141: 12300,
					33142: 12301,
					33143: 12302,
					33144: 12303,
					33145: 12304,
					33146: 12305,
					33147: 65291,
					33148: 8722,
					33149: 177,
					33150: 215,
					33152: 247,
					33153: 65309,
					33154: 8800,
					33155: 65308,
					33156: 65310,
					33157: 8806,
					33158: 8807,
					33159: 8734,
					33160: 8756,
					33161: 9794,
					33162: 9792,
					33163: 176,
					33164: 8242,
					33165: 8243,
					33166: 8451,
					33167: 65509,
					33168: 65284,
					33169: 162,
					33170: 163,
					33171: 65285,
					33172: 65283,
					33173: 65286,
					33174: 65290,
					33175: 65312,
					33176: 167,
					33177: 9734,
					33178: 9733,
					33179: 9675,
					33180: 9679,
					33181: 9678,
					33182: 9671,
					33183: 9670,
					33184: 9633,
					33185: 9632,
					33186: 9651,
					33187: 9650,
					33188: 9661,
					33189: 9660,
					33190: 8251,
					33191: 12306,
					33192: 8594,
					33193: 8592,
					33194: 8593,
					33195: 8595,
					33196: 12307,
					33208: 8712,
					33209: 8715,
					33210: 8838,
					33211: 8839,
					33212: 8834,
					33213: 8835,
					33214: 8746,
					33215: 8745,
					33224: 8743,
					33225: 8744,
					33226: 172,
					33227: 8658,
					33228: 8660,
					33229: 8704,
					33230: 8707,
					33242: 8736,
					33243: 8869,
					33244: 8978,
					33245: 8706,
					33246: 8711,
					33247: 8801,
					33248: 8786,
					33249: 8810,
					33250: 8811,
					33251: 8730,
					33252: 8765,
					33253: 8733,
					33254: 8757,
					33255: 8747,
					33256: 8748,
					33264: 8491,
					33265: 8240,
					33266: 9839,
					33267: 9837,
					33268: 9834,
					33269: 8224,
					33270: 8225,
					33271: 182,
					33276: 9711,
					33359: 65296,
					33360: 65297,
					33361: 65298,
					33362: 65299,
					33363: 65300,
					33364: 65301,
					33365: 65302,
					33366: 65303,
					33367: 65304,
					33368: 65305,
					33376: 65313,
					33377: 65314,
					33378: 65315,
					33379: 65316,
					33380: 65317,
					33381: 65318,
					33382: 65319,
					33383: 65320,
					33384: 65321,
					33385: 65322,
					33386: 65323,
					33387: 65324,
					33388: 65325,
					33389: 65326,
					33390: 65327,
					33391: 65328,
					33392: 65329,
					33393: 65330,
					33394: 65331,
					33395: 65332,
					33396: 65333,
					33397: 65334,
					33398: 65335,
					33399: 65336,
					33400: 65337,
					33401: 65338,
					33409: 65345,
					33410: 65346,
					33411: 65347,
					33412: 65348,
					33413: 65349,
					33414: 65350,
					33415: 65351,
					33416: 65352,
					33417: 65353,
					33418: 65354,
					33419: 65355,
					33420: 65356,
					33421: 65357,
					33422: 65358,
					33423: 65359,
					33424: 65360,
					33425: 65361,
					33426: 65362,
					33427: 65363,
					33428: 65364,
					33429: 65365,
					33430: 65366,
					33431: 65367,
					33432: 65368,
					33433: 65369,
					33434: 65370,
					33439: 12353,
					33440: 12354,
					33441: 12355,
					33442: 12356,
					33443: 12357,
					33444: 12358,
					33445: 12359,
					33446: 12360,
					33447: 12361,
					33448: 12362,
					33449: 12363,
					33450: 12364,
					33451: 12365,
					33452: 12366,
					33453: 12367,
					33454: 12368,
					33455: 12369,
					33456: 12370,
					33457: 12371,
					33458: 12372,
					33459: 12373,
					33460: 12374,
					33461: 12375,
					33462: 12376,
					33463: 12377,
					33464: 12378,
					33465: 12379,
					33466: 12380,
					33467: 12381,
					33468: 12382,
					33469: 12383,
					33470: 12384,
					33471: 12385,
					33472: 12386,
					33473: 12387,
					33474: 12388,
					33475: 12389,
					33476: 12390,
					33477: 12391,
					33478: 12392,
					33479: 12393,
					33480: 12394,
					33481: 12395,
					33482: 12396,
					33483: 12397,
					33484: 12398,
					33485: 12399,
					33486: 12400,
					33487: 12401,
					33488: 12402,
					33489: 12403,
					33490: 12404,
					33491: 12405,
					33492: 12406,
					33493: 12407,
					33494: 12408,
					33495: 12409,
					33496: 12410,
					33497: 12411,
					33498: 12412,
					33499: 12413,
					33500: 12414,
					33501: 12415,
					33502: 12416,
					33503: 12417,
					33504: 12418,
					33505: 12419,
					33506: 12420,
					33507: 12421,
					33508: 12422,
					33509: 12423,
					33510: 12424,
					33511: 12425,
					33512: 12426,
					33513: 12427,
					33514: 12428,
					33515: 12429,
					33516: 12430,
					33517: 12431,
					33518: 12432,
					33519: 12433,
					33520: 12434,
					33521: 12435,
					33600: 12449,
					33601: 12450,
					33602: 12451,
					33603: 12452,
					33604: 12453,
					33605: 12454,
					33606: 12455,
					33607: 12456,
					33608: 12457,
					33609: 12458,
					33610: 12459,
					33611: 12460,
					33612: 12461,
					33613: 12462,
					33614: 12463,
					33615: 12464,
					33616: 12465,
					33617: 12466,
					33618: 12467,
					33619: 12468,
					33620: 12469,
					33621: 12470,
					33622: 12471,
					33623: 12472,
					33624: 12473,
					33625: 12474,
					33626: 12475,
					33627: 12476,
					33628: 12477,
					33629: 12478,
					33630: 12479,
					33631: 12480,
					33632: 12481,
					33633: 12482,
					33634: 12483,
					33635: 12484,
					33636: 12485,
					33637: 12486,
					33638: 12487,
					33639: 12488,
					33640: 12489,
					33641: 12490,
					33642: 12491,
					33643: 12492,
					33644: 12493,
					33645: 12494,
					33646: 12495,
					33647: 12496,
					33648: 12497,
					33649: 12498,
					33650: 12499,
					33651: 12500,
					33652: 12501,
					33653: 12502,
					33654: 12503,
					33655: 12504,
					33656: 12505,
					33657: 12506,
					33658: 12507,
					33659: 12508,
					33660: 12509,
					33661: 12510,
					33662: 12511,
					33664: 12512,
					33665: 12513,
					33666: 12514,
					33667: 12515,
					33668: 12516,
					33669: 12517,
					33670: 12518,
					33671: 12519,
					33672: 12520,
					33673: 12521,
					33674: 12522,
					33675: 12523,
					33676: 12524,
					33677: 12525,
					33678: 12526,
					33679: 12527,
					33680: 12528,
					33681: 12529,
					33682: 12530,
					33683: 12531,
					33684: 12532,
					33685: 12533,
					33686: 12534,
					33695: 913,
					33696: 914,
					33697: 915,
					33698: 916,
					33699: 917,
					33700: 918,
					33701: 919,
					33702: 920,
					33703: 921,
					33704: 922,
					33705: 923,
					33706: 924,
					33707: 925,
					33708: 926,
					33709: 927,
					33710: 928,
					33711: 929,
					33712: 931,
					33713: 932,
					33714: 933,
					33715: 934,
					33716: 935,
					33717: 936,
					33718: 937,
					33727: 945,
					33728: 946,
					33729: 947,
					33730: 948,
					33731: 949,
					33732: 950,
					33733: 951,
					33734: 952,
					33735: 953,
					33736: 954,
					33737: 955,
					33738: 956,
					33739: 957,
					33740: 958,
					33741: 959,
					33742: 960,
					33743: 961,
					33744: 963,
					33745: 964,
					33746: 965,
					33747: 966,
					33748: 967,
					33749: 968,
					33750: 969,
					33856: 1040,
					33857: 1041,
					33858: 1042,
					33859: 1043,
					33860: 1044,
					33861: 1045,
					33862: 1025,
					33863: 1046,
					33864: 1047,
					33865: 1048,
					33866: 1049,
					33867: 1050,
					33868: 1051,
					33869: 1052,
					33870: 1053,
					33871: 1054,
					33872: 1055,
					33873: 1056,
					33874: 1057,
					33875: 1058,
					33876: 1059,
					33877: 1060,
					33878: 1061,
					33879: 1062,
					33880: 1063,
					33881: 1064,
					33882: 1065,
					33883: 1066,
					33884: 1067,
					33885: 1068,
					33886: 1069,
					33887: 1070,
					33888: 1071,
					33904: 1072,
					33905: 1073,
					33906: 1074,
					33907: 1075,
					33908: 1076,
					33909: 1077,
					33910: 1105,
					33911: 1078,
					33912: 1079,
					33913: 1080,
					33914: 1081,
					33915: 1082,
					33916: 1083,
					33917: 1084,
					33918: 1085,
					33920: 1086,
					33921: 1087,
					33922: 1088,
					33923: 1089,
					33924: 1090,
					33925: 1091,
					33926: 1092,
					33927: 1093,
					33928: 1094,
					33929: 1095,
					33930: 1096,
					33931: 1097,
					33932: 1098,
					33933: 1099,
					33934: 1100,
					33935: 1101,
					33936: 1102,
					33937: 1103,
					33951: 9472,
					33952: 9474,
					33953: 9484,
					33954: 9488,
					33955: 9496,
					33956: 9492,
					33957: 9500,
					33958: 9516,
					33959: 9508,
					33960: 9524,
					33961: 9532,
					33962: 9473,
					33963: 9475,
					33964: 9487,
					33965: 9491,
					33966: 9499,
					33967: 9495,
					33968: 9507,
					33969: 9523,
					33970: 9515,
					33971: 9531,
					33972: 9547,
					33973: 9504,
					33974: 9519,
					33975: 9512,
					33976: 9527,
					33977: 9535,
					33978: 9501,
					33979: 9520,
					33980: 9509,
					33981: 9528,
					33982: 9538,
					34975: 20124,
					34976: 21782,
					34977: 23043,
					34978: 38463,
					34979: 21696,
					34980: 24859,
					34981: 25384,
					34982: 23030,
					34983: 36898,
					34984: 33909,
					34985: 33564,
					34986: 31312,
					34987: 24746,
					34988: 25569,
					34989: 28197,
					34990: 26093,
					34991: 33894,
					34992: 33446,
					34993: 39925,
					34994: 26771,
					34995: 22311,
					34996: 26017,
					34997: 25201,
					34998: 23451,
					34999: 22992,
					35e3: 34427,
					35001: 39156,
					35002: 32098,
					35003: 32190,
					35004: 39822,
					35005: 25110,
					35006: 31903,
					35007: 34999,
					35008: 23433,
					35009: 24245,
					35010: 25353,
					35011: 26263,
					35012: 26696,
					35013: 38343,
					35014: 38797,
					35015: 26447,
					35016: 20197,
					35017: 20234,
					35018: 20301,
					35019: 20381,
					35020: 20553,
					35021: 22258,
					35022: 22839,
					35023: 22996,
					35024: 23041,
					35025: 23561,
					35026: 24799,
					35027: 24847,
					35028: 24944,
					35029: 26131,
					35030: 26885,
					35031: 28858,
					35032: 30031,
					35033: 30064,
					35034: 31227,
					35035: 32173,
					35036: 32239,
					35037: 32963,
					35038: 33806,
					35039: 34915,
					35040: 35586,
					35041: 36949,
					35042: 36986,
					35043: 21307,
					35044: 20117,
					35045: 20133,
					35046: 22495,
					35047: 32946,
					35048: 37057,
					35049: 30959,
					35050: 19968,
					35051: 22769,
					35052: 28322,
					35053: 36920,
					35054: 31282,
					35055: 33576,
					35056: 33419,
					35057: 39983,
					35058: 20801,
					35059: 21360,
					35060: 21693,
					35061: 21729,
					35062: 22240,
					35063: 23035,
					35064: 24341,
					35065: 39154,
					35066: 28139,
					35067: 32996,
					35068: 34093,
					35136: 38498,
					35137: 38512,
					35138: 38560,
					35139: 38907,
					35140: 21515,
					35141: 21491,
					35142: 23431,
					35143: 28879,
					35144: 32701,
					35145: 36802,
					35146: 38632,
					35147: 21359,
					35148: 40284,
					35149: 31418,
					35150: 19985,
					35151: 30867,
					35152: 33276,
					35153: 28198,
					35154: 22040,
					35155: 21764,
					35156: 27421,
					35157: 34074,
					35158: 39995,
					35159: 23013,
					35160: 21417,
					35161: 28006,
					35162: 29916,
					35163: 38287,
					35164: 22082,
					35165: 20113,
					35166: 36939,
					35167: 38642,
					35168: 33615,
					35169: 39180,
					35170: 21473,
					35171: 21942,
					35172: 23344,
					35173: 24433,
					35174: 26144,
					35175: 26355,
					35176: 26628,
					35177: 27704,
					35178: 27891,
					35179: 27945,
					35180: 29787,
					35181: 30408,
					35182: 31310,
					35183: 38964,
					35184: 33521,
					35185: 34907,
					35186: 35424,
					35187: 37613,
					35188: 28082,
					35189: 30123,
					35190: 30410,
					35191: 39365,
					35192: 24742,
					35193: 35585,
					35194: 36234,
					35195: 38322,
					35196: 27022,
					35197: 21421,
					35198: 20870,
					35200: 22290,
					35201: 22576,
					35202: 22852,
					35203: 23476,
					35204: 24310,
					35205: 24616,
					35206: 25513,
					35207: 25588,
					35208: 27839,
					35209: 28436,
					35210: 28814,
					35211: 28948,
					35212: 29017,
					35213: 29141,
					35214: 29503,
					35215: 32257,
					35216: 33398,
					35217: 33489,
					35218: 34199,
					35219: 36960,
					35220: 37467,
					35221: 40219,
					35222: 22633,
					35223: 26044,
					35224: 27738,
					35225: 29989,
					35226: 20985,
					35227: 22830,
					35228: 22885,
					35229: 24448,
					35230: 24540,
					35231: 25276,
					35232: 26106,
					35233: 27178,
					35234: 27431,
					35235: 27572,
					35236: 29579,
					35237: 32705,
					35238: 35158,
					35239: 40236,
					35240: 40206,
					35241: 40644,
					35242: 23713,
					35243: 27798,
					35244: 33659,
					35245: 20740,
					35246: 23627,
					35247: 25014,
					35248: 33222,
					35249: 26742,
					35250: 29281,
					35251: 20057,
					35252: 20474,
					35253: 21368,
					35254: 24681,
					35255: 28201,
					35256: 31311,
					35257: 38899,
					35258: 19979,
					35259: 21270,
					35260: 20206,
					35261: 20309,
					35262: 20285,
					35263: 20385,
					35264: 20339,
					35265: 21152,
					35266: 21487,
					35267: 22025,
					35268: 22799,
					35269: 23233,
					35270: 23478,
					35271: 23521,
					35272: 31185,
					35273: 26247,
					35274: 26524,
					35275: 26550,
					35276: 27468,
					35277: 27827,
					35278: 28779,
					35279: 29634,
					35280: 31117,
					35281: 31166,
					35282: 31292,
					35283: 31623,
					35284: 33457,
					35285: 33499,
					35286: 33540,
					35287: 33655,
					35288: 33775,
					35289: 33747,
					35290: 34662,
					35291: 35506,
					35292: 22057,
					35293: 36008,
					35294: 36838,
					35295: 36942,
					35296: 38686,
					35297: 34442,
					35298: 20420,
					35299: 23784,
					35300: 25105,
					35301: 29273,
					35302: 30011,
					35303: 33253,
					35304: 33469,
					35305: 34558,
					35306: 36032,
					35307: 38597,
					35308: 39187,
					35309: 39381,
					35310: 20171,
					35311: 20250,
					35312: 35299,
					35313: 22238,
					35314: 22602,
					35315: 22730,
					35316: 24315,
					35317: 24555,
					35318: 24618,
					35319: 24724,
					35320: 24674,
					35321: 25040,
					35322: 25106,
					35323: 25296,
					35324: 25913,
					35392: 39745,
					35393: 26214,
					35394: 26800,
					35395: 28023,
					35396: 28784,
					35397: 30028,
					35398: 30342,
					35399: 32117,
					35400: 33445,
					35401: 34809,
					35402: 38283,
					35403: 38542,
					35404: 35997,
					35405: 20977,
					35406: 21182,
					35407: 22806,
					35408: 21683,
					35409: 23475,
					35410: 23830,
					35411: 24936,
					35412: 27010,
					35413: 28079,
					35414: 30861,
					35415: 33995,
					35416: 34903,
					35417: 35442,
					35418: 37799,
					35419: 39608,
					35420: 28012,
					35421: 39336,
					35422: 34521,
					35423: 22435,
					35424: 26623,
					35425: 34510,
					35426: 37390,
					35427: 21123,
					35428: 22151,
					35429: 21508,
					35430: 24275,
					35431: 25313,
					35432: 25785,
					35433: 26684,
					35434: 26680,
					35435: 27579,
					35436: 29554,
					35437: 30906,
					35438: 31339,
					35439: 35226,
					35440: 35282,
					35441: 36203,
					35442: 36611,
					35443: 37101,
					35444: 38307,
					35445: 38548,
					35446: 38761,
					35447: 23398,
					35448: 23731,
					35449: 27005,
					35450: 38989,
					35451: 38990,
					35452: 25499,
					35453: 31520,
					35454: 27179,
					35456: 27263,
					35457: 26806,
					35458: 39949,
					35459: 28511,
					35460: 21106,
					35461: 21917,
					35462: 24688,
					35463: 25324,
					35464: 27963,
					35465: 28167,
					35466: 28369,
					35467: 33883,
					35468: 35088,
					35469: 36676,
					35470: 19988,
					35471: 39993,
					35472: 21494,
					35473: 26907,
					35474: 27194,
					35475: 38788,
					35476: 26666,
					35477: 20828,
					35478: 31427,
					35479: 33970,
					35480: 37340,
					35481: 37772,
					35482: 22107,
					35483: 40232,
					35484: 26658,
					35485: 33541,
					35486: 33841,
					35487: 31909,
					35488: 21e3,
					35489: 33477,
					35490: 29926,
					35491: 20094,
					35492: 20355,
					35493: 20896,
					35494: 23506,
					35495: 21002,
					35496: 21208,
					35497: 21223,
					35498: 24059,
					35499: 21914,
					35500: 22570,
					35501: 23014,
					35502: 23436,
					35503: 23448,
					35504: 23515,
					35505: 24178,
					35506: 24185,
					35507: 24739,
					35508: 24863,
					35509: 24931,
					35510: 25022,
					35511: 25563,
					35512: 25954,
					35513: 26577,
					35514: 26707,
					35515: 26874,
					35516: 27454,
					35517: 27475,
					35518: 27735,
					35519: 28450,
					35520: 28567,
					35521: 28485,
					35522: 29872,
					35523: 29976,
					35524: 30435,
					35525: 30475,
					35526: 31487,
					35527: 31649,
					35528: 31777,
					35529: 32233,
					35530: 32566,
					35531: 32752,
					35532: 32925,
					35533: 33382,
					35534: 33694,
					35535: 35251,
					35536: 35532,
					35537: 36011,
					35538: 36996,
					35539: 37969,
					35540: 38291,
					35541: 38289,
					35542: 38306,
					35543: 38501,
					35544: 38867,
					35545: 39208,
					35546: 33304,
					35547: 20024,
					35548: 21547,
					35549: 23736,
					35550: 24012,
					35551: 29609,
					35552: 30284,
					35553: 30524,
					35554: 23721,
					35555: 32747,
					35556: 36107,
					35557: 38593,
					35558: 38929,
					35559: 38996,
					35560: 39e3,
					35561: 20225,
					35562: 20238,
					35563: 21361,
					35564: 21916,
					35565: 22120,
					35566: 22522,
					35567: 22855,
					35568: 23305,
					35569: 23492,
					35570: 23696,
					35571: 24076,
					35572: 24190,
					35573: 24524,
					35574: 25582,
					35575: 26426,
					35576: 26071,
					35577: 26082,
					35578: 26399,
					35579: 26827,
					35580: 26820,
					35648: 27231,
					35649: 24112,
					35650: 27589,
					35651: 27671,
					35652: 27773,
					35653: 30079,
					35654: 31048,
					35655: 23395,
					35656: 31232,
					35657: 32e3,
					35658: 24509,
					35659: 35215,
					35660: 35352,
					35661: 36020,
					35662: 36215,
					35663: 36556,
					35664: 36637,
					35665: 39138,
					35666: 39438,
					35667: 39740,
					35668: 20096,
					35669: 20605,
					35670: 20736,
					35671: 22931,
					35672: 23452,
					35673: 25135,
					35674: 25216,
					35675: 25836,
					35676: 27450,
					35677: 29344,
					35678: 30097,
					35679: 31047,
					35680: 32681,
					35681: 34811,
					35682: 35516,
					35683: 35696,
					35684: 25516,
					35685: 33738,
					35686: 38816,
					35687: 21513,
					35688: 21507,
					35689: 21931,
					35690: 26708,
					35691: 27224,
					35692: 35440,
					35693: 30759,
					35694: 26485,
					35695: 40653,
					35696: 21364,
					35697: 23458,
					35698: 33050,
					35699: 34384,
					35700: 36870,
					35701: 19992,
					35702: 20037,
					35703: 20167,
					35704: 20241,
					35705: 21450,
					35706: 21560,
					35707: 23470,
					35708: 24339,
					35709: 24613,
					35710: 25937,
					35712: 26429,
					35713: 27714,
					35714: 27762,
					35715: 27875,
					35716: 28792,
					35717: 29699,
					35718: 31350,
					35719: 31406,
					35720: 31496,
					35721: 32026,
					35722: 31998,
					35723: 32102,
					35724: 26087,
					35725: 29275,
					35726: 21435,
					35727: 23621,
					35728: 24040,
					35729: 25298,
					35730: 25312,
					35731: 25369,
					35732: 28192,
					35733: 34394,
					35734: 35377,
					35735: 36317,
					35736: 37624,
					35737: 28417,
					35738: 31142,
					35739: 39770,
					35740: 20136,
					35741: 20139,
					35742: 20140,
					35743: 20379,
					35744: 20384,
					35745: 20689,
					35746: 20807,
					35747: 31478,
					35748: 20849,
					35749: 20982,
					35750: 21332,
					35751: 21281,
					35752: 21375,
					35753: 21483,
					35754: 21932,
					35755: 22659,
					35756: 23777,
					35757: 24375,
					35758: 24394,
					35759: 24623,
					35760: 24656,
					35761: 24685,
					35762: 25375,
					35763: 25945,
					35764: 27211,
					35765: 27841,
					35766: 29378,
					35767: 29421,
					35768: 30703,
					35769: 33016,
					35770: 33029,
					35771: 33288,
					35772: 34126,
					35773: 37111,
					35774: 37857,
					35775: 38911,
					35776: 39255,
					35777: 39514,
					35778: 20208,
					35779: 20957,
					35780: 23597,
					35781: 26241,
					35782: 26989,
					35783: 23616,
					35784: 26354,
					35785: 26997,
					35786: 29577,
					35787: 26704,
					35788: 31873,
					35789: 20677,
					35790: 21220,
					35791: 22343,
					35792: 24062,
					35793: 37670,
					35794: 26020,
					35795: 27427,
					35796: 27453,
					35797: 29748,
					35798: 31105,
					35799: 31165,
					35800: 31563,
					35801: 32202,
					35802: 33465,
					35803: 33740,
					35804: 34943,
					35805: 35167,
					35806: 35641,
					35807: 36817,
					35808: 37329,
					35809: 21535,
					35810: 37504,
					35811: 20061,
					35812: 20534,
					35813: 21477,
					35814: 21306,
					35815: 29399,
					35816: 29590,
					35817: 30697,
					35818: 33510,
					35819: 36527,
					35820: 39366,
					35821: 39368,
					35822: 39378,
					35823: 20855,
					35824: 24858,
					35825: 34398,
					35826: 21936,
					35827: 31354,
					35828: 20598,
					35829: 23507,
					35830: 36935,
					35831: 38533,
					35832: 20018,
					35833: 27355,
					35834: 37351,
					35835: 23633,
					35836: 23624,
					35904: 25496,
					35905: 31391,
					35906: 27795,
					35907: 38772,
					35908: 36705,
					35909: 31402,
					35910: 29066,
					35911: 38536,
					35912: 31874,
					35913: 26647,
					35914: 32368,
					35915: 26705,
					35916: 37740,
					35917: 21234,
					35918: 21531,
					35919: 34219,
					35920: 35347,
					35921: 32676,
					35922: 36557,
					35923: 37089,
					35924: 21350,
					35925: 34952,
					35926: 31041,
					35927: 20418,
					35928: 20670,
					35929: 21009,
					35930: 20804,
					35931: 21843,
					35932: 22317,
					35933: 29674,
					35934: 22411,
					35935: 22865,
					35936: 24418,
					35937: 24452,
					35938: 24693,
					35939: 24950,
					35940: 24935,
					35941: 25001,
					35942: 25522,
					35943: 25658,
					35944: 25964,
					35945: 26223,
					35946: 26690,
					35947: 28179,
					35948: 30054,
					35949: 31293,
					35950: 31995,
					35951: 32076,
					35952: 32153,
					35953: 32331,
					35954: 32619,
					35955: 33550,
					35956: 33610,
					35957: 34509,
					35958: 35336,
					35959: 35427,
					35960: 35686,
					35961: 36605,
					35962: 38938,
					35963: 40335,
					35964: 33464,
					35965: 36814,
					35966: 39912,
					35968: 21127,
					35969: 25119,
					35970: 25731,
					35971: 28608,
					35972: 38553,
					35973: 26689,
					35974: 20625,
					35975: 27424,
					35976: 27770,
					35977: 28500,
					35978: 31348,
					35979: 32080,
					35980: 34880,
					35981: 35363,
					35982: 26376,
					35983: 20214,
					35984: 20537,
					35985: 20518,
					35986: 20581,
					35987: 20860,
					35988: 21048,
					35989: 21091,
					35990: 21927,
					35991: 22287,
					35992: 22533,
					35993: 23244,
					35994: 24314,
					35995: 25010,
					35996: 25080,
					35997: 25331,
					35998: 25458,
					35999: 26908,
					36e3: 27177,
					36001: 29309,
					36002: 29356,
					36003: 29486,
					36004: 30740,
					36005: 30831,
					36006: 32121,
					36007: 30476,
					36008: 32937,
					36009: 35211,
					36010: 35609,
					36011: 36066,
					36012: 36562,
					36013: 36963,
					36014: 37749,
					36015: 38522,
					36016: 38997,
					36017: 39443,
					36018: 40568,
					36019: 20803,
					36020: 21407,
					36021: 21427,
					36022: 24187,
					36023: 24358,
					36024: 28187,
					36025: 28304,
					36026: 29572,
					36027: 29694,
					36028: 32067,
					36029: 33335,
					36030: 35328,
					36031: 35578,
					36032: 38480,
					36033: 20046,
					36034: 20491,
					36035: 21476,
					36036: 21628,
					36037: 22266,
					36038: 22993,
					36039: 23396,
					36040: 24049,
					36041: 24235,
					36042: 24359,
					36043: 25144,
					36044: 25925,
					36045: 26543,
					36046: 28246,
					36047: 29392,
					36048: 31946,
					36049: 34996,
					36050: 32929,
					36051: 32993,
					36052: 33776,
					36053: 34382,
					36054: 35463,
					36055: 36328,
					36056: 37431,
					36057: 38599,
					36058: 39015,
					36059: 40723,
					36060: 20116,
					36061: 20114,
					36062: 20237,
					36063: 21320,
					36064: 21577,
					36065: 21566,
					36066: 23087,
					36067: 24460,
					36068: 24481,
					36069: 24735,
					36070: 26791,
					36071: 27278,
					36072: 29786,
					36073: 30849,
					36074: 35486,
					36075: 35492,
					36076: 35703,
					36077: 37264,
					36078: 20062,
					36079: 39881,
					36080: 20132,
					36081: 20348,
					36082: 20399,
					36083: 20505,
					36084: 20502,
					36085: 20809,
					36086: 20844,
					36087: 21151,
					36088: 21177,
					36089: 21246,
					36090: 21402,
					36091: 21475,
					36092: 21521,
					36160: 21518,
					36161: 21897,
					36162: 22353,
					36163: 22434,
					36164: 22909,
					36165: 23380,
					36166: 23389,
					36167: 23439,
					36168: 24037,
					36169: 24039,
					36170: 24055,
					36171: 24184,
					36172: 24195,
					36173: 24218,
					36174: 24247,
					36175: 24344,
					36176: 24658,
					36177: 24908,
					36178: 25239,
					36179: 25304,
					36180: 25511,
					36181: 25915,
					36182: 26114,
					36183: 26179,
					36184: 26356,
					36185: 26477,
					36186: 26657,
					36187: 26775,
					36188: 27083,
					36189: 27743,
					36190: 27946,
					36191: 28009,
					36192: 28207,
					36193: 28317,
					36194: 30002,
					36195: 30343,
					36196: 30828,
					36197: 31295,
					36198: 31968,
					36199: 32005,
					36200: 32024,
					36201: 32094,
					36202: 32177,
					36203: 32789,
					36204: 32771,
					36205: 32943,
					36206: 32945,
					36207: 33108,
					36208: 33167,
					36209: 33322,
					36210: 33618,
					36211: 34892,
					36212: 34913,
					36213: 35611,
					36214: 36002,
					36215: 36092,
					36216: 37066,
					36217: 37237,
					36218: 37489,
					36219: 30783,
					36220: 37628,
					36221: 38308,
					36222: 38477,
					36224: 38917,
					36225: 39321,
					36226: 39640,
					36227: 40251,
					36228: 21083,
					36229: 21163,
					36230: 21495,
					36231: 21512,
					36232: 22741,
					36233: 25335,
					36234: 28640,
					36235: 35946,
					36236: 36703,
					36237: 40633,
					36238: 20811,
					36239: 21051,
					36240: 21578,
					36241: 22269,
					36242: 31296,
					36243: 37239,
					36244: 40288,
					36245: 40658,
					36246: 29508,
					36247: 28425,
					36248: 33136,
					36249: 29969,
					36250: 24573,
					36251: 24794,
					36252: 39592,
					36253: 29403,
					36254: 36796,
					36255: 27492,
					36256: 38915,
					36257: 20170,
					36258: 22256,
					36259: 22372,
					36260: 22718,
					36261: 23130,
					36262: 24680,
					36263: 25031,
					36264: 26127,
					36265: 26118,
					36266: 26681,
					36267: 26801,
					36268: 28151,
					36269: 30165,
					36270: 32058,
					36271: 33390,
					36272: 39746,
					36273: 20123,
					36274: 20304,
					36275: 21449,
					36276: 21766,
					36277: 23919,
					36278: 24038,
					36279: 24046,
					36280: 26619,
					36281: 27801,
					36282: 29811,
					36283: 30722,
					36284: 35408,
					36285: 37782,
					36286: 35039,
					36287: 22352,
					36288: 24231,
					36289: 25387,
					36290: 20661,
					36291: 20652,
					36292: 20877,
					36293: 26368,
					36294: 21705,
					36295: 22622,
					36296: 22971,
					36297: 23472,
					36298: 24425,
					36299: 25165,
					36300: 25505,
					36301: 26685,
					36302: 27507,
					36303: 28168,
					36304: 28797,
					36305: 37319,
					36306: 29312,
					36307: 30741,
					36308: 30758,
					36309: 31085,
					36310: 25998,
					36311: 32048,
					36312: 33756,
					36313: 35009,
					36314: 36617,
					36315: 38555,
					36316: 21092,
					36317: 22312,
					36318: 26448,
					36319: 32618,
					36320: 36001,
					36321: 20916,
					36322: 22338,
					36323: 38442,
					36324: 22586,
					36325: 27018,
					36326: 32948,
					36327: 21682,
					36328: 23822,
					36329: 22524,
					36330: 30869,
					36331: 40442,
					36332: 20316,
					36333: 21066,
					36334: 21643,
					36335: 25662,
					36336: 26152,
					36337: 26388,
					36338: 26613,
					36339: 31364,
					36340: 31574,
					36341: 32034,
					36342: 37679,
					36343: 26716,
					36344: 39853,
					36345: 31545,
					36346: 21273,
					36347: 20874,
					36348: 21047,
					36416: 23519,
					36417: 25334,
					36418: 25774,
					36419: 25830,
					36420: 26413,
					36421: 27578,
					36422: 34217,
					36423: 38609,
					36424: 30352,
					36425: 39894,
					36426: 25420,
					36427: 37638,
					36428: 39851,
					36429: 30399,
					36430: 26194,
					36431: 19977,
					36432: 20632,
					36433: 21442,
					36434: 23665,
					36435: 24808,
					36436: 25746,
					36437: 25955,
					36438: 26719,
					36439: 29158,
					36440: 29642,
					36441: 29987,
					36442: 31639,
					36443: 32386,
					36444: 34453,
					36445: 35715,
					36446: 36059,
					36447: 37240,
					36448: 39184,
					36449: 26028,
					36450: 26283,
					36451: 27531,
					36452: 20181,
					36453: 20180,
					36454: 20282,
					36455: 20351,
					36456: 21050,
					36457: 21496,
					36458: 21490,
					36459: 21987,
					36460: 22235,
					36461: 22763,
					36462: 22987,
					36463: 22985,
					36464: 23039,
					36465: 23376,
					36466: 23629,
					36467: 24066,
					36468: 24107,
					36469: 24535,
					36470: 24605,
					36471: 25351,
					36472: 25903,
					36473: 23388,
					36474: 26031,
					36475: 26045,
					36476: 26088,
					36477: 26525,
					36478: 27490,
					36480: 27515,
					36481: 27663,
					36482: 29509,
					36483: 31049,
					36484: 31169,
					36485: 31992,
					36486: 32025,
					36487: 32043,
					36488: 32930,
					36489: 33026,
					36490: 33267,
					36491: 35222,
					36492: 35422,
					36493: 35433,
					36494: 35430,
					36495: 35468,
					36496: 35566,
					36497: 36039,
					36498: 36060,
					36499: 38604,
					36500: 39164,
					36501: 27503,
					36502: 20107,
					36503: 20284,
					36504: 20365,
					36505: 20816,
					36506: 23383,
					36507: 23546,
					36508: 24904,
					36509: 25345,
					36510: 26178,
					36511: 27425,
					36512: 28363,
					36513: 27835,
					36514: 29246,
					36515: 29885,
					36516: 30164,
					36517: 30913,
					36518: 31034,
					36519: 32780,
					36520: 32819,
					36521: 33258,
					36522: 33940,
					36523: 36766,
					36524: 27728,
					36525: 40575,
					36526: 24335,
					36527: 35672,
					36528: 40235,
					36529: 31482,
					36530: 36600,
					36531: 23437,
					36532: 38635,
					36533: 19971,
					36534: 21489,
					36535: 22519,
					36536: 22833,
					36537: 23241,
					36538: 23460,
					36539: 24713,
					36540: 28287,
					36541: 28422,
					36542: 30142,
					36543: 36074,
					36544: 23455,
					36545: 34048,
					36546: 31712,
					36547: 20594,
					36548: 26612,
					36549: 33437,
					36550: 23649,
					36551: 34122,
					36552: 32286,
					36553: 33294,
					36554: 20889,
					36555: 23556,
					36556: 25448,
					36557: 36198,
					36558: 26012,
					36559: 29038,
					36560: 31038,
					36561: 32023,
					36562: 32773,
					36563: 35613,
					36564: 36554,
					36565: 36974,
					36566: 34503,
					36567: 37034,
					36568: 20511,
					36569: 21242,
					36570: 23610,
					36571: 26451,
					36572: 28796,
					36573: 29237,
					36574: 37196,
					36575: 37320,
					36576: 37675,
					36577: 33509,
					36578: 23490,
					36579: 24369,
					36580: 24825,
					36581: 20027,
					36582: 21462,
					36583: 23432,
					36584: 25163,
					36585: 26417,
					36586: 27530,
					36587: 29417,
					36588: 29664,
					36589: 31278,
					36590: 33131,
					36591: 36259,
					36592: 37202,
					36593: 39318,
					36594: 20754,
					36595: 21463,
					36596: 21610,
					36597: 23551,
					36598: 25480,
					36599: 27193,
					36600: 32172,
					36601: 38656,
					36602: 22234,
					36603: 21454,
					36604: 21608,
					36672: 23447,
					36673: 23601,
					36674: 24030,
					36675: 20462,
					36676: 24833,
					36677: 25342,
					36678: 27954,
					36679: 31168,
					36680: 31179,
					36681: 32066,
					36682: 32333,
					36683: 32722,
					36684: 33261,
					36685: 33311,
					36686: 33936,
					36687: 34886,
					36688: 35186,
					36689: 35728,
					36690: 36468,
					36691: 36655,
					36692: 36913,
					36693: 37195,
					36694: 37228,
					36695: 38598,
					36696: 37276,
					36697: 20160,
					36698: 20303,
					36699: 20805,
					36700: 21313,
					36701: 24467,
					36702: 25102,
					36703: 26580,
					36704: 27713,
					36705: 28171,
					36706: 29539,
					36707: 32294,
					36708: 37325,
					36709: 37507,
					36710: 21460,
					36711: 22809,
					36712: 23487,
					36713: 28113,
					36714: 31069,
					36715: 32302,
					36716: 31899,
					36717: 22654,
					36718: 29087,
					36719: 20986,
					36720: 34899,
					36721: 36848,
					36722: 20426,
					36723: 23803,
					36724: 26149,
					36725: 30636,
					36726: 31459,
					36727: 33308,
					36728: 39423,
					36729: 20934,
					36730: 24490,
					36731: 26092,
					36732: 26991,
					36733: 27529,
					36734: 28147,
					36736: 28310,
					36737: 28516,
					36738: 30462,
					36739: 32020,
					36740: 24033,
					36741: 36981,
					36742: 37255,
					36743: 38918,
					36744: 20966,
					36745: 21021,
					36746: 25152,
					36747: 26257,
					36748: 26329,
					36749: 28186,
					36750: 24246,
					36751: 32210,
					36752: 32626,
					36753: 26360,
					36754: 34223,
					36755: 34295,
					36756: 35576,
					36757: 21161,
					36758: 21465,
					36759: 22899,
					36760: 24207,
					36761: 24464,
					36762: 24661,
					36763: 37604,
					36764: 38500,
					36765: 20663,
					36766: 20767,
					36767: 21213,
					36768: 21280,
					36769: 21319,
					36770: 21484,
					36771: 21736,
					36772: 21830,
					36773: 21809,
					36774: 22039,
					36775: 22888,
					36776: 22974,
					36777: 23100,
					36778: 23477,
					36779: 23558,
					36780: 23567,
					36781: 23569,
					36782: 23578,
					36783: 24196,
					36784: 24202,
					36785: 24288,
					36786: 24432,
					36787: 25215,
					36788: 25220,
					36789: 25307,
					36790: 25484,
					36791: 25463,
					36792: 26119,
					36793: 26124,
					36794: 26157,
					36795: 26230,
					36796: 26494,
					36797: 26786,
					36798: 27167,
					36799: 27189,
					36800: 27836,
					36801: 28040,
					36802: 28169,
					36803: 28248,
					36804: 28988,
					36805: 28966,
					36806: 29031,
					36807: 30151,
					36808: 30465,
					36809: 30813,
					36810: 30977,
					36811: 31077,
					36812: 31216,
					36813: 31456,
					36814: 31505,
					36815: 31911,
					36816: 32057,
					36817: 32918,
					36818: 33750,
					36819: 33931,
					36820: 34121,
					36821: 34909,
					36822: 35059,
					36823: 35359,
					36824: 35388,
					36825: 35412,
					36826: 35443,
					36827: 35937,
					36828: 36062,
					36829: 37284,
					36830: 37478,
					36831: 37758,
					36832: 37912,
					36833: 38556,
					36834: 38808,
					36835: 19978,
					36836: 19976,
					36837: 19998,
					36838: 20055,
					36839: 20887,
					36840: 21104,
					36841: 22478,
					36842: 22580,
					36843: 22732,
					36844: 23330,
					36845: 24120,
					36846: 24773,
					36847: 25854,
					36848: 26465,
					36849: 26454,
					36850: 27972,
					36851: 29366,
					36852: 30067,
					36853: 31331,
					36854: 33976,
					36855: 35698,
					36856: 37304,
					36857: 37664,
					36858: 22065,
					36859: 22516,
					36860: 39166,
					36928: 25325,
					36929: 26893,
					36930: 27542,
					36931: 29165,
					36932: 32340,
					36933: 32887,
					36934: 33394,
					36935: 35302,
					36936: 39135,
					36937: 34645,
					36938: 36785,
					36939: 23611,
					36940: 20280,
					36941: 20449,
					36942: 20405,
					36943: 21767,
					36944: 23072,
					36945: 23517,
					36946: 23529,
					36947: 24515,
					36948: 24910,
					36949: 25391,
					36950: 26032,
					36951: 26187,
					36952: 26862,
					36953: 27035,
					36954: 28024,
					36955: 28145,
					36956: 30003,
					36957: 30137,
					36958: 30495,
					36959: 31070,
					36960: 31206,
					36961: 32051,
					36962: 33251,
					36963: 33455,
					36964: 34218,
					36965: 35242,
					36966: 35386,
					36967: 36523,
					36968: 36763,
					36969: 36914,
					36970: 37341,
					36971: 38663,
					36972: 20154,
					36973: 20161,
					36974: 20995,
					36975: 22645,
					36976: 22764,
					36977: 23563,
					36978: 29978,
					36979: 23613,
					36980: 33102,
					36981: 35338,
					36982: 36805,
					36983: 38499,
					36984: 38765,
					36985: 31525,
					36986: 35535,
					36987: 38920,
					36988: 37218,
					36989: 22259,
					36990: 21416,
					36992: 36887,
					36993: 21561,
					36994: 22402,
					36995: 24101,
					36996: 25512,
					36997: 27700,
					36998: 28810,
					36999: 30561,
					37e3: 31883,
					37001: 32736,
					37002: 34928,
					37003: 36930,
					37004: 37204,
					37005: 37648,
					37006: 37656,
					37007: 38543,
					37008: 29790,
					37009: 39620,
					37010: 23815,
					37011: 23913,
					37012: 25968,
					37013: 26530,
					37014: 36264,
					37015: 38619,
					37016: 25454,
					37017: 26441,
					37018: 26905,
					37019: 33733,
					37020: 38935,
					37021: 38592,
					37022: 35070,
					37023: 28548,
					37024: 25722,
					37025: 23544,
					37026: 19990,
					37027: 28716,
					37028: 30045,
					37029: 26159,
					37030: 20932,
					37031: 21046,
					37032: 21218,
					37033: 22995,
					37034: 24449,
					37035: 24615,
					37036: 25104,
					37037: 25919,
					37038: 25972,
					37039: 26143,
					37040: 26228,
					37041: 26866,
					37042: 26646,
					37043: 27491,
					37044: 28165,
					37045: 29298,
					37046: 29983,
					37047: 30427,
					37048: 31934,
					37049: 32854,
					37050: 22768,
					37051: 35069,
					37052: 35199,
					37053: 35488,
					37054: 35475,
					37055: 35531,
					37056: 36893,
					37057: 37266,
					37058: 38738,
					37059: 38745,
					37060: 25993,
					37061: 31246,
					37062: 33030,
					37063: 38587,
					37064: 24109,
					37065: 24796,
					37066: 25114,
					37067: 26021,
					37068: 26132,
					37069: 26512,
					37070: 30707,
					37071: 31309,
					37072: 31821,
					37073: 32318,
					37074: 33034,
					37075: 36012,
					37076: 36196,
					37077: 36321,
					37078: 36447,
					37079: 30889,
					37080: 20999,
					37081: 25305,
					37082: 25509,
					37083: 25666,
					37084: 25240,
					37085: 35373,
					37086: 31363,
					37087: 31680,
					37088: 35500,
					37089: 38634,
					37090: 32118,
					37091: 33292,
					37092: 34633,
					37093: 20185,
					37094: 20808,
					37095: 21315,
					37096: 21344,
					37097: 23459,
					37098: 23554,
					37099: 23574,
					37100: 24029,
					37101: 25126,
					37102: 25159,
					37103: 25776,
					37104: 26643,
					37105: 26676,
					37106: 27849,
					37107: 27973,
					37108: 27927,
					37109: 26579,
					37110: 28508,
					37111: 29006,
					37112: 29053,
					37113: 26059,
					37114: 31359,
					37115: 31661,
					37116: 32218,
					37184: 32330,
					37185: 32680,
					37186: 33146,
					37187: 33307,
					37188: 33337,
					37189: 34214,
					37190: 35438,
					37191: 36046,
					37192: 36341,
					37193: 36984,
					37194: 36983,
					37195: 37549,
					37196: 37521,
					37197: 38275,
					37198: 39854,
					37199: 21069,
					37200: 21892,
					37201: 28472,
					37202: 28982,
					37203: 20840,
					37204: 31109,
					37205: 32341,
					37206: 33203,
					37207: 31950,
					37208: 22092,
					37209: 22609,
					37210: 23720,
					37211: 25514,
					37212: 26366,
					37213: 26365,
					37214: 26970,
					37215: 29401,
					37216: 30095,
					37217: 30094,
					37218: 30990,
					37219: 31062,
					37220: 31199,
					37221: 31895,
					37222: 32032,
					37223: 32068,
					37224: 34311,
					37225: 35380,
					37226: 38459,
					37227: 36961,
					37228: 40736,
					37229: 20711,
					37230: 21109,
					37231: 21452,
					37232: 21474,
					37233: 20489,
					37234: 21930,
					37235: 22766,
					37236: 22863,
					37237: 29245,
					37238: 23435,
					37239: 23652,
					37240: 21277,
					37241: 24803,
					37242: 24819,
					37243: 25436,
					37244: 25475,
					37245: 25407,
					37246: 25531,
					37248: 25805,
					37249: 26089,
					37250: 26361,
					37251: 24035,
					37252: 27085,
					37253: 27133,
					37254: 28437,
					37255: 29157,
					37256: 20105,
					37257: 30185,
					37258: 30456,
					37259: 31379,
					37260: 31967,
					37261: 32207,
					37262: 32156,
					37263: 32865,
					37264: 33609,
					37265: 33624,
					37266: 33900,
					37267: 33980,
					37268: 34299,
					37269: 35013,
					37270: 36208,
					37271: 36865,
					37272: 36973,
					37273: 37783,
					37274: 38684,
					37275: 39442,
					37276: 20687,
					37277: 22679,
					37278: 24974,
					37279: 33235,
					37280: 34101,
					37281: 36104,
					37282: 36896,
					37283: 20419,
					37284: 20596,
					37285: 21063,
					37286: 21363,
					37287: 24687,
					37288: 25417,
					37289: 26463,
					37290: 28204,
					37291: 36275,
					37292: 36895,
					37293: 20439,
					37294: 23646,
					37295: 36042,
					37296: 26063,
					37297: 32154,
					37298: 21330,
					37299: 34966,
					37300: 20854,
					37301: 25539,
					37302: 23384,
					37303: 23403,
					37304: 23562,
					37305: 25613,
					37306: 26449,
					37307: 36956,
					37308: 20182,
					37309: 22810,
					37310: 22826,
					37311: 27760,
					37312: 35409,
					37313: 21822,
					37314: 22549,
					37315: 22949,
					37316: 24816,
					37317: 25171,
					37318: 26561,
					37319: 33333,
					37320: 26965,
					37321: 38464,
					37322: 39364,
					37323: 39464,
					37324: 20307,
					37325: 22534,
					37326: 23550,
					37327: 32784,
					37328: 23729,
					37329: 24111,
					37330: 24453,
					37331: 24608,
					37332: 24907,
					37333: 25140,
					37334: 26367,
					37335: 27888,
					37336: 28382,
					37337: 32974,
					37338: 33151,
					37339: 33492,
					37340: 34955,
					37341: 36024,
					37342: 36864,
					37343: 36910,
					37344: 38538,
					37345: 40667,
					37346: 39899,
					37347: 20195,
					37348: 21488,
					37349: 22823,
					37350: 31532,
					37351: 37261,
					37352: 38988,
					37353: 40441,
					37354: 28381,
					37355: 28711,
					37356: 21331,
					37357: 21828,
					37358: 23429,
					37359: 25176,
					37360: 25246,
					37361: 25299,
					37362: 27810,
					37363: 28655,
					37364: 29730,
					37365: 35351,
					37366: 37944,
					37367: 28609,
					37368: 35582,
					37369: 33592,
					37370: 20967,
					37371: 34552,
					37372: 21482,
					37440: 21481,
					37441: 20294,
					37442: 36948,
					37443: 36784,
					37444: 22890,
					37445: 33073,
					37446: 24061,
					37447: 31466,
					37448: 36799,
					37449: 26842,
					37450: 35895,
					37451: 29432,
					37452: 40008,
					37453: 27197,
					37454: 35504,
					37455: 20025,
					37456: 21336,
					37457: 22022,
					37458: 22374,
					37459: 25285,
					37460: 25506,
					37461: 26086,
					37462: 27470,
					37463: 28129,
					37464: 28251,
					37465: 28845,
					37466: 30701,
					37467: 31471,
					37468: 31658,
					37469: 32187,
					37470: 32829,
					37471: 32966,
					37472: 34507,
					37473: 35477,
					37474: 37723,
					37475: 22243,
					37476: 22727,
					37477: 24382,
					37478: 26029,
					37479: 26262,
					37480: 27264,
					37481: 27573,
					37482: 30007,
					37483: 35527,
					37484: 20516,
					37485: 30693,
					37486: 22320,
					37487: 24347,
					37488: 24677,
					37489: 26234,
					37490: 27744,
					37491: 30196,
					37492: 31258,
					37493: 32622,
					37494: 33268,
					37495: 34584,
					37496: 36933,
					37497: 39347,
					37498: 31689,
					37499: 30044,
					37500: 31481,
					37501: 31569,
					37502: 33988,
					37504: 36880,
					37505: 31209,
					37506: 31378,
					37507: 33590,
					37508: 23265,
					37509: 30528,
					37510: 20013,
					37511: 20210,
					37512: 23449,
					37513: 24544,
					37514: 25277,
					37515: 26172,
					37516: 26609,
					37517: 27880,
					37518: 34411,
					37519: 34935,
					37520: 35387,
					37521: 37198,
					37522: 37619,
					37523: 39376,
					37524: 27159,
					37525: 28710,
					37526: 29482,
					37527: 33511,
					37528: 33879,
					37529: 36015,
					37530: 19969,
					37531: 20806,
					37532: 20939,
					37533: 21899,
					37534: 23541,
					37535: 24086,
					37536: 24115,
					37537: 24193,
					37538: 24340,
					37539: 24373,
					37540: 24427,
					37541: 24500,
					37542: 25074,
					37543: 25361,
					37544: 26274,
					37545: 26397,
					37546: 28526,
					37547: 29266,
					37548: 30010,
					37549: 30522,
					37550: 32884,
					37551: 33081,
					37552: 33144,
					37553: 34678,
					37554: 35519,
					37555: 35548,
					37556: 36229,
					37557: 36339,
					37558: 37530,
					37559: 38263,
					37560: 38914,
					37561: 40165,
					37562: 21189,
					37563: 25431,
					37564: 30452,
					37565: 26389,
					37566: 27784,
					37567: 29645,
					37568: 36035,
					37569: 37806,
					37570: 38515,
					37571: 27941,
					37572: 22684,
					37573: 26894,
					37574: 27084,
					37575: 36861,
					37576: 37786,
					37577: 30171,
					37578: 36890,
					37579: 22618,
					37580: 26626,
					37581: 25524,
					37582: 27131,
					37583: 20291,
					37584: 28460,
					37585: 26584,
					37586: 36795,
					37587: 34086,
					37588: 32180,
					37589: 37716,
					37590: 26943,
					37591: 28528,
					37592: 22378,
					37593: 22775,
					37594: 23340,
					37595: 32044,
					37596: 29226,
					37597: 21514,
					37598: 37347,
					37599: 40372,
					37600: 20141,
					37601: 20302,
					37602: 20572,
					37603: 20597,
					37604: 21059,
					37605: 35998,
					37606: 21576,
					37607: 22564,
					37608: 23450,
					37609: 24093,
					37610: 24213,
					37611: 24237,
					37612: 24311,
					37613: 24351,
					37614: 24716,
					37615: 25269,
					37616: 25402,
					37617: 25552,
					37618: 26799,
					37619: 27712,
					37620: 30855,
					37621: 31118,
					37622: 31243,
					37623: 32224,
					37624: 33351,
					37625: 35330,
					37626: 35558,
					37627: 36420,
					37628: 36883,
					37696: 37048,
					37697: 37165,
					37698: 37336,
					37699: 40718,
					37700: 27877,
					37701: 25688,
					37702: 25826,
					37703: 25973,
					37704: 28404,
					37705: 30340,
					37706: 31515,
					37707: 36969,
					37708: 37841,
					37709: 28346,
					37710: 21746,
					37711: 24505,
					37712: 25764,
					37713: 36685,
					37714: 36845,
					37715: 37444,
					37716: 20856,
					37717: 22635,
					37718: 22825,
					37719: 23637,
					37720: 24215,
					37721: 28155,
					37722: 32399,
					37723: 29980,
					37724: 36028,
					37725: 36578,
					37726: 39003,
					37727: 28857,
					37728: 20253,
					37729: 27583,
					37730: 28593,
					37731: 3e4,
					37732: 38651,
					37733: 20814,
					37734: 21520,
					37735: 22581,
					37736: 22615,
					37737: 22956,
					37738: 23648,
					37739: 24466,
					37740: 26007,
					37741: 26460,
					37742: 28193,
					37743: 30331,
					37744: 33759,
					37745: 36077,
					37746: 36884,
					37747: 37117,
					37748: 37709,
					37749: 30757,
					37750: 30778,
					37751: 21162,
					37752: 24230,
					37753: 22303,
					37754: 22900,
					37755: 24594,
					37756: 20498,
					37757: 20826,
					37758: 20908,
					37760: 20941,
					37761: 20992,
					37762: 21776,
					37763: 22612,
					37764: 22616,
					37765: 22871,
					37766: 23445,
					37767: 23798,
					37768: 23947,
					37769: 24764,
					37770: 25237,
					37771: 25645,
					37772: 26481,
					37773: 26691,
					37774: 26812,
					37775: 26847,
					37776: 30423,
					37777: 28120,
					37778: 28271,
					37779: 28059,
					37780: 28783,
					37781: 29128,
					37782: 24403,
					37783: 30168,
					37784: 31095,
					37785: 31561,
					37786: 31572,
					37787: 31570,
					37788: 31958,
					37789: 32113,
					37790: 21040,
					37791: 33891,
					37792: 34153,
					37793: 34276,
					37794: 35342,
					37795: 35588,
					37796: 35910,
					37797: 36367,
					37798: 36867,
					37799: 36879,
					37800: 37913,
					37801: 38518,
					37802: 38957,
					37803: 39472,
					37804: 38360,
					37805: 20685,
					37806: 21205,
					37807: 21516,
					37808: 22530,
					37809: 23566,
					37810: 24999,
					37811: 25758,
					37812: 27934,
					37813: 30643,
					37814: 31461,
					37815: 33012,
					37816: 33796,
					37817: 36947,
					37818: 37509,
					37819: 23776,
					37820: 40199,
					37821: 21311,
					37822: 24471,
					37823: 24499,
					37824: 28060,
					37825: 29305,
					37826: 30563,
					37827: 31167,
					37828: 31716,
					37829: 27602,
					37830: 29420,
					37831: 35501,
					37832: 26627,
					37833: 27233,
					37834: 20984,
					37835: 31361,
					37836: 26932,
					37837: 23626,
					37838: 40182,
					37839: 33515,
					37840: 23493,
					37841: 37193,
					37842: 28702,
					37843: 22136,
					37844: 23663,
					37845: 24775,
					37846: 25958,
					37847: 27788,
					37848: 35930,
					37849: 36929,
					37850: 38931,
					37851: 21585,
					37852: 26311,
					37853: 37389,
					37854: 22856,
					37855: 37027,
					37856: 20869,
					37857: 20045,
					37858: 20970,
					37859: 34201,
					37860: 35598,
					37861: 28760,
					37862: 25466,
					37863: 37707,
					37864: 26978,
					37865: 39348,
					37866: 32260,
					37867: 30071,
					37868: 21335,
					37869: 26976,
					37870: 36575,
					37871: 38627,
					37872: 27741,
					37873: 20108,
					37874: 23612,
					37875: 24336,
					37876: 36841,
					37877: 21250,
					37878: 36049,
					37879: 32905,
					37880: 34425,
					37881: 24319,
					37882: 26085,
					37883: 20083,
					37884: 20837,
					37952: 22914,
					37953: 23615,
					37954: 38894,
					37955: 20219,
					37956: 22922,
					37957: 24525,
					37958: 35469,
					37959: 28641,
					37960: 31152,
					37961: 31074,
					37962: 23527,
					37963: 33905,
					37964: 29483,
					37965: 29105,
					37966: 24180,
					37967: 24565,
					37968: 25467,
					37969: 25754,
					37970: 29123,
					37971: 31896,
					37972: 20035,
					37973: 24316,
					37974: 20043,
					37975: 22492,
					37976: 22178,
					37977: 24745,
					37978: 28611,
					37979: 32013,
					37980: 33021,
					37981: 33075,
					37982: 33215,
					37983: 36786,
					37984: 35223,
					37985: 34468,
					37986: 24052,
					37987: 25226,
					37988: 25773,
					37989: 35207,
					37990: 26487,
					37991: 27874,
					37992: 27966,
					37993: 29750,
					37994: 30772,
					37995: 23110,
					37996: 32629,
					37997: 33453,
					37998: 39340,
					37999: 20467,
					38e3: 24259,
					38001: 25309,
					38002: 25490,
					38003: 25943,
					38004: 26479,
					38005: 30403,
					38006: 29260,
					38007: 32972,
					38008: 32954,
					38009: 36649,
					38010: 37197,
					38011: 20493,
					38012: 22521,
					38013: 23186,
					38014: 26757,
					38016: 26995,
					38017: 29028,
					38018: 29437,
					38019: 36023,
					38020: 22770,
					38021: 36064,
					38022: 38506,
					38023: 36889,
					38024: 34687,
					38025: 31204,
					38026: 30695,
					38027: 33833,
					38028: 20271,
					38029: 21093,
					38030: 21338,
					38031: 25293,
					38032: 26575,
					38033: 27850,
					38034: 30333,
					38035: 31636,
					38036: 31893,
					38037: 33334,
					38038: 34180,
					38039: 36843,
					38040: 26333,
					38041: 28448,
					38042: 29190,
					38043: 32283,
					38044: 33707,
					38045: 39361,
					38046: 40614,
					38047: 20989,
					38048: 31665,
					38049: 30834,
					38050: 31672,
					38051: 32903,
					38052: 31560,
					38053: 27368,
					38054: 24161,
					38055: 32908,
					38056: 30033,
					38057: 30048,
					38058: 20843,
					38059: 37474,
					38060: 28300,
					38061: 30330,
					38062: 37271,
					38063: 39658,
					38064: 20240,
					38065: 32624,
					38066: 25244,
					38067: 31567,
					38068: 38309,
					38069: 40169,
					38070: 22138,
					38071: 22617,
					38072: 34532,
					38073: 38588,
					38074: 20276,
					38075: 21028,
					38076: 21322,
					38077: 21453,
					38078: 21467,
					38079: 24070,
					38080: 25644,
					38081: 26001,
					38082: 26495,
					38083: 27710,
					38084: 27726,
					38085: 29256,
					38086: 29359,
					38087: 29677,
					38088: 30036,
					38089: 32321,
					38090: 33324,
					38091: 34281,
					38092: 36009,
					38093: 31684,
					38094: 37318,
					38095: 29033,
					38096: 38930,
					38097: 39151,
					38098: 25405,
					38099: 26217,
					38100: 30058,
					38101: 30436,
					38102: 30928,
					38103: 34115,
					38104: 34542,
					38105: 21290,
					38106: 21329,
					38107: 21542,
					38108: 22915,
					38109: 24199,
					38110: 24444,
					38111: 24754,
					38112: 25161,
					38113: 25209,
					38114: 25259,
					38115: 26e3,
					38116: 27604,
					38117: 27852,
					38118: 30130,
					38119: 30382,
					38120: 30865,
					38121: 31192,
					38122: 32203,
					38123: 32631,
					38124: 32933,
					38125: 34987,
					38126: 35513,
					38127: 36027,
					38128: 36991,
					38129: 38750,
					38130: 39131,
					38131: 27147,
					38132: 31800,
					38133: 20633,
					38134: 23614,
					38135: 24494,
					38136: 26503,
					38137: 27608,
					38138: 29749,
					38139: 30473,
					38140: 32654,
					38208: 40763,
					38209: 26570,
					38210: 31255,
					38211: 21305,
					38212: 30091,
					38213: 39661,
					38214: 24422,
					38215: 33181,
					38216: 33777,
					38217: 32920,
					38218: 24380,
					38219: 24517,
					38220: 30050,
					38221: 31558,
					38222: 36924,
					38223: 26727,
					38224: 23019,
					38225: 23195,
					38226: 32016,
					38227: 30334,
					38228: 35628,
					38229: 20469,
					38230: 24426,
					38231: 27161,
					38232: 27703,
					38233: 28418,
					38234: 29922,
					38235: 31080,
					38236: 34920,
					38237: 35413,
					38238: 35961,
					38239: 24287,
					38240: 25551,
					38241: 30149,
					38242: 31186,
					38243: 33495,
					38244: 37672,
					38245: 37618,
					38246: 33948,
					38247: 34541,
					38248: 39981,
					38249: 21697,
					38250: 24428,
					38251: 25996,
					38252: 27996,
					38253: 28693,
					38254: 36007,
					38255: 36051,
					38256: 38971,
					38257: 25935,
					38258: 29942,
					38259: 19981,
					38260: 20184,
					38261: 22496,
					38262: 22827,
					38263: 23142,
					38264: 23500,
					38265: 20904,
					38266: 24067,
					38267: 24220,
					38268: 24598,
					38269: 25206,
					38270: 25975,
					38272: 26023,
					38273: 26222,
					38274: 28014,
					38275: 29238,
					38276: 31526,
					38277: 33104,
					38278: 33178,
					38279: 33433,
					38280: 35676,
					38281: 36e3,
					38282: 36070,
					38283: 36212,
					38284: 38428,
					38285: 38468,
					38286: 20398,
					38287: 25771,
					38288: 27494,
					38289: 33310,
					38290: 33889,
					38291: 34154,
					38292: 37096,
					38293: 23553,
					38294: 26963,
					38295: 39080,
					38296: 33914,
					38297: 34135,
					38298: 20239,
					38299: 21103,
					38300: 24489,
					38301: 24133,
					38302: 26381,
					38303: 31119,
					38304: 33145,
					38305: 35079,
					38306: 35206,
					38307: 28149,
					38308: 24343,
					38309: 25173,
					38310: 27832,
					38311: 20175,
					38312: 29289,
					38313: 39826,
					38314: 20998,
					38315: 21563,
					38316: 22132,
					38317: 22707,
					38318: 24996,
					38319: 25198,
					38320: 28954,
					38321: 22894,
					38322: 31881,
					38323: 31966,
					38324: 32027,
					38325: 38640,
					38326: 25991,
					38327: 32862,
					38328: 19993,
					38329: 20341,
					38330: 20853,
					38331: 22592,
					38332: 24163,
					38333: 24179,
					38334: 24330,
					38335: 26564,
					38336: 20006,
					38337: 34109,
					38338: 38281,
					38339: 38491,
					38340: 31859,
					38341: 38913,
					38342: 20731,
					38343: 22721,
					38344: 30294,
					38345: 30887,
					38346: 21029,
					38347: 30629,
					38348: 34065,
					38349: 31622,
					38350: 20559,
					38351: 22793,
					38352: 29255,
					38353: 31687,
					38354: 32232,
					38355: 36794,
					38356: 36820,
					38357: 36941,
					38358: 20415,
					38359: 21193,
					38360: 23081,
					38361: 24321,
					38362: 38829,
					38363: 20445,
					38364: 33303,
					38365: 37610,
					38366: 22275,
					38367: 25429,
					38368: 27497,
					38369: 29995,
					38370: 35036,
					38371: 36628,
					38372: 31298,
					38373: 21215,
					38374: 22675,
					38375: 24917,
					38376: 25098,
					38377: 26286,
					38378: 27597,
					38379: 31807,
					38380: 33769,
					38381: 20515,
					38382: 20472,
					38383: 21253,
					38384: 21574,
					38385: 22577,
					38386: 22857,
					38387: 23453,
					38388: 23792,
					38389: 23791,
					38390: 23849,
					38391: 24214,
					38392: 25265,
					38393: 25447,
					38394: 25918,
					38395: 26041,
					38396: 26379,
					38464: 27861,
					38465: 27873,
					38466: 28921,
					38467: 30770,
					38468: 32299,
					38469: 32990,
					38470: 33459,
					38471: 33804,
					38472: 34028,
					38473: 34562,
					38474: 35090,
					38475: 35370,
					38476: 35914,
					38477: 37030,
					38478: 37586,
					38479: 39165,
					38480: 40179,
					38481: 40300,
					38482: 20047,
					38483: 20129,
					38484: 20621,
					38485: 21078,
					38486: 22346,
					38487: 22952,
					38488: 24125,
					38489: 24536,
					38490: 24537,
					38491: 25151,
					38492: 26292,
					38493: 26395,
					38494: 26576,
					38495: 26834,
					38496: 20882,
					38497: 32033,
					38498: 32938,
					38499: 33192,
					38500: 35584,
					38501: 35980,
					38502: 36031,
					38503: 37502,
					38504: 38450,
					38505: 21536,
					38506: 38956,
					38507: 21271,
					38508: 20693,
					38509: 21340,
					38510: 22696,
					38511: 25778,
					38512: 26420,
					38513: 29287,
					38514: 30566,
					38515: 31302,
					38516: 37350,
					38517: 21187,
					38518: 27809,
					38519: 27526,
					38520: 22528,
					38521: 24140,
					38522: 22868,
					38523: 26412,
					38524: 32763,
					38525: 20961,
					38526: 30406,
					38528: 25705,
					38529: 30952,
					38530: 39764,
					38531: 40635,
					38532: 22475,
					38533: 22969,
					38534: 26151,
					38535: 26522,
					38536: 27598,
					38537: 21737,
					38538: 27097,
					38539: 24149,
					38540: 33180,
					38541: 26517,
					38542: 39850,
					38543: 26622,
					38544: 40018,
					38545: 26717,
					38546: 20134,
					38547: 20451,
					38548: 21448,
					38549: 25273,
					38550: 26411,
					38551: 27819,
					38552: 36804,
					38553: 20397,
					38554: 32365,
					38555: 40639,
					38556: 19975,
					38557: 24930,
					38558: 28288,
					38559: 28459,
					38560: 34067,
					38561: 21619,
					38562: 26410,
					38563: 39749,
					38564: 24051,
					38565: 31637,
					38566: 23724,
					38567: 23494,
					38568: 34588,
					38569: 28234,
					38570: 34001,
					38571: 31252,
					38572: 33032,
					38573: 22937,
					38574: 31885,
					38575: 27665,
					38576: 30496,
					38577: 21209,
					38578: 22818,
					38579: 28961,
					38580: 29279,
					38581: 30683,
					38582: 38695,
					38583: 40289,
					38584: 26891,
					38585: 23167,
					38586: 23064,
					38587: 20901,
					38588: 21517,
					38589: 21629,
					38590: 26126,
					38591: 30431,
					38592: 36855,
					38593: 37528,
					38594: 40180,
					38595: 23018,
					38596: 29277,
					38597: 28357,
					38598: 20813,
					38599: 26825,
					38600: 32191,
					38601: 32236,
					38602: 38754,
					38603: 40634,
					38604: 25720,
					38605: 27169,
					38606: 33538,
					38607: 22916,
					38608: 23391,
					38609: 27611,
					38610: 29467,
					38611: 30450,
					38612: 32178,
					38613: 32791,
					38614: 33945,
					38615: 20786,
					38616: 26408,
					38617: 40665,
					38618: 30446,
					38619: 26466,
					38620: 21247,
					38621: 39173,
					38622: 23588,
					38623: 25147,
					38624: 31870,
					38625: 36016,
					38626: 21839,
					38627: 24758,
					38628: 32011,
					38629: 38272,
					38630: 21249,
					38631: 20063,
					38632: 20918,
					38633: 22812,
					38634: 29242,
					38635: 32822,
					38636: 37326,
					38637: 24357,
					38638: 30690,
					38639: 21380,
					38640: 24441,
					38641: 32004,
					38642: 34220,
					38643: 35379,
					38644: 36493,
					38645: 38742,
					38646: 26611,
					38647: 34222,
					38648: 37971,
					38649: 24841,
					38650: 24840,
					38651: 27833,
					38652: 30290,
					38720: 35565,
					38721: 36664,
					38722: 21807,
					38723: 20305,
					38724: 20778,
					38725: 21191,
					38726: 21451,
					38727: 23461,
					38728: 24189,
					38729: 24736,
					38730: 24962,
					38731: 25558,
					38732: 26377,
					38733: 26586,
					38734: 28263,
					38735: 28044,
					38736: 29494,
					38737: 29495,
					38738: 30001,
					38739: 31056,
					38740: 35029,
					38741: 35480,
					38742: 36938,
					38743: 37009,
					38744: 37109,
					38745: 38596,
					38746: 34701,
					38747: 22805,
					38748: 20104,
					38749: 20313,
					38750: 19982,
					38751: 35465,
					38752: 36671,
					38753: 38928,
					38754: 20653,
					38755: 24188,
					38756: 22934,
					38757: 23481,
					38758: 24248,
					38759: 25562,
					38760: 25594,
					38761: 25793,
					38762: 26332,
					38763: 26954,
					38764: 27096,
					38765: 27915,
					38766: 28342,
					38767: 29076,
					38768: 29992,
					38769: 31407,
					38770: 32650,
					38771: 32768,
					38772: 33865,
					38773: 33993,
					38774: 35201,
					38775: 35617,
					38776: 36362,
					38777: 36965,
					38778: 38525,
					38779: 39178,
					38780: 24958,
					38781: 25233,
					38782: 27442,
					38784: 27779,
					38785: 28020,
					38786: 32716,
					38787: 32764,
					38788: 28096,
					38789: 32645,
					38790: 34746,
					38791: 35064,
					38792: 26469,
					38793: 33713,
					38794: 38972,
					38795: 38647,
					38796: 27931,
					38797: 32097,
					38798: 33853,
					38799: 37226,
					38800: 20081,
					38801: 21365,
					38802: 23888,
					38803: 27396,
					38804: 28651,
					38805: 34253,
					38806: 34349,
					38807: 35239,
					38808: 21033,
					38809: 21519,
					38810: 23653,
					38811: 26446,
					38812: 26792,
					38813: 29702,
					38814: 29827,
					38815: 30178,
					38816: 35023,
					38817: 35041,
					38818: 37324,
					38819: 38626,
					38820: 38520,
					38821: 24459,
					38822: 29575,
					38823: 31435,
					38824: 33870,
					38825: 25504,
					38826: 30053,
					38827: 21129,
					38828: 27969,
					38829: 28316,
					38830: 29705,
					38831: 30041,
					38832: 30827,
					38833: 31890,
					38834: 38534,
					38835: 31452,
					38836: 40845,
					38837: 20406,
					38838: 24942,
					38839: 26053,
					38840: 34396,
					38841: 20102,
					38842: 20142,
					38843: 20698,
					38844: 20001,
					38845: 20940,
					38846: 23534,
					38847: 26009,
					38848: 26753,
					38849: 28092,
					38850: 29471,
					38851: 30274,
					38852: 30637,
					38853: 31260,
					38854: 31975,
					38855: 33391,
					38856: 35538,
					38857: 36988,
					38858: 37327,
					38859: 38517,
					38860: 38936,
					38861: 21147,
					38862: 32209,
					38863: 20523,
					38864: 21400,
					38865: 26519,
					38866: 28107,
					38867: 29136,
					38868: 29747,
					38869: 33256,
					38870: 36650,
					38871: 38563,
					38872: 40023,
					38873: 40607,
					38874: 29792,
					38875: 22593,
					38876: 28057,
					38877: 32047,
					38878: 39006,
					38879: 20196,
					38880: 20278,
					38881: 20363,
					38882: 20919,
					38883: 21169,
					38884: 23994,
					38885: 24604,
					38886: 29618,
					38887: 31036,
					38888: 33491,
					38889: 37428,
					38890: 38583,
					38891: 38646,
					38892: 38666,
					38893: 40599,
					38894: 40802,
					38895: 26278,
					38896: 27508,
					38897: 21015,
					38898: 21155,
					38899: 28872,
					38900: 35010,
					38901: 24265,
					38902: 24651,
					38903: 24976,
					38904: 28451,
					38905: 29001,
					38906: 31806,
					38907: 32244,
					38908: 32879,
					38976: 34030,
					38977: 36899,
					38978: 37676,
					38979: 21570,
					38980: 39791,
					38981: 27347,
					38982: 28809,
					38983: 36034,
					38984: 36335,
					38985: 38706,
					38986: 21172,
					38987: 23105,
					38988: 24266,
					38989: 24324,
					38990: 26391,
					38991: 27004,
					38992: 27028,
					38993: 28010,
					38994: 28431,
					38995: 29282,
					38996: 29436,
					38997: 31725,
					38998: 32769,
					38999: 32894,
					39e3: 34635,
					39001: 37070,
					39002: 20845,
					39003: 40595,
					39004: 31108,
					39005: 32907,
					39006: 37682,
					39007: 35542,
					39008: 20525,
					39009: 21644,
					39010: 35441,
					39011: 27498,
					39012: 36036,
					39013: 33031,
					39014: 24785,
					39015: 26528,
					39016: 40434,
					39017: 20121,
					39018: 20120,
					39019: 39952,
					39020: 35435,
					39021: 34241,
					39022: 34152,
					39023: 26880,
					39024: 28286,
					39025: 30871,
					39026: 33109,
					39071: 24332,
					39072: 19984,
					39073: 19989,
					39074: 20010,
					39075: 20017,
					39076: 20022,
					39077: 20028,
					39078: 20031,
					39079: 20034,
					39080: 20054,
					39081: 20056,
					39082: 20098,
					39083: 20101,
					39084: 35947,
					39085: 20106,
					39086: 33298,
					39087: 24333,
					39088: 20110,
					39089: 20126,
					39090: 20127,
					39091: 20128,
					39092: 20130,
					39093: 20144,
					39094: 20147,
					39095: 20150,
					39096: 20174,
					39097: 20173,
					39098: 20164,
					39099: 20166,
					39100: 20162,
					39101: 20183,
					39102: 20190,
					39103: 20205,
					39104: 20191,
					39105: 20215,
					39106: 20233,
					39107: 20314,
					39108: 20272,
					39109: 20315,
					39110: 20317,
					39111: 20311,
					39112: 20295,
					39113: 20342,
					39114: 20360,
					39115: 20367,
					39116: 20376,
					39117: 20347,
					39118: 20329,
					39119: 20336,
					39120: 20369,
					39121: 20335,
					39122: 20358,
					39123: 20374,
					39124: 20760,
					39125: 20436,
					39126: 20447,
					39127: 20430,
					39128: 20440,
					39129: 20443,
					39130: 20433,
					39131: 20442,
					39132: 20432,
					39133: 20452,
					39134: 20453,
					39135: 20506,
					39136: 20520,
					39137: 20500,
					39138: 20522,
					39139: 20517,
					39140: 20485,
					39141: 20252,
					39142: 20470,
					39143: 20513,
					39144: 20521,
					39145: 20524,
					39146: 20478,
					39147: 20463,
					39148: 20497,
					39149: 20486,
					39150: 20547,
					39151: 20551,
					39152: 26371,
					39153: 20565,
					39154: 20560,
					39155: 20552,
					39156: 20570,
					39157: 20566,
					39158: 20588,
					39159: 20600,
					39160: 20608,
					39161: 20634,
					39162: 20613,
					39163: 20660,
					39164: 20658,
					39232: 20681,
					39233: 20682,
					39234: 20659,
					39235: 20674,
					39236: 20694,
					39237: 20702,
					39238: 20709,
					39239: 20717,
					39240: 20707,
					39241: 20718,
					39242: 20729,
					39243: 20725,
					39244: 20745,
					39245: 20737,
					39246: 20738,
					39247: 20758,
					39248: 20757,
					39249: 20756,
					39250: 20762,
					39251: 20769,
					39252: 20794,
					39253: 20791,
					39254: 20796,
					39255: 20795,
					39256: 20799,
					39257: 20800,
					39258: 20818,
					39259: 20812,
					39260: 20820,
					39261: 20834,
					39262: 31480,
					39263: 20841,
					39264: 20842,
					39265: 20846,
					39266: 20864,
					39267: 20866,
					39268: 22232,
					39269: 20876,
					39270: 20873,
					39271: 20879,
					39272: 20881,
					39273: 20883,
					39274: 20885,
					39275: 20886,
					39276: 20900,
					39277: 20902,
					39278: 20898,
					39279: 20905,
					39280: 20906,
					39281: 20907,
					39282: 20915,
					39283: 20913,
					39284: 20914,
					39285: 20912,
					39286: 20917,
					39287: 20925,
					39288: 20933,
					39289: 20937,
					39290: 20955,
					39291: 20960,
					39292: 34389,
					39293: 20969,
					39294: 20973,
					39296: 20976,
					39297: 20981,
					39298: 20990,
					39299: 20996,
					39300: 21003,
					39301: 21012,
					39302: 21006,
					39303: 21031,
					39304: 21034,
					39305: 21038,
					39306: 21043,
					39307: 21049,
					39308: 21071,
					39309: 21060,
					39310: 21067,
					39311: 21068,
					39312: 21086,
					39313: 21076,
					39314: 21098,
					39315: 21108,
					39316: 21097,
					39317: 21107,
					39318: 21119,
					39319: 21117,
					39320: 21133,
					39321: 21140,
					39322: 21138,
					39323: 21105,
					39324: 21128,
					39325: 21137,
					39326: 36776,
					39327: 36775,
					39328: 21164,
					39329: 21165,
					39330: 21180,
					39331: 21173,
					39332: 21185,
					39333: 21197,
					39334: 21207,
					39335: 21214,
					39336: 21219,
					39337: 21222,
					39338: 39149,
					39339: 21216,
					39340: 21235,
					39341: 21237,
					39342: 21240,
					39343: 21241,
					39344: 21254,
					39345: 21256,
					39346: 30008,
					39347: 21261,
					39348: 21264,
					39349: 21263,
					39350: 21269,
					39351: 21274,
					39352: 21283,
					39353: 21295,
					39354: 21297,
					39355: 21299,
					39356: 21304,
					39357: 21312,
					39358: 21318,
					39359: 21317,
					39360: 19991,
					39361: 21321,
					39362: 21325,
					39363: 20950,
					39364: 21342,
					39365: 21353,
					39366: 21358,
					39367: 22808,
					39368: 21371,
					39369: 21367,
					39370: 21378,
					39371: 21398,
					39372: 21408,
					39373: 21414,
					39374: 21413,
					39375: 21422,
					39376: 21424,
					39377: 21430,
					39378: 21443,
					39379: 31762,
					39380: 38617,
					39381: 21471,
					39382: 26364,
					39383: 29166,
					39384: 21486,
					39385: 21480,
					39386: 21485,
					39387: 21498,
					39388: 21505,
					39389: 21565,
					39390: 21568,
					39391: 21548,
					39392: 21549,
					39393: 21564,
					39394: 21550,
					39395: 21558,
					39396: 21545,
					39397: 21533,
					39398: 21582,
					39399: 21647,
					39400: 21621,
					39401: 21646,
					39402: 21599,
					39403: 21617,
					39404: 21623,
					39405: 21616,
					39406: 21650,
					39407: 21627,
					39408: 21632,
					39409: 21622,
					39410: 21636,
					39411: 21648,
					39412: 21638,
					39413: 21703,
					39414: 21666,
					39415: 21688,
					39416: 21669,
					39417: 21676,
					39418: 21700,
					39419: 21704,
					39420: 21672,
					39488: 21675,
					39489: 21698,
					39490: 21668,
					39491: 21694,
					39492: 21692,
					39493: 21720,
					39494: 21733,
					39495: 21734,
					39496: 21775,
					39497: 21780,
					39498: 21757,
					39499: 21742,
					39500: 21741,
					39501: 21754,
					39502: 21730,
					39503: 21817,
					39504: 21824,
					39505: 21859,
					39506: 21836,
					39507: 21806,
					39508: 21852,
					39509: 21829,
					39510: 21846,
					39511: 21847,
					39512: 21816,
					39513: 21811,
					39514: 21853,
					39515: 21913,
					39516: 21888,
					39517: 21679,
					39518: 21898,
					39519: 21919,
					39520: 21883,
					39521: 21886,
					39522: 21912,
					39523: 21918,
					39524: 21934,
					39525: 21884,
					39526: 21891,
					39527: 21929,
					39528: 21895,
					39529: 21928,
					39530: 21978,
					39531: 21957,
					39532: 21983,
					39533: 21956,
					39534: 21980,
					39535: 21988,
					39536: 21972,
					39537: 22036,
					39538: 22007,
					39539: 22038,
					39540: 22014,
					39541: 22013,
					39542: 22043,
					39543: 22009,
					39544: 22094,
					39545: 22096,
					39546: 29151,
					39547: 22068,
					39548: 22070,
					39549: 22066,
					39550: 22072,
					39552: 22123,
					39553: 22116,
					39554: 22063,
					39555: 22124,
					39556: 22122,
					39557: 22150,
					39558: 22144,
					39559: 22154,
					39560: 22176,
					39561: 22164,
					39562: 22159,
					39563: 22181,
					39564: 22190,
					39565: 22198,
					39566: 22196,
					39567: 22210,
					39568: 22204,
					39569: 22209,
					39570: 22211,
					39571: 22208,
					39572: 22216,
					39573: 22222,
					39574: 22225,
					39575: 22227,
					39576: 22231,
					39577: 22254,
					39578: 22265,
					39579: 22272,
					39580: 22271,
					39581: 22276,
					39582: 22281,
					39583: 22280,
					39584: 22283,
					39585: 22285,
					39586: 22291,
					39587: 22296,
					39588: 22294,
					39589: 21959,
					39590: 22300,
					39591: 22310,
					39592: 22327,
					39593: 22328,
					39594: 22350,
					39595: 22331,
					39596: 22336,
					39597: 22351,
					39598: 22377,
					39599: 22464,
					39600: 22408,
					39601: 22369,
					39602: 22399,
					39603: 22409,
					39604: 22419,
					39605: 22432,
					39606: 22451,
					39607: 22436,
					39608: 22442,
					39609: 22448,
					39610: 22467,
					39611: 22470,
					39612: 22484,
					39613: 22482,
					39614: 22483,
					39615: 22538,
					39616: 22486,
					39617: 22499,
					39618: 22539,
					39619: 22553,
					39620: 22557,
					39621: 22642,
					39622: 22561,
					39623: 22626,
					39624: 22603,
					39625: 22640,
					39626: 27584,
					39627: 22610,
					39628: 22589,
					39629: 22649,
					39630: 22661,
					39631: 22713,
					39632: 22687,
					39633: 22699,
					39634: 22714,
					39635: 22750,
					39636: 22715,
					39637: 22712,
					39638: 22702,
					39639: 22725,
					39640: 22739,
					39641: 22737,
					39642: 22743,
					39643: 22745,
					39644: 22744,
					39645: 22757,
					39646: 22748,
					39647: 22756,
					39648: 22751,
					39649: 22767,
					39650: 22778,
					39651: 22777,
					39652: 22779,
					39653: 22780,
					39654: 22781,
					39655: 22786,
					39656: 22794,
					39657: 22800,
					39658: 22811,
					39659: 26790,
					39660: 22821,
					39661: 22828,
					39662: 22829,
					39663: 22834,
					39664: 22840,
					39665: 22846,
					39666: 31442,
					39667: 22869,
					39668: 22864,
					39669: 22862,
					39670: 22874,
					39671: 22872,
					39672: 22882,
					39673: 22880,
					39674: 22887,
					39675: 22892,
					39676: 22889,
					39744: 22904,
					39745: 22913,
					39746: 22941,
					39747: 20318,
					39748: 20395,
					39749: 22947,
					39750: 22962,
					39751: 22982,
					39752: 23016,
					39753: 23004,
					39754: 22925,
					39755: 23001,
					39756: 23002,
					39757: 23077,
					39758: 23071,
					39759: 23057,
					39760: 23068,
					39761: 23049,
					39762: 23066,
					39763: 23104,
					39764: 23148,
					39765: 23113,
					39766: 23093,
					39767: 23094,
					39768: 23138,
					39769: 23146,
					39770: 23194,
					39771: 23228,
					39772: 23230,
					39773: 23243,
					39774: 23234,
					39775: 23229,
					39776: 23267,
					39777: 23255,
					39778: 23270,
					39779: 23273,
					39780: 23254,
					39781: 23290,
					39782: 23291,
					39783: 23308,
					39784: 23307,
					39785: 23318,
					39786: 23346,
					39787: 23248,
					39788: 23338,
					39789: 23350,
					39790: 23358,
					39791: 23363,
					39792: 23365,
					39793: 23360,
					39794: 23377,
					39795: 23381,
					39796: 23386,
					39797: 23387,
					39798: 23397,
					39799: 23401,
					39800: 23408,
					39801: 23411,
					39802: 23413,
					39803: 23416,
					39804: 25992,
					39805: 23418,
					39806: 23424,
					39808: 23427,
					39809: 23462,
					39810: 23480,
					39811: 23491,
					39812: 23495,
					39813: 23497,
					39814: 23508,
					39815: 23504,
					39816: 23524,
					39817: 23526,
					39818: 23522,
					39819: 23518,
					39820: 23525,
					39821: 23531,
					39822: 23536,
					39823: 23542,
					39824: 23539,
					39825: 23557,
					39826: 23559,
					39827: 23560,
					39828: 23565,
					39829: 23571,
					39830: 23584,
					39831: 23586,
					39832: 23592,
					39833: 23608,
					39834: 23609,
					39835: 23617,
					39836: 23622,
					39837: 23630,
					39838: 23635,
					39839: 23632,
					39840: 23631,
					39841: 23409,
					39842: 23660,
					39843: 23662,
					39844: 20066,
					39845: 23670,
					39846: 23673,
					39847: 23692,
					39848: 23697,
					39849: 23700,
					39850: 22939,
					39851: 23723,
					39852: 23739,
					39853: 23734,
					39854: 23740,
					39855: 23735,
					39856: 23749,
					39857: 23742,
					39858: 23751,
					39859: 23769,
					39860: 23785,
					39861: 23805,
					39862: 23802,
					39863: 23789,
					39864: 23948,
					39865: 23786,
					39866: 23819,
					39867: 23829,
					39868: 23831,
					39869: 23900,
					39870: 23839,
					39871: 23835,
					39872: 23825,
					39873: 23828,
					39874: 23842,
					39875: 23834,
					39876: 23833,
					39877: 23832,
					39878: 23884,
					39879: 23890,
					39880: 23886,
					39881: 23883,
					39882: 23916,
					39883: 23923,
					39884: 23926,
					39885: 23943,
					39886: 23940,
					39887: 23938,
					39888: 23970,
					39889: 23965,
					39890: 23980,
					39891: 23982,
					39892: 23997,
					39893: 23952,
					39894: 23991,
					39895: 23996,
					39896: 24009,
					39897: 24013,
					39898: 24019,
					39899: 24018,
					39900: 24022,
					39901: 24027,
					39902: 24043,
					39903: 24050,
					39904: 24053,
					39905: 24075,
					39906: 24090,
					39907: 24089,
					39908: 24081,
					39909: 24091,
					39910: 24118,
					39911: 24119,
					39912: 24132,
					39913: 24131,
					39914: 24128,
					39915: 24142,
					39916: 24151,
					39917: 24148,
					39918: 24159,
					39919: 24162,
					39920: 24164,
					39921: 24135,
					39922: 24181,
					39923: 24182,
					39924: 24186,
					39925: 40636,
					39926: 24191,
					39927: 24224,
					39928: 24257,
					39929: 24258,
					39930: 24264,
					39931: 24272,
					39932: 24271,
					4e4: 24278,
					40001: 24291,
					40002: 24285,
					40003: 24282,
					40004: 24283,
					40005: 24290,
					40006: 24289,
					40007: 24296,
					40008: 24297,
					40009: 24300,
					40010: 24305,
					40011: 24307,
					40012: 24304,
					40013: 24308,
					40014: 24312,
					40015: 24318,
					40016: 24323,
					40017: 24329,
					40018: 24413,
					40019: 24412,
					40020: 24331,
					40021: 24337,
					40022: 24342,
					40023: 24361,
					40024: 24365,
					40025: 24376,
					40026: 24385,
					40027: 24392,
					40028: 24396,
					40029: 24398,
					40030: 24367,
					40031: 24401,
					40032: 24406,
					40033: 24407,
					40034: 24409,
					40035: 24417,
					40036: 24429,
					40037: 24435,
					40038: 24439,
					40039: 24451,
					40040: 24450,
					40041: 24447,
					40042: 24458,
					40043: 24456,
					40044: 24465,
					40045: 24455,
					40046: 24478,
					40047: 24473,
					40048: 24472,
					40049: 24480,
					40050: 24488,
					40051: 24493,
					40052: 24508,
					40053: 24534,
					40054: 24571,
					40055: 24548,
					40056: 24568,
					40057: 24561,
					40058: 24541,
					40059: 24755,
					40060: 24575,
					40061: 24609,
					40062: 24672,
					40064: 24601,
					40065: 24592,
					40066: 24617,
					40067: 24590,
					40068: 24625,
					40069: 24603,
					40070: 24597,
					40071: 24619,
					40072: 24614,
					40073: 24591,
					40074: 24634,
					40075: 24666,
					40076: 24641,
					40077: 24682,
					40078: 24695,
					40079: 24671,
					40080: 24650,
					40081: 24646,
					40082: 24653,
					40083: 24675,
					40084: 24643,
					40085: 24676,
					40086: 24642,
					40087: 24684,
					40088: 24683,
					40089: 24665,
					40090: 24705,
					40091: 24717,
					40092: 24807,
					40093: 24707,
					40094: 24730,
					40095: 24708,
					40096: 24731,
					40097: 24726,
					40098: 24727,
					40099: 24722,
					40100: 24743,
					40101: 24715,
					40102: 24801,
					40103: 24760,
					40104: 24800,
					40105: 24787,
					40106: 24756,
					40107: 24560,
					40108: 24765,
					40109: 24774,
					40110: 24757,
					40111: 24792,
					40112: 24909,
					40113: 24853,
					40114: 24838,
					40115: 24822,
					40116: 24823,
					40117: 24832,
					40118: 24820,
					40119: 24826,
					40120: 24835,
					40121: 24865,
					40122: 24827,
					40123: 24817,
					40124: 24845,
					40125: 24846,
					40126: 24903,
					40127: 24894,
					40128: 24872,
					40129: 24871,
					40130: 24906,
					40131: 24895,
					40132: 24892,
					40133: 24876,
					40134: 24884,
					40135: 24893,
					40136: 24898,
					40137: 24900,
					40138: 24947,
					40139: 24951,
					40140: 24920,
					40141: 24921,
					40142: 24922,
					40143: 24939,
					40144: 24948,
					40145: 24943,
					40146: 24933,
					40147: 24945,
					40148: 24927,
					40149: 24925,
					40150: 24915,
					40151: 24949,
					40152: 24985,
					40153: 24982,
					40154: 24967,
					40155: 25004,
					40156: 24980,
					40157: 24986,
					40158: 24970,
					40159: 24977,
					40160: 25003,
					40161: 25006,
					40162: 25036,
					40163: 25034,
					40164: 25033,
					40165: 25079,
					40166: 25032,
					40167: 25027,
					40168: 25030,
					40169: 25018,
					40170: 25035,
					40171: 32633,
					40172: 25037,
					40173: 25062,
					40174: 25059,
					40175: 25078,
					40176: 25082,
					40177: 25076,
					40178: 25087,
					40179: 25085,
					40180: 25084,
					40181: 25086,
					40182: 25088,
					40183: 25096,
					40184: 25097,
					40185: 25101,
					40186: 25100,
					40187: 25108,
					40188: 25115,
					40256: 25118,
					40257: 25121,
					40258: 25130,
					40259: 25134,
					40260: 25136,
					40261: 25138,
					40262: 25139,
					40263: 25153,
					40264: 25166,
					40265: 25182,
					40266: 25187,
					40267: 25179,
					40268: 25184,
					40269: 25192,
					40270: 25212,
					40271: 25218,
					40272: 25225,
					40273: 25214,
					40274: 25234,
					40275: 25235,
					40276: 25238,
					40277: 25300,
					40278: 25219,
					40279: 25236,
					40280: 25303,
					40281: 25297,
					40282: 25275,
					40283: 25295,
					40284: 25343,
					40285: 25286,
					40286: 25812,
					40287: 25288,
					40288: 25308,
					40289: 25292,
					40290: 25290,
					40291: 25282,
					40292: 25287,
					40293: 25243,
					40294: 25289,
					40295: 25356,
					40296: 25326,
					40297: 25329,
					40298: 25383,
					40299: 25346,
					40300: 25352,
					40301: 25327,
					40302: 25333,
					40303: 25424,
					40304: 25406,
					40305: 25421,
					40306: 25628,
					40307: 25423,
					40308: 25494,
					40309: 25486,
					40310: 25472,
					40311: 25515,
					40312: 25462,
					40313: 25507,
					40314: 25487,
					40315: 25481,
					40316: 25503,
					40317: 25525,
					40318: 25451,
					40320: 25449,
					40321: 25534,
					40322: 25577,
					40323: 25536,
					40324: 25542,
					40325: 25571,
					40326: 25545,
					40327: 25554,
					40328: 25590,
					40329: 25540,
					40330: 25622,
					40331: 25652,
					40332: 25606,
					40333: 25619,
					40334: 25638,
					40335: 25654,
					40336: 25885,
					40337: 25623,
					40338: 25640,
					40339: 25615,
					40340: 25703,
					40341: 25711,
					40342: 25718,
					40343: 25678,
					40344: 25898,
					40345: 25749,
					40346: 25747,
					40347: 25765,
					40348: 25769,
					40349: 25736,
					40350: 25788,
					40351: 25818,
					40352: 25810,
					40353: 25797,
					40354: 25799,
					40355: 25787,
					40356: 25816,
					40357: 25794,
					40358: 25841,
					40359: 25831,
					40360: 33289,
					40361: 25824,
					40362: 25825,
					40363: 25260,
					40364: 25827,
					40365: 25839,
					40366: 25900,
					40367: 25846,
					40368: 25844,
					40369: 25842,
					40370: 25850,
					40371: 25856,
					40372: 25853,
					40373: 25880,
					40374: 25884,
					40375: 25861,
					40376: 25892,
					40377: 25891,
					40378: 25899,
					40379: 25908,
					40380: 25909,
					40381: 25911,
					40382: 25910,
					40383: 25912,
					40384: 30027,
					40385: 25928,
					40386: 25942,
					40387: 25941,
					40388: 25933,
					40389: 25944,
					40390: 25950,
					40391: 25949,
					40392: 25970,
					40393: 25976,
					40394: 25986,
					40395: 25987,
					40396: 35722,
					40397: 26011,
					40398: 26015,
					40399: 26027,
					40400: 26039,
					40401: 26051,
					40402: 26054,
					40403: 26049,
					40404: 26052,
					40405: 26060,
					40406: 26066,
					40407: 26075,
					40408: 26073,
					40409: 26080,
					40410: 26081,
					40411: 26097,
					40412: 26482,
					40413: 26122,
					40414: 26115,
					40415: 26107,
					40416: 26483,
					40417: 26165,
					40418: 26166,
					40419: 26164,
					40420: 26140,
					40421: 26191,
					40422: 26180,
					40423: 26185,
					40424: 26177,
					40425: 26206,
					40426: 26205,
					40427: 26212,
					40428: 26215,
					40429: 26216,
					40430: 26207,
					40431: 26210,
					40432: 26224,
					40433: 26243,
					40434: 26248,
					40435: 26254,
					40436: 26249,
					40437: 26244,
					40438: 26264,
					40439: 26269,
					40440: 26305,
					40441: 26297,
					40442: 26313,
					40443: 26302,
					40444: 26300,
					40512: 26308,
					40513: 26296,
					40514: 26326,
					40515: 26330,
					40516: 26336,
					40517: 26175,
					40518: 26342,
					40519: 26345,
					40520: 26352,
					40521: 26357,
					40522: 26359,
					40523: 26383,
					40524: 26390,
					40525: 26398,
					40526: 26406,
					40527: 26407,
					40528: 38712,
					40529: 26414,
					40530: 26431,
					40531: 26422,
					40532: 26433,
					40533: 26424,
					40534: 26423,
					40535: 26438,
					40536: 26462,
					40537: 26464,
					40538: 26457,
					40539: 26467,
					40540: 26468,
					40541: 26505,
					40542: 26480,
					40543: 26537,
					40544: 26492,
					40545: 26474,
					40546: 26508,
					40547: 26507,
					40548: 26534,
					40549: 26529,
					40550: 26501,
					40551: 26551,
					40552: 26607,
					40553: 26548,
					40554: 26604,
					40555: 26547,
					40556: 26601,
					40557: 26552,
					40558: 26596,
					40559: 26590,
					40560: 26589,
					40561: 26594,
					40562: 26606,
					40563: 26553,
					40564: 26574,
					40565: 26566,
					40566: 26599,
					40567: 27292,
					40568: 26654,
					40569: 26694,
					40570: 26665,
					40571: 26688,
					40572: 26701,
					40573: 26674,
					40574: 26702,
					40576: 26803,
					40577: 26667,
					40578: 26713,
					40579: 26723,
					40580: 26743,
					40581: 26751,
					40582: 26783,
					40583: 26767,
					40584: 26797,
					40585: 26772,
					40586: 26781,
					40587: 26779,
					40588: 26755,
					40589: 27310,
					40590: 26809,
					40591: 26740,
					40592: 26805,
					40593: 26784,
					40594: 26810,
					40595: 26895,
					40596: 26765,
					40597: 26750,
					40598: 26881,
					40599: 26826,
					40600: 26888,
					40601: 26840,
					40602: 26914,
					40603: 26918,
					40604: 26849,
					40605: 26892,
					40606: 26829,
					40607: 26836,
					40608: 26855,
					40609: 26837,
					40610: 26934,
					40611: 26898,
					40612: 26884,
					40613: 26839,
					40614: 26851,
					40615: 26917,
					40616: 26873,
					40617: 26848,
					40618: 26863,
					40619: 26920,
					40620: 26922,
					40621: 26906,
					40622: 26915,
					40623: 26913,
					40624: 26822,
					40625: 27001,
					40626: 26999,
					40627: 26972,
					40628: 27e3,
					40629: 26987,
					40630: 26964,
					40631: 27006,
					40632: 26990,
					40633: 26937,
					40634: 26996,
					40635: 26941,
					40636: 26969,
					40637: 26928,
					40638: 26977,
					40639: 26974,
					40640: 26973,
					40641: 27009,
					40642: 26986,
					40643: 27058,
					40644: 27054,
					40645: 27088,
					40646: 27071,
					40647: 27073,
					40648: 27091,
					40649: 27070,
					40650: 27086,
					40651: 23528,
					40652: 27082,
					40653: 27101,
					40654: 27067,
					40655: 27075,
					40656: 27047,
					40657: 27182,
					40658: 27025,
					40659: 27040,
					40660: 27036,
					40661: 27029,
					40662: 27060,
					40663: 27102,
					40664: 27112,
					40665: 27138,
					40666: 27163,
					40667: 27135,
					40668: 27402,
					40669: 27129,
					40670: 27122,
					40671: 27111,
					40672: 27141,
					40673: 27057,
					40674: 27166,
					40675: 27117,
					40676: 27156,
					40677: 27115,
					40678: 27146,
					40679: 27154,
					40680: 27329,
					40681: 27171,
					40682: 27155,
					40683: 27204,
					40684: 27148,
					40685: 27250,
					40686: 27190,
					40687: 27256,
					40688: 27207,
					40689: 27234,
					40690: 27225,
					40691: 27238,
					40692: 27208,
					40693: 27192,
					40694: 27170,
					40695: 27280,
					40696: 27277,
					40697: 27296,
					40698: 27268,
					40699: 27298,
					40700: 27299,
					40768: 27287,
					40769: 34327,
					40770: 27323,
					40771: 27331,
					40772: 27330,
					40773: 27320,
					40774: 27315,
					40775: 27308,
					40776: 27358,
					40777: 27345,
					40778: 27359,
					40779: 27306,
					40780: 27354,
					40781: 27370,
					40782: 27387,
					40783: 27397,
					40784: 34326,
					40785: 27386,
					40786: 27410,
					40787: 27414,
					40788: 39729,
					40789: 27423,
					40790: 27448,
					40791: 27447,
					40792: 30428,
					40793: 27449,
					40794: 39150,
					40795: 27463,
					40796: 27459,
					40797: 27465,
					40798: 27472,
					40799: 27481,
					40800: 27476,
					40801: 27483,
					40802: 27487,
					40803: 27489,
					40804: 27512,
					40805: 27513,
					40806: 27519,
					40807: 27520,
					40808: 27524,
					40809: 27523,
					40810: 27533,
					40811: 27544,
					40812: 27541,
					40813: 27550,
					40814: 27556,
					40815: 27562,
					40816: 27563,
					40817: 27567,
					40818: 27570,
					40819: 27569,
					40820: 27571,
					40821: 27575,
					40822: 27580,
					40823: 27590,
					40824: 27595,
					40825: 27603,
					40826: 27615,
					40827: 27628,
					40828: 27627,
					40829: 27635,
					40830: 27631,
					40832: 40638,
					40833: 27656,
					40834: 27667,
					40835: 27668,
					40836: 27675,
					40837: 27684,
					40838: 27683,
					40839: 27742,
					40840: 27733,
					40841: 27746,
					40842: 27754,
					40843: 27778,
					40844: 27789,
					40845: 27802,
					40846: 27777,
					40847: 27803,
					40848: 27774,
					40849: 27752,
					40850: 27763,
					40851: 27794,
					40852: 27792,
					40853: 27844,
					40854: 27889,
					40855: 27859,
					40856: 27837,
					40857: 27863,
					40858: 27845,
					40859: 27869,
					40860: 27822,
					40861: 27825,
					40862: 27838,
					40863: 27834,
					40864: 27867,
					40865: 27887,
					40866: 27865,
					40867: 27882,
					40868: 27935,
					40869: 34893,
					40870: 27958,
					40871: 27947,
					40872: 27965,
					40873: 27960,
					40874: 27929,
					40875: 27957,
					40876: 27955,
					40877: 27922,
					40878: 27916,
					40879: 28003,
					40880: 28051,
					40881: 28004,
					40882: 27994,
					40883: 28025,
					40884: 27993,
					40885: 28046,
					40886: 28053,
					40887: 28644,
					40888: 28037,
					40889: 28153,
					40890: 28181,
					40891: 28170,
					40892: 28085,
					40893: 28103,
					40894: 28134,
					40895: 28088,
					40896: 28102,
					40897: 28140,
					40898: 28126,
					40899: 28108,
					40900: 28136,
					40901: 28114,
					40902: 28101,
					40903: 28154,
					40904: 28121,
					40905: 28132,
					40906: 28117,
					40907: 28138,
					40908: 28142,
					40909: 28205,
					40910: 28270,
					40911: 28206,
					40912: 28185,
					40913: 28274,
					40914: 28255,
					40915: 28222,
					40916: 28195,
					40917: 28267,
					40918: 28203,
					40919: 28278,
					40920: 28237,
					40921: 28191,
					40922: 28227,
					40923: 28218,
					40924: 28238,
					40925: 28196,
					40926: 28415,
					40927: 28189,
					40928: 28216,
					40929: 28290,
					40930: 28330,
					40931: 28312,
					40932: 28361,
					40933: 28343,
					40934: 28371,
					40935: 28349,
					40936: 28335,
					40937: 28356,
					40938: 28338,
					40939: 28372,
					40940: 28373,
					40941: 28303,
					40942: 28325,
					40943: 28354,
					40944: 28319,
					40945: 28481,
					40946: 28433,
					40947: 28748,
					40948: 28396,
					40949: 28408,
					40950: 28414,
					40951: 28479,
					40952: 28402,
					40953: 28465,
					40954: 28399,
					40955: 28466,
					40956: 28364,
					161: 65377,
					162: 65378,
					163: 65379,
					164: 65380,
					165: 65381,
					166: 65382,
					167: 65383,
					168: 65384,
					169: 65385,
					170: 65386,
					171: 65387,
					172: 65388,
					173: 65389,
					174: 65390,
					175: 65391,
					176: 65392,
					177: 65393,
					178: 65394,
					179: 65395,
					180: 65396,
					181: 65397,
					182: 65398,
					183: 65399,
					184: 65400,
					185: 65401,
					186: 65402,
					187: 65403,
					188: 65404,
					189: 65405,
					190: 65406,
					191: 65407,
					192: 65408,
					193: 65409,
					194: 65410,
					195: 65411,
					196: 65412,
					197: 65413,
					198: 65414,
					199: 65415,
					200: 65416,
					201: 65417,
					202: 65418,
					203: 65419,
					204: 65420,
					205: 65421,
					206: 65422,
					207: 65423,
					208: 65424,
					209: 65425,
					210: 65426,
					211: 65427,
					212: 65428,
					213: 65429,
					214: 65430,
					215: 65431,
					216: 65432,
					217: 65433,
					218: 65434,
					219: 65435,
					220: 65436,
					221: 65437,
					222: 65438,
					223: 65439,
					57408: 28478,
					57409: 28435,
					57410: 28407,
					57411: 28550,
					57412: 28538,
					57413: 28536,
					57414: 28545,
					57415: 28544,
					57416: 28527,
					57417: 28507,
					57418: 28659,
					57419: 28525,
					57420: 28546,
					57421: 28540,
					57422: 28504,
					57423: 28558,
					57424: 28561,
					57425: 28610,
					57426: 28518,
					57427: 28595,
					57428: 28579,
					57429: 28577,
					57430: 28580,
					57431: 28601,
					57432: 28614,
					57433: 28586,
					57434: 28639,
					57435: 28629,
					57436: 28652,
					57437: 28628,
					57438: 28632,
					57439: 28657,
					57440: 28654,
					57441: 28635,
					57442: 28681,
					57443: 28683,
					57444: 28666,
					57445: 28689,
					57446: 28673,
					57447: 28687,
					57448: 28670,
					57449: 28699,
					57450: 28698,
					57451: 28532,
					57452: 28701,
					57453: 28696,
					57454: 28703,
					57455: 28720,
					57456: 28734,
					57457: 28722,
					57458: 28753,
					57459: 28771,
					57460: 28825,
					57461: 28818,
					57462: 28847,
					57463: 28913,
					57464: 28844,
					57465: 28856,
					57466: 28851,
					57467: 28846,
					57468: 28895,
					57469: 28875,
					57470: 28893,
					57472: 28889,
					57473: 28937,
					57474: 28925,
					57475: 28956,
					57476: 28953,
					57477: 29029,
					57478: 29013,
					57479: 29064,
					57480: 29030,
					57481: 29026,
					57482: 29004,
					57483: 29014,
					57484: 29036,
					57485: 29071,
					57486: 29179,
					57487: 29060,
					57488: 29077,
					57489: 29096,
					57490: 29100,
					57491: 29143,
					57492: 29113,
					57493: 29118,
					57494: 29138,
					57495: 29129,
					57496: 29140,
					57497: 29134,
					57498: 29152,
					57499: 29164,
					57500: 29159,
					57501: 29173,
					57502: 29180,
					57503: 29177,
					57504: 29183,
					57505: 29197,
					57506: 29200,
					57507: 29211,
					57508: 29224,
					57509: 29229,
					57510: 29228,
					57511: 29232,
					57512: 29234,
					57513: 29243,
					57514: 29244,
					57515: 29247,
					57516: 29248,
					57517: 29254,
					57518: 29259,
					57519: 29272,
					57520: 29300,
					57521: 29310,
					57522: 29314,
					57523: 29313,
					57524: 29319,
					57525: 29330,
					57526: 29334,
					57527: 29346,
					57528: 29351,
					57529: 29369,
					57530: 29362,
					57531: 29379,
					57532: 29382,
					57533: 29380,
					57534: 29390,
					57535: 29394,
					57536: 29410,
					57537: 29408,
					57538: 29409,
					57539: 29433,
					57540: 29431,
					57541: 20495,
					57542: 29463,
					57543: 29450,
					57544: 29468,
					57545: 29462,
					57546: 29469,
					57547: 29492,
					57548: 29487,
					57549: 29481,
					57550: 29477,
					57551: 29502,
					57552: 29518,
					57553: 29519,
					57554: 40664,
					57555: 29527,
					57556: 29546,
					57557: 29544,
					57558: 29552,
					57559: 29560,
					57560: 29557,
					57561: 29563,
					57562: 29562,
					57563: 29640,
					57564: 29619,
					57565: 29646,
					57566: 29627,
					57567: 29632,
					57568: 29669,
					57569: 29678,
					57570: 29662,
					57571: 29858,
					57572: 29701,
					57573: 29807,
					57574: 29733,
					57575: 29688,
					57576: 29746,
					57577: 29754,
					57578: 29781,
					57579: 29759,
					57580: 29791,
					57581: 29785,
					57582: 29761,
					57583: 29788,
					57584: 29801,
					57585: 29808,
					57586: 29795,
					57587: 29802,
					57588: 29814,
					57589: 29822,
					57590: 29835,
					57591: 29854,
					57592: 29863,
					57593: 29898,
					57594: 29903,
					57595: 29908,
					57596: 29681,
					57664: 29920,
					57665: 29923,
					57666: 29927,
					57667: 29929,
					57668: 29934,
					57669: 29938,
					57670: 29936,
					57671: 29937,
					57672: 29944,
					57673: 29943,
					57674: 29956,
					57675: 29955,
					57676: 29957,
					57677: 29964,
					57678: 29966,
					57679: 29965,
					57680: 29973,
					57681: 29971,
					57682: 29982,
					57683: 29990,
					57684: 29996,
					57685: 30012,
					57686: 30020,
					57687: 30029,
					57688: 30026,
					57689: 30025,
					57690: 30043,
					57691: 30022,
					57692: 30042,
					57693: 30057,
					57694: 30052,
					57695: 30055,
					57696: 30059,
					57697: 30061,
					57698: 30072,
					57699: 30070,
					57700: 30086,
					57701: 30087,
					57702: 30068,
					57703: 30090,
					57704: 30089,
					57705: 30082,
					57706: 30100,
					57707: 30106,
					57708: 30109,
					57709: 30117,
					57710: 30115,
					57711: 30146,
					57712: 30131,
					57713: 30147,
					57714: 30133,
					57715: 30141,
					57716: 30136,
					57717: 30140,
					57718: 30129,
					57719: 30157,
					57720: 30154,
					57721: 30162,
					57722: 30169,
					57723: 30179,
					57724: 30174,
					57725: 30206,
					57726: 30207,
					57728: 30204,
					57729: 30209,
					57730: 30192,
					57731: 30202,
					57732: 30194,
					57733: 30195,
					57734: 30219,
					57735: 30221,
					57736: 30217,
					57737: 30239,
					57738: 30247,
					57739: 30240,
					57740: 30241,
					57741: 30242,
					57742: 30244,
					57743: 30260,
					57744: 30256,
					57745: 30267,
					57746: 30279,
					57747: 30280,
					57748: 30278,
					57749: 30300,
					57750: 30296,
					57751: 30305,
					57752: 30306,
					57753: 30312,
					57754: 30313,
					57755: 30314,
					57756: 30311,
					57757: 30316,
					57758: 30320,
					57759: 30322,
					57760: 30326,
					57761: 30328,
					57762: 30332,
					57763: 30336,
					57764: 30339,
					57765: 30344,
					57766: 30347,
					57767: 30350,
					57768: 30358,
					57769: 30355,
					57770: 30361,
					57771: 30362,
					57772: 30384,
					57773: 30388,
					57774: 30392,
					57775: 30393,
					57776: 30394,
					57777: 30402,
					57778: 30413,
					57779: 30422,
					57780: 30418,
					57781: 30430,
					57782: 30433,
					57783: 30437,
					57784: 30439,
					57785: 30442,
					57786: 34351,
					57787: 30459,
					57788: 30472,
					57789: 30471,
					57790: 30468,
					57791: 30505,
					57792: 30500,
					57793: 30494,
					57794: 30501,
					57795: 30502,
					57796: 30491,
					57797: 30519,
					57798: 30520,
					57799: 30535,
					57800: 30554,
					57801: 30568,
					57802: 30571,
					57803: 30555,
					57804: 30565,
					57805: 30591,
					57806: 30590,
					57807: 30585,
					57808: 30606,
					57809: 30603,
					57810: 30609,
					57811: 30624,
					57812: 30622,
					57813: 30640,
					57814: 30646,
					57815: 30649,
					57816: 30655,
					57817: 30652,
					57818: 30653,
					57819: 30651,
					57820: 30663,
					57821: 30669,
					57822: 30679,
					57823: 30682,
					57824: 30684,
					57825: 30691,
					57826: 30702,
					57827: 30716,
					57828: 30732,
					57829: 30738,
					57830: 31014,
					57831: 30752,
					57832: 31018,
					57833: 30789,
					57834: 30862,
					57835: 30836,
					57836: 30854,
					57837: 30844,
					57838: 30874,
					57839: 30860,
					57840: 30883,
					57841: 30901,
					57842: 30890,
					57843: 30895,
					57844: 30929,
					57845: 30918,
					57846: 30923,
					57847: 30932,
					57848: 30910,
					57849: 30908,
					57850: 30917,
					57851: 30922,
					57852: 30956,
					57920: 30951,
					57921: 30938,
					57922: 30973,
					57923: 30964,
					57924: 30983,
					57925: 30994,
					57926: 30993,
					57927: 31001,
					57928: 31020,
					57929: 31019,
					57930: 31040,
					57931: 31072,
					57932: 31063,
					57933: 31071,
					57934: 31066,
					57935: 31061,
					57936: 31059,
					57937: 31098,
					57938: 31103,
					57939: 31114,
					57940: 31133,
					57941: 31143,
					57942: 40779,
					57943: 31146,
					57944: 31150,
					57945: 31155,
					57946: 31161,
					57947: 31162,
					57948: 31177,
					57949: 31189,
					57950: 31207,
					57951: 31212,
					57952: 31201,
					57953: 31203,
					57954: 31240,
					57955: 31245,
					57956: 31256,
					57957: 31257,
					57958: 31264,
					57959: 31263,
					57960: 31104,
					57961: 31281,
					57962: 31291,
					57963: 31294,
					57964: 31287,
					57965: 31299,
					57966: 31319,
					57967: 31305,
					57968: 31329,
					57969: 31330,
					57970: 31337,
					57971: 40861,
					57972: 31344,
					57973: 31353,
					57974: 31357,
					57975: 31368,
					57976: 31383,
					57977: 31381,
					57978: 31384,
					57979: 31382,
					57980: 31401,
					57981: 31432,
					57982: 31408,
					57984: 31414,
					57985: 31429,
					57986: 31428,
					57987: 31423,
					57988: 36995,
					57989: 31431,
					57990: 31434,
					57991: 31437,
					57992: 31439,
					57993: 31445,
					57994: 31443,
					57995: 31449,
					57996: 31450,
					57997: 31453,
					57998: 31457,
					57999: 31458,
					58e3: 31462,
					58001: 31469,
					58002: 31472,
					58003: 31490,
					58004: 31503,
					58005: 31498,
					58006: 31494,
					58007: 31539,
					58008: 31512,
					58009: 31513,
					58010: 31518,
					58011: 31541,
					58012: 31528,
					58013: 31542,
					58014: 31568,
					58015: 31610,
					58016: 31492,
					58017: 31565,
					58018: 31499,
					58019: 31564,
					58020: 31557,
					58021: 31605,
					58022: 31589,
					58023: 31604,
					58024: 31591,
					58025: 31600,
					58026: 31601,
					58027: 31596,
					58028: 31598,
					58029: 31645,
					58030: 31640,
					58031: 31647,
					58032: 31629,
					58033: 31644,
					58034: 31642,
					58035: 31627,
					58036: 31634,
					58037: 31631,
					58038: 31581,
					58039: 31641,
					58040: 31691,
					58041: 31681,
					58042: 31692,
					58043: 31695,
					58044: 31668,
					58045: 31686,
					58046: 31709,
					58047: 31721,
					58048: 31761,
					58049: 31764,
					58050: 31718,
					58051: 31717,
					58052: 31840,
					58053: 31744,
					58054: 31751,
					58055: 31763,
					58056: 31731,
					58057: 31735,
					58058: 31767,
					58059: 31757,
					58060: 31734,
					58061: 31779,
					58062: 31783,
					58063: 31786,
					58064: 31775,
					58065: 31799,
					58066: 31787,
					58067: 31805,
					58068: 31820,
					58069: 31811,
					58070: 31828,
					58071: 31823,
					58072: 31808,
					58073: 31824,
					58074: 31832,
					58075: 31839,
					58076: 31844,
					58077: 31830,
					58078: 31845,
					58079: 31852,
					58080: 31861,
					58081: 31875,
					58082: 31888,
					58083: 31908,
					58084: 31917,
					58085: 31906,
					58086: 31915,
					58087: 31905,
					58088: 31912,
					58089: 31923,
					58090: 31922,
					58091: 31921,
					58092: 31918,
					58093: 31929,
					58094: 31933,
					58095: 31936,
					58096: 31941,
					58097: 31938,
					58098: 31960,
					58099: 31954,
					58100: 31964,
					58101: 31970,
					58102: 39739,
					58103: 31983,
					58104: 31986,
					58105: 31988,
					58106: 31990,
					58107: 31994,
					58108: 32006,
					58176: 32002,
					58177: 32028,
					58178: 32021,
					58179: 32010,
					58180: 32069,
					58181: 32075,
					58182: 32046,
					58183: 32050,
					58184: 32063,
					58185: 32053,
					58186: 32070,
					58187: 32115,
					58188: 32086,
					58189: 32078,
					58190: 32114,
					58191: 32104,
					58192: 32110,
					58193: 32079,
					58194: 32099,
					58195: 32147,
					58196: 32137,
					58197: 32091,
					58198: 32143,
					58199: 32125,
					58200: 32155,
					58201: 32186,
					58202: 32174,
					58203: 32163,
					58204: 32181,
					58205: 32199,
					58206: 32189,
					58207: 32171,
					58208: 32317,
					58209: 32162,
					58210: 32175,
					58211: 32220,
					58212: 32184,
					58213: 32159,
					58214: 32176,
					58215: 32216,
					58216: 32221,
					58217: 32228,
					58218: 32222,
					58219: 32251,
					58220: 32242,
					58221: 32225,
					58222: 32261,
					58223: 32266,
					58224: 32291,
					58225: 32289,
					58226: 32274,
					58227: 32305,
					58228: 32287,
					58229: 32265,
					58230: 32267,
					58231: 32290,
					58232: 32326,
					58233: 32358,
					58234: 32315,
					58235: 32309,
					58236: 32313,
					58237: 32323,
					58238: 32311,
					58240: 32306,
					58241: 32314,
					58242: 32359,
					58243: 32349,
					58244: 32342,
					58245: 32350,
					58246: 32345,
					58247: 32346,
					58248: 32377,
					58249: 32362,
					58250: 32361,
					58251: 32380,
					58252: 32379,
					58253: 32387,
					58254: 32213,
					58255: 32381,
					58256: 36782,
					58257: 32383,
					58258: 32392,
					58259: 32393,
					58260: 32396,
					58261: 32402,
					58262: 32400,
					58263: 32403,
					58264: 32404,
					58265: 32406,
					58266: 32398,
					58267: 32411,
					58268: 32412,
					58269: 32568,
					58270: 32570,
					58271: 32581,
					58272: 32588,
					58273: 32589,
					58274: 32590,
					58275: 32592,
					58276: 32593,
					58277: 32597,
					58278: 32596,
					58279: 32600,
					58280: 32607,
					58281: 32608,
					58282: 32616,
					58283: 32617,
					58284: 32615,
					58285: 32632,
					58286: 32642,
					58287: 32646,
					58288: 32643,
					58289: 32648,
					58290: 32647,
					58291: 32652,
					58292: 32660,
					58293: 32670,
					58294: 32669,
					58295: 32666,
					58296: 32675,
					58297: 32687,
					58298: 32690,
					58299: 32697,
					58300: 32686,
					58301: 32694,
					58302: 32696,
					58303: 35697,
					58304: 32709,
					58305: 32710,
					58306: 32714,
					58307: 32725,
					58308: 32724,
					58309: 32737,
					58310: 32742,
					58311: 32745,
					58312: 32755,
					58313: 32761,
					58314: 39132,
					58315: 32774,
					58316: 32772,
					58317: 32779,
					58318: 32786,
					58319: 32792,
					58320: 32793,
					58321: 32796,
					58322: 32801,
					58323: 32808,
					58324: 32831,
					58325: 32827,
					58326: 32842,
					58327: 32838,
					58328: 32850,
					58329: 32856,
					58330: 32858,
					58331: 32863,
					58332: 32866,
					58333: 32872,
					58334: 32883,
					58335: 32882,
					58336: 32880,
					58337: 32886,
					58338: 32889,
					58339: 32893,
					58340: 32895,
					58341: 32900,
					58342: 32902,
					58343: 32901,
					58344: 32923,
					58345: 32915,
					58346: 32922,
					58347: 32941,
					58348: 20880,
					58349: 32940,
					58350: 32987,
					58351: 32997,
					58352: 32985,
					58353: 32989,
					58354: 32964,
					58355: 32986,
					58356: 32982,
					58357: 33033,
					58358: 33007,
					58359: 33009,
					58360: 33051,
					58361: 33065,
					58362: 33059,
					58363: 33071,
					58364: 33099,
					58432: 38539,
					58433: 33094,
					58434: 33086,
					58435: 33107,
					58436: 33105,
					58437: 33020,
					58438: 33137,
					58439: 33134,
					58440: 33125,
					58441: 33126,
					58442: 33140,
					58443: 33155,
					58444: 33160,
					58445: 33162,
					58446: 33152,
					58447: 33154,
					58448: 33184,
					58449: 33173,
					58450: 33188,
					58451: 33187,
					58452: 33119,
					58453: 33171,
					58454: 33193,
					58455: 33200,
					58456: 33205,
					58457: 33214,
					58458: 33208,
					58459: 33213,
					58460: 33216,
					58461: 33218,
					58462: 33210,
					58463: 33225,
					58464: 33229,
					58465: 33233,
					58466: 33241,
					58467: 33240,
					58468: 33224,
					58469: 33242,
					58470: 33247,
					58471: 33248,
					58472: 33255,
					58473: 33274,
					58474: 33275,
					58475: 33278,
					58476: 33281,
					58477: 33282,
					58478: 33285,
					58479: 33287,
					58480: 33290,
					58481: 33293,
					58482: 33296,
					58483: 33302,
					58484: 33321,
					58485: 33323,
					58486: 33336,
					58487: 33331,
					58488: 33344,
					58489: 33369,
					58490: 33368,
					58491: 33373,
					58492: 33370,
					58493: 33375,
					58494: 33380,
					58496: 33378,
					58497: 33384,
					58498: 33386,
					58499: 33387,
					58500: 33326,
					58501: 33393,
					58502: 33399,
					58503: 33400,
					58504: 33406,
					58505: 33421,
					58506: 33426,
					58507: 33451,
					58508: 33439,
					58509: 33467,
					58510: 33452,
					58511: 33505,
					58512: 33507,
					58513: 33503,
					58514: 33490,
					58515: 33524,
					58516: 33523,
					58517: 33530,
					58518: 33683,
					58519: 33539,
					58520: 33531,
					58521: 33529,
					58522: 33502,
					58523: 33542,
					58524: 33500,
					58525: 33545,
					58526: 33497,
					58527: 33589,
					58528: 33588,
					58529: 33558,
					58530: 33586,
					58531: 33585,
					58532: 33600,
					58533: 33593,
					58534: 33616,
					58535: 33605,
					58536: 33583,
					58537: 33579,
					58538: 33559,
					58539: 33560,
					58540: 33669,
					58541: 33690,
					58542: 33706,
					58543: 33695,
					58544: 33698,
					58545: 33686,
					58546: 33571,
					58547: 33678,
					58548: 33671,
					58549: 33674,
					58550: 33660,
					58551: 33717,
					58552: 33651,
					58553: 33653,
					58554: 33696,
					58555: 33673,
					58556: 33704,
					58557: 33780,
					58558: 33811,
					58559: 33771,
					58560: 33742,
					58561: 33789,
					58562: 33795,
					58563: 33752,
					58564: 33803,
					58565: 33729,
					58566: 33783,
					58567: 33799,
					58568: 33760,
					58569: 33778,
					58570: 33805,
					58571: 33826,
					58572: 33824,
					58573: 33725,
					58574: 33848,
					58575: 34054,
					58576: 33787,
					58577: 33901,
					58578: 33834,
					58579: 33852,
					58580: 34138,
					58581: 33924,
					58582: 33911,
					58583: 33899,
					58584: 33965,
					58585: 33902,
					58586: 33922,
					58587: 33897,
					58588: 33862,
					58589: 33836,
					58590: 33903,
					58591: 33913,
					58592: 33845,
					58593: 33994,
					58594: 33890,
					58595: 33977,
					58596: 33983,
					58597: 33951,
					58598: 34009,
					58599: 33997,
					58600: 33979,
					58601: 34010,
					58602: 34e3,
					58603: 33985,
					58604: 33990,
					58605: 34006,
					58606: 33953,
					58607: 34081,
					58608: 34047,
					58609: 34036,
					58610: 34071,
					58611: 34072,
					58612: 34092,
					58613: 34079,
					58614: 34069,
					58615: 34068,
					58616: 34044,
					58617: 34112,
					58618: 34147,
					58619: 34136,
					58620: 34120,
					58688: 34113,
					58689: 34306,
					58690: 34123,
					58691: 34133,
					58692: 34176,
					58693: 34212,
					58694: 34184,
					58695: 34193,
					58696: 34186,
					58697: 34216,
					58698: 34157,
					58699: 34196,
					58700: 34203,
					58701: 34282,
					58702: 34183,
					58703: 34204,
					58704: 34167,
					58705: 34174,
					58706: 34192,
					58707: 34249,
					58708: 34234,
					58709: 34255,
					58710: 34233,
					58711: 34256,
					58712: 34261,
					58713: 34269,
					58714: 34277,
					58715: 34268,
					58716: 34297,
					58717: 34314,
					58718: 34323,
					58719: 34315,
					58720: 34302,
					58721: 34298,
					58722: 34310,
					58723: 34338,
					58724: 34330,
					58725: 34352,
					58726: 34367,
					58727: 34381,
					58728: 20053,
					58729: 34388,
					58730: 34399,
					58731: 34407,
					58732: 34417,
					58733: 34451,
					58734: 34467,
					58735: 34473,
					58736: 34474,
					58737: 34443,
					58738: 34444,
					58739: 34486,
					58740: 34479,
					58741: 34500,
					58742: 34502,
					58743: 34480,
					58744: 34505,
					58745: 34851,
					58746: 34475,
					58747: 34516,
					58748: 34526,
					58749: 34537,
					58750: 34540,
					58752: 34527,
					58753: 34523,
					58754: 34543,
					58755: 34578,
					58756: 34566,
					58757: 34568,
					58758: 34560,
					58759: 34563,
					58760: 34555,
					58761: 34577,
					58762: 34569,
					58763: 34573,
					58764: 34553,
					58765: 34570,
					58766: 34612,
					58767: 34623,
					58768: 34615,
					58769: 34619,
					58770: 34597,
					58771: 34601,
					58772: 34586,
					58773: 34656,
					58774: 34655,
					58775: 34680,
					58776: 34636,
					58777: 34638,
					58778: 34676,
					58779: 34647,
					58780: 34664,
					58781: 34670,
					58782: 34649,
					58783: 34643,
					58784: 34659,
					58785: 34666,
					58786: 34821,
					58787: 34722,
					58788: 34719,
					58789: 34690,
					58790: 34735,
					58791: 34763,
					58792: 34749,
					58793: 34752,
					58794: 34768,
					58795: 38614,
					58796: 34731,
					58797: 34756,
					58798: 34739,
					58799: 34759,
					58800: 34758,
					58801: 34747,
					58802: 34799,
					58803: 34802,
					58804: 34784,
					58805: 34831,
					58806: 34829,
					58807: 34814,
					58808: 34806,
					58809: 34807,
					58810: 34830,
					58811: 34770,
					58812: 34833,
					58813: 34838,
					58814: 34837,
					58815: 34850,
					58816: 34849,
					58817: 34865,
					58818: 34870,
					58819: 34873,
					58820: 34855,
					58821: 34875,
					58822: 34884,
					58823: 34882,
					58824: 34898,
					58825: 34905,
					58826: 34910,
					58827: 34914,
					58828: 34923,
					58829: 34945,
					58830: 34942,
					58831: 34974,
					58832: 34933,
					58833: 34941,
					58834: 34997,
					58835: 34930,
					58836: 34946,
					58837: 34967,
					58838: 34962,
					58839: 34990,
					58840: 34969,
					58841: 34978,
					58842: 34957,
					58843: 34980,
					58844: 34992,
					58845: 35007,
					58846: 34993,
					58847: 35011,
					58848: 35012,
					58849: 35028,
					58850: 35032,
					58851: 35033,
					58852: 35037,
					58853: 35065,
					58854: 35074,
					58855: 35068,
					58856: 35060,
					58857: 35048,
					58858: 35058,
					58859: 35076,
					58860: 35084,
					58861: 35082,
					58862: 35091,
					58863: 35139,
					58864: 35102,
					58865: 35109,
					58866: 35114,
					58867: 35115,
					58868: 35137,
					58869: 35140,
					58870: 35131,
					58871: 35126,
					58872: 35128,
					58873: 35148,
					58874: 35101,
					58875: 35168,
					58876: 35166,
					58944: 35174,
					58945: 35172,
					58946: 35181,
					58947: 35178,
					58948: 35183,
					58949: 35188,
					58950: 35191,
					58951: 35198,
					58952: 35203,
					58953: 35208,
					58954: 35210,
					58955: 35219,
					58956: 35224,
					58957: 35233,
					58958: 35241,
					58959: 35238,
					58960: 35244,
					58961: 35247,
					58962: 35250,
					58963: 35258,
					58964: 35261,
					58965: 35263,
					58966: 35264,
					58967: 35290,
					58968: 35292,
					58969: 35293,
					58970: 35303,
					58971: 35316,
					58972: 35320,
					58973: 35331,
					58974: 35350,
					58975: 35344,
					58976: 35340,
					58977: 35355,
					58978: 35357,
					58979: 35365,
					58980: 35382,
					58981: 35393,
					58982: 35419,
					58983: 35410,
					58984: 35398,
					58985: 35400,
					58986: 35452,
					58987: 35437,
					58988: 35436,
					58989: 35426,
					58990: 35461,
					58991: 35458,
					58992: 35460,
					58993: 35496,
					58994: 35489,
					58995: 35473,
					58996: 35493,
					58997: 35494,
					58998: 35482,
					58999: 35491,
					59e3: 35524,
					59001: 35533,
					59002: 35522,
					59003: 35546,
					59004: 35563,
					59005: 35571,
					59006: 35559,
					59008: 35556,
					59009: 35569,
					59010: 35604,
					59011: 35552,
					59012: 35554,
					59013: 35575,
					59014: 35550,
					59015: 35547,
					59016: 35596,
					59017: 35591,
					59018: 35610,
					59019: 35553,
					59020: 35606,
					59021: 35600,
					59022: 35607,
					59023: 35616,
					59024: 35635,
					59025: 38827,
					59026: 35622,
					59027: 35627,
					59028: 35646,
					59029: 35624,
					59030: 35649,
					59031: 35660,
					59032: 35663,
					59033: 35662,
					59034: 35657,
					59035: 35670,
					59036: 35675,
					59037: 35674,
					59038: 35691,
					59039: 35679,
					59040: 35692,
					59041: 35695,
					59042: 35700,
					59043: 35709,
					59044: 35712,
					59045: 35724,
					59046: 35726,
					59047: 35730,
					59048: 35731,
					59049: 35734,
					59050: 35737,
					59051: 35738,
					59052: 35898,
					59053: 35905,
					59054: 35903,
					59055: 35912,
					59056: 35916,
					59057: 35918,
					59058: 35920,
					59059: 35925,
					59060: 35938,
					59061: 35948,
					59062: 35960,
					59063: 35962,
					59064: 35970,
					59065: 35977,
					59066: 35973,
					59067: 35978,
					59068: 35981,
					59069: 35982,
					59070: 35988,
					59071: 35964,
					59072: 35992,
					59073: 25117,
					59074: 36013,
					59075: 36010,
					59076: 36029,
					59077: 36018,
					59078: 36019,
					59079: 36014,
					59080: 36022,
					59081: 36040,
					59082: 36033,
					59083: 36068,
					59084: 36067,
					59085: 36058,
					59086: 36093,
					59087: 36090,
					59088: 36091,
					59089: 36100,
					59090: 36101,
					59091: 36106,
					59092: 36103,
					59093: 36111,
					59094: 36109,
					59095: 36112,
					59096: 40782,
					59097: 36115,
					59098: 36045,
					59099: 36116,
					59100: 36118,
					59101: 36199,
					59102: 36205,
					59103: 36209,
					59104: 36211,
					59105: 36225,
					59106: 36249,
					59107: 36290,
					59108: 36286,
					59109: 36282,
					59110: 36303,
					59111: 36314,
					59112: 36310,
					59113: 36300,
					59114: 36315,
					59115: 36299,
					59116: 36330,
					59117: 36331,
					59118: 36319,
					59119: 36323,
					59120: 36348,
					59121: 36360,
					59122: 36361,
					59123: 36351,
					59124: 36381,
					59125: 36382,
					59126: 36368,
					59127: 36383,
					59128: 36418,
					59129: 36405,
					59130: 36400,
					59131: 36404,
					59132: 36426,
					59200: 36423,
					59201: 36425,
					59202: 36428,
					59203: 36432,
					59204: 36424,
					59205: 36441,
					59206: 36452,
					59207: 36448,
					59208: 36394,
					59209: 36451,
					59210: 36437,
					59211: 36470,
					59212: 36466,
					59213: 36476,
					59214: 36481,
					59215: 36487,
					59216: 36485,
					59217: 36484,
					59218: 36491,
					59219: 36490,
					59220: 36499,
					59221: 36497,
					59222: 36500,
					59223: 36505,
					59224: 36522,
					59225: 36513,
					59226: 36524,
					59227: 36528,
					59228: 36550,
					59229: 36529,
					59230: 36542,
					59231: 36549,
					59232: 36552,
					59233: 36555,
					59234: 36571,
					59235: 36579,
					59236: 36604,
					59237: 36603,
					59238: 36587,
					59239: 36606,
					59240: 36618,
					59241: 36613,
					59242: 36629,
					59243: 36626,
					59244: 36633,
					59245: 36627,
					59246: 36636,
					59247: 36639,
					59248: 36635,
					59249: 36620,
					59250: 36646,
					59251: 36659,
					59252: 36667,
					59253: 36665,
					59254: 36677,
					59255: 36674,
					59256: 36670,
					59257: 36684,
					59258: 36681,
					59259: 36678,
					59260: 36686,
					59261: 36695,
					59262: 36700,
					59264: 36706,
					59265: 36707,
					59266: 36708,
					59267: 36764,
					59268: 36767,
					59269: 36771,
					59270: 36781,
					59271: 36783,
					59272: 36791,
					59273: 36826,
					59274: 36837,
					59275: 36834,
					59276: 36842,
					59277: 36847,
					59278: 36999,
					59279: 36852,
					59280: 36869,
					59281: 36857,
					59282: 36858,
					59283: 36881,
					59284: 36885,
					59285: 36897,
					59286: 36877,
					59287: 36894,
					59288: 36886,
					59289: 36875,
					59290: 36903,
					59291: 36918,
					59292: 36917,
					59293: 36921,
					59294: 36856,
					59295: 36943,
					59296: 36944,
					59297: 36945,
					59298: 36946,
					59299: 36878,
					59300: 36937,
					59301: 36926,
					59302: 36950,
					59303: 36952,
					59304: 36958,
					59305: 36968,
					59306: 36975,
					59307: 36982,
					59308: 38568,
					59309: 36978,
					59310: 36994,
					59311: 36989,
					59312: 36993,
					59313: 36992,
					59314: 37002,
					59315: 37001,
					59316: 37007,
					59317: 37032,
					59318: 37039,
					59319: 37041,
					59320: 37045,
					59321: 37090,
					59322: 37092,
					59323: 25160,
					59324: 37083,
					59325: 37122,
					59326: 37138,
					59327: 37145,
					59328: 37170,
					59329: 37168,
					59330: 37194,
					59331: 37206,
					59332: 37208,
					59333: 37219,
					59334: 37221,
					59335: 37225,
					59336: 37235,
					59337: 37234,
					59338: 37259,
					59339: 37257,
					59340: 37250,
					59341: 37282,
					59342: 37291,
					59343: 37295,
					59344: 37290,
					59345: 37301,
					59346: 37300,
					59347: 37306,
					59348: 37312,
					59349: 37313,
					59350: 37321,
					59351: 37323,
					59352: 37328,
					59353: 37334,
					59354: 37343,
					59355: 37345,
					59356: 37339,
					59357: 37372,
					59358: 37365,
					59359: 37366,
					59360: 37406,
					59361: 37375,
					59362: 37396,
					59363: 37420,
					59364: 37397,
					59365: 37393,
					59366: 37470,
					59367: 37463,
					59368: 37445,
					59369: 37449,
					59370: 37476,
					59371: 37448,
					59372: 37525,
					59373: 37439,
					59374: 37451,
					59375: 37456,
					59376: 37532,
					59377: 37526,
					59378: 37523,
					59379: 37531,
					59380: 37466,
					59381: 37583,
					59382: 37561,
					59383: 37559,
					59384: 37609,
					59385: 37647,
					59386: 37626,
					59387: 37700,
					59388: 37678,
					59456: 37657,
					59457: 37666,
					59458: 37658,
					59459: 37667,
					59460: 37690,
					59461: 37685,
					59462: 37691,
					59463: 37724,
					59464: 37728,
					59465: 37756,
					59466: 37742,
					59467: 37718,
					59468: 37808,
					59469: 37804,
					59470: 37805,
					59471: 37780,
					59472: 37817,
					59473: 37846,
					59474: 37847,
					59475: 37864,
					59476: 37861,
					59477: 37848,
					59478: 37827,
					59479: 37853,
					59480: 37840,
					59481: 37832,
					59482: 37860,
					59483: 37914,
					59484: 37908,
					59485: 37907,
					59486: 37891,
					59487: 37895,
					59488: 37904,
					59489: 37942,
					59490: 37931,
					59491: 37941,
					59492: 37921,
					59493: 37946,
					59494: 37953,
					59495: 37970,
					59496: 37956,
					59497: 37979,
					59498: 37984,
					59499: 37986,
					59500: 37982,
					59501: 37994,
					59502: 37417,
					59503: 38e3,
					59504: 38005,
					59505: 38007,
					59506: 38013,
					59507: 37978,
					59508: 38012,
					59509: 38014,
					59510: 38017,
					59511: 38015,
					59512: 38274,
					59513: 38279,
					59514: 38282,
					59515: 38292,
					59516: 38294,
					59517: 38296,
					59518: 38297,
					59520: 38304,
					59521: 38312,
					59522: 38311,
					59523: 38317,
					59524: 38332,
					59525: 38331,
					59526: 38329,
					59527: 38334,
					59528: 38346,
					59529: 28662,
					59530: 38339,
					59531: 38349,
					59532: 38348,
					59533: 38357,
					59534: 38356,
					59535: 38358,
					59536: 38364,
					59537: 38369,
					59538: 38373,
					59539: 38370,
					59540: 38433,
					59541: 38440,
					59542: 38446,
					59543: 38447,
					59544: 38466,
					59545: 38476,
					59546: 38479,
					59547: 38475,
					59548: 38519,
					59549: 38492,
					59550: 38494,
					59551: 38493,
					59552: 38495,
					59553: 38502,
					59554: 38514,
					59555: 38508,
					59556: 38541,
					59557: 38552,
					59558: 38549,
					59559: 38551,
					59560: 38570,
					59561: 38567,
					59562: 38577,
					59563: 38578,
					59564: 38576,
					59565: 38580,
					59566: 38582,
					59567: 38584,
					59568: 38585,
					59569: 38606,
					59570: 38603,
					59571: 38601,
					59572: 38605,
					59573: 35149,
					59574: 38620,
					59575: 38669,
					59576: 38613,
					59577: 38649,
					59578: 38660,
					59579: 38662,
					59580: 38664,
					59581: 38675,
					59582: 38670,
					59583: 38673,
					59584: 38671,
					59585: 38678,
					59586: 38681,
					59587: 38692,
					59588: 38698,
					59589: 38704,
					59590: 38713,
					59591: 38717,
					59592: 38718,
					59593: 38724,
					59594: 38726,
					59595: 38728,
					59596: 38722,
					59597: 38729,
					59598: 38748,
					59599: 38752,
					59600: 38756,
					59601: 38758,
					59602: 38760,
					59603: 21202,
					59604: 38763,
					59605: 38769,
					59606: 38777,
					59607: 38789,
					59608: 38780,
					59609: 38785,
					59610: 38778,
					59611: 38790,
					59612: 38795,
					59613: 38799,
					59614: 38800,
					59615: 38812,
					59616: 38824,
					59617: 38822,
					59618: 38819,
					59619: 38835,
					59620: 38836,
					59621: 38851,
					59622: 38854,
					59623: 38856,
					59624: 38859,
					59625: 38876,
					59626: 38893,
					59627: 40783,
					59628: 38898,
					59629: 31455,
					59630: 38902,
					59631: 38901,
					59632: 38927,
					59633: 38924,
					59634: 38968,
					59635: 38948,
					59636: 38945,
					59637: 38967,
					59638: 38973,
					59639: 38982,
					59640: 38991,
					59641: 38987,
					59642: 39019,
					59643: 39023,
					59644: 39024,
					59712: 39025,
					59713: 39028,
					59714: 39027,
					59715: 39082,
					59716: 39087,
					59717: 39089,
					59718: 39094,
					59719: 39108,
					59720: 39107,
					59721: 39110,
					59722: 39145,
					59723: 39147,
					59724: 39171,
					59725: 39177,
					59726: 39186,
					59727: 39188,
					59728: 39192,
					59729: 39201,
					59730: 39197,
					59731: 39198,
					59732: 39204,
					59733: 39200,
					59734: 39212,
					59735: 39214,
					59736: 39229,
					59737: 39230,
					59738: 39234,
					59739: 39241,
					59740: 39237,
					59741: 39248,
					59742: 39243,
					59743: 39249,
					59744: 39250,
					59745: 39244,
					59746: 39253,
					59747: 39319,
					59748: 39320,
					59749: 39333,
					59750: 39341,
					59751: 39342,
					59752: 39356,
					59753: 39391,
					59754: 39387,
					59755: 39389,
					59756: 39384,
					59757: 39377,
					59758: 39405,
					59759: 39406,
					59760: 39409,
					59761: 39410,
					59762: 39419,
					59763: 39416,
					59764: 39425,
					59765: 39439,
					59766: 39429,
					59767: 39394,
					59768: 39449,
					59769: 39467,
					59770: 39479,
					59771: 39493,
					59772: 39490,
					59773: 39488,
					59774: 39491,
					59776: 39486,
					59777: 39509,
					59778: 39501,
					59779: 39515,
					59780: 39511,
					59781: 39519,
					59782: 39522,
					59783: 39525,
					59784: 39524,
					59785: 39529,
					59786: 39531,
					59787: 39530,
					59788: 39597,
					59789: 39600,
					59790: 39612,
					59791: 39616,
					59792: 39631,
					59793: 39633,
					59794: 39635,
					59795: 39636,
					59796: 39646,
					59797: 39647,
					59798: 39650,
					59799: 39651,
					59800: 39654,
					59801: 39663,
					59802: 39659,
					59803: 39662,
					59804: 39668,
					59805: 39665,
					59806: 39671,
					59807: 39675,
					59808: 39686,
					59809: 39704,
					59810: 39706,
					59811: 39711,
					59812: 39714,
					59813: 39715,
					59814: 39717,
					59815: 39719,
					59816: 39720,
					59817: 39721,
					59818: 39722,
					59819: 39726,
					59820: 39727,
					59821: 39730,
					59822: 39748,
					59823: 39747,
					59824: 39759,
					59825: 39757,
					59826: 39758,
					59827: 39761,
					59828: 39768,
					59829: 39796,
					59830: 39827,
					59831: 39811,
					59832: 39825,
					59833: 39830,
					59834: 39831,
					59835: 39839,
					59836: 39840,
					59837: 39848,
					59838: 39860,
					59839: 39872,
					59840: 39882,
					59841: 39865,
					59842: 39878,
					59843: 39887,
					59844: 39889,
					59845: 39890,
					59846: 39907,
					59847: 39906,
					59848: 39908,
					59849: 39892,
					59850: 39905,
					59851: 39994,
					59852: 39922,
					59853: 39921,
					59854: 39920,
					59855: 39957,
					59856: 39956,
					59857: 39945,
					59858: 39955,
					59859: 39948,
					59860: 39942,
					59861: 39944,
					59862: 39954,
					59863: 39946,
					59864: 39940,
					59865: 39982,
					59866: 39963,
					59867: 39973,
					59868: 39972,
					59869: 39969,
					59870: 39984,
					59871: 40007,
					59872: 39986,
					59873: 40006,
					59874: 39998,
					59875: 40026,
					59876: 40032,
					59877: 40039,
					59878: 40054,
					59879: 40056,
					59880: 40167,
					59881: 40172,
					59882: 40176,
					59883: 40201,
					59884: 40200,
					59885: 40171,
					59886: 40195,
					59887: 40198,
					59888: 40234,
					59889: 40230,
					59890: 40367,
					59891: 40227,
					59892: 40223,
					59893: 40260,
					59894: 40213,
					59895: 40210,
					59896: 40257,
					59897: 40255,
					59898: 40254,
					59899: 40262,
					59900: 40264,
					59968: 40285,
					59969: 40286,
					59970: 40292,
					59971: 40273,
					59972: 40272,
					59973: 40281,
					59974: 40306,
					59975: 40329,
					59976: 40327,
					59977: 40363,
					59978: 40303,
					59979: 40314,
					59980: 40346,
					59981: 40356,
					59982: 40361,
					59983: 40370,
					59984: 40388,
					59985: 40385,
					59986: 40379,
					59987: 40376,
					59988: 40378,
					59989: 40390,
					59990: 40399,
					59991: 40386,
					59992: 40409,
					59993: 40403,
					59994: 40440,
					59995: 40422,
					59996: 40429,
					59997: 40431,
					59998: 40445,
					59999: 40474,
					6e4: 40475,
					60001: 40478,
					60002: 40565,
					60003: 40569,
					60004: 40573,
					60005: 40577,
					60006: 40584,
					60007: 40587,
					60008: 40588,
					60009: 40594,
					60010: 40597,
					60011: 40593,
					60012: 40605,
					60013: 40613,
					60014: 40617,
					60015: 40632,
					60016: 40618,
					60017: 40621,
					60018: 38753,
					60019: 40652,
					60020: 40654,
					60021: 40655,
					60022: 40656,
					60023: 40660,
					60024: 40668,
					60025: 40670,
					60026: 40669,
					60027: 40672,
					60028: 40677,
					60029: 40680,
					60030: 40687,
					60032: 40692,
					60033: 40694,
					60034: 40695,
					60035: 40697,
					60036: 40699,
					60037: 40700,
					60038: 40701,
					60039: 40711,
					60040: 40712,
					60041: 30391,
					60042: 40725,
					60043: 40737,
					60044: 40748,
					60045: 40766,
					60046: 40778,
					60047: 40786,
					60048: 40788,
					60049: 40803,
					60050: 40799,
					60051: 40800,
					60052: 40801,
					60053: 40806,
					60054: 40807,
					60055: 40812,
					60056: 40810,
					60057: 40823,
					60058: 40818,
					60059: 40822,
					60060: 40853,
					60061: 40860,
					60062: 40864,
					60063: 22575,
					60064: 27079,
					60065: 36953,
					60066: 29796,
					60067: 20956,
					60068: 29081
				};
			}),
			(function(module$12, exports$11, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$11, "__esModule", { value: true });
				var GenericGF_1 = __webpack_require__(1);
				var GenericGFPoly_1 = __webpack_require__(2);
				function runEuclideanAlgorithm(field, a, b, R) {
					var _a;
					if (a.degree() < b.degree()) _a = [b, a], a = _a[0], b = _a[1];
					var rLast = a;
					var r = b;
					var tLast = field.zero;
					var t = field.one;
					while (r.degree() >= R / 2) {
						var rLastLast = rLast;
						var tLastLast = tLast;
						rLast = r;
						tLast = t;
						if (rLast.isZero()) return null;
						r = rLastLast;
						var q = field.zero;
						var denominatorLeadingTerm = rLast.getCoefficient(rLast.degree());
						var dltInverse = field.inverse(denominatorLeadingTerm);
						while (r.degree() >= rLast.degree() && !r.isZero()) {
							var degreeDiff = r.degree() - rLast.degree();
							var scale = field.multiply(r.getCoefficient(r.degree()), dltInverse);
							q = q.addOrSubtract(field.buildMonomial(degreeDiff, scale));
							r = r.addOrSubtract(rLast.multiplyByMonomial(degreeDiff, scale));
						}
						t = q.multiplyPoly(tLast).addOrSubtract(tLastLast);
						if (r.degree() >= rLast.degree()) return null;
					}
					var sigmaTildeAtZero = t.getCoefficient(0);
					if (sigmaTildeAtZero === 0) return null;
					var inverse = field.inverse(sigmaTildeAtZero);
					return [t.multiply(inverse), r.multiply(inverse)];
				}
				function findErrorLocations(field, errorLocator) {
					var numErrors = errorLocator.degree();
					if (numErrors === 1) return [errorLocator.getCoefficient(1)];
					var result = new Array(numErrors);
					var errorCount = 0;
					for (var i = 1; i < field.size && errorCount < numErrors; i++) if (errorLocator.evaluateAt(i) === 0) {
						result[errorCount] = field.inverse(i);
						errorCount++;
					}
					if (errorCount !== numErrors) return null;
					return result;
				}
				function findErrorMagnitudes(field, errorEvaluator, errorLocations) {
					var s = errorLocations.length;
					var result = new Array(s);
					for (var i = 0; i < s; i++) {
						var xiInverse = field.inverse(errorLocations[i]);
						var denominator = 1;
						for (var j = 0; j < s; j++) if (i !== j) denominator = field.multiply(denominator, GenericGF_1.addOrSubtractGF(1, field.multiply(errorLocations[j], xiInverse)));
						result[i] = field.multiply(errorEvaluator.evaluateAt(xiInverse), field.inverse(denominator));
						if (field.generatorBase !== 0) result[i] = field.multiply(result[i], xiInverse);
					}
					return result;
				}
				function decode(bytes, twoS) {
					var outputBytes = new Uint8ClampedArray(bytes.length);
					outputBytes.set(bytes);
					var field = new GenericGF_1.default(285, 256, 0);
					var poly = new GenericGFPoly_1.default(field, outputBytes);
					var syndromeCoefficients = new Uint8ClampedArray(twoS);
					var error = false;
					for (var s = 0; s < twoS; s++) {
						var evaluation = poly.evaluateAt(field.exp(s + field.generatorBase));
						syndromeCoefficients[syndromeCoefficients.length - 1 - s] = evaluation;
						if (evaluation !== 0) error = true;
					}
					if (!error) return outputBytes;
					var syndrome = new GenericGFPoly_1.default(field, syndromeCoefficients);
					var sigmaOmega = runEuclideanAlgorithm(field, field.buildMonomial(twoS, 1), syndrome, twoS);
					if (sigmaOmega === null) return null;
					var errorLocations = findErrorLocations(field, sigmaOmega[0]);
					if (errorLocations == null) return null;
					var errorMagnitudes = findErrorMagnitudes(field, sigmaOmega[1], errorLocations);
					for (var i = 0; i < errorLocations.length; i++) {
						var position = outputBytes.length - 1 - field.log(errorLocations[i]);
						if (position < 0) return null;
						outputBytes[position] = GenericGF_1.addOrSubtractGF(outputBytes[position], errorMagnitudes[i]);
					}
					return outputBytes;
				}
				exports$11.decode = decode;
			}),
			(function(module$13, exports$12, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$12, "__esModule", { value: true });
				exports$12.VERSIONS = [
					{
						infoBits: null,
						versionNumber: 1,
						alignmentPatternCenters: [],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 7,
								ecBlocks: [{
									numBlocks: 1,
									dataCodewordsPerBlock: 19
								}]
							},
							{
								ecCodewordsPerBlock: 10,
								ecBlocks: [{
									numBlocks: 1,
									dataCodewordsPerBlock: 16
								}]
							},
							{
								ecCodewordsPerBlock: 13,
								ecBlocks: [{
									numBlocks: 1,
									dataCodewordsPerBlock: 13
								}]
							},
							{
								ecCodewordsPerBlock: 17,
								ecBlocks: [{
									numBlocks: 1,
									dataCodewordsPerBlock: 9
								}]
							}
						]
					},
					{
						infoBits: null,
						versionNumber: 2,
						alignmentPatternCenters: [6, 18],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 10,
								ecBlocks: [{
									numBlocks: 1,
									dataCodewordsPerBlock: 34
								}]
							},
							{
								ecCodewordsPerBlock: 16,
								ecBlocks: [{
									numBlocks: 1,
									dataCodewordsPerBlock: 28
								}]
							},
							{
								ecCodewordsPerBlock: 22,
								ecBlocks: [{
									numBlocks: 1,
									dataCodewordsPerBlock: 22
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 1,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: null,
						versionNumber: 3,
						alignmentPatternCenters: [6, 22],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 15,
								ecBlocks: [{
									numBlocks: 1,
									dataCodewordsPerBlock: 55
								}]
							},
							{
								ecCodewordsPerBlock: 26,
								ecBlocks: [{
									numBlocks: 1,
									dataCodewordsPerBlock: 44
								}]
							},
							{
								ecCodewordsPerBlock: 18,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 17
								}]
							},
							{
								ecCodewordsPerBlock: 22,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 13
								}]
							}
						]
					},
					{
						infoBits: null,
						versionNumber: 4,
						alignmentPatternCenters: [6, 26],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 20,
								ecBlocks: [{
									numBlocks: 1,
									dataCodewordsPerBlock: 80
								}]
							},
							{
								ecCodewordsPerBlock: 18,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 32
								}]
							},
							{
								ecCodewordsPerBlock: 26,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 24
								}]
							},
							{
								ecCodewordsPerBlock: 16,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 9
								}]
							}
						]
					},
					{
						infoBits: null,
						versionNumber: 5,
						alignmentPatternCenters: [6, 30],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 26,
								ecBlocks: [{
									numBlocks: 1,
									dataCodewordsPerBlock: 108
								}]
							},
							{
								ecCodewordsPerBlock: 24,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 43
								}]
							},
							{
								ecCodewordsPerBlock: 18,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 2,
									dataCodewordsPerBlock: 16
								}]
							},
							{
								ecCodewordsPerBlock: 22,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 11
								}, {
									numBlocks: 2,
									dataCodewordsPerBlock: 12
								}]
							}
						]
					},
					{
						infoBits: null,
						versionNumber: 6,
						alignmentPatternCenters: [6, 34],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 18,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 68
								}]
							},
							{
								ecCodewordsPerBlock: 16,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 27
								}]
							},
							{
								ecCodewordsPerBlock: 24,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 19
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 15
								}]
							}
						]
					},
					{
						infoBits: 31892,
						versionNumber: 7,
						alignmentPatternCenters: [
							6,
							22,
							38
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 20,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 78
								}]
							},
							{
								ecCodewordsPerBlock: 18,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 31
								}]
							},
							{
								ecCodewordsPerBlock: 18,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 14
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 15
								}]
							},
							{
								ecCodewordsPerBlock: 26,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 13
								}, {
									numBlocks: 1,
									dataCodewordsPerBlock: 14
								}]
							}
						]
					},
					{
						infoBits: 34236,
						versionNumber: 8,
						alignmentPatternCenters: [
							6,
							24,
							42
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 24,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 97
								}]
							},
							{
								ecCodewordsPerBlock: 22,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 38
								}, {
									numBlocks: 2,
									dataCodewordsPerBlock: 39
								}]
							},
							{
								ecCodewordsPerBlock: 22,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 18
								}, {
									numBlocks: 2,
									dataCodewordsPerBlock: 19
								}]
							},
							{
								ecCodewordsPerBlock: 26,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 14
								}, {
									numBlocks: 2,
									dataCodewordsPerBlock: 15
								}]
							}
						]
					},
					{
						infoBits: 39577,
						versionNumber: 9,
						alignmentPatternCenters: [
							6,
							26,
							46
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 116
								}]
							},
							{
								ecCodewordsPerBlock: 22,
								ecBlocks: [{
									numBlocks: 3,
									dataCodewordsPerBlock: 36
								}, {
									numBlocks: 2,
									dataCodewordsPerBlock: 37
								}]
							},
							{
								ecCodewordsPerBlock: 20,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 16
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 17
								}]
							},
							{
								ecCodewordsPerBlock: 24,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 12
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 13
								}]
							}
						]
					},
					{
						infoBits: 42195,
						versionNumber: 10,
						alignmentPatternCenters: [
							6,
							28,
							50
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 18,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 68
								}, {
									numBlocks: 2,
									dataCodewordsPerBlock: 69
								}]
							},
							{
								ecCodewordsPerBlock: 26,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 43
								}, {
									numBlocks: 1,
									dataCodewordsPerBlock: 44
								}]
							},
							{
								ecCodewordsPerBlock: 24,
								ecBlocks: [{
									numBlocks: 6,
									dataCodewordsPerBlock: 19
								}, {
									numBlocks: 2,
									dataCodewordsPerBlock: 20
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 6,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 2,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 48118,
						versionNumber: 11,
						alignmentPatternCenters: [
							6,
							30,
							54
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 20,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 81
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 1,
									dataCodewordsPerBlock: 50
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 51
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 22
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 23
								}]
							},
							{
								ecCodewordsPerBlock: 24,
								ecBlocks: [{
									numBlocks: 3,
									dataCodewordsPerBlock: 12
								}, {
									numBlocks: 8,
									dataCodewordsPerBlock: 13
								}]
							}
						]
					},
					{
						infoBits: 51042,
						versionNumber: 12,
						alignmentPatternCenters: [
							6,
							32,
							58
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 24,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 92
								}, {
									numBlocks: 2,
									dataCodewordsPerBlock: 93
								}]
							},
							{
								ecCodewordsPerBlock: 22,
								ecBlocks: [{
									numBlocks: 6,
									dataCodewordsPerBlock: 36
								}, {
									numBlocks: 2,
									dataCodewordsPerBlock: 37
								}]
							},
							{
								ecCodewordsPerBlock: 26,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 20
								}, {
									numBlocks: 6,
									dataCodewordsPerBlock: 21
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 7,
									dataCodewordsPerBlock: 14
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 15
								}]
							}
						]
					},
					{
						infoBits: 55367,
						versionNumber: 13,
						alignmentPatternCenters: [
							6,
							34,
							62
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 26,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 107
								}]
							},
							{
								ecCodewordsPerBlock: 22,
								ecBlocks: [{
									numBlocks: 8,
									dataCodewordsPerBlock: 37
								}, {
									numBlocks: 1,
									dataCodewordsPerBlock: 38
								}]
							},
							{
								ecCodewordsPerBlock: 24,
								ecBlocks: [{
									numBlocks: 8,
									dataCodewordsPerBlock: 20
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 21
								}]
							},
							{
								ecCodewordsPerBlock: 22,
								ecBlocks: [{
									numBlocks: 12,
									dataCodewordsPerBlock: 11
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 12
								}]
							}
						]
					},
					{
						infoBits: 58893,
						versionNumber: 14,
						alignmentPatternCenters: [
							6,
							26,
							46,
							66
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 3,
									dataCodewordsPerBlock: 115
								}, {
									numBlocks: 1,
									dataCodewordsPerBlock: 116
								}]
							},
							{
								ecCodewordsPerBlock: 24,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 40
								}, {
									numBlocks: 5,
									dataCodewordsPerBlock: 41
								}]
							},
							{
								ecCodewordsPerBlock: 20,
								ecBlocks: [{
									numBlocks: 11,
									dataCodewordsPerBlock: 16
								}, {
									numBlocks: 5,
									dataCodewordsPerBlock: 17
								}]
							},
							{
								ecCodewordsPerBlock: 24,
								ecBlocks: [{
									numBlocks: 11,
									dataCodewordsPerBlock: 12
								}, {
									numBlocks: 5,
									dataCodewordsPerBlock: 13
								}]
							}
						]
					},
					{
						infoBits: 63784,
						versionNumber: 15,
						alignmentPatternCenters: [
							6,
							26,
							48,
							70
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 22,
								ecBlocks: [{
									numBlocks: 5,
									dataCodewordsPerBlock: 87
								}, {
									numBlocks: 1,
									dataCodewordsPerBlock: 88
								}]
							},
							{
								ecCodewordsPerBlock: 24,
								ecBlocks: [{
									numBlocks: 5,
									dataCodewordsPerBlock: 41
								}, {
									numBlocks: 5,
									dataCodewordsPerBlock: 42
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 5,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 7,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 24,
								ecBlocks: [{
									numBlocks: 11,
									dataCodewordsPerBlock: 12
								}, {
									numBlocks: 7,
									dataCodewordsPerBlock: 13
								}]
							}
						]
					},
					{
						infoBits: 68472,
						versionNumber: 16,
						alignmentPatternCenters: [
							6,
							26,
							50,
							74
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 24,
								ecBlocks: [{
									numBlocks: 5,
									dataCodewordsPerBlock: 98
								}, {
									numBlocks: 1,
									dataCodewordsPerBlock: 99
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 7,
									dataCodewordsPerBlock: 45
								}, {
									numBlocks: 3,
									dataCodewordsPerBlock: 46
								}]
							},
							{
								ecCodewordsPerBlock: 24,
								ecBlocks: [{
									numBlocks: 15,
									dataCodewordsPerBlock: 19
								}, {
									numBlocks: 2,
									dataCodewordsPerBlock: 20
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 3,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 13,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 70749,
						versionNumber: 17,
						alignmentPatternCenters: [
							6,
							30,
							54,
							78
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 1,
									dataCodewordsPerBlock: 107
								}, {
									numBlocks: 5,
									dataCodewordsPerBlock: 108
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 10,
									dataCodewordsPerBlock: 46
								}, {
									numBlocks: 1,
									dataCodewordsPerBlock: 47
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 1,
									dataCodewordsPerBlock: 22
								}, {
									numBlocks: 15,
									dataCodewordsPerBlock: 23
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 14
								}, {
									numBlocks: 17,
									dataCodewordsPerBlock: 15
								}]
							}
						]
					},
					{
						infoBits: 76311,
						versionNumber: 18,
						alignmentPatternCenters: [
							6,
							30,
							56,
							82
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 5,
									dataCodewordsPerBlock: 120
								}, {
									numBlocks: 1,
									dataCodewordsPerBlock: 121
								}]
							},
							{
								ecCodewordsPerBlock: 26,
								ecBlocks: [{
									numBlocks: 9,
									dataCodewordsPerBlock: 43
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 44
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 17,
									dataCodewordsPerBlock: 22
								}, {
									numBlocks: 1,
									dataCodewordsPerBlock: 23
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 14
								}, {
									numBlocks: 19,
									dataCodewordsPerBlock: 15
								}]
							}
						]
					},
					{
						infoBits: 79154,
						versionNumber: 19,
						alignmentPatternCenters: [
							6,
							30,
							58,
							86
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 3,
									dataCodewordsPerBlock: 113
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 114
								}]
							},
							{
								ecCodewordsPerBlock: 26,
								ecBlocks: [{
									numBlocks: 3,
									dataCodewordsPerBlock: 44
								}, {
									numBlocks: 11,
									dataCodewordsPerBlock: 45
								}]
							},
							{
								ecCodewordsPerBlock: 26,
								ecBlocks: [{
									numBlocks: 17,
									dataCodewordsPerBlock: 21
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 22
								}]
							},
							{
								ecCodewordsPerBlock: 26,
								ecBlocks: [{
									numBlocks: 9,
									dataCodewordsPerBlock: 13
								}, {
									numBlocks: 16,
									dataCodewordsPerBlock: 14
								}]
							}
						]
					},
					{
						infoBits: 84390,
						versionNumber: 20,
						alignmentPatternCenters: [
							6,
							34,
							62,
							90
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 3,
									dataCodewordsPerBlock: 107
								}, {
									numBlocks: 5,
									dataCodewordsPerBlock: 108
								}]
							},
							{
								ecCodewordsPerBlock: 26,
								ecBlocks: [{
									numBlocks: 3,
									dataCodewordsPerBlock: 41
								}, {
									numBlocks: 13,
									dataCodewordsPerBlock: 42
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 15,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 5,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 15,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 10,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 87683,
						versionNumber: 21,
						alignmentPatternCenters: [
							6,
							28,
							50,
							72,
							94
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 116
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 117
								}]
							},
							{
								ecCodewordsPerBlock: 26,
								ecBlocks: [{
									numBlocks: 17,
									dataCodewordsPerBlock: 42
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 17,
									dataCodewordsPerBlock: 22
								}, {
									numBlocks: 6,
									dataCodewordsPerBlock: 23
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 19,
									dataCodewordsPerBlock: 16
								}, {
									numBlocks: 6,
									dataCodewordsPerBlock: 17
								}]
							}
						]
					},
					{
						infoBits: 92361,
						versionNumber: 22,
						alignmentPatternCenters: [
							6,
							26,
							50,
							74,
							98
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 111
								}, {
									numBlocks: 7,
									dataCodewordsPerBlock: 112
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 17,
									dataCodewordsPerBlock: 46
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 7,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 16,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 24,
								ecBlocks: [{
									numBlocks: 34,
									dataCodewordsPerBlock: 13
								}]
							}
						]
					},
					{
						infoBits: 96236,
						versionNumber: 23,
						alignmentPatternCenters: [
							6,
							30,
							54,
							74,
							102
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 121
								}, {
									numBlocks: 5,
									dataCodewordsPerBlock: 122
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 47
								}, {
									numBlocks: 14,
									dataCodewordsPerBlock: 48
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 11,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 14,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 16,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 14,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 102084,
						versionNumber: 24,
						alignmentPatternCenters: [
							6,
							28,
							54,
							80,
							106
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 6,
									dataCodewordsPerBlock: 117
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 118
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 6,
									dataCodewordsPerBlock: 45
								}, {
									numBlocks: 14,
									dataCodewordsPerBlock: 46
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 11,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 16,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 30,
									dataCodewordsPerBlock: 16
								}, {
									numBlocks: 2,
									dataCodewordsPerBlock: 17
								}]
							}
						]
					},
					{
						infoBits: 102881,
						versionNumber: 25,
						alignmentPatternCenters: [
							6,
							32,
							58,
							84,
							110
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 26,
								ecBlocks: [{
									numBlocks: 8,
									dataCodewordsPerBlock: 106
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 107
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 8,
									dataCodewordsPerBlock: 47
								}, {
									numBlocks: 13,
									dataCodewordsPerBlock: 48
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 7,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 22,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 22,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 13,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 110507,
						versionNumber: 26,
						alignmentPatternCenters: [
							6,
							30,
							58,
							86,
							114
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 10,
									dataCodewordsPerBlock: 114
								}, {
									numBlocks: 2,
									dataCodewordsPerBlock: 115
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 19,
									dataCodewordsPerBlock: 46
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 47
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 28,
									dataCodewordsPerBlock: 22
								}, {
									numBlocks: 6,
									dataCodewordsPerBlock: 23
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 33,
									dataCodewordsPerBlock: 16
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 17
								}]
							}
						]
					},
					{
						infoBits: 110734,
						versionNumber: 27,
						alignmentPatternCenters: [
							6,
							34,
							62,
							90,
							118
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 8,
									dataCodewordsPerBlock: 122
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 123
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 22,
									dataCodewordsPerBlock: 45
								}, {
									numBlocks: 3,
									dataCodewordsPerBlock: 46
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 8,
									dataCodewordsPerBlock: 23
								}, {
									numBlocks: 26,
									dataCodewordsPerBlock: 24
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 12,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 28,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 117786,
						versionNumber: 28,
						alignmentPatternCenters: [
							6,
							26,
							50,
							74,
							98,
							122
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 3,
									dataCodewordsPerBlock: 117
								}, {
									numBlocks: 10,
									dataCodewordsPerBlock: 118
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 3,
									dataCodewordsPerBlock: 45
								}, {
									numBlocks: 23,
									dataCodewordsPerBlock: 46
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 31,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 11,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 31,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 119615,
						versionNumber: 29,
						alignmentPatternCenters: [
							6,
							30,
							54,
							78,
							102,
							126
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 7,
									dataCodewordsPerBlock: 116
								}, {
									numBlocks: 7,
									dataCodewordsPerBlock: 117
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 21,
									dataCodewordsPerBlock: 45
								}, {
									numBlocks: 7,
									dataCodewordsPerBlock: 46
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 1,
									dataCodewordsPerBlock: 23
								}, {
									numBlocks: 37,
									dataCodewordsPerBlock: 24
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 19,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 26,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 126325,
						versionNumber: 30,
						alignmentPatternCenters: [
							6,
							26,
							52,
							78,
							104,
							130
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 5,
									dataCodewordsPerBlock: 115
								}, {
									numBlocks: 10,
									dataCodewordsPerBlock: 116
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 19,
									dataCodewordsPerBlock: 47
								}, {
									numBlocks: 10,
									dataCodewordsPerBlock: 48
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 15,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 25,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 23,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 25,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 127568,
						versionNumber: 31,
						alignmentPatternCenters: [
							6,
							30,
							56,
							82,
							108,
							134
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 13,
									dataCodewordsPerBlock: 115
								}, {
									numBlocks: 3,
									dataCodewordsPerBlock: 116
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 46
								}, {
									numBlocks: 29,
									dataCodewordsPerBlock: 47
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 42,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 1,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 23,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 28,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 133589,
						versionNumber: 32,
						alignmentPatternCenters: [
							6,
							34,
							60,
							86,
							112,
							138
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 17,
									dataCodewordsPerBlock: 115
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 10,
									dataCodewordsPerBlock: 46
								}, {
									numBlocks: 23,
									dataCodewordsPerBlock: 47
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 10,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 35,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 19,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 35,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 136944,
						versionNumber: 33,
						alignmentPatternCenters: [
							6,
							30,
							58,
							86,
							114,
							142
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 17,
									dataCodewordsPerBlock: 115
								}, {
									numBlocks: 1,
									dataCodewordsPerBlock: 116
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 14,
									dataCodewordsPerBlock: 46
								}, {
									numBlocks: 21,
									dataCodewordsPerBlock: 47
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 29,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 19,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 11,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 46,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 141498,
						versionNumber: 34,
						alignmentPatternCenters: [
							6,
							34,
							62,
							90,
							118,
							146
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 13,
									dataCodewordsPerBlock: 115
								}, {
									numBlocks: 6,
									dataCodewordsPerBlock: 116
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 14,
									dataCodewordsPerBlock: 46
								}, {
									numBlocks: 23,
									dataCodewordsPerBlock: 47
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 44,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 7,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 59,
									dataCodewordsPerBlock: 16
								}, {
									numBlocks: 1,
									dataCodewordsPerBlock: 17
								}]
							}
						]
					},
					{
						infoBits: 145311,
						versionNumber: 35,
						alignmentPatternCenters: [
							6,
							30,
							54,
							78,
							102,
							126,
							150
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 12,
									dataCodewordsPerBlock: 121
								}, {
									numBlocks: 7,
									dataCodewordsPerBlock: 122
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 12,
									dataCodewordsPerBlock: 47
								}, {
									numBlocks: 26,
									dataCodewordsPerBlock: 48
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 39,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 14,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 22,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 41,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 150283,
						versionNumber: 36,
						alignmentPatternCenters: [
							6,
							24,
							50,
							76,
							102,
							128,
							154
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 6,
									dataCodewordsPerBlock: 121
								}, {
									numBlocks: 14,
									dataCodewordsPerBlock: 122
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 6,
									dataCodewordsPerBlock: 47
								}, {
									numBlocks: 34,
									dataCodewordsPerBlock: 48
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 46,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 10,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 2,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 64,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 152622,
						versionNumber: 37,
						alignmentPatternCenters: [
							6,
							28,
							54,
							80,
							106,
							132,
							158
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 17,
									dataCodewordsPerBlock: 122
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 123
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 29,
									dataCodewordsPerBlock: 46
								}, {
									numBlocks: 14,
									dataCodewordsPerBlock: 47
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 49,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 10,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 24,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 46,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 158308,
						versionNumber: 38,
						alignmentPatternCenters: [
							6,
							32,
							58,
							84,
							110,
							136,
							162
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 4,
									dataCodewordsPerBlock: 122
								}, {
									numBlocks: 18,
									dataCodewordsPerBlock: 123
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 13,
									dataCodewordsPerBlock: 46
								}, {
									numBlocks: 32,
									dataCodewordsPerBlock: 47
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 48,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 14,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 42,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 32,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 161089,
						versionNumber: 39,
						alignmentPatternCenters: [
							6,
							26,
							54,
							82,
							110,
							138,
							166
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 20,
									dataCodewordsPerBlock: 117
								}, {
									numBlocks: 4,
									dataCodewordsPerBlock: 118
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 40,
									dataCodewordsPerBlock: 47
								}, {
									numBlocks: 7,
									dataCodewordsPerBlock: 48
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 43,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 22,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 10,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 67,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					},
					{
						infoBits: 167017,
						versionNumber: 40,
						alignmentPatternCenters: [
							6,
							30,
							58,
							86,
							114,
							142,
							170
						],
						errorCorrectionLevels: [
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 19,
									dataCodewordsPerBlock: 118
								}, {
									numBlocks: 6,
									dataCodewordsPerBlock: 119
								}]
							},
							{
								ecCodewordsPerBlock: 28,
								ecBlocks: [{
									numBlocks: 18,
									dataCodewordsPerBlock: 47
								}, {
									numBlocks: 31,
									dataCodewordsPerBlock: 48
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 34,
									dataCodewordsPerBlock: 24
								}, {
									numBlocks: 34,
									dataCodewordsPerBlock: 25
								}]
							},
							{
								ecCodewordsPerBlock: 30,
								ecBlocks: [{
									numBlocks: 20,
									dataCodewordsPerBlock: 15
								}, {
									numBlocks: 61,
									dataCodewordsPerBlock: 16
								}]
							}
						]
					}
				];
			}),
			(function(module$14, exports$13, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$13, "__esModule", { value: true });
				var BitMatrix_1 = __webpack_require__(0);
				function squareToQuadrilateral(p1, p2, p3, p4) {
					var dx3 = p1.x - p2.x + p3.x - p4.x;
					var dy3 = p1.y - p2.y + p3.y - p4.y;
					if (dx3 === 0 && dy3 === 0) return {
						a11: p2.x - p1.x,
						a12: p2.y - p1.y,
						a13: 0,
						a21: p3.x - p2.x,
						a22: p3.y - p2.y,
						a23: 0,
						a31: p1.x,
						a32: p1.y,
						a33: 1
					};
					else {
						var dx1 = p2.x - p3.x;
						var dx2 = p4.x - p3.x;
						var dy1 = p2.y - p3.y;
						var dy2 = p4.y - p3.y;
						var denominator = dx1 * dy2 - dx2 * dy1;
						var a13 = (dx3 * dy2 - dx2 * dy3) / denominator;
						var a23 = (dx1 * dy3 - dx3 * dy1) / denominator;
						return {
							a11: p2.x - p1.x + a13 * p2.x,
							a12: p2.y - p1.y + a13 * p2.y,
							a13,
							a21: p4.x - p1.x + a23 * p4.x,
							a22: p4.y - p1.y + a23 * p4.y,
							a23,
							a31: p1.x,
							a32: p1.y,
							a33: 1
						};
					}
				}
				function quadrilateralToSquare(p1, p2, p3, p4) {
					var sToQ = squareToQuadrilateral(p1, p2, p3, p4);
					return {
						a11: sToQ.a22 * sToQ.a33 - sToQ.a23 * sToQ.a32,
						a12: sToQ.a13 * sToQ.a32 - sToQ.a12 * sToQ.a33,
						a13: sToQ.a12 * sToQ.a23 - sToQ.a13 * sToQ.a22,
						a21: sToQ.a23 * sToQ.a31 - sToQ.a21 * sToQ.a33,
						a22: sToQ.a11 * sToQ.a33 - sToQ.a13 * sToQ.a31,
						a23: sToQ.a13 * sToQ.a21 - sToQ.a11 * sToQ.a23,
						a31: sToQ.a21 * sToQ.a32 - sToQ.a22 * sToQ.a31,
						a32: sToQ.a12 * sToQ.a31 - sToQ.a11 * sToQ.a32,
						a33: sToQ.a11 * sToQ.a22 - sToQ.a12 * sToQ.a21
					};
				}
				function times(a, b) {
					return {
						a11: a.a11 * b.a11 + a.a21 * b.a12 + a.a31 * b.a13,
						a12: a.a12 * b.a11 + a.a22 * b.a12 + a.a32 * b.a13,
						a13: a.a13 * b.a11 + a.a23 * b.a12 + a.a33 * b.a13,
						a21: a.a11 * b.a21 + a.a21 * b.a22 + a.a31 * b.a23,
						a22: a.a12 * b.a21 + a.a22 * b.a22 + a.a32 * b.a23,
						a23: a.a13 * b.a21 + a.a23 * b.a22 + a.a33 * b.a23,
						a31: a.a11 * b.a31 + a.a21 * b.a32 + a.a31 * b.a33,
						a32: a.a12 * b.a31 + a.a22 * b.a32 + a.a32 * b.a33,
						a33: a.a13 * b.a31 + a.a23 * b.a32 + a.a33 * b.a33
					};
				}
				function extract(image, location) {
					var qToS = quadrilateralToSquare({
						x: 3.5,
						y: 3.5
					}, {
						x: location.dimension - 3.5,
						y: 3.5
					}, {
						x: location.dimension - 6.5,
						y: location.dimension - 6.5
					}, {
						x: 3.5,
						y: location.dimension - 3.5
					});
					var transform = times(squareToQuadrilateral(location.topLeft, location.topRight, location.alignmentPattern, location.bottomLeft), qToS);
					var matrix = BitMatrix_1.BitMatrix.createEmpty(location.dimension, location.dimension);
					var mappingFunction = function(x, y) {
						var denominator = transform.a13 * x + transform.a23 * y + transform.a33;
						return {
							x: (transform.a11 * x + transform.a21 * y + transform.a31) / denominator,
							y: (transform.a12 * x + transform.a22 * y + transform.a32) / denominator
						};
					};
					for (var y = 0; y < location.dimension; y++) for (var x = 0; x < location.dimension; x++) {
						var sourcePixel = mappingFunction(x + .5, y + .5);
						matrix.set(x, y, image.get(Math.floor(sourcePixel.x), Math.floor(sourcePixel.y)));
					}
					return {
						matrix,
						mappingFunction
					};
				}
				exports$13.extract = extract;
			}),
			(function(module$15, exports$14, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$14, "__esModule", { value: true });
				var MAX_FINDERPATTERNS_TO_SEARCH = 4;
				var MIN_QUAD_RATIO = .5;
				var MAX_QUAD_RATIO = 1.5;
				var distance = function(a, b) {
					return Math.sqrt(Math.pow(b.x - a.x, 2) + Math.pow(b.y - a.y, 2));
				};
				function sum(values) {
					return values.reduce(function(a, b) {
						return a + b;
					});
				}
				function reorderFinderPatterns(pattern1, pattern2, pattern3) {
					var _a, _b, _c, _d;
					var oneTwoDistance = distance(pattern1, pattern2);
					var twoThreeDistance = distance(pattern2, pattern3);
					var oneThreeDistance = distance(pattern1, pattern3);
					var bottomLeft;
					var topLeft;
					var topRight;
					if (twoThreeDistance >= oneTwoDistance && twoThreeDistance >= oneThreeDistance) _a = [
						pattern2,
						pattern1,
						pattern3
					], bottomLeft = _a[0], topLeft = _a[1], topRight = _a[2];
					else if (oneThreeDistance >= twoThreeDistance && oneThreeDistance >= oneTwoDistance) _b = [
						pattern1,
						pattern2,
						pattern3
					], bottomLeft = _b[0], topLeft = _b[1], topRight = _b[2];
					else _c = [
						pattern1,
						pattern3,
						pattern2
					], bottomLeft = _c[0], topLeft = _c[1], topRight = _c[2];
					if ((topRight.x - topLeft.x) * (bottomLeft.y - topLeft.y) - (topRight.y - topLeft.y) * (bottomLeft.x - topLeft.x) < 0) _d = [topRight, bottomLeft], bottomLeft = _d[0], topRight = _d[1];
					return {
						bottomLeft,
						topLeft,
						topRight
					};
				}
				function computeDimension(topLeft, topRight, bottomLeft, matrix) {
					var moduleSize = (sum(countBlackWhiteRun(topLeft, bottomLeft, matrix, 5)) / 7 + sum(countBlackWhiteRun(topLeft, topRight, matrix, 5)) / 7 + sum(countBlackWhiteRun(bottomLeft, topLeft, matrix, 5)) / 7 + sum(countBlackWhiteRun(topRight, topLeft, matrix, 5)) / 7) / 4;
					if (moduleSize < 1) throw new Error("Invalid module size");
					var topDimension = Math.round(distance(topLeft, topRight) / moduleSize);
					var sideDimension = Math.round(distance(topLeft, bottomLeft) / moduleSize);
					var dimension = Math.floor((topDimension + sideDimension) / 2) + 7;
					switch (dimension % 4) {
						case 0:
							dimension++;
							break;
						case 2: dimension--;
					}
					return {
						dimension,
						moduleSize
					};
				}
				function countBlackWhiteRunTowardsPoint(origin, end, matrix, length) {
					var switchPoints = [{
						x: Math.floor(origin.x),
						y: Math.floor(origin.y)
					}];
					var steep = Math.abs(end.y - origin.y) > Math.abs(end.x - origin.x);
					var fromX;
					var fromY;
					var toX;
					var toY;
					if (steep) {
						fromX = Math.floor(origin.y);
						fromY = Math.floor(origin.x);
						toX = Math.floor(end.y);
						toY = Math.floor(end.x);
					} else {
						fromX = Math.floor(origin.x);
						fromY = Math.floor(origin.y);
						toX = Math.floor(end.x);
						toY = Math.floor(end.y);
					}
					var dx = Math.abs(toX - fromX);
					var dy = Math.abs(toY - fromY);
					var error = Math.floor(-dx / 2);
					var xStep = fromX < toX ? 1 : -1;
					var yStep = fromY < toY ? 1 : -1;
					var currentPixel = true;
					for (var x = fromX, y = fromY; x !== toX + xStep; x += xStep) {
						var realX = steep ? y : x;
						var realY = steep ? x : y;
						if (matrix.get(realX, realY) !== currentPixel) {
							currentPixel = !currentPixel;
							switchPoints.push({
								x: realX,
								y: realY
							});
							if (switchPoints.length === length + 1) break;
						}
						error += dy;
						if (error > 0) {
							if (y === toY) break;
							y += yStep;
							error -= dx;
						}
					}
					var distances = [];
					for (var i = 0; i < length; i++) if (switchPoints[i] && switchPoints[i + 1]) distances.push(distance(switchPoints[i], switchPoints[i + 1]));
					else distances.push(0);
					return distances;
				}
				function countBlackWhiteRun(origin, end, matrix, length) {
					var _a;
					var rise = end.y - origin.y;
					var run = end.x - origin.x;
					var towardsEnd = countBlackWhiteRunTowardsPoint(origin, end, matrix, Math.ceil(length / 2));
					var awayFromEnd = countBlackWhiteRunTowardsPoint(origin, {
						x: origin.x - run,
						y: origin.y - rise
					}, matrix, Math.ceil(length / 2));
					var middleValue = towardsEnd.shift() + awayFromEnd.shift() - 1;
					return (_a = awayFromEnd.concat(middleValue)).concat.apply(_a, towardsEnd);
				}
				function scoreBlackWhiteRun(sequence, ratios) {
					var averageSize = sum(sequence) / sum(ratios);
					var error = 0;
					ratios.forEach(function(ratio, i) {
						error += Math.pow(sequence[i] - ratio * averageSize, 2);
					});
					return {
						averageSize,
						error
					};
				}
				function scorePattern(point, ratios, matrix) {
					try {
						var horizontalRun = countBlackWhiteRun(point, {
							x: -1,
							y: point.y
						}, matrix, ratios.length);
						var verticalRun = countBlackWhiteRun(point, {
							x: point.x,
							y: -1
						}, matrix, ratios.length);
						var topLeftBottomRightRun = countBlackWhiteRun(point, {
							x: Math.max(0, point.x - point.y) - 1,
							y: Math.max(0, point.y - point.x) - 1
						}, matrix, ratios.length);
						var bottomLeftTopRightRun = countBlackWhiteRun(point, {
							x: Math.min(matrix.width, point.x + point.y) + 1,
							y: Math.min(matrix.height, point.y + point.x) + 1
						}, matrix, ratios.length);
						var horzError = scoreBlackWhiteRun(horizontalRun, ratios);
						var vertError = scoreBlackWhiteRun(verticalRun, ratios);
						var diagDownError = scoreBlackWhiteRun(topLeftBottomRightRun, ratios);
						var diagUpError = scoreBlackWhiteRun(bottomLeftTopRightRun, ratios);
						var ratioError = Math.sqrt(horzError.error * horzError.error + vertError.error * vertError.error + diagDownError.error * diagDownError.error + diagUpError.error * diagUpError.error);
						var avgSize = (horzError.averageSize + vertError.averageSize + diagDownError.averageSize + diagUpError.averageSize) / 4;
						return ratioError + (Math.pow(horzError.averageSize - avgSize, 2) + Math.pow(vertError.averageSize - avgSize, 2) + Math.pow(diagDownError.averageSize - avgSize, 2) + Math.pow(diagUpError.averageSize - avgSize, 2)) / avgSize;
					} catch (_a) {
						return Infinity;
					}
				}
				function recenterLocation(matrix, p) {
					var leftX = Math.round(p.x);
					while (matrix.get(leftX, Math.round(p.y))) leftX--;
					var rightX = Math.round(p.x);
					while (matrix.get(rightX, Math.round(p.y))) rightX++;
					var x = (leftX + rightX) / 2;
					var topY = Math.round(p.y);
					while (matrix.get(Math.round(x), topY)) topY--;
					var bottomY = Math.round(p.y);
					while (matrix.get(Math.round(x), bottomY)) bottomY++;
					return {
						x,
						y: (topY + bottomY) / 2
					};
				}
				function locate(matrix) {
					var finderPatternQuads = [];
					var activeFinderPatternQuads = [];
					var alignmentPatternQuads = [];
					var activeAlignmentPatternQuads = [];
					var _loop_1 = function(y) {
						var length_1 = 0;
						var lastBit = false;
						var scans = [
							0,
							0,
							0,
							0,
							0
						];
						var _loop_2 = function(x) {
							var v = matrix.get(x, y);
							if (v === lastBit) length_1++;
							else {
								scans = [
									scans[1],
									scans[2],
									scans[3],
									scans[4],
									length_1
								];
								length_1 = 1;
								lastBit = v;
								var averageFinderPatternBlocksize = sum(scans) / 7;
								var validFinderPattern = Math.abs(scans[0] - averageFinderPatternBlocksize) < averageFinderPatternBlocksize && Math.abs(scans[1] - averageFinderPatternBlocksize) < averageFinderPatternBlocksize && Math.abs(scans[2] - 3 * averageFinderPatternBlocksize) < 3 * averageFinderPatternBlocksize && Math.abs(scans[3] - averageFinderPatternBlocksize) < averageFinderPatternBlocksize && Math.abs(scans[4] - averageFinderPatternBlocksize) < averageFinderPatternBlocksize && !v;
								var averageAlignmentPatternBlocksize = sum(scans.slice(-3)) / 3;
								var validAlignmentPattern = Math.abs(scans[2] - averageAlignmentPatternBlocksize) < averageAlignmentPatternBlocksize && Math.abs(scans[3] - averageAlignmentPatternBlocksize) < averageAlignmentPatternBlocksize && Math.abs(scans[4] - averageAlignmentPatternBlocksize) < averageAlignmentPatternBlocksize && v;
								if (validFinderPattern) {
									var endX_1 = x - scans[3] - scans[4];
									var startX_1 = endX_1 - scans[2];
									var line = {
										startX: startX_1,
										endX: endX_1,
										y
									};
									var matchingQuads = activeFinderPatternQuads.filter(function(q) {
										return startX_1 >= q.bottom.startX && startX_1 <= q.bottom.endX || endX_1 >= q.bottom.startX && startX_1 <= q.bottom.endX || startX_1 <= q.bottom.startX && endX_1 >= q.bottom.endX && scans[2] / (q.bottom.endX - q.bottom.startX) < MAX_QUAD_RATIO && scans[2] / (q.bottom.endX - q.bottom.startX) > MIN_QUAD_RATIO;
									});
									if (matchingQuads.length > 0) matchingQuads[0].bottom = line;
									else activeFinderPatternQuads.push({
										top: line,
										bottom: line
									});
								}
								if (validAlignmentPattern) {
									var endX_2 = x - scans[4];
									var startX_2 = endX_2 - scans[3];
									var line = {
										startX: startX_2,
										y,
										endX: endX_2
									};
									var matchingQuads = activeAlignmentPatternQuads.filter(function(q) {
										return startX_2 >= q.bottom.startX && startX_2 <= q.bottom.endX || endX_2 >= q.bottom.startX && startX_2 <= q.bottom.endX || startX_2 <= q.bottom.startX && endX_2 >= q.bottom.endX && scans[2] / (q.bottom.endX - q.bottom.startX) < MAX_QUAD_RATIO && scans[2] / (q.bottom.endX - q.bottom.startX) > MIN_QUAD_RATIO;
									});
									if (matchingQuads.length > 0) matchingQuads[0].bottom = line;
									else activeAlignmentPatternQuads.push({
										top: line,
										bottom: line
									});
								}
							}
						};
						for (var x = -1; x <= matrix.width; x++) _loop_2(x);
						finderPatternQuads.push.apply(finderPatternQuads, activeFinderPatternQuads.filter(function(q) {
							return q.bottom.y !== y && q.bottom.y - q.top.y >= 2;
						}));
						activeFinderPatternQuads = activeFinderPatternQuads.filter(function(q) {
							return q.bottom.y === y;
						});
						alignmentPatternQuads.push.apply(alignmentPatternQuads, activeAlignmentPatternQuads.filter(function(q) {
							return q.bottom.y !== y;
						}));
						activeAlignmentPatternQuads = activeAlignmentPatternQuads.filter(function(q) {
							return q.bottom.y === y;
						});
					};
					for (var y = 0; y <= matrix.height; y++) _loop_1(y);
					finderPatternQuads.push.apply(finderPatternQuads, activeFinderPatternQuads.filter(function(q) {
						return q.bottom.y - q.top.y >= 2;
					}));
					alignmentPatternQuads.push.apply(alignmentPatternQuads, activeAlignmentPatternQuads);
					var finderPatternGroups = finderPatternQuads.filter(function(q) {
						return q.bottom.y - q.top.y >= 2;
					}).map(function(q) {
						var x = (q.top.startX + q.top.endX + q.bottom.startX + q.bottom.endX) / 4;
						var y = (q.top.y + q.bottom.y + 1) / 2;
						if (!matrix.get(Math.round(x), Math.round(y))) return;
						var lengths = [
							q.top.endX - q.top.startX,
							q.bottom.endX - q.bottom.startX,
							q.bottom.y - q.top.y + 1
						];
						var size = sum(lengths) / lengths.length;
						return {
							score: scorePattern({
								x: Math.round(x),
								y: Math.round(y)
							}, [
								1,
								1,
								3,
								1,
								1
							], matrix),
							x,
							y,
							size
						};
					}).filter(function(q) {
						return !!q;
					}).sort(function(a, b) {
						return a.score - b.score;
					}).map(function(point, i, finderPatterns) {
						if (i > MAX_FINDERPATTERNS_TO_SEARCH) return null;
						var otherPoints = finderPatterns.filter(function(p, ii) {
							return i !== ii;
						}).map(function(p) {
							return {
								x: p.x,
								y: p.y,
								score: p.score + Math.pow(p.size - point.size, 2) / point.size,
								size: p.size
							};
						}).sort(function(a, b) {
							return a.score - b.score;
						});
						if (otherPoints.length < 2) return null;
						var score = point.score + otherPoints[0].score + otherPoints[1].score;
						return {
							points: [point].concat(otherPoints.slice(0, 2)),
							score
						};
					}).filter(function(q) {
						return !!q;
					}).sort(function(a, b) {
						return a.score - b.score;
					});
					if (finderPatternGroups.length === 0) return null;
					var _a = reorderFinderPatterns(finderPatternGroups[0].points[0], finderPatternGroups[0].points[1], finderPatternGroups[0].points[2]), topRight = _a.topRight, topLeft = _a.topLeft, bottomLeft = _a.bottomLeft;
					var alignment = findAlignmentPattern(matrix, alignmentPatternQuads, topRight, topLeft, bottomLeft);
					var result = [];
					if (alignment) result.push({
						alignmentPattern: {
							x: alignment.alignmentPattern.x,
							y: alignment.alignmentPattern.y
						},
						bottomLeft: {
							x: bottomLeft.x,
							y: bottomLeft.y
						},
						dimension: alignment.dimension,
						topLeft: {
							x: topLeft.x,
							y: topLeft.y
						},
						topRight: {
							x: topRight.x,
							y: topRight.y
						}
					});
					var midTopRight = recenterLocation(matrix, topRight);
					var midTopLeft = recenterLocation(matrix, topLeft);
					var midBottomLeft = recenterLocation(matrix, bottomLeft);
					var centeredAlignment = findAlignmentPattern(matrix, alignmentPatternQuads, midTopRight, midTopLeft, midBottomLeft);
					if (centeredAlignment) result.push({
						alignmentPattern: {
							x: centeredAlignment.alignmentPattern.x,
							y: centeredAlignment.alignmentPattern.y
						},
						bottomLeft: {
							x: midBottomLeft.x,
							y: midBottomLeft.y
						},
						topLeft: {
							x: midTopLeft.x,
							y: midTopLeft.y
						},
						topRight: {
							x: midTopRight.x,
							y: midTopRight.y
						},
						dimension: centeredAlignment.dimension
					});
					if (result.length === 0) return null;
					return result;
				}
				exports$14.locate = locate;
				function findAlignmentPattern(matrix, alignmentPatternQuads, topRight, topLeft, bottomLeft) {
					var _a;
					var dimension;
					var moduleSize;
					try {
						_a = computeDimension(topLeft, topRight, bottomLeft, matrix), dimension = _a.dimension, moduleSize = _a.moduleSize;
					} catch (e) {
						return null;
					}
					var bottomRightFinderPattern = {
						x: topRight.x - topLeft.x + bottomLeft.x,
						y: topRight.y - topLeft.y + bottomLeft.y
					};
					var modulesBetweenFinderPatterns = (distance(topLeft, bottomLeft) + distance(topLeft, topRight)) / 2 / moduleSize;
					var correctionToTopLeft = 1 - 3 / modulesBetweenFinderPatterns;
					var expectedAlignmentPattern = {
						x: topLeft.x + correctionToTopLeft * (bottomRightFinderPattern.x - topLeft.x),
						y: topLeft.y + correctionToTopLeft * (bottomRightFinderPattern.y - topLeft.y)
					};
					var alignmentPatterns = alignmentPatternQuads.map(function(q) {
						var x = (q.top.startX + q.top.endX + q.bottom.startX + q.bottom.endX) / 4;
						var y = (q.top.y + q.bottom.y + 1) / 2;
						if (!matrix.get(Math.floor(x), Math.floor(y))) return;
						var lengths = [
							q.top.endX - q.top.startX,
							q.bottom.endX - q.bottom.startX,
							q.bottom.y - q.top.y + 1
						];
						sum(lengths) / lengths.length;
						return {
							x,
							y,
							score: scorePattern({
								x: Math.floor(x),
								y: Math.floor(y)
							}, [
								1,
								1,
								1
							], matrix) + distance({
								x,
								y
							}, expectedAlignmentPattern)
						};
					}).filter(function(v) {
						return !!v;
					}).sort(function(a, b) {
						return a.score - b.score;
					});
					return {
						alignmentPattern: modulesBetweenFinderPatterns >= 15 && alignmentPatterns.length ? alignmentPatterns[0] : expectedAlignmentPattern,
						dimension
					};
				}
			})
		])["default"];
	});
}));
//#endregion
export default require_jsQR();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoianNxci5qcyIsIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydHMiXSwic291cmNlcyI6WyIuLi8uLi9qc3FyL2Rpc3QvanNRUi5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gd2VicGFja1VuaXZlcnNhbE1vZHVsZURlZmluaXRpb24ocm9vdCwgZmFjdG9yeSkge1xuXHRpZih0eXBlb2YgZXhwb3J0cyA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIG1vZHVsZSA9PT0gJ29iamVjdCcpXG5cdFx0bW9kdWxlLmV4cG9ydHMgPSBmYWN0b3J5KCk7XG5cdGVsc2UgaWYodHlwZW9mIGRlZmluZSA9PT0gJ2Z1bmN0aW9uJyAmJiBkZWZpbmUuYW1kKVxuXHRcdGRlZmluZShbXSwgZmFjdG9yeSk7XG5cdGVsc2UgaWYodHlwZW9mIGV4cG9ydHMgPT09ICdvYmplY3QnKVxuXHRcdGV4cG9ydHNbXCJqc1FSXCJdID0gZmFjdG9yeSgpO1xuXHRlbHNlXG5cdFx0cm9vdFtcImpzUVJcIl0gPSBmYWN0b3J5KCk7XG59KSh0eXBlb2Ygc2VsZiAhPT0gJ3VuZGVmaW5lZCcgPyBzZWxmIDogdGhpcywgZnVuY3Rpb24oKSB7XG5yZXR1cm4gLyoqKioqKi8gKGZ1bmN0aW9uKG1vZHVsZXMpIHsgLy8gd2VicGFja0Jvb3RzdHJhcFxuLyoqKioqKi8gXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4vKioqKioqLyBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0ge307XG4vKioqKioqL1xuLyoqKioqKi8gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuLyoqKioqKi8gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG4vKioqKioqL1xuLyoqKioqKi8gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuLyoqKioqKi8gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4vKioqKioqLyBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbi8qKioqKiovIFx0XHR9XG4vKioqKioqLyBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbi8qKioqKiovIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4vKioqKioqLyBcdFx0XHRpOiBtb2R1bGVJZCxcbi8qKioqKiovIFx0XHRcdGw6IGZhbHNlLFxuLyoqKioqKi8gXHRcdFx0ZXhwb3J0czoge31cbi8qKioqKiovIFx0XHR9O1xuLyoqKioqKi9cbi8qKioqKiovIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbi8qKioqKiovIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcbi8qKioqKiovXG4vKioqKioqLyBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuLyoqKioqKi8gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcbi8qKioqKiovXG4vKioqKioqLyBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbi8qKioqKiovIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4vKioqKioqLyBcdH1cbi8qKioqKiovXG4vKioqKioqL1xuLyoqKioqKi8gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuLyoqKioqKi8gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuLyoqKioqKi9cbi8qKioqKiovIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbi8qKioqKiovIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcbi8qKioqKiovXG4vKioqKioqLyBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuLyoqKioqKi8gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbi8qKioqKiovIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4vKioqKioqLyBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwge1xuLyoqKioqKi8gXHRcdFx0XHRjb25maWd1cmFibGU6IGZhbHNlLFxuLyoqKioqKi8gXHRcdFx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuLyoqKioqKi8gXHRcdFx0XHRnZXQ6IGdldHRlclxuLyoqKioqKi8gXHRcdFx0fSk7XG4vKioqKioqLyBcdFx0fVxuLyoqKioqKi8gXHR9O1xuLyoqKioqKi9cbi8qKioqKiovIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbi8qKioqKiovIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4vKioqKioqLyBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4vKioqKioqLyBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuLyoqKioqKi8gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbi8qKioqKiovIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4vKioqKioqLyBcdFx0cmV0dXJuIGdldHRlcjtcbi8qKioqKiovIFx0fTtcbi8qKioqKiovXG4vKioqKioqLyBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuLyoqKioqKi8gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG4vKioqKioqL1xuLyoqKioqKi8gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuLyoqKioqKi8gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuLyoqKioqKi9cbi8qKioqKiovIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4vKioqKioqLyBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IDMpO1xuLyoqKioqKi8gfSlcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKioqKioqLyAoW1xuLyogMCAqL1xuLyoqKi8gKGZ1bmN0aW9uKG1vZHVsZSwgZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXykge1xuXG5cInVzZSBzdHJpY3RcIjtcblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xudmFyIEJpdE1hdHJpeCA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBCaXRNYXRyaXgoZGF0YSwgd2lkdGgpIHtcbiAgICAgICAgdGhpcy53aWR0aCA9IHdpZHRoO1xuICAgICAgICB0aGlzLmhlaWdodCA9IGRhdGEubGVuZ3RoIC8gd2lkdGg7XG4gICAgICAgIHRoaXMuZGF0YSA9IGRhdGE7XG4gICAgfVxuICAgIEJpdE1hdHJpeC5jcmVhdGVFbXB0eSA9IGZ1bmN0aW9uICh3aWR0aCwgaGVpZ2h0KSB7XG4gICAgICAgIHJldHVybiBuZXcgQml0TWF0cml4KG5ldyBVaW50OENsYW1wZWRBcnJheSh3aWR0aCAqIGhlaWdodCksIHdpZHRoKTtcbiAgICB9O1xuICAgIEJpdE1hdHJpeC5wcm90b3R5cGUuZ2V0ID0gZnVuY3Rpb24gKHgsIHkpIHtcbiAgICAgICAgaWYgKHggPCAwIHx8IHggPj0gdGhpcy53aWR0aCB8fCB5IDwgMCB8fCB5ID49IHRoaXMuaGVpZ2h0KSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuICEhdGhpcy5kYXRhW3kgKiB0aGlzLndpZHRoICsgeF07XG4gICAgfTtcbiAgICBCaXRNYXRyaXgucHJvdG90eXBlLnNldCA9IGZ1bmN0aW9uICh4LCB5LCB2KSB7XG4gICAgICAgIHRoaXMuZGF0YVt5ICogdGhpcy53aWR0aCArIHhdID0gdiA/IDEgOiAwO1xuICAgIH07XG4gICAgQml0TWF0cml4LnByb3RvdHlwZS5zZXRSZWdpb24gPSBmdW5jdGlvbiAobGVmdCwgdG9wLCB3aWR0aCwgaGVpZ2h0LCB2KSB7XG4gICAgICAgIGZvciAodmFyIHkgPSB0b3A7IHkgPCB0b3AgKyBoZWlnaHQ7IHkrKykge1xuICAgICAgICAgICAgZm9yICh2YXIgeCA9IGxlZnQ7IHggPCBsZWZ0ICsgd2lkdGg7IHgrKykge1xuICAgICAgICAgICAgICAgIHRoaXMuc2V0KHgsIHksICEhdik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIHJldHVybiBCaXRNYXRyaXg7XG59KCkpO1xuZXhwb3J0cy5CaXRNYXRyaXggPSBCaXRNYXRyaXg7XG5cblxuLyoqKi8gfSksXG4vKiAxICovXG4vKioqLyAoZnVuY3Rpb24obW9kdWxlLCBleHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKSB7XG5cblwidXNlIHN0cmljdFwiO1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG52YXIgR2VuZXJpY0dGUG9seV8xID0gX193ZWJwYWNrX3JlcXVpcmVfXygyKTtcbmZ1bmN0aW9uIGFkZE9yU3VidHJhY3RHRihhLCBiKSB7XG4gICAgcmV0dXJuIGEgXiBiOyAvLyB0c2xpbnQ6ZGlzYWJsZS1saW5lOm5vLWJpdHdpc2Vcbn1cbmV4cG9ydHMuYWRkT3JTdWJ0cmFjdEdGID0gYWRkT3JTdWJ0cmFjdEdGO1xudmFyIEdlbmVyaWNHRiA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBHZW5lcmljR0YocHJpbWl0aXZlLCBzaXplLCBnZW5CYXNlKSB7XG4gICAgICAgIHRoaXMucHJpbWl0aXZlID0gcHJpbWl0aXZlO1xuICAgICAgICB0aGlzLnNpemUgPSBzaXplO1xuICAgICAgICB0aGlzLmdlbmVyYXRvckJhc2UgPSBnZW5CYXNlO1xuICAgICAgICB0aGlzLmV4cFRhYmxlID0gbmV3IEFycmF5KHRoaXMuc2l6ZSk7XG4gICAgICAgIHRoaXMubG9nVGFibGUgPSBuZXcgQXJyYXkodGhpcy5zaXplKTtcbiAgICAgICAgdmFyIHggPSAxO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuc2l6ZTsgaSsrKSB7XG4gICAgICAgICAgICB0aGlzLmV4cFRhYmxlW2ldID0geDtcbiAgICAgICAgICAgIHggPSB4ICogMjtcbiAgICAgICAgICAgIGlmICh4ID49IHRoaXMuc2l6ZSkge1xuICAgICAgICAgICAgICAgIHggPSAoeCBeIHRoaXMucHJpbWl0aXZlKSAmICh0aGlzLnNpemUgLSAxKTsgLy8gdHNsaW50OmRpc2FibGUtbGluZTpuby1iaXR3aXNlXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0aGlzLnNpemUgLSAxOyBpKyspIHtcbiAgICAgICAgICAgIHRoaXMubG9nVGFibGVbdGhpcy5leHBUYWJsZVtpXV0gPSBpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuemVybyA9IG5ldyBHZW5lcmljR0ZQb2x5XzEuZGVmYXVsdCh0aGlzLCBVaW50OENsYW1wZWRBcnJheS5mcm9tKFswXSkpO1xuICAgICAgICB0aGlzLm9uZSA9IG5ldyBHZW5lcmljR0ZQb2x5XzEuZGVmYXVsdCh0aGlzLCBVaW50OENsYW1wZWRBcnJheS5mcm9tKFsxXSkpO1xuICAgIH1cbiAgICBHZW5lcmljR0YucHJvdG90eXBlLm11bHRpcGx5ID0gZnVuY3Rpb24gKGEsIGIpIHtcbiAgICAgICAgaWYgKGEgPT09IDAgfHwgYiA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuZXhwVGFibGVbKHRoaXMubG9nVGFibGVbYV0gKyB0aGlzLmxvZ1RhYmxlW2JdKSAlICh0aGlzLnNpemUgLSAxKV07XG4gICAgfTtcbiAgICBHZW5lcmljR0YucHJvdG90eXBlLmludmVyc2UgPSBmdW5jdGlvbiAoYSkge1xuICAgICAgICBpZiAoYSA9PT0gMCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQ2FuJ3QgaW52ZXJ0IDBcIik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuZXhwVGFibGVbdGhpcy5zaXplIC0gdGhpcy5sb2dUYWJsZVthXSAtIDFdO1xuICAgIH07XG4gICAgR2VuZXJpY0dGLnByb3RvdHlwZS5idWlsZE1vbm9taWFsID0gZnVuY3Rpb24gKGRlZ3JlZSwgY29lZmZpY2llbnQpIHtcbiAgICAgICAgaWYgKGRlZ3JlZSA8IDApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgbW9ub21pYWwgZGVncmVlIGxlc3MgdGhhbiAwXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjb2VmZmljaWVudCA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuemVybztcbiAgICAgICAgfVxuICAgICAgICB2YXIgY29lZmZpY2llbnRzID0gbmV3IFVpbnQ4Q2xhbXBlZEFycmF5KGRlZ3JlZSArIDEpO1xuICAgICAgICBjb2VmZmljaWVudHNbMF0gPSBjb2VmZmljaWVudDtcbiAgICAgICAgcmV0dXJuIG5ldyBHZW5lcmljR0ZQb2x5XzEuZGVmYXVsdCh0aGlzLCBjb2VmZmljaWVudHMpO1xuICAgIH07XG4gICAgR2VuZXJpY0dGLnByb3RvdHlwZS5sb2cgPSBmdW5jdGlvbiAoYSkge1xuICAgICAgICBpZiAoYSA9PT0gMCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQ2FuJ3QgdGFrZSBsb2coMClcIik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMubG9nVGFibGVbYV07XG4gICAgfTtcbiAgICBHZW5lcmljR0YucHJvdG90eXBlLmV4cCA9IGZ1bmN0aW9uIChhKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmV4cFRhYmxlW2FdO1xuICAgIH07XG4gICAgcmV0dXJuIEdlbmVyaWNHRjtcbn0oKSk7XG5leHBvcnRzLmRlZmF1bHQgPSBHZW5lcmljR0Y7XG5cblxuLyoqKi8gfSksXG4vKiAyICovXG4vKioqLyAoZnVuY3Rpb24obW9kdWxlLCBleHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKSB7XG5cblwidXNlIHN0cmljdFwiO1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG52YXIgR2VuZXJpY0dGXzEgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKDEpO1xudmFyIEdlbmVyaWNHRlBvbHkgPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gR2VuZXJpY0dGUG9seShmaWVsZCwgY29lZmZpY2llbnRzKSB7XG4gICAgICAgIGlmIChjb2VmZmljaWVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBjb2VmZmljaWVudHMuXCIpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZmllbGQgPSBmaWVsZDtcbiAgICAgICAgdmFyIGNvZWZmaWNpZW50c0xlbmd0aCA9IGNvZWZmaWNpZW50cy5sZW5ndGg7XG4gICAgICAgIGlmIChjb2VmZmljaWVudHNMZW5ndGggPiAxICYmIGNvZWZmaWNpZW50c1swXSA9PT0gMCkge1xuICAgICAgICAgICAgLy8gTGVhZGluZyB0ZXJtIG11c3QgYmUgbm9uLXplcm8gZm9yIGFueXRoaW5nIGV4Y2VwdCB0aGUgY29uc3RhbnQgcG9seW5vbWlhbCBcIjBcIlxuICAgICAgICAgICAgdmFyIGZpcnN0Tm9uWmVybyA9IDE7XG4gICAgICAgICAgICB3aGlsZSAoZmlyc3ROb25aZXJvIDwgY29lZmZpY2llbnRzTGVuZ3RoICYmIGNvZWZmaWNpZW50c1tmaXJzdE5vblplcm9dID09PSAwKSB7XG4gICAgICAgICAgICAgICAgZmlyc3ROb25aZXJvKys7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoZmlyc3ROb25aZXJvID09PSBjb2VmZmljaWVudHNMZW5ndGgpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNvZWZmaWNpZW50cyA9IGZpZWxkLnplcm8uY29lZmZpY2llbnRzO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5jb2VmZmljaWVudHMgPSBuZXcgVWludDhDbGFtcGVkQXJyYXkoY29lZmZpY2llbnRzTGVuZ3RoIC0gZmlyc3ROb25aZXJvKTtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuY29lZmZpY2llbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY29lZmZpY2llbnRzW2ldID0gY29lZmZpY2llbnRzW2ZpcnN0Tm9uWmVybyArIGldO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuY29lZmZpY2llbnRzID0gY29lZmZpY2llbnRzO1xuICAgICAgICB9XG4gICAgfVxuICAgIEdlbmVyaWNHRlBvbHkucHJvdG90eXBlLmRlZ3JlZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY29lZmZpY2llbnRzLmxlbmd0aCAtIDE7XG4gICAgfTtcbiAgICBHZW5lcmljR0ZQb2x5LnByb3RvdHlwZS5pc1plcm8gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmNvZWZmaWNpZW50c1swXSA9PT0gMDtcbiAgICB9O1xuICAgIEdlbmVyaWNHRlBvbHkucHJvdG90eXBlLmdldENvZWZmaWNpZW50ID0gZnVuY3Rpb24gKGRlZ3JlZSkge1xuICAgICAgICByZXR1cm4gdGhpcy5jb2VmZmljaWVudHNbdGhpcy5jb2VmZmljaWVudHMubGVuZ3RoIC0gMSAtIGRlZ3JlZV07XG4gICAgfTtcbiAgICBHZW5lcmljR0ZQb2x5LnByb3RvdHlwZS5hZGRPclN1YnRyYWN0ID0gZnVuY3Rpb24gKG90aGVyKSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgaWYgKHRoaXMuaXNaZXJvKCkpIHtcbiAgICAgICAgICAgIHJldHVybiBvdGhlcjtcbiAgICAgICAgfVxuICAgICAgICBpZiAob3RoZXIuaXNaZXJvKCkpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG4gICAgICAgIHZhciBzbWFsbGVyQ29lZmZpY2llbnRzID0gdGhpcy5jb2VmZmljaWVudHM7XG4gICAgICAgIHZhciBsYXJnZXJDb2VmZmljaWVudHMgPSBvdGhlci5jb2VmZmljaWVudHM7XG4gICAgICAgIGlmIChzbWFsbGVyQ29lZmZpY2llbnRzLmxlbmd0aCA+IGxhcmdlckNvZWZmaWNpZW50cy5sZW5ndGgpIHtcbiAgICAgICAgICAgIF9hID0gW2xhcmdlckNvZWZmaWNpZW50cywgc21hbGxlckNvZWZmaWNpZW50c10sIHNtYWxsZXJDb2VmZmljaWVudHMgPSBfYVswXSwgbGFyZ2VyQ29lZmZpY2llbnRzID0gX2FbMV07XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHN1bURpZmYgPSBuZXcgVWludDhDbGFtcGVkQXJyYXkobGFyZ2VyQ29lZmZpY2llbnRzLmxlbmd0aCk7XG4gICAgICAgIHZhciBsZW5ndGhEaWZmID0gbGFyZ2VyQ29lZmZpY2llbnRzLmxlbmd0aCAtIHNtYWxsZXJDb2VmZmljaWVudHMubGVuZ3RoO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbmd0aERpZmY7IGkrKykge1xuICAgICAgICAgICAgc3VtRGlmZltpXSA9IGxhcmdlckNvZWZmaWNpZW50c1tpXTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKHZhciBpID0gbGVuZ3RoRGlmZjsgaSA8IGxhcmdlckNvZWZmaWNpZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgc3VtRGlmZltpXSA9IEdlbmVyaWNHRl8xLmFkZE9yU3VidHJhY3RHRihzbWFsbGVyQ29lZmZpY2llbnRzW2kgLSBsZW5ndGhEaWZmXSwgbGFyZ2VyQ29lZmZpY2llbnRzW2ldKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmV3IEdlbmVyaWNHRlBvbHkodGhpcy5maWVsZCwgc3VtRGlmZik7XG4gICAgfTtcbiAgICBHZW5lcmljR0ZQb2x5LnByb3RvdHlwZS5tdWx0aXBseSA9IGZ1bmN0aW9uIChzY2FsYXIpIHtcbiAgICAgICAgaWYgKHNjYWxhciA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZmllbGQuemVybztcbiAgICAgICAgfVxuICAgICAgICBpZiAoc2NhbGFyID09PSAxKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfVxuICAgICAgICB2YXIgc2l6ZSA9IHRoaXMuY29lZmZpY2llbnRzLmxlbmd0aDtcbiAgICAgICAgdmFyIHByb2R1Y3QgPSBuZXcgVWludDhDbGFtcGVkQXJyYXkoc2l6ZSk7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgc2l6ZTsgaSsrKSB7XG4gICAgICAgICAgICBwcm9kdWN0W2ldID0gdGhpcy5maWVsZC5tdWx0aXBseSh0aGlzLmNvZWZmaWNpZW50c1tpXSwgc2NhbGFyKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmV3IEdlbmVyaWNHRlBvbHkodGhpcy5maWVsZCwgcHJvZHVjdCk7XG4gICAgfTtcbiAgICBHZW5lcmljR0ZQb2x5LnByb3RvdHlwZS5tdWx0aXBseVBvbHkgPSBmdW5jdGlvbiAob3RoZXIpIHtcbiAgICAgICAgaWYgKHRoaXMuaXNaZXJvKCkgfHwgb3RoZXIuaXNaZXJvKCkpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmZpZWxkLnplcm87XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGFDb2VmZmljaWVudHMgPSB0aGlzLmNvZWZmaWNpZW50cztcbiAgICAgICAgdmFyIGFMZW5ndGggPSBhQ29lZmZpY2llbnRzLmxlbmd0aDtcbiAgICAgICAgdmFyIGJDb2VmZmljaWVudHMgPSBvdGhlci5jb2VmZmljaWVudHM7XG4gICAgICAgIHZhciBiTGVuZ3RoID0gYkNvZWZmaWNpZW50cy5sZW5ndGg7XG4gICAgICAgIHZhciBwcm9kdWN0ID0gbmV3IFVpbnQ4Q2xhbXBlZEFycmF5KGFMZW5ndGggKyBiTGVuZ3RoIC0gMSk7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYUxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgYUNvZWZmID0gYUNvZWZmaWNpZW50c1tpXTtcbiAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgYkxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICAgICAgcHJvZHVjdFtpICsgal0gPSBHZW5lcmljR0ZfMS5hZGRPclN1YnRyYWN0R0YocHJvZHVjdFtpICsgal0sIHRoaXMuZmllbGQubXVsdGlwbHkoYUNvZWZmLCBiQ29lZmZpY2llbnRzW2pdKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG5ldyBHZW5lcmljR0ZQb2x5KHRoaXMuZmllbGQsIHByb2R1Y3QpO1xuICAgIH07XG4gICAgR2VuZXJpY0dGUG9seS5wcm90b3R5cGUubXVsdGlwbHlCeU1vbm9taWFsID0gZnVuY3Rpb24gKGRlZ3JlZSwgY29lZmZpY2llbnQpIHtcbiAgICAgICAgaWYgKGRlZ3JlZSA8IDApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgZGVncmVlIGxlc3MgdGhhbiAwXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjb2VmZmljaWVudCA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZmllbGQuemVybztcbiAgICAgICAgfVxuICAgICAgICB2YXIgc2l6ZSA9IHRoaXMuY29lZmZpY2llbnRzLmxlbmd0aDtcbiAgICAgICAgdmFyIHByb2R1Y3QgPSBuZXcgVWludDhDbGFtcGVkQXJyYXkoc2l6ZSArIGRlZ3JlZSk7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgc2l6ZTsgaSsrKSB7XG4gICAgICAgICAgICBwcm9kdWN0W2ldID0gdGhpcy5maWVsZC5tdWx0aXBseSh0aGlzLmNvZWZmaWNpZW50c1tpXSwgY29lZmZpY2llbnQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBuZXcgR2VuZXJpY0dGUG9seSh0aGlzLmZpZWxkLCBwcm9kdWN0KTtcbiAgICB9O1xuICAgIEdlbmVyaWNHRlBvbHkucHJvdG90eXBlLmV2YWx1YXRlQXQgPSBmdW5jdGlvbiAoYSkge1xuICAgICAgICB2YXIgcmVzdWx0ID0gMDtcbiAgICAgICAgaWYgKGEgPT09IDApIHtcbiAgICAgICAgICAgIC8vIEp1c3QgcmV0dXJuIHRoZSB4XjAgY29lZmZpY2llbnRcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmdldENvZWZmaWNpZW50KDApO1xuICAgICAgICB9XG4gICAgICAgIHZhciBzaXplID0gdGhpcy5jb2VmZmljaWVudHMubGVuZ3RoO1xuICAgICAgICBpZiAoYSA9PT0gMSkge1xuICAgICAgICAgICAgLy8gSnVzdCB0aGUgc3VtIG9mIHRoZSBjb2VmZmljaWVudHNcbiAgICAgICAgICAgIHRoaXMuY29lZmZpY2llbnRzLmZvckVhY2goZnVuY3Rpb24gKGNvZWZmaWNpZW50KSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0ID0gR2VuZXJpY0dGXzEuYWRkT3JTdWJ0cmFjdEdGKHJlc3VsdCwgY29lZmZpY2llbnQpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9XG4gICAgICAgIHJlc3VsdCA9IHRoaXMuY29lZmZpY2llbnRzWzBdO1xuICAgICAgICBmb3IgKHZhciBpID0gMTsgaSA8IHNpemU7IGkrKykge1xuICAgICAgICAgICAgcmVzdWx0ID0gR2VuZXJpY0dGXzEuYWRkT3JTdWJ0cmFjdEdGKHRoaXMuZmllbGQubXVsdGlwbHkoYSwgcmVzdWx0KSwgdGhpcy5jb2VmZmljaWVudHNbaV0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfTtcbiAgICByZXR1cm4gR2VuZXJpY0dGUG9seTtcbn0oKSk7XG5leHBvcnRzLmRlZmF1bHQgPSBHZW5lcmljR0ZQb2x5O1xuXG5cbi8qKiovIH0pLFxuLyogMyAqL1xuLyoqKi8gKGZ1bmN0aW9uKG1vZHVsZSwgZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXykge1xuXG5cInVzZSBzdHJpY3RcIjtcblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xudmFyIGJpbmFyaXplcl8xID0gX193ZWJwYWNrX3JlcXVpcmVfXyg0KTtcbnZhciBkZWNvZGVyXzEgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKDUpO1xudmFyIGV4dHJhY3Rvcl8xID0gX193ZWJwYWNrX3JlcXVpcmVfXygxMSk7XG52YXIgbG9jYXRvcl8xID0gX193ZWJwYWNrX3JlcXVpcmVfXygxMik7XG5mdW5jdGlvbiBzY2FuKG1hdHJpeCkge1xuICAgIHZhciBsb2NhdGlvbnMgPSBsb2NhdG9yXzEubG9jYXRlKG1hdHJpeCk7XG4gICAgaWYgKCFsb2NhdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGZvciAodmFyIF9pID0gMCwgbG9jYXRpb25zXzEgPSBsb2NhdGlvbnM7IF9pIDwgbG9jYXRpb25zXzEubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgIHZhciBsb2NhdGlvbl8xID0gbG9jYXRpb25zXzFbX2ldO1xuICAgICAgICB2YXIgZXh0cmFjdGVkID0gZXh0cmFjdG9yXzEuZXh0cmFjdChtYXRyaXgsIGxvY2F0aW9uXzEpO1xuICAgICAgICB2YXIgZGVjb2RlZCA9IGRlY29kZXJfMS5kZWNvZGUoZXh0cmFjdGVkLm1hdHJpeCk7XG4gICAgICAgIGlmIChkZWNvZGVkKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIGJpbmFyeURhdGE6IGRlY29kZWQuYnl0ZXMsXG4gICAgICAgICAgICAgICAgZGF0YTogZGVjb2RlZC50ZXh0LFxuICAgICAgICAgICAgICAgIGNodW5rczogZGVjb2RlZC5jaHVua3MsXG4gICAgICAgICAgICAgICAgdmVyc2lvbjogZGVjb2RlZC52ZXJzaW9uLFxuICAgICAgICAgICAgICAgIGxvY2F0aW9uOiB7XG4gICAgICAgICAgICAgICAgICAgIHRvcFJpZ2h0Q29ybmVyOiBleHRyYWN0ZWQubWFwcGluZ0Z1bmN0aW9uKGxvY2F0aW9uXzEuZGltZW5zaW9uLCAwKSxcbiAgICAgICAgICAgICAgICAgICAgdG9wTGVmdENvcm5lcjogZXh0cmFjdGVkLm1hcHBpbmdGdW5jdGlvbigwLCAwKSxcbiAgICAgICAgICAgICAgICAgICAgYm90dG9tUmlnaHRDb3JuZXI6IGV4dHJhY3RlZC5tYXBwaW5nRnVuY3Rpb24obG9jYXRpb25fMS5kaW1lbnNpb24sIGxvY2F0aW9uXzEuZGltZW5zaW9uKSxcbiAgICAgICAgICAgICAgICAgICAgYm90dG9tTGVmdENvcm5lcjogZXh0cmFjdGVkLm1hcHBpbmdGdW5jdGlvbigwLCBsb2NhdGlvbl8xLmRpbWVuc2lvbiksXG4gICAgICAgICAgICAgICAgICAgIHRvcFJpZ2h0RmluZGVyUGF0dGVybjogbG9jYXRpb25fMS50b3BSaWdodCxcbiAgICAgICAgICAgICAgICAgICAgdG9wTGVmdEZpbmRlclBhdHRlcm46IGxvY2F0aW9uXzEudG9wTGVmdCxcbiAgICAgICAgICAgICAgICAgICAgYm90dG9tTGVmdEZpbmRlclBhdHRlcm46IGxvY2F0aW9uXzEuYm90dG9tTGVmdCxcbiAgICAgICAgICAgICAgICAgICAgYm90dG9tUmlnaHRBbGlnbm1lbnRQYXR0ZXJuOiBsb2NhdGlvbl8xLmFsaWdubWVudFBhdHRlcm4sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59XG52YXIgZGVmYXVsdE9wdGlvbnMgPSB7XG4gICAgaW52ZXJzaW9uQXR0ZW1wdHM6IFwiYXR0ZW1wdEJvdGhcIixcbn07XG5mdW5jdGlvbiBqc1FSKGRhdGEsIHdpZHRoLCBoZWlnaHQsIHByb3ZpZGVkT3B0aW9ucykge1xuICAgIGlmIChwcm92aWRlZE9wdGlvbnMgPT09IHZvaWQgMCkgeyBwcm92aWRlZE9wdGlvbnMgPSB7fTsgfVxuICAgIHZhciBvcHRpb25zID0gZGVmYXVsdE9wdGlvbnM7XG4gICAgT2JqZWN0LmtleXMob3B0aW9ucyB8fCB7fSkuZm9yRWFjaChmdW5jdGlvbiAob3B0KSB7XG4gICAgICAgIG9wdGlvbnNbb3B0XSA9IHByb3ZpZGVkT3B0aW9uc1tvcHRdIHx8IG9wdGlvbnNbb3B0XTtcbiAgICB9KTtcbiAgICB2YXIgc2hvdWxkSW52ZXJ0ID0gb3B0aW9ucy5pbnZlcnNpb25BdHRlbXB0cyA9PT0gXCJhdHRlbXB0Qm90aFwiIHx8IG9wdGlvbnMuaW52ZXJzaW9uQXR0ZW1wdHMgPT09IFwiaW52ZXJ0Rmlyc3RcIjtcbiAgICB2YXIgdHJ5SW52ZXJ0ZWRGaXJzdCA9IG9wdGlvbnMuaW52ZXJzaW9uQXR0ZW1wdHMgPT09IFwib25seUludmVydFwiIHx8IG9wdGlvbnMuaW52ZXJzaW9uQXR0ZW1wdHMgPT09IFwiaW52ZXJ0Rmlyc3RcIjtcbiAgICB2YXIgX2EgPSBiaW5hcml6ZXJfMS5iaW5hcml6ZShkYXRhLCB3aWR0aCwgaGVpZ2h0LCBzaG91bGRJbnZlcnQpLCBiaW5hcml6ZWQgPSBfYS5iaW5hcml6ZWQsIGludmVydGVkID0gX2EuaW52ZXJ0ZWQ7XG4gICAgdmFyIHJlc3VsdCA9IHNjYW4odHJ5SW52ZXJ0ZWRGaXJzdCA/IGludmVydGVkIDogYmluYXJpemVkKTtcbiAgICBpZiAoIXJlc3VsdCAmJiAob3B0aW9ucy5pbnZlcnNpb25BdHRlbXB0cyA9PT0gXCJhdHRlbXB0Qm90aFwiIHx8IG9wdGlvbnMuaW52ZXJzaW9uQXR0ZW1wdHMgPT09IFwiaW52ZXJ0Rmlyc3RcIikpIHtcbiAgICAgICAgcmVzdWx0ID0gc2Nhbih0cnlJbnZlcnRlZEZpcnN0ID8gYmluYXJpemVkIDogaW52ZXJ0ZWQpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuanNRUi5kZWZhdWx0ID0ganNRUjtcbmV4cG9ydHMuZGVmYXVsdCA9IGpzUVI7XG5cblxuLyoqKi8gfSksXG4vKiA0ICovXG4vKioqLyAoZnVuY3Rpb24obW9kdWxlLCBleHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKSB7XG5cblwidXNlIHN0cmljdFwiO1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG52YXIgQml0TWF0cml4XzEgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKDApO1xudmFyIFJFR0lPTl9TSVpFID0gODtcbnZhciBNSU5fRFlOQU1JQ19SQU5HRSA9IDI0O1xuZnVuY3Rpb24gbnVtQmV0d2Vlbih2YWx1ZSwgbWluLCBtYXgpIHtcbiAgICByZXR1cm4gdmFsdWUgPCBtaW4gPyBtaW4gOiB2YWx1ZSA+IG1heCA/IG1heCA6IHZhbHVlO1xufVxuLy8gTGlrZSBCaXRNYXRyaXggYnV0IGFjY2VwdHMgYXJiaXRyeSBVaW50OCB2YWx1ZXNcbnZhciBNYXRyaXggPSAvKiogQGNsYXNzICovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gTWF0cml4KHdpZHRoLCBoZWlnaHQpIHtcbiAgICAgICAgdGhpcy53aWR0aCA9IHdpZHRoO1xuICAgICAgICB0aGlzLmRhdGEgPSBuZXcgVWludDhDbGFtcGVkQXJyYXkod2lkdGggKiBoZWlnaHQpO1xuICAgIH1cbiAgICBNYXRyaXgucHJvdG90eXBlLmdldCA9IGZ1bmN0aW9uICh4LCB5KSB7XG4gICAgICAgIHJldHVybiB0aGlzLmRhdGFbeSAqIHRoaXMud2lkdGggKyB4XTtcbiAgICB9O1xuICAgIE1hdHJpeC5wcm90b3R5cGUuc2V0ID0gZnVuY3Rpb24gKHgsIHksIHZhbHVlKSB7XG4gICAgICAgIHRoaXMuZGF0YVt5ICogdGhpcy53aWR0aCArIHhdID0gdmFsdWU7XG4gICAgfTtcbiAgICByZXR1cm4gTWF0cml4O1xufSgpKTtcbmZ1bmN0aW9uIGJpbmFyaXplKGRhdGEsIHdpZHRoLCBoZWlnaHQsIHJldHVybkludmVydGVkKSB7XG4gICAgaWYgKGRhdGEubGVuZ3RoICE9PSB3aWR0aCAqIGhlaWdodCAqIDQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTWFsZm9ybWVkIGRhdGEgcGFzc2VkIHRvIGJpbmFyaXplci5cIik7XG4gICAgfVxuICAgIC8vIENvbnZlcnQgaW1hZ2UgdG8gZ3JleXNjYWxlXG4gICAgdmFyIGdyZXlzY2FsZVBpeGVscyA9IG5ldyBNYXRyaXgod2lkdGgsIGhlaWdodCk7XG4gICAgZm9yICh2YXIgeCA9IDA7IHggPCB3aWR0aDsgeCsrKSB7XG4gICAgICAgIGZvciAodmFyIHkgPSAwOyB5IDwgaGVpZ2h0OyB5KyspIHtcbiAgICAgICAgICAgIHZhciByID0gZGF0YVsoKHkgKiB3aWR0aCArIHgpICogNCkgKyAwXTtcbiAgICAgICAgICAgIHZhciBnID0gZGF0YVsoKHkgKiB3aWR0aCArIHgpICogNCkgKyAxXTtcbiAgICAgICAgICAgIHZhciBiID0gZGF0YVsoKHkgKiB3aWR0aCArIHgpICogNCkgKyAyXTtcbiAgICAgICAgICAgIGdyZXlzY2FsZVBpeGVscy5zZXQoeCwgeSwgMC4yMTI2ICogciArIDAuNzE1MiAqIGcgKyAwLjA3MjIgKiBiKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICB2YXIgaG9yaXpvbnRhbFJlZ2lvbkNvdW50ID0gTWF0aC5jZWlsKHdpZHRoIC8gUkVHSU9OX1NJWkUpO1xuICAgIHZhciB2ZXJ0aWNhbFJlZ2lvbkNvdW50ID0gTWF0aC5jZWlsKGhlaWdodCAvIFJFR0lPTl9TSVpFKTtcbiAgICB2YXIgYmxhY2tQb2ludHMgPSBuZXcgTWF0cml4KGhvcml6b250YWxSZWdpb25Db3VudCwgdmVydGljYWxSZWdpb25Db3VudCk7XG4gICAgZm9yICh2YXIgdmVydGljYWxSZWdpb24gPSAwOyB2ZXJ0aWNhbFJlZ2lvbiA8IHZlcnRpY2FsUmVnaW9uQ291bnQ7IHZlcnRpY2FsUmVnaW9uKyspIHtcbiAgICAgICAgZm9yICh2YXIgaG9ydGl6b250YWxSZWdpb24gPSAwOyBob3J0aXpvbnRhbFJlZ2lvbiA8IGhvcml6b250YWxSZWdpb25Db3VudDsgaG9ydGl6b250YWxSZWdpb24rKykge1xuICAgICAgICAgICAgdmFyIHN1bSA9IDA7XG4gICAgICAgICAgICB2YXIgbWluID0gSW5maW5pdHk7XG4gICAgICAgICAgICB2YXIgbWF4ID0gMDtcbiAgICAgICAgICAgIGZvciAodmFyIHkgPSAwOyB5IDwgUkVHSU9OX1NJWkU7IHkrKykge1xuICAgICAgICAgICAgICAgIGZvciAodmFyIHggPSAwOyB4IDwgUkVHSU9OX1NJWkU7IHgrKykge1xuICAgICAgICAgICAgICAgICAgICB2YXIgcGl4ZWxMdW1vc2l0eSA9IGdyZXlzY2FsZVBpeGVscy5nZXQoaG9ydGl6b250YWxSZWdpb24gKiBSRUdJT05fU0laRSArIHgsIHZlcnRpY2FsUmVnaW9uICogUkVHSU9OX1NJWkUgKyB5KTtcbiAgICAgICAgICAgICAgICAgICAgc3VtICs9IHBpeGVsTHVtb3NpdHk7XG4gICAgICAgICAgICAgICAgICAgIG1pbiA9IE1hdGgubWluKG1pbiwgcGl4ZWxMdW1vc2l0eSk7XG4gICAgICAgICAgICAgICAgICAgIG1heCA9IE1hdGgubWF4KG1heCwgcGl4ZWxMdW1vc2l0eSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFyIGF2ZXJhZ2UgPSBzdW0gLyAoTWF0aC5wb3coUkVHSU9OX1NJWkUsIDIpKTtcbiAgICAgICAgICAgIGlmIChtYXggLSBtaW4gPD0gTUlOX0RZTkFNSUNfUkFOR0UpIHtcbiAgICAgICAgICAgICAgICAvLyBJZiB2YXJpYXRpb24gd2l0aGluIHRoZSBibG9jayBpcyBsb3csIGFzc3VtZSB0aGlzIGlzIGEgYmxvY2sgd2l0aCBvbmx5IGxpZ2h0IG9yIG9ubHlcbiAgICAgICAgICAgICAgICAvLyBkYXJrIHBpeGVscy4gSW4gdGhhdCBjYXNlIHdlIGRvIG5vdCB3YW50IHRvIHVzZSB0aGUgYXZlcmFnZSwgYXMgaXQgd291bGQgZGl2aWRlIHRoaXNcbiAgICAgICAgICAgICAgICAvLyBsb3cgY29udHJhc3QgYXJlYSBpbnRvIGJsYWNrIGFuZCB3aGl0ZSBwaXhlbHMsIGVzc2VudGlhbGx5IGNyZWF0aW5nIGRhdGEgb3V0IG9mIG5vaXNlLlxuICAgICAgICAgICAgICAgIC8vXG4gICAgICAgICAgICAgICAgLy8gRGVmYXVsdCB0aGUgYmxhY2twb2ludCBmb3IgdGhlc2UgYmxvY2tzIHRvIGJlIGhhbGYgdGhlIG1pbiAtIGVmZmVjdGl2ZWx5IHdoaXRlIHRoZW0gb3V0XG4gICAgICAgICAgICAgICAgYXZlcmFnZSA9IG1pbiAvIDI7XG4gICAgICAgICAgICAgICAgaWYgKHZlcnRpY2FsUmVnaW9uID4gMCAmJiBob3J0aXpvbnRhbFJlZ2lvbiA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gQ29ycmVjdCB0aGUgXCJ3aGl0ZSBiYWNrZ3JvdW5kXCIgYXNzdW1wdGlvbiBmb3IgYmxvY2tzIHRoYXQgaGF2ZSBuZWlnaGJvcnMgYnkgY29tcGFyaW5nXG4gICAgICAgICAgICAgICAgICAgIC8vIHRoZSBwaXhlbHMgaW4gdGhpcyBibG9jayB0byB0aGUgcHJldmlvdXNseSBjYWxjdWxhdGVkIGJsYWNrIHBvaW50cy4gVGhpcyBpcyBiYXNlZCBvblxuICAgICAgICAgICAgICAgICAgICAvLyB0aGUgZmFjdCB0aGF0IGRhcmsgYmFyY29kZSBzeW1ib2xvZ3kgaXMgYWx3YXlzIHN1cnJvdW5kZWQgYnkgc29tZSBhbW91bnQgb2YgbGlnaHRcbiAgICAgICAgICAgICAgICAgICAgLy8gYmFja2dyb3VuZCBmb3Igd2hpY2ggcmVhc29uYWJsZSBibGFjayBwb2ludCBlc3RpbWF0ZXMgd2VyZSBtYWRlLiBUaGUgYnAgZXN0aW1hdGVkIGF0XG4gICAgICAgICAgICAgICAgICAgIC8vIHRoZSBib3VuZGFyaWVzIGlzIHVzZWQgZm9yIHRoZSBpbnRlcmlvci5cbiAgICAgICAgICAgICAgICAgICAgLy8gVGhlIChtaW4gPCBicCkgaXMgYXJiaXRyYXJ5IGJ1dCB3b3JrcyBiZXR0ZXIgdGhhbiBvdGhlciBoZXVyaXN0aWNzIHRoYXQgd2VyZSB0cmllZC5cbiAgICAgICAgICAgICAgICAgICAgdmFyIGF2ZXJhZ2VOZWlnaGJvckJsYWNrUG9pbnQgPSAoYmxhY2tQb2ludHMuZ2V0KGhvcnRpem9udGFsUmVnaW9uLCB2ZXJ0aWNhbFJlZ2lvbiAtIDEpICtcbiAgICAgICAgICAgICAgICAgICAgICAgICgyICogYmxhY2tQb2ludHMuZ2V0KGhvcnRpem9udGFsUmVnaW9uIC0gMSwgdmVydGljYWxSZWdpb24pKSArXG4gICAgICAgICAgICAgICAgICAgICAgICBibGFja1BvaW50cy5nZXQoaG9ydGl6b250YWxSZWdpb24gLSAxLCB2ZXJ0aWNhbFJlZ2lvbiAtIDEpKSAvIDQ7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtaW4gPCBhdmVyYWdlTmVpZ2hib3JCbGFja1BvaW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhdmVyYWdlID0gYXZlcmFnZU5laWdoYm9yQmxhY2tQb2ludDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJsYWNrUG9pbnRzLnNldChob3J0aXpvbnRhbFJlZ2lvbiwgdmVydGljYWxSZWdpb24sIGF2ZXJhZ2UpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHZhciBiaW5hcml6ZWQgPSBCaXRNYXRyaXhfMS5CaXRNYXRyaXguY3JlYXRlRW1wdHkod2lkdGgsIGhlaWdodCk7XG4gICAgdmFyIGludmVydGVkID0gbnVsbDtcbiAgICBpZiAocmV0dXJuSW52ZXJ0ZWQpIHtcbiAgICAgICAgaW52ZXJ0ZWQgPSBCaXRNYXRyaXhfMS5CaXRNYXRyaXguY3JlYXRlRW1wdHkod2lkdGgsIGhlaWdodCk7XG4gICAgfVxuICAgIGZvciAodmFyIHZlcnRpY2FsUmVnaW9uID0gMDsgdmVydGljYWxSZWdpb24gPCB2ZXJ0aWNhbFJlZ2lvbkNvdW50OyB2ZXJ0aWNhbFJlZ2lvbisrKSB7XG4gICAgICAgIGZvciAodmFyIGhvcnRpem9udGFsUmVnaW9uID0gMDsgaG9ydGl6b250YWxSZWdpb24gPCBob3Jpem9udGFsUmVnaW9uQ291bnQ7IGhvcnRpem9udGFsUmVnaW9uKyspIHtcbiAgICAgICAgICAgIHZhciBsZWZ0ID0gbnVtQmV0d2Vlbihob3J0aXpvbnRhbFJlZ2lvbiwgMiwgaG9yaXpvbnRhbFJlZ2lvbkNvdW50IC0gMyk7XG4gICAgICAgICAgICB2YXIgdG9wXzEgPSBudW1CZXR3ZWVuKHZlcnRpY2FsUmVnaW9uLCAyLCB2ZXJ0aWNhbFJlZ2lvbkNvdW50IC0gMyk7XG4gICAgICAgICAgICB2YXIgc3VtID0gMDtcbiAgICAgICAgICAgIGZvciAodmFyIHhSZWdpb24gPSAtMjsgeFJlZ2lvbiA8PSAyOyB4UmVnaW9uKyspIHtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciB5UmVnaW9uID0gLTI7IHlSZWdpb24gPD0gMjsgeVJlZ2lvbisrKSB7XG4gICAgICAgICAgICAgICAgICAgIHN1bSArPSBibGFja1BvaW50cy5nZXQobGVmdCArIHhSZWdpb24sIHRvcF8xICsgeVJlZ2lvbik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFyIHRocmVzaG9sZCA9IHN1bSAvIDI1O1xuICAgICAgICAgICAgZm9yICh2YXIgeFJlZ2lvbiA9IDA7IHhSZWdpb24gPCBSRUdJT05fU0laRTsgeFJlZ2lvbisrKSB7XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgeVJlZ2lvbiA9IDA7IHlSZWdpb24gPCBSRUdJT05fU0laRTsgeVJlZ2lvbisrKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciB4ID0gaG9ydGl6b250YWxSZWdpb24gKiBSRUdJT05fU0laRSArIHhSZWdpb247XG4gICAgICAgICAgICAgICAgICAgIHZhciB5ID0gdmVydGljYWxSZWdpb24gKiBSRUdJT05fU0laRSArIHlSZWdpb247XG4gICAgICAgICAgICAgICAgICAgIHZhciBsdW0gPSBncmV5c2NhbGVQaXhlbHMuZ2V0KHgsIHkpO1xuICAgICAgICAgICAgICAgICAgICBiaW5hcml6ZWQuc2V0KHgsIHksIGx1bSA8PSB0aHJlc2hvbGQpO1xuICAgICAgICAgICAgICAgICAgICBpZiAocmV0dXJuSW52ZXJ0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGludmVydGVkLnNldCh4LCB5LCAhKGx1bSA8PSB0aHJlc2hvbGQpKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAocmV0dXJuSW52ZXJ0ZWQpIHtcbiAgICAgICAgcmV0dXJuIHsgYmluYXJpemVkOiBiaW5hcml6ZWQsIGludmVydGVkOiBpbnZlcnRlZCB9O1xuICAgIH1cbiAgICByZXR1cm4geyBiaW5hcml6ZWQ6IGJpbmFyaXplZCB9O1xufVxuZXhwb3J0cy5iaW5hcml6ZSA9IGJpbmFyaXplO1xuXG5cbi8qKiovIH0pLFxuLyogNSAqL1xuLyoqKi8gKGZ1bmN0aW9uKG1vZHVsZSwgZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXykge1xuXG5cInVzZSBzdHJpY3RcIjtcblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xudmFyIEJpdE1hdHJpeF8xID0gX193ZWJwYWNrX3JlcXVpcmVfXygwKTtcbnZhciBkZWNvZGVEYXRhXzEgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKDYpO1xudmFyIHJlZWRzb2xvbW9uXzEgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKDkpO1xudmFyIHZlcnNpb25fMSA9IF9fd2VicGFja19yZXF1aXJlX18oMTApO1xuLy8gdHNsaW50OmRpc2FibGU6bm8tYml0d2lzZVxuZnVuY3Rpb24gbnVtQml0c0RpZmZlcmluZyh4LCB5KSB7XG4gICAgdmFyIHogPSB4IF4geTtcbiAgICB2YXIgYml0Q291bnQgPSAwO1xuICAgIHdoaWxlICh6KSB7XG4gICAgICAgIGJpdENvdW50Kys7XG4gICAgICAgIHogJj0geiAtIDE7XG4gICAgfVxuICAgIHJldHVybiBiaXRDb3VudDtcbn1cbmZ1bmN0aW9uIHB1c2hCaXQoYml0LCBieXRlKSB7XG4gICAgcmV0dXJuIChieXRlIDw8IDEpIHwgYml0O1xufVxuLy8gdHNsaW50OmVuYWJsZTpuby1iaXR3aXNlXG52YXIgRk9STUFUX0lORk9fVEFCTEUgPSBbXG4gICAgeyBiaXRzOiAweDU0MTIsIGZvcm1hdEluZm86IHsgZXJyb3JDb3JyZWN0aW9uTGV2ZWw6IDEsIGRhdGFNYXNrOiAwIH0gfSxcbiAgICB7IGJpdHM6IDB4NTEyNSwgZm9ybWF0SW5mbzogeyBlcnJvckNvcnJlY3Rpb25MZXZlbDogMSwgZGF0YU1hc2s6IDEgfSB9LFxuICAgIHsgYml0czogMHg1RTdDLCBmb3JtYXRJbmZvOiB7IGVycm9yQ29ycmVjdGlvbkxldmVsOiAxLCBkYXRhTWFzazogMiB9IH0sXG4gICAgeyBiaXRzOiAweDVCNEIsIGZvcm1hdEluZm86IHsgZXJyb3JDb3JyZWN0aW9uTGV2ZWw6IDEsIGRhdGFNYXNrOiAzIH0gfSxcbiAgICB7IGJpdHM6IDB4NDVGOSwgZm9ybWF0SW5mbzogeyBlcnJvckNvcnJlY3Rpb25MZXZlbDogMSwgZGF0YU1hc2s6IDQgfSB9LFxuICAgIHsgYml0czogMHg0MENFLCBmb3JtYXRJbmZvOiB7IGVycm9yQ29ycmVjdGlvbkxldmVsOiAxLCBkYXRhTWFzazogNSB9IH0sXG4gICAgeyBiaXRzOiAweDRGOTcsIGZvcm1hdEluZm86IHsgZXJyb3JDb3JyZWN0aW9uTGV2ZWw6IDEsIGRhdGFNYXNrOiA2IH0gfSxcbiAgICB7IGJpdHM6IDB4NEFBMCwgZm9ybWF0SW5mbzogeyBlcnJvckNvcnJlY3Rpb25MZXZlbDogMSwgZGF0YU1hc2s6IDcgfSB9LFxuICAgIHsgYml0czogMHg3N0M0LCBmb3JtYXRJbmZvOiB7IGVycm9yQ29ycmVjdGlvbkxldmVsOiAwLCBkYXRhTWFzazogMCB9IH0sXG4gICAgeyBiaXRzOiAweDcyRjMsIGZvcm1hdEluZm86IHsgZXJyb3JDb3JyZWN0aW9uTGV2ZWw6IDAsIGRhdGFNYXNrOiAxIH0gfSxcbiAgICB7IGJpdHM6IDB4N0RBQSwgZm9ybWF0SW5mbzogeyBlcnJvckNvcnJlY3Rpb25MZXZlbDogMCwgZGF0YU1hc2s6IDIgfSB9LFxuICAgIHsgYml0czogMHg3ODlELCBmb3JtYXRJbmZvOiB7IGVycm9yQ29ycmVjdGlvbkxldmVsOiAwLCBkYXRhTWFzazogMyB9IH0sXG4gICAgeyBiaXRzOiAweDY2MkYsIGZvcm1hdEluZm86IHsgZXJyb3JDb3JyZWN0aW9uTGV2ZWw6IDAsIGRhdGFNYXNrOiA0IH0gfSxcbiAgICB7IGJpdHM6IDB4NjMxOCwgZm9ybWF0SW5mbzogeyBlcnJvckNvcnJlY3Rpb25MZXZlbDogMCwgZGF0YU1hc2s6IDUgfSB9LFxuICAgIHsgYml0czogMHg2QzQxLCBmb3JtYXRJbmZvOiB7IGVycm9yQ29ycmVjdGlvbkxldmVsOiAwLCBkYXRhTWFzazogNiB9IH0sXG4gICAgeyBiaXRzOiAweDY5NzYsIGZvcm1hdEluZm86IHsgZXJyb3JDb3JyZWN0aW9uTGV2ZWw6IDAsIGRhdGFNYXNrOiA3IH0gfSxcbiAgICB7IGJpdHM6IDB4MTY4OSwgZm9ybWF0SW5mbzogeyBlcnJvckNvcnJlY3Rpb25MZXZlbDogMywgZGF0YU1hc2s6IDAgfSB9LFxuICAgIHsgYml0czogMHgxM0JFLCBmb3JtYXRJbmZvOiB7IGVycm9yQ29ycmVjdGlvbkxldmVsOiAzLCBkYXRhTWFzazogMSB9IH0sXG4gICAgeyBiaXRzOiAweDFDRTcsIGZvcm1hdEluZm86IHsgZXJyb3JDb3JyZWN0aW9uTGV2ZWw6IDMsIGRhdGFNYXNrOiAyIH0gfSxcbiAgICB7IGJpdHM6IDB4MTlEMCwgZm9ybWF0SW5mbzogeyBlcnJvckNvcnJlY3Rpb25MZXZlbDogMywgZGF0YU1hc2s6IDMgfSB9LFxuICAgIHsgYml0czogMHgwNzYyLCBmb3JtYXRJbmZvOiB7IGVycm9yQ29ycmVjdGlvbkxldmVsOiAzLCBkYXRhTWFzazogNCB9IH0sXG4gICAgeyBiaXRzOiAweDAyNTUsIGZvcm1hdEluZm86IHsgZXJyb3JDb3JyZWN0aW9uTGV2ZWw6IDMsIGRhdGFNYXNrOiA1IH0gfSxcbiAgICB7IGJpdHM6IDB4MEQwQywgZm9ybWF0SW5mbzogeyBlcnJvckNvcnJlY3Rpb25MZXZlbDogMywgZGF0YU1hc2s6IDYgfSB9LFxuICAgIHsgYml0czogMHgwODNCLCBmb3JtYXRJbmZvOiB7IGVycm9yQ29ycmVjdGlvbkxldmVsOiAzLCBkYXRhTWFzazogNyB9IH0sXG4gICAgeyBiaXRzOiAweDM1NUYsIGZvcm1hdEluZm86IHsgZXJyb3JDb3JyZWN0aW9uTGV2ZWw6IDIsIGRhdGFNYXNrOiAwIH0gfSxcbiAgICB7IGJpdHM6IDB4MzA2OCwgZm9ybWF0SW5mbzogeyBlcnJvckNvcnJlY3Rpb25MZXZlbDogMiwgZGF0YU1hc2s6IDEgfSB9LFxuICAgIHsgYml0czogMHgzRjMxLCBmb3JtYXRJbmZvOiB7IGVycm9yQ29ycmVjdGlvbkxldmVsOiAyLCBkYXRhTWFzazogMiB9IH0sXG4gICAgeyBiaXRzOiAweDNBMDYsIGZvcm1hdEluZm86IHsgZXJyb3JDb3JyZWN0aW9uTGV2ZWw6IDIsIGRhdGFNYXNrOiAzIH0gfSxcbiAgICB7IGJpdHM6IDB4MjRCNCwgZm9ybWF0SW5mbzogeyBlcnJvckNvcnJlY3Rpb25MZXZlbDogMiwgZGF0YU1hc2s6IDQgfSB9LFxuICAgIHsgYml0czogMHgyMTgzLCBmb3JtYXRJbmZvOiB7IGVycm9yQ29ycmVjdGlvbkxldmVsOiAyLCBkYXRhTWFzazogNSB9IH0sXG4gICAgeyBiaXRzOiAweDJFREEsIGZvcm1hdEluZm86IHsgZXJyb3JDb3JyZWN0aW9uTGV2ZWw6IDIsIGRhdGFNYXNrOiA2IH0gfSxcbiAgICB7IGJpdHM6IDB4MkJFRCwgZm9ybWF0SW5mbzogeyBlcnJvckNvcnJlY3Rpb25MZXZlbDogMiwgZGF0YU1hc2s6IDcgfSB9LFxuXTtcbnZhciBEQVRBX01BU0tTID0gW1xuICAgIGZ1bmN0aW9uIChwKSB7IHJldHVybiAoKHAueSArIHAueCkgJSAyKSA9PT0gMDsgfSxcbiAgICBmdW5jdGlvbiAocCkgeyByZXR1cm4gKHAueSAlIDIpID09PSAwOyB9LFxuICAgIGZ1bmN0aW9uIChwKSB7IHJldHVybiBwLnggJSAzID09PSAwOyB9LFxuICAgIGZ1bmN0aW9uIChwKSB7IHJldHVybiAocC55ICsgcC54KSAlIDMgPT09IDA7IH0sXG4gICAgZnVuY3Rpb24gKHApIHsgcmV0dXJuIChNYXRoLmZsb29yKHAueSAvIDIpICsgTWF0aC5mbG9vcihwLnggLyAzKSkgJSAyID09PSAwOyB9LFxuICAgIGZ1bmN0aW9uIChwKSB7IHJldHVybiAoKHAueCAqIHAueSkgJSAyKSArICgocC54ICogcC55KSAlIDMpID09PSAwOyB9LFxuICAgIGZ1bmN0aW9uIChwKSB7IHJldHVybiAoKCgocC55ICogcC54KSAlIDIpICsgKHAueSAqIHAueCkgJSAzKSAlIDIpID09PSAwOyB9LFxuICAgIGZ1bmN0aW9uIChwKSB7IHJldHVybiAoKCgocC55ICsgcC54KSAlIDIpICsgKHAueSAqIHAueCkgJSAzKSAlIDIpID09PSAwOyB9LFxuXTtcbmZ1bmN0aW9uIGJ1aWxkRnVuY3Rpb25QYXR0ZXJuTWFzayh2ZXJzaW9uKSB7XG4gICAgdmFyIGRpbWVuc2lvbiA9IDE3ICsgNCAqIHZlcnNpb24udmVyc2lvbk51bWJlcjtcbiAgICB2YXIgbWF0cml4ID0gQml0TWF0cml4XzEuQml0TWF0cml4LmNyZWF0ZUVtcHR5KGRpbWVuc2lvbiwgZGltZW5zaW9uKTtcbiAgICBtYXRyaXguc2V0UmVnaW9uKDAsIDAsIDksIDksIHRydWUpOyAvLyBUb3AgbGVmdCBmaW5kZXIgcGF0dGVybiArIHNlcGFyYXRvciArIGZvcm1hdFxuICAgIG1hdHJpeC5zZXRSZWdpb24oZGltZW5zaW9uIC0gOCwgMCwgOCwgOSwgdHJ1ZSk7IC8vIFRvcCByaWdodCBmaW5kZXIgcGF0dGVybiArIHNlcGFyYXRvciArIGZvcm1hdFxuICAgIG1hdHJpeC5zZXRSZWdpb24oMCwgZGltZW5zaW9uIC0gOCwgOSwgOCwgdHJ1ZSk7IC8vIEJvdHRvbSBsZWZ0IGZpbmRlciBwYXR0ZXJuICsgc2VwYXJhdG9yICsgZm9ybWF0XG4gICAgLy8gQWxpZ25tZW50IHBhdHRlcm5zXG4gICAgZm9yICh2YXIgX2kgPSAwLCBfYSA9IHZlcnNpb24uYWxpZ25tZW50UGF0dGVybkNlbnRlcnM7IF9pIDwgX2EubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgIHZhciB4ID0gX2FbX2ldO1xuICAgICAgICBmb3IgKHZhciBfYiA9IDAsIF9jID0gdmVyc2lvbi5hbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczsgX2IgPCBfYy5sZW5ndGg7IF9iKyspIHtcbiAgICAgICAgICAgIHZhciB5ID0gX2NbX2JdO1xuICAgICAgICAgICAgaWYgKCEoeCA9PT0gNiAmJiB5ID09PSA2IHx8IHggPT09IDYgJiYgeSA9PT0gZGltZW5zaW9uIC0gNyB8fCB4ID09PSBkaW1lbnNpb24gLSA3ICYmIHkgPT09IDYpKSB7XG4gICAgICAgICAgICAgICAgbWF0cml4LnNldFJlZ2lvbih4IC0gMiwgeSAtIDIsIDUsIDUsIHRydWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIG1hdHJpeC5zZXRSZWdpb24oNiwgOSwgMSwgZGltZW5zaW9uIC0gMTcsIHRydWUpOyAvLyBWZXJ0aWNhbCB0aW1pbmcgcGF0dGVyblxuICAgIG1hdHJpeC5zZXRSZWdpb24oOSwgNiwgZGltZW5zaW9uIC0gMTcsIDEsIHRydWUpOyAvLyBIb3Jpem9udGFsIHRpbWluZyBwYXR0ZXJuXG4gICAgaWYgKHZlcnNpb24udmVyc2lvbk51bWJlciA+IDYpIHtcbiAgICAgICAgbWF0cml4LnNldFJlZ2lvbihkaW1lbnNpb24gLSAxMSwgMCwgMywgNiwgdHJ1ZSk7IC8vIFZlcnNpb24gaW5mbywgdG9wIHJpZ2h0XG4gICAgICAgIG1hdHJpeC5zZXRSZWdpb24oMCwgZGltZW5zaW9uIC0gMTEsIDYsIDMsIHRydWUpOyAvLyBWZXJzaW9uIGluZm8sIGJvdHRvbSBsZWZ0XG4gICAgfVxuICAgIHJldHVybiBtYXRyaXg7XG59XG5mdW5jdGlvbiByZWFkQ29kZXdvcmRzKG1hdHJpeCwgdmVyc2lvbiwgZm9ybWF0SW5mbykge1xuICAgIHZhciBkYXRhTWFzayA9IERBVEFfTUFTS1NbZm9ybWF0SW5mby5kYXRhTWFza107XG4gICAgdmFyIGRpbWVuc2lvbiA9IG1hdHJpeC5oZWlnaHQ7XG4gICAgdmFyIGZ1bmN0aW9uUGF0dGVybk1hc2sgPSBidWlsZEZ1bmN0aW9uUGF0dGVybk1hc2sodmVyc2lvbik7XG4gICAgdmFyIGNvZGV3b3JkcyA9IFtdO1xuICAgIHZhciBjdXJyZW50Qnl0ZSA9IDA7XG4gICAgdmFyIGJpdHNSZWFkID0gMDtcbiAgICAvLyBSZWFkIGNvbHVtbnMgaW4gcGFpcnMsIGZyb20gcmlnaHQgdG8gbGVmdFxuICAgIHZhciByZWFkaW5nVXAgPSB0cnVlO1xuICAgIGZvciAodmFyIGNvbHVtbkluZGV4ID0gZGltZW5zaW9uIC0gMTsgY29sdW1uSW5kZXggPiAwOyBjb2x1bW5JbmRleCAtPSAyKSB7XG4gICAgICAgIGlmIChjb2x1bW5JbmRleCA9PT0gNikgeyAvLyBTa2lwIHdob2xlIGNvbHVtbiB3aXRoIHZlcnRpY2FsIGFsaWdubWVudCBwYXR0ZXJuO1xuICAgICAgICAgICAgY29sdW1uSW5kZXgtLTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGRpbWVuc2lvbjsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgeSA9IHJlYWRpbmdVcCA/IGRpbWVuc2lvbiAtIDEgLSBpIDogaTtcbiAgICAgICAgICAgIGZvciAodmFyIGNvbHVtbk9mZnNldCA9IDA7IGNvbHVtbk9mZnNldCA8IDI7IGNvbHVtbk9mZnNldCsrKSB7XG4gICAgICAgICAgICAgICAgdmFyIHggPSBjb2x1bW5JbmRleCAtIGNvbHVtbk9mZnNldDtcbiAgICAgICAgICAgICAgICBpZiAoIWZ1bmN0aW9uUGF0dGVybk1hc2suZ2V0KHgsIHkpKSB7XG4gICAgICAgICAgICAgICAgICAgIGJpdHNSZWFkKys7XG4gICAgICAgICAgICAgICAgICAgIHZhciBiaXQgPSBtYXRyaXguZ2V0KHgsIHkpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZGF0YU1hc2soeyB5OiB5LCB4OiB4IH0pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBiaXQgPSAhYml0O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnRCeXRlID0gcHVzaEJpdChiaXQsIGN1cnJlbnRCeXRlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGJpdHNSZWFkID09PSA4KSB7IC8vIFdob2xlIGJ5dGVzXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2Rld29yZHMucHVzaChjdXJyZW50Qnl0ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBiaXRzUmVhZCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50Qnl0ZSA9IDA7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmVhZGluZ1VwID0gIXJlYWRpbmdVcDtcbiAgICB9XG4gICAgcmV0dXJuIGNvZGV3b3Jkcztcbn1cbmZ1bmN0aW9uIHJlYWRWZXJzaW9uKG1hdHJpeCkge1xuICAgIHZhciBkaW1lbnNpb24gPSBtYXRyaXguaGVpZ2h0O1xuICAgIHZhciBwcm92aXNpb25hbFZlcnNpb24gPSBNYXRoLmZsb29yKChkaW1lbnNpb24gLSAxNykgLyA0KTtcbiAgICBpZiAocHJvdmlzaW9uYWxWZXJzaW9uIDw9IDYpIHsgLy8gNiBhbmQgdW5kZXIgZG9udCBoYXZlIHZlcnNpb24gaW5mbyBpbiB0aGUgUVIgY29kZVxuICAgICAgICByZXR1cm4gdmVyc2lvbl8xLlZFUlNJT05TW3Byb3Zpc2lvbmFsVmVyc2lvbiAtIDFdO1xuICAgIH1cbiAgICB2YXIgdG9wUmlnaHRWZXJzaW9uQml0cyA9IDA7XG4gICAgZm9yICh2YXIgeSA9IDU7IHkgPj0gMDsgeS0tKSB7XG4gICAgICAgIGZvciAodmFyIHggPSBkaW1lbnNpb24gLSA5OyB4ID49IGRpbWVuc2lvbiAtIDExOyB4LS0pIHtcbiAgICAgICAgICAgIHRvcFJpZ2h0VmVyc2lvbkJpdHMgPSBwdXNoQml0KG1hdHJpeC5nZXQoeCwgeSksIHRvcFJpZ2h0VmVyc2lvbkJpdHMpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHZhciBib3R0b21MZWZ0VmVyc2lvbkJpdHMgPSAwO1xuICAgIGZvciAodmFyIHggPSA1OyB4ID49IDA7IHgtLSkge1xuICAgICAgICBmb3IgKHZhciB5ID0gZGltZW5zaW9uIC0gOTsgeSA+PSBkaW1lbnNpb24gLSAxMTsgeS0tKSB7XG4gICAgICAgICAgICBib3R0b21MZWZ0VmVyc2lvbkJpdHMgPSBwdXNoQml0KG1hdHJpeC5nZXQoeCwgeSksIGJvdHRvbUxlZnRWZXJzaW9uQml0cyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgdmFyIGJlc3REaWZmZXJlbmNlID0gSW5maW5pdHk7XG4gICAgdmFyIGJlc3RWZXJzaW9uO1xuICAgIGZvciAodmFyIF9pID0gMCwgVkVSU0lPTlNfMSA9IHZlcnNpb25fMS5WRVJTSU9OUzsgX2kgPCBWRVJTSU9OU18xLmxlbmd0aDsgX2krKykge1xuICAgICAgICB2YXIgdmVyc2lvbiA9IFZFUlNJT05TXzFbX2ldO1xuICAgICAgICBpZiAodmVyc2lvbi5pbmZvQml0cyA9PT0gdG9wUmlnaHRWZXJzaW9uQml0cyB8fCB2ZXJzaW9uLmluZm9CaXRzID09PSBib3R0b21MZWZ0VmVyc2lvbkJpdHMpIHtcbiAgICAgICAgICAgIHJldHVybiB2ZXJzaW9uO1xuICAgICAgICB9XG4gICAgICAgIHZhciBkaWZmZXJlbmNlID0gbnVtQml0c0RpZmZlcmluZyh0b3BSaWdodFZlcnNpb25CaXRzLCB2ZXJzaW9uLmluZm9CaXRzKTtcbiAgICAgICAgaWYgKGRpZmZlcmVuY2UgPCBiZXN0RGlmZmVyZW5jZSkge1xuICAgICAgICAgICAgYmVzdFZlcnNpb24gPSB2ZXJzaW9uO1xuICAgICAgICAgICAgYmVzdERpZmZlcmVuY2UgPSBkaWZmZXJlbmNlO1xuICAgICAgICB9XG4gICAgICAgIGRpZmZlcmVuY2UgPSBudW1CaXRzRGlmZmVyaW5nKGJvdHRvbUxlZnRWZXJzaW9uQml0cywgdmVyc2lvbi5pbmZvQml0cyk7XG4gICAgICAgIGlmIChkaWZmZXJlbmNlIDwgYmVzdERpZmZlcmVuY2UpIHtcbiAgICAgICAgICAgIGJlc3RWZXJzaW9uID0gdmVyc2lvbjtcbiAgICAgICAgICAgIGJlc3REaWZmZXJlbmNlID0gZGlmZmVyZW5jZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvLyBXZSBjYW4gdG9sZXJhdGUgdXAgdG8gMyBiaXRzIG9mIGVycm9yIHNpbmNlIG5vIHR3byB2ZXJzaW9uIGluZm8gY29kZXdvcmRzIHdpbGxcbiAgICAvLyBkaWZmZXIgaW4gbGVzcyB0aGFuIDggYml0cy5cbiAgICBpZiAoYmVzdERpZmZlcmVuY2UgPD0gMykge1xuICAgICAgICByZXR1cm4gYmVzdFZlcnNpb247XG4gICAgfVxufVxuZnVuY3Rpb24gcmVhZEZvcm1hdEluZm9ybWF0aW9uKG1hdHJpeCkge1xuICAgIHZhciB0b3BMZWZ0Rm9ybWF0SW5mb0JpdHMgPSAwO1xuICAgIGZvciAodmFyIHggPSAwOyB4IDw9IDg7IHgrKykge1xuICAgICAgICBpZiAoeCAhPT0gNikgeyAvLyBTa2lwIHRpbWluZyBwYXR0ZXJuIGJpdFxuICAgICAgICAgICAgdG9wTGVmdEZvcm1hdEluZm9CaXRzID0gcHVzaEJpdChtYXRyaXguZ2V0KHgsIDgpLCB0b3BMZWZ0Rm9ybWF0SW5mb0JpdHMpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGZvciAodmFyIHkgPSA3OyB5ID49IDA7IHktLSkge1xuICAgICAgICBpZiAoeSAhPT0gNikgeyAvLyBTa2lwIHRpbWluZyBwYXR0ZXJuIGJpdFxuICAgICAgICAgICAgdG9wTGVmdEZvcm1hdEluZm9CaXRzID0gcHVzaEJpdChtYXRyaXguZ2V0KDgsIHkpLCB0b3BMZWZ0Rm9ybWF0SW5mb0JpdHMpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHZhciBkaW1lbnNpb24gPSBtYXRyaXguaGVpZ2h0O1xuICAgIHZhciB0b3BSaWdodEJvdHRvbVJpZ2h0Rm9ybWF0SW5mb0JpdHMgPSAwO1xuICAgIGZvciAodmFyIHkgPSBkaW1lbnNpb24gLSAxOyB5ID49IGRpbWVuc2lvbiAtIDc7IHktLSkgeyAvLyBib3R0b20gbGVmdFxuICAgICAgICB0b3BSaWdodEJvdHRvbVJpZ2h0Rm9ybWF0SW5mb0JpdHMgPSBwdXNoQml0KG1hdHJpeC5nZXQoOCwgeSksIHRvcFJpZ2h0Qm90dG9tUmlnaHRGb3JtYXRJbmZvQml0cyk7XG4gICAgfVxuICAgIGZvciAodmFyIHggPSBkaW1lbnNpb24gLSA4OyB4IDwgZGltZW5zaW9uOyB4KyspIHsgLy8gdG9wIHJpZ2h0XG4gICAgICAgIHRvcFJpZ2h0Qm90dG9tUmlnaHRGb3JtYXRJbmZvQml0cyA9IHB1c2hCaXQobWF0cml4LmdldCh4LCA4KSwgdG9wUmlnaHRCb3R0b21SaWdodEZvcm1hdEluZm9CaXRzKTtcbiAgICB9XG4gICAgdmFyIGJlc3REaWZmZXJlbmNlID0gSW5maW5pdHk7XG4gICAgdmFyIGJlc3RGb3JtYXRJbmZvID0gbnVsbDtcbiAgICBmb3IgKHZhciBfaSA9IDAsIEZPUk1BVF9JTkZPX1RBQkxFXzEgPSBGT1JNQVRfSU5GT19UQUJMRTsgX2kgPCBGT1JNQVRfSU5GT19UQUJMRV8xLmxlbmd0aDsgX2krKykge1xuICAgICAgICB2YXIgX2EgPSBGT1JNQVRfSU5GT19UQUJMRV8xW19pXSwgYml0cyA9IF9hLmJpdHMsIGZvcm1hdEluZm8gPSBfYS5mb3JtYXRJbmZvO1xuICAgICAgICBpZiAoYml0cyA9PT0gdG9wTGVmdEZvcm1hdEluZm9CaXRzIHx8IGJpdHMgPT09IHRvcFJpZ2h0Qm90dG9tUmlnaHRGb3JtYXRJbmZvQml0cykge1xuICAgICAgICAgICAgcmV0dXJuIGZvcm1hdEluZm87XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGRpZmZlcmVuY2UgPSBudW1CaXRzRGlmZmVyaW5nKHRvcExlZnRGb3JtYXRJbmZvQml0cywgYml0cyk7XG4gICAgICAgIGlmIChkaWZmZXJlbmNlIDwgYmVzdERpZmZlcmVuY2UpIHtcbiAgICAgICAgICAgIGJlc3RGb3JtYXRJbmZvID0gZm9ybWF0SW5mbztcbiAgICAgICAgICAgIGJlc3REaWZmZXJlbmNlID0gZGlmZmVyZW5jZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodG9wTGVmdEZvcm1hdEluZm9CaXRzICE9PSB0b3BSaWdodEJvdHRvbVJpZ2h0Rm9ybWF0SW5mb0JpdHMpIHsgLy8gYWxzbyB0cnkgdGhlIG90aGVyIG9wdGlvblxuICAgICAgICAgICAgZGlmZmVyZW5jZSA9IG51bUJpdHNEaWZmZXJpbmcodG9wUmlnaHRCb3R0b21SaWdodEZvcm1hdEluZm9CaXRzLCBiaXRzKTtcbiAgICAgICAgICAgIGlmIChkaWZmZXJlbmNlIDwgYmVzdERpZmZlcmVuY2UpIHtcbiAgICAgICAgICAgICAgICBiZXN0Rm9ybWF0SW5mbyA9IGZvcm1hdEluZm87XG4gICAgICAgICAgICAgICAgYmVzdERpZmZlcmVuY2UgPSBkaWZmZXJlbmNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIC8vIEhhbW1pbmcgZGlzdGFuY2Ugb2YgdGhlIDMyIG1hc2tlZCBjb2RlcyBpcyA3LCBieSBjb25zdHJ1Y3Rpb24sIHNvIDw9IDMgYml0cyBkaWZmZXJpbmcgbWVhbnMgd2UgZm91bmQgYSBtYXRjaFxuICAgIGlmIChiZXN0RGlmZmVyZW5jZSA8PSAzKSB7XG4gICAgICAgIHJldHVybiBiZXN0Rm9ybWF0SW5mbztcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiBnZXREYXRhQmxvY2tzKGNvZGV3b3JkcywgdmVyc2lvbiwgZWNMZXZlbCkge1xuICAgIHZhciBlY0luZm8gPSB2ZXJzaW9uLmVycm9yQ29ycmVjdGlvbkxldmVsc1tlY0xldmVsXTtcbiAgICB2YXIgZGF0YUJsb2NrcyA9IFtdO1xuICAgIHZhciB0b3RhbENvZGV3b3JkcyA9IDA7XG4gICAgZWNJbmZvLmVjQmxvY2tzLmZvckVhY2goZnVuY3Rpb24gKGJsb2NrKSB7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYmxvY2subnVtQmxvY2tzOyBpKyspIHtcbiAgICAgICAgICAgIGRhdGFCbG9ja3MucHVzaCh7IG51bURhdGFDb2Rld29yZHM6IGJsb2NrLmRhdGFDb2Rld29yZHNQZXJCbG9jaywgY29kZXdvcmRzOiBbXSB9KTtcbiAgICAgICAgICAgIHRvdGFsQ29kZXdvcmRzICs9IGJsb2NrLmRhdGFDb2Rld29yZHNQZXJCbG9jayArIGVjSW5mby5lY0NvZGV3b3Jkc1BlckJsb2NrO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgLy8gSW4gc29tZSBjYXNlcyB0aGUgUVIgY29kZSB3aWxsIGJlIG1hbGZvcm1lZCBlbm91Z2ggdGhhdCB3ZSBwdWxsIG9mZiBtb3JlIG9yIGxlc3MgdGhhbiB3ZSBzaG91bGQuXG4gICAgLy8gSWYgd2UgcHVsbCBvZmYgbGVzcyB0aGVyZSdzIG5vdGhpbmcgd2UgY2FuIGRvLlxuICAgIC8vIElmIHdlIHB1bGwgb2ZmIG1vcmUgd2UgY2FuIHNhZmVseSB0cnVuY2F0ZVxuICAgIGlmIChjb2Rld29yZHMubGVuZ3RoIDwgdG90YWxDb2Rld29yZHMpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGNvZGV3b3JkcyA9IGNvZGV3b3Jkcy5zbGljZSgwLCB0b3RhbENvZGV3b3Jkcyk7XG4gICAgdmFyIHNob3J0QmxvY2tTaXplID0gZWNJbmZvLmVjQmxvY2tzWzBdLmRhdGFDb2Rld29yZHNQZXJCbG9jaztcbiAgICAvLyBQdWxsIGNvZGV3b3JkcyB0byBmaWxsIHRoZSBibG9ja3MgdXAgdG8gdGhlIG1pbmltdW0gc2l6ZVxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgc2hvcnRCbG9ja1NpemU7IGkrKykge1xuICAgICAgICBmb3IgKHZhciBfaSA9IDAsIGRhdGFCbG9ja3NfMSA9IGRhdGFCbG9ja3M7IF9pIDwgZGF0YUJsb2Nrc18xLmxlbmd0aDsgX2krKykge1xuICAgICAgICAgICAgdmFyIGRhdGFCbG9jayA9IGRhdGFCbG9ja3NfMVtfaV07XG4gICAgICAgICAgICBkYXRhQmxvY2suY29kZXdvcmRzLnB1c2goY29kZXdvcmRzLnNoaWZ0KCkpO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vIElmIHRoZXJlIGFyZSBhbnkgbGFyZ2UgYmxvY2tzLCBwdWxsIGNvZGV3b3JkcyB0byBmaWxsIHRoZSBsYXN0IGVsZW1lbnQgb2YgdGhvc2VcbiAgICBpZiAoZWNJbmZvLmVjQmxvY2tzLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgdmFyIHNtYWxsQmxvY2tDb3VudCA9IGVjSW5mby5lY0Jsb2Nrc1swXS5udW1CbG9ja3M7XG4gICAgICAgIHZhciBsYXJnZUJsb2NrQ291bnQgPSBlY0luZm8uZWNCbG9ja3NbMV0ubnVtQmxvY2tzO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxhcmdlQmxvY2tDb3VudDsgaSsrKSB7XG4gICAgICAgICAgICBkYXRhQmxvY2tzW3NtYWxsQmxvY2tDb3VudCArIGldLmNvZGV3b3Jkcy5wdXNoKGNvZGV3b3Jkcy5zaGlmdCgpKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvLyBBZGQgdGhlIHJlc3Qgb2YgdGhlIGNvZGV3b3JkcyB0byB0aGUgYmxvY2tzLiBUaGVzZSBhcmUgdGhlIGVycm9yIGNvcnJlY3Rpb24gY29kZXdvcmRzLlxuICAgIHdoaWxlIChjb2Rld29yZHMubGVuZ3RoID4gMCkge1xuICAgICAgICBmb3IgKHZhciBfYSA9IDAsIGRhdGFCbG9ja3NfMiA9IGRhdGFCbG9ja3M7IF9hIDwgZGF0YUJsb2Nrc18yLmxlbmd0aDsgX2ErKykge1xuICAgICAgICAgICAgdmFyIGRhdGFCbG9jayA9IGRhdGFCbG9ja3NfMltfYV07XG4gICAgICAgICAgICBkYXRhQmxvY2suY29kZXdvcmRzLnB1c2goY29kZXdvcmRzLnNoaWZ0KCkpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBkYXRhQmxvY2tzO1xufVxuZnVuY3Rpb24gZGVjb2RlTWF0cml4KG1hdHJpeCkge1xuICAgIHZhciB2ZXJzaW9uID0gcmVhZFZlcnNpb24obWF0cml4KTtcbiAgICBpZiAoIXZlcnNpb24pIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHZhciBmb3JtYXRJbmZvID0gcmVhZEZvcm1hdEluZm9ybWF0aW9uKG1hdHJpeCk7XG4gICAgaWYgKCFmb3JtYXRJbmZvKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICB2YXIgY29kZXdvcmRzID0gcmVhZENvZGV3b3JkcyhtYXRyaXgsIHZlcnNpb24sIGZvcm1hdEluZm8pO1xuICAgIHZhciBkYXRhQmxvY2tzID0gZ2V0RGF0YUJsb2Nrcyhjb2Rld29yZHMsIHZlcnNpb24sIGZvcm1hdEluZm8uZXJyb3JDb3JyZWN0aW9uTGV2ZWwpO1xuICAgIGlmICghZGF0YUJsb2Nrcykge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgLy8gQ291bnQgdG90YWwgbnVtYmVyIG9mIGRhdGEgYnl0ZXNcbiAgICB2YXIgdG90YWxCeXRlcyA9IGRhdGFCbG9ja3MucmVkdWNlKGZ1bmN0aW9uIChhLCBiKSB7IHJldHVybiBhICsgYi5udW1EYXRhQ29kZXdvcmRzOyB9LCAwKTtcbiAgICB2YXIgcmVzdWx0Qnl0ZXMgPSBuZXcgVWludDhDbGFtcGVkQXJyYXkodG90YWxCeXRlcyk7XG4gICAgdmFyIHJlc3VsdEluZGV4ID0gMDtcbiAgICBmb3IgKHZhciBfaSA9IDAsIGRhdGFCbG9ja3NfMyA9IGRhdGFCbG9ja3M7IF9pIDwgZGF0YUJsb2Nrc18zLmxlbmd0aDsgX2krKykge1xuICAgICAgICB2YXIgZGF0YUJsb2NrID0gZGF0YUJsb2Nrc18zW19pXTtcbiAgICAgICAgdmFyIGNvcnJlY3RlZEJ5dGVzID0gcmVlZHNvbG9tb25fMS5kZWNvZGUoZGF0YUJsb2NrLmNvZGV3b3JkcywgZGF0YUJsb2NrLmNvZGV3b3Jkcy5sZW5ndGggLSBkYXRhQmxvY2subnVtRGF0YUNvZGV3b3Jkcyk7XG4gICAgICAgIGlmICghY29ycmVjdGVkQnl0ZXMpIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZGF0YUJsb2NrLm51bURhdGFDb2Rld29yZHM7IGkrKykge1xuICAgICAgICAgICAgcmVzdWx0Qnl0ZXNbcmVzdWx0SW5kZXgrK10gPSBjb3JyZWN0ZWRCeXRlc1tpXTtcbiAgICAgICAgfVxuICAgIH1cbiAgICB0cnkge1xuICAgICAgICByZXR1cm4gZGVjb2RlRGF0YV8xLmRlY29kZShyZXN1bHRCeXRlcywgdmVyc2lvbi52ZXJzaW9uTnVtYmVyKTtcbiAgICB9XG4gICAgY2F0Y2ggKF9hKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGRlY29kZShtYXRyaXgpIHtcbiAgICBpZiAobWF0cml4ID09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHZhciByZXN1bHQgPSBkZWNvZGVNYXRyaXgobWF0cml4KTtcbiAgICBpZiAocmVzdWx0KSB7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIC8vIERlY29kaW5nIGRpZG4ndCB3b3JrLCB0cnkgbWlycm9yaW5nIHRoZSBRUiBhY3Jvc3MgdGhlIHRvcExlZnQgLT4gYm90dG9tUmlnaHQgbGluZS5cbiAgICBmb3IgKHZhciB4ID0gMDsgeCA8IG1hdHJpeC53aWR0aDsgeCsrKSB7XG4gICAgICAgIGZvciAodmFyIHkgPSB4ICsgMTsgeSA8IG1hdHJpeC5oZWlnaHQ7IHkrKykge1xuICAgICAgICAgICAgaWYgKG1hdHJpeC5nZXQoeCwgeSkgIT09IG1hdHJpeC5nZXQoeSwgeCkpIHtcbiAgICAgICAgICAgICAgICBtYXRyaXguc2V0KHgsIHksICFtYXRyaXguZ2V0KHgsIHkpKTtcbiAgICAgICAgICAgICAgICBtYXRyaXguc2V0KHksIHgsICFtYXRyaXguZ2V0KHksIHgpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZGVjb2RlTWF0cml4KG1hdHJpeCk7XG59XG5leHBvcnRzLmRlY29kZSA9IGRlY29kZTtcblxuXG4vKioqLyB9KSxcbi8qIDYgKi9cbi8qKiovIChmdW5jdGlvbihtb2R1bGUsIGV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pIHtcblxuXCJ1c2Ugc3RyaWN0XCI7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbi8vIHRzbGludDpkaXNhYmxlOm5vLWJpdHdpc2VcbnZhciBCaXRTdHJlYW1fMSA9IF9fd2VicGFja19yZXF1aXJlX18oNyk7XG52YXIgc2hpZnRKSVNUYWJsZV8xID0gX193ZWJwYWNrX3JlcXVpcmVfXyg4KTtcbnZhciBNb2RlO1xuKGZ1bmN0aW9uIChNb2RlKSB7XG4gICAgTW9kZVtcIk51bWVyaWNcIl0gPSBcIm51bWVyaWNcIjtcbiAgICBNb2RlW1wiQWxwaGFudW1lcmljXCJdID0gXCJhbHBoYW51bWVyaWNcIjtcbiAgICBNb2RlW1wiQnl0ZVwiXSA9IFwiYnl0ZVwiO1xuICAgIE1vZGVbXCJLYW5qaVwiXSA9IFwia2FuamlcIjtcbiAgICBNb2RlW1wiRUNJXCJdID0gXCJlY2lcIjtcbn0pKE1vZGUgPSBleHBvcnRzLk1vZGUgfHwgKGV4cG9ydHMuTW9kZSA9IHt9KSk7XG52YXIgTW9kZUJ5dGU7XG4oZnVuY3Rpb24gKE1vZGVCeXRlKSB7XG4gICAgTW9kZUJ5dGVbTW9kZUJ5dGVbXCJUZXJtaW5hdG9yXCJdID0gMF0gPSBcIlRlcm1pbmF0b3JcIjtcbiAgICBNb2RlQnl0ZVtNb2RlQnl0ZVtcIk51bWVyaWNcIl0gPSAxXSA9IFwiTnVtZXJpY1wiO1xuICAgIE1vZGVCeXRlW01vZGVCeXRlW1wiQWxwaGFudW1lcmljXCJdID0gMl0gPSBcIkFscGhhbnVtZXJpY1wiO1xuICAgIE1vZGVCeXRlW01vZGVCeXRlW1wiQnl0ZVwiXSA9IDRdID0gXCJCeXRlXCI7XG4gICAgTW9kZUJ5dGVbTW9kZUJ5dGVbXCJLYW5qaVwiXSA9IDhdID0gXCJLYW5qaVwiO1xuICAgIE1vZGVCeXRlW01vZGVCeXRlW1wiRUNJXCJdID0gN10gPSBcIkVDSVwiO1xuICAgIC8vIFN0cnVjdHVyZWRBcHBlbmQgPSAweDMsXG4gICAgLy8gRk5DMUZpcnN0UG9zaXRpb24gPSAweDUsXG4gICAgLy8gRk5DMVNlY29uZFBvc2l0aW9uID0gMHg5LFxufSkoTW9kZUJ5dGUgfHwgKE1vZGVCeXRlID0ge30pKTtcbmZ1bmN0aW9uIGRlY29kZU51bWVyaWMoc3RyZWFtLCBzaXplKSB7XG4gICAgdmFyIGJ5dGVzID0gW107XG4gICAgdmFyIHRleHQgPSBcIlwiO1xuICAgIHZhciBjaGFyYWN0ZXJDb3VudFNpemUgPSBbMTAsIDEyLCAxNF1bc2l6ZV07XG4gICAgdmFyIGxlbmd0aCA9IHN0cmVhbS5yZWFkQml0cyhjaGFyYWN0ZXJDb3VudFNpemUpO1xuICAgIC8vIFJlYWQgZGlnaXRzIGluIGdyb3VwcyBvZiAzXG4gICAgd2hpbGUgKGxlbmd0aCA+PSAzKSB7XG4gICAgICAgIHZhciBudW0gPSBzdHJlYW0ucmVhZEJpdHMoMTApO1xuICAgICAgICBpZiAobnVtID49IDEwMDApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgbnVtZXJpYyB2YWx1ZSBhYm92ZSA5OTlcIik7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGEgPSBNYXRoLmZsb29yKG51bSAvIDEwMCk7XG4gICAgICAgIHZhciBiID0gTWF0aC5mbG9vcihudW0gLyAxMCkgJSAxMDtcbiAgICAgICAgdmFyIGMgPSBudW0gJSAxMDtcbiAgICAgICAgYnl0ZXMucHVzaCg0OCArIGEsIDQ4ICsgYiwgNDggKyBjKTtcbiAgICAgICAgdGV4dCArPSBhLnRvU3RyaW5nKCkgKyBiLnRvU3RyaW5nKCkgKyBjLnRvU3RyaW5nKCk7XG4gICAgICAgIGxlbmd0aCAtPSAzO1xuICAgIH1cbiAgICAvLyBJZiB0aGUgbnVtYmVyIG9mIGRpZ2l0cyBhcmVuJ3QgYSBtdWx0aXBsZSBvZiAzLCB0aGUgcmVtYWluaW5nIGRpZ2l0cyBhcmUgc3BlY2lhbCBjYXNlZC5cbiAgICBpZiAobGVuZ3RoID09PSAyKSB7XG4gICAgICAgIHZhciBudW0gPSBzdHJlYW0ucmVhZEJpdHMoNyk7XG4gICAgICAgIGlmIChudW0gPj0gMTAwKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIG51bWVyaWMgdmFsdWUgYWJvdmUgOTlcIik7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGEgPSBNYXRoLmZsb29yKG51bSAvIDEwKTtcbiAgICAgICAgdmFyIGIgPSBudW0gJSAxMDtcbiAgICAgICAgYnl0ZXMucHVzaCg0OCArIGEsIDQ4ICsgYik7XG4gICAgICAgIHRleHQgKz0gYS50b1N0cmluZygpICsgYi50b1N0cmluZygpO1xuICAgIH1cbiAgICBlbHNlIGlmIChsZW5ndGggPT09IDEpIHtcbiAgICAgICAgdmFyIG51bSA9IHN0cmVhbS5yZWFkQml0cyg0KTtcbiAgICAgICAgaWYgKG51bSA+PSAxMCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCBudW1lcmljIHZhbHVlIGFib3ZlIDlcIik7XG4gICAgICAgIH1cbiAgICAgICAgYnl0ZXMucHVzaCg0OCArIG51bSk7XG4gICAgICAgIHRleHQgKz0gbnVtLnRvU3RyaW5nKCk7XG4gICAgfVxuICAgIHJldHVybiB7IGJ5dGVzOiBieXRlcywgdGV4dDogdGV4dCB9O1xufVxudmFyIEFscGhhbnVtZXJpY0NoYXJhY3RlckNvZGVzID0gW1xuICAgIFwiMFwiLCBcIjFcIiwgXCIyXCIsIFwiM1wiLCBcIjRcIiwgXCI1XCIsIFwiNlwiLCBcIjdcIiwgXCI4XCIsXG4gICAgXCI5XCIsIFwiQVwiLCBcIkJcIiwgXCJDXCIsIFwiRFwiLCBcIkVcIiwgXCJGXCIsIFwiR1wiLCBcIkhcIixcbiAgICBcIklcIiwgXCJKXCIsIFwiS1wiLCBcIkxcIiwgXCJNXCIsIFwiTlwiLCBcIk9cIiwgXCJQXCIsIFwiUVwiLFxuICAgIFwiUlwiLCBcIlNcIiwgXCJUXCIsIFwiVVwiLCBcIlZcIiwgXCJXXCIsIFwiWFwiLCBcIllcIiwgXCJaXCIsXG4gICAgXCIgXCIsIFwiJFwiLCBcIiVcIiwgXCIqXCIsIFwiK1wiLCBcIi1cIiwgXCIuXCIsIFwiL1wiLCBcIjpcIixcbl07XG5mdW5jdGlvbiBkZWNvZGVBbHBoYW51bWVyaWMoc3RyZWFtLCBzaXplKSB7XG4gICAgdmFyIGJ5dGVzID0gW107XG4gICAgdmFyIHRleHQgPSBcIlwiO1xuICAgIHZhciBjaGFyYWN0ZXJDb3VudFNpemUgPSBbOSwgMTEsIDEzXVtzaXplXTtcbiAgICB2YXIgbGVuZ3RoID0gc3RyZWFtLnJlYWRCaXRzKGNoYXJhY3RlckNvdW50U2l6ZSk7XG4gICAgd2hpbGUgKGxlbmd0aCA+PSAyKSB7XG4gICAgICAgIHZhciB2ID0gc3RyZWFtLnJlYWRCaXRzKDExKTtcbiAgICAgICAgdmFyIGEgPSBNYXRoLmZsb29yKHYgLyA0NSk7XG4gICAgICAgIHZhciBiID0gdiAlIDQ1O1xuICAgICAgICBieXRlcy5wdXNoKEFscGhhbnVtZXJpY0NoYXJhY3RlckNvZGVzW2FdLmNoYXJDb2RlQXQoMCksIEFscGhhbnVtZXJpY0NoYXJhY3RlckNvZGVzW2JdLmNoYXJDb2RlQXQoMCkpO1xuICAgICAgICB0ZXh0ICs9IEFscGhhbnVtZXJpY0NoYXJhY3RlckNvZGVzW2FdICsgQWxwaGFudW1lcmljQ2hhcmFjdGVyQ29kZXNbYl07XG4gICAgICAgIGxlbmd0aCAtPSAyO1xuICAgIH1cbiAgICBpZiAobGVuZ3RoID09PSAxKSB7XG4gICAgICAgIHZhciBhID0gc3RyZWFtLnJlYWRCaXRzKDYpO1xuICAgICAgICBieXRlcy5wdXNoKEFscGhhbnVtZXJpY0NoYXJhY3RlckNvZGVzW2FdLmNoYXJDb2RlQXQoMCkpO1xuICAgICAgICB0ZXh0ICs9IEFscGhhbnVtZXJpY0NoYXJhY3RlckNvZGVzW2FdO1xuICAgIH1cbiAgICByZXR1cm4geyBieXRlczogYnl0ZXMsIHRleHQ6IHRleHQgfTtcbn1cbmZ1bmN0aW9uIGRlY29kZUJ5dGUoc3RyZWFtLCBzaXplKSB7XG4gICAgdmFyIGJ5dGVzID0gW107XG4gICAgdmFyIHRleHQgPSBcIlwiO1xuICAgIHZhciBjaGFyYWN0ZXJDb3VudFNpemUgPSBbOCwgMTYsIDE2XVtzaXplXTtcbiAgICB2YXIgbGVuZ3RoID0gc3RyZWFtLnJlYWRCaXRzKGNoYXJhY3RlckNvdW50U2l6ZSk7XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgICAgICB2YXIgYiA9IHN0cmVhbS5yZWFkQml0cyg4KTtcbiAgICAgICAgYnl0ZXMucHVzaChiKTtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgdGV4dCArPSBkZWNvZGVVUklDb21wb25lbnQoYnl0ZXMubWFwKGZ1bmN0aW9uIChiKSB7IHJldHVybiBcIiVcIiArIChcIjBcIiArIGIudG9TdHJpbmcoMTYpKS5zdWJzdHIoLTIpOyB9KS5qb2luKFwiXCIpKTtcbiAgICB9XG4gICAgY2F0Y2ggKF9hKSB7XG4gICAgICAgIC8vIGZhaWxlZCB0byBkZWNvZGVcbiAgICB9XG4gICAgcmV0dXJuIHsgYnl0ZXM6IGJ5dGVzLCB0ZXh0OiB0ZXh0IH07XG59XG5mdW5jdGlvbiBkZWNvZGVLYW5qaShzdHJlYW0sIHNpemUpIHtcbiAgICB2YXIgYnl0ZXMgPSBbXTtcbiAgICB2YXIgdGV4dCA9IFwiXCI7XG4gICAgdmFyIGNoYXJhY3RlckNvdW50U2l6ZSA9IFs4LCAxMCwgMTJdW3NpemVdO1xuICAgIHZhciBsZW5ndGggPSBzdHJlYW0ucmVhZEJpdHMoY2hhcmFjdGVyQ291bnRTaXplKTtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHZhciBrID0gc3RyZWFtLnJlYWRCaXRzKDEzKTtcbiAgICAgICAgdmFyIGMgPSAoTWF0aC5mbG9vcihrIC8gMHhDMCkgPDwgOCkgfCAoayAlIDB4QzApO1xuICAgICAgICBpZiAoYyA8IDB4MUYwMCkge1xuICAgICAgICAgICAgYyArPSAweDgxNDA7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjICs9IDB4QzE0MDtcbiAgICAgICAgfVxuICAgICAgICBieXRlcy5wdXNoKGMgPj4gOCwgYyAmIDB4RkYpO1xuICAgICAgICB0ZXh0ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoc2hpZnRKSVNUYWJsZV8xLnNoaWZ0SklTVGFibGVbY10pO1xuICAgIH1cbiAgICByZXR1cm4geyBieXRlczogYnl0ZXMsIHRleHQ6IHRleHQgfTtcbn1cbmZ1bmN0aW9uIGRlY29kZShkYXRhLCB2ZXJzaW9uKSB7XG4gICAgdmFyIF9hLCBfYiwgX2MsIF9kO1xuICAgIHZhciBzdHJlYW0gPSBuZXcgQml0U3RyZWFtXzEuQml0U3RyZWFtKGRhdGEpO1xuICAgIC8vIFRoZXJlIGFyZSAzICdzaXplcycgYmFzZWQgb24gdGhlIHZlcnNpb24uIDEtOSBpcyBzbWFsbCAoMCksIDEwLTI2IGlzIG1lZGl1bSAoMSkgYW5kIDI3LTQwIGlzIGxhcmdlICgyKS5cbiAgICB2YXIgc2l6ZSA9IHZlcnNpb24gPD0gOSA/IDAgOiB2ZXJzaW9uIDw9IDI2ID8gMSA6IDI7XG4gICAgdmFyIHJlc3VsdCA9IHtcbiAgICAgICAgdGV4dDogXCJcIixcbiAgICAgICAgYnl0ZXM6IFtdLFxuICAgICAgICBjaHVua3M6IFtdLFxuICAgICAgICB2ZXJzaW9uOiB2ZXJzaW9uLFxuICAgIH07XG4gICAgd2hpbGUgKHN0cmVhbS5hdmFpbGFibGUoKSA+PSA0KSB7XG4gICAgICAgIHZhciBtb2RlID0gc3RyZWFtLnJlYWRCaXRzKDQpO1xuICAgICAgICBpZiAobW9kZSA9PT0gTW9kZUJ5dGUuVGVybWluYXRvcikge1xuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtb2RlID09PSBNb2RlQnl0ZS5FQ0kpIHtcbiAgICAgICAgICAgIGlmIChzdHJlYW0ucmVhZEJpdHMoMSkgPT09IDApIHtcbiAgICAgICAgICAgICAgICByZXN1bHQuY2h1bmtzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBNb2RlLkVDSSxcbiAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudE51bWJlcjogc3RyZWFtLnJlYWRCaXRzKDcpLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoc3RyZWFtLnJlYWRCaXRzKDEpID09PSAwKSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0LmNodW5rcy5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogTW9kZS5FQ0ksXG4gICAgICAgICAgICAgICAgICAgIGFzc2lnbm1lbnROdW1iZXI6IHN0cmVhbS5yZWFkQml0cygxNCksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChzdHJlYW0ucmVhZEJpdHMoMSkgPT09IDApIHtcbiAgICAgICAgICAgICAgICByZXN1bHQuY2h1bmtzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBNb2RlLkVDSSxcbiAgICAgICAgICAgICAgICAgICAgYXNzaWdubWVudE51bWJlcjogc3RyZWFtLnJlYWRCaXRzKDIxKSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIEVDSSBkYXRhIHNlZW1zIGNvcnJ1cHRlZFxuICAgICAgICAgICAgICAgIHJlc3VsdC5jaHVua3MucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IE1vZGUuRUNJLFxuICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50TnVtYmVyOiAtMSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtb2RlID09PSBNb2RlQnl0ZS5OdW1lcmljKSB7XG4gICAgICAgICAgICB2YXIgbnVtZXJpY1Jlc3VsdCA9IGRlY29kZU51bWVyaWMoc3RyZWFtLCBzaXplKTtcbiAgICAgICAgICAgIHJlc3VsdC50ZXh0ICs9IG51bWVyaWNSZXN1bHQudGV4dDtcbiAgICAgICAgICAgIChfYSA9IHJlc3VsdC5ieXRlcykucHVzaC5hcHBseShfYSwgbnVtZXJpY1Jlc3VsdC5ieXRlcyk7XG4gICAgICAgICAgICByZXN1bHQuY2h1bmtzLnB1c2goe1xuICAgICAgICAgICAgICAgIHR5cGU6IE1vZGUuTnVtZXJpYyxcbiAgICAgICAgICAgICAgICB0ZXh0OiBudW1lcmljUmVzdWx0LnRleHQsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChtb2RlID09PSBNb2RlQnl0ZS5BbHBoYW51bWVyaWMpIHtcbiAgICAgICAgICAgIHZhciBhbHBoYW51bWVyaWNSZXN1bHQgPSBkZWNvZGVBbHBoYW51bWVyaWMoc3RyZWFtLCBzaXplKTtcbiAgICAgICAgICAgIHJlc3VsdC50ZXh0ICs9IGFscGhhbnVtZXJpY1Jlc3VsdC50ZXh0O1xuICAgICAgICAgICAgKF9iID0gcmVzdWx0LmJ5dGVzKS5wdXNoLmFwcGx5KF9iLCBhbHBoYW51bWVyaWNSZXN1bHQuYnl0ZXMpO1xuICAgICAgICAgICAgcmVzdWx0LmNodW5rcy5wdXNoKHtcbiAgICAgICAgICAgICAgICB0eXBlOiBNb2RlLkFscGhhbnVtZXJpYyxcbiAgICAgICAgICAgICAgICB0ZXh0OiBhbHBoYW51bWVyaWNSZXN1bHQudGV4dCxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1vZGUgPT09IE1vZGVCeXRlLkJ5dGUpIHtcbiAgICAgICAgICAgIHZhciBieXRlUmVzdWx0ID0gZGVjb2RlQnl0ZShzdHJlYW0sIHNpemUpO1xuICAgICAgICAgICAgcmVzdWx0LnRleHQgKz0gYnl0ZVJlc3VsdC50ZXh0O1xuICAgICAgICAgICAgKF9jID0gcmVzdWx0LmJ5dGVzKS5wdXNoLmFwcGx5KF9jLCBieXRlUmVzdWx0LmJ5dGVzKTtcbiAgICAgICAgICAgIHJlc3VsdC5jaHVua3MucHVzaCh7XG4gICAgICAgICAgICAgICAgdHlwZTogTW9kZS5CeXRlLFxuICAgICAgICAgICAgICAgIGJ5dGVzOiBieXRlUmVzdWx0LmJ5dGVzLFxuICAgICAgICAgICAgICAgIHRleHQ6IGJ5dGVSZXN1bHQudGV4dCxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG1vZGUgPT09IE1vZGVCeXRlLkthbmppKSB7XG4gICAgICAgICAgICB2YXIga2FuamlSZXN1bHQgPSBkZWNvZGVLYW5qaShzdHJlYW0sIHNpemUpO1xuICAgICAgICAgICAgcmVzdWx0LnRleHQgKz0ga2FuamlSZXN1bHQudGV4dDtcbiAgICAgICAgICAgIChfZCA9IHJlc3VsdC5ieXRlcykucHVzaC5hcHBseShfZCwga2FuamlSZXN1bHQuYnl0ZXMpO1xuICAgICAgICAgICAgcmVzdWx0LmNodW5rcy5wdXNoKHtcbiAgICAgICAgICAgICAgICB0eXBlOiBNb2RlLkthbmppLFxuICAgICAgICAgICAgICAgIGJ5dGVzOiBrYW5qaVJlc3VsdC5ieXRlcyxcbiAgICAgICAgICAgICAgICB0ZXh0OiBrYW5qaVJlc3VsdC50ZXh0LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gSWYgdGhlcmUgaXMgbm8gZGF0YSBsZWZ0LCBvciB0aGUgcmVtYWluaW5nIGJpdHMgYXJlIGFsbCAwLCB0aGVuIHRoYXQgY291bnRzIGFzIGEgdGVybWluYXRpb24gbWFya2VyXG4gICAgaWYgKHN0cmVhbS5hdmFpbGFibGUoKSA9PT0gMCB8fCBzdHJlYW0ucmVhZEJpdHMoc3RyZWFtLmF2YWlsYWJsZSgpKSA9PT0gMCkge1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbn1cbmV4cG9ydHMuZGVjb2RlID0gZGVjb2RlO1xuXG5cbi8qKiovIH0pLFxuLyogNyAqL1xuLyoqKi8gKGZ1bmN0aW9uKG1vZHVsZSwgZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXykge1xuXG5cInVzZSBzdHJpY3RcIjtcblxuLy8gdHNsaW50OmRpc2FibGU6bm8tYml0d2lzZVxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xudmFyIEJpdFN0cmVhbSA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBCaXRTdHJlYW0oYnl0ZXMpIHtcbiAgICAgICAgdGhpcy5ieXRlT2Zmc2V0ID0gMDtcbiAgICAgICAgdGhpcy5iaXRPZmZzZXQgPSAwO1xuICAgICAgICB0aGlzLmJ5dGVzID0gYnl0ZXM7XG4gICAgfVxuICAgIEJpdFN0cmVhbS5wcm90b3R5cGUucmVhZEJpdHMgPSBmdW5jdGlvbiAobnVtQml0cykge1xuICAgICAgICBpZiAobnVtQml0cyA8IDEgfHwgbnVtQml0cyA+IDMyIHx8IG51bUJpdHMgPiB0aGlzLmF2YWlsYWJsZSgpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3QgcmVhZCBcIiArIG51bUJpdHMudG9TdHJpbmcoKSArIFwiIGJpdHNcIik7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHJlc3VsdCA9IDA7XG4gICAgICAgIC8vIEZpcnN0LCByZWFkIHJlbWFpbmRlciBmcm9tIGN1cnJlbnQgYnl0ZVxuICAgICAgICBpZiAodGhpcy5iaXRPZmZzZXQgPiAwKSB7XG4gICAgICAgICAgICB2YXIgYml0c0xlZnQgPSA4IC0gdGhpcy5iaXRPZmZzZXQ7XG4gICAgICAgICAgICB2YXIgdG9SZWFkID0gbnVtQml0cyA8IGJpdHNMZWZ0ID8gbnVtQml0cyA6IGJpdHNMZWZ0O1xuICAgICAgICAgICAgdmFyIGJpdHNUb05vdFJlYWQgPSBiaXRzTGVmdCAtIHRvUmVhZDtcbiAgICAgICAgICAgIHZhciBtYXNrID0gKDB4RkYgPj4gKDggLSB0b1JlYWQpKSA8PCBiaXRzVG9Ob3RSZWFkO1xuICAgICAgICAgICAgcmVzdWx0ID0gKHRoaXMuYnl0ZXNbdGhpcy5ieXRlT2Zmc2V0XSAmIG1hc2spID4+IGJpdHNUb05vdFJlYWQ7XG4gICAgICAgICAgICBudW1CaXRzIC09IHRvUmVhZDtcbiAgICAgICAgICAgIHRoaXMuYml0T2Zmc2V0ICs9IHRvUmVhZDtcbiAgICAgICAgICAgIGlmICh0aGlzLmJpdE9mZnNldCA9PT0gOCkge1xuICAgICAgICAgICAgICAgIHRoaXMuYml0T2Zmc2V0ID0gMDtcbiAgICAgICAgICAgICAgICB0aGlzLmJ5dGVPZmZzZXQrKztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBOZXh0IHJlYWQgd2hvbGUgYnl0ZXNcbiAgICAgICAgaWYgKG51bUJpdHMgPiAwKSB7XG4gICAgICAgICAgICB3aGlsZSAobnVtQml0cyA+PSA4KSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0ID0gKHJlc3VsdCA8PCA4KSB8ICh0aGlzLmJ5dGVzW3RoaXMuYnl0ZU9mZnNldF0gJiAweEZGKTtcbiAgICAgICAgICAgICAgICB0aGlzLmJ5dGVPZmZzZXQrKztcbiAgICAgICAgICAgICAgICBudW1CaXRzIC09IDg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBGaW5hbGx5IHJlYWQgYSBwYXJ0aWFsIGJ5dGVcbiAgICAgICAgICAgIGlmIChudW1CaXRzID4gMCkge1xuICAgICAgICAgICAgICAgIHZhciBiaXRzVG9Ob3RSZWFkID0gOCAtIG51bUJpdHM7XG4gICAgICAgICAgICAgICAgdmFyIG1hc2sgPSAoMHhGRiA+PiBiaXRzVG9Ob3RSZWFkKSA8PCBiaXRzVG9Ob3RSZWFkO1xuICAgICAgICAgICAgICAgIHJlc3VsdCA9IChyZXN1bHQgPDwgbnVtQml0cykgfCAoKHRoaXMuYnl0ZXNbdGhpcy5ieXRlT2Zmc2V0XSAmIG1hc2spID4+IGJpdHNUb05vdFJlYWQpO1xuICAgICAgICAgICAgICAgIHRoaXMuYml0T2Zmc2V0ICs9IG51bUJpdHM7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9O1xuICAgIEJpdFN0cmVhbS5wcm90b3R5cGUuYXZhaWxhYmxlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gOCAqICh0aGlzLmJ5dGVzLmxlbmd0aCAtIHRoaXMuYnl0ZU9mZnNldCkgLSB0aGlzLmJpdE9mZnNldDtcbiAgICB9O1xuICAgIHJldHVybiBCaXRTdHJlYW07XG59KCkpO1xuZXhwb3J0cy5CaXRTdHJlYW0gPSBCaXRTdHJlYW07XG5cblxuLyoqKi8gfSksXG4vKiA4ICovXG4vKioqLyAoZnVuY3Rpb24obW9kdWxlLCBleHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKSB7XG5cblwidXNlIHN0cmljdFwiO1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLnNoaWZ0SklTVGFibGUgPSB7XG4gICAgMHgyMDogMHgwMDIwLFxuICAgIDB4MjE6IDB4MDAyMSxcbiAgICAweDIyOiAweDAwMjIsXG4gICAgMHgyMzogMHgwMDIzLFxuICAgIDB4MjQ6IDB4MDAyNCxcbiAgICAweDI1OiAweDAwMjUsXG4gICAgMHgyNjogMHgwMDI2LFxuICAgIDB4Mjc6IDB4MDAyNyxcbiAgICAweDI4OiAweDAwMjgsXG4gICAgMHgyOTogMHgwMDI5LFxuICAgIDB4MkE6IDB4MDAyQSxcbiAgICAweDJCOiAweDAwMkIsXG4gICAgMHgyQzogMHgwMDJDLFxuICAgIDB4MkQ6IDB4MDAyRCxcbiAgICAweDJFOiAweDAwMkUsXG4gICAgMHgyRjogMHgwMDJGLFxuICAgIDB4MzA6IDB4MDAzMCxcbiAgICAweDMxOiAweDAwMzEsXG4gICAgMHgzMjogMHgwMDMyLFxuICAgIDB4MzM6IDB4MDAzMyxcbiAgICAweDM0OiAweDAwMzQsXG4gICAgMHgzNTogMHgwMDM1LFxuICAgIDB4MzY6IDB4MDAzNixcbiAgICAweDM3OiAweDAwMzcsXG4gICAgMHgzODogMHgwMDM4LFxuICAgIDB4Mzk6IDB4MDAzOSxcbiAgICAweDNBOiAweDAwM0EsXG4gICAgMHgzQjogMHgwMDNCLFxuICAgIDB4M0M6IDB4MDAzQyxcbiAgICAweDNEOiAweDAwM0QsXG4gICAgMHgzRTogMHgwMDNFLFxuICAgIDB4M0Y6IDB4MDAzRixcbiAgICAweDQwOiAweDAwNDAsXG4gICAgMHg0MTogMHgwMDQxLFxuICAgIDB4NDI6IDB4MDA0MixcbiAgICAweDQzOiAweDAwNDMsXG4gICAgMHg0NDogMHgwMDQ0LFxuICAgIDB4NDU6IDB4MDA0NSxcbiAgICAweDQ2OiAweDAwNDYsXG4gICAgMHg0NzogMHgwMDQ3LFxuICAgIDB4NDg6IDB4MDA0OCxcbiAgICAweDQ5OiAweDAwNDksXG4gICAgMHg0QTogMHgwMDRBLFxuICAgIDB4NEI6IDB4MDA0QixcbiAgICAweDRDOiAweDAwNEMsXG4gICAgMHg0RDogMHgwMDRELFxuICAgIDB4NEU6IDB4MDA0RSxcbiAgICAweDRGOiAweDAwNEYsXG4gICAgMHg1MDogMHgwMDUwLFxuICAgIDB4NTE6IDB4MDA1MSxcbiAgICAweDUyOiAweDAwNTIsXG4gICAgMHg1MzogMHgwMDUzLFxuICAgIDB4NTQ6IDB4MDA1NCxcbiAgICAweDU1OiAweDAwNTUsXG4gICAgMHg1NjogMHgwMDU2LFxuICAgIDB4NTc6IDB4MDA1NyxcbiAgICAweDU4OiAweDAwNTgsXG4gICAgMHg1OTogMHgwMDU5LFxuICAgIDB4NUE6IDB4MDA1QSxcbiAgICAweDVCOiAweDAwNUIsXG4gICAgMHg1QzogMHgwMEE1LFxuICAgIDB4NUQ6IDB4MDA1RCxcbiAgICAweDVFOiAweDAwNUUsXG4gICAgMHg1RjogMHgwMDVGLFxuICAgIDB4NjA6IDB4MDA2MCxcbiAgICAweDYxOiAweDAwNjEsXG4gICAgMHg2MjogMHgwMDYyLFxuICAgIDB4NjM6IDB4MDA2MyxcbiAgICAweDY0OiAweDAwNjQsXG4gICAgMHg2NTogMHgwMDY1LFxuICAgIDB4NjY6IDB4MDA2NixcbiAgICAweDY3OiAweDAwNjcsXG4gICAgMHg2ODogMHgwMDY4LFxuICAgIDB4Njk6IDB4MDA2OSxcbiAgICAweDZBOiAweDAwNkEsXG4gICAgMHg2QjogMHgwMDZCLFxuICAgIDB4NkM6IDB4MDA2QyxcbiAgICAweDZEOiAweDAwNkQsXG4gICAgMHg2RTogMHgwMDZFLFxuICAgIDB4NkY6IDB4MDA2RixcbiAgICAweDcwOiAweDAwNzAsXG4gICAgMHg3MTogMHgwMDcxLFxuICAgIDB4NzI6IDB4MDA3MixcbiAgICAweDczOiAweDAwNzMsXG4gICAgMHg3NDogMHgwMDc0LFxuICAgIDB4NzU6IDB4MDA3NSxcbiAgICAweDc2OiAweDAwNzYsXG4gICAgMHg3NzogMHgwMDc3LFxuICAgIDB4Nzg6IDB4MDA3OCxcbiAgICAweDc5OiAweDAwNzksXG4gICAgMHg3QTogMHgwMDdBLFxuICAgIDB4N0I6IDB4MDA3QixcbiAgICAweDdDOiAweDAwN0MsXG4gICAgMHg3RDogMHgwMDdELFxuICAgIDB4N0U6IDB4MjAzRSxcbiAgICAweDgxNDA6IDB4MzAwMCxcbiAgICAweDgxNDE6IDB4MzAwMSxcbiAgICAweDgxNDI6IDB4MzAwMixcbiAgICAweDgxNDM6IDB4RkYwQyxcbiAgICAweDgxNDQ6IDB4RkYwRSxcbiAgICAweDgxNDU6IDB4MzBGQixcbiAgICAweDgxNDY6IDB4RkYxQSxcbiAgICAweDgxNDc6IDB4RkYxQixcbiAgICAweDgxNDg6IDB4RkYxRixcbiAgICAweDgxNDk6IDB4RkYwMSxcbiAgICAweDgxNEE6IDB4MzA5QixcbiAgICAweDgxNEI6IDB4MzA5QyxcbiAgICAweDgxNEM6IDB4MDBCNCxcbiAgICAweDgxNEQ6IDB4RkY0MCxcbiAgICAweDgxNEU6IDB4MDBBOCxcbiAgICAweDgxNEY6IDB4RkYzRSxcbiAgICAweDgxNTA6IDB4RkZFMyxcbiAgICAweDgxNTE6IDB4RkYzRixcbiAgICAweDgxNTI6IDB4MzBGRCxcbiAgICAweDgxNTM6IDB4MzBGRSxcbiAgICAweDgxNTQ6IDB4MzA5RCxcbiAgICAweDgxNTU6IDB4MzA5RSxcbiAgICAweDgxNTY6IDB4MzAwMyxcbiAgICAweDgxNTc6IDB4NEVERCxcbiAgICAweDgxNTg6IDB4MzAwNSxcbiAgICAweDgxNTk6IDB4MzAwNixcbiAgICAweDgxNUE6IDB4MzAwNyxcbiAgICAweDgxNUI6IDB4MzBGQyxcbiAgICAweDgxNUM6IDB4MjAxNSxcbiAgICAweDgxNUQ6IDB4MjAxMCxcbiAgICAweDgxNUU6IDB4RkYwRixcbiAgICAweDgxNUY6IDB4MDA1QyxcbiAgICAweDgxNjA6IDB4MzAxQyxcbiAgICAweDgxNjE6IDB4MjAxNixcbiAgICAweDgxNjI6IDB4RkY1QyxcbiAgICAweDgxNjM6IDB4MjAyNixcbiAgICAweDgxNjQ6IDB4MjAyNSxcbiAgICAweDgxNjU6IDB4MjAxOCxcbiAgICAweDgxNjY6IDB4MjAxOSxcbiAgICAweDgxNjc6IDB4MjAxQyxcbiAgICAweDgxNjg6IDB4MjAxRCxcbiAgICAweDgxNjk6IDB4RkYwOCxcbiAgICAweDgxNkE6IDB4RkYwOSxcbiAgICAweDgxNkI6IDB4MzAxNCxcbiAgICAweDgxNkM6IDB4MzAxNSxcbiAgICAweDgxNkQ6IDB4RkYzQixcbiAgICAweDgxNkU6IDB4RkYzRCxcbiAgICAweDgxNkY6IDB4RkY1QixcbiAgICAweDgxNzA6IDB4RkY1RCxcbiAgICAweDgxNzE6IDB4MzAwOCxcbiAgICAweDgxNzI6IDB4MzAwOSxcbiAgICAweDgxNzM6IDB4MzAwQSxcbiAgICAweDgxNzQ6IDB4MzAwQixcbiAgICAweDgxNzU6IDB4MzAwQyxcbiAgICAweDgxNzY6IDB4MzAwRCxcbiAgICAweDgxNzc6IDB4MzAwRSxcbiAgICAweDgxNzg6IDB4MzAwRixcbiAgICAweDgxNzk6IDB4MzAxMCxcbiAgICAweDgxN0E6IDB4MzAxMSxcbiAgICAweDgxN0I6IDB4RkYwQixcbiAgICAweDgxN0M6IDB4MjIxMixcbiAgICAweDgxN0Q6IDB4MDBCMSxcbiAgICAweDgxN0U6IDB4MDBENyxcbiAgICAweDgxODA6IDB4MDBGNyxcbiAgICAweDgxODE6IDB4RkYxRCxcbiAgICAweDgxODI6IDB4MjI2MCxcbiAgICAweDgxODM6IDB4RkYxQyxcbiAgICAweDgxODQ6IDB4RkYxRSxcbiAgICAweDgxODU6IDB4MjI2NixcbiAgICAweDgxODY6IDB4MjI2NyxcbiAgICAweDgxODc6IDB4MjIxRSxcbiAgICAweDgxODg6IDB4MjIzNCxcbiAgICAweDgxODk6IDB4MjY0MixcbiAgICAweDgxOEE6IDB4MjY0MCxcbiAgICAweDgxOEI6IDB4MDBCMCxcbiAgICAweDgxOEM6IDB4MjAzMixcbiAgICAweDgxOEQ6IDB4MjAzMyxcbiAgICAweDgxOEU6IDB4MjEwMyxcbiAgICAweDgxOEY6IDB4RkZFNSxcbiAgICAweDgxOTA6IDB4RkYwNCxcbiAgICAweDgxOTE6IDB4MDBBMixcbiAgICAweDgxOTI6IDB4MDBBMyxcbiAgICAweDgxOTM6IDB4RkYwNSxcbiAgICAweDgxOTQ6IDB4RkYwMyxcbiAgICAweDgxOTU6IDB4RkYwNixcbiAgICAweDgxOTY6IDB4RkYwQSxcbiAgICAweDgxOTc6IDB4RkYyMCxcbiAgICAweDgxOTg6IDB4MDBBNyxcbiAgICAweDgxOTk6IDB4MjYwNixcbiAgICAweDgxOUE6IDB4MjYwNSxcbiAgICAweDgxOUI6IDB4MjVDQixcbiAgICAweDgxOUM6IDB4MjVDRixcbiAgICAweDgxOUQ6IDB4MjVDRSxcbiAgICAweDgxOUU6IDB4MjVDNyxcbiAgICAweDgxOUY6IDB4MjVDNixcbiAgICAweDgxQTA6IDB4MjVBMSxcbiAgICAweDgxQTE6IDB4MjVBMCxcbiAgICAweDgxQTI6IDB4MjVCMyxcbiAgICAweDgxQTM6IDB4MjVCMixcbiAgICAweDgxQTQ6IDB4MjVCRCxcbiAgICAweDgxQTU6IDB4MjVCQyxcbiAgICAweDgxQTY6IDB4MjAzQixcbiAgICAweDgxQTc6IDB4MzAxMixcbiAgICAweDgxQTg6IDB4MjE5MixcbiAgICAweDgxQTk6IDB4MjE5MCxcbiAgICAweDgxQUE6IDB4MjE5MSxcbiAgICAweDgxQUI6IDB4MjE5MyxcbiAgICAweDgxQUM6IDB4MzAxMyxcbiAgICAweDgxQjg6IDB4MjIwOCxcbiAgICAweDgxQjk6IDB4MjIwQixcbiAgICAweDgxQkE6IDB4MjI4NixcbiAgICAweDgxQkI6IDB4MjI4NyxcbiAgICAweDgxQkM6IDB4MjI4MixcbiAgICAweDgxQkQ6IDB4MjI4MyxcbiAgICAweDgxQkU6IDB4MjIyQSxcbiAgICAweDgxQkY6IDB4MjIyOSxcbiAgICAweDgxQzg6IDB4MjIyNyxcbiAgICAweDgxQzk6IDB4MjIyOCxcbiAgICAweDgxQ0E6IDB4MDBBQyxcbiAgICAweDgxQ0I6IDB4MjFEMixcbiAgICAweDgxQ0M6IDB4MjFENCxcbiAgICAweDgxQ0Q6IDB4MjIwMCxcbiAgICAweDgxQ0U6IDB4MjIwMyxcbiAgICAweDgxREE6IDB4MjIyMCxcbiAgICAweDgxREI6IDB4MjJBNSxcbiAgICAweDgxREM6IDB4MjMxMixcbiAgICAweDgxREQ6IDB4MjIwMixcbiAgICAweDgxREU6IDB4MjIwNyxcbiAgICAweDgxREY6IDB4MjI2MSxcbiAgICAweDgxRTA6IDB4MjI1MixcbiAgICAweDgxRTE6IDB4MjI2QSxcbiAgICAweDgxRTI6IDB4MjI2QixcbiAgICAweDgxRTM6IDB4MjIxQSxcbiAgICAweDgxRTQ6IDB4MjIzRCxcbiAgICAweDgxRTU6IDB4MjIxRCxcbiAgICAweDgxRTY6IDB4MjIzNSxcbiAgICAweDgxRTc6IDB4MjIyQixcbiAgICAweDgxRTg6IDB4MjIyQyxcbiAgICAweDgxRjA6IDB4MjEyQixcbiAgICAweDgxRjE6IDB4MjAzMCxcbiAgICAweDgxRjI6IDB4MjY2RixcbiAgICAweDgxRjM6IDB4MjY2RCxcbiAgICAweDgxRjQ6IDB4MjY2QSxcbiAgICAweDgxRjU6IDB4MjAyMCxcbiAgICAweDgxRjY6IDB4MjAyMSxcbiAgICAweDgxRjc6IDB4MDBCNixcbiAgICAweDgxRkM6IDB4MjVFRixcbiAgICAweDgyNEY6IDB4RkYxMCxcbiAgICAweDgyNTA6IDB4RkYxMSxcbiAgICAweDgyNTE6IDB4RkYxMixcbiAgICAweDgyNTI6IDB4RkYxMyxcbiAgICAweDgyNTM6IDB4RkYxNCxcbiAgICAweDgyNTQ6IDB4RkYxNSxcbiAgICAweDgyNTU6IDB4RkYxNixcbiAgICAweDgyNTY6IDB4RkYxNyxcbiAgICAweDgyNTc6IDB4RkYxOCxcbiAgICAweDgyNTg6IDB4RkYxOSxcbiAgICAweDgyNjA6IDB4RkYyMSxcbiAgICAweDgyNjE6IDB4RkYyMixcbiAgICAweDgyNjI6IDB4RkYyMyxcbiAgICAweDgyNjM6IDB4RkYyNCxcbiAgICAweDgyNjQ6IDB4RkYyNSxcbiAgICAweDgyNjU6IDB4RkYyNixcbiAgICAweDgyNjY6IDB4RkYyNyxcbiAgICAweDgyNjc6IDB4RkYyOCxcbiAgICAweDgyNjg6IDB4RkYyOSxcbiAgICAweDgyNjk6IDB4RkYyQSxcbiAgICAweDgyNkE6IDB4RkYyQixcbiAgICAweDgyNkI6IDB4RkYyQyxcbiAgICAweDgyNkM6IDB4RkYyRCxcbiAgICAweDgyNkQ6IDB4RkYyRSxcbiAgICAweDgyNkU6IDB4RkYyRixcbiAgICAweDgyNkY6IDB4RkYzMCxcbiAgICAweDgyNzA6IDB4RkYzMSxcbiAgICAweDgyNzE6IDB4RkYzMixcbiAgICAweDgyNzI6IDB4RkYzMyxcbiAgICAweDgyNzM6IDB4RkYzNCxcbiAgICAweDgyNzQ6IDB4RkYzNSxcbiAgICAweDgyNzU6IDB4RkYzNixcbiAgICAweDgyNzY6IDB4RkYzNyxcbiAgICAweDgyNzc6IDB4RkYzOCxcbiAgICAweDgyNzg6IDB4RkYzOSxcbiAgICAweDgyNzk6IDB4RkYzQSxcbiAgICAweDgyODE6IDB4RkY0MSxcbiAgICAweDgyODI6IDB4RkY0MixcbiAgICAweDgyODM6IDB4RkY0MyxcbiAgICAweDgyODQ6IDB4RkY0NCxcbiAgICAweDgyODU6IDB4RkY0NSxcbiAgICAweDgyODY6IDB4RkY0NixcbiAgICAweDgyODc6IDB4RkY0NyxcbiAgICAweDgyODg6IDB4RkY0OCxcbiAgICAweDgyODk6IDB4RkY0OSxcbiAgICAweDgyOEE6IDB4RkY0QSxcbiAgICAweDgyOEI6IDB4RkY0QixcbiAgICAweDgyOEM6IDB4RkY0QyxcbiAgICAweDgyOEQ6IDB4RkY0RCxcbiAgICAweDgyOEU6IDB4RkY0RSxcbiAgICAweDgyOEY6IDB4RkY0RixcbiAgICAweDgyOTA6IDB4RkY1MCxcbiAgICAweDgyOTE6IDB4RkY1MSxcbiAgICAweDgyOTI6IDB4RkY1MixcbiAgICAweDgyOTM6IDB4RkY1MyxcbiAgICAweDgyOTQ6IDB4RkY1NCxcbiAgICAweDgyOTU6IDB4RkY1NSxcbiAgICAweDgyOTY6IDB4RkY1NixcbiAgICAweDgyOTc6IDB4RkY1NyxcbiAgICAweDgyOTg6IDB4RkY1OCxcbiAgICAweDgyOTk6IDB4RkY1OSxcbiAgICAweDgyOUE6IDB4RkY1QSxcbiAgICAweDgyOUY6IDB4MzA0MSxcbiAgICAweDgyQTA6IDB4MzA0MixcbiAgICAweDgyQTE6IDB4MzA0MyxcbiAgICAweDgyQTI6IDB4MzA0NCxcbiAgICAweDgyQTM6IDB4MzA0NSxcbiAgICAweDgyQTQ6IDB4MzA0NixcbiAgICAweDgyQTU6IDB4MzA0NyxcbiAgICAweDgyQTY6IDB4MzA0OCxcbiAgICAweDgyQTc6IDB4MzA0OSxcbiAgICAweDgyQTg6IDB4MzA0QSxcbiAgICAweDgyQTk6IDB4MzA0QixcbiAgICAweDgyQUE6IDB4MzA0QyxcbiAgICAweDgyQUI6IDB4MzA0RCxcbiAgICAweDgyQUM6IDB4MzA0RSxcbiAgICAweDgyQUQ6IDB4MzA0RixcbiAgICAweDgyQUU6IDB4MzA1MCxcbiAgICAweDgyQUY6IDB4MzA1MSxcbiAgICAweDgyQjA6IDB4MzA1MixcbiAgICAweDgyQjE6IDB4MzA1MyxcbiAgICAweDgyQjI6IDB4MzA1NCxcbiAgICAweDgyQjM6IDB4MzA1NSxcbiAgICAweDgyQjQ6IDB4MzA1NixcbiAgICAweDgyQjU6IDB4MzA1NyxcbiAgICAweDgyQjY6IDB4MzA1OCxcbiAgICAweDgyQjc6IDB4MzA1OSxcbiAgICAweDgyQjg6IDB4MzA1QSxcbiAgICAweDgyQjk6IDB4MzA1QixcbiAgICAweDgyQkE6IDB4MzA1QyxcbiAgICAweDgyQkI6IDB4MzA1RCxcbiAgICAweDgyQkM6IDB4MzA1RSxcbiAgICAweDgyQkQ6IDB4MzA1RixcbiAgICAweDgyQkU6IDB4MzA2MCxcbiAgICAweDgyQkY6IDB4MzA2MSxcbiAgICAweDgyQzA6IDB4MzA2MixcbiAgICAweDgyQzE6IDB4MzA2MyxcbiAgICAweDgyQzI6IDB4MzA2NCxcbiAgICAweDgyQzM6IDB4MzA2NSxcbiAgICAweDgyQzQ6IDB4MzA2NixcbiAgICAweDgyQzU6IDB4MzA2NyxcbiAgICAweDgyQzY6IDB4MzA2OCxcbiAgICAweDgyQzc6IDB4MzA2OSxcbiAgICAweDgyQzg6IDB4MzA2QSxcbiAgICAweDgyQzk6IDB4MzA2QixcbiAgICAweDgyQ0E6IDB4MzA2QyxcbiAgICAweDgyQ0I6IDB4MzA2RCxcbiAgICAweDgyQ0M6IDB4MzA2RSxcbiAgICAweDgyQ0Q6IDB4MzA2RixcbiAgICAweDgyQ0U6IDB4MzA3MCxcbiAgICAweDgyQ0Y6IDB4MzA3MSxcbiAgICAweDgyRDA6IDB4MzA3MixcbiAgICAweDgyRDE6IDB4MzA3MyxcbiAgICAweDgyRDI6IDB4MzA3NCxcbiAgICAweDgyRDM6IDB4MzA3NSxcbiAgICAweDgyRDQ6IDB4MzA3NixcbiAgICAweDgyRDU6IDB4MzA3NyxcbiAgICAweDgyRDY6IDB4MzA3OCxcbiAgICAweDgyRDc6IDB4MzA3OSxcbiAgICAweDgyRDg6IDB4MzA3QSxcbiAgICAweDgyRDk6IDB4MzA3QixcbiAgICAweDgyREE6IDB4MzA3QyxcbiAgICAweDgyREI6IDB4MzA3RCxcbiAgICAweDgyREM6IDB4MzA3RSxcbiAgICAweDgyREQ6IDB4MzA3RixcbiAgICAweDgyREU6IDB4MzA4MCxcbiAgICAweDgyREY6IDB4MzA4MSxcbiAgICAweDgyRTA6IDB4MzA4MixcbiAgICAweDgyRTE6IDB4MzA4MyxcbiAgICAweDgyRTI6IDB4MzA4NCxcbiAgICAweDgyRTM6IDB4MzA4NSxcbiAgICAweDgyRTQ6IDB4MzA4NixcbiAgICAweDgyRTU6IDB4MzA4NyxcbiAgICAweDgyRTY6IDB4MzA4OCxcbiAgICAweDgyRTc6IDB4MzA4OSxcbiAgICAweDgyRTg6IDB4MzA4QSxcbiAgICAweDgyRTk6IDB4MzA4QixcbiAgICAweDgyRUE6IDB4MzA4QyxcbiAgICAweDgyRUI6IDB4MzA4RCxcbiAgICAweDgyRUM6IDB4MzA4RSxcbiAgICAweDgyRUQ6IDB4MzA4RixcbiAgICAweDgyRUU6IDB4MzA5MCxcbiAgICAweDgyRUY6IDB4MzA5MSxcbiAgICAweDgyRjA6IDB4MzA5MixcbiAgICAweDgyRjE6IDB4MzA5MyxcbiAgICAweDgzNDA6IDB4MzBBMSxcbiAgICAweDgzNDE6IDB4MzBBMixcbiAgICAweDgzNDI6IDB4MzBBMyxcbiAgICAweDgzNDM6IDB4MzBBNCxcbiAgICAweDgzNDQ6IDB4MzBBNSxcbiAgICAweDgzNDU6IDB4MzBBNixcbiAgICAweDgzNDY6IDB4MzBBNyxcbiAgICAweDgzNDc6IDB4MzBBOCxcbiAgICAweDgzNDg6IDB4MzBBOSxcbiAgICAweDgzNDk6IDB4MzBBQSxcbiAgICAweDgzNEE6IDB4MzBBQixcbiAgICAweDgzNEI6IDB4MzBBQyxcbiAgICAweDgzNEM6IDB4MzBBRCxcbiAgICAweDgzNEQ6IDB4MzBBRSxcbiAgICAweDgzNEU6IDB4MzBBRixcbiAgICAweDgzNEY6IDB4MzBCMCxcbiAgICAweDgzNTA6IDB4MzBCMSxcbiAgICAweDgzNTE6IDB4MzBCMixcbiAgICAweDgzNTI6IDB4MzBCMyxcbiAgICAweDgzNTM6IDB4MzBCNCxcbiAgICAweDgzNTQ6IDB4MzBCNSxcbiAgICAweDgzNTU6IDB4MzBCNixcbiAgICAweDgzNTY6IDB4MzBCNyxcbiAgICAweDgzNTc6IDB4MzBCOCxcbiAgICAweDgzNTg6IDB4MzBCOSxcbiAgICAweDgzNTk6IDB4MzBCQSxcbiAgICAweDgzNUE6IDB4MzBCQixcbiAgICAweDgzNUI6IDB4MzBCQyxcbiAgICAweDgzNUM6IDB4MzBCRCxcbiAgICAweDgzNUQ6IDB4MzBCRSxcbiAgICAweDgzNUU6IDB4MzBCRixcbiAgICAweDgzNUY6IDB4MzBDMCxcbiAgICAweDgzNjA6IDB4MzBDMSxcbiAgICAweDgzNjE6IDB4MzBDMixcbiAgICAweDgzNjI6IDB4MzBDMyxcbiAgICAweDgzNjM6IDB4MzBDNCxcbiAgICAweDgzNjQ6IDB4MzBDNSxcbiAgICAweDgzNjU6IDB4MzBDNixcbiAgICAweDgzNjY6IDB4MzBDNyxcbiAgICAweDgzNjc6IDB4MzBDOCxcbiAgICAweDgzNjg6IDB4MzBDOSxcbiAgICAweDgzNjk6IDB4MzBDQSxcbiAgICAweDgzNkE6IDB4MzBDQixcbiAgICAweDgzNkI6IDB4MzBDQyxcbiAgICAweDgzNkM6IDB4MzBDRCxcbiAgICAweDgzNkQ6IDB4MzBDRSxcbiAgICAweDgzNkU6IDB4MzBDRixcbiAgICAweDgzNkY6IDB4MzBEMCxcbiAgICAweDgzNzA6IDB4MzBEMSxcbiAgICAweDgzNzE6IDB4MzBEMixcbiAgICAweDgzNzI6IDB4MzBEMyxcbiAgICAweDgzNzM6IDB4MzBENCxcbiAgICAweDgzNzQ6IDB4MzBENSxcbiAgICAweDgzNzU6IDB4MzBENixcbiAgICAweDgzNzY6IDB4MzBENyxcbiAgICAweDgzNzc6IDB4MzBEOCxcbiAgICAweDgzNzg6IDB4MzBEOSxcbiAgICAweDgzNzk6IDB4MzBEQSxcbiAgICAweDgzN0E6IDB4MzBEQixcbiAgICAweDgzN0I6IDB4MzBEQyxcbiAgICAweDgzN0M6IDB4MzBERCxcbiAgICAweDgzN0Q6IDB4MzBERSxcbiAgICAweDgzN0U6IDB4MzBERixcbiAgICAweDgzODA6IDB4MzBFMCxcbiAgICAweDgzODE6IDB4MzBFMSxcbiAgICAweDgzODI6IDB4MzBFMixcbiAgICAweDgzODM6IDB4MzBFMyxcbiAgICAweDgzODQ6IDB4MzBFNCxcbiAgICAweDgzODU6IDB4MzBFNSxcbiAgICAweDgzODY6IDB4MzBFNixcbiAgICAweDgzODc6IDB4MzBFNyxcbiAgICAweDgzODg6IDB4MzBFOCxcbiAgICAweDgzODk6IDB4MzBFOSxcbiAgICAweDgzOEE6IDB4MzBFQSxcbiAgICAweDgzOEI6IDB4MzBFQixcbiAgICAweDgzOEM6IDB4MzBFQyxcbiAgICAweDgzOEQ6IDB4MzBFRCxcbiAgICAweDgzOEU6IDB4MzBFRSxcbiAgICAweDgzOEY6IDB4MzBFRixcbiAgICAweDgzOTA6IDB4MzBGMCxcbiAgICAweDgzOTE6IDB4MzBGMSxcbiAgICAweDgzOTI6IDB4MzBGMixcbiAgICAweDgzOTM6IDB4MzBGMyxcbiAgICAweDgzOTQ6IDB4MzBGNCxcbiAgICAweDgzOTU6IDB4MzBGNSxcbiAgICAweDgzOTY6IDB4MzBGNixcbiAgICAweDgzOUY6IDB4MDM5MSxcbiAgICAweDgzQTA6IDB4MDM5MixcbiAgICAweDgzQTE6IDB4MDM5MyxcbiAgICAweDgzQTI6IDB4MDM5NCxcbiAgICAweDgzQTM6IDB4MDM5NSxcbiAgICAweDgzQTQ6IDB4MDM5NixcbiAgICAweDgzQTU6IDB4MDM5NyxcbiAgICAweDgzQTY6IDB4MDM5OCxcbiAgICAweDgzQTc6IDB4MDM5OSxcbiAgICAweDgzQTg6IDB4MDM5QSxcbiAgICAweDgzQTk6IDB4MDM5QixcbiAgICAweDgzQUE6IDB4MDM5QyxcbiAgICAweDgzQUI6IDB4MDM5RCxcbiAgICAweDgzQUM6IDB4MDM5RSxcbiAgICAweDgzQUQ6IDB4MDM5RixcbiAgICAweDgzQUU6IDB4MDNBMCxcbiAgICAweDgzQUY6IDB4MDNBMSxcbiAgICAweDgzQjA6IDB4MDNBMyxcbiAgICAweDgzQjE6IDB4MDNBNCxcbiAgICAweDgzQjI6IDB4MDNBNSxcbiAgICAweDgzQjM6IDB4MDNBNixcbiAgICAweDgzQjQ6IDB4MDNBNyxcbiAgICAweDgzQjU6IDB4MDNBOCxcbiAgICAweDgzQjY6IDB4MDNBOSxcbiAgICAweDgzQkY6IDB4MDNCMSxcbiAgICAweDgzQzA6IDB4MDNCMixcbiAgICAweDgzQzE6IDB4MDNCMyxcbiAgICAweDgzQzI6IDB4MDNCNCxcbiAgICAweDgzQzM6IDB4MDNCNSxcbiAgICAweDgzQzQ6IDB4MDNCNixcbiAgICAweDgzQzU6IDB4MDNCNyxcbiAgICAweDgzQzY6IDB4MDNCOCxcbiAgICAweDgzQzc6IDB4MDNCOSxcbiAgICAweDgzQzg6IDB4MDNCQSxcbiAgICAweDgzQzk6IDB4MDNCQixcbiAgICAweDgzQ0E6IDB4MDNCQyxcbiAgICAweDgzQ0I6IDB4MDNCRCxcbiAgICAweDgzQ0M6IDB4MDNCRSxcbiAgICAweDgzQ0Q6IDB4MDNCRixcbiAgICAweDgzQ0U6IDB4MDNDMCxcbiAgICAweDgzQ0Y6IDB4MDNDMSxcbiAgICAweDgzRDA6IDB4MDNDMyxcbiAgICAweDgzRDE6IDB4MDNDNCxcbiAgICAweDgzRDI6IDB4MDNDNSxcbiAgICAweDgzRDM6IDB4MDNDNixcbiAgICAweDgzRDQ6IDB4MDNDNyxcbiAgICAweDgzRDU6IDB4MDNDOCxcbiAgICAweDgzRDY6IDB4MDNDOSxcbiAgICAweDg0NDA6IDB4MDQxMCxcbiAgICAweDg0NDE6IDB4MDQxMSxcbiAgICAweDg0NDI6IDB4MDQxMixcbiAgICAweDg0NDM6IDB4MDQxMyxcbiAgICAweDg0NDQ6IDB4MDQxNCxcbiAgICAweDg0NDU6IDB4MDQxNSxcbiAgICAweDg0NDY6IDB4MDQwMSxcbiAgICAweDg0NDc6IDB4MDQxNixcbiAgICAweDg0NDg6IDB4MDQxNyxcbiAgICAweDg0NDk6IDB4MDQxOCxcbiAgICAweDg0NEE6IDB4MDQxOSxcbiAgICAweDg0NEI6IDB4MDQxQSxcbiAgICAweDg0NEM6IDB4MDQxQixcbiAgICAweDg0NEQ6IDB4MDQxQyxcbiAgICAweDg0NEU6IDB4MDQxRCxcbiAgICAweDg0NEY6IDB4MDQxRSxcbiAgICAweDg0NTA6IDB4MDQxRixcbiAgICAweDg0NTE6IDB4MDQyMCxcbiAgICAweDg0NTI6IDB4MDQyMSxcbiAgICAweDg0NTM6IDB4MDQyMixcbiAgICAweDg0NTQ6IDB4MDQyMyxcbiAgICAweDg0NTU6IDB4MDQyNCxcbiAgICAweDg0NTY6IDB4MDQyNSxcbiAgICAweDg0NTc6IDB4MDQyNixcbiAgICAweDg0NTg6IDB4MDQyNyxcbiAgICAweDg0NTk6IDB4MDQyOCxcbiAgICAweDg0NUE6IDB4MDQyOSxcbiAgICAweDg0NUI6IDB4MDQyQSxcbiAgICAweDg0NUM6IDB4MDQyQixcbiAgICAweDg0NUQ6IDB4MDQyQyxcbiAgICAweDg0NUU6IDB4MDQyRCxcbiAgICAweDg0NUY6IDB4MDQyRSxcbiAgICAweDg0NjA6IDB4MDQyRixcbiAgICAweDg0NzA6IDB4MDQzMCxcbiAgICAweDg0NzE6IDB4MDQzMSxcbiAgICAweDg0NzI6IDB4MDQzMixcbiAgICAweDg0NzM6IDB4MDQzMyxcbiAgICAweDg0NzQ6IDB4MDQzNCxcbiAgICAweDg0NzU6IDB4MDQzNSxcbiAgICAweDg0NzY6IDB4MDQ1MSxcbiAgICAweDg0Nzc6IDB4MDQzNixcbiAgICAweDg0Nzg6IDB4MDQzNyxcbiAgICAweDg0Nzk6IDB4MDQzOCxcbiAgICAweDg0N0E6IDB4MDQzOSxcbiAgICAweDg0N0I6IDB4MDQzQSxcbiAgICAweDg0N0M6IDB4MDQzQixcbiAgICAweDg0N0Q6IDB4MDQzQyxcbiAgICAweDg0N0U6IDB4MDQzRCxcbiAgICAweDg0ODA6IDB4MDQzRSxcbiAgICAweDg0ODE6IDB4MDQzRixcbiAgICAweDg0ODI6IDB4MDQ0MCxcbiAgICAweDg0ODM6IDB4MDQ0MSxcbiAgICAweDg0ODQ6IDB4MDQ0MixcbiAgICAweDg0ODU6IDB4MDQ0MyxcbiAgICAweDg0ODY6IDB4MDQ0NCxcbiAgICAweDg0ODc6IDB4MDQ0NSxcbiAgICAweDg0ODg6IDB4MDQ0NixcbiAgICAweDg0ODk6IDB4MDQ0NyxcbiAgICAweDg0OEE6IDB4MDQ0OCxcbiAgICAweDg0OEI6IDB4MDQ0OSxcbiAgICAweDg0OEM6IDB4MDQ0QSxcbiAgICAweDg0OEQ6IDB4MDQ0QixcbiAgICAweDg0OEU6IDB4MDQ0QyxcbiAgICAweDg0OEY6IDB4MDQ0RCxcbiAgICAweDg0OTA6IDB4MDQ0RSxcbiAgICAweDg0OTE6IDB4MDQ0RixcbiAgICAweDg0OUY6IDB4MjUwMCxcbiAgICAweDg0QTA6IDB4MjUwMixcbiAgICAweDg0QTE6IDB4MjUwQyxcbiAgICAweDg0QTI6IDB4MjUxMCxcbiAgICAweDg0QTM6IDB4MjUxOCxcbiAgICAweDg0QTQ6IDB4MjUxNCxcbiAgICAweDg0QTU6IDB4MjUxQyxcbiAgICAweDg0QTY6IDB4MjUyQyxcbiAgICAweDg0QTc6IDB4MjUyNCxcbiAgICAweDg0QTg6IDB4MjUzNCxcbiAgICAweDg0QTk6IDB4MjUzQyxcbiAgICAweDg0QUE6IDB4MjUwMSxcbiAgICAweDg0QUI6IDB4MjUwMyxcbiAgICAweDg0QUM6IDB4MjUwRixcbiAgICAweDg0QUQ6IDB4MjUxMyxcbiAgICAweDg0QUU6IDB4MjUxQixcbiAgICAweDg0QUY6IDB4MjUxNyxcbiAgICAweDg0QjA6IDB4MjUyMyxcbiAgICAweDg0QjE6IDB4MjUzMyxcbiAgICAweDg0QjI6IDB4MjUyQixcbiAgICAweDg0QjM6IDB4MjUzQixcbiAgICAweDg0QjQ6IDB4MjU0QixcbiAgICAweDg0QjU6IDB4MjUyMCxcbiAgICAweDg0QjY6IDB4MjUyRixcbiAgICAweDg0Qjc6IDB4MjUyOCxcbiAgICAweDg0Qjg6IDB4MjUzNyxcbiAgICAweDg0Qjk6IDB4MjUzRixcbiAgICAweDg0QkE6IDB4MjUxRCxcbiAgICAweDg0QkI6IDB4MjUzMCxcbiAgICAweDg0QkM6IDB4MjUyNSxcbiAgICAweDg0QkQ6IDB4MjUzOCxcbiAgICAweDg0QkU6IDB4MjU0MixcbiAgICAweDg4OUY6IDB4NEU5QyxcbiAgICAweDg4QTA6IDB4NTUxNixcbiAgICAweDg4QTE6IDB4NUEwMyxcbiAgICAweDg4QTI6IDB4OTYzRixcbiAgICAweDg4QTM6IDB4NTRDMCxcbiAgICAweDg4QTQ6IDB4NjExQixcbiAgICAweDg4QTU6IDB4NjMyOCxcbiAgICAweDg4QTY6IDB4NTlGNixcbiAgICAweDg4QTc6IDB4OTAyMixcbiAgICAweDg4QTg6IDB4ODQ3NSxcbiAgICAweDg4QTk6IDB4ODMxQyxcbiAgICAweDg4QUE6IDB4N0E1MCxcbiAgICAweDg4QUI6IDB4NjBBQSxcbiAgICAweDg4QUM6IDB4NjNFMSxcbiAgICAweDg4QUQ6IDB4NkUyNSxcbiAgICAweDg4QUU6IDB4NjVFRCxcbiAgICAweDg4QUY6IDB4ODQ2NixcbiAgICAweDg4QjA6IDB4ODJBNixcbiAgICAweDg4QjE6IDB4OUJGNSxcbiAgICAweDg4QjI6IDB4Njg5MyxcbiAgICAweDg4QjM6IDB4NTcyNyxcbiAgICAweDg4QjQ6IDB4NjVBMSxcbiAgICAweDg4QjU6IDB4NjI3MSxcbiAgICAweDg4QjY6IDB4NUI5QixcbiAgICAweDg4Qjc6IDB4NTlEMCxcbiAgICAweDg4Qjg6IDB4ODY3QixcbiAgICAweDg4Qjk6IDB4OThGNCxcbiAgICAweDg4QkE6IDB4N0Q2MixcbiAgICAweDg4QkI6IDB4N0RCRSxcbiAgICAweDg4QkM6IDB4OUI4RSxcbiAgICAweDg4QkQ6IDB4NjIxNixcbiAgICAweDg4QkU6IDB4N0M5RixcbiAgICAweDg4QkY6IDB4ODhCNyxcbiAgICAweDg4QzA6IDB4NUI4OSxcbiAgICAweDg4QzE6IDB4NUVCNSxcbiAgICAweDg4QzI6IDB4NjMwOSxcbiAgICAweDg4QzM6IDB4NjY5NyxcbiAgICAweDg4QzQ6IDB4Njg0OCxcbiAgICAweDg4QzU6IDB4OTVDNyxcbiAgICAweDg4QzY6IDB4OTc4RCxcbiAgICAweDg4Qzc6IDB4Njc0RixcbiAgICAweDg4Qzg6IDB4NEVFNSxcbiAgICAweDg4Qzk6IDB4NEYwQSxcbiAgICAweDg4Q0E6IDB4NEY0RCxcbiAgICAweDg4Q0I6IDB4NEY5RCxcbiAgICAweDg4Q0M6IDB4NTA0OSxcbiAgICAweDg4Q0Q6IDB4NTZGMixcbiAgICAweDg4Q0U6IDB4NTkzNyxcbiAgICAweDg4Q0Y6IDB4NTlENCxcbiAgICAweDg4RDA6IDB4NUEwMSxcbiAgICAweDg4RDE6IDB4NUMwOSxcbiAgICAweDg4RDI6IDB4NjBERixcbiAgICAweDg4RDM6IDB4NjEwRixcbiAgICAweDg4RDQ6IDB4NjE3MCxcbiAgICAweDg4RDU6IDB4NjYxMyxcbiAgICAweDg4RDY6IDB4NjkwNSxcbiAgICAweDg4RDc6IDB4NzBCQSxcbiAgICAweDg4RDg6IDB4NzU0RixcbiAgICAweDg4RDk6IDB4NzU3MCxcbiAgICAweDg4REE6IDB4NzlGQixcbiAgICAweDg4REI6IDB4N0RBRCxcbiAgICAweDg4REM6IDB4N0RFRixcbiAgICAweDg4REQ6IDB4ODBDMyxcbiAgICAweDg4REU6IDB4ODQwRSxcbiAgICAweDg4REY6IDB4ODg2MyxcbiAgICAweDg4RTA6IDB4OEIwMixcbiAgICAweDg4RTE6IDB4OTA1NSxcbiAgICAweDg4RTI6IDB4OTA3QSxcbiAgICAweDg4RTM6IDB4NTMzQixcbiAgICAweDg4RTQ6IDB4NEU5NSxcbiAgICAweDg4RTU6IDB4NEVBNSxcbiAgICAweDg4RTY6IDB4NTdERixcbiAgICAweDg4RTc6IDB4ODBCMixcbiAgICAweDg4RTg6IDB4OTBDMSxcbiAgICAweDg4RTk6IDB4NzhFRixcbiAgICAweDg4RUE6IDB4NEUwMCxcbiAgICAweDg4RUI6IDB4NThGMSxcbiAgICAweDg4RUM6IDB4NkVBMixcbiAgICAweDg4RUQ6IDB4OTAzOCxcbiAgICAweDg4RUU6IDB4N0EzMixcbiAgICAweDg4RUY6IDB4ODMyOCxcbiAgICAweDg4RjA6IDB4ODI4QixcbiAgICAweDg4RjE6IDB4OUMyRixcbiAgICAweDg4RjI6IDB4NTE0MSxcbiAgICAweDg4RjM6IDB4NTM3MCxcbiAgICAweDg4RjQ6IDB4NTRCRCxcbiAgICAweDg4RjU6IDB4NTRFMSxcbiAgICAweDg4RjY6IDB4NTZFMCxcbiAgICAweDg4Rjc6IDB4NTlGQixcbiAgICAweDg4Rjg6IDB4NUYxNSxcbiAgICAweDg4Rjk6IDB4OThGMixcbiAgICAweDg4RkE6IDB4NkRFQixcbiAgICAweDg4RkI6IDB4ODBFNCxcbiAgICAweDg4RkM6IDB4ODUyRCxcbiAgICAweDg5NDA6IDB4OTY2MixcbiAgICAweDg5NDE6IDB4OTY3MCxcbiAgICAweDg5NDI6IDB4OTZBMCxcbiAgICAweDg5NDM6IDB4OTdGQixcbiAgICAweDg5NDQ6IDB4NTQwQixcbiAgICAweDg5NDU6IDB4NTNGMyxcbiAgICAweDg5NDY6IDB4NUI4NyxcbiAgICAweDg5NDc6IDB4NzBDRixcbiAgICAweDg5NDg6IDB4N0ZCRCxcbiAgICAweDg5NDk6IDB4OEZDMixcbiAgICAweDg5NEE6IDB4OTZFOCxcbiAgICAweDg5NEI6IDB4NTM2RixcbiAgICAweDg5NEM6IDB4OUQ1QyxcbiAgICAweDg5NEQ6IDB4N0FCQSxcbiAgICAweDg5NEU6IDB4NEUxMSxcbiAgICAweDg5NEY6IDB4Nzg5MyxcbiAgICAweDg5NTA6IDB4ODFGQyxcbiAgICAweDg5NTE6IDB4NkUyNixcbiAgICAweDg5NTI6IDB4NTYxOCxcbiAgICAweDg5NTM6IDB4NTUwNCxcbiAgICAweDg5NTQ6IDB4NkIxRCxcbiAgICAweDg5NTU6IDB4ODUxQSxcbiAgICAweDg5NTY6IDB4OUMzQixcbiAgICAweDg5NTc6IDB4NTlFNSxcbiAgICAweDg5NTg6IDB4NTNBOSxcbiAgICAweDg5NTk6IDB4NkQ2NixcbiAgICAweDg5NUE6IDB4NzREQyxcbiAgICAweDg5NUI6IDB4OTU4RixcbiAgICAweDg5NUM6IDB4NTY0MixcbiAgICAweDg5NUQ6IDB4NEU5MSxcbiAgICAweDg5NUU6IDB4OTA0QixcbiAgICAweDg5NUY6IDB4OTZGMixcbiAgICAweDg5NjA6IDB4ODM0RixcbiAgICAweDg5NjE6IDB4OTkwQyxcbiAgICAweDg5NjI6IDB4NTNFMSxcbiAgICAweDg5NjM6IDB4NTVCNixcbiAgICAweDg5NjQ6IDB4NUIzMCxcbiAgICAweDg5NjU6IDB4NUY3MSxcbiAgICAweDg5NjY6IDB4NjYyMCxcbiAgICAweDg5Njc6IDB4NjZGMyxcbiAgICAweDg5Njg6IDB4NjgwNCxcbiAgICAweDg5Njk6IDB4NkMzOCxcbiAgICAweDg5NkE6IDB4NkNGMyxcbiAgICAweDg5NkI6IDB4NkQyOSxcbiAgICAweDg5NkM6IDB4NzQ1QixcbiAgICAweDg5NkQ6IDB4NzZDOCxcbiAgICAweDg5NkU6IDB4N0E0RSxcbiAgICAweDg5NkY6IDB4OTgzNCxcbiAgICAweDg5NzA6IDB4ODJGMSxcbiAgICAweDg5NzE6IDB4ODg1QixcbiAgICAweDg5NzI6IDB4OEE2MCxcbiAgICAweDg5NzM6IDB4OTJFRCxcbiAgICAweDg5NzQ6IDB4NkRCMixcbiAgICAweDg5NzU6IDB4NzVBQixcbiAgICAweDg5NzY6IDB4NzZDQSxcbiAgICAweDg5Nzc6IDB4OTlDNSxcbiAgICAweDg5Nzg6IDB4NjBBNixcbiAgICAweDg5Nzk6IDB4OEIwMSxcbiAgICAweDg5N0E6IDB4OEQ4QSxcbiAgICAweDg5N0I6IDB4OTVCMixcbiAgICAweDg5N0M6IDB4Njk4RSxcbiAgICAweDg5N0Q6IDB4NTNBRCxcbiAgICAweDg5N0U6IDB4NTE4NixcbiAgICAweDg5ODA6IDB4NTcxMixcbiAgICAweDg5ODE6IDB4NTgzMCxcbiAgICAweDg5ODI6IDB4NTk0NCxcbiAgICAweDg5ODM6IDB4NUJCNCxcbiAgICAweDg5ODQ6IDB4NUVGNixcbiAgICAweDg5ODU6IDB4NjAyOCxcbiAgICAweDg5ODY6IDB4NjNBOSxcbiAgICAweDg5ODc6IDB4NjNGNCxcbiAgICAweDg5ODg6IDB4NkNCRixcbiAgICAweDg5ODk6IDB4NkYxNCxcbiAgICAweDg5OEE6IDB4NzA4RSxcbiAgICAweDg5OEI6IDB4NzExNCxcbiAgICAweDg5OEM6IDB4NzE1OSxcbiAgICAweDg5OEQ6IDB4NzFENSxcbiAgICAweDg5OEU6IDB4NzMzRixcbiAgICAweDg5OEY6IDB4N0UwMSxcbiAgICAweDg5OTA6IDB4ODI3NixcbiAgICAweDg5OTE6IDB4ODJEMSxcbiAgICAweDg5OTI6IDB4ODU5NyxcbiAgICAweDg5OTM6IDB4OTA2MCxcbiAgICAweDg5OTQ6IDB4OTI1QixcbiAgICAweDg5OTU6IDB4OUQxQixcbiAgICAweDg5OTY6IDB4NTg2OSxcbiAgICAweDg5OTc6IDB4NjVCQyxcbiAgICAweDg5OTg6IDB4NkM1QSxcbiAgICAweDg5OTk6IDB4NzUyNSxcbiAgICAweDg5OUE6IDB4NTFGOSxcbiAgICAweDg5OUI6IDB4NTkyRSxcbiAgICAweDg5OUM6IDB4NTk2NSxcbiAgICAweDg5OUQ6IDB4NUY4MCxcbiAgICAweDg5OUU6IDB4NUZEQyxcbiAgICAweDg5OUY6IDB4NjJCQyxcbiAgICAweDg5QTA6IDB4NjVGQSxcbiAgICAweDg5QTE6IDB4NkEyQSxcbiAgICAweDg5QTI6IDB4NkIyNyxcbiAgICAweDg5QTM6IDB4NkJCNCxcbiAgICAweDg5QTQ6IDB4NzM4QixcbiAgICAweDg5QTU6IDB4N0ZDMSxcbiAgICAweDg5QTY6IDB4ODk1NixcbiAgICAweDg5QTc6IDB4OUQyQyxcbiAgICAweDg5QTg6IDB4OUQwRSxcbiAgICAweDg5QTk6IDB4OUVDNCxcbiAgICAweDg5QUE6IDB4NUNBMSxcbiAgICAweDg5QUI6IDB4NkM5NixcbiAgICAweDg5QUM6IDB4ODM3QixcbiAgICAweDg5QUQ6IDB4NTEwNCxcbiAgICAweDg5QUU6IDB4NUM0QixcbiAgICAweDg5QUY6IDB4NjFCNixcbiAgICAweDg5QjA6IDB4ODFDNixcbiAgICAweDg5QjE6IDB4Njg3NixcbiAgICAweDg5QjI6IDB4NzI2MSxcbiAgICAweDg5QjM6IDB4NEU1OSxcbiAgICAweDg5QjQ6IDB4NEZGQSxcbiAgICAweDg5QjU6IDB4NTM3OCxcbiAgICAweDg5QjY6IDB4NjA2OSxcbiAgICAweDg5Qjc6IDB4NkUyOSxcbiAgICAweDg5Qjg6IDB4N0E0RixcbiAgICAweDg5Qjk6IDB4OTdGMyxcbiAgICAweDg5QkE6IDB4NEUwQixcbiAgICAweDg5QkI6IDB4NTMxNixcbiAgICAweDg5QkM6IDB4NEVFRSxcbiAgICAweDg5QkQ6IDB4NEY1NSxcbiAgICAweDg5QkU6IDB4NEYzRCxcbiAgICAweDg5QkY6IDB4NEZBMSxcbiAgICAweDg5QzA6IDB4NEY3MyxcbiAgICAweDg5QzE6IDB4NTJBMCxcbiAgICAweDg5QzI6IDB4NTNFRixcbiAgICAweDg5QzM6IDB4NTYwOSxcbiAgICAweDg5QzQ6IDB4NTkwRixcbiAgICAweDg5QzU6IDB4NUFDMSxcbiAgICAweDg5QzY6IDB4NUJCNixcbiAgICAweDg5Qzc6IDB4NUJFMSxcbiAgICAweDg5Qzg6IDB4NzlEMSxcbiAgICAweDg5Qzk6IDB4NjY4NyxcbiAgICAweDg5Q0E6IDB4Njc5QyxcbiAgICAweDg5Q0I6IDB4NjdCNixcbiAgICAweDg5Q0M6IDB4NkI0QyxcbiAgICAweDg5Q0Q6IDB4NkNCMyxcbiAgICAweDg5Q0U6IDB4NzA2QixcbiAgICAweDg5Q0Y6IDB4NzNDMixcbiAgICAweDg5RDA6IDB4Nzk4RCxcbiAgICAweDg5RDE6IDB4NzlCRSxcbiAgICAweDg5RDI6IDB4N0EzQyxcbiAgICAweDg5RDM6IDB4N0I4NyxcbiAgICAweDg5RDQ6IDB4ODJCMSxcbiAgICAweDg5RDU6IDB4ODJEQixcbiAgICAweDg5RDY6IDB4ODMwNCxcbiAgICAweDg5RDc6IDB4ODM3NyxcbiAgICAweDg5RDg6IDB4ODNFRixcbiAgICAweDg5RDk6IDB4ODNEMyxcbiAgICAweDg5REE6IDB4ODc2NixcbiAgICAweDg5REI6IDB4OEFCMixcbiAgICAweDg5REM6IDB4NTYyOSxcbiAgICAweDg5REQ6IDB4OENBOCxcbiAgICAweDg5REU6IDB4OEZFNixcbiAgICAweDg5REY6IDB4OTA0RSxcbiAgICAweDg5RTA6IDB4OTcxRSxcbiAgICAweDg5RTE6IDB4ODY4QSxcbiAgICAweDg5RTI6IDB4NEZDNCxcbiAgICAweDg5RTM6IDB4NUNFOCxcbiAgICAweDg5RTQ6IDB4NjIxMSxcbiAgICAweDg5RTU6IDB4NzI1OSxcbiAgICAweDg5RTY6IDB4NzUzQixcbiAgICAweDg5RTc6IDB4ODFFNSxcbiAgICAweDg5RTg6IDB4ODJCRCxcbiAgICAweDg5RTk6IDB4ODZGRSxcbiAgICAweDg5RUE6IDB4OENDMCxcbiAgICAweDg5RUI6IDB4OTZDNSxcbiAgICAweDg5RUM6IDB4OTkxMyxcbiAgICAweDg5RUQ6IDB4OTlENSxcbiAgICAweDg5RUU6IDB4NEVDQixcbiAgICAweDg5RUY6IDB4NEYxQSxcbiAgICAweDg5RjA6IDB4ODlFMyxcbiAgICAweDg5RjE6IDB4NTZERSxcbiAgICAweDg5RjI6IDB4NTg0QSxcbiAgICAweDg5RjM6IDB4NThDQSxcbiAgICAweDg5RjQ6IDB4NUVGQixcbiAgICAweDg5RjU6IDB4NUZFQixcbiAgICAweDg5RjY6IDB4NjAyQSxcbiAgICAweDg5Rjc6IDB4NjA5NCxcbiAgICAweDg5Rjg6IDB4NjA2MixcbiAgICAweDg5Rjk6IDB4NjFEMCxcbiAgICAweDg5RkE6IDB4NjIxMixcbiAgICAweDg5RkI6IDB4NjJEMCxcbiAgICAweDg5RkM6IDB4NjUzOSxcbiAgICAweDhBNDA6IDB4OUI0MSxcbiAgICAweDhBNDE6IDB4NjY2NixcbiAgICAweDhBNDI6IDB4NjhCMCxcbiAgICAweDhBNDM6IDB4NkQ3NyxcbiAgICAweDhBNDQ6IDB4NzA3MCxcbiAgICAweDhBNDU6IDB4NzU0QyxcbiAgICAweDhBNDY6IDB4NzY4NixcbiAgICAweDhBNDc6IDB4N0Q3NSxcbiAgICAweDhBNDg6IDB4ODJBNSxcbiAgICAweDhBNDk6IDB4ODdGOSxcbiAgICAweDhBNEE6IDB4OTU4QixcbiAgICAweDhBNEI6IDB4OTY4RSxcbiAgICAweDhBNEM6IDB4OEM5RCxcbiAgICAweDhBNEQ6IDB4NTFGMSxcbiAgICAweDhBNEU6IDB4NTJCRSxcbiAgICAweDhBNEY6IDB4NTkxNixcbiAgICAweDhBNTA6IDB4NTRCMyxcbiAgICAweDhBNTE6IDB4NUJCMyxcbiAgICAweDhBNTI6IDB4NUQxNixcbiAgICAweDhBNTM6IDB4NjE2OCxcbiAgICAweDhBNTQ6IDB4Njk4MixcbiAgICAweDhBNTU6IDB4NkRBRixcbiAgICAweDhBNTY6IDB4Nzg4RCxcbiAgICAweDhBNTc6IDB4ODRDQixcbiAgICAweDhBNTg6IDB4ODg1NyxcbiAgICAweDhBNTk6IDB4OEE3MixcbiAgICAweDhBNUE6IDB4OTNBNyxcbiAgICAweDhBNUI6IDB4OUFCOCxcbiAgICAweDhBNUM6IDB4NkQ2QyxcbiAgICAweDhBNUQ6IDB4OTlBOCxcbiAgICAweDhBNUU6IDB4ODZEOSxcbiAgICAweDhBNUY6IDB4NTdBMyxcbiAgICAweDhBNjA6IDB4NjdGRixcbiAgICAweDhBNjE6IDB4ODZDRSxcbiAgICAweDhBNjI6IDB4OTIwRSxcbiAgICAweDhBNjM6IDB4NTI4MyxcbiAgICAweDhBNjQ6IDB4NTY4NyxcbiAgICAweDhBNjU6IDB4NTQwNCxcbiAgICAweDhBNjY6IDB4NUVEMyxcbiAgICAweDhBNjc6IDB4NjJFMSxcbiAgICAweDhBNjg6IDB4NjRCOSxcbiAgICAweDhBNjk6IDB4NjgzQyxcbiAgICAweDhBNkE6IDB4NjgzOCxcbiAgICAweDhBNkI6IDB4NkJCQixcbiAgICAweDhBNkM6IDB4NzM3MixcbiAgICAweDhBNkQ6IDB4NzhCQSxcbiAgICAweDhBNkU6IDB4N0E2QixcbiAgICAweDhBNkY6IDB4ODk5QSxcbiAgICAweDhBNzA6IDB4ODlEMixcbiAgICAweDhBNzE6IDB4OEQ2QixcbiAgICAweDhBNzI6IDB4OEYwMyxcbiAgICAweDhBNzM6IDB4OTBFRCxcbiAgICAweDhBNzQ6IDB4OTVBMyxcbiAgICAweDhBNzU6IDB4OTY5NCxcbiAgICAweDhBNzY6IDB4OTc2OSxcbiAgICAweDhBNzc6IDB4NUI2NixcbiAgICAweDhBNzg6IDB4NUNCMyxcbiAgICAweDhBNzk6IDB4Njk3RCxcbiAgICAweDhBN0E6IDB4OTg0RCxcbiAgICAweDhBN0I6IDB4OTg0RSxcbiAgICAweDhBN0M6IDB4NjM5QixcbiAgICAweDhBN0Q6IDB4N0IyMCxcbiAgICAweDhBN0U6IDB4NkEyQixcbiAgICAweDhBODA6IDB4NkE3RixcbiAgICAweDhBODE6IDB4NjhCNixcbiAgICAweDhBODI6IDB4OUMwRCxcbiAgICAweDhBODM6IDB4NkY1RixcbiAgICAweDhBODQ6IDB4NTI3MixcbiAgICAweDhBODU6IDB4NTU5RCxcbiAgICAweDhBODY6IDB4NjA3MCxcbiAgICAweDhBODc6IDB4NjJFQyxcbiAgICAweDhBODg6IDB4NkQzQixcbiAgICAweDhBODk6IDB4NkUwNyxcbiAgICAweDhBOEE6IDB4NkVEMSxcbiAgICAweDhBOEI6IDB4ODQ1QixcbiAgICAweDhBOEM6IDB4ODkxMCxcbiAgICAweDhBOEQ6IDB4OEY0NCxcbiAgICAweDhBOEU6IDB4NEUxNCxcbiAgICAweDhBOEY6IDB4OUMzOSxcbiAgICAweDhBOTA6IDB4NTNGNixcbiAgICAweDhBOTE6IDB4NjkxQixcbiAgICAweDhBOTI6IDB4NkEzQSxcbiAgICAweDhBOTM6IDB4OTc4NCxcbiAgICAweDhBOTQ6IDB4NjgyQSxcbiAgICAweDhBOTU6IDB4NTE1QyxcbiAgICAweDhBOTY6IDB4N0FDMyxcbiAgICAweDhBOTc6IDB4ODRCMixcbiAgICAweDhBOTg6IDB4OTFEQyxcbiAgICAweDhBOTk6IDB4OTM4QyxcbiAgICAweDhBOUE6IDB4NTY1QixcbiAgICAweDhBOUI6IDB4OUQyOCxcbiAgICAweDhBOUM6IDB4NjgyMixcbiAgICAweDhBOUQ6IDB4ODMwNSxcbiAgICAweDhBOUU6IDB4ODQzMSxcbiAgICAweDhBOUY6IDB4N0NBNSxcbiAgICAweDhBQTA6IDB4NTIwOCxcbiAgICAweDhBQTE6IDB4ODJDNSxcbiAgICAweDhBQTI6IDB4NzRFNixcbiAgICAweDhBQTM6IDB4NEU3RSxcbiAgICAweDhBQTQ6IDB4NEY4MyxcbiAgICAweDhBQTU6IDB4NTFBMCxcbiAgICAweDhBQTY6IDB4NUJEMixcbiAgICAweDhBQTc6IDB4NTIwQSxcbiAgICAweDhBQTg6IDB4NTJEOCxcbiAgICAweDhBQTk6IDB4NTJFNyxcbiAgICAweDhBQUE6IDB4NURGQixcbiAgICAweDhBQUI6IDB4NTU5QSxcbiAgICAweDhBQUM6IDB4NTgyQSxcbiAgICAweDhBQUQ6IDB4NTlFNixcbiAgICAweDhBQUU6IDB4NUI4QyxcbiAgICAweDhBQUY6IDB4NUI5OCxcbiAgICAweDhBQjA6IDB4NUJEQixcbiAgICAweDhBQjE6IDB4NUU3MixcbiAgICAweDhBQjI6IDB4NUU3OSxcbiAgICAweDhBQjM6IDB4NjBBMyxcbiAgICAweDhBQjQ6IDB4NjExRixcbiAgICAweDhBQjU6IDB4NjE2MyxcbiAgICAweDhBQjY6IDB4NjFCRSxcbiAgICAweDhBQjc6IDB4NjNEQixcbiAgICAweDhBQjg6IDB4NjU2MixcbiAgICAweDhBQjk6IDB4NjdEMSxcbiAgICAweDhBQkE6IDB4Njg1MyxcbiAgICAweDhBQkI6IDB4NjhGQSxcbiAgICAweDhBQkM6IDB4NkIzRSxcbiAgICAweDhBQkQ6IDB4NkI1MyxcbiAgICAweDhBQkU6IDB4NkM1NyxcbiAgICAweDhBQkY6IDB4NkYyMixcbiAgICAweDhBQzA6IDB4NkY5NyxcbiAgICAweDhBQzE6IDB4NkY0NSxcbiAgICAweDhBQzI6IDB4NzRCMCxcbiAgICAweDhBQzM6IDB4NzUxOCxcbiAgICAweDhBQzQ6IDB4NzZFMyxcbiAgICAweDhBQzU6IDB4NzcwQixcbiAgICAweDhBQzY6IDB4N0FGRixcbiAgICAweDhBQzc6IDB4N0JBMSxcbiAgICAweDhBQzg6IDB4N0MyMSxcbiAgICAweDhBQzk6IDB4N0RFOSxcbiAgICAweDhBQ0E6IDB4N0YzNixcbiAgICAweDhBQ0I6IDB4N0ZGMCxcbiAgICAweDhBQ0M6IDB4ODA5RCxcbiAgICAweDhBQ0Q6IDB4ODI2NixcbiAgICAweDhBQ0U6IDB4ODM5RSxcbiAgICAweDhBQ0Y6IDB4ODlCMyxcbiAgICAweDhBRDA6IDB4OEFDQyxcbiAgICAweDhBRDE6IDB4OENBQixcbiAgICAweDhBRDI6IDB4OTA4NCxcbiAgICAweDhBRDM6IDB4OTQ1MSxcbiAgICAweDhBRDQ6IDB4OTU5MyxcbiAgICAweDhBRDU6IDB4OTU5MSxcbiAgICAweDhBRDY6IDB4OTVBMixcbiAgICAweDhBRDc6IDB4OTY2NSxcbiAgICAweDhBRDg6IDB4OTdEMyxcbiAgICAweDhBRDk6IDB4OTkyOCxcbiAgICAweDhBREE6IDB4ODIxOCxcbiAgICAweDhBREI6IDB4NEUzOCxcbiAgICAweDhBREM6IDB4NTQyQixcbiAgICAweDhBREQ6IDB4NUNCOCxcbiAgICAweDhBREU6IDB4NURDQyxcbiAgICAweDhBREY6IDB4NzNBOSxcbiAgICAweDhBRTA6IDB4NzY0QyxcbiAgICAweDhBRTE6IDB4NzczQyxcbiAgICAweDhBRTI6IDB4NUNBOSxcbiAgICAweDhBRTM6IDB4N0ZFQixcbiAgICAweDhBRTQ6IDB4OEQwQixcbiAgICAweDhBRTU6IDB4OTZDMSxcbiAgICAweDhBRTY6IDB4OTgxMSxcbiAgICAweDhBRTc6IDB4OTg1NCxcbiAgICAweDhBRTg6IDB4OTg1OCxcbiAgICAweDhBRTk6IDB4NEYwMSxcbiAgICAweDhBRUE6IDB4NEYwRSxcbiAgICAweDhBRUI6IDB4NTM3MSxcbiAgICAweDhBRUM6IDB4NTU5QyxcbiAgICAweDhBRUQ6IDB4NTY2OCxcbiAgICAweDhBRUU6IDB4NTdGQSxcbiAgICAweDhBRUY6IDB4NTk0NyxcbiAgICAweDhBRjA6IDB4NUIwOSxcbiAgICAweDhBRjE6IDB4NUJDNCxcbiAgICAweDhBRjI6IDB4NUM5MCxcbiAgICAweDhBRjM6IDB4NUUwQyxcbiAgICAweDhBRjQ6IDB4NUU3RSxcbiAgICAweDhBRjU6IDB4NUZDQyxcbiAgICAweDhBRjY6IDB4NjNFRSxcbiAgICAweDhBRjc6IDB4NjczQSxcbiAgICAweDhBRjg6IDB4NjVENyxcbiAgICAweDhBRjk6IDB4NjVFMixcbiAgICAweDhBRkE6IDB4NjcxRixcbiAgICAweDhBRkI6IDB4NjhDQixcbiAgICAweDhBRkM6IDB4NjhDNCxcbiAgICAweDhCNDA6IDB4NkE1RixcbiAgICAweDhCNDE6IDB4NUUzMCxcbiAgICAweDhCNDI6IDB4NkJDNSxcbiAgICAweDhCNDM6IDB4NkMxNyxcbiAgICAweDhCNDQ6IDB4NkM3RCxcbiAgICAweDhCNDU6IDB4NzU3RixcbiAgICAweDhCNDY6IDB4Nzk0OCxcbiAgICAweDhCNDc6IDB4NUI2MyxcbiAgICAweDhCNDg6IDB4N0EwMCxcbiAgICAweDhCNDk6IDB4N0QwMCxcbiAgICAweDhCNEE6IDB4NUZCRCxcbiAgICAweDhCNEI6IDB4ODk4RixcbiAgICAweDhCNEM6IDB4OEExOCxcbiAgICAweDhCNEQ6IDB4OENCNCxcbiAgICAweDhCNEU6IDB4OEQ3NyxcbiAgICAweDhCNEY6IDB4OEVDQyxcbiAgICAweDhCNTA6IDB4OEYxRCxcbiAgICAweDhCNTE6IDB4OThFMixcbiAgICAweDhCNTI6IDB4OUEwRSxcbiAgICAweDhCNTM6IDB4OUIzQyxcbiAgICAweDhCNTQ6IDB4NEU4MCxcbiAgICAweDhCNTU6IDB4NTA3RCxcbiAgICAweDhCNTY6IDB4NTEwMCxcbiAgICAweDhCNTc6IDB4NTk5MyxcbiAgICAweDhCNTg6IDB4NUI5QyxcbiAgICAweDhCNTk6IDB4NjIyRixcbiAgICAweDhCNUE6IDB4NjI4MCxcbiAgICAweDhCNUI6IDB4NjRFQyxcbiAgICAweDhCNUM6IDB4NkIzQSxcbiAgICAweDhCNUQ6IDB4NzJBMCxcbiAgICAweDhCNUU6IDB4NzU5MSxcbiAgICAweDhCNUY6IDB4Nzk0NyxcbiAgICAweDhCNjA6IDB4N0ZBOSxcbiAgICAweDhCNjE6IDB4ODdGQixcbiAgICAweDhCNjI6IDB4OEFCQyxcbiAgICAweDhCNjM6IDB4OEI3MCxcbiAgICAweDhCNjQ6IDB4NjNBQyxcbiAgICAweDhCNjU6IDB4ODNDQSxcbiAgICAweDhCNjY6IDB4OTdBMCxcbiAgICAweDhCNjc6IDB4NTQwOSxcbiAgICAweDhCNjg6IDB4NTQwMyxcbiAgICAweDhCNjk6IDB4NTVBQixcbiAgICAweDhCNkE6IDB4Njg1NCxcbiAgICAweDhCNkI6IDB4NkE1OCxcbiAgICAweDhCNkM6IDB4OEE3MCxcbiAgICAweDhCNkQ6IDB4NzgyNyxcbiAgICAweDhCNkU6IDB4Njc3NSxcbiAgICAweDhCNkY6IDB4OUVDRCxcbiAgICAweDhCNzA6IDB4NTM3NCxcbiAgICAweDhCNzE6IDB4NUJBMixcbiAgICAweDhCNzI6IDB4ODExQSxcbiAgICAweDhCNzM6IDB4ODY1MCxcbiAgICAweDhCNzQ6IDB4OTAwNixcbiAgICAweDhCNzU6IDB4NEUxOCxcbiAgICAweDhCNzY6IDB4NEU0NSxcbiAgICAweDhCNzc6IDB4NEVDNyxcbiAgICAweDhCNzg6IDB4NEYxMSxcbiAgICAweDhCNzk6IDB4NTNDQSxcbiAgICAweDhCN0E6IDB4NTQzOCxcbiAgICAweDhCN0I6IDB4NUJBRSxcbiAgICAweDhCN0M6IDB4NUYxMyxcbiAgICAweDhCN0Q6IDB4NjAyNSxcbiAgICAweDhCN0U6IDB4NjU1MSxcbiAgICAweDhCODA6IDB4NjczRCxcbiAgICAweDhCODE6IDB4NkM0MixcbiAgICAweDhCODI6IDB4NkM3MixcbiAgICAweDhCODM6IDB4NkNFMyxcbiAgICAweDhCODQ6IDB4NzA3OCxcbiAgICAweDhCODU6IDB4NzQwMyxcbiAgICAweDhCODY6IDB4N0E3NixcbiAgICAweDhCODc6IDB4N0FBRSxcbiAgICAweDhCODg6IDB4N0IwOCxcbiAgICAweDhCODk6IDB4N0QxQSxcbiAgICAweDhCOEE6IDB4N0NGRSxcbiAgICAweDhCOEI6IDB4N0Q2NixcbiAgICAweDhCOEM6IDB4NjVFNyxcbiAgICAweDhCOEQ6IDB4NzI1QixcbiAgICAweDhCOEU6IDB4NTNCQixcbiAgICAweDhCOEY6IDB4NUM0NSxcbiAgICAweDhCOTA6IDB4NURFOCxcbiAgICAweDhCOTE6IDB4NjJEMixcbiAgICAweDhCOTI6IDB4NjJFMCxcbiAgICAweDhCOTM6IDB4NjMxOSxcbiAgICAweDhCOTQ6IDB4NkUyMCxcbiAgICAweDhCOTU6IDB4ODY1QSxcbiAgICAweDhCOTY6IDB4OEEzMSxcbiAgICAweDhCOTc6IDB4OERERCxcbiAgICAweDhCOTg6IDB4OTJGOCxcbiAgICAweDhCOTk6IDB4NkYwMSxcbiAgICAweDhCOUE6IDB4NzlBNixcbiAgICAweDhCOUI6IDB4OUI1QSxcbiAgICAweDhCOUM6IDB4NEVBOCxcbiAgICAweDhCOUQ6IDB4NEVBQixcbiAgICAweDhCOUU6IDB4NEVBQyxcbiAgICAweDhCOUY6IDB4NEY5QixcbiAgICAweDhCQTA6IDB4NEZBMCxcbiAgICAweDhCQTE6IDB4NTBEMSxcbiAgICAweDhCQTI6IDB4NTE0NyxcbiAgICAweDhCQTM6IDB4N0FGNixcbiAgICAweDhCQTQ6IDB4NTE3MSxcbiAgICAweDhCQTU6IDB4NTFGNixcbiAgICAweDhCQTY6IDB4NTM1NCxcbiAgICAweDhCQTc6IDB4NTMyMSxcbiAgICAweDhCQTg6IDB4NTM3RixcbiAgICAweDhCQTk6IDB4NTNFQixcbiAgICAweDhCQUE6IDB4NTVBQyxcbiAgICAweDhCQUI6IDB4NTg4MyxcbiAgICAweDhCQUM6IDB4NUNFMSxcbiAgICAweDhCQUQ6IDB4NUYzNyxcbiAgICAweDhCQUU6IDB4NUY0QSxcbiAgICAweDhCQUY6IDB4NjAyRixcbiAgICAweDhCQjA6IDB4NjA1MCxcbiAgICAweDhCQjE6IDB4NjA2RCxcbiAgICAweDhCQjI6IDB4NjMxRixcbiAgICAweDhCQjM6IDB4NjU1OSxcbiAgICAweDhCQjQ6IDB4NkE0QixcbiAgICAweDhCQjU6IDB4NkNDMSxcbiAgICAweDhCQjY6IDB4NzJDMixcbiAgICAweDhCQjc6IDB4NzJFRCxcbiAgICAweDhCQjg6IDB4NzdFRixcbiAgICAweDhCQjk6IDB4ODBGOCxcbiAgICAweDhCQkE6IDB4ODEwNSxcbiAgICAweDhCQkI6IDB4ODIwOCxcbiAgICAweDhCQkM6IDB4ODU0RSxcbiAgICAweDhCQkQ6IDB4OTBGNyxcbiAgICAweDhCQkU6IDB4OTNFMSxcbiAgICAweDhCQkY6IDB4OTdGRixcbiAgICAweDhCQzA6IDB4OTk1NyxcbiAgICAweDhCQzE6IDB4OUE1QSxcbiAgICAweDhCQzI6IDB4NEVGMCxcbiAgICAweDhCQzM6IDB4NTFERCxcbiAgICAweDhCQzQ6IDB4NUMyRCxcbiAgICAweDhCQzU6IDB4NjY4MSxcbiAgICAweDhCQzY6IDB4Njk2RCxcbiAgICAweDhCQzc6IDB4NUM0MCxcbiAgICAweDhCQzg6IDB4NjZGMixcbiAgICAweDhCQzk6IDB4Njk3NSxcbiAgICAweDhCQ0E6IDB4NzM4OSxcbiAgICAweDhCQ0I6IDB4Njg1MCxcbiAgICAweDhCQ0M6IDB4N0M4MSxcbiAgICAweDhCQ0Q6IDB4NTBDNSxcbiAgICAweDhCQ0U6IDB4NTJFNCxcbiAgICAweDhCQ0Y6IDB4NTc0NyxcbiAgICAweDhCRDA6IDB4NURGRSxcbiAgICAweDhCRDE6IDB4OTMyNixcbiAgICAweDhCRDI6IDB4NjVBNCxcbiAgICAweDhCRDM6IDB4NkIyMyxcbiAgICAweDhCRDQ6IDB4NkIzRCxcbiAgICAweDhCRDU6IDB4NzQzNCxcbiAgICAweDhCRDY6IDB4Nzk4MSxcbiAgICAweDhCRDc6IDB4NzlCRCxcbiAgICAweDhCRDg6IDB4N0I0QixcbiAgICAweDhCRDk6IDB4N0RDQSxcbiAgICAweDhCREE6IDB4ODJCOSxcbiAgICAweDhCREI6IDB4ODNDQyxcbiAgICAweDhCREM6IDB4ODg3RixcbiAgICAweDhCREQ6IDB4ODk1RixcbiAgICAweDhCREU6IDB4OEIzOSxcbiAgICAweDhCREY6IDB4OEZEMSxcbiAgICAweDhCRTA6IDB4OTFEMSxcbiAgICAweDhCRTE6IDB4NTQxRixcbiAgICAweDhCRTI6IDB4OTI4MCxcbiAgICAweDhCRTM6IDB4NEU1RCxcbiAgICAweDhCRTQ6IDB4NTAzNixcbiAgICAweDhCRTU6IDB4NTNFNSxcbiAgICAweDhCRTY6IDB4NTMzQSxcbiAgICAweDhCRTc6IDB4NzJENyxcbiAgICAweDhCRTg6IDB4NzM5NixcbiAgICAweDhCRTk6IDB4NzdFOSxcbiAgICAweDhCRUE6IDB4ODJFNixcbiAgICAweDhCRUI6IDB4OEVBRixcbiAgICAweDhCRUM6IDB4OTlDNixcbiAgICAweDhCRUQ6IDB4OTlDOCxcbiAgICAweDhCRUU6IDB4OTlEMixcbiAgICAweDhCRUY6IDB4NTE3NyxcbiAgICAweDhCRjA6IDB4NjExQSxcbiAgICAweDhCRjE6IDB4ODY1RSxcbiAgICAweDhCRjI6IDB4NTVCMCxcbiAgICAweDhCRjM6IDB4N0E3QSxcbiAgICAweDhCRjQ6IDB4NTA3NixcbiAgICAweDhCRjU6IDB4NUJEMyxcbiAgICAweDhCRjY6IDB4OTA0NyxcbiAgICAweDhCRjc6IDB4OTY4NSxcbiAgICAweDhCRjg6IDB4NEUzMixcbiAgICAweDhCRjk6IDB4NkFEQixcbiAgICAweDhCRkE6IDB4OTFFNyxcbiAgICAweDhCRkI6IDB4NUM1MSxcbiAgICAweDhCRkM6IDB4NUM0OCxcbiAgICAweDhDNDA6IDB4NjM5OCxcbiAgICAweDhDNDE6IDB4N0E5RixcbiAgICAweDhDNDI6IDB4NkM5MyxcbiAgICAweDhDNDM6IDB4OTc3NCxcbiAgICAweDhDNDQ6IDB4OEY2MSxcbiAgICAweDhDNDU6IDB4N0FBQSxcbiAgICAweDhDNDY6IDB4NzE4QSxcbiAgICAweDhDNDc6IDB4OTY4OCxcbiAgICAweDhDNDg6IDB4N0M4MixcbiAgICAweDhDNDk6IDB4NjgxNyxcbiAgICAweDhDNEE6IDB4N0U3MCxcbiAgICAweDhDNEI6IDB4Njg1MSxcbiAgICAweDhDNEM6IDB4OTM2QyxcbiAgICAweDhDNEQ6IDB4NTJGMixcbiAgICAweDhDNEU6IDB4NTQxQixcbiAgICAweDhDNEY6IDB4ODVBQixcbiAgICAweDhDNTA6IDB4OEExMyxcbiAgICAweDhDNTE6IDB4N0ZBNCxcbiAgICAweDhDNTI6IDB4OEVDRCxcbiAgICAweDhDNTM6IDB4OTBFMSxcbiAgICAweDhDNTQ6IDB4NTM2NixcbiAgICAweDhDNTU6IDB4ODg4OCxcbiAgICAweDhDNTY6IDB4Nzk0MSxcbiAgICAweDhDNTc6IDB4NEZDMixcbiAgICAweDhDNTg6IDB4NTBCRSxcbiAgICAweDhDNTk6IDB4NTIxMSxcbiAgICAweDhDNUE6IDB4NTE0NCxcbiAgICAweDhDNUI6IDB4NTU1MyxcbiAgICAweDhDNUM6IDB4NTcyRCxcbiAgICAweDhDNUQ6IDB4NzNFQSxcbiAgICAweDhDNUU6IDB4NTc4QixcbiAgICAweDhDNUY6IDB4NTk1MSxcbiAgICAweDhDNjA6IDB4NUY2MixcbiAgICAweDhDNjE6IDB4NUY4NCxcbiAgICAweDhDNjI6IDB4NjA3NSxcbiAgICAweDhDNjM6IDB4NjE3NixcbiAgICAweDhDNjQ6IDB4NjE2NyxcbiAgICAweDhDNjU6IDB4NjFBOSxcbiAgICAweDhDNjY6IDB4NjNCMixcbiAgICAweDhDNjc6IDB4NjQzQSxcbiAgICAweDhDNjg6IDB4NjU2QyxcbiAgICAweDhDNjk6IDB4NjY2RixcbiAgICAweDhDNkE6IDB4Njg0MixcbiAgICAweDhDNkI6IDB4NkUxMyxcbiAgICAweDhDNkM6IDB4NzU2NixcbiAgICAweDhDNkQ6IDB4N0EzRCxcbiAgICAweDhDNkU6IDB4N0NGQixcbiAgICAweDhDNkY6IDB4N0Q0QyxcbiAgICAweDhDNzA6IDB4N0Q5OSxcbiAgICAweDhDNzE6IDB4N0U0QixcbiAgICAweDhDNzI6IDB4N0Y2QixcbiAgICAweDhDNzM6IDB4ODMwRSxcbiAgICAweDhDNzQ6IDB4ODM0QSxcbiAgICAweDhDNzU6IDB4ODZDRCxcbiAgICAweDhDNzY6IDB4OEEwOCxcbiAgICAweDhDNzc6IDB4OEE2MyxcbiAgICAweDhDNzg6IDB4OEI2NixcbiAgICAweDhDNzk6IDB4OEVGRCxcbiAgICAweDhDN0E6IDB4OTgxQSxcbiAgICAweDhDN0I6IDB4OUQ4RixcbiAgICAweDhDN0M6IDB4ODJCOCxcbiAgICAweDhDN0Q6IDB4OEZDRSxcbiAgICAweDhDN0U6IDB4OUJFOCxcbiAgICAweDhDODA6IDB4NTI4NyxcbiAgICAweDhDODE6IDB4NjIxRixcbiAgICAweDhDODI6IDB4NjQ4MyxcbiAgICAweDhDODM6IDB4NkZDMCxcbiAgICAweDhDODQ6IDB4OTY5OSxcbiAgICAweDhDODU6IDB4Njg0MSxcbiAgICAweDhDODY6IDB4NTA5MSxcbiAgICAweDhDODc6IDB4NkIyMCxcbiAgICAweDhDODg6IDB4NkM3QSxcbiAgICAweDhDODk6IDB4NkY1NCxcbiAgICAweDhDOEE6IDB4N0E3NCxcbiAgICAweDhDOEI6IDB4N0Q1MCxcbiAgICAweDhDOEM6IDB4ODg0MCxcbiAgICAweDhDOEQ6IDB4OEEyMyxcbiAgICAweDhDOEU6IDB4NjcwOCxcbiAgICAweDhDOEY6IDB4NEVGNixcbiAgICAweDhDOTA6IDB4NTAzOSxcbiAgICAweDhDOTE6IDB4NTAyNixcbiAgICAweDhDOTI6IDB4NTA2NSxcbiAgICAweDhDOTM6IDB4NTE3QyxcbiAgICAweDhDOTQ6IDB4NTIzOCxcbiAgICAweDhDOTU6IDB4NTI2MyxcbiAgICAweDhDOTY6IDB4NTVBNyxcbiAgICAweDhDOTc6IDB4NTcwRixcbiAgICAweDhDOTg6IDB4NTgwNSxcbiAgICAweDhDOTk6IDB4NUFDQyxcbiAgICAweDhDOUE6IDB4NUVGQSxcbiAgICAweDhDOUI6IDB4NjFCMixcbiAgICAweDhDOUM6IDB4NjFGOCxcbiAgICAweDhDOUQ6IDB4NjJGMyxcbiAgICAweDhDOUU6IDB4NjM3MixcbiAgICAweDhDOUY6IDB4NjkxQyxcbiAgICAweDhDQTA6IDB4NkEyOSxcbiAgICAweDhDQTE6IDB4NzI3RCxcbiAgICAweDhDQTI6IDB4NzJBQyxcbiAgICAweDhDQTM6IDB4NzMyRSxcbiAgICAweDhDQTQ6IDB4NzgxNCxcbiAgICAweDhDQTU6IDB4Nzg2RixcbiAgICAweDhDQTY6IDB4N0Q3OSxcbiAgICAweDhDQTc6IDB4NzcwQyxcbiAgICAweDhDQTg6IDB4ODBBOSxcbiAgICAweDhDQTk6IDB4ODk4QixcbiAgICAweDhDQUE6IDB4OEIxOSxcbiAgICAweDhDQUI6IDB4OENFMixcbiAgICAweDhDQUM6IDB4OEVEMixcbiAgICAweDhDQUQ6IDB4OTA2MyxcbiAgICAweDhDQUU6IDB4OTM3NSxcbiAgICAweDhDQUY6IDB4OTY3QSxcbiAgICAweDhDQjA6IDB4OTg1NSxcbiAgICAweDhDQjE6IDB4OUExMyxcbiAgICAweDhDQjI6IDB4OUU3OCxcbiAgICAweDhDQjM6IDB4NTE0MyxcbiAgICAweDhDQjQ6IDB4NTM5RixcbiAgICAweDhDQjU6IDB4NTNCMyxcbiAgICAweDhDQjY6IDB4NUU3QixcbiAgICAweDhDQjc6IDB4NUYyNixcbiAgICAweDhDQjg6IDB4NkUxQixcbiAgICAweDhDQjk6IDB4NkU5MCxcbiAgICAweDhDQkE6IDB4NzM4NCxcbiAgICAweDhDQkI6IDB4NzNGRSxcbiAgICAweDhDQkM6IDB4N0Q0MyxcbiAgICAweDhDQkQ6IDB4ODIzNyxcbiAgICAweDhDQkU6IDB4OEEwMCxcbiAgICAweDhDQkY6IDB4OEFGQSxcbiAgICAweDhDQzA6IDB4OTY1MCxcbiAgICAweDhDQzE6IDB4NEU0RSxcbiAgICAweDhDQzI6IDB4NTAwQixcbiAgICAweDhDQzM6IDB4NTNFNCxcbiAgICAweDhDQzQ6IDB4NTQ3QyxcbiAgICAweDhDQzU6IDB4NTZGQSxcbiAgICAweDhDQzY6IDB4NTlEMSxcbiAgICAweDhDQzc6IDB4NUI2NCxcbiAgICAweDhDQzg6IDB4NURGMSxcbiAgICAweDhDQzk6IDB4NUVBQixcbiAgICAweDhDQ0E6IDB4NUYyNyxcbiAgICAweDhDQ0I6IDB4NjIzOCxcbiAgICAweDhDQ0M6IDB4NjU0NSxcbiAgICAweDhDQ0Q6IDB4NjdBRixcbiAgICAweDhDQ0U6IDB4NkU1NixcbiAgICAweDhDQ0Y6IDB4NzJEMCxcbiAgICAweDhDRDA6IDB4N0NDQSxcbiAgICAweDhDRDE6IDB4ODhCNCxcbiAgICAweDhDRDI6IDB4ODBBMSxcbiAgICAweDhDRDM6IDB4ODBFMSxcbiAgICAweDhDRDQ6IDB4ODNGMCxcbiAgICAweDhDRDU6IDB4ODY0RSxcbiAgICAweDhDRDY6IDB4OEE4NyxcbiAgICAweDhDRDc6IDB4OERFOCxcbiAgICAweDhDRDg6IDB4OTIzNyxcbiAgICAweDhDRDk6IDB4OTZDNyxcbiAgICAweDhDREE6IDB4OTg2NyxcbiAgICAweDhDREI6IDB4OUYxMyxcbiAgICAweDhDREM6IDB4NEU5NCxcbiAgICAweDhDREQ6IDB4NEU5MixcbiAgICAweDhDREU6IDB4NEYwRCxcbiAgICAweDhDREY6IDB4NTM0OCxcbiAgICAweDhDRTA6IDB4NTQ0OSxcbiAgICAweDhDRTE6IDB4NTQzRSxcbiAgICAweDhDRTI6IDB4NUEyRixcbiAgICAweDhDRTM6IDB4NUY4QyxcbiAgICAweDhDRTQ6IDB4NUZBMSxcbiAgICAweDhDRTU6IDB4NjA5RixcbiAgICAweDhDRTY6IDB4NjhBNyxcbiAgICAweDhDRTc6IDB4NkE4RSxcbiAgICAweDhDRTg6IDB4NzQ1QSxcbiAgICAweDhDRTk6IDB4Nzg4MSxcbiAgICAweDhDRUE6IDB4OEE5RSxcbiAgICAweDhDRUI6IDB4OEFBNCxcbiAgICAweDhDRUM6IDB4OEI3NyxcbiAgICAweDhDRUQ6IDB4OTE5MCxcbiAgICAweDhDRUU6IDB4NEU1RSxcbiAgICAweDhDRUY6IDB4OUJDOSxcbiAgICAweDhDRjA6IDB4NEVBNCxcbiAgICAweDhDRjE6IDB4NEY3QyxcbiAgICAweDhDRjI6IDB4NEZBRixcbiAgICAweDhDRjM6IDB4NTAxOSxcbiAgICAweDhDRjQ6IDB4NTAxNixcbiAgICAweDhDRjU6IDB4NTE0OSxcbiAgICAweDhDRjY6IDB4NTE2QyxcbiAgICAweDhDRjc6IDB4NTI5RixcbiAgICAweDhDRjg6IDB4NTJCOSxcbiAgICAweDhDRjk6IDB4NTJGRSxcbiAgICAweDhDRkE6IDB4NTM5QSxcbiAgICAweDhDRkI6IDB4NTNFMyxcbiAgICAweDhDRkM6IDB4NTQxMSxcbiAgICAweDhENDA6IDB4NTQwRSxcbiAgICAweDhENDE6IDB4NTU4OSxcbiAgICAweDhENDI6IDB4NTc1MSxcbiAgICAweDhENDM6IDB4NTdBMixcbiAgICAweDhENDQ6IDB4NTk3RCxcbiAgICAweDhENDU6IDB4NUI1NCxcbiAgICAweDhENDY6IDB4NUI1RCxcbiAgICAweDhENDc6IDB4NUI4RixcbiAgICAweDhENDg6IDB4NURFNSxcbiAgICAweDhENDk6IDB4NURFNyxcbiAgICAweDhENEE6IDB4NURGNyxcbiAgICAweDhENEI6IDB4NUU3OCxcbiAgICAweDhENEM6IDB4NUU4MyxcbiAgICAweDhENEQ6IDB4NUU5QSxcbiAgICAweDhENEU6IDB4NUVCNyxcbiAgICAweDhENEY6IDB4NUYxOCxcbiAgICAweDhENTA6IDB4NjA1MixcbiAgICAweDhENTE6IDB4NjE0QyxcbiAgICAweDhENTI6IDB4NjI5NyxcbiAgICAweDhENTM6IDB4NjJEOCxcbiAgICAweDhENTQ6IDB4NjNBNyxcbiAgICAweDhENTU6IDB4NjUzQixcbiAgICAweDhENTY6IDB4NjYwMixcbiAgICAweDhENTc6IDB4NjY0MyxcbiAgICAweDhENTg6IDB4NjZGNCxcbiAgICAweDhENTk6IDB4Njc2RCxcbiAgICAweDhENUE6IDB4NjgyMSxcbiAgICAweDhENUI6IDB4Njg5NyxcbiAgICAweDhENUM6IDB4NjlDQixcbiAgICAweDhENUQ6IDB4NkM1RixcbiAgICAweDhENUU6IDB4NkQyQSxcbiAgICAweDhENUY6IDB4NkQ2OSxcbiAgICAweDhENjA6IDB4NkUyRixcbiAgICAweDhENjE6IDB4NkU5RCxcbiAgICAweDhENjI6IDB4NzUzMixcbiAgICAweDhENjM6IDB4NzY4NyxcbiAgICAweDhENjQ6IDB4Nzg2QyxcbiAgICAweDhENjU6IDB4N0EzRixcbiAgICAweDhENjY6IDB4N0NFMCxcbiAgICAweDhENjc6IDB4N0QwNSxcbiAgICAweDhENjg6IDB4N0QxOCxcbiAgICAweDhENjk6IDB4N0Q1RSxcbiAgICAweDhENkE6IDB4N0RCMSxcbiAgICAweDhENkI6IDB4ODAxNSxcbiAgICAweDhENkM6IDB4ODAwMyxcbiAgICAweDhENkQ6IDB4ODBBRixcbiAgICAweDhENkU6IDB4ODBCMSxcbiAgICAweDhENkY6IDB4ODE1NCxcbiAgICAweDhENzA6IDB4ODE4RixcbiAgICAweDhENzE6IDB4ODIyQSxcbiAgICAweDhENzI6IDB4ODM1MixcbiAgICAweDhENzM6IDB4ODg0QyxcbiAgICAweDhENzQ6IDB4ODg2MSxcbiAgICAweDhENzU6IDB4OEIxQixcbiAgICAweDhENzY6IDB4OENBMixcbiAgICAweDhENzc6IDB4OENGQyxcbiAgICAweDhENzg6IDB4OTBDQSxcbiAgICAweDhENzk6IDB4OTE3NSxcbiAgICAweDhEN0E6IDB4OTI3MSxcbiAgICAweDhEN0I6IDB4NzgzRixcbiAgICAweDhEN0M6IDB4OTJGQyxcbiAgICAweDhEN0Q6IDB4OTVBNCxcbiAgICAweDhEN0U6IDB4OTY0RCxcbiAgICAweDhEODA6IDB4OTgwNSxcbiAgICAweDhEODE6IDB4OTk5OSxcbiAgICAweDhEODI6IDB4OUFEOCxcbiAgICAweDhEODM6IDB4OUQzQixcbiAgICAweDhEODQ6IDB4NTI1QixcbiAgICAweDhEODU6IDB4NTJBQixcbiAgICAweDhEODY6IDB4NTNGNyxcbiAgICAweDhEODc6IDB4NTQwOCxcbiAgICAweDhEODg6IDB4NThENSxcbiAgICAweDhEODk6IDB4NjJGNyxcbiAgICAweDhEOEE6IDB4NkZFMCxcbiAgICAweDhEOEI6IDB4OEM2QSxcbiAgICAweDhEOEM6IDB4OEY1RixcbiAgICAweDhEOEQ6IDB4OUVCOSxcbiAgICAweDhEOEU6IDB4NTE0QixcbiAgICAweDhEOEY6IDB4NTIzQixcbiAgICAweDhEOTA6IDB4NTQ0QSxcbiAgICAweDhEOTE6IDB4NTZGRCxcbiAgICAweDhEOTI6IDB4N0E0MCxcbiAgICAweDhEOTM6IDB4OTE3NyxcbiAgICAweDhEOTQ6IDB4OUQ2MCxcbiAgICAweDhEOTU6IDB4OUVEMixcbiAgICAweDhEOTY6IDB4NzM0NCxcbiAgICAweDhEOTc6IDB4NkYwOSxcbiAgICAweDhEOTg6IDB4ODE3MCxcbiAgICAweDhEOTk6IDB4NzUxMSxcbiAgICAweDhEOUE6IDB4NUZGRCxcbiAgICAweDhEOUI6IDB4NjBEQSxcbiAgICAweDhEOUM6IDB4OUFBOCxcbiAgICAweDhEOUQ6IDB4NzJEQixcbiAgICAweDhEOUU6IDB4OEZCQyxcbiAgICAweDhEOUY6IDB4NkI2NCxcbiAgICAweDhEQTA6IDB4OTgwMyxcbiAgICAweDhEQTE6IDB4NEVDQSxcbiAgICAweDhEQTI6IDB4NTZGMCxcbiAgICAweDhEQTM6IDB4NTc2NCxcbiAgICAweDhEQTQ6IDB4NThCRSxcbiAgICAweDhEQTU6IDB4NUE1QSxcbiAgICAweDhEQTY6IDB4NjA2OCxcbiAgICAweDhEQTc6IDB4NjFDNyxcbiAgICAweDhEQTg6IDB4NjYwRixcbiAgICAweDhEQTk6IDB4NjYwNixcbiAgICAweDhEQUE6IDB4NjgzOSxcbiAgICAweDhEQUI6IDB4NjhCMSxcbiAgICAweDhEQUM6IDB4NkRGNyxcbiAgICAweDhEQUQ6IDB4NzVENSxcbiAgICAweDhEQUU6IDB4N0QzQSxcbiAgICAweDhEQUY6IDB4ODI2RSxcbiAgICAweDhEQjA6IDB4OUI0MixcbiAgICAweDhEQjE6IDB4NEU5QixcbiAgICAweDhEQjI6IDB4NEY1MCxcbiAgICAweDhEQjM6IDB4NTNDOSxcbiAgICAweDhEQjQ6IDB4NTUwNixcbiAgICAweDhEQjU6IDB4NUQ2RixcbiAgICAweDhEQjY6IDB4NURFNixcbiAgICAweDhEQjc6IDB4NURFRSxcbiAgICAweDhEQjg6IDB4NjdGQixcbiAgICAweDhEQjk6IDB4NkM5OSxcbiAgICAweDhEQkE6IDB4NzQ3MyxcbiAgICAweDhEQkI6IDB4NzgwMixcbiAgICAweDhEQkM6IDB4OEE1MCxcbiAgICAweDhEQkQ6IDB4OTM5NixcbiAgICAweDhEQkU6IDB4ODhERixcbiAgICAweDhEQkY6IDB4NTc1MCxcbiAgICAweDhEQzA6IDB4NUVBNyxcbiAgICAweDhEQzE6IDB4NjMyQixcbiAgICAweDhEQzI6IDB4NTBCNSxcbiAgICAweDhEQzM6IDB4NTBBQyxcbiAgICAweDhEQzQ6IDB4NTE4RCxcbiAgICAweDhEQzU6IDB4NjcwMCxcbiAgICAweDhEQzY6IDB4NTRDOSxcbiAgICAweDhEQzc6IDB4NTg1RSxcbiAgICAweDhEQzg6IDB4NTlCQixcbiAgICAweDhEQzk6IDB4NUJCMCxcbiAgICAweDhEQ0E6IDB4NUY2OSxcbiAgICAweDhEQ0I6IDB4NjI0RCxcbiAgICAweDhEQ0M6IDB4NjNBMSxcbiAgICAweDhEQ0Q6IDB4NjgzRCxcbiAgICAweDhEQ0U6IDB4NkI3MyxcbiAgICAweDhEQ0Y6IDB4NkUwOCxcbiAgICAweDhERDA6IDB4NzA3RCxcbiAgICAweDhERDE6IDB4OTFDNyxcbiAgICAweDhERDI6IDB4NzI4MCxcbiAgICAweDhERDM6IDB4NzgxNSxcbiAgICAweDhERDQ6IDB4NzgyNixcbiAgICAweDhERDU6IDB4Nzk2RCxcbiAgICAweDhERDY6IDB4NjU4RSxcbiAgICAweDhERDc6IDB4N0QzMCxcbiAgICAweDhERDg6IDB4ODNEQyxcbiAgICAweDhERDk6IDB4ODhDMSxcbiAgICAweDhEREE6IDB4OEYwOSxcbiAgICAweDhEREI6IDB4OTY5QixcbiAgICAweDhEREM6IDB4NTI2NCxcbiAgICAweDhEREQ6IDB4NTcyOCxcbiAgICAweDhEREU6IDB4Njc1MCxcbiAgICAweDhEREY6IDB4N0Y2QSxcbiAgICAweDhERTA6IDB4OENBMSxcbiAgICAweDhERTE6IDB4NTFCNCxcbiAgICAweDhERTI6IDB4NTc0MixcbiAgICAweDhERTM6IDB4OTYyQSxcbiAgICAweDhERTQ6IDB4NTgzQSxcbiAgICAweDhERTU6IDB4Njk4QSxcbiAgICAweDhERTY6IDB4ODBCNCxcbiAgICAweDhERTc6IDB4NTRCMixcbiAgICAweDhERTg6IDB4NUQwRSxcbiAgICAweDhERTk6IDB4NTdGQyxcbiAgICAweDhERUE6IDB4Nzg5NSxcbiAgICAweDhERUI6IDB4OURGQSxcbiAgICAweDhERUM6IDB4NEY1QyxcbiAgICAweDhERUQ6IDB4NTI0QSxcbiAgICAweDhERUU6IDB4NTQ4QixcbiAgICAweDhERUY6IDB4NjQzRSxcbiAgICAweDhERjA6IDB4NjYyOCxcbiAgICAweDhERjE6IDB4NjcxNCxcbiAgICAweDhERjI6IDB4NjdGNSxcbiAgICAweDhERjM6IDB4N0E4NCxcbiAgICAweDhERjQ6IDB4N0I1NixcbiAgICAweDhERjU6IDB4N0QyMixcbiAgICAweDhERjY6IDB4OTMyRixcbiAgICAweDhERjc6IDB4Njg1QyxcbiAgICAweDhERjg6IDB4OUJBRCxcbiAgICAweDhERjk6IDB4N0IzOSxcbiAgICAweDhERkE6IDB4NTMxOSxcbiAgICAweDhERkI6IDB4NTE4QSxcbiAgICAweDhERkM6IDB4NTIzNyxcbiAgICAweDhFNDA6IDB4NUJERixcbiAgICAweDhFNDE6IDB4NjJGNixcbiAgICAweDhFNDI6IDB4NjRBRSxcbiAgICAweDhFNDM6IDB4NjRFNixcbiAgICAweDhFNDQ6IDB4NjcyRCxcbiAgICAweDhFNDU6IDB4NkJCQSxcbiAgICAweDhFNDY6IDB4ODVBOSxcbiAgICAweDhFNDc6IDB4OTZEMSxcbiAgICAweDhFNDg6IDB4NzY5MCxcbiAgICAweDhFNDk6IDB4OUJENixcbiAgICAweDhFNEE6IDB4NjM0QyxcbiAgICAweDhFNEI6IDB4OTMwNixcbiAgICAweDhFNEM6IDB4OUJBQixcbiAgICAweDhFNEQ6IDB4NzZCRixcbiAgICAweDhFNEU6IDB4NjY1MixcbiAgICAweDhFNEY6IDB4NEUwOSxcbiAgICAweDhFNTA6IDB4NTA5OCxcbiAgICAweDhFNTE6IDB4NTNDMixcbiAgICAweDhFNTI6IDB4NUM3MSxcbiAgICAweDhFNTM6IDB4NjBFOCxcbiAgICAweDhFNTQ6IDB4NjQ5MixcbiAgICAweDhFNTU6IDB4NjU2MyxcbiAgICAweDhFNTY6IDB4Njg1RixcbiAgICAweDhFNTc6IDB4NzFFNixcbiAgICAweDhFNTg6IDB4NzNDQSxcbiAgICAweDhFNTk6IDB4NzUyMyxcbiAgICAweDhFNUE6IDB4N0I5NyxcbiAgICAweDhFNUI6IDB4N0U4MixcbiAgICAweDhFNUM6IDB4ODY5NSxcbiAgICAweDhFNUQ6IDB4OEI4MyxcbiAgICAweDhFNUU6IDB4OENEQixcbiAgICAweDhFNUY6IDB4OTE3OCxcbiAgICAweDhFNjA6IDB4OTkxMCxcbiAgICAweDhFNjE6IDB4NjVBQyxcbiAgICAweDhFNjI6IDB4NjZBQixcbiAgICAweDhFNjM6IDB4NkI4QixcbiAgICAweDhFNjQ6IDB4NEVENSxcbiAgICAweDhFNjU6IDB4NEVENCxcbiAgICAweDhFNjY6IDB4NEYzQSxcbiAgICAweDhFNjc6IDB4NEY3RixcbiAgICAweDhFNjg6IDB4NTIzQSxcbiAgICAweDhFNjk6IDB4NTNGOCxcbiAgICAweDhFNkE6IDB4NTNGMixcbiAgICAweDhFNkI6IDB4NTVFMyxcbiAgICAweDhFNkM6IDB4NTZEQixcbiAgICAweDhFNkQ6IDB4NThFQixcbiAgICAweDhFNkU6IDB4NTlDQixcbiAgICAweDhFNkY6IDB4NTlDOSxcbiAgICAweDhFNzA6IDB4NTlGRixcbiAgICAweDhFNzE6IDB4NUI1MCxcbiAgICAweDhFNzI6IDB4NUM0RCxcbiAgICAweDhFNzM6IDB4NUUwMixcbiAgICAweDhFNzQ6IDB4NUUyQixcbiAgICAweDhFNzU6IDB4NUZENyxcbiAgICAweDhFNzY6IDB4NjAxRCxcbiAgICAweDhFNzc6IDB4NjMwNyxcbiAgICAweDhFNzg6IDB4NjUyRixcbiAgICAweDhFNzk6IDB4NUI1QyxcbiAgICAweDhFN0E6IDB4NjVBRixcbiAgICAweDhFN0I6IDB4NjVCRCxcbiAgICAweDhFN0M6IDB4NjVFOCxcbiAgICAweDhFN0Q6IDB4Njc5RCxcbiAgICAweDhFN0U6IDB4NkI2MixcbiAgICAweDhFODA6IDB4NkI3QixcbiAgICAweDhFODE6IDB4NkMwRixcbiAgICAweDhFODI6IDB4NzM0NSxcbiAgICAweDhFODM6IDB4Nzk0OSxcbiAgICAweDhFODQ6IDB4NzlDMSxcbiAgICAweDhFODU6IDB4N0NGOCxcbiAgICAweDhFODY6IDB4N0QxOSxcbiAgICAweDhFODc6IDB4N0QyQixcbiAgICAweDhFODg6IDB4ODBBMixcbiAgICAweDhFODk6IDB4ODEwMixcbiAgICAweDhFOEE6IDB4ODFGMyxcbiAgICAweDhFOEI6IDB4ODk5NixcbiAgICAweDhFOEM6IDB4OEE1RSxcbiAgICAweDhFOEQ6IDB4OEE2OSxcbiAgICAweDhFOEU6IDB4OEE2NixcbiAgICAweDhFOEY6IDB4OEE4QyxcbiAgICAweDhFOTA6IDB4OEFFRSxcbiAgICAweDhFOTE6IDB4OENDNyxcbiAgICAweDhFOTI6IDB4OENEQyxcbiAgICAweDhFOTM6IDB4OTZDQyxcbiAgICAweDhFOTQ6IDB4OThGQyxcbiAgICAweDhFOTU6IDB4NkI2RixcbiAgICAweDhFOTY6IDB4NEU4QixcbiAgICAweDhFOTc6IDB4NEYzQyxcbiAgICAweDhFOTg6IDB4NEY4RCxcbiAgICAweDhFOTk6IDB4NTE1MCxcbiAgICAweDhFOUE6IDB4NUI1NyxcbiAgICAweDhFOUI6IDB4NUJGQSxcbiAgICAweDhFOUM6IDB4NjE0OCxcbiAgICAweDhFOUQ6IDB4NjMwMSxcbiAgICAweDhFOUU6IDB4NjY0MixcbiAgICAweDhFOUY6IDB4NkIyMSxcbiAgICAweDhFQTA6IDB4NkVDQixcbiAgICAweDhFQTE6IDB4NkNCQixcbiAgICAweDhFQTI6IDB4NzIzRSxcbiAgICAweDhFQTM6IDB4NzRCRCxcbiAgICAweDhFQTQ6IDB4NzVENCxcbiAgICAweDhFQTU6IDB4NzhDMSxcbiAgICAweDhFQTY6IDB4NzkzQSxcbiAgICAweDhFQTc6IDB4ODAwQyxcbiAgICAweDhFQTg6IDB4ODAzMyxcbiAgICAweDhFQTk6IDB4ODFFQSxcbiAgICAweDhFQUE6IDB4ODQ5NCxcbiAgICAweDhFQUI6IDB4OEY5RSxcbiAgICAweDhFQUM6IDB4NkM1MCxcbiAgICAweDhFQUQ6IDB4OUU3RixcbiAgICAweDhFQUU6IDB4NUYwRixcbiAgICAweDhFQUY6IDB4OEI1OCxcbiAgICAweDhFQjA6IDB4OUQyQixcbiAgICAweDhFQjE6IDB4N0FGQSxcbiAgICAweDhFQjI6IDB4OEVGOCxcbiAgICAweDhFQjM6IDB4NUI4RCxcbiAgICAweDhFQjQ6IDB4OTZFQixcbiAgICAweDhFQjU6IDB4NEUwMyxcbiAgICAweDhFQjY6IDB4NTNGMSxcbiAgICAweDhFQjc6IDB4NTdGNyxcbiAgICAweDhFQjg6IDB4NTkzMSxcbiAgICAweDhFQjk6IDB4NUFDOSxcbiAgICAweDhFQkE6IDB4NUJBNCxcbiAgICAweDhFQkI6IDB4NjA4OSxcbiAgICAweDhFQkM6IDB4NkU3RixcbiAgICAweDhFQkQ6IDB4NkYwNixcbiAgICAweDhFQkU6IDB4NzVCRSxcbiAgICAweDhFQkY6IDB4OENFQSxcbiAgICAweDhFQzA6IDB4NUI5RixcbiAgICAweDhFQzE6IDB4ODUwMCxcbiAgICAweDhFQzI6IDB4N0JFMCxcbiAgICAweDhFQzM6IDB4NTA3MixcbiAgICAweDhFQzQ6IDB4NjdGNCxcbiAgICAweDhFQzU6IDB4ODI5RCxcbiAgICAweDhFQzY6IDB4NUM2MSxcbiAgICAweDhFQzc6IDB4ODU0QSxcbiAgICAweDhFQzg6IDB4N0UxRSxcbiAgICAweDhFQzk6IDB4ODIwRSxcbiAgICAweDhFQ0E6IDB4NTE5OSxcbiAgICAweDhFQ0I6IDB4NUMwNCxcbiAgICAweDhFQ0M6IDB4NjM2OCxcbiAgICAweDhFQ0Q6IDB4OEQ2NixcbiAgICAweDhFQ0U6IDB4NjU5QyxcbiAgICAweDhFQ0Y6IDB4NzE2RSxcbiAgICAweDhFRDA6IDB4NzkzRSxcbiAgICAweDhFRDE6IDB4N0QxNyxcbiAgICAweDhFRDI6IDB4ODAwNSxcbiAgICAweDhFRDM6IDB4OEIxRCxcbiAgICAweDhFRDQ6IDB4OEVDQSxcbiAgICAweDhFRDU6IDB4OTA2RSxcbiAgICAweDhFRDY6IDB4ODZDNyxcbiAgICAweDhFRDc6IDB4OTBBQSxcbiAgICAweDhFRDg6IDB4NTAxRixcbiAgICAweDhFRDk6IDB4NTJGQSxcbiAgICAweDhFREE6IDB4NUMzQSxcbiAgICAweDhFREI6IDB4Njc1MyxcbiAgICAweDhFREM6IDB4NzA3QyxcbiAgICAweDhFREQ6IDB4NzIzNSxcbiAgICAweDhFREU6IDB4OTE0QyxcbiAgICAweDhFREY6IDB4OTFDOCxcbiAgICAweDhFRTA6IDB4OTMyQixcbiAgICAweDhFRTE6IDB4ODJFNSxcbiAgICAweDhFRTI6IDB4NUJDMixcbiAgICAweDhFRTM6IDB4NUYzMSxcbiAgICAweDhFRTQ6IDB4NjBGOSxcbiAgICAweDhFRTU6IDB4NEUzQixcbiAgICAweDhFRTY6IDB4NTNENixcbiAgICAweDhFRTc6IDB4NUI4OCxcbiAgICAweDhFRTg6IDB4NjI0QixcbiAgICAweDhFRTk6IDB4NjczMSxcbiAgICAweDhFRUE6IDB4NkI4QSxcbiAgICAweDhFRUI6IDB4NzJFOSxcbiAgICAweDhFRUM6IDB4NzNFMCxcbiAgICAweDhFRUQ6IDB4N0EyRSxcbiAgICAweDhFRUU6IDB4ODE2QixcbiAgICAweDhFRUY6IDB4OERBMyxcbiAgICAweDhFRjA6IDB4OTE1MixcbiAgICAweDhFRjE6IDB4OTk5NixcbiAgICAweDhFRjI6IDB4NTExMixcbiAgICAweDhFRjM6IDB4NTNENyxcbiAgICAweDhFRjQ6IDB4NTQ2QSxcbiAgICAweDhFRjU6IDB4NUJGRixcbiAgICAweDhFRjY6IDB4NjM4OCxcbiAgICAweDhFRjc6IDB4NkEzOSxcbiAgICAweDhFRjg6IDB4N0RBQyxcbiAgICAweDhFRjk6IDB4OTcwMCxcbiAgICAweDhFRkE6IDB4NTZEQSxcbiAgICAweDhFRkI6IDB4NTNDRSxcbiAgICAweDhFRkM6IDB4NTQ2OCxcbiAgICAweDhGNDA6IDB4NUI5NyxcbiAgICAweDhGNDE6IDB4NUMzMSxcbiAgICAweDhGNDI6IDB4NURERSxcbiAgICAweDhGNDM6IDB4NEZFRSxcbiAgICAweDhGNDQ6IDB4NjEwMSxcbiAgICAweDhGNDU6IDB4NjJGRSxcbiAgICAweDhGNDY6IDB4NkQzMixcbiAgICAweDhGNDc6IDB4NzlDMCxcbiAgICAweDhGNDg6IDB4NzlDQixcbiAgICAweDhGNDk6IDB4N0Q0MixcbiAgICAweDhGNEE6IDB4N0U0RCxcbiAgICAweDhGNEI6IDB4N0ZEMixcbiAgICAweDhGNEM6IDB4ODFFRCxcbiAgICAweDhGNEQ6IDB4ODIxRixcbiAgICAweDhGNEU6IDB4ODQ5MCxcbiAgICAweDhGNEY6IDB4ODg0NixcbiAgICAweDhGNTA6IDB4ODk3MixcbiAgICAweDhGNTE6IDB4OEI5MCxcbiAgICAweDhGNTI6IDB4OEU3NCxcbiAgICAweDhGNTM6IDB4OEYyRixcbiAgICAweDhGNTQ6IDB4OTAzMSxcbiAgICAweDhGNTU6IDB4OTE0QixcbiAgICAweDhGNTY6IDB4OTE2QyxcbiAgICAweDhGNTc6IDB4OTZDNixcbiAgICAweDhGNTg6IDB4OTE5QyxcbiAgICAweDhGNTk6IDB4NEVDMCxcbiAgICAweDhGNUE6IDB4NEY0RixcbiAgICAweDhGNUI6IDB4NTE0NSxcbiAgICAweDhGNUM6IDB4NTM0MSxcbiAgICAweDhGNUQ6IDB4NUY5MyxcbiAgICAweDhGNUU6IDB4NjIwRSxcbiAgICAweDhGNUY6IDB4NjdENCxcbiAgICAweDhGNjA6IDB4NkM0MSxcbiAgICAweDhGNjE6IDB4NkUwQixcbiAgICAweDhGNjI6IDB4NzM2MyxcbiAgICAweDhGNjM6IDB4N0UyNixcbiAgICAweDhGNjQ6IDB4OTFDRCxcbiAgICAweDhGNjU6IDB4OTI4MyxcbiAgICAweDhGNjY6IDB4NTNENCxcbiAgICAweDhGNjc6IDB4NTkxOSxcbiAgICAweDhGNjg6IDB4NUJCRixcbiAgICAweDhGNjk6IDB4NkREMSxcbiAgICAweDhGNkE6IDB4Nzk1RCxcbiAgICAweDhGNkI6IDB4N0UyRSxcbiAgICAweDhGNkM6IDB4N0M5QixcbiAgICAweDhGNkQ6IDB4NTg3RSxcbiAgICAweDhGNkU6IDB4NzE5RixcbiAgICAweDhGNkY6IDB4NTFGQSxcbiAgICAweDhGNzA6IDB4ODg1MyxcbiAgICAweDhGNzE6IDB4OEZGMCxcbiAgICAweDhGNzI6IDB4NEZDQSxcbiAgICAweDhGNzM6IDB4NUNGQixcbiAgICAweDhGNzQ6IDB4NjYyNSxcbiAgICAweDhGNzU6IDB4NzdBQyxcbiAgICAweDhGNzY6IDB4N0FFMyxcbiAgICAweDhGNzc6IDB4ODIxQyxcbiAgICAweDhGNzg6IDB4OTlGRixcbiAgICAweDhGNzk6IDB4NTFDNixcbiAgICAweDhGN0E6IDB4NUZBQSxcbiAgICAweDhGN0I6IDB4NjVFQyxcbiAgICAweDhGN0M6IDB4Njk2RixcbiAgICAweDhGN0Q6IDB4NkI4OSxcbiAgICAweDhGN0U6IDB4NkRGMyxcbiAgICAweDhGODA6IDB4NkU5NixcbiAgICAweDhGODE6IDB4NkY2NCxcbiAgICAweDhGODI6IDB4NzZGRSxcbiAgICAweDhGODM6IDB4N0QxNCxcbiAgICAweDhGODQ6IDB4NURFMSxcbiAgICAweDhGODU6IDB4OTA3NSxcbiAgICAweDhGODY6IDB4OTE4NyxcbiAgICAweDhGODc6IDB4OTgwNixcbiAgICAweDhGODg6IDB4NTFFNixcbiAgICAweDhGODk6IDB4NTIxRCxcbiAgICAweDhGOEE6IDB4NjI0MCxcbiAgICAweDhGOEI6IDB4NjY5MSxcbiAgICAweDhGOEM6IDB4NjZEOSxcbiAgICAweDhGOEQ6IDB4NkUxQSxcbiAgICAweDhGOEU6IDB4NUVCNixcbiAgICAweDhGOEY6IDB4N0REMixcbiAgICAweDhGOTA6IDB4N0Y3MixcbiAgICAweDhGOTE6IDB4NjZGOCxcbiAgICAweDhGOTI6IDB4ODVBRixcbiAgICAweDhGOTM6IDB4ODVGNyxcbiAgICAweDhGOTQ6IDB4OEFGOCxcbiAgICAweDhGOTU6IDB4NTJBOSxcbiAgICAweDhGOTY6IDB4NTNEOSxcbiAgICAweDhGOTc6IDB4NTk3MyxcbiAgICAweDhGOTg6IDB4NUU4RixcbiAgICAweDhGOTk6IDB4NUY5MCxcbiAgICAweDhGOUE6IDB4NjA1NSxcbiAgICAweDhGOUI6IDB4OTJFNCxcbiAgICAweDhGOUM6IDB4OTY2NCxcbiAgICAweDhGOUQ6IDB4NTBCNyxcbiAgICAweDhGOUU6IDB4NTExRixcbiAgICAweDhGOUY6IDB4NTJERCxcbiAgICAweDhGQTA6IDB4NTMyMCxcbiAgICAweDhGQTE6IDB4NTM0NyxcbiAgICAweDhGQTI6IDB4NTNFQyxcbiAgICAweDhGQTM6IDB4NTRFOCxcbiAgICAweDhGQTQ6IDB4NTU0NixcbiAgICAweDhGQTU6IDB4NTUzMSxcbiAgICAweDhGQTY6IDB4NTYxNyxcbiAgICAweDhGQTc6IDB4NTk2OCxcbiAgICAweDhGQTg6IDB4NTlCRSxcbiAgICAweDhGQTk6IDB4NUEzQyxcbiAgICAweDhGQUE6IDB4NUJCNSxcbiAgICAweDhGQUI6IDB4NUMwNixcbiAgICAweDhGQUM6IDB4NUMwRixcbiAgICAweDhGQUQ6IDB4NUMxMSxcbiAgICAweDhGQUU6IDB4NUMxQSxcbiAgICAweDhGQUY6IDB4NUU4NCxcbiAgICAweDhGQjA6IDB4NUU4QSxcbiAgICAweDhGQjE6IDB4NUVFMCxcbiAgICAweDhGQjI6IDB4NUY3MCxcbiAgICAweDhGQjM6IDB4NjI3RixcbiAgICAweDhGQjQ6IDB4NjI4NCxcbiAgICAweDhGQjU6IDB4NjJEQixcbiAgICAweDhGQjY6IDB4NjM4QyxcbiAgICAweDhGQjc6IDB4NjM3NyxcbiAgICAweDhGQjg6IDB4NjYwNyxcbiAgICAweDhGQjk6IDB4NjYwQyxcbiAgICAweDhGQkE6IDB4NjYyRCxcbiAgICAweDhGQkI6IDB4NjY3NixcbiAgICAweDhGQkM6IDB4Njc3RSxcbiAgICAweDhGQkQ6IDB4NjhBMixcbiAgICAweDhGQkU6IDB4NkExRixcbiAgICAweDhGQkY6IDB4NkEzNSxcbiAgICAweDhGQzA6IDB4NkNCQyxcbiAgICAweDhGQzE6IDB4NkQ4OCxcbiAgICAweDhGQzI6IDB4NkUwOSxcbiAgICAweDhGQzM6IDB4NkU1OCxcbiAgICAweDhGQzQ6IDB4NzEzQyxcbiAgICAweDhGQzU6IDB4NzEyNixcbiAgICAweDhGQzY6IDB4NzE2NyxcbiAgICAweDhGQzc6IDB4NzVDNyxcbiAgICAweDhGQzg6IDB4NzcwMSxcbiAgICAweDhGQzk6IDB4Nzg1RCxcbiAgICAweDhGQ0E6IDB4NzkwMSxcbiAgICAweDhGQ0I6IDB4Nzk2NSxcbiAgICAweDhGQ0M6IDB4NzlGMCxcbiAgICAweDhGQ0Q6IDB4N0FFMCxcbiAgICAweDhGQ0U6IDB4N0IxMSxcbiAgICAweDhGQ0Y6IDB4N0NBNyxcbiAgICAweDhGRDA6IDB4N0QzOSxcbiAgICAweDhGRDE6IDB4ODA5NixcbiAgICAweDhGRDI6IDB4ODNENixcbiAgICAweDhGRDM6IDB4ODQ4QixcbiAgICAweDhGRDQ6IDB4ODU0OSxcbiAgICAweDhGRDU6IDB4ODg1RCxcbiAgICAweDhGRDY6IDB4ODhGMyxcbiAgICAweDhGRDc6IDB4OEExRixcbiAgICAweDhGRDg6IDB4OEEzQyxcbiAgICAweDhGRDk6IDB4OEE1NCxcbiAgICAweDhGREE6IDB4OEE3MyxcbiAgICAweDhGREI6IDB4OEM2MSxcbiAgICAweDhGREM6IDB4OENERSxcbiAgICAweDhGREQ6IDB4OTFBNCxcbiAgICAweDhGREU6IDB4OTI2NixcbiAgICAweDhGREY6IDB4OTM3RSxcbiAgICAweDhGRTA6IDB4OTQxOCxcbiAgICAweDhGRTE6IDB4OTY5QyxcbiAgICAweDhGRTI6IDB4OTc5OCxcbiAgICAweDhGRTM6IDB4NEUwQSxcbiAgICAweDhGRTQ6IDB4NEUwOCxcbiAgICAweDhGRTU6IDB4NEUxRSxcbiAgICAweDhGRTY6IDB4NEU1NyxcbiAgICAweDhGRTc6IDB4NTE5NyxcbiAgICAweDhGRTg6IDB4NTI3MCxcbiAgICAweDhGRTk6IDB4NTdDRSxcbiAgICAweDhGRUE6IDB4NTgzNCxcbiAgICAweDhGRUI6IDB4NThDQyxcbiAgICAweDhGRUM6IDB4NUIyMixcbiAgICAweDhGRUQ6IDB4NUUzOCxcbiAgICAweDhGRUU6IDB4NjBDNSxcbiAgICAweDhGRUY6IDB4NjRGRSxcbiAgICAweDhGRjA6IDB4Njc2MSxcbiAgICAweDhGRjE6IDB4Njc1NixcbiAgICAweDhGRjI6IDB4NkQ0NCxcbiAgICAweDhGRjM6IDB4NzJCNixcbiAgICAweDhGRjQ6IDB4NzU3MyxcbiAgICAweDhGRjU6IDB4N0E2MyxcbiAgICAweDhGRjY6IDB4ODRCOCxcbiAgICAweDhGRjc6IDB4OEI3MixcbiAgICAweDhGRjg6IDB4OTFCOCxcbiAgICAweDhGRjk6IDB4OTMyMCxcbiAgICAweDhGRkE6IDB4NTYzMSxcbiAgICAweDhGRkI6IDB4NTdGNCxcbiAgICAweDhGRkM6IDB4OThGRSxcbiAgICAweDkwNDA6IDB4NjJFRCxcbiAgICAweDkwNDE6IDB4NjkwRCxcbiAgICAweDkwNDI6IDB4NkI5NixcbiAgICAweDkwNDM6IDB4NzFFRCxcbiAgICAweDkwNDQ6IDB4N0U1NCxcbiAgICAweDkwNDU6IDB4ODA3NyxcbiAgICAweDkwNDY6IDB4ODI3MixcbiAgICAweDkwNDc6IDB4ODlFNixcbiAgICAweDkwNDg6IDB4OThERixcbiAgICAweDkwNDk6IDB4ODc1NSxcbiAgICAweDkwNEE6IDB4OEZCMSxcbiAgICAweDkwNEI6IDB4NUMzQixcbiAgICAweDkwNEM6IDB4NEYzOCxcbiAgICAweDkwNEQ6IDB4NEZFMSxcbiAgICAweDkwNEU6IDB4NEZCNSxcbiAgICAweDkwNEY6IDB4NTUwNyxcbiAgICAweDkwNTA6IDB4NUEyMCxcbiAgICAweDkwNTE6IDB4NUJERCxcbiAgICAweDkwNTI6IDB4NUJFOSxcbiAgICAweDkwNTM6IDB4NUZDMyxcbiAgICAweDkwNTQ6IDB4NjE0RSxcbiAgICAweDkwNTU6IDB4NjMyRixcbiAgICAweDkwNTY6IDB4NjVCMCxcbiAgICAweDkwNTc6IDB4NjY0QixcbiAgICAweDkwNTg6IDB4NjhFRSxcbiAgICAweDkwNTk6IDB4Njk5QixcbiAgICAweDkwNUE6IDB4NkQ3OCxcbiAgICAweDkwNUI6IDB4NkRGMSxcbiAgICAweDkwNUM6IDB4NzUzMyxcbiAgICAweDkwNUQ6IDB4NzVCOSxcbiAgICAweDkwNUU6IDB4NzcxRixcbiAgICAweDkwNUY6IDB4Nzk1RSxcbiAgICAweDkwNjA6IDB4NzlFNixcbiAgICAweDkwNjE6IDB4N0QzMyxcbiAgICAweDkwNjI6IDB4ODFFMyxcbiAgICAweDkwNjM6IDB4ODJBRixcbiAgICAweDkwNjQ6IDB4ODVBQSxcbiAgICAweDkwNjU6IDB4ODlBQSxcbiAgICAweDkwNjY6IDB4OEEzQSxcbiAgICAweDkwNjc6IDB4OEVBQixcbiAgICAweDkwNjg6IDB4OEY5QixcbiAgICAweDkwNjk6IDB4OTAzMixcbiAgICAweDkwNkE6IDB4OTFERCxcbiAgICAweDkwNkI6IDB4OTcwNyxcbiAgICAweDkwNkM6IDB4NEVCQSxcbiAgICAweDkwNkQ6IDB4NEVDMSxcbiAgICAweDkwNkU6IDB4NTIwMyxcbiAgICAweDkwNkY6IDB4NTg3NSxcbiAgICAweDkwNzA6IDB4NThFQyxcbiAgICAweDkwNzE6IDB4NUMwQixcbiAgICAweDkwNzI6IDB4NzUxQSxcbiAgICAweDkwNzM6IDB4NUMzRCxcbiAgICAweDkwNzQ6IDB4ODE0RSxcbiAgICAweDkwNzU6IDB4OEEwQSxcbiAgICAweDkwNzY6IDB4OEZDNSxcbiAgICAweDkwNzc6IDB4OTY2MyxcbiAgICAweDkwNzg6IDB4OTc2RCxcbiAgICAweDkwNzk6IDB4N0IyNSxcbiAgICAweDkwN0E6IDB4OEFDRixcbiAgICAweDkwN0I6IDB4OTgwOCxcbiAgICAweDkwN0M6IDB4OTE2MixcbiAgICAweDkwN0Q6IDB4NTZGMyxcbiAgICAweDkwN0U6IDB4NTNBOCxcbiAgICAweDkwODA6IDB4OTAxNyxcbiAgICAweDkwODE6IDB4NTQzOSxcbiAgICAweDkwODI6IDB4NTc4MixcbiAgICAweDkwODM6IDB4NUUyNSxcbiAgICAweDkwODQ6IDB4NjNBOCxcbiAgICAweDkwODU6IDB4NkMzNCxcbiAgICAweDkwODY6IDB4NzA4QSxcbiAgICAweDkwODc6IDB4Nzc2MSxcbiAgICAweDkwODg6IDB4N0M4QixcbiAgICAweDkwODk6IDB4N0ZFMCxcbiAgICAweDkwOEE6IDB4ODg3MCxcbiAgICAweDkwOEI6IDB4OTA0MixcbiAgICAweDkwOEM6IDB4OTE1NCxcbiAgICAweDkwOEQ6IDB4OTMxMCxcbiAgICAweDkwOEU6IDB4OTMxOCxcbiAgICAweDkwOEY6IDB4OTY4RixcbiAgICAweDkwOTA6IDB4NzQ1RSxcbiAgICAweDkwOTE6IDB4OUFDNCxcbiAgICAweDkwOTI6IDB4NUQwNyxcbiAgICAweDkwOTM6IDB4NUQ2OSxcbiAgICAweDkwOTQ6IDB4NjU3MCxcbiAgICAweDkwOTU6IDB4NjdBMixcbiAgICAweDkwOTY6IDB4OERBOCxcbiAgICAweDkwOTc6IDB4OTZEQixcbiAgICAweDkwOTg6IDB4NjM2RSxcbiAgICAweDkwOTk6IDB4Njc0OSxcbiAgICAweDkwOUE6IDB4NjkxOSxcbiAgICAweDkwOUI6IDB4ODNDNSxcbiAgICAweDkwOUM6IDB4OTgxNyxcbiAgICAweDkwOUQ6IDB4OTZDMCxcbiAgICAweDkwOUU6IDB4ODhGRSxcbiAgICAweDkwOUY6IDB4NkY4NCxcbiAgICAweDkwQTA6IDB4NjQ3QSxcbiAgICAweDkwQTE6IDB4NUJGOCxcbiAgICAweDkwQTI6IDB4NEUxNixcbiAgICAweDkwQTM6IDB4NzAyQyxcbiAgICAweDkwQTQ6IDB4NzU1RCxcbiAgICAweDkwQTU6IDB4NjYyRixcbiAgICAweDkwQTY6IDB4NTFDNCxcbiAgICAweDkwQTc6IDB4NTIzNixcbiAgICAweDkwQTg6IDB4NTJFMixcbiAgICAweDkwQTk6IDB4NTlEMyxcbiAgICAweDkwQUE6IDB4NUY4MSxcbiAgICAweDkwQUI6IDB4NjAyNyxcbiAgICAweDkwQUM6IDB4NjIxMCxcbiAgICAweDkwQUQ6IDB4NjUzRixcbiAgICAweDkwQUU6IDB4NjU3NCxcbiAgICAweDkwQUY6IDB4NjYxRixcbiAgICAweDkwQjA6IDB4NjY3NCxcbiAgICAweDkwQjE6IDB4NjhGMixcbiAgICAweDkwQjI6IDB4NjgxNixcbiAgICAweDkwQjM6IDB4NkI2MyxcbiAgICAweDkwQjQ6IDB4NkUwNSxcbiAgICAweDkwQjU6IDB4NzI3MixcbiAgICAweDkwQjY6IDB4NzUxRixcbiAgICAweDkwQjc6IDB4NzZEQixcbiAgICAweDkwQjg6IDB4N0NCRSxcbiAgICAweDkwQjk6IDB4ODA1NixcbiAgICAweDkwQkE6IDB4NThGMCxcbiAgICAweDkwQkI6IDB4ODhGRCxcbiAgICAweDkwQkM6IDB4ODk3RixcbiAgICAweDkwQkQ6IDB4OEFBMCxcbiAgICAweDkwQkU6IDB4OEE5MyxcbiAgICAweDkwQkY6IDB4OEFDQixcbiAgICAweDkwQzA6IDB4OTAxRCxcbiAgICAweDkwQzE6IDB4OTE5MixcbiAgICAweDkwQzI6IDB4OTc1MixcbiAgICAweDkwQzM6IDB4OTc1OSxcbiAgICAweDkwQzQ6IDB4NjU4OSxcbiAgICAweDkwQzU6IDB4N0EwRSxcbiAgICAweDkwQzY6IDB4ODEwNixcbiAgICAweDkwQzc6IDB4OTZCQixcbiAgICAweDkwQzg6IDB4NUUyRCxcbiAgICAweDkwQzk6IDB4NjBEQyxcbiAgICAweDkwQ0E6IDB4NjIxQSxcbiAgICAweDkwQ0I6IDB4NjVBNSxcbiAgICAweDkwQ0M6IDB4NjYxNCxcbiAgICAweDkwQ0Q6IDB4Njc5MCxcbiAgICAweDkwQ0U6IDB4NzdGMyxcbiAgICAweDkwQ0Y6IDB4N0E0RCxcbiAgICAweDkwRDA6IDB4N0M0RCxcbiAgICAweDkwRDE6IDB4N0UzRSxcbiAgICAweDkwRDI6IDB4ODEwQSxcbiAgICAweDkwRDM6IDB4OENBQyxcbiAgICAweDkwRDQ6IDB4OEQ2NCxcbiAgICAweDkwRDU6IDB4OERFMSxcbiAgICAweDkwRDY6IDB4OEU1RixcbiAgICAweDkwRDc6IDB4NzhBOSxcbiAgICAweDkwRDg6IDB4NTIwNyxcbiAgICAweDkwRDk6IDB4NjJEOSxcbiAgICAweDkwREE6IDB4NjNBNSxcbiAgICAweDkwREI6IDB4NjQ0MixcbiAgICAweDkwREM6IDB4NjI5OCxcbiAgICAweDkwREQ6IDB4OEEyRCxcbiAgICAweDkwREU6IDB4N0E4MyxcbiAgICAweDkwREY6IDB4N0JDMCxcbiAgICAweDkwRTA6IDB4OEFBQyxcbiAgICAweDkwRTE6IDB4OTZFQSxcbiAgICAweDkwRTI6IDB4N0Q3NixcbiAgICAweDkwRTM6IDB4ODIwQyxcbiAgICAweDkwRTQ6IDB4ODc0OSxcbiAgICAweDkwRTU6IDB4NEVEOSxcbiAgICAweDkwRTY6IDB4NTE0OCxcbiAgICAweDkwRTc6IDB4NTM0MyxcbiAgICAweDkwRTg6IDB4NTM2MCxcbiAgICAweDkwRTk6IDB4NUJBMyxcbiAgICAweDkwRUE6IDB4NUMwMixcbiAgICAweDkwRUI6IDB4NUMxNixcbiAgICAweDkwRUM6IDB4NURERCxcbiAgICAweDkwRUQ6IDB4NjIyNixcbiAgICAweDkwRUU6IDB4NjI0NyxcbiAgICAweDkwRUY6IDB4NjRCMCxcbiAgICAweDkwRjA6IDB4NjgxMyxcbiAgICAweDkwRjE6IDB4NjgzNCxcbiAgICAweDkwRjI6IDB4NkNDOSxcbiAgICAweDkwRjM6IDB4NkQ0NSxcbiAgICAweDkwRjQ6IDB4NkQxNyxcbiAgICAweDkwRjU6IDB4NjdEMyxcbiAgICAweDkwRjY6IDB4NkY1QyxcbiAgICAweDkwRjc6IDB4NzE0RSxcbiAgICAweDkwRjg6IDB4NzE3RCxcbiAgICAweDkwRjk6IDB4NjVDQixcbiAgICAweDkwRkE6IDB4N0E3RixcbiAgICAweDkwRkI6IDB4N0JBRCxcbiAgICAweDkwRkM6IDB4N0REQSxcbiAgICAweDkxNDA6IDB4N0U0QSxcbiAgICAweDkxNDE6IDB4N0ZBOCxcbiAgICAweDkxNDI6IDB4ODE3QSxcbiAgICAweDkxNDM6IDB4ODIxQixcbiAgICAweDkxNDQ6IDB4ODIzOSxcbiAgICAweDkxNDU6IDB4ODVBNixcbiAgICAweDkxNDY6IDB4OEE2RSxcbiAgICAweDkxNDc6IDB4OENDRSxcbiAgICAweDkxNDg6IDB4OERGNSxcbiAgICAweDkxNDk6IDB4OTA3OCxcbiAgICAweDkxNEE6IDB4OTA3NyxcbiAgICAweDkxNEI6IDB4OTJBRCxcbiAgICAweDkxNEM6IDB4OTI5MSxcbiAgICAweDkxNEQ6IDB4OTU4MyxcbiAgICAweDkxNEU6IDB4OUJBRSxcbiAgICAweDkxNEY6IDB4NTI0RCxcbiAgICAweDkxNTA6IDB4NTU4NCxcbiAgICAweDkxNTE6IDB4NkYzOCxcbiAgICAweDkxNTI6IDB4NzEzNixcbiAgICAweDkxNTM6IDB4NTE2OCxcbiAgICAweDkxNTQ6IDB4Nzk4NSxcbiAgICAweDkxNTU6IDB4N0U1NSxcbiAgICAweDkxNTY6IDB4ODFCMyxcbiAgICAweDkxNTc6IDB4N0NDRSxcbiAgICAweDkxNTg6IDB4NTY0QyxcbiAgICAweDkxNTk6IDB4NTg1MSxcbiAgICAweDkxNUE6IDB4NUNBOCxcbiAgICAweDkxNUI6IDB4NjNBQSxcbiAgICAweDkxNUM6IDB4NjZGRSxcbiAgICAweDkxNUQ6IDB4NjZGRCxcbiAgICAweDkxNUU6IDB4Njk1QSxcbiAgICAweDkxNUY6IDB4NzJEOSxcbiAgICAweDkxNjA6IDB4NzU4RixcbiAgICAweDkxNjE6IDB4NzU4RSxcbiAgICAweDkxNjI6IDB4NzkwRSxcbiAgICAweDkxNjM6IDB4Nzk1NixcbiAgICAweDkxNjQ6IDB4NzlERixcbiAgICAweDkxNjU6IDB4N0M5NyxcbiAgICAweDkxNjY6IDB4N0QyMCxcbiAgICAweDkxNjc6IDB4N0Q0NCxcbiAgICAweDkxNjg6IDB4ODYwNyxcbiAgICAweDkxNjk6IDB4OEEzNCxcbiAgICAweDkxNkE6IDB4OTYzQixcbiAgICAweDkxNkI6IDB4OTA2MSxcbiAgICAweDkxNkM6IDB4OUYyMCxcbiAgICAweDkxNkQ6IDB4NTBFNyxcbiAgICAweDkxNkU6IDB4NTI3NSxcbiAgICAweDkxNkY6IDB4NTNDQyxcbiAgICAweDkxNzA6IDB4NTNFMixcbiAgICAweDkxNzE6IDB4NTAwOSxcbiAgICAweDkxNzI6IDB4NTVBQSxcbiAgICAweDkxNzM6IDB4NThFRSxcbiAgICAweDkxNzQ6IDB4NTk0RixcbiAgICAweDkxNzU6IDB4NzIzRCxcbiAgICAweDkxNzY6IDB4NUI4QixcbiAgICAweDkxNzc6IDB4NUM2NCxcbiAgICAweDkxNzg6IDB4NTMxRCxcbiAgICAweDkxNzk6IDB4NjBFMyxcbiAgICAweDkxN0E6IDB4NjBGMyxcbiAgICAweDkxN0I6IDB4NjM1QyxcbiAgICAweDkxN0M6IDB4NjM4MyxcbiAgICAweDkxN0Q6IDB4NjMzRixcbiAgICAweDkxN0U6IDB4NjNCQixcbiAgICAweDkxODA6IDB4NjRDRCxcbiAgICAweDkxODE6IDB4NjVFOSxcbiAgICAweDkxODI6IDB4NjZGOSxcbiAgICAweDkxODM6IDB4NURFMyxcbiAgICAweDkxODQ6IDB4NjlDRCxcbiAgICAweDkxODU6IDB4NjlGRCxcbiAgICAweDkxODY6IDB4NkYxNSxcbiAgICAweDkxODc6IDB4NzFFNSxcbiAgICAweDkxODg6IDB4NEU4OSxcbiAgICAweDkxODk6IDB4NzVFOSxcbiAgICAweDkxOEE6IDB4NzZGOCxcbiAgICAweDkxOEI6IDB4N0E5MyxcbiAgICAweDkxOEM6IDB4N0NERixcbiAgICAweDkxOEQ6IDB4N0RDRixcbiAgICAweDkxOEU6IDB4N0Q5QyxcbiAgICAweDkxOEY6IDB4ODA2MSxcbiAgICAweDkxOTA6IDB4ODM0OSxcbiAgICAweDkxOTE6IDB4ODM1OCxcbiAgICAweDkxOTI6IDB4ODQ2QyxcbiAgICAweDkxOTM6IDB4ODRCQyxcbiAgICAweDkxOTQ6IDB4ODVGQixcbiAgICAweDkxOTU6IDB4ODhDNSxcbiAgICAweDkxOTY6IDB4OEQ3MCxcbiAgICAweDkxOTc6IDB4OTAwMSxcbiAgICAweDkxOTg6IDB4OTA2RCxcbiAgICAweDkxOTk6IDB4OTM5NyxcbiAgICAweDkxOUE6IDB4OTcxQyxcbiAgICAweDkxOUI6IDB4OUExMixcbiAgICAweDkxOUM6IDB4NTBDRixcbiAgICAweDkxOUQ6IDB4NTg5NyxcbiAgICAweDkxOUU6IDB4NjE4RSxcbiAgICAweDkxOUY6IDB4ODFEMyxcbiAgICAweDkxQTA6IDB4ODUzNSxcbiAgICAweDkxQTE6IDB4OEQwOCxcbiAgICAweDkxQTI6IDB4OTAyMCxcbiAgICAweDkxQTM6IDB4NEZDMyxcbiAgICAweDkxQTQ6IDB4NTA3NCxcbiAgICAweDkxQTU6IDB4NTI0NyxcbiAgICAweDkxQTY6IDB4NTM3MyxcbiAgICAweDkxQTc6IDB4NjA2RixcbiAgICAweDkxQTg6IDB4NjM0OSxcbiAgICAweDkxQTk6IDB4Njc1RixcbiAgICAweDkxQUE6IDB4NkUyQyxcbiAgICAweDkxQUI6IDB4OERCMyxcbiAgICAweDkxQUM6IDB4OTAxRixcbiAgICAweDkxQUQ6IDB4NEZENyxcbiAgICAweDkxQUU6IDB4NUM1RSxcbiAgICAweDkxQUY6IDB4OENDQSxcbiAgICAweDkxQjA6IDB4NjVDRixcbiAgICAweDkxQjE6IDB4N0Q5QSxcbiAgICAweDkxQjI6IDB4NTM1MixcbiAgICAweDkxQjM6IDB4ODg5NixcbiAgICAweDkxQjQ6IDB4NTE3NixcbiAgICAweDkxQjU6IDB4NjNDMyxcbiAgICAweDkxQjY6IDB4NUI1OCxcbiAgICAweDkxQjc6IDB4NUI2QixcbiAgICAweDkxQjg6IDB4NUMwQSxcbiAgICAweDkxQjk6IDB4NjQwRCxcbiAgICAweDkxQkE6IDB4Njc1MSxcbiAgICAweDkxQkI6IDB4OTA1QyxcbiAgICAweDkxQkM6IDB4NEVENixcbiAgICAweDkxQkQ6IDB4NTkxQSxcbiAgICAweDkxQkU6IDB4NTkyQSxcbiAgICAweDkxQkY6IDB4NkM3MCxcbiAgICAweDkxQzA6IDB4OEE1MSxcbiAgICAweDkxQzE6IDB4NTUzRSxcbiAgICAweDkxQzI6IDB4NTgxNSxcbiAgICAweDkxQzM6IDB4NTlBNSxcbiAgICAweDkxQzQ6IDB4NjBGMCxcbiAgICAweDkxQzU6IDB4NjI1MyxcbiAgICAweDkxQzY6IDB4NjdDMSxcbiAgICAweDkxQzc6IDB4ODIzNSxcbiAgICAweDkxQzg6IDB4Njk1NSxcbiAgICAweDkxQzk6IDB4OTY0MCxcbiAgICAweDkxQ0E6IDB4OTlDNCxcbiAgICAweDkxQ0I6IDB4OUEyOCxcbiAgICAweDkxQ0M6IDB4NEY1MyxcbiAgICAweDkxQ0Q6IDB4NTgwNixcbiAgICAweDkxQ0U6IDB4NUJGRSxcbiAgICAweDkxQ0Y6IDB4ODAxMCxcbiAgICAweDkxRDA6IDB4NUNCMSxcbiAgICAweDkxRDE6IDB4NUUyRixcbiAgICAweDkxRDI6IDB4NUY4NSxcbiAgICAweDkxRDM6IDB4NjAyMCxcbiAgICAweDkxRDQ6IDB4NjE0QixcbiAgICAweDkxRDU6IDB4NjIzNCxcbiAgICAweDkxRDY6IDB4NjZGRixcbiAgICAweDkxRDc6IDB4NkNGMCxcbiAgICAweDkxRDg6IDB4NkVERSxcbiAgICAweDkxRDk6IDB4ODBDRSxcbiAgICAweDkxREE6IDB4ODE3RixcbiAgICAweDkxREI6IDB4ODJENCxcbiAgICAweDkxREM6IDB4ODg4QixcbiAgICAweDkxREQ6IDB4OENCOCxcbiAgICAweDkxREU6IDB4OTAwMCxcbiAgICAweDkxREY6IDB4OTAyRSxcbiAgICAweDkxRTA6IDB4OTY4QSxcbiAgICAweDkxRTE6IDB4OUVEQixcbiAgICAweDkxRTI6IDB4OUJEQixcbiAgICAweDkxRTM6IDB4NEVFMyxcbiAgICAweDkxRTQ6IDB4NTNGMCxcbiAgICAweDkxRTU6IDB4NTkyNyxcbiAgICAweDkxRTY6IDB4N0IyQyxcbiAgICAweDkxRTc6IDB4OTE4RCxcbiAgICAweDkxRTg6IDB4OTg0QyxcbiAgICAweDkxRTk6IDB4OURGOSxcbiAgICAweDkxRUE6IDB4NkVERCxcbiAgICAweDkxRUI6IDB4NzAyNyxcbiAgICAweDkxRUM6IDB4NTM1MyxcbiAgICAweDkxRUQ6IDB4NTU0NCxcbiAgICAweDkxRUU6IDB4NUI4NSxcbiAgICAweDkxRUY6IDB4NjI1OCxcbiAgICAweDkxRjA6IDB4NjI5RSxcbiAgICAweDkxRjE6IDB4NjJEMyxcbiAgICAweDkxRjI6IDB4NkNBMixcbiAgICAweDkxRjM6IDB4NkZFRixcbiAgICAweDkxRjQ6IDB4NzQyMixcbiAgICAweDkxRjU6IDB4OEExNyxcbiAgICAweDkxRjY6IDB4OTQzOCxcbiAgICAweDkxRjc6IDB4NkZDMSxcbiAgICAweDkxRjg6IDB4OEFGRSxcbiAgICAweDkxRjk6IDB4ODMzOCxcbiAgICAweDkxRkE6IDB4NTFFNyxcbiAgICAweDkxRkI6IDB4ODZGOCxcbiAgICAweDkxRkM6IDB4NTNFQSxcbiAgICAweDkyNDA6IDB4NTNFOSxcbiAgICAweDkyNDE6IDB4NEY0NixcbiAgICAweDkyNDI6IDB4OTA1NCxcbiAgICAweDkyNDM6IDB4OEZCMCxcbiAgICAweDkyNDQ6IDB4NTk2QSxcbiAgICAweDkyNDU6IDB4ODEzMSxcbiAgICAweDkyNDY6IDB4NURGRCxcbiAgICAweDkyNDc6IDB4N0FFQSxcbiAgICAweDkyNDg6IDB4OEZCRixcbiAgICAweDkyNDk6IDB4NjhEQSxcbiAgICAweDkyNEE6IDB4OEMzNyxcbiAgICAweDkyNEI6IDB4NzJGOCxcbiAgICAweDkyNEM6IDB4OUM0OCxcbiAgICAweDkyNEQ6IDB4NkEzRCxcbiAgICAweDkyNEU6IDB4OEFCMCxcbiAgICAweDkyNEY6IDB4NEUzOSxcbiAgICAweDkyNTA6IDB4NTM1OCxcbiAgICAweDkyNTE6IDB4NTYwNixcbiAgICAweDkyNTI6IDB4NTc2NixcbiAgICAweDkyNTM6IDB4NjJDNSxcbiAgICAweDkyNTQ6IDB4NjNBMixcbiAgICAweDkyNTU6IDB4NjVFNixcbiAgICAweDkyNTY6IDB4NkI0RSxcbiAgICAweDkyNTc6IDB4NkRFMSxcbiAgICAweDkyNTg6IDB4NkU1QixcbiAgICAweDkyNTk6IDB4NzBBRCxcbiAgICAweDkyNUE6IDB4NzdFRCxcbiAgICAweDkyNUI6IDB4N0FFRixcbiAgICAweDkyNUM6IDB4N0JBQSxcbiAgICAweDkyNUQ6IDB4N0RCQixcbiAgICAweDkyNUU6IDB4ODAzRCxcbiAgICAweDkyNUY6IDB4ODBDNixcbiAgICAweDkyNjA6IDB4ODZDQixcbiAgICAweDkyNjE6IDB4OEE5NSxcbiAgICAweDkyNjI6IDB4OTM1QixcbiAgICAweDkyNjM6IDB4NTZFMyxcbiAgICAweDkyNjQ6IDB4NThDNyxcbiAgICAweDkyNjU6IDB4NUYzRSxcbiAgICAweDkyNjY6IDB4NjVBRCxcbiAgICAweDkyNjc6IDB4NjY5NixcbiAgICAweDkyNjg6IDB4NkE4MCxcbiAgICAweDkyNjk6IDB4NkJCNSxcbiAgICAweDkyNkE6IDB4NzUzNyxcbiAgICAweDkyNkI6IDB4OEFDNyxcbiAgICAweDkyNkM6IDB4NTAyNCxcbiAgICAweDkyNkQ6IDB4NzdFNSxcbiAgICAweDkyNkU6IDB4NTczMCxcbiAgICAweDkyNkY6IDB4NUYxQixcbiAgICAweDkyNzA6IDB4NjA2NSxcbiAgICAweDkyNzE6IDB4NjY3QSxcbiAgICAweDkyNzI6IDB4NkM2MCxcbiAgICAweDkyNzM6IDB4NzVGNCxcbiAgICAweDkyNzQ6IDB4N0ExQSxcbiAgICAweDkyNzU6IDB4N0Y2RSxcbiAgICAweDkyNzY6IDB4ODFGNCxcbiAgICAweDkyNzc6IDB4ODcxOCxcbiAgICAweDkyNzg6IDB4OTA0NSxcbiAgICAweDkyNzk6IDB4OTlCMyxcbiAgICAweDkyN0E6IDB4N0JDOSxcbiAgICAweDkyN0I6IDB4NzU1QyxcbiAgICAweDkyN0M6IDB4N0FGOSxcbiAgICAweDkyN0Q6IDB4N0I1MSxcbiAgICAweDkyN0U6IDB4ODRDNCxcbiAgICAweDkyODA6IDB4OTAxMCxcbiAgICAweDkyODE6IDB4NzlFOSxcbiAgICAweDkyODI6IDB4N0E5MixcbiAgICAweDkyODM6IDB4ODMzNixcbiAgICAweDkyODQ6IDB4NUFFMSxcbiAgICAweDkyODU6IDB4Nzc0MCxcbiAgICAweDkyODY6IDB4NEUyRCxcbiAgICAweDkyODc6IDB4NEVGMixcbiAgICAweDkyODg6IDB4NUI5OSxcbiAgICAweDkyODk6IDB4NUZFMCxcbiAgICAweDkyOEE6IDB4NjJCRCxcbiAgICAweDkyOEI6IDB4NjYzQyxcbiAgICAweDkyOEM6IDB4NjdGMSxcbiAgICAweDkyOEQ6IDB4NkNFOCxcbiAgICAweDkyOEU6IDB4ODY2QixcbiAgICAweDkyOEY6IDB4ODg3NyxcbiAgICAweDkyOTA6IDB4OEEzQixcbiAgICAweDkyOTE6IDB4OTE0RSxcbiAgICAweDkyOTI6IDB4OTJGMyxcbiAgICAweDkyOTM6IDB4OTlEMCxcbiAgICAweDkyOTQ6IDB4NkExNyxcbiAgICAweDkyOTU6IDB4NzAyNixcbiAgICAweDkyOTY6IDB4NzMyQSxcbiAgICAweDkyOTc6IDB4ODJFNyxcbiAgICAweDkyOTg6IDB4ODQ1NyxcbiAgICAweDkyOTk6IDB4OENBRixcbiAgICAweDkyOUE6IDB4NEUwMSxcbiAgICAweDkyOUI6IDB4NTE0NixcbiAgICAweDkyOUM6IDB4NTFDQixcbiAgICAweDkyOUQ6IDB4NTU4QixcbiAgICAweDkyOUU6IDB4NUJGNSxcbiAgICAweDkyOUY6IDB4NUUxNixcbiAgICAweDkyQTA6IDB4NUUzMyxcbiAgICAweDkyQTE6IDB4NUU4MSxcbiAgICAweDkyQTI6IDB4NUYxNCxcbiAgICAweDkyQTM6IDB4NUYzNSxcbiAgICAweDkyQTQ6IDB4NUY2QixcbiAgICAweDkyQTU6IDB4NUZCNCxcbiAgICAweDkyQTY6IDB4NjFGMixcbiAgICAweDkyQTc6IDB4NjMxMSxcbiAgICAweDkyQTg6IDB4NjZBMixcbiAgICAweDkyQTk6IDB4NjcxRCxcbiAgICAweDkyQUE6IDB4NkY2RSxcbiAgICAweDkyQUI6IDB4NzI1MixcbiAgICAweDkyQUM6IDB4NzUzQSxcbiAgICAweDkyQUQ6IDB4NzczQSxcbiAgICAweDkyQUU6IDB4ODA3NCxcbiAgICAweDkyQUY6IDB4ODEzOSxcbiAgICAweDkyQjA6IDB4ODE3OCxcbiAgICAweDkyQjE6IDB4ODc3NixcbiAgICAweDkyQjI6IDB4OEFCRixcbiAgICAweDkyQjM6IDB4OEFEQyxcbiAgICAweDkyQjQ6IDB4OEQ4NSxcbiAgICAweDkyQjU6IDB4OERGMyxcbiAgICAweDkyQjY6IDB4OTI5QSxcbiAgICAweDkyQjc6IDB4OTU3NyxcbiAgICAweDkyQjg6IDB4OTgwMixcbiAgICAweDkyQjk6IDB4OUNFNSxcbiAgICAweDkyQkE6IDB4NTJDNSxcbiAgICAweDkyQkI6IDB4NjM1NyxcbiAgICAweDkyQkM6IDB4NzZGNCxcbiAgICAweDkyQkQ6IDB4NjcxNSxcbiAgICAweDkyQkU6IDB4NkM4OCxcbiAgICAweDkyQkY6IDB4NzNDRCxcbiAgICAweDkyQzA6IDB4OENDMyxcbiAgICAweDkyQzE6IDB4OTNBRSxcbiAgICAweDkyQzI6IDB4OTY3MyxcbiAgICAweDkyQzM6IDB4NkQyNSxcbiAgICAweDkyQzQ6IDB4NTg5QyxcbiAgICAweDkyQzU6IDB4NjkwRSxcbiAgICAweDkyQzY6IDB4NjlDQyxcbiAgICAweDkyQzc6IDB4OEZGRCxcbiAgICAweDkyQzg6IDB4OTM5QSxcbiAgICAweDkyQzk6IDB4NzVEQixcbiAgICAweDkyQ0E6IDB4OTAxQSxcbiAgICAweDkyQ0I6IDB4NTg1QSxcbiAgICAweDkyQ0M6IDB4NjgwMixcbiAgICAweDkyQ0Q6IDB4NjNCNCxcbiAgICAweDkyQ0U6IDB4NjlGQixcbiAgICAweDkyQ0Y6IDB4NEY0MyxcbiAgICAweDkyRDA6IDB4NkYyQyxcbiAgICAweDkyRDE6IDB4NjdEOCxcbiAgICAweDkyRDI6IDB4OEZCQixcbiAgICAweDkyRDM6IDB4ODUyNixcbiAgICAweDkyRDQ6IDB4N0RCNCxcbiAgICAweDkyRDU6IDB4OTM1NCxcbiAgICAweDkyRDY6IDB4NjkzRixcbiAgICAweDkyRDc6IDB4NkY3MCxcbiAgICAweDkyRDg6IDB4NTc2QSxcbiAgICAweDkyRDk6IDB4NThGNyxcbiAgICAweDkyREE6IDB4NUIyQyxcbiAgICAweDkyREI6IDB4N0QyQyxcbiAgICAweDkyREM6IDB4NzIyQSxcbiAgICAweDkyREQ6IDB4NTQwQSxcbiAgICAweDkyREU6IDB4OTFFMyxcbiAgICAweDkyREY6IDB4OURCNCxcbiAgICAweDkyRTA6IDB4NEVBRCxcbiAgICAweDkyRTE6IDB4NEY0RSxcbiAgICAweDkyRTI6IDB4NTA1QyxcbiAgICAweDkyRTM6IDB4NTA3NSxcbiAgICAweDkyRTQ6IDB4NTI0MyxcbiAgICAweDkyRTU6IDB4OEM5RSxcbiAgICAweDkyRTY6IDB4NTQ0OCxcbiAgICAweDkyRTc6IDB4NTgyNCxcbiAgICAweDkyRTg6IDB4NUI5QSxcbiAgICAweDkyRTk6IDB4NUUxRCxcbiAgICAweDkyRUE6IDB4NUU5NSxcbiAgICAweDkyRUI6IDB4NUVBRCxcbiAgICAweDkyRUM6IDB4NUVGNyxcbiAgICAweDkyRUQ6IDB4NUYxRixcbiAgICAweDkyRUU6IDB4NjA4QyxcbiAgICAweDkyRUY6IDB4NjJCNSxcbiAgICAweDkyRjA6IDB4NjMzQSxcbiAgICAweDkyRjE6IDB4NjNEMCxcbiAgICAweDkyRjI6IDB4NjhBRixcbiAgICAweDkyRjM6IDB4NkM0MCxcbiAgICAweDkyRjQ6IDB4Nzg4NyxcbiAgICAweDkyRjU6IDB4Nzk4RSxcbiAgICAweDkyRjY6IDB4N0EwQixcbiAgICAweDkyRjc6IDB4N0RFMCxcbiAgICAweDkyRjg6IDB4ODI0NyxcbiAgICAweDkyRjk6IDB4OEEwMixcbiAgICAweDkyRkE6IDB4OEFFNixcbiAgICAweDkyRkI6IDB4OEU0NCxcbiAgICAweDkyRkM6IDB4OTAxMyxcbiAgICAweDkzNDA6IDB4OTBCOCxcbiAgICAweDkzNDE6IDB4OTEyRCxcbiAgICAweDkzNDI6IDB4OTFEOCxcbiAgICAweDkzNDM6IDB4OUYwRSxcbiAgICAweDkzNDQ6IDB4NkNFNSxcbiAgICAweDkzNDU6IDB4NjQ1OCxcbiAgICAweDkzNDY6IDB4NjRFMixcbiAgICAweDkzNDc6IDB4NjU3NSxcbiAgICAweDkzNDg6IDB4NkVGNCxcbiAgICAweDkzNDk6IDB4NzY4NCxcbiAgICAweDkzNEE6IDB4N0IxQixcbiAgICAweDkzNEI6IDB4OTA2OSxcbiAgICAweDkzNEM6IDB4OTNEMSxcbiAgICAweDkzNEQ6IDB4NkVCQSxcbiAgICAweDkzNEU6IDB4NTRGMixcbiAgICAweDkzNEY6IDB4NUZCOSxcbiAgICAweDkzNTA6IDB4NjRBNCxcbiAgICAweDkzNTE6IDB4OEY0RCxcbiAgICAweDkzNTI6IDB4OEZFRCxcbiAgICAweDkzNTM6IDB4OTI0NCxcbiAgICAweDkzNTQ6IDB4NTE3OCxcbiAgICAweDkzNTU6IDB4NTg2QixcbiAgICAweDkzNTY6IDB4NTkyOSxcbiAgICAweDkzNTc6IDB4NUM1NSxcbiAgICAweDkzNTg6IDB4NUU5NyxcbiAgICAweDkzNTk6IDB4NkRGQixcbiAgICAweDkzNUE6IDB4N0U4RixcbiAgICAweDkzNUI6IDB4NzUxQyxcbiAgICAweDkzNUM6IDB4OENCQyxcbiAgICAweDkzNUQ6IDB4OEVFMixcbiAgICAweDkzNUU6IDB4OTg1QixcbiAgICAweDkzNUY6IDB4NzBCOSxcbiAgICAweDkzNjA6IDB4NEYxRCxcbiAgICAweDkzNjE6IDB4NkJCRixcbiAgICAweDkzNjI6IDB4NkZCMSxcbiAgICAweDkzNjM6IDB4NzUzMCxcbiAgICAweDkzNjQ6IDB4OTZGQixcbiAgICAweDkzNjU6IDB4NTE0RSxcbiAgICAweDkzNjY6IDB4NTQxMCxcbiAgICAweDkzNjc6IDB4NTgzNSxcbiAgICAweDkzNjg6IDB4NTg1NyxcbiAgICAweDkzNjk6IDB4NTlBQyxcbiAgICAweDkzNkE6IDB4NUM2MCxcbiAgICAweDkzNkI6IDB4NUY5MixcbiAgICAweDkzNkM6IDB4NjU5NyxcbiAgICAweDkzNkQ6IDB4Njc1QyxcbiAgICAweDkzNkU6IDB4NkUyMSxcbiAgICAweDkzNkY6IDB4NzY3QixcbiAgICAweDkzNzA6IDB4ODNERixcbiAgICAweDkzNzE6IDB4OENFRCxcbiAgICAweDkzNzI6IDB4OTAxNCxcbiAgICAweDkzNzM6IDB4OTBGRCxcbiAgICAweDkzNzQ6IDB4OTM0RCxcbiAgICAweDkzNzU6IDB4NzgyNSxcbiAgICAweDkzNzY6IDB4NzgzQSxcbiAgICAweDkzNzc6IDB4NTJBQSxcbiAgICAweDkzNzg6IDB4NUVBNixcbiAgICAweDkzNzk6IDB4NTcxRixcbiAgICAweDkzN0E6IDB4NTk3NCxcbiAgICAweDkzN0I6IDB4NjAxMixcbiAgICAweDkzN0M6IDB4NTAxMixcbiAgICAweDkzN0Q6IDB4NTE1QSxcbiAgICAweDkzN0U6IDB4NTFBQyxcbiAgICAweDkzODA6IDB4NTFDRCxcbiAgICAweDkzODE6IDB4NTIwMCxcbiAgICAweDkzODI6IDB4NTUxMCxcbiAgICAweDkzODM6IDB4NTg1NCxcbiAgICAweDkzODQ6IDB4NTg1OCxcbiAgICAweDkzODU6IDB4NTk1NyxcbiAgICAweDkzODY6IDB4NUI5NSxcbiAgICAweDkzODc6IDB4NUNGNixcbiAgICAweDkzODg6IDB4NUQ4QixcbiAgICAweDkzODk6IDB4NjBCQyxcbiAgICAweDkzOEE6IDB4NjI5NSxcbiAgICAweDkzOEI6IDB4NjQyRCxcbiAgICAweDkzOEM6IDB4Njc3MSxcbiAgICAweDkzOEQ6IDB4Njg0MyxcbiAgICAweDkzOEU6IDB4NjhCQyxcbiAgICAweDkzOEY6IDB4NjhERixcbiAgICAweDkzOTA6IDB4NzZENyxcbiAgICAweDkzOTE6IDB4NkREOCxcbiAgICAweDkzOTI6IDB4NkU2RixcbiAgICAweDkzOTM6IDB4NkQ5QixcbiAgICAweDkzOTQ6IDB4NzA2RixcbiAgICAweDkzOTU6IDB4NzFDOCxcbiAgICAweDkzOTY6IDB4NUY1MyxcbiAgICAweDkzOTc6IDB4NzVEOCxcbiAgICAweDkzOTg6IDB4Nzk3NyxcbiAgICAweDkzOTk6IDB4N0I0OSxcbiAgICAweDkzOUE6IDB4N0I1NCxcbiAgICAweDkzOUI6IDB4N0I1MixcbiAgICAweDkzOUM6IDB4N0NENixcbiAgICAweDkzOUQ6IDB4N0Q3MSxcbiAgICAweDkzOUU6IDB4NTIzMCxcbiAgICAweDkzOUY6IDB4ODQ2MyxcbiAgICAweDkzQTA6IDB4ODU2OSxcbiAgICAweDkzQTE6IDB4ODVFNCxcbiAgICAweDkzQTI6IDB4OEEwRSxcbiAgICAweDkzQTM6IDB4OEIwNCxcbiAgICAweDkzQTQ6IDB4OEM0NixcbiAgICAweDkzQTU6IDB4OEUwRixcbiAgICAweDkzQTY6IDB4OTAwMyxcbiAgICAweDkzQTc6IDB4OTAwRixcbiAgICAweDkzQTg6IDB4OTQxOSxcbiAgICAweDkzQTk6IDB4OTY3NixcbiAgICAweDkzQUE6IDB4OTgyRCxcbiAgICAweDkzQUI6IDB4OUEzMCxcbiAgICAweDkzQUM6IDB4OTVEOCxcbiAgICAweDkzQUQ6IDB4NTBDRCxcbiAgICAweDkzQUU6IDB4NTJENSxcbiAgICAweDkzQUY6IDB4NTQwQyxcbiAgICAweDkzQjA6IDB4NTgwMixcbiAgICAweDkzQjE6IDB4NUMwRSxcbiAgICAweDkzQjI6IDB4NjFBNyxcbiAgICAweDkzQjM6IDB4NjQ5RSxcbiAgICAweDkzQjQ6IDB4NkQxRSxcbiAgICAweDkzQjU6IDB4NzdCMyxcbiAgICAweDkzQjY6IDB4N0FFNSxcbiAgICAweDkzQjc6IDB4ODBGNCxcbiAgICAweDkzQjg6IDB4ODQwNCxcbiAgICAweDkzQjk6IDB4OTA1MyxcbiAgICAweDkzQkE6IDB4OTI4NSxcbiAgICAweDkzQkI6IDB4NUNFMCxcbiAgICAweDkzQkM6IDB4OUQwNyxcbiAgICAweDkzQkQ6IDB4NTMzRixcbiAgICAweDkzQkU6IDB4NUY5NyxcbiAgICAweDkzQkY6IDB4NUZCMyxcbiAgICAweDkzQzA6IDB4NkQ5QyxcbiAgICAweDkzQzE6IDB4NzI3OSxcbiAgICAweDkzQzI6IDB4Nzc2MyxcbiAgICAweDkzQzM6IDB4NzlCRixcbiAgICAweDkzQzQ6IDB4N0JFNCxcbiAgICAweDkzQzU6IDB4NkJEMixcbiAgICAweDkzQzY6IDB4NzJFQyxcbiAgICAweDkzQzc6IDB4OEFBRCxcbiAgICAweDkzQzg6IDB4NjgwMyxcbiAgICAweDkzQzk6IDB4NkE2MSxcbiAgICAweDkzQ0E6IDB4NTFGOCxcbiAgICAweDkzQ0I6IDB4N0E4MSxcbiAgICAweDkzQ0M6IDB4NjkzNCxcbiAgICAweDkzQ0Q6IDB4NUM0QSxcbiAgICAweDkzQ0U6IDB4OUNGNixcbiAgICAweDkzQ0Y6IDB4ODJFQixcbiAgICAweDkzRDA6IDB4NUJDNSxcbiAgICAweDkzRDE6IDB4OTE0OSxcbiAgICAweDkzRDI6IDB4NzAxRSxcbiAgICAweDkzRDM6IDB4NTY3OCxcbiAgICAweDkzRDQ6IDB4NUM2RixcbiAgICAweDkzRDU6IDB4NjBDNyxcbiAgICAweDkzRDY6IDB4NjU2NixcbiAgICAweDkzRDc6IDB4NkM4QyxcbiAgICAweDkzRDg6IDB4OEM1QSxcbiAgICAweDkzRDk6IDB4OTA0MSxcbiAgICAweDkzREE6IDB4OTgxMyxcbiAgICAweDkzREI6IDB4NTQ1MSxcbiAgICAweDkzREM6IDB4NjZDNyxcbiAgICAweDkzREQ6IDB4OTIwRCxcbiAgICAweDkzREU6IDB4NTk0OCxcbiAgICAweDkzREY6IDB4OTBBMyxcbiAgICAweDkzRTA6IDB4NTE4NSxcbiAgICAweDkzRTE6IDB4NEU0RCxcbiAgICAweDkzRTI6IDB4NTFFQSxcbiAgICAweDkzRTM6IDB4ODU5OSxcbiAgICAweDkzRTQ6IDB4OEIwRSxcbiAgICAweDkzRTU6IDB4NzA1OCxcbiAgICAweDkzRTY6IDB4NjM3QSxcbiAgICAweDkzRTc6IDB4OTM0QixcbiAgICAweDkzRTg6IDB4Njk2MixcbiAgICAweDkzRTk6IDB4OTlCNCxcbiAgICAweDkzRUE6IDB4N0UwNCxcbiAgICAweDkzRUI6IDB4NzU3NyxcbiAgICAweDkzRUM6IDB4NTM1NyxcbiAgICAweDkzRUQ6IDB4Njk2MCxcbiAgICAweDkzRUU6IDB4OEVERixcbiAgICAweDkzRUY6IDB4OTZFMyxcbiAgICAweDkzRjA6IDB4NkM1RCxcbiAgICAweDkzRjE6IDB4NEU4QyxcbiAgICAweDkzRjI6IDB4NUMzQyxcbiAgICAweDkzRjM6IDB4NUYxMCxcbiAgICAweDkzRjQ6IDB4OEZFOSxcbiAgICAweDkzRjU6IDB4NTMwMixcbiAgICAweDkzRjY6IDB4OENEMSxcbiAgICAweDkzRjc6IDB4ODA4OSxcbiAgICAweDkzRjg6IDB4ODY3OSxcbiAgICAweDkzRjk6IDB4NUVGRixcbiAgICAweDkzRkE6IDB4NjVFNSxcbiAgICAweDkzRkI6IDB4NEU3MyxcbiAgICAweDkzRkM6IDB4NTE2NSxcbiAgICAweDk0NDA6IDB4NTk4MixcbiAgICAweDk0NDE6IDB4NUMzRixcbiAgICAweDk0NDI6IDB4OTdFRSxcbiAgICAweDk0NDM6IDB4NEVGQixcbiAgICAweDk0NDQ6IDB4NTk4QSxcbiAgICAweDk0NDU6IDB4NUZDRCxcbiAgICAweDk0NDY6IDB4OEE4RCxcbiAgICAweDk0NDc6IDB4NkZFMSxcbiAgICAweDk0NDg6IDB4NzlCMCxcbiAgICAweDk0NDk6IDB4Nzk2MixcbiAgICAweDk0NEE6IDB4NUJFNyxcbiAgICAweDk0NEI6IDB4ODQ3MSxcbiAgICAweDk0NEM6IDB4NzMyQixcbiAgICAweDk0NEQ6IDB4NzFCMSxcbiAgICAweDk0NEU6IDB4NUU3NCxcbiAgICAweDk0NEY6IDB4NUZGNSxcbiAgICAweDk0NTA6IDB4NjM3QixcbiAgICAweDk0NTE6IDB4NjQ5QSxcbiAgICAweDk0NTI6IDB4NzFDMyxcbiAgICAweDk0NTM6IDB4N0M5OCxcbiAgICAweDk0NTQ6IDB4NEU0MyxcbiAgICAweDk0NTU6IDB4NUVGQyxcbiAgICAweDk0NTY6IDB4NEU0QixcbiAgICAweDk0NTc6IDB4NTdEQyxcbiAgICAweDk0NTg6IDB4NTZBMixcbiAgICAweDk0NTk6IDB4NjBBOSxcbiAgICAweDk0NUE6IDB4NkZDMyxcbiAgICAweDk0NUI6IDB4N0QwRCxcbiAgICAweDk0NUM6IDB4ODBGRCxcbiAgICAweDk0NUQ6IDB4ODEzMyxcbiAgICAweDk0NUU6IDB4ODFCRixcbiAgICAweDk0NUY6IDB4OEZCMixcbiAgICAweDk0NjA6IDB4ODk5NyxcbiAgICAweDk0NjE6IDB4ODZBNCxcbiAgICAweDk0NjI6IDB4NURGNCxcbiAgICAweDk0NjM6IDB4NjI4QSxcbiAgICAweDk0NjQ6IDB4NjRBRCxcbiAgICAweDk0NjU6IDB4ODk4NyxcbiAgICAweDk0NjY6IDB4Njc3NyxcbiAgICAweDk0Njc6IDB4NkNFMixcbiAgICAweDk0Njg6IDB4NkQzRSxcbiAgICAweDk0Njk6IDB4NzQzNixcbiAgICAweDk0NkE6IDB4NzgzNCxcbiAgICAweDk0NkI6IDB4NUE0NixcbiAgICAweDk0NkM6IDB4N0Y3NSxcbiAgICAweDk0NkQ6IDB4ODJBRCxcbiAgICAweDk0NkU6IDB4OTlBQyxcbiAgICAweDk0NkY6IDB4NEZGMyxcbiAgICAweDk0NzA6IDB4NUVDMyxcbiAgICAweDk0NzE6IDB4NjJERCxcbiAgICAweDk0NzI6IDB4NjM5MixcbiAgICAweDk0NzM6IDB4NjU1NyxcbiAgICAweDk0NzQ6IDB4Njc2RixcbiAgICAweDk0NzU6IDB4NzZDMyxcbiAgICAweDk0NzY6IDB4NzI0QyxcbiAgICAweDk0Nzc6IDB4ODBDQyxcbiAgICAweDk0Nzg6IDB4ODBCQSxcbiAgICAweDk0Nzk6IDB4OEYyOSxcbiAgICAweDk0N0E6IDB4OTE0RCxcbiAgICAweDk0N0I6IDB4NTAwRCxcbiAgICAweDk0N0M6IDB4NTdGOSxcbiAgICAweDk0N0Q6IDB4NUE5MixcbiAgICAweDk0N0U6IDB4Njg4NSxcbiAgICAweDk0ODA6IDB4Njk3MyxcbiAgICAweDk0ODE6IDB4NzE2NCxcbiAgICAweDk0ODI6IDB4NzJGRCxcbiAgICAweDk0ODM6IDB4OENCNyxcbiAgICAweDk0ODQ6IDB4NThGMixcbiAgICAweDk0ODU6IDB4OENFMCxcbiAgICAweDk0ODY6IDB4OTY2QSxcbiAgICAweDk0ODc6IDB4OTAxOSxcbiAgICAweDk0ODg6IDB4ODc3RixcbiAgICAweDk0ODk6IDB4NzlFNCxcbiAgICAweDk0OEE6IDB4NzdFNyxcbiAgICAweDk0OEI6IDB4ODQyOSxcbiAgICAweDk0OEM6IDB4NEYyRixcbiAgICAweDk0OEQ6IDB4NTI2NSxcbiAgICAweDk0OEU6IDB4NTM1QSxcbiAgICAweDk0OEY6IDB4NjJDRCxcbiAgICAweDk0OTA6IDB4NjdDRixcbiAgICAweDk0OTE6IDB4NkNDQSxcbiAgICAweDk0OTI6IDB4NzY3RCxcbiAgICAweDk0OTM6IDB4N0I5NCxcbiAgICAweDk0OTQ6IDB4N0M5NSxcbiAgICAweDk0OTU6IDB4ODIzNixcbiAgICAweDk0OTY6IDB4ODU4NCxcbiAgICAweDk0OTc6IDB4OEZFQixcbiAgICAweDk0OTg6IDB4NjZERCxcbiAgICAweDk0OTk6IDB4NkYyMCxcbiAgICAweDk0OUE6IDB4NzIwNixcbiAgICAweDk0OUI6IDB4N0UxQixcbiAgICAweDk0OUM6IDB4ODNBQixcbiAgICAweDk0OUQ6IDB4OTlDMSxcbiAgICAweDk0OUU6IDB4OUVBNixcbiAgICAweDk0OUY6IDB4NTFGRCxcbiAgICAweDk0QTA6IDB4N0JCMSxcbiAgICAweDk0QTE6IDB4Nzg3MixcbiAgICAweDk0QTI6IDB4N0JCOCxcbiAgICAweDk0QTM6IDB4ODA4NyxcbiAgICAweDk0QTQ6IDB4N0I0OCxcbiAgICAweDk0QTU6IDB4NkFFOCxcbiAgICAweDk0QTY6IDB4NUU2MSxcbiAgICAweDk0QTc6IDB4ODA4QyxcbiAgICAweDk0QTg6IDB4NzU1MSxcbiAgICAweDk0QTk6IDB4NzU2MCxcbiAgICAweDk0QUE6IDB4NTE2QixcbiAgICAweDk0QUI6IDB4OTI2MixcbiAgICAweDk0QUM6IDB4NkU4QyxcbiAgICAweDk0QUQ6IDB4NzY3QSxcbiAgICAweDk0QUU6IDB4OTE5NyxcbiAgICAweDk0QUY6IDB4OUFFQSxcbiAgICAweDk0QjA6IDB4NEYxMCxcbiAgICAweDk0QjE6IDB4N0Y3MCxcbiAgICAweDk0QjI6IDB4NjI5QyxcbiAgICAweDk0QjM6IDB4N0I0RixcbiAgICAweDk0QjQ6IDB4OTVBNSxcbiAgICAweDk0QjU6IDB4OUNFOSxcbiAgICAweDk0QjY6IDB4NTY3QSxcbiAgICAweDk0Qjc6IDB4NTg1OSxcbiAgICAweDk0Qjg6IDB4ODZFNCxcbiAgICAweDk0Qjk6IDB4OTZCQyxcbiAgICAweDk0QkE6IDB4NEYzNCxcbiAgICAweDk0QkI6IDB4NTIyNCxcbiAgICAweDk0QkM6IDB4NTM0QSxcbiAgICAweDk0QkQ6IDB4NTNDRCxcbiAgICAweDk0QkU6IDB4NTNEQixcbiAgICAweDk0QkY6IDB4NUUwNixcbiAgICAweDk0QzA6IDB4NjQyQyxcbiAgICAweDk0QzE6IDB4NjU5MSxcbiAgICAweDk0QzI6IDB4Njc3RixcbiAgICAweDk0QzM6IDB4NkMzRSxcbiAgICAweDk0QzQ6IDB4NkM0RSxcbiAgICAweDk0QzU6IDB4NzI0OCxcbiAgICAweDk0QzY6IDB4NzJBRixcbiAgICAweDk0Qzc6IDB4NzNFRCxcbiAgICAweDk0Qzg6IDB4NzU1NCxcbiAgICAweDk0Qzk6IDB4N0U0MSxcbiAgICAweDk0Q0E6IDB4ODIyQyxcbiAgICAweDk0Q0I6IDB4ODVFOSxcbiAgICAweDk0Q0M6IDB4OENBOSxcbiAgICAweDk0Q0Q6IDB4N0JDNCxcbiAgICAweDk0Q0U6IDB4OTFDNixcbiAgICAweDk0Q0Y6IDB4NzE2OSxcbiAgICAweDk0RDA6IDB4OTgxMixcbiAgICAweDk0RDE6IDB4OThFRixcbiAgICAweDk0RDI6IDB4NjMzRCxcbiAgICAweDk0RDM6IDB4NjY2OSxcbiAgICAweDk0RDQ6IDB4NzU2QSxcbiAgICAweDk0RDU6IDB4NzZFNCxcbiAgICAweDk0RDY6IDB4NzhEMCxcbiAgICAweDk0RDc6IDB4ODU0MyxcbiAgICAweDk0RDg6IDB4ODZFRSxcbiAgICAweDk0RDk6IDB4NTMyQSxcbiAgICAweDk0REE6IDB4NTM1MSxcbiAgICAweDk0REI6IDB4NTQyNixcbiAgICAweDk0REM6IDB4NTk4MyxcbiAgICAweDk0REQ6IDB4NUU4NyxcbiAgICAweDk0REU6IDB4NUY3QyxcbiAgICAweDk0REY6IDB4NjBCMixcbiAgICAweDk0RTA6IDB4NjI0OSxcbiAgICAweDk0RTE6IDB4NjI3OSxcbiAgICAweDk0RTI6IDB4NjJBQixcbiAgICAweDk0RTM6IDB4NjU5MCxcbiAgICAweDk0RTQ6IDB4NkJENCxcbiAgICAweDk0RTU6IDB4NkNDQyxcbiAgICAweDk0RTY6IDB4NzVCMixcbiAgICAweDk0RTc6IDB4NzZBRSxcbiAgICAweDk0RTg6IDB4Nzg5MSxcbiAgICAweDk0RTk6IDB4NzlEOCxcbiAgICAweDk0RUE6IDB4N0RDQixcbiAgICAweDk0RUI6IDB4N0Y3NyxcbiAgICAweDk0RUM6IDB4ODBBNSxcbiAgICAweDk0RUQ6IDB4ODhBQixcbiAgICAweDk0RUU6IDB4OEFCOSxcbiAgICAweDk0RUY6IDB4OENCQixcbiAgICAweDk0RjA6IDB4OTA3RixcbiAgICAweDk0RjE6IDB4OTc1RSxcbiAgICAweDk0RjI6IDB4OThEQixcbiAgICAweDk0RjM6IDB4NkEwQixcbiAgICAweDk0RjQ6IDB4N0MzOCxcbiAgICAweDk0RjU6IDB4NTA5OSxcbiAgICAweDk0RjY6IDB4NUMzRSxcbiAgICAweDk0Rjc6IDB4NUZBRSxcbiAgICAweDk0Rjg6IDB4Njc4NyxcbiAgICAweDk0Rjk6IDB4NkJEOCxcbiAgICAweDk0RkE6IDB4NzQzNSxcbiAgICAweDk0RkI6IDB4NzcwOSxcbiAgICAweDk0RkM6IDB4N0Y4RSxcbiAgICAweDk1NDA6IDB4OUYzQixcbiAgICAweDk1NDE6IDB4NjdDQSxcbiAgICAweDk1NDI6IDB4N0ExNyxcbiAgICAweDk1NDM6IDB4NTMzOSxcbiAgICAweDk1NDQ6IDB4NzU4QixcbiAgICAweDk1NDU6IDB4OUFFRCxcbiAgICAweDk1NDY6IDB4NUY2NixcbiAgICAweDk1NDc6IDB4ODE5RCxcbiAgICAweDk1NDg6IDB4ODNGMSxcbiAgICAweDk1NDk6IDB4ODA5OCxcbiAgICAweDk1NEE6IDB4NUYzQyxcbiAgICAweDk1NEI6IDB4NUZDNSxcbiAgICAweDk1NEM6IDB4NzU2MixcbiAgICAweDk1NEQ6IDB4N0I0NixcbiAgICAweDk1NEU6IDB4OTAzQyxcbiAgICAweDk1NEY6IDB4Njg2NyxcbiAgICAweDk1NTA6IDB4NTlFQixcbiAgICAweDk1NTE6IDB4NUE5QixcbiAgICAweDk1NTI6IDB4N0QxMCxcbiAgICAweDk1NTM6IDB4NzY3RSxcbiAgICAweDk1NTQ6IDB4OEIyQyxcbiAgICAweDk1NTU6IDB4NEZGNSxcbiAgICAweDk1NTY6IDB4NUY2QSxcbiAgICAweDk1NTc6IDB4NkExOSxcbiAgICAweDk1NTg6IDB4NkMzNyxcbiAgICAweDk1NTk6IDB4NkYwMixcbiAgICAweDk1NUE6IDB4NzRFMixcbiAgICAweDk1NUI6IDB4Nzk2OCxcbiAgICAweDk1NUM6IDB4ODg2OCxcbiAgICAweDk1NUQ6IDB4OEE1NSxcbiAgICAweDk1NUU6IDB4OEM3OSxcbiAgICAweDk1NUY6IDB4NUVERixcbiAgICAweDk1NjA6IDB4NjNDRixcbiAgICAweDk1NjE6IDB4NzVDNSxcbiAgICAweDk1NjI6IDB4NzlEMixcbiAgICAweDk1NjM6IDB4ODJENyxcbiAgICAweDk1NjQ6IDB4OTMyOCxcbiAgICAweDk1NjU6IDB4OTJGMixcbiAgICAweDk1NjY6IDB4ODQ5QyxcbiAgICAweDk1Njc6IDB4ODZFRCxcbiAgICAweDk1Njg6IDB4OUMyRCxcbiAgICAweDk1Njk6IDB4NTRDMSxcbiAgICAweDk1NkE6IDB4NUY2QyxcbiAgICAweDk1NkI6IDB4NjU4QyxcbiAgICAweDk1NkM6IDB4NkQ1QyxcbiAgICAweDk1NkQ6IDB4NzAxNSxcbiAgICAweDk1NkU6IDB4OENBNyxcbiAgICAweDk1NkY6IDB4OENEMyxcbiAgICAweDk1NzA6IDB4OTgzQixcbiAgICAweDk1NzE6IDB4NjU0RixcbiAgICAweDk1NzI6IDB4NzRGNixcbiAgICAweDk1NzM6IDB4NEUwRCxcbiAgICAweDk1NzQ6IDB4NEVEOCxcbiAgICAweDk1NzU6IDB4NTdFMCxcbiAgICAweDk1NzY6IDB4NTkyQixcbiAgICAweDk1Nzc6IDB4NUE2NixcbiAgICAweDk1Nzg6IDB4NUJDQyxcbiAgICAweDk1Nzk6IDB4NTFBOCxcbiAgICAweDk1N0E6IDB4NUUwMyxcbiAgICAweDk1N0I6IDB4NUU5QyxcbiAgICAweDk1N0M6IDB4NjAxNixcbiAgICAweDk1N0Q6IDB4NjI3NixcbiAgICAweDk1N0U6IDB4NjU3NyxcbiAgICAweDk1ODA6IDB4NjVBNyxcbiAgICAweDk1ODE6IDB4NjY2RSxcbiAgICAweDk1ODI6IDB4NkQ2RSxcbiAgICAweDk1ODM6IDB4NzIzNixcbiAgICAweDk1ODQ6IDB4N0IyNixcbiAgICAweDk1ODU6IDB4ODE1MCxcbiAgICAweDk1ODY6IDB4ODE5QSxcbiAgICAweDk1ODc6IDB4ODI5OSxcbiAgICAweDk1ODg6IDB4OEI1QyxcbiAgICAweDk1ODk6IDB4OENBMCxcbiAgICAweDk1OEE6IDB4OENFNixcbiAgICAweDk1OEI6IDB4OEQ3NCxcbiAgICAweDk1OEM6IDB4OTYxQyxcbiAgICAweDk1OEQ6IDB4OTY0NCxcbiAgICAweDk1OEU6IDB4NEZBRSxcbiAgICAweDk1OEY6IDB4NjRBQixcbiAgICAweDk1OTA6IDB4NkI2NixcbiAgICAweDk1OTE6IDB4ODIxRSxcbiAgICAweDk1OTI6IDB4ODQ2MSxcbiAgICAweDk1OTM6IDB4ODU2QSxcbiAgICAweDk1OTQ6IDB4OTBFOCxcbiAgICAweDk1OTU6IDB4NUMwMSxcbiAgICAweDk1OTY6IDB4Njk1MyxcbiAgICAweDk1OTc6IDB4OThBOCxcbiAgICAweDk1OTg6IDB4ODQ3QSxcbiAgICAweDk1OTk6IDB4ODU1NyxcbiAgICAweDk1OUE6IDB4NEYwRixcbiAgICAweDk1OUI6IDB4NTI2RixcbiAgICAweDk1OUM6IDB4NUZBOSxcbiAgICAweDk1OUQ6IDB4NUU0NSxcbiAgICAweDk1OUU6IDB4NjcwRCxcbiAgICAweDk1OUY6IDB4Nzk4RixcbiAgICAweDk1QTA6IDB4ODE3OSxcbiAgICAweDk1QTE6IDB4ODkwNyxcbiAgICAweDk1QTI6IDB4ODk4NixcbiAgICAweDk1QTM6IDB4NkRGNSxcbiAgICAweDk1QTQ6IDB4NUYxNyxcbiAgICAweDk1QTU6IDB4NjI1NSxcbiAgICAweDk1QTY6IDB4NkNCOCxcbiAgICAweDk1QTc6IDB4NEVDRixcbiAgICAweDk1QTg6IDB4NzI2OSxcbiAgICAweDk1QTk6IDB4OUI5MixcbiAgICAweDk1QUE6IDB4NTIwNixcbiAgICAweDk1QUI6IDB4NTQzQixcbiAgICAweDk1QUM6IDB4NTY3NCxcbiAgICAweDk1QUQ6IDB4NThCMyxcbiAgICAweDk1QUU6IDB4NjFBNCxcbiAgICAweDk1QUY6IDB4NjI2RSxcbiAgICAweDk1QjA6IDB4NzExQSxcbiAgICAweDk1QjE6IDB4NTk2RSxcbiAgICAweDk1QjI6IDB4N0M4OSxcbiAgICAweDk1QjM6IDB4N0NERSxcbiAgICAweDk1QjQ6IDB4N0QxQixcbiAgICAweDk1QjU6IDB4OTZGMCxcbiAgICAweDk1QjY6IDB4NjU4NyxcbiAgICAweDk1Qjc6IDB4ODA1RSxcbiAgICAweDk1Qjg6IDB4NEUxOSxcbiAgICAweDk1Qjk6IDB4NEY3NSxcbiAgICAweDk1QkE6IDB4NTE3NSxcbiAgICAweDk1QkI6IDB4NTg0MCxcbiAgICAweDk1QkM6IDB4NUU2MyxcbiAgICAweDk1QkQ6IDB4NUU3MyxcbiAgICAweDk1QkU6IDB4NUYwQSxcbiAgICAweDk1QkY6IDB4NjdDNCxcbiAgICAweDk1QzA6IDB4NEUyNixcbiAgICAweDk1QzE6IDB4ODUzRCxcbiAgICAweDk1QzI6IDB4OTU4OSxcbiAgICAweDk1QzM6IDB4OTY1QixcbiAgICAweDk1QzQ6IDB4N0M3MyxcbiAgICAweDk1QzU6IDB4OTgwMSxcbiAgICAweDk1QzY6IDB4NTBGQixcbiAgICAweDk1Qzc6IDB4NThDMSxcbiAgICAweDk1Qzg6IDB4NzY1NixcbiAgICAweDk1Qzk6IDB4NzhBNyxcbiAgICAweDk1Q0E6IDB4NTIyNSxcbiAgICAweDk1Q0I6IDB4NzdBNSxcbiAgICAweDk1Q0M6IDB4ODUxMSxcbiAgICAweDk1Q0Q6IDB4N0I4NixcbiAgICAweDk1Q0U6IDB4NTA0RixcbiAgICAweDk1Q0Y6IDB4NTkwOSxcbiAgICAweDk1RDA6IDB4NzI0NyxcbiAgICAweDk1RDE6IDB4N0JDNyxcbiAgICAweDk1RDI6IDB4N0RFOCxcbiAgICAweDk1RDM6IDB4OEZCQSxcbiAgICAweDk1RDQ6IDB4OEZENCxcbiAgICAweDk1RDU6IDB4OTA0RCxcbiAgICAweDk1RDY6IDB4NEZCRixcbiAgICAweDk1RDc6IDB4NTJDOSxcbiAgICAweDk1RDg6IDB4NUEyOSxcbiAgICAweDk1RDk6IDB4NUYwMSxcbiAgICAweDk1REE6IDB4OTdBRCxcbiAgICAweDk1REI6IDB4NEZERCxcbiAgICAweDk1REM6IDB4ODIxNyxcbiAgICAweDk1REQ6IDB4OTJFQSxcbiAgICAweDk1REU6IDB4NTcwMyxcbiAgICAweDk1REY6IDB4NjM1NSxcbiAgICAweDk1RTA6IDB4NkI2OSxcbiAgICAweDk1RTE6IDB4NzUyQixcbiAgICAweDk1RTI6IDB4ODhEQyxcbiAgICAweDk1RTM6IDB4OEYxNCxcbiAgICAweDk1RTQ6IDB4N0E0MixcbiAgICAweDk1RTU6IDB4NTJERixcbiAgICAweDk1RTY6IDB4NTg5MyxcbiAgICAweDk1RTc6IDB4NjE1NSxcbiAgICAweDk1RTg6IDB4NjIwQSxcbiAgICAweDk1RTk6IDB4NjZBRSxcbiAgICAweDk1RUE6IDB4NkJDRCxcbiAgICAweDk1RUI6IDB4N0MzRixcbiAgICAweDk1RUM6IDB4ODNFOSxcbiAgICAweDk1RUQ6IDB4NTAyMyxcbiAgICAweDk1RUU6IDB4NEZGOCxcbiAgICAweDk1RUY6IDB4NTMwNSxcbiAgICAweDk1RjA6IDB4NTQ0NixcbiAgICAweDk1RjE6IDB4NTgzMSxcbiAgICAweDk1RjI6IDB4NTk0OSxcbiAgICAweDk1RjM6IDB4NUI5RCxcbiAgICAweDk1RjQ6IDB4NUNGMCxcbiAgICAweDk1RjU6IDB4NUNFRixcbiAgICAweDk1RjY6IDB4NUQyOSxcbiAgICAweDk1Rjc6IDB4NUU5NixcbiAgICAweDk1Rjg6IDB4NjJCMSxcbiAgICAweDk1Rjk6IDB4NjM2NyxcbiAgICAweDk1RkE6IDB4NjUzRSxcbiAgICAweDk1RkI6IDB4NjVCOSxcbiAgICAweDk1RkM6IDB4NjcwQixcbiAgICAweDk2NDA6IDB4NkNENSxcbiAgICAweDk2NDE6IDB4NkNFMSxcbiAgICAweDk2NDI6IDB4NzBGOSxcbiAgICAweDk2NDM6IDB4NzgzMixcbiAgICAweDk2NDQ6IDB4N0UyQixcbiAgICAweDk2NDU6IDB4ODBERSxcbiAgICAweDk2NDY6IDB4ODJCMyxcbiAgICAweDk2NDc6IDB4ODQwQyxcbiAgICAweDk2NDg6IDB4ODRFQyxcbiAgICAweDk2NDk6IDB4ODcwMixcbiAgICAweDk2NEE6IDB4ODkxMixcbiAgICAweDk2NEI6IDB4OEEyQSxcbiAgICAweDk2NEM6IDB4OEM0QSxcbiAgICAweDk2NEQ6IDB4OTBBNixcbiAgICAweDk2NEU6IDB4OTJEMixcbiAgICAweDk2NEY6IDB4OThGRCxcbiAgICAweDk2NTA6IDB4OUNGMyxcbiAgICAweDk2NTE6IDB4OUQ2QyxcbiAgICAweDk2NTI6IDB4NEU0RixcbiAgICAweDk2NTM6IDB4NEVBMSxcbiAgICAweDk2NTQ6IDB4NTA4RCxcbiAgICAweDk2NTU6IDB4NTI1NixcbiAgICAweDk2NTY6IDB4NTc0QSxcbiAgICAweDk2NTc6IDB4NTlBOCxcbiAgICAweDk2NTg6IDB4NUUzRCxcbiAgICAweDk2NTk6IDB4NUZEOCxcbiAgICAweDk2NUE6IDB4NUZEOSxcbiAgICAweDk2NUI6IDB4NjIzRixcbiAgICAweDk2NUM6IDB4NjZCNCxcbiAgICAweDk2NUQ6IDB4NjcxQixcbiAgICAweDk2NUU6IDB4NjdEMCxcbiAgICAweDk2NUY6IDB4NjhEMixcbiAgICAweDk2NjA6IDB4NTE5MixcbiAgICAweDk2NjE6IDB4N0QyMSxcbiAgICAweDk2NjI6IDB4ODBBQSxcbiAgICAweDk2NjM6IDB4ODFBOCxcbiAgICAweDk2NjQ6IDB4OEIwMCxcbiAgICAweDk2NjU6IDB4OEM4QyxcbiAgICAweDk2NjY6IDB4OENCRixcbiAgICAweDk2Njc6IDB4OTI3RSxcbiAgICAweDk2Njg6IDB4OTYzMixcbiAgICAweDk2Njk6IDB4NTQyMCxcbiAgICAweDk2NkE6IDB4OTgyQyxcbiAgICAweDk2NkI6IDB4NTMxNyxcbiAgICAweDk2NkM6IDB4NTBENSxcbiAgICAweDk2NkQ6IDB4NTM1QyxcbiAgICAweDk2NkU6IDB4NThBOCxcbiAgICAweDk2NkY6IDB4NjRCMixcbiAgICAweDk2NzA6IDB4NjczNCxcbiAgICAweDk2NzE6IDB4NzI2NyxcbiAgICAweDk2NzI6IDB4Nzc2NixcbiAgICAweDk2NzM6IDB4N0E0NixcbiAgICAweDk2NzQ6IDB4OTFFNixcbiAgICAweDk2NzU6IDB4NTJDMyxcbiAgICAweDk2NzY6IDB4NkNBMSxcbiAgICAweDk2Nzc6IDB4NkI4NixcbiAgICAweDk2Nzg6IDB4NTgwMCxcbiAgICAweDk2Nzk6IDB4NUU0QyxcbiAgICAweDk2N0E6IDB4NTk1NCxcbiAgICAweDk2N0I6IDB4NjcyQyxcbiAgICAweDk2N0M6IDB4N0ZGQixcbiAgICAweDk2N0Q6IDB4NTFFMSxcbiAgICAweDk2N0U6IDB4NzZDNixcbiAgICAweDk2ODA6IDB4NjQ2OSxcbiAgICAweDk2ODE6IDB4NzhFOCxcbiAgICAweDk2ODI6IDB4OUI1NCxcbiAgICAweDk2ODM6IDB4OUVCQixcbiAgICAweDk2ODQ6IDB4NTdDQixcbiAgICAweDk2ODU6IDB4NTlCOSxcbiAgICAweDk2ODY6IDB4NjYyNyxcbiAgICAweDk2ODc6IDB4Njc5QSxcbiAgICAweDk2ODg6IDB4NkJDRSxcbiAgICAweDk2ODk6IDB4NTRFOSxcbiAgICAweDk2OEE6IDB4NjlEOSxcbiAgICAweDk2OEI6IDB4NUU1NSxcbiAgICAweDk2OEM6IDB4ODE5QyxcbiAgICAweDk2OEQ6IDB4Njc5NSxcbiAgICAweDk2OEU6IDB4OUJBQSxcbiAgICAweDk2OEY6IDB4NjdGRSxcbiAgICAweDk2OTA6IDB4OUM1MixcbiAgICAweDk2OTE6IDB4Njg1RCxcbiAgICAweDk2OTI6IDB4NEVBNixcbiAgICAweDk2OTM6IDB4NEZFMyxcbiAgICAweDk2OTQ6IDB4NTNDOCxcbiAgICAweDk2OTU6IDB4NjJCOSxcbiAgICAweDk2OTY6IDB4NjcyQixcbiAgICAweDk2OTc6IDB4NkNBQixcbiAgICAweDk2OTg6IDB4OEZDNCxcbiAgICAweDk2OTk6IDB4NEZBRCxcbiAgICAweDk2OUE6IDB4N0U2RCxcbiAgICAweDk2OUI6IDB4OUVCRixcbiAgICAweDk2OUM6IDB4NEUwNyxcbiAgICAweDk2OUQ6IDB4NjE2MixcbiAgICAweDk2OUU6IDB4NkU4MCxcbiAgICAweDk2OUY6IDB4NkYyQixcbiAgICAweDk2QTA6IDB4ODUxMyxcbiAgICAweDk2QTE6IDB4NTQ3MyxcbiAgICAweDk2QTI6IDB4NjcyQSxcbiAgICAweDk2QTM6IDB4OUI0NSxcbiAgICAweDk2QTQ6IDB4NURGMyxcbiAgICAweDk2QTU6IDB4N0I5NSxcbiAgICAweDk2QTY6IDB4NUNBQyxcbiAgICAweDk2QTc6IDB4NUJDNixcbiAgICAweDk2QTg6IDB4ODcxQyxcbiAgICAweDk2QTk6IDB4NkU0QSxcbiAgICAweDk2QUE6IDB4ODREMSxcbiAgICAweDk2QUI6IDB4N0ExNCxcbiAgICAweDk2QUM6IDB4ODEwOCxcbiAgICAweDk2QUQ6IDB4NTk5OSxcbiAgICAweDk2QUU6IDB4N0M4RCxcbiAgICAweDk2QUY6IDB4NkMxMSxcbiAgICAweDk2QjA6IDB4NzcyMCxcbiAgICAweDk2QjE6IDB4NTJEOSxcbiAgICAweDk2QjI6IDB4NTkyMixcbiAgICAweDk2QjM6IDB4NzEyMSxcbiAgICAweDk2QjQ6IDB4NzI1RixcbiAgICAweDk2QjU6IDB4NzdEQixcbiAgICAweDk2QjY6IDB4OTcyNyxcbiAgICAweDk2Qjc6IDB4OUQ2MSxcbiAgICAweDk2Qjg6IDB4NjkwQixcbiAgICAweDk2Qjk6IDB4NUE3RixcbiAgICAweDk2QkE6IDB4NUExOCxcbiAgICAweDk2QkI6IDB4NTFBNSxcbiAgICAweDk2QkM6IDB4NTQwRCxcbiAgICAweDk2QkQ6IDB4NTQ3RCxcbiAgICAweDk2QkU6IDB4NjYwRSxcbiAgICAweDk2QkY6IDB4NzZERixcbiAgICAweDk2QzA6IDB4OEZGNyxcbiAgICAweDk2QzE6IDB4OTI5OCxcbiAgICAweDk2QzI6IDB4OUNGNCxcbiAgICAweDk2QzM6IDB4NTlFQSxcbiAgICAweDk2QzQ6IDB4NzI1RCxcbiAgICAweDk2QzU6IDB4NkVDNSxcbiAgICAweDk2QzY6IDB4NTE0RCxcbiAgICAweDk2Qzc6IDB4NjhDOSxcbiAgICAweDk2Qzg6IDB4N0RCRixcbiAgICAweDk2Qzk6IDB4N0RFQyxcbiAgICAweDk2Q0E6IDB4OTc2MixcbiAgICAweDk2Q0I6IDB4OUVCQSxcbiAgICAweDk2Q0M6IDB4NjQ3OCxcbiAgICAweDk2Q0Q6IDB4NkEyMSxcbiAgICAweDk2Q0U6IDB4ODMwMixcbiAgICAweDk2Q0Y6IDB4NTk4NCxcbiAgICAweDk2RDA6IDB4NUI1RixcbiAgICAweDk2RDE6IDB4NkJEQixcbiAgICAweDk2RDI6IDB4NzMxQixcbiAgICAweDk2RDM6IDB4NzZGMixcbiAgICAweDk2RDQ6IDB4N0RCMixcbiAgICAweDk2RDU6IDB4ODAxNyxcbiAgICAweDk2RDY6IDB4ODQ5OSxcbiAgICAweDk2RDc6IDB4NTEzMixcbiAgICAweDk2RDg6IDB4NjcyOCxcbiAgICAweDk2RDk6IDB4OUVEOSxcbiAgICAweDk2REE6IDB4NzZFRSxcbiAgICAweDk2REI6IDB4Njc2MixcbiAgICAweDk2REM6IDB4NTJGRixcbiAgICAweDk2REQ6IDB4OTkwNSxcbiAgICAweDk2REU6IDB4NUMyNCxcbiAgICAweDk2REY6IDB4NjIzQixcbiAgICAweDk2RTA6IDB4N0M3RSxcbiAgICAweDk2RTE6IDB4OENCMCxcbiAgICAweDk2RTI6IDB4NTU0RixcbiAgICAweDk2RTM6IDB4NjBCNixcbiAgICAweDk2RTQ6IDB4N0QwQixcbiAgICAweDk2RTU6IDB4OTU4MCxcbiAgICAweDk2RTY6IDB4NTMwMSxcbiAgICAweDk2RTc6IDB4NEU1RixcbiAgICAweDk2RTg6IDB4NTFCNixcbiAgICAweDk2RTk6IDB4NTkxQyxcbiAgICAweDk2RUE6IDB4NzIzQSxcbiAgICAweDk2RUI6IDB4ODAzNixcbiAgICAweDk2RUM6IDB4OTFDRSxcbiAgICAweDk2RUQ6IDB4NUYyNSxcbiAgICAweDk2RUU6IDB4NzdFMixcbiAgICAweDk2RUY6IDB4NTM4NCxcbiAgICAweDk2RjA6IDB4NUY3OSxcbiAgICAweDk2RjE6IDB4N0QwNCxcbiAgICAweDk2RjI6IDB4ODVBQyxcbiAgICAweDk2RjM6IDB4OEEzMyxcbiAgICAweDk2RjQ6IDB4OEU4RCxcbiAgICAweDk2RjU6IDB4OTc1NixcbiAgICAweDk2RjY6IDB4NjdGMyxcbiAgICAweDk2Rjc6IDB4ODVBRSxcbiAgICAweDk2Rjg6IDB4OTQ1MyxcbiAgICAweDk2Rjk6IDB4NjEwOSxcbiAgICAweDk2RkE6IDB4NjEwOCxcbiAgICAweDk2RkI6IDB4NkNCOSxcbiAgICAweDk2RkM6IDB4NzY1MixcbiAgICAweDk3NDA6IDB4OEFFRCxcbiAgICAweDk3NDE6IDB4OEYzOCxcbiAgICAweDk3NDI6IDB4NTUyRixcbiAgICAweDk3NDM6IDB4NEY1MSxcbiAgICAweDk3NDQ6IDB4NTEyQSxcbiAgICAweDk3NDU6IDB4NTJDNyxcbiAgICAweDk3NDY6IDB4NTNDQixcbiAgICAweDk3NDc6IDB4NUJBNSxcbiAgICAweDk3NDg6IDB4NUU3RCxcbiAgICAweDk3NDk6IDB4NjBBMCxcbiAgICAweDk3NEE6IDB4NjE4MixcbiAgICAweDk3NEI6IDB4NjNENixcbiAgICAweDk3NEM6IDB4NjcwOSxcbiAgICAweDk3NEQ6IDB4NjdEQSxcbiAgICAweDk3NEU6IDB4NkU2NyxcbiAgICAweDk3NEY6IDB4NkQ4QyxcbiAgICAweDk3NTA6IDB4NzMzNixcbiAgICAweDk3NTE6IDB4NzMzNyxcbiAgICAweDk3NTI6IDB4NzUzMSxcbiAgICAweDk3NTM6IDB4Nzk1MCxcbiAgICAweDk3NTQ6IDB4ODhENSxcbiAgICAweDk3NTU6IDB4OEE5OCxcbiAgICAweDk3NTY6IDB4OTA0QSxcbiAgICAweDk3NTc6IDB4OTA5MSxcbiAgICAweDk3NTg6IDB4OTBGNSxcbiAgICAweDk3NTk6IDB4OTZDNCxcbiAgICAweDk3NUE6IDB4ODc4RCxcbiAgICAweDk3NUI6IDB4NTkxNSxcbiAgICAweDk3NUM6IDB4NEU4OCxcbiAgICAweDk3NUQ6IDB4NEY1OSxcbiAgICAweDk3NUU6IDB4NEUwRSxcbiAgICAweDk3NUY6IDB4OEE4OSxcbiAgICAweDk3NjA6IDB4OEYzRixcbiAgICAweDk3NjE6IDB4OTgxMCxcbiAgICAweDk3NjI6IDB4NTBBRCxcbiAgICAweDk3NjM6IDB4NUU3QyxcbiAgICAweDk3NjQ6IDB4NTk5NixcbiAgICAweDk3NjU6IDB4NUJCOSxcbiAgICAweDk3NjY6IDB4NUVCOCxcbiAgICAweDk3Njc6IDB4NjNEQSxcbiAgICAweDk3Njg6IDB4NjNGQSxcbiAgICAweDk3Njk6IDB4NjRDMSxcbiAgICAweDk3NkE6IDB4NjZEQyxcbiAgICAweDk3NkI6IDB4Njk0QSxcbiAgICAweDk3NkM6IDB4NjlEOCxcbiAgICAweDk3NkQ6IDB4NkQwQixcbiAgICAweDk3NkU6IDB4NkVCNixcbiAgICAweDk3NkY6IDB4NzE5NCxcbiAgICAweDk3NzA6IDB4NzUyOCxcbiAgICAweDk3NzE6IDB4N0FBRixcbiAgICAweDk3NzI6IDB4N0Y4QSxcbiAgICAweDk3NzM6IDB4ODAwMCxcbiAgICAweDk3NzQ6IDB4ODQ0OSxcbiAgICAweDk3NzU6IDB4ODRDOSxcbiAgICAweDk3NzY6IDB4ODk4MSxcbiAgICAweDk3Nzc6IDB4OEIyMSxcbiAgICAweDk3Nzg6IDB4OEUwQSxcbiAgICAweDk3Nzk6IDB4OTA2NSxcbiAgICAweDk3N0E6IDB4OTY3RCxcbiAgICAweDk3N0I6IDB4OTkwQSxcbiAgICAweDk3N0M6IDB4NjE3RSxcbiAgICAweDk3N0Q6IDB4NjI5MSxcbiAgICAweDk3N0U6IDB4NkIzMixcbiAgICAweDk3ODA6IDB4NkM4MyxcbiAgICAweDk3ODE6IDB4NkQ3NCxcbiAgICAweDk3ODI6IDB4N0ZDQyxcbiAgICAweDk3ODM6IDB4N0ZGQyxcbiAgICAweDk3ODQ6IDB4NkRDMCxcbiAgICAweDk3ODU6IDB4N0Y4NSxcbiAgICAweDk3ODY6IDB4ODdCQSxcbiAgICAweDk3ODc6IDB4ODhGOCxcbiAgICAweDk3ODg6IDB4Njc2NSxcbiAgICAweDk3ODk6IDB4ODNCMSxcbiAgICAweDk3OEE6IDB4OTgzQyxcbiAgICAweDk3OEI6IDB4OTZGNyxcbiAgICAweDk3OEM6IDB4NkQxQixcbiAgICAweDk3OEQ6IDB4N0Q2MSxcbiAgICAweDk3OEU6IDB4ODQzRCxcbiAgICAweDk3OEY6IDB4OTE2QSxcbiAgICAweDk3OTA6IDB4NEU3MSxcbiAgICAweDk3OTE6IDB4NTM3NSxcbiAgICAweDk3OTI6IDB4NUQ1MCxcbiAgICAweDk3OTM6IDB4NkIwNCxcbiAgICAweDk3OTQ6IDB4NkZFQixcbiAgICAweDk3OTU6IDB4ODVDRCxcbiAgICAweDk3OTY6IDB4ODYyRCxcbiAgICAweDk3OTc6IDB4ODlBNyxcbiAgICAweDk3OTg6IDB4NTIyOSxcbiAgICAweDk3OTk6IDB4NTQwRixcbiAgICAweDk3OUE6IDB4NUM2NSxcbiAgICAweDk3OUI6IDB4Njc0RSxcbiAgICAweDk3OUM6IDB4NjhBOCxcbiAgICAweDk3OUQ6IDB4NzQwNixcbiAgICAweDk3OUU6IDB4NzQ4MyxcbiAgICAweDk3OUY6IDB4NzVFMixcbiAgICAweDk3QTA6IDB4ODhDRixcbiAgICAweDk3QTE6IDB4ODhFMSxcbiAgICAweDk3QTI6IDB4OTFDQyxcbiAgICAweDk3QTM6IDB4OTZFMixcbiAgICAweDk3QTQ6IDB4OTY3OCxcbiAgICAweDk3QTU6IDB4NUY4QixcbiAgICAweDk3QTY6IDB4NzM4NyxcbiAgICAweDk3QTc6IDB4N0FDQixcbiAgICAweDk3QTg6IDB4ODQ0RSxcbiAgICAweDk3QTk6IDB4NjNBMCxcbiAgICAweDk3QUE6IDB4NzU2NSxcbiAgICAweDk3QUI6IDB4NTI4OSxcbiAgICAweDk3QUM6IDB4NkQ0MSxcbiAgICAweDk3QUQ6IDB4NkU5QyxcbiAgICAweDk3QUU6IDB4NzQwOSxcbiAgICAweDk3QUY6IDB4NzU1OSxcbiAgICAweDk3QjA6IDB4Nzg2QixcbiAgICAweDk3QjE6IDB4N0M5MixcbiAgICAweDk3QjI6IDB4OTY4NixcbiAgICAweDk3QjM6IDB4N0FEQyxcbiAgICAweDk3QjQ6IDB4OUY4RCxcbiAgICAweDk3QjU6IDB4NEZCNixcbiAgICAweDk3QjY6IDB4NjE2RSxcbiAgICAweDk3Qjc6IDB4NjVDNSxcbiAgICAweDk3Qjg6IDB4ODY1QyxcbiAgICAweDk3Qjk6IDB4NEU4NixcbiAgICAweDk3QkE6IDB4NEVBRSxcbiAgICAweDk3QkI6IDB4NTBEQSxcbiAgICAweDk3QkM6IDB4NEUyMSxcbiAgICAweDk3QkQ6IDB4NTFDQyxcbiAgICAweDk3QkU6IDB4NUJFRSxcbiAgICAweDk3QkY6IDB4NjU5OSxcbiAgICAweDk3QzA6IDB4Njg4MSxcbiAgICAweDk3QzE6IDB4NkRCQyxcbiAgICAweDk3QzI6IDB4NzMxRixcbiAgICAweDk3QzM6IDB4NzY0MixcbiAgICAweDk3QzQ6IDB4NzdBRCxcbiAgICAweDk3QzU6IDB4N0ExQyxcbiAgICAweDk3QzY6IDB4N0NFNyxcbiAgICAweDk3Qzc6IDB4ODI2RixcbiAgICAweDk3Qzg6IDB4OEFEMixcbiAgICAweDk3Qzk6IDB4OTA3QyxcbiAgICAweDk3Q0E6IDB4OTFDRixcbiAgICAweDk3Q0I6IDB4OTY3NSxcbiAgICAweDk3Q0M6IDB4OTgxOCxcbiAgICAweDk3Q0Q6IDB4NTI5QixcbiAgICAweDk3Q0U6IDB4N0REMSxcbiAgICAweDk3Q0Y6IDB4NTAyQixcbiAgICAweDk3RDA6IDB4NTM5OCxcbiAgICAweDk3RDE6IDB4Njc5NyxcbiAgICAweDk3RDI6IDB4NkRDQixcbiAgICAweDk3RDM6IDB4NzFEMCxcbiAgICAweDk3RDQ6IDB4NzQzMyxcbiAgICAweDk3RDU6IDB4ODFFOCxcbiAgICAweDk3RDY6IDB4OEYyQSxcbiAgICAweDk3RDc6IDB4OTZBMyxcbiAgICAweDk3RDg6IDB4OUM1NyxcbiAgICAweDk3RDk6IDB4OUU5RixcbiAgICAweDk3REE6IDB4NzQ2MCxcbiAgICAweDk3REI6IDB4NTg0MSxcbiAgICAweDk3REM6IDB4NkQ5OSxcbiAgICAweDk3REQ6IDB4N0QyRixcbiAgICAweDk3REU6IDB4OTg1RSxcbiAgICAweDk3REY6IDB4NEVFNCxcbiAgICAweDk3RTA6IDB4NEYzNixcbiAgICAweDk3RTE6IDB4NEY4QixcbiAgICAweDk3RTI6IDB4NTFCNyxcbiAgICAweDk3RTM6IDB4NTJCMSxcbiAgICAweDk3RTQ6IDB4NURCQSxcbiAgICAweDk3RTU6IDB4NjAxQyxcbiAgICAweDk3RTY6IDB4NzNCMixcbiAgICAweDk3RTc6IDB4NzkzQyxcbiAgICAweDk3RTg6IDB4ODJEMyxcbiAgICAweDk3RTk6IDB4OTIzNCxcbiAgICAweDk3RUE6IDB4OTZCNyxcbiAgICAweDk3RUI6IDB4OTZGNixcbiAgICAweDk3RUM6IDB4OTcwQSxcbiAgICAweDk3RUQ6IDB4OUU5NyxcbiAgICAweDk3RUU6IDB4OUY2MixcbiAgICAweDk3RUY6IDB4NjZBNixcbiAgICAweDk3RjA6IDB4NkI3NCxcbiAgICAweDk3RjE6IDB4NTIxNyxcbiAgICAweDk3RjI6IDB4NTJBMyxcbiAgICAweDk3RjM6IDB4NzBDOCxcbiAgICAweDk3RjQ6IDB4ODhDMixcbiAgICAweDk3RjU6IDB4NUVDOSxcbiAgICAweDk3RjY6IDB4NjA0QixcbiAgICAweDk3Rjc6IDB4NjE5MCxcbiAgICAweDk3Rjg6IDB4NkYyMyxcbiAgICAweDk3Rjk6IDB4NzE0OSxcbiAgICAweDk3RkE6IDB4N0MzRSxcbiAgICAweDk3RkI6IDB4N0RGNCxcbiAgICAweDk3RkM6IDB4ODA2RixcbiAgICAweDk4NDA6IDB4ODRFRSxcbiAgICAweDk4NDE6IDB4OTAyMyxcbiAgICAweDk4NDI6IDB4OTMyQyxcbiAgICAweDk4NDM6IDB4NTQ0MixcbiAgICAweDk4NDQ6IDB4OUI2RixcbiAgICAweDk4NDU6IDB4NkFEMyxcbiAgICAweDk4NDY6IDB4NzA4OSxcbiAgICAweDk4NDc6IDB4OENDMixcbiAgICAweDk4NDg6IDB4OERFRixcbiAgICAweDk4NDk6IDB4OTczMixcbiAgICAweDk4NEE6IDB4NTJCNCxcbiAgICAweDk4NEI6IDB4NUE0MSxcbiAgICAweDk4NEM6IDB4NUVDQSxcbiAgICAweDk4NEQ6IDB4NUYwNCxcbiAgICAweDk4NEU6IDB4NjcxNyxcbiAgICAweDk4NEY6IDB4Njk3QyxcbiAgICAweDk4NTA6IDB4Njk5NCxcbiAgICAweDk4NTE6IDB4NkQ2QSxcbiAgICAweDk4NTI6IDB4NkYwRixcbiAgICAweDk4NTM6IDB4NzI2MixcbiAgICAweDk4NTQ6IDB4NzJGQyxcbiAgICAweDk4NTU6IDB4N0JFRCxcbiAgICAweDk4NTY6IDB4ODAwMSxcbiAgICAweDk4NTc6IDB4ODA3RSxcbiAgICAweDk4NTg6IDB4ODc0QixcbiAgICAweDk4NTk6IDB4OTBDRSxcbiAgICAweDk4NUE6IDB4NTE2RCxcbiAgICAweDk4NUI6IDB4OUU5MyxcbiAgICAweDk4NUM6IDB4Nzk4NCxcbiAgICAweDk4NUQ6IDB4ODA4QixcbiAgICAweDk4NUU6IDB4OTMzMixcbiAgICAweDk4NUY6IDB4OEFENixcbiAgICAweDk4NjA6IDB4NTAyRCxcbiAgICAweDk4NjE6IDB4NTQ4QyxcbiAgICAweDk4NjI6IDB4OEE3MSxcbiAgICAweDk4NjM6IDB4NkI2QSxcbiAgICAweDk4NjQ6IDB4OENDNCxcbiAgICAweDk4NjU6IDB4ODEwNyxcbiAgICAweDk4NjY6IDB4NjBEMSxcbiAgICAweDk4Njc6IDB4NjdBMCxcbiAgICAweDk4Njg6IDB4OURGMixcbiAgICAweDk4Njk6IDB4NEU5OSxcbiAgICAweDk4NkE6IDB4NEU5OCxcbiAgICAweDk4NkI6IDB4OUMxMCxcbiAgICAweDk4NkM6IDB4OEE2QixcbiAgICAweDk4NkQ6IDB4ODVDMSxcbiAgICAweDk4NkU6IDB4ODU2OCxcbiAgICAweDk4NkY6IDB4NjkwMCxcbiAgICAweDk4NzA6IDB4NkU3RSxcbiAgICAweDk4NzE6IDB4Nzg5NyxcbiAgICAweDk4NzI6IDB4ODE1NSxcbiAgICAweDk4OUY6IDB4NUYwQyxcbiAgICAweDk4QTA6IDB4NEUxMCxcbiAgICAweDk4QTE6IDB4NEUxNSxcbiAgICAweDk4QTI6IDB4NEUyQSxcbiAgICAweDk4QTM6IDB4NEUzMSxcbiAgICAweDk4QTQ6IDB4NEUzNixcbiAgICAweDk4QTU6IDB4NEUzQyxcbiAgICAweDk4QTY6IDB4NEUzRixcbiAgICAweDk4QTc6IDB4NEU0MixcbiAgICAweDk4QTg6IDB4NEU1NixcbiAgICAweDk4QTk6IDB4NEU1OCxcbiAgICAweDk4QUE6IDB4NEU4MixcbiAgICAweDk4QUI6IDB4NEU4NSxcbiAgICAweDk4QUM6IDB4OEM2QixcbiAgICAweDk4QUQ6IDB4NEU4QSxcbiAgICAweDk4QUU6IDB4ODIxMixcbiAgICAweDk4QUY6IDB4NUYwRCxcbiAgICAweDk4QjA6IDB4NEU4RSxcbiAgICAweDk4QjE6IDB4NEU5RSxcbiAgICAweDk4QjI6IDB4NEU5RixcbiAgICAweDk4QjM6IDB4NEVBMCxcbiAgICAweDk4QjQ6IDB4NEVBMixcbiAgICAweDk4QjU6IDB4NEVCMCxcbiAgICAweDk4QjY6IDB4NEVCMyxcbiAgICAweDk4Qjc6IDB4NEVCNixcbiAgICAweDk4Qjg6IDB4NEVDRSxcbiAgICAweDk4Qjk6IDB4NEVDRCxcbiAgICAweDk4QkE6IDB4NEVDNCxcbiAgICAweDk4QkI6IDB4NEVDNixcbiAgICAweDk4QkM6IDB4NEVDMixcbiAgICAweDk4QkQ6IDB4NEVENyxcbiAgICAweDk4QkU6IDB4NEVERSxcbiAgICAweDk4QkY6IDB4NEVFRCxcbiAgICAweDk4QzA6IDB4NEVERixcbiAgICAweDk4QzE6IDB4NEVGNyxcbiAgICAweDk4QzI6IDB4NEYwOSxcbiAgICAweDk4QzM6IDB4NEY1QSxcbiAgICAweDk4QzQ6IDB4NEYzMCxcbiAgICAweDk4QzU6IDB4NEY1QixcbiAgICAweDk4QzY6IDB4NEY1RCxcbiAgICAweDk4Qzc6IDB4NEY1NyxcbiAgICAweDk4Qzg6IDB4NEY0NyxcbiAgICAweDk4Qzk6IDB4NEY3NixcbiAgICAweDk4Q0E6IDB4NEY4OCxcbiAgICAweDk4Q0I6IDB4NEY4RixcbiAgICAweDk4Q0M6IDB4NEY5OCxcbiAgICAweDk4Q0Q6IDB4NEY3QixcbiAgICAweDk4Q0U6IDB4NEY2OSxcbiAgICAweDk4Q0Y6IDB4NEY3MCxcbiAgICAweDk4RDA6IDB4NEY5MSxcbiAgICAweDk4RDE6IDB4NEY2RixcbiAgICAweDk4RDI6IDB4NEY4NixcbiAgICAweDk4RDM6IDB4NEY5NixcbiAgICAweDk4RDQ6IDB4NTExOCxcbiAgICAweDk4RDU6IDB4NEZENCxcbiAgICAweDk4RDY6IDB4NEZERixcbiAgICAweDk4RDc6IDB4NEZDRSxcbiAgICAweDk4RDg6IDB4NEZEOCxcbiAgICAweDk4RDk6IDB4NEZEQixcbiAgICAweDk4REE6IDB4NEZEMSxcbiAgICAweDk4REI6IDB4NEZEQSxcbiAgICAweDk4REM6IDB4NEZEMCxcbiAgICAweDk4REQ6IDB4NEZFNCxcbiAgICAweDk4REU6IDB4NEZFNSxcbiAgICAweDk4REY6IDB4NTAxQSxcbiAgICAweDk4RTA6IDB4NTAyOCxcbiAgICAweDk4RTE6IDB4NTAxNCxcbiAgICAweDk4RTI6IDB4NTAyQSxcbiAgICAweDk4RTM6IDB4NTAyNSxcbiAgICAweDk4RTQ6IDB4NTAwNSxcbiAgICAweDk4RTU6IDB4NEYxQyxcbiAgICAweDk4RTY6IDB4NEZGNixcbiAgICAweDk4RTc6IDB4NTAyMSxcbiAgICAweDk4RTg6IDB4NTAyOSxcbiAgICAweDk4RTk6IDB4NTAyQyxcbiAgICAweDk4RUE6IDB4NEZGRSxcbiAgICAweDk4RUI6IDB4NEZFRixcbiAgICAweDk4RUM6IDB4NTAxMSxcbiAgICAweDk4RUQ6IDB4NTAwNixcbiAgICAweDk4RUU6IDB4NTA0MyxcbiAgICAweDk4RUY6IDB4NTA0NyxcbiAgICAweDk4RjA6IDB4NjcwMyxcbiAgICAweDk4RjE6IDB4NTA1NSxcbiAgICAweDk4RjI6IDB4NTA1MCxcbiAgICAweDk4RjM6IDB4NTA0OCxcbiAgICAweDk4RjQ6IDB4NTA1QSxcbiAgICAweDk4RjU6IDB4NTA1NixcbiAgICAweDk4RjY6IDB4NTA2QyxcbiAgICAweDk4Rjc6IDB4NTA3OCxcbiAgICAweDk4Rjg6IDB4NTA4MCxcbiAgICAweDk4Rjk6IDB4NTA5QSxcbiAgICAweDk4RkE6IDB4NTA4NSxcbiAgICAweDk4RkI6IDB4NTBCNCxcbiAgICAweDk4RkM6IDB4NTBCMixcbiAgICAweDk5NDA6IDB4NTBDOSxcbiAgICAweDk5NDE6IDB4NTBDQSxcbiAgICAweDk5NDI6IDB4NTBCMyxcbiAgICAweDk5NDM6IDB4NTBDMixcbiAgICAweDk5NDQ6IDB4NTBENixcbiAgICAweDk5NDU6IDB4NTBERSxcbiAgICAweDk5NDY6IDB4NTBFNSxcbiAgICAweDk5NDc6IDB4NTBFRCxcbiAgICAweDk5NDg6IDB4NTBFMyxcbiAgICAweDk5NDk6IDB4NTBFRSxcbiAgICAweDk5NEE6IDB4NTBGOSxcbiAgICAweDk5NEI6IDB4NTBGNSxcbiAgICAweDk5NEM6IDB4NTEwOSxcbiAgICAweDk5NEQ6IDB4NTEwMSxcbiAgICAweDk5NEU6IDB4NTEwMixcbiAgICAweDk5NEY6IDB4NTExNixcbiAgICAweDk5NTA6IDB4NTExNSxcbiAgICAweDk5NTE6IDB4NTExNCxcbiAgICAweDk5NTI6IDB4NTExQSxcbiAgICAweDk5NTM6IDB4NTEyMSxcbiAgICAweDk5NTQ6IDB4NTEzQSxcbiAgICAweDk5NTU6IDB4NTEzNyxcbiAgICAweDk5NTY6IDB4NTEzQyxcbiAgICAweDk5NTc6IDB4NTEzQixcbiAgICAweDk5NTg6IDB4NTEzRixcbiAgICAweDk5NTk6IDB4NTE0MCxcbiAgICAweDk5NUE6IDB4NTE1MixcbiAgICAweDk5NUI6IDB4NTE0QyxcbiAgICAweDk5NUM6IDB4NTE1NCxcbiAgICAweDk5NUQ6IDB4NTE2MixcbiAgICAweDk5NUU6IDB4N0FGOCxcbiAgICAweDk5NUY6IDB4NTE2OSxcbiAgICAweDk5NjA6IDB4NTE2QSxcbiAgICAweDk5NjE6IDB4NTE2RSxcbiAgICAweDk5NjI6IDB4NTE4MCxcbiAgICAweDk5NjM6IDB4NTE4MixcbiAgICAweDk5NjQ6IDB4NTZEOCxcbiAgICAweDk5NjU6IDB4NTE4QyxcbiAgICAweDk5NjY6IDB4NTE4OSxcbiAgICAweDk5Njc6IDB4NTE4RixcbiAgICAweDk5Njg6IDB4NTE5MSxcbiAgICAweDk5Njk6IDB4NTE5MyxcbiAgICAweDk5NkE6IDB4NTE5NSxcbiAgICAweDk5NkI6IDB4NTE5NixcbiAgICAweDk5NkM6IDB4NTFBNCxcbiAgICAweDk5NkQ6IDB4NTFBNixcbiAgICAweDk5NkU6IDB4NTFBMixcbiAgICAweDk5NkY6IDB4NTFBOSxcbiAgICAweDk5NzA6IDB4NTFBQSxcbiAgICAweDk5NzE6IDB4NTFBQixcbiAgICAweDk5NzI6IDB4NTFCMyxcbiAgICAweDk5NzM6IDB4NTFCMSxcbiAgICAweDk5NzQ6IDB4NTFCMixcbiAgICAweDk5NzU6IDB4NTFCMCxcbiAgICAweDk5NzY6IDB4NTFCNSxcbiAgICAweDk5Nzc6IDB4NTFCRCxcbiAgICAweDk5Nzg6IDB4NTFDNSxcbiAgICAweDk5Nzk6IDB4NTFDOSxcbiAgICAweDk5N0E6IDB4NTFEQixcbiAgICAweDk5N0I6IDB4NTFFMCxcbiAgICAweDk5N0M6IDB4ODY1NSxcbiAgICAweDk5N0Q6IDB4NTFFOSxcbiAgICAweDk5N0U6IDB4NTFFRCxcbiAgICAweDk5ODA6IDB4NTFGMCxcbiAgICAweDk5ODE6IDB4NTFGNSxcbiAgICAweDk5ODI6IDB4NTFGRSxcbiAgICAweDk5ODM6IDB4NTIwNCxcbiAgICAweDk5ODQ6IDB4NTIwQixcbiAgICAweDk5ODU6IDB4NTIxNCxcbiAgICAweDk5ODY6IDB4NTIwRSxcbiAgICAweDk5ODc6IDB4NTIyNyxcbiAgICAweDk5ODg6IDB4NTIyQSxcbiAgICAweDk5ODk6IDB4NTIyRSxcbiAgICAweDk5OEE6IDB4NTIzMyxcbiAgICAweDk5OEI6IDB4NTIzOSxcbiAgICAweDk5OEM6IDB4NTI0RixcbiAgICAweDk5OEQ6IDB4NTI0NCxcbiAgICAweDk5OEU6IDB4NTI0QixcbiAgICAweDk5OEY6IDB4NTI0QyxcbiAgICAweDk5OTA6IDB4NTI1RSxcbiAgICAweDk5OTE6IDB4NTI1NCxcbiAgICAweDk5OTI6IDB4NTI2QSxcbiAgICAweDk5OTM6IDB4NTI3NCxcbiAgICAweDk5OTQ6IDB4NTI2OSxcbiAgICAweDk5OTU6IDB4NTI3MyxcbiAgICAweDk5OTY6IDB4NTI3RixcbiAgICAweDk5OTc6IDB4NTI3RCxcbiAgICAweDk5OTg6IDB4NTI4RCxcbiAgICAweDk5OTk6IDB4NTI5NCxcbiAgICAweDk5OUE6IDB4NTI5MixcbiAgICAweDk5OUI6IDB4NTI3MSxcbiAgICAweDk5OUM6IDB4NTI4OCxcbiAgICAweDk5OUQ6IDB4NTI5MSxcbiAgICAweDk5OUU6IDB4OEZBOCxcbiAgICAweDk5OUY6IDB4OEZBNyxcbiAgICAweDk5QTA6IDB4NTJBQyxcbiAgICAweDk5QTE6IDB4NTJBRCxcbiAgICAweDk5QTI6IDB4NTJCQyxcbiAgICAweDk5QTM6IDB4NTJCNSxcbiAgICAweDk5QTQ6IDB4NTJDMSxcbiAgICAweDk5QTU6IDB4NTJDRCxcbiAgICAweDk5QTY6IDB4NTJENyxcbiAgICAweDk5QTc6IDB4NTJERSxcbiAgICAweDk5QTg6IDB4NTJFMyxcbiAgICAweDk5QTk6IDB4NTJFNixcbiAgICAweDk5QUE6IDB4OThFRCxcbiAgICAweDk5QUI6IDB4NTJFMCxcbiAgICAweDk5QUM6IDB4NTJGMyxcbiAgICAweDk5QUQ6IDB4NTJGNSxcbiAgICAweDk5QUU6IDB4NTJGOCxcbiAgICAweDk5QUY6IDB4NTJGOSxcbiAgICAweDk5QjA6IDB4NTMwNixcbiAgICAweDk5QjE6IDB4NTMwOCxcbiAgICAweDk5QjI6IDB4NzUzOCxcbiAgICAweDk5QjM6IDB4NTMwRCxcbiAgICAweDk5QjQ6IDB4NTMxMCxcbiAgICAweDk5QjU6IDB4NTMwRixcbiAgICAweDk5QjY6IDB4NTMxNSxcbiAgICAweDk5Qjc6IDB4NTMxQSxcbiAgICAweDk5Qjg6IDB4NTMyMyxcbiAgICAweDk5Qjk6IDB4NTMyRixcbiAgICAweDk5QkE6IDB4NTMzMSxcbiAgICAweDk5QkI6IDB4NTMzMyxcbiAgICAweDk5QkM6IDB4NTMzOCxcbiAgICAweDk5QkQ6IDB4NTM0MCxcbiAgICAweDk5QkU6IDB4NTM0NixcbiAgICAweDk5QkY6IDB4NTM0NSxcbiAgICAweDk5QzA6IDB4NEUxNyxcbiAgICAweDk5QzE6IDB4NTM0OSxcbiAgICAweDk5QzI6IDB4NTM0RCxcbiAgICAweDk5QzM6IDB4NTFENixcbiAgICAweDk5QzQ6IDB4NTM1RSxcbiAgICAweDk5QzU6IDB4NTM2OSxcbiAgICAweDk5QzY6IDB4NTM2RSxcbiAgICAweDk5Qzc6IDB4NTkxOCxcbiAgICAweDk5Qzg6IDB4NTM3QixcbiAgICAweDk5Qzk6IDB4NTM3NyxcbiAgICAweDk5Q0E6IDB4NTM4MixcbiAgICAweDk5Q0I6IDB4NTM5NixcbiAgICAweDk5Q0M6IDB4NTNBMCxcbiAgICAweDk5Q0Q6IDB4NTNBNixcbiAgICAweDk5Q0U6IDB4NTNBNSxcbiAgICAweDk5Q0Y6IDB4NTNBRSxcbiAgICAweDk5RDA6IDB4NTNCMCxcbiAgICAweDk5RDE6IDB4NTNCNixcbiAgICAweDk5RDI6IDB4NTNDMyxcbiAgICAweDk5RDM6IDB4N0MxMixcbiAgICAweDk5RDQ6IDB4OTZEOSxcbiAgICAweDk5RDU6IDB4NTNERixcbiAgICAweDk5RDY6IDB4NjZGQyxcbiAgICAweDk5RDc6IDB4NzFFRSxcbiAgICAweDk5RDg6IDB4NTNFRSxcbiAgICAweDk5RDk6IDB4NTNFOCxcbiAgICAweDk5REE6IDB4NTNFRCxcbiAgICAweDk5REI6IDB4NTNGQSxcbiAgICAweDk5REM6IDB4NTQwMSxcbiAgICAweDk5REQ6IDB4NTQzRCxcbiAgICAweDk5REU6IDB4NTQ0MCxcbiAgICAweDk5REY6IDB4NTQyQyxcbiAgICAweDk5RTA6IDB4NTQyRCxcbiAgICAweDk5RTE6IDB4NTQzQyxcbiAgICAweDk5RTI6IDB4NTQyRSxcbiAgICAweDk5RTM6IDB4NTQzNixcbiAgICAweDk5RTQ6IDB4NTQyOSxcbiAgICAweDk5RTU6IDB4NTQxRCxcbiAgICAweDk5RTY6IDB4NTQ0RSxcbiAgICAweDk5RTc6IDB4NTQ4RixcbiAgICAweDk5RTg6IDB4NTQ3NSxcbiAgICAweDk5RTk6IDB4NTQ4RSxcbiAgICAweDk5RUE6IDB4NTQ1RixcbiAgICAweDk5RUI6IDB4NTQ3MSxcbiAgICAweDk5RUM6IDB4NTQ3NyxcbiAgICAweDk5RUQ6IDB4NTQ3MCxcbiAgICAweDk5RUU6IDB4NTQ5MixcbiAgICAweDk5RUY6IDB4NTQ3QixcbiAgICAweDk5RjA6IDB4NTQ4MCxcbiAgICAweDk5RjE6IDB4NTQ3NixcbiAgICAweDk5RjI6IDB4NTQ4NCxcbiAgICAweDk5RjM6IDB4NTQ5MCxcbiAgICAweDk5RjQ6IDB4NTQ4NixcbiAgICAweDk5RjU6IDB4NTRDNyxcbiAgICAweDk5RjY6IDB4NTRBMixcbiAgICAweDk5Rjc6IDB4NTRCOCxcbiAgICAweDk5Rjg6IDB4NTRBNSxcbiAgICAweDk5Rjk6IDB4NTRBQyxcbiAgICAweDk5RkE6IDB4NTRDNCxcbiAgICAweDk5RkI6IDB4NTRDOCxcbiAgICAweDk5RkM6IDB4NTRBOCxcbiAgICAweDlBNDA6IDB4NTRBQixcbiAgICAweDlBNDE6IDB4NTRDMixcbiAgICAweDlBNDI6IDB4NTRBNCxcbiAgICAweDlBNDM6IDB4NTRCRSxcbiAgICAweDlBNDQ6IDB4NTRCQyxcbiAgICAweDlBNDU6IDB4NTREOCxcbiAgICAweDlBNDY6IDB4NTRFNSxcbiAgICAweDlBNDc6IDB4NTRFNixcbiAgICAweDlBNDg6IDB4NTUwRixcbiAgICAweDlBNDk6IDB4NTUxNCxcbiAgICAweDlBNEE6IDB4NTRGRCxcbiAgICAweDlBNEI6IDB4NTRFRSxcbiAgICAweDlBNEM6IDB4NTRFRCxcbiAgICAweDlBNEQ6IDB4NTRGQSxcbiAgICAweDlBNEU6IDB4NTRFMixcbiAgICAweDlBNEY6IDB4NTUzOSxcbiAgICAweDlBNTA6IDB4NTU0MCxcbiAgICAweDlBNTE6IDB4NTU2MyxcbiAgICAweDlBNTI6IDB4NTU0QyxcbiAgICAweDlBNTM6IDB4NTUyRSxcbiAgICAweDlBNTQ6IDB4NTU1QyxcbiAgICAweDlBNTU6IDB4NTU0NSxcbiAgICAweDlBNTY6IDB4NTU1NixcbiAgICAweDlBNTc6IDB4NTU1NyxcbiAgICAweDlBNTg6IDB4NTUzOCxcbiAgICAweDlBNTk6IDB4NTUzMyxcbiAgICAweDlBNUE6IDB4NTU1RCxcbiAgICAweDlBNUI6IDB4NTU5OSxcbiAgICAweDlBNUM6IDB4NTU4MCxcbiAgICAweDlBNUQ6IDB4NTRBRixcbiAgICAweDlBNUU6IDB4NTU4QSxcbiAgICAweDlBNUY6IDB4NTU5RixcbiAgICAweDlBNjA6IDB4NTU3QixcbiAgICAweDlBNjE6IDB4NTU3RSxcbiAgICAweDlBNjI6IDB4NTU5OCxcbiAgICAweDlBNjM6IDB4NTU5RSxcbiAgICAweDlBNjQ6IDB4NTVBRSxcbiAgICAweDlBNjU6IDB4NTU3QyxcbiAgICAweDlBNjY6IDB4NTU4MyxcbiAgICAweDlBNjc6IDB4NTVBOSxcbiAgICAweDlBNjg6IDB4NTU4NyxcbiAgICAweDlBNjk6IDB4NTVBOCxcbiAgICAweDlBNkE6IDB4NTVEQSxcbiAgICAweDlBNkI6IDB4NTVDNSxcbiAgICAweDlBNkM6IDB4NTVERixcbiAgICAweDlBNkQ6IDB4NTVDNCxcbiAgICAweDlBNkU6IDB4NTVEQyxcbiAgICAweDlBNkY6IDB4NTVFNCxcbiAgICAweDlBNzA6IDB4NTVENCxcbiAgICAweDlBNzE6IDB4NTYxNCxcbiAgICAweDlBNzI6IDB4NTVGNyxcbiAgICAweDlBNzM6IDB4NTYxNixcbiAgICAweDlBNzQ6IDB4NTVGRSxcbiAgICAweDlBNzU6IDB4NTVGRCxcbiAgICAweDlBNzY6IDB4NTYxQixcbiAgICAweDlBNzc6IDB4NTVGOSxcbiAgICAweDlBNzg6IDB4NTY0RSxcbiAgICAweDlBNzk6IDB4NTY1MCxcbiAgICAweDlBN0E6IDB4NzFERixcbiAgICAweDlBN0I6IDB4NTYzNCxcbiAgICAweDlBN0M6IDB4NTYzNixcbiAgICAweDlBN0Q6IDB4NTYzMixcbiAgICAweDlBN0U6IDB4NTYzOCxcbiAgICAweDlBODA6IDB4NTY2QixcbiAgICAweDlBODE6IDB4NTY2NCxcbiAgICAweDlBODI6IDB4NTYyRixcbiAgICAweDlBODM6IDB4NTY2QyxcbiAgICAweDlBODQ6IDB4NTY2QSxcbiAgICAweDlBODU6IDB4NTY4NixcbiAgICAweDlBODY6IDB4NTY4MCxcbiAgICAweDlBODc6IDB4NTY4QSxcbiAgICAweDlBODg6IDB4NTZBMCxcbiAgICAweDlBODk6IDB4NTY5NCxcbiAgICAweDlBOEE6IDB4NTY4RixcbiAgICAweDlBOEI6IDB4NTZBNSxcbiAgICAweDlBOEM6IDB4NTZBRSxcbiAgICAweDlBOEQ6IDB4NTZCNixcbiAgICAweDlBOEU6IDB4NTZCNCxcbiAgICAweDlBOEY6IDB4NTZDMixcbiAgICAweDlBOTA6IDB4NTZCQyxcbiAgICAweDlBOTE6IDB4NTZDMSxcbiAgICAweDlBOTI6IDB4NTZDMyxcbiAgICAweDlBOTM6IDB4NTZDMCxcbiAgICAweDlBOTQ6IDB4NTZDOCxcbiAgICAweDlBOTU6IDB4NTZDRSxcbiAgICAweDlBOTY6IDB4NTZEMSxcbiAgICAweDlBOTc6IDB4NTZEMyxcbiAgICAweDlBOTg6IDB4NTZENyxcbiAgICAweDlBOTk6IDB4NTZFRSxcbiAgICAweDlBOUE6IDB4NTZGOSxcbiAgICAweDlBOUI6IDB4NTcwMCxcbiAgICAweDlBOUM6IDB4NTZGRixcbiAgICAweDlBOUQ6IDB4NTcwNCxcbiAgICAweDlBOUU6IDB4NTcwOSxcbiAgICAweDlBOUY6IDB4NTcwOCxcbiAgICAweDlBQTA6IDB4NTcwQixcbiAgICAweDlBQTE6IDB4NTcwRCxcbiAgICAweDlBQTI6IDB4NTcxMyxcbiAgICAweDlBQTM6IDB4NTcxOCxcbiAgICAweDlBQTQ6IDB4NTcxNixcbiAgICAweDlBQTU6IDB4NTVDNyxcbiAgICAweDlBQTY6IDB4NTcxQyxcbiAgICAweDlBQTc6IDB4NTcyNixcbiAgICAweDlBQTg6IDB4NTczNyxcbiAgICAweDlBQTk6IDB4NTczOCxcbiAgICAweDlBQUE6IDB4NTc0RSxcbiAgICAweDlBQUI6IDB4NTczQixcbiAgICAweDlBQUM6IDB4NTc0MCxcbiAgICAweDlBQUQ6IDB4NTc0RixcbiAgICAweDlBQUU6IDB4NTc2OSxcbiAgICAweDlBQUY6IDB4NTdDMCxcbiAgICAweDlBQjA6IDB4NTc4OCxcbiAgICAweDlBQjE6IDB4NTc2MSxcbiAgICAweDlBQjI6IDB4NTc3RixcbiAgICAweDlBQjM6IDB4NTc4OSxcbiAgICAweDlBQjQ6IDB4NTc5MyxcbiAgICAweDlBQjU6IDB4NTdBMCxcbiAgICAweDlBQjY6IDB4NTdCMyxcbiAgICAweDlBQjc6IDB4NTdBNCxcbiAgICAweDlBQjg6IDB4NTdBQSxcbiAgICAweDlBQjk6IDB4NTdCMCxcbiAgICAweDlBQkE6IDB4NTdDMyxcbiAgICAweDlBQkI6IDB4NTdDNixcbiAgICAweDlBQkM6IDB4NTdENCxcbiAgICAweDlBQkQ6IDB4NTdEMixcbiAgICAweDlBQkU6IDB4NTdEMyxcbiAgICAweDlBQkY6IDB4NTgwQSxcbiAgICAweDlBQzA6IDB4NTdENixcbiAgICAweDlBQzE6IDB4NTdFMyxcbiAgICAweDlBQzI6IDB4NTgwQixcbiAgICAweDlBQzM6IDB4NTgxOSxcbiAgICAweDlBQzQ6IDB4NTgxRCxcbiAgICAweDlBQzU6IDB4NTg3MixcbiAgICAweDlBQzY6IDB4NTgyMSxcbiAgICAweDlBQzc6IDB4NTg2MixcbiAgICAweDlBQzg6IDB4NTg0QixcbiAgICAweDlBQzk6IDB4NTg3MCxcbiAgICAweDlBQ0E6IDB4NkJDMCxcbiAgICAweDlBQ0I6IDB4NTg1MixcbiAgICAweDlBQ0M6IDB4NTgzRCxcbiAgICAweDlBQ0Q6IDB4NTg3OSxcbiAgICAweDlBQ0U6IDB4NTg4NSxcbiAgICAweDlBQ0Y6IDB4NThCOSxcbiAgICAweDlBRDA6IDB4NTg5RixcbiAgICAweDlBRDE6IDB4NThBQixcbiAgICAweDlBRDI6IDB4NThCQSxcbiAgICAweDlBRDM6IDB4NThERSxcbiAgICAweDlBRDQ6IDB4NThCQixcbiAgICAweDlBRDU6IDB4NThCOCxcbiAgICAweDlBRDY6IDB4NThBRSxcbiAgICAweDlBRDc6IDB4NThDNSxcbiAgICAweDlBRDg6IDB4NThEMyxcbiAgICAweDlBRDk6IDB4NThEMSxcbiAgICAweDlBREE6IDB4NThENyxcbiAgICAweDlBREI6IDB4NThEOSxcbiAgICAweDlBREM6IDB4NThEOCxcbiAgICAweDlBREQ6IDB4NThFNSxcbiAgICAweDlBREU6IDB4NThEQyxcbiAgICAweDlBREY6IDB4NThFNCxcbiAgICAweDlBRTA6IDB4NThERixcbiAgICAweDlBRTE6IDB4NThFRixcbiAgICAweDlBRTI6IDB4NThGQSxcbiAgICAweDlBRTM6IDB4NThGOSxcbiAgICAweDlBRTQ6IDB4NThGQixcbiAgICAweDlBRTU6IDB4NThGQyxcbiAgICAweDlBRTY6IDB4NThGRCxcbiAgICAweDlBRTc6IDB4NTkwMixcbiAgICAweDlBRTg6IDB4NTkwQSxcbiAgICAweDlBRTk6IDB4NTkxMCxcbiAgICAweDlBRUE6IDB4NTkxQixcbiAgICAweDlBRUI6IDB4NjhBNixcbiAgICAweDlBRUM6IDB4NTkyNSxcbiAgICAweDlBRUQ6IDB4NTkyQyxcbiAgICAweDlBRUU6IDB4NTkyRCxcbiAgICAweDlBRUY6IDB4NTkzMixcbiAgICAweDlBRjA6IDB4NTkzOCxcbiAgICAweDlBRjE6IDB4NTkzRSxcbiAgICAweDlBRjI6IDB4N0FEMixcbiAgICAweDlBRjM6IDB4NTk1NSxcbiAgICAweDlBRjQ6IDB4NTk1MCxcbiAgICAweDlBRjU6IDB4NTk0RSxcbiAgICAweDlBRjY6IDB4NTk1QSxcbiAgICAweDlBRjc6IDB4NTk1OCxcbiAgICAweDlBRjg6IDB4NTk2MixcbiAgICAweDlBRjk6IDB4NTk2MCxcbiAgICAweDlBRkE6IDB4NTk2NyxcbiAgICAweDlBRkI6IDB4NTk2QyxcbiAgICAweDlBRkM6IDB4NTk2OSxcbiAgICAweDlCNDA6IDB4NTk3OCxcbiAgICAweDlCNDE6IDB4NTk4MSxcbiAgICAweDlCNDI6IDB4NTk5RCxcbiAgICAweDlCNDM6IDB4NEY1RSxcbiAgICAweDlCNDQ6IDB4NEZBQixcbiAgICAweDlCNDU6IDB4NTlBMyxcbiAgICAweDlCNDY6IDB4NTlCMixcbiAgICAweDlCNDc6IDB4NTlDNixcbiAgICAweDlCNDg6IDB4NTlFOCxcbiAgICAweDlCNDk6IDB4NTlEQyxcbiAgICAweDlCNEE6IDB4NTk4RCxcbiAgICAweDlCNEI6IDB4NTlEOSxcbiAgICAweDlCNEM6IDB4NTlEQSxcbiAgICAweDlCNEQ6IDB4NUEyNSxcbiAgICAweDlCNEU6IDB4NUExRixcbiAgICAweDlCNEY6IDB4NUExMSxcbiAgICAweDlCNTA6IDB4NUExQyxcbiAgICAweDlCNTE6IDB4NUEwOSxcbiAgICAweDlCNTI6IDB4NUExQSxcbiAgICAweDlCNTM6IDB4NUE0MCxcbiAgICAweDlCNTQ6IDB4NUE2QyxcbiAgICAweDlCNTU6IDB4NUE0OSxcbiAgICAweDlCNTY6IDB4NUEzNSxcbiAgICAweDlCNTc6IDB4NUEzNixcbiAgICAweDlCNTg6IDB4NUE2MixcbiAgICAweDlCNTk6IDB4NUE2QSxcbiAgICAweDlCNUE6IDB4NUE5QSxcbiAgICAweDlCNUI6IDB4NUFCQyxcbiAgICAweDlCNUM6IDB4NUFCRSxcbiAgICAweDlCNUQ6IDB4NUFDQixcbiAgICAweDlCNUU6IDB4NUFDMixcbiAgICAweDlCNUY6IDB4NUFCRCxcbiAgICAweDlCNjA6IDB4NUFFMyxcbiAgICAweDlCNjE6IDB4NUFENyxcbiAgICAweDlCNjI6IDB4NUFFNixcbiAgICAweDlCNjM6IDB4NUFFOSxcbiAgICAweDlCNjQ6IDB4NUFENixcbiAgICAweDlCNjU6IDB4NUFGQSxcbiAgICAweDlCNjY6IDB4NUFGQixcbiAgICAweDlCNjc6IDB4NUIwQyxcbiAgICAweDlCNjg6IDB4NUIwQixcbiAgICAweDlCNjk6IDB4NUIxNixcbiAgICAweDlCNkE6IDB4NUIzMixcbiAgICAweDlCNkI6IDB4NUFEMCxcbiAgICAweDlCNkM6IDB4NUIyQSxcbiAgICAweDlCNkQ6IDB4NUIzNixcbiAgICAweDlCNkU6IDB4NUIzRSxcbiAgICAweDlCNkY6IDB4NUI0MyxcbiAgICAweDlCNzA6IDB4NUI0NSxcbiAgICAweDlCNzE6IDB4NUI0MCxcbiAgICAweDlCNzI6IDB4NUI1MSxcbiAgICAweDlCNzM6IDB4NUI1NSxcbiAgICAweDlCNzQ6IDB4NUI1QSxcbiAgICAweDlCNzU6IDB4NUI1QixcbiAgICAweDlCNzY6IDB4NUI2NSxcbiAgICAweDlCNzc6IDB4NUI2OSxcbiAgICAweDlCNzg6IDB4NUI3MCxcbiAgICAweDlCNzk6IDB4NUI3MyxcbiAgICAweDlCN0E6IDB4NUI3NSxcbiAgICAweDlCN0I6IDB4NUI3OCxcbiAgICAweDlCN0M6IDB4NjU4OCxcbiAgICAweDlCN0Q6IDB4NUI3QSxcbiAgICAweDlCN0U6IDB4NUI4MCxcbiAgICAweDlCODA6IDB4NUI4MyxcbiAgICAweDlCODE6IDB4NUJBNixcbiAgICAweDlCODI6IDB4NUJCOCxcbiAgICAweDlCODM6IDB4NUJDMyxcbiAgICAweDlCODQ6IDB4NUJDNyxcbiAgICAweDlCODU6IDB4NUJDOSxcbiAgICAweDlCODY6IDB4NUJENCxcbiAgICAweDlCODc6IDB4NUJEMCxcbiAgICAweDlCODg6IDB4NUJFNCxcbiAgICAweDlCODk6IDB4NUJFNixcbiAgICAweDlCOEE6IDB4NUJFMixcbiAgICAweDlCOEI6IDB4NUJERSxcbiAgICAweDlCOEM6IDB4NUJFNSxcbiAgICAweDlCOEQ6IDB4NUJFQixcbiAgICAweDlCOEU6IDB4NUJGMCxcbiAgICAweDlCOEY6IDB4NUJGNixcbiAgICAweDlCOTA6IDB4NUJGMyxcbiAgICAweDlCOTE6IDB4NUMwNSxcbiAgICAweDlCOTI6IDB4NUMwNyxcbiAgICAweDlCOTM6IDB4NUMwOCxcbiAgICAweDlCOTQ6IDB4NUMwRCxcbiAgICAweDlCOTU6IDB4NUMxMyxcbiAgICAweDlCOTY6IDB4NUMyMCxcbiAgICAweDlCOTc6IDB4NUMyMixcbiAgICAweDlCOTg6IDB4NUMyOCxcbiAgICAweDlCOTk6IDB4NUMzOCxcbiAgICAweDlCOUE6IDB4NUMzOSxcbiAgICAweDlCOUI6IDB4NUM0MSxcbiAgICAweDlCOUM6IDB4NUM0NixcbiAgICAweDlCOUQ6IDB4NUM0RSxcbiAgICAweDlCOUU6IDB4NUM1MyxcbiAgICAweDlCOUY6IDB4NUM1MCxcbiAgICAweDlCQTA6IDB4NUM0RixcbiAgICAweDlCQTE6IDB4NUI3MSxcbiAgICAweDlCQTI6IDB4NUM2QyxcbiAgICAweDlCQTM6IDB4NUM2RSxcbiAgICAweDlCQTQ6IDB4NEU2MixcbiAgICAweDlCQTU6IDB4NUM3NixcbiAgICAweDlCQTY6IDB4NUM3OSxcbiAgICAweDlCQTc6IDB4NUM4QyxcbiAgICAweDlCQTg6IDB4NUM5MSxcbiAgICAweDlCQTk6IDB4NUM5NCxcbiAgICAweDlCQUE6IDB4NTk5QixcbiAgICAweDlCQUI6IDB4NUNBQixcbiAgICAweDlCQUM6IDB4NUNCQixcbiAgICAweDlCQUQ6IDB4NUNCNixcbiAgICAweDlCQUU6IDB4NUNCQyxcbiAgICAweDlCQUY6IDB4NUNCNyxcbiAgICAweDlCQjA6IDB4NUNDNSxcbiAgICAweDlCQjE6IDB4NUNCRSxcbiAgICAweDlCQjI6IDB4NUNDNyxcbiAgICAweDlCQjM6IDB4NUNEOSxcbiAgICAweDlCQjQ6IDB4NUNFOSxcbiAgICAweDlCQjU6IDB4NUNGRCxcbiAgICAweDlCQjY6IDB4NUNGQSxcbiAgICAweDlCQjc6IDB4NUNFRCxcbiAgICAweDlCQjg6IDB4NUQ4QyxcbiAgICAweDlCQjk6IDB4NUNFQSxcbiAgICAweDlCQkE6IDB4NUQwQixcbiAgICAweDlCQkI6IDB4NUQxNSxcbiAgICAweDlCQkM6IDB4NUQxNyxcbiAgICAweDlCQkQ6IDB4NUQ1QyxcbiAgICAweDlCQkU6IDB4NUQxRixcbiAgICAweDlCQkY6IDB4NUQxQixcbiAgICAweDlCQzA6IDB4NUQxMSxcbiAgICAweDlCQzE6IDB4NUQxNCxcbiAgICAweDlCQzI6IDB4NUQyMixcbiAgICAweDlCQzM6IDB4NUQxQSxcbiAgICAweDlCQzQ6IDB4NUQxOSxcbiAgICAweDlCQzU6IDB4NUQxOCxcbiAgICAweDlCQzY6IDB4NUQ0QyxcbiAgICAweDlCQzc6IDB4NUQ1MixcbiAgICAweDlCQzg6IDB4NUQ0RSxcbiAgICAweDlCQzk6IDB4NUQ0QixcbiAgICAweDlCQ0E6IDB4NUQ2QyxcbiAgICAweDlCQ0I6IDB4NUQ3MyxcbiAgICAweDlCQ0M6IDB4NUQ3NixcbiAgICAweDlCQ0Q6IDB4NUQ4NyxcbiAgICAweDlCQ0U6IDB4NUQ4NCxcbiAgICAweDlCQ0Y6IDB4NUQ4MixcbiAgICAweDlCRDA6IDB4NURBMixcbiAgICAweDlCRDE6IDB4NUQ5RCxcbiAgICAweDlCRDI6IDB4NURBQyxcbiAgICAweDlCRDM6IDB4NURBRSxcbiAgICAweDlCRDQ6IDB4NURCRCxcbiAgICAweDlCRDU6IDB4NUQ5MCxcbiAgICAweDlCRDY6IDB4NURCNyxcbiAgICAweDlCRDc6IDB4NURCQyxcbiAgICAweDlCRDg6IDB4NURDOSxcbiAgICAweDlCRDk6IDB4NURDRCxcbiAgICAweDlCREE6IDB4NUREMyxcbiAgICAweDlCREI6IDB4NUREMixcbiAgICAweDlCREM6IDB4NURENixcbiAgICAweDlCREQ6IDB4NUREQixcbiAgICAweDlCREU6IDB4NURFQixcbiAgICAweDlCREY6IDB4NURGMixcbiAgICAweDlCRTA6IDB4NURGNSxcbiAgICAweDlCRTE6IDB4NUUwQixcbiAgICAweDlCRTI6IDB4NUUxQSxcbiAgICAweDlCRTM6IDB4NUUxOSxcbiAgICAweDlCRTQ6IDB4NUUxMSxcbiAgICAweDlCRTU6IDB4NUUxQixcbiAgICAweDlCRTY6IDB4NUUzNixcbiAgICAweDlCRTc6IDB4NUUzNyxcbiAgICAweDlCRTg6IDB4NUU0NCxcbiAgICAweDlCRTk6IDB4NUU0MyxcbiAgICAweDlCRUE6IDB4NUU0MCxcbiAgICAweDlCRUI6IDB4NUU0RSxcbiAgICAweDlCRUM6IDB4NUU1NyxcbiAgICAweDlCRUQ6IDB4NUU1NCxcbiAgICAweDlCRUU6IDB4NUU1RixcbiAgICAweDlCRUY6IDB4NUU2MixcbiAgICAweDlCRjA6IDB4NUU2NCxcbiAgICAweDlCRjE6IDB4NUU0NyxcbiAgICAweDlCRjI6IDB4NUU3NSxcbiAgICAweDlCRjM6IDB4NUU3NixcbiAgICAweDlCRjQ6IDB4NUU3QSxcbiAgICAweDlCRjU6IDB4OUVCQyxcbiAgICAweDlCRjY6IDB4NUU3RixcbiAgICAweDlCRjc6IDB4NUVBMCxcbiAgICAweDlCRjg6IDB4NUVDMSxcbiAgICAweDlCRjk6IDB4NUVDMixcbiAgICAweDlCRkE6IDB4NUVDOCxcbiAgICAweDlCRkI6IDB4NUVEMCxcbiAgICAweDlCRkM6IDB4NUVDRixcbiAgICAweDlDNDA6IDB4NUVENixcbiAgICAweDlDNDE6IDB4NUVFMyxcbiAgICAweDlDNDI6IDB4NUVERCxcbiAgICAweDlDNDM6IDB4NUVEQSxcbiAgICAweDlDNDQ6IDB4NUVEQixcbiAgICAweDlDNDU6IDB4NUVFMixcbiAgICAweDlDNDY6IDB4NUVFMSxcbiAgICAweDlDNDc6IDB4NUVFOCxcbiAgICAweDlDNDg6IDB4NUVFOSxcbiAgICAweDlDNDk6IDB4NUVFQyxcbiAgICAweDlDNEE6IDB4NUVGMSxcbiAgICAweDlDNEI6IDB4NUVGMyxcbiAgICAweDlDNEM6IDB4NUVGMCxcbiAgICAweDlDNEQ6IDB4NUVGNCxcbiAgICAweDlDNEU6IDB4NUVGOCxcbiAgICAweDlDNEY6IDB4NUVGRSxcbiAgICAweDlDNTA6IDB4NUYwMyxcbiAgICAweDlDNTE6IDB4NUYwOSxcbiAgICAweDlDNTI6IDB4NUY1RCxcbiAgICAweDlDNTM6IDB4NUY1QyxcbiAgICAweDlDNTQ6IDB4NUYwQixcbiAgICAweDlDNTU6IDB4NUYxMSxcbiAgICAweDlDNTY6IDB4NUYxNixcbiAgICAweDlDNTc6IDB4NUYyOSxcbiAgICAweDlDNTg6IDB4NUYyRCxcbiAgICAweDlDNTk6IDB4NUYzOCxcbiAgICAweDlDNUE6IDB4NUY0MSxcbiAgICAweDlDNUI6IDB4NUY0OCxcbiAgICAweDlDNUM6IDB4NUY0QyxcbiAgICAweDlDNUQ6IDB4NUY0RSxcbiAgICAweDlDNUU6IDB4NUYyRixcbiAgICAweDlDNUY6IDB4NUY1MSxcbiAgICAweDlDNjA6IDB4NUY1NixcbiAgICAweDlDNjE6IDB4NUY1NyxcbiAgICAweDlDNjI6IDB4NUY1OSxcbiAgICAweDlDNjM6IDB4NUY2MSxcbiAgICAweDlDNjQ6IDB4NUY2RCxcbiAgICAweDlDNjU6IDB4NUY3MyxcbiAgICAweDlDNjY6IDB4NUY3NyxcbiAgICAweDlDNjc6IDB4NUY4MyxcbiAgICAweDlDNjg6IDB4NUY4MixcbiAgICAweDlDNjk6IDB4NUY3RixcbiAgICAweDlDNkE6IDB4NUY4QSxcbiAgICAweDlDNkI6IDB4NUY4OCxcbiAgICAweDlDNkM6IDB4NUY5MSxcbiAgICAweDlDNkQ6IDB4NUY4NyxcbiAgICAweDlDNkU6IDB4NUY5RSxcbiAgICAweDlDNkY6IDB4NUY5OSxcbiAgICAweDlDNzA6IDB4NUY5OCxcbiAgICAweDlDNzE6IDB4NUZBMCxcbiAgICAweDlDNzI6IDB4NUZBOCxcbiAgICAweDlDNzM6IDB4NUZBRCxcbiAgICAweDlDNzQ6IDB4NUZCQyxcbiAgICAweDlDNzU6IDB4NUZENixcbiAgICAweDlDNzY6IDB4NUZGQixcbiAgICAweDlDNzc6IDB4NUZFNCxcbiAgICAweDlDNzg6IDB4NUZGOCxcbiAgICAweDlDNzk6IDB4NUZGMSxcbiAgICAweDlDN0E6IDB4NUZERCxcbiAgICAweDlDN0I6IDB4NjBCMyxcbiAgICAweDlDN0M6IDB4NUZGRixcbiAgICAweDlDN0Q6IDB4NjAyMSxcbiAgICAweDlDN0U6IDB4NjA2MCxcbiAgICAweDlDODA6IDB4NjAxOSxcbiAgICAweDlDODE6IDB4NjAxMCxcbiAgICAweDlDODI6IDB4NjAyOSxcbiAgICAweDlDODM6IDB4NjAwRSxcbiAgICAweDlDODQ6IDB4NjAzMSxcbiAgICAweDlDODU6IDB4NjAxQixcbiAgICAweDlDODY6IDB4NjAxNSxcbiAgICAweDlDODc6IDB4NjAyQixcbiAgICAweDlDODg6IDB4NjAyNixcbiAgICAweDlDODk6IDB4NjAwRixcbiAgICAweDlDOEE6IDB4NjAzQSxcbiAgICAweDlDOEI6IDB4NjA1QSxcbiAgICAweDlDOEM6IDB4NjA0MSxcbiAgICAweDlDOEQ6IDB4NjA2QSxcbiAgICAweDlDOEU6IDB4NjA3NyxcbiAgICAweDlDOEY6IDB4NjA1RixcbiAgICAweDlDOTA6IDB4NjA0QSxcbiAgICAweDlDOTE6IDB4NjA0NixcbiAgICAweDlDOTI6IDB4NjA0RCxcbiAgICAweDlDOTM6IDB4NjA2MyxcbiAgICAweDlDOTQ6IDB4NjA0MyxcbiAgICAweDlDOTU6IDB4NjA2NCxcbiAgICAweDlDOTY6IDB4NjA0MixcbiAgICAweDlDOTc6IDB4NjA2QyxcbiAgICAweDlDOTg6IDB4NjA2QixcbiAgICAweDlDOTk6IDB4NjA1OSxcbiAgICAweDlDOUE6IDB4NjA4MSxcbiAgICAweDlDOUI6IDB4NjA4RCxcbiAgICAweDlDOUM6IDB4NjBFNyxcbiAgICAweDlDOUQ6IDB4NjA4MyxcbiAgICAweDlDOUU6IDB4NjA5QSxcbiAgICAweDlDOUY6IDB4NjA4NCxcbiAgICAweDlDQTA6IDB4NjA5QixcbiAgICAweDlDQTE6IDB4NjA5NixcbiAgICAweDlDQTI6IDB4NjA5NyxcbiAgICAweDlDQTM6IDB4NjA5MixcbiAgICAweDlDQTQ6IDB4NjBBNyxcbiAgICAweDlDQTU6IDB4NjA4QixcbiAgICAweDlDQTY6IDB4NjBFMSxcbiAgICAweDlDQTc6IDB4NjBCOCxcbiAgICAweDlDQTg6IDB4NjBFMCxcbiAgICAweDlDQTk6IDB4NjBEMyxcbiAgICAweDlDQUE6IDB4NjBCNCxcbiAgICAweDlDQUI6IDB4NUZGMCxcbiAgICAweDlDQUM6IDB4NjBCRCxcbiAgICAweDlDQUQ6IDB4NjBDNixcbiAgICAweDlDQUU6IDB4NjBCNSxcbiAgICAweDlDQUY6IDB4NjBEOCxcbiAgICAweDlDQjA6IDB4NjE0RCxcbiAgICAweDlDQjE6IDB4NjExNSxcbiAgICAweDlDQjI6IDB4NjEwNixcbiAgICAweDlDQjM6IDB4NjBGNixcbiAgICAweDlDQjQ6IDB4NjBGNyxcbiAgICAweDlDQjU6IDB4NjEwMCxcbiAgICAweDlDQjY6IDB4NjBGNCxcbiAgICAweDlDQjc6IDB4NjBGQSxcbiAgICAweDlDQjg6IDB4NjEwMyxcbiAgICAweDlDQjk6IDB4NjEyMSxcbiAgICAweDlDQkE6IDB4NjBGQixcbiAgICAweDlDQkI6IDB4NjBGMSxcbiAgICAweDlDQkM6IDB4NjEwRCxcbiAgICAweDlDQkQ6IDB4NjEwRSxcbiAgICAweDlDQkU6IDB4NjE0NyxcbiAgICAweDlDQkY6IDB4NjEzRSxcbiAgICAweDlDQzA6IDB4NjEyOCxcbiAgICAweDlDQzE6IDB4NjEyNyxcbiAgICAweDlDQzI6IDB4NjE0QSxcbiAgICAweDlDQzM6IDB4NjEzRixcbiAgICAweDlDQzQ6IDB4NjEzQyxcbiAgICAweDlDQzU6IDB4NjEyQyxcbiAgICAweDlDQzY6IDB4NjEzNCxcbiAgICAweDlDQzc6IDB4NjEzRCxcbiAgICAweDlDQzg6IDB4NjE0MixcbiAgICAweDlDQzk6IDB4NjE0NCxcbiAgICAweDlDQ0E6IDB4NjE3MyxcbiAgICAweDlDQ0I6IDB4NjE3NyxcbiAgICAweDlDQ0M6IDB4NjE1OCxcbiAgICAweDlDQ0Q6IDB4NjE1OSxcbiAgICAweDlDQ0U6IDB4NjE1QSxcbiAgICAweDlDQ0Y6IDB4NjE2QixcbiAgICAweDlDRDA6IDB4NjE3NCxcbiAgICAweDlDRDE6IDB4NjE2RixcbiAgICAweDlDRDI6IDB4NjE2NSxcbiAgICAweDlDRDM6IDB4NjE3MSxcbiAgICAweDlDRDQ6IDB4NjE1RixcbiAgICAweDlDRDU6IDB4NjE1RCxcbiAgICAweDlDRDY6IDB4NjE1MyxcbiAgICAweDlDRDc6IDB4NjE3NSxcbiAgICAweDlDRDg6IDB4NjE5OSxcbiAgICAweDlDRDk6IDB4NjE5NixcbiAgICAweDlDREE6IDB4NjE4NyxcbiAgICAweDlDREI6IDB4NjFBQyxcbiAgICAweDlDREM6IDB4NjE5NCxcbiAgICAweDlDREQ6IDB4NjE5QSxcbiAgICAweDlDREU6IDB4NjE4QSxcbiAgICAweDlDREY6IDB4NjE5MSxcbiAgICAweDlDRTA6IDB4NjFBQixcbiAgICAweDlDRTE6IDB4NjFBRSxcbiAgICAweDlDRTI6IDB4NjFDQyxcbiAgICAweDlDRTM6IDB4NjFDQSxcbiAgICAweDlDRTQ6IDB4NjFDOSxcbiAgICAweDlDRTU6IDB4NjFGNyxcbiAgICAweDlDRTY6IDB4NjFDOCxcbiAgICAweDlDRTc6IDB4NjFDMyxcbiAgICAweDlDRTg6IDB4NjFDNixcbiAgICAweDlDRTk6IDB4NjFCQSxcbiAgICAweDlDRUE6IDB4NjFDQixcbiAgICAweDlDRUI6IDB4N0Y3OSxcbiAgICAweDlDRUM6IDB4NjFDRCxcbiAgICAweDlDRUQ6IDB4NjFFNixcbiAgICAweDlDRUU6IDB4NjFFMyxcbiAgICAweDlDRUY6IDB4NjFGNixcbiAgICAweDlDRjA6IDB4NjFGQSxcbiAgICAweDlDRjE6IDB4NjFGNCxcbiAgICAweDlDRjI6IDB4NjFGRixcbiAgICAweDlDRjM6IDB4NjFGRCxcbiAgICAweDlDRjQ6IDB4NjFGQyxcbiAgICAweDlDRjU6IDB4NjFGRSxcbiAgICAweDlDRjY6IDB4NjIwMCxcbiAgICAweDlDRjc6IDB4NjIwOCxcbiAgICAweDlDRjg6IDB4NjIwOSxcbiAgICAweDlDRjk6IDB4NjIwRCxcbiAgICAweDlDRkE6IDB4NjIwQyxcbiAgICAweDlDRkI6IDB4NjIxNCxcbiAgICAweDlDRkM6IDB4NjIxQixcbiAgICAweDlENDA6IDB4NjIxRSxcbiAgICAweDlENDE6IDB4NjIyMSxcbiAgICAweDlENDI6IDB4NjIyQSxcbiAgICAweDlENDM6IDB4NjIyRSxcbiAgICAweDlENDQ6IDB4NjIzMCxcbiAgICAweDlENDU6IDB4NjIzMixcbiAgICAweDlENDY6IDB4NjIzMyxcbiAgICAweDlENDc6IDB4NjI0MSxcbiAgICAweDlENDg6IDB4NjI0RSxcbiAgICAweDlENDk6IDB4NjI1RSxcbiAgICAweDlENEE6IDB4NjI2MyxcbiAgICAweDlENEI6IDB4NjI1QixcbiAgICAweDlENEM6IDB4NjI2MCxcbiAgICAweDlENEQ6IDB4NjI2OCxcbiAgICAweDlENEU6IDB4NjI3QyxcbiAgICAweDlENEY6IDB4NjI4MixcbiAgICAweDlENTA6IDB4NjI4OSxcbiAgICAweDlENTE6IDB4NjI3RSxcbiAgICAweDlENTI6IDB4NjI5MixcbiAgICAweDlENTM6IDB4NjI5MyxcbiAgICAweDlENTQ6IDB4NjI5NixcbiAgICAweDlENTU6IDB4NjJENCxcbiAgICAweDlENTY6IDB4NjI4MyxcbiAgICAweDlENTc6IDB4NjI5NCxcbiAgICAweDlENTg6IDB4NjJENyxcbiAgICAweDlENTk6IDB4NjJEMSxcbiAgICAweDlENUE6IDB4NjJCQixcbiAgICAweDlENUI6IDB4NjJDRixcbiAgICAweDlENUM6IDB4NjJGRixcbiAgICAweDlENUQ6IDB4NjJDNixcbiAgICAweDlENUU6IDB4NjRENCxcbiAgICAweDlENUY6IDB4NjJDOCxcbiAgICAweDlENjA6IDB4NjJEQyxcbiAgICAweDlENjE6IDB4NjJDQyxcbiAgICAweDlENjI6IDB4NjJDQSxcbiAgICAweDlENjM6IDB4NjJDMixcbiAgICAweDlENjQ6IDB4NjJDNyxcbiAgICAweDlENjU6IDB4NjI5QixcbiAgICAweDlENjY6IDB4NjJDOSxcbiAgICAweDlENjc6IDB4NjMwQyxcbiAgICAweDlENjg6IDB4NjJFRSxcbiAgICAweDlENjk6IDB4NjJGMSxcbiAgICAweDlENkE6IDB4NjMyNyxcbiAgICAweDlENkI6IDB4NjMwMixcbiAgICAweDlENkM6IDB4NjMwOCxcbiAgICAweDlENkQ6IDB4NjJFRixcbiAgICAweDlENkU6IDB4NjJGNSxcbiAgICAweDlENkY6IDB4NjM1MCxcbiAgICAweDlENzA6IDB4NjMzRSxcbiAgICAweDlENzE6IDB4NjM0RCxcbiAgICAweDlENzI6IDB4NjQxQyxcbiAgICAweDlENzM6IDB4NjM0RixcbiAgICAweDlENzQ6IDB4NjM5NixcbiAgICAweDlENzU6IDB4NjM4RSxcbiAgICAweDlENzY6IDB4NjM4MCxcbiAgICAweDlENzc6IDB4NjNBQixcbiAgICAweDlENzg6IDB4NjM3NixcbiAgICAweDlENzk6IDB4NjNBMyxcbiAgICAweDlEN0E6IDB4NjM4RixcbiAgICAweDlEN0I6IDB4NjM4OSxcbiAgICAweDlEN0M6IDB4NjM5RixcbiAgICAweDlEN0Q6IDB4NjNCNSxcbiAgICAweDlEN0U6IDB4NjM2QixcbiAgICAweDlEODA6IDB4NjM2OSxcbiAgICAweDlEODE6IDB4NjNCRSxcbiAgICAweDlEODI6IDB4NjNFOSxcbiAgICAweDlEODM6IDB4NjNDMCxcbiAgICAweDlEODQ6IDB4NjNDNixcbiAgICAweDlEODU6IDB4NjNFMyxcbiAgICAweDlEODY6IDB4NjNDOSxcbiAgICAweDlEODc6IDB4NjNEMixcbiAgICAweDlEODg6IDB4NjNGNixcbiAgICAweDlEODk6IDB4NjNDNCxcbiAgICAweDlEOEE6IDB4NjQxNixcbiAgICAweDlEOEI6IDB4NjQzNCxcbiAgICAweDlEOEM6IDB4NjQwNixcbiAgICAweDlEOEQ6IDB4NjQxMyxcbiAgICAweDlEOEU6IDB4NjQyNixcbiAgICAweDlEOEY6IDB4NjQzNixcbiAgICAweDlEOTA6IDB4NjUxRCxcbiAgICAweDlEOTE6IDB4NjQxNyxcbiAgICAweDlEOTI6IDB4NjQyOCxcbiAgICAweDlEOTM6IDB4NjQwRixcbiAgICAweDlEOTQ6IDB4NjQ2NyxcbiAgICAweDlEOTU6IDB4NjQ2RixcbiAgICAweDlEOTY6IDB4NjQ3NixcbiAgICAweDlEOTc6IDB4NjQ0RSxcbiAgICAweDlEOTg6IDB4NjUyQSxcbiAgICAweDlEOTk6IDB4NjQ5NSxcbiAgICAweDlEOUE6IDB4NjQ5MyxcbiAgICAweDlEOUI6IDB4NjRBNSxcbiAgICAweDlEOUM6IDB4NjRBOSxcbiAgICAweDlEOUQ6IDB4NjQ4OCxcbiAgICAweDlEOUU6IDB4NjRCQyxcbiAgICAweDlEOUY6IDB4NjREQSxcbiAgICAweDlEQTA6IDB4NjREMixcbiAgICAweDlEQTE6IDB4NjRDNSxcbiAgICAweDlEQTI6IDB4NjRDNyxcbiAgICAweDlEQTM6IDB4NjRCQixcbiAgICAweDlEQTQ6IDB4NjREOCxcbiAgICAweDlEQTU6IDB4NjRDMixcbiAgICAweDlEQTY6IDB4NjRGMSxcbiAgICAweDlEQTc6IDB4NjRFNyxcbiAgICAweDlEQTg6IDB4ODIwOSxcbiAgICAweDlEQTk6IDB4NjRFMCxcbiAgICAweDlEQUE6IDB4NjRFMSxcbiAgICAweDlEQUI6IDB4NjJBQyxcbiAgICAweDlEQUM6IDB4NjRFMyxcbiAgICAweDlEQUQ6IDB4NjRFRixcbiAgICAweDlEQUU6IDB4NjUyQyxcbiAgICAweDlEQUY6IDB4NjRGNixcbiAgICAweDlEQjA6IDB4NjRGNCxcbiAgICAweDlEQjE6IDB4NjRGMixcbiAgICAweDlEQjI6IDB4NjRGQSxcbiAgICAweDlEQjM6IDB4NjUwMCxcbiAgICAweDlEQjQ6IDB4NjRGRCxcbiAgICAweDlEQjU6IDB4NjUxOCxcbiAgICAweDlEQjY6IDB4NjUxQyxcbiAgICAweDlEQjc6IDB4NjUwNSxcbiAgICAweDlEQjg6IDB4NjUyNCxcbiAgICAweDlEQjk6IDB4NjUyMyxcbiAgICAweDlEQkE6IDB4NjUyQixcbiAgICAweDlEQkI6IDB4NjUzNCxcbiAgICAweDlEQkM6IDB4NjUzNSxcbiAgICAweDlEQkQ6IDB4NjUzNyxcbiAgICAweDlEQkU6IDB4NjUzNixcbiAgICAweDlEQkY6IDB4NjUzOCxcbiAgICAweDlEQzA6IDB4NzU0QixcbiAgICAweDlEQzE6IDB4NjU0OCxcbiAgICAweDlEQzI6IDB4NjU1NixcbiAgICAweDlEQzM6IDB4NjU1NSxcbiAgICAweDlEQzQ6IDB4NjU0RCxcbiAgICAweDlEQzU6IDB4NjU1OCxcbiAgICAweDlEQzY6IDB4NjU1RSxcbiAgICAweDlEQzc6IDB4NjU1RCxcbiAgICAweDlEQzg6IDB4NjU3MixcbiAgICAweDlEQzk6IDB4NjU3OCxcbiAgICAweDlEQ0E6IDB4NjU4MixcbiAgICAweDlEQ0I6IDB4NjU4MyxcbiAgICAweDlEQ0M6IDB4OEI4QSxcbiAgICAweDlEQ0Q6IDB4NjU5QixcbiAgICAweDlEQ0U6IDB4NjU5RixcbiAgICAweDlEQ0Y6IDB4NjVBQixcbiAgICAweDlERDA6IDB4NjVCNyxcbiAgICAweDlERDE6IDB4NjVDMyxcbiAgICAweDlERDI6IDB4NjVDNixcbiAgICAweDlERDM6IDB4NjVDMSxcbiAgICAweDlERDQ6IDB4NjVDNCxcbiAgICAweDlERDU6IDB4NjVDQyxcbiAgICAweDlERDY6IDB4NjVEMixcbiAgICAweDlERDc6IDB4NjVEQixcbiAgICAweDlERDg6IDB4NjVEOSxcbiAgICAweDlERDk6IDB4NjVFMCxcbiAgICAweDlEREE6IDB4NjVFMSxcbiAgICAweDlEREI6IDB4NjVGMSxcbiAgICAweDlEREM6IDB4Njc3MixcbiAgICAweDlEREQ6IDB4NjYwQSxcbiAgICAweDlEREU6IDB4NjYwMyxcbiAgICAweDlEREY6IDB4NjVGQixcbiAgICAweDlERTA6IDB4Njc3MyxcbiAgICAweDlERTE6IDB4NjYzNSxcbiAgICAweDlERTI6IDB4NjYzNixcbiAgICAweDlERTM6IDB4NjYzNCxcbiAgICAweDlERTQ6IDB4NjYxQyxcbiAgICAweDlERTU6IDB4NjY0RixcbiAgICAweDlERTY6IDB4NjY0NCxcbiAgICAweDlERTc6IDB4NjY0OSxcbiAgICAweDlERTg6IDB4NjY0MSxcbiAgICAweDlERTk6IDB4NjY1RSxcbiAgICAweDlERUE6IDB4NjY1RCxcbiAgICAweDlERUI6IDB4NjY2NCxcbiAgICAweDlERUM6IDB4NjY2NyxcbiAgICAweDlERUQ6IDB4NjY2OCxcbiAgICAweDlERUU6IDB4NjY1RixcbiAgICAweDlERUY6IDB4NjY2MixcbiAgICAweDlERjA6IDB4NjY3MCxcbiAgICAweDlERjE6IDB4NjY4MyxcbiAgICAweDlERjI6IDB4NjY4OCxcbiAgICAweDlERjM6IDB4NjY4RSxcbiAgICAweDlERjQ6IDB4NjY4OSxcbiAgICAweDlERjU6IDB4NjY4NCxcbiAgICAweDlERjY6IDB4NjY5OCxcbiAgICAweDlERjc6IDB4NjY5RCxcbiAgICAweDlERjg6IDB4NjZDMSxcbiAgICAweDlERjk6IDB4NjZCOSxcbiAgICAweDlERkE6IDB4NjZDOSxcbiAgICAweDlERkI6IDB4NjZCRSxcbiAgICAweDlERkM6IDB4NjZCQyxcbiAgICAweDlFNDA6IDB4NjZDNCxcbiAgICAweDlFNDE6IDB4NjZCOCxcbiAgICAweDlFNDI6IDB4NjZENixcbiAgICAweDlFNDM6IDB4NjZEQSxcbiAgICAweDlFNDQ6IDB4NjZFMCxcbiAgICAweDlFNDU6IDB4NjYzRixcbiAgICAweDlFNDY6IDB4NjZFNixcbiAgICAweDlFNDc6IDB4NjZFOSxcbiAgICAweDlFNDg6IDB4NjZGMCxcbiAgICAweDlFNDk6IDB4NjZGNSxcbiAgICAweDlFNEE6IDB4NjZGNyxcbiAgICAweDlFNEI6IDB4NjcwRixcbiAgICAweDlFNEM6IDB4NjcxNixcbiAgICAweDlFNEQ6IDB4NjcxRSxcbiAgICAweDlFNEU6IDB4NjcyNixcbiAgICAweDlFNEY6IDB4NjcyNyxcbiAgICAweDlFNTA6IDB4OTczOCxcbiAgICAweDlFNTE6IDB4NjcyRSxcbiAgICAweDlFNTI6IDB4NjczRixcbiAgICAweDlFNTM6IDB4NjczNixcbiAgICAweDlFNTQ6IDB4Njc0MSxcbiAgICAweDlFNTU6IDB4NjczOCxcbiAgICAweDlFNTY6IDB4NjczNyxcbiAgICAweDlFNTc6IDB4Njc0NixcbiAgICAweDlFNTg6IDB4Njc1RSxcbiAgICAweDlFNTk6IDB4Njc2MCxcbiAgICAweDlFNUE6IDB4Njc1OSxcbiAgICAweDlFNUI6IDB4Njc2MyxcbiAgICAweDlFNUM6IDB4Njc2NCxcbiAgICAweDlFNUQ6IDB4Njc4OSxcbiAgICAweDlFNUU6IDB4Njc3MCxcbiAgICAweDlFNUY6IDB4NjdBOSxcbiAgICAweDlFNjA6IDB4Njc3QyxcbiAgICAweDlFNjE6IDB4Njc2QSxcbiAgICAweDlFNjI6IDB4Njc4QyxcbiAgICAweDlFNjM6IDB4Njc4QixcbiAgICAweDlFNjQ6IDB4NjdBNixcbiAgICAweDlFNjU6IDB4NjdBMSxcbiAgICAweDlFNjY6IDB4Njc4NSxcbiAgICAweDlFNjc6IDB4NjdCNyxcbiAgICAweDlFNjg6IDB4NjdFRixcbiAgICAweDlFNjk6IDB4NjdCNCxcbiAgICAweDlFNkE6IDB4NjdFQyxcbiAgICAweDlFNkI6IDB4NjdCMyxcbiAgICAweDlFNkM6IDB4NjdFOSxcbiAgICAweDlFNkQ6IDB4NjdCOCxcbiAgICAweDlFNkU6IDB4NjdFNCxcbiAgICAweDlFNkY6IDB4NjdERSxcbiAgICAweDlFNzA6IDB4NjdERCxcbiAgICAweDlFNzE6IDB4NjdFMixcbiAgICAweDlFNzI6IDB4NjdFRSxcbiAgICAweDlFNzM6IDB4NjdCOSxcbiAgICAweDlFNzQ6IDB4NjdDRSxcbiAgICAweDlFNzU6IDB4NjdDNixcbiAgICAweDlFNzY6IDB4NjdFNyxcbiAgICAweDlFNzc6IDB4NkE5QyxcbiAgICAweDlFNzg6IDB4NjgxRSxcbiAgICAweDlFNzk6IDB4Njg0NixcbiAgICAweDlFN0E6IDB4NjgyOSxcbiAgICAweDlFN0I6IDB4Njg0MCxcbiAgICAweDlFN0M6IDB4Njg0RCxcbiAgICAweDlFN0Q6IDB4NjgzMixcbiAgICAweDlFN0U6IDB4Njg0RSxcbiAgICAweDlFODA6IDB4NjhCMyxcbiAgICAweDlFODE6IDB4NjgyQixcbiAgICAweDlFODI6IDB4Njg1OSxcbiAgICAweDlFODM6IDB4Njg2MyxcbiAgICAweDlFODQ6IDB4Njg3NyxcbiAgICAweDlFODU6IDB4Njg3RixcbiAgICAweDlFODY6IDB4Njg5RixcbiAgICAweDlFODc6IDB4Njg4RixcbiAgICAweDlFODg6IDB4NjhBRCxcbiAgICAweDlFODk6IDB4Njg5NCxcbiAgICAweDlFOEE6IDB4Njg5RCxcbiAgICAweDlFOEI6IDB4Njg5QixcbiAgICAweDlFOEM6IDB4Njg4MyxcbiAgICAweDlFOEQ6IDB4NkFBRSxcbiAgICAweDlFOEU6IDB4NjhCOSxcbiAgICAweDlFOEY6IDB4Njg3NCxcbiAgICAweDlFOTA6IDB4NjhCNSxcbiAgICAweDlFOTE6IDB4NjhBMCxcbiAgICAweDlFOTI6IDB4NjhCQSxcbiAgICAweDlFOTM6IDB4NjkwRixcbiAgICAweDlFOTQ6IDB4Njg4RCxcbiAgICAweDlFOTU6IDB4Njg3RSxcbiAgICAweDlFOTY6IDB4NjkwMSxcbiAgICAweDlFOTc6IDB4NjhDQSxcbiAgICAweDlFOTg6IDB4NjkwOCxcbiAgICAweDlFOTk6IDB4NjhEOCxcbiAgICAweDlFOUE6IDB4NjkyMixcbiAgICAweDlFOUI6IDB4NjkyNixcbiAgICAweDlFOUM6IDB4NjhFMSxcbiAgICAweDlFOUQ6IDB4NjkwQyxcbiAgICAweDlFOUU6IDB4NjhDRCxcbiAgICAweDlFOUY6IDB4NjhENCxcbiAgICAweDlFQTA6IDB4NjhFNyxcbiAgICAweDlFQTE6IDB4NjhENSxcbiAgICAweDlFQTI6IDB4NjkzNixcbiAgICAweDlFQTM6IDB4NjkxMixcbiAgICAweDlFQTQ6IDB4NjkwNCxcbiAgICAweDlFQTU6IDB4NjhENyxcbiAgICAweDlFQTY6IDB4NjhFMyxcbiAgICAweDlFQTc6IDB4NjkyNSxcbiAgICAweDlFQTg6IDB4NjhGOSxcbiAgICAweDlFQTk6IDB4NjhFMCxcbiAgICAweDlFQUE6IDB4NjhFRixcbiAgICAweDlFQUI6IDB4NjkyOCxcbiAgICAweDlFQUM6IDB4NjkyQSxcbiAgICAweDlFQUQ6IDB4NjkxQSxcbiAgICAweDlFQUU6IDB4NjkyMyxcbiAgICAweDlFQUY6IDB4NjkyMSxcbiAgICAweDlFQjA6IDB4NjhDNixcbiAgICAweDlFQjE6IDB4Njk3OSxcbiAgICAweDlFQjI6IDB4Njk3NyxcbiAgICAweDlFQjM6IDB4Njk1QyxcbiAgICAweDlFQjQ6IDB4Njk3OCxcbiAgICAweDlFQjU6IDB4Njk2QixcbiAgICAweDlFQjY6IDB4Njk1NCxcbiAgICAweDlFQjc6IDB4Njk3RSxcbiAgICAweDlFQjg6IDB4Njk2RSxcbiAgICAweDlFQjk6IDB4NjkzOSxcbiAgICAweDlFQkE6IDB4Njk3NCxcbiAgICAweDlFQkI6IDB4NjkzRCxcbiAgICAweDlFQkM6IDB4Njk1OSxcbiAgICAweDlFQkQ6IDB4NjkzMCxcbiAgICAweDlFQkU6IDB4Njk2MSxcbiAgICAweDlFQkY6IDB4Njk1RSxcbiAgICAweDlFQzA6IDB4Njk1RCxcbiAgICAweDlFQzE6IDB4Njk4MSxcbiAgICAweDlFQzI6IDB4Njk2QSxcbiAgICAweDlFQzM6IDB4NjlCMixcbiAgICAweDlFQzQ6IDB4NjlBRSxcbiAgICAweDlFQzU6IDB4NjlEMCxcbiAgICAweDlFQzY6IDB4NjlCRixcbiAgICAweDlFQzc6IDB4NjlDMSxcbiAgICAweDlFQzg6IDB4NjlEMyxcbiAgICAweDlFQzk6IDB4NjlCRSxcbiAgICAweDlFQ0E6IDB4NjlDRSxcbiAgICAweDlFQ0I6IDB4NUJFOCxcbiAgICAweDlFQ0M6IDB4NjlDQSxcbiAgICAweDlFQ0Q6IDB4NjlERCxcbiAgICAweDlFQ0U6IDB4NjlCQixcbiAgICAweDlFQ0Y6IDB4NjlDMyxcbiAgICAweDlFRDA6IDB4NjlBNyxcbiAgICAweDlFRDE6IDB4NkEyRSxcbiAgICAweDlFRDI6IDB4Njk5MSxcbiAgICAweDlFRDM6IDB4NjlBMCxcbiAgICAweDlFRDQ6IDB4Njk5QyxcbiAgICAweDlFRDU6IDB4Njk5NSxcbiAgICAweDlFRDY6IDB4NjlCNCxcbiAgICAweDlFRDc6IDB4NjlERSxcbiAgICAweDlFRDg6IDB4NjlFOCxcbiAgICAweDlFRDk6IDB4NkEwMixcbiAgICAweDlFREE6IDB4NkExQixcbiAgICAweDlFREI6IDB4NjlGRixcbiAgICAweDlFREM6IDB4NkIwQSxcbiAgICAweDlFREQ6IDB4NjlGOSxcbiAgICAweDlFREU6IDB4NjlGMixcbiAgICAweDlFREY6IDB4NjlFNyxcbiAgICAweDlFRTA6IDB4NkEwNSxcbiAgICAweDlFRTE6IDB4NjlCMSxcbiAgICAweDlFRTI6IDB4NkExRSxcbiAgICAweDlFRTM6IDB4NjlFRCxcbiAgICAweDlFRTQ6IDB4NkExNCxcbiAgICAweDlFRTU6IDB4NjlFQixcbiAgICAweDlFRTY6IDB4NkEwQSxcbiAgICAweDlFRTc6IDB4NkExMixcbiAgICAweDlFRTg6IDB4NkFDMSxcbiAgICAweDlFRTk6IDB4NkEyMyxcbiAgICAweDlFRUE6IDB4NkExMyxcbiAgICAweDlFRUI6IDB4NkE0NCxcbiAgICAweDlFRUM6IDB4NkEwQyxcbiAgICAweDlFRUQ6IDB4NkE3MixcbiAgICAweDlFRUU6IDB4NkEzNixcbiAgICAweDlFRUY6IDB4NkE3OCxcbiAgICAweDlFRjA6IDB4NkE0NyxcbiAgICAweDlFRjE6IDB4NkE2MixcbiAgICAweDlFRjI6IDB4NkE1OSxcbiAgICAweDlFRjM6IDB4NkE2NixcbiAgICAweDlFRjQ6IDB4NkE0OCxcbiAgICAweDlFRjU6IDB4NkEzOCxcbiAgICAweDlFRjY6IDB4NkEyMixcbiAgICAweDlFRjc6IDB4NkE5MCxcbiAgICAweDlFRjg6IDB4NkE4RCxcbiAgICAweDlFRjk6IDB4NkFBMCxcbiAgICAweDlFRkE6IDB4NkE4NCxcbiAgICAweDlFRkI6IDB4NkFBMixcbiAgICAweDlFRkM6IDB4NkFBMyxcbiAgICAweDlGNDA6IDB4NkE5NyxcbiAgICAweDlGNDE6IDB4ODYxNyxcbiAgICAweDlGNDI6IDB4NkFCQixcbiAgICAweDlGNDM6IDB4NkFDMyxcbiAgICAweDlGNDQ6IDB4NkFDMixcbiAgICAweDlGNDU6IDB4NkFCOCxcbiAgICAweDlGNDY6IDB4NkFCMyxcbiAgICAweDlGNDc6IDB4NkFBQyxcbiAgICAweDlGNDg6IDB4NkFERSxcbiAgICAweDlGNDk6IDB4NkFEMSxcbiAgICAweDlGNEE6IDB4NkFERixcbiAgICAweDlGNEI6IDB4NkFBQSxcbiAgICAweDlGNEM6IDB4NkFEQSxcbiAgICAweDlGNEQ6IDB4NkFFQSxcbiAgICAweDlGNEU6IDB4NkFGQixcbiAgICAweDlGNEY6IDB4NkIwNSxcbiAgICAweDlGNTA6IDB4ODYxNixcbiAgICAweDlGNTE6IDB4NkFGQSxcbiAgICAweDlGNTI6IDB4NkIxMixcbiAgICAweDlGNTM6IDB4NkIxNixcbiAgICAweDlGNTQ6IDB4OUIzMSxcbiAgICAweDlGNTU6IDB4NkIxRixcbiAgICAweDlGNTY6IDB4NkIzOCxcbiAgICAweDlGNTc6IDB4NkIzNyxcbiAgICAweDlGNTg6IDB4NzZEQyxcbiAgICAweDlGNTk6IDB4NkIzOSxcbiAgICAweDlGNUE6IDB4OThFRSxcbiAgICAweDlGNUI6IDB4NkI0NyxcbiAgICAweDlGNUM6IDB4NkI0MyxcbiAgICAweDlGNUQ6IDB4NkI0OSxcbiAgICAweDlGNUU6IDB4NkI1MCxcbiAgICAweDlGNUY6IDB4NkI1OSxcbiAgICAweDlGNjA6IDB4NkI1NCxcbiAgICAweDlGNjE6IDB4NkI1QixcbiAgICAweDlGNjI6IDB4NkI1RixcbiAgICAweDlGNjM6IDB4NkI2MSxcbiAgICAweDlGNjQ6IDB4NkI3OCxcbiAgICAweDlGNjU6IDB4NkI3OSxcbiAgICAweDlGNjY6IDB4NkI3RixcbiAgICAweDlGNjc6IDB4NkI4MCxcbiAgICAweDlGNjg6IDB4NkI4NCxcbiAgICAweDlGNjk6IDB4NkI4MyxcbiAgICAweDlGNkE6IDB4NkI4RCxcbiAgICAweDlGNkI6IDB4NkI5OCxcbiAgICAweDlGNkM6IDB4NkI5NSxcbiAgICAweDlGNkQ6IDB4NkI5RSxcbiAgICAweDlGNkU6IDB4NkJBNCxcbiAgICAweDlGNkY6IDB4NkJBQSxcbiAgICAweDlGNzA6IDB4NkJBQixcbiAgICAweDlGNzE6IDB4NkJBRixcbiAgICAweDlGNzI6IDB4NkJCMixcbiAgICAweDlGNzM6IDB4NkJCMSxcbiAgICAweDlGNzQ6IDB4NkJCMyxcbiAgICAweDlGNzU6IDB4NkJCNyxcbiAgICAweDlGNzY6IDB4NkJCQyxcbiAgICAweDlGNzc6IDB4NkJDNixcbiAgICAweDlGNzg6IDB4NkJDQixcbiAgICAweDlGNzk6IDB4NkJEMyxcbiAgICAweDlGN0E6IDB4NkJERixcbiAgICAweDlGN0I6IDB4NkJFQyxcbiAgICAweDlGN0M6IDB4NkJFQixcbiAgICAweDlGN0Q6IDB4NkJGMyxcbiAgICAweDlGN0U6IDB4NkJFRixcbiAgICAweDlGODA6IDB4OUVCRSxcbiAgICAweDlGODE6IDB4NkMwOCxcbiAgICAweDlGODI6IDB4NkMxMyxcbiAgICAweDlGODM6IDB4NkMxNCxcbiAgICAweDlGODQ6IDB4NkMxQixcbiAgICAweDlGODU6IDB4NkMyNCxcbiAgICAweDlGODY6IDB4NkMyMyxcbiAgICAweDlGODc6IDB4NkM1RSxcbiAgICAweDlGODg6IDB4NkM1NSxcbiAgICAweDlGODk6IDB4NkM2MixcbiAgICAweDlGOEE6IDB4NkM2QSxcbiAgICAweDlGOEI6IDB4NkM4MixcbiAgICAweDlGOEM6IDB4NkM4RCxcbiAgICAweDlGOEQ6IDB4NkM5QSxcbiAgICAweDlGOEU6IDB4NkM4MSxcbiAgICAweDlGOEY6IDB4NkM5QixcbiAgICAweDlGOTA6IDB4NkM3RSxcbiAgICAweDlGOTE6IDB4NkM2OCxcbiAgICAweDlGOTI6IDB4NkM3MyxcbiAgICAweDlGOTM6IDB4NkM5MixcbiAgICAweDlGOTQ6IDB4NkM5MCxcbiAgICAweDlGOTU6IDB4NkNDNCxcbiAgICAweDlGOTY6IDB4NkNGMSxcbiAgICAweDlGOTc6IDB4NkNEMyxcbiAgICAweDlGOTg6IDB4NkNCRCxcbiAgICAweDlGOTk6IDB4NkNENyxcbiAgICAweDlGOUE6IDB4NkNDNSxcbiAgICAweDlGOUI6IDB4NkNERCxcbiAgICAweDlGOUM6IDB4NkNBRSxcbiAgICAweDlGOUQ6IDB4NkNCMSxcbiAgICAweDlGOUU6IDB4NkNCRSxcbiAgICAweDlGOUY6IDB4NkNCQSxcbiAgICAweDlGQTA6IDB4NkNEQixcbiAgICAweDlGQTE6IDB4NkNFRixcbiAgICAweDlGQTI6IDB4NkNEOSxcbiAgICAweDlGQTM6IDB4NkNFQSxcbiAgICAweDlGQTQ6IDB4NkQxRixcbiAgICAweDlGQTU6IDB4ODg0RCxcbiAgICAweDlGQTY6IDB4NkQzNixcbiAgICAweDlGQTc6IDB4NkQyQixcbiAgICAweDlGQTg6IDB4NkQzRCxcbiAgICAweDlGQTk6IDB4NkQzOCxcbiAgICAweDlGQUE6IDB4NkQxOSxcbiAgICAweDlGQUI6IDB4NkQzNSxcbiAgICAweDlGQUM6IDB4NkQzMyxcbiAgICAweDlGQUQ6IDB4NkQxMixcbiAgICAweDlGQUU6IDB4NkQwQyxcbiAgICAweDlGQUY6IDB4NkQ2MyxcbiAgICAweDlGQjA6IDB4NkQ5MyxcbiAgICAweDlGQjE6IDB4NkQ2NCxcbiAgICAweDlGQjI6IDB4NkQ1QSxcbiAgICAweDlGQjM6IDB4NkQ3OSxcbiAgICAweDlGQjQ6IDB4NkQ1OSxcbiAgICAweDlGQjU6IDB4NkQ4RSxcbiAgICAweDlGQjY6IDB4NkQ5NSxcbiAgICAweDlGQjc6IDB4NkZFNCxcbiAgICAweDlGQjg6IDB4NkQ4NSxcbiAgICAweDlGQjk6IDB4NkRGOSxcbiAgICAweDlGQkE6IDB4NkUxNSxcbiAgICAweDlGQkI6IDB4NkUwQSxcbiAgICAweDlGQkM6IDB4NkRCNSxcbiAgICAweDlGQkQ6IDB4NkRDNyxcbiAgICAweDlGQkU6IDB4NkRFNixcbiAgICAweDlGQkY6IDB4NkRCOCxcbiAgICAweDlGQzA6IDB4NkRDNixcbiAgICAweDlGQzE6IDB4NkRFQyxcbiAgICAweDlGQzI6IDB4NkRERSxcbiAgICAweDlGQzM6IDB4NkRDQyxcbiAgICAweDlGQzQ6IDB4NkRFOCxcbiAgICAweDlGQzU6IDB4NkREMixcbiAgICAweDlGQzY6IDB4NkRDNSxcbiAgICAweDlGQzc6IDB4NkRGQSxcbiAgICAweDlGQzg6IDB4NkREOSxcbiAgICAweDlGQzk6IDB4NkRFNCxcbiAgICAweDlGQ0E6IDB4NkRENSxcbiAgICAweDlGQ0I6IDB4NkRFQSxcbiAgICAweDlGQ0M6IDB4NkRFRSxcbiAgICAweDlGQ0Q6IDB4NkUyRCxcbiAgICAweDlGQ0U6IDB4NkU2RSxcbiAgICAweDlGQ0Y6IDB4NkUyRSxcbiAgICAweDlGRDA6IDB4NkUxOSxcbiAgICAweDlGRDE6IDB4NkU3MixcbiAgICAweDlGRDI6IDB4NkU1RixcbiAgICAweDlGRDM6IDB4NkUzRSxcbiAgICAweDlGRDQ6IDB4NkUyMyxcbiAgICAweDlGRDU6IDB4NkU2QixcbiAgICAweDlGRDY6IDB4NkUyQixcbiAgICAweDlGRDc6IDB4NkU3NixcbiAgICAweDlGRDg6IDB4NkU0RCxcbiAgICAweDlGRDk6IDB4NkUxRixcbiAgICAweDlGREE6IDB4NkU0MyxcbiAgICAweDlGREI6IDB4NkUzQSxcbiAgICAweDlGREM6IDB4NkU0RSxcbiAgICAweDlGREQ6IDB4NkUyNCxcbiAgICAweDlGREU6IDB4NkVGRixcbiAgICAweDlGREY6IDB4NkUxRCxcbiAgICAweDlGRTA6IDB4NkUzOCxcbiAgICAweDlGRTE6IDB4NkU4MixcbiAgICAweDlGRTI6IDB4NkVBQSxcbiAgICAweDlGRTM6IDB4NkU5OCxcbiAgICAweDlGRTQ6IDB4NkVDOSxcbiAgICAweDlGRTU6IDB4NkVCNyxcbiAgICAweDlGRTY6IDB4NkVEMyxcbiAgICAweDlGRTc6IDB4NkVCRCxcbiAgICAweDlGRTg6IDB4NkVBRixcbiAgICAweDlGRTk6IDB4NkVDNCxcbiAgICAweDlGRUE6IDB4NkVCMixcbiAgICAweDlGRUI6IDB4NkVENCxcbiAgICAweDlGRUM6IDB4NkVENSxcbiAgICAweDlGRUQ6IDB4NkU4RixcbiAgICAweDlGRUU6IDB4NkVBNSxcbiAgICAweDlGRUY6IDB4NkVDMixcbiAgICAweDlGRjA6IDB4NkU5RixcbiAgICAweDlGRjE6IDB4NkY0MSxcbiAgICAweDlGRjI6IDB4NkYxMSxcbiAgICAweDlGRjM6IDB4NzA0QyxcbiAgICAweDlGRjQ6IDB4NkVFQyxcbiAgICAweDlGRjU6IDB4NkVGOCxcbiAgICAweDlGRjY6IDB4NkVGRSxcbiAgICAweDlGRjc6IDB4NkYzRixcbiAgICAweDlGRjg6IDB4NkVGMixcbiAgICAweDlGRjk6IDB4NkYzMSxcbiAgICAweDlGRkE6IDB4NkVFRixcbiAgICAweDlGRkI6IDB4NkYzMixcbiAgICAweDlGRkM6IDB4NkVDQyxcbiAgICAweEExOiAweEZGNjEsXG4gICAgMHhBMjogMHhGRjYyLFxuICAgIDB4QTM6IDB4RkY2MyxcbiAgICAweEE0OiAweEZGNjQsXG4gICAgMHhBNTogMHhGRjY1LFxuICAgIDB4QTY6IDB4RkY2NixcbiAgICAweEE3OiAweEZGNjcsXG4gICAgMHhBODogMHhGRjY4LFxuICAgIDB4QTk6IDB4RkY2OSxcbiAgICAweEFBOiAweEZGNkEsXG4gICAgMHhBQjogMHhGRjZCLFxuICAgIDB4QUM6IDB4RkY2QyxcbiAgICAweEFEOiAweEZGNkQsXG4gICAgMHhBRTogMHhGRjZFLFxuICAgIDB4QUY6IDB4RkY2RixcbiAgICAweEIwOiAweEZGNzAsXG4gICAgMHhCMTogMHhGRjcxLFxuICAgIDB4QjI6IDB4RkY3MixcbiAgICAweEIzOiAweEZGNzMsXG4gICAgMHhCNDogMHhGRjc0LFxuICAgIDB4QjU6IDB4RkY3NSxcbiAgICAweEI2OiAweEZGNzYsXG4gICAgMHhCNzogMHhGRjc3LFxuICAgIDB4Qjg6IDB4RkY3OCxcbiAgICAweEI5OiAweEZGNzksXG4gICAgMHhCQTogMHhGRjdBLFxuICAgIDB4QkI6IDB4RkY3QixcbiAgICAweEJDOiAweEZGN0MsXG4gICAgMHhCRDogMHhGRjdELFxuICAgIDB4QkU6IDB4RkY3RSxcbiAgICAweEJGOiAweEZGN0YsXG4gICAgMHhDMDogMHhGRjgwLFxuICAgIDB4QzE6IDB4RkY4MSxcbiAgICAweEMyOiAweEZGODIsXG4gICAgMHhDMzogMHhGRjgzLFxuICAgIDB4QzQ6IDB4RkY4NCxcbiAgICAweEM1OiAweEZGODUsXG4gICAgMHhDNjogMHhGRjg2LFxuICAgIDB4Qzc6IDB4RkY4NyxcbiAgICAweEM4OiAweEZGODgsXG4gICAgMHhDOTogMHhGRjg5LFxuICAgIDB4Q0E6IDB4RkY4QSxcbiAgICAweENCOiAweEZGOEIsXG4gICAgMHhDQzogMHhGRjhDLFxuICAgIDB4Q0Q6IDB4RkY4RCxcbiAgICAweENFOiAweEZGOEUsXG4gICAgMHhDRjogMHhGRjhGLFxuICAgIDB4RDA6IDB4RkY5MCxcbiAgICAweEQxOiAweEZGOTEsXG4gICAgMHhEMjogMHhGRjkyLFxuICAgIDB4RDM6IDB4RkY5MyxcbiAgICAweEQ0OiAweEZGOTQsXG4gICAgMHhENTogMHhGRjk1LFxuICAgIDB4RDY6IDB4RkY5NixcbiAgICAweEQ3OiAweEZGOTcsXG4gICAgMHhEODogMHhGRjk4LFxuICAgIDB4RDk6IDB4RkY5OSxcbiAgICAweERBOiAweEZGOUEsXG4gICAgMHhEQjogMHhGRjlCLFxuICAgIDB4REM6IDB4RkY5QyxcbiAgICAweEREOiAweEZGOUQsXG4gICAgMHhERTogMHhGRjlFLFxuICAgIDB4REY6IDB4RkY5RixcbiAgICAweEUwNDA6IDB4NkYzRSxcbiAgICAweEUwNDE6IDB4NkYxMyxcbiAgICAweEUwNDI6IDB4NkVGNyxcbiAgICAweEUwNDM6IDB4NkY4NixcbiAgICAweEUwNDQ6IDB4NkY3QSxcbiAgICAweEUwNDU6IDB4NkY3OCxcbiAgICAweEUwNDY6IDB4NkY4MSxcbiAgICAweEUwNDc6IDB4NkY4MCxcbiAgICAweEUwNDg6IDB4NkY2RixcbiAgICAweEUwNDk6IDB4NkY1QixcbiAgICAweEUwNEE6IDB4NkZGMyxcbiAgICAweEUwNEI6IDB4NkY2RCxcbiAgICAweEUwNEM6IDB4NkY4MixcbiAgICAweEUwNEQ6IDB4NkY3QyxcbiAgICAweEUwNEU6IDB4NkY1OCxcbiAgICAweEUwNEY6IDB4NkY4RSxcbiAgICAweEUwNTA6IDB4NkY5MSxcbiAgICAweEUwNTE6IDB4NkZDMixcbiAgICAweEUwNTI6IDB4NkY2NixcbiAgICAweEUwNTM6IDB4NkZCMyxcbiAgICAweEUwNTQ6IDB4NkZBMyxcbiAgICAweEUwNTU6IDB4NkZBMSxcbiAgICAweEUwNTY6IDB4NkZBNCxcbiAgICAweEUwNTc6IDB4NkZCOSxcbiAgICAweEUwNTg6IDB4NkZDNixcbiAgICAweEUwNTk6IDB4NkZBQSxcbiAgICAweEUwNUE6IDB4NkZERixcbiAgICAweEUwNUI6IDB4NkZENSxcbiAgICAweEUwNUM6IDB4NkZFQyxcbiAgICAweEUwNUQ6IDB4NkZENCxcbiAgICAweEUwNUU6IDB4NkZEOCxcbiAgICAweEUwNUY6IDB4NkZGMSxcbiAgICAweEUwNjA6IDB4NkZFRSxcbiAgICAweEUwNjE6IDB4NkZEQixcbiAgICAweEUwNjI6IDB4NzAwOSxcbiAgICAweEUwNjM6IDB4NzAwQixcbiAgICAweEUwNjQ6IDB4NkZGQSxcbiAgICAweEUwNjU6IDB4NzAxMSxcbiAgICAweEUwNjY6IDB4NzAwMSxcbiAgICAweEUwNjc6IDB4NzAwRixcbiAgICAweEUwNjg6IDB4NkZGRSxcbiAgICAweEUwNjk6IDB4NzAxQixcbiAgICAweEUwNkE6IDB4NzAxQSxcbiAgICAweEUwNkI6IDB4NkY3NCxcbiAgICAweEUwNkM6IDB4NzAxRCxcbiAgICAweEUwNkQ6IDB4NzAxOCxcbiAgICAweEUwNkU6IDB4NzAxRixcbiAgICAweEUwNkY6IDB4NzAzMCxcbiAgICAweEUwNzA6IDB4NzAzRSxcbiAgICAweEUwNzE6IDB4NzAzMixcbiAgICAweEUwNzI6IDB4NzA1MSxcbiAgICAweEUwNzM6IDB4NzA2MyxcbiAgICAweEUwNzQ6IDB4NzA5OSxcbiAgICAweEUwNzU6IDB4NzA5MixcbiAgICAweEUwNzY6IDB4NzBBRixcbiAgICAweEUwNzc6IDB4NzBGMSxcbiAgICAweEUwNzg6IDB4NzBBQyxcbiAgICAweEUwNzk6IDB4NzBCOCxcbiAgICAweEUwN0E6IDB4NzBCMyxcbiAgICAweEUwN0I6IDB4NzBBRSxcbiAgICAweEUwN0M6IDB4NzBERixcbiAgICAweEUwN0Q6IDB4NzBDQixcbiAgICAweEUwN0U6IDB4NzBERCxcbiAgICAweEUwODA6IDB4NzBEOSxcbiAgICAweEUwODE6IDB4NzEwOSxcbiAgICAweEUwODI6IDB4NzBGRCxcbiAgICAweEUwODM6IDB4NzExQyxcbiAgICAweEUwODQ6IDB4NzExOSxcbiAgICAweEUwODU6IDB4NzE2NSxcbiAgICAweEUwODY6IDB4NzE1NSxcbiAgICAweEUwODc6IDB4NzE4OCxcbiAgICAweEUwODg6IDB4NzE2NixcbiAgICAweEUwODk6IDB4NzE2MixcbiAgICAweEUwOEE6IDB4NzE0QyxcbiAgICAweEUwOEI6IDB4NzE1NixcbiAgICAweEUwOEM6IDB4NzE2QyxcbiAgICAweEUwOEQ6IDB4NzE4RixcbiAgICAweEUwOEU6IDB4NzFGQixcbiAgICAweEUwOEY6IDB4NzE4NCxcbiAgICAweEUwOTA6IDB4NzE5NSxcbiAgICAweEUwOTE6IDB4NzFBOCxcbiAgICAweEUwOTI6IDB4NzFBQyxcbiAgICAweEUwOTM6IDB4NzFENyxcbiAgICAweEUwOTQ6IDB4NzFCOSxcbiAgICAweEUwOTU6IDB4NzFCRSxcbiAgICAweEUwOTY6IDB4NzFEMixcbiAgICAweEUwOTc6IDB4NzFDOSxcbiAgICAweEUwOTg6IDB4NzFENCxcbiAgICAweEUwOTk6IDB4NzFDRSxcbiAgICAweEUwOUE6IDB4NzFFMCxcbiAgICAweEUwOUI6IDB4NzFFQyxcbiAgICAweEUwOUM6IDB4NzFFNyxcbiAgICAweEUwOUQ6IDB4NzFGNSxcbiAgICAweEUwOUU6IDB4NzFGQyxcbiAgICAweEUwOUY6IDB4NzFGOSxcbiAgICAweEUwQTA6IDB4NzFGRixcbiAgICAweEUwQTE6IDB4NzIwRCxcbiAgICAweEUwQTI6IDB4NzIxMCxcbiAgICAweEUwQTM6IDB4NzIxQixcbiAgICAweEUwQTQ6IDB4NzIyOCxcbiAgICAweEUwQTU6IDB4NzIyRCxcbiAgICAweEUwQTY6IDB4NzIyQyxcbiAgICAweEUwQTc6IDB4NzIzMCxcbiAgICAweEUwQTg6IDB4NzIzMixcbiAgICAweEUwQTk6IDB4NzIzQixcbiAgICAweEUwQUE6IDB4NzIzQyxcbiAgICAweEUwQUI6IDB4NzIzRixcbiAgICAweEUwQUM6IDB4NzI0MCxcbiAgICAweEUwQUQ6IDB4NzI0NixcbiAgICAweEUwQUU6IDB4NzI0QixcbiAgICAweEUwQUY6IDB4NzI1OCxcbiAgICAweEUwQjA6IDB4NzI3NCxcbiAgICAweEUwQjE6IDB4NzI3RSxcbiAgICAweEUwQjI6IDB4NzI4MixcbiAgICAweEUwQjM6IDB4NzI4MSxcbiAgICAweEUwQjQ6IDB4NzI4NyxcbiAgICAweEUwQjU6IDB4NzI5MixcbiAgICAweEUwQjY6IDB4NzI5NixcbiAgICAweEUwQjc6IDB4NzJBMixcbiAgICAweEUwQjg6IDB4NzJBNyxcbiAgICAweEUwQjk6IDB4NzJCOSxcbiAgICAweEUwQkE6IDB4NzJCMixcbiAgICAweEUwQkI6IDB4NzJDMyxcbiAgICAweEUwQkM6IDB4NzJDNixcbiAgICAweEUwQkQ6IDB4NzJDNCxcbiAgICAweEUwQkU6IDB4NzJDRSxcbiAgICAweEUwQkY6IDB4NzJEMixcbiAgICAweEUwQzA6IDB4NzJFMixcbiAgICAweEUwQzE6IDB4NzJFMCxcbiAgICAweEUwQzI6IDB4NzJFMSxcbiAgICAweEUwQzM6IDB4NzJGOSxcbiAgICAweEUwQzQ6IDB4NzJGNyxcbiAgICAweEUwQzU6IDB4NTAwRixcbiAgICAweEUwQzY6IDB4NzMxNyxcbiAgICAweEUwQzc6IDB4NzMwQSxcbiAgICAweEUwQzg6IDB4NzMxQyxcbiAgICAweEUwQzk6IDB4NzMxNixcbiAgICAweEUwQ0E6IDB4NzMxRCxcbiAgICAweEUwQ0I6IDB4NzMzNCxcbiAgICAweEUwQ0M6IDB4NzMyRixcbiAgICAweEUwQ0Q6IDB4NzMyOSxcbiAgICAweEUwQ0U6IDB4NzMyNSxcbiAgICAweEUwQ0Y6IDB4NzMzRSxcbiAgICAweEUwRDA6IDB4NzM0RSxcbiAgICAweEUwRDE6IDB4NzM0RixcbiAgICAweEUwRDI6IDB4OUVEOCxcbiAgICAweEUwRDM6IDB4NzM1NyxcbiAgICAweEUwRDQ6IDB4NzM2QSxcbiAgICAweEUwRDU6IDB4NzM2OCxcbiAgICAweEUwRDY6IDB4NzM3MCxcbiAgICAweEUwRDc6IDB4NzM3OCxcbiAgICAweEUwRDg6IDB4NzM3NSxcbiAgICAweEUwRDk6IDB4NzM3QixcbiAgICAweEUwREE6IDB4NzM3QSxcbiAgICAweEUwREI6IDB4NzNDOCxcbiAgICAweEUwREM6IDB4NzNCMyxcbiAgICAweEUwREQ6IDB4NzNDRSxcbiAgICAweEUwREU6IDB4NzNCQixcbiAgICAweEUwREY6IDB4NzNDMCxcbiAgICAweEUwRTA6IDB4NzNFNSxcbiAgICAweEUwRTE6IDB4NzNFRSxcbiAgICAweEUwRTI6IDB4NzNERSxcbiAgICAweEUwRTM6IDB4NzRBMixcbiAgICAweEUwRTQ6IDB4NzQwNSxcbiAgICAweEUwRTU6IDB4NzQ2RixcbiAgICAweEUwRTY6IDB4NzQyNSxcbiAgICAweEUwRTc6IDB4NzNGOCxcbiAgICAweEUwRTg6IDB4NzQzMixcbiAgICAweEUwRTk6IDB4NzQzQSxcbiAgICAweEUwRUE6IDB4NzQ1NSxcbiAgICAweEUwRUI6IDB4NzQzRixcbiAgICAweEUwRUM6IDB4NzQ1RixcbiAgICAweEUwRUQ6IDB4NzQ1OSxcbiAgICAweEUwRUU6IDB4NzQ0MSxcbiAgICAweEUwRUY6IDB4NzQ1QyxcbiAgICAweEUwRjA6IDB4NzQ2OSxcbiAgICAweEUwRjE6IDB4NzQ3MCxcbiAgICAweEUwRjI6IDB4NzQ2MyxcbiAgICAweEUwRjM6IDB4NzQ2QSxcbiAgICAweEUwRjQ6IDB4NzQ3NixcbiAgICAweEUwRjU6IDB4NzQ3RSxcbiAgICAweEUwRjY6IDB4NzQ4QixcbiAgICAweEUwRjc6IDB4NzQ5RSxcbiAgICAweEUwRjg6IDB4NzRBNyxcbiAgICAweEUwRjk6IDB4NzRDQSxcbiAgICAweEUwRkE6IDB4NzRDRixcbiAgICAweEUwRkI6IDB4NzRENCxcbiAgICAweEUwRkM6IDB4NzNGMSxcbiAgICAweEUxNDA6IDB4NzRFMCxcbiAgICAweEUxNDE6IDB4NzRFMyxcbiAgICAweEUxNDI6IDB4NzRFNyxcbiAgICAweEUxNDM6IDB4NzRFOSxcbiAgICAweEUxNDQ6IDB4NzRFRSxcbiAgICAweEUxNDU6IDB4NzRGMixcbiAgICAweEUxNDY6IDB4NzRGMCxcbiAgICAweEUxNDc6IDB4NzRGMSxcbiAgICAweEUxNDg6IDB4NzRGOCxcbiAgICAweEUxNDk6IDB4NzRGNyxcbiAgICAweEUxNEE6IDB4NzUwNCxcbiAgICAweEUxNEI6IDB4NzUwMyxcbiAgICAweEUxNEM6IDB4NzUwNSxcbiAgICAweEUxNEQ6IDB4NzUwQyxcbiAgICAweEUxNEU6IDB4NzUwRSxcbiAgICAweEUxNEY6IDB4NzUwRCxcbiAgICAweEUxNTA6IDB4NzUxNSxcbiAgICAweEUxNTE6IDB4NzUxMyxcbiAgICAweEUxNTI6IDB4NzUxRSxcbiAgICAweEUxNTM6IDB4NzUyNixcbiAgICAweEUxNTQ6IDB4NzUyQyxcbiAgICAweEUxNTU6IDB4NzUzQyxcbiAgICAweEUxNTY6IDB4NzU0NCxcbiAgICAweEUxNTc6IDB4NzU0RCxcbiAgICAweEUxNTg6IDB4NzU0QSxcbiAgICAweEUxNTk6IDB4NzU0OSxcbiAgICAweEUxNUE6IDB4NzU1QixcbiAgICAweEUxNUI6IDB4NzU0NixcbiAgICAweEUxNUM6IDB4NzU1QSxcbiAgICAweEUxNUQ6IDB4NzU2OSxcbiAgICAweEUxNUU6IDB4NzU2NCxcbiAgICAweEUxNUY6IDB4NzU2NyxcbiAgICAweEUxNjA6IDB4NzU2QixcbiAgICAweEUxNjE6IDB4NzU2RCxcbiAgICAweEUxNjI6IDB4NzU3OCxcbiAgICAweEUxNjM6IDB4NzU3NixcbiAgICAweEUxNjQ6IDB4NzU4NixcbiAgICAweEUxNjU6IDB4NzU4NyxcbiAgICAweEUxNjY6IDB4NzU3NCxcbiAgICAweEUxNjc6IDB4NzU4QSxcbiAgICAweEUxNjg6IDB4NzU4OSxcbiAgICAweEUxNjk6IDB4NzU4MixcbiAgICAweEUxNkE6IDB4NzU5NCxcbiAgICAweEUxNkI6IDB4NzU5QSxcbiAgICAweEUxNkM6IDB4NzU5RCxcbiAgICAweEUxNkQ6IDB4NzVBNSxcbiAgICAweEUxNkU6IDB4NzVBMyxcbiAgICAweEUxNkY6IDB4NzVDMixcbiAgICAweEUxNzA6IDB4NzVCMyxcbiAgICAweEUxNzE6IDB4NzVDMyxcbiAgICAweEUxNzI6IDB4NzVCNSxcbiAgICAweEUxNzM6IDB4NzVCRCxcbiAgICAweEUxNzQ6IDB4NzVCOCxcbiAgICAweEUxNzU6IDB4NzVCQyxcbiAgICAweEUxNzY6IDB4NzVCMSxcbiAgICAweEUxNzc6IDB4NzVDRCxcbiAgICAweEUxNzg6IDB4NzVDQSxcbiAgICAweEUxNzk6IDB4NzVEMixcbiAgICAweEUxN0E6IDB4NzVEOSxcbiAgICAweEUxN0I6IDB4NzVFMyxcbiAgICAweEUxN0M6IDB4NzVERSxcbiAgICAweEUxN0Q6IDB4NzVGRSxcbiAgICAweEUxN0U6IDB4NzVGRixcbiAgICAweEUxODA6IDB4NzVGQyxcbiAgICAweEUxODE6IDB4NzYwMSxcbiAgICAweEUxODI6IDB4NzVGMCxcbiAgICAweEUxODM6IDB4NzVGQSxcbiAgICAweEUxODQ6IDB4NzVGMixcbiAgICAweEUxODU6IDB4NzVGMyxcbiAgICAweEUxODY6IDB4NzYwQixcbiAgICAweEUxODc6IDB4NzYwRCxcbiAgICAweEUxODg6IDB4NzYwOSxcbiAgICAweEUxODk6IDB4NzYxRixcbiAgICAweEUxOEE6IDB4NzYyNyxcbiAgICAweEUxOEI6IDB4NzYyMCxcbiAgICAweEUxOEM6IDB4NzYyMSxcbiAgICAweEUxOEQ6IDB4NzYyMixcbiAgICAweEUxOEU6IDB4NzYyNCxcbiAgICAweEUxOEY6IDB4NzYzNCxcbiAgICAweEUxOTA6IDB4NzYzMCxcbiAgICAweEUxOTE6IDB4NzYzQixcbiAgICAweEUxOTI6IDB4NzY0NyxcbiAgICAweEUxOTM6IDB4NzY0OCxcbiAgICAweEUxOTQ6IDB4NzY0NixcbiAgICAweEUxOTU6IDB4NzY1QyxcbiAgICAweEUxOTY6IDB4NzY1OCxcbiAgICAweEUxOTc6IDB4NzY2MSxcbiAgICAweEUxOTg6IDB4NzY2MixcbiAgICAweEUxOTk6IDB4NzY2OCxcbiAgICAweEUxOUE6IDB4NzY2OSxcbiAgICAweEUxOUI6IDB4NzY2QSxcbiAgICAweEUxOUM6IDB4NzY2NyxcbiAgICAweEUxOUQ6IDB4NzY2QyxcbiAgICAweEUxOUU6IDB4NzY3MCxcbiAgICAweEUxOUY6IDB4NzY3MixcbiAgICAweEUxQTA6IDB4NzY3NixcbiAgICAweEUxQTE6IDB4NzY3OCxcbiAgICAweEUxQTI6IDB4NzY3QyxcbiAgICAweEUxQTM6IDB4NzY4MCxcbiAgICAweEUxQTQ6IDB4NzY4MyxcbiAgICAweEUxQTU6IDB4NzY4OCxcbiAgICAweEUxQTY6IDB4NzY4QixcbiAgICAweEUxQTc6IDB4NzY4RSxcbiAgICAweEUxQTg6IDB4NzY5NixcbiAgICAweEUxQTk6IDB4NzY5MyxcbiAgICAweEUxQUE6IDB4NzY5OSxcbiAgICAweEUxQUI6IDB4NzY5QSxcbiAgICAweEUxQUM6IDB4NzZCMCxcbiAgICAweEUxQUQ6IDB4NzZCNCxcbiAgICAweEUxQUU6IDB4NzZCOCxcbiAgICAweEUxQUY6IDB4NzZCOSxcbiAgICAweEUxQjA6IDB4NzZCQSxcbiAgICAweEUxQjE6IDB4NzZDMixcbiAgICAweEUxQjI6IDB4NzZDRCxcbiAgICAweEUxQjM6IDB4NzZENixcbiAgICAweEUxQjQ6IDB4NzZEMixcbiAgICAweEUxQjU6IDB4NzZERSxcbiAgICAweEUxQjY6IDB4NzZFMSxcbiAgICAweEUxQjc6IDB4NzZFNSxcbiAgICAweEUxQjg6IDB4NzZFNyxcbiAgICAweEUxQjk6IDB4NzZFQSxcbiAgICAweEUxQkE6IDB4ODYyRixcbiAgICAweEUxQkI6IDB4NzZGQixcbiAgICAweEUxQkM6IDB4NzcwOCxcbiAgICAweEUxQkQ6IDB4NzcwNyxcbiAgICAweEUxQkU6IDB4NzcwNCxcbiAgICAweEUxQkY6IDB4NzcyOSxcbiAgICAweEUxQzA6IDB4NzcyNCxcbiAgICAweEUxQzE6IDB4NzcxRSxcbiAgICAweEUxQzI6IDB4NzcyNSxcbiAgICAweEUxQzM6IDB4NzcyNixcbiAgICAweEUxQzQ6IDB4NzcxQixcbiAgICAweEUxQzU6IDB4NzczNyxcbiAgICAweEUxQzY6IDB4NzczOCxcbiAgICAweEUxQzc6IDB4Nzc0NyxcbiAgICAweEUxQzg6IDB4Nzc1QSxcbiAgICAweEUxQzk6IDB4Nzc2OCxcbiAgICAweEUxQ0E6IDB4Nzc2QixcbiAgICAweEUxQ0I6IDB4Nzc1QixcbiAgICAweEUxQ0M6IDB4Nzc2NSxcbiAgICAweEUxQ0Q6IDB4Nzc3RixcbiAgICAweEUxQ0U6IDB4Nzc3RSxcbiAgICAweEUxQ0Y6IDB4Nzc3OSxcbiAgICAweEUxRDA6IDB4Nzc4RSxcbiAgICAweEUxRDE6IDB4Nzc4QixcbiAgICAweEUxRDI6IDB4Nzc5MSxcbiAgICAweEUxRDM6IDB4NzdBMCxcbiAgICAweEUxRDQ6IDB4Nzc5RSxcbiAgICAweEUxRDU6IDB4NzdCMCxcbiAgICAweEUxRDY6IDB4NzdCNixcbiAgICAweEUxRDc6IDB4NzdCOSxcbiAgICAweEUxRDg6IDB4NzdCRixcbiAgICAweEUxRDk6IDB4NzdCQyxcbiAgICAweEUxREE6IDB4NzdCRCxcbiAgICAweEUxREI6IDB4NzdCQixcbiAgICAweEUxREM6IDB4NzdDNyxcbiAgICAweEUxREQ6IDB4NzdDRCxcbiAgICAweEUxREU6IDB4NzdENyxcbiAgICAweEUxREY6IDB4NzdEQSxcbiAgICAweEUxRTA6IDB4NzdEQyxcbiAgICAweEUxRTE6IDB4NzdFMyxcbiAgICAweEUxRTI6IDB4NzdFRSxcbiAgICAweEUxRTM6IDB4NzdGQyxcbiAgICAweEUxRTQ6IDB4NzgwQyxcbiAgICAweEUxRTU6IDB4NzgxMixcbiAgICAweEUxRTY6IDB4NzkyNixcbiAgICAweEUxRTc6IDB4NzgyMCxcbiAgICAweEUxRTg6IDB4NzkyQSxcbiAgICAweEUxRTk6IDB4Nzg0NSxcbiAgICAweEUxRUE6IDB4Nzg4RSxcbiAgICAweEUxRUI6IDB4Nzg3NCxcbiAgICAweEUxRUM6IDB4Nzg4NixcbiAgICAweEUxRUQ6IDB4Nzg3QyxcbiAgICAweEUxRUU6IDB4Nzg5QSxcbiAgICAweEUxRUY6IDB4Nzg4QyxcbiAgICAweEUxRjA6IDB4NzhBMyxcbiAgICAweEUxRjE6IDB4NzhCNSxcbiAgICAweEUxRjI6IDB4NzhBQSxcbiAgICAweEUxRjM6IDB4NzhBRixcbiAgICAweEUxRjQ6IDB4NzhEMSxcbiAgICAweEUxRjU6IDB4NzhDNixcbiAgICAweEUxRjY6IDB4NzhDQixcbiAgICAweEUxRjc6IDB4NzhENCxcbiAgICAweEUxRjg6IDB4NzhCRSxcbiAgICAweEUxRjk6IDB4NzhCQyxcbiAgICAweEUxRkE6IDB4NzhDNSxcbiAgICAweEUxRkI6IDB4NzhDQSxcbiAgICAweEUxRkM6IDB4NzhFQyxcbiAgICAweEUyNDA6IDB4NzhFNyxcbiAgICAweEUyNDE6IDB4NzhEQSxcbiAgICAweEUyNDI6IDB4NzhGRCxcbiAgICAweEUyNDM6IDB4NzhGNCxcbiAgICAweEUyNDQ6IDB4NzkwNyxcbiAgICAweEUyNDU6IDB4NzkxMixcbiAgICAweEUyNDY6IDB4NzkxMSxcbiAgICAweEUyNDc6IDB4NzkxOSxcbiAgICAweEUyNDg6IDB4NzkyQyxcbiAgICAweEUyNDk6IDB4NzkyQixcbiAgICAweEUyNEE6IDB4Nzk0MCxcbiAgICAweEUyNEI6IDB4Nzk2MCxcbiAgICAweEUyNEM6IDB4Nzk1NyxcbiAgICAweEUyNEQ6IDB4Nzk1RixcbiAgICAweEUyNEU6IDB4Nzk1QSxcbiAgICAweEUyNEY6IDB4Nzk1NSxcbiAgICAweEUyNTA6IDB4Nzk1MyxcbiAgICAweEUyNTE6IDB4Nzk3QSxcbiAgICAweEUyNTI6IDB4Nzk3RixcbiAgICAweEUyNTM6IDB4Nzk4QSxcbiAgICAweEUyNTQ6IDB4Nzk5RCxcbiAgICAweEUyNTU6IDB4NzlBNyxcbiAgICAweEUyNTY6IDB4OUY0QixcbiAgICAweEUyNTc6IDB4NzlBQSxcbiAgICAweEUyNTg6IDB4NzlBRSxcbiAgICAweEUyNTk6IDB4NzlCMyxcbiAgICAweEUyNUE6IDB4NzlCOSxcbiAgICAweEUyNUI6IDB4NzlCQSxcbiAgICAweEUyNUM6IDB4NzlDOSxcbiAgICAweEUyNUQ6IDB4NzlENSxcbiAgICAweEUyNUU6IDB4NzlFNyxcbiAgICAweEUyNUY6IDB4NzlFQyxcbiAgICAweEUyNjA6IDB4NzlFMSxcbiAgICAweEUyNjE6IDB4NzlFMyxcbiAgICAweEUyNjI6IDB4N0EwOCxcbiAgICAweEUyNjM6IDB4N0EwRCxcbiAgICAweEUyNjQ6IDB4N0ExOCxcbiAgICAweEUyNjU6IDB4N0ExOSxcbiAgICAweEUyNjY6IDB4N0EyMCxcbiAgICAweEUyNjc6IDB4N0ExRixcbiAgICAweEUyNjg6IDB4Nzk4MCxcbiAgICAweEUyNjk6IDB4N0EzMSxcbiAgICAweEUyNkE6IDB4N0EzQixcbiAgICAweEUyNkI6IDB4N0EzRSxcbiAgICAweEUyNkM6IDB4N0EzNyxcbiAgICAweEUyNkQ6IDB4N0E0MyxcbiAgICAweEUyNkU6IDB4N0E1NyxcbiAgICAweEUyNkY6IDB4N0E0OSxcbiAgICAweEUyNzA6IDB4N0E2MSxcbiAgICAweEUyNzE6IDB4N0E2MixcbiAgICAweEUyNzI6IDB4N0E2OSxcbiAgICAweEUyNzM6IDB4OUY5RCxcbiAgICAweEUyNzQ6IDB4N0E3MCxcbiAgICAweEUyNzU6IDB4N0E3OSxcbiAgICAweEUyNzY6IDB4N0E3RCxcbiAgICAweEUyNzc6IDB4N0E4OCxcbiAgICAweEUyNzg6IDB4N0E5NyxcbiAgICAweEUyNzk6IDB4N0E5NSxcbiAgICAweEUyN0E6IDB4N0E5OCxcbiAgICAweEUyN0I6IDB4N0E5NixcbiAgICAweEUyN0M6IDB4N0FBOSxcbiAgICAweEUyN0Q6IDB4N0FDOCxcbiAgICAweEUyN0U6IDB4N0FCMCxcbiAgICAweEUyODA6IDB4N0FCNixcbiAgICAweEUyODE6IDB4N0FDNSxcbiAgICAweEUyODI6IDB4N0FDNCxcbiAgICAweEUyODM6IDB4N0FCRixcbiAgICAweEUyODQ6IDB4OTA4MyxcbiAgICAweEUyODU6IDB4N0FDNyxcbiAgICAweEUyODY6IDB4N0FDQSxcbiAgICAweEUyODc6IDB4N0FDRCxcbiAgICAweEUyODg6IDB4N0FDRixcbiAgICAweEUyODk6IDB4N0FENSxcbiAgICAweEUyOEE6IDB4N0FEMyxcbiAgICAweEUyOEI6IDB4N0FEOSxcbiAgICAweEUyOEM6IDB4N0FEQSxcbiAgICAweEUyOEQ6IDB4N0FERCxcbiAgICAweEUyOEU6IDB4N0FFMSxcbiAgICAweEUyOEY6IDB4N0FFMixcbiAgICAweEUyOTA6IDB4N0FFNixcbiAgICAweEUyOTE6IDB4N0FFRCxcbiAgICAweEUyOTI6IDB4N0FGMCxcbiAgICAweEUyOTM6IDB4N0IwMixcbiAgICAweEUyOTQ6IDB4N0IwRixcbiAgICAweEUyOTU6IDB4N0IwQSxcbiAgICAweEUyOTY6IDB4N0IwNixcbiAgICAweEUyOTc6IDB4N0IzMyxcbiAgICAweEUyOTg6IDB4N0IxOCxcbiAgICAweEUyOTk6IDB4N0IxOSxcbiAgICAweEUyOUE6IDB4N0IxRSxcbiAgICAweEUyOUI6IDB4N0IzNSxcbiAgICAweEUyOUM6IDB4N0IyOCxcbiAgICAweEUyOUQ6IDB4N0IzNixcbiAgICAweEUyOUU6IDB4N0I1MCxcbiAgICAweEUyOUY6IDB4N0I3QSxcbiAgICAweEUyQTA6IDB4N0IwNCxcbiAgICAweEUyQTE6IDB4N0I0RCxcbiAgICAweEUyQTI6IDB4N0IwQixcbiAgICAweEUyQTM6IDB4N0I0QyxcbiAgICAweEUyQTQ6IDB4N0I0NSxcbiAgICAweEUyQTU6IDB4N0I3NSxcbiAgICAweEUyQTY6IDB4N0I2NSxcbiAgICAweEUyQTc6IDB4N0I3NCxcbiAgICAweEUyQTg6IDB4N0I2NyxcbiAgICAweEUyQTk6IDB4N0I3MCxcbiAgICAweEUyQUE6IDB4N0I3MSxcbiAgICAweEUyQUI6IDB4N0I2QyxcbiAgICAweEUyQUM6IDB4N0I2RSxcbiAgICAweEUyQUQ6IDB4N0I5RCxcbiAgICAweEUyQUU6IDB4N0I5OCxcbiAgICAweEUyQUY6IDB4N0I5RixcbiAgICAweEUyQjA6IDB4N0I4RCxcbiAgICAweEUyQjE6IDB4N0I5QyxcbiAgICAweEUyQjI6IDB4N0I5QSxcbiAgICAweEUyQjM6IDB4N0I4QixcbiAgICAweEUyQjQ6IDB4N0I5MixcbiAgICAweEUyQjU6IDB4N0I4RixcbiAgICAweEUyQjY6IDB4N0I1RCxcbiAgICAweEUyQjc6IDB4N0I5OSxcbiAgICAweEUyQjg6IDB4N0JDQixcbiAgICAweEUyQjk6IDB4N0JDMSxcbiAgICAweEUyQkE6IDB4N0JDQyxcbiAgICAweEUyQkI6IDB4N0JDRixcbiAgICAweEUyQkM6IDB4N0JCNCxcbiAgICAweEUyQkQ6IDB4N0JDNixcbiAgICAweEUyQkU6IDB4N0JERCxcbiAgICAweEUyQkY6IDB4N0JFOSxcbiAgICAweEUyQzA6IDB4N0MxMSxcbiAgICAweEUyQzE6IDB4N0MxNCxcbiAgICAweEUyQzI6IDB4N0JFNixcbiAgICAweEUyQzM6IDB4N0JFNSxcbiAgICAweEUyQzQ6IDB4N0M2MCxcbiAgICAweEUyQzU6IDB4N0MwMCxcbiAgICAweEUyQzY6IDB4N0MwNyxcbiAgICAweEUyQzc6IDB4N0MxMyxcbiAgICAweEUyQzg6IDB4N0JGMyxcbiAgICAweEUyQzk6IDB4N0JGNyxcbiAgICAweEUyQ0E6IDB4N0MxNyxcbiAgICAweEUyQ0I6IDB4N0MwRCxcbiAgICAweEUyQ0M6IDB4N0JGNixcbiAgICAweEUyQ0Q6IDB4N0MyMyxcbiAgICAweEUyQ0U6IDB4N0MyNyxcbiAgICAweEUyQ0Y6IDB4N0MyQSxcbiAgICAweEUyRDA6IDB4N0MxRixcbiAgICAweEUyRDE6IDB4N0MzNyxcbiAgICAweEUyRDI6IDB4N0MyQixcbiAgICAweEUyRDM6IDB4N0MzRCxcbiAgICAweEUyRDQ6IDB4N0M0QyxcbiAgICAweEUyRDU6IDB4N0M0MyxcbiAgICAweEUyRDY6IDB4N0M1NCxcbiAgICAweEUyRDc6IDB4N0M0RixcbiAgICAweEUyRDg6IDB4N0M0MCxcbiAgICAweEUyRDk6IDB4N0M1MCxcbiAgICAweEUyREE6IDB4N0M1OCxcbiAgICAweEUyREI6IDB4N0M1RixcbiAgICAweEUyREM6IDB4N0M2NCxcbiAgICAweEUyREQ6IDB4N0M1NixcbiAgICAweEUyREU6IDB4N0M2NSxcbiAgICAweEUyREY6IDB4N0M2QyxcbiAgICAweEUyRTA6IDB4N0M3NSxcbiAgICAweEUyRTE6IDB4N0M4MyxcbiAgICAweEUyRTI6IDB4N0M5MCxcbiAgICAweEUyRTM6IDB4N0NBNCxcbiAgICAweEUyRTQ6IDB4N0NBRCxcbiAgICAweEUyRTU6IDB4N0NBMixcbiAgICAweEUyRTY6IDB4N0NBQixcbiAgICAweEUyRTc6IDB4N0NBMSxcbiAgICAweEUyRTg6IDB4N0NBOCxcbiAgICAweEUyRTk6IDB4N0NCMyxcbiAgICAweEUyRUE6IDB4N0NCMixcbiAgICAweEUyRUI6IDB4N0NCMSxcbiAgICAweEUyRUM6IDB4N0NBRSxcbiAgICAweEUyRUQ6IDB4N0NCOSxcbiAgICAweEUyRUU6IDB4N0NCRCxcbiAgICAweEUyRUY6IDB4N0NDMCxcbiAgICAweEUyRjA6IDB4N0NDNSxcbiAgICAweEUyRjE6IDB4N0NDMixcbiAgICAweEUyRjI6IDB4N0NEOCxcbiAgICAweEUyRjM6IDB4N0NEMixcbiAgICAweEUyRjQ6IDB4N0NEQyxcbiAgICAweEUyRjU6IDB4N0NFMixcbiAgICAweEUyRjY6IDB4OUIzQixcbiAgICAweEUyRjc6IDB4N0NFRixcbiAgICAweEUyRjg6IDB4N0NGMixcbiAgICAweEUyRjk6IDB4N0NGNCxcbiAgICAweEUyRkE6IDB4N0NGNixcbiAgICAweEUyRkI6IDB4N0NGQSxcbiAgICAweEUyRkM6IDB4N0QwNixcbiAgICAweEUzNDA6IDB4N0QwMixcbiAgICAweEUzNDE6IDB4N0QxQyxcbiAgICAweEUzNDI6IDB4N0QxNSxcbiAgICAweEUzNDM6IDB4N0QwQSxcbiAgICAweEUzNDQ6IDB4N0Q0NSxcbiAgICAweEUzNDU6IDB4N0Q0QixcbiAgICAweEUzNDY6IDB4N0QyRSxcbiAgICAweEUzNDc6IDB4N0QzMixcbiAgICAweEUzNDg6IDB4N0QzRixcbiAgICAweEUzNDk6IDB4N0QzNSxcbiAgICAweEUzNEE6IDB4N0Q0NixcbiAgICAweEUzNEI6IDB4N0Q3MyxcbiAgICAweEUzNEM6IDB4N0Q1NixcbiAgICAweEUzNEQ6IDB4N0Q0RSxcbiAgICAweEUzNEU6IDB4N0Q3MixcbiAgICAweEUzNEY6IDB4N0Q2OCxcbiAgICAweEUzNTA6IDB4N0Q2RSxcbiAgICAweEUzNTE6IDB4N0Q0RixcbiAgICAweEUzNTI6IDB4N0Q2MyxcbiAgICAweEUzNTM6IDB4N0Q5MyxcbiAgICAweEUzNTQ6IDB4N0Q4OSxcbiAgICAweEUzNTU6IDB4N0Q1QixcbiAgICAweEUzNTY6IDB4N0Q4RixcbiAgICAweEUzNTc6IDB4N0Q3RCxcbiAgICAweEUzNTg6IDB4N0Q5QixcbiAgICAweEUzNTk6IDB4N0RCQSxcbiAgICAweEUzNUE6IDB4N0RBRSxcbiAgICAweEUzNUI6IDB4N0RBMyxcbiAgICAweEUzNUM6IDB4N0RCNSxcbiAgICAweEUzNUQ6IDB4N0RDNyxcbiAgICAweEUzNUU6IDB4N0RCRCxcbiAgICAweEUzNUY6IDB4N0RBQixcbiAgICAweEUzNjA6IDB4N0UzRCxcbiAgICAweEUzNjE6IDB4N0RBMixcbiAgICAweEUzNjI6IDB4N0RBRixcbiAgICAweEUzNjM6IDB4N0REQyxcbiAgICAweEUzNjQ6IDB4N0RCOCxcbiAgICAweEUzNjU6IDB4N0Q5RixcbiAgICAweEUzNjY6IDB4N0RCMCxcbiAgICAweEUzNjc6IDB4N0REOCxcbiAgICAweEUzNjg6IDB4N0RERCxcbiAgICAweEUzNjk6IDB4N0RFNCxcbiAgICAweEUzNkE6IDB4N0RERSxcbiAgICAweEUzNkI6IDB4N0RGQixcbiAgICAweEUzNkM6IDB4N0RGMixcbiAgICAweEUzNkQ6IDB4N0RFMSxcbiAgICAweEUzNkU6IDB4N0UwNSxcbiAgICAweEUzNkY6IDB4N0UwQSxcbiAgICAweEUzNzA6IDB4N0UyMyxcbiAgICAweEUzNzE6IDB4N0UyMSxcbiAgICAweEUzNzI6IDB4N0UxMixcbiAgICAweEUzNzM6IDB4N0UzMSxcbiAgICAweEUzNzQ6IDB4N0UxRixcbiAgICAweEUzNzU6IDB4N0UwOSxcbiAgICAweEUzNzY6IDB4N0UwQixcbiAgICAweEUzNzc6IDB4N0UyMixcbiAgICAweEUzNzg6IDB4N0U0NixcbiAgICAweEUzNzk6IDB4N0U2NixcbiAgICAweEUzN0E6IDB4N0UzQixcbiAgICAweEUzN0I6IDB4N0UzNSxcbiAgICAweEUzN0M6IDB4N0UzOSxcbiAgICAweEUzN0Q6IDB4N0U0MyxcbiAgICAweEUzN0U6IDB4N0UzNyxcbiAgICAweEUzODA6IDB4N0UzMixcbiAgICAweEUzODE6IDB4N0UzQSxcbiAgICAweEUzODI6IDB4N0U2NyxcbiAgICAweEUzODM6IDB4N0U1RCxcbiAgICAweEUzODQ6IDB4N0U1NixcbiAgICAweEUzODU6IDB4N0U1RSxcbiAgICAweEUzODY6IDB4N0U1OSxcbiAgICAweEUzODc6IDB4N0U1QSxcbiAgICAweEUzODg6IDB4N0U3OSxcbiAgICAweEUzODk6IDB4N0U2QSxcbiAgICAweEUzOEE6IDB4N0U2OSxcbiAgICAweEUzOEI6IDB4N0U3QyxcbiAgICAweEUzOEM6IDB4N0U3QixcbiAgICAweEUzOEQ6IDB4N0U4MyxcbiAgICAweEUzOEU6IDB4N0RENSxcbiAgICAweEUzOEY6IDB4N0U3RCxcbiAgICAweEUzOTA6IDB4OEZBRSxcbiAgICAweEUzOTE6IDB4N0U3RixcbiAgICAweEUzOTI6IDB4N0U4OCxcbiAgICAweEUzOTM6IDB4N0U4OSxcbiAgICAweEUzOTQ6IDB4N0U4QyxcbiAgICAweEUzOTU6IDB4N0U5MixcbiAgICAweEUzOTY6IDB4N0U5MCxcbiAgICAweEUzOTc6IDB4N0U5MyxcbiAgICAweEUzOTg6IDB4N0U5NCxcbiAgICAweEUzOTk6IDB4N0U5NixcbiAgICAweEUzOUE6IDB4N0U4RSxcbiAgICAweEUzOUI6IDB4N0U5QixcbiAgICAweEUzOUM6IDB4N0U5QyxcbiAgICAweEUzOUQ6IDB4N0YzOCxcbiAgICAweEUzOUU6IDB4N0YzQSxcbiAgICAweEUzOUY6IDB4N0Y0NSxcbiAgICAweEUzQTA6IDB4N0Y0QyxcbiAgICAweEUzQTE6IDB4N0Y0RCxcbiAgICAweEUzQTI6IDB4N0Y0RSxcbiAgICAweEUzQTM6IDB4N0Y1MCxcbiAgICAweEUzQTQ6IDB4N0Y1MSxcbiAgICAweEUzQTU6IDB4N0Y1NSxcbiAgICAweEUzQTY6IDB4N0Y1NCxcbiAgICAweEUzQTc6IDB4N0Y1OCxcbiAgICAweEUzQTg6IDB4N0Y1RixcbiAgICAweEUzQTk6IDB4N0Y2MCxcbiAgICAweEUzQUE6IDB4N0Y2OCxcbiAgICAweEUzQUI6IDB4N0Y2OSxcbiAgICAweEUzQUM6IDB4N0Y2NyxcbiAgICAweEUzQUQ6IDB4N0Y3OCxcbiAgICAweEUzQUU6IDB4N0Y4MixcbiAgICAweEUzQUY6IDB4N0Y4NixcbiAgICAweEUzQjA6IDB4N0Y4MyxcbiAgICAweEUzQjE6IDB4N0Y4OCxcbiAgICAweEUzQjI6IDB4N0Y4NyxcbiAgICAweEUzQjM6IDB4N0Y4QyxcbiAgICAweEUzQjQ6IDB4N0Y5NCxcbiAgICAweEUzQjU6IDB4N0Y5RSxcbiAgICAweEUzQjY6IDB4N0Y5RCxcbiAgICAweEUzQjc6IDB4N0Y5QSxcbiAgICAweEUzQjg6IDB4N0ZBMyxcbiAgICAweEUzQjk6IDB4N0ZBRixcbiAgICAweEUzQkE6IDB4N0ZCMixcbiAgICAweEUzQkI6IDB4N0ZCOSxcbiAgICAweEUzQkM6IDB4N0ZBRSxcbiAgICAweEUzQkQ6IDB4N0ZCNixcbiAgICAweEUzQkU6IDB4N0ZCOCxcbiAgICAweEUzQkY6IDB4OEI3MSxcbiAgICAweEUzQzA6IDB4N0ZDNSxcbiAgICAweEUzQzE6IDB4N0ZDNixcbiAgICAweEUzQzI6IDB4N0ZDQSxcbiAgICAweEUzQzM6IDB4N0ZENSxcbiAgICAweEUzQzQ6IDB4N0ZENCxcbiAgICAweEUzQzU6IDB4N0ZFMSxcbiAgICAweEUzQzY6IDB4N0ZFNixcbiAgICAweEUzQzc6IDB4N0ZFOSxcbiAgICAweEUzQzg6IDB4N0ZGMyxcbiAgICAweEUzQzk6IDB4N0ZGOSxcbiAgICAweEUzQ0E6IDB4OThEQyxcbiAgICAweEUzQ0I6IDB4ODAwNixcbiAgICAweEUzQ0M6IDB4ODAwNCxcbiAgICAweEUzQ0Q6IDB4ODAwQixcbiAgICAweEUzQ0U6IDB4ODAxMixcbiAgICAweEUzQ0Y6IDB4ODAxOCxcbiAgICAweEUzRDA6IDB4ODAxOSxcbiAgICAweEUzRDE6IDB4ODAxQyxcbiAgICAweEUzRDI6IDB4ODAyMSxcbiAgICAweEUzRDM6IDB4ODAyOCxcbiAgICAweEUzRDQ6IDB4ODAzRixcbiAgICAweEUzRDU6IDB4ODAzQixcbiAgICAweEUzRDY6IDB4ODA0QSxcbiAgICAweEUzRDc6IDB4ODA0NixcbiAgICAweEUzRDg6IDB4ODA1MixcbiAgICAweEUzRDk6IDB4ODA1OCxcbiAgICAweEUzREE6IDB4ODA1QSxcbiAgICAweEUzREI6IDB4ODA1RixcbiAgICAweEUzREM6IDB4ODA2MixcbiAgICAweEUzREQ6IDB4ODA2OCxcbiAgICAweEUzREU6IDB4ODA3MyxcbiAgICAweEUzREY6IDB4ODA3MixcbiAgICAweEUzRTA6IDB4ODA3MCxcbiAgICAweEUzRTE6IDB4ODA3NixcbiAgICAweEUzRTI6IDB4ODA3OSxcbiAgICAweEUzRTM6IDB4ODA3RCxcbiAgICAweEUzRTQ6IDB4ODA3RixcbiAgICAweEUzRTU6IDB4ODA4NCxcbiAgICAweEUzRTY6IDB4ODA4NixcbiAgICAweEUzRTc6IDB4ODA4NSxcbiAgICAweEUzRTg6IDB4ODA5QixcbiAgICAweEUzRTk6IDB4ODA5MyxcbiAgICAweEUzRUE6IDB4ODA5QSxcbiAgICAweEUzRUI6IDB4ODBBRCxcbiAgICAweEUzRUM6IDB4NTE5MCxcbiAgICAweEUzRUQ6IDB4ODBBQyxcbiAgICAweEUzRUU6IDB4ODBEQixcbiAgICAweEUzRUY6IDB4ODBFNSxcbiAgICAweEUzRjA6IDB4ODBEOSxcbiAgICAweEUzRjE6IDB4ODBERCxcbiAgICAweEUzRjI6IDB4ODBDNCxcbiAgICAweEUzRjM6IDB4ODBEQSxcbiAgICAweEUzRjQ6IDB4ODBENixcbiAgICAweEUzRjU6IDB4ODEwOSxcbiAgICAweEUzRjY6IDB4ODBFRixcbiAgICAweEUzRjc6IDB4ODBGMSxcbiAgICAweEUzRjg6IDB4ODExQixcbiAgICAweEUzRjk6IDB4ODEyOSxcbiAgICAweEUzRkE6IDB4ODEyMyxcbiAgICAweEUzRkI6IDB4ODEyRixcbiAgICAweEUzRkM6IDB4ODE0QixcbiAgICAweEU0NDA6IDB4OTY4QixcbiAgICAweEU0NDE6IDB4ODE0NixcbiAgICAweEU0NDI6IDB4ODEzRSxcbiAgICAweEU0NDM6IDB4ODE1MyxcbiAgICAweEU0NDQ6IDB4ODE1MSxcbiAgICAweEU0NDU6IDB4ODBGQyxcbiAgICAweEU0NDY6IDB4ODE3MSxcbiAgICAweEU0NDc6IDB4ODE2RSxcbiAgICAweEU0NDg6IDB4ODE2NSxcbiAgICAweEU0NDk6IDB4ODE2NixcbiAgICAweEU0NEE6IDB4ODE3NCxcbiAgICAweEU0NEI6IDB4ODE4MyxcbiAgICAweEU0NEM6IDB4ODE4OCxcbiAgICAweEU0NEQ6IDB4ODE4QSxcbiAgICAweEU0NEU6IDB4ODE4MCxcbiAgICAweEU0NEY6IDB4ODE4MixcbiAgICAweEU0NTA6IDB4ODFBMCxcbiAgICAweEU0NTE6IDB4ODE5NSxcbiAgICAweEU0NTI6IDB4ODFBNCxcbiAgICAweEU0NTM6IDB4ODFBMyxcbiAgICAweEU0NTQ6IDB4ODE1RixcbiAgICAweEU0NTU6IDB4ODE5MyxcbiAgICAweEU0NTY6IDB4ODFBOSxcbiAgICAweEU0NTc6IDB4ODFCMCxcbiAgICAweEU0NTg6IDB4ODFCNSxcbiAgICAweEU0NTk6IDB4ODFCRSxcbiAgICAweEU0NUE6IDB4ODFCOCxcbiAgICAweEU0NUI6IDB4ODFCRCxcbiAgICAweEU0NUM6IDB4ODFDMCxcbiAgICAweEU0NUQ6IDB4ODFDMixcbiAgICAweEU0NUU6IDB4ODFCQSxcbiAgICAweEU0NUY6IDB4ODFDOSxcbiAgICAweEU0NjA6IDB4ODFDRCxcbiAgICAweEU0NjE6IDB4ODFEMSxcbiAgICAweEU0NjI6IDB4ODFEOSxcbiAgICAweEU0NjM6IDB4ODFEOCxcbiAgICAweEU0NjQ6IDB4ODFDOCxcbiAgICAweEU0NjU6IDB4ODFEQSxcbiAgICAweEU0NjY6IDB4ODFERixcbiAgICAweEU0Njc6IDB4ODFFMCxcbiAgICAweEU0Njg6IDB4ODFFNyxcbiAgICAweEU0Njk6IDB4ODFGQSxcbiAgICAweEU0NkE6IDB4ODFGQixcbiAgICAweEU0NkI6IDB4ODFGRSxcbiAgICAweEU0NkM6IDB4ODIwMSxcbiAgICAweEU0NkQ6IDB4ODIwMixcbiAgICAweEU0NkU6IDB4ODIwNSxcbiAgICAweEU0NkY6IDB4ODIwNyxcbiAgICAweEU0NzA6IDB4ODIwQSxcbiAgICAweEU0NzE6IDB4ODIwRCxcbiAgICAweEU0NzI6IDB4ODIxMCxcbiAgICAweEU0NzM6IDB4ODIxNixcbiAgICAweEU0NzQ6IDB4ODIyOSxcbiAgICAweEU0NzU6IDB4ODIyQixcbiAgICAweEU0NzY6IDB4ODIzOCxcbiAgICAweEU0Nzc6IDB4ODIzMyxcbiAgICAweEU0Nzg6IDB4ODI0MCxcbiAgICAweEU0Nzk6IDB4ODI1OSxcbiAgICAweEU0N0E6IDB4ODI1OCxcbiAgICAweEU0N0I6IDB4ODI1RCxcbiAgICAweEU0N0M6IDB4ODI1QSxcbiAgICAweEU0N0Q6IDB4ODI1RixcbiAgICAweEU0N0U6IDB4ODI2NCxcbiAgICAweEU0ODA6IDB4ODI2MixcbiAgICAweEU0ODE6IDB4ODI2OCxcbiAgICAweEU0ODI6IDB4ODI2QSxcbiAgICAweEU0ODM6IDB4ODI2QixcbiAgICAweEU0ODQ6IDB4ODIyRSxcbiAgICAweEU0ODU6IDB4ODI3MSxcbiAgICAweEU0ODY6IDB4ODI3NyxcbiAgICAweEU0ODc6IDB4ODI3OCxcbiAgICAweEU0ODg6IDB4ODI3RSxcbiAgICAweEU0ODk6IDB4ODI4RCxcbiAgICAweEU0OEE6IDB4ODI5MixcbiAgICAweEU0OEI6IDB4ODJBQixcbiAgICAweEU0OEM6IDB4ODI5RixcbiAgICAweEU0OEQ6IDB4ODJCQixcbiAgICAweEU0OEU6IDB4ODJBQyxcbiAgICAweEU0OEY6IDB4ODJFMSxcbiAgICAweEU0OTA6IDB4ODJFMyxcbiAgICAweEU0OTE6IDB4ODJERixcbiAgICAweEU0OTI6IDB4ODJEMixcbiAgICAweEU0OTM6IDB4ODJGNCxcbiAgICAweEU0OTQ6IDB4ODJGMyxcbiAgICAweEU0OTU6IDB4ODJGQSxcbiAgICAweEU0OTY6IDB4ODM5MyxcbiAgICAweEU0OTc6IDB4ODMwMyxcbiAgICAweEU0OTg6IDB4ODJGQixcbiAgICAweEU0OTk6IDB4ODJGOSxcbiAgICAweEU0OUE6IDB4ODJERSxcbiAgICAweEU0OUI6IDB4ODMwNixcbiAgICAweEU0OUM6IDB4ODJEQyxcbiAgICAweEU0OUQ6IDB4ODMwOSxcbiAgICAweEU0OUU6IDB4ODJEOSxcbiAgICAweEU0OUY6IDB4ODMzNSxcbiAgICAweEU0QTA6IDB4ODMzNCxcbiAgICAweEU0QTE6IDB4ODMxNixcbiAgICAweEU0QTI6IDB4ODMzMixcbiAgICAweEU0QTM6IDB4ODMzMSxcbiAgICAweEU0QTQ6IDB4ODM0MCxcbiAgICAweEU0QTU6IDB4ODMzOSxcbiAgICAweEU0QTY6IDB4ODM1MCxcbiAgICAweEU0QTc6IDB4ODM0NSxcbiAgICAweEU0QTg6IDB4ODMyRixcbiAgICAweEU0QTk6IDB4ODMyQixcbiAgICAweEU0QUE6IDB4ODMxNyxcbiAgICAweEU0QUI6IDB4ODMxOCxcbiAgICAweEU0QUM6IDB4ODM4NSxcbiAgICAweEU0QUQ6IDB4ODM5QSxcbiAgICAweEU0QUU6IDB4ODNBQSxcbiAgICAweEU0QUY6IDB4ODM5RixcbiAgICAweEU0QjA6IDB4ODNBMixcbiAgICAweEU0QjE6IDB4ODM5NixcbiAgICAweEU0QjI6IDB4ODMyMyxcbiAgICAweEU0QjM6IDB4ODM4RSxcbiAgICAweEU0QjQ6IDB4ODM4NyxcbiAgICAweEU0QjU6IDB4ODM4QSxcbiAgICAweEU0QjY6IDB4ODM3QyxcbiAgICAweEU0Qjc6IDB4ODNCNSxcbiAgICAweEU0Qjg6IDB4ODM3MyxcbiAgICAweEU0Qjk6IDB4ODM3NSxcbiAgICAweEU0QkE6IDB4ODNBMCxcbiAgICAweEU0QkI6IDB4ODM4OSxcbiAgICAweEU0QkM6IDB4ODNBOCxcbiAgICAweEU0QkQ6IDB4ODNGNCxcbiAgICAweEU0QkU6IDB4ODQxMyxcbiAgICAweEU0QkY6IDB4ODNFQixcbiAgICAweEU0QzA6IDB4ODNDRSxcbiAgICAweEU0QzE6IDB4ODNGRCxcbiAgICAweEU0QzI6IDB4ODQwMyxcbiAgICAweEU0QzM6IDB4ODNEOCxcbiAgICAweEU0QzQ6IDB4ODQwQixcbiAgICAweEU0QzU6IDB4ODNDMSxcbiAgICAweEU0QzY6IDB4ODNGNyxcbiAgICAweEU0Qzc6IDB4ODQwNyxcbiAgICAweEU0Qzg6IDB4ODNFMCxcbiAgICAweEU0Qzk6IDB4ODNGMixcbiAgICAweEU0Q0E6IDB4ODQwRCxcbiAgICAweEU0Q0I6IDB4ODQyMixcbiAgICAweEU0Q0M6IDB4ODQyMCxcbiAgICAweEU0Q0Q6IDB4ODNCRCxcbiAgICAweEU0Q0U6IDB4ODQzOCxcbiAgICAweEU0Q0Y6IDB4ODUwNixcbiAgICAweEU0RDA6IDB4ODNGQixcbiAgICAweEU0RDE6IDB4ODQ2RCxcbiAgICAweEU0RDI6IDB4ODQyQSxcbiAgICAweEU0RDM6IDB4ODQzQyxcbiAgICAweEU0RDQ6IDB4ODU1QSxcbiAgICAweEU0RDU6IDB4ODQ4NCxcbiAgICAweEU0RDY6IDB4ODQ3NyxcbiAgICAweEU0RDc6IDB4ODQ2QixcbiAgICAweEU0RDg6IDB4ODRBRCxcbiAgICAweEU0RDk6IDB4ODQ2RSxcbiAgICAweEU0REE6IDB4ODQ4MixcbiAgICAweEU0REI6IDB4ODQ2OSxcbiAgICAweEU0REM6IDB4ODQ0NixcbiAgICAweEU0REQ6IDB4ODQyQyxcbiAgICAweEU0REU6IDB4ODQ2RixcbiAgICAweEU0REY6IDB4ODQ3OSxcbiAgICAweEU0RTA6IDB4ODQzNSxcbiAgICAweEU0RTE6IDB4ODRDQSxcbiAgICAweEU0RTI6IDB4ODQ2MixcbiAgICAweEU0RTM6IDB4ODRCOSxcbiAgICAweEU0RTQ6IDB4ODRCRixcbiAgICAweEU0RTU6IDB4ODQ5RixcbiAgICAweEU0RTY6IDB4ODREOSxcbiAgICAweEU0RTc6IDB4ODRDRCxcbiAgICAweEU0RTg6IDB4ODRCQixcbiAgICAweEU0RTk6IDB4ODREQSxcbiAgICAweEU0RUE6IDB4ODREMCxcbiAgICAweEU0RUI6IDB4ODRDMSxcbiAgICAweEU0RUM6IDB4ODRDNixcbiAgICAweEU0RUQ6IDB4ODRENixcbiAgICAweEU0RUU6IDB4ODRBMSxcbiAgICAweEU0RUY6IDB4ODUyMSxcbiAgICAweEU0RjA6IDB4ODRGRixcbiAgICAweEU0RjE6IDB4ODRGNCxcbiAgICAweEU0RjI6IDB4ODUxNyxcbiAgICAweEU0RjM6IDB4ODUxOCxcbiAgICAweEU0RjQ6IDB4ODUyQyxcbiAgICAweEU0RjU6IDB4ODUxRixcbiAgICAweEU0RjY6IDB4ODUxNSxcbiAgICAweEU0Rjc6IDB4ODUxNCxcbiAgICAweEU0Rjg6IDB4ODRGQyxcbiAgICAweEU0Rjk6IDB4ODU0MCxcbiAgICAweEU0RkE6IDB4ODU2MyxcbiAgICAweEU0RkI6IDB4ODU1OCxcbiAgICAweEU0RkM6IDB4ODU0OCxcbiAgICAweEU1NDA6IDB4ODU0MSxcbiAgICAweEU1NDE6IDB4ODYwMixcbiAgICAweEU1NDI6IDB4ODU0QixcbiAgICAweEU1NDM6IDB4ODU1NSxcbiAgICAweEU1NDQ6IDB4ODU4MCxcbiAgICAweEU1NDU6IDB4ODVBNCxcbiAgICAweEU1NDY6IDB4ODU4OCxcbiAgICAweEU1NDc6IDB4ODU5MSxcbiAgICAweEU1NDg6IDB4ODU4QSxcbiAgICAweEU1NDk6IDB4ODVBOCxcbiAgICAweEU1NEE6IDB4ODU2RCxcbiAgICAweEU1NEI6IDB4ODU5NCxcbiAgICAweEU1NEM6IDB4ODU5QixcbiAgICAweEU1NEQ6IDB4ODVFQSxcbiAgICAweEU1NEU6IDB4ODU4NyxcbiAgICAweEU1NEY6IDB4ODU5QyxcbiAgICAweEU1NTA6IDB4ODU3NyxcbiAgICAweEU1NTE6IDB4ODU3RSxcbiAgICAweEU1NTI6IDB4ODU5MCxcbiAgICAweEU1NTM6IDB4ODVDOSxcbiAgICAweEU1NTQ6IDB4ODVCQSxcbiAgICAweEU1NTU6IDB4ODVDRixcbiAgICAweEU1NTY6IDB4ODVCOSxcbiAgICAweEU1NTc6IDB4ODVEMCxcbiAgICAweEU1NTg6IDB4ODVENSxcbiAgICAweEU1NTk6IDB4ODVERCxcbiAgICAweEU1NUE6IDB4ODVFNSxcbiAgICAweEU1NUI6IDB4ODVEQyxcbiAgICAweEU1NUM6IDB4ODVGOSxcbiAgICAweEU1NUQ6IDB4ODYwQSxcbiAgICAweEU1NUU6IDB4ODYxMyxcbiAgICAweEU1NUY6IDB4ODYwQixcbiAgICAweEU1NjA6IDB4ODVGRSxcbiAgICAweEU1NjE6IDB4ODVGQSxcbiAgICAweEU1NjI6IDB4ODYwNixcbiAgICAweEU1NjM6IDB4ODYyMixcbiAgICAweEU1NjQ6IDB4ODYxQSxcbiAgICAweEU1NjU6IDB4ODYzMCxcbiAgICAweEU1NjY6IDB4ODYzRixcbiAgICAweEU1Njc6IDB4ODY0RCxcbiAgICAweEU1Njg6IDB4NEU1NSxcbiAgICAweEU1Njk6IDB4ODY1NCxcbiAgICAweEU1NkE6IDB4ODY1RixcbiAgICAweEU1NkI6IDB4ODY2NyxcbiAgICAweEU1NkM6IDB4ODY3MSxcbiAgICAweEU1NkQ6IDB4ODY5MyxcbiAgICAweEU1NkU6IDB4ODZBMyxcbiAgICAweEU1NkY6IDB4ODZBOSxcbiAgICAweEU1NzA6IDB4ODZBQSxcbiAgICAweEU1NzE6IDB4ODY4QixcbiAgICAweEU1NzI6IDB4ODY4QyxcbiAgICAweEU1NzM6IDB4ODZCNixcbiAgICAweEU1NzQ6IDB4ODZBRixcbiAgICAweEU1NzU6IDB4ODZDNCxcbiAgICAweEU1NzY6IDB4ODZDNixcbiAgICAweEU1Nzc6IDB4ODZCMCxcbiAgICAweEU1Nzg6IDB4ODZDOSxcbiAgICAweEU1Nzk6IDB4ODgyMyxcbiAgICAweEU1N0E6IDB4ODZBQixcbiAgICAweEU1N0I6IDB4ODZENCxcbiAgICAweEU1N0M6IDB4ODZERSxcbiAgICAweEU1N0Q6IDB4ODZFOSxcbiAgICAweEU1N0U6IDB4ODZFQyxcbiAgICAweEU1ODA6IDB4ODZERixcbiAgICAweEU1ODE6IDB4ODZEQixcbiAgICAweEU1ODI6IDB4ODZFRixcbiAgICAweEU1ODM6IDB4ODcxMixcbiAgICAweEU1ODQ6IDB4ODcwNixcbiAgICAweEU1ODU6IDB4ODcwOCxcbiAgICAweEU1ODY6IDB4ODcwMCxcbiAgICAweEU1ODc6IDB4ODcwMyxcbiAgICAweEU1ODg6IDB4ODZGQixcbiAgICAweEU1ODk6IDB4ODcxMSxcbiAgICAweEU1OEE6IDB4ODcwOSxcbiAgICAweEU1OEI6IDB4ODcwRCxcbiAgICAweEU1OEM6IDB4ODZGOSxcbiAgICAweEU1OEQ6IDB4ODcwQSxcbiAgICAweEU1OEU6IDB4ODczNCxcbiAgICAweEU1OEY6IDB4ODczRixcbiAgICAweEU1OTA6IDB4ODczNyxcbiAgICAweEU1OTE6IDB4ODczQixcbiAgICAweEU1OTI6IDB4ODcyNSxcbiAgICAweEU1OTM6IDB4ODcyOSxcbiAgICAweEU1OTQ6IDB4ODcxQSxcbiAgICAweEU1OTU6IDB4ODc2MCxcbiAgICAweEU1OTY6IDB4ODc1RixcbiAgICAweEU1OTc6IDB4ODc3OCxcbiAgICAweEU1OTg6IDB4ODc0QyxcbiAgICAweEU1OTk6IDB4ODc0RSxcbiAgICAweEU1OUE6IDB4ODc3NCxcbiAgICAweEU1OUI6IDB4ODc1NyxcbiAgICAweEU1OUM6IDB4ODc2OCxcbiAgICAweEU1OUQ6IDB4ODc2RSxcbiAgICAweEU1OUU6IDB4ODc1OSxcbiAgICAweEU1OUY6IDB4ODc1MyxcbiAgICAweEU1QTA6IDB4ODc2MyxcbiAgICAweEU1QTE6IDB4ODc2QSxcbiAgICAweEU1QTI6IDB4ODgwNSxcbiAgICAweEU1QTM6IDB4ODdBMixcbiAgICAweEU1QTQ6IDB4ODc5RixcbiAgICAweEU1QTU6IDB4ODc4MixcbiAgICAweEU1QTY6IDB4ODdBRixcbiAgICAweEU1QTc6IDB4ODdDQixcbiAgICAweEU1QTg6IDB4ODdCRCxcbiAgICAweEU1QTk6IDB4ODdDMCxcbiAgICAweEU1QUE6IDB4ODdEMCxcbiAgICAweEU1QUI6IDB4OTZENixcbiAgICAweEU1QUM6IDB4ODdBQixcbiAgICAweEU1QUQ6IDB4ODdDNCxcbiAgICAweEU1QUU6IDB4ODdCMyxcbiAgICAweEU1QUY6IDB4ODdDNyxcbiAgICAweEU1QjA6IDB4ODdDNixcbiAgICAweEU1QjE6IDB4ODdCQixcbiAgICAweEU1QjI6IDB4ODdFRixcbiAgICAweEU1QjM6IDB4ODdGMixcbiAgICAweEU1QjQ6IDB4ODdFMCxcbiAgICAweEU1QjU6IDB4ODgwRixcbiAgICAweEU1QjY6IDB4ODgwRCxcbiAgICAweEU1Qjc6IDB4ODdGRSxcbiAgICAweEU1Qjg6IDB4ODdGNixcbiAgICAweEU1Qjk6IDB4ODdGNyxcbiAgICAweEU1QkE6IDB4ODgwRSxcbiAgICAweEU1QkI6IDB4ODdEMixcbiAgICAweEU1QkM6IDB4ODgxMSxcbiAgICAweEU1QkQ6IDB4ODgxNixcbiAgICAweEU1QkU6IDB4ODgxNSxcbiAgICAweEU1QkY6IDB4ODgyMixcbiAgICAweEU1QzA6IDB4ODgyMSxcbiAgICAweEU1QzE6IDB4ODgzMSxcbiAgICAweEU1QzI6IDB4ODgzNixcbiAgICAweEU1QzM6IDB4ODgzOSxcbiAgICAweEU1QzQ6IDB4ODgyNyxcbiAgICAweEU1QzU6IDB4ODgzQixcbiAgICAweEU1QzY6IDB4ODg0NCxcbiAgICAweEU1Qzc6IDB4ODg0MixcbiAgICAweEU1Qzg6IDB4ODg1MixcbiAgICAweEU1Qzk6IDB4ODg1OSxcbiAgICAweEU1Q0E6IDB4ODg1RSxcbiAgICAweEU1Q0I6IDB4ODg2MixcbiAgICAweEU1Q0M6IDB4ODg2QixcbiAgICAweEU1Q0Q6IDB4ODg4MSxcbiAgICAweEU1Q0U6IDB4ODg3RSxcbiAgICAweEU1Q0Y6IDB4ODg5RSxcbiAgICAweEU1RDA6IDB4ODg3NSxcbiAgICAweEU1RDE6IDB4ODg3RCxcbiAgICAweEU1RDI6IDB4ODhCNSxcbiAgICAweEU1RDM6IDB4ODg3MixcbiAgICAweEU1RDQ6IDB4ODg4MixcbiAgICAweEU1RDU6IDB4ODg5NyxcbiAgICAweEU1RDY6IDB4ODg5MixcbiAgICAweEU1RDc6IDB4ODhBRSxcbiAgICAweEU1RDg6IDB4ODg5OSxcbiAgICAweEU1RDk6IDB4ODhBMixcbiAgICAweEU1REE6IDB4ODg4RCxcbiAgICAweEU1REI6IDB4ODhBNCxcbiAgICAweEU1REM6IDB4ODhCMCxcbiAgICAweEU1REQ6IDB4ODhCRixcbiAgICAweEU1REU6IDB4ODhCMSxcbiAgICAweEU1REY6IDB4ODhDMyxcbiAgICAweEU1RTA6IDB4ODhDNCxcbiAgICAweEU1RTE6IDB4ODhENCxcbiAgICAweEU1RTI6IDB4ODhEOCxcbiAgICAweEU1RTM6IDB4ODhEOSxcbiAgICAweEU1RTQ6IDB4ODhERCxcbiAgICAweEU1RTU6IDB4ODhGOSxcbiAgICAweEU1RTY6IDB4ODkwMixcbiAgICAweEU1RTc6IDB4ODhGQyxcbiAgICAweEU1RTg6IDB4ODhGNCxcbiAgICAweEU1RTk6IDB4ODhFOCxcbiAgICAweEU1RUE6IDB4ODhGMixcbiAgICAweEU1RUI6IDB4ODkwNCxcbiAgICAweEU1RUM6IDB4ODkwQyxcbiAgICAweEU1RUQ6IDB4ODkwQSxcbiAgICAweEU1RUU6IDB4ODkxMyxcbiAgICAweEU1RUY6IDB4ODk0MyxcbiAgICAweEU1RjA6IDB4ODkxRSxcbiAgICAweEU1RjE6IDB4ODkyNSxcbiAgICAweEU1RjI6IDB4ODkyQSxcbiAgICAweEU1RjM6IDB4ODkyQixcbiAgICAweEU1RjQ6IDB4ODk0MSxcbiAgICAweEU1RjU6IDB4ODk0NCxcbiAgICAweEU1RjY6IDB4ODkzQixcbiAgICAweEU1Rjc6IDB4ODkzNixcbiAgICAweEU1Rjg6IDB4ODkzOCxcbiAgICAweEU1Rjk6IDB4ODk0QyxcbiAgICAweEU1RkE6IDB4ODkxRCxcbiAgICAweEU1RkI6IDB4ODk2MCxcbiAgICAweEU1RkM6IDB4ODk1RSxcbiAgICAweEU2NDA6IDB4ODk2NixcbiAgICAweEU2NDE6IDB4ODk2NCxcbiAgICAweEU2NDI6IDB4ODk2RCxcbiAgICAweEU2NDM6IDB4ODk2QSxcbiAgICAweEU2NDQ6IDB4ODk2RixcbiAgICAweEU2NDU6IDB4ODk3NCxcbiAgICAweEU2NDY6IDB4ODk3NyxcbiAgICAweEU2NDc6IDB4ODk3RSxcbiAgICAweEU2NDg6IDB4ODk4MyxcbiAgICAweEU2NDk6IDB4ODk4OCxcbiAgICAweEU2NEE6IDB4ODk4QSxcbiAgICAweEU2NEI6IDB4ODk5MyxcbiAgICAweEU2NEM6IDB4ODk5OCxcbiAgICAweEU2NEQ6IDB4ODlBMSxcbiAgICAweEU2NEU6IDB4ODlBOSxcbiAgICAweEU2NEY6IDB4ODlBNixcbiAgICAweEU2NTA6IDB4ODlBQyxcbiAgICAweEU2NTE6IDB4ODlBRixcbiAgICAweEU2NTI6IDB4ODlCMixcbiAgICAweEU2NTM6IDB4ODlCQSxcbiAgICAweEU2NTQ6IDB4ODlCRCxcbiAgICAweEU2NTU6IDB4ODlCRixcbiAgICAweEU2NTY6IDB4ODlDMCxcbiAgICAweEU2NTc6IDB4ODlEQSxcbiAgICAweEU2NTg6IDB4ODlEQyxcbiAgICAweEU2NTk6IDB4ODlERCxcbiAgICAweEU2NUE6IDB4ODlFNyxcbiAgICAweEU2NUI6IDB4ODlGNCxcbiAgICAweEU2NUM6IDB4ODlGOCxcbiAgICAweEU2NUQ6IDB4OEEwMyxcbiAgICAweEU2NUU6IDB4OEExNixcbiAgICAweEU2NUY6IDB4OEExMCxcbiAgICAweEU2NjA6IDB4OEEwQyxcbiAgICAweEU2NjE6IDB4OEExQixcbiAgICAweEU2NjI6IDB4OEExRCxcbiAgICAweEU2NjM6IDB4OEEyNSxcbiAgICAweEU2NjQ6IDB4OEEzNixcbiAgICAweEU2NjU6IDB4OEE0MSxcbiAgICAweEU2NjY6IDB4OEE1QixcbiAgICAweEU2Njc6IDB4OEE1MixcbiAgICAweEU2Njg6IDB4OEE0NixcbiAgICAweEU2Njk6IDB4OEE0OCxcbiAgICAweEU2NkE6IDB4OEE3QyxcbiAgICAweEU2NkI6IDB4OEE2RCxcbiAgICAweEU2NkM6IDB4OEE2QyxcbiAgICAweEU2NkQ6IDB4OEE2MixcbiAgICAweEU2NkU6IDB4OEE4NSxcbiAgICAweEU2NkY6IDB4OEE4MixcbiAgICAweEU2NzA6IDB4OEE4NCxcbiAgICAweEU2NzE6IDB4OEFBOCxcbiAgICAweEU2NzI6IDB4OEFBMSxcbiAgICAweEU2NzM6IDB4OEE5MSxcbiAgICAweEU2NzQ6IDB4OEFBNSxcbiAgICAweEU2NzU6IDB4OEFBNixcbiAgICAweEU2NzY6IDB4OEE5QSxcbiAgICAweEU2Nzc6IDB4OEFBMyxcbiAgICAweEU2Nzg6IDB4OEFDNCxcbiAgICAweEU2Nzk6IDB4OEFDRCxcbiAgICAweEU2N0E6IDB4OEFDMixcbiAgICAweEU2N0I6IDB4OEFEQSxcbiAgICAweEU2N0M6IDB4OEFFQixcbiAgICAweEU2N0Q6IDB4OEFGMyxcbiAgICAweEU2N0U6IDB4OEFFNyxcbiAgICAweEU2ODA6IDB4OEFFNCxcbiAgICAweEU2ODE6IDB4OEFGMSxcbiAgICAweEU2ODI6IDB4OEIxNCxcbiAgICAweEU2ODM6IDB4OEFFMCxcbiAgICAweEU2ODQ6IDB4OEFFMixcbiAgICAweEU2ODU6IDB4OEFGNyxcbiAgICAweEU2ODY6IDB4OEFERSxcbiAgICAweEU2ODc6IDB4OEFEQixcbiAgICAweEU2ODg6IDB4OEIwQyxcbiAgICAweEU2ODk6IDB4OEIwNyxcbiAgICAweEU2OEE6IDB4OEIxQSxcbiAgICAweEU2OEI6IDB4OEFFMSxcbiAgICAweEU2OEM6IDB4OEIxNixcbiAgICAweEU2OEQ6IDB4OEIxMCxcbiAgICAweEU2OEU6IDB4OEIxNyxcbiAgICAweEU2OEY6IDB4OEIyMCxcbiAgICAweEU2OTA6IDB4OEIzMyxcbiAgICAweEU2OTE6IDB4OTdBQixcbiAgICAweEU2OTI6IDB4OEIyNixcbiAgICAweEU2OTM6IDB4OEIyQixcbiAgICAweEU2OTQ6IDB4OEIzRSxcbiAgICAweEU2OTU6IDB4OEIyOCxcbiAgICAweEU2OTY6IDB4OEI0MSxcbiAgICAweEU2OTc6IDB4OEI0QyxcbiAgICAweEU2OTg6IDB4OEI0RixcbiAgICAweEU2OTk6IDB4OEI0RSxcbiAgICAweEU2OUE6IDB4OEI0OSxcbiAgICAweEU2OUI6IDB4OEI1NixcbiAgICAweEU2OUM6IDB4OEI1QixcbiAgICAweEU2OUQ6IDB4OEI1QSxcbiAgICAweEU2OUU6IDB4OEI2QixcbiAgICAweEU2OUY6IDB4OEI1RixcbiAgICAweEU2QTA6IDB4OEI2QyxcbiAgICAweEU2QTE6IDB4OEI2RixcbiAgICAweEU2QTI6IDB4OEI3NCxcbiAgICAweEU2QTM6IDB4OEI3RCxcbiAgICAweEU2QTQ6IDB4OEI4MCxcbiAgICAweEU2QTU6IDB4OEI4QyxcbiAgICAweEU2QTY6IDB4OEI4RSxcbiAgICAweEU2QTc6IDB4OEI5MixcbiAgICAweEU2QTg6IDB4OEI5MyxcbiAgICAweEU2QTk6IDB4OEI5NixcbiAgICAweEU2QUE6IDB4OEI5OSxcbiAgICAweEU2QUI6IDB4OEI5QSxcbiAgICAweEU2QUM6IDB4OEMzQSxcbiAgICAweEU2QUQ6IDB4OEM0MSxcbiAgICAweEU2QUU6IDB4OEMzRixcbiAgICAweEU2QUY6IDB4OEM0OCxcbiAgICAweEU2QjA6IDB4OEM0QyxcbiAgICAweEU2QjE6IDB4OEM0RSxcbiAgICAweEU2QjI6IDB4OEM1MCxcbiAgICAweEU2QjM6IDB4OEM1NSxcbiAgICAweEU2QjQ6IDB4OEM2MixcbiAgICAweEU2QjU6IDB4OEM2QyxcbiAgICAweEU2QjY6IDB4OEM3OCxcbiAgICAweEU2Qjc6IDB4OEM3QSxcbiAgICAweEU2Qjg6IDB4OEM4MixcbiAgICAweEU2Qjk6IDB4OEM4OSxcbiAgICAweEU2QkE6IDB4OEM4NSxcbiAgICAweEU2QkI6IDB4OEM4QSxcbiAgICAweEU2QkM6IDB4OEM4RCxcbiAgICAweEU2QkQ6IDB4OEM4RSxcbiAgICAweEU2QkU6IDB4OEM5NCxcbiAgICAweEU2QkY6IDB4OEM3QyxcbiAgICAweEU2QzA6IDB4OEM5OCxcbiAgICAweEU2QzE6IDB4NjIxRCxcbiAgICAweEU2QzI6IDB4OENBRCxcbiAgICAweEU2QzM6IDB4OENBQSxcbiAgICAweEU2QzQ6IDB4OENCRCxcbiAgICAweEU2QzU6IDB4OENCMixcbiAgICAweEU2QzY6IDB4OENCMyxcbiAgICAweEU2Qzc6IDB4OENBRSxcbiAgICAweEU2Qzg6IDB4OENCNixcbiAgICAweEU2Qzk6IDB4OENDOCxcbiAgICAweEU2Q0E6IDB4OENDMSxcbiAgICAweEU2Q0I6IDB4OENFNCxcbiAgICAweEU2Q0M6IDB4OENFMyxcbiAgICAweEU2Q0Q6IDB4OENEQSxcbiAgICAweEU2Q0U6IDB4OENGRCxcbiAgICAweEU2Q0Y6IDB4OENGQSxcbiAgICAweEU2RDA6IDB4OENGQixcbiAgICAweEU2RDE6IDB4OEQwNCxcbiAgICAweEU2RDI6IDB4OEQwNSxcbiAgICAweEU2RDM6IDB4OEQwQSxcbiAgICAweEU2RDQ6IDB4OEQwNyxcbiAgICAweEU2RDU6IDB4OEQwRixcbiAgICAweEU2RDY6IDB4OEQwRCxcbiAgICAweEU2RDc6IDB4OEQxMCxcbiAgICAweEU2RDg6IDB4OUY0RSxcbiAgICAweEU2RDk6IDB4OEQxMyxcbiAgICAweEU2REE6IDB4OENDRCxcbiAgICAweEU2REI6IDB4OEQxNCxcbiAgICAweEU2REM6IDB4OEQxNixcbiAgICAweEU2REQ6IDB4OEQ2NyxcbiAgICAweEU2REU6IDB4OEQ2RCxcbiAgICAweEU2REY6IDB4OEQ3MSxcbiAgICAweEU2RTA6IDB4OEQ3MyxcbiAgICAweEU2RTE6IDB4OEQ4MSxcbiAgICAweEU2RTI6IDB4OEQ5OSxcbiAgICAweEU2RTM6IDB4OERDMixcbiAgICAweEU2RTQ6IDB4OERCRSxcbiAgICAweEU2RTU6IDB4OERCQSxcbiAgICAweEU2RTY6IDB4OERDRixcbiAgICAweEU2RTc6IDB4OEREQSxcbiAgICAweEU2RTg6IDB4OERENixcbiAgICAweEU2RTk6IDB4OERDQyxcbiAgICAweEU2RUE6IDB4OEREQixcbiAgICAweEU2RUI6IDB4OERDQixcbiAgICAweEU2RUM6IDB4OERFQSxcbiAgICAweEU2RUQ6IDB4OERFQixcbiAgICAweEU2RUU6IDB4OERERixcbiAgICAweEU2RUY6IDB4OERFMyxcbiAgICAweEU2RjA6IDB4OERGQyxcbiAgICAweEU2RjE6IDB4OEUwOCxcbiAgICAweEU2RjI6IDB4OEUwOSxcbiAgICAweEU2RjM6IDB4OERGRixcbiAgICAweEU2RjQ6IDB4OEUxRCxcbiAgICAweEU2RjU6IDB4OEUxRSxcbiAgICAweEU2RjY6IDB4OEUxMCxcbiAgICAweEU2Rjc6IDB4OEUxRixcbiAgICAweEU2Rjg6IDB4OEU0MixcbiAgICAweEU2Rjk6IDB4OEUzNSxcbiAgICAweEU2RkE6IDB4OEUzMCxcbiAgICAweEU2RkI6IDB4OEUzNCxcbiAgICAweEU2RkM6IDB4OEU0QSxcbiAgICAweEU3NDA6IDB4OEU0NyxcbiAgICAweEU3NDE6IDB4OEU0OSxcbiAgICAweEU3NDI6IDB4OEU0QyxcbiAgICAweEU3NDM6IDB4OEU1MCxcbiAgICAweEU3NDQ6IDB4OEU0OCxcbiAgICAweEU3NDU6IDB4OEU1OSxcbiAgICAweEU3NDY6IDB4OEU2NCxcbiAgICAweEU3NDc6IDB4OEU2MCxcbiAgICAweEU3NDg6IDB4OEUyQSxcbiAgICAweEU3NDk6IDB4OEU2MyxcbiAgICAweEU3NEE6IDB4OEU1NSxcbiAgICAweEU3NEI6IDB4OEU3NixcbiAgICAweEU3NEM6IDB4OEU3MixcbiAgICAweEU3NEQ6IDB4OEU3QyxcbiAgICAweEU3NEU6IDB4OEU4MSxcbiAgICAweEU3NEY6IDB4OEU4NyxcbiAgICAweEU3NTA6IDB4OEU4NSxcbiAgICAweEU3NTE6IDB4OEU4NCxcbiAgICAweEU3NTI6IDB4OEU4QixcbiAgICAweEU3NTM6IDB4OEU4QSxcbiAgICAweEU3NTQ6IDB4OEU5MyxcbiAgICAweEU3NTU6IDB4OEU5MSxcbiAgICAweEU3NTY6IDB4OEU5NCxcbiAgICAweEU3NTc6IDB4OEU5OSxcbiAgICAweEU3NTg6IDB4OEVBQSxcbiAgICAweEU3NTk6IDB4OEVBMSxcbiAgICAweEU3NUE6IDB4OEVBQyxcbiAgICAweEU3NUI6IDB4OEVCMCxcbiAgICAweEU3NUM6IDB4OEVDNixcbiAgICAweEU3NUQ6IDB4OEVCMSxcbiAgICAweEU3NUU6IDB4OEVCRSxcbiAgICAweEU3NUY6IDB4OEVDNSxcbiAgICAweEU3NjA6IDB4OEVDOCxcbiAgICAweEU3NjE6IDB4OEVDQixcbiAgICAweEU3NjI6IDB4OEVEQixcbiAgICAweEU3NjM6IDB4OEVFMyxcbiAgICAweEU3NjQ6IDB4OEVGQyxcbiAgICAweEU3NjU6IDB4OEVGQixcbiAgICAweEU3NjY6IDB4OEVFQixcbiAgICAweEU3Njc6IDB4OEVGRSxcbiAgICAweEU3Njg6IDB4OEYwQSxcbiAgICAweEU3Njk6IDB4OEYwNSxcbiAgICAweEU3NkE6IDB4OEYxNSxcbiAgICAweEU3NkI6IDB4OEYxMixcbiAgICAweEU3NkM6IDB4OEYxOSxcbiAgICAweEU3NkQ6IDB4OEYxMyxcbiAgICAweEU3NkU6IDB4OEYxQyxcbiAgICAweEU3NkY6IDB4OEYxRixcbiAgICAweEU3NzA6IDB4OEYxQixcbiAgICAweEU3NzE6IDB4OEYwQyxcbiAgICAweEU3NzI6IDB4OEYyNixcbiAgICAweEU3NzM6IDB4OEYzMyxcbiAgICAweEU3NzQ6IDB4OEYzQixcbiAgICAweEU3NzU6IDB4OEYzOSxcbiAgICAweEU3NzY6IDB4OEY0NSxcbiAgICAweEU3Nzc6IDB4OEY0MixcbiAgICAweEU3Nzg6IDB4OEYzRSxcbiAgICAweEU3Nzk6IDB4OEY0QyxcbiAgICAweEU3N0E6IDB4OEY0OSxcbiAgICAweEU3N0I6IDB4OEY0NixcbiAgICAweEU3N0M6IDB4OEY0RSxcbiAgICAweEU3N0Q6IDB4OEY1NyxcbiAgICAweEU3N0U6IDB4OEY1QyxcbiAgICAweEU3ODA6IDB4OEY2MixcbiAgICAweEU3ODE6IDB4OEY2MyxcbiAgICAweEU3ODI6IDB4OEY2NCxcbiAgICAweEU3ODM6IDB4OEY5QyxcbiAgICAweEU3ODQ6IDB4OEY5RixcbiAgICAweEU3ODU6IDB4OEZBMyxcbiAgICAweEU3ODY6IDB4OEZBRCxcbiAgICAweEU3ODc6IDB4OEZBRixcbiAgICAweEU3ODg6IDB4OEZCNyxcbiAgICAweEU3ODk6IDB4OEZEQSxcbiAgICAweEU3OEE6IDB4OEZFNSxcbiAgICAweEU3OEI6IDB4OEZFMixcbiAgICAweEU3OEM6IDB4OEZFQSxcbiAgICAweEU3OEQ6IDB4OEZFRixcbiAgICAweEU3OEU6IDB4OTA4NyxcbiAgICAweEU3OEY6IDB4OEZGNCxcbiAgICAweEU3OTA6IDB4OTAwNSxcbiAgICAweEU3OTE6IDB4OEZGOSxcbiAgICAweEU3OTI6IDB4OEZGQSxcbiAgICAweEU3OTM6IDB4OTAxMSxcbiAgICAweEU3OTQ6IDB4OTAxNSxcbiAgICAweEU3OTU6IDB4OTAyMSxcbiAgICAweEU3OTY6IDB4OTAwRCxcbiAgICAweEU3OTc6IDB4OTAxRSxcbiAgICAweEU3OTg6IDB4OTAxNixcbiAgICAweEU3OTk6IDB4OTAwQixcbiAgICAweEU3OUE6IDB4OTAyNyxcbiAgICAweEU3OUI6IDB4OTAzNixcbiAgICAweEU3OUM6IDB4OTAzNSxcbiAgICAweEU3OUQ6IDB4OTAzOSxcbiAgICAweEU3OUU6IDB4OEZGOCxcbiAgICAweEU3OUY6IDB4OTA0RixcbiAgICAweEU3QTA6IDB4OTA1MCxcbiAgICAweEU3QTE6IDB4OTA1MSxcbiAgICAweEU3QTI6IDB4OTA1MixcbiAgICAweEU3QTM6IDB4OTAwRSxcbiAgICAweEU3QTQ6IDB4OTA0OSxcbiAgICAweEU3QTU6IDB4OTAzRSxcbiAgICAweEU3QTY6IDB4OTA1NixcbiAgICAweEU3QTc6IDB4OTA1OCxcbiAgICAweEU3QTg6IDB4OTA1RSxcbiAgICAweEU3QTk6IDB4OTA2OCxcbiAgICAweEU3QUE6IDB4OTA2RixcbiAgICAweEU3QUI6IDB4OTA3NixcbiAgICAweEU3QUM6IDB4OTZBOCxcbiAgICAweEU3QUQ6IDB4OTA3MixcbiAgICAweEU3QUU6IDB4OTA4MixcbiAgICAweEU3QUY6IDB4OTA3RCxcbiAgICAweEU3QjA6IDB4OTA4MSxcbiAgICAweEU3QjE6IDB4OTA4MCxcbiAgICAweEU3QjI6IDB4OTA4QSxcbiAgICAweEU3QjM6IDB4OTA4OSxcbiAgICAweEU3QjQ6IDB4OTA4RixcbiAgICAweEU3QjU6IDB4OTBBOCxcbiAgICAweEU3QjY6IDB4OTBBRixcbiAgICAweEU3Qjc6IDB4OTBCMSxcbiAgICAweEU3Qjg6IDB4OTBCNSxcbiAgICAweEU3Qjk6IDB4OTBFMixcbiAgICAweEU3QkE6IDB4OTBFNCxcbiAgICAweEU3QkI6IDB4NjI0OCxcbiAgICAweEU3QkM6IDB4OTBEQixcbiAgICAweEU3QkQ6IDB4OTEwMixcbiAgICAweEU3QkU6IDB4OTExMixcbiAgICAweEU3QkY6IDB4OTExOSxcbiAgICAweEU3QzA6IDB4OTEzMixcbiAgICAweEU3QzE6IDB4OTEzMCxcbiAgICAweEU3QzI6IDB4OTE0QSxcbiAgICAweEU3QzM6IDB4OTE1NixcbiAgICAweEU3QzQ6IDB4OTE1OCxcbiAgICAweEU3QzU6IDB4OTE2MyxcbiAgICAweEU3QzY6IDB4OTE2NSxcbiAgICAweEU3Qzc6IDB4OTE2OSxcbiAgICAweEU3Qzg6IDB4OTE3MyxcbiAgICAweEU3Qzk6IDB4OTE3MixcbiAgICAweEU3Q0E6IDB4OTE4QixcbiAgICAweEU3Q0I6IDB4OTE4OSxcbiAgICAweEU3Q0M6IDB4OTE4MixcbiAgICAweEU3Q0Q6IDB4OTFBMixcbiAgICAweEU3Q0U6IDB4OTFBQixcbiAgICAweEU3Q0Y6IDB4OTFBRixcbiAgICAweEU3RDA6IDB4OTFBQSxcbiAgICAweEU3RDE6IDB4OTFCNSxcbiAgICAweEU3RDI6IDB4OTFCNCxcbiAgICAweEU3RDM6IDB4OTFCQSxcbiAgICAweEU3RDQ6IDB4OTFDMCxcbiAgICAweEU3RDU6IDB4OTFDMSxcbiAgICAweEU3RDY6IDB4OTFDOSxcbiAgICAweEU3RDc6IDB4OTFDQixcbiAgICAweEU3RDg6IDB4OTFEMCxcbiAgICAweEU3RDk6IDB4OTFENixcbiAgICAweEU3REE6IDB4OTFERixcbiAgICAweEU3REI6IDB4OTFFMSxcbiAgICAweEU3REM6IDB4OTFEQixcbiAgICAweEU3REQ6IDB4OTFGQyxcbiAgICAweEU3REU6IDB4OTFGNSxcbiAgICAweEU3REY6IDB4OTFGNixcbiAgICAweEU3RTA6IDB4OTIxRSxcbiAgICAweEU3RTE6IDB4OTFGRixcbiAgICAweEU3RTI6IDB4OTIxNCxcbiAgICAweEU3RTM6IDB4OTIyQyxcbiAgICAweEU3RTQ6IDB4OTIxNSxcbiAgICAweEU3RTU6IDB4OTIxMSxcbiAgICAweEU3RTY6IDB4OTI1RSxcbiAgICAweEU3RTc6IDB4OTI1NyxcbiAgICAweEU3RTg6IDB4OTI0NSxcbiAgICAweEU3RTk6IDB4OTI0OSxcbiAgICAweEU3RUE6IDB4OTI2NCxcbiAgICAweEU3RUI6IDB4OTI0OCxcbiAgICAweEU3RUM6IDB4OTI5NSxcbiAgICAweEU3RUQ6IDB4OTIzRixcbiAgICAweEU3RUU6IDB4OTI0QixcbiAgICAweEU3RUY6IDB4OTI1MCxcbiAgICAweEU3RjA6IDB4OTI5QyxcbiAgICAweEU3RjE6IDB4OTI5NixcbiAgICAweEU3RjI6IDB4OTI5MyxcbiAgICAweEU3RjM6IDB4OTI5QixcbiAgICAweEU3RjQ6IDB4OTI1QSxcbiAgICAweEU3RjU6IDB4OTJDRixcbiAgICAweEU3RjY6IDB4OTJCOSxcbiAgICAweEU3Rjc6IDB4OTJCNyxcbiAgICAweEU3Rjg6IDB4OTJFOSxcbiAgICAweEU3Rjk6IDB4OTMwRixcbiAgICAweEU3RkE6IDB4OTJGQSxcbiAgICAweEU3RkI6IDB4OTM0NCxcbiAgICAweEU3RkM6IDB4OTMyRSxcbiAgICAweEU4NDA6IDB4OTMxOSxcbiAgICAweEU4NDE6IDB4OTMyMixcbiAgICAweEU4NDI6IDB4OTMxQSxcbiAgICAweEU4NDM6IDB4OTMyMyxcbiAgICAweEU4NDQ6IDB4OTMzQSxcbiAgICAweEU4NDU6IDB4OTMzNSxcbiAgICAweEU4NDY6IDB4OTMzQixcbiAgICAweEU4NDc6IDB4OTM1QyxcbiAgICAweEU4NDg6IDB4OTM2MCxcbiAgICAweEU4NDk6IDB4OTM3QyxcbiAgICAweEU4NEE6IDB4OTM2RSxcbiAgICAweEU4NEI6IDB4OTM1NixcbiAgICAweEU4NEM6IDB4OTNCMCxcbiAgICAweEU4NEQ6IDB4OTNBQyxcbiAgICAweEU4NEU6IDB4OTNBRCxcbiAgICAweEU4NEY6IDB4OTM5NCxcbiAgICAweEU4NTA6IDB4OTNCOSxcbiAgICAweEU4NTE6IDB4OTNENixcbiAgICAweEU4NTI6IDB4OTNENyxcbiAgICAweEU4NTM6IDB4OTNFOCxcbiAgICAweEU4NTQ6IDB4OTNFNSxcbiAgICAweEU4NTU6IDB4OTNEOCxcbiAgICAweEU4NTY6IDB4OTNDMyxcbiAgICAweEU4NTc6IDB4OTNERCxcbiAgICAweEU4NTg6IDB4OTNEMCxcbiAgICAweEU4NTk6IDB4OTNDOCxcbiAgICAweEU4NUE6IDB4OTNFNCxcbiAgICAweEU4NUI6IDB4OTQxQSxcbiAgICAweEU4NUM6IDB4OTQxNCxcbiAgICAweEU4NUQ6IDB4OTQxMyxcbiAgICAweEU4NUU6IDB4OTQwMyxcbiAgICAweEU4NUY6IDB4OTQwNyxcbiAgICAweEU4NjA6IDB4OTQxMCxcbiAgICAweEU4NjE6IDB4OTQzNixcbiAgICAweEU4NjI6IDB4OTQyQixcbiAgICAweEU4NjM6IDB4OTQzNSxcbiAgICAweEU4NjQ6IDB4OTQyMSxcbiAgICAweEU4NjU6IDB4OTQzQSxcbiAgICAweEU4NjY6IDB4OTQ0MSxcbiAgICAweEU4Njc6IDB4OTQ1MixcbiAgICAweEU4Njg6IDB4OTQ0NCxcbiAgICAweEU4Njk6IDB4OTQ1QixcbiAgICAweEU4NkE6IDB4OTQ2MCxcbiAgICAweEU4NkI6IDB4OTQ2MixcbiAgICAweEU4NkM6IDB4OTQ1RSxcbiAgICAweEU4NkQ6IDB4OTQ2QSxcbiAgICAweEU4NkU6IDB4OTIyOSxcbiAgICAweEU4NkY6IDB4OTQ3MCxcbiAgICAweEU4NzA6IDB4OTQ3NSxcbiAgICAweEU4NzE6IDB4OTQ3NyxcbiAgICAweEU4NzI6IDB4OTQ3RCxcbiAgICAweEU4NzM6IDB4OTQ1QSxcbiAgICAweEU4NzQ6IDB4OTQ3QyxcbiAgICAweEU4NzU6IDB4OTQ3RSxcbiAgICAweEU4NzY6IDB4OTQ4MSxcbiAgICAweEU4Nzc6IDB4OTQ3RixcbiAgICAweEU4Nzg6IDB4OTU4MixcbiAgICAweEU4Nzk6IDB4OTU4NyxcbiAgICAweEU4N0E6IDB4OTU4QSxcbiAgICAweEU4N0I6IDB4OTU5NCxcbiAgICAweEU4N0M6IDB4OTU5NixcbiAgICAweEU4N0Q6IDB4OTU5OCxcbiAgICAweEU4N0U6IDB4OTU5OSxcbiAgICAweEU4ODA6IDB4OTVBMCxcbiAgICAweEU4ODE6IDB4OTVBOCxcbiAgICAweEU4ODI6IDB4OTVBNyxcbiAgICAweEU4ODM6IDB4OTVBRCxcbiAgICAweEU4ODQ6IDB4OTVCQyxcbiAgICAweEU4ODU6IDB4OTVCQixcbiAgICAweEU4ODY6IDB4OTVCOSxcbiAgICAweEU4ODc6IDB4OTVCRSxcbiAgICAweEU4ODg6IDB4OTVDQSxcbiAgICAweEU4ODk6IDB4NkZGNixcbiAgICAweEU4OEE6IDB4OTVDMyxcbiAgICAweEU4OEI6IDB4OTVDRCxcbiAgICAweEU4OEM6IDB4OTVDQyxcbiAgICAweEU4OEQ6IDB4OTVENSxcbiAgICAweEU4OEU6IDB4OTVENCxcbiAgICAweEU4OEY6IDB4OTVENixcbiAgICAweEU4OTA6IDB4OTVEQyxcbiAgICAweEU4OTE6IDB4OTVFMSxcbiAgICAweEU4OTI6IDB4OTVFNSxcbiAgICAweEU4OTM6IDB4OTVFMixcbiAgICAweEU4OTQ6IDB4OTYyMSxcbiAgICAweEU4OTU6IDB4OTYyOCxcbiAgICAweEU4OTY6IDB4OTYyRSxcbiAgICAweEU4OTc6IDB4OTYyRixcbiAgICAweEU4OTg6IDB4OTY0MixcbiAgICAweEU4OTk6IDB4OTY0QyxcbiAgICAweEU4OUE6IDB4OTY0RixcbiAgICAweEU4OUI6IDB4OTY0QixcbiAgICAweEU4OUM6IDB4OTY3NyxcbiAgICAweEU4OUQ6IDB4OTY1QyxcbiAgICAweEU4OUU6IDB4OTY1RSxcbiAgICAweEU4OUY6IDB4OTY1RCxcbiAgICAweEU4QTA6IDB4OTY1RixcbiAgICAweEU4QTE6IDB4OTY2NixcbiAgICAweEU4QTI6IDB4OTY3MixcbiAgICAweEU4QTM6IDB4OTY2QyxcbiAgICAweEU4QTQ6IDB4OTY4RCxcbiAgICAweEU4QTU6IDB4OTY5OCxcbiAgICAweEU4QTY6IDB4OTY5NSxcbiAgICAweEU4QTc6IDB4OTY5NyxcbiAgICAweEU4QTg6IDB4OTZBQSxcbiAgICAweEU4QTk6IDB4OTZBNyxcbiAgICAweEU4QUE6IDB4OTZCMSxcbiAgICAweEU4QUI6IDB4OTZCMixcbiAgICAweEU4QUM6IDB4OTZCMCxcbiAgICAweEU4QUQ6IDB4OTZCNCxcbiAgICAweEU4QUU6IDB4OTZCNixcbiAgICAweEU4QUY6IDB4OTZCOCxcbiAgICAweEU4QjA6IDB4OTZCOSxcbiAgICAweEU4QjE6IDB4OTZDRSxcbiAgICAweEU4QjI6IDB4OTZDQixcbiAgICAweEU4QjM6IDB4OTZDOSxcbiAgICAweEU4QjQ6IDB4OTZDRCxcbiAgICAweEU4QjU6IDB4ODk0RCxcbiAgICAweEU4QjY6IDB4OTZEQyxcbiAgICAweEU4Qjc6IDB4OTcwRCxcbiAgICAweEU4Qjg6IDB4OTZENSxcbiAgICAweEU4Qjk6IDB4OTZGOSxcbiAgICAweEU4QkE6IDB4OTcwNCxcbiAgICAweEU4QkI6IDB4OTcwNixcbiAgICAweEU4QkM6IDB4OTcwOCxcbiAgICAweEU4QkQ6IDB4OTcxMyxcbiAgICAweEU4QkU6IDB4OTcwRSxcbiAgICAweEU4QkY6IDB4OTcxMSxcbiAgICAweEU4QzA6IDB4OTcwRixcbiAgICAweEU4QzE6IDB4OTcxNixcbiAgICAweEU4QzI6IDB4OTcxOSxcbiAgICAweEU4QzM6IDB4OTcyNCxcbiAgICAweEU4QzQ6IDB4OTcyQSxcbiAgICAweEU4QzU6IDB4OTczMCxcbiAgICAweEU4QzY6IDB4OTczOSxcbiAgICAweEU4Qzc6IDB4OTczRCxcbiAgICAweEU4Qzg6IDB4OTczRSxcbiAgICAweEU4Qzk6IDB4OTc0NCxcbiAgICAweEU4Q0E6IDB4OTc0NixcbiAgICAweEU4Q0I6IDB4OTc0OCxcbiAgICAweEU4Q0M6IDB4OTc0MixcbiAgICAweEU4Q0Q6IDB4OTc0OSxcbiAgICAweEU4Q0U6IDB4OTc1QyxcbiAgICAweEU4Q0Y6IDB4OTc2MCxcbiAgICAweEU4RDA6IDB4OTc2NCxcbiAgICAweEU4RDE6IDB4OTc2NixcbiAgICAweEU4RDI6IDB4OTc2OCxcbiAgICAweEU4RDM6IDB4NTJEMixcbiAgICAweEU4RDQ6IDB4OTc2QixcbiAgICAweEU4RDU6IDB4OTc3MSxcbiAgICAweEU4RDY6IDB4OTc3OSxcbiAgICAweEU4RDc6IDB4OTc4NSxcbiAgICAweEU4RDg6IDB4OTc3QyxcbiAgICAweEU4RDk6IDB4OTc4MSxcbiAgICAweEU4REE6IDB4OTc3QSxcbiAgICAweEU4REI6IDB4OTc4NixcbiAgICAweEU4REM6IDB4OTc4QixcbiAgICAweEU4REQ6IDB4OTc4RixcbiAgICAweEU4REU6IDB4OTc5MCxcbiAgICAweEU4REY6IDB4OTc5QyxcbiAgICAweEU4RTA6IDB4OTdBOCxcbiAgICAweEU4RTE6IDB4OTdBNixcbiAgICAweEU4RTI6IDB4OTdBMyxcbiAgICAweEU4RTM6IDB4OTdCMyxcbiAgICAweEU4RTQ6IDB4OTdCNCxcbiAgICAweEU4RTU6IDB4OTdDMyxcbiAgICAweEU4RTY6IDB4OTdDNixcbiAgICAweEU4RTc6IDB4OTdDOCxcbiAgICAweEU4RTg6IDB4OTdDQixcbiAgICAweEU4RTk6IDB4OTdEQyxcbiAgICAweEU4RUE6IDB4OTdFRCxcbiAgICAweEU4RUI6IDB4OUY0RixcbiAgICAweEU4RUM6IDB4OTdGMixcbiAgICAweEU4RUQ6IDB4N0FERixcbiAgICAweEU4RUU6IDB4OTdGNixcbiAgICAweEU4RUY6IDB4OTdGNSxcbiAgICAweEU4RjA6IDB4OTgwRixcbiAgICAweEU4RjE6IDB4OTgwQyxcbiAgICAweEU4RjI6IDB4OTgzOCxcbiAgICAweEU4RjM6IDB4OTgyNCxcbiAgICAweEU4RjQ6IDB4OTgyMSxcbiAgICAweEU4RjU6IDB4OTgzNyxcbiAgICAweEU4RjY6IDB4OTgzRCxcbiAgICAweEU4Rjc6IDB4OTg0NixcbiAgICAweEU4Rjg6IDB4OTg0RixcbiAgICAweEU4Rjk6IDB4OTg0QixcbiAgICAweEU4RkE6IDB4OTg2QixcbiAgICAweEU4RkI6IDB4OTg2RixcbiAgICAweEU4RkM6IDB4OTg3MCxcbiAgICAweEU5NDA6IDB4OTg3MSxcbiAgICAweEU5NDE6IDB4OTg3NCxcbiAgICAweEU5NDI6IDB4OTg3MyxcbiAgICAweEU5NDM6IDB4OThBQSxcbiAgICAweEU5NDQ6IDB4OThBRixcbiAgICAweEU5NDU6IDB4OThCMSxcbiAgICAweEU5NDY6IDB4OThCNixcbiAgICAweEU5NDc6IDB4OThDNCxcbiAgICAweEU5NDg6IDB4OThDMyxcbiAgICAweEU5NDk6IDB4OThDNixcbiAgICAweEU5NEE6IDB4OThFOSxcbiAgICAweEU5NEI6IDB4OThFQixcbiAgICAweEU5NEM6IDB4OTkwMyxcbiAgICAweEU5NEQ6IDB4OTkwOSxcbiAgICAweEU5NEU6IDB4OTkxMixcbiAgICAweEU5NEY6IDB4OTkxNCxcbiAgICAweEU5NTA6IDB4OTkxOCxcbiAgICAweEU5NTE6IDB4OTkyMSxcbiAgICAweEU5NTI6IDB4OTkxRCxcbiAgICAweEU5NTM6IDB4OTkxRSxcbiAgICAweEU5NTQ6IDB4OTkyNCxcbiAgICAweEU5NTU6IDB4OTkyMCxcbiAgICAweEU5NTY6IDB4OTkyQyxcbiAgICAweEU5NTc6IDB4OTkyRSxcbiAgICAweEU5NTg6IDB4OTkzRCxcbiAgICAweEU5NTk6IDB4OTkzRSxcbiAgICAweEU5NUE6IDB4OTk0MixcbiAgICAweEU5NUI6IDB4OTk0OSxcbiAgICAweEU5NUM6IDB4OTk0NSxcbiAgICAweEU5NUQ6IDB4OTk1MCxcbiAgICAweEU5NUU6IDB4OTk0QixcbiAgICAweEU5NUY6IDB4OTk1MSxcbiAgICAweEU5NjA6IDB4OTk1MixcbiAgICAweEU5NjE6IDB4OTk0QyxcbiAgICAweEU5NjI6IDB4OTk1NSxcbiAgICAweEU5NjM6IDB4OTk5NyxcbiAgICAweEU5NjQ6IDB4OTk5OCxcbiAgICAweEU5NjU6IDB4OTlBNSxcbiAgICAweEU5NjY6IDB4OTlBRCxcbiAgICAweEU5Njc6IDB4OTlBRSxcbiAgICAweEU5Njg6IDB4OTlCQyxcbiAgICAweEU5Njk6IDB4OTlERixcbiAgICAweEU5NkE6IDB4OTlEQixcbiAgICAweEU5NkI6IDB4OTlERCxcbiAgICAweEU5NkM6IDB4OTlEOCxcbiAgICAweEU5NkQ6IDB4OTlEMSxcbiAgICAweEU5NkU6IDB4OTlFRCxcbiAgICAweEU5NkY6IDB4OTlFRSxcbiAgICAweEU5NzA6IDB4OTlGMSxcbiAgICAweEU5NzE6IDB4OTlGMixcbiAgICAweEU5NzI6IDB4OTlGQixcbiAgICAweEU5NzM6IDB4OTlGOCxcbiAgICAweEU5NzQ6IDB4OUEwMSxcbiAgICAweEU5NzU6IDB4OUEwRixcbiAgICAweEU5NzY6IDB4OUEwNSxcbiAgICAweEU5Nzc6IDB4OTlFMixcbiAgICAweEU5Nzg6IDB4OUExOSxcbiAgICAweEU5Nzk6IDB4OUEyQixcbiAgICAweEU5N0E6IDB4OUEzNyxcbiAgICAweEU5N0I6IDB4OUE0NSxcbiAgICAweEU5N0M6IDB4OUE0MixcbiAgICAweEU5N0Q6IDB4OUE0MCxcbiAgICAweEU5N0U6IDB4OUE0MyxcbiAgICAweEU5ODA6IDB4OUEzRSxcbiAgICAweEU5ODE6IDB4OUE1NSxcbiAgICAweEU5ODI6IDB4OUE0RCxcbiAgICAweEU5ODM6IDB4OUE1QixcbiAgICAweEU5ODQ6IDB4OUE1NyxcbiAgICAweEU5ODU6IDB4OUE1RixcbiAgICAweEU5ODY6IDB4OUE2MixcbiAgICAweEU5ODc6IDB4OUE2NSxcbiAgICAweEU5ODg6IDB4OUE2NCxcbiAgICAweEU5ODk6IDB4OUE2OSxcbiAgICAweEU5OEE6IDB4OUE2QixcbiAgICAweEU5OEI6IDB4OUE2QSxcbiAgICAweEU5OEM6IDB4OUFBRCxcbiAgICAweEU5OEQ6IDB4OUFCMCxcbiAgICAweEU5OEU6IDB4OUFCQyxcbiAgICAweEU5OEY6IDB4OUFDMCxcbiAgICAweEU5OTA6IDB4OUFDRixcbiAgICAweEU5OTE6IDB4OUFEMSxcbiAgICAweEU5OTI6IDB4OUFEMyxcbiAgICAweEU5OTM6IDB4OUFENCxcbiAgICAweEU5OTQ6IDB4OUFERSxcbiAgICAweEU5OTU6IDB4OUFERixcbiAgICAweEU5OTY6IDB4OUFFMixcbiAgICAweEU5OTc6IDB4OUFFMyxcbiAgICAweEU5OTg6IDB4OUFFNixcbiAgICAweEU5OTk6IDB4OUFFRixcbiAgICAweEU5OUE6IDB4OUFFQixcbiAgICAweEU5OUI6IDB4OUFFRSxcbiAgICAweEU5OUM6IDB4OUFGNCxcbiAgICAweEU5OUQ6IDB4OUFGMSxcbiAgICAweEU5OUU6IDB4OUFGNyxcbiAgICAweEU5OUY6IDB4OUFGQixcbiAgICAweEU5QTA6IDB4OUIwNixcbiAgICAweEU5QTE6IDB4OUIxOCxcbiAgICAweEU5QTI6IDB4OUIxQSxcbiAgICAweEU5QTM6IDB4OUIxRixcbiAgICAweEU5QTQ6IDB4OUIyMixcbiAgICAweEU5QTU6IDB4OUIyMyxcbiAgICAweEU5QTY6IDB4OUIyNSxcbiAgICAweEU5QTc6IDB4OUIyNyxcbiAgICAweEU5QTg6IDB4OUIyOCxcbiAgICAweEU5QTk6IDB4OUIyOSxcbiAgICAweEU5QUE6IDB4OUIyQSxcbiAgICAweEU5QUI6IDB4OUIyRSxcbiAgICAweEU5QUM6IDB4OUIyRixcbiAgICAweEU5QUQ6IDB4OUIzMixcbiAgICAweEU5QUU6IDB4OUI0NCxcbiAgICAweEU5QUY6IDB4OUI0MyxcbiAgICAweEU5QjA6IDB4OUI0RixcbiAgICAweEU5QjE6IDB4OUI0RCxcbiAgICAweEU5QjI6IDB4OUI0RSxcbiAgICAweEU5QjM6IDB4OUI1MSxcbiAgICAweEU5QjQ6IDB4OUI1OCxcbiAgICAweEU5QjU6IDB4OUI3NCxcbiAgICAweEU5QjY6IDB4OUI5MyxcbiAgICAweEU5Qjc6IDB4OUI4MyxcbiAgICAweEU5Qjg6IDB4OUI5MSxcbiAgICAweEU5Qjk6IDB4OUI5NixcbiAgICAweEU5QkE6IDB4OUI5NyxcbiAgICAweEU5QkI6IDB4OUI5RixcbiAgICAweEU5QkM6IDB4OUJBMCxcbiAgICAweEU5QkQ6IDB4OUJBOCxcbiAgICAweEU5QkU6IDB4OUJCNCxcbiAgICAweEU5QkY6IDB4OUJDMCxcbiAgICAweEU5QzA6IDB4OUJDQSxcbiAgICAweEU5QzE6IDB4OUJCOSxcbiAgICAweEU5QzI6IDB4OUJDNixcbiAgICAweEU5QzM6IDB4OUJDRixcbiAgICAweEU5QzQ6IDB4OUJEMSxcbiAgICAweEU5QzU6IDB4OUJEMixcbiAgICAweEU5QzY6IDB4OUJFMyxcbiAgICAweEU5Qzc6IDB4OUJFMixcbiAgICAweEU5Qzg6IDB4OUJFNCxcbiAgICAweEU5Qzk6IDB4OUJENCxcbiAgICAweEU5Q0E6IDB4OUJFMSxcbiAgICAweEU5Q0I6IDB4OUMzQSxcbiAgICAweEU5Q0M6IDB4OUJGMixcbiAgICAweEU5Q0Q6IDB4OUJGMSxcbiAgICAweEU5Q0U6IDB4OUJGMCxcbiAgICAweEU5Q0Y6IDB4OUMxNSxcbiAgICAweEU5RDA6IDB4OUMxNCxcbiAgICAweEU5RDE6IDB4OUMwOSxcbiAgICAweEU5RDI6IDB4OUMxMyxcbiAgICAweEU5RDM6IDB4OUMwQyxcbiAgICAweEU5RDQ6IDB4OUMwNixcbiAgICAweEU5RDU6IDB4OUMwOCxcbiAgICAweEU5RDY6IDB4OUMxMixcbiAgICAweEU5RDc6IDB4OUMwQSxcbiAgICAweEU5RDg6IDB4OUMwNCxcbiAgICAweEU5RDk6IDB4OUMyRSxcbiAgICAweEU5REE6IDB4OUMxQixcbiAgICAweEU5REI6IDB4OUMyNSxcbiAgICAweEU5REM6IDB4OUMyNCxcbiAgICAweEU5REQ6IDB4OUMyMSxcbiAgICAweEU5REU6IDB4OUMzMCxcbiAgICAweEU5REY6IDB4OUM0NyxcbiAgICAweEU5RTA6IDB4OUMzMixcbiAgICAweEU5RTE6IDB4OUM0NixcbiAgICAweEU5RTI6IDB4OUMzRSxcbiAgICAweEU5RTM6IDB4OUM1QSxcbiAgICAweEU5RTQ6IDB4OUM2MCxcbiAgICAweEU5RTU6IDB4OUM2NyxcbiAgICAweEU5RTY6IDB4OUM3NixcbiAgICAweEU5RTc6IDB4OUM3OCxcbiAgICAweEU5RTg6IDB4OUNFNyxcbiAgICAweEU5RTk6IDB4OUNFQyxcbiAgICAweEU5RUE6IDB4OUNGMCxcbiAgICAweEU5RUI6IDB4OUQwOSxcbiAgICAweEU5RUM6IDB4OUQwOCxcbiAgICAweEU5RUQ6IDB4OUNFQixcbiAgICAweEU5RUU6IDB4OUQwMyxcbiAgICAweEU5RUY6IDB4OUQwNixcbiAgICAweEU5RjA6IDB4OUQyQSxcbiAgICAweEU5RjE6IDB4OUQyNixcbiAgICAweEU5RjI6IDB4OURBRixcbiAgICAweEU5RjM6IDB4OUQyMyxcbiAgICAweEU5RjQ6IDB4OUQxRixcbiAgICAweEU5RjU6IDB4OUQ0NCxcbiAgICAweEU5RjY6IDB4OUQxNSxcbiAgICAweEU5Rjc6IDB4OUQxMixcbiAgICAweEU5Rjg6IDB4OUQ0MSxcbiAgICAweEU5Rjk6IDB4OUQzRixcbiAgICAweEU5RkE6IDB4OUQzRSxcbiAgICAweEU5RkI6IDB4OUQ0NixcbiAgICAweEU5RkM6IDB4OUQ0OCxcbiAgICAweEVBNDA6IDB4OUQ1RCxcbiAgICAweEVBNDE6IDB4OUQ1RSxcbiAgICAweEVBNDI6IDB4OUQ2NCxcbiAgICAweEVBNDM6IDB4OUQ1MSxcbiAgICAweEVBNDQ6IDB4OUQ1MCxcbiAgICAweEVBNDU6IDB4OUQ1OSxcbiAgICAweEVBNDY6IDB4OUQ3MixcbiAgICAweEVBNDc6IDB4OUQ4OSxcbiAgICAweEVBNDg6IDB4OUQ4NyxcbiAgICAweEVBNDk6IDB4OURBQixcbiAgICAweEVBNEE6IDB4OUQ2RixcbiAgICAweEVBNEI6IDB4OUQ3QSxcbiAgICAweEVBNEM6IDB4OUQ5QSxcbiAgICAweEVBNEQ6IDB4OURBNCxcbiAgICAweEVBNEU6IDB4OURBOSxcbiAgICAweEVBNEY6IDB4OURCMixcbiAgICAweEVBNTA6IDB4OURDNCxcbiAgICAweEVBNTE6IDB4OURDMSxcbiAgICAweEVBNTI6IDB4OURCQixcbiAgICAweEVBNTM6IDB4OURCOCxcbiAgICAweEVBNTQ6IDB4OURCQSxcbiAgICAweEVBNTU6IDB4OURDNixcbiAgICAweEVBNTY6IDB4OURDRixcbiAgICAweEVBNTc6IDB4OURDMixcbiAgICAweEVBNTg6IDB4OUREOSxcbiAgICAweEVBNTk6IDB4OUREMyxcbiAgICAweEVBNUE6IDB4OURGOCxcbiAgICAweEVBNUI6IDB4OURFNixcbiAgICAweEVBNUM6IDB4OURFRCxcbiAgICAweEVBNUQ6IDB4OURFRixcbiAgICAweEVBNUU6IDB4OURGRCxcbiAgICAweEVBNUY6IDB4OUUxQSxcbiAgICAweEVBNjA6IDB4OUUxQixcbiAgICAweEVBNjE6IDB4OUUxRSxcbiAgICAweEVBNjI6IDB4OUU3NSxcbiAgICAweEVBNjM6IDB4OUU3OSxcbiAgICAweEVBNjQ6IDB4OUU3RCxcbiAgICAweEVBNjU6IDB4OUU4MSxcbiAgICAweEVBNjY6IDB4OUU4OCxcbiAgICAweEVBNjc6IDB4OUU4QixcbiAgICAweEVBNjg6IDB4OUU4QyxcbiAgICAweEVBNjk6IDB4OUU5MixcbiAgICAweEVBNkE6IDB4OUU5NSxcbiAgICAweEVBNkI6IDB4OUU5MSxcbiAgICAweEVBNkM6IDB4OUU5RCxcbiAgICAweEVBNkQ6IDB4OUVBNSxcbiAgICAweEVBNkU6IDB4OUVBOSxcbiAgICAweEVBNkY6IDB4OUVCOCxcbiAgICAweEVBNzA6IDB4OUVBQSxcbiAgICAweEVBNzE6IDB4OUVBRCxcbiAgICAweEVBNzI6IDB4OTc2MSxcbiAgICAweEVBNzM6IDB4OUVDQyxcbiAgICAweEVBNzQ6IDB4OUVDRSxcbiAgICAweEVBNzU6IDB4OUVDRixcbiAgICAweEVBNzY6IDB4OUVEMCxcbiAgICAweEVBNzc6IDB4OUVENCxcbiAgICAweEVBNzg6IDB4OUVEQyxcbiAgICAweEVBNzk6IDB4OUVERSxcbiAgICAweEVBN0E6IDB4OUVERCxcbiAgICAweEVBN0I6IDB4OUVFMCxcbiAgICAweEVBN0M6IDB4OUVFNSxcbiAgICAweEVBN0Q6IDB4OUVFOCxcbiAgICAweEVBN0U6IDB4OUVFRixcbiAgICAweEVBODA6IDB4OUVGNCxcbiAgICAweEVBODE6IDB4OUVGNixcbiAgICAweEVBODI6IDB4OUVGNyxcbiAgICAweEVBODM6IDB4OUVGOSxcbiAgICAweEVBODQ6IDB4OUVGQixcbiAgICAweEVBODU6IDB4OUVGQyxcbiAgICAweEVBODY6IDB4OUVGRCxcbiAgICAweEVBODc6IDB4OUYwNyxcbiAgICAweEVBODg6IDB4OUYwOCxcbiAgICAweEVBODk6IDB4NzZCNyxcbiAgICAweEVBOEE6IDB4OUYxNSxcbiAgICAweEVBOEI6IDB4OUYyMSxcbiAgICAweEVBOEM6IDB4OUYyQyxcbiAgICAweEVBOEQ6IDB4OUYzRSxcbiAgICAweEVBOEU6IDB4OUY0QSxcbiAgICAweEVBOEY6IDB4OUY1MixcbiAgICAweEVBOTA6IDB4OUY1NCxcbiAgICAweEVBOTE6IDB4OUY2MyxcbiAgICAweEVBOTI6IDB4OUY1RixcbiAgICAweEVBOTM6IDB4OUY2MCxcbiAgICAweEVBOTQ6IDB4OUY2MSxcbiAgICAweEVBOTU6IDB4OUY2NixcbiAgICAweEVBOTY6IDB4OUY2NyxcbiAgICAweEVBOTc6IDB4OUY2QyxcbiAgICAweEVBOTg6IDB4OUY2QSxcbiAgICAweEVBOTk6IDB4OUY3NyxcbiAgICAweEVBOUE6IDB4OUY3MixcbiAgICAweEVBOUI6IDB4OUY3NixcbiAgICAweEVBOUM6IDB4OUY5NSxcbiAgICAweEVBOUQ6IDB4OUY5QyxcbiAgICAweEVBOUU6IDB4OUZBMCxcbiAgICAweEVBOUY6IDB4NTgyRixcbiAgICAweEVBQTA6IDB4NjlDNyxcbiAgICAweEVBQTE6IDB4OTA1OSxcbiAgICAweEVBQTI6IDB4NzQ2NCxcbiAgICAweEVBQTM6IDB4NTFEQyxcbiAgICAweEVBQTQ6IDB4NzE5OSxcbn07XG5cblxuLyoqKi8gfSksXG4vKiA5ICovXG4vKioqLyAoZnVuY3Rpb24obW9kdWxlLCBleHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKSB7XG5cblwidXNlIHN0cmljdFwiO1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG52YXIgR2VuZXJpY0dGXzEgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKDEpO1xudmFyIEdlbmVyaWNHRlBvbHlfMSA9IF9fd2VicGFja19yZXF1aXJlX18oMik7XG5mdW5jdGlvbiBydW5FdWNsaWRlYW5BbGdvcml0aG0oZmllbGQsIGEsIGIsIFIpIHtcbiAgICB2YXIgX2E7XG4gICAgLy8gQXNzdW1lIGEncyBkZWdyZWUgaXMgPj0gYidzXG4gICAgaWYgKGEuZGVncmVlKCkgPCBiLmRlZ3JlZSgpKSB7XG4gICAgICAgIF9hID0gW2IsIGFdLCBhID0gX2FbMF0sIGIgPSBfYVsxXTtcbiAgICB9XG4gICAgdmFyIHJMYXN0ID0gYTtcbiAgICB2YXIgciA9IGI7XG4gICAgdmFyIHRMYXN0ID0gZmllbGQuemVybztcbiAgICB2YXIgdCA9IGZpZWxkLm9uZTtcbiAgICAvLyBSdW4gRXVjbGlkZWFuIGFsZ29yaXRobSB1bnRpbCByJ3MgZGVncmVlIGlzIGxlc3MgdGhhbiBSLzJcbiAgICB3aGlsZSAoci5kZWdyZWUoKSA+PSBSIC8gMikge1xuICAgICAgICB2YXIgckxhc3RMYXN0ID0gckxhc3Q7XG4gICAgICAgIHZhciB0TGFzdExhc3QgPSB0TGFzdDtcbiAgICAgICAgckxhc3QgPSByO1xuICAgICAgICB0TGFzdCA9IHQ7XG4gICAgICAgIC8vIERpdmlkZSByTGFzdExhc3QgYnkgckxhc3QsIHdpdGggcXVvdGllbnQgaW4gcSBhbmQgcmVtYWluZGVyIGluIHJcbiAgICAgICAgaWYgKHJMYXN0LmlzWmVybygpKSB7XG4gICAgICAgICAgICAvLyBFdWNsaWRlYW4gYWxnb3JpdGhtIGFscmVhZHkgdGVybWluYXRlZD9cbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHIgPSByTGFzdExhc3Q7XG4gICAgICAgIHZhciBxID0gZmllbGQuemVybztcbiAgICAgICAgdmFyIGRlbm9taW5hdG9yTGVhZGluZ1Rlcm0gPSByTGFzdC5nZXRDb2VmZmljaWVudChyTGFzdC5kZWdyZWUoKSk7XG4gICAgICAgIHZhciBkbHRJbnZlcnNlID0gZmllbGQuaW52ZXJzZShkZW5vbWluYXRvckxlYWRpbmdUZXJtKTtcbiAgICAgICAgd2hpbGUgKHIuZGVncmVlKCkgPj0gckxhc3QuZGVncmVlKCkgJiYgIXIuaXNaZXJvKCkpIHtcbiAgICAgICAgICAgIHZhciBkZWdyZWVEaWZmID0gci5kZWdyZWUoKSAtIHJMYXN0LmRlZ3JlZSgpO1xuICAgICAgICAgICAgdmFyIHNjYWxlID0gZmllbGQubXVsdGlwbHkoci5nZXRDb2VmZmljaWVudChyLmRlZ3JlZSgpKSwgZGx0SW52ZXJzZSk7XG4gICAgICAgICAgICBxID0gcS5hZGRPclN1YnRyYWN0KGZpZWxkLmJ1aWxkTW9ub21pYWwoZGVncmVlRGlmZiwgc2NhbGUpKTtcbiAgICAgICAgICAgIHIgPSByLmFkZE9yU3VidHJhY3Qockxhc3QubXVsdGlwbHlCeU1vbm9taWFsKGRlZ3JlZURpZmYsIHNjYWxlKSk7XG4gICAgICAgIH1cbiAgICAgICAgdCA9IHEubXVsdGlwbHlQb2x5KHRMYXN0KS5hZGRPclN1YnRyYWN0KHRMYXN0TGFzdCk7XG4gICAgICAgIGlmIChyLmRlZ3JlZSgpID49IHJMYXN0LmRlZ3JlZSgpKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgIH1cbiAgICB2YXIgc2lnbWFUaWxkZUF0WmVybyA9IHQuZ2V0Q29lZmZpY2llbnQoMCk7XG4gICAgaWYgKHNpZ21hVGlsZGVBdFplcm8gPT09IDApIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHZhciBpbnZlcnNlID0gZmllbGQuaW52ZXJzZShzaWdtYVRpbGRlQXRaZXJvKTtcbiAgICByZXR1cm4gW3QubXVsdGlwbHkoaW52ZXJzZSksIHIubXVsdGlwbHkoaW52ZXJzZSldO1xufVxuZnVuY3Rpb24gZmluZEVycm9yTG9jYXRpb25zKGZpZWxkLCBlcnJvckxvY2F0b3IpIHtcbiAgICAvLyBUaGlzIGlzIGEgZGlyZWN0IGFwcGxpY2F0aW9uIG9mIENoaWVuJ3Mgc2VhcmNoXG4gICAgdmFyIG51bUVycm9ycyA9IGVycm9yTG9jYXRvci5kZWdyZWUoKTtcbiAgICBpZiAobnVtRXJyb3JzID09PSAxKSB7XG4gICAgICAgIHJldHVybiBbZXJyb3JMb2NhdG9yLmdldENvZWZmaWNpZW50KDEpXTtcbiAgICB9XG4gICAgdmFyIHJlc3VsdCA9IG5ldyBBcnJheShudW1FcnJvcnMpO1xuICAgIHZhciBlcnJvckNvdW50ID0gMDtcbiAgICBmb3IgKHZhciBpID0gMTsgaSA8IGZpZWxkLnNpemUgJiYgZXJyb3JDb3VudCA8IG51bUVycm9yczsgaSsrKSB7XG4gICAgICAgIGlmIChlcnJvckxvY2F0b3IuZXZhbHVhdGVBdChpKSA9PT0gMCkge1xuICAgICAgICAgICAgcmVzdWx0W2Vycm9yQ291bnRdID0gZmllbGQuaW52ZXJzZShpKTtcbiAgICAgICAgICAgIGVycm9yQ291bnQrKztcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoZXJyb3JDb3VudCAhPT0gbnVtRXJyb3JzKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gZmluZEVycm9yTWFnbml0dWRlcyhmaWVsZCwgZXJyb3JFdmFsdWF0b3IsIGVycm9yTG9jYXRpb25zKSB7XG4gICAgLy8gVGhpcyBpcyBkaXJlY3RseSBhcHBseWluZyBGb3JuZXkncyBGb3JtdWxhXG4gICAgdmFyIHMgPSBlcnJvckxvY2F0aW9ucy5sZW5ndGg7XG4gICAgdmFyIHJlc3VsdCA9IG5ldyBBcnJheShzKTtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHM7IGkrKykge1xuICAgICAgICB2YXIgeGlJbnZlcnNlID0gZmllbGQuaW52ZXJzZShlcnJvckxvY2F0aW9uc1tpXSk7XG4gICAgICAgIHZhciBkZW5vbWluYXRvciA9IDE7XG4gICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgczsgaisrKSB7XG4gICAgICAgICAgICBpZiAoaSAhPT0gaikge1xuICAgICAgICAgICAgICAgIGRlbm9taW5hdG9yID0gZmllbGQubXVsdGlwbHkoZGVub21pbmF0b3IsIEdlbmVyaWNHRl8xLmFkZE9yU3VidHJhY3RHRigxLCBmaWVsZC5tdWx0aXBseShlcnJvckxvY2F0aW9uc1tqXSwgeGlJbnZlcnNlKSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJlc3VsdFtpXSA9IGZpZWxkLm11bHRpcGx5KGVycm9yRXZhbHVhdG9yLmV2YWx1YXRlQXQoeGlJbnZlcnNlKSwgZmllbGQuaW52ZXJzZShkZW5vbWluYXRvcikpO1xuICAgICAgICBpZiAoZmllbGQuZ2VuZXJhdG9yQmFzZSAhPT0gMCkge1xuICAgICAgICAgICAgcmVzdWx0W2ldID0gZmllbGQubXVsdGlwbHkocmVzdWx0W2ldLCB4aUludmVyc2UpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBkZWNvZGUoYnl0ZXMsIHR3b1MpIHtcbiAgICB2YXIgb3V0cHV0Qnl0ZXMgPSBuZXcgVWludDhDbGFtcGVkQXJyYXkoYnl0ZXMubGVuZ3RoKTtcbiAgICBvdXRwdXRCeXRlcy5zZXQoYnl0ZXMpO1xuICAgIHZhciBmaWVsZCA9IG5ldyBHZW5lcmljR0ZfMS5kZWZhdWx0KDB4MDExRCwgMjU2LCAwKTsgLy8geF44ICsgeF40ICsgeF4zICsgeF4yICsgMVxuICAgIHZhciBwb2x5ID0gbmV3IEdlbmVyaWNHRlBvbHlfMS5kZWZhdWx0KGZpZWxkLCBvdXRwdXRCeXRlcyk7XG4gICAgdmFyIHN5bmRyb21lQ29lZmZpY2llbnRzID0gbmV3IFVpbnQ4Q2xhbXBlZEFycmF5KHR3b1MpO1xuICAgIHZhciBlcnJvciA9IGZhbHNlO1xuICAgIGZvciAodmFyIHMgPSAwOyBzIDwgdHdvUzsgcysrKSB7XG4gICAgICAgIHZhciBldmFsdWF0aW9uID0gcG9seS5ldmFsdWF0ZUF0KGZpZWxkLmV4cChzICsgZmllbGQuZ2VuZXJhdG9yQmFzZSkpO1xuICAgICAgICBzeW5kcm9tZUNvZWZmaWNpZW50c1tzeW5kcm9tZUNvZWZmaWNpZW50cy5sZW5ndGggLSAxIC0gc10gPSBldmFsdWF0aW9uO1xuICAgICAgICBpZiAoZXZhbHVhdGlvbiAhPT0gMCkge1xuICAgICAgICAgICAgZXJyb3IgPSB0cnVlO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmICghZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIG91dHB1dEJ5dGVzO1xuICAgIH1cbiAgICB2YXIgc3luZHJvbWUgPSBuZXcgR2VuZXJpY0dGUG9seV8xLmRlZmF1bHQoZmllbGQsIHN5bmRyb21lQ29lZmZpY2llbnRzKTtcbiAgICB2YXIgc2lnbWFPbWVnYSA9IHJ1bkV1Y2xpZGVhbkFsZ29yaXRobShmaWVsZCwgZmllbGQuYnVpbGRNb25vbWlhbCh0d29TLCAxKSwgc3luZHJvbWUsIHR3b1MpO1xuICAgIGlmIChzaWdtYU9tZWdhID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICB2YXIgZXJyb3JMb2NhdGlvbnMgPSBmaW5kRXJyb3JMb2NhdGlvbnMoZmllbGQsIHNpZ21hT21lZ2FbMF0pO1xuICAgIGlmIChlcnJvckxvY2F0aW9ucyA9PSBudWxsKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICB2YXIgZXJyb3JNYWduaXR1ZGVzID0gZmluZEVycm9yTWFnbml0dWRlcyhmaWVsZCwgc2lnbWFPbWVnYVsxXSwgZXJyb3JMb2NhdGlvbnMpO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZXJyb3JMb2NhdGlvbnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgdmFyIHBvc2l0aW9uID0gb3V0cHV0Qnl0ZXMubGVuZ3RoIC0gMSAtIGZpZWxkLmxvZyhlcnJvckxvY2F0aW9uc1tpXSk7XG4gICAgICAgIGlmIChwb3NpdGlvbiA8IDApIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIG91dHB1dEJ5dGVzW3Bvc2l0aW9uXSA9IEdlbmVyaWNHRl8xLmFkZE9yU3VidHJhY3RHRihvdXRwdXRCeXRlc1twb3NpdGlvbl0sIGVycm9yTWFnbml0dWRlc1tpXSk7XG4gICAgfVxuICAgIHJldHVybiBvdXRwdXRCeXRlcztcbn1cbmV4cG9ydHMuZGVjb2RlID0gZGVjb2RlO1xuXG5cbi8qKiovIH0pLFxuLyogMTAgKi9cbi8qKiovIChmdW5jdGlvbihtb2R1bGUsIGV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pIHtcblxuXCJ1c2Ugc3RyaWN0XCI7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuVkVSU0lPTlMgPSBbXG4gICAge1xuICAgICAgICBpbmZvQml0czogbnVsbCxcbiAgICAgICAgdmVyc2lvbk51bWJlcjogMSxcbiAgICAgICAgYWxpZ25tZW50UGF0dGVybkNlbnRlcnM6IFtdLFxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbHM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiA3LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbeyBudW1CbG9ja3M6IDEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTkgfV0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDEwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbeyBudW1CbG9ja3M6IDEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTYgfV0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDEzLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbeyBudW1CbG9ja3M6IDEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTMgfV0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDE3LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbeyBudW1CbG9ja3M6IDEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogOSB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGluZm9CaXRzOiBudWxsLFxuICAgICAgICB2ZXJzaW9uTnVtYmVyOiAyLFxuICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczogWzYsIDE4XSxcbiAgICAgICAgZXJyb3JDb3JyZWN0aW9uTGV2ZWxzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMTAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAzNCB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMTYsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyOCB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjIsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyMiB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjgsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNiB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGluZm9CaXRzOiBudWxsLFxuICAgICAgICB2ZXJzaW9uTnVtYmVyOiAzLFxuICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczogWzYsIDIyXSxcbiAgICAgICAgZXJyb3JDb3JyZWN0aW9uTGV2ZWxzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMTUsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA1NSB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjYsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NCB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMTgsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNyB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjIsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMyB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGluZm9CaXRzOiBudWxsLFxuICAgICAgICB2ZXJzaW9uTnVtYmVyOiA0LFxuICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczogWzYsIDI2XSxcbiAgICAgICAgZXJyb3JDb3JyZWN0aW9uTGV2ZWxzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA4MCB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMTgsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAzMiB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjYsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyNCB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMTYsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA5IH1dLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgaW5mb0JpdHM6IG51bGwsXG4gICAgICAgIHZlcnNpb25OdW1iZXI6IDUsXG4gICAgICAgIGFsaWdubWVudFBhdHRlcm5DZW50ZXJzOiBbNiwgMzBdLFxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbHM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyNixcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW3sgbnVtQmxvY2tzOiAxLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDEwOCB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjQsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0MyB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMTgsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDIsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDIsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTYgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyMixcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMiB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBpbmZvQml0czogbnVsbCxcbiAgICAgICAgdmVyc2lvbk51bWJlcjogNixcbiAgICAgICAgYWxpZ25tZW50UGF0dGVybkNlbnRlcnM6IFs2LCAzNF0sXG4gICAgICAgIGVycm9yQ29ycmVjdGlvbkxldmVsczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDE4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbeyBudW1CbG9ja3M6IDIsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNjggfV0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDE2LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbeyBudW1CbG9ja3M6IDQsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjcgfV0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI0LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbeyBudW1CbG9ja3M6IDQsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTkgfV0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbeyBudW1CbG9ja3M6IDQsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTUgfV0sXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBpbmZvQml0czogMHgwN0M5NCxcbiAgICAgICAgdmVyc2lvbk51bWJlcjogNyxcbiAgICAgICAgYWxpZ25tZW50UGF0dGVybkNlbnRlcnM6IFs2LCAyMiwgMzhdLFxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbHM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW3sgbnVtQmxvY2tzOiAyLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDc4IH1dLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAxOCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW3sgbnVtQmxvY2tzOiA0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDMxIH1dLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAxOCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNCB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNSB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI2LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDEzIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDE0IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGluZm9CaXRzOiAweDA4NUJDLFxuICAgICAgICB2ZXJzaW9uTnVtYmVyOiA4LFxuICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczogWzYsIDI0LCA0Ml0sXG4gICAgICAgIGVycm9yQ29ycmVjdGlvbkxldmVsczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI0LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbeyBudW1CbG9ja3M6IDIsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogOTcgfV0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDIyLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDM4IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDM5IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjIsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDQsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTggfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDIsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTkgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyNixcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNCB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNSB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBpbmZvQml0czogMHgwOUE5OSxcbiAgICAgICAgdmVyc2lvbk51bWJlcjogOSxcbiAgICAgICAgYWxpZ25tZW50UGF0dGVybkNlbnRlcnM6IFs2LCAyNiwgNDZdLFxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbHM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW3sgbnVtQmxvY2tzOiAyLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDExNiB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjIsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDMsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMzYgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDIsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMzcgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNiB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI0LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDEyIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDEzIH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGluZm9CaXRzOiAweDBBNEQzLFxuICAgICAgICB2ZXJzaW9uTnVtYmVyOiAxMCxcbiAgICAgICAgYWxpZ25tZW50UGF0dGVybkNlbnRlcnM6IFs2LCAyOCwgNTBdLFxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbHM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAxOCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA2OCB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA2OSB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI2LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQzIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQ0IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjQsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDYsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTkgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDIsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjAgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyOCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNiB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBpbmZvQml0czogMHgwQkJGNixcbiAgICAgICAgdmVyc2lvbk51bWJlcjogMTEsXG4gICAgICAgIGFsaWdubWVudFBhdHRlcm5DZW50ZXJzOiBbNiwgMzAsIDU0XSxcbiAgICAgICAgZXJyb3JDb3JyZWN0aW9uTGV2ZWxzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA4MSB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNTAgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDQsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNTEgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyOCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyMiB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyMyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI0LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAzLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDEyIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA4LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDEzIH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGluZm9CaXRzOiAweDBDNzYyLFxuICAgICAgICB2ZXJzaW9uTnVtYmVyOiAxMixcbiAgICAgICAgYWxpZ25tZW50UGF0dGVybkNlbnRlcnM6IFs2LCAzMiwgNThdLFxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbHM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyNCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA5MiB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA5MyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDIyLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA2LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDM2IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDM3IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjYsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDQsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjAgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDYsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjEgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyOCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNCB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNSB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBpbmZvQml0czogMHgwRDg0NyxcbiAgICAgICAgdmVyc2lvbk51bWJlcjogMTMsXG4gICAgICAgIGFsaWdubWVudFBhdHRlcm5DZW50ZXJzOiBbNiwgMzQsIDYyXSxcbiAgICAgICAgZXJyb3JDb3JyZWN0aW9uTGV2ZWxzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjYsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMDcgfV0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDIyLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA4LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDM3IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDM4IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjQsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDgsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjAgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDQsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjEgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyMixcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTIsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTEgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDQsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTIgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgaW5mb0JpdHM6IDB4MEU2MEQsXG4gICAgICAgIHZlcnNpb25OdW1iZXI6IDE0LFxuICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczogWzYsIDI2LCA0NiwgNjZdLFxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbHM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMTUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTE2IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjQsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDQsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNDAgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDUsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNDEgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTYgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDUsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTcgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyNCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTIgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDUsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTMgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgaW5mb0JpdHM6IDB4MEY5MjgsXG4gICAgICAgIHZlcnNpb25OdW1iZXI6IDE1LFxuICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczogWzYsIDI2LCA0OCwgNzBdLFxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbHM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyMixcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA4NyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA4OCB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI0LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA1LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQxIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA1LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQyIH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDUsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjQgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDcsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjUgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyNCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTIgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDcsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTMgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgaW5mb0JpdHM6IDB4MTBCNzgsXG4gICAgICAgIHZlcnNpb25OdW1iZXI6IDE2LFxuICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczogWzYsIDI2LCA1MCwgNzRdLFxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbHM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyNCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA5OCB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA5OSB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA3LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQ1IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAzLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQ2IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjQsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDE1LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDE5IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDIwIH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDMsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDEzLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDE2IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGluZm9CaXRzOiAweDExNDVELFxuICAgICAgICB2ZXJzaW9uTnVtYmVyOiAxNyxcbiAgICAgICAgYWxpZ25tZW50UGF0dGVybkNlbnRlcnM6IFs2LCAzMCwgNTQsIDc4XSxcbiAgICAgICAgZXJyb3JDb3JyZWN0aW9uTGV2ZWxzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjgsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTA3IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA1LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDEwOCB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxMCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NiB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDIyIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxNSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyMyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDE0IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxNywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNSB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBpbmZvQml0czogMHgxMkExNyxcbiAgICAgICAgdmVyc2lvbk51bWJlcjogMTgsXG4gICAgICAgIGFsaWdubWVudFBhdHRlcm5DZW50ZXJzOiBbNiwgMzAsIDU2LCA4Ml0sXG4gICAgICAgIGVycm9yQ29ycmVjdGlvbkxldmVsczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA1LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDEyMCB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMjEgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyNixcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogOSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0MyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NCB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxNywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyMiB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyMyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDE0IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxOSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNSB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBpbmZvQml0czogMHgxMzUzMixcbiAgICAgICAgdmVyc2lvbk51bWJlcjogMTksXG4gICAgICAgIGFsaWdubWVudFBhdHRlcm5DZW50ZXJzOiBbNiwgMzAsIDU4LCA4Nl0sXG4gICAgICAgIGVycm9yQ29ycmVjdGlvbkxldmVsczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAzLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDExMyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMTQgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyNixcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NCB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNDUgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyNixcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTcsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjEgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDQsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjIgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyNixcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogOSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTYsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTQgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgaW5mb0JpdHM6IDB4MTQ5QTYsXG4gICAgICAgIHZlcnNpb25OdW1iZXI6IDIwLFxuICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczogWzYsIDM0LCA2MiwgOTBdLFxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbHM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyOCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMDcgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDUsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTA4IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjYsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDMsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNDEgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDEzLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQyIH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDE1LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDI0IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA1LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDI1IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjgsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDE1LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDE1IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxMCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNiB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBpbmZvQml0czogMHgxNTY4MyxcbiAgICAgICAgdmVyc2lvbk51bWJlcjogMjEsXG4gICAgICAgIGFsaWdubWVudFBhdHRlcm5DZW50ZXJzOiBbNiwgMjgsIDUwLCA3MiwgOTRdLFxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbHM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyOCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMTYgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDQsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTE3IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjYsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogMTcsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNDIgfV0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxNywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyMiB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyMyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxOSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNiB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBpbmZvQml0czogMHgxNjhDOSxcbiAgICAgICAgdmVyc2lvbk51bWJlcjogMjIsXG4gICAgICAgIGFsaWdubWVudFBhdHRlcm5DZW50ZXJzOiBbNiwgMjYsIDUwLCA3NCwgOThdLFxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbHM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyOCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMTEgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDcsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTEyIH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjgsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFt7IG51bUJsb2NrczogMTcsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNDYgfV0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA3LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDI0IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxNiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyNSB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI0LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbeyBudW1CbG9ja3M6IDM0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDEzIH1dLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgaW5mb0JpdHM6IDB4MTc3RUMsXG4gICAgICAgIHZlcnNpb25OdW1iZXI6IDIzLFxuICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczogWzYsIDMwLCA1NCwgNzQsIDEwMl0sXG4gICAgICAgIGVycm9yQ29ycmVjdGlvbkxldmVsczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDEyMSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMjIgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyOCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTQsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNDggfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjQgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDE0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDI1IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDE2LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDE1IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNiB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBpbmZvQml0czogMHgxOEVDNCxcbiAgICAgICAgdmVyc2lvbk51bWJlcjogMjQsXG4gICAgICAgIGFsaWdubWVudFBhdHRlcm5DZW50ZXJzOiBbNiwgMjgsIDU0LCA4MCwgMTA2XSxcbiAgICAgICAgZXJyb3JDb3JyZWN0aW9uTGV2ZWxzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDYsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTE3IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDExOCB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA2LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQ1IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NiB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyNCB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTYsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjUgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMzAsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTYgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDIsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTcgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgaW5mb0JpdHM6IDB4MTkxRTEsXG4gICAgICAgIHZlcnNpb25OdW1iZXI6IDI1LFxuICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczogWzYsIDMyLCA1OCwgODQsIDExMF0sXG4gICAgICAgIGVycm9yQ29ycmVjdGlvbkxldmVsczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI2LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA4LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDEwNiB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMDcgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyOCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogOCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTMsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNDggfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyNCB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMjIsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjUgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMjIsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDEzLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDE2IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGluZm9CaXRzOiAweDFBRkFCLFxuICAgICAgICB2ZXJzaW9uTnVtYmVyOiAyNixcbiAgICAgICAgYWxpZ25tZW50UGF0dGVybkNlbnRlcnM6IFs2LCAzMCwgNTgsIDg2LCAxMTRdLFxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbHM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyOCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTAsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTE0IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDExNSB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxOSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NiB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyOCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyMiB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyMyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAzMywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNiB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBpbmZvQml0czogMHgxQjA4RSxcbiAgICAgICAgdmVyc2lvbk51bWJlcjogMjcsXG4gICAgICAgIGFsaWdubWVudFBhdHRlcm5DZW50ZXJzOiBbNiwgMzQsIDYyLCA5MCwgMTE4XSxcbiAgICAgICAgZXJyb3JDb3JyZWN0aW9uTGV2ZWxzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDgsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTIyIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDEyMyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NiB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA4LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDIzIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyNiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyNCB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMjgsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTYgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgaW5mb0JpdHM6IDB4MUNDMUEsXG4gICAgICAgIHZlcnNpb25OdW1iZXI6IDI4LFxuICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczogWzYsIDI2LCA1MCwgNzQsIDk4LCAxMjJdLFxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbHM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMTcgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDEwLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDExOCB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAzLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQ1IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyMywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NiB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDI0IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAzMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyNSB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMzEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTYgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgaW5mb0JpdHM6IDB4MUQzM0YsXG4gICAgICAgIHZlcnNpb25OdW1iZXI6IDI5LFxuICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczogWzYsIDMwLCA1NCwgNzgsIDEwMiwgMTI2XSxcbiAgICAgICAgZXJyb3JDb3JyZWN0aW9uTGV2ZWxzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDcsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTE2IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA3LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDExNyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NiB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDIzIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAzNywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyNCB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxOSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMjYsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTYgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgaW5mb0JpdHM6IDB4MUVENzUsXG4gICAgICAgIHZlcnNpb25OdW1iZXI6IDMwLFxuICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczogWzYsIDI2LCA1MiwgNzgsIDEwNCwgMTMwXSxcbiAgICAgICAgZXJyb3JDb3JyZWN0aW9uTGV2ZWxzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDUsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTE1IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxMCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMTYgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyOCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTksIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNDcgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDEwLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQ4IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDE1LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDI0IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyNSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyNSB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyMywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMjUsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTYgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgaW5mb0JpdHM6IDB4MUYyNTAsXG4gICAgICAgIHZlcnNpb25OdW1iZXI6IDMxLFxuICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczogWzYsIDMwLCA1NiwgODIsIDEwOCwgMTM0XSxcbiAgICAgICAgZXJyb3JDb3JyZWN0aW9uTGV2ZWxzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDEzLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDExNSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMTYgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyOCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NiB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMjksIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNDcgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNDIsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjQgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjUgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMjMsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDI4LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDE2IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGluZm9CaXRzOiAweDIwOUQ1LFxuICAgICAgICB2ZXJzaW9uTnVtYmVyOiAzMixcbiAgICAgICAgYWxpZ25tZW50UGF0dGVybkNlbnRlcnM6IFs2LCAzNCwgNjAsIDg2LCAxMTIsIDEzOF0sXG4gICAgICAgIGVycm9yQ29ycmVjdGlvbkxldmVsczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbeyBudW1CbG9ja3M6IDE3LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDExNSB9XSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjgsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDEwLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQ2IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyMywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxMCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyNCB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMzUsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjUgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTksIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDM1LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDE2IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGluZm9CaXRzOiAweDIxNkYwLFxuICAgICAgICB2ZXJzaW9uTnVtYmVyOiAzMyxcbiAgICAgICAgYWxpZ25tZW50UGF0dGVybkNlbnRlcnM6IFs2LCAzMCwgNTgsIDg2LCAxMTQsIDE0Ml0sXG4gICAgICAgIGVycm9yQ29ycmVjdGlvbkxldmVsczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxNywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMTUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTE2IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjgsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDE0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQ2IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyOSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyNCB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTksIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjUgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDQ2LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDE2IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGluZm9CaXRzOiAweDIyOEJBLFxuICAgICAgICB2ZXJzaW9uTnVtYmVyOiAzNCxcbiAgICAgICAgYWxpZ25tZW50UGF0dGVybkNlbnRlcnM6IFs2LCAzNCwgNjIsIDkwLCAxMTgsIDE0Nl0sXG4gICAgICAgIGVycm9yQ29ycmVjdGlvbkxldmVsczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxMywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMTUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDYsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTE2IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjgsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDE0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQ2IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyMywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA0NCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyNCB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyNSB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA1OSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNiB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBpbmZvQml0czogMHgyMzc5RixcbiAgICAgICAgdmVyc2lvbk51bWJlcjogMzUsXG4gICAgICAgIGFsaWdubWVudFBhdHRlcm5DZW50ZXJzOiBbNiwgMzAsIDU0LCA3OCwgMTAyLCAxMjYsIDE1MF0sXG4gICAgICAgIGVycm9yQ29ycmVjdGlvbkxldmVsczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMjEgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDcsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTIyIH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjgsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDEyLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQ3IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyNiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0OCB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAzOSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyNCB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTQsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjUgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMjIsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDQxLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDE2IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGluZm9CaXRzOiAweDI0QjBCLFxuICAgICAgICB2ZXJzaW9uTnVtYmVyOiAzNixcbiAgICAgICAgYWxpZ25tZW50UGF0dGVybkNlbnRlcnM6IFs2LCAyNCwgNTAsIDc2LCAxMDIsIDEyOCwgMTU0XSxcbiAgICAgICAgZXJyb3JDb3JyZWN0aW9uTGV2ZWxzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDYsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTIxIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMjIgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyOCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMzQsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNDggfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNDYsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjQgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDEwLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDI1IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDIsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDY0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDE2IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGluZm9CaXRzOiAweDI1NDJFLFxuICAgICAgICB2ZXJzaW9uTnVtYmVyOiAzNyxcbiAgICAgICAgYWxpZ25tZW50UGF0dGVybkNlbnRlcnM6IFs2LCAyOCwgNTQsIDgwLCAxMDYsIDEzMiwgMTU4XSxcbiAgICAgICAgZXJyb3JDb3JyZWN0aW9uTGV2ZWxzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDE3LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDEyMiB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMjMgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAyOCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMjksIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNDYgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDE0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQ3IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDQ5LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDI0IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxMCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyNSB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNDYsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTYgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgaW5mb0JpdHM6IDB4MjZBNjQsXG4gICAgICAgIHZlcnNpb25OdW1iZXI6IDM4LFxuICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczogWzYsIDMyLCA1OCwgODQsIDExMCwgMTM2LCAxNjJdLFxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbHM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMjIgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDE4LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDEyMyB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxMywgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NiB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMzIsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNDcgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNDgsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjQgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDE0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDI1IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDQyLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDE1IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAzMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNiB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAge1xuICAgICAgICBpbmZvQml0czogMHgyNzU0MSxcbiAgICAgICAgdmVyc2lvbk51bWJlcjogMzksXG4gICAgICAgIGFsaWdubWVudFBhdHRlcm5DZW50ZXJzOiBbNiwgMjYsIDU0LCA4MiwgMTEwLCAxMzgsIDE2Nl0sXG4gICAgICAgIGVycm9yQ29ycmVjdGlvbkxldmVsczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyMCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxMTcgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDQsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTE4IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMjgsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDQwLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQ3IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA3LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDQ4IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDQzLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDI0IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAyMiwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAyNSB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDMwLFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxMCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNSB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogNjcsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTYgfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgaW5mb0JpdHM6IDB4MjhDNjksXG4gICAgICAgIHZlcnNpb25OdW1iZXI6IDQwLFxuICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuQ2VudGVyczogWzYsIDMwLCA1OCwgODYsIDExNCwgMTQyLCAxNzBdLFxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbHM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMTksIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMTE4IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA2LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDExOSB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGVjQ29kZXdvcmRzUGVyQmxvY2s6IDI4LFxuICAgICAgICAgICAgICAgIGVjQmxvY2tzOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiAxOCwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiA0NyB9LFxuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMzEsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogNDggfSxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBlY0NvZGV3b3Jkc1BlckJsb2NrOiAzMCxcbiAgICAgICAgICAgICAgICBlY0Jsb2NrczogW1xuICAgICAgICAgICAgICAgICAgICB7IG51bUJsb2NrczogMzQsIGRhdGFDb2Rld29yZHNQZXJCbG9jazogMjQgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDM0LCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDI1IH0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZWNDb2Rld29yZHNQZXJCbG9jazogMzAsXG4gICAgICAgICAgICAgICAgZWNCbG9ja3M6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBudW1CbG9ja3M6IDIwLCBkYXRhQ29kZXdvcmRzUGVyQmxvY2s6IDE1IH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbnVtQmxvY2tzOiA2MSwgZGF0YUNvZGV3b3Jkc1BlckJsb2NrOiAxNiB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgIH0sXG5dO1xuXG5cbi8qKiovIH0pLFxuLyogMTEgKi9cbi8qKiovIChmdW5jdGlvbihtb2R1bGUsIGV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pIHtcblxuXCJ1c2Ugc3RyaWN0XCI7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbnZhciBCaXRNYXRyaXhfMSA9IF9fd2VicGFja19yZXF1aXJlX18oMCk7XG5mdW5jdGlvbiBzcXVhcmVUb1F1YWRyaWxhdGVyYWwocDEsIHAyLCBwMywgcDQpIHtcbiAgICB2YXIgZHgzID0gcDEueCAtIHAyLnggKyBwMy54IC0gcDQueDtcbiAgICB2YXIgZHkzID0gcDEueSAtIHAyLnkgKyBwMy55IC0gcDQueTtcbiAgICBpZiAoZHgzID09PSAwICYmIGR5MyA9PT0gMCkgeyAvLyBBZmZpbmVcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGExMTogcDIueCAtIHAxLngsXG4gICAgICAgICAgICBhMTI6IHAyLnkgLSBwMS55LFxuICAgICAgICAgICAgYTEzOiAwLFxuICAgICAgICAgICAgYTIxOiBwMy54IC0gcDIueCxcbiAgICAgICAgICAgIGEyMjogcDMueSAtIHAyLnksXG4gICAgICAgICAgICBhMjM6IDAsXG4gICAgICAgICAgICBhMzE6IHAxLngsXG4gICAgICAgICAgICBhMzI6IHAxLnksXG4gICAgICAgICAgICBhMzM6IDEsXG4gICAgICAgIH07XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICB2YXIgZHgxID0gcDIueCAtIHAzLng7XG4gICAgICAgIHZhciBkeDIgPSBwNC54IC0gcDMueDtcbiAgICAgICAgdmFyIGR5MSA9IHAyLnkgLSBwMy55O1xuICAgICAgICB2YXIgZHkyID0gcDQueSAtIHAzLnk7XG4gICAgICAgIHZhciBkZW5vbWluYXRvciA9IGR4MSAqIGR5MiAtIGR4MiAqIGR5MTtcbiAgICAgICAgdmFyIGExMyA9IChkeDMgKiBkeTIgLSBkeDIgKiBkeTMpIC8gZGVub21pbmF0b3I7XG4gICAgICAgIHZhciBhMjMgPSAoZHgxICogZHkzIC0gZHgzICogZHkxKSAvIGRlbm9taW5hdG9yO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgYTExOiBwMi54IC0gcDEueCArIGExMyAqIHAyLngsXG4gICAgICAgICAgICBhMTI6IHAyLnkgLSBwMS55ICsgYTEzICogcDIueSxcbiAgICAgICAgICAgIGExMzogYTEzLFxuICAgICAgICAgICAgYTIxOiBwNC54IC0gcDEueCArIGEyMyAqIHA0LngsXG4gICAgICAgICAgICBhMjI6IHA0LnkgLSBwMS55ICsgYTIzICogcDQueSxcbiAgICAgICAgICAgIGEyMzogYTIzLFxuICAgICAgICAgICAgYTMxOiBwMS54LFxuICAgICAgICAgICAgYTMyOiBwMS55LFxuICAgICAgICAgICAgYTMzOiAxLFxuICAgICAgICB9O1xuICAgIH1cbn1cbmZ1bmN0aW9uIHF1YWRyaWxhdGVyYWxUb1NxdWFyZShwMSwgcDIsIHAzLCBwNCkge1xuICAgIC8vIEhlcmUsIHRoZSBhZGpvaW50IHNlcnZlcyBhcyB0aGUgaW52ZXJzZTpcbiAgICB2YXIgc1RvUSA9IHNxdWFyZVRvUXVhZHJpbGF0ZXJhbChwMSwgcDIsIHAzLCBwNCk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgYTExOiBzVG9RLmEyMiAqIHNUb1EuYTMzIC0gc1RvUS5hMjMgKiBzVG9RLmEzMixcbiAgICAgICAgYTEyOiBzVG9RLmExMyAqIHNUb1EuYTMyIC0gc1RvUS5hMTIgKiBzVG9RLmEzMyxcbiAgICAgICAgYTEzOiBzVG9RLmExMiAqIHNUb1EuYTIzIC0gc1RvUS5hMTMgKiBzVG9RLmEyMixcbiAgICAgICAgYTIxOiBzVG9RLmEyMyAqIHNUb1EuYTMxIC0gc1RvUS5hMjEgKiBzVG9RLmEzMyxcbiAgICAgICAgYTIyOiBzVG9RLmExMSAqIHNUb1EuYTMzIC0gc1RvUS5hMTMgKiBzVG9RLmEzMSxcbiAgICAgICAgYTIzOiBzVG9RLmExMyAqIHNUb1EuYTIxIC0gc1RvUS5hMTEgKiBzVG9RLmEyMyxcbiAgICAgICAgYTMxOiBzVG9RLmEyMSAqIHNUb1EuYTMyIC0gc1RvUS5hMjIgKiBzVG9RLmEzMSxcbiAgICAgICAgYTMyOiBzVG9RLmExMiAqIHNUb1EuYTMxIC0gc1RvUS5hMTEgKiBzVG9RLmEzMixcbiAgICAgICAgYTMzOiBzVG9RLmExMSAqIHNUb1EuYTIyIC0gc1RvUS5hMTIgKiBzVG9RLmEyMSxcbiAgICB9O1xufVxuZnVuY3Rpb24gdGltZXMoYSwgYikge1xuICAgIHJldHVybiB7XG4gICAgICAgIGExMTogYS5hMTEgKiBiLmExMSArIGEuYTIxICogYi5hMTIgKyBhLmEzMSAqIGIuYTEzLFxuICAgICAgICBhMTI6IGEuYTEyICogYi5hMTEgKyBhLmEyMiAqIGIuYTEyICsgYS5hMzIgKiBiLmExMyxcbiAgICAgICAgYTEzOiBhLmExMyAqIGIuYTExICsgYS5hMjMgKiBiLmExMiArIGEuYTMzICogYi5hMTMsXG4gICAgICAgIGEyMTogYS5hMTEgKiBiLmEyMSArIGEuYTIxICogYi5hMjIgKyBhLmEzMSAqIGIuYTIzLFxuICAgICAgICBhMjI6IGEuYTEyICogYi5hMjEgKyBhLmEyMiAqIGIuYTIyICsgYS5hMzIgKiBiLmEyMyxcbiAgICAgICAgYTIzOiBhLmExMyAqIGIuYTIxICsgYS5hMjMgKiBiLmEyMiArIGEuYTMzICogYi5hMjMsXG4gICAgICAgIGEzMTogYS5hMTEgKiBiLmEzMSArIGEuYTIxICogYi5hMzIgKyBhLmEzMSAqIGIuYTMzLFxuICAgICAgICBhMzI6IGEuYTEyICogYi5hMzEgKyBhLmEyMiAqIGIuYTMyICsgYS5hMzIgKiBiLmEzMyxcbiAgICAgICAgYTMzOiBhLmExMyAqIGIuYTMxICsgYS5hMjMgKiBiLmEzMiArIGEuYTMzICogYi5hMzMsXG4gICAgfTtcbn1cbmZ1bmN0aW9uIGV4dHJhY3QoaW1hZ2UsIGxvY2F0aW9uKSB7XG4gICAgdmFyIHFUb1MgPSBxdWFkcmlsYXRlcmFsVG9TcXVhcmUoeyB4OiAzLjUsIHk6IDMuNSB9LCB7IHg6IGxvY2F0aW9uLmRpbWVuc2lvbiAtIDMuNSwgeTogMy41IH0sIHsgeDogbG9jYXRpb24uZGltZW5zaW9uIC0gNi41LCB5OiBsb2NhdGlvbi5kaW1lbnNpb24gLSA2LjUgfSwgeyB4OiAzLjUsIHk6IGxvY2F0aW9uLmRpbWVuc2lvbiAtIDMuNSB9KTtcbiAgICB2YXIgc1RvUSA9IHNxdWFyZVRvUXVhZHJpbGF0ZXJhbChsb2NhdGlvbi50b3BMZWZ0LCBsb2NhdGlvbi50b3BSaWdodCwgbG9jYXRpb24uYWxpZ25tZW50UGF0dGVybiwgbG9jYXRpb24uYm90dG9tTGVmdCk7XG4gICAgdmFyIHRyYW5zZm9ybSA9IHRpbWVzKHNUb1EsIHFUb1MpO1xuICAgIHZhciBtYXRyaXggPSBCaXRNYXRyaXhfMS5CaXRNYXRyaXguY3JlYXRlRW1wdHkobG9jYXRpb24uZGltZW5zaW9uLCBsb2NhdGlvbi5kaW1lbnNpb24pO1xuICAgIHZhciBtYXBwaW5nRnVuY3Rpb24gPSBmdW5jdGlvbiAoeCwgeSkge1xuICAgICAgICB2YXIgZGVub21pbmF0b3IgPSB0cmFuc2Zvcm0uYTEzICogeCArIHRyYW5zZm9ybS5hMjMgKiB5ICsgdHJhbnNmb3JtLmEzMztcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHg6ICh0cmFuc2Zvcm0uYTExICogeCArIHRyYW5zZm9ybS5hMjEgKiB5ICsgdHJhbnNmb3JtLmEzMSkgLyBkZW5vbWluYXRvcixcbiAgICAgICAgICAgIHk6ICh0cmFuc2Zvcm0uYTEyICogeCArIHRyYW5zZm9ybS5hMjIgKiB5ICsgdHJhbnNmb3JtLmEzMikgLyBkZW5vbWluYXRvcixcbiAgICAgICAgfTtcbiAgICB9O1xuICAgIGZvciAodmFyIHkgPSAwOyB5IDwgbG9jYXRpb24uZGltZW5zaW9uOyB5KyspIHtcbiAgICAgICAgZm9yICh2YXIgeCA9IDA7IHggPCBsb2NhdGlvbi5kaW1lbnNpb247IHgrKykge1xuICAgICAgICAgICAgdmFyIHhWYWx1ZSA9IHggKyAwLjU7XG4gICAgICAgICAgICB2YXIgeVZhbHVlID0geSArIDAuNTtcbiAgICAgICAgICAgIHZhciBzb3VyY2VQaXhlbCA9IG1hcHBpbmdGdW5jdGlvbih4VmFsdWUsIHlWYWx1ZSk7XG4gICAgICAgICAgICBtYXRyaXguc2V0KHgsIHksIGltYWdlLmdldChNYXRoLmZsb29yKHNvdXJjZVBpeGVsLngpLCBNYXRoLmZsb29yKHNvdXJjZVBpeGVsLnkpKSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgbWF0cml4OiBtYXRyaXgsXG4gICAgICAgIG1hcHBpbmdGdW5jdGlvbjogbWFwcGluZ0Z1bmN0aW9uLFxuICAgIH07XG59XG5leHBvcnRzLmV4dHJhY3QgPSBleHRyYWN0O1xuXG5cbi8qKiovIH0pLFxuLyogMTIgKi9cbi8qKiovIChmdW5jdGlvbihtb2R1bGUsIGV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pIHtcblxuXCJ1c2Ugc3RyaWN0XCI7XG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbnZhciBNQVhfRklOREVSUEFUVEVSTlNfVE9fU0VBUkNIID0gNDtcbnZhciBNSU5fUVVBRF9SQVRJTyA9IDAuNTtcbnZhciBNQVhfUVVBRF9SQVRJTyA9IDEuNTtcbnZhciBkaXN0YW5jZSA9IGZ1bmN0aW9uIChhLCBiKSB7IHJldHVybiBNYXRoLnNxcnQoTWF0aC5wb3coKGIueCAtIGEueCksIDIpICsgTWF0aC5wb3coKGIueSAtIGEueSksIDIpKTsgfTtcbmZ1bmN0aW9uIHN1bSh2YWx1ZXMpIHtcbiAgICByZXR1cm4gdmFsdWVzLnJlZHVjZShmdW5jdGlvbiAoYSwgYikgeyByZXR1cm4gYSArIGI7IH0pO1xufVxuLy8gVGFrZXMgdGhyZWUgZmluZGVyIHBhdHRlcm5zIGFuZCBvcmdhbml6ZXMgdGhlbSBpbnRvIHRvcExlZnQsIHRvcFJpZ2h0LCBldGNcbmZ1bmN0aW9uIHJlb3JkZXJGaW5kZXJQYXR0ZXJucyhwYXR0ZXJuMSwgcGF0dGVybjIsIHBhdHRlcm4zKSB7XG4gICAgdmFyIF9hLCBfYiwgX2MsIF9kO1xuICAgIC8vIEZpbmQgZGlzdGFuY2VzIGJldHdlZW4gcGF0dGVybiBjZW50ZXJzXG4gICAgdmFyIG9uZVR3b0Rpc3RhbmNlID0gZGlzdGFuY2UocGF0dGVybjEsIHBhdHRlcm4yKTtcbiAgICB2YXIgdHdvVGhyZWVEaXN0YW5jZSA9IGRpc3RhbmNlKHBhdHRlcm4yLCBwYXR0ZXJuMyk7XG4gICAgdmFyIG9uZVRocmVlRGlzdGFuY2UgPSBkaXN0YW5jZShwYXR0ZXJuMSwgcGF0dGVybjMpO1xuICAgIHZhciBib3R0b21MZWZ0O1xuICAgIHZhciB0b3BMZWZ0O1xuICAgIHZhciB0b3BSaWdodDtcbiAgICAvLyBBc3N1bWUgb25lIGNsb3Nlc3QgdG8gb3RoZXIgdHdvIGlzIEI7IEEgYW5kIEMgd2lsbCBqdXN0IGJlIGd1ZXNzZXMgYXQgZmlyc3RcbiAgICBpZiAodHdvVGhyZWVEaXN0YW5jZSA+PSBvbmVUd29EaXN0YW5jZSAmJiB0d29UaHJlZURpc3RhbmNlID49IG9uZVRocmVlRGlzdGFuY2UpIHtcbiAgICAgICAgX2EgPSBbcGF0dGVybjIsIHBhdHRlcm4xLCBwYXR0ZXJuM10sIGJvdHRvbUxlZnQgPSBfYVswXSwgdG9wTGVmdCA9IF9hWzFdLCB0b3BSaWdodCA9IF9hWzJdO1xuICAgIH1cbiAgICBlbHNlIGlmIChvbmVUaHJlZURpc3RhbmNlID49IHR3b1RocmVlRGlzdGFuY2UgJiYgb25lVGhyZWVEaXN0YW5jZSA+PSBvbmVUd29EaXN0YW5jZSkge1xuICAgICAgICBfYiA9IFtwYXR0ZXJuMSwgcGF0dGVybjIsIHBhdHRlcm4zXSwgYm90dG9tTGVmdCA9IF9iWzBdLCB0b3BMZWZ0ID0gX2JbMV0sIHRvcFJpZ2h0ID0gX2JbMl07XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBfYyA9IFtwYXR0ZXJuMSwgcGF0dGVybjMsIHBhdHRlcm4yXSwgYm90dG9tTGVmdCA9IF9jWzBdLCB0b3BMZWZ0ID0gX2NbMV0sIHRvcFJpZ2h0ID0gX2NbMl07XG4gICAgfVxuICAgIC8vIFVzZSBjcm9zcyBwcm9kdWN0IHRvIGZpZ3VyZSBvdXQgd2hldGhlciBib3R0b21MZWZ0IChBKSBhbmQgdG9wUmlnaHQgKEMpIGFyZSBjb3JyZWN0IG9yIGZsaXBwZWQgaW4gcmVsYXRpb24gdG8gdG9wTGVmdCAoQilcbiAgICAvLyBUaGlzIGFza3Mgd2hldGhlciBCQyB4IEJBIGhhcyBhIHBvc2l0aXZlIHogY29tcG9uZW50LCB3aGljaCBpcyB0aGUgYXJyYW5nZW1lbnQgd2Ugd2FudC4gSWYgaXQncyBuZWdhdGl2ZSwgdGhlblxuICAgIC8vIHdlJ3ZlIGdvdCBpdCBmbGlwcGVkIGFyb3VuZCBhbmQgc2hvdWxkIHN3YXAgdG9wUmlnaHQgYW5kIGJvdHRvbUxlZnQuXG4gICAgaWYgKCgodG9wUmlnaHQueCAtIHRvcExlZnQueCkgKiAoYm90dG9tTGVmdC55IC0gdG9wTGVmdC55KSkgLSAoKHRvcFJpZ2h0LnkgLSB0b3BMZWZ0LnkpICogKGJvdHRvbUxlZnQueCAtIHRvcExlZnQueCkpIDwgMCkge1xuICAgICAgICBfZCA9IFt0b3BSaWdodCwgYm90dG9tTGVmdF0sIGJvdHRvbUxlZnQgPSBfZFswXSwgdG9wUmlnaHQgPSBfZFsxXTtcbiAgICB9XG4gICAgcmV0dXJuIHsgYm90dG9tTGVmdDogYm90dG9tTGVmdCwgdG9wTGVmdDogdG9wTGVmdCwgdG9wUmlnaHQ6IHRvcFJpZ2h0IH07XG59XG4vLyBDb21wdXRlcyB0aGUgZGltZW5zaW9uIChudW1iZXIgb2YgbW9kdWxlcyBvbiBhIHNpZGUpIG9mIHRoZSBRUiBDb2RlIGJhc2VkIG9uIHRoZSBwb3NpdGlvbiBvZiB0aGUgZmluZGVyIHBhdHRlcm5zXG5mdW5jdGlvbiBjb21wdXRlRGltZW5zaW9uKHRvcExlZnQsIHRvcFJpZ2h0LCBib3R0b21MZWZ0LCBtYXRyaXgpIHtcbiAgICB2YXIgbW9kdWxlU2l6ZSA9IChzdW0oY291bnRCbGFja1doaXRlUnVuKHRvcExlZnQsIGJvdHRvbUxlZnQsIG1hdHJpeCwgNSkpIC8gNyArIC8vIERpdmlkZSBieSA3IHNpbmNlIHRoZSByYXRpbyBpcyAxOjE6MzoxOjFcbiAgICAgICAgc3VtKGNvdW50QmxhY2tXaGl0ZVJ1bih0b3BMZWZ0LCB0b3BSaWdodCwgbWF0cml4LCA1KSkgLyA3ICtcbiAgICAgICAgc3VtKGNvdW50QmxhY2tXaGl0ZVJ1bihib3R0b21MZWZ0LCB0b3BMZWZ0LCBtYXRyaXgsIDUpKSAvIDcgK1xuICAgICAgICBzdW0oY291bnRCbGFja1doaXRlUnVuKHRvcFJpZ2h0LCB0b3BMZWZ0LCBtYXRyaXgsIDUpKSAvIDcpIC8gNDtcbiAgICBpZiAobW9kdWxlU2l6ZSA8IDEpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCBtb2R1bGUgc2l6ZVwiKTtcbiAgICB9XG4gICAgdmFyIHRvcERpbWVuc2lvbiA9IE1hdGgucm91bmQoZGlzdGFuY2UodG9wTGVmdCwgdG9wUmlnaHQpIC8gbW9kdWxlU2l6ZSk7XG4gICAgdmFyIHNpZGVEaW1lbnNpb24gPSBNYXRoLnJvdW5kKGRpc3RhbmNlKHRvcExlZnQsIGJvdHRvbUxlZnQpIC8gbW9kdWxlU2l6ZSk7XG4gICAgdmFyIGRpbWVuc2lvbiA9IE1hdGguZmxvb3IoKHRvcERpbWVuc2lvbiArIHNpZGVEaW1lbnNpb24pIC8gMikgKyA3O1xuICAgIHN3aXRjaCAoZGltZW5zaW9uICUgNCkge1xuICAgICAgICBjYXNlIDA6XG4gICAgICAgICAgICBkaW1lbnNpb24rKztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICBkaW1lbnNpb24tLTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgIH1cbiAgICByZXR1cm4geyBkaW1lbnNpb246IGRpbWVuc2lvbiwgbW9kdWxlU2l6ZTogbW9kdWxlU2l6ZSB9O1xufVxuLy8gVGFrZXMgYW4gb3JpZ2luIHBvaW50IGFuZCBhbiBlbmQgcG9pbnQgYW5kIGNvdW50cyB0aGUgc2l6ZXMgb2YgdGhlIGJsYWNrIHdoaXRlIHJ1biBmcm9tIHRoZSBvcmlnaW4gdG93YXJkcyB0aGUgZW5kIHBvaW50LlxuLy8gUmV0dXJucyBhbiBhcnJheSBvZiBlbGVtZW50cywgcmVwcmVzZW50aW5nIHRoZSBwaXhlbCBzaXplIG9mIHRoZSBibGFjayB3aGl0ZSBydW4uXG4vLyBVc2VzIGEgdmFyaWFudCBvZiBodHRwOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0JyZXNlbmhhbSdzX2xpbmVfYWxnb3JpdGhtXG5mdW5jdGlvbiBjb3VudEJsYWNrV2hpdGVSdW5Ub3dhcmRzUG9pbnQob3JpZ2luLCBlbmQsIG1hdHJpeCwgbGVuZ3RoKSB7XG4gICAgdmFyIHN3aXRjaFBvaW50cyA9IFt7IHg6IE1hdGguZmxvb3Iob3JpZ2luLngpLCB5OiBNYXRoLmZsb29yKG9yaWdpbi55KSB9XTtcbiAgICB2YXIgc3RlZXAgPSBNYXRoLmFicyhlbmQueSAtIG9yaWdpbi55KSA+IE1hdGguYWJzKGVuZC54IC0gb3JpZ2luLngpO1xuICAgIHZhciBmcm9tWDtcbiAgICB2YXIgZnJvbVk7XG4gICAgdmFyIHRvWDtcbiAgICB2YXIgdG9ZO1xuICAgIGlmIChzdGVlcCkge1xuICAgICAgICBmcm9tWCA9IE1hdGguZmxvb3Iob3JpZ2luLnkpO1xuICAgICAgICBmcm9tWSA9IE1hdGguZmxvb3Iob3JpZ2luLngpO1xuICAgICAgICB0b1ggPSBNYXRoLmZsb29yKGVuZC55KTtcbiAgICAgICAgdG9ZID0gTWF0aC5mbG9vcihlbmQueCk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBmcm9tWCA9IE1hdGguZmxvb3Iob3JpZ2luLngpO1xuICAgICAgICBmcm9tWSA9IE1hdGguZmxvb3Iob3JpZ2luLnkpO1xuICAgICAgICB0b1ggPSBNYXRoLmZsb29yKGVuZC54KTtcbiAgICAgICAgdG9ZID0gTWF0aC5mbG9vcihlbmQueSk7XG4gICAgfVxuICAgIHZhciBkeCA9IE1hdGguYWJzKHRvWCAtIGZyb21YKTtcbiAgICB2YXIgZHkgPSBNYXRoLmFicyh0b1kgLSBmcm9tWSk7XG4gICAgdmFyIGVycm9yID0gTWF0aC5mbG9vcigtZHggLyAyKTtcbiAgICB2YXIgeFN0ZXAgPSBmcm9tWCA8IHRvWCA/IDEgOiAtMTtcbiAgICB2YXIgeVN0ZXAgPSBmcm9tWSA8IHRvWSA/IDEgOiAtMTtcbiAgICB2YXIgY3VycmVudFBpeGVsID0gdHJ1ZTtcbiAgICAvLyBMb29wIHVwIHVudGlsIHggPT0gdG9YLCBidXQgbm90IGJleW9uZFxuICAgIGZvciAodmFyIHggPSBmcm9tWCwgeSA9IGZyb21ZOyB4ICE9PSB0b1ggKyB4U3RlcDsgeCArPSB4U3RlcCkge1xuICAgICAgICAvLyBEb2VzIGN1cnJlbnQgcGl4ZWwgbWVhbiB3ZSBoYXZlIG1vdmVkIHdoaXRlIHRvIGJsYWNrIG9yIHZpY2UgdmVyc2E/XG4gICAgICAgIC8vIFNjYW5uaW5nIGJsYWNrIGluIHN0YXRlIDAsMiBhbmQgd2hpdGUgaW4gc3RhdGUgMSwgc28gaWYgd2UgZmluZCB0aGUgd3JvbmdcbiAgICAgICAgLy8gY29sb3IsIGFkdmFuY2UgdG8gbmV4dCBzdGF0ZSBvciBlbmQgaWYgd2UgYXJlIGluIHN0YXRlIDIgYWxyZWFkeVxuICAgICAgICB2YXIgcmVhbFggPSBzdGVlcCA/IHkgOiB4O1xuICAgICAgICB2YXIgcmVhbFkgPSBzdGVlcCA/IHggOiB5O1xuICAgICAgICBpZiAobWF0cml4LmdldChyZWFsWCwgcmVhbFkpICE9PSBjdXJyZW50UGl4ZWwpIHtcbiAgICAgICAgICAgIGN1cnJlbnRQaXhlbCA9ICFjdXJyZW50UGl4ZWw7XG4gICAgICAgICAgICBzd2l0Y2hQb2ludHMucHVzaCh7IHg6IHJlYWxYLCB5OiByZWFsWSB9KTtcbiAgICAgICAgICAgIGlmIChzd2l0Y2hQb2ludHMubGVuZ3RoID09PSBsZW5ndGggKyAxKSB7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZXJyb3IgKz0gZHk7XG4gICAgICAgIGlmIChlcnJvciA+IDApIHtcbiAgICAgICAgICAgIGlmICh5ID09PSB0b1kpIHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHkgKz0geVN0ZXA7XG4gICAgICAgICAgICBlcnJvciAtPSBkeDtcbiAgICAgICAgfVxuICAgIH1cbiAgICB2YXIgZGlzdGFuY2VzID0gW107XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgICAgICBpZiAoc3dpdGNoUG9pbnRzW2ldICYmIHN3aXRjaFBvaW50c1tpICsgMV0pIHtcbiAgICAgICAgICAgIGRpc3RhbmNlcy5wdXNoKGRpc3RhbmNlKHN3aXRjaFBvaW50c1tpXSwgc3dpdGNoUG9pbnRzW2kgKyAxXSkpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgZGlzdGFuY2VzLnB1c2goMCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGRpc3RhbmNlcztcbn1cbi8vIFRha2VzIGFuIG9yaWdpbiBwb2ludCBhbmQgYW4gZW5kIHBvaW50IGFuZCBjb3VudHMgdGhlIHNpemVzIG9mIHRoZSBibGFjayB3aGl0ZSBydW4gaW4gdGhlIG9yaWdpbiBwb2ludFxuLy8gYWxvbmcgdGhlIGxpbmUgdGhhdCBpbnRlcnNlY3RzIHdpdGggdGhlIGVuZCBwb2ludC4gUmV0dXJucyBhbiBhcnJheSBvZiBlbGVtZW50cywgcmVwcmVzZW50aW5nIHRoZSBwaXhlbCBzaXplc1xuLy8gb2YgdGhlIGJsYWNrIHdoaXRlIHJ1bi4gVGFrZXMgYSBsZW5ndGggd2hpY2ggcmVwcmVzZW50cyB0aGUgbnVtYmVyIG9mIHN3aXRjaGVzIGZyb20gYmxhY2sgdG8gd2hpdGUgdG8gbG9vayBmb3IuXG5mdW5jdGlvbiBjb3VudEJsYWNrV2hpdGVSdW4ob3JpZ2luLCBlbmQsIG1hdHJpeCwgbGVuZ3RoKSB7XG4gICAgdmFyIF9hO1xuICAgIHZhciByaXNlID0gZW5kLnkgLSBvcmlnaW4ueTtcbiAgICB2YXIgcnVuID0gZW5kLnggLSBvcmlnaW4ueDtcbiAgICB2YXIgdG93YXJkc0VuZCA9IGNvdW50QmxhY2tXaGl0ZVJ1blRvd2FyZHNQb2ludChvcmlnaW4sIGVuZCwgbWF0cml4LCBNYXRoLmNlaWwobGVuZ3RoIC8gMikpO1xuICAgIHZhciBhd2F5RnJvbUVuZCA9IGNvdW50QmxhY2tXaGl0ZVJ1blRvd2FyZHNQb2ludChvcmlnaW4sIHsgeDogb3JpZ2luLnggLSBydW4sIHk6IG9yaWdpbi55IC0gcmlzZSB9LCBtYXRyaXgsIE1hdGguY2VpbChsZW5ndGggLyAyKSk7XG4gICAgdmFyIG1pZGRsZVZhbHVlID0gdG93YXJkc0VuZC5zaGlmdCgpICsgYXdheUZyb21FbmQuc2hpZnQoKSAtIDE7IC8vIFN1YnN0cmFjdCBvbmUgc28gd2UgZG9uJ3QgZG91YmxlIGNvdW50IGEgcGl4ZWxcbiAgICByZXR1cm4gKF9hID0gYXdheUZyb21FbmQuY29uY2F0KG1pZGRsZVZhbHVlKSkuY29uY2F0LmFwcGx5KF9hLCB0b3dhcmRzRW5kKTtcbn1cbi8vIFRha2VzIGluIGEgYmxhY2sgd2hpdGUgcnVuIGFuZCBhbiBhcnJheSBvZiBleHBlY3RlZCByYXRpb3MuIFJldHVybnMgdGhlIGF2ZXJhZ2Ugc2l6ZSBvZiB0aGUgcnVuIGFzIHdlbGwgYXMgdGhlIFwiZXJyb3JcIiAtXG4vLyB0aGF0IGlzIHRoZSBhbW91bnQgdGhlIHJ1biBkaXZlcmdlcyBmcm9tIHRoZSBleHBlY3RlZCByYXRpb1xuZnVuY3Rpb24gc2NvcmVCbGFja1doaXRlUnVuKHNlcXVlbmNlLCByYXRpb3MpIHtcbiAgICB2YXIgYXZlcmFnZVNpemUgPSBzdW0oc2VxdWVuY2UpIC8gc3VtKHJhdGlvcyk7XG4gICAgdmFyIGVycm9yID0gMDtcbiAgICByYXRpb3MuZm9yRWFjaChmdW5jdGlvbiAocmF0aW8sIGkpIHtcbiAgICAgICAgZXJyb3IgKz0gTWF0aC5wb3coKHNlcXVlbmNlW2ldIC0gcmF0aW8gKiBhdmVyYWdlU2l6ZSksIDIpO1xuICAgIH0pO1xuICAgIHJldHVybiB7IGF2ZXJhZ2VTaXplOiBhdmVyYWdlU2l6ZSwgZXJyb3I6IGVycm9yIH07XG59XG4vLyBUYWtlcyBhbiBYLFkgcG9pbnQgYW5kIGFuIGFycmF5IG9mIHNpemVzIGFuZCBzY29yZXMgdGhlIHBvaW50IGFnYWluc3QgdGhvc2UgcmF0aW9zLlxuLy8gRm9yIGV4YW1wbGUgZm9yIGEgZmluZGVyIHBhdHRlcm4gdGFrZXMgdGhlIHJhdGlvIGxpc3Qgb2YgMToxOjM6MToxIGFuZCBjaGVja3MgaG9yaXpvbnRhbCwgdmVydGljYWwgYW5kIGRpYWdvbmFsIHJhdGlvc1xuLy8gYWdhaW5zdCB0aGF0LlxuZnVuY3Rpb24gc2NvcmVQYXR0ZXJuKHBvaW50LCByYXRpb3MsIG1hdHJpeCkge1xuICAgIHRyeSB7XG4gICAgICAgIHZhciBob3Jpem9udGFsUnVuID0gY291bnRCbGFja1doaXRlUnVuKHBvaW50LCB7IHg6IC0xLCB5OiBwb2ludC55IH0sIG1hdHJpeCwgcmF0aW9zLmxlbmd0aCk7XG4gICAgICAgIHZhciB2ZXJ0aWNhbFJ1biA9IGNvdW50QmxhY2tXaGl0ZVJ1bihwb2ludCwgeyB4OiBwb2ludC54LCB5OiAtMSB9LCBtYXRyaXgsIHJhdGlvcy5sZW5ndGgpO1xuICAgICAgICB2YXIgdG9wTGVmdFBvaW50ID0ge1xuICAgICAgICAgICAgeDogTWF0aC5tYXgoMCwgcG9pbnQueCAtIHBvaW50LnkpIC0gMSxcbiAgICAgICAgICAgIHk6IE1hdGgubWF4KDAsIHBvaW50LnkgLSBwb2ludC54KSAtIDEsXG4gICAgICAgIH07XG4gICAgICAgIHZhciB0b3BMZWZ0Qm90dG9tUmlnaHRSdW4gPSBjb3VudEJsYWNrV2hpdGVSdW4ocG9pbnQsIHRvcExlZnRQb2ludCwgbWF0cml4LCByYXRpb3MubGVuZ3RoKTtcbiAgICAgICAgdmFyIGJvdHRvbUxlZnRQb2ludCA9IHtcbiAgICAgICAgICAgIHg6IE1hdGgubWluKG1hdHJpeC53aWR0aCwgcG9pbnQueCArIHBvaW50LnkpICsgMSxcbiAgICAgICAgICAgIHk6IE1hdGgubWluKG1hdHJpeC5oZWlnaHQsIHBvaW50LnkgKyBwb2ludC54KSArIDEsXG4gICAgICAgIH07XG4gICAgICAgIHZhciBib3R0b21MZWZ0VG9wUmlnaHRSdW4gPSBjb3VudEJsYWNrV2hpdGVSdW4ocG9pbnQsIGJvdHRvbUxlZnRQb2ludCwgbWF0cml4LCByYXRpb3MubGVuZ3RoKTtcbiAgICAgICAgdmFyIGhvcnpFcnJvciA9IHNjb3JlQmxhY2tXaGl0ZVJ1bihob3Jpem9udGFsUnVuLCByYXRpb3MpO1xuICAgICAgICB2YXIgdmVydEVycm9yID0gc2NvcmVCbGFja1doaXRlUnVuKHZlcnRpY2FsUnVuLCByYXRpb3MpO1xuICAgICAgICB2YXIgZGlhZ0Rvd25FcnJvciA9IHNjb3JlQmxhY2tXaGl0ZVJ1bih0b3BMZWZ0Qm90dG9tUmlnaHRSdW4sIHJhdGlvcyk7XG4gICAgICAgIHZhciBkaWFnVXBFcnJvciA9IHNjb3JlQmxhY2tXaGl0ZVJ1bihib3R0b21MZWZ0VG9wUmlnaHRSdW4sIHJhdGlvcyk7XG4gICAgICAgIHZhciByYXRpb0Vycm9yID0gTWF0aC5zcXJ0KGhvcnpFcnJvci5lcnJvciAqIGhvcnpFcnJvci5lcnJvciArXG4gICAgICAgICAgICB2ZXJ0RXJyb3IuZXJyb3IgKiB2ZXJ0RXJyb3IuZXJyb3IgK1xuICAgICAgICAgICAgZGlhZ0Rvd25FcnJvci5lcnJvciAqIGRpYWdEb3duRXJyb3IuZXJyb3IgK1xuICAgICAgICAgICAgZGlhZ1VwRXJyb3IuZXJyb3IgKiBkaWFnVXBFcnJvci5lcnJvcik7XG4gICAgICAgIHZhciBhdmdTaXplID0gKGhvcnpFcnJvci5hdmVyYWdlU2l6ZSArIHZlcnRFcnJvci5hdmVyYWdlU2l6ZSArIGRpYWdEb3duRXJyb3IuYXZlcmFnZVNpemUgKyBkaWFnVXBFcnJvci5hdmVyYWdlU2l6ZSkgLyA0O1xuICAgICAgICB2YXIgc2l6ZUVycm9yID0gKE1hdGgucG93KChob3J6RXJyb3IuYXZlcmFnZVNpemUgLSBhdmdTaXplKSwgMikgK1xuICAgICAgICAgICAgTWF0aC5wb3coKHZlcnRFcnJvci5hdmVyYWdlU2l6ZSAtIGF2Z1NpemUpLCAyKSArXG4gICAgICAgICAgICBNYXRoLnBvdygoZGlhZ0Rvd25FcnJvci5hdmVyYWdlU2l6ZSAtIGF2Z1NpemUpLCAyKSArXG4gICAgICAgICAgICBNYXRoLnBvdygoZGlhZ1VwRXJyb3IuYXZlcmFnZVNpemUgLSBhdmdTaXplKSwgMikpIC8gYXZnU2l6ZTtcbiAgICAgICAgcmV0dXJuIHJhdGlvRXJyb3IgKyBzaXplRXJyb3I7XG4gICAgfVxuICAgIGNhdGNoIChfYSkge1xuICAgICAgICByZXR1cm4gSW5maW5pdHk7XG4gICAgfVxufVxuZnVuY3Rpb24gcmVjZW50ZXJMb2NhdGlvbihtYXRyaXgsIHApIHtcbiAgICB2YXIgbGVmdFggPSBNYXRoLnJvdW5kKHAueCk7XG4gICAgd2hpbGUgKG1hdHJpeC5nZXQobGVmdFgsIE1hdGgucm91bmQocC55KSkpIHtcbiAgICAgICAgbGVmdFgtLTtcbiAgICB9XG4gICAgdmFyIHJpZ2h0WCA9IE1hdGgucm91bmQocC54KTtcbiAgICB3aGlsZSAobWF0cml4LmdldChyaWdodFgsIE1hdGgucm91bmQocC55KSkpIHtcbiAgICAgICAgcmlnaHRYKys7XG4gICAgfVxuICAgIHZhciB4ID0gKGxlZnRYICsgcmlnaHRYKSAvIDI7XG4gICAgdmFyIHRvcFkgPSBNYXRoLnJvdW5kKHAueSk7XG4gICAgd2hpbGUgKG1hdHJpeC5nZXQoTWF0aC5yb3VuZCh4KSwgdG9wWSkpIHtcbiAgICAgICAgdG9wWS0tO1xuICAgIH1cbiAgICB2YXIgYm90dG9tWSA9IE1hdGgucm91bmQocC55KTtcbiAgICB3aGlsZSAobWF0cml4LmdldChNYXRoLnJvdW5kKHgpLCBib3R0b21ZKSkge1xuICAgICAgICBib3R0b21ZKys7XG4gICAgfVxuICAgIHZhciB5ID0gKHRvcFkgKyBib3R0b21ZKSAvIDI7XG4gICAgcmV0dXJuIHsgeDogeCwgeTogeSB9O1xufVxuZnVuY3Rpb24gbG9jYXRlKG1hdHJpeCkge1xuICAgIHZhciBmaW5kZXJQYXR0ZXJuUXVhZHMgPSBbXTtcbiAgICB2YXIgYWN0aXZlRmluZGVyUGF0dGVyblF1YWRzID0gW107XG4gICAgdmFyIGFsaWdubWVudFBhdHRlcm5RdWFkcyA9IFtdO1xuICAgIHZhciBhY3RpdmVBbGlnbm1lbnRQYXR0ZXJuUXVhZHMgPSBbXTtcbiAgICB2YXIgX2xvb3BfMSA9IGZ1bmN0aW9uICh5KSB7XG4gICAgICAgIHZhciBsZW5ndGhfMSA9IDA7XG4gICAgICAgIHZhciBsYXN0Qml0ID0gZmFsc2U7XG4gICAgICAgIHZhciBzY2FucyA9IFswLCAwLCAwLCAwLCAwXTtcbiAgICAgICAgdmFyIF9sb29wXzIgPSBmdW5jdGlvbiAoeCkge1xuICAgICAgICAgICAgdmFyIHYgPSBtYXRyaXguZ2V0KHgsIHkpO1xuICAgICAgICAgICAgaWYgKHYgPT09IGxhc3RCaXQpIHtcbiAgICAgICAgICAgICAgICBsZW5ndGhfMSsrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgc2NhbnMgPSBbc2NhbnNbMV0sIHNjYW5zWzJdLCBzY2Fuc1szXSwgc2NhbnNbNF0sIGxlbmd0aF8xXTtcbiAgICAgICAgICAgICAgICBsZW5ndGhfMSA9IDE7XG4gICAgICAgICAgICAgICAgbGFzdEJpdCA9IHY7XG4gICAgICAgICAgICAgICAgLy8gRG8gdGhlIGxhc3QgNSBjb2xvciBjaGFuZ2VzIH4gbWF0Y2ggdGhlIGV4cGVjdGVkIHJhdGlvIGZvciBhIGZpbmRlciBwYXR0ZXJuPyAxOjE6MzoxOjEgb2YgYjp3OmI6dzpiXG4gICAgICAgICAgICAgICAgdmFyIGF2ZXJhZ2VGaW5kZXJQYXR0ZXJuQmxvY2tzaXplID0gc3VtKHNjYW5zKSAvIDc7XG4gICAgICAgICAgICAgICAgdmFyIHZhbGlkRmluZGVyUGF0dGVybiA9IE1hdGguYWJzKHNjYW5zWzBdIC0gYXZlcmFnZUZpbmRlclBhdHRlcm5CbG9ja3NpemUpIDwgYXZlcmFnZUZpbmRlclBhdHRlcm5CbG9ja3NpemUgJiZcbiAgICAgICAgICAgICAgICAgICAgTWF0aC5hYnMoc2NhbnNbMV0gLSBhdmVyYWdlRmluZGVyUGF0dGVybkJsb2Nrc2l6ZSkgPCBhdmVyYWdlRmluZGVyUGF0dGVybkJsb2Nrc2l6ZSAmJlxuICAgICAgICAgICAgICAgICAgICBNYXRoLmFicyhzY2Fuc1syXSAtIDMgKiBhdmVyYWdlRmluZGVyUGF0dGVybkJsb2Nrc2l6ZSkgPCAzICogYXZlcmFnZUZpbmRlclBhdHRlcm5CbG9ja3NpemUgJiZcbiAgICAgICAgICAgICAgICAgICAgTWF0aC5hYnMoc2NhbnNbM10gLSBhdmVyYWdlRmluZGVyUGF0dGVybkJsb2Nrc2l6ZSkgPCBhdmVyYWdlRmluZGVyUGF0dGVybkJsb2Nrc2l6ZSAmJlxuICAgICAgICAgICAgICAgICAgICBNYXRoLmFicyhzY2Fuc1s0XSAtIGF2ZXJhZ2VGaW5kZXJQYXR0ZXJuQmxvY2tzaXplKSA8IGF2ZXJhZ2VGaW5kZXJQYXR0ZXJuQmxvY2tzaXplICYmXG4gICAgICAgICAgICAgICAgICAgICF2OyAvLyBBbmQgbWFrZSBzdXJlIHRoZSBjdXJyZW50IHBpeGVsIGlzIHdoaXRlIHNpbmNlIGZpbmRlciBwYXR0ZXJucyBhcmUgYm9yZGVyZWQgaW4gd2hpdGVcbiAgICAgICAgICAgICAgICAvLyBEbyB0aGUgbGFzdCAzIGNvbG9yIGNoYW5nZXMgfiBtYXRjaCB0aGUgZXhwZWN0ZWQgcmF0aW8gZm9yIGFuIGFsaWdubWVudCBwYXR0ZXJuPyAxOjE6MSBvZiB3OmI6d1xuICAgICAgICAgICAgICAgIHZhciBhdmVyYWdlQWxpZ25tZW50UGF0dGVybkJsb2Nrc2l6ZSA9IHN1bShzY2Fucy5zbGljZSgtMykpIC8gMztcbiAgICAgICAgICAgICAgICB2YXIgdmFsaWRBbGlnbm1lbnRQYXR0ZXJuID0gTWF0aC5hYnMoc2NhbnNbMl0gLSBhdmVyYWdlQWxpZ25tZW50UGF0dGVybkJsb2Nrc2l6ZSkgPCBhdmVyYWdlQWxpZ25tZW50UGF0dGVybkJsb2Nrc2l6ZSAmJlxuICAgICAgICAgICAgICAgICAgICBNYXRoLmFicyhzY2Fuc1szXSAtIGF2ZXJhZ2VBbGlnbm1lbnRQYXR0ZXJuQmxvY2tzaXplKSA8IGF2ZXJhZ2VBbGlnbm1lbnRQYXR0ZXJuQmxvY2tzaXplICYmXG4gICAgICAgICAgICAgICAgICAgIE1hdGguYWJzKHNjYW5zWzRdIC0gYXZlcmFnZUFsaWdubWVudFBhdHRlcm5CbG9ja3NpemUpIDwgYXZlcmFnZUFsaWdubWVudFBhdHRlcm5CbG9ja3NpemUgJiZcbiAgICAgICAgICAgICAgICAgICAgdjsgLy8gSXMgdGhlIGN1cnJlbnQgcGl4ZWwgYmxhY2sgc2luY2UgYWxpZ25tZW50IHBhdHRlcm5zIGFyZSBib3JkZXJlZCBpbiBibGFja1xuICAgICAgICAgICAgICAgIGlmICh2YWxpZEZpbmRlclBhdHRlcm4pIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gQ29tcHV0ZSB0aGUgc3RhcnQgYW5kIGVuZCB4IHZhbHVlcyBvZiB0aGUgbGFyZ2UgY2VudGVyIGJsYWNrIHNxdWFyZVxuICAgICAgICAgICAgICAgICAgICB2YXIgZW5kWF8xID0geCAtIHNjYW5zWzNdIC0gc2NhbnNbNF07XG4gICAgICAgICAgICAgICAgICAgIHZhciBzdGFydFhfMSA9IGVuZFhfMSAtIHNjYW5zWzJdO1xuICAgICAgICAgICAgICAgICAgICB2YXIgbGluZSA9IHsgc3RhcnRYOiBzdGFydFhfMSwgZW5kWDogZW5kWF8xLCB5OiB5IH07XG4gICAgICAgICAgICAgICAgICAgIC8vIElzIHRoZXJlIGEgcXVhZCBkaXJlY3RseSBhYm92ZSB0aGUgY3VycmVudCBzcG90PyBJZiBzbywgZXh0ZW5kIGl0IHdpdGggdGhlIG5ldyBsaW5lLiBPdGhlcndpc2UsIGNyZWF0ZSBhIG5ldyBxdWFkIHdpdGhcbiAgICAgICAgICAgICAgICAgICAgLy8gdGhhdCBsaW5lIGFzIHRoZSBzdGFydGluZyBwb2ludC5cbiAgICAgICAgICAgICAgICAgICAgdmFyIG1hdGNoaW5nUXVhZHMgPSBhY3RpdmVGaW5kZXJQYXR0ZXJuUXVhZHMuZmlsdGVyKGZ1bmN0aW9uIChxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKHN0YXJ0WF8xID49IHEuYm90dG9tLnN0YXJ0WCAmJiBzdGFydFhfMSA8PSBxLmJvdHRvbS5lbmRYKSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChlbmRYXzEgPj0gcS5ib3R0b20uc3RhcnRYICYmIHN0YXJ0WF8xIDw9IHEuYm90dG9tLmVuZFgpIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKHN0YXJ0WF8xIDw9IHEuYm90dG9tLnN0YXJ0WCAmJiBlbmRYXzEgPj0gcS5ib3R0b20uZW5kWCAmJiAoKHNjYW5zWzJdIC8gKHEuYm90dG9tLmVuZFggLSBxLmJvdHRvbS5zdGFydFgpKSA8IE1BWF9RVUFEX1JBVElPICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChzY2Fuc1syXSAvIChxLmJvdHRvbS5lbmRYIC0gcS5ib3R0b20uc3RhcnRYKSkgPiBNSU5fUVVBRF9SQVRJTykpO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG1hdGNoaW5nUXVhZHMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbWF0Y2hpbmdRdWFkc1swXS5ib3R0b20gPSBsaW5lO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZlRmluZGVyUGF0dGVyblF1YWRzLnB1c2goeyB0b3A6IGxpbmUsIGJvdHRvbTogbGluZSB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAodmFsaWRBbGlnbm1lbnRQYXR0ZXJuKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIENvbXB1dGUgdGhlIHN0YXJ0IGFuZCBlbmQgeCB2YWx1ZXMgb2YgdGhlIGNlbnRlciBibGFjayBzcXVhcmVcbiAgICAgICAgICAgICAgICAgICAgdmFyIGVuZFhfMiA9IHggLSBzY2Fuc1s0XTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHN0YXJ0WF8yID0gZW5kWF8yIC0gc2NhbnNbM107XG4gICAgICAgICAgICAgICAgICAgIHZhciBsaW5lID0geyBzdGFydFg6IHN0YXJ0WF8yLCB5OiB5LCBlbmRYOiBlbmRYXzIgfTtcbiAgICAgICAgICAgICAgICAgICAgLy8gSXMgdGhlcmUgYSBxdWFkIGRpcmVjdGx5IGFib3ZlIHRoZSBjdXJyZW50IHNwb3Q/IElmIHNvLCBleHRlbmQgaXQgd2l0aCB0aGUgbmV3IGxpbmUuIE90aGVyd2lzZSwgY3JlYXRlIGEgbmV3IHF1YWQgd2l0aFxuICAgICAgICAgICAgICAgICAgICAvLyB0aGF0IGxpbmUgYXMgdGhlIHN0YXJ0aW5nIHBvaW50LlxuICAgICAgICAgICAgICAgICAgICB2YXIgbWF0Y2hpbmdRdWFkcyA9IGFjdGl2ZUFsaWdubWVudFBhdHRlcm5RdWFkcy5maWx0ZXIoZnVuY3Rpb24gKHEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoc3RhcnRYXzIgPj0gcS5ib3R0b20uc3RhcnRYICYmIHN0YXJ0WF8yIDw9IHEuYm90dG9tLmVuZFgpIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKGVuZFhfMiA+PSBxLmJvdHRvbS5zdGFydFggJiYgc3RhcnRYXzIgPD0gcS5ib3R0b20uZW5kWCkgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoc3RhcnRYXzIgPD0gcS5ib3R0b20uc3RhcnRYICYmIGVuZFhfMiA+PSBxLmJvdHRvbS5lbmRYICYmICgoc2NhbnNbMl0gLyAocS5ib3R0b20uZW5kWCAtIHEuYm90dG9tLnN0YXJ0WCkpIDwgTUFYX1FVQURfUkFUSU8gJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHNjYW5zWzJdIC8gKHEuYm90dG9tLmVuZFggLSBxLmJvdHRvbS5zdGFydFgpKSA+IE1JTl9RVUFEX1JBVElPKSk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICBpZiAobWF0Y2hpbmdRdWFkcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBtYXRjaGluZ1F1YWRzWzBdLmJvdHRvbSA9IGxpbmU7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVBbGlnbm1lbnRQYXR0ZXJuUXVhZHMucHVzaCh7IHRvcDogbGluZSwgYm90dG9tOiBsaW5lIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBmb3IgKHZhciB4ID0gLTE7IHggPD0gbWF0cml4LndpZHRoOyB4KyspIHtcbiAgICAgICAgICAgIF9sb29wXzIoeCk7XG4gICAgICAgIH1cbiAgICAgICAgZmluZGVyUGF0dGVyblF1YWRzLnB1c2guYXBwbHkoZmluZGVyUGF0dGVyblF1YWRzLCBhY3RpdmVGaW5kZXJQYXR0ZXJuUXVhZHMuZmlsdGVyKGZ1bmN0aW9uIChxKSB7IHJldHVybiBxLmJvdHRvbS55ICE9PSB5ICYmIHEuYm90dG9tLnkgLSBxLnRvcC55ID49IDI7IH0pKTtcbiAgICAgICAgYWN0aXZlRmluZGVyUGF0dGVyblF1YWRzID0gYWN0aXZlRmluZGVyUGF0dGVyblF1YWRzLmZpbHRlcihmdW5jdGlvbiAocSkgeyByZXR1cm4gcS5ib3R0b20ueSA9PT0geTsgfSk7XG4gICAgICAgIGFsaWdubWVudFBhdHRlcm5RdWFkcy5wdXNoLmFwcGx5KGFsaWdubWVudFBhdHRlcm5RdWFkcywgYWN0aXZlQWxpZ25tZW50UGF0dGVyblF1YWRzLmZpbHRlcihmdW5jdGlvbiAocSkgeyByZXR1cm4gcS5ib3R0b20ueSAhPT0geTsgfSkpO1xuICAgICAgICBhY3RpdmVBbGlnbm1lbnRQYXR0ZXJuUXVhZHMgPSBhY3RpdmVBbGlnbm1lbnRQYXR0ZXJuUXVhZHMuZmlsdGVyKGZ1bmN0aW9uIChxKSB7IHJldHVybiBxLmJvdHRvbS55ID09PSB5OyB9KTtcbiAgICB9O1xuICAgIGZvciAodmFyIHkgPSAwOyB5IDw9IG1hdHJpeC5oZWlnaHQ7IHkrKykge1xuICAgICAgICBfbG9vcF8xKHkpO1xuICAgIH1cbiAgICBmaW5kZXJQYXR0ZXJuUXVhZHMucHVzaC5hcHBseShmaW5kZXJQYXR0ZXJuUXVhZHMsIGFjdGl2ZUZpbmRlclBhdHRlcm5RdWFkcy5maWx0ZXIoZnVuY3Rpb24gKHEpIHsgcmV0dXJuIHEuYm90dG9tLnkgLSBxLnRvcC55ID49IDI7IH0pKTtcbiAgICBhbGlnbm1lbnRQYXR0ZXJuUXVhZHMucHVzaC5hcHBseShhbGlnbm1lbnRQYXR0ZXJuUXVhZHMsIGFjdGl2ZUFsaWdubWVudFBhdHRlcm5RdWFkcyk7XG4gICAgdmFyIGZpbmRlclBhdHRlcm5Hcm91cHMgPSBmaW5kZXJQYXR0ZXJuUXVhZHNcbiAgICAgICAgLmZpbHRlcihmdW5jdGlvbiAocSkgeyByZXR1cm4gcS5ib3R0b20ueSAtIHEudG9wLnkgPj0gMjsgfSkgLy8gQWxsIHF1YWRzIG11c3QgYmUgYXQgbGVhc3QgMnB4IHRhbGwgc2luY2UgdGhlIGNlbnRlciBzcXVhcmUgaXMgbGFyZ2VyIHRoYW4gYSBibG9ja1xuICAgICAgICAubWFwKGZ1bmN0aW9uIChxKSB7XG4gICAgICAgIHZhciB4ID0gKHEudG9wLnN0YXJ0WCArIHEudG9wLmVuZFggKyBxLmJvdHRvbS5zdGFydFggKyBxLmJvdHRvbS5lbmRYKSAvIDQ7XG4gICAgICAgIHZhciB5ID0gKHEudG9wLnkgKyBxLmJvdHRvbS55ICsgMSkgLyAyO1xuICAgICAgICBpZiAoIW1hdHJpeC5nZXQoTWF0aC5yb3VuZCh4KSwgTWF0aC5yb3VuZCh5KSkpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB2YXIgbGVuZ3RocyA9IFtxLnRvcC5lbmRYIC0gcS50b3Auc3RhcnRYLCBxLmJvdHRvbS5lbmRYIC0gcS5ib3R0b20uc3RhcnRYLCBxLmJvdHRvbS55IC0gcS50b3AueSArIDFdO1xuICAgICAgICB2YXIgc2l6ZSA9IHN1bShsZW5ndGhzKSAvIGxlbmd0aHMubGVuZ3RoO1xuICAgICAgICB2YXIgc2NvcmUgPSBzY29yZVBhdHRlcm4oeyB4OiBNYXRoLnJvdW5kKHgpLCB5OiBNYXRoLnJvdW5kKHkpIH0sIFsxLCAxLCAzLCAxLCAxXSwgbWF0cml4KTtcbiAgICAgICAgcmV0dXJuIHsgc2NvcmU6IHNjb3JlLCB4OiB4LCB5OiB5LCBzaXplOiBzaXplIH07XG4gICAgfSlcbiAgICAgICAgLmZpbHRlcihmdW5jdGlvbiAocSkgeyByZXR1cm4gISFxOyB9KSAvLyBGaWx0ZXIgb3V0IGFueSByZWplY3RlZCBxdWFkcyBmcm9tIGFib3ZlXG4gICAgICAgIC5zb3J0KGZ1bmN0aW9uIChhLCBiKSB7IHJldHVybiBhLnNjb3JlIC0gYi5zY29yZTsgfSlcbiAgICAgICAgLy8gTm93IHRha2UgdGhlIHRvcCBmaW5kZXIgcGF0dGVybiBvcHRpb25zIGFuZCB0cnkgdG8gZmluZCAyIG90aGVyIG9wdGlvbnMgd2l0aCBhIHNpbWlsYXIgc2l6ZS5cbiAgICAgICAgLm1hcChmdW5jdGlvbiAocG9pbnQsIGksIGZpbmRlclBhdHRlcm5zKSB7XG4gICAgICAgIGlmIChpID4gTUFYX0ZJTkRFUlBBVFRFUk5TX1RPX1NFQVJDSCkge1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIG90aGVyUG9pbnRzID0gZmluZGVyUGF0dGVybnNcbiAgICAgICAgICAgIC5maWx0ZXIoZnVuY3Rpb24gKHAsIGlpKSB7IHJldHVybiBpICE9PSBpaTsgfSlcbiAgICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKHApIHsgcmV0dXJuICh7IHg6IHAueCwgeTogcC55LCBzY29yZTogcC5zY29yZSArIChNYXRoLnBvdygocC5zaXplIC0gcG9pbnQuc2l6ZSksIDIpKSAvIHBvaW50LnNpemUsIHNpemU6IHAuc2l6ZSB9KTsgfSlcbiAgICAgICAgICAgIC5zb3J0KGZ1bmN0aW9uIChhLCBiKSB7IHJldHVybiBhLnNjb3JlIC0gYi5zY29yZTsgfSk7XG4gICAgICAgIGlmIChvdGhlclBvaW50cy5sZW5ndGggPCAyKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICB2YXIgc2NvcmUgPSBwb2ludC5zY29yZSArIG90aGVyUG9pbnRzWzBdLnNjb3JlICsgb3RoZXJQb2ludHNbMV0uc2NvcmU7XG4gICAgICAgIHJldHVybiB7IHBvaW50czogW3BvaW50XS5jb25jYXQob3RoZXJQb2ludHMuc2xpY2UoMCwgMikpLCBzY29yZTogc2NvcmUgfTtcbiAgICB9KVxuICAgICAgICAuZmlsdGVyKGZ1bmN0aW9uIChxKSB7IHJldHVybiAhIXE7IH0pIC8vIEZpbHRlciBvdXQgYW55IHJlamVjdGVkIGZpbmRlciBwYXR0ZXJucyBmcm9tIGFib3ZlXG4gICAgICAgIC5zb3J0KGZ1bmN0aW9uIChhLCBiKSB7IHJldHVybiBhLnNjb3JlIC0gYi5zY29yZTsgfSk7XG4gICAgaWYgKGZpbmRlclBhdHRlcm5Hcm91cHMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICB2YXIgX2EgPSByZW9yZGVyRmluZGVyUGF0dGVybnMoZmluZGVyUGF0dGVybkdyb3Vwc1swXS5wb2ludHNbMF0sIGZpbmRlclBhdHRlcm5Hcm91cHNbMF0ucG9pbnRzWzFdLCBmaW5kZXJQYXR0ZXJuR3JvdXBzWzBdLnBvaW50c1syXSksIHRvcFJpZ2h0ID0gX2EudG9wUmlnaHQsIHRvcExlZnQgPSBfYS50b3BMZWZ0LCBib3R0b21MZWZ0ID0gX2EuYm90dG9tTGVmdDtcbiAgICB2YXIgYWxpZ25tZW50ID0gZmluZEFsaWdubWVudFBhdHRlcm4obWF0cml4LCBhbGlnbm1lbnRQYXR0ZXJuUXVhZHMsIHRvcFJpZ2h0LCB0b3BMZWZ0LCBib3R0b21MZWZ0KTtcbiAgICB2YXIgcmVzdWx0ID0gW107XG4gICAgaWYgKGFsaWdubWVudCkge1xuICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuOiB7IHg6IGFsaWdubWVudC5hbGlnbm1lbnRQYXR0ZXJuLngsIHk6IGFsaWdubWVudC5hbGlnbm1lbnRQYXR0ZXJuLnkgfSxcbiAgICAgICAgICAgIGJvdHRvbUxlZnQ6IHsgeDogYm90dG9tTGVmdC54LCB5OiBib3R0b21MZWZ0LnkgfSxcbiAgICAgICAgICAgIGRpbWVuc2lvbjogYWxpZ25tZW50LmRpbWVuc2lvbixcbiAgICAgICAgICAgIHRvcExlZnQ6IHsgeDogdG9wTGVmdC54LCB5OiB0b3BMZWZ0LnkgfSxcbiAgICAgICAgICAgIHRvcFJpZ2h0OiB7IHg6IHRvcFJpZ2h0LngsIHk6IHRvcFJpZ2h0LnkgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIC8vIFdlIG5vcm1hbGx5IHVzZSB0aGUgY2VudGVyIG9mIHRoZSBxdWFkcyBhcyB0aGUgbG9jYXRpb24gb2YgdGhlIHRyYWNraW5nIHBvaW50cywgd2hpY2ggaXMgb3B0aW1hbCBmb3IgbW9zdCBjYXNlcyBhbmQgd2lsbCBhY2NvdW50XG4gICAgLy8gZm9yIGEgc2tldyBpbiB0aGUgaW1hZ2UuIEhvd2V2ZXIsIEluIHNvbWUgY2FzZXMsIGEgc2xpZ2h0IHNrZXcgbWlnaHQgbm90IGJlIHJlYWwgYW5kIGluc3RlYWQgYmUgY2F1c2VkIGJ5IGltYWdlIGNvbXByZXNzaW9uXG4gICAgLy8gZXJyb3JzIGFuZC9vciBsb3cgcmVzb2x1dGlvbi4gRm9yIHRob3NlIGNhc2VzLCB3ZSdkIGJlIGJldHRlciBvZmYgY2VudGVyaW5nIHRoZSBwb2ludCBleGFjdGx5IGluIHRoZSBtaWRkbGUgb2YgdGhlIGJsYWNrIGFyZWEuIFdlXG4gICAgLy8gY29tcHV0ZSBhbmQgcmV0dXJuIHRoZSBsb2NhdGlvbiBkYXRhIGZvciB0aGUgbmFpdmVseSBjZW50ZXJlZCBwb2ludHMgYXMgaXQgaXMgbGl0dGxlIGFkZGl0aW9uYWwgd29yayBhbmQgYWxsb3dzIGZvciBtdWx0aXBsZVxuICAgIC8vIGF0dGVtcHRzIGF0IGRlY29kaW5nIGhhcmRlciBpbWFnZXMuXG4gICAgdmFyIG1pZFRvcFJpZ2h0ID0gcmVjZW50ZXJMb2NhdGlvbihtYXRyaXgsIHRvcFJpZ2h0KTtcbiAgICB2YXIgbWlkVG9wTGVmdCA9IHJlY2VudGVyTG9jYXRpb24obWF0cml4LCB0b3BMZWZ0KTtcbiAgICB2YXIgbWlkQm90dG9tTGVmdCA9IHJlY2VudGVyTG9jYXRpb24obWF0cml4LCBib3R0b21MZWZ0KTtcbiAgICB2YXIgY2VudGVyZWRBbGlnbm1lbnQgPSBmaW5kQWxpZ25tZW50UGF0dGVybihtYXRyaXgsIGFsaWdubWVudFBhdHRlcm5RdWFkcywgbWlkVG9wUmlnaHQsIG1pZFRvcExlZnQsIG1pZEJvdHRvbUxlZnQpO1xuICAgIGlmIChjZW50ZXJlZEFsaWdubWVudCkge1xuICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICBhbGlnbm1lbnRQYXR0ZXJuOiB7IHg6IGNlbnRlcmVkQWxpZ25tZW50LmFsaWdubWVudFBhdHRlcm4ueCwgeTogY2VudGVyZWRBbGlnbm1lbnQuYWxpZ25tZW50UGF0dGVybi55IH0sXG4gICAgICAgICAgICBib3R0b21MZWZ0OiB7IHg6IG1pZEJvdHRvbUxlZnQueCwgeTogbWlkQm90dG9tTGVmdC55IH0sXG4gICAgICAgICAgICB0b3BMZWZ0OiB7IHg6IG1pZFRvcExlZnQueCwgeTogbWlkVG9wTGVmdC55IH0sXG4gICAgICAgICAgICB0b3BSaWdodDogeyB4OiBtaWRUb3BSaWdodC54LCB5OiBtaWRUb3BSaWdodC55IH0sXG4gICAgICAgICAgICBkaW1lbnNpb246IGNlbnRlcmVkQWxpZ25tZW50LmRpbWVuc2lvbixcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChyZXN1bHQubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuZXhwb3J0cy5sb2NhdGUgPSBsb2NhdGU7XG5mdW5jdGlvbiBmaW5kQWxpZ25tZW50UGF0dGVybihtYXRyaXgsIGFsaWdubWVudFBhdHRlcm5RdWFkcywgdG9wUmlnaHQsIHRvcExlZnQsIGJvdHRvbUxlZnQpIHtcbiAgICB2YXIgX2E7XG4gICAgLy8gTm93IHRoYXQgd2UndmUgZm91bmQgdGhlIHRocmVlIGZpbmRlciBwYXR0ZXJucyB3ZSBjYW4gZGV0ZXJtaW5lIHRoZSBibG9ja1NpemUgYW5kIHRoZSBzaXplIG9mIHRoZSBRUiBjb2RlLlxuICAgIC8vIFdlJ2xsIHVzZSB0aGVzZSB0byBoZWxwIGZpbmQgdGhlIGFsaWdubWVudCBwYXR0ZXJuIGJ1dCBhbHNvIGxhdGVyIHdoZW4gd2UgZG8gdGhlIGV4dHJhY3Rpb24uXG4gICAgdmFyIGRpbWVuc2lvbjtcbiAgICB2YXIgbW9kdWxlU2l6ZTtcbiAgICB0cnkge1xuICAgICAgICAoX2EgPSBjb21wdXRlRGltZW5zaW9uKHRvcExlZnQsIHRvcFJpZ2h0LCBib3R0b21MZWZ0LCBtYXRyaXgpLCBkaW1lbnNpb24gPSBfYS5kaW1lbnNpb24sIG1vZHVsZVNpemUgPSBfYS5tb2R1bGVTaXplKTtcbiAgICB9XG4gICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIC8vIE5vdyBmaW5kIHRoZSBhbGlnbm1lbnQgcGF0dGVyblxuICAgIHZhciBib3R0b21SaWdodEZpbmRlclBhdHRlcm4gPSB7XG4gICAgICAgIHg6IHRvcFJpZ2h0LnggLSB0b3BMZWZ0LnggKyBib3R0b21MZWZ0LngsXG4gICAgICAgIHk6IHRvcFJpZ2h0LnkgLSB0b3BMZWZ0LnkgKyBib3R0b21MZWZ0LnksXG4gICAgfTtcbiAgICB2YXIgbW9kdWxlc0JldHdlZW5GaW5kZXJQYXR0ZXJucyA9ICgoZGlzdGFuY2UodG9wTGVmdCwgYm90dG9tTGVmdCkgKyBkaXN0YW5jZSh0b3BMZWZ0LCB0b3BSaWdodCkpIC8gMiAvIG1vZHVsZVNpemUpO1xuICAgIHZhciBjb3JyZWN0aW9uVG9Ub3BMZWZ0ID0gMSAtICgzIC8gbW9kdWxlc0JldHdlZW5GaW5kZXJQYXR0ZXJucyk7XG4gICAgdmFyIGV4cGVjdGVkQWxpZ25tZW50UGF0dGVybiA9IHtcbiAgICAgICAgeDogdG9wTGVmdC54ICsgY29ycmVjdGlvblRvVG9wTGVmdCAqIChib3R0b21SaWdodEZpbmRlclBhdHRlcm4ueCAtIHRvcExlZnQueCksXG4gICAgICAgIHk6IHRvcExlZnQueSArIGNvcnJlY3Rpb25Ub1RvcExlZnQgKiAoYm90dG9tUmlnaHRGaW5kZXJQYXR0ZXJuLnkgLSB0b3BMZWZ0LnkpLFxuICAgIH07XG4gICAgdmFyIGFsaWdubWVudFBhdHRlcm5zID0gYWxpZ25tZW50UGF0dGVyblF1YWRzXG4gICAgICAgIC5tYXAoZnVuY3Rpb24gKHEpIHtcbiAgICAgICAgdmFyIHggPSAocS50b3Auc3RhcnRYICsgcS50b3AuZW5kWCArIHEuYm90dG9tLnN0YXJ0WCArIHEuYm90dG9tLmVuZFgpIC8gNDtcbiAgICAgICAgdmFyIHkgPSAocS50b3AueSArIHEuYm90dG9tLnkgKyAxKSAvIDI7XG4gICAgICAgIGlmICghbWF0cml4LmdldChNYXRoLmZsb29yKHgpLCBNYXRoLmZsb29yKHkpKSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHZhciBsZW5ndGhzID0gW3EudG9wLmVuZFggLSBxLnRvcC5zdGFydFgsIHEuYm90dG9tLmVuZFggLSBxLmJvdHRvbS5zdGFydFgsIChxLmJvdHRvbS55IC0gcS50b3AueSArIDEpXTtcbiAgICAgICAgdmFyIHNpemUgPSBzdW0obGVuZ3RocykgLyBsZW5ndGhzLmxlbmd0aDtcbiAgICAgICAgdmFyIHNpemVTY29yZSA9IHNjb3JlUGF0dGVybih7IHg6IE1hdGguZmxvb3IoeCksIHk6IE1hdGguZmxvb3IoeSkgfSwgWzEsIDEsIDFdLCBtYXRyaXgpO1xuICAgICAgICB2YXIgc2NvcmUgPSBzaXplU2NvcmUgKyBkaXN0YW5jZSh7IHg6IHgsIHk6IHkgfSwgZXhwZWN0ZWRBbGlnbm1lbnRQYXR0ZXJuKTtcbiAgICAgICAgcmV0dXJuIHsgeDogeCwgeTogeSwgc2NvcmU6IHNjb3JlIH07XG4gICAgfSlcbiAgICAgICAgLmZpbHRlcihmdW5jdGlvbiAodikgeyByZXR1cm4gISF2OyB9KVxuICAgICAgICAuc29ydChmdW5jdGlvbiAoYSwgYikgeyByZXR1cm4gYS5zY29yZSAtIGIuc2NvcmU7IH0pO1xuICAgIC8vIElmIHRoZXJlIGFyZSBsZXNzIHRoYW4gMTUgbW9kdWxlcyBiZXR3ZWVuIGZpbmRlciBwYXR0ZXJucyBpdCdzIGEgdmVyc2lvbiAxIFFSIGNvZGUgYW5kIGFzIHN1Y2ggaGFzIG5vIGFsaWdubWVtbnQgcGF0dGVyblxuICAgIC8vIHNvIHdlIGNhbiBvbmx5IHVzZSBvdXIgYmVzdCBndWVzcy5cbiAgICB2YXIgYWxpZ25tZW50UGF0dGVybiA9IG1vZHVsZXNCZXR3ZWVuRmluZGVyUGF0dGVybnMgPj0gMTUgJiYgYWxpZ25tZW50UGF0dGVybnMubGVuZ3RoID8gYWxpZ25tZW50UGF0dGVybnNbMF0gOiBleHBlY3RlZEFsaWdubWVudFBhdHRlcm47XG4gICAgcmV0dXJuIHsgYWxpZ25tZW50UGF0dGVybjogYWxpZ25tZW50UGF0dGVybiwgZGltZW5zaW9uOiBkaW1lbnNpb24gfTtcbn1cblxuXG4vKioqLyB9KVxuLyoqKioqKi8gXSlbXCJkZWZhdWx0XCJdO1xufSk7Il0sIm1hcHBpbmdzIjoiOzs7Q0FBQSxDQUFDLFNBQVMsaUNBQWlDLE1BQU0sU0FBUztFQUN6RCxJQUFHLE9BQU8sWUFBWSxZQUFZLE9BQU8sV0FBVyxVQUNuRCxPQUFPLFVBQVUsUUFBUTtPQUNyQixJQUFHLE9BQU8sV0FBVyxjQUFjLE9BQU8sS0FDOUMsT0FBTyxDQUFDLEdBQUcsT0FBTztPQUNkLElBQUcsT0FBTyxZQUFZLFVBQzFCLFFBQVEsVUFBVSxRQUFRO09BRTFCLEtBQUssVUFBVSxRQUFRO0NBQ3pCLEVBQUEsQ0FBRyxPQUFPLFNBQVMsY0FBYyxPQUFBLFNBQWEsV0FBVztFQUN6RCxRQUFpQixTQUFTLFNBQVM7R0FFekIsSUFBSSxtQkFBbUIsQ0FBQztHQUd4QixTQUFTLG9CQUFvQixVQUFVO0lBR3RDLElBQUcsaUJBQWlCLFdBQ25CLE9BQU8saUJBQWlCLFNBQVMsQ0FBQztJQUduQyxJQUFJQSxXQUFTLGlCQUFpQixZQUFZO0tBQ3pDLEdBQUc7S0FDSCxHQUFHO0tBQ0gsU0FBUyxDQUFDO0lBQ1g7SUFHQSxRQUFRLFNBQVMsQ0FBQyxLQUFLQSxTQUFPLFNBQVNBLFVBQVFBLFNBQU8sU0FBUyxtQkFBbUI7SUFHbEYsU0FBTyxJQUFJO0lBR1gsT0FBT0EsU0FBTztHQUNmO0dBSUEsb0JBQW9CLElBQUk7R0FHeEIsb0JBQW9CLElBQUk7R0FHeEIsb0JBQW9CLElBQUksU0FBUyxXQUFTLE1BQU0sUUFBUTtJQUN2RCxJQUFHLENBQUMsb0JBQW9CLEVBQUVDLFdBQVMsSUFBSSxHQUN0QyxPQUFPLGVBQWVBLFdBQVMsTUFBTTtLQUNwQyxjQUFjO0tBQ2QsWUFBWTtLQUNaLEtBQUs7SUFDTixDQUFDO0dBRUg7R0FHQSxvQkFBb0IsSUFBSSxTQUFTLFVBQVE7SUFDeEMsSUFBSSxTQUFTRCxZQUFVQSxTQUFPLGFBQzdCLFNBQVMsYUFBYTtLQUFFLE9BQU9BLFNBQU87SUFBWSxJQUNsRCxTQUFTLG1CQUFtQjtLQUFFLE9BQU9BO0lBQVE7SUFDOUMsb0JBQW9CLEVBQUUsUUFBUSxLQUFLLE1BQU07SUFDekMsT0FBTztHQUNSO0dBR0Esb0JBQW9CLElBQUksU0FBUyxRQUFRLFVBQVU7SUFBRSxPQUFPLE9BQU8sVUFBVSxlQUFlLEtBQUssUUFBUSxRQUFRO0dBQUc7R0FHcEgsb0JBQW9CLElBQUk7R0FHeEIsT0FBTyxvQkFBb0Isb0JBQW9CLElBQUksQ0FBQztFQUNyRCxFQUFBLENBRUM7SUFFSCxTQUFTLFVBQVEsV0FBUyxxQkFBcUI7SUFFdEQ7SUFFQSxPQUFPLGVBQWVDLFdBQVMsY0FBYyxFQUFFLE9BQU8sS0FBSyxDQUFDO0lBNEI1RCxVQUFRLFlBM0J1QixXQUFZO0tBQ3ZDLFNBQVMsVUFBVSxNQUFNLE9BQU87TUFDNUIsS0FBSyxRQUFRO01BQ2IsS0FBSyxTQUFTLEtBQUssU0FBUztNQUM1QixLQUFLLE9BQU87S0FDaEI7S0FDQSxVQUFVLGNBQWMsU0FBVSxPQUFPLFFBQVE7TUFDN0MsT0FBTyxJQUFJLFVBQVUsSUFBSSxrQkFBa0IsUUFBUSxNQUFNLEdBQUcsS0FBSztLQUNyRTtLQUNBLFVBQVUsVUFBVSxNQUFNLFNBQVUsR0FBRyxHQUFHO01BQ3RDLElBQUksSUFBSSxLQUFLLEtBQUssS0FBSyxTQUFTLElBQUksS0FBSyxLQUFLLEtBQUssUUFDL0MsT0FBTztNQUVYLE9BQU8sQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLEtBQUssUUFBUTtLQUN4QztLQUNBLFVBQVUsVUFBVSxNQUFNLFNBQVUsR0FBRyxHQUFHLEdBQUc7TUFDekMsS0FBSyxLQUFLLElBQUksS0FBSyxRQUFRLEtBQUssSUFBSSxJQUFJO0tBQzVDO0tBQ0EsVUFBVSxVQUFVLFlBQVksU0FBVSxNQUFNLEtBQUssT0FBTyxRQUFRLEdBQUc7TUFDbkUsS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLE1BQU0sUUFBUSxLQUNoQyxLQUFLLElBQUksSUFBSSxNQUFNLElBQUksT0FBTyxPQUFPLEtBQ2pDLEtBQUssSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7S0FHOUI7S0FDQSxPQUFPO0lBQ1gsRUFDNEI7R0FHdEI7SUFFQyxTQUFTLFVBQVEsV0FBUyxxQkFBcUI7SUFFdEQ7SUFFQSxPQUFPLGVBQWVBLFdBQVMsY0FBYyxFQUFFLE9BQU8sS0FBSyxDQUFDO0lBQzVELElBQUksa0JBQWtCLG9CQUFvQixDQUFDO0lBQzNDLFNBQVMsZ0JBQWdCLEdBQUcsR0FBRztLQUMzQixPQUFPLElBQUk7SUFDZjtJQUNBLFVBQVEsa0JBQWtCO0lBd0QxQixVQUFRLFVBdkR1QixXQUFZO0tBQ3ZDLFNBQVMsVUFBVSxXQUFXLE1BQU0sU0FBUztNQUN6QyxLQUFLLFlBQVk7TUFDakIsS0FBSyxPQUFPO01BQ1osS0FBSyxnQkFBZ0I7TUFDckIsS0FBSyxXQUFXLElBQUksTUFBTSxLQUFLLElBQUk7TUFDbkMsS0FBSyxXQUFXLElBQUksTUFBTSxLQUFLLElBQUk7TUFDbkMsSUFBSSxJQUFJO01BQ1IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssTUFBTSxLQUFLO09BQ2hDLEtBQUssU0FBUyxLQUFLO09BQ25CLElBQUksSUFBSTtPQUNSLElBQUksS0FBSyxLQUFLLE1BQ1YsS0FBSyxJQUFJLEtBQUssYUFBYyxLQUFLLE9BQU87TUFFaEQ7TUFDQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxPQUFPLEdBQUcsS0FDL0IsS0FBSyxTQUFTLEtBQUssU0FBUyxNQUFNO01BRXRDLEtBQUssT0FBTyxJQUFJLGdCQUFnQixRQUFRLE1BQU0sa0JBQWtCLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUN6RSxLQUFLLE1BQU0sSUFBSSxnQkFBZ0IsUUFBUSxNQUFNLGtCQUFrQixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDNUU7S0FDQSxVQUFVLFVBQVUsV0FBVyxTQUFVLEdBQUcsR0FBRztNQUMzQyxJQUFJLE1BQU0sS0FBSyxNQUFNLEdBQ2pCLE9BQU87TUFFWCxPQUFPLEtBQUssVUFBVSxLQUFLLFNBQVMsS0FBSyxLQUFLLFNBQVMsT0FBTyxLQUFLLE9BQU87S0FDOUU7S0FDQSxVQUFVLFVBQVUsVUFBVSxTQUFVLEdBQUc7TUFDdkMsSUFBSSxNQUFNLEdBQ04sTUFBTSxJQUFJLE1BQU0sZ0JBQWdCO01BRXBDLE9BQU8sS0FBSyxTQUFTLEtBQUssT0FBTyxLQUFLLFNBQVMsS0FBSztLQUN4RDtLQUNBLFVBQVUsVUFBVSxnQkFBZ0IsU0FBVSxRQUFRLGFBQWE7TUFDL0QsSUFBSSxTQUFTLEdBQ1QsTUFBTSxJQUFJLE1BQU0scUNBQXFDO01BRXpELElBQUksZ0JBQWdCLEdBQ2hCLE9BQU8sS0FBSztNQUVoQixJQUFJLGVBQWUsSUFBSSxrQkFBa0IsU0FBUyxDQUFDO01BQ25ELGFBQWEsS0FBSztNQUNsQixPQUFPLElBQUksZ0JBQWdCLFFBQVEsTUFBTSxZQUFZO0tBQ3pEO0tBQ0EsVUFBVSxVQUFVLE1BQU0sU0FBVSxHQUFHO01BQ25DLElBQUksTUFBTSxHQUNOLE1BQU0sSUFBSSxNQUFNLG1CQUFtQjtNQUV2QyxPQUFPLEtBQUssU0FBUztLQUN6QjtLQUNBLFVBQVUsVUFBVSxNQUFNLFNBQVUsR0FBRztNQUNuQyxPQUFPLEtBQUssU0FBUztLQUN6QjtLQUNBLE9BQU87SUFDWCxFQUMwQjtHQUdwQjtJQUVDLFNBQVMsVUFBUSxXQUFTLHFCQUFxQjtJQUV0RDtJQUVBLE9BQU8sZUFBZUEsV0FBUyxjQUFjLEVBQUUsT0FBTyxLQUFLLENBQUM7SUFDNUQsSUFBSSxjQUFjLG9CQUFvQixDQUFDO0lBK0h2QyxVQUFRLFVBOUgyQixXQUFZO0tBQzNDLFNBQVMsY0FBYyxPQUFPLGNBQWM7TUFDeEMsSUFBSSxhQUFhLFdBQVcsR0FDeEIsTUFBTSxJQUFJLE1BQU0sa0JBQWtCO01BRXRDLEtBQUssUUFBUTtNQUNiLElBQUkscUJBQXFCLGFBQWE7TUFDdEMsSUFBSSxxQkFBcUIsS0FBSyxhQUFhLE9BQU8sR0FBRztPQUVqRCxJQUFJLGVBQWU7T0FDbkIsT0FBTyxlQUFlLHNCQUFzQixhQUFhLGtCQUFrQixHQUN2RTtPQUVKLElBQUksaUJBQWlCLG9CQUNqQixLQUFLLGVBQWUsTUFBTSxLQUFLO1lBRTlCO1FBQ0QsS0FBSyxlQUFlLElBQUksa0JBQWtCLHFCQUFxQixZQUFZO1FBQzNFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLGFBQWEsUUFBUSxLQUMxQyxLQUFLLGFBQWEsS0FBSyxhQUFhLGVBQWU7T0FFM0Q7TUFDSixPQUVJLEtBQUssZUFBZTtLQUU1QjtLQUNBLGNBQWMsVUFBVSxTQUFTLFdBQVk7TUFDekMsT0FBTyxLQUFLLGFBQWEsU0FBUztLQUN0QztLQUNBLGNBQWMsVUFBVSxTQUFTLFdBQVk7TUFDekMsT0FBTyxLQUFLLGFBQWEsT0FBTztLQUNwQztLQUNBLGNBQWMsVUFBVSxpQkFBaUIsU0FBVSxRQUFRO01BQ3ZELE9BQU8sS0FBSyxhQUFhLEtBQUssYUFBYSxTQUFTLElBQUk7S0FDNUQ7S0FDQSxjQUFjLFVBQVUsZ0JBQWdCLFNBQVUsT0FBTztNQUNyRCxJQUFJO01BQ0osSUFBSSxLQUFLLE9BQU8sR0FDWixPQUFPO01BRVgsSUFBSSxNQUFNLE9BQU8sR0FDYixPQUFPO01BRVgsSUFBSSxzQkFBc0IsS0FBSztNQUMvQixJQUFJLHFCQUFxQixNQUFNO01BQy9CLElBQUksb0JBQW9CLFNBQVMsbUJBQW1CLFFBQ2hELEtBQUssQ0FBQyxvQkFBb0IsbUJBQW1CLEdBQUcsc0JBQXNCLEdBQUcsSUFBSSxxQkFBcUIsR0FBRztNQUV6RyxJQUFJLFVBQVUsSUFBSSxrQkFBa0IsbUJBQW1CLE1BQU07TUFDN0QsSUFBSSxhQUFhLG1CQUFtQixTQUFTLG9CQUFvQjtNQUNqRSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksWUFBWSxLQUM1QixRQUFRLEtBQUssbUJBQW1CO01BRXBDLEtBQUssSUFBSSxJQUFJLFlBQVksSUFBSSxtQkFBbUIsUUFBUSxLQUNwRCxRQUFRLEtBQUssWUFBWSxnQkFBZ0Isb0JBQW9CLElBQUksYUFBYSxtQkFBbUIsRUFBRTtNQUV2RyxPQUFPLElBQUksY0FBYyxLQUFLLE9BQU8sT0FBTztLQUNoRDtLQUNBLGNBQWMsVUFBVSxXQUFXLFNBQVUsUUFBUTtNQUNqRCxJQUFJLFdBQVcsR0FDWCxPQUFPLEtBQUssTUFBTTtNQUV0QixJQUFJLFdBQVcsR0FDWCxPQUFPO01BRVgsSUFBSSxPQUFPLEtBQUssYUFBYTtNQUM3QixJQUFJLFVBQVUsSUFBSSxrQkFBa0IsSUFBSTtNQUN4QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxLQUN0QixRQUFRLEtBQUssS0FBSyxNQUFNLFNBQVMsS0FBSyxhQUFhLElBQUksTUFBTTtNQUVqRSxPQUFPLElBQUksY0FBYyxLQUFLLE9BQU8sT0FBTztLQUNoRDtLQUNBLGNBQWMsVUFBVSxlQUFlLFNBQVUsT0FBTztNQUNwRCxJQUFJLEtBQUssT0FBTyxLQUFLLE1BQU0sT0FBTyxHQUM5QixPQUFPLEtBQUssTUFBTTtNQUV0QixJQUFJLGdCQUFnQixLQUFLO01BQ3pCLElBQUksVUFBVSxjQUFjO01BQzVCLElBQUksZ0JBQWdCLE1BQU07TUFDMUIsSUFBSSxVQUFVLGNBQWM7TUFDNUIsSUFBSSxVQUFVLElBQUksa0JBQWtCLFVBQVUsVUFBVSxDQUFDO01BQ3pELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLEtBQUs7T0FDOUIsSUFBSSxTQUFTLGNBQWM7T0FDM0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsS0FDekIsUUFBUSxJQUFJLEtBQUssWUFBWSxnQkFBZ0IsUUFBUSxJQUFJLElBQUksS0FBSyxNQUFNLFNBQVMsUUFBUSxjQUFjLEVBQUUsQ0FBQztNQUVsSDtNQUNBLE9BQU8sSUFBSSxjQUFjLEtBQUssT0FBTyxPQUFPO0tBQ2hEO0tBQ0EsY0FBYyxVQUFVLHFCQUFxQixTQUFVLFFBQVEsYUFBYTtNQUN4RSxJQUFJLFNBQVMsR0FDVCxNQUFNLElBQUksTUFBTSw0QkFBNEI7TUFFaEQsSUFBSSxnQkFBZ0IsR0FDaEIsT0FBTyxLQUFLLE1BQU07TUFFdEIsSUFBSSxPQUFPLEtBQUssYUFBYTtNQUM3QixJQUFJLFVBQVUsSUFBSSxrQkFBa0IsT0FBTyxNQUFNO01BQ2pELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLEtBQ3RCLFFBQVEsS0FBSyxLQUFLLE1BQU0sU0FBUyxLQUFLLGFBQWEsSUFBSSxXQUFXO01BRXRFLE9BQU8sSUFBSSxjQUFjLEtBQUssT0FBTyxPQUFPO0tBQ2hEO0tBQ0EsY0FBYyxVQUFVLGFBQWEsU0FBVSxHQUFHO01BQzlDLElBQUksU0FBUztNQUNiLElBQUksTUFBTSxHQUVOLE9BQU8sS0FBSyxlQUFlLENBQUM7TUFFaEMsSUFBSSxPQUFPLEtBQUssYUFBYTtNQUM3QixJQUFJLE1BQU0sR0FBRztPQUVULEtBQUssYUFBYSxRQUFRLFNBQVUsYUFBYTtRQUM3QyxTQUFTLFlBQVksZ0JBQWdCLFFBQVEsV0FBVztPQUM1RCxDQUFDO09BQ0QsT0FBTztNQUNYO01BQ0EsU0FBUyxLQUFLLGFBQWE7TUFDM0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sS0FDdEIsU0FBUyxZQUFZLGdCQUFnQixLQUFLLE1BQU0sU0FBUyxHQUFHLE1BQU0sR0FBRyxLQUFLLGFBQWEsRUFBRTtNQUU3RixPQUFPO0tBQ1g7S0FDQSxPQUFPO0lBQ1gsRUFDOEI7R0FHeEI7SUFFQyxTQUFTLFVBQVEsV0FBUyxxQkFBcUI7SUFFdEQ7SUFFQSxPQUFPLGVBQWVBLFdBQVMsY0FBYyxFQUFFLE9BQU8sS0FBSyxDQUFDO0lBQzVELElBQUksY0FBYyxvQkFBb0IsQ0FBQztJQUN2QyxJQUFJLFlBQVksb0JBQW9CLENBQUM7SUFDckMsSUFBSSxjQUFjLG9CQUFvQixFQUFFO0lBQ3hDLElBQUksWUFBWSxvQkFBb0IsRUFBRTtJQUN0QyxTQUFTLEtBQUssUUFBUTtLQUNsQixJQUFJLFlBQVksVUFBVSxPQUFPLE1BQU07S0FDdkMsSUFBSSxDQUFDLFdBQ0QsT0FBTztLQUVYLEtBQUssSUFBSSxLQUFLLEdBQUcsY0FBYyxXQUFXLEtBQUssWUFBWSxRQUFRLE1BQU07TUFDckUsSUFBSSxhQUFhLFlBQVk7TUFDN0IsSUFBSSxZQUFZLFlBQVksUUFBUSxRQUFRLFVBQVU7TUFDdEQsSUFBSSxVQUFVLFVBQVUsT0FBTyxVQUFVLE1BQU07TUFDL0MsSUFBSSxTQUNBLE9BQU87T0FDSCxZQUFZLFFBQVE7T0FDcEIsTUFBTSxRQUFRO09BQ2QsUUFBUSxRQUFRO09BQ2hCLFNBQVMsUUFBUTtPQUNqQixVQUFVO1FBQ04sZ0JBQWdCLFVBQVUsZ0JBQWdCLFdBQVcsV0FBVyxDQUFDO1FBQ2pFLGVBQWUsVUFBVSxnQkFBZ0IsR0FBRyxDQUFDO1FBQzdDLG1CQUFtQixVQUFVLGdCQUFnQixXQUFXLFdBQVcsV0FBVyxTQUFTO1FBQ3ZGLGtCQUFrQixVQUFVLGdCQUFnQixHQUFHLFdBQVcsU0FBUztRQUNuRSx1QkFBdUIsV0FBVztRQUNsQyxzQkFBc0IsV0FBVztRQUNqQyx5QkFBeUIsV0FBVztRQUNwQyw2QkFBNkIsV0FBVztPQUM1QztNQUNKO0tBRVI7S0FDQSxPQUFPO0lBQ1g7SUFDQSxJQUFJLGlCQUFpQixFQUNqQixtQkFBbUIsY0FDdkI7SUFDQSxTQUFTLEtBQUssTUFBTSxPQUFPLFFBQVEsaUJBQWlCO0tBQ2hELElBQUksb0JBQW9CLEtBQUssR0FBSyxrQkFBa0IsQ0FBQztLQUNyRCxJQUFJLFVBQVU7S0FDZCxPQUFPLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsU0FBVSxLQUFLO01BQzlDLFFBQVEsT0FBTyxnQkFBZ0IsUUFBUSxRQUFRO0tBQ25ELENBQUM7S0FDRCxJQUFJLGVBQWUsUUFBUSxzQkFBc0IsaUJBQWlCLFFBQVEsc0JBQXNCO0tBQ2hHLElBQUksbUJBQW1CLFFBQVEsc0JBQXNCLGdCQUFnQixRQUFRLHNCQUFzQjtLQUNuRyxJQUFJLEtBQUssWUFBWSxTQUFTLE1BQU0sT0FBTyxRQUFRLFlBQVksR0FBRyxZQUFZLEdBQUcsV0FBVyxXQUFXLEdBQUc7S0FDMUcsSUFBSSxTQUFTLEtBQUssbUJBQW1CLFdBQVcsU0FBUztLQUN6RCxJQUFJLENBQUMsV0FBVyxRQUFRLHNCQUFzQixpQkFBaUIsUUFBUSxzQkFBc0IsZ0JBQ3pGLFNBQVMsS0FBSyxtQkFBbUIsWUFBWSxRQUFRO0tBRXpELE9BQU87SUFDWDtJQUNBLEtBQUssVUFBVTtJQUNmLFVBQVEsVUFBVTtHQUdaO0lBRUMsU0FBUyxVQUFRLFdBQVMscUJBQXFCO0lBRXREO0lBRUEsT0FBTyxlQUFlQSxXQUFTLGNBQWMsRUFBRSxPQUFPLEtBQUssQ0FBQztJQUM1RCxJQUFJLGNBQWMsb0JBQW9CLENBQUM7SUFDdkMsSUFBSSxjQUFjO0lBQ2xCLElBQUksb0JBQW9CO0lBQ3hCLFNBQVMsV0FBVyxPQUFPLEtBQUssS0FBSztLQUNqQyxPQUFPLFFBQVEsTUFBTSxNQUFNLFFBQVEsTUFBTSxNQUFNO0lBQ25EO0lBRUEsSUFBSSxTQUF3QixXQUFZO0tBQ3BDLFNBQVMsT0FBTyxPQUFPLFFBQVE7TUFDM0IsS0FBSyxRQUFRO01BQ2IsS0FBSyxPQUFPLElBQUksa0JBQWtCLFFBQVEsTUFBTTtLQUNwRDtLQUNBLE9BQU8sVUFBVSxNQUFNLFNBQVUsR0FBRyxHQUFHO01BQ25DLE9BQU8sS0FBSyxLQUFLLElBQUksS0FBSyxRQUFRO0tBQ3RDO0tBQ0EsT0FBTyxVQUFVLE1BQU0sU0FBVSxHQUFHLEdBQUcsT0FBTztNQUMxQyxLQUFLLEtBQUssSUFBSSxLQUFLLFFBQVEsS0FBSztLQUNwQztLQUNBLE9BQU87SUFDWCxFQUFFO0lBQ0YsU0FBUyxTQUFTLE1BQU0sT0FBTyxRQUFRLGdCQUFnQjtLQUNuRCxJQUFJLEtBQUssV0FBVyxRQUFRLFNBQVMsR0FDakMsTUFBTSxJQUFJLE1BQU0scUNBQXFDO0tBR3pELElBQUksa0JBQWtCLElBQUksT0FBTyxPQUFPLE1BQU07S0FDOUMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sS0FDdkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FBSztNQUM3QixJQUFJLElBQUksTUFBTyxJQUFJLFFBQVEsS0FBSyxJQUFLO01BQ3JDLElBQUksSUFBSSxNQUFPLElBQUksUUFBUSxLQUFLLElBQUs7TUFDckMsSUFBSSxJQUFJLE1BQU8sSUFBSSxRQUFRLEtBQUssSUFBSztNQUNyQyxnQkFBZ0IsSUFBSSxHQUFHLEdBQUcsUUFBUyxJQUFJLFFBQVMsSUFBSSxRQUFTLENBQUM7S0FDbEU7S0FFSixJQUFJLHdCQUF3QixLQUFLLEtBQUssUUFBUSxXQUFXO0tBQ3pELElBQUksc0JBQXNCLEtBQUssS0FBSyxTQUFTLFdBQVc7S0FDeEQsSUFBSSxjQUFjLElBQUksT0FBTyx1QkFBdUIsbUJBQW1CO0tBQ3ZFLEtBQUssSUFBSSxpQkFBaUIsR0FBRyxpQkFBaUIscUJBQXFCLGtCQUMvRCxLQUFLLElBQUksb0JBQW9CLEdBQUcsb0JBQW9CLHVCQUF1QixxQkFBcUI7TUFDNUYsSUFBSSxNQUFNO01BQ1YsSUFBSSxNQUFNO01BQ1YsSUFBSSxNQUFNO01BQ1YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGFBQWEsS0FDN0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGFBQWEsS0FBSztPQUNsQyxJQUFJLGdCQUFnQixnQkFBZ0IsSUFBSSxvQkFBb0IsY0FBYyxHQUFHLGlCQUFpQixjQUFjLENBQUM7T0FDN0csT0FBTztPQUNQLE1BQU0sS0FBSyxJQUFJLEtBQUssYUFBYTtPQUNqQyxNQUFNLEtBQUssSUFBSSxLQUFLLGFBQWE7TUFDckM7TUFFSixJQUFJLFVBQVUsTUFBTyxLQUFLLElBQUksYUFBYSxDQUFDO01BQzVDLElBQUksTUFBTSxPQUFPLG1CQUFtQjtPQU1oQyxVQUFVLE1BQU07T0FDaEIsSUFBSSxpQkFBaUIsS0FBSyxvQkFBb0IsR0FBRztRQU83QyxJQUFJLDZCQUE2QixZQUFZLElBQUksbUJBQW1CLGlCQUFpQixDQUFDLElBQ2pGLElBQUksWUFBWSxJQUFJLG9CQUFvQixHQUFHLGNBQWMsSUFDMUQsWUFBWSxJQUFJLG9CQUFvQixHQUFHLGlCQUFpQixDQUFDLEtBQUs7UUFDbEUsSUFBSSxNQUFNLDJCQUNOLFVBQVU7T0FFbEI7TUFDSjtNQUNBLFlBQVksSUFBSSxtQkFBbUIsZ0JBQWdCLE9BQU87S0FDOUQ7S0FFSixJQUFJLFlBQVksWUFBWSxVQUFVLFlBQVksT0FBTyxNQUFNO0tBQy9ELElBQUksV0FBVztLQUNmLElBQUksZ0JBQ0EsV0FBVyxZQUFZLFVBQVUsWUFBWSxPQUFPLE1BQU07S0FFOUQsS0FBSyxJQUFJLGlCQUFpQixHQUFHLGlCQUFpQixxQkFBcUIsa0JBQy9ELEtBQUssSUFBSSxvQkFBb0IsR0FBRyxvQkFBb0IsdUJBQXVCLHFCQUFxQjtNQUM1RixJQUFJLE9BQU8sV0FBVyxtQkFBbUIsR0FBRyx3QkFBd0IsQ0FBQztNQUNyRSxJQUFJLFFBQVEsV0FBVyxnQkFBZ0IsR0FBRyxzQkFBc0IsQ0FBQztNQUNqRSxJQUFJLE1BQU07TUFDVixLQUFLLElBQUksVUFBVSxJQUFJLFdBQVcsR0FBRyxXQUNqQyxLQUFLLElBQUksVUFBVSxJQUFJLFdBQVcsR0FBRyxXQUNqQyxPQUFPLFlBQVksSUFBSSxPQUFPLFNBQVMsUUFBUSxPQUFPO01BRzlELElBQUksWUFBWSxNQUFNO01BQ3RCLEtBQUssSUFBSSxVQUFVLEdBQUcsVUFBVSxhQUFhLFdBQ3pDLEtBQUssSUFBSSxVQUFVLEdBQUcsVUFBVSxhQUFhLFdBQVc7T0FDcEQsSUFBSSxJQUFJLG9CQUFvQixjQUFjO09BQzFDLElBQUksSUFBSSxpQkFBaUIsY0FBYztPQUN2QyxJQUFJLE1BQU0sZ0JBQWdCLElBQUksR0FBRyxDQUFDO09BQ2xDLFVBQVUsSUFBSSxHQUFHLEdBQUcsT0FBTyxTQUFTO09BQ3BDLElBQUksZ0JBQ0EsU0FBUyxJQUFJLEdBQUcsR0FBRyxFQUFFLE9BQU8sVUFBVTtNQUU5QztLQUVSO0tBRUosSUFBSSxnQkFDQSxPQUFPO01BQWE7TUFBcUI7S0FBUztLQUV0RCxPQUFPLEVBQWEsVUFBVTtJQUNsQztJQUNBLFVBQVEsV0FBVztHQUdiO0lBRUMsU0FBUyxVQUFRLFdBQVMscUJBQXFCO0lBRXREO0lBRUEsT0FBTyxlQUFlQSxXQUFTLGNBQWMsRUFBRSxPQUFPLEtBQUssQ0FBQztJQUM1RCxJQUFJLGNBQWMsb0JBQW9CLENBQUM7SUFDdkMsSUFBSSxlQUFlLG9CQUFvQixDQUFDO0lBQ3hDLElBQUksZ0JBQWdCLG9CQUFvQixDQUFDO0lBQ3pDLElBQUksWUFBWSxvQkFBb0IsRUFBRTtJQUV0QyxTQUFTLGlCQUFpQixHQUFHLEdBQUc7S0FDNUIsSUFBSSxJQUFJLElBQUk7S0FDWixJQUFJLFdBQVc7S0FDZixPQUFPLEdBQUc7TUFDTjtNQUNBLEtBQUssSUFBSTtLQUNiO0tBQ0EsT0FBTztJQUNYO0lBQ0EsU0FBUyxRQUFRLEtBQUssTUFBTTtLQUN4QixPQUFRLFFBQVEsSUFBSztJQUN6QjtJQUVBLElBQUksb0JBQW9CO0tBQ3BCO01BQUUsTUFBTTtNQUFRLFlBQVk7T0FBRSxzQkFBc0I7T0FBRyxVQUFVO01BQUU7S0FBRTtLQUNyRTtNQUFFLE1BQU07TUFBUSxZQUFZO09BQUUsc0JBQXNCO09BQUcsVUFBVTtNQUFFO0tBQUU7S0FDckU7TUFBRSxNQUFNO01BQVEsWUFBWTtPQUFFLHNCQUFzQjtPQUFHLFVBQVU7TUFBRTtLQUFFO0tBQ3JFO01BQUUsTUFBTTtNQUFRLFlBQVk7T0FBRSxzQkFBc0I7T0FBRyxVQUFVO01BQUU7S0FBRTtLQUNyRTtNQUFFLE1BQU07TUFBUSxZQUFZO09BQUUsc0JBQXNCO09BQUcsVUFBVTtNQUFFO0tBQUU7S0FDckU7TUFBRSxNQUFNO01BQVEsWUFBWTtPQUFFLHNCQUFzQjtPQUFHLFVBQVU7TUFBRTtLQUFFO0tBQ3JFO01BQUUsTUFBTTtNQUFRLFlBQVk7T0FBRSxzQkFBc0I7T0FBRyxVQUFVO01BQUU7S0FBRTtLQUNyRTtNQUFFLE1BQU07TUFBUSxZQUFZO09BQUUsc0JBQXNCO09BQUcsVUFBVTtNQUFFO0tBQUU7S0FDckU7TUFBRSxNQUFNO01BQVEsWUFBWTtPQUFFLHNCQUFzQjtPQUFHLFVBQVU7TUFBRTtLQUFFO0tBQ3JFO01BQUUsTUFBTTtNQUFRLFlBQVk7T0FBRSxzQkFBc0I7T0FBRyxVQUFVO01BQUU7S0FBRTtLQUNyRTtNQUFFLE1BQU07TUFBUSxZQUFZO09BQUUsc0JBQXNCO09BQUcsVUFBVTtNQUFFO0tBQUU7S0FDckU7TUFBRSxNQUFNO01BQVEsWUFBWTtPQUFFLHNCQUFzQjtPQUFHLFVBQVU7TUFBRTtLQUFFO0tBQ3JFO01BQUUsTUFBTTtNQUFRLFlBQVk7T0FBRSxzQkFBc0I7T0FBRyxVQUFVO01BQUU7S0FBRTtLQUNyRTtNQUFFLE1BQU07TUFBUSxZQUFZO09BQUUsc0JBQXNCO09BQUcsVUFBVTtNQUFFO0tBQUU7S0FDckU7TUFBRSxNQUFNO01BQVEsWUFBWTtPQUFFLHNCQUFzQjtPQUFHLFVBQVU7TUFBRTtLQUFFO0tBQ3JFO01BQUUsTUFBTTtNQUFRLFlBQVk7T0FBRSxzQkFBc0I7T0FBRyxVQUFVO01BQUU7S0FBRTtLQUNyRTtNQUFFLE1BQU07TUFBUSxZQUFZO09BQUUsc0JBQXNCO09BQUcsVUFBVTtNQUFFO0tBQUU7S0FDckU7TUFBRSxNQUFNO01BQVEsWUFBWTtPQUFFLHNCQUFzQjtPQUFHLFVBQVU7TUFBRTtLQUFFO0tBQ3JFO01BQUUsTUFBTTtNQUFRLFlBQVk7T0FBRSxzQkFBc0I7T0FBRyxVQUFVO01BQUU7S0FBRTtLQUNyRTtNQUFFLE1BQU07TUFBUSxZQUFZO09BQUUsc0JBQXNCO09BQUcsVUFBVTtNQUFFO0tBQUU7S0FDckU7TUFBRSxNQUFNO01BQVEsWUFBWTtPQUFFLHNCQUFzQjtPQUFHLFVBQVU7TUFBRTtLQUFFO0tBQ3JFO01BQUUsTUFBTTtNQUFRLFlBQVk7T0FBRSxzQkFBc0I7T0FBRyxVQUFVO01BQUU7S0FBRTtLQUNyRTtNQUFFLE1BQU07TUFBUSxZQUFZO09BQUUsc0JBQXNCO09BQUcsVUFBVTtNQUFFO0tBQUU7S0FDckU7TUFBRSxNQUFNO01BQVEsWUFBWTtPQUFFLHNCQUFzQjtPQUFHLFVBQVU7TUFBRTtLQUFFO0tBQ3JFO01BQUUsTUFBTTtNQUFRLFlBQVk7T0FBRSxzQkFBc0I7T0FBRyxVQUFVO01BQUU7S0FBRTtLQUNyRTtNQUFFLE1BQU07TUFBUSxZQUFZO09BQUUsc0JBQXNCO09BQUcsVUFBVTtNQUFFO0tBQUU7S0FDckU7TUFBRSxNQUFNO01BQVEsWUFBWTtPQUFFLHNCQUFzQjtPQUFHLFVBQVU7TUFBRTtLQUFFO0tBQ3JFO01BQUUsTUFBTTtNQUFRLFlBQVk7T0FBRSxzQkFBc0I7T0FBRyxVQUFVO01BQUU7S0FBRTtLQUNyRTtNQUFFLE1BQU07TUFBUSxZQUFZO09BQUUsc0JBQXNCO09BQUcsVUFBVTtNQUFFO0tBQUU7S0FDckU7TUFBRSxNQUFNO01BQVEsWUFBWTtPQUFFLHNCQUFzQjtPQUFHLFVBQVU7TUFBRTtLQUFFO0tBQ3JFO01BQUUsTUFBTTtNQUFRLFlBQVk7T0FBRSxzQkFBc0I7T0FBRyxVQUFVO01BQUU7S0FBRTtLQUNyRTtNQUFFLE1BQU07TUFBUSxZQUFZO09BQUUsc0JBQXNCO09BQUcsVUFBVTtNQUFFO0tBQUU7SUFDekU7SUFDQSxJQUFJLGFBQWE7S0FDYixTQUFVLEdBQUc7TUFBRSxRQUFTLEVBQUUsSUFBSSxFQUFFLEtBQUssTUFBTztLQUFHO0tBQy9DLFNBQVUsR0FBRztNQUFFLE9BQVEsRUFBRSxJQUFJLE1BQU87S0FBRztLQUN2QyxTQUFVLEdBQUc7TUFBRSxPQUFPLEVBQUUsSUFBSSxNQUFNO0tBQUc7S0FDckMsU0FBVSxHQUFHO01BQUUsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLE1BQU07S0FBRztLQUM3QyxTQUFVLEdBQUc7TUFBRSxRQUFRLEtBQUssTUFBTSxFQUFFLElBQUksQ0FBQyxJQUFJLEtBQUssTUFBTSxFQUFFLElBQUksQ0FBQyxLQUFLLE1BQU07S0FBRztLQUM3RSxTQUFVLEdBQUc7TUFBRSxPQUFTLEVBQUUsSUFBSSxFQUFFLElBQUssSUFBTyxFQUFFLElBQUksRUFBRSxJQUFLLE1BQU87S0FBRztLQUNuRSxTQUFVLEdBQUc7TUFBRSxRQUFXLEVBQUUsSUFBSSxFQUFFLElBQUssSUFBTSxFQUFFLElBQUksRUFBRSxJQUFLLEtBQUssTUFBTztLQUFHO0tBQ3pFLFNBQVUsR0FBRztNQUFFLFNBQVcsRUFBRSxJQUFJLEVBQUUsS0FBSyxJQUFNLEVBQUUsSUFBSSxFQUFFLElBQUssS0FBSyxNQUFPO0tBQUc7SUFDN0U7SUFDQSxTQUFTLHlCQUF5QixTQUFTO0tBQ3ZDLElBQUksWUFBWSxLQUFLLElBQUksUUFBUTtLQUNqQyxJQUFJLFNBQVMsWUFBWSxVQUFVLFlBQVksV0FBVyxTQUFTO0tBQ25FLE9BQU8sVUFBVSxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUk7S0FDakMsT0FBTyxVQUFVLFlBQVksR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJO0tBQzdDLE9BQU8sVUFBVSxHQUFHLFlBQVksR0FBRyxHQUFHLEdBQUcsSUFBSTtLQUU3QyxLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssUUFBUSx5QkFBeUIsS0FBSyxHQUFHLFFBQVEsTUFBTTtNQUN6RSxJQUFJLElBQUksR0FBRztNQUNYLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxRQUFRLHlCQUF5QixLQUFLLEdBQUcsUUFBUSxNQUFNO09BQ3pFLElBQUksSUFBSSxHQUFHO09BQ1gsSUFBSSxFQUFFLE1BQU0sS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sWUFBWSxLQUFLLE1BQU0sWUFBWSxLQUFLLE1BQU0sSUFDdkYsT0FBTyxVQUFVLElBQUksR0FBRyxJQUFJLEdBQUcsR0FBRyxHQUFHLElBQUk7TUFFakQ7S0FDSjtLQUNBLE9BQU8sVUFBVSxHQUFHLEdBQUcsR0FBRyxZQUFZLElBQUksSUFBSTtLQUM5QyxPQUFPLFVBQVUsR0FBRyxHQUFHLFlBQVksSUFBSSxHQUFHLElBQUk7S0FDOUMsSUFBSSxRQUFRLGdCQUFnQixHQUFHO01BQzNCLE9BQU8sVUFBVSxZQUFZLElBQUksR0FBRyxHQUFHLEdBQUcsSUFBSTtNQUM5QyxPQUFPLFVBQVUsR0FBRyxZQUFZLElBQUksR0FBRyxHQUFHLElBQUk7S0FDbEQ7S0FDQSxPQUFPO0lBQ1g7SUFDQSxTQUFTLGNBQWMsUUFBUSxTQUFTLFlBQVk7S0FDaEQsSUFBSSxXQUFXLFdBQVcsV0FBVztLQUNyQyxJQUFJLFlBQVksT0FBTztLQUN2QixJQUFJLHNCQUFzQix5QkFBeUIsT0FBTztLQUMxRCxJQUFJLFlBQVksQ0FBQztLQUNqQixJQUFJLGNBQWM7S0FDbEIsSUFBSSxXQUFXO0tBRWYsSUFBSSxZQUFZO0tBQ2hCLEtBQUssSUFBSSxjQUFjLFlBQVksR0FBRyxjQUFjLEdBQUcsZUFBZSxHQUFHO01BQ3JFLElBQUksZ0JBQWdCLEdBQ2hCO01BRUosS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFdBQVcsS0FBSztPQUNoQyxJQUFJLElBQUksWUFBWSxZQUFZLElBQUksSUFBSTtPQUN4QyxLQUFLLElBQUksZUFBZSxHQUFHLGVBQWUsR0FBRyxnQkFBZ0I7UUFDekQsSUFBSSxJQUFJLGNBQWM7UUFDdEIsSUFBSSxDQUFDLG9CQUFvQixJQUFJLEdBQUcsQ0FBQyxHQUFHO1NBQ2hDO1NBQ0EsSUFBSSxNQUFNLE9BQU8sSUFBSSxHQUFHLENBQUM7U0FDekIsSUFBSSxTQUFTO1VBQUs7VUFBTTtTQUFFLENBQUMsR0FDdkIsTUFBTSxDQUFDO1NBRVgsY0FBYyxRQUFRLEtBQUssV0FBVztTQUN0QyxJQUFJLGFBQWEsR0FBRztVQUNoQixVQUFVLEtBQUssV0FBVztVQUMxQixXQUFXO1VBQ1gsY0FBYztTQUNsQjtRQUNKO09BQ0o7TUFDSjtNQUNBLFlBQVksQ0FBQztLQUNqQjtLQUNBLE9BQU87SUFDWDtJQUNBLFNBQVMsWUFBWSxRQUFRO0tBQ3pCLElBQUksWUFBWSxPQUFPO0tBQ3ZCLElBQUkscUJBQXFCLEtBQUssT0FBTyxZQUFZLE1BQU0sQ0FBQztLQUN4RCxJQUFJLHNCQUFzQixHQUN0QixPQUFPLFVBQVUsU0FBUyxxQkFBcUI7S0FFbkQsSUFBSSxzQkFBc0I7S0FDMUIsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLEdBQUcsS0FDcEIsS0FBSyxJQUFJLElBQUksWUFBWSxHQUFHLEtBQUssWUFBWSxJQUFJLEtBQzdDLHNCQUFzQixRQUFRLE9BQU8sSUFBSSxHQUFHLENBQUMsR0FBRyxtQkFBbUI7S0FHM0UsSUFBSSx3QkFBd0I7S0FDNUIsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLEdBQUcsS0FDcEIsS0FBSyxJQUFJLElBQUksWUFBWSxHQUFHLEtBQUssWUFBWSxJQUFJLEtBQzdDLHdCQUF3QixRQUFRLE9BQU8sSUFBSSxHQUFHLENBQUMsR0FBRyxxQkFBcUI7S0FHL0UsSUFBSSxpQkFBaUI7S0FDckIsSUFBSTtLQUNKLEtBQUssSUFBSSxLQUFLLEdBQUcsYUFBYSxVQUFVLFVBQVUsS0FBSyxXQUFXLFFBQVEsTUFBTTtNQUM1RSxJQUFJLFVBQVUsV0FBVztNQUN6QixJQUFJLFFBQVEsYUFBYSx1QkFBdUIsUUFBUSxhQUFhLHVCQUNqRSxPQUFPO01BRVgsSUFBSSxhQUFhLGlCQUFpQixxQkFBcUIsUUFBUSxRQUFRO01BQ3ZFLElBQUksYUFBYSxnQkFBZ0I7T0FDN0IsY0FBYztPQUNkLGlCQUFpQjtNQUNyQjtNQUNBLGFBQWEsaUJBQWlCLHVCQUF1QixRQUFRLFFBQVE7TUFDckUsSUFBSSxhQUFhLGdCQUFnQjtPQUM3QixjQUFjO09BQ2QsaUJBQWlCO01BQ3JCO0tBQ0o7S0FHQSxJQUFJLGtCQUFrQixHQUNsQixPQUFPO0lBRWY7SUFDQSxTQUFTLHNCQUFzQixRQUFRO0tBQ25DLElBQUksd0JBQXdCO0tBQzVCLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxHQUFHLEtBQ3BCLElBQUksTUFBTSxHQUNOLHdCQUF3QixRQUFRLE9BQU8sSUFBSSxHQUFHLENBQUMsR0FBRyxxQkFBcUI7S0FHL0UsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLEdBQUcsS0FDcEIsSUFBSSxNQUFNLEdBQ04sd0JBQXdCLFFBQVEsT0FBTyxJQUFJLEdBQUcsQ0FBQyxHQUFHLHFCQUFxQjtLQUcvRSxJQUFJLFlBQVksT0FBTztLQUN2QixJQUFJLG9DQUFvQztLQUN4QyxLQUFLLElBQUksSUFBSSxZQUFZLEdBQUcsS0FBSyxZQUFZLEdBQUcsS0FDNUMsb0NBQW9DLFFBQVEsT0FBTyxJQUFJLEdBQUcsQ0FBQyxHQUFHLGlDQUFpQztLQUVuRyxLQUFLLElBQUksSUFBSSxZQUFZLEdBQUcsSUFBSSxXQUFXLEtBQ3ZDLG9DQUFvQyxRQUFRLE9BQU8sSUFBSSxHQUFHLENBQUMsR0FBRyxpQ0FBaUM7S0FFbkcsSUFBSSxpQkFBaUI7S0FDckIsSUFBSSxpQkFBaUI7S0FDckIsS0FBSyxJQUFJLEtBQUssR0FBRyxzQkFBc0IsbUJBQW1CLEtBQUssb0JBQW9CLFFBQVEsTUFBTTtNQUM3RixJQUFJLEtBQUssb0JBQW9CLEtBQUssT0FBTyxHQUFHLE1BQU0sYUFBYSxHQUFHO01BQ2xFLElBQUksU0FBUyx5QkFBeUIsU0FBUyxtQ0FDM0MsT0FBTztNQUVYLElBQUksYUFBYSxpQkFBaUIsdUJBQXVCLElBQUk7TUFDN0QsSUFBSSxhQUFhLGdCQUFnQjtPQUM3QixpQkFBaUI7T0FDakIsaUJBQWlCO01BQ3JCO01BQ0EsSUFBSSwwQkFBMEIsbUNBQW1DO09BQzdELGFBQWEsaUJBQWlCLG1DQUFtQyxJQUFJO09BQ3JFLElBQUksYUFBYSxnQkFBZ0I7UUFDN0IsaUJBQWlCO1FBQ2pCLGlCQUFpQjtPQUNyQjtNQUNKO0tBQ0o7S0FFQSxJQUFJLGtCQUFrQixHQUNsQixPQUFPO0tBRVgsT0FBTztJQUNYO0lBQ0EsU0FBUyxjQUFjLFdBQVcsU0FBUyxTQUFTO0tBQ2hELElBQUksU0FBUyxRQUFRLHNCQUFzQjtLQUMzQyxJQUFJLGFBQWEsQ0FBQztLQUNsQixJQUFJLGlCQUFpQjtLQUNyQixPQUFPLFNBQVMsUUFBUSxTQUFVLE9BQU87TUFDckMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sV0FBVyxLQUFLO09BQ3RDLFdBQVcsS0FBSztRQUFFLGtCQUFrQixNQUFNO1FBQXVCLFdBQVcsQ0FBQztPQUFFLENBQUM7T0FDaEYsa0JBQWtCLE1BQU0sd0JBQXdCLE9BQU87TUFDM0Q7S0FDSixDQUFDO0tBSUQsSUFBSSxVQUFVLFNBQVMsZ0JBQ25CLE9BQU87S0FFWCxZQUFZLFVBQVUsTUFBTSxHQUFHLGNBQWM7S0FDN0MsSUFBSSxpQkFBaUIsT0FBTyxTQUFTLEVBQUUsQ0FBQztLQUV4QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksZ0JBQWdCLEtBQ2hDLEtBQUssSUFBSSxLQUFLLEdBQUcsZUFBZSxZQUFZLEtBQUssYUFBYSxRQUFRLE1BQU07TUFDeEUsSUFBSSxZQUFZLGFBQWE7TUFDN0IsVUFBVSxVQUFVLEtBQUssVUFBVSxNQUFNLENBQUM7S0FDOUM7S0FHSixJQUFJLE9BQU8sU0FBUyxTQUFTLEdBQUc7TUFDNUIsSUFBSSxrQkFBa0IsT0FBTyxTQUFTLEVBQUUsQ0FBQztNQUN6QyxJQUFJLGtCQUFrQixPQUFPLFNBQVMsRUFBRSxDQUFDO01BQ3pDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxpQkFBaUIsS0FDakMsV0FBVyxrQkFBa0IsRUFBRSxDQUFDLFVBQVUsS0FBSyxVQUFVLE1BQU0sQ0FBQztLQUV4RTtLQUVBLE9BQU8sVUFBVSxTQUFTLEdBQ3RCLEtBQUssSUFBSSxLQUFLLEdBQUcsZUFBZSxZQUFZLEtBQUssYUFBYSxRQUFRLE1BQU07TUFDeEUsSUFBSSxZQUFZLGFBQWE7TUFDN0IsVUFBVSxVQUFVLEtBQUssVUFBVSxNQUFNLENBQUM7S0FDOUM7S0FFSixPQUFPO0lBQ1g7SUFDQSxTQUFTLGFBQWEsUUFBUTtLQUMxQixJQUFJLFVBQVUsWUFBWSxNQUFNO0tBQ2hDLElBQUksQ0FBQyxTQUNELE9BQU87S0FFWCxJQUFJLGFBQWEsc0JBQXNCLE1BQU07S0FDN0MsSUFBSSxDQUFDLFlBQ0QsT0FBTztLQUdYLElBQUksYUFBYSxjQURELGNBQWMsUUFBUSxTQUFTLFVBQ1IsR0FBRyxTQUFTLFdBQVcsb0JBQW9CO0tBQ2xGLElBQUksQ0FBQyxZQUNELE9BQU87S0FHWCxJQUFJLGFBQWEsV0FBVyxPQUFPLFNBQVUsR0FBRyxHQUFHO01BQUUsT0FBTyxJQUFJLEVBQUU7S0FBa0IsR0FBRyxDQUFDO0tBQ3hGLElBQUksY0FBYyxJQUFJLGtCQUFrQixVQUFVO0tBQ2xELElBQUksY0FBYztLQUNsQixLQUFLLElBQUksS0FBSyxHQUFHLGVBQWUsWUFBWSxLQUFLLGFBQWEsUUFBUSxNQUFNO01BQ3hFLElBQUksWUFBWSxhQUFhO01BQzdCLElBQUksaUJBQWlCLGNBQWMsT0FBTyxVQUFVLFdBQVcsVUFBVSxVQUFVLFNBQVMsVUFBVSxnQkFBZ0I7TUFDdEgsSUFBSSxDQUFDLGdCQUNELE9BQU87TUFFWCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxrQkFBa0IsS0FDNUMsWUFBWSxpQkFBaUIsZUFBZTtLQUVwRDtLQUNBLElBQUk7TUFDQSxPQUFPLGFBQWEsT0FBTyxhQUFhLFFBQVEsYUFBYTtLQUNqRSxTQUNPLElBQUk7TUFDUCxPQUFPO0tBQ1g7SUFDSjtJQUNBLFNBQVMsT0FBTyxRQUFRO0tBQ3BCLElBQUksVUFBVSxNQUNWLE9BQU87S0FFWCxJQUFJLFNBQVMsYUFBYSxNQUFNO0tBQ2hDLElBQUksUUFDQSxPQUFPO0tBR1gsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sT0FBTyxLQUM5QixLQUFLLElBQUksSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsS0FDbkMsSUFBSSxPQUFPLElBQUksR0FBRyxDQUFDLE1BQU0sT0FBTyxJQUFJLEdBQUcsQ0FBQyxHQUFHO01BQ3ZDLE9BQU8sSUFBSSxHQUFHLEdBQUcsQ0FBQyxPQUFPLElBQUksR0FBRyxDQUFDLENBQUM7TUFDbEMsT0FBTyxJQUFJLEdBQUcsR0FBRyxDQUFDLE9BQU8sSUFBSSxHQUFHLENBQUMsQ0FBQztLQUN0QztLQUdSLE9BQU8sYUFBYSxNQUFNO0lBQzlCO0lBQ0EsVUFBUSxTQUFTO0dBR1g7SUFFQyxTQUFTLFVBQVEsV0FBUyxxQkFBcUI7SUFFdEQ7SUFFQSxPQUFPLGVBQWVBLFdBQVMsY0FBYyxFQUFFLE9BQU8sS0FBSyxDQUFDO0lBRTVELElBQUksY0FBYyxvQkFBb0IsQ0FBQztJQUN2QyxJQUFJLGtCQUFrQixvQkFBb0IsQ0FBQztJQUMzQyxJQUFJO0lBQ0osQ0FBQyxTQUFVLE1BQU07S0FDYixLQUFLLGFBQWE7S0FDbEIsS0FBSyxrQkFBa0I7S0FDdkIsS0FBSyxVQUFVO0tBQ2YsS0FBSyxXQUFXO0tBQ2hCLEtBQUssU0FBUztJQUNsQixFQUFBLENBQUcsT0FBT0EsVUFBUSxTQUFTLFVBQVEsT0FBTyxDQUFDLEVBQUU7SUFDN0MsSUFBSTtJQUNKLENBQUMsU0FBVSxVQUFVO0tBQ2pCLFNBQVMsU0FBUyxnQkFBZ0IsS0FBSztLQUN2QyxTQUFTLFNBQVMsYUFBYSxLQUFLO0tBQ3BDLFNBQVMsU0FBUyxrQkFBa0IsS0FBSztLQUN6QyxTQUFTLFNBQVMsVUFBVSxLQUFLO0tBQ2pDLFNBQVMsU0FBUyxXQUFXLEtBQUs7S0FDbEMsU0FBUyxTQUFTLFNBQVMsS0FBSztJQUlwQyxFQUFBLENBQUcsYUFBYSxXQUFXLENBQUMsRUFBRTtJQUM5QixTQUFTLGNBQWMsUUFBUSxNQUFNO0tBQ2pDLElBQUksUUFBUSxDQUFDO0tBQ2IsSUFBSSxPQUFPO0tBQ1gsSUFBSSxxQkFBcUI7TUFBQztNQUFJO01BQUk7S0FBRSxDQUFDLENBQUM7S0FDdEMsSUFBSSxTQUFTLE9BQU8sU0FBUyxrQkFBa0I7S0FFL0MsT0FBTyxVQUFVLEdBQUc7TUFDaEIsSUFBSSxNQUFNLE9BQU8sU0FBUyxFQUFFO01BQzVCLElBQUksT0FBTyxLQUNQLE1BQU0sSUFBSSxNQUFNLGlDQUFpQztNQUVyRCxJQUFJLElBQUksS0FBSyxNQUFNLE1BQU0sR0FBRztNQUM1QixJQUFJLElBQUksS0FBSyxNQUFNLE1BQU0sRUFBRSxJQUFJO01BQy9CLElBQUksSUFBSSxNQUFNO01BQ2QsTUFBTSxLQUFLLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDO01BQ2pDLFFBQVEsRUFBRSxTQUFTLElBQUksRUFBRSxTQUFTLElBQUksRUFBRSxTQUFTO01BQ2pELFVBQVU7S0FDZDtLQUVBLElBQUksV0FBVyxHQUFHO01BQ2QsSUFBSSxNQUFNLE9BQU8sU0FBUyxDQUFDO01BQzNCLElBQUksT0FBTyxLQUNQLE1BQU0sSUFBSSxNQUFNLGdDQUFnQztNQUVwRCxJQUFJLElBQUksS0FBSyxNQUFNLE1BQU0sRUFBRTtNQUMzQixJQUFJLElBQUksTUFBTTtNQUNkLE1BQU0sS0FBSyxLQUFLLEdBQUcsS0FBSyxDQUFDO01BQ3pCLFFBQVEsRUFBRSxTQUFTLElBQUksRUFBRSxTQUFTO0tBQ3RDLE9BQ0ssSUFBSSxXQUFXLEdBQUc7TUFDbkIsSUFBSSxNQUFNLE9BQU8sU0FBUyxDQUFDO01BQzNCLElBQUksT0FBTyxJQUNQLE1BQU0sSUFBSSxNQUFNLCtCQUErQjtNQUVuRCxNQUFNLEtBQUssS0FBSyxHQUFHO01BQ25CLFFBQVEsSUFBSSxTQUFTO0tBQ3pCO0tBQ0EsT0FBTztNQUFTO01BQWE7S0FBSztJQUN0QztJQUNBLElBQUksNkJBQTZCO0tBQzdCO0tBQUs7S0FBSztLQUFLO0tBQUs7S0FBSztLQUFLO0tBQUs7S0FBSztLQUN4QztLQUFLO0tBQUs7S0FBSztLQUFLO0tBQUs7S0FBSztLQUFLO0tBQUs7S0FDeEM7S0FBSztLQUFLO0tBQUs7S0FBSztLQUFLO0tBQUs7S0FBSztLQUFLO0tBQ3hDO0tBQUs7S0FBSztLQUFLO0tBQUs7S0FBSztLQUFLO0tBQUs7S0FBSztLQUN4QztLQUFLO0tBQUs7S0FBSztLQUFLO0tBQUs7S0FBSztLQUFLO0tBQUs7SUFDNUM7SUFDQSxTQUFTLG1CQUFtQixRQUFRLE1BQU07S0FDdEMsSUFBSSxRQUFRLENBQUM7S0FDYixJQUFJLE9BQU87S0FDWCxJQUFJLHFCQUFxQjtNQUFDO01BQUc7TUFBSTtLQUFFLENBQUMsQ0FBQztLQUNyQyxJQUFJLFNBQVMsT0FBTyxTQUFTLGtCQUFrQjtLQUMvQyxPQUFPLFVBQVUsR0FBRztNQUNoQixJQUFJLElBQUksT0FBTyxTQUFTLEVBQUU7TUFDMUIsSUFBSSxJQUFJLEtBQUssTUFBTSxJQUFJLEVBQUU7TUFDekIsSUFBSSxJQUFJLElBQUk7TUFDWixNQUFNLEtBQUssMkJBQTJCLEVBQUUsQ0FBQyxXQUFXLENBQUMsR0FBRywyQkFBMkIsRUFBRSxDQUFDLFdBQVcsQ0FBQyxDQUFDO01BQ25HLFFBQVEsMkJBQTJCLEtBQUssMkJBQTJCO01BQ25FLFVBQVU7S0FDZDtLQUNBLElBQUksV0FBVyxHQUFHO01BQ2QsSUFBSSxJQUFJLE9BQU8sU0FBUyxDQUFDO01BQ3pCLE1BQU0sS0FBSywyQkFBMkIsRUFBRSxDQUFDLFdBQVcsQ0FBQyxDQUFDO01BQ3RELFFBQVEsMkJBQTJCO0tBQ3ZDO0tBQ0EsT0FBTztNQUFTO01BQWE7S0FBSztJQUN0QztJQUNBLFNBQVMsV0FBVyxRQUFRLE1BQU07S0FDOUIsSUFBSSxRQUFRLENBQUM7S0FDYixJQUFJLE9BQU87S0FDWCxJQUFJLHFCQUFxQjtNQUFDO01BQUc7TUFBSTtLQUFFLENBQUMsQ0FBQztLQUNyQyxJQUFJLFNBQVMsT0FBTyxTQUFTLGtCQUFrQjtLQUMvQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUFLO01BQzdCLElBQUksSUFBSSxPQUFPLFNBQVMsQ0FBQztNQUN6QixNQUFNLEtBQUssQ0FBQztLQUNoQjtLQUNBLElBQUk7TUFDQSxRQUFRLG1CQUFtQixNQUFNLElBQUksU0FBVSxHQUFHO09BQUUsT0FBTyxPQUFPLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBQSxDQUFHLE9BQU8sRUFBRTtNQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDO0tBQ25ILFNBQ08sSUFBSSxDQUVYO0tBQ0EsT0FBTztNQUFTO01BQWE7S0FBSztJQUN0QztJQUNBLFNBQVMsWUFBWSxRQUFRLE1BQU07S0FDL0IsSUFBSSxRQUFRLENBQUM7S0FDYixJQUFJLE9BQU87S0FDWCxJQUFJLHFCQUFxQjtNQUFDO01BQUc7TUFBSTtLQUFFLENBQUMsQ0FBQztLQUNyQyxJQUFJLFNBQVMsT0FBTyxTQUFTLGtCQUFrQjtLQUMvQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUFLO01BQzdCLElBQUksSUFBSSxPQUFPLFNBQVMsRUFBRTtNQUMxQixJQUFJLElBQUssS0FBSyxNQUFNLElBQUksR0FBSSxLQUFLLElBQU0sSUFBSTtNQUMzQyxJQUFJLElBQUksTUFDSixLQUFLO1dBR0wsS0FBSztNQUVULE1BQU0sS0FBSyxLQUFLLEdBQUcsSUFBSSxHQUFJO01BQzNCLFFBQVEsT0FBTyxhQUFhLGdCQUFnQixjQUFjLEVBQUU7S0FDaEU7S0FDQSxPQUFPO01BQVM7TUFBYTtLQUFLO0lBQ3RDO0lBQ0EsU0FBUyxPQUFPLE1BQU0sU0FBUztLQUMzQixJQUFJLElBQUksSUFBSSxJQUFJO0tBQ2hCLElBQUksU0FBUyxJQUFJLFlBQVksVUFBVSxJQUFJO0tBRTNDLElBQUksT0FBTyxXQUFXLElBQUksSUFBSSxXQUFXLEtBQUssSUFBSTtLQUNsRCxJQUFJLFNBQVM7TUFDVCxNQUFNO01BQ04sT0FBTyxDQUFDO01BQ1IsUUFBUSxDQUFDO01BQ0E7S0FDYjtLQUNBLE9BQU8sT0FBTyxVQUFVLEtBQUssR0FBRztNQUM1QixJQUFJLE9BQU8sT0FBTyxTQUFTLENBQUM7TUFDNUIsSUFBSSxTQUFTLFNBQVMsWUFDbEIsT0FBTztXQUVOLElBQUksU0FBUyxTQUFTLEtBQUs7T0FDNUIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLEdBQ3ZCLE9BQU8sT0FBTyxLQUFLO1FBQ2YsTUFBTSxLQUFLO1FBQ1gsa0JBQWtCLE9BQU8sU0FBUyxDQUFDO09BQ3ZDLENBQUM7WUFFQSxJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sR0FDNUIsT0FBTyxPQUFPLEtBQUs7UUFDZixNQUFNLEtBQUs7UUFDWCxrQkFBa0IsT0FBTyxTQUFTLEVBQUU7T0FDeEMsQ0FBQztZQUVBLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTSxHQUM1QixPQUFPLE9BQU8sS0FBSztRQUNmLE1BQU0sS0FBSztRQUNYLGtCQUFrQixPQUFPLFNBQVMsRUFBRTtPQUN4QyxDQUFDO1lBSUQsT0FBTyxPQUFPLEtBQUs7UUFDZixNQUFNLEtBQUs7UUFDWCxrQkFBa0I7T0FDdEIsQ0FBQztNQUVULE9BQ0ssSUFBSSxTQUFTLFNBQVMsU0FBUztPQUNoQyxJQUFJLGdCQUFnQixjQUFjLFFBQVEsSUFBSTtPQUM5QyxPQUFPLFFBQVEsY0FBYztPQUM3QixDQUFDLEtBQUssT0FBTyxNQUFBLENBQU8sS0FBSyxNQUFNLElBQUksY0FBYyxLQUFLO09BQ3RELE9BQU8sT0FBTyxLQUFLO1FBQ2YsTUFBTSxLQUFLO1FBQ1gsTUFBTSxjQUFjO09BQ3hCLENBQUM7TUFDTCxPQUNLLElBQUksU0FBUyxTQUFTLGNBQWM7T0FDckMsSUFBSSxxQkFBcUIsbUJBQW1CLFFBQVEsSUFBSTtPQUN4RCxPQUFPLFFBQVEsbUJBQW1CO09BQ2xDLENBQUMsS0FBSyxPQUFPLE1BQUEsQ0FBTyxLQUFLLE1BQU0sSUFBSSxtQkFBbUIsS0FBSztPQUMzRCxPQUFPLE9BQU8sS0FBSztRQUNmLE1BQU0sS0FBSztRQUNYLE1BQU0sbUJBQW1CO09BQzdCLENBQUM7TUFDTCxPQUNLLElBQUksU0FBUyxTQUFTLE1BQU07T0FDN0IsSUFBSSxhQUFhLFdBQVcsUUFBUSxJQUFJO09BQ3hDLE9BQU8sUUFBUSxXQUFXO09BQzFCLENBQUMsS0FBSyxPQUFPLE1BQUEsQ0FBTyxLQUFLLE1BQU0sSUFBSSxXQUFXLEtBQUs7T0FDbkQsT0FBTyxPQUFPLEtBQUs7UUFDZixNQUFNLEtBQUs7UUFDWCxPQUFPLFdBQVc7UUFDbEIsTUFBTSxXQUFXO09BQ3JCLENBQUM7TUFDTCxPQUNLLElBQUksU0FBUyxTQUFTLE9BQU87T0FDOUIsSUFBSSxjQUFjLFlBQVksUUFBUSxJQUFJO09BQzFDLE9BQU8sUUFBUSxZQUFZO09BQzNCLENBQUMsS0FBSyxPQUFPLE1BQUEsQ0FBTyxLQUFLLE1BQU0sSUFBSSxZQUFZLEtBQUs7T0FDcEQsT0FBTyxPQUFPLEtBQUs7UUFDZixNQUFNLEtBQUs7UUFDWCxPQUFPLFlBQVk7UUFDbkIsTUFBTSxZQUFZO09BQ3RCLENBQUM7TUFDTDtLQUNKO0tBRUEsSUFBSSxPQUFPLFVBQVUsTUFBTSxLQUFLLE9BQU8sU0FBUyxPQUFPLFVBQVUsQ0FBQyxNQUFNLEdBQ3BFLE9BQU87SUFFZjtJQUNBLFVBQVEsU0FBUztHQUdYO0lBRUMsU0FBUyxXQUFRLFdBQVMscUJBQXFCO0lBRXREO0lBR0EsT0FBTyxlQUFlQSxXQUFTLGNBQWMsRUFBRSxPQUFPLEtBQUssQ0FBQztJQWdENUQsVUFBUSxZQS9DdUIsV0FBWTtLQUN2QyxTQUFTLFVBQVUsT0FBTztNQUN0QixLQUFLLGFBQWE7TUFDbEIsS0FBSyxZQUFZO01BQ2pCLEtBQUssUUFBUTtLQUNqQjtLQUNBLFVBQVUsVUFBVSxXQUFXLFNBQVUsU0FBUztNQUM5QyxJQUFJLFVBQVUsS0FBSyxVQUFVLE1BQU0sVUFBVSxLQUFLLFVBQVUsR0FDeEQsTUFBTSxJQUFJLE1BQU0saUJBQWlCLFFBQVEsU0FBUyxJQUFJLE9BQU87TUFFakUsSUFBSSxTQUFTO01BRWIsSUFBSSxLQUFLLFlBQVksR0FBRztPQUNwQixJQUFJLFdBQVcsSUFBSSxLQUFLO09BQ3hCLElBQUksU0FBUyxVQUFVLFdBQVcsVUFBVTtPQUM1QyxJQUFJLGdCQUFnQixXQUFXO09BQy9CLElBQUksT0FBUSxPQUFTLElBQUksVUFBWTtPQUNyQyxVQUFVLEtBQUssTUFBTSxLQUFLLGNBQWMsU0FBUztPQUNqRCxXQUFXO09BQ1gsS0FBSyxhQUFhO09BQ2xCLElBQUksS0FBSyxjQUFjLEdBQUc7UUFDdEIsS0FBSyxZQUFZO1FBQ2pCLEtBQUs7T0FDVDtNQUNKO01BRUEsSUFBSSxVQUFVLEdBQUc7T0FDYixPQUFPLFdBQVcsR0FBRztRQUNqQixTQUFVLFVBQVUsSUFBTSxLQUFLLE1BQU0sS0FBSyxjQUFjO1FBQ3hELEtBQUs7UUFDTCxXQUFXO09BQ2Y7T0FFQSxJQUFJLFVBQVUsR0FBRztRQUNiLElBQUksZ0JBQWdCLElBQUk7UUFDeEIsSUFBSSxPQUFRLE9BQVEsaUJBQWtCO1FBQ3RDLFNBQVUsVUFBVSxXQUFhLEtBQUssTUFBTSxLQUFLLGNBQWMsU0FBUztRQUN4RSxLQUFLLGFBQWE7T0FDdEI7TUFDSjtNQUNBLE9BQU87S0FDWDtLQUNBLFVBQVUsVUFBVSxZQUFZLFdBQVk7TUFDeEMsT0FBTyxLQUFLLEtBQUssTUFBTSxTQUFTLEtBQUssY0FBYyxLQUFLO0tBQzVEO0tBQ0EsT0FBTztJQUNYLEVBQzRCO0dBR3RCO0lBRUMsU0FBUyxXQUFRLFlBQVMscUJBQXFCO0lBRXREO0lBRUEsT0FBTyxlQUFlQSxZQUFTLGNBQWMsRUFBRSxPQUFPLEtBQUssQ0FBQztJQUM1RCxXQUFRLGdCQUFnQjtLQUNwQixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLElBQU07S0FDTixJQUFNO0tBQ04sSUFBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE1BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsTUFBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixNQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixNQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE1BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixLQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLEtBQU07S0FDTixLQUFNO0tBQ04sS0FBTTtLQUNOLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsTUFBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsTUFBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixLQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtLQUNSLE9BQVE7S0FDUixPQUFRO0tBQ1IsT0FBUTtJQUNaO0dBR007SUFFQyxTQUFTLFdBQVEsWUFBUyxxQkFBcUI7SUFFdEQ7SUFFQSxPQUFPLGVBQWVBLFlBQVMsY0FBYyxFQUFFLE9BQU8sS0FBSyxDQUFDO0lBQzVELElBQUksY0FBYyxvQkFBb0IsQ0FBQztJQUN2QyxJQUFJLGtCQUFrQixvQkFBb0IsQ0FBQztJQUMzQyxTQUFTLHNCQUFzQixPQUFPLEdBQUcsR0FBRyxHQUFHO0tBQzNDLElBQUk7S0FFSixJQUFJLEVBQUUsT0FBTyxJQUFJLEVBQUUsT0FBTyxHQUN0QixLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLElBQUksSUFBSSxHQUFHO0tBRW5DLElBQUksUUFBUTtLQUNaLElBQUksSUFBSTtLQUNSLElBQUksUUFBUSxNQUFNO0tBQ2xCLElBQUksSUFBSSxNQUFNO0tBRWQsT0FBTyxFQUFFLE9BQU8sS0FBSyxJQUFJLEdBQUc7TUFDeEIsSUFBSSxZQUFZO01BQ2hCLElBQUksWUFBWTtNQUNoQixRQUFRO01BQ1IsUUFBUTtNQUVSLElBQUksTUFBTSxPQUFPLEdBRWIsT0FBTztNQUVYLElBQUk7TUFDSixJQUFJLElBQUksTUFBTTtNQUNkLElBQUkseUJBQXlCLE1BQU0sZUFBZSxNQUFNLE9BQU8sQ0FBQztNQUNoRSxJQUFJLGFBQWEsTUFBTSxRQUFRLHNCQUFzQjtNQUNyRCxPQUFPLEVBQUUsT0FBTyxLQUFLLE1BQU0sT0FBTyxLQUFLLENBQUMsRUFBRSxPQUFPLEdBQUc7T0FDaEQsSUFBSSxhQUFhLEVBQUUsT0FBTyxJQUFJLE1BQU0sT0FBTztPQUMzQyxJQUFJLFFBQVEsTUFBTSxTQUFTLEVBQUUsZUFBZSxFQUFFLE9BQU8sQ0FBQyxHQUFHLFVBQVU7T0FDbkUsSUFBSSxFQUFFLGNBQWMsTUFBTSxjQUFjLFlBQVksS0FBSyxDQUFDO09BQzFELElBQUksRUFBRSxjQUFjLE1BQU0sbUJBQW1CLFlBQVksS0FBSyxDQUFDO01BQ25FO01BQ0EsSUFBSSxFQUFFLGFBQWEsS0FBSyxDQUFDLENBQUMsY0FBYyxTQUFTO01BQ2pELElBQUksRUFBRSxPQUFPLEtBQUssTUFBTSxPQUFPLEdBQzNCLE9BQU87S0FFZjtLQUNBLElBQUksbUJBQW1CLEVBQUUsZUFBZSxDQUFDO0tBQ3pDLElBQUkscUJBQXFCLEdBQ3JCLE9BQU87S0FFWCxJQUFJLFVBQVUsTUFBTSxRQUFRLGdCQUFnQjtLQUM1QyxPQUFPLENBQUMsRUFBRSxTQUFTLE9BQU8sR0FBRyxFQUFFLFNBQVMsT0FBTyxDQUFDO0lBQ3BEO0lBQ0EsU0FBUyxtQkFBbUIsT0FBTyxjQUFjO0tBRTdDLElBQUksWUFBWSxhQUFhLE9BQU87S0FDcEMsSUFBSSxjQUFjLEdBQ2QsT0FBTyxDQUFDLGFBQWEsZUFBZSxDQUFDLENBQUM7S0FFMUMsSUFBSSxTQUFTLElBQUksTUFBTSxTQUFTO0tBQ2hDLElBQUksYUFBYTtLQUNqQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLGFBQWEsV0FBVyxLQUN0RCxJQUFJLGFBQWEsV0FBVyxDQUFDLE1BQU0sR0FBRztNQUNsQyxPQUFPLGNBQWMsTUFBTSxRQUFRLENBQUM7TUFDcEM7S0FDSjtLQUVKLElBQUksZUFBZSxXQUNmLE9BQU87S0FFWCxPQUFPO0lBQ1g7SUFDQSxTQUFTLG9CQUFvQixPQUFPLGdCQUFnQixnQkFBZ0I7S0FFaEUsSUFBSSxJQUFJLGVBQWU7S0FDdkIsSUFBSSxTQUFTLElBQUksTUFBTSxDQUFDO0tBQ3hCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7TUFDeEIsSUFBSSxZQUFZLE1BQU0sUUFBUSxlQUFlLEVBQUU7TUFDL0MsSUFBSSxjQUFjO01BQ2xCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQ25CLElBQUksTUFBTSxHQUNOLGNBQWMsTUFBTSxTQUFTLGFBQWEsWUFBWSxnQkFBZ0IsR0FBRyxNQUFNLFNBQVMsZUFBZSxJQUFJLFNBQVMsQ0FBQyxDQUFDO01BRzlILE9BQU8sS0FBSyxNQUFNLFNBQVMsZUFBZSxXQUFXLFNBQVMsR0FBRyxNQUFNLFFBQVEsV0FBVyxDQUFDO01BQzNGLElBQUksTUFBTSxrQkFBa0IsR0FDeEIsT0FBTyxLQUFLLE1BQU0sU0FBUyxPQUFPLElBQUksU0FBUztLQUV2RDtLQUNBLE9BQU87SUFDWDtJQUNBLFNBQVMsT0FBTyxPQUFPLE1BQU07S0FDekIsSUFBSSxjQUFjLElBQUksa0JBQWtCLE1BQU0sTUFBTTtLQUNwRCxZQUFZLElBQUksS0FBSztLQUNyQixJQUFJLFFBQVEsSUFBSSxZQUFZLFFBQVEsS0FBUSxLQUFLLENBQUM7S0FDbEQsSUFBSSxPQUFPLElBQUksZ0JBQWdCLFFBQVEsT0FBTyxXQUFXO0tBQ3pELElBQUksdUJBQXVCLElBQUksa0JBQWtCLElBQUk7S0FDckQsSUFBSSxRQUFRO0tBQ1osS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sS0FBSztNQUMzQixJQUFJLGFBQWEsS0FBSyxXQUFXLE1BQU0sSUFBSSxJQUFJLE1BQU0sYUFBYSxDQUFDO01BQ25FLHFCQUFxQixxQkFBcUIsU0FBUyxJQUFJLEtBQUs7TUFDNUQsSUFBSSxlQUFlLEdBQ2YsUUFBUTtLQUVoQjtLQUNBLElBQUksQ0FBQyxPQUNELE9BQU87S0FFWCxJQUFJLFdBQVcsSUFBSSxnQkFBZ0IsUUFBUSxPQUFPLG9CQUFvQjtLQUN0RSxJQUFJLGFBQWEsc0JBQXNCLE9BQU8sTUFBTSxjQUFjLE1BQU0sQ0FBQyxHQUFHLFVBQVUsSUFBSTtLQUMxRixJQUFJLGVBQWUsTUFDZixPQUFPO0tBRVgsSUFBSSxpQkFBaUIsbUJBQW1CLE9BQU8sV0FBVyxFQUFFO0tBQzVELElBQUksa0JBQWtCLE1BQ2xCLE9BQU87S0FFWCxJQUFJLGtCQUFrQixvQkFBb0IsT0FBTyxXQUFXLElBQUksY0FBYztLQUM5RSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksZUFBZSxRQUFRLEtBQUs7TUFDNUMsSUFBSSxXQUFXLFlBQVksU0FBUyxJQUFJLE1BQU0sSUFBSSxlQUFlLEVBQUU7TUFDbkUsSUFBSSxXQUFXLEdBQ1gsT0FBTztNQUVYLFlBQVksWUFBWSxZQUFZLGdCQUFnQixZQUFZLFdBQVcsZ0JBQWdCLEVBQUU7S0FDakc7S0FDQSxPQUFPO0lBQ1g7SUFDQSxXQUFRLFNBQVM7R0FHWDtJQUVDLFNBQVMsV0FBUSxZQUFTLHFCQUFxQjtJQUV0RDtJQUVBLE9BQU8sZUFBZUEsWUFBUyxjQUFjLEVBQUUsT0FBTyxLQUFLLENBQUM7SUFDNUQsV0FBUSxXQUFXO0tBQ2Y7TUFDSSxVQUFVO01BQ1YsZUFBZTtNQUNmLHlCQUF5QixDQUFDO01BQzFCLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FBQztPQUMxRDtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FBQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUFDO09BQzFEO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQUM7T0FDMUQ7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUUsQ0FBQztPQUN6RDtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCLENBQUMsR0FBRyxFQUFFO01BQy9CLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FBQztPQUMxRDtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FBQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUFDO09BQzFEO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQUM7T0FDMUQ7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FBQztPQUMxRDtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCLENBQUMsR0FBRyxFQUFFO01BQy9CLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FBQztPQUMxRDtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FBQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUFDO09BQzFEO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQUM7T0FDMUQ7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FBQztPQUMxRDtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCLENBQUMsR0FBRyxFQUFFO01BQy9CLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FBQztPQUMxRDtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FBQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUFDO09BQzFEO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQUM7T0FDMUQ7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUUsQ0FBQztPQUN6RDtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCLENBQUMsR0FBRyxFQUFFO01BQy9CLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksQ0FBQztPQUMzRDtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FBQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUFDO09BQzFEO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQzlDO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsR0FDMUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCLENBQUMsR0FBRyxFQUFFO01BQy9CLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FBQztPQUMxRDtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FBQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUFDO09BQzFEO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQUM7T0FDMUQ7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FBQztPQUMxRDtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO01BQUU7TUFDbkMsdUJBQXVCO09BQ25CO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FBQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUFDO09BQzFEO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQUM7T0FDMUQ7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsR0FDMUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUM5QztPQUNKO01BQ0o7S0FDSjtLQUNBO01BQ0ksVUFBVTtNQUNWLGVBQWU7TUFDZix5QkFBeUI7T0FBQztPQUFHO09BQUk7TUFBRTtNQUNuQyx1QkFBdUI7T0FDbkI7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQUM7T0FDMUQ7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsR0FDMUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUM5QztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQzlDO09BQ0o7TUFDSjtLQUNKO0tBQ0E7TUFDSSxVQUFVO01BQ1YsZUFBZTtNQUNmLHlCQUF5QjtPQUFDO09BQUc7T0FBSTtNQUFFO01BQ25DLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksQ0FBQztPQUMzRDtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUM5QztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQzlDO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsR0FDMUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO01BQUU7TUFDbkMsdUJBQXVCO09BQ25CO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUM5QztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQzlDO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsR0FDMUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUM5QztPQUNKO01BQ0o7S0FDSjtLQUNBO01BQ0ksVUFBVTtNQUNWLGVBQWU7TUFDZix5QkFBeUI7T0FBQztPQUFHO09BQUk7TUFBRTtNQUNuQyx1QkFBdUI7T0FDbkI7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQUM7T0FDMUQ7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsR0FDMUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUM5QztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQzlDO09BQ0o7TUFDSjtLQUNKO0tBQ0E7TUFDSSxVQUFVO01BQ1YsZUFBZTtNQUNmLHlCQUF5QjtPQUFDO09BQUc7T0FBSTtNQUFFO01BQ25DLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsR0FDMUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUM5QztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQzlDO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsR0FDMUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO01BQUU7TUFDbkMsdUJBQXVCO09BQ25CO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FBQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBSSxDQUFDO09BQzNEO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQzlDO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsR0FDMUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUM5QztPQUNKO01BQ0o7S0FDSjtLQUNBO01BQ0ksVUFBVTtNQUNWLGVBQWU7TUFDZix5QkFBeUI7T0FBQztPQUFHO09BQUk7T0FBSTtNQUFFO01BQ3ZDLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUM5QztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQzlDO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO09BQUk7TUFBRTtNQUN2Qyx1QkFBdUI7T0FDbkI7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQzlDO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsR0FDMUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUM5QztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQzlDO09BQ0o7TUFDSjtLQUNKO0tBQ0E7TUFDSSxVQUFVO01BQ1YsZUFBZTtNQUNmLHlCQUF5QjtPQUFDO09BQUc7T0FBSTtPQUFJO01BQUU7TUFDdkMsdUJBQXVCO09BQ25CO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUM5QztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQzlDO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO01BQ0o7S0FDSjtLQUNBO01BQ0ksVUFBVTtNQUNWLGVBQWU7TUFDZix5QkFBeUI7T0FBQztPQUFHO09BQUk7T0FBSTtNQUFFO01BQ3ZDLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUM5QztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsR0FDMUM7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsQ0FDL0M7T0FDSjtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO09BQUk7TUFBRTtNQUN2Qyx1QkFBdUI7T0FDbkI7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFJLEdBQzNDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFJLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsR0FDMUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUM5QztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7TUFDSjtLQUNKO0tBQ0E7TUFDSSxVQUFVO01BQ1YsZUFBZTtNQUNmLHlCQUF5QjtPQUFDO09BQUc7T0FBSTtPQUFJO01BQUU7TUFDdkMsdUJBQXVCO09BQ25CO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBSSxHQUMzQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBSSxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO01BQ0o7S0FDSjtLQUNBO01BQ0ksVUFBVTtNQUNWLGVBQWU7TUFDZix5QkFBeUI7T0FBQztPQUFHO09BQUk7T0FBSTtNQUFFO01BQ3ZDLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQzlDO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsQ0FDL0M7T0FDSjtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO09BQUk7T0FBSTtNQUFFO01BQzNDLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FBQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUFDO09BQzNEO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQzlDO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO09BQUk7T0FBSTtNQUFFO01BQzNDLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FBQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUFDO09BQzNEO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQUM7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsQ0FBQztPQUMzRDtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO09BQUk7T0FBSTtNQUFHO01BQzVDLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsQ0FDL0M7T0FDSjtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO09BQUk7T0FBSTtNQUFHO01BQzVDLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO09BQUk7T0FBSTtNQUFHO01BQzVDLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsQ0FDL0M7T0FDSjtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO09BQUk7T0FBSTtNQUFHO01BQzVDLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUksR0FDNUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUM5QztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLENBQzlDO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO09BQUk7T0FBSTtNQUFHO01BQzVDLHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUM5QztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsQ0FDL0M7T0FDSjtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO09BQUk7T0FBSTtPQUFJO01BQUc7TUFDaEQsdUJBQXVCO09BQ25CO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBSSxHQUMzQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBSSxDQUNoRDtPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsR0FDMUM7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO01BQ0o7S0FDSjtLQUNBO01BQ0ksVUFBVTtNQUNWLGVBQWU7TUFDZix5QkFBeUI7T0FBQztPQUFHO09BQUk7T0FBSTtPQUFJO09BQUs7TUFBRztNQUNqRCx1QkFBdUI7T0FDbkI7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFJLEdBQzNDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFJLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxHQUMxQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7TUFDSjtLQUNKO0tBQ0E7TUFDSSxVQUFVO01BQ1YsZUFBZTtNQUNmLHlCQUF5QjtPQUFDO09BQUc7T0FBSTtPQUFJO09BQUk7T0FBSztNQUFHO01BQ2pELHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksR0FDM0M7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUksQ0FDaEQ7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsQ0FDL0M7T0FDSjtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO09BQUk7T0FBSTtPQUFLO01BQUc7TUFDakQsdUJBQXVCO09BQ25CO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBSSxHQUM1QztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBSSxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO01BQ0o7S0FDSjtLQUNBO01BQ0ksVUFBVTtNQUNWLGVBQWU7TUFDZix5QkFBeUI7T0FBQztPQUFHO09BQUk7T0FBSTtPQUFJO09BQUs7TUFBRztNQUNqRCx1QkFBdUI7T0FDbkI7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUFDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFJLENBQUM7T0FDNUQ7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7TUFDSjtLQUNKO0tBQ0E7TUFDSSxVQUFVO01BQ1YsZUFBZTtNQUNmLHlCQUF5QjtPQUFDO09BQUc7T0FBSTtPQUFJO09BQUk7T0FBSztNQUFHO01BQ2pELHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUksR0FDNUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsQ0FDL0M7T0FDSjtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO09BQUk7T0FBSTtPQUFLO01BQUc7TUFDakQsdUJBQXVCO09BQ25CO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBSSxHQUM1QztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBSSxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBRyxDQUM5QztPQUNKO01BQ0o7S0FDSjtLQUNBO01BQ0ksVUFBVTtNQUNWLGVBQWU7TUFDZix5QkFBeUI7T0FBQztPQUFHO09BQUk7T0FBSTtPQUFJO09BQUs7T0FBSztNQUFHO01BQ3RELHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUksR0FDNUM7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsQ0FDL0M7T0FDSjtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO09BQUk7T0FBSTtPQUFLO09BQUs7TUFBRztNQUN0RCx1QkFBdUI7T0FDbkI7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFJLEdBQzNDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFJLENBQ2hEO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsR0FDMUM7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFHLEdBQzFDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7TUFDSjtLQUNKO0tBQ0E7TUFDSSxVQUFVO01BQ1YsZUFBZTtNQUNmLHlCQUF5QjtPQUFDO09BQUc7T0FBSTtPQUFJO09BQUk7T0FBSztPQUFLO01BQUc7TUFDdEQsdUJBQXVCO09BQ25CO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBSSxHQUM1QztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBSSxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO01BQ0o7S0FDSjtLQUNBO01BQ0ksVUFBVTtNQUNWLGVBQWU7TUFDZix5QkFBeUI7T0FBQztPQUFHO09BQUk7T0FBSTtPQUFJO09BQUs7T0FBSztNQUFHO01BQ3RELHVCQUF1QjtPQUNuQjtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUksR0FDM0M7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUksQ0FDaEQ7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsQ0FDL0M7T0FDSjtNQUNKO0tBQ0o7S0FDQTtNQUNJLFVBQVU7TUFDVixlQUFlO01BQ2YseUJBQXlCO09BQUM7T0FBRztPQUFJO09BQUk7T0FBSTtPQUFLO09BQUs7TUFBRztNQUN0RCx1QkFBdUI7T0FDbkI7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFJLEdBQzVDO1NBQUUsV0FBVztTQUFHLHVCQUF1QjtRQUFJLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUcsdUJBQXVCO1FBQUcsQ0FDOUM7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7TUFDSjtLQUNKO0tBQ0E7TUFDSSxVQUFVO01BQ1YsZUFBZTtNQUNmLHlCQUF5QjtPQUFDO09BQUc7T0FBSTtPQUFJO09BQUk7T0FBSztPQUFLO01BQUc7TUFDdEQsdUJBQXVCO09BQ25CO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBSSxHQUM1QztTQUFFLFdBQVc7U0FBRyx1QkFBdUI7UUFBSSxDQUMvQztPQUNKO09BQ0E7UUFDSSxxQkFBcUI7UUFDckIsVUFBVSxDQUNOO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLEdBQzNDO1NBQUUsV0FBVztTQUFJLHVCQUF1QjtRQUFHLENBQy9DO09BQ0o7T0FDQTtRQUNJLHFCQUFxQjtRQUNyQixVQUFVLENBQ047U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsR0FDM0M7U0FBRSxXQUFXO1NBQUksdUJBQXVCO1FBQUcsQ0FDL0M7T0FDSjtPQUNBO1FBQ0kscUJBQXFCO1FBQ3JCLFVBQVUsQ0FDTjtTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxHQUMzQztTQUFFLFdBQVc7U0FBSSx1QkFBdUI7UUFBRyxDQUMvQztPQUNKO01BQ0o7S0FDSjtJQUNKO0dBR007SUFFQyxTQUFTLFdBQVEsWUFBUyxxQkFBcUI7SUFFdEQ7SUFFQSxPQUFPLGVBQWVBLFlBQVMsY0FBYyxFQUFFLE9BQU8sS0FBSyxDQUFDO0lBQzVELElBQUksY0FBYyxvQkFBb0IsQ0FBQztJQUN2QyxTQUFTLHNCQUFzQixJQUFJLElBQUksSUFBSSxJQUFJO0tBQzNDLElBQUksTUFBTSxHQUFHLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHO0tBQ2xDLElBQUksTUFBTSxHQUFHLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHO0tBQ2xDLElBQUksUUFBUSxLQUFLLFFBQVEsR0FDckIsT0FBTztNQUNILEtBQUssR0FBRyxJQUFJLEdBQUc7TUFDZixLQUFLLEdBQUcsSUFBSSxHQUFHO01BQ2YsS0FBSztNQUNMLEtBQUssR0FBRyxJQUFJLEdBQUc7TUFDZixLQUFLLEdBQUcsSUFBSSxHQUFHO01BQ2YsS0FBSztNQUNMLEtBQUssR0FBRztNQUNSLEtBQUssR0FBRztNQUNSLEtBQUs7S0FDVDtVQUVDO01BQ0QsSUFBSSxNQUFNLEdBQUcsSUFBSSxHQUFHO01BQ3BCLElBQUksTUFBTSxHQUFHLElBQUksR0FBRztNQUNwQixJQUFJLE1BQU0sR0FBRyxJQUFJLEdBQUc7TUFDcEIsSUFBSSxNQUFNLEdBQUcsSUFBSSxHQUFHO01BQ3BCLElBQUksY0FBYyxNQUFNLE1BQU0sTUFBTTtNQUNwQyxJQUFJLE9BQU8sTUFBTSxNQUFNLE1BQU0sT0FBTztNQUNwQyxJQUFJLE9BQU8sTUFBTSxNQUFNLE1BQU0sT0FBTztNQUNwQyxPQUFPO09BQ0gsS0FBSyxHQUFHLElBQUksR0FBRyxJQUFJLE1BQU0sR0FBRztPQUM1QixLQUFLLEdBQUcsSUFBSSxHQUFHLElBQUksTUFBTSxHQUFHO09BQ3ZCO09BQ0wsS0FBSyxHQUFHLElBQUksR0FBRyxJQUFJLE1BQU0sR0FBRztPQUM1QixLQUFLLEdBQUcsSUFBSSxHQUFHLElBQUksTUFBTSxHQUFHO09BQ3ZCO09BQ0wsS0FBSyxHQUFHO09BQ1IsS0FBSyxHQUFHO09BQ1IsS0FBSztNQUNUO0tBQ0o7SUFDSjtJQUNBLFNBQVMsc0JBQXNCLElBQUksSUFBSSxJQUFJLElBQUk7S0FFM0MsSUFBSSxPQUFPLHNCQUFzQixJQUFJLElBQUksSUFBSSxFQUFFO0tBQy9DLE9BQU87TUFDSCxLQUFLLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSyxNQUFNLEtBQUs7TUFDM0MsS0FBSyxLQUFLLE1BQU0sS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLO01BQzNDLEtBQUssS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztNQUMzQyxLQUFLLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSyxNQUFNLEtBQUs7TUFDM0MsS0FBSyxLQUFLLE1BQU0sS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLO01BQzNDLEtBQUssS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztNQUMzQyxLQUFLLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSyxNQUFNLEtBQUs7TUFDM0MsS0FBSyxLQUFLLE1BQU0sS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLO01BQzNDLEtBQUssS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sS0FBSztLQUMvQztJQUNKO0lBQ0EsU0FBUyxNQUFNLEdBQUcsR0FBRztLQUNqQixPQUFPO01BQ0gsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUU7TUFDL0MsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUU7TUFDL0MsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUU7TUFDL0MsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUU7TUFDL0MsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUU7TUFDL0MsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUU7TUFDL0MsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUU7TUFDL0MsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUU7TUFDL0MsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUU7S0FDbkQ7SUFDSjtJQUNBLFNBQVMsUUFBUSxPQUFPLFVBQVU7S0FDOUIsSUFBSSxPQUFPLHNCQUFzQjtNQUFFLEdBQUc7TUFBSyxHQUFHO0tBQUksR0FBRztNQUFFLEdBQUcsU0FBUyxZQUFZO01BQUssR0FBRztLQUFJLEdBQUc7TUFBRSxHQUFHLFNBQVMsWUFBWTtNQUFLLEdBQUcsU0FBUyxZQUFZO0tBQUksR0FBRztNQUFFLEdBQUc7TUFBSyxHQUFHLFNBQVMsWUFBWTtLQUFJLENBQUM7S0FFbk0sSUFBSSxZQUFZLE1BREwsc0JBQXNCLFNBQVMsU0FBUyxTQUFTLFVBQVUsU0FBUyxrQkFBa0IsU0FBUyxVQUNqRixHQUFHLElBQUk7S0FDaEMsSUFBSSxTQUFTLFlBQVksVUFBVSxZQUFZLFNBQVMsV0FBVyxTQUFTLFNBQVM7S0FDckYsSUFBSSxrQkFBa0IsU0FBVSxHQUFHLEdBQUc7TUFDbEMsSUFBSSxjQUFjLFVBQVUsTUFBTSxJQUFJLFVBQVUsTUFBTSxJQUFJLFVBQVU7TUFDcEUsT0FBTztPQUNILElBQUksVUFBVSxNQUFNLElBQUksVUFBVSxNQUFNLElBQUksVUFBVSxPQUFPO09BQzdELElBQUksVUFBVSxNQUFNLElBQUksVUFBVSxNQUFNLElBQUksVUFBVSxPQUFPO01BQ2pFO0tBQ0o7S0FDQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxXQUFXLEtBQ3BDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFdBQVcsS0FBSztNQUd6QyxJQUFJLGNBQWMsZ0JBRkwsSUFBSSxJQUNKLElBQUksRUFDK0I7TUFDaEQsT0FBTyxJQUFJLEdBQUcsR0FBRyxNQUFNLElBQUksS0FBSyxNQUFNLFlBQVksQ0FBQyxHQUFHLEtBQUssTUFBTSxZQUFZLENBQUMsQ0FBQyxDQUFDO0tBQ3BGO0tBRUosT0FBTztNQUNLO01BQ1M7S0FDckI7SUFDSjtJQUNBLFdBQVEsVUFBVTtHQUdaO0lBRUMsU0FBUyxXQUFRLFlBQVMscUJBQXFCO0lBRXREO0lBRUEsT0FBTyxlQUFlQSxZQUFTLGNBQWMsRUFBRSxPQUFPLEtBQUssQ0FBQztJQUM1RCxJQUFJLCtCQUErQjtJQUNuQyxJQUFJLGlCQUFpQjtJQUNyQixJQUFJLGlCQUFpQjtJQUNyQixJQUFJLFdBQVcsU0FBVSxHQUFHLEdBQUc7S0FBRSxPQUFPLEtBQUssS0FBSyxLQUFLLElBQUssRUFBRSxJQUFJLEVBQUUsR0FBSSxDQUFDLElBQUksS0FBSyxJQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUksQ0FBQyxDQUFDO0lBQUc7SUFDeEcsU0FBUyxJQUFJLFFBQVE7S0FDakIsT0FBTyxPQUFPLE9BQU8sU0FBVSxHQUFHLEdBQUc7TUFBRSxPQUFPLElBQUk7S0FBRyxDQUFDO0lBQzFEO0lBRUEsU0FBUyxzQkFBc0IsVUFBVSxVQUFVLFVBQVU7S0FDekQsSUFBSSxJQUFJLElBQUksSUFBSTtLQUVoQixJQUFJLGlCQUFpQixTQUFTLFVBQVUsUUFBUTtLQUNoRCxJQUFJLG1CQUFtQixTQUFTLFVBQVUsUUFBUTtLQUNsRCxJQUFJLG1CQUFtQixTQUFTLFVBQVUsUUFBUTtLQUNsRCxJQUFJO0tBQ0osSUFBSTtLQUNKLElBQUk7S0FFSixJQUFJLG9CQUFvQixrQkFBa0Isb0JBQW9CLGtCQUMxRCxLQUFLO01BQUM7TUFBVTtNQUFVO0tBQVEsR0FBRyxhQUFhLEdBQUcsSUFBSSxVQUFVLEdBQUcsSUFBSSxXQUFXLEdBQUc7VUFFdkYsSUFBSSxvQkFBb0Isb0JBQW9CLG9CQUFvQixnQkFDakUsS0FBSztNQUFDO01BQVU7TUFBVTtLQUFRLEdBQUcsYUFBYSxHQUFHLElBQUksVUFBVSxHQUFHLElBQUksV0FBVyxHQUFHO1VBR3hGLEtBQUs7TUFBQztNQUFVO01BQVU7S0FBUSxHQUFHLGFBQWEsR0FBRyxJQUFJLFVBQVUsR0FBRyxJQUFJLFdBQVcsR0FBRztLQUs1RixLQUFNLFNBQVMsSUFBSSxRQUFRLE1BQU0sV0FBVyxJQUFJLFFBQVEsTUFBUSxTQUFTLElBQUksUUFBUSxNQUFNLFdBQVcsSUFBSSxRQUFRLEtBQU0sR0FDcEgsS0FBSyxDQUFDLFVBQVUsVUFBVSxHQUFHLGFBQWEsR0FBRyxJQUFJLFdBQVcsR0FBRztLQUVuRSxPQUFPO01BQWM7TUFBcUI7TUFBbUI7S0FBUztJQUMxRTtJQUVBLFNBQVMsaUJBQWlCLFNBQVMsVUFBVSxZQUFZLFFBQVE7S0FDN0QsSUFBSSxjQUFjLElBQUksbUJBQW1CLFNBQVMsWUFBWSxRQUFRLENBQUMsQ0FBQyxJQUFJLElBQ3hFLElBQUksbUJBQW1CLFNBQVMsVUFBVSxRQUFRLENBQUMsQ0FBQyxJQUFJLElBQ3hELElBQUksbUJBQW1CLFlBQVksU0FBUyxRQUFRLENBQUMsQ0FBQyxJQUFJLElBQzFELElBQUksbUJBQW1CLFVBQVUsU0FBUyxRQUFRLENBQUMsQ0FBQyxJQUFJLEtBQUs7S0FDakUsSUFBSSxhQUFhLEdBQ2IsTUFBTSxJQUFJLE1BQU0scUJBQXFCO0tBRXpDLElBQUksZUFBZSxLQUFLLE1BQU0sU0FBUyxTQUFTLFFBQVEsSUFBSSxVQUFVO0tBQ3RFLElBQUksZ0JBQWdCLEtBQUssTUFBTSxTQUFTLFNBQVMsVUFBVSxJQUFJLFVBQVU7S0FDekUsSUFBSSxZQUFZLEtBQUssT0FBTyxlQUFlLGlCQUFpQixDQUFDLElBQUk7S0FDakUsUUFBUSxZQUFZLEdBQXBCO01BQ0ksS0FBSztPQUNEO09BQ0E7TUFDSixLQUFLLEdBQ0Q7S0FFUjtLQUNBLE9BQU87TUFBYTtNQUF1QjtLQUFXO0lBQzFEO0lBSUEsU0FBUywrQkFBK0IsUUFBUSxLQUFLLFFBQVEsUUFBUTtLQUNqRSxJQUFJLGVBQWUsQ0FBQztNQUFFLEdBQUcsS0FBSyxNQUFNLE9BQU8sQ0FBQztNQUFHLEdBQUcsS0FBSyxNQUFNLE9BQU8sQ0FBQztLQUFFLENBQUM7S0FDeEUsSUFBSSxRQUFRLEtBQUssSUFBSSxJQUFJLElBQUksT0FBTyxDQUFDLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxPQUFPLENBQUM7S0FDbEUsSUFBSTtLQUNKLElBQUk7S0FDSixJQUFJO0tBQ0osSUFBSTtLQUNKLElBQUksT0FBTztNQUNQLFFBQVEsS0FBSyxNQUFNLE9BQU8sQ0FBQztNQUMzQixRQUFRLEtBQUssTUFBTSxPQUFPLENBQUM7TUFDM0IsTUFBTSxLQUFLLE1BQU0sSUFBSSxDQUFDO01BQ3RCLE1BQU0sS0FBSyxNQUFNLElBQUksQ0FBQztLQUMxQixPQUNLO01BQ0QsUUFBUSxLQUFLLE1BQU0sT0FBTyxDQUFDO01BQzNCLFFBQVEsS0FBSyxNQUFNLE9BQU8sQ0FBQztNQUMzQixNQUFNLEtBQUssTUFBTSxJQUFJLENBQUM7TUFDdEIsTUFBTSxLQUFLLE1BQU0sSUFBSSxDQUFDO0tBQzFCO0tBQ0EsSUFBSSxLQUFLLEtBQUssSUFBSSxNQUFNLEtBQUs7S0FDN0IsSUFBSSxLQUFLLEtBQUssSUFBSSxNQUFNLEtBQUs7S0FDN0IsSUFBSSxRQUFRLEtBQUssTUFBTSxDQUFDLEtBQUssQ0FBQztLQUM5QixJQUFJLFFBQVEsUUFBUSxNQUFNLElBQUk7S0FDOUIsSUFBSSxRQUFRLFFBQVEsTUFBTSxJQUFJO0tBQzlCLElBQUksZUFBZTtLQUVuQixLQUFLLElBQUksSUFBSSxPQUFPLElBQUksT0FBTyxNQUFNLE1BQU0sT0FBTyxLQUFLLE9BQU87TUFJMUQsSUFBSSxRQUFRLFFBQVEsSUFBSTtNQUN4QixJQUFJLFFBQVEsUUFBUSxJQUFJO01BQ3hCLElBQUksT0FBTyxJQUFJLE9BQU8sS0FBSyxNQUFNLGNBQWM7T0FDM0MsZUFBZSxDQUFDO09BQ2hCLGFBQWEsS0FBSztRQUFFLEdBQUc7UUFBTyxHQUFHO09BQU0sQ0FBQztPQUN4QyxJQUFJLGFBQWEsV0FBVyxTQUFTLEdBQ2pDO01BRVI7TUFDQSxTQUFTO01BQ1QsSUFBSSxRQUFRLEdBQUc7T0FDWCxJQUFJLE1BQU0sS0FDTjtPQUVKLEtBQUs7T0FDTCxTQUFTO01BQ2I7S0FDSjtLQUNBLElBQUksWUFBWSxDQUFDO0tBQ2pCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLEtBQ3hCLElBQUksYUFBYSxNQUFNLGFBQWEsSUFBSSxJQUNwQyxVQUFVLEtBQUssU0FBUyxhQUFhLElBQUksYUFBYSxJQUFJLEVBQUUsQ0FBQztVQUc3RCxVQUFVLEtBQUssQ0FBQztLQUd4QixPQUFPO0lBQ1g7SUFJQSxTQUFTLG1CQUFtQixRQUFRLEtBQUssUUFBUSxRQUFRO0tBQ3JELElBQUk7S0FDSixJQUFJLE9BQU8sSUFBSSxJQUFJLE9BQU87S0FDMUIsSUFBSSxNQUFNLElBQUksSUFBSSxPQUFPO0tBQ3pCLElBQUksYUFBYSwrQkFBK0IsUUFBUSxLQUFLLFFBQVEsS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDO0tBQzFGLElBQUksY0FBYywrQkFBK0IsUUFBUTtNQUFFLEdBQUcsT0FBTyxJQUFJO01BQUssR0FBRyxPQUFPLElBQUk7S0FBSyxHQUFHLFFBQVEsS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDO0tBQ2pJLElBQUksY0FBYyxXQUFXLE1BQU0sSUFBSSxZQUFZLE1BQU0sSUFBSTtLQUM3RCxRQUFRLEtBQUssWUFBWSxPQUFPLFdBQVcsRUFBQSxDQUFHLE9BQU8sTUFBTSxJQUFJLFVBQVU7SUFDN0U7SUFHQSxTQUFTLG1CQUFtQixVQUFVLFFBQVE7S0FDMUMsSUFBSSxjQUFjLElBQUksUUFBUSxJQUFJLElBQUksTUFBTTtLQUM1QyxJQUFJLFFBQVE7S0FDWixPQUFPLFFBQVEsU0FBVSxPQUFPLEdBQUc7TUFDL0IsU0FBUyxLQUFLLElBQUssU0FBUyxLQUFLLFFBQVEsYUFBYyxDQUFDO0tBQzVELENBQUM7S0FDRCxPQUFPO01BQWU7TUFBb0I7S0FBTTtJQUNwRDtJQUlBLFNBQVMsYUFBYSxPQUFPLFFBQVEsUUFBUTtLQUN6QyxJQUFJO01BQ0EsSUFBSSxnQkFBZ0IsbUJBQW1CLE9BQU87T0FBRSxHQUFHO09BQUksR0FBRyxNQUFNO01BQUUsR0FBRyxRQUFRLE9BQU8sTUFBTTtNQUMxRixJQUFJLGNBQWMsbUJBQW1CLE9BQU87T0FBRSxHQUFHLE1BQU07T0FBRyxHQUFHO01BQUcsR0FBRyxRQUFRLE9BQU8sTUFBTTtNQUt4RixJQUFJLHdCQUF3QixtQkFBbUIsT0FBTztPQUhsRCxHQUFHLEtBQUssSUFBSSxHQUFHLE1BQU0sSUFBSSxNQUFNLENBQUMsSUFBSTtPQUNwQyxHQUFHLEtBQUssSUFBSSxHQUFHLE1BQU0sSUFBSSxNQUFNLENBQUMsSUFBSTtNQUV5QixHQUFHLFFBQVEsT0FBTyxNQUFNO01BS3pGLElBQUksd0JBQXdCLG1CQUFtQixPQUFPO09BSGxELEdBQUcsS0FBSyxJQUFJLE9BQU8sT0FBTyxNQUFNLElBQUksTUFBTSxDQUFDLElBQUk7T0FDL0MsR0FBRyxLQUFLLElBQUksT0FBTyxRQUFRLE1BQU0sSUFBSSxNQUFNLENBQUMsSUFBSTtNQUVnQixHQUFHLFFBQVEsT0FBTyxNQUFNO01BQzVGLElBQUksWUFBWSxtQkFBbUIsZUFBZSxNQUFNO01BQ3hELElBQUksWUFBWSxtQkFBbUIsYUFBYSxNQUFNO01BQ3RELElBQUksZ0JBQWdCLG1CQUFtQix1QkFBdUIsTUFBTTtNQUNwRSxJQUFJLGNBQWMsbUJBQW1CLHVCQUF1QixNQUFNO01BQ2xFLElBQUksYUFBYSxLQUFLLEtBQUssVUFBVSxRQUFRLFVBQVUsUUFDbkQsVUFBVSxRQUFRLFVBQVUsUUFDNUIsY0FBYyxRQUFRLGNBQWMsUUFDcEMsWUFBWSxRQUFRLFlBQVksS0FBSztNQUN6QyxJQUFJLFdBQVcsVUFBVSxjQUFjLFVBQVUsY0FBYyxjQUFjLGNBQWMsWUFBWSxlQUFlO01BS3RILE9BQU8sY0FKVSxLQUFLLElBQUssVUFBVSxjQUFjLFNBQVUsQ0FBQyxJQUMxRCxLQUFLLElBQUssVUFBVSxjQUFjLFNBQVUsQ0FBQyxJQUM3QyxLQUFLLElBQUssY0FBYyxjQUFjLFNBQVUsQ0FBQyxJQUNqRCxLQUFLLElBQUssWUFBWSxjQUFjLFNBQVUsQ0FBQyxLQUFLO0tBRTVELFNBQ08sSUFBSTtNQUNQLE9BQU87S0FDWDtJQUNKO0lBQ0EsU0FBUyxpQkFBaUIsUUFBUSxHQUFHO0tBQ2pDLElBQUksUUFBUSxLQUFLLE1BQU0sRUFBRSxDQUFDO0tBQzFCLE9BQU8sT0FBTyxJQUFJLE9BQU8sS0FBSyxNQUFNLEVBQUUsQ0FBQyxDQUFDLEdBQ3BDO0tBRUosSUFBSSxTQUFTLEtBQUssTUFBTSxFQUFFLENBQUM7S0FDM0IsT0FBTyxPQUFPLElBQUksUUFBUSxLQUFLLE1BQU0sRUFBRSxDQUFDLENBQUMsR0FDckM7S0FFSixJQUFJLEtBQUssUUFBUSxVQUFVO0tBQzNCLElBQUksT0FBTyxLQUFLLE1BQU0sRUFBRSxDQUFDO0tBQ3pCLE9BQU8sT0FBTyxJQUFJLEtBQUssTUFBTSxDQUFDLEdBQUcsSUFBSSxHQUNqQztLQUVKLElBQUksVUFBVSxLQUFLLE1BQU0sRUFBRSxDQUFDO0tBQzVCLE9BQU8sT0FBTyxJQUFJLEtBQUssTUFBTSxDQUFDLEdBQUcsT0FBTyxHQUNwQztLQUdKLE9BQU87TUFBSztNQUFHLElBRE4sT0FBTyxXQUFXO0tBQ1A7SUFDeEI7SUFDQSxTQUFTLE9BQU8sUUFBUTtLQUNwQixJQUFJLHFCQUFxQixDQUFDO0tBQzFCLElBQUksMkJBQTJCLENBQUM7S0FDaEMsSUFBSSx3QkFBd0IsQ0FBQztLQUM3QixJQUFJLDhCQUE4QixDQUFDO0tBQ25DLElBQUksVUFBVSxTQUFVLEdBQUc7TUFDdkIsSUFBSSxXQUFXO01BQ2YsSUFBSSxVQUFVO01BQ2QsSUFBSSxRQUFRO09BQUM7T0FBRztPQUFHO09BQUc7T0FBRztNQUFDO01BQzFCLElBQUksVUFBVSxTQUFVLEdBQUc7T0FDdkIsSUFBSSxJQUFJLE9BQU8sSUFBSSxHQUFHLENBQUM7T0FDdkIsSUFBSSxNQUFNLFNBQ047WUFFQztRQUNELFFBQVE7U0FBQyxNQUFNO1NBQUksTUFBTTtTQUFJLE1BQU07U0FBSSxNQUFNO1NBQUk7UUFBUTtRQUN6RCxXQUFXO1FBQ1gsVUFBVTtRQUVWLElBQUksZ0NBQWdDLElBQUksS0FBSyxJQUFJO1FBQ2pELElBQUkscUJBQXFCLEtBQUssSUFBSSxNQUFNLEtBQUssNkJBQTZCLElBQUksaUNBQzFFLEtBQUssSUFBSSxNQUFNLEtBQUssNkJBQTZCLElBQUksaUNBQ3JELEtBQUssSUFBSSxNQUFNLEtBQUssSUFBSSw2QkFBNkIsSUFBSSxJQUFJLGlDQUM3RCxLQUFLLElBQUksTUFBTSxLQUFLLDZCQUE2QixJQUFJLGlDQUNyRCxLQUFLLElBQUksTUFBTSxLQUFLLDZCQUE2QixJQUFJLGlDQUNyRCxDQUFDO1FBRUwsSUFBSSxtQ0FBbUMsSUFBSSxNQUFNLE1BQU0sRUFBRSxDQUFDLElBQUk7UUFDOUQsSUFBSSx3QkFBd0IsS0FBSyxJQUFJLE1BQU0sS0FBSyxnQ0FBZ0MsSUFBSSxvQ0FDaEYsS0FBSyxJQUFJLE1BQU0sS0FBSyxnQ0FBZ0MsSUFBSSxvQ0FDeEQsS0FBSyxJQUFJLE1BQU0sS0FBSyxnQ0FBZ0MsSUFBSSxvQ0FDeEQ7UUFDSixJQUFJLG9CQUFvQjtTQUVwQixJQUFJLFNBQVMsSUFBSSxNQUFNLEtBQUssTUFBTTtTQUNsQyxJQUFJLFdBQVcsU0FBUyxNQUFNO1NBQzlCLElBQUksT0FBTztVQUFFLFFBQVE7VUFBVSxNQUFNO1VBQVc7U0FBRTtTQUdsRCxJQUFJLGdCQUFnQix5QkFBeUIsT0FBTyxTQUFVLEdBQUc7VUFDN0QsT0FBUSxZQUFZLEVBQUUsT0FBTyxVQUFVLFlBQVksRUFBRSxPQUFPLFFBQ3ZELFVBQVUsRUFBRSxPQUFPLFVBQVUsWUFBWSxFQUFFLE9BQU8sUUFDbEQsWUFBWSxFQUFFLE9BQU8sVUFBVSxVQUFVLEVBQUUsT0FBTyxRQUFVLE1BQU0sTUFBTSxFQUFFLE9BQU8sT0FBTyxFQUFFLE9BQU8sVUFBVyxrQkFDeEcsTUFBTSxNQUFNLEVBQUUsT0FBTyxPQUFPLEVBQUUsT0FBTyxVQUFXO1NBQzdELENBQUM7U0FDRCxJQUFJLGNBQWMsU0FBUyxHQUN2QixjQUFjLEVBQUUsQ0FBQyxTQUFTO2NBRzFCLHlCQUF5QixLQUFLO1VBQUUsS0FBSztVQUFNLFFBQVE7U0FBSyxDQUFDO1FBRWpFO1FBQ0EsSUFBSSx1QkFBdUI7U0FFdkIsSUFBSSxTQUFTLElBQUksTUFBTTtTQUN2QixJQUFJLFdBQVcsU0FBUyxNQUFNO1NBQzlCLElBQUksT0FBTztVQUFFLFFBQVE7VUFBYTtVQUFHLE1BQU07U0FBTztTQUdsRCxJQUFJLGdCQUFnQiw0QkFBNEIsT0FBTyxTQUFVLEdBQUc7VUFDaEUsT0FBUSxZQUFZLEVBQUUsT0FBTyxVQUFVLFlBQVksRUFBRSxPQUFPLFFBQ3ZELFVBQVUsRUFBRSxPQUFPLFVBQVUsWUFBWSxFQUFFLE9BQU8sUUFDbEQsWUFBWSxFQUFFLE9BQU8sVUFBVSxVQUFVLEVBQUUsT0FBTyxRQUFVLE1BQU0sTUFBTSxFQUFFLE9BQU8sT0FBTyxFQUFFLE9BQU8sVUFBVyxrQkFDeEcsTUFBTSxNQUFNLEVBQUUsT0FBTyxPQUFPLEVBQUUsT0FBTyxVQUFXO1NBQzdELENBQUM7U0FDRCxJQUFJLGNBQWMsU0FBUyxHQUN2QixjQUFjLEVBQUUsQ0FBQyxTQUFTO2NBRzFCLDRCQUE0QixLQUFLO1VBQUUsS0FBSztVQUFNLFFBQVE7U0FBSyxDQUFDO1FBRXBFO09BQ0o7TUFDSjtNQUNBLEtBQUssSUFBSSxJQUFJLElBQUksS0FBSyxPQUFPLE9BQU8sS0FDaEMsUUFBUSxDQUFDO01BRWIsbUJBQW1CLEtBQUssTUFBTSxvQkFBb0IseUJBQXlCLE9BQU8sU0FBVSxHQUFHO09BQUUsT0FBTyxFQUFFLE9BQU8sTUFBTSxLQUFLLEVBQUUsT0FBTyxJQUFJLEVBQUUsSUFBSSxLQUFLO01BQUcsQ0FBQyxDQUFDO01BQ3pKLDJCQUEyQix5QkFBeUIsT0FBTyxTQUFVLEdBQUc7T0FBRSxPQUFPLEVBQUUsT0FBTyxNQUFNO01BQUcsQ0FBQztNQUNwRyxzQkFBc0IsS0FBSyxNQUFNLHVCQUF1Qiw0QkFBNEIsT0FBTyxTQUFVLEdBQUc7T0FBRSxPQUFPLEVBQUUsT0FBTyxNQUFNO01BQUcsQ0FBQyxDQUFDO01BQ3JJLDhCQUE4Qiw0QkFBNEIsT0FBTyxTQUFVLEdBQUc7T0FBRSxPQUFPLEVBQUUsT0FBTyxNQUFNO01BQUcsQ0FBQztLQUM5RztLQUNBLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxPQUFPLFFBQVEsS0FDaEMsUUFBUSxDQUFDO0tBRWIsbUJBQW1CLEtBQUssTUFBTSxvQkFBb0IseUJBQXlCLE9BQU8sU0FBVSxHQUFHO01BQUUsT0FBTyxFQUFFLE9BQU8sSUFBSSxFQUFFLElBQUksS0FBSztLQUFHLENBQUMsQ0FBQztLQUNySSxzQkFBc0IsS0FBSyxNQUFNLHVCQUF1QiwyQkFBMkI7S0FDbkYsSUFBSSxzQkFBc0IsbUJBQ3JCLE9BQU8sU0FBVSxHQUFHO01BQUUsT0FBTyxFQUFFLE9BQU8sSUFBSSxFQUFFLElBQUksS0FBSztLQUFHLENBQUMsQ0FBQyxDQUMxRCxJQUFJLFNBQVUsR0FBRztNQUNsQixJQUFJLEtBQUssRUFBRSxJQUFJLFNBQVMsRUFBRSxJQUFJLE9BQU8sRUFBRSxPQUFPLFNBQVMsRUFBRSxPQUFPLFFBQVE7TUFDeEUsSUFBSSxLQUFLLEVBQUUsSUFBSSxJQUFJLEVBQUUsT0FBTyxJQUFJLEtBQUs7TUFDckMsSUFBSSxDQUFDLE9BQU8sSUFBSSxLQUFLLE1BQU0sQ0FBQyxHQUFHLEtBQUssTUFBTSxDQUFDLENBQUMsR0FDeEM7TUFFSixJQUFJLFVBQVU7T0FBQyxFQUFFLElBQUksT0FBTyxFQUFFLElBQUk7T0FBUSxFQUFFLE9BQU8sT0FBTyxFQUFFLE9BQU87T0FBUSxFQUFFLE9BQU8sSUFBSSxFQUFFLElBQUksSUFBSTtNQUFDO01BQ25HLElBQUksT0FBTyxJQUFJLE9BQU8sSUFBSSxRQUFRO01BRWxDLE9BQU87T0FBRSxPQURHLGFBQWE7UUFBRSxHQUFHLEtBQUssTUFBTSxDQUFDO1FBQUcsR0FBRyxLQUFLLE1BQU0sQ0FBQztPQUFFLEdBQUc7UUFBQztRQUFHO1FBQUc7UUFBRztRQUFHO09BQUMsR0FBRyxNQUM5RDtPQUFNO09BQU07T0FBUztNQUFLO0tBQ2xELENBQUMsQ0FBQyxDQUNHLE9BQU8sU0FBVSxHQUFHO01BQUUsT0FBTyxDQUFDLENBQUM7S0FBRyxDQUFDLENBQUMsQ0FDcEMsS0FBSyxTQUFVLEdBQUcsR0FBRztNQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUU7S0FBTyxDQUFDLENBQUMsQ0FFbkQsSUFBSSxTQUFVLE9BQU8sR0FBRyxnQkFBZ0I7TUFDekMsSUFBSSxJQUFJLDhCQUNKLE9BQU87TUFFWCxJQUFJLGNBQWMsZUFDYixPQUFPLFNBQVUsR0FBRyxJQUFJO09BQUUsT0FBTyxNQUFNO01BQUksQ0FBQyxDQUFDLENBQzdDLElBQUksU0FBVSxHQUFHO09BQUUsT0FBUTtRQUFFLEdBQUcsRUFBRTtRQUFHLEdBQUcsRUFBRTtRQUFHLE9BQU8sRUFBRSxRQUFTLEtBQUssSUFBSyxFQUFFLE9BQU8sTUFBTSxNQUFPLENBQUMsSUFBSyxNQUFNO1FBQU0sTUFBTSxFQUFFO09BQUs7TUFBSSxDQUFDLENBQUMsQ0FDcEksS0FBSyxTQUFVLEdBQUcsR0FBRztPQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUU7TUFBTyxDQUFDO01BQ3ZELElBQUksWUFBWSxTQUFTLEdBQ3JCLE9BQU87TUFFWCxJQUFJLFFBQVEsTUFBTSxRQUFRLFlBQVksRUFBRSxDQUFDLFFBQVEsWUFBWSxFQUFFLENBQUM7TUFDaEUsT0FBTztPQUFFLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLFlBQVksTUFBTSxHQUFHLENBQUMsQ0FBQztPQUFVO01BQU07S0FDM0UsQ0FBQyxDQUFDLENBQ0csT0FBTyxTQUFVLEdBQUc7TUFBRSxPQUFPLENBQUMsQ0FBQztLQUFHLENBQUMsQ0FBQyxDQUNwQyxLQUFLLFNBQVUsR0FBRyxHQUFHO01BQUUsT0FBTyxFQUFFLFFBQVEsRUFBRTtLQUFPLENBQUM7S0FDdkQsSUFBSSxvQkFBb0IsV0FBVyxHQUMvQixPQUFPO0tBRVgsSUFBSSxLQUFLLHNCQUFzQixvQkFBb0IsRUFBRSxDQUFDLE9BQU8sSUFBSSxvQkFBb0IsRUFBRSxDQUFDLE9BQU8sSUFBSSxvQkFBb0IsRUFBRSxDQUFDLE9BQU8sRUFBRSxHQUFHLFdBQVcsR0FBRyxVQUFVLFVBQVUsR0FBRyxTQUFTLGFBQWEsR0FBRztLQUNwTSxJQUFJLFlBQVkscUJBQXFCLFFBQVEsdUJBQXVCLFVBQVUsU0FBUyxVQUFVO0tBQ2pHLElBQUksU0FBUyxDQUFDO0tBQ2QsSUFBSSxXQUNBLE9BQU8sS0FBSztNQUNSLGtCQUFrQjtPQUFFLEdBQUcsVUFBVSxpQkFBaUI7T0FBRyxHQUFHLFVBQVUsaUJBQWlCO01BQUU7TUFDckYsWUFBWTtPQUFFLEdBQUcsV0FBVztPQUFHLEdBQUcsV0FBVztNQUFFO01BQy9DLFdBQVcsVUFBVTtNQUNyQixTQUFTO09BQUUsR0FBRyxRQUFRO09BQUcsR0FBRyxRQUFRO01BQUU7TUFDdEMsVUFBVTtPQUFFLEdBQUcsU0FBUztPQUFHLEdBQUcsU0FBUztNQUFFO0tBQzdDLENBQUM7S0FPTCxJQUFJLGNBQWMsaUJBQWlCLFFBQVEsUUFBUTtLQUNuRCxJQUFJLGFBQWEsaUJBQWlCLFFBQVEsT0FBTztLQUNqRCxJQUFJLGdCQUFnQixpQkFBaUIsUUFBUSxVQUFVO0tBQ3ZELElBQUksb0JBQW9CLHFCQUFxQixRQUFRLHVCQUF1QixhQUFhLFlBQVksYUFBYTtLQUNsSCxJQUFJLG1CQUNBLE9BQU8sS0FBSztNQUNSLGtCQUFrQjtPQUFFLEdBQUcsa0JBQWtCLGlCQUFpQjtPQUFHLEdBQUcsa0JBQWtCLGlCQUFpQjtNQUFFO01BQ3JHLFlBQVk7T0FBRSxHQUFHLGNBQWM7T0FBRyxHQUFHLGNBQWM7TUFBRTtNQUNyRCxTQUFTO09BQUUsR0FBRyxXQUFXO09BQUcsR0FBRyxXQUFXO01BQUU7TUFDNUMsVUFBVTtPQUFFLEdBQUcsWUFBWTtPQUFHLEdBQUcsWUFBWTtNQUFFO01BQy9DLFdBQVcsa0JBQWtCO0tBQ2pDLENBQUM7S0FFTCxJQUFJLE9BQU8sV0FBVyxHQUNsQixPQUFPO0tBRVgsT0FBTztJQUNYO0lBQ0EsV0FBUSxTQUFTO0lBQ2pCLFNBQVMscUJBQXFCLFFBQVEsdUJBQXVCLFVBQVUsU0FBUyxZQUFZO0tBQ3hGLElBQUk7S0FHSixJQUFJO0tBQ0osSUFBSTtLQUNKLElBQUk7TUFDQSxLQUFNLGlCQUFpQixTQUFTLFVBQVUsWUFBWSxNQUFNLEdBQUcsWUFBWSxHQUFHLFdBQVcsYUFBYSxHQUFHO0tBQzdHLFNBQ08sR0FBRztNQUNOLE9BQU87S0FDWDtLQUVBLElBQUksMkJBQTJCO01BQzNCLEdBQUcsU0FBUyxJQUFJLFFBQVEsSUFBSSxXQUFXO01BQ3ZDLEdBQUcsU0FBUyxJQUFJLFFBQVEsSUFBSSxXQUFXO0tBQzNDO0tBQ0EsSUFBSSxnQ0FBaUMsU0FBUyxTQUFTLFVBQVUsSUFBSSxTQUFTLFNBQVMsUUFBUSxLQUFLLElBQUk7S0FDeEcsSUFBSSxzQkFBc0IsSUFBSyxJQUFJO0tBQ25DLElBQUksMkJBQTJCO01BQzNCLEdBQUcsUUFBUSxJQUFJLHVCQUF1Qix5QkFBeUIsSUFBSSxRQUFRO01BQzNFLEdBQUcsUUFBUSxJQUFJLHVCQUF1Qix5QkFBeUIsSUFBSSxRQUFRO0tBQy9FO0tBQ0EsSUFBSSxvQkFBb0Isc0JBQ25CLElBQUksU0FBVSxHQUFHO01BQ2xCLElBQUksS0FBSyxFQUFFLElBQUksU0FBUyxFQUFFLElBQUksT0FBTyxFQUFFLE9BQU8sU0FBUyxFQUFFLE9BQU8sUUFBUTtNQUN4RSxJQUFJLEtBQUssRUFBRSxJQUFJLElBQUksRUFBRSxPQUFPLElBQUksS0FBSztNQUNyQyxJQUFJLENBQUMsT0FBTyxJQUFJLEtBQUssTUFBTSxDQUFDLEdBQUcsS0FBSyxNQUFNLENBQUMsQ0FBQyxHQUN4QztNQUVKLElBQUksVUFBVTtPQUFDLEVBQUUsSUFBSSxPQUFPLEVBQUUsSUFBSTtPQUFRLEVBQUUsT0FBTyxPQUFPLEVBQUUsT0FBTztPQUFTLEVBQUUsT0FBTyxJQUFJLEVBQUUsSUFBSSxJQUFJO01BQUU7TUFDMUYsSUFBSSxPQUFPLElBQUksUUFBUTtNQUdsQyxPQUFPO09BQUs7T0FBTTtPQUFHLE9BRkwsYUFBYTtRQUFFLEdBQUcsS0FBSyxNQUFNLENBQUM7UUFBRyxHQUFHLEtBQUssTUFBTSxDQUFDO09BQUUsR0FBRztRQUFDO1FBQUc7UUFBRztPQUFDLEdBQUcsTUFDNUQsSUFBSSxTQUFTO1FBQUs7UUFBTTtPQUFFLEdBQUcsd0JBQXdCO01BQ3ZDO0tBQ3RDLENBQUMsQ0FBQyxDQUNHLE9BQU8sU0FBVSxHQUFHO01BQUUsT0FBTyxDQUFDLENBQUM7S0FBRyxDQUFDLENBQUMsQ0FDcEMsS0FBSyxTQUFVLEdBQUcsR0FBRztNQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUU7S0FBTyxDQUFDO0tBSXZELE9BQU87TUFBRSxrQkFEYyxnQ0FBZ0MsTUFBTSxrQkFBa0IsU0FBUyxrQkFBa0IsS0FBSztNQUN2RDtLQUFVO0lBQ3RFO0dBR007RUFDRyxDQUFDLENBQUMsQ0FBQztDQUNaLENBQUMiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19