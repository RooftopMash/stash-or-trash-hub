import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ProductAuthenticityCameraScanner.tsx");const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=a8030269";
import { Button } from "/src/components/ui/button.tsx";
import { Badge } from "/src/components/ui/badge.tsx";
import { Progress } from "/src/components/ui/progress.tsx";
import { Camera, Scan, QrCode, ShieldCheck, ShieldAlert, AlertTriangle, Building2, Sparkles, Upload, RefreshCw, CheckCircle2, ArrowRight, Zap, ZapOff, Eye, Copy, Tag, HelpCircle, ExternalLink, FileCheck, Printer } from "/node_modules/.vite/deps/lucide-react.js?v=a8030269";
import { detectBarcodeOrQr, getGs1CountryPrefix, playScanChime, fileToOptimizedBase64, extractFrameFromVideo, runAiScan } from "/src/lib/ai-scanner.ts";
import { searchBrands } from "/src/lib/brands.ts";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=a8030269";
var _jsxFileName = "/app/applet/src/components/ProductAuthenticityCameraScanner.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
var _s = $RefreshSig$();
export function ProductAuthenticityCameraScanner({ onApplyToPost, onClose, standalone = false }) {
	_s();
	const { t } = useTranslation();
	// Permission & Stream State
	const [permissionState, setPermissionState] = useState("prompt");
	const [streamActive, setStreamActive] = useState(false);
	const [cameraFacing, setCameraFacing] = useState("environment");
	const [hasTorch, setHasTorch] = useState(false);
	const [torchOn, setTorchOn] = useState(false);
	const [activeMode, setActiveMode] = useState("barcode");
	// Analysis & Result State
	const [scanning, setScanning] = useState(false);
	const [analyzingStep, setAnalyzingStep] = useState("");
	const [capturedImage, setCapturedImage] = useState(null);
	const [capturedFile, setCapturedFile] = useState(null);
	const [detectedCode, setDetectedCode] = useState(null);
	const [scanResult, setScanResult] = useState(null);
	const [matchedBrand, setMatchedBrand] = useState(null);
	// Tab view in results
	const [resultTab, setResultTab] = useState("authenticity");
	const [manualBarcode, setManualBarcode] = useState("");
	const [showManualBarcode, setShowManualBarcode] = useState(false);
	// Refs
	const videoRef = useRef(null);
	const streamRef = useRef(null);
	const scanLoopRef = useRef(null);
	const fileInputRef = useRef(null);
	const isDetectingRef = useRef(false);
	const handlePrintCertificate = () => {
		if (!scanResult) return;
		const printWindow = window.open("", "_blank");
		if (!printWindow) {
			toast.info("Please allow popups to print the certificate.");
			return;
		}
		const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Brand PR Authenticity & Forensic Audit Certificate</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 40px; color: #0f172a; max-width: 800px; margin: 0 auto; }
          .header { border-bottom: 2px solid #0f172a; padding-bottom: 20px; display: flex; justify-content: space-between; align-items: flex-end; }
          .badge { display: inline-block; padding: 6px 14px; background: #10b981; color: white; border-radius: 9999px; font-weight: bold; text-transform: uppercase; font-size: 12px; }
          .hero { margin: 30px 0; background: #f8fafc; padding: 24px; border-radius: 16px; border: 1px solid #e2e8f0; }
          .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 20px 0; }
          .card { border: 1px solid #e2e8f0; padding: 16px; border-radius: 12px; background: white; }
          .score { font-size: 36px; font-weight: 900; color: #10b981; }
          .footer { margin-top: 40px; border-top: 1px solid #e2e8f0; padding-top: 20px; font-size: 11px; color: #64748b; }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <h1 style="margin:0; font-size:24px;">STASH OR TRASH</h1>
            <p style="margin:4px 0 0 0; color:#64748b; font-size:13px;">Official Forensic Media & Authenticity Audit Dossier</p>
          </div>
          <div class="badge">${scanResult.counterfeitAssessment?.badgeLabel || "Verified Authentic"}</div>
        </div>
        <div class="hero">
          <div style="font-size:12px; text-transform:uppercase; color:#64748b; font-weight:bold;">Product & Brand Profile</div>
          <h2 style="margin:6px 0; font-size:26px;">${scanResult.brandInfo.brandName} — ${scanResult.brandInfo.productName || "Verified Product"}</h2>
          <p style="margin:0; color:#475569; font-size:14px;"><strong>Corporate Owner:</strong> ${scanResult.brandInfo.brandOwner} (${scanResult.brandInfo.countryOfOrigin})</p>
        </div>
        <div class="grid">
          <div class="card">
            <div style="font-size:12px; color:#64748b;">Authenticity Score</div>
            <div class="score">${scanResult.counterfeitAssessment?.authenticityScore ?? scanResult.authenticity.score}%</div>
            <p style="font-size:12px; color:#475569; margin-top:6px;">Confidence: ${scanResult.counterfeitAssessment?.confidence?.toUpperCase() || "HIGH"}</p>
          </div>
          <div class="card">
            <div style="font-size:12px; color:#64748b;">Media Integrity (Tamper Check)</div>
            <div class="score" style="color: #0284c7;">${scanResult.authenticity.score}%</div>
            <p style="font-size:12px; color:#475569; margin-top:6px;">Status: ${scanResult.authenticity.verdictStatus.replace("_", " ")}</p>
          </div>
        </div>
        <div class="card" style="margin-bottom: 20px;">
          <h3 style="margin-top:0; font-size:14px;">Forensic Attribute Verification</h3>
          <ul style="font-size:12px; color:#334155; line-height: 1.6; padding-left: 20px;">
            <li><strong>Lighting & Shadows:</strong> ${scanResult.authenticity.forensics?.physicalLighting || "Consistent physical shadows"}</li>
            <li><strong>Texture & Noise:</strong> ${scanResult.authenticity.forensics?.textureAndNoise || "Natural camera sensor grain verified"}</li>
            <li><strong>Typography & Print:</strong> ${scanResult.authenticity.forensics?.textIntegrity || "Verified manufacturer typeface geometry"}</li>
            <li><strong>AI / Deepfake Check:</strong> ${scanResult.authenticity.forensics?.aiGenerationMarkers || "Zero synthetic AI generation markers detected"}</li>
          </ul>
        </div>
        <div class="footer">
          Issued by Stash Or Trash AI Forensic System • Verified for Brand PR Officers & Client Service • Timestamp: ${new Date().toISOString()}
        </div>
        <script>
          window.onload = function() { window.print(); }
        <\/script>
      </body>
      </html>
    `;
		printWindow.document.write(html);
		printWindow.document.close();
	};
	// Check initial permission status if supported
	useEffect(() => {
		if (typeof navigator !== "undefined" && navigator.permissions?.query) {
			navigator.permissions.query({ name: "camera" }).then((permissionStatus) => {
				if (permissionStatus.state === "granted") {
					setPermissionState("granted");
				} else if (permissionStatus.state === "denied") {
					setPermissionState("denied");
				} else {
					setPermissionState("prompt");
				}
				permissionStatus.onchange = () => {
					if (permissionStatus.state === "granted") setPermissionState("granted");
					else if (permissionStatus.state === "denied") setPermissionState("denied");
					else setPermissionState("prompt");
				};
			}).catch(() => {
				// Fallback
			});
		}
	}, []);
	// Stop camera tracks and cancel scan loop
	const stopCamera = useCallback(() => {
		if (scanLoopRef.current) {
			cancelAnimationFrame(scanLoopRef.current);
			scanLoopRef.current = null;
		}
		if (streamRef.current) {
			streamRef.current.getTracks().forEach((track) => {
				try {
					track.stop();
				} catch {}
			});
			streamRef.current = null;
		}
		setStreamActive(false);
		setTorchOn(false);
	}, []);
	// Real-time detection loop for Barcodes & QR codes
	const runDetectionLoop = useCallback(() => {
		if (!videoRef.current || videoRef.current.readyState < 2) {
			scanLoopRef.current = requestAnimationFrame(runDetectionLoop);
			return;
		}
		if (isDetectingRef.current) {
			scanLoopRef.current = requestAnimationFrame(runDetectionLoop);
			return;
		}
		isDetectingRef.current = true;
		const video = videoRef.current;
		detectBarcodeOrQr(video).then((detected) => {
			if (detected && detected.rawValue) {
				const country = getGs1CountryPrefix(detected.rawValue);
				setDetectedCode((prev) => {
					if (prev?.rawValue !== detected.rawValue) {
						playScanChime();
						if (typeof navigator !== "undefined" && navigator.vibrate) {
							navigator.vibrate([
								60,
								40,
								60
							]);
						}
						toast.info(`Captured ${detected.format.toUpperCase()}: ${detected.rawValue}${country ? ` (${country})` : ""}`, { duration: 2500 });
						return {
							format: detected.format,
							rawValue: detected.rawValue,
							country
						};
					}
					return prev;
				});
			}
		}).catch(() => {
			// ignore detection frame errors
		}).finally(() => {
			isDetectingRef.current = false;
			scanLoopRef.current = requestAnimationFrame(runDetectionLoop);
		});
	}, []);
	// Start live camera stream
	const startCamera = useCallback(async () => {
		stopCamera();
		try {
			if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
				setPermissionState("unsupported");
				toast.error("Camera API is not supported on this browser/device.");
				return;
			}
			const constraints = {
				video: {
					facingMode: cameraFacing,
					width: {
						ideal: 1920,
						min: 640
					},
					height: {
						ideal: 1080,
						min: 480
					}
				},
				audio: false
			};
			const stream = await navigator.mediaDevices.getUserMedia(constraints);
			streamRef.current = stream;
			setPermissionState("granted");
			if (videoRef.current) {
				videoRef.current.srcObject = stream;
				await videoRef.current.play().catch(() => {});
				setStreamActive(true);
				// Check torch capability
				const track = stream.getVideoTracks()[0];
				if (track && track.getCapabilities) {
					const caps = track.getCapabilities();
					if (caps && "torch" in caps) {
						setHasTorch(true);
					}
				}
				scanLoopRef.current = requestAnimationFrame(runDetectionLoop);
			}
		} catch (err) {
			console.warn("Camera start failed:", err);
			if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
				setPermissionState("denied");
				toast.error("Camera permission denied. Please allow camera access in browser settings.");
			} else if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") {
				setPermissionState("unsupported");
				toast.error("No camera found on this device.");
			} else {
				toast.error(`Unable to open camera: ${err.message || "Unknown error"}`);
			}
		}
	}, [
		cameraFacing,
		stopCamera,
		runDetectionLoop
	]);
	// Toggle torch / flashlight
	const toggleTorch = async () => {
		if (!streamRef.current) return;
		const track = streamRef.current.getVideoTracks()[0];
		if (!track) return;
		try {
			const nextState = !torchOn;
			// @ts-expect-error torch capability
			await track.applyConstraints({ advanced: [{ torch: nextState }] });
			setTorchOn(nextState);
		} catch (err) {
			toast.error("Flashlight could not be toggled on this camera.");
		}
	};
	// Flip camera between front & back
	const flipCamera = () => {
		setCameraFacing((prev) => prev === "environment" ? "user" : "environment");
	};
	// Trigger camera start once granted or on active view
	useEffect(() => {
		if (permissionState === "granted" && !capturedImage) {
			startCamera();
		}
		return () => {
			stopCamera();
		};
	}, [
		permissionState,
		cameraFacing,
		startCamera,
		stopCamera,
		capturedImage
	]);
	// Execute AI scan on payload
	const processImageForAuthenticity = async (base64, mime, previewUrl, fileObj, barcodeData, mode = activeMode) => {
		setScanning(true);
		setCapturedImage(previewUrl);
		setCapturedFile(fileObj);
		stopCamera();
		try {
			setAnalyzingStep("Executing forensic edge & logo geometry inspection...");
			await new Promise((r) => setTimeout(r, 200));
			setAnalyzingStep(mode === "barcode" ? "Validating GS1 barcode checksum & international registry..." : "Analyzing typography, stitching density & micro-embossing...");
			const result = await runAiScan({
				image: base64,
				mimeType: mime,
				barcode: barcodeData || detectedCode?.rawValue || undefined,
				qrData: detectedCode?.format === "qr_code" ? detectedCode.rawValue : undefined,
				inspectionMode: mode,
				mediaType: "image"
			});
			setAnalyzingStep("Verifying corporate brand ownership & counterfeit risk...");
			setScanResult(result);
			// Check if this brand exists in Stash or Trash database
			if (result.brandInfo?.brandName) {
				try {
					const matches = await searchBrands(result.brandInfo.brandName);
					if (matches && matches.length > 0) {
						setMatchedBrand(matches[0]);
					}
				} catch {}
			}
			playScanChime();
			const verdict = result.counterfeitAssessment?.verdict;
			if (verdict === "legit" || verdict === "likely_legit") {
				toast.success(`Authenticity Confirmed: ${result.brandInfo.brandName} is Verified Legit!`);
			} else if (verdict === "suspected_counterfeit" || verdict === "high_risk_fake") {
				toast.error(`Counterfeit Warning: High replica risk detected for ${result.brandInfo.brandName}.`);
			} else {
				toast.info(`Identified: ${result.brandInfo.brandName} (${result.brandInfo.brandOwner})`);
			}
		} catch (err) {
			toast.error(err.message || "Authenticity scan failed");
		} finally {
			setScanning(false);
			setAnalyzingStep("");
		}
	};
	// Capture frame from active camera
	const captureFromCamera = async () => {
		if (!videoRef.current) return;
		const v = videoRef.current;
		const canvas = document.createElement("canvas");
		canvas.width = v.videoWidth || 1280;
		canvas.height = v.videoHeight || 720;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		ctx.drawImage(v, 0, 0, canvas.width, canvas.height);
		const dataUrl = canvas.toDataURL("image/jpeg", .92);
		const base64 = dataUrl.split(",")[1];
		// Detect barcode on snapshot
		const barcodeSnapshot = await detectBarcodeOrQr(canvas);
		const barcodeVal = barcodeSnapshot?.rawValue || detectedCode?.rawValue;
		const blob = await (await fetch(dataUrl)).blob();
		const file = new File([blob], `auth-scan-${Date.now()}.jpg`, { type: "image/jpeg" });
		await processImageForAuthenticity(base64, "image/jpeg", dataUrl, file, barcodeVal, activeMode);
	};
	// Upload photo/video fallback
	const handleFileUpload = async (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const isVideo = file.type.startsWith("video/");
		setScanning(true);
		setAnalyzingStep(isVideo ? "Extracting representative video frame..." : "Optimizing image resolution...");
		try {
			if (isVideo) {
				const { dataUrl, base64, mimeType, qrData, barcodeData } = await extractFrameFromVideo(file);
				await processImageForAuthenticity(base64, mimeType, dataUrl, file, barcodeData || qrData || undefined, activeMode);
			} else {
				const { dataUrl, base64, mimeType, qrData, barcodeData } = await fileToOptimizedBase64(file);
				await processImageForAuthenticity(base64, mimeType, dataUrl, file, barcodeData || qrData || undefined, activeMode);
			}
		} catch (err) {
			toast.error(err.message || "Failed to process media file");
			setScanning(false);
			setAnalyzingStep("");
		}
	};
	// Manual barcode lookup
	const handleManualBarcodeSubmit = async (e) => {
		if (e) e.preventDefault();
		const code = manualBarcode.trim();
		if (!code) {
			toast.error("Please enter a barcode number");
			return;
		}
		const country = getGs1CountryPrefix(code);
		setDetectedCode({
			format: "barcode",
			rawValue: code,
			country
		});
		playScanChime();
		await processImageForAuthenticity("", "image/jpeg", "", null, code, "barcode");
	};
	// Reset scan and return to live camera
	const handleReset = () => {
		setCapturedImage(null);
		setCapturedFile(null);
		setScanResult(null);
		setMatchedBrand(null);
		setDetectedCode(null);
		startCamera();
	};
	// Apply to post
	const handleApplyPost = () => {
		if (!scanResult) return;
		if (onApplyToPost) {
			onApplyToPost({
				brandName: scanResult.brandInfo.brandName,
				brandOwner: scanResult.brandInfo.brandOwner,
				productName: scanResult.brandInfo.productName,
				category: scanResult.brandInfo.category,
				matchedBrandId: matchedBrand?.id,
				file: capturedFile,
				scanResult
			});
		}
		if (onClose) onClose();
	};
	// Copy official authenticity certificate text
	const handleCopyReport = () => {
		if (!scanResult) return;
		const b = scanResult.brandInfo;
		const c = scanResult.counterfeitAssessment;
		const reportText = `[STASH OR TRASH AUTHENTICITY CERTIFICATE]
Product: ${b.productName || b.brandName}
Brand: ${b.brandName}
Corporate Owner: ${b.brandOwner} (${b.countryOfOrigin})
Authenticity Verdict: ${c?.verdict?.toUpperCase() || scanResult.authenticity.verdictStatus}
Legitimacy Score: ${c?.authenticityScore ?? scanResult.authenticity.score}%
Counterfeit Risk: ${c?.counterfeitRiskScore ?? 0}%
Logo Inspection: ${c?.logoInspection || "Verified typography"}
Barcode / Tags: ${b.qrOrBarcodeDecoded || detectedCode?.rawValue || "Standard compliant"}
Verified on Stash Or Trash Brand Barometer`;
		navigator.clipboard.writeText(reportText);
		toast.success("Authenticity audit certificate copied to clipboard!");
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `flex flex-col w-full bg-card rounded-2xl border border-border shadow-2xl overflow-hidden ${standalone ? "max-w-4xl mx-auto" : ""}`,
		"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:528:5",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between px-5 py-4 border-b border-border bg-muted/30",
			"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:530:7",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2.5",
				"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:531:9",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "h-9 w-9 rounded-xl bg-primary/10 text-primary flex items-center justify-center shadow-inner",
					"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:532:11",
					children: /* @__PURE__ */ _jsxDEV(Scan, {
						className: "h-5 w-5",
						"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:533:13"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 533,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 532,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:535:11",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-base sm:text-lg font-bold font-display leading-tight flex items-center gap-2",
						"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:536:13",
						children: [t("scanner.title", { defaultValue: "Authenticity & Anti-Counterfeit Scanner" }), /* @__PURE__ */ _jsxDEV(Badge, {
							variant: "outline",
							className: "text-[10px] font-mono border-primary/30 text-primary bg-primary/5",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:538:15",
							children: "AI Forensic v2.5"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 538,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 536,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-muted-foreground",
						"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:542:13",
						children: t("scanner.subtitle", { defaultValue: "Scan product barcodes, luxury logos, and care tags to verify genuine vs. counterfeit" })
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 542,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 535,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 531,
				columnNumber: 9
			}, this), !scanResult && /* @__PURE__ */ _jsxDEV("div", {
				className: "hidden sm:flex items-center gap-1 bg-background/80 p-1 rounded-xl border border-border text-xs",
				"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:550:11",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveMode("barcode"),
						className: `px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${activeMode === "barcode" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
						"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:551:13",
						children: [
							/* @__PURE__ */ _jsxDEV(QrCode, {
								className: "h-3.5 w-3.5",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:559:15"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 559,
								columnNumber: 15
							}, this),
							" ",
							t("scanner.modeBarcode", { defaultValue: "Barcode & QR" })
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 551,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveMode("logo"),
						className: `px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${activeMode === "logo" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
						"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:561:13",
						children: [
							/* @__PURE__ */ _jsxDEV(Tag, {
								className: "h-3.5 w-3.5",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:569:15"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 569,
								columnNumber: 15
							}, this),
							" ",
							t("scanner.modeLogo", { defaultValue: "Logo & Tag" })
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 561,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveMode("full_product"),
						className: `px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${activeMode === "full_product" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
						"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:571:13",
						children: [
							/* @__PURE__ */ _jsxDEV(Eye, {
								className: "h-3.5 w-3.5",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:579:15"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 579,
								columnNumber: 15
							}, this),
							" ",
							t("scanner.modeFullProduct", { defaultValue: "Full Product" })
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 571,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 550,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 530,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "p-4 sm:p-6 space-y-5",
			"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:586:7",
			children: [
				!scanResult && /* @__PURE__ */ _jsxDEV("div", {
					className: "relative w-full aspect-video sm:aspect-[16/9] max-h-[460px] rounded-2xl overflow-hidden bg-black flex items-center justify-center shadow-inner group",
					"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:589:11",
					children: [
						/* @__PURE__ */ _jsxDEV("video", {
							ref: videoRef,
							autoPlay: true,
							playsInline: true,
							muted: true,
							className: `absolute inset-0 w-full h-full object-cover pointer-events-none transition-opacity duration-300 ${streamActive && !scanning ? "opacity-100" : "opacity-0"}`,
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:591:13"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 591,
							columnNumber: 13
						}, this),
						permissionState === "prompt" && /* @__PURE__ */ _jsxDEV("div", {
							className: "relative z-10 w-full max-w-md mx-auto flex flex-col items-center justify-center text-center p-6 space-y-4",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:603:15",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mx-auto h-16 w-16 rounded-2xl bg-primary/20 text-primary flex items-center justify-center border border-primary/30 shadow-lg",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:604:17",
									children: /* @__PURE__ */ _jsxDEV(Camera, {
										className: "h-8 w-8",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:605:19"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 605,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 604,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1.5 text-center",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:607:17",
									children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "text-lg font-bold text-white tracking-tight",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:608:19",
										children: t("scanner.cameraAccessRequired", { defaultValue: "Camera Access Required" })
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 608,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-white/80 max-w-sm mx-auto leading-relaxed",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:609:19",
										children: t("scanner.cameraAccessDesc", { defaultValue: "Allow camera access to inspect physical packaging, barcodes, luxury logos, and verify if the product is legit or fake." })
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 609,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 607,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-col sm:flex-row gap-2.5 justify-center items-center pt-2 w-full max-w-xs sm:max-w-sm mx-auto",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:613:17",
									children: [/* @__PURE__ */ _jsxDEV(Button, {
										onClick: startCamera,
										className: "w-full sm:w-auto gap-2 font-semibold shadow-md",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:614:19",
										children: [
											/* @__PURE__ */ _jsxDEV(Camera, {
												className: "h-4 w-4",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:615:21"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 615,
												columnNumber: 21
											}, this),
											" ",
											t("scanner.grantPermission", { defaultValue: "Grant Camera Permission" })
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 614,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV(Button, {
										variant: "outline",
										onClick: () => fileInputRef.current?.click(),
										className: "w-full sm:w-auto gap-2 text-white border-white/20 bg-white/10 hover:bg-white/20",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:617:19",
										children: [
											/* @__PURE__ */ _jsxDEV(Upload, {
												className: "h-4 w-4",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:622:21"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 622,
												columnNumber: 21
											}, this),
											" ",
											t("scanner.uploadPhotoInstead", { defaultValue: "Upload Photo Instead" })
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 617,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 613,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 603,
							columnNumber: 15
						}, this),
						permissionState === "denied" && /* @__PURE__ */ _jsxDEV("div", {
							className: "relative z-10 w-full max-w-md mx-auto flex flex-col items-center justify-center text-center p-6 space-y-3",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:630:15",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mx-auto h-14 w-14 rounded-2xl bg-destructive/20 text-destructive flex items-center justify-center border border-destructive/30 shadow-lg",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:631:17",
									children: /* @__PURE__ */ _jsxDEV(ShieldAlert, {
										className: "h-7 w-7",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:632:19"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 632,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 631,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1 text-center",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:634:17",
									children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "text-lg font-bold text-white",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:635:19",
										children: t("scanner.cameraBlocked", { defaultValue: "Camera Permission Was Blocked" })
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 635,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-white/80 max-w-sm mx-auto leading-relaxed",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:636:19",
										children: t("scanner.cameraBlockedDesc", { defaultValue: "Your browser has restricted camera access for this page. Click the camera icon or padlock in your browser's address bar to change permissions to Allow." })
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 636,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 634,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-col sm:flex-row gap-2 justify-center items-center pt-2 w-full max-w-xs sm:max-w-sm mx-auto",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:640:17",
									children: [/* @__PURE__ */ _jsxDEV(Button, {
										onClick: startCamera,
										variant: "secondary",
										className: "w-full sm:w-auto gap-2",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:641:19",
										children: [
											/* @__PURE__ */ _jsxDEV(RefreshCw, {
												className: "h-4 w-4",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:642:21"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 642,
												columnNumber: 21
											}, this),
											" ",
											t("scanner.retryCamera", { defaultValue: "Retry Camera Access" })
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 641,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV(Button, {
										onClick: () => fileInputRef.current?.click(),
										className: "w-full sm:w-auto gap-2",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:644:19",
										children: [
											/* @__PURE__ */ _jsxDEV(Upload, {
												className: "h-4 w-4",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:645:21"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 645,
												columnNumber: 21
											}, this),
											" ",
											t("scanner.uploadFile", { defaultValue: "Choose File to Inspect" })
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 644,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 640,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 630,
							columnNumber: 15
						}, this),
						permissionState === "unsupported" && /* @__PURE__ */ _jsxDEV("div", {
							className: "relative z-10 w-full max-w-md mx-auto flex flex-col items-center justify-center text-center p-6 space-y-3",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:653:15",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mx-auto h-14 w-14 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30 shadow-lg",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:654:17",
									children: /* @__PURE__ */ _jsxDEV(AlertTriangle, {
										className: "h-7 w-7",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:655:19"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 655,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 654,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1 text-center",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:657:17",
									children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "text-lg font-bold text-white",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:658:19",
										children: t("scanner.noWebcam", { defaultValue: "No Webcam Detected" })
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 658,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-white/80 max-w-sm mx-auto leading-relaxed",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:659:19",
										children: t("scanner.noWebcamDesc", { defaultValue: "No hardware camera was detected. You can upload a photo or video recording of the item." })
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 659,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 657,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV(Button, {
									onClick: () => fileInputRef.current?.click(),
									className: "gap-2 w-full max-w-xs mx-auto",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:663:17",
									children: [
										/* @__PURE__ */ _jsxDEV(Upload, {
											className: "h-4 w-4",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:664:19"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 664,
											columnNumber: 19
										}, this),
										" ",
										t("scanner.uploadProductMedia", { defaultValue: "Upload Product Media" })
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 663,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 653,
							columnNumber: 15
						}, this),
						streamActive && !scanning && /* @__PURE__ */ _jsxDEV("div", {
							className: "absolute inset-0 pointer-events-none flex flex-col items-center justify-center",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:671:15",
							children: [
								activeMode === "barcode" && /* @__PURE__ */ _jsxDEV("div", {
									className: "relative w-72 sm:w-96 h-48 border-2 border-emerald-400/80 rounded-2xl shadow-[0_0_20px_rgba(52,211,153,0.3)] flex items-center justify-center overflow-hidden",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:674:19",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute -top-1 -left-1 w-6 h-6 border-t-4 border-l-4 border-emerald-400",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:676:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 676,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute -top-1 -right-1 w-6 h-6 border-t-4 border-r-4 border-emerald-400",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:677:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 677,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute -bottom-1 -left-1 w-6 h-6 border-b-4 border-l-4 border-emerald-400",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:678:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 678,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute -bottom-1 -right-1 w-6 h-6 border-b-4 border-r-4 border-emerald-400",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:679:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 679,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_12px_#34d399] animate-[bounce_2s_infinite]",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:682:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 682,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-[11px] font-semibold font-mono tracking-wider text-emerald-300 bg-black/60 px-3 py-1 rounded-full backdrop-blur-sm border border-emerald-500/30",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:684:21",
											children: "GS1 BARCODE / UPC / QR RETICLE"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 684,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 674,
									columnNumber: 19
								}, this),
								activeMode === "logo" && /* @__PURE__ */ _jsxDEV("div", {
									className: "relative w-56 sm:w-64 h-56 sm:h-64 border-2 border-amber-400/80 rounded-2xl shadow-[0_0_20px_rgba(251,191,36,0.3)] flex items-center justify-center",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:692:19",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute -top-1 -left-1 w-7 h-7 border-t-4 border-l-4 border-amber-400",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:693:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 693,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute -top-1 -right-1 w-7 h-7 border-t-4 border-r-4 border-amber-400",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:694:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 694,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute -bottom-1 -left-1 w-7 h-7 border-b-4 border-l-4 border-amber-400",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:695:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 695,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute -bottom-1 -right-1 w-7 h-7 border-b-4 border-r-4 border-amber-400",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:696:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 696,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "w-8 h-0.5 bg-amber-400/60",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:699:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 699,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "h-8 w-0.5 bg-amber-400/60 absolute",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:700:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 700,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute bottom-3 text-[11px] font-semibold font-mono tracking-wider text-amber-300 bg-black/60 px-3 py-1 rounded-full backdrop-blur-sm border border-amber-500/30",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:702:21",
											children: "LOGO / EMBROIDERY TARGET"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 702,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 692,
									columnNumber: 19
								}, this),
								activeMode === "full_product" && /* @__PURE__ */ _jsxDEV("div", {
									className: "relative w-4/5 sm:w-3/4 h-3/4 border-2 border-dashed border-primary/70 rounded-3xl flex items-center justify-center",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:710:19",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "absolute top-4 text-[11px] font-semibold font-mono tracking-wider text-primary bg-black/60 px-3 py-1 rounded-full backdrop-blur-sm border border-primary/30",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:711:21",
										children: "FULL PRODUCT / SEAMS & MATERIALS"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 711,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 710,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "absolute bottom-4 bg-black/75 backdrop-blur-md px-4 py-1.5 rounded-full border border-white/10 text-xs text-white/90 font-medium shadow-lg flex items-center gap-2",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:718:17",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "h-2 w-2 rounded-full bg-emerald-400 animate-ping",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:719:19"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 719,
											columnNumber: 19
										}, this),
										activeMode === "barcode" && "Point at UPC-A, EAN-13, or QR code on retail box / tag",
										activeMode === "logo" && "Center the brand logo, metal badge, or neck tag",
										activeMode === "full_product" && "Fit the entire garment, sneaker, bottle or accessory"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 718,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 671,
							columnNumber: 15
						}, this),
						detectedCode && streamActive && !scanning && /* @__PURE__ */ _jsxDEV("div", {
							className: "absolute top-4 inset-x-4 flex items-center justify-between bg-emerald-950/90 border border-emerald-500/50 backdrop-blur-md px-4 py-2 rounded-xl text-white shadow-xl z-20 animate-in fade-in",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:729:15",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2.5",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:730:17",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "h-7 w-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:731:19",
									children: /* @__PURE__ */ _jsxDEV(CheckCircle2, {
										className: "h-4 w-4",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:732:21"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 732,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 731,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:734:19",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "text-xs font-bold font-mono tracking-wide",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:735:21",
										children: [
											detectedCode.format.toUpperCase(),
											": ",
											detectedCode.rawValue
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 735,
										columnNumber: 21
									}, this), detectedCode.country && /* @__PURE__ */ _jsxDEV("div", {
										className: "text-[10px] text-emerald-300",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:739:23",
										children: ["GS1 Origin: ", detectedCode.country]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 739,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 734,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 730,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV(Button, {
								size: "sm",
								onClick: captureFromCamera,
								className: "bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs h-8 px-3",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:746:17",
								children: ["Verify Now ", /* @__PURE__ */ _jsxDEV(ArrowRight, {
									className: "h-3 w-3 ml-1",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:751:30"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 751,
									columnNumber: 30
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 746,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 729,
							columnNumber: 15
						}, this),
						streamActive && !scanning && /* @__PURE__ */ _jsxDEV("div", {
							className: "absolute top-4 right-4 flex items-center gap-2 z-20",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:758:15",
							children: [hasTorch && /* @__PURE__ */ _jsxDEV(Button, {
								size: "icon",
								variant: "secondary",
								onClick: toggleTorch,
								className: `h-9 w-9 rounded-xl backdrop-blur-md ${torchOn ? "bg-amber-400 text-black hover:bg-amber-300" : "bg-black/60 text-white hover:bg-black/80"}`,
								title: torchOn ? "Turn flashlight off" : "Turn flashlight on",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:760:19",
								children: torchOn ? /* @__PURE__ */ _jsxDEV(Zap, {
									className: "h-4 w-4 fill-current",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:769:32"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 769,
									columnNumber: 32
								}, this) : /* @__PURE__ */ _jsxDEV(ZapOff, {
									className: "h-4 w-4",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:769:75"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 769,
									columnNumber: 153
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 760,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV(Button, {
								size: "icon",
								variant: "secondary",
								onClick: flipCamera,
								className: "h-9 w-9 rounded-xl bg-black/60 text-white hover:bg-black/80 backdrop-blur-md",
								title: "Switch Front/Rear Camera",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:773:17",
								children: /* @__PURE__ */ _jsxDEV(RefreshCw, {
									className: "h-4 w-4",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:780:19"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 780,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 773,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 758,
							columnNumber: 15
						}, this),
						scanning && /* @__PURE__ */ _jsxDEV("div", {
							className: "absolute inset-0 bg-black/85 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-30 space-y-4",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:787:15",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "relative flex items-center justify-center",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:788:17",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "h-20 w-20 rounded-full border-4 border-primary/20 border-t-primary animate-spin",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:789:19"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 789,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV(Sparkles, {
										className: "h-8 w-8 text-primary absolute animate-pulse",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:790:19"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 790,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 788,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1.5 max-w-sm",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:792:17",
									children: [/* @__PURE__ */ _jsxDEV("h4", {
										className: "text-base font-bold text-white font-display",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:793:19",
										children: "Multimodal Forensic Inspection"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 793,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-white/70 min-h-6",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:796:19",
										children: analyzingStep || "Examining pixels, typography & corporate lineage..."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 796,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 792,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV(Progress, {
									value: 65,
									className: "w-48 h-1.5 bg-white/10",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:800:17"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 800,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 787,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 589,
					columnNumber: 11
				}, this),
				!scanResult && streamActive && !scanning && /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col sm:flex-row items-center justify-between gap-4 pt-1",
					"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:808:11",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:809:13",
							children: [
								/* @__PURE__ */ _jsxDEV(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => fileInputRef.current?.click(),
									className: "gap-2 text-xs",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:810:15",
									children: [
										/* @__PURE__ */ _jsxDEV(Upload, {
											className: "h-3.5 w-3.5",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:816:17"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 816,
											columnNumber: 17
										}, this),
										" ",
										t("scanner.uploadFile", { defaultValue: "Upload File" })
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 810,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Button, {
									variant: "ghost",
									size: "sm",
									onClick: () => setShowManualBarcode(!showManualBarcode),
									className: "gap-1.5 text-xs text-muted-foreground hover:text-foreground",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:818:15",
									children: [
										/* @__PURE__ */ _jsxDEV(Tag, {
											className: "h-3.5 w-3.5",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:824:17"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 824,
											columnNumber: 17
										}, this),
										" ",
										t("scanner.enterBarcode", { defaultValue: "Enter Barcode" })
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 818,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									ref: fileInputRef,
									type: "file",
									accept: "image/*,video/*",
									onChange: handleFileUpload,
									className: "hidden",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:826:15"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 826,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 809,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:836:13",
							children: /* @__PURE__ */ _jsxDEV(Button, {
								size: "lg",
								onClick: captureFromCamera,
								className: "gap-2.5 px-8 font-bold text-sm bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/25 rounded-xl h-12",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:837:15",
								children: [
									/* @__PURE__ */ _jsxDEV(Camera, {
										className: "h-5 w-5",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:842:17"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 842,
										columnNumber: 17
									}, this),
									" ",
									t("scanner.inspectAuthenticity", { defaultValue: "Inspect Authenticity" })
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 837,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 836,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "text-xs text-muted-foreground text-center sm:text-right",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:846:13",
							children: activeMode === "barcode" ? `Mode: ${t("scanner.modeBarcode", { defaultValue: "Barcode Checksum" })}` : activeMode === "logo" ? `Mode: ${t("scanner.modeLogo", { defaultValue: "Luxury Logo Geometry" })}` : `Mode: ${t("scanner.modeFullProduct", { defaultValue: "Full Garment & Package Analysis" })}`
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 846,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 808,
					columnNumber: 11
				}, this),
				!scanResult && !scanning && (showManualBarcode || permissionState === "unsupported" || permissionState === "denied") && /* @__PURE__ */ _jsxDEV("form", {
					onSubmit: handleManualBarcodeSubmit,
					className: "p-3 bg-muted/40 rounded-xl border border-border flex flex-col gap-2 animate-in fade-in",
					"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:858:11",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row items-center gap-2 w-full",
						"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:862:13",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "relative flex-1 w-full",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:863:15",
							children: [/* @__PURE__ */ _jsxDEV(Tag, {
								className: "h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:864:17"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 864,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								placeholder: "Enter UPC-A, EAN-13, or serial (e.g. 6001087000140 for Coca-Cola 2L)...",
								value: manualBarcode,
								onChange: (e) => setManualBarcode(e.target.value),
								className: "w-full bg-background border border-border rounded-lg pl-9 pr-3 py-1.5 text-xs placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:865:17"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 865,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 863,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 w-full sm:w-auto",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:873:15",
							children: /* @__PURE__ */ _jsxDEV(Button, {
								type: "submit",
								size: "sm",
								disabled: !manualBarcode.trim(),
								className: "w-full sm:w-auto text-xs h-8 px-4 font-semibold",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:874:17",
								children: t("scanner.verifyBarcode", { defaultValue: "Verify Barcode" })
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 874,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 873,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 862,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "w-full flex items-center gap-1.5 flex-wrap pt-1 text-[11px] text-muted-foreground",
						"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:886:13",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-foreground/80",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:887:15",
								children: "Quick test:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 887,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									setManualBarcode("6001087000140");
									processImageForAuthenticity("", "image/jpeg", "", null, "6001087000140", "barcode");
								},
								className: "px-2 py-0.5 rounded bg-background hover:bg-muted border border-border text-foreground transition-colors font-mono text-[10px]",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:888:15",
								children: "Coca-Cola 2L (SA: 6001087000140)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 888,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									setManualBarcode("5449000000996");
									processImageForAuthenticity("", "image/jpeg", "", null, "5449000000996", "barcode");
								},
								className: "px-2 py-0.5 rounded bg-background hover:bg-muted border border-border text-foreground transition-colors font-mono text-[10px]",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:898:15",
								children: "Coca-Cola 2L (Global: 5449000000996)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 898,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									setManualBarcode("049000050103");
									processImageForAuthenticity("", "image/jpeg", "", null, "049000050103", "barcode");
								},
								className: "px-2 py-0.5 rounded bg-background hover:bg-muted border border-border text-foreground transition-colors font-mono text-[10px]",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:908:15",
								children: "Coca-Cola 2L (US: 049000050103)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 908,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									setManualBarcode("6001087000034");
									processImageForAuthenticity("", "image/jpeg", "", null, "6001087000034", "barcode");
								},
								className: "px-2 py-0.5 rounded bg-background hover:bg-muted border border-border text-foreground transition-colors font-mono text-[10px]",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:918:15",
								children: "Sprite 2L (SA: 6001087000034)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 918,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 886,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 858,
					columnNumber: 11
				}, this),
				scanResult && /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300",
					"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:936:11",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: `p-6 rounded-2xl border ${scanResult.counterfeitAssessment?.verdict === "legit" || scanResult.counterfeitAssessment?.verdict === "likely_legit" ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-950 dark:text-emerald-100" : scanResult.counterfeitAssessment?.verdict === "suspected_counterfeit" || scanResult.counterfeitAssessment?.verdict === "high_risk_fake" ? "bg-rose-500/10 border-rose-500/30 text-rose-950 dark:text-rose-100" : "bg-amber-500/10 border-amber-500/30 text-amber-950 dark:text-amber-100"}`,
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:938:13",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:949:15",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-start gap-4",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:950:17",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: `h-14 w-14 rounded-2xl flex items-center justify-center shadow-md shrink-0 ${scanResult.counterfeitAssessment?.verdict === "legit" || scanResult.counterfeitAssessment?.verdict === "likely_legit" ? "bg-emerald-500 text-white" : scanResult.counterfeitAssessment?.verdict === "suspected_counterfeit" || scanResult.counterfeitAssessment?.verdict === "high_risk_fake" ? "bg-rose-500 text-white" : "bg-amber-500 text-white"}`,
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:951:19",
										children: scanResult.counterfeitAssessment?.verdict === "legit" || scanResult.counterfeitAssessment?.verdict === "likely_legit" ? /* @__PURE__ */ _jsxDEV(ShieldCheck, {
											className: "h-8 w-8",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:964:23"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 964,
											columnNumber: 23
										}, this) : /* @__PURE__ */ _jsxDEV(ShieldAlert, {
											className: "h-8 w-8",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:966:23"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 966,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 951,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:970:19",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2 flex-wrap",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:971:21",
												children: [/* @__PURE__ */ _jsxDEV(Badge, {
													className: `font-bold uppercase tracking-wider text-xs px-2.5 py-0.5 ${scanResult.counterfeitAssessment?.verdict === "legit" || scanResult.counterfeitAssessment?.verdict === "likely_legit" ? "bg-emerald-600 text-white hover:bg-emerald-600" : scanResult.counterfeitAssessment?.verdict === "suspected_counterfeit" || scanResult.counterfeitAssessment?.verdict === "high_risk_fake" ? "bg-rose-600 text-white hover:bg-rose-600" : "bg-amber-600 text-white hover:bg-amber-600"}`,
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:972:23",
													children: scanResult.counterfeitAssessment?.badgeLabel || scanResult.counterfeitAssessment?.verdict?.replace("_", " ") || scanResult.authenticity.badgeLabel
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 972,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs opacity-75 font-mono",
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:987:23",
													children: ["Confidence: ", scanResult.counterfeitAssessment?.confidence?.toUpperCase() || "HIGH"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 987,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 971,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("h3", {
												className: "text-xl sm:text-2xl font-black font-display tracking-tight",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:992:21",
												children: [
													scanResult.brandInfo.brandName,
													" ",
													/* @__PURE__ */ _jsxDEV("span", {
														className: "text-sm sm:text-base font-normal opacity-85",
														"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:994:23",
														children: scanResult.brandInfo.productName || ""
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 994,
														columnNumber: 23
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 992,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2 text-xs opacity-90",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:999:21",
												children: [/* @__PURE__ */ _jsxDEV(Building2, {
													className: "h-3.5 w-3.5",
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1000:23"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1e3,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1001:23",
													children: [
														"Corporate Parent: ",
														/* @__PURE__ */ _jsxDEV("strong", {
															"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1002:43",
															children: scanResult.brandInfo.brandOwner
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1002,
															columnNumber: 43
														}, this),
														" (",
														scanResult.brandInfo.countryOfOrigin,
														")"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1001,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 999,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 970,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 950,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex sm:flex-col items-center sm:items-end justify-between sm:justify-center border-t sm:border-t-0 pt-3 sm:pt-0 border-border/20 gap-1 min-w-[140px]",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1010:17",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "text-left sm:text-right",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1011:19",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] uppercase font-mono tracking-wider opacity-75",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1012:21",
											children: "Legitimacy Score"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1012,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-2xl sm:text-3xl font-black font-display",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1015:21",
											children: [scanResult.counterfeitAssessment?.authenticityScore ?? scanResult.authenticity.score, "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1015,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1011,
										columnNumber: 19
									}, this), scanResult.counterfeitAssessment?.counterfeitRiskScore !== undefined && /* @__PURE__ */ _jsxDEV("div", {
										className: "text-xs font-medium opacity-85",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1020:21",
										children: [
											"Replica Risk: ",
											scanResult.counterfeitAssessment.counterfeitRiskScore,
											"%"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1020,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1010,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 949,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 938,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex border-b border-border overflow-x-auto",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1029:13",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setResultTab("authenticity"),
									className: `px-4 py-2.5 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${resultTab === "authenticity" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`,
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1030:15",
									children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, {
										className: "h-4 w-4",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1038:17"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1038,
										columnNumber: 17
									}, this), " Anti-Counterfeit Audit"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1030,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setResultTab("guide"),
									className: `px-4 py-2.5 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${resultTab === "guide" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`,
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1040:15",
									children: [/* @__PURE__ */ _jsxDEV(HelpCircle, {
										className: "h-4 w-4",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1048:17"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1048,
										columnNumber: 17
									}, this), " Client Verification Guide"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1040,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setResultTab("brand"),
									className: `px-4 py-2.5 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${resultTab === "brand" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`,
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1050:15",
									children: [/* @__PURE__ */ _jsxDEV(Building2, {
										className: "h-4 w-4",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1058:17"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1058,
										columnNumber: 17
									}, this), " Brand Lineage & Protection"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1050,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setResultTab("forensics"),
									className: `px-4 py-2.5 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${resultTab === "forensics" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`,
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1060:15",
									children: [/* @__PURE__ */ _jsxDEV(Sparkles, {
										className: "h-4 w-4",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1068:17"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1068,
										columnNumber: 17
									}, this), " Media Forensics & Tamper Check"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1060,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setResultTab("pr_dossier"),
									className: `px-4 py-2.5 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${resultTab === "pr_dossier" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`,
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1070:15",
									children: [/* @__PURE__ */ _jsxDEV(Printer, {
										className: "h-4 w-4",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1078:17"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1078,
										columnNumber: 17
									}, this), " Brand PR & Client Dossier"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1070,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1029,
							columnNumber: 13
						}, this),
						resultTab === "authenticity" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1084:15",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 md:grid-cols-3 gap-3",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1085:17",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-4 rounded-xl border border-border bg-card/60 space-y-1.5",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1087:19",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs font-bold flex items-center gap-1.5 text-foreground",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1088:21",
												children: [/* @__PURE__ */ _jsxDEV(Tag, {
													className: "h-3.5 w-3.5 text-primary",
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1089:23"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1089,
													columnNumber: 23
												}, this), " Logo & Typography Check"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1088,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-muted-foreground leading-relaxed",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1091:21",
												children: scanResult.counterfeitAssessment?.logoInspection || "Typography kerning, debossing depth, and font geometric alignment verified."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1091,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1087,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-4 rounded-xl border border-border bg-card/60 space-y-1.5",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1098:19",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs font-bold flex items-center gap-1.5 text-foreground",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1099:21",
												children: [/* @__PURE__ */ _jsxDEV(QrCode, {
													className: "h-3.5 w-3.5 text-primary",
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1100:23"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1100,
													columnNumber: 23
												}, this), " Barcode & GS1 Registry"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1099,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-muted-foreground leading-relaxed",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1102:21",
												children: scanResult.counterfeitAssessment?.barcodeAndTagsInspection || scanResult.brandInfo.qrOrBarcodeDecoded || "Standard GS1 GTIN/UPC formatting verified against international brand registries."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1102,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1098,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-4 rounded-xl border border-border bg-card/60 space-y-1.5",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1110:19",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs font-bold flex items-center gap-1.5 text-foreground",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1111:21",
												children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, {
													className: "h-3.5 w-3.5 text-primary",
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1112:23"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1112,
													columnNumber: 23
												}, this), " Craftsmanship & Hardware"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1111,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-muted-foreground leading-relaxed",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1114:21",
												children: scanResult.counterfeitAssessment?.materialAndCraftsmanship || "Consistent stitch density, metallic hardware engravings, and material grain inspected."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1114,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1110,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1085,
									columnNumber: 17
								}, this),
								scanResult.counterfeitAssessment?.keyDifferencesToLookFor && scanResult.counterfeitAssessment.keyDifferencesToLookFor.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 rounded-xl border border-border bg-muted/20 space-y-2",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1124:21",
									children: [/* @__PURE__ */ _jsxDEV("h4", {
										className: "text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1125:23",
										children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, {
											className: "h-3.5 w-3.5 text-amber-500",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1126:25"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1126,
											columnNumber: 25
										}, this), " Key Authentic vs. Replica Indicators"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1125,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("ul", {
										className: "space-y-1 text-xs text-foreground/90",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1129:23",
										children: scanResult.counterfeitAssessment.keyDifferencesToLookFor.map((item, idx) => /* @__PURE__ */ _jsxDEV("li", {
											className: "flex items-start gap-2",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1131:27",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-primary font-bold",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1132:29",
												children: "•"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1132,
												columnNumber: 29
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1133:29",
												children: item
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1133,
												columnNumber: 29
											}, this)]
										}, idx, true, {
											fileName: _jsxFileName,
											lineNumber: 1131,
											columnNumber: 27
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1129,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1124,
									columnNumber: 21
								}, this),
								capturedImage && /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-3 p-3 rounded-xl border border-border bg-muted/10 text-xs",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1142:19",
									children: [/* @__PURE__ */ _jsxDEV("img", {
										src: capturedImage,
										alt: "Captured verification source",
										className: "h-14 w-14 rounded-lg object-cover border border-border",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1143:21"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1143,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-0.5",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1148:21",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "font-semibold",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1149:23",
											children: "Analyzed Visual Evidence"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1149,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-muted-foreground",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1150:23",
											children: [
												"Forensic pixel integrity score: ",
												scanResult.authenticity.score,
												"% • Status:",
												" ",
												scanResult.authenticity.verdictStatus
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1150,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1148,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1142,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1084,
							columnNumber: 15
						}, this),
						resultTab === "guide" && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-5 rounded-2xl border border-border bg-card space-y-4",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1162:15",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1163:17",
								children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "text-sm font-bold flex items-center gap-2",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1164:19",
									children: [/* @__PURE__ */ _jsxDEV(HelpCircle, {
										className: "h-4 w-4 text-primary",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1165:21"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1165,
										columnNumber: 21
									}, this), " How Clients & Buyers Can Verify This Product"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1164,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-muted-foreground",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1168:19",
									children: [
										"Actionable instructions tailored to ",
										scanResult.brandInfo.brandName,
										" to confirm genuine ownership and protect against counterfeit market circulation."
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1168,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1163,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2.5",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1174:17",
								children: scanResult.counterfeitAssessment?.clientVerificationGuide?.map((guideStep, idx) => /* @__PURE__ */ _jsxDEV("div", {
									className: "p-3.5 rounded-xl border border-border/80 bg-muted/20 flex items-start gap-3 text-xs",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1176:21",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "h-6 w-6 rounded-full bg-primary/10 text-primary font-bold flex items-center justify-center shrink-0 text-[11px]",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1180:23",
										children: idx + 1
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1180,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "leading-relaxed text-foreground pt-0.5",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1183:23",
										children: guideStep
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1183,
										columnNumber: 23
									}, this)]
								}, idx, true, {
									fileName: _jsxFileName,
									lineNumber: 1176,
									columnNumber: 21
								}, this)) || /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-muted-foreground",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1186:21",
									children: "Always check the serial number on the brand's official customer portal, verify receipt of purchase from authorized stockists, and look for internal micro-embossed security tags."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1186,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1174,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1162,
							columnNumber: 15
						}, this),
						resultTab === "brand" && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-5 rounded-2xl border border-border bg-card space-y-4",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1197:15",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1.5",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1198:17",
									children: [/* @__PURE__ */ _jsxDEV("h4", {
										className: "text-sm font-bold flex items-center gap-2",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1199:19",
										children: [/* @__PURE__ */ _jsxDEV(Building2, {
											className: "h-4 w-4 text-primary",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1200:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1200,
											columnNumber: 21
										}, this), " Corporate Ownership & Distribution"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1199,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-muted-foreground",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1202:19",
										children: scanResult.brandInfo.parentCompanyContext || `${scanResult.brandInfo.brandName} is operated and owned by ${scanResult.brandInfo.brandOwner}.`
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1202,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1198,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1208:17",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 rounded-xl border border-border bg-muted/20 space-y-1",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1209:19",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-muted-foreground",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1210:21",
											children: "Brand Category & Tier:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1210,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "font-semibold",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1211:21",
											children: [
												scanResult.brandInfo.category,
												" • ",
												scanResult.brandInfo.marketTier
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1211,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1209,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 rounded-xl border border-border bg-muted/20 space-y-1",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1215:19",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-muted-foreground",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1216:21",
											children: "Authorized Channels:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1216,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "font-semibold",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1217:21",
											children: scanResult.counterfeitAssessment?.brandProtectionTracking?.authorizedChannels || "Official Brand Stores & Certified Retailers"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1217,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1215,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1208,
									columnNumber: 17
								}, this),
								matchedBrand && /* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 rounded-xl border border-primary/20 bg-primary/5 flex items-center justify-between text-xs",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1225:19",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1226:21",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "font-bold text-foreground",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1227:23",
											children: [matchedBrand.name, " in Stash Or Trash"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1227,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-muted-foreground",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1230:23",
											children: [
												"Overall Trust Score: ",
												matchedBrand.trust_score,
												"/100 • Verdict: ",
												matchedBrand.trust_score >= 60 ? "Stash" : "Trash"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1230,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1226,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV(Button, {
										variant: "outline",
										size: "sm",
										onClick: () => window.location.href = `/brands/${matchedBrand.slug}`,
										className: "gap-1 text-xs",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1234:21",
										children: ["View Brand Page ", /* @__PURE__ */ _jsxDEV(ExternalLink, {
											className: "h-3 w-3",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1240:39"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1240,
											columnNumber: 39
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1234,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1225,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1197,
							columnNumber: 15
						}, this),
						resultTab === "forensics" && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-5 rounded-2xl border border-border bg-card space-y-4 animate-in fade-in",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1249:15",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1250:17",
									children: [/* @__PURE__ */ _jsxDEV("h4", {
										className: "text-sm font-bold flex items-center gap-2",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1251:19",
										children: [/* @__PURE__ */ _jsxDEV(Sparkles, {
											className: "h-4 w-4 text-primary",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1252:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1252,
											columnNumber: 21
										}, this), " Visual Media Integrity & Deepfake Shield"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1251,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-muted-foreground",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1254:19",
										children: "Pixel-level forensic audit of the uploaded media to verify genuine camera optics versus AI synthesis, digital splicing, or Photoshop alteration."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1254,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1250,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1259:17",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-3.5 rounded-xl border border-border bg-muted/20 space-y-1",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1260:19",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "font-bold text-foreground flex items-center gap-1.5",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1261:21",
												children: [/* @__PURE__ */ _jsxDEV(Zap, {
													className: "h-3.5 w-3.5 text-primary",
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1262:23"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1262,
													columnNumber: 23
												}, this), " Lighting Vectors & Specular Consistency"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1261,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-muted-foreground leading-relaxed",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1264:21",
												children: scanResult.authenticity.forensics.physicalLighting || "Natural shadow falloff and specular highlights consistent with real physical camera capture."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1264,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1260,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-3.5 rounded-xl border border-border bg-muted/20 space-y-1",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1270:19",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "font-bold text-foreground flex items-center gap-1.5",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1271:21",
												children: [/* @__PURE__ */ _jsxDEV(Sparkles, {
													className: "h-3.5 w-3.5 text-primary",
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1272:23"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1272,
													columnNumber: 23
												}, this), " Sensor Noise & Compression Artifacts"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1271,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-muted-foreground leading-relaxed",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1274:21",
												children: scanResult.authenticity.forensics.textureAndNoise || "Organic CMOS Bayer sensor noise detected; zero generative diffusion or neural upscaling marks."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1274,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1270,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-3.5 rounded-xl border border-border bg-muted/20 space-y-1",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1280:19",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "font-bold text-foreground flex items-center gap-1.5",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1281:21",
												children: [/* @__PURE__ */ _jsxDEV(Tag, {
													className: "h-3.5 w-3.5 text-primary",
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1282:23"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1282,
													columnNumber: 23
												}, this), " Micro-Typography & Edge Integrity"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1281,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-muted-foreground leading-relaxed",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1284:21",
												children: scanResult.authenticity.forensics.textIntegrity || "Printed text adheres to vector standards without hallucinated or distorted glyphs."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1284,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1280,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-3.5 rounded-xl border border-border bg-muted/20 space-y-1",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1290:19",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "font-bold text-foreground flex items-center gap-1.5",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1291:21",
												children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, {
													className: "h-3.5 w-3.5 text-emerald-500",
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1292:23"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1292,
													columnNumber: 23
												}, this), " AI Generation (GAN/Diffusion) Check"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1291,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-muted-foreground leading-relaxed",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1294:21",
												children: scanResult.authenticity.forensics.aiGenerationMarkers || "No Midjourney, Stable Diffusion, DALL-E, or Sora generative signatures found."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1294,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1290,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1259,
									columnNumber: 17
								}, this),
								scanResult.authenticity.reasons && scanResult.authenticity.reasons.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
									className: "p-3.5 rounded-xl border border-border/80 bg-background space-y-1.5 text-xs",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1302:19",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "font-bold text-foreground",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1303:21",
										children: "Forensic Confirmation Factors:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1303,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("ul", {
										className: "space-y-1 text-muted-foreground",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1304:21",
										children: scanResult.authenticity.reasons.map((r, i) => /* @__PURE__ */ _jsxDEV("li", {
											className: "flex items-start gap-1.5",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1306:25",
											children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, {
												className: "h-3.5 w-3.5 text-emerald-500 shrink-0 mt-0.5",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1307:27"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1307,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1308:27",
												children: r
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1308,
												columnNumber: 27
											}, this)]
										}, i, true, {
											fileName: _jsxFileName,
											lineNumber: 1306,
											columnNumber: 25
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1304,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1302,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1249,
							columnNumber: 15
						}, this),
						resultTab === "pr_dossier" && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-5 rounded-2xl border border-border bg-card space-y-4 animate-in fade-in",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1319:15",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1320:17",
								children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "text-sm font-bold flex items-center gap-2",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1321:19",
									children: [/* @__PURE__ */ _jsxDEV(Printer, {
										className: "h-4 w-4 text-primary",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1322:21"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1322,
										columnNumber: 21
									}, this), " Official Brand PR & Client Verification Dossier"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1321,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-muted-foreground",
									"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1324:19",
									children: "Ready-to-share audit documentation for Brand Public Relations Officers, Client Verification teams, and Legal Brand Protection."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1324,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1320,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "p-4 rounded-xl border border-primary/30 bg-primary/5 space-y-3 text-xs",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1329:17",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-primary/20 pb-3",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1330:19",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1331:21",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "text-sm font-black font-display text-foreground",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1332:23",
												children: [scanResult.brandInfo.brandName, " • Official Audit Dossier"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1332,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "text-muted-foreground",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1335:23",
												children: [
													"Parent Company: ",
													scanResult.brandInfo.brandOwner,
													" (",
													scanResult.brandInfo.countryOfOrigin,
													")"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1335,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1331,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV(Button, {
											size: "sm",
											onClick: handlePrintCertificate,
											className: "gap-1.5 text-xs bg-primary text-primary-foreground font-semibold",
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1339:21",
											children: [/* @__PURE__ */ _jsxDEV(Printer, {
												className: "h-3.5 w-3.5",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1344:23"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1344,
												columnNumber: 23
											}, this), " Print / Export Audit PDF"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1339,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1330,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1348:19",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "p-2.5 rounded-lg bg-background border border-border",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1349:21",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1350:23",
													children: "Authenticity Verdict"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1350,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "font-bold text-foreground text-sm",
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1351:23",
													children: scanResult.counterfeitAssessment?.badgeLabel || "Verified Authentic"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1351,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1349,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "p-2.5 rounded-lg bg-background border border-border",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1355:21",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1356:23",
													children: "Legitimacy Score"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1356,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "font-bold text-emerald-600 text-sm",
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1357:23",
													children: [scanResult.counterfeitAssessment?.authenticityScore ?? scanResult.authenticity.score, "%"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1357,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1355,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "p-2.5 rounded-lg bg-background border border-border",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1361:21",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "text-[10px] text-muted-foreground uppercase font-mono",
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1362:23",
													children: "Media Forensic Integrity"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1362,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "font-bold text-primary text-sm",
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1363:23",
													children: [scanResult.authenticity.score, "% Verified"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1363,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1361,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1348,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1 text-muted-foreground pt-1",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1369:19",
										children: [/* @__PURE__ */ _jsxDEV("p", {
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1370:21",
											children: [
												/* @__PURE__ */ _jsxDEV("strong", {
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1371:23",
													children: "Authorized Channels:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1371,
													columnNumber: 23
												}, this),
												" ",
												scanResult.counterfeitAssessment?.brandProtectionTracking?.authorizedChannels || "Authorized retailers and certified distribution networks."
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1370,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1375:21",
											children: [
												/* @__PURE__ */ _jsxDEV("strong", {
													"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1376:23",
													children: "Brand PR Advisory:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1376,
													columnNumber: 23
												}, this),
												" ",
												scanResult.counterfeitAssessment?.brandProtectionTracking?.advice || `Client verification confirmed in favor of ${scanResult.brandInfo.brandOwner}.`
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1375,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1369,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1329,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1319,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-border",
							"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1386:13",
							children: [/* @__PURE__ */ _jsxDEV(Button, {
								variant: "outline",
								onClick: handleReset,
								className: "w-full sm:w-auto gap-2 text-xs",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1387:15",
								children: [
									/* @__PURE__ */ _jsxDEV(RefreshCw, {
										className: "h-3.5 w-3.5",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1388:17"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1388,
										columnNumber: 17
									}, this),
									" ",
									t("scanner.scanAnother", { defaultValue: "Scan Another Product" })
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1387,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 w-full sm:w-auto flex-wrap",
								"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1391:15",
								children: [
									/* @__PURE__ */ _jsxDEV(Button, {
										variant: "outline",
										onClick: handlePrintCertificate,
										className: "flex-1 sm:flex-none gap-2 text-xs font-medium",
										title: t("scanner.printCertTitle", { defaultValue: "Print Brand PR & Client Verification Certificate" }),
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1392:17",
										children: [
											/* @__PURE__ */ _jsxDEV(Printer, {
												className: "h-3.5 w-3.5 text-primary",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1398:19"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1398,
												columnNumber: 19
											}, this),
											" ",
											t("scanner.printCert", { defaultValue: "Print PR Audit Certificate" })
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1392,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV(Button, {
										variant: "outline",
										onClick: handleCopyReport,
										className: "flex-1 sm:flex-none gap-2 text-xs",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1400:17",
										children: [
											/* @__PURE__ */ _jsxDEV(Copy, {
												className: "h-3.5 w-3.5",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1405:19"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1405,
												columnNumber: 19
											}, this),
											" ",
											t("scanner.copyCert", { defaultValue: "Copy Certificate" })
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1400,
										columnNumber: 17
									}, this),
									onApplyToPost && /* @__PURE__ */ _jsxDEV(Button, {
										onClick: handleApplyPost,
										className: "flex-1 sm:flex-none gap-2 text-xs font-semibold shadow-md",
										"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1408:19",
										children: [
											/* @__PURE__ */ _jsxDEV(FileCheck, {
												className: "h-3.5 w-3.5",
												"data-tsd-source": "/src/components/ProductAuthenticityCameraScanner.tsx:1412:21"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1412,
												columnNumber: 21
											}, this),
											" ",
											t("scanner.postToBarometer", { defaultValue: "Post to Brand Barometer" })
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1408,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1391,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1386,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 936,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 586,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 528,
		columnNumber: 5
	}, this);
}
_s(ProductAuthenticityCameraScanner, "88W/+o0dXVesNTIkg6rz/4/EUDc=", false, function() {
	return [useTranslation];
});
_c = ProductAuthenticityCameraScanner;
var _c;
$RefreshReg$(_c, "ProductAuthenticityCameraScanner");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ProductAuthenticityCameraScanner.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/ProductAuthenticityCameraScanner.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/ProductAuthenticityCameraScanner.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/ProductAuthenticityCameraScanner.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQ0EsUUFDQSxNQUNBLFFBQ0EsYUFDQSxhQUNBLGVBQ0EsV0FDQSxVQUNBLFFBQ0EsV0FDQSxjQUNBLFlBQ0EsS0FDQSxRQUNBLEtBQ0EsTUFDQSxLQUNBLFlBRUEsY0FFQSxXQUVBLGVBQ0E7QUFDQSxTQUNBLG1CQUNBLHFCQUNBLGVBQ0EsdUJBQ0EsdUJBQ0EsaUJBRUE7QUFDQTtBQUNBOzs7O0FBa0JBLG1EQUNBLGVBQ0EsU0FDQSxzQkFDQTs7Q0FDQTs7Q0FFQSx1REFFQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7O0NBR0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxpREFJQTtDQUNBO0NBQ0E7O0NBR0E7Q0FDQTtDQUNBOztDQUdBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FFQTtFQUNBO0VBQ0E7RUFDQTtHQUNBO0dBQ0E7RUFDQTtFQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OytCQXNCQTs7OztzREFJQTtrR0FDQTs7Ozs7aUNBS0E7b0ZBQ0E7Ozs7eURBSUE7Z0ZBQ0E7Ozs7Ozt1REFNQTtvREFDQTt1REFDQTt3REFDQTs7Ozt1SEFJQTs7Ozs7Ozs7RUFRQTtFQUNBO0NBQ0E7O0NBR0E7RUFDQTtHQUNBLHNCQUNBLDBCQUNBO0lBQ0E7S0FDQTtJQUNBO0tBQ0E7SUFDQTtLQUNBO0lBQ0E7SUFFQTtLQUNBO1VBQ0E7VUFDQTtJQUNBO0dBQ0EsR0FDQTs7R0FFQTtFQUNBO0NBQ0E7O0NBR0E7RUFDQTtHQUNBO0dBQ0E7RUFDQTtFQUNBO0dBQ0E7SUFDQTtLQUNBO0lBQ0EsU0FFQTtHQUNBO0dBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDQTs7Q0FHQTtFQUNBO0dBQ0E7R0FDQTtFQUNBO0VBRUE7R0FDQTtHQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0EseUJBQ0E7R0FDQTtJQUNBO0lBQ0E7S0FDQTtNQUNBO01BQ0E7T0FDQTtRQUFBO1FBQUE7UUFBQTtPQUFBO01BQ0E7TUFDQSxXQUNBLGtFQUNBLGtDQUVBLGtCQUNBO01BQ0E7T0FDQTtPQUNBO09BQ0E7TUFDQTtLQUNBO0tBQ0E7SUFDQTtHQUNBO0VBQ0EsR0FDQTs7RUFFQSxHQUNBO0dBQ0E7R0FDQTtFQUNBO0NBQ0E7O0NBR0E7RUFDQTtFQUNBO0dBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FDQTtHQUVBO0lBQ0E7S0FDQTtLQUNBO01BQUE7TUFBQTtLQUFBO0tBQ0E7TUFBQTtNQUFBO0tBQUE7SUFDQTtJQUNBO0dBQ0E7R0FFQTtHQUNBO0dBQ0E7R0FFQTtJQUNBO0lBQ0E7SUFDQTs7SUFHQTtJQUNBO0tBQ0E7S0FDQTtNQUNBO0tBQ0E7SUFDQTtJQUVBO0dBQ0E7RUFDQTtHQUNBO0dBQ0E7SUFDQTtJQUNBO0dBQ0E7SUFDQTtJQUNBO0dBQ0E7SUFDQTtHQUNBO0VBQ0E7Q0FDQTtFQUFBO0VBQUE7RUFBQTtDQUFBOztDQUdBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7R0FDQTs7R0FFQTtHQUNBO0VBQ0E7R0FDQTtFQUNBO0NBQ0E7O0NBR0E7RUFDQTtDQUNBOztDQUdBO0VBQ0E7R0FDQTtFQUNBO0VBQ0E7R0FDQTtFQUNBO0NBQ0E7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0NBQUE7O0NBR0EsMkNBQ0EsUUFDQSxNQUNBLFlBQ0EsU0FDQSxhQUNBLHNCQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtHQUNBO0dBQ0E7R0FFQSxpQkFDQSxxQkFDQSxnRUFDQSw4REFDQTtHQUVBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0E7R0FFQTtHQUNBOztHQUdBO0lBQ0E7S0FDQTtLQUNBO01BQ0E7S0FDQTtJQUNBLFNBRUE7R0FDQTtHQUVBO0dBQ0E7R0FDQTtJQUNBO0dBQ0E7SUFDQTtHQUNBO0lBQ0E7R0FDQTtFQUNBO0dBQ0E7RUFDQTtHQUNBO0dBQ0E7RUFDQTtDQUNBOztDQUdBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7O0VBR0E7RUFDQTtFQUVBO0VBQ0E7RUFFQTtDQUNBOztDQUdBO0VBQ0E7RUFDQTtFQUVBO0VBQ0E7RUFDQTtFQUVBO0dBQ0E7SUFDQTtJQUNBO0dBQ0E7SUFDQTtJQUNBO0dBQ0E7RUFDQTtHQUNBO0dBQ0E7R0FDQTtFQUNBO0NBQ0E7O0NBR0E7RUFDQTtFQUNBO0VBQ0E7R0FDQTtHQUNBO0VBQ0E7RUFDQTtFQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0E7O0NBR0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDQTs7Q0FHQTtFQUNBO0VBQ0E7R0FDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0E7RUFDQTtFQUNBO0NBQ0E7O0NBR0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtXQUNBO1NBQ0E7bUJBQ0E7d0JBQ0E7b0JBQ0E7b0JBQ0E7bUJBQ0E7a0JBQ0E7O0VBR0E7RUFDQTtDQUNBO0NBRUEsT0FDQTtFQUFBO0VBQUE7WUFBQSxDQUVBO0dBQUE7R0FBQTthQUFBLENBQ0E7SUFBQTtJQUFBO2NBQUEsQ0FDQTtLQUFBO0tBQUE7ZUFDQTtNQUFBO01BQUE7S0FBc0M7Ozs7O0lBQ3RDOzs7O2NBQ0E7S0FBQTtlQUFBLENBQ0E7TUFBQTtNQUFBO2dCQUFBLENBQ0EsaUZBQ0E7T0FBQTtPQUFBO09BQUE7aUJBQW9IO01BRXBIOzs7O2NBQ0E7Ozs7O2VBQ0E7TUFBQTtNQUFBO2dCQUNBO0tBQ0E7Ozs7YUFDQTs7Ozs7WUFDQTs7Ozs7YUFHQSxlQUNBO0lBQUE7SUFBQTtjQUFBO0tBQ0E7TUFDQTtNQUNBLDZGQUNBLDJCQUNBLGlEQUNBO01BRUE7Z0JBUEE7T0FRQTtRQUFBO1FBQUE7T0FBOEM7Ozs7O09BQUE7T0FBQTtNQUM5Qzs7Ozs7O0tBQ0E7TUFDQTtNQUNBLDZGQUNBLHdCQUNBLGlEQUNBO01BRUE7Z0JBUEE7T0FRQTtRQUFBO1FBQUE7T0FBMkM7Ozs7O09BQUE7T0FBQTtNQUMzQzs7Ozs7O0tBQ0E7TUFDQTtNQUNBLDZGQUNBLGdDQUNBLGlEQUNBO01BRUE7Z0JBUEE7T0FRQTtRQUFBO1FBQUE7T0FBMkM7Ozs7O09BQUE7T0FBQTtNQUMzQzs7Ozs7O0lBQ0E7Ozs7O1dBRUE7Ozs7O1lBR0E7R0FBQTtHQUFBO2FBQUE7SUFFQSxlQUNBO0tBQUE7S0FBQTtlQUFBO01BRUE7T0FDQTtPQUNBO09BQ0E7T0FDQTtPQUNBLDhHQUNBO09BRUE7TUFBWTs7Ozs7TUFHWixnQ0FDQTtPQUFBO09BQUE7aUJBQUE7UUFDQTtTQUFBO1NBQUE7bUJBQ0E7VUFBQTtVQUFBO1NBQThDOzs7OztRQUM5Qzs7Ozs7UUFDQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQTtVQUFBO1VBQUE7b0JBQTZFO1NBQUE7Ozs7bUJBQzdFO1VBQUE7VUFBQTtvQkFDQTtTQUNBOzs7O2lCQUNBOzs7Ozs7UUFDQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQTtVQUFBO1VBQUE7VUFBQTtvQkFBQTtXQUNBO1lBQUE7WUFBQTtXQUFnRDs7Ozs7V0FBQTtXQUFBO1VBQ2hEOzs7OzttQkFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO29CQUpBO1dBS0E7WUFBQTtZQUFBO1dBQWdEOzs7OztXQUFBO1dBQUE7VUFDaEQ7Ozs7O2lCQUNBOzs7Ozs7T0FDQTs7Ozs7O01BSUEsZ0NBQ0E7T0FBQTtPQUFBO2lCQUFBO1FBQ0E7U0FBQTtTQUFBO21CQUNBO1VBQUE7VUFBQTtTQUFtRDs7Ozs7UUFDbkQ7Ozs7O1FBQ0E7U0FBQTtTQUFBO21CQUFBLENBQ0E7VUFBQTtVQUFBO29CQUE4RDtTQUFBOzs7O21CQUM5RDtVQUFBO1VBQUE7b0JBQ0E7U0FDQTs7OztpQkFDQTs7Ozs7O1FBQ0E7U0FBQTtTQUFBO21CQUFBLENBQ0E7VUFBQTtVQUFBO1VBQUE7VUFBQTtvQkFBQTtXQUNBO1lBQUE7WUFBQTtXQUFtRDs7Ozs7V0FBQTtXQUFBO1VBQ25EOzs7OzttQkFDQTtVQUFBO1VBQUE7VUFBQTtvQkFBQTtXQUNBO1lBQUE7WUFBQTtXQUFnRDs7Ozs7V0FBQTtXQUFBO1VBQ2hEOzs7OztpQkFDQTs7Ozs7O09BQ0E7Ozs7OztNQUlBLHFDQUNBO09BQUE7T0FBQTtpQkFBQTtRQUNBO1NBQUE7U0FBQTttQkFDQTtVQUFBO1VBQUE7U0FBcUQ7Ozs7O1FBQ3JEOzs7OztRQUNBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtvQkFBOEQ7U0FBQTs7OzttQkFDOUQ7VUFBQTtVQUFBO29CQUNBO1NBQ0E7Ozs7aUJBQ0E7Ozs7OztRQUNBO1NBQUE7U0FBQTtTQUFBO21CQUFBO1VBQ0E7V0FBQTtXQUFBO1VBQThDOzs7OztVQUFBO1VBQUE7U0FDOUM7Ozs7OztPQUNBOzs7Ozs7TUFJQSw2QkFDQTtPQUFBO09BQUE7aUJBQUE7UUFFQSw0QkFDQTtTQUFBO1NBQUE7bUJBQUE7VUFFQTtXQUFBO1dBQUE7VUFBOEc7Ozs7O1VBQzlHO1dBQUE7V0FBQTtVQUErRzs7Ozs7VUFDL0c7V0FBQTtXQUFBO1VBQWlIOzs7OztVQUNqSDtXQUFBO1dBQUE7VUFBa0g7Ozs7O1VBR2xIO1dBQUE7V0FBQTtVQUFzTDs7Ozs7VUFFdEw7V0FBQTtXQUFBO3FCQUF5TDtVQUV6TDs7Ozs7U0FDQTs7Ozs7O1FBSUEseUJBQ0E7U0FBQTtTQUFBO21CQUFBO1VBQ0E7V0FBQTtXQUFBO1VBQTRHOzs7OztVQUM1RztXQUFBO1dBQUE7VUFBNkc7Ozs7O1VBQzdHO1dBQUE7V0FBQTtVQUErRzs7Ozs7VUFDL0c7V0FBQTtXQUFBO1VBQWdIOzs7OztVQUdoSDtXQUFBO1dBQUE7VUFBK0Q7Ozs7O1VBQy9EO1dBQUE7V0FBQTtVQUF3RTs7Ozs7VUFFeEU7V0FBQTtXQUFBO3FCQUF1TTtVQUV2TTs7Ozs7U0FDQTs7Ozs7O1FBSUEsaUNBQ0E7U0FBQTtTQUFBO21CQUNBO1VBQUE7VUFBQTtvQkFBZ007U0FFaE07Ozs7O1FBQ0E7Ozs7O1FBSUE7U0FBQTtTQUFBO21CQUFBO1VBQ0E7V0FBQTtXQUFBO1VBQXFGOzs7OztVQUNyRjtVQUNBO1VBQ0E7U0FDQTs7Ozs7O09BQ0E7Ozs7OztNQUlBLDZDQUNBO09BQUE7T0FBQTtpQkFBQSxDQUNBO1FBQUE7UUFBQTtrQkFBQSxDQUNBO1NBQUE7U0FBQTttQkFDQTtVQUFBO1VBQUE7U0FBc0Q7Ozs7O1FBQ3REOzs7O2tCQUNBO1NBQUE7bUJBQUEsQ0FDQTtVQUFBO1VBQUE7b0JBQUE7V0FDQTtXQUFBO1dBQUE7VUFDQTs7Ozs7bUJBQ0Esd0JBQ0E7VUFBQTtVQUFBO29CQUFBLENBQW1FLGdCQUNuRSxvQkFDQTs7Ozs7aUJBRUE7Ozs7O2dCQUNBOzs7OztpQkFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO2tCQUpBLENBSWdCLGVBQ2hCO1NBQUE7U0FBQTtRQUFrRTs7OztnQkFDbEU7Ozs7O2VBQ0E7Ozs7OztNQUlBLDZCQUNBO09BQUE7T0FBQTtpQkFBQSxDQUNBLFlBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSxrREFDQTtRQUVBO1FBQ0E7a0JBQ0E7U0FBQTtTQUFBO1FBQXFFOzs7O21CQUFBO1NBQUE7U0FBQTtRQUFpQzs7Ozs7T0FDdEc7Ozs7aUJBR0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7a0JBQ0E7U0FBQTtTQUFBO1FBQWlEOzs7OztPQUNqRDs7OztlQUNBOzs7Ozs7TUFJQSxZQUNBO09BQUE7T0FBQTtpQkFBQTtRQUNBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtTQUFtSDs7OzttQkFDbkg7VUFBQTtVQUFBO1NBQW9GOzs7O2lCQUNwRjs7Ozs7O1FBQ0E7U0FBQTtTQUFBO21CQUFBLENBQ0E7VUFBQTtVQUFBO29CQUE2RTtTQUU3RTs7OzttQkFDQTtVQUFBO1VBQUE7b0JBQ0E7U0FDQTs7OztpQkFDQTs7Ozs7O1FBQ0E7U0FBQTtTQUFBO1NBQUE7UUFBd0U7Ozs7O09BQ3hFOzs7Ozs7S0FFQTs7Ozs7O0lBSUEsNENBQ0E7S0FBQTtLQUFBO2VBQUE7TUFDQTtPQUFBO09BQUE7aUJBQUE7UUFDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7bUJBTEE7VUFNQTtXQUFBO1dBQUE7VUFBZ0Q7Ozs7O1VBQUE7VUFBQTtTQUNoRDs7Ozs7O1FBQ0E7U0FDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO21CQUxBO1VBTUE7V0FBQTtXQUFBO1VBQTZDOzs7OztVQUFBO1VBQUE7U0FDN0M7Ozs7OztRQUNBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1FBQWM7Ozs7O09BQ2Q7Ozs7OztNQUdBO09BQUE7T0FBQTtpQkFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO2tCQUpBO1NBS0E7VUFBQTtVQUFBO1NBQTRDOzs7OztTQUFBO1NBQUE7UUFDNUM7Ozs7OztNQUNBOzs7OztNQUVBO09BQUE7T0FBQTtpQkFDQSwyQkFDQSw0RUFDQSx3QkFDQSw2RUFDQTtNQUNBOzs7OztLQUNBOzs7Ozs7SUFJQSx3SEFDQTtLQUNBO0tBQ0E7S0FDQTtlQUhBLENBSUE7TUFBQTtNQUFBO2dCQUFBLENBQ0E7T0FBQTtPQUFBO2lCQUFBLENBQ0E7UUFBQTtRQUFBO09BQXdHOzs7O2lCQUN4RztRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtPQUFnQjs7OztlQUNoQjs7Ozs7Z0JBQ0E7T0FBQTtPQUFBO2lCQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtrQkFDQTtPQUNBOzs7OztNQUNBOzs7O2NBQ0E7Ozs7O2VBR0E7TUFBQTtNQUFBO2dCQUFBO09BQ0E7UUFBQTtRQUFBO2tCQUFnRTtPQUFBOzs7OztPQUNoRTtRQUNBO1FBQ0E7U0FDQTtTQUNBO1FBQ0E7UUFDQTtRQUNBO2tCQUFjO09BRWQ7Ozs7O09BQ0E7UUFDQTtRQUNBO1NBQ0E7U0FDQTtRQUNBO1FBQ0E7UUFDQTtrQkFBYztPQUVkOzs7OztPQUNBO1FBQ0E7UUFDQTtTQUNBO1NBQ0E7UUFDQTtRQUNBO1FBQ0E7a0JBQWM7T0FFZDs7Ozs7T0FDQTtRQUNBO1FBQ0E7U0FDQTtTQUNBO1FBQ0E7UUFDQTtRQUNBO2tCQUFjO09BRWQ7Ozs7O01BQ0E7Ozs7O2FBQ0E7Ozs7OztJQU1BLGNBQ0E7S0FBQTtLQUFBO2VBQUE7TUFFQTtPQUNBLHFDQUNBLHlEQUNBLCtEQUNBLG1GQUNBLHlFQUNBLGlFQUNBLHVFQUNBO09BRUE7aUJBQ0E7UUFBQTtRQUFBO2tCQUFBLENBQ0E7U0FBQTtTQUFBO21CQUFBLENBQ0E7VUFDQSx3RkFDQSx5REFDQSwrREFDQSw4QkFDQSx5RUFDQSxpRUFDQSwyQkFDQTtVQUVBO29CQUNBLHlEQUNBLCtEQUNBO1dBQUE7V0FBQTtVQUF1RDs7OztxQkFFdkQ7V0FBQTtXQUFBO1VBQXVEOzs7OztTQUV2RDs7OzttQkFFQTtVQUFBO1VBQUE7b0JBQUE7V0FDQTtZQUFBO1lBQUE7c0JBQUEsQ0FDQTthQUNBLHVFQUNBLHlEQUNBLCtEQUNBLG1EQUNBLHlFQUNBLGlFQUNBLDZDQUNBO2FBRUE7dUJBQ0EsZ0RBQ0EsZ0VBQ0E7WUFDQTs7OztzQkFDQTthQUFBO2FBQUE7dUJBQUEsQ0FBb0UsZ0JBQ3BFLHFFQUNBOzs7OztvQkFDQTs7Ozs7O1dBRUE7WUFBQTtZQUFBO3NCQUFBO2FBQ0E7YUFBQTthQUNBO2NBQUE7Y0FBQTt3QkFDQTthQUNBOzs7OztZQUNBOzs7Ozs7V0FFQTtZQUFBO1lBQUE7c0JBQUEsQ0FDQTthQUFBO2FBQUE7WUFBeUQ7Ozs7c0JBQ3pEO2FBQUE7dUJBQUE7Y0FBMkI7Y0FDM0I7ZUFBQTt5QkFBaUQ7Y0FBQTs7Ozs7Y0FBQTtjQUNqRDtjQUFBO2FBQ0E7Ozs7O29CQUNBOzs7Ozs7VUFDQTs7Ozs7aUJBQ0E7Ozs7O2tCQUdBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtvQkFBQSxDQUNBO1dBQUE7V0FBQTtxQkFBOEY7VUFFOUY7Ozs7b0JBQ0E7V0FBQTtXQUFBO3FCQUFBLENBQ0EseUZBQ0E7Ozs7O2tCQUNBOzs7OzttQkFDQSx3RUFDQTtVQUFBO1VBQUE7b0JBQUE7V0FBbUU7V0FDbkU7V0FBQTtVQUNBOzs7OztpQkFFQTs7Ozs7Z0JBQ0E7Ozs7OztNQUNBOzs7OztNQUdBO09BQUE7T0FBQTtpQkFBQTtRQUNBO1NBQ0E7U0FDQSx5SEFDQSwrQkFDQSxnQ0FDQTtTQUVBO21CQVBBLENBUUE7VUFBQTtVQUFBO1NBQWlEOzs7O21CQUFBLHlCQUNqRDs7Ozs7O1FBQ0E7U0FDQTtTQUNBLHlIQUNBLHdCQUNBLGdDQUNBO1NBRUE7bUJBUEEsQ0FRQTtVQUFBO1VBQUE7U0FBZ0Q7Ozs7bUJBQUEsNEJBQ2hEOzs7Ozs7UUFDQTtTQUNBO1NBQ0EseUhBQ0Esd0JBQ0EsZ0NBQ0E7U0FFQTttQkFQQSxDQVFBO1VBQUE7VUFBQTtTQUErQzs7OzttQkFBQSw2QkFDL0M7Ozs7OztRQUNBO1NBQ0E7U0FDQSx5SEFDQSw0QkFDQSxnQ0FDQTtTQUVBO21CQVBBLENBUUE7VUFBQTtVQUFBO1NBQThDOzs7O21CQUFBLGlDQUM5Qzs7Ozs7O1FBQ0E7U0FDQTtTQUNBLHlIQUNBLDZCQUNBLGdDQUNBO1NBRUE7bUJBUEEsQ0FRQTtVQUFBO1VBQUE7U0FBNkM7Ozs7bUJBQUEsNEJBQzdDOzs7Ozs7T0FDQTs7Ozs7O01BR0EsZ0NBQ0E7T0FBQTtPQUFBO2lCQUFBO1FBQ0E7U0FBQTtTQUFBO21CQUFBO1VBRUE7V0FBQTtXQUFBO3FCQUFBLENBQ0E7WUFBQTtZQUFBO3NCQUFBLENBQ0E7YUFBQTthQUFBO1lBQWdFOzs7O3NCQUFBLDBCQUNoRTs7Ozs7cUJBQ0E7WUFBQTtZQUFBO3NCQUNBLG9EQUNBO1dBQ0E7Ozs7bUJBQ0E7Ozs7OztVQUdBO1dBQUE7V0FBQTtxQkFBQSxDQUNBO1lBQUE7WUFBQTtzQkFBQSxDQUNBO2FBQUE7YUFBQTtZQUFtRTs7OztzQkFBQSx5QkFDbkU7Ozs7O3FCQUNBO1lBQUE7WUFBQTtzQkFDQSw4REFDQSwyQ0FDQTtXQUNBOzs7O21CQUNBOzs7Ozs7VUFHQTtXQUFBO1dBQUE7cUJBQUEsQ0FDQTtZQUFBO1lBQUE7c0JBQUEsQ0FDQTthQUFBO2FBQUE7WUFBeUU7Ozs7c0JBQUEsMkJBQ3pFOzs7OztxQkFDQTtZQUFBO1lBQUE7c0JBQ0EsOERBQ0E7V0FDQTs7OzttQkFDQTs7Ozs7O1NBQ0E7Ozs7OztRQUdBLDZEQUNBLHVFQUNBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtvQkFBQSxDQUNBO1dBQUE7V0FBQTtVQUE4RTs7OztvQkFBQSx1Q0FFOUU7Ozs7O21CQUNBO1VBQUE7VUFBQTtvQkFDQSw0RUFDQTtXQUFBO1dBQUE7cUJBQUEsQ0FDQTtZQUFBO1lBQUE7c0JBQW9FO1dBQUE7Ozs7cUJBQ3BFO1lBQUE7c0JBQWlDO1dBQUE7Ozs7bUJBQ2pDO2FBSEE7Ozs7aUJBR0EsQ0FDQTtTQUNBOzs7O2lCQUNBOzs7Ozs7UUFJQSxpQkFDQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1NBQW9COzs7O21CQUNwQjtVQUFBO1VBQUE7b0JBQUEsQ0FDQTtXQUFBO1dBQUE7cUJBQW9EO1VBQUE7Ozs7b0JBQ3BEO1dBQUE7V0FBQTtxQkFBQTtZQUE0RDtZQUM1RDtZQUFBO1lBQUE7WUFDQTtXQUNBOzs7OztrQkFDQTs7Ozs7aUJBQ0E7Ozs7OztPQUVBOzs7Ozs7TUFJQSx5QkFDQTtPQUFBO09BQUE7aUJBQUEsQ0FDQTtRQUFBO1FBQUE7a0JBQUEsQ0FDQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQTtVQUFBO1VBQUE7U0FBaUU7Ozs7bUJBQUEsK0NBRWpFOzs7OztrQkFDQTtTQUFBO1NBQUE7bUJBQUE7VUFBOEQ7VUFDOUQ7VUFBQTtTQUVBOzs7OztnQkFDQTs7Ozs7aUJBRUE7UUFBQTtRQUFBO2tCQUNBLG1GQUNBO1NBRUE7U0FDQTttQkFIQSxDQUlBO1VBQUE7VUFBQTtvQkFDQTtTQUNBOzs7O21CQUNBO1VBQUE7VUFBQTtvQkFBNkU7U0FBQTs7OztpQkFDN0U7V0FQQTs7OztlQU9BLENBQ0EsS0FDQTtTQUFBO1NBQUE7bUJBQWdFO1FBR2hFOzs7OztPQUVBOzs7O2VBQ0E7Ozs7OztNQUlBLHlCQUNBO09BQUE7T0FBQTtpQkFBQTtRQUNBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtvQkFBQSxDQUNBO1dBQUE7V0FBQTtVQUFnRTs7OztvQkFBQSxxQ0FDaEU7Ozs7O21CQUNBO1VBQUE7VUFBQTtvQkFDQSw2Q0FDQTtTQUNBOzs7O2lCQUNBOzs7Ozs7UUFFQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQTtVQUFBO1VBQUE7b0JBQUEsQ0FDQTtXQUFBO1dBQUE7cUJBQTJEO1VBQUE7Ozs7b0JBQzNEO1dBQUE7V0FBQTtxQkFBQTtZQUNBO1lBQUE7WUFBQTtXQUNBOzs7OztrQkFDQTs7Ozs7bUJBQ0E7VUFBQTtVQUFBO29CQUFBLENBQ0E7V0FBQTtXQUFBO3FCQUEyRDtVQUFBOzs7O29CQUMzRDtXQUFBO1dBQUE7cUJBQ0EsaUZBQ0E7VUFDQTs7OztrQkFDQTs7Ozs7aUJBQ0E7Ozs7OztRQUVBLGdCQUNBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7b0JBQUEsQ0FDQTtXQUFBO1dBQUE7cUJBQUEsQ0FDQSx1Q0FDQTs7Ozs7b0JBQ0E7V0FBQTtXQUFBO3FCQUFBO1lBQTREO1lBQzVEO1lBQUE7WUFBQTtXQUNBOzs7OztrQkFDQTs7Ozs7bUJBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO29CQUxBLENBS29CLG9CQUNwQjtXQUFBO1dBQUE7VUFBd0U7Ozs7a0JBQ3hFOzs7OztpQkFDQTs7Ozs7O09BRUE7Ozs7OztNQUlBLDZCQUNBO09BQUE7T0FBQTtpQkFBQTtRQUNBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtvQkFBQSxDQUNBO1dBQUE7V0FBQTtVQUErRDs7OztvQkFBQSwyQ0FDL0Q7Ozs7O21CQUNBO1VBQUE7VUFBQTtvQkFBOEQ7U0FFOUQ7Ozs7aUJBQ0E7Ozs7OztRQUVBO1NBQUE7U0FBQTttQkFBQTtVQUNBO1dBQUE7V0FBQTtxQkFBQSxDQUNBO1lBQUE7WUFBQTtzQkFBQSxDQUNBO2FBQUE7YUFBQTtZQUFnRTs7OztzQkFBQSwwQ0FDaEU7Ozs7O3FCQUNBO1lBQUE7WUFBQTtzQkFDQSxzREFDQTtXQUNBOzs7O21CQUNBOzs7Ozs7VUFFQTtXQUFBO1dBQUE7cUJBQUEsQ0FDQTtZQUFBO1lBQUE7c0JBQUEsQ0FDQTthQUFBO2FBQUE7WUFBcUU7Ozs7c0JBQUEsdUNBQ3JFOzs7OztxQkFDQTtZQUFBO1lBQUE7c0JBQ0EscURBQ0E7V0FDQTs7OzttQkFDQTs7Ozs7O1VBRUE7V0FBQTtXQUFBO3FCQUFBLENBQ0E7WUFBQTtZQUFBO3NCQUFBLENBQ0E7YUFBQTthQUFBO1lBQWdFOzs7O3NCQUFBLG9DQUNoRTs7Ozs7cUJBQ0E7WUFBQTtZQUFBO3NCQUNBLG1EQUNBO1dBQ0E7Ozs7bUJBQ0E7Ozs7OztVQUVBO1dBQUE7V0FBQTtxQkFBQSxDQUNBO1lBQUE7WUFBQTtzQkFBQSxDQUNBO2FBQUE7YUFBQTtZQUE0RTs7OztzQkFBQSxzQ0FDNUU7Ozs7O3FCQUNBO1lBQUE7WUFBQTtzQkFDQSx5REFDQTtXQUNBOzs7O21CQUNBOzs7Ozs7U0FDQTs7Ozs7O1FBRUEsaUZBQ0E7U0FBQTtTQUFBO21CQUFBLENBQ0E7VUFBQTtVQUFBO29CQUE4RDtTQUFBOzs7O21CQUM5RDtVQUFBO1VBQUE7b0JBQ0EsOENBQ0E7V0FBQTtXQUFBO3FCQUFBLENBQ0E7WUFBQTtZQUFBO1dBQWlHOzs7O3FCQUNqRztZQUFBO3NCQUErQjtXQUFBOzs7O21CQUMvQjthQUhBOzs7O2lCQUdBLENBQ0E7U0FDQTs7OztpQkFDQTs7Ozs7O09BRUE7Ozs7OztNQUlBLDhCQUNBO09BQUE7T0FBQTtpQkFBQSxDQUNBO1FBQUE7UUFBQTtrQkFBQSxDQUNBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtTQUE4RDs7OzttQkFBQSxrREFDOUQ7Ozs7O2tCQUNBO1NBQUE7U0FBQTttQkFBOEQ7UUFFOUQ7Ozs7Z0JBQ0E7Ozs7O2lCQUVBO1FBQUE7UUFBQTtrQkFBQTtTQUNBO1VBQUE7VUFBQTtvQkFBQSxDQUNBO1dBQUE7cUJBQUEsQ0FDQTtZQUFBO1lBQUE7c0JBQUEsQ0FDQSwyREFDQTs7Ozs7cUJBQ0E7WUFBQTtZQUFBO3NCQUFBO2FBQTREO2FBQzVEO2FBQUE7YUFBQTthQUFBO1lBQ0E7Ozs7O21CQUNBOzs7OztvQkFDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO3FCQUpBLENBS0E7WUFBQTtZQUFBO1dBQXVEOzs7O3FCQUFBLDJCQUN2RDs7Ozs7a0JBQ0E7Ozs7OztTQUVBO1VBQUE7VUFBQTtvQkFBQTtXQUNBO1lBQUE7WUFBQTtzQkFBQSxDQUNBO2FBQUE7YUFBQTt1QkFBNEY7WUFBQTs7OztzQkFDNUY7YUFBQTthQUFBO3VCQUNBO1lBQ0E7Ozs7b0JBQ0E7Ozs7OztXQUNBO1lBQUE7WUFBQTtzQkFBQSxDQUNBO2FBQUE7YUFBQTt1QkFBNEY7WUFBQTs7OztzQkFDNUY7YUFBQTthQUFBO3VCQUFBLENBQ0EseUZBQ0E7Ozs7O29CQUNBOzs7Ozs7V0FDQTtZQUFBO1lBQUE7c0JBQUEsQ0FDQTthQUFBO2FBQUE7dUJBQTRGO1lBQUE7Ozs7c0JBQzVGO2FBQUE7YUFBQTt1QkFBQSxDQUNBLDJDQUNBOzs7OztvQkFDQTs7Ozs7O1VBQ0E7Ozs7OztTQUVBO1VBQUE7VUFBQTtvQkFBQSxDQUNBO1dBQUE7cUJBQUE7WUFDQTthQUFBO3VCQUE2QjtZQUFBOzs7OztZQUFBO1lBQzdCLGlGQUNBO1dBQ0E7Ozs7O29CQUNBO1dBQUE7cUJBQUE7WUFDQTthQUFBO3VCQUE2QjtZQUFBOzs7OztZQUFBO1lBQzdCLHFFQUNBO1dBQ0E7Ozs7O2tCQUNBOzs7Ozs7UUFDQTs7Ozs7ZUFDQTs7Ozs7O01BSUE7T0FBQTtPQUFBO2lCQUFBLENBQ0E7UUFBQTtRQUFBO1FBQUE7UUFBQTtrQkFBQTtTQUNBO1VBQUE7VUFBQTtTQUFtRDs7Ozs7U0FBQTtTQUFBO1FBQ25EOzs7OztpQkFFQTtRQUFBO1FBQUE7a0JBQUE7U0FDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7b0JBTEE7V0FNQTtZQUFBO1lBQUE7V0FBZ0U7Ozs7O1dBQUE7V0FBQTtVQUNoRTs7Ozs7O1NBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtvQkFKQTtXQUtBO1lBQUE7WUFBQTtXQUFnRDs7Ozs7V0FBQTtXQUFBO1VBQ2hEOzs7Ozs7U0FDQSxpQkFDQTtVQUNBO1VBQ0E7VUFDQTtvQkFIQTtXQUlBO1lBQUE7WUFBQTtXQUF1RDs7Ozs7V0FBQTtXQUFBO1VBQ3ZEOzs7Ozs7UUFFQTs7Ozs7ZUFDQTs7Ozs7O0tBQ0E7Ozs7OztHQUVBOzs7OztVQUNBOzs7Ozs7QUFFQSIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJvZHVjdEF1dGhlbnRpY2l0eUNhbWVyYVNjYW5uZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VSZWYsIHVzZUVmZmVjdCwgdXNlQ2FsbGJhY2sgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZVRyYW5zbGF0aW9uIH0gZnJvbSBcInJlYWN0LWkxOG5leHRcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCI7XG5pbXBvcnQgeyBCYWRnZSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYmFkZ2VcIjtcbmltcG9ydCB7IFByb2dyZXNzIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9wcm9ncmVzc1wiO1xuaW1wb3J0IHtcbiAgQ2FtZXJhLFxuICBTY2FuLFxuICBRckNvZGUsXG4gIFNoaWVsZENoZWNrLFxuICBTaGllbGRBbGVydCxcbiAgQWxlcnRUcmlhbmdsZSxcbiAgQnVpbGRpbmcyLFxuICBTcGFya2xlcyxcbiAgVXBsb2FkLFxuICBSZWZyZXNoQ3csXG4gIENoZWNrQ2lyY2xlMixcbiAgQXJyb3dSaWdodCxcbiAgWmFwLFxuICBaYXBPZmYsXG4gIEV5ZSxcbiAgQ29weSxcbiAgVGFnLFxuICBIZWxwQ2lyY2xlLFxuICBNYXhpbWl6ZTIsXG4gIEV4dGVybmFsTGluayxcbiAgTWVzc2FnZVNxdWFyZSxcbiAgRmlsZUNoZWNrLFxuICBEb3dubG9hZCxcbiAgUHJpbnRlcixcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHtcbiAgZGV0ZWN0QmFyY29kZU9yUXIsXG4gIGdldEdzMUNvdW50cnlQcmVmaXgsXG4gIHBsYXlTY2FuQ2hpbWUsXG4gIGZpbGVUb09wdGltaXplZEJhc2U2NCxcbiAgZXh0cmFjdEZyYW1lRnJvbVZpZGVvLFxuICBydW5BaVNjYW4sXG4gIHR5cGUgQWlTY2FuUmVzdWx0LFxufSBmcm9tIFwiQC9saWIvYWktc2Nhbm5lclwiO1xuaW1wb3J0IHsgc2VhcmNoQnJhbmRzLCB0eXBlIEJyYW5kIH0gZnJvbSBcIkAvbGliL2JyYW5kc1wiO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tIFwic29ubmVyXCI7XG5cbmV4cG9ydCB0eXBlIEluc3BlY3Rpb25Nb2RlID0gXCJiYXJjb2RlXCIgfCBcImxvZ29cIiB8IFwiZnVsbF9wcm9kdWN0XCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHJvZHVjdENhbWVyYVNjYW5uZXJQcm9wcyB7XG4gIG9uQXBwbHlUb1Bvc3Q/OiAocGFyYW1zOiB7XG4gICAgYnJhbmROYW1lOiBzdHJpbmc7XG4gICAgYnJhbmRPd25lcjogc3RyaW5nO1xuICAgIHByb2R1Y3ROYW1lOiBzdHJpbmc7XG4gICAgY2F0ZWdvcnk6IHN0cmluZztcbiAgICBtYXRjaGVkQnJhbmRJZD86IHN0cmluZztcbiAgICBmaWxlPzogRmlsZSB8IG51bGw7XG4gICAgc2NhblJlc3VsdDogQWlTY2FuUmVzdWx0O1xuICB9KSA9PiB2b2lkO1xuICBvbkNsb3NlPzogKCkgPT4gdm9pZDtcbiAgc3RhbmRhbG9uZT86IGJvb2xlYW47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBQcm9kdWN0QXV0aGVudGljaXR5Q2FtZXJhU2Nhbm5lcih7XG4gIG9uQXBwbHlUb1Bvc3QsXG4gIG9uQ2xvc2UsXG4gIHN0YW5kYWxvbmUgPSBmYWxzZSxcbn06IFByb2R1Y3RDYW1lcmFTY2FubmVyUHJvcHMpIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VUcmFuc2xhdGlvbigpO1xuICAvLyBQZXJtaXNzaW9uICYgU3RyZWFtIFN0YXRlXG4gIGNvbnN0IFtwZXJtaXNzaW9uU3RhdGUsIHNldFBlcm1pc3Npb25TdGF0ZV0gPSB1c2VTdGF0ZTxcbiAgICBcInByb21wdFwiIHwgXCJncmFudGVkXCIgfCBcImRlbmllZFwiIHwgXCJ1bnN1cHBvcnRlZFwiXG4gID4oXCJwcm9tcHRcIik7XG4gIGNvbnN0IFtzdHJlYW1BY3RpdmUsIHNldFN0cmVhbUFjdGl2ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtjYW1lcmFGYWNpbmcsIHNldENhbWVyYUZhY2luZ10gPSB1c2VTdGF0ZTxcImVudmlyb25tZW50XCIgfCBcInVzZXJcIj4oXCJlbnZpcm9ubWVudFwiKTtcbiAgY29uc3QgW2hhc1RvcmNoLCBzZXRIYXNUb3JjaF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFt0b3JjaE9uLCBzZXRUb3JjaE9uXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2FjdGl2ZU1vZGUsIHNldEFjdGl2ZU1vZGVdID0gdXNlU3RhdGU8SW5zcGVjdGlvbk1vZGU+KFwiYmFyY29kZVwiKTtcblxuICAvLyBBbmFseXNpcyAmIFJlc3VsdCBTdGF0ZVxuICBjb25zdCBbc2Nhbm5pbmcsIHNldFNjYW5uaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2FuYWx5emluZ1N0ZXAsIHNldEFuYWx5emluZ1N0ZXBdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcbiAgY29uc3QgW2NhcHR1cmVkSW1hZ2UsIHNldENhcHR1cmVkSW1hZ2VdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtjYXB0dXJlZEZpbGUsIHNldENhcHR1cmVkRmlsZV0gPSB1c2VTdGF0ZTxGaWxlIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtkZXRlY3RlZENvZGUsIHNldERldGVjdGVkQ29kZV0gPSB1c2VTdGF0ZTx7XG4gICAgZm9ybWF0OiBzdHJpbmc7XG4gICAgcmF3VmFsdWU6IHN0cmluZztcbiAgICBjb3VudHJ5Pzogc3RyaW5nIHwgbnVsbDtcbiAgfSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbc2NhblJlc3VsdCwgc2V0U2NhblJlc3VsdF0gPSB1c2VTdGF0ZTxBaVNjYW5SZXN1bHQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW21hdGNoZWRCcmFuZCwgc2V0TWF0Y2hlZEJyYW5kXSA9IHVzZVN0YXRlPEJyYW5kIHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gVGFiIHZpZXcgaW4gcmVzdWx0c1xuICBjb25zdCBbcmVzdWx0VGFiLCBzZXRSZXN1bHRUYWJdID0gdXNlU3RhdGU8XCJhdXRoZW50aWNpdHlcIiB8IFwiZ3VpZGVcIiB8IFwiYnJhbmRcIiB8IFwiZm9yZW5zaWNzXCIgfCBcInByX2Rvc3NpZXJcIj4oXCJhdXRoZW50aWNpdHlcIik7XG4gIGNvbnN0IFttYW51YWxCYXJjb2RlLCBzZXRNYW51YWxCYXJjb2RlXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbc2hvd01hbnVhbEJhcmNvZGUsIHNldFNob3dNYW51YWxCYXJjb2RlXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyBSZWZzXG4gIGNvbnN0IHZpZGVvUmVmID0gdXNlUmVmPEhUTUxWaWRlb0VsZW1lbnQgfCBudWxsPihudWxsKTtcbiAgY29uc3Qgc3RyZWFtUmVmID0gdXNlUmVmPE1lZGlhU3RyZWFtIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHNjYW5Mb29wUmVmID0gdXNlUmVmPG51bWJlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBmaWxlSW5wdXRSZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudCB8IG51bGw+KG51bGwpO1xuICBjb25zdCBpc0RldGVjdGluZ1JlZiA9IHVzZVJlZihmYWxzZSk7XG5cbiAgY29uc3QgaGFuZGxlUHJpbnRDZXJ0aWZpY2F0ZSA9ICgpID0+IHtcbiAgICBpZiAoIXNjYW5SZXN1bHQpIHJldHVybjtcbiAgICBjb25zdCBwcmludFdpbmRvdyA9IHdpbmRvdy5vcGVuKFwiXCIsIFwiX2JsYW5rXCIpO1xuICAgIGlmICghcHJpbnRXaW5kb3cpIHtcbiAgICAgIHRvYXN0LmluZm8oXCJQbGVhc2UgYWxsb3cgcG9wdXBzIHRvIHByaW50IHRoZSBjZXJ0aWZpY2F0ZS5cIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGh0bWwgPSBgXG4gICAgICA8IURPQ1RZUEUgaHRtbD5cbiAgICAgIDxodG1sPlxuICAgICAgPGhlYWQ+XG4gICAgICAgIDx0aXRsZT5CcmFuZCBQUiBBdXRoZW50aWNpdHkgJiBGb3JlbnNpYyBBdWRpdCBDZXJ0aWZpY2F0ZTwvdGl0bGU+XG4gICAgICAgIDxzdHlsZT5cbiAgICAgICAgICBib2R5IHsgZm9udC1mYW1pbHk6IC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXCJTZWdvZSBVSVwiLCBSb2JvdG8sIHNhbnMtc2VyaWY7IHBhZGRpbmc6IDQwcHg7IGNvbG9yOiAjMGYxNzJhOyBtYXgtd2lkdGg6IDgwMHB4OyBtYXJnaW46IDAgYXV0bzsgfVxuICAgICAgICAgIC5oZWFkZXIgeyBib3JkZXItYm90dG9tOiAycHggc29saWQgIzBmMTcyYTsgcGFkZGluZy1ib3R0b206IDIwcHg7IGRpc3BsYXk6IGZsZXg7IGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjsgYWxpZ24taXRlbXM6IGZsZXgtZW5kOyB9XG4gICAgICAgICAgLmJhZGdlIHsgZGlzcGxheTogaW5saW5lLWJsb2NrOyBwYWRkaW5nOiA2cHggMTRweDsgYmFja2dyb3VuZDogIzEwYjk4MTsgY29sb3I6IHdoaXRlOyBib3JkZXItcmFkaXVzOiA5OTk5cHg7IGZvbnQtd2VpZ2h0OiBib2xkOyB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlOyBmb250LXNpemU6IDEycHg7IH1cbiAgICAgICAgICAuaGVybyB7IG1hcmdpbjogMzBweCAwOyBiYWNrZ3JvdW5kOiAjZjhmYWZjOyBwYWRkaW5nOiAyNHB4OyBib3JkZXItcmFkaXVzOiAxNnB4OyBib3JkZXI6IDFweCBzb2xpZCAjZTJlOGYwOyB9XG4gICAgICAgICAgLmdyaWQgeyBkaXNwbGF5OiBncmlkOyBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxZnI7IGdhcDogMjBweDsgbWFyZ2luOiAyMHB4IDA7IH1cbiAgICAgICAgICAuY2FyZCB7IGJvcmRlcjogMXB4IHNvbGlkICNlMmU4ZjA7IHBhZGRpbmc6IDE2cHg7IGJvcmRlci1yYWRpdXM6IDEycHg7IGJhY2tncm91bmQ6IHdoaXRlOyB9XG4gICAgICAgICAgLnNjb3JlIHsgZm9udC1zaXplOiAzNnB4OyBmb250LXdlaWdodDogOTAwOyBjb2xvcjogIzEwYjk4MTsgfVxuICAgICAgICAgIC5mb290ZXIgeyBtYXJnaW4tdG9wOiA0MHB4OyBib3JkZXItdG9wOiAxcHggc29saWQgI2UyZThmMDsgcGFkZGluZy10b3A6IDIwcHg7IGZvbnQtc2l6ZTogMTFweDsgY29sb3I6ICM2NDc0OGI7IH1cbiAgICAgICAgPC9zdHlsZT5cbiAgICAgIDwvaGVhZD5cbiAgICAgIDxib2R5PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiaGVhZGVyXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMSBzdHlsZT1cIm1hcmdpbjowOyBmb250LXNpemU6MjRweDtcIj5TVEFTSCBPUiBUUkFTSDwvaDE+XG4gICAgICAgICAgICA8cCBzdHlsZT1cIm1hcmdpbjo0cHggMCAwIDA7IGNvbG9yOiM2NDc0OGI7IGZvbnQtc2l6ZToxM3B4O1wiPk9mZmljaWFsIEZvcmVuc2ljIE1lZGlhICYgQXV0aGVudGljaXR5IEF1ZGl0IERvc3NpZXI8L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cImJhZGdlXCI+JHtzY2FuUmVzdWx0LmNvdW50ZXJmZWl0QXNzZXNzbWVudD8uYmFkZ2VMYWJlbCB8fCBcIlZlcmlmaWVkIEF1dGhlbnRpY1wifTwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImhlcm9cIj5cbiAgICAgICAgICA8ZGl2IHN0eWxlPVwiZm9udC1zaXplOjEycHg7IHRleHQtdHJhbnNmb3JtOnVwcGVyY2FzZTsgY29sb3I6IzY0NzQ4YjsgZm9udC13ZWlnaHQ6Ym9sZDtcIj5Qcm9kdWN0ICYgQnJhbmQgUHJvZmlsZTwvZGl2PlxuICAgICAgICAgIDxoMiBzdHlsZT1cIm1hcmdpbjo2cHggMDsgZm9udC1zaXplOjI2cHg7XCI+JHtzY2FuUmVzdWx0LmJyYW5kSW5mby5icmFuZE5hbWV9IOKAlCAke3NjYW5SZXN1bHQuYnJhbmRJbmZvLnByb2R1Y3ROYW1lIHx8IFwiVmVyaWZpZWQgUHJvZHVjdFwifTwvaDI+XG4gICAgICAgICAgPHAgc3R5bGU9XCJtYXJnaW46MDsgY29sb3I6IzQ3NTU2OTsgZm9udC1zaXplOjE0cHg7XCI+PHN0cm9uZz5Db3Jwb3JhdGUgT3duZXI6PC9zdHJvbmc+ICR7c2NhblJlc3VsdC5icmFuZEluZm8uYnJhbmRPd25lcn0gKCR7c2NhblJlc3VsdC5icmFuZEluZm8uY291bnRyeU9mT3JpZ2lufSk8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZ3JpZFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYXJkXCI+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPVwiZm9udC1zaXplOjEycHg7IGNvbG9yOiM2NDc0OGI7XCI+QXV0aGVudGljaXR5IFNjb3JlPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwic2NvcmVcIj4ke3NjYW5SZXN1bHQuY291bnRlcmZlaXRBc3Nlc3NtZW50Py5hdXRoZW50aWNpdHlTY29yZSA/PyBzY2FuUmVzdWx0LmF1dGhlbnRpY2l0eS5zY29yZX0lPC9kaXY+XG4gICAgICAgICAgICA8cCBzdHlsZT1cImZvbnQtc2l6ZToxMnB4OyBjb2xvcjojNDc1NTY5OyBtYXJnaW4tdG9wOjZweDtcIj5Db25maWRlbmNlOiAke3NjYW5SZXN1bHQuY291bnRlcmZlaXRBc3Nlc3NtZW50Py5jb25maWRlbmNlPy50b1VwcGVyQ2FzZSgpIHx8IFwiSElHSFwifTwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZFwiPlxuICAgICAgICAgICAgPGRpdiBzdHlsZT1cImZvbnQtc2l6ZToxMnB4OyBjb2xvcjojNjQ3NDhiO1wiPk1lZGlhIEludGVncml0eSAoVGFtcGVyIENoZWNrKTwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNjb3JlXCIgc3R5bGU9XCJjb2xvcjogIzAyODRjNztcIj4ke3NjYW5SZXN1bHQuYXV0aGVudGljaXR5LnNjb3JlfSU8L2Rpdj5cbiAgICAgICAgICAgIDxwIHN0eWxlPVwiZm9udC1zaXplOjEycHg7IGNvbG9yOiM0NzU1Njk7IG1hcmdpbi10b3A6NnB4O1wiPlN0YXR1czogJHtzY2FuUmVzdWx0LmF1dGhlbnRpY2l0eS52ZXJkaWN0U3RhdHVzLnJlcGxhY2UoXCJfXCIsIFwiIFwiKX08L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZFwiIHN0eWxlPVwibWFyZ2luLWJvdHRvbTogMjBweDtcIj5cbiAgICAgICAgICA8aDMgc3R5bGU9XCJtYXJnaW4tdG9wOjA7IGZvbnQtc2l6ZToxNHB4O1wiPkZvcmVuc2ljIEF0dHJpYnV0ZSBWZXJpZmljYXRpb248L2gzPlxuICAgICAgICAgIDx1bCBzdHlsZT1cImZvbnQtc2l6ZToxMnB4OyBjb2xvcjojMzM0MTU1OyBsaW5lLWhlaWdodDogMS42OyBwYWRkaW5nLWxlZnQ6IDIwcHg7XCI+XG4gICAgICAgICAgICA8bGk+PHN0cm9uZz5MaWdodGluZyAmIFNoYWRvd3M6PC9zdHJvbmc+ICR7c2NhblJlc3VsdC5hdXRoZW50aWNpdHkuZm9yZW5zaWNzPy5waHlzaWNhbExpZ2h0aW5nIHx8IFwiQ29uc2lzdGVudCBwaHlzaWNhbCBzaGFkb3dzXCJ9PC9saT5cbiAgICAgICAgICAgIDxsaT48c3Ryb25nPlRleHR1cmUgJiBOb2lzZTo8L3N0cm9uZz4gJHtzY2FuUmVzdWx0LmF1dGhlbnRpY2l0eS5mb3JlbnNpY3M/LnRleHR1cmVBbmROb2lzZSB8fCBcIk5hdHVyYWwgY2FtZXJhIHNlbnNvciBncmFpbiB2ZXJpZmllZFwifTwvbGk+XG4gICAgICAgICAgICA8bGk+PHN0cm9uZz5UeXBvZ3JhcGh5ICYgUHJpbnQ6PC9zdHJvbmc+ICR7c2NhblJlc3VsdC5hdXRoZW50aWNpdHkuZm9yZW5zaWNzPy50ZXh0SW50ZWdyaXR5IHx8IFwiVmVyaWZpZWQgbWFudWZhY3R1cmVyIHR5cGVmYWNlIGdlb21ldHJ5XCJ9PC9saT5cbiAgICAgICAgICAgIDxsaT48c3Ryb25nPkFJIC8gRGVlcGZha2UgQ2hlY2s6PC9zdHJvbmc+ICR7c2NhblJlc3VsdC5hdXRoZW50aWNpdHkuZm9yZW5zaWNzPy5haUdlbmVyYXRpb25NYXJrZXJzIHx8IFwiWmVybyBzeW50aGV0aWMgQUkgZ2VuZXJhdGlvbiBtYXJrZXJzIGRldGVjdGVkXCJ9PC9saT5cbiAgICAgICAgICA8L3VsPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImZvb3RlclwiPlxuICAgICAgICAgIElzc3VlZCBieSBTdGFzaCBPciBUcmFzaCBBSSBGb3JlbnNpYyBTeXN0ZW0g4oCiIFZlcmlmaWVkIGZvciBCcmFuZCBQUiBPZmZpY2VycyAmIENsaWVudCBTZXJ2aWNlIOKAoiBUaW1lc3RhbXA6ICR7bmV3IERhdGUoKS50b0lTT1N0cmluZygpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPHNjcmlwdD5cbiAgICAgICAgICB3aW5kb3cub25sb2FkID0gZnVuY3Rpb24oKSB7IHdpbmRvdy5wcmludCgpOyB9XG4gICAgICAgIDwvc2NyaXB0PlxuICAgICAgPC9ib2R5PlxuICAgICAgPC9odG1sPlxuICAgIGA7XG4gICAgcHJpbnRXaW5kb3cuZG9jdW1lbnQud3JpdGUoaHRtbCk7XG4gICAgcHJpbnRXaW5kb3cuZG9jdW1lbnQuY2xvc2UoKTtcbiAgfTtcblxuICAvLyBDaGVjayBpbml0aWFsIHBlcm1pc3Npb24gc3RhdHVzIGlmIHN1cHBvcnRlZFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICh0eXBlb2YgbmF2aWdhdG9yICE9PSBcInVuZGVmaW5lZFwiICYmIG5hdmlnYXRvci5wZXJtaXNzaW9ucz8ucXVlcnkpIHtcbiAgICAgIG5hdmlnYXRvci5wZXJtaXNzaW9uc1xuICAgICAgICAucXVlcnkoeyBuYW1lOiBcImNhbWVyYVwiIGFzIFBlcm1pc3Npb25OYW1lIH0pXG4gICAgICAgIC50aGVuKChwZXJtaXNzaW9uU3RhdHVzKSA9PiB7XG4gICAgICAgICAgaWYgKHBlcm1pc3Npb25TdGF0dXMuc3RhdGUgPT09IFwiZ3JhbnRlZFwiKSB7XG4gICAgICAgICAgICBzZXRQZXJtaXNzaW9uU3RhdGUoXCJncmFudGVkXCIpO1xuICAgICAgICAgIH0gZWxzZSBpZiAocGVybWlzc2lvblN0YXR1cy5zdGF0ZSA9PT0gXCJkZW5pZWRcIikge1xuICAgICAgICAgICAgc2V0UGVybWlzc2lvblN0YXRlKFwiZGVuaWVkXCIpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzZXRQZXJtaXNzaW9uU3RhdGUoXCJwcm9tcHRcIik7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcGVybWlzc2lvblN0YXR1cy5vbmNoYW5nZSA9ICgpID0+IHtcbiAgICAgICAgICAgIGlmIChwZXJtaXNzaW9uU3RhdHVzLnN0YXRlID09PSBcImdyYW50ZWRcIikgc2V0UGVybWlzc2lvblN0YXRlKFwiZ3JhbnRlZFwiKTtcbiAgICAgICAgICAgIGVsc2UgaWYgKHBlcm1pc3Npb25TdGF0dXMuc3RhdGUgPT09IFwiZGVuaWVkXCIpIHNldFBlcm1pc3Npb25TdGF0ZShcImRlbmllZFwiKTtcbiAgICAgICAgICAgIGVsc2Ugc2V0UGVybWlzc2lvblN0YXRlKFwicHJvbXB0XCIpO1xuICAgICAgICAgIH07XG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgLy8gRmFsbGJhY2tcbiAgICAgICAgfSk7XG4gICAgfVxuICB9LCBbXSk7XG5cbiAgLy8gU3RvcCBjYW1lcmEgdHJhY2tzIGFuZCBjYW5jZWwgc2NhbiBsb29wXG4gIGNvbnN0IHN0b3BDYW1lcmEgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKHNjYW5Mb29wUmVmLmN1cnJlbnQpIHtcbiAgICAgIGNhbmNlbEFuaW1hdGlvbkZyYW1lKHNjYW5Mb29wUmVmLmN1cnJlbnQpO1xuICAgICAgc2Nhbkxvb3BSZWYuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICAgIGlmIChzdHJlYW1SZWYuY3VycmVudCkge1xuICAgICAgc3RyZWFtUmVmLmN1cnJlbnQuZ2V0VHJhY2tzKCkuZm9yRWFjaCgodHJhY2spID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICB0cmFjay5zdG9wKCk7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8vIGlnbm9yZVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIHN0cmVhbVJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gICAgc2V0U3RyZWFtQWN0aXZlKGZhbHNlKTtcbiAgICBzZXRUb3JjaE9uKGZhbHNlKTtcbiAgfSwgW10pO1xuXG4gIC8vIFJlYWwtdGltZSBkZXRlY3Rpb24gbG9vcCBmb3IgQmFyY29kZXMgJiBRUiBjb2Rlc1xuICBjb25zdCBydW5EZXRlY3Rpb25Mb29wID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGlmICghdmlkZW9SZWYuY3VycmVudCB8fCB2aWRlb1JlZi5jdXJyZW50LnJlYWR5U3RhdGUgPCAyKSB7XG4gICAgICBzY2FuTG9vcFJlZi5jdXJyZW50ID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHJ1bkRldGVjdGlvbkxvb3ApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChpc0RldGVjdGluZ1JlZi5jdXJyZW50KSB7XG4gICAgICBzY2FuTG9vcFJlZi5jdXJyZW50ID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHJ1bkRldGVjdGlvbkxvb3ApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlzRGV0ZWN0aW5nUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgIGNvbnN0IHZpZGVvID0gdmlkZW9SZWYuY3VycmVudDtcbiAgICBkZXRlY3RCYXJjb2RlT3JRcih2aWRlbylcbiAgICAgIC50aGVuKChkZXRlY3RlZCkgPT4ge1xuICAgICAgICBpZiAoZGV0ZWN0ZWQgJiYgZGV0ZWN0ZWQucmF3VmFsdWUpIHtcbiAgICAgICAgICBjb25zdCBjb3VudHJ5ID0gZ2V0R3MxQ291bnRyeVByZWZpeChkZXRlY3RlZC5yYXdWYWx1ZSk7XG4gICAgICAgICAgc2V0RGV0ZWN0ZWRDb2RlKChwcmV2KSA9PiB7XG4gICAgICAgICAgICBpZiAocHJldj8ucmF3VmFsdWUgIT09IGRldGVjdGVkLnJhd1ZhbHVlKSB7XG4gICAgICAgICAgICAgIHBsYXlTY2FuQ2hpbWUoKTtcbiAgICAgICAgICAgICAgaWYgKHR5cGVvZiBuYXZpZ2F0b3IgIT09IFwidW5kZWZpbmVkXCIgJiYgbmF2aWdhdG9yLnZpYnJhdGUpIHtcbiAgICAgICAgICAgICAgICBuYXZpZ2F0b3IudmlicmF0ZShbNjAsIDQwLCA2MF0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHRvYXN0LmluZm8oXG4gICAgICAgICAgICAgICAgYENhcHR1cmVkICR7ZGV0ZWN0ZWQuZm9ybWF0LnRvVXBwZXJDYXNlKCl9OiAke2RldGVjdGVkLnJhd1ZhbHVlfSR7XG4gICAgICAgICAgICAgICAgICBjb3VudHJ5ID8gYCAoJHtjb3VudHJ5fSlgIDogXCJcIlxuICAgICAgICAgICAgICAgIH1gLFxuICAgICAgICAgICAgICAgIHsgZHVyYXRpb246IDI1MDAgfVxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIGZvcm1hdDogZGV0ZWN0ZWQuZm9ybWF0LFxuICAgICAgICAgICAgICAgIHJhd1ZhbHVlOiBkZXRlY3RlZC5yYXdWYWx1ZSxcbiAgICAgICAgICAgICAgICBjb3VudHJ5LFxuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHByZXY7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICAvLyBpZ25vcmUgZGV0ZWN0aW9uIGZyYW1lIGVycm9yc1xuICAgICAgfSlcbiAgICAgIC5maW5hbGx5KCgpID0+IHtcbiAgICAgICAgaXNEZXRlY3RpbmdSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICBzY2FuTG9vcFJlZi5jdXJyZW50ID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHJ1bkRldGVjdGlvbkxvb3ApO1xuICAgICAgfSk7XG4gIH0sIFtdKTtcblxuICAvLyBTdGFydCBsaXZlIGNhbWVyYSBzdHJlYW1cbiAgY29uc3Qgc3RhcnRDYW1lcmEgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgc3RvcENhbWVyYSgpO1xuICAgIHRyeSB7XG4gICAgICBpZiAoIW5hdmlnYXRvci5tZWRpYURldmljZXMgfHwgIW5hdmlnYXRvci5tZWRpYURldmljZXMuZ2V0VXNlck1lZGlhKSB7XG4gICAgICAgIHNldFBlcm1pc3Npb25TdGF0ZShcInVuc3VwcG9ydGVkXCIpO1xuICAgICAgICB0b2FzdC5lcnJvcihcIkNhbWVyYSBBUEkgaXMgbm90IHN1cHBvcnRlZCBvbiB0aGlzIGJyb3dzZXIvZGV2aWNlLlwiKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBjb25zdHJhaW50czogTWVkaWFTdHJlYW1Db25zdHJhaW50cyA9IHtcbiAgICAgICAgdmlkZW86IHtcbiAgICAgICAgICBmYWNpbmdNb2RlOiBjYW1lcmFGYWNpbmcsXG4gICAgICAgICAgd2lkdGg6IHsgaWRlYWw6IDE5MjAsIG1pbjogNjQwIH0sXG4gICAgICAgICAgaGVpZ2h0OiB7IGlkZWFsOiAxMDgwLCBtaW46IDQ4MCB9LFxuICAgICAgICB9LFxuICAgICAgICBhdWRpbzogZmFsc2UsXG4gICAgICB9O1xuXG4gICAgICBjb25zdCBzdHJlYW0gPSBhd2FpdCBuYXZpZ2F0b3IubWVkaWFEZXZpY2VzLmdldFVzZXJNZWRpYShjb25zdHJhaW50cyk7XG4gICAgICBzdHJlYW1SZWYuY3VycmVudCA9IHN0cmVhbTtcbiAgICAgIHNldFBlcm1pc3Npb25TdGF0ZShcImdyYW50ZWRcIik7XG5cbiAgICAgIGlmICh2aWRlb1JlZi5jdXJyZW50KSB7XG4gICAgICAgIHZpZGVvUmVmLmN1cnJlbnQuc3JjT2JqZWN0ID0gc3RyZWFtO1xuICAgICAgICBhd2FpdCB2aWRlb1JlZi5jdXJyZW50LnBsYXkoKS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgICAgIHNldFN0cmVhbUFjdGl2ZSh0cnVlKTtcblxuICAgICAgICAvLyBDaGVjayB0b3JjaCBjYXBhYmlsaXR5XG4gICAgICAgIGNvbnN0IHRyYWNrID0gc3RyZWFtLmdldFZpZGVvVHJhY2tzKClbMF07XG4gICAgICAgIGlmICh0cmFjayAmJiB0cmFjay5nZXRDYXBhYmlsaXRpZXMpIHtcbiAgICAgICAgICBjb25zdCBjYXBzID0gdHJhY2suZ2V0Q2FwYWJpbGl0aWVzKCkgYXMgYW55O1xuICAgICAgICAgIGlmIChjYXBzICYmIFwidG9yY2hcIiBpbiBjYXBzKSB7XG4gICAgICAgICAgICBzZXRIYXNUb3JjaCh0cnVlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBzY2FuTG9vcFJlZi5jdXJyZW50ID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHJ1bkRldGVjdGlvbkxvb3ApO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICBjb25zb2xlLndhcm4oXCJDYW1lcmEgc3RhcnQgZmFpbGVkOlwiLCBlcnIpO1xuICAgICAgaWYgKGVyci5uYW1lID09PSBcIk5vdEFsbG93ZWRFcnJvclwiIHx8IGVyci5uYW1lID09PSBcIlBlcm1pc3Npb25EZW5pZWRFcnJvclwiKSB7XG4gICAgICAgIHNldFBlcm1pc3Npb25TdGF0ZShcImRlbmllZFwiKTtcbiAgICAgICAgdG9hc3QuZXJyb3IoXCJDYW1lcmEgcGVybWlzc2lvbiBkZW5pZWQuIFBsZWFzZSBhbGxvdyBjYW1lcmEgYWNjZXNzIGluIGJyb3dzZXIgc2V0dGluZ3MuXCIpO1xuICAgICAgfSBlbHNlIGlmIChlcnIubmFtZSA9PT0gXCJOb3RGb3VuZEVycm9yXCIgfHwgZXJyLm5hbWUgPT09IFwiRGV2aWNlc05vdEZvdW5kRXJyb3JcIikge1xuICAgICAgICBzZXRQZXJtaXNzaW9uU3RhdGUoXCJ1bnN1cHBvcnRlZFwiKTtcbiAgICAgICAgdG9hc3QuZXJyb3IoXCJObyBjYW1lcmEgZm91bmQgb24gdGhpcyBkZXZpY2UuXCIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdG9hc3QuZXJyb3IoYFVuYWJsZSB0byBvcGVuIGNhbWVyYTogJHtlcnIubWVzc2FnZSB8fCBcIlVua25vd24gZXJyb3JcIn1gKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIFtjYW1lcmFGYWNpbmcsIHN0b3BDYW1lcmEsIHJ1bkRldGVjdGlvbkxvb3BdKTtcblxuICAvLyBUb2dnbGUgdG9yY2ggLyBmbGFzaGxpZ2h0XG4gIGNvbnN0IHRvZ2dsZVRvcmNoID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghc3RyZWFtUmVmLmN1cnJlbnQpIHJldHVybjtcbiAgICBjb25zdCB0cmFjayA9IHN0cmVhbVJlZi5jdXJyZW50LmdldFZpZGVvVHJhY2tzKClbMF07XG4gICAgaWYgKCF0cmFjaykgcmV0dXJuO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBuZXh0U3RhdGUgPSAhdG9yY2hPbjtcbiAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgdG9yY2ggY2FwYWJpbGl0eVxuICAgICAgYXdhaXQgdHJhY2suYXBwbHlDb25zdHJhaW50cyh7IGFkdmFuY2VkOiBbeyB0b3JjaDogbmV4dFN0YXRlIH1dIH0pO1xuICAgICAgc2V0VG9yY2hPbihuZXh0U3RhdGUpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgdG9hc3QuZXJyb3IoXCJGbGFzaGxpZ2h0IGNvdWxkIG5vdCBiZSB0b2dnbGVkIG9uIHRoaXMgY2FtZXJhLlwiKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gRmxpcCBjYW1lcmEgYmV0d2VlbiBmcm9udCAmIGJhY2tcbiAgY29uc3QgZmxpcENhbWVyYSA9ICgpID0+IHtcbiAgICBzZXRDYW1lcmFGYWNpbmcoKHByZXYpID0+IChwcmV2ID09PSBcImVudmlyb25tZW50XCIgPyBcInVzZXJcIiA6IFwiZW52aXJvbm1lbnRcIikpO1xuICB9O1xuXG4gIC8vIFRyaWdnZXIgY2FtZXJhIHN0YXJ0IG9uY2UgZ3JhbnRlZCBvciBvbiBhY3RpdmUgdmlld1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChwZXJtaXNzaW9uU3RhdGUgPT09IFwiZ3JhbnRlZFwiICYmICFjYXB0dXJlZEltYWdlKSB7XG4gICAgICBzdGFydENhbWVyYSgpO1xuICAgIH1cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgc3RvcENhbWVyYSgpO1xuICAgIH07XG4gIH0sIFtwZXJtaXNzaW9uU3RhdGUsIGNhbWVyYUZhY2luZywgc3RhcnRDYW1lcmEsIHN0b3BDYW1lcmEsIGNhcHR1cmVkSW1hZ2VdKTtcblxuICAvLyBFeGVjdXRlIEFJIHNjYW4gb24gcGF5bG9hZFxuICBjb25zdCBwcm9jZXNzSW1hZ2VGb3JBdXRoZW50aWNpdHkgPSBhc3luYyAoXG4gICAgYmFzZTY0OiBzdHJpbmcsXG4gICAgbWltZTogc3RyaW5nLFxuICAgIHByZXZpZXdVcmw6IHN0cmluZyxcbiAgICBmaWxlT2JqOiBGaWxlIHwgbnVsbCxcbiAgICBiYXJjb2RlRGF0YT86IHN0cmluZyxcbiAgICBtb2RlOiBJbnNwZWN0aW9uTW9kZSA9IGFjdGl2ZU1vZGVcbiAgKSA9PiB7XG4gICAgc2V0U2Nhbm5pbmcodHJ1ZSk7XG4gICAgc2V0Q2FwdHVyZWRJbWFnZShwcmV2aWV3VXJsKTtcbiAgICBzZXRDYXB0dXJlZEZpbGUoZmlsZU9iaik7XG4gICAgc3RvcENhbWVyYSgpO1xuXG4gICAgdHJ5IHtcbiAgICAgIHNldEFuYWx5emluZ1N0ZXAoXCJFeGVjdXRpbmcgZm9yZW5zaWMgZWRnZSAmIGxvZ28gZ2VvbWV0cnkgaW5zcGVjdGlvbi4uLlwiKTtcbiAgICAgIGF3YWl0IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIDIwMCkpO1xuXG4gICAgICBzZXRBbmFseXppbmdTdGVwKFxuICAgICAgICBtb2RlID09PSBcImJhcmNvZGVcIlxuICAgICAgICAgID8gXCJWYWxpZGF0aW5nIEdTMSBiYXJjb2RlIGNoZWNrc3VtICYgaW50ZXJuYXRpb25hbCByZWdpc3RyeS4uLlwiXG4gICAgICAgICAgOiBcIkFuYWx5emluZyB0eXBvZ3JhcGh5LCBzdGl0Y2hpbmcgZGVuc2l0eSAmIG1pY3JvLWVtYm9zc2luZy4uLlwiXG4gICAgICApO1xuXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBydW5BaVNjYW4oe1xuICAgICAgICBpbWFnZTogYmFzZTY0LFxuICAgICAgICBtaW1lVHlwZTogbWltZSxcbiAgICAgICAgYmFyY29kZTogYmFyY29kZURhdGEgfHwgZGV0ZWN0ZWRDb2RlPy5yYXdWYWx1ZSB8fCB1bmRlZmluZWQsXG4gICAgICAgIHFyRGF0YTogZGV0ZWN0ZWRDb2RlPy5mb3JtYXQgPT09IFwicXJfY29kZVwiID8gZGV0ZWN0ZWRDb2RlLnJhd1ZhbHVlIDogdW5kZWZpbmVkLFxuICAgICAgICBpbnNwZWN0aW9uTW9kZTogbW9kZSxcbiAgICAgICAgbWVkaWFUeXBlOiBcImltYWdlXCIsXG4gICAgICB9KTtcblxuICAgICAgc2V0QW5hbHl6aW5nU3RlcChcIlZlcmlmeWluZyBjb3Jwb3JhdGUgYnJhbmQgb3duZXJzaGlwICYgY291bnRlcmZlaXQgcmlzay4uLlwiKTtcbiAgICAgIHNldFNjYW5SZXN1bHQocmVzdWx0KTtcblxuICAgICAgLy8gQ2hlY2sgaWYgdGhpcyBicmFuZCBleGlzdHMgaW4gU3Rhc2ggb3IgVHJhc2ggZGF0YWJhc2VcbiAgICAgIGlmIChyZXN1bHQuYnJhbmRJbmZvPy5icmFuZE5hbWUpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBtYXRjaGVzID0gYXdhaXQgc2VhcmNoQnJhbmRzKHJlc3VsdC5icmFuZEluZm8uYnJhbmROYW1lKTtcbiAgICAgICAgICBpZiAobWF0Y2hlcyAmJiBtYXRjaGVzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHNldE1hdGNoZWRCcmFuZChtYXRjaGVzWzBdKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8vIGlnbm9yZVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHBsYXlTY2FuQ2hpbWUoKTtcbiAgICAgIGNvbnN0IHZlcmRpY3QgPSByZXN1bHQuY291bnRlcmZlaXRBc3Nlc3NtZW50Py52ZXJkaWN0O1xuICAgICAgaWYgKHZlcmRpY3QgPT09IFwibGVnaXRcIiB8fCB2ZXJkaWN0ID09PSBcImxpa2VseV9sZWdpdFwiKSB7XG4gICAgICAgIHRvYXN0LnN1Y2Nlc3MoYEF1dGhlbnRpY2l0eSBDb25maXJtZWQ6ICR7cmVzdWx0LmJyYW5kSW5mby5icmFuZE5hbWV9IGlzIFZlcmlmaWVkIExlZ2l0IWApO1xuICAgICAgfSBlbHNlIGlmICh2ZXJkaWN0ID09PSBcInN1c3BlY3RlZF9jb3VudGVyZmVpdFwiIHx8IHZlcmRpY3QgPT09IFwiaGlnaF9yaXNrX2Zha2VcIikge1xuICAgICAgICB0b2FzdC5lcnJvcihgQ291bnRlcmZlaXQgV2FybmluZzogSGlnaCByZXBsaWNhIHJpc2sgZGV0ZWN0ZWQgZm9yICR7cmVzdWx0LmJyYW5kSW5mby5icmFuZE5hbWV9LmApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdG9hc3QuaW5mbyhgSWRlbnRpZmllZDogJHtyZXN1bHQuYnJhbmRJbmZvLmJyYW5kTmFtZX0gKCR7cmVzdWx0LmJyYW5kSW5mby5icmFuZE93bmVyfSlgKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgdG9hc3QuZXJyb3IoZXJyLm1lc3NhZ2UgfHwgXCJBdXRoZW50aWNpdHkgc2NhbiBmYWlsZWRcIik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFNjYW5uaW5nKGZhbHNlKTtcbiAgICAgIHNldEFuYWx5emluZ1N0ZXAoXCJcIik7XG4gICAgfVxuICB9O1xuXG4gIC8vIENhcHR1cmUgZnJhbWUgZnJvbSBhY3RpdmUgY2FtZXJhXG4gIGNvbnN0IGNhcHR1cmVGcm9tQ2FtZXJhID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghdmlkZW9SZWYuY3VycmVudCkgcmV0dXJuO1xuICAgIGNvbnN0IHYgPSB2aWRlb1JlZi5jdXJyZW50O1xuICAgIGNvbnN0IGNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJjYW52YXNcIik7XG4gICAgY2FudmFzLndpZHRoID0gdi52aWRlb1dpZHRoIHx8IDEyODA7XG4gICAgY2FudmFzLmhlaWdodCA9IHYudmlkZW9IZWlnaHQgfHwgNzIwO1xuICAgIGNvbnN0IGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KFwiMmRcIik7XG4gICAgaWYgKCFjdHgpIHJldHVybjtcblxuICAgIGN0eC5kcmF3SW1hZ2UodiwgMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KTtcbiAgICBjb25zdCBkYXRhVXJsID0gY2FudmFzLnRvRGF0YVVSTChcImltYWdlL2pwZWdcIiwgMC45Mik7XG4gICAgY29uc3QgYmFzZTY0ID0gZGF0YVVybC5zcGxpdChcIixcIilbMV07XG5cbiAgICAvLyBEZXRlY3QgYmFyY29kZSBvbiBzbmFwc2hvdFxuICAgIGNvbnN0IGJhcmNvZGVTbmFwc2hvdCA9IGF3YWl0IGRldGVjdEJhcmNvZGVPclFyKGNhbnZhcyk7XG4gICAgY29uc3QgYmFyY29kZVZhbCA9IGJhcmNvZGVTbmFwc2hvdD8ucmF3VmFsdWUgfHwgZGV0ZWN0ZWRDb2RlPy5yYXdWYWx1ZTtcblxuICAgIGNvbnN0IGJsb2IgPSBhd2FpdCAoYXdhaXQgZmV0Y2goZGF0YVVybCkpLmJsb2IoKTtcbiAgICBjb25zdCBmaWxlID0gbmV3IEZpbGUoW2Jsb2JdLCBgYXV0aC1zY2FuLSR7RGF0ZS5ub3coKX0uanBnYCwgeyB0eXBlOiBcImltYWdlL2pwZWdcIiB9KTtcblxuICAgIGF3YWl0IHByb2Nlc3NJbWFnZUZvckF1dGhlbnRpY2l0eShiYXNlNjQsIFwiaW1hZ2UvanBlZ1wiLCBkYXRhVXJsLCBmaWxlLCBiYXJjb2RlVmFsLCBhY3RpdmVNb2RlKTtcbiAgfTtcblxuICAvLyBVcGxvYWQgcGhvdG8vdmlkZW8gZmFsbGJhY2tcbiAgY29uc3QgaGFuZGxlRmlsZVVwbG9hZCA9IGFzeW5jIChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgIGlmICghZmlsZSkgcmV0dXJuO1xuXG4gICAgY29uc3QgaXNWaWRlbyA9IGZpbGUudHlwZS5zdGFydHNXaXRoKFwidmlkZW8vXCIpO1xuICAgIHNldFNjYW5uaW5nKHRydWUpO1xuICAgIHNldEFuYWx5emluZ1N0ZXAoaXNWaWRlbyA/IFwiRXh0cmFjdGluZyByZXByZXNlbnRhdGl2ZSB2aWRlbyBmcmFtZS4uLlwiIDogXCJPcHRpbWl6aW5nIGltYWdlIHJlc29sdXRpb24uLi5cIik7XG5cbiAgICB0cnkge1xuICAgICAgaWYgKGlzVmlkZW8pIHtcbiAgICAgICAgY29uc3QgeyBkYXRhVXJsLCBiYXNlNjQsIG1pbWVUeXBlLCBxckRhdGEsIGJhcmNvZGVEYXRhIH0gPSBhd2FpdCBleHRyYWN0RnJhbWVGcm9tVmlkZW8oZmlsZSk7XG4gICAgICAgIGF3YWl0IHByb2Nlc3NJbWFnZUZvckF1dGhlbnRpY2l0eShiYXNlNjQsIG1pbWVUeXBlLCBkYXRhVXJsLCBmaWxlLCBiYXJjb2RlRGF0YSB8fCBxckRhdGEgfHwgdW5kZWZpbmVkLCBhY3RpdmVNb2RlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHsgZGF0YVVybCwgYmFzZTY0LCBtaW1lVHlwZSwgcXJEYXRhLCBiYXJjb2RlRGF0YSB9ID0gYXdhaXQgZmlsZVRvT3B0aW1pemVkQmFzZTY0KGZpbGUpO1xuICAgICAgICBhd2FpdCBwcm9jZXNzSW1hZ2VGb3JBdXRoZW50aWNpdHkoYmFzZTY0LCBtaW1lVHlwZSwgZGF0YVVybCwgZmlsZSwgYmFyY29kZURhdGEgfHwgcXJEYXRhIHx8IHVuZGVmaW5lZCwgYWN0aXZlTW9kZSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIHRvYXN0LmVycm9yKGVyci5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIHByb2Nlc3MgbWVkaWEgZmlsZVwiKTtcbiAgICAgIHNldFNjYW5uaW5nKGZhbHNlKTtcbiAgICAgIHNldEFuYWx5emluZ1N0ZXAoXCJcIik7XG4gICAgfVxuICB9O1xuXG4gIC8vIE1hbnVhbCBiYXJjb2RlIGxvb2t1cFxuICBjb25zdCBoYW5kbGVNYW51YWxCYXJjb2RlU3VibWl0ID0gYXN5bmMgKGU/OiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBpZiAoZSkgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGNvbnN0IGNvZGUgPSBtYW51YWxCYXJjb2RlLnRyaW0oKTtcbiAgICBpZiAoIWNvZGUpIHtcbiAgICAgIHRvYXN0LmVycm9yKFwiUGxlYXNlIGVudGVyIGEgYmFyY29kZSBudW1iZXJcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGNvdW50cnkgPSBnZXRHczFDb3VudHJ5UHJlZml4KGNvZGUpO1xuICAgIHNldERldGVjdGVkQ29kZSh7XG4gICAgICBmb3JtYXQ6IFwiYmFyY29kZVwiLFxuICAgICAgcmF3VmFsdWU6IGNvZGUsXG4gICAgICBjb3VudHJ5LFxuICAgIH0pO1xuICAgIHBsYXlTY2FuQ2hpbWUoKTtcbiAgICBhd2FpdCBwcm9jZXNzSW1hZ2VGb3JBdXRoZW50aWNpdHkoXCJcIiwgXCJpbWFnZS9qcGVnXCIsIFwiXCIsIG51bGwsIGNvZGUsIFwiYmFyY29kZVwiKTtcbiAgfTtcblxuICAvLyBSZXNldCBzY2FuIGFuZCByZXR1cm4gdG8gbGl2ZSBjYW1lcmFcbiAgY29uc3QgaGFuZGxlUmVzZXQgPSAoKSA9PiB7XG4gICAgc2V0Q2FwdHVyZWRJbWFnZShudWxsKTtcbiAgICBzZXRDYXB0dXJlZEZpbGUobnVsbCk7XG4gICAgc2V0U2NhblJlc3VsdChudWxsKTtcbiAgICBzZXRNYXRjaGVkQnJhbmQobnVsbCk7XG4gICAgc2V0RGV0ZWN0ZWRDb2RlKG51bGwpO1xuICAgIHN0YXJ0Q2FtZXJhKCk7XG4gIH07XG5cbiAgLy8gQXBwbHkgdG8gcG9zdFxuICBjb25zdCBoYW5kbGVBcHBseVBvc3QgPSAoKSA9PiB7XG4gICAgaWYgKCFzY2FuUmVzdWx0KSByZXR1cm47XG4gICAgaWYgKG9uQXBwbHlUb1Bvc3QpIHtcbiAgICAgIG9uQXBwbHlUb1Bvc3Qoe1xuICAgICAgICBicmFuZE5hbWU6IHNjYW5SZXN1bHQuYnJhbmRJbmZvLmJyYW5kTmFtZSxcbiAgICAgICAgYnJhbmRPd25lcjogc2NhblJlc3VsdC5icmFuZEluZm8uYnJhbmRPd25lcixcbiAgICAgICAgcHJvZHVjdE5hbWU6IHNjYW5SZXN1bHQuYnJhbmRJbmZvLnByb2R1Y3ROYW1lLFxuICAgICAgICBjYXRlZ29yeTogc2NhblJlc3VsdC5icmFuZEluZm8uY2F0ZWdvcnksXG4gICAgICAgIG1hdGNoZWRCcmFuZElkOiBtYXRjaGVkQnJhbmQ/LmlkLFxuICAgICAgICBmaWxlOiBjYXB0dXJlZEZpbGUsXG4gICAgICAgIHNjYW5SZXN1bHQsXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKG9uQ2xvc2UpIG9uQ2xvc2UoKTtcbiAgfTtcblxuICAvLyBDb3B5IG9mZmljaWFsIGF1dGhlbnRpY2l0eSBjZXJ0aWZpY2F0ZSB0ZXh0XG4gIGNvbnN0IGhhbmRsZUNvcHlSZXBvcnQgPSAoKSA9PiB7XG4gICAgaWYgKCFzY2FuUmVzdWx0KSByZXR1cm47XG4gICAgY29uc3QgYiA9IHNjYW5SZXN1bHQuYnJhbmRJbmZvO1xuICAgIGNvbnN0IGMgPSBzY2FuUmVzdWx0LmNvdW50ZXJmZWl0QXNzZXNzbWVudDtcbiAgICBjb25zdCByZXBvcnRUZXh0ID0gYFtTVEFTSCBPUiBUUkFTSCBBVVRIRU5USUNJVFkgQ0VSVElGSUNBVEVdXG5Qcm9kdWN0OiAke2IucHJvZHVjdE5hbWUgfHwgYi5icmFuZE5hbWV9XG5CcmFuZDogJHtiLmJyYW5kTmFtZX1cbkNvcnBvcmF0ZSBPd25lcjogJHtiLmJyYW5kT3duZXJ9ICgke2IuY291bnRyeU9mT3JpZ2lufSlcbkF1dGhlbnRpY2l0eSBWZXJkaWN0OiAke2M/LnZlcmRpY3Q/LnRvVXBwZXJDYXNlKCkgfHwgc2NhblJlc3VsdC5hdXRoZW50aWNpdHkudmVyZGljdFN0YXR1c31cbkxlZ2l0aW1hY3kgU2NvcmU6ICR7Yz8uYXV0aGVudGljaXR5U2NvcmUgPz8gc2NhblJlc3VsdC5hdXRoZW50aWNpdHkuc2NvcmV9JVxuQ291bnRlcmZlaXQgUmlzazogJHtjPy5jb3VudGVyZmVpdFJpc2tTY29yZSA/PyAwfSVcbkxvZ28gSW5zcGVjdGlvbjogJHtjPy5sb2dvSW5zcGVjdGlvbiB8fCBcIlZlcmlmaWVkIHR5cG9ncmFwaHlcIn1cbkJhcmNvZGUgLyBUYWdzOiAke2IucXJPckJhcmNvZGVEZWNvZGVkIHx8IGRldGVjdGVkQ29kZT8ucmF3VmFsdWUgfHwgXCJTdGFuZGFyZCBjb21wbGlhbnRcIn1cblZlcmlmaWVkIG9uIFN0YXNoIE9yIFRyYXNoIEJyYW5kIEJhcm9tZXRlcmA7XG5cbiAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChyZXBvcnRUZXh0KTtcbiAgICB0b2FzdC5zdWNjZXNzKFwiQXV0aGVudGljaXR5IGF1ZGl0IGNlcnRpZmljYXRlIGNvcGllZCB0byBjbGlwYm9hcmQhXCIpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2BmbGV4IGZsZXgtY29sIHctZnVsbCBiZy1jYXJkIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItYm9yZGVyIHNoYWRvdy0yeGwgb3ZlcmZsb3ctaGlkZGVuICR7c3RhbmRhbG9uZSA/IFwibWF4LXctNHhsIG14LWF1dG9cIiA6IFwiXCJ9YH0+XG4gICAgICB7LyogVG9wIEJhciBIZWFkZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC01IHB5LTQgYm9yZGVyLWIgYm9yZGVyLWJvcmRlciBiZy1tdXRlZC8zMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtOSB3LTkgcm91bmRlZC14bCBiZy1wcmltYXJ5LzEwIHRleHQtcHJpbWFyeSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctaW5uZXJcIj5cbiAgICAgICAgICAgIDxTY2FuIGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIHNtOnRleHQtbGcgZm9udC1ib2xkIGZvbnQtZGlzcGxheSBsZWFkaW5nLXRpZ2h0IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIHt0KFwic2Nhbm5lci50aXRsZVwiLCB7IGRlZmF1bHRWYWx1ZTogXCJBdXRoZW50aWNpdHkgJiBBbnRpLUNvdW50ZXJmZWl0IFNjYW5uZXJcIiB9KX1cbiAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCIgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1tb25vIGJvcmRlci1wcmltYXJ5LzMwIHRleHQtcHJpbWFyeSBiZy1wcmltYXJ5LzVcIj5cbiAgICAgICAgICAgICAgICBBSSBGb3JlbnNpYyB2Mi41XG4gICAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAge3QoXCJzY2FubmVyLnN1YnRpdGxlXCIsIHsgZGVmYXVsdFZhbHVlOiBcIlNjYW4gcHJvZHVjdCBiYXJjb2RlcywgbHV4dXJ5IGxvZ29zLCBhbmQgY2FyZSB0YWdzIHRvIHZlcmlmeSBnZW51aW5lIHZzLiBjb3VudGVyZmVpdFwiIH0pfVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogTW9kZSBTZWxlY3RvciBQaWxsIEJ1dHRvbnMgKHdoZW4gb24gY2FtZXJhIHZpZXcpICovfVxuICAgICAgICB7IXNjYW5SZXN1bHQgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGJnLWJhY2tncm91bmQvODAgcC0xIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ib3JkZXIgdGV4dC14c1wiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVNb2RlKFwiYmFyY29kZVwiKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41ICR7XG4gICAgICAgICAgICAgICAgYWN0aXZlTW9kZSA9PT0gXCJiYXJjb2RlXCJcbiAgICAgICAgICAgICAgICAgID8gXCJiZy1wcmltYXJ5IHRleHQtcHJpbWFyeS1mb3JlZ3JvdW5kIHNoYWRvdy1zbVwiXG4gICAgICAgICAgICAgICAgICA6IFwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGhvdmVyOnRleHQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8UXJDb2RlIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz4ge3QoXCJzY2FubmVyLm1vZGVCYXJjb2RlXCIsIHsgZGVmYXVsdFZhbHVlOiBcIkJhcmNvZGUgJiBRUlwiIH0pfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZU1vZGUoXCJsb2dvXCIpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSByb3VuZGVkLWxnIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgJHtcbiAgICAgICAgICAgICAgICBhY3RpdmVNb2RlID09PSBcImxvZ29cIlxuICAgICAgICAgICAgICAgICAgPyBcImJnLXByaW1hcnkgdGV4dC1wcmltYXJ5LWZvcmVncm91bmQgc2hhZG93LXNtXCJcbiAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LW11dGVkLWZvcmVncm91bmQgaG92ZXI6dGV4dC1mb3JlZ3JvdW5kXCJcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxUYWcgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPiB7dChcInNjYW5uZXIubW9kZUxvZ29cIiwgeyBkZWZhdWx0VmFsdWU6IFwiTG9nbyAmIFRhZ1wiIH0pfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZU1vZGUoXCJmdWxsX3Byb2R1Y3RcIil9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHJvdW5kZWQtbGcgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSAke1xuICAgICAgICAgICAgICAgIGFjdGl2ZU1vZGUgPT09IFwiZnVsbF9wcm9kdWN0XCJcbiAgICAgICAgICAgICAgICAgID8gXCJiZy1wcmltYXJ5IHRleHQtcHJpbWFyeS1mb3JlZ3JvdW5kIHNoYWRvdy1zbVwiXG4gICAgICAgICAgICAgICAgICA6IFwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGhvdmVyOnRleHQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8RXllIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz4ge3QoXCJzY2FubmVyLm1vZGVGdWxsUHJvZHVjdFwiLCB7IGRlZmF1bHRWYWx1ZTogXCJGdWxsIFByb2R1Y3RcIiB9KX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBNYWluIFZpZXdwb3J0IENvbnRlbnQgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBzbTpwLTYgc3BhY2UteS01XCI+XG4gICAgICAgIHsvKiBJZiBTdGlsbCBMaXZlIENhbWVyYSBvciBQcmVwYXJpbmcgKi99XG4gICAgICAgIHshc2NhblJlc3VsdCAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgYXNwZWN0LXZpZGVvIHNtOmFzcGVjdC1bMTYvOV0gbWF4LWgtWzQ2MHB4XSByb3VuZGVkLTJ4bCBvdmVyZmxvdy1oaWRkZW4gYmctYmxhY2sgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hhZG93LWlubmVyIGdyb3VwXCI+XG4gICAgICAgICAgICB7LyogTGl2ZSBWaWRlbyBGZWVkIChCYWNrZ3JvdW5kIExheWVyKSAqL31cbiAgICAgICAgICAgIDx2aWRlb1xuICAgICAgICAgICAgICByZWY9e3ZpZGVvUmVmfVxuICAgICAgICAgICAgICBhdXRvUGxheVxuICAgICAgICAgICAgICBwbGF5c0lubGluZVxuICAgICAgICAgICAgICBtdXRlZFxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BhYnNvbHV0ZSBpbnNldC0wIHctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyIHBvaW50ZXItZXZlbnRzLW5vbmUgdHJhbnNpdGlvbi1vcGFjaXR5IGR1cmF0aW9uLTMwMCAke1xuICAgICAgICAgICAgICAgIHN0cmVhbUFjdGl2ZSAmJiAhc2Nhbm5pbmcgPyBcIm9wYWNpdHktMTAwXCIgOiBcIm9wYWNpdHktMFwiXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgey8qIFBlcm1pc3Npb24gUHJvbXB0IFNjcmVlbiAtIENlbnRlcmVkIGluIHRoZSBtaWRkbGUgKi99XG4gICAgICAgICAgICB7cGVybWlzc2lvblN0YXRlID09PSBcInByb21wdFwiICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwIHctZnVsbCBtYXgtdy1tZCBteC1hdXRvIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtY2VudGVyIHAtNiBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gaC0xNiB3LTE2IHJvdW5kZWQtMnhsIGJnLXByaW1hcnkvMjAgdGV4dC1wcmltYXJ5IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJvcmRlciBib3JkZXItcHJpbWFyeS8zMCBzaGFkb3ctbGdcIj5cbiAgICAgICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwiaC04IHctOFwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNSB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj57dChcInNjYW5uZXIuY2FtZXJhQWNjZXNzUmVxdWlyZWRcIiwgeyBkZWZhdWx0VmFsdWU6IFwiQ2FtZXJhIEFjY2VzcyBSZXF1aXJlZFwiIH0pfTwvaDM+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtd2hpdGUvODAgbWF4LXctc20gbXgtYXV0byBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAge3QoXCJzY2FubmVyLmNhbWVyYUFjY2Vzc0Rlc2NcIiwgeyBkZWZhdWx0VmFsdWU6IFwiQWxsb3cgY2FtZXJhIGFjY2VzcyB0byBpbnNwZWN0IHBoeXNpY2FsIHBhY2thZ2luZywgYmFyY29kZXMsIGx1eHVyeSBsb2dvcywgYW5kIHZlcmlmeSBpZiB0aGUgcHJvZHVjdCBpcyBsZWdpdCBvciBmYWtlLlwiIH0pfVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBnYXAtMi41IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBwdC0yIHctZnVsbCBtYXgtdy14cyBzbTptYXgtdy1zbSBteC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9e3N0YXJ0Q2FtZXJhfSBjbGFzc05hbWU9XCJ3LWZ1bGwgc206dy1hdXRvIGdhcC0yIGZvbnQtc2VtaWJvbGQgc2hhZG93LW1kXCI+XG4gICAgICAgICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IHt0KFwic2Nhbm5lci5ncmFudFBlcm1pc3Npb25cIiwgeyBkZWZhdWx0VmFsdWU6IFwiR3JhbnQgQ2FtZXJhIFBlcm1pc3Npb25cIiB9KX1cbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGZpbGVJbnB1dFJlZi5jdXJyZW50Py5jbGljaygpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgc206dy1hdXRvIGdhcC0yIHRleHQtd2hpdGUgYm9yZGVyLXdoaXRlLzIwIGJnLXdoaXRlLzEwIGhvdmVyOmJnLXdoaXRlLzIwXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFVwbG9hZCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz4ge3QoXCJzY2FubmVyLnVwbG9hZFBob3RvSW5zdGVhZFwiLCB7IGRlZmF1bHRWYWx1ZTogXCJVcGxvYWQgUGhvdG8gSW5zdGVhZFwiIH0pfVxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIFBlcm1pc3Npb24gRGVuaWVkIFNjcmVlbiAtIENlbnRlcmVkIGluIHRoZSBtaWRkbGUgKi99XG4gICAgICAgICAgICB7cGVybWlzc2lvblN0YXRlID09PSBcImRlbmllZFwiICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwIHctZnVsbCBtYXgtdy1tZCBteC1hdXRvIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtY2VudGVyIHAtNiBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gaC0xNCB3LTE0IHJvdW5kZWQtMnhsIGJnLWRlc3RydWN0aXZlLzIwIHRleHQtZGVzdHJ1Y3RpdmUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyIGJvcmRlci1kZXN0cnVjdGl2ZS8zMCBzaGFkb3ctbGdcIj5cbiAgICAgICAgICAgICAgICAgIDxTaGllbGRBbGVydCBjbGFzc05hbWU9XCJoLTcgdy03XCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMSB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtd2hpdGVcIj57dChcInNjYW5uZXIuY2FtZXJhQmxvY2tlZFwiLCB7IGRlZmF1bHRWYWx1ZTogXCJDYW1lcmEgUGVybWlzc2lvbiBXYXMgQmxvY2tlZFwiIH0pfTwvaDM+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtd2hpdGUvODAgbWF4LXctc20gbXgtYXV0byBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAge3QoXCJzY2FubmVyLmNhbWVyYUJsb2NrZWREZXNjXCIsIHsgZGVmYXVsdFZhbHVlOiBcIllvdXIgYnJvd3NlciBoYXMgcmVzdHJpY3RlZCBjYW1lcmEgYWNjZXNzIGZvciB0aGlzIHBhZ2UuIENsaWNrIHRoZSBjYW1lcmEgaWNvbiBvciBwYWRsb2NrIGluIHlvdXIgYnJvd3NlcidzIGFkZHJlc3MgYmFyIHRvIGNoYW5nZSBwZXJtaXNzaW9ucyB0byBBbGxvdy5cIiB9KX1cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgZ2FwLTIganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHB0LTIgdy1mdWxsIG1heC13LXhzIHNtOm1heC13LXNtIG14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgIDxCdXR0b24gb25DbGljaz17c3RhcnRDYW1lcmF9IHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgc206dy1hdXRvIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxSZWZyZXNoQ3cgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IHt0KFwic2Nhbm5lci5yZXRyeUNhbWVyYVwiLCB7IGRlZmF1bHRWYWx1ZTogXCJSZXRyeSBDYW1lcmEgQWNjZXNzXCIgfSl9XG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxCdXR0b24gb25DbGljaz17KCkgPT4gZmlsZUlucHV0UmVmLmN1cnJlbnQ/LmNsaWNrKCl9IGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPFVwbG9hZCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz4ge3QoXCJzY2FubmVyLnVwbG9hZEZpbGVcIiwgeyBkZWZhdWx0VmFsdWU6IFwiQ2hvb3NlIEZpbGUgdG8gSW5zcGVjdFwiIH0pfVxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIERldmljZSBVbnN1cHBvcnRlZCBTY3JlZW4gLSBDZW50ZXJlZCBpbiB0aGUgbWlkZGxlICovfVxuICAgICAgICAgICAge3Blcm1pc3Npb25TdGF0ZSA9PT0gXCJ1bnN1cHBvcnRlZFwiICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwIHctZnVsbCBtYXgtdy1tZCBteC1hdXRvIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtY2VudGVyIHAtNiBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm14LWF1dG8gaC0xNCB3LTE0IHJvdW5kZWQtMnhsIGJnLWFtYmVyLTUwMC8yMCB0ZXh0LWFtYmVyLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBzaGFkb3ctbGdcIj5cbiAgICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cImgtNyB3LTdcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC13aGl0ZVwiPnt0KFwic2Nhbm5lci5ub1dlYmNhbVwiLCB7IGRlZmF1bHRWYWx1ZTogXCJObyBXZWJjYW0gRGV0ZWN0ZWRcIiB9KX08L2gzPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXdoaXRlLzgwIG1heC13LXNtIG14LWF1dG8gbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgIHt0KFwic2Nhbm5lci5ub1dlYmNhbURlc2NcIiwgeyBkZWZhdWx0VmFsdWU6IFwiTm8gaGFyZHdhcmUgY2FtZXJhIHdhcyBkZXRlY3RlZC4gWW91IGNhbiB1cGxvYWQgYSBwaG90byBvciB2aWRlbyByZWNvcmRpbmcgb2YgdGhlIGl0ZW0uXCIgfSl9XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBmaWxlSW5wdXRSZWYuY3VycmVudD8uY2xpY2soKX0gY2xhc3NOYW1lPVwiZ2FwLTIgdy1mdWxsIG1heC13LXhzIG14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgIDxVcGxvYWQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IHt0KFwic2Nhbm5lci51cGxvYWRQcm9kdWN0TWVkaWFcIiwgeyBkZWZhdWx0VmFsdWU6IFwiVXBsb2FkIFByb2R1Y3QgTWVkaWFcIiB9KX1cbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogUmV0aWNsZSAmIFRhcmdldGluZyBIVUQgT3ZlcmxheSAqL31cbiAgICAgICAgICAgIHtzdHJlYW1BY3RpdmUgJiYgIXNjYW5uaW5nICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIHBvaW50ZXItZXZlbnRzLW5vbmUgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICB7LyogTW9kZTogQmFyY29kZSAmIFFSIFJldGljbGUgKi99XG4gICAgICAgICAgICAgICAge2FjdGl2ZU1vZGUgPT09IFwiYmFyY29kZVwiICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy03MiBzbTp3LTk2IGgtNDggYm9yZGVyLTIgYm9yZGVyLWVtZXJhbGQtNDAwLzgwIHJvdW5kZWQtMnhsIHNoYWRvdy1bMF8wXzIwcHhfcmdiYSg1MiwyMTEsMTUzLDAuMyldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICB7LyogQ29ybmVyIGFjY2VudHMgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC0xIC1sZWZ0LTEgdy02IGgtNiBib3JkZXItdC00IGJvcmRlci1sLTQgYm9yZGVyLWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtdG9wLTEgLXJpZ2h0LTEgdy02IGgtNiBib3JkZXItdC00IGJvcmRlci1yLTQgYm9yZGVyLWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtYm90dG9tLTEgLWxlZnQtMSB3LTYgaC02IGJvcmRlci1iLTQgYm9yZGVyLWwtNCBib3JkZXItZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC1ib3R0b20tMSAtcmlnaHQtMSB3LTYgaC02IGJvcmRlci1iLTQgYm9yZGVyLXItNCBib3JkZXItZW1lcmFsZC00MDBcIiAvPlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBBbmltYXRlZCBzY2FubmluZyBsYXNlciBsaW5lICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXgtMCBoLTAuNSBiZy1ncmFkaWVudC10by1yIGZyb20tdHJhbnNwYXJlbnQgdmlhLWVtZXJhbGQtNDAwIHRvLXRyYW5zcGFyZW50IHNoYWRvdy1bMF8wXzEycHhfIzM0ZDM5OV0gYW5pbWF0ZS1bYm91bmNlXzJzX2luZmluaXRlXVwiIC8+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIGZvbnQtbW9ubyB0cmFja2luZy13aWRlciB0ZXh0LWVtZXJhbGQtMzAwIGJnLWJsYWNrLzYwIHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgYmFja2Ryb3AtYmx1ci1zbSBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgR1MxIEJBUkNPREUgLyBVUEMgLyBRUiBSRVRJQ0xFXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHsvKiBNb2RlOiBMb2dvICYgVGFnIEluc3BlY3Rpb24gKi99XG4gICAgICAgICAgICAgICAge2FjdGl2ZU1vZGUgPT09IFwibG9nb1wiICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy01NiBzbTp3LTY0IGgtNTYgc206aC02NCBib3JkZXItMiBib3JkZXItYW1iZXItNDAwLzgwIHJvdW5kZWQtMnhsIHNoYWRvdy1bMF8wXzIwcHhfcmdiYSgyNTEsMTkxLDM2LDAuMyldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC0xIC1sZWZ0LTEgdy03IGgtNyBib3JkZXItdC00IGJvcmRlci1sLTQgYm9yZGVyLWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC0xIC1yaWdodC0xIHctNyBoLTcgYm9yZGVyLXQtNCBib3JkZXItci00IGJvcmRlci1hbWJlci00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC1ib3R0b20tMSAtbGVmdC0xIHctNyBoLTcgYm9yZGVyLWItNCBib3JkZXItbC00IGJvcmRlci1hbWJlci00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC1ib3R0b20tMSAtcmlnaHQtMSB3LTcgaC03IGJvcmRlci1iLTQgYm9yZGVyLXItNCBib3JkZXItYW1iZXItNDAwXCIgLz5cblxuICAgICAgICAgICAgICAgICAgICB7LyogQ3Jvc3NoYWlyIGxpbmVzICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTAuNSBiZy1hbWJlci00MDAvNjBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtOCB3LTAuNSBiZy1hbWJlci00MDAvNjAgYWJzb2x1dGVcIiAvPlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTMgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCBmb250LW1vbm8gdHJhY2tpbmctd2lkZXIgdGV4dC1hbWJlci0zMDAgYmctYmxhY2svNjAgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCBiYWNrZHJvcC1ibHVyLXNtIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgTE9HTyAvIEVNQlJPSURFUlkgVEFSR0VUXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHsvKiBNb2RlOiBGdWxsIFByb2R1Y3QgJiBDcmFmdHNtYW5zaGlwICovfVxuICAgICAgICAgICAgICAgIHthY3RpdmVNb2RlID09PSBcImZ1bGxfcHJvZHVjdFwiICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy00LzUgc206dy0zLzQgaC0zLzQgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItcHJpbWFyeS83MCByb3VuZGVkLTN4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC00IHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgZm9udC1tb25vIHRyYWNraW5nLXdpZGVyIHRleHQtcHJpbWFyeSBiZy1ibGFjay82MCBweC0zIHB5LTEgcm91bmRlZC1mdWxsIGJhY2tkcm9wLWJsdXItc20gYm9yZGVyIGJvcmRlci1wcmltYXJ5LzMwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgRlVMTCBQUk9EVUNUIC8gU0VBTVMgJiBNQVRFUklBTFNcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgey8qIFN1YnRpdGxlIGhlbHBlciBiYWRnZSAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS00IGJnLWJsYWNrLzc1IGJhY2tkcm9wLWJsdXItbWQgcHgtNCBweS0xLjUgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItd2hpdGUvMTAgdGV4dC14cyB0ZXh0LXdoaXRlLzkwIGZvbnQtbWVkaXVtIHNoYWRvdy1sZyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaC0yIHctMiByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC00MDAgYW5pbWF0ZS1waW5nXCIgLz5cbiAgICAgICAgICAgICAgICAgIHthY3RpdmVNb2RlID09PSBcImJhcmNvZGVcIiAmJiBcIlBvaW50IGF0IFVQQy1BLCBFQU4tMTMsIG9yIFFSIGNvZGUgb24gcmV0YWlsIGJveCAvIHRhZ1wifVxuICAgICAgICAgICAgICAgICAge2FjdGl2ZU1vZGUgPT09IFwibG9nb1wiICYmIFwiQ2VudGVyIHRoZSBicmFuZCBsb2dvLCBtZXRhbCBiYWRnZSwgb3IgbmVjayB0YWdcIn1cbiAgICAgICAgICAgICAgICAgIHthY3RpdmVNb2RlID09PSBcImZ1bGxfcHJvZHVjdFwiICYmIFwiRml0IHRoZSBlbnRpcmUgZ2FybWVudCwgc25lYWtlciwgYm90dGxlIG9yIGFjY2Vzc29yeVwifVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBEZXRlY3RlZCBCYXJjb2RlIFRvYXN0IFN0cmlwICovfVxuICAgICAgICAgICAge2RldGVjdGVkQ29kZSAmJiBzdHJlYW1BY3RpdmUgJiYgIXNjYW5uaW5nICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNCBpbnNldC14LTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJnLWVtZXJhbGQtOTUwLzkwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvNTAgYmFja2Ryb3AtYmx1ci1tZCBweC00IHB5LTIgcm91bmRlZC14bCB0ZXh0LXdoaXRlIHNoYWRvdy14bCB6LTIwIGFuaW1hdGUtaW4gZmFkZS1pblwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTcgdy03IHJvdW5kZWQtbGcgYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIGZvbnQtbW9ubyB0cmFja2luZy13aWRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2RldGVjdGVkQ29kZS5mb3JtYXQudG9VcHBlckNhc2UoKX06IHtkZXRlY3RlZENvZGUucmF3VmFsdWV9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICB7ZGV0ZWN0ZWRDb2RlLmNvdW50cnkgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1lbWVyYWxkLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgR1MxIE9yaWdpbjoge2RldGVjdGVkQ29kZS5jb3VudHJ5fVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17Y2FwdHVyZUZyb21DYW1lcmF9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTUwMCB0ZXh0LXdoaXRlIGZvbnQtc2VtaWJvbGQgdGV4dC14cyBoLTggcHgtM1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgVmVyaWZ5IE5vdyA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJoLTMgdy0zIG1sLTFcIiAvPlxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBUb3AgUmlnaHQgQ2FtZXJhIENvbnRyb2xzIChUb3JjaCwgRmxpcCkgKi99XG4gICAgICAgICAgICB7c3RyZWFtQWN0aXZlICYmICFzY2FubmluZyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTQgcmlnaHQtNCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB6LTIwXCI+XG4gICAgICAgICAgICAgICAge2hhc1RvcmNoICYmIChcbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImljb25cIlxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwic2Vjb25kYXJ5XCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17dG9nZ2xlVG9yY2h9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGgtOSB3LTkgcm91bmRlZC14bCBiYWNrZHJvcC1ibHVyLW1kICR7XG4gICAgICAgICAgICAgICAgICAgICAgdG9yY2hPbiA/IFwiYmctYW1iZXItNDAwIHRleHQtYmxhY2sgaG92ZXI6YmctYW1iZXItMzAwXCIgOiBcImJnLWJsYWNrLzYwIHRleHQtd2hpdGUgaG92ZXI6YmctYmxhY2svODBcIlxuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9e3RvcmNoT24gPyBcIlR1cm4gZmxhc2hsaWdodCBvZmZcIiA6IFwiVHVybiBmbGFzaGxpZ2h0IG9uXCJ9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHt0b3JjaE9uID8gPFphcCBjbGFzc05hbWU9XCJoLTQgdy00IGZpbGwtY3VycmVudFwiIC8+IDogPFphcE9mZiBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz59XG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImljb25cIlxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInNlY29uZGFyeVwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtmbGlwQ2FtZXJhfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC05IHctOSByb3VuZGVkLXhsIGJnLWJsYWNrLzYwIHRleHQtd2hpdGUgaG92ZXI6YmctYmxhY2svODAgYmFja2Ryb3AtYmx1ci1tZFwiXG4gICAgICAgICAgICAgICAgICB0aXRsZT1cIlN3aXRjaCBGcm9udC9SZWFyIENhbWVyYVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFJlZnJlc2hDdyBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogQW5hbHl6aW5nIFByb2dyZXNzIFN0YXRlICovfVxuICAgICAgICAgICAge3NjYW5uaW5nICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWJsYWNrLzg1IGJhY2tkcm9wLWJsdXItbWQgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC02IHRleHQtY2VudGVyIHotMzAgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTIwIHctMjAgcm91bmRlZC1mdWxsIGJvcmRlci00IGJvcmRlci1wcmltYXJ5LzIwIGJvcmRlci10LXByaW1hcnkgYW5pbWF0ZS1zcGluXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJoLTggdy04IHRleHQtcHJpbWFyeSBhYnNvbHV0ZSBhbmltYXRlLXB1bHNlXCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41IG1heC13LXNtXCI+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGZvbnQtZGlzcGxheVwiPlxuICAgICAgICAgICAgICAgICAgICBNdWx0aW1vZGFsIEZvcmVuc2ljIEluc3BlY3Rpb25cbiAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtd2hpdGUvNzAgbWluLWgtNlwiPlxuICAgICAgICAgICAgICAgICAgICB7YW5hbHl6aW5nU3RlcCB8fCBcIkV4YW1pbmluZyBwaXhlbHMsIHR5cG9ncmFwaHkgJiBjb3Jwb3JhdGUgbGluZWFnZS4uLlwifVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxQcm9ncmVzcyB2YWx1ZT17NjV9IGNsYXNzTmFtZT1cInctNDggaC0xLjUgYmctd2hpdGUvMTBcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIExpdmUgQ2FtZXJhIEJvdHRvbSBBY3Rpb24gQ29udHJvbHMgKi99XG4gICAgICAgIHshc2NhblJlc3VsdCAmJiBzdHJlYW1BY3RpdmUgJiYgIXNjYW5uaW5nICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBwdC0xXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBmaWxlSW5wdXRSZWYuY3VycmVudD8uY2xpY2soKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnYXAtMiB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxVcGxvYWQgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPiB7dChcInNjYW5uZXIudXBsb2FkRmlsZVwiLCB7IGRlZmF1bHRWYWx1ZTogXCJVcGxvYWQgRmlsZVwiIH0pfVxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TWFudWFsQmFyY29kZSghc2hvd01hbnVhbEJhcmNvZGUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdhcC0xLjUgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmQgaG92ZXI6dGV4dC1mb3JlZ3JvdW5kXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxUYWcgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPiB7dChcInNjYW5uZXIuZW50ZXJCYXJjb2RlXCIsIHsgZGVmYXVsdFZhbHVlOiBcIkVudGVyIEJhcmNvZGVcIiB9KX1cbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHJlZj17ZmlsZUlucHV0UmVmfVxuICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qLHZpZGVvLypcIlxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVGaWxlVXBsb2FkfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEJpZyBTaHV0dGVyIEJ1dHRvbiAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIHNpemU9XCJsZ1wiXG4gICAgICAgICAgICAgICAgb25DbGljaz17Y2FwdHVyZUZyb21DYW1lcmF9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2FwLTIuNSBweC04IGZvbnQtYm9sZCB0ZXh0LXNtIGJnLXByaW1hcnkgaG92ZXI6YmctcHJpbWFyeS85MCB0ZXh0LXByaW1hcnktZm9yZWdyb3VuZCBzaGFkb3ctbGcgc2hhZG93LXByaW1hcnkvMjUgcm91bmRlZC14bCBoLTEyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+IHt0KFwic2Nhbm5lci5pbnNwZWN0QXV0aGVudGljaXR5XCIsIHsgZGVmYXVsdFZhbHVlOiBcIkluc3BlY3QgQXV0aGVudGljaXR5XCIgfSl9XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmQgdGV4dC1jZW50ZXIgc206dGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICB7YWN0aXZlTW9kZSA9PT0gXCJiYXJjb2RlXCJcbiAgICAgICAgICAgICAgICA/IGBNb2RlOiAke3QoXCJzY2FubmVyLm1vZGVCYXJjb2RlXCIsIHsgZGVmYXVsdFZhbHVlOiBcIkJhcmNvZGUgQ2hlY2tzdW1cIiB9KX1gXG4gICAgICAgICAgICAgICAgOiBhY3RpdmVNb2RlID09PSBcImxvZ29cIlxuICAgICAgICAgICAgICAgID8gYE1vZGU6ICR7dChcInNjYW5uZXIubW9kZUxvZ29cIiwgeyBkZWZhdWx0VmFsdWU6IFwiTHV4dXJ5IExvZ28gR2VvbWV0cnlcIiB9KX1gXG4gICAgICAgICAgICAgICAgOiBgTW9kZTogJHt0KFwic2Nhbm5lci5tb2RlRnVsbFByb2R1Y3RcIiwgeyBkZWZhdWx0VmFsdWU6IFwiRnVsbCBHYXJtZW50ICYgUGFja2FnZSBBbmFseXNpc1wiIH0pfWB9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogTWFudWFsIEJhcmNvZGUgSW5wdXQgQmFyICovfVxuICAgICAgICB7IXNjYW5SZXN1bHQgJiYgIXNjYW5uaW5nICYmIChzaG93TWFudWFsQmFyY29kZSB8fCBwZXJtaXNzaW9uU3RhdGUgPT09IFwidW5zdXBwb3J0ZWRcIiB8fCBwZXJtaXNzaW9uU3RhdGUgPT09IFwiZGVuaWVkXCIpICYmIChcbiAgICAgICAgICA8Zm9ybVxuICAgICAgICAgICAgb25TdWJtaXQ9e2hhbmRsZU1hbnVhbEJhcmNvZGVTdWJtaXR9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwLTMgYmctbXV0ZWQvNDAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWJvcmRlciBmbGV4IGZsZXgtY29sIGdhcC0yIGFuaW1hdGUtaW4gZmFkZS1pblwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLWNlbnRlciBnYXAtMiB3LWZ1bGxcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4LTEgdy1mdWxsXCI+XG4gICAgICAgICAgICAgICAgPFRhZyBjbGFzc05hbWU9XCJoLTQgdy00IGFic29sdXRlIGxlZnQtMyB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgLz5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgVVBDLUEsIEVBTi0xMywgb3Igc2VyaWFsIChlLmcuIDYwMDEwODcwMDAxNDAgZm9yIENvY2EtQ29sYSAyTCkuLi5cIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e21hbnVhbEJhcmNvZGV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE1hbnVhbEJhcmNvZGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLWJhY2tncm91bmQgYm9yZGVyIGJvcmRlci1ib3JkZXIgcm91bmRlZC1sZyBwbC05IHByLTMgcHktMS41IHRleHQteHMgcGxhY2Vob2xkZXI6dGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1wcmltYXJ5XCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB3LWZ1bGwgc206dy1hdXRvXCI+XG4gICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFtYW51YWxCYXJjb2RlLnRyaW0oKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gdGV4dC14cyBoLTggcHgtNCBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7dChcInNjYW5uZXIudmVyaWZ5QmFyY29kZVwiLCB7IGRlZmF1bHRWYWx1ZTogXCJWZXJpZnkgQmFyY29kZVwiIH0pfVxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogUXVpY2sgYmFyY29kZSBzaG9ydGN1dHMgaW5jbHVkaW5nIENvY2EtQ29sYSAyTCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgZmxleC13cmFwIHB0LTEgdGV4dC1bMTFweF0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kLzgwXCI+UXVpY2sgdGVzdDo8L3NwYW4+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBzZXRNYW51YWxCYXJjb2RlKFwiNjAwMTA4NzAwMDE0MFwiKTtcbiAgICAgICAgICAgICAgICAgIHByb2Nlc3NJbWFnZUZvckF1dGhlbnRpY2l0eShcIlwiLCBcImltYWdlL2pwZWdcIiwgXCJcIiwgbnVsbCwgXCI2MDAxMDg3MDAwMTQwXCIsIFwiYmFyY29kZVwiKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHJvdW5kZWQgYmctYmFja2dyb3VuZCBob3ZlcjpiZy1tdXRlZCBib3JkZXIgYm9yZGVyLWJvcmRlciB0ZXh0LWZvcmVncm91bmQgdHJhbnNpdGlvbi1jb2xvcnMgZm9udC1tb25vIHRleHQtWzEwcHhdXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENvY2EtQ29sYSAyTCAoU0E6IDYwMDEwODcwMDAxNDApXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgc2V0TWFudWFsQmFyY29kZShcIjU0NDkwMDAwMDA5OTZcIik7XG4gICAgICAgICAgICAgICAgICBwcm9jZXNzSW1hZ2VGb3JBdXRoZW50aWNpdHkoXCJcIiwgXCJpbWFnZS9qcGVnXCIsIFwiXCIsIG51bGwsIFwiNTQ0OTAwMDAwMDk5NlwiLCBcImJhcmNvZGVcIik7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkIGJnLWJhY2tncm91bmQgaG92ZXI6YmctbXV0ZWQgYm9yZGVyIGJvcmRlci1ib3JkZXIgdGV4dC1mb3JlZ3JvdW5kIHRyYW5zaXRpb24tY29sb3JzIGZvbnQtbW9ubyB0ZXh0LVsxMHB4XVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBDb2NhLUNvbGEgMkwgKEdsb2JhbDogNTQ0OTAwMDAwMDk5NilcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBzZXRNYW51YWxCYXJjb2RlKFwiMDQ5MDAwMDUwMTAzXCIpO1xuICAgICAgICAgICAgICAgICAgcHJvY2Vzc0ltYWdlRm9yQXV0aGVudGljaXR5KFwiXCIsIFwiaW1hZ2UvanBlZ1wiLCBcIlwiLCBudWxsLCBcIjA0OTAwMDA1MDEwM1wiLCBcImJhcmNvZGVcIik7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkIGJnLWJhY2tncm91bmQgaG92ZXI6YmctbXV0ZWQgYm9yZGVyIGJvcmRlci1ib3JkZXIgdGV4dC1mb3JlZ3JvdW5kIHRyYW5zaXRpb24tY29sb3JzIGZvbnQtbW9ubyB0ZXh0LVsxMHB4XVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBDb2NhLUNvbGEgMkwgKFVTOiAwNDkwMDAwNTAxMDMpXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgc2V0TWFudWFsQmFyY29kZShcIjYwMDEwODcwMDAwMzRcIik7XG4gICAgICAgICAgICAgICAgICBwcm9jZXNzSW1hZ2VGb3JBdXRoZW50aWNpdHkoXCJcIiwgXCJpbWFnZS9qcGVnXCIsIFwiXCIsIG51bGwsIFwiNjAwMTA4NzAwMDAzNFwiLCBcImJhcmNvZGVcIik7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkIGJnLWJhY2tncm91bmQgaG92ZXI6YmctbXV0ZWQgYm9yZGVyIGJvcmRlci1ib3JkZXIgdGV4dC1mb3JlZ3JvdW5kIHRyYW5zaXRpb24tY29sb3JzIGZvbnQtbW9ubyB0ZXh0LVsxMHB4XVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBTcHJpdGUgMkwgKFNBOiA2MDAxMDg3MDAwMDM0KVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICB7LyogQ09NUFJFSEVOU0lWRSBBVVRIRU5USUNJVFkgJiBBTlRJLUNPVU5URVJGRUlUIFJFUE9SVCAgICAgICovfVxuICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovfVxuICAgICAgICB7c2NhblJlc3VsdCAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTYgYW5pbWF0ZS1pbiBmYWRlLWluIHNsaWRlLWluLWZyb20tYm90dG9tLTIgZHVyYXRpb24tMzAwXCI+XG4gICAgICAgICAgICB7LyogVG9wIFZlcmRpY3QgSGVybyBDYXJkICovfVxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTYgcm91bmRlZC0yeGwgYm9yZGVyICR7XG4gICAgICAgICAgICAgICAgc2NhblJlc3VsdC5jb3VudGVyZmVpdEFzc2Vzc21lbnQ/LnZlcmRpY3QgPT09IFwibGVnaXRcIiB8fFxuICAgICAgICAgICAgICAgIHNjYW5SZXN1bHQuY291bnRlcmZlaXRBc3Nlc3NtZW50Py52ZXJkaWN0ID09PSBcImxpa2VseV9sZWdpdFwiXG4gICAgICAgICAgICAgICAgICA/IFwiYmctZW1lcmFsZC01MDAvMTAgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIHRleHQtZW1lcmFsZC05NTAgZGFyazp0ZXh0LWVtZXJhbGQtMTAwXCJcbiAgICAgICAgICAgICAgICAgIDogc2NhblJlc3VsdC5jb3VudGVyZmVpdEFzc2Vzc21lbnQ/LnZlcmRpY3QgPT09IFwic3VzcGVjdGVkX2NvdW50ZXJmZWl0XCIgfHxcbiAgICAgICAgICAgICAgICAgICAgc2NhblJlc3VsdC5jb3VudGVyZmVpdEFzc2Vzc21lbnQ/LnZlcmRpY3QgPT09IFwiaGlnaF9yaXNrX2Zha2VcIlxuICAgICAgICAgICAgICAgICAgPyBcImJnLXJvc2UtNTAwLzEwIGJvcmRlci1yb3NlLTUwMC8zMCB0ZXh0LXJvc2UtOTUwIGRhcms6dGV4dC1yb3NlLTEwMFwiXG4gICAgICAgICAgICAgICAgICA6IFwiYmctYW1iZXItNTAwLzEwIGJvcmRlci1hbWJlci01MDAvMzAgdGV4dC1hbWJlci05NTAgZGFyazp0ZXh0LWFtYmVyLTEwMFwiXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BoLTE0IHctMTQgcm91bmRlZC0yeGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hhZG93LW1kIHNocmluay0wICR7XG4gICAgICAgICAgICAgICAgICAgICAgc2NhblJlc3VsdC5jb3VudGVyZmVpdEFzc2Vzc21lbnQ/LnZlcmRpY3QgPT09IFwibGVnaXRcIiB8fFxuICAgICAgICAgICAgICAgICAgICAgIHNjYW5SZXN1bHQuY291bnRlcmZlaXRBc3Nlc3NtZW50Py52ZXJkaWN0ID09PSBcImxpa2VseV9sZWdpdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctZW1lcmFsZC01MDAgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHNjYW5SZXN1bHQuY291bnRlcmZlaXRBc3Nlc3NtZW50Py52ZXJkaWN0ID09PSBcInN1c3BlY3RlZF9jb3VudGVyZmVpdFwiIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNjYW5SZXN1bHQuY291bnRlcmZlaXRBc3Nlc3NtZW50Py52ZXJkaWN0ID09PSBcImhpZ2hfcmlza19mYWtlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1yb3NlLTUwMCB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1hbWJlci01MDAgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7c2NhblJlc3VsdC5jb3VudGVyZmVpdEFzc2Vzc21lbnQ/LnZlcmRpY3QgPT09IFwibGVnaXRcIiB8fFxuICAgICAgICAgICAgICAgICAgICBzY2FuUmVzdWx0LmNvdW50ZXJmZWl0QXNzZXNzbWVudD8udmVyZGljdCA9PT0gXCJsaWtlbHlfbGVnaXRcIiA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwiaC04IHctOFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPFNoaWVsZEFsZXJ0IGNsYXNzTmFtZT1cImgtOCB3LThcIiAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPEJhZGdlXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQteHMgcHgtMi41IHB5LTAuNSAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzY2FuUmVzdWx0LmNvdW50ZXJmZWl0QXNzZXNzbWVudD8udmVyZGljdCA9PT0gXCJsZWdpdFwiIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNjYW5SZXN1bHQuY291bnRlcmZlaXRBc3Nlc3NtZW50Py52ZXJkaWN0ID09PSBcImxpa2VseV9sZWdpdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWVtZXJhbGQtNjAwIHRleHQtd2hpdGUgaG92ZXI6YmctZW1lcmFsZC02MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogc2NhblJlc3VsdC5jb3VudGVyZmVpdEFzc2Vzc21lbnQ/LnZlcmRpY3QgPT09IFwic3VzcGVjdGVkX2NvdW50ZXJmZWl0XCIgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNjYW5SZXN1bHQuY291bnRlcmZlaXRBc3Nlc3NtZW50Py52ZXJkaWN0ID09PSBcImhpZ2hfcmlza19mYWtlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctcm9zZS02MDAgdGV4dC13aGl0ZSBob3ZlcjpiZy1yb3NlLTYwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWFtYmVyLTYwMCB0ZXh0LXdoaXRlIGhvdmVyOmJnLWFtYmVyLTYwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7c2NhblJlc3VsdC5jb3VudGVyZmVpdEFzc2Vzc21lbnQ/LmJhZGdlTGFiZWwgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2NhblJlc3VsdC5jb3VudGVyZmVpdEFzc2Vzc21lbnQ/LnZlcmRpY3Q/LnJlcGxhY2UoXCJfXCIsIFwiIFwiKSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICBzY2FuUmVzdWx0LmF1dGhlbnRpY2l0eS5iYWRnZUxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBvcGFjaXR5LTc1IGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgQ29uZmlkZW5jZToge3NjYW5SZXN1bHQuY291bnRlcmZlaXRBc3Nlc3NtZW50Py5jb25maWRlbmNlPy50b1VwcGVyQ2FzZSgpIHx8IFwiSElHSFwifVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgc206dGV4dC0yeGwgZm9udC1ibGFjayBmb250LWRpc3BsYXkgdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2NhblJlc3VsdC5icmFuZEluZm8uYnJhbmROYW1lfXtcIiBcIn1cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHNtOnRleHQtYmFzZSBmb250LW5vcm1hbCBvcGFjaXR5LTg1XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7c2NhblJlc3VsdC5icmFuZEluZm8ucHJvZHVjdE5hbWUgfHwgXCJcIn1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIG9wYWNpdHktOTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8QnVpbGRpbmcyIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIENvcnBvcmF0ZSBQYXJlbnQ6IDxzdHJvbmc+e3NjYW5SZXN1bHQuYnJhbmRJbmZvLmJyYW5kT3duZXJ9PC9zdHJvbmc+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIHtzY2FuUmVzdWx0LmJyYW5kSW5mby5jb3VudHJ5T2ZPcmlnaW59KVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBTY29yZSBNZXRlcnMgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNtOmZsZXgtY29sIGl0ZW1zLWNlbnRlciBzbTppdGVtcy1lbmQganVzdGlmeS1iZXR3ZWVuIHNtOmp1c3RpZnktY2VudGVyIGJvcmRlci10IHNtOmJvcmRlci10LTAgcHQtMyBzbTpwdC0wIGJvcmRlci1ib3JkZXIvMjAgZ2FwLTEgbWluLXctWzE0MHB4XVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgc206dGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSBmb250LW1vbm8gdHJhY2tpbmctd2lkZXIgb3BhY2l0eS03NVwiPlxuICAgICAgICAgICAgICAgICAgICAgIExlZ2l0aW1hY3kgU2NvcmVcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgc206dGV4dC0zeGwgZm9udC1ibGFjayBmb250LWRpc3BsYXlcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2NhblJlc3VsdC5jb3VudGVyZmVpdEFzc2Vzc21lbnQ/LmF1dGhlbnRpY2l0eVNjb3JlID8/IHNjYW5SZXN1bHQuYXV0aGVudGljaXR5LnNjb3JlfSVcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIHtzY2FuUmVzdWx0LmNvdW50ZXJmZWl0QXNzZXNzbWVudD8uY291bnRlcmZlaXRSaXNrU2NvcmUgIT09IHVuZGVmaW5lZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSBvcGFjaXR5LTg1XCI+XG4gICAgICAgICAgICAgICAgICAgICAgUmVwbGljYSBSaXNrOiB7c2NhblJlc3VsdC5jb3VudGVyZmVpdEFzc2Vzc21lbnQuY291bnRlcmZlaXRSaXNrU2NvcmV9JVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBOYXZpZ2F0aW9uIFRhYnMgZm9yIEZvcmVuc2ljIERldGFpbHMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggYm9yZGVyLWIgYm9yZGVyLWJvcmRlciBvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJlc3VsdFRhYihcImF1dGhlbnRpY2l0eVwiKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgYm9yZGVyLWItMiB3aGl0ZXNwYWNlLW5vd3JhcCB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41ICR7XG4gICAgICAgICAgICAgICAgICByZXN1bHRUYWIgPT09IFwiYXV0aGVudGljaXR5XCJcbiAgICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci1wcmltYXJ5IHRleHQtcHJpbWFyeVwiXG4gICAgICAgICAgICAgICAgICAgIDogXCJib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGhvdmVyOnRleHQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IEFudGktQ291bnRlcmZlaXQgQXVkaXRcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRSZXN1bHRUYWIoXCJndWlkZVwiKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgYm9yZGVyLWItMiB3aGl0ZXNwYWNlLW5vd3JhcCB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41ICR7XG4gICAgICAgICAgICAgICAgICByZXN1bHRUYWIgPT09IFwiZ3VpZGVcIlxuICAgICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLXByaW1hcnkgdGV4dC1wcmltYXJ5XCJcbiAgICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCB0ZXh0LW11dGVkLWZvcmVncm91bmQgaG92ZXI6dGV4dC1mb3JlZ3JvdW5kXCJcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxIZWxwQ2lyY2xlIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPiBDbGllbnQgVmVyaWZpY2F0aW9uIEd1aWRlXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UmVzdWx0VGFiKFwiYnJhbmRcIil9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yLjUgdGV4dC14cyBmb250LXNlbWlib2xkIGJvcmRlci1iLTIgd2hpdGVzcGFjZS1ub3dyYXAgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSAke1xuICAgICAgICAgICAgICAgICAgcmVzdWx0VGFiID09PSBcImJyYW5kXCJcbiAgICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci1wcmltYXJ5IHRleHQtcHJpbWFyeVwiXG4gICAgICAgICAgICAgICAgICAgIDogXCJib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGhvdmVyOnRleHQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8QnVpbGRpbmcyIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPiBCcmFuZCBMaW5lYWdlICYgUHJvdGVjdGlvblxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJlc3VsdFRhYihcImZvcmVuc2ljc1wiKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgYm9yZGVyLWItMiB3aGl0ZXNwYWNlLW5vd3JhcCB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41ICR7XG4gICAgICAgICAgICAgICAgICByZXN1bHRUYWIgPT09IFwiZm9yZW5zaWNzXCJcbiAgICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci1wcmltYXJ5IHRleHQtcHJpbWFyeVwiXG4gICAgICAgICAgICAgICAgICAgIDogXCJib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGhvdmVyOnRleHQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IE1lZGlhIEZvcmVuc2ljcyAmIFRhbXBlciBDaGVja1xuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJlc3VsdFRhYihcInByX2Rvc3NpZXJcIil9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yLjUgdGV4dC14cyBmb250LXNlbWlib2xkIGJvcmRlci1iLTIgd2hpdGVzcGFjZS1ub3dyYXAgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSAke1xuICAgICAgICAgICAgICAgICAgcmVzdWx0VGFiID09PSBcInByX2Rvc3NpZXJcIlxuICAgICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLXByaW1hcnkgdGV4dC1wcmltYXJ5XCJcbiAgICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCB0ZXh0LW11dGVkLWZvcmVncm91bmQgaG92ZXI6dGV4dC1mb3JlZ3JvdW5kXCJcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPiBCcmFuZCBQUiAmIENsaWVudCBEb3NzaWVyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBUYWIgMTogQW50aS1Db3VudGVyZmVpdCBBdWRpdCAqL31cbiAgICAgICAgICAgIHtyZXN1bHRUYWIgPT09IFwiYXV0aGVudGljaXR5XCIgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgey8qIExvZ28gSW5zcGVjdGlvbiAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctY2FyZC82MCBzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPFRhZyBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSB0ZXh0LXByaW1hcnlcIiAvPiBMb2dvICYgVHlwb2dyYXBoeSBDaGVja1xuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmQgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3NjYW5SZXN1bHQuY291bnRlcmZlaXRBc3Nlc3NtZW50Py5sb2dvSW5zcGVjdGlvbiB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJUeXBvZ3JhcGh5IGtlcm5pbmcsIGRlYm9zc2luZyBkZXB0aCwgYW5kIGZvbnQgZ2VvbWV0cmljIGFsaWdubWVudCB2ZXJpZmllZC5cIn1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBCYXJjb2RlICYgVGFnIENoZWNrICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1jYXJkLzYwIHNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8UXJDb2RlIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHRleHQtcHJpbWFyeVwiIC8+IEJhcmNvZGUgJiBHUzEgUmVnaXN0cnlcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtzY2FuUmVzdWx0LmNvdW50ZXJmZWl0QXNzZXNzbWVudD8uYmFyY29kZUFuZFRhZ3NJbnNwZWN0aW9uIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICBzY2FuUmVzdWx0LmJyYW5kSW5mby5xck9yQmFyY29kZURlY29kZWQgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiU3RhbmRhcmQgR1MxIEdUSU4vVVBDIGZvcm1hdHRpbmcgdmVyaWZpZWQgYWdhaW5zdCBpbnRlcm5hdGlvbmFsIGJyYW5kIHJlZ2lzdHJpZXMuXCJ9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7LyogQ3JhZnRzbWFuc2hpcCAmIFNlYW1zICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1jYXJkLzYwIHNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHRleHQtcHJpbWFyeVwiIC8+IENyYWZ0c21hbnNoaXAgJiBIYXJkd2FyZVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmQgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3NjYW5SZXN1bHQuY291bnRlcmZlaXRBc3Nlc3NtZW50Py5tYXRlcmlhbEFuZENyYWZ0c21hbnNoaXAgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiQ29uc2lzdGVudCBzdGl0Y2ggZGVuc2l0eSwgbWV0YWxsaWMgaGFyZHdhcmUgZW5ncmF2aW5ncywgYW5kIG1hdGVyaWFsIGdyYWluIGluc3BlY3RlZC5cIn1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogS2V5IERpZmZlcmVuY2VzIC8gRmFrZSBUcmFwcyAqL31cbiAgICAgICAgICAgICAgICB7c2NhblJlc3VsdC5jb3VudGVyZmVpdEFzc2Vzc21lbnQ/LmtleURpZmZlcmVuY2VzVG9Mb29rRm9yICYmXG4gICAgICAgICAgICAgICAgICBzY2FuUmVzdWx0LmNvdW50ZXJmZWl0QXNzZXNzbWVudC5rZXlEaWZmZXJlbmNlc1RvTG9va0Zvci5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1tdXRlZC8yMCBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSB0ZXh0LWFtYmVyLTUwMFwiIC8+IEtleSBBdXRoZW50aWMgdnMuIFJlcGxpY2FcbiAgICAgICAgICAgICAgICAgICAgICAgIEluZGljYXRvcnNcbiAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTEgdGV4dC14cyB0ZXh0LWZvcmVncm91bmQvOTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtzY2FuUmVzdWx0LmNvdW50ZXJmZWl0QXNzZXNzbWVudC5rZXlEaWZmZXJlbmNlc1RvTG9va0Zvci5tYXAoKGl0ZW0sIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtpZHh9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnkgZm9udC1ib2xkXCI+4oCiPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntpdGVtfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHsvKiBDYXB0dXJlZCBTbmFwc2hvdCBwcmV2aWV3ICovfVxuICAgICAgICAgICAgICAgIHtjYXB0dXJlZEltYWdlICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcC0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctbXV0ZWQvMTAgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICAgICAgc3JjPXtjYXB0dXJlZEltYWdlfVxuICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIkNhcHR1cmVkIHZlcmlmaWNhdGlvbiBzb3VyY2VcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTQgdy0xNCByb3VuZGVkLWxnIG9iamVjdC1jb3ZlciBib3JkZXIgYm9yZGVyLWJvcmRlclwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5BbmFseXplZCBWaXN1YWwgRXZpZGVuY2U8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgRm9yZW5zaWMgcGl4ZWwgaW50ZWdyaXR5IHNjb3JlOiB7c2NhblJlc3VsdC5hdXRoZW50aWNpdHkuc2NvcmV9JSDigKIgU3RhdHVzOntcIiBcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtzY2FuUmVzdWx0LmF1dGhlbnRpY2l0eS52ZXJkaWN0U3RhdHVzfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIFRhYiAyOiBDbGllbnQgVmVyaWZpY2F0aW9uIEd1aWRlICovfVxuICAgICAgICAgICAge3Jlc3VsdFRhYiA9PT0gXCJndWlkZVwiICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctY2FyZCBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxIZWxwQ2lyY2xlIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1wcmltYXJ5XCIgLz4gSG93IENsaWVudHMgJiBCdXllcnMgQ2FuIFZlcmlmeSBUaGlzXG4gICAgICAgICAgICAgICAgICAgIFByb2R1Y3RcbiAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICBBY3Rpb25hYmxlIGluc3RydWN0aW9ucyB0YWlsb3JlZCB0byB7c2NhblJlc3VsdC5icmFuZEluZm8uYnJhbmROYW1lfSB0byBjb25maXJtIGdlbnVpbmVcbiAgICAgICAgICAgICAgICAgICAgb3duZXJzaGlwIGFuZCBwcm90ZWN0IGFnYWluc3QgY291bnRlcmZlaXQgbWFya2V0IGNpcmN1bGF0aW9uLlxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIuNVwiPlxuICAgICAgICAgICAgICAgICAge3NjYW5SZXN1bHQuY291bnRlcmZlaXRBc3Nlc3NtZW50Py5jbGllbnRWZXJpZmljYXRpb25HdWlkZT8ubWFwKChndWlkZVN0ZXAsIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtpZHh9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0zLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWJvcmRlci84MCBiZy1tdXRlZC8yMCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zIHRleHQteHNcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTYgdy02IHJvdW5kZWQtZnVsbCBiZy1wcmltYXJ5LzEwIHRleHQtcHJpbWFyeSBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hyaW5rLTAgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpZHggKyAxfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGVhZGluZy1yZWxheGVkIHRleHQtZm9yZWdyb3VuZCBwdC0wLjVcIj57Z3VpZGVTdGVwfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICkpIHx8IChcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICBBbHdheXMgY2hlY2sgdGhlIHNlcmlhbCBudW1iZXIgb24gdGhlIGJyYW5kJ3Mgb2ZmaWNpYWwgY3VzdG9tZXIgcG9ydGFsLCB2ZXJpZnkgcmVjZWlwdCBvZlxuICAgICAgICAgICAgICAgICAgICAgIHB1cmNoYXNlIGZyb20gYXV0aG9yaXplZCBzdG9ja2lzdHMsIGFuZCBsb29rIGZvciBpbnRlcm5hbCBtaWNyby1lbWJvc3NlZCBzZWN1cml0eSB0YWdzLlxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBUYWIgMzogQnJhbmQgTGluZWFnZSAmIFByb3RlY3Rpb24gKi99XG4gICAgICAgICAgICB7cmVzdWx0VGFiID09PSBcImJyYW5kXCIgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1jYXJkIHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8QnVpbGRpbmcyIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1wcmltYXJ5XCIgLz4gQ29ycG9yYXRlIE93bmVyc2hpcCAmIERpc3RyaWJ1dGlvblxuICAgICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgIHtzY2FuUmVzdWx0LmJyYW5kSW5mby5wYXJlbnRDb21wYW55Q29udGV4dCB8fFxuICAgICAgICAgICAgICAgICAgICAgIGAke3NjYW5SZXN1bHQuYnJhbmRJbmZvLmJyYW5kTmFtZX0gaXMgb3BlcmF0ZWQgYW5kIG93bmVkIGJ5ICR7c2NhblJlc3VsdC5icmFuZEluZm8uYnJhbmRPd25lcn0uYH1cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLW11dGVkLzIwIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5CcmFuZCBDYXRlZ29yeSAmIFRpZXI6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2NhblJlc3VsdC5icmFuZEluZm8uY2F0ZWdvcnl9IOKAoiB7c2NhblJlc3VsdC5icmFuZEluZm8ubWFya2V0VGllcn1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctbXV0ZWQvMjAgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPkF1dGhvcml6ZWQgQ2hhbm5lbHM6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2NhblJlc3VsdC5jb3VudGVyZmVpdEFzc2Vzc21lbnQ/LmJyYW5kUHJvdGVjdGlvblRyYWNraW5nPy5hdXRob3JpemVkQ2hhbm5lbHMgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiT2ZmaWNpYWwgQnJhbmQgU3RvcmVzICYgQ2VydGlmaWVkIFJldGFpbGVyc1wifVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAge21hdGNoZWRCcmFuZCAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItcHJpbWFyeS8yMCBiZy1wcmltYXJ5LzUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHttYXRjaGVkQnJhbmQubmFtZX0gaW4gU3Rhc2ggT3IgVHJhc2hcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgT3ZlcmFsbCBUcnVzdCBTY29yZToge21hdGNoZWRCcmFuZC50cnVzdF9zY29yZX0vMTAwIOKAoiBWZXJkaWN0OiB7bWF0Y2hlZEJyYW5kLnRydXN0X3Njb3JlID49IDYwID8gXCJTdGFzaFwiIDogXCJUcmFzaFwifVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+ICh3aW5kb3cubG9jYXRpb24uaHJlZiA9IGAvYnJhbmRzLyR7bWF0Y2hlZEJyYW5kLnNsdWd9YCl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2FwLTEgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICBWaWV3IEJyYW5kIFBhZ2UgPEV4dGVybmFsTGluayBjbGFzc05hbWU9XCJoLTMgdy0zXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBUYWIgNDogTWVkaWEgRm9yZW5zaWNzICYgVGFtcGVyIENoZWNrICovfVxuICAgICAgICAgICAge3Jlc3VsdFRhYiA9PT0gXCJmb3JlbnNpY3NcIiAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLWNhcmQgc3BhY2UteS00IGFuaW1hdGUtaW4gZmFkZS1pblwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1wcmltYXJ5XCIgLz4gVmlzdWFsIE1lZGlhIEludGVncml0eSAmIERlZXBmYWtlIFNoaWVsZFxuICAgICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgIFBpeGVsLWxldmVsIGZvcmVuc2ljIGF1ZGl0IG9mIHRoZSB1cGxvYWRlZCBtZWRpYSB0byB2ZXJpZnkgZ2VudWluZSBjYW1lcmEgb3B0aWNzIHZlcnN1cyBBSSBzeW50aGVzaXMsIGRpZ2l0YWwgc3BsaWNpbmcsIG9yIFBob3Rvc2hvcCBhbHRlcmF0aW9uLlxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC0zIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1tdXRlZC8yMCBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1mb3JlZ3JvdW5kIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHRleHQtcHJpbWFyeVwiIC8+IExpZ2h0aW5nIFZlY3RvcnMgJiBTcGVjdWxhciBDb25zaXN0ZW5jeVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtzY2FuUmVzdWx0LmF1dGhlbnRpY2l0eS5mb3JlbnNpY3MucGh5c2ljYWxMaWdodGluZyB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJOYXR1cmFsIHNoYWRvdyBmYWxsb2ZmIGFuZCBzcGVjdWxhciBoaWdobGlnaHRzIGNvbnNpc3RlbnQgd2l0aCByZWFsIHBoeXNpY2FsIGNhbWVyYSBjYXB0dXJlLlwifVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLW11dGVkLzIwIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWZvcmVncm91bmQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSB0ZXh0LXByaW1hcnlcIiAvPiBTZW5zb3IgTm9pc2UgJiBDb21wcmVzc2lvbiBBcnRpZmFjdHNcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2NhblJlc3VsdC5hdXRoZW50aWNpdHkuZm9yZW5zaWNzLnRleHR1cmVBbmROb2lzZSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJPcmdhbmljIENNT1MgQmF5ZXIgc2Vuc29yIG5vaXNlIGRldGVjdGVkOyB6ZXJvIGdlbmVyYXRpdmUgZGlmZnVzaW9uIG9yIG5ldXJhbCB1cHNjYWxpbmcgbWFya3MuXCJ9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctbXV0ZWQvMjAgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZm9yZWdyb3VuZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPFRhZyBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSB0ZXh0LXByaW1hcnlcIiAvPiBNaWNyby1UeXBvZ3JhcGh5ICYgRWRnZSBJbnRlZ3JpdHlcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2NhblJlc3VsdC5hdXRoZW50aWNpdHkuZm9yZW5zaWNzLnRleHRJbnRlZ3JpdHkgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiUHJpbnRlZCB0ZXh0IGFkaGVyZXMgdG8gdmVjdG9yIHN0YW5kYXJkcyB3aXRob3V0IGhhbGx1Y2luYXRlZCBvciBkaXN0b3J0ZWQgZ2x5cGhzLlwifVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLW11dGVkLzIwIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWZvcmVncm91bmQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSB0ZXh0LWVtZXJhbGQtNTAwXCIgLz4gQUkgR2VuZXJhdGlvbiAoR0FOL0RpZmZ1c2lvbikgQ2hlY2tcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2NhblJlc3VsdC5hdXRoZW50aWNpdHkuZm9yZW5zaWNzLmFpR2VuZXJhdGlvbk1hcmtlcnMgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiTm8gTWlkam91cm5leSwgU3RhYmxlIERpZmZ1c2lvbiwgREFMTC1FLCBvciBTb3JhIGdlbmVyYXRpdmUgc2lnbmF0dXJlcyBmb3VuZC5cIn1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7c2NhblJlc3VsdC5hdXRoZW50aWNpdHkucmVhc29ucyAmJiBzY2FuUmVzdWx0LmF1dGhlbnRpY2l0eS5yZWFzb25zLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYm9yZGVyLzgwIGJnLWJhY2tncm91bmQgc3BhY2UteS0xLjUgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWZvcmVncm91bmRcIj5Gb3JlbnNpYyBDb25maXJtYXRpb24gRmFjdG9yczo8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNwYWNlLXktMSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2NhblJlc3VsdC5hdXRoZW50aWNpdHkucmVhc29ucy5tYXAoKHIsIGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2l9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHRleHQtZW1lcmFsZC01MDAgc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3J9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIFRhYiA1OiBCcmFuZCBQUiAmIENsaWVudCBEb3NzaWVyICovfVxuICAgICAgICAgICAge3Jlc3VsdFRhYiA9PT0gXCJwcl9kb3NzaWVyXCIgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1jYXJkIHNwYWNlLXktNCBhbmltYXRlLWluIGZhZGUtaW5cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1wcmltYXJ5XCIgLz4gT2ZmaWNpYWwgQnJhbmQgUFIgJiBDbGllbnQgVmVyaWZpY2F0aW9uIERvc3NpZXJcbiAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICBSZWFkeS10by1zaGFyZSBhdWRpdCBkb2N1bWVudGF0aW9uIGZvciBCcmFuZCBQdWJsaWMgUmVsYXRpb25zIE9mZmljZXJzLCBDbGllbnQgVmVyaWZpY2F0aW9uIHRlYW1zLCBhbmQgTGVnYWwgQnJhbmQgUHJvdGVjdGlvbi5cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1wcmltYXJ5LzMwIGJnLXByaW1hcnkvNSBzcGFjZS15LTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgYm9yZGVyLWIgYm9yZGVyLXByaW1hcnkvMjAgcGItM1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJsYWNrIGZvbnQtZGlzcGxheSB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtzY2FuUmVzdWx0LmJyYW5kSW5mby5icmFuZE5hbWV9IOKAoiBPZmZpY2lhbCBBdWRpdCBEb3NzaWVyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFBhcmVudCBDb21wYW55OiB7c2NhblJlc3VsdC5icmFuZEluZm8uYnJhbmRPd25lcn0gKHtzY2FuUmVzdWx0LmJyYW5kSW5mby5jb3VudHJ5T2ZPcmlnaW59KVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUHJpbnRDZXJ0aWZpY2F0ZX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnYXAtMS41IHRleHQteHMgYmctcHJpbWFyeSB0ZXh0LXByaW1hcnktZm9yZWdyb3VuZCBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz4gUHJpbnQgLyBFeHBvcnQgQXVkaXQgUERGXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMyBnYXAtMi41IHB0LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIuNSByb3VuZGVkLWxnIGJnLWJhY2tncm91bmQgYm9yZGVyIGJvcmRlci1ib3JkZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCB1cHBlcmNhc2UgZm9udC1tb25vXCI+QXV0aGVudGljaXR5IFZlcmRpY3Q8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWZvcmVncm91bmQgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3NjYW5SZXN1bHQuY291bnRlcmZlaXRBc3Nlc3NtZW50Py5iYWRnZUxhYmVsIHx8IFwiVmVyaWZpZWQgQXV0aGVudGljXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMi41IHJvdW5kZWQtbGcgYmctYmFja2dyb3VuZCBib3JkZXIgYm9yZGVyLWJvcmRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIHVwcGVyY2FzZSBmb250LW1vbm9cIj5MZWdpdGltYWN5IFNjb3JlPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1lbWVyYWxkLTYwMCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7c2NhblJlc3VsdC5jb3VudGVyZmVpdEFzc2Vzc21lbnQ/LmF1dGhlbnRpY2l0eVNjb3JlID8/IHNjYW5SZXN1bHQuYXV0aGVudGljaXR5LnNjb3JlfSVcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yLjUgcm91bmRlZC1sZyBiZy1iYWNrZ3JvdW5kIGJvcmRlciBib3JkZXItYm9yZGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LW11dGVkLWZvcmVncm91bmQgdXBwZXJjYXNlIGZvbnQtbW9ub1wiPk1lZGlhIEZvcmVuc2ljIEludGVncml0eTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtcHJpbWFyeSB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7c2NhblJlc3VsdC5hdXRoZW50aWNpdHkuc2NvcmV9JSBWZXJpZmllZFxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMSB0ZXh0LW11dGVkLWZvcmVncm91bmQgcHQtMVwiPlxuICAgICAgICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPkF1dGhvcml6ZWQgQ2hhbm5lbHM6PC9zdHJvbmc+e1wiIFwifVxuICAgICAgICAgICAgICAgICAgICAgIHtzY2FuUmVzdWx0LmNvdW50ZXJmZWl0QXNzZXNzbWVudD8uYnJhbmRQcm90ZWN0aW9uVHJhY2tpbmc/LmF1dGhvcml6ZWRDaGFubmVscyB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJBdXRob3JpemVkIHJldGFpbGVycyBhbmQgY2VydGlmaWVkIGRpc3RyaWJ1dGlvbiBuZXR3b3Jrcy5cIn1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPkJyYW5kIFBSIEFkdmlzb3J5Ojwvc3Ryb25nPntcIiBcIn1cbiAgICAgICAgICAgICAgICAgICAgICB7c2NhblJlc3VsdC5jb3VudGVyZmVpdEFzc2Vzc21lbnQ/LmJyYW5kUHJvdGVjdGlvblRyYWNraW5nPy5hZHZpY2UgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIGBDbGllbnQgdmVyaWZpY2F0aW9uIGNvbmZpcm1lZCBpbiBmYXZvciBvZiAke3NjYW5SZXN1bHQuYnJhbmRJbmZvLmJyYW5kT3duZXJ9LmB9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBCb3R0b20gQWN0aW9ucyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHB0LTMgYm9yZGVyLXQgYm9yZGVyLWJvcmRlclwiPlxuICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgb25DbGljaz17aGFuZGxlUmVzZXR9IGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gZ2FwLTIgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIDxSZWZyZXNoQ3cgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPiB7dChcInNjYW5uZXIuc2NhbkFub3RoZXJcIiwgeyBkZWZhdWx0VmFsdWU6IFwiU2NhbiBBbm90aGVyIFByb2R1Y3RcIiB9KX1cbiAgICAgICAgICAgICAgPC9CdXR0b24+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB3LWZ1bGwgc206dy1hdXRvIGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVByaW50Q2VydGlmaWNhdGV9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgc206ZmxleC1ub25lIGdhcC0yIHRleHQteHMgZm9udC1tZWRpdW1cIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9e3QoXCJzY2FubmVyLnByaW50Q2VydFRpdGxlXCIsIHsgZGVmYXVsdFZhbHVlOiBcIlByaW50IEJyYW5kIFBSICYgQ2xpZW50IFZlcmlmaWNhdGlvbiBDZXJ0aWZpY2F0ZVwiIH0pfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHRleHQtcHJpbWFyeVwiIC8+IHt0KFwic2Nhbm5lci5wcmludENlcnRcIiwgeyBkZWZhdWx0VmFsdWU6IFwiUHJpbnQgUFIgQXVkaXQgQ2VydGlmaWNhdGVcIiB9KX1cbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDb3B5UmVwb3J0fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHNtOmZsZXgtbm9uZSBnYXAtMiB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8Q29weSBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+IHt0KFwic2Nhbm5lci5jb3B5Q2VydFwiLCB7IGRlZmF1bHRWYWx1ZTogXCJDb3B5IENlcnRpZmljYXRlXCIgfSl9XG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAge29uQXBwbHlUb1Bvc3QgJiYgKFxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVBcHBseVBvc3R9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBzbTpmbGV4LW5vbmUgZ2FwLTIgdGV4dC14cyBmb250LXNlbWlib2xkIHNoYWRvdy1tZFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxGaWxlQ2hlY2sgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPiB7dChcInNjYW5uZXIucG9zdFRvQmFyb21ldGVyXCIsIHsgZGVmYXVsdFZhbHVlOiBcIlBvc3QgdG8gQnJhbmQgQmFyb21ldGVyXCIgfSl9XG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9hcHAvYXBwbGV0L3NyYy9jb21wb25lbnRzL1Byb2R1Y3RBdXRoZW50aWNpdHlDYW1lcmFTY2FubmVyLnRzeCJ9