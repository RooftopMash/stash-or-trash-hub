const OPERATORS_KEY = "sot_brand_desk_operators_v1";
const ACTIVE_OPERATOR_ID_KEY = "sot_active_desk_operator_id_v1";
const OPERATOR_LOG_KEY = "sot_brand_operator_logs_v1";
const CX_LIFECYCLE_KEY = "sot_brand_cx_lifecycle_v1";
const BRAND_SUBSCRIPTION_KEY = "sot_brand_subscription_state_v1";
const REGISTERED_BRAND_KEY = "sot_registered_brand_identity_v1";
const DEFAULT_REGISTERED_BRAND = {
	id: "registered-brand-nandos-za",
	name: "Nando's South Africa",
	slug: "nandos",
	category: "Food & Fast Food",
	country: "ZA",
	website: "https://www.nandos.co.za",
	trust_score: 86,
	verified: true
};
export function getRegisteredBrandIdentity() {
	if (typeof window === "undefined") return DEFAULT_REGISTERED_BRAND;
	try {
		const raw = window.localStorage.getItem(REGISTERED_BRAND_KEY);
		if (!raw) return DEFAULT_REGISTERED_BRAND;
		const parsed = JSON.parse(raw);
		if (parsed && typeof parsed.name === "string" && parsed.name.trim()) {
			return {
				...DEFAULT_REGISTERED_BRAND,
				...parsed,
				name: parsed.name.trim(),
				slug: parsed.slug?.trim() || parsed.name.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || "official-brand"
			};
		}
		return DEFAULT_REGISTERED_BRAND;
	} catch {
		return DEFAULT_REGISTERED_BRAND;
	}
}
export function setRegisteredBrandIdentity(partial) {
	const current = getRegisteredBrandIdentity();
	const cleanName = partial.name.trim() || current.name;
	const cleanSlug = partial.slug?.trim() || cleanName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || "official-brand";
	const updated = {
		...current,
		...partial,
		id: partial.id || `reg-brand-${cleanSlug}`,
		name: cleanName,
		slug: cleanSlug,
		category: partial.category || current.category || "Consumer Brand",
		country: partial.country || current.country || "ZA",
		website: partial.website ?? current.website,
		trust_score: Number(partial.trust_score) > 0 ? Number(partial.trust_score) : current.trust_score,
		verified: partial.verified ?? true
	};
	if (typeof window !== "undefined") {
		try {
			window.localStorage.setItem(REGISTERED_BRAND_KEY, JSON.stringify(updated));
			window.dispatchEvent(new CustomEvent("sot-registered-brand-updated", { detail: updated }));
		} catch {}
	}
	emitOperatorUpdate();
	return updated;
}
export function getTierRank(planId) {
	if (planId === "enterprise_intelligence") return 3;
	if (planId === "cx_launch_matrix") return 2;
	if (planId === "pulse_starter") return 1;
	return 0;
}
export function isTierEntitled(activeTier, requiredTier) {
	return getTierRank(activeTier) >= getTierRank(requiredTier);
}
export function setActiveBrandPlanTier(planId, brandName) {
	const current = getActiveBrandSubscription();
	const nextState = {
		...current,
		activePlanId: planId
	};
	if (typeof window !== "undefined") {
		try {
			window.localStorage.setItem(BRAND_SUBSCRIPTION_KEY, JSON.stringify(nextState));
		} catch {}
	}
	if (brandName) {
		const plan = B2B_BRAND_PLANS.find((p) => p.id === planId);
		const activeOp = getActiveDeskOperator();
		logOperatorAction({
			operatorId: activeOp.id,
			operatorName: activeOp.name,
			operatorRole: activeOp.roleTitle,
			actionType: "shift_handover",
			summary: `Updated ${brandName} B2B Subscription Tier to ${plan?.name ?? planId}.`
		});
	}
	emitOperatorUpdate();
}
export function getBrandSpecificTelemetry(brandName) {
	const clean = brandName.trim() || "Registered Brand";
	const prefix = clean.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 5) || "BRAND";
	return {
		branches: [
			{
				branchName: `${clean} — Sandton Flagship & Digital Hub`,
				region: "Gauteng · JHB North",
				stashCount: 184,
				trashCount: 14,
				trustPct: 93,
				openEscalations: 0,
				topSignal: "Fast turnaround & high launch voucher redemption"
			},
			{
				branchName: `${clean} — Rosebank & Mall of Africa`,
				region: "Gauteng · Metro",
				stashCount: 142,
				trashCount: 19,
				trustPct: 88,
				openEscalations: 1,
				topSignal: "2 packaging seal checks resolved within 15 mins"
			},
			{
				branchName: `${clean} — V&A Waterfront & Canal Walk`,
				region: "Western Cape · CPT",
				stashCount: 168,
				trashCount: 11,
				trustPct: 94,
				openEscalations: 0,
				topSignal: "Top-rated customer service desk this week"
			},
			{
				branchName: `${clean} — Umhlanga Arch & Gateway`,
				region: "KwaZulu-Natal · DBN",
				stashCount: 119,
				trashCount: 21,
				trustPct: 85,
				openEscalations: 2,
				topSignal: "Peak weekend queue feedback under active CX review"
			}
		],
		counterfeitRadar: [
			{
				id: "cf-1",
				batchCode: `#${prefix}-LOT-884`,
				location: "Johannesburg CBD Informal Trader Cluster",
				scanStatus: "Suspected Grey-Market Leak",
				scansCount: 14,
				actionRecommended: "Issue Genuine Store Recovery Voucher & alert supply-chain auditor"
			},
			{
				id: "cf-2",
				batchCode: `#${prefix}-LOT-910`,
				location: "Pretoria East Retail Partner",
				scanStatus: "Packaging Seal Flagged",
				scansCount: 6,
				actionRecommended: "Video-inspect batch with customer via Zero-Phone-Number Call"
			},
			{
				id: "cf-3",
				batchCode: `#${prefix}-LOT-945`,
				location: "National Authorised Distribution Channels",
				scanStatus: "Verified Authentic Batch",
				scansCount: 412,
				actionRecommended: "100% authentic barcode scans — 94% Stash conversion"
			}
		]
	};
}
export const B2B_BRAND_PLANS = [
	{
		id: "free_public_voice",
		name: "00. Free Public Voice (Fairness & Public Mouthpiece)",
		tagline: "Unrestricted public right of reply — text in public, defend products & state your truth for free",
		targetAudience: "For Spazas, Emerging Brands, Startups & Any Business (100% Free Forever)",
		priceZarMonthly: 0,
		priceUsdMonthly: 0,
		broadcastLimitLabel: "Public Text Responses (No Live Video Broadcasts)",
		operatorSeatsLabel: "1 Official Public Brand Mouthpiece Desk",
		dataExtractionFeatures: [
			"Official Claimed Brand Profile & Verified Public Voice Badge",
			"Public Right of Reply: Text public responses on community Trash & Stash posts",
			"Public Brand Wall & Community Engagement Desk",
			"Live Public Stash vs Trash Sentiment Barometer & People's Grade",
			"100% Free Forever — Freedom & Fairness (Zero Credit Card Required)",
			"🔒 Private CX Data Extraction & CSV Reports (Requires Paid Tier)",
			"🔒 Zero-Number Private Calling & Live Video Studios (Requires Paid Tier)"
		]
	},
	{
		id: "pulse_starter",
		name: "01. Pulse Starter (SME & Local Hero)",
		tagline: "Essential brand presence & verified public responses",
		targetAudience: "For Spazas, Local Stores & Emerging SMEs",
		priceZarMonthly: 1450,
		priceUsdMonthly: 85,
		broadcastLimitLabel: "15-Min Live Broadcasts (2 / mo)",
		operatorSeatsLabel: "Up to 2 Active Desk Operators",
		dataExtractionFeatures: [
			"Official Claimed Brand Profile & Verified Trust Seal",
			"Live Stash vs Trash Barometer & People's SOT Grade",
			"Switch Active Operator (2 Staff Shift Seats)",
			"15-Minute Product Showcase Broadcasts"
		]
	},
	{
		id: "cx_launch_matrix",
		name: "02. Full-Cycle CX & Launch Matrix",
		tagline: "Complete Launch-to-Resolution data extraction & client calling",
		targetAudience: "For National Retailers, Fast Food, FMCG & Growth Brands",
		priceZarMonthly: 4950,
		priceUsdMonthly: 290,
		broadcastLimitLabel: "60-Min Commercial Launch & Relaunch Studio",
		operatorSeatsLabel: "Up to 10 Active Desk Operators + Leaderboard",
		highlighted: true,
		dataExtractionFeatures: [
			"Full-Cycle CX Data Matrix (Launch ➔ Trash Callout ➔ Voucher ➔ Stash Flip)",
			"60-Min Live Product Launch & Relaunch Studio + 1-Click Promo Drops",
			"Zero-Phone-Number Direct Client Calling & Request-to-Call Desk",
			"Employee & Operator Performance Leaderboard (Track Trash-to-Stash ROI)",
			"Exportable CSV / Executive CX Intelligence Reports"
		]
	},
	{
		id: "enterprise_intelligence",
		name: "03. Enterprise Intelligence & Awards Suite",
		tagline: "Unlimited broadcasts, counterfeit radar & SOrT Employee Awards",
		targetAudience: "For Banks, Telcos, Airlines, Multinationals & Agencies",
		priceZarMonthly: 14900,
		priceUsdMonthly: 890,
		broadcastLimitLabel: "Unlimited HD Commercial Broadcasts + Home Stage Priority",
		operatorSeatsLabel: "Unlimited Desk Operators + Official SOrT Staff Awards",
		dataExtractionFeatures: [
			"Everything in CX & Launch Matrix + Priority Home Feed Broadcast Stage",
			"Counterfeit & Grey-Market Leak Radar (Store, Batch & Geo Scan Extraction)",
			"Official SOrT Employee Recognition Awards & Downloadable Staff Certificates",
			"14–20 Business Day CPA Pre-Escalation Shield (Before CGSO / NCC)",
			"AI CX Copilot & Multi-Branch Executive Telemetry API"
		]
	}
];
const DEFAULT_OPERATORS = [
	{
		id: "op-lerato",
		name: "Lerato Mokoena",
		roleTitle: "Senior CX & Launch Desk Lead",
		shiftLabel: "Day Shift (08:00–17:00)",
		activeSince: "2026-01-15",
		trashesTurnedToStash: 42,
		vouchersIssued: 38,
		medianResponseMinutes: 11,
		clientCallRating: 4.95,
		liveBroadcastsHosted: 9,
		sotOperatorScore: 97,
		awardBadge: "🏆 SOrT Star CX Operator of the Month"
	},
	{
		id: "op-sipho",
		name: "Sipho Dlamini",
		roleTitle: "Client Resolution & Recovery Specialist",
		shiftLabel: "Afternoon / Evening Shift",
		activeSince: "2026-02-10",
		trashesTurnedToStash: 31,
		vouchersIssued: 29,
		medianResponseMinutes: 16,
		clientCallRating: 4.85,
		liveBroadcastsHosted: 5,
		sotOperatorScore: 91,
		awardBadge: "⚡ Rapid Trash-to-Stash Turnaround Award"
	},
	{
		id: "op-thandi",
		name: "Thandi Ndlovu",
		roleTitle: "Counterfeit & Batch Quality Auditor",
		shiftLabel: "Quality & Supply Chain Desk",
		activeSince: "2026-03-01",
		trashesTurnedToStash: 24,
		vouchersIssued: 22,
		medianResponseMinutes: 19,
		clientCallRating: 4.8,
		liveBroadcastsHosted: 6,
		sotOperatorScore: 88,
		awardBadge: "🛡️ Counterfeit Intercept Champion"
	}
];
const DEFAULT_CX_LIFECYCLE = [
	{
		id: "cx-101",
		brandName: "Nando's",
		clientName: "Thabo M. (Verified Voter)",
		stage1LaunchSource: "Watched 'Peri-Honey Launch Broadcast' (Claimed 25% Code)",
		stage2ScanOrPostSignal: "Posted Trash Callout: Drive-thru missing peri-chips at Sandton",
		initialVerdict: "trash",
		operatorAssigned: "Lerato Mokoena (Senior CX Desk)",
		actionTaken: "Zero-Phone-Number SOT Video Call + Issued Recovery Voucher",
		voucherCode: "SOT_RECOVER_NANDOS_412",
		finalVerdict: "stash",
		revenueRetainedZar: 1850,
		updatedAt: "14 mins ago"
	},
	{
		id: "cx-102",
		brandName: "Takealot",
		clientName: "Zanele K. (Gold Arbitrator)",
		stage1LaunchSource: "Watched '45-Min Locker Relaunch Broadcast'",
		stage2ScanOrPostSignal: "Scanned Barcode #LOT-882 on /scan — Flagged damaged outer box",
		initialVerdict: "trash",
		operatorAssigned: "Sipho Dlamini (Resolution Desk)",
		actionTaken: "1-Click Request-to-Call Approved + Express Replacement Dispatched",
		voucherCode: "SOT_RECOVER_TAKEAL_809",
		finalVerdict: "stash",
		revenueRetainedZar: 3400,
		updatedAt: "42 mins ago"
	},
	{
		id: "cx-103",
		brandName: "Bathu",
		clientName: "Kabelo S. (Level 4 Watchdog)",
		stage1LaunchSource: "Watched 'Midrand Factory Quality Tour'",
		stage2ScanOrPostSignal: "Reported suspected grey-market sneaker stall in CBD via /scan",
		initialVerdict: "trash",
		operatorAssigned: "Thandi Ndlovu (Quality Auditor)",
		actionTaken: "Logged Counterfeit Leak Location + Issued Genuine Store Voucher",
		voucherCode: "BATHU_REAL_250",
		finalVerdict: "stash",
		revenueRetainedZar: 2200,
		updatedAt: "2 hours ago"
	}
];
function emitOperatorUpdate() {
	if (typeof window !== "undefined") {
		window.dispatchEvent(new CustomEvent("sot-brand-operator-updated"));
	}
}
export function getBrandDeskOperators() {
	if (typeof window === "undefined") return DEFAULT_OPERATORS;
	try {
		const raw = window.localStorage.getItem(OPERATORS_KEY);
		if (!raw) {
			window.localStorage.setItem(OPERATORS_KEY, JSON.stringify(DEFAULT_OPERATORS));
			return DEFAULT_OPERATORS;
		}
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_OPERATORS;
	} catch {
		return DEFAULT_OPERATORS;
	}
}
export function getActiveDeskOperator() {
	const list = getBrandDeskOperators();
	if (typeof window === "undefined") return list[0];
	try {
		const activeId = window.localStorage.getItem(ACTIVE_OPERATOR_ID_KEY);
		return list.find((o) => o.id === activeId) ?? list[0];
	} catch {
		return list[0];
	}
}
export function switchActiveDeskOperator(operatorId) {
	const list = getBrandDeskOperators();
	const chosen = list.find((o) => o.id === operatorId) ?? list[0];
	if (typeof window !== "undefined") {
		try {
			window.localStorage.setItem(ACTIVE_OPERATOR_ID_KEY, chosen.id);
			logOperatorAction({
				operatorId: chosen.id,
				operatorName: chosen.name,
				operatorRole: chosen.roleTitle,
				actionType: "shift_handover",
				summary: `Active Brand Desk handed over to ${chosen.name} (${chosen.roleTitle} · ${chosen.shiftLabel}). Personal user profile remains 100% separated.`
			});
		} catch {}
	}
	emitOperatorUpdate();
	return chosen;
}
export function addAndSwitchDeskOperator(params) {
	const list = getBrandDeskOperators();
	const newOp = {
		id: `op-${Date.now()}`,
		name: params.name.trim(),
		roleTitle: params.roleTitle.trim() || "Authorized Brand CX Operator",
		shiftLabel: params.shiftLabel?.trim() || "Active Shift Desk",
		activeSince: new Date().toISOString().slice(0, 10),
		trashesTurnedToStash: 1,
		vouchersIssued: 1,
		medianResponseMinutes: 12,
		clientCallRating: 5,
		liveBroadcastsHosted: 1,
		sotOperatorScore: 90,
		awardBadge: "🌟 Verified Brand Desk Custodian"
	};
	const next = [newOp, ...list];
	if (typeof window !== "undefined") {
		try {
			window.localStorage.setItem(OPERATORS_KEY, JSON.stringify(next));
			window.localStorage.setItem(ACTIVE_OPERATOR_ID_KEY, newOp.id);
			logOperatorAction({
				operatorId: newOp.id,
				operatorName: newOp.name,
				operatorRole: newOp.roleTitle,
				actionType: "shift_handover",
				summary: `Registered & activated new Brand Desk Operator: ${newOp.name} (${newOp.roleTitle}).`
			});
		} catch {}
	}
	emitOperatorUpdate();
	return newOp;
}
export function recordOperatorResolutionMetric(actionType, detailSummary) {
	const active = getActiveDeskOperator();
	const list = getBrandDeskOperators().map((op) => {
		if (op.id !== active.id) return op;
		return {
			...op,
			trashesTurnedToStash: actionType === "trash_to_stash" ? op.trashesTurnedToStash + 1 : op.trashesTurnedToStash,
			vouchersIssued: actionType === "voucher_issued" ? op.vouchersIssued + 1 : op.vouchersIssued,
			liveBroadcastsHosted: actionType === "launch_broadcast" ? op.liveBroadcastsHosted + 1 : op.liveBroadcastsHosted,
			sotOperatorScore: Math.min(100, op.sotOperatorScore + 1)
		};
	});
	if (typeof window !== "undefined") {
		try {
			window.localStorage.setItem(OPERATORS_KEY, JSON.stringify(list));
		} catch {}
	}
	logOperatorAction({
		operatorId: active.id,
		operatorName: active.name,
		operatorRole: active.roleTitle,
		actionType,
		summary: detailSummary
	});
	emitOperatorUpdate();
}
export function logOperatorAction(entry) {
	const full = {
		...entry,
		id: `log-${Date.now()}`,
		timestamp: new Date().toLocaleTimeString([], {
			hour: "2-digit",
			minute: "2-digit"
		})
	};
	if (typeof window !== "undefined") {
		try {
			const existing = getOperatorShiftLogs();
			const updated = [full, ...existing].slice(0, 25);
			window.localStorage.setItem(OPERATOR_LOG_KEY, JSON.stringify(updated));
		} catch {}
	}
	return full;
}
export function getOperatorShiftLogs() {
	const seed = [{
		id: "seed-log-1",
		operatorId: "op-lerato",
		operatorName: "Lerato Mokoena",
		operatorRole: "Senior CX & Launch Desk Lead",
		actionType: "trash_to_stash",
		summary: "Resolved Sandton drive-thru Trash callout via SOT Video Call & flipped client verdict to Stash.",
		timestamp: "09:42"
	}, {
		id: "seed-log-2",
		operatorId: "op-sipho",
		operatorName: "Sipho Dlamini",
		operatorRole: "Client Resolution Specialist",
		actionType: "voucher_issued",
		summary: "Issued Revenue Recovery Voucher SOT_RECOVER_TAKEAL_809 after barcode scan alert.",
		timestamp: "09:15"
	}];
	if (typeof window === "undefined") return seed;
	try {
		const raw = window.localStorage.getItem(OPERATOR_LOG_KEY);
		if (!raw) return seed;
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) && parsed.length > 0 ? parsed : seed;
	} catch {
		return seed;
	}
}
export function getCxLifecycleMatrix(brandName) {
	const targetBrand = brandName?.trim() || getRegisteredBrandIdentity().name;
	const prefix = targetBrand.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6) || "BRAND";
	const scopedDefaults = [
		{
			id: "cx-101",
			brandName: targetBrand,
			clientName: "Thabo M. (Verified Voter)",
			stage1LaunchSource: `Watched '${targetBrand} Product Launch Broadcast' (Claimed 25% Code)`,
			stage2ScanOrPostSignal: `Posted Trash Callout: Order fulfillment delay at ${targetBrand} Sandton branch`,
			initialVerdict: "trash",
			operatorAssigned: "Lerato Mokoena (Senior CX Desk)",
			actionTaken: "Zero-Phone-Number SOT Video Call + Issued Recovery Voucher",
			voucherCode: `SOT_RECOVER_${prefix}_412`,
			finalVerdict: "stash",
			revenueRetainedZar: 1850,
			updatedAt: "14 mins ago"
		},
		{
			id: "cx-102",
			brandName: targetBrand,
			clientName: "Zanele K. (Gold Arbitrator)",
			stage1LaunchSource: `Watched '${targetBrand} 45-Min Relaunch Broadcast'`,
			stage2ScanOrPostSignal: `Scanned ${targetBrand} Barcode #${prefix}-882 on /scan — Flagged outer seal`,
			initialVerdict: "trash",
			operatorAssigned: "Sipho Dlamini (Resolution Desk)",
			actionTaken: "1-Click Request-to-Call Approved + Express Replacement Dispatched",
			voucherCode: `SOT_RECOVER_${prefix}_809`,
			finalVerdict: "stash",
			revenueRetainedZar: 3400,
			updatedAt: "42 mins ago"
		},
		{
			id: "cx-103",
			brandName: targetBrand,
			clientName: "Kabelo S. (Level 4 Watchdog)",
			stage1LaunchSource: `Watched '${targetBrand} Behind-the-Scenes Quality Tour'`,
			stage2ScanOrPostSignal: `Reported suspected grey-market ${targetBrand} batch in CBD via /scan`,
			initialVerdict: "trash",
			operatorAssigned: "Thandi Ndlovu (Quality Auditor)",
			actionTaken: "Logged Counterfeit Leak Location + Issued Genuine Store Voucher",
			voucherCode: `${prefix}_REAL_250`,
			finalVerdict: "stash",
			revenueRetainedZar: 2200,
			updatedAt: "2 hours ago"
		}
	];
	if (typeof window === "undefined") return scopedDefaults;
	try {
		const raw = window.localStorage.getItem(CX_LIFECYCLE_KEY);
		if (!raw) {
			return scopedDefaults;
		}
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed) || parsed.length === 0) return scopedDefaults;
		const customForBrand = parsed.filter((r) => r.id && ![
			"cx-101",
			"cx-102",
			"cx-103"
		].includes(r.id) && (!brandName || r.brandName.toLowerCase() === targetBrand.toLowerCase()));
		return [...customForBrand, ...scopedDefaults];
	} catch {
		return scopedDefaults;
	}
}
export function addCxLifecycleResolution(record) {
	const existing = getCxLifecycleMatrix();
	const created = {
		...record,
		id: `cx-${Date.now()}`,
		updatedAt: "Just now"
	};
	const next = [created, ...existing];
	if (typeof window !== "undefined") {
		try {
			window.localStorage.setItem(CX_LIFECYCLE_KEY, JSON.stringify(next));
		} catch {}
	}
	emitOperatorUpdate();
	return created;
}
export function getActiveBrandSubscription() {
	const fallback = {
		activePlanId: "cx_launch_matrix",
		receipts: []
	};
	if (typeof window === "undefined") return fallback;
	try {
		const raw = window.localStorage.getItem(BRAND_SUBSCRIPTION_KEY);
		if (!raw) return fallback;
		return JSON.parse(raw);
	} catch {
		return fallback;
	}
}
export function recordBrandSubscriptionPayment(params) {
	const plan = B2B_BRAND_PLANS.find((p) => p.id === params.planId) ?? B2B_BRAND_PLANS[1];
	const activeOp = getActiveDeskOperator();
	const amountDisplay = params.currency === "ZAR" ? `R${plan.priceZarMonthly.toLocaleString()} / mo` : `$${plan.priceUsdMonthly.toLocaleString()} / mo`;
	const receipt = {
		id: `rcpt-${Date.now()}`,
		brandName: params.brandName,
		planId: plan.id,
		planName: plan.name,
		paymentMethod: params.paymentMethod,
		amountDisplay,
		referenceCode: `SOT-B2B-${Math.floor(1e5 + Math.random() * 899999)}`,
		operatorOnDuty: `${activeOp.name} (${activeOp.roleTitle})`,
		status: params.paymentMethod === "corporate_invoice" ? "pro_forma_issued" : "active",
		createdAt: new Date().toISOString()
	};
	const current = getActiveBrandSubscription();
	const nextState = {
		activePlanId: plan.id,
		receipts: [receipt, ...current.receipts].slice(0, 15)
	};
	if (typeof window !== "undefined") {
		try {
			window.localStorage.setItem(BRAND_SUBSCRIPTION_KEY, JSON.stringify(nextState));
		} catch {}
	}
	emitOperatorUpdate();
	return receipt;
}
const BRAND_CONTACT_SETTINGS_PREFIX = "sot_brand_contact_settings_v1_";
const INBOUND_CALL_REQUESTS_KEY = "sot_inbound_call_requests_v1";
export function getBrandContactSettings(brandSlug) {
	const normSlug = (brandSlug || "official-brand").toLowerCase().trim();
	const sub = getActiveBrandSubscription();
	const isFreeTier = sub.activePlanId === "free_public_voice";
	const defaultSettings = {
		brandSlug: normSlug,
		directCallingMode: isFreeTier ? "disabled" : "request_only",
		operatingHours: "08:00 - 17:00 (SAST Desk)",
		requireOrderOrBatchNumber: false,
		contactNotice: isFreeTier ? "Public text right-of-reply only. Upgrade to Pulse Starter or higher to unlock Zero-Phone Inbound Calling & Request-to-Call Desk." : "Our verified desk operators respond to call requests within 15 minutes during desk hours.",
		allowedCallTypes: "voice_and_video",
		autoDeclineOffHours: false,
		updatedAt: new Date().toISOString()
	};
	if (typeof window === "undefined") return defaultSettings;
	try {
		const raw = window.localStorage.getItem(`${BRAND_CONTACT_SETTINGS_PREFIX}${normSlug}`);
		if (!raw) return defaultSettings;
		const parsed = JSON.parse(raw);
		return {
			...defaultSettings,
			...parsed
		};
	} catch {
		return defaultSettings;
	}
}
export function saveBrandContactSettings(brandSlug, updates) {
	const normSlug = (brandSlug || "official-brand").toLowerCase().trim();
	const current = getBrandContactSettings(normSlug);
	const updated = {
		...current,
		...updates,
		brandSlug: normSlug,
		updatedAt: new Date().toISOString()
	};
	if (typeof window !== "undefined") {
		try {
			window.localStorage.setItem(`${BRAND_CONTACT_SETTINGS_PREFIX}${normSlug}`, JSON.stringify(updated));
			window.dispatchEvent(new CustomEvent("sot-brand-contact-settings-updated", { detail: updated }));
		} catch {}
	}
	emitOperatorUpdate();
	return updated;
}
export function getInboundCallRequests(brandSlug) {
	const normSlug = brandSlug ? brandSlug.toLowerCase().trim() : undefined;
	if (typeof window === "undefined") return [];
	try {
		const raw = window.localStorage.getItem(INBOUND_CALL_REQUESTS_KEY);
		if (!raw) return [];
		const list = JSON.parse(raw);
		if (!Array.isArray(list)) return [];
		if (!normSlug) return list;
		return list.filter((r) => r.brandSlug.toLowerCase() === normSlug);
	} catch {
		return [];
	}
}
export function submitInboundCallRequest(request) {
	const created = {
		...request,
		id: `call-req-${Date.now()}-${Math.floor(Math.random() * 1e3)}`,
		status: "pending",
		createdAt: new Date().toISOString()
	};
	if (typeof window !== "undefined") {
		try {
			const all = getInboundCallRequests();
			const updated = [created, ...all].slice(0, 100);
			window.localStorage.setItem(INBOUND_CALL_REQUESTS_KEY, JSON.stringify(updated));
			window.dispatchEvent(new CustomEvent("sot-inbound-call-request-created", { detail: created }));
		} catch {}
	}
	emitOperatorUpdate();
	return created;
}
export function updateInboundCallRequestStatus(requestId, status, notes) {
	if (typeof window === "undefined") return;
	try {
		const all = getInboundCallRequests();
		const updated = all.map((r) => r.id === requestId ? {
			...r,
			status,
			...notes ? { operatorNotes: notes } : {}
		} : r);
		window.localStorage.setItem(INBOUND_CALL_REQUESTS_KEY, JSON.stringify(updated));
		window.dispatchEvent(new CustomEvent("sot-inbound-call-request-updated", { detail: {
			requestId,
			status
		} }));
	} catch {}
	emitOperatorUpdate();
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBb0VBLE1BQU0sZ0JBQWdCO0FBQ3RCLE1BQU0seUJBQXlCO0FBQy9CLE1BQU0sbUJBQW1CO0FBQ3pCLE1BQU0sbUJBQW1CO0FBQ3pCLE1BQU0seUJBQXlCO0FBQy9CLE1BQU0sdUJBQXVCO0FBYzdCLE1BQU0sMkJBQW9EO0NBQ3hELElBQUk7Q0FDSixNQUFNO0NBQ04sTUFBTTtDQUNOLFVBQVU7Q0FDVixTQUFTO0NBQ1QsU0FBUztDQUNULGFBQWE7Q0FDYixVQUFVO0FBQ1o7QUFFQSxPQUFPLFNBQVMsNkJBQXNEO0NBQ3BFLElBQUksT0FBTyxXQUFXLGFBQWEsT0FBTztDQUMxQyxJQUFJO0VBQ0YsTUFBTSxNQUFNLE9BQU8sYUFBYSxRQUFRLG9CQUFvQjtFQUM1RCxJQUFJLENBQUMsS0FBSyxPQUFPO0VBQ2pCLE1BQU0sU0FBUyxLQUFLLE1BQU0sR0FBRztFQUM3QixJQUFJLFVBQVUsT0FBTyxPQUFPLFNBQVMsWUFBWSxPQUFPLEtBQUssS0FBSyxHQUFHO0dBQ25FLE9BQU87SUFDTCxHQUFHO0lBQ0gsR0FBRztJQUNILE1BQU0sT0FBTyxLQUFLLEtBQUs7SUFDdkIsTUFDRSxPQUFPLE1BQU0sS0FBSyxLQUNsQixPQUFPLEtBQ0osS0FBSyxDQUFDLENBQ04sWUFBWSxDQUFDLENBQ2IsUUFBUSxlQUFlLEdBQUcsQ0FBQyxDQUMzQixRQUFRLFlBQVksRUFBRSxLQUN6QjtHQUNKO0VBQ0Y7RUFDQSxPQUFPO0NBQ1QsUUFBUTtFQUNOLE9BQU87Q0FDVDtBQUNGO0FBRUEsT0FBTyxTQUFTLDJCQUNkLFNBQ3lCO0NBQ3pCLE1BQU0sVUFBVSwyQkFBMkI7Q0FDM0MsTUFBTSxZQUFZLFFBQVEsS0FBSyxLQUFLLEtBQUssUUFBUTtDQUNqRCxNQUFNLFlBQ0osUUFBUSxNQUFNLEtBQUssS0FDbkIsVUFDRyxZQUFZLENBQUMsQ0FDYixRQUFRLGVBQWUsR0FBRyxDQUFDLENBQzNCLFFBQVEsWUFBWSxFQUFFLEtBQ3pCO0NBQ0YsTUFBTSxVQUFtQztFQUN2QyxHQUFHO0VBQ0gsR0FBRztFQUNILElBQUksUUFBUSxNQUFNLGFBQWE7RUFDL0IsTUFBTTtFQUNOLE1BQU07RUFDTixVQUFVLFFBQVEsWUFBWSxRQUFRLFlBQVk7RUFDbEQsU0FBUyxRQUFRLFdBQVcsUUFBUSxXQUFXO0VBQy9DLFNBQVMsUUFBUSxXQUFXLFFBQVE7RUFDcEMsYUFBYSxPQUFPLFFBQVEsV0FBVyxJQUFJLElBQUksT0FBTyxRQUFRLFdBQVcsSUFBSSxRQUFRO0VBQ3JGLFVBQVUsUUFBUSxZQUFZO0NBQ2hDO0NBQ0EsSUFBSSxPQUFPLFdBQVcsYUFBYTtFQUNqQyxJQUFJO0dBQ0YsT0FBTyxhQUFhLFFBQVEsc0JBQXNCLEtBQUssVUFBVSxPQUFPLENBQUM7R0FDekUsT0FBTyxjQUFjLElBQUksWUFBWSxnQ0FBZ0MsRUFBRSxRQUFRLFFBQVEsQ0FBQyxDQUFDO0VBQzNGLFFBQVEsQ0FFUjtDQUNGO0NBQ0EsbUJBQW1CO0NBQ25CLE9BQU87QUFDVDtBQUVBLE9BQU8sU0FBUyxZQUFZLFFBQWlDO0NBQzNELElBQUksV0FBVywyQkFBMkIsT0FBTztDQUNqRCxJQUFJLFdBQVcsb0JBQW9CLE9BQU87Q0FDMUMsSUFBSSxXQUFXLGlCQUFpQixPQUFPO0NBQ3ZDLE9BQU87QUFDVDtBQUVBLE9BQU8sU0FBUyxlQUNkLFlBQ0EsY0FDUztDQUNULE9BQU8sWUFBWSxVQUFVLEtBQUssWUFBWSxZQUFZO0FBQzVEO0FBRUEsT0FBTyxTQUFTLHVCQUF1QixRQUF5QixXQUFvQjtDQUNsRixNQUFNLFVBQVUsMkJBQTJCO0NBQzNDLE1BQU0sWUFBWTtFQUNoQixHQUFHO0VBQ0gsY0FBYztDQUNoQjtDQUNBLElBQUksT0FBTyxXQUFXLGFBQWE7RUFDakMsSUFBSTtHQUNGLE9BQU8sYUFBYSxRQUFRLHdCQUF3QixLQUFLLFVBQVUsU0FBUyxDQUFDO0VBQy9FLFFBQVEsQ0FFUjtDQUNGO0NBQ0EsSUFBSSxXQUFXO0VBQ2IsTUFBTSxPQUFPLGdCQUFnQixNQUFNLE1BQU0sRUFBRSxPQUFPLE1BQU07RUFDeEQsTUFBTSxXQUFXLHNCQUFzQjtFQUN2QyxrQkFBa0I7R0FDaEIsWUFBWSxTQUFTO0dBQ3JCLGNBQWMsU0FBUztHQUN2QixjQUFjLFNBQVM7R0FDdkIsWUFBWTtHQUNaLFNBQVMsV0FBVyxVQUFVLDRCQUE0QixNQUFNLFFBQVEsT0FBTztFQUNqRixDQUFDO0NBQ0g7Q0FDQSxtQkFBbUI7QUFDckI7QUFxQkEsT0FBTyxTQUFTLDBCQUEwQixXQUd4QztDQUNBLE1BQU0sUUFBUSxVQUFVLEtBQUssS0FBSztDQUNsQyxNQUFNLFNBQVMsTUFBTSxZQUFZLENBQUMsQ0FBQyxRQUFRLGNBQWMsRUFBRSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsS0FBSztDQUM1RSxPQUFPO0VBQ0wsVUFBVTtHQUNSO0lBQ0UsWUFBWSxHQUFHLE1BQU07SUFDckIsUUFBUTtJQUNSLFlBQVk7SUFDWixZQUFZO0lBQ1osVUFBVTtJQUNWLGlCQUFpQjtJQUNqQixXQUFXO0dBQ2I7R0FDQTtJQUNFLFlBQVksR0FBRyxNQUFNO0lBQ3JCLFFBQVE7SUFDUixZQUFZO0lBQ1osWUFBWTtJQUNaLFVBQVU7SUFDVixpQkFBaUI7SUFDakIsV0FBVztHQUNiO0dBQ0E7SUFDRSxZQUFZLEdBQUcsTUFBTTtJQUNyQixRQUFRO0lBQ1IsWUFBWTtJQUNaLFlBQVk7SUFDWixVQUFVO0lBQ1YsaUJBQWlCO0lBQ2pCLFdBQVc7R0FDYjtHQUNBO0lBQ0UsWUFBWSxHQUFHLE1BQU07SUFDckIsUUFBUTtJQUNSLFlBQVk7SUFDWixZQUFZO0lBQ1osVUFBVTtJQUNWLGlCQUFpQjtJQUNqQixXQUFXO0dBQ2I7RUFDRjtFQUNBLGtCQUFrQjtHQUNoQjtJQUNFLElBQUk7SUFDSixXQUFXLElBQUksT0FBTztJQUN0QixVQUFVO0lBQ1YsWUFBWTtJQUNaLFlBQVk7SUFDWixtQkFBbUI7R0FDckI7R0FDQTtJQUNFLElBQUk7SUFDSixXQUFXLElBQUksT0FBTztJQUN0QixVQUFVO0lBQ1YsWUFBWTtJQUNaLFlBQVk7SUFDWixtQkFBbUI7R0FDckI7R0FDQTtJQUNFLElBQUk7SUFDSixXQUFXLElBQUksT0FBTztJQUN0QixVQUFVO0lBQ1YsWUFBWTtJQUNaLFlBQVk7SUFDWixtQkFBbUI7R0FDckI7RUFDRjtDQUNGO0FBQ0Y7QUFFQSxPQUFPLE1BQU0sa0JBQTJDO0NBQ3REO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixTQUFTO0VBQ1QsZ0JBQWdCO0VBQ2hCLGlCQUFpQjtFQUNqQixpQkFBaUI7RUFDakIscUJBQXFCO0VBQ3JCLG9CQUFvQjtFQUNwQix3QkFBd0I7R0FDdEI7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRjtDQUNGO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLFNBQVM7RUFDVCxnQkFBZ0I7RUFDaEIsaUJBQWlCO0VBQ2pCLGlCQUFpQjtFQUNqQixxQkFBcUI7RUFDckIsb0JBQW9CO0VBQ3BCLHdCQUF3QjtHQUN0QjtHQUNBO0dBQ0E7R0FDQTtFQUNGO0NBQ0Y7Q0FDQTtFQUNFLElBQUk7RUFDSixNQUFNO0VBQ04sU0FBUztFQUNULGdCQUFnQjtFQUNoQixpQkFBaUI7RUFDakIsaUJBQWlCO0VBQ2pCLHFCQUFxQjtFQUNyQixvQkFBb0I7RUFDcEIsYUFBYTtFQUNiLHdCQUF3QjtHQUN0QjtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixTQUFTO0VBQ1QsZ0JBQWdCO0VBQ2hCLGlCQUFpQjtFQUNqQixpQkFBaUI7RUFDakIscUJBQXFCO0VBQ3JCLG9CQUFvQjtFQUNwQix3QkFBd0I7R0FDdEI7R0FDQTtHQUNBO0dBQ0E7R0FDQTtFQUNGO0NBQ0Y7QUFDRjtBQUVBLE1BQU0sb0JBQXlDO0NBQzdDO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixXQUFXO0VBQ1gsWUFBWTtFQUNaLGFBQWE7RUFDYixzQkFBc0I7RUFDdEIsZ0JBQWdCO0VBQ2hCLHVCQUF1QjtFQUN2QixrQkFBa0I7RUFDbEIsc0JBQXNCO0VBQ3RCLGtCQUFrQjtFQUNsQixZQUFZO0NBQ2Q7Q0FDQTtFQUNFLElBQUk7RUFDSixNQUFNO0VBQ04sV0FBVztFQUNYLFlBQVk7RUFDWixhQUFhO0VBQ2Isc0JBQXNCO0VBQ3RCLGdCQUFnQjtFQUNoQix1QkFBdUI7RUFDdkIsa0JBQWtCO0VBQ2xCLHNCQUFzQjtFQUN0QixrQkFBa0I7RUFDbEIsWUFBWTtDQUNkO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLFdBQVc7RUFDWCxZQUFZO0VBQ1osYUFBYTtFQUNiLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsdUJBQXVCO0VBQ3ZCLGtCQUFrQjtFQUNsQixzQkFBc0I7RUFDdEIsa0JBQWtCO0VBQ2xCLFlBQVk7Q0FDZDtBQUNGO0FBRUEsTUFBTSx1QkFBNEM7Q0FDaEQ7RUFDRSxJQUFJO0VBQ0osV0FBVztFQUNYLFlBQVk7RUFDWixvQkFBb0I7RUFDcEIsd0JBQXdCO0VBQ3hCLGdCQUFnQjtFQUNoQixrQkFBa0I7RUFDbEIsYUFBYTtFQUNiLGFBQWE7RUFDYixjQUFjO0VBQ2Qsb0JBQW9CO0VBQ3BCLFdBQVc7Q0FDYjtDQUNBO0VBQ0UsSUFBSTtFQUNKLFdBQVc7RUFDWCxZQUFZO0VBQ1osb0JBQW9CO0VBQ3BCLHdCQUF3QjtFQUN4QixnQkFBZ0I7RUFDaEIsa0JBQWtCO0VBQ2xCLGFBQWE7RUFDYixhQUFhO0VBQ2IsY0FBYztFQUNkLG9CQUFvQjtFQUNwQixXQUFXO0NBQ2I7Q0FDQTtFQUNFLElBQUk7RUFDSixXQUFXO0VBQ1gsWUFBWTtFQUNaLG9CQUFvQjtFQUNwQix3QkFBd0I7RUFDeEIsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixhQUFhO0VBQ2IsYUFBYTtFQUNiLGNBQWM7RUFDZCxvQkFBb0I7RUFDcEIsV0FBVztDQUNiO0FBQ0Y7QUFFQSxTQUFTLHFCQUFxQjtDQUM1QixJQUFJLE9BQU8sV0FBVyxhQUFhO0VBQ2pDLE9BQU8sY0FBYyxJQUFJLFlBQVksNEJBQTRCLENBQUM7Q0FDcEU7QUFDRjtBQUVBLE9BQU8sU0FBUyx3QkFBNkM7Q0FDM0QsSUFBSSxPQUFPLFdBQVcsYUFBYSxPQUFPO0NBQzFDLElBQUk7RUFDRixNQUFNLE1BQU0sT0FBTyxhQUFhLFFBQVEsYUFBYTtFQUNyRCxJQUFJLENBQUMsS0FBSztHQUNSLE9BQU8sYUFBYSxRQUFRLGVBQWUsS0FBSyxVQUFVLGlCQUFpQixDQUFDO0dBQzVFLE9BQU87RUFDVDtFQUNBLE1BQU0sU0FBUyxLQUFLLE1BQU0sR0FBRztFQUM3QixPQUFPLE1BQU0sUUFBUSxNQUFNLEtBQUssT0FBTyxTQUFTLElBQUksU0FBUztDQUMvRCxRQUFRO0VBQ04sT0FBTztDQUNUO0FBQ0Y7QUFFQSxPQUFPLFNBQVMsd0JBQTJDO0NBQ3pELE1BQU0sT0FBTyxzQkFBc0I7Q0FDbkMsSUFBSSxPQUFPLFdBQVcsYUFBYSxPQUFPLEtBQUs7Q0FDL0MsSUFBSTtFQUNGLE1BQU0sV0FBVyxPQUFPLGFBQWEsUUFBUSxzQkFBc0I7RUFDbkUsT0FBTyxLQUFLLE1BQU0sTUFBTSxFQUFFLE9BQU8sUUFBUSxLQUFLLEtBQUs7Q0FDckQsUUFBUTtFQUNOLE9BQU8sS0FBSztDQUNkO0FBQ0Y7QUFFQSxPQUFPLFNBQVMseUJBQXlCLFlBQXVDO0NBQzlFLE1BQU0sT0FBTyxzQkFBc0I7Q0FDbkMsTUFBTSxTQUFTLEtBQUssTUFBTSxNQUFNLEVBQUUsT0FBTyxVQUFVLEtBQUssS0FBSztDQUM3RCxJQUFJLE9BQU8sV0FBVyxhQUFhO0VBQ2pDLElBQUk7R0FDRixPQUFPLGFBQWEsUUFBUSx3QkFBd0IsT0FBTyxFQUFFO0dBQzdELGtCQUFrQjtJQUNoQixZQUFZLE9BQU87SUFDbkIsY0FBYyxPQUFPO0lBQ3JCLGNBQWMsT0FBTztJQUNyQixZQUFZO0lBQ1osU0FBUyxvQ0FBb0MsT0FBTyxLQUFLLElBQUksT0FBTyxVQUFVLEtBQUssT0FBTyxXQUFXO0dBQ3ZHLENBQUM7RUFDSCxRQUFRLENBRVI7Q0FDRjtDQUNBLG1CQUFtQjtDQUNuQixPQUFPO0FBQ1Q7QUFFQSxPQUFPLFNBQVMseUJBQXlCLFFBSW5CO0NBQ3BCLE1BQU0sT0FBTyxzQkFBc0I7Q0FDbkMsTUFBTSxRQUEyQjtFQUMvQixJQUFJLE1BQU0sS0FBSyxJQUFJO0VBQ25CLE1BQU0sT0FBTyxLQUFLLEtBQUs7RUFDdkIsV0FBVyxPQUFPLFVBQVUsS0FBSyxLQUFLO0VBQ3RDLFlBQVksT0FBTyxZQUFZLEtBQUssS0FBSztFQUN6QyxhQUFhLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUU7RUFDakQsc0JBQXNCO0VBQ3RCLGdCQUFnQjtFQUNoQix1QkFBdUI7RUFDdkIsa0JBQWtCO0VBQ2xCLHNCQUFzQjtFQUN0QixrQkFBa0I7RUFDbEIsWUFBWTtDQUNkO0NBQ0EsTUFBTSxPQUFPLENBQUMsT0FBTyxHQUFHLElBQUk7Q0FDNUIsSUFBSSxPQUFPLFdBQVcsYUFBYTtFQUNqQyxJQUFJO0dBQ0YsT0FBTyxhQUFhLFFBQVEsZUFBZSxLQUFLLFVBQVUsSUFBSSxDQUFDO0dBQy9ELE9BQU8sYUFBYSxRQUFRLHdCQUF3QixNQUFNLEVBQUU7R0FDNUQsa0JBQWtCO0lBQ2hCLFlBQVksTUFBTTtJQUNsQixjQUFjLE1BQU07SUFDcEIsY0FBYyxNQUFNO0lBQ3BCLFlBQVk7SUFDWixTQUFTLG1EQUFtRCxNQUFNLEtBQUssSUFBSSxNQUFNLFVBQVU7R0FDN0YsQ0FBQztFQUNILFFBQVEsQ0FFUjtDQUNGO0NBQ0EsbUJBQW1CO0NBQ25CLE9BQU87QUFDVDtBQUVBLE9BQU8sU0FBUywrQkFDZCxZQUNBLGVBQ0E7Q0FDQSxNQUFNLFNBQVMsc0JBQXNCO0NBQ3JDLE1BQU0sT0FBTyxzQkFBc0IsQ0FBQyxDQUFDLEtBQUssT0FBTztFQUMvQyxJQUFJLEdBQUcsT0FBTyxPQUFPLElBQUksT0FBTztFQUNoQyxPQUFPO0dBQ0wsR0FBRztHQUNILHNCQUNFLGVBQWUsbUJBQW1CLEdBQUcsdUJBQXVCLElBQUksR0FBRztHQUNyRSxnQkFDRSxlQUFlLG1CQUFtQixHQUFHLGlCQUFpQixJQUFJLEdBQUc7R0FDL0Qsc0JBQ0UsZUFBZSxxQkFBcUIsR0FBRyx1QkFBdUIsSUFBSSxHQUFHO0dBQ3ZFLGtCQUFrQixLQUFLLElBQUksS0FBSyxHQUFHLG1CQUFtQixDQUFDO0VBQ3pEO0NBQ0YsQ0FBQztDQUVELElBQUksT0FBTyxXQUFXLGFBQWE7RUFDakMsSUFBSTtHQUNGLE9BQU8sYUFBYSxRQUFRLGVBQWUsS0FBSyxVQUFVLElBQUksQ0FBQztFQUNqRSxRQUFRLENBRVI7Q0FDRjtDQUNBLGtCQUFrQjtFQUNoQixZQUFZLE9BQU87RUFDbkIsY0FBYyxPQUFPO0VBQ3JCLGNBQWMsT0FBTztFQUNyQjtFQUNBLFNBQVM7Q0FDWCxDQUFDO0NBQ0QsbUJBQW1CO0FBQ3JCO0FBRUEsT0FBTyxTQUFTLGtCQUNkLE9BQ3VCO0NBQ3ZCLE1BQU0sT0FBOEI7RUFDbEMsR0FBRztFQUNILElBQUksT0FBTyxLQUFLLElBQUk7RUFDcEIsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLG1CQUFtQixDQUFDLEdBQUc7R0FBRSxNQUFNO0dBQVcsUUFBUTtFQUFVLENBQUM7Q0FDckY7Q0FDQSxJQUFJLE9BQU8sV0FBVyxhQUFhO0VBQ2pDLElBQUk7R0FDRixNQUFNLFdBQVcscUJBQXFCO0dBQ3RDLE1BQU0sVUFBVSxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRTtHQUMvQyxPQUFPLGFBQWEsUUFBUSxrQkFBa0IsS0FBSyxVQUFVLE9BQU8sQ0FBQztFQUN2RSxRQUFRLENBRVI7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUVBLE9BQU8sU0FBUyx1QkFBZ0Q7Q0FDOUQsTUFBTSxPQUFnQyxDQUNwQztFQUNFLElBQUk7RUFDSixZQUFZO0VBQ1osY0FBYztFQUNkLGNBQWM7RUFDZCxZQUFZO0VBQ1osU0FDRTtFQUNGLFdBQVc7Q0FDYixHQUNBO0VBQ0UsSUFBSTtFQUNKLFlBQVk7RUFDWixjQUFjO0VBQ2QsY0FBYztFQUNkLFlBQVk7RUFDWixTQUFTO0VBQ1QsV0FBVztDQUNiLENBQ0Y7Q0FDQSxJQUFJLE9BQU8sV0FBVyxhQUFhLE9BQU87Q0FDMUMsSUFBSTtFQUNGLE1BQU0sTUFBTSxPQUFPLGFBQWEsUUFBUSxnQkFBZ0I7RUFDeEQsSUFBSSxDQUFDLEtBQUssT0FBTztFQUNqQixNQUFNLFNBQVMsS0FBSyxNQUFNLEdBQUc7RUFDN0IsT0FBTyxNQUFNLFFBQVEsTUFBTSxLQUFLLE9BQU8sU0FBUyxJQUFJLFNBQVM7Q0FDL0QsUUFBUTtFQUNOLE9BQU87Q0FDVDtBQUNGO0FBRUEsT0FBTyxTQUFTLHFCQUFxQixXQUF5QztDQUM1RSxNQUFNLGNBQWMsV0FBVyxLQUFLLEtBQUssMkJBQTJCLENBQUMsQ0FBQztDQUN0RSxNQUFNLFNBQVMsWUFBWSxZQUFZLENBQUMsQ0FBQyxRQUFRLGNBQWMsRUFBRSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsS0FBSztDQUVsRixNQUFNLGlCQUFzQztFQUMxQztHQUNFLElBQUk7R0FDSixXQUFXO0dBQ1gsWUFBWTtHQUNaLG9CQUFvQixZQUFZLFlBQVk7R0FDNUMsd0JBQXdCLG9EQUFvRCxZQUFZO0dBQ3hGLGdCQUFnQjtHQUNoQixrQkFBa0I7R0FDbEIsYUFBYTtHQUNiLGFBQWEsZUFBZSxPQUFPO0dBQ25DLGNBQWM7R0FDZCxvQkFBb0I7R0FDcEIsV0FBVztFQUNiO0VBQ0E7R0FDRSxJQUFJO0dBQ0osV0FBVztHQUNYLFlBQVk7R0FDWixvQkFBb0IsWUFBWSxZQUFZO0dBQzVDLHdCQUF3QixXQUFXLFlBQVksWUFBWSxPQUFPO0dBQ2xFLGdCQUFnQjtHQUNoQixrQkFBa0I7R0FDbEIsYUFBYTtHQUNiLGFBQWEsZUFBZSxPQUFPO0dBQ25DLGNBQWM7R0FDZCxvQkFBb0I7R0FDcEIsV0FBVztFQUNiO0VBQ0E7R0FDRSxJQUFJO0dBQ0osV0FBVztHQUNYLFlBQVk7R0FDWixvQkFBb0IsWUFBWSxZQUFZO0dBQzVDLHdCQUF3QixrQ0FBa0MsWUFBWTtHQUN0RSxnQkFBZ0I7R0FDaEIsa0JBQWtCO0dBQ2xCLGFBQWE7R0FDYixhQUFhLEdBQUcsT0FBTztHQUN2QixjQUFjO0dBQ2Qsb0JBQW9CO0dBQ3BCLFdBQVc7RUFDYjtDQUNGO0NBRUEsSUFBSSxPQUFPLFdBQVcsYUFBYSxPQUFPO0NBQzFDLElBQUk7RUFDRixNQUFNLE1BQU0sT0FBTyxhQUFhLFFBQVEsZ0JBQWdCO0VBQ3hELElBQUksQ0FBQyxLQUFLO0dBQ1IsT0FBTztFQUNUO0VBQ0EsTUFBTSxTQUFTLEtBQUssTUFBTSxHQUFHO0VBQzdCLElBQUksQ0FBQyxNQUFNLFFBQVEsTUFBTSxLQUFLLE9BQU8sV0FBVyxHQUFHLE9BQU87RUFDMUQsTUFBTSxpQkFBaUIsT0FBTyxRQUMzQixNQUNDLEVBQUUsTUFDRixDQUFDO0dBQUM7R0FBVTtHQUFVO0VBQVEsQ0FBQyxDQUFDLFNBQVMsRUFBRSxFQUFFLE1BQzVDLENBQUMsYUFBYSxFQUFFLFVBQVUsWUFBWSxNQUFNLFlBQVksWUFBWSxFQUN6RTtFQUNBLE9BQU8sQ0FBQyxHQUFHLGdCQUFnQixHQUFHLGNBQWM7Q0FDOUMsUUFBUTtFQUNOLE9BQU87Q0FDVDtBQUNGO0FBRUEsT0FBTyxTQUFTLHlCQUF5QixRQUFxRDtDQUM1RixNQUFNLFdBQVcscUJBQXFCO0NBQ3RDLE1BQU0sVUFBNkI7RUFDakMsR0FBRztFQUNILElBQUksTUFBTSxLQUFLLElBQUk7RUFDbkIsV0FBVztDQUNiO0NBQ0EsTUFBTSxPQUFPLENBQUMsU0FBUyxHQUFHLFFBQVE7Q0FDbEMsSUFBSSxPQUFPLFdBQVcsYUFBYTtFQUNqQyxJQUFJO0dBQ0YsT0FBTyxhQUFhLFFBQVEsa0JBQWtCLEtBQUssVUFBVSxJQUFJLENBQUM7RUFDcEUsUUFBUSxDQUVSO0NBQ0Y7Q0FDQSxtQkFBbUI7Q0FDbkIsT0FBTztBQUNUO0FBRUEsT0FBTyxTQUFTLDZCQUdkO0NBQ0EsTUFBTSxXQUFXO0VBQ2YsY0FBYztFQUNkLFVBQVUsQ0FBQztDQUNiO0NBQ0EsSUFBSSxPQUFPLFdBQVcsYUFBYSxPQUFPO0NBQzFDLElBQUk7RUFDRixNQUFNLE1BQU0sT0FBTyxhQUFhLFFBQVEsc0JBQXNCO0VBQzlELElBQUksQ0FBQyxLQUFLLE9BQU87RUFDakIsT0FBTyxLQUFLLE1BQU0sR0FBRztDQUN2QixRQUFRO0VBQ04sT0FBTztDQUNUO0FBQ0Y7QUFFQSxPQUFPLFNBQVMsK0JBQStCLFFBS2xCO0NBQzNCLE1BQU0sT0FBTyxnQkFBZ0IsTUFBTSxNQUFNLEVBQUUsT0FBTyxPQUFPLE1BQU0sS0FBSyxnQkFBZ0I7Q0FDcEYsTUFBTSxXQUFXLHNCQUFzQjtDQUN2QyxNQUFNLGdCQUNKLE9BQU8sYUFBYSxRQUNoQixJQUFJLEtBQUssZ0JBQWdCLGVBQWUsRUFBRSxTQUMxQyxJQUFJLEtBQUssZ0JBQWdCLGVBQWUsRUFBRTtDQUVoRCxNQUFNLFVBQW9DO0VBQ3hDLElBQUksUUFBUSxLQUFLLElBQUk7RUFDckIsV0FBVyxPQUFPO0VBQ2xCLFFBQVEsS0FBSztFQUNiLFVBQVUsS0FBSztFQUNmLGVBQWUsT0FBTztFQUN0QjtFQUNBLGVBQWUsV0FBVyxLQUFLLE1BQU0sTUFBUyxLQUFLLE9BQU8sSUFBSSxNQUFNO0VBQ3BFLGdCQUFnQixHQUFHLFNBQVMsS0FBSyxJQUFJLFNBQVMsVUFBVTtFQUN4RCxRQUFRLE9BQU8sa0JBQWtCLHNCQUFzQixxQkFBcUI7RUFDNUUsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7Q0FDcEM7Q0FFQSxNQUFNLFVBQVUsMkJBQTJCO0NBQzNDLE1BQU0sWUFBWTtFQUNoQixjQUFjLEtBQUs7RUFDbkIsVUFBVSxDQUFDLFNBQVMsR0FBRyxRQUFRLFFBQVEsQ0FBQyxDQUFDLE1BQU0sR0FBRyxFQUFFO0NBQ3REO0NBRUEsSUFBSSxPQUFPLFdBQVcsYUFBYTtFQUNqQyxJQUFJO0dBQ0YsT0FBTyxhQUFhLFFBQVEsd0JBQXdCLEtBQUssVUFBVSxTQUFTLENBQUM7RUFDL0UsUUFBUSxDQUVSO0NBQ0Y7Q0FDQSxtQkFBbUI7Q0FDbkIsT0FBTztBQUNUO0FBK0JBLE1BQU0sZ0NBQWdDO0FBQ3RDLE1BQU0sNEJBQTRCO0FBRWxDLE9BQU8sU0FBUyx3QkFBd0IsV0FBZ0Q7Q0FDdEYsTUFBTSxZQUFZLGFBQWEsaUJBQWdCLENBQUUsWUFBWSxDQUFDLENBQUMsS0FBSztDQUNwRSxNQUFNLE1BQU0sMkJBQTJCO0NBQ3ZDLE1BQU0sYUFBYSxJQUFJLGlCQUFpQjtDQUV4QyxNQUFNLGtCQUErQztFQUNuRCxXQUFXO0VBQ1gsbUJBQW1CLGFBQWEsYUFBYTtFQUM3QyxnQkFBZ0I7RUFDaEIsMkJBQTJCO0VBQzNCLGVBQWUsYUFDWCxxSUFDQTtFQUNKLGtCQUFrQjtFQUNsQixxQkFBcUI7RUFDckIsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7Q0FDcEM7Q0FFQSxJQUFJLE9BQU8sV0FBVyxhQUFhLE9BQU87Q0FDMUMsSUFBSTtFQUNGLE1BQU0sTUFBTSxPQUFPLGFBQWEsUUFBUSxHQUFHLGdDQUFnQyxVQUFVO0VBQ3JGLElBQUksQ0FBQyxLQUFLLE9BQU87RUFDakIsTUFBTSxTQUFTLEtBQUssTUFBTSxHQUFHO0VBQzdCLE9BQU87R0FDTCxHQUFHO0dBQ0gsR0FBRztFQUNMO0NBQ0YsUUFBUTtFQUNOLE9BQU87Q0FDVDtBQUNGO0FBRUEsT0FBTyxTQUFTLHlCQUNkLFdBQ0EsU0FDNkI7Q0FDN0IsTUFBTSxZQUFZLGFBQWEsaUJBQWdCLENBQUUsWUFBWSxDQUFDLENBQUMsS0FBSztDQUNwRSxNQUFNLFVBQVUsd0JBQXdCLFFBQVE7Q0FDaEQsTUFBTSxVQUF1QztFQUMzQyxHQUFHO0VBQ0gsR0FBRztFQUNILFdBQVc7RUFDWCxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtDQUNwQztDQUVBLElBQUksT0FBTyxXQUFXLGFBQWE7RUFDakMsSUFBSTtHQUNGLE9BQU8sYUFBYSxRQUNsQixHQUFHLGdDQUFnQyxZQUNuQyxLQUFLLFVBQVUsT0FBTyxDQUN4QjtHQUNBLE9BQU8sY0FDTCxJQUFJLFlBQVksc0NBQXNDLEVBQUUsUUFBUSxRQUFRLENBQUMsQ0FDM0U7RUFDRixRQUFRLENBRVI7Q0FDRjtDQUNBLG1CQUFtQjtDQUNuQixPQUFPO0FBQ1Q7QUFFQSxPQUFPLFNBQVMsdUJBQXVCLFdBQWtEO0NBQ3ZGLE1BQU0sV0FBVyxZQUFZLFVBQVUsWUFBWSxDQUFDLENBQUMsS0FBSyxJQUFJO0NBQzlELElBQUksT0FBTyxXQUFXLGFBQWEsT0FBTyxDQUFDO0NBQzNDLElBQUk7RUFDRixNQUFNLE1BQU0sT0FBTyxhQUFhLFFBQVEseUJBQXlCO0VBQ2pFLElBQUksQ0FBQyxLQUFLLE9BQU8sQ0FBQztFQUNsQixNQUFNLE9BQXFDLEtBQUssTUFBTSxHQUFHO0VBQ3pELElBQUksQ0FBQyxNQUFNLFFBQVEsSUFBSSxHQUFHLE9BQU8sQ0FBQztFQUNsQyxJQUFJLENBQUMsVUFBVSxPQUFPO0VBQ3RCLE9BQU8sS0FBSyxRQUFRLE1BQU0sRUFBRSxVQUFVLFlBQVksTUFBTSxRQUFRO0NBQ2xFLFFBQVE7RUFDTixPQUFPLENBQUM7Q0FDVjtBQUNGO0FBRUEsT0FBTyxTQUFTLHlCQUNkLFNBQzRCO0NBQzVCLE1BQU0sVUFBc0M7RUFDMUMsR0FBRztFQUNILElBQUksWUFBWSxLQUFLLElBQUksRUFBRSxHQUFHLEtBQUssTUFBTSxLQUFLLE9BQU8sSUFBSSxHQUFJO0VBQzdELFFBQVE7RUFDUixXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtDQUNwQztDQUVBLElBQUksT0FBTyxXQUFXLGFBQWE7RUFDakMsSUFBSTtHQUNGLE1BQU0sTUFBTSx1QkFBdUI7R0FDbkMsTUFBTSxVQUFVLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQyxDQUFDLE1BQU0sR0FBRyxHQUFHO0dBQzlDLE9BQU8sYUFBYSxRQUFRLDJCQUEyQixLQUFLLFVBQVUsT0FBTyxDQUFDO0dBQzlFLE9BQU8sY0FDTCxJQUFJLFlBQVksb0NBQW9DLEVBQUUsUUFBUSxRQUFRLENBQUMsQ0FDekU7RUFDRixRQUFRLENBRVI7Q0FDRjtDQUNBLG1CQUFtQjtDQUNuQixPQUFPO0FBQ1Q7QUFFQSxPQUFPLFNBQVMsK0JBQ2QsV0FDQSxRQUNBLE9BQ007Q0FDTixJQUFJLE9BQU8sV0FBVyxhQUFhO0NBQ25DLElBQUk7RUFDRixNQUFNLE1BQU0sdUJBQXVCO0VBQ25DLE1BQU0sVUFBVSxJQUFJLEtBQUssTUFDdkIsRUFBRSxPQUFPLFlBQVk7R0FBRSxHQUFHO0dBQUc7R0FBUSxHQUFJLFFBQVEsRUFBRSxlQUFlLE1BQU0sSUFBSSxDQUFDO0VBQUcsSUFBSSxDQUN0RjtFQUNBLE9BQU8sYUFBYSxRQUFRLDJCQUEyQixLQUFLLFVBQVUsT0FBTyxDQUFDO0VBQzlFLE9BQU8sY0FDTCxJQUFJLFlBQVksb0NBQW9DLEVBQUUsUUFBUTtHQUFFO0dBQVc7RUFBTyxFQUFFLENBQUMsQ0FDdkY7Q0FDRixRQUFRLENBRVI7Q0FDQSxtQkFBbUI7QUFDckIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiYnJhbmQtb3BlcmF0b3JzLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBpbnRlcmZhY2UgQnJhbmREZXNrT3BlcmF0b3Ige1xuICBpZDogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG4gIHJvbGVUaXRsZTogc3RyaW5nO1xuICBzaGlmdExhYmVsOiBzdHJpbmc7XG4gIGFjdGl2ZVNpbmNlOiBzdHJpbmc7XG4gIHRyYXNoZXNUdXJuZWRUb1N0YXNoOiBudW1iZXI7XG4gIHZvdWNoZXJzSXNzdWVkOiBudW1iZXI7XG4gIG1lZGlhblJlc3BvbnNlTWludXRlczogbnVtYmVyO1xuICBjbGllbnRDYWxsUmF0aW5nOiBudW1iZXI7XG4gIGxpdmVCcm9hZGNhc3RzSG9zdGVkOiBudW1iZXI7XG4gIHNvdE9wZXJhdG9yU2NvcmU6IG51bWJlcjtcbiAgYXdhcmRCYWRnZTogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIE9wZXJhdG9yU2hpZnRMb2dFbnRyeSB7XG4gIGlkOiBzdHJpbmc7XG4gIG9wZXJhdG9ySWQ6IHN0cmluZztcbiAgb3BlcmF0b3JOYW1lOiBzdHJpbmc7XG4gIG9wZXJhdG9yUm9sZTogc3RyaW5nO1xuICBhY3Rpb25UeXBlOiBcInNoaWZ0X2hhbmRvdmVyXCIgfCBcImNsaWVudF9jYWxsXCIgfCBcInZvdWNoZXJfaXNzdWVkXCIgfCBcImxhdW5jaF9icm9hZGNhc3RcIiB8IFwidHJhc2hfdG9fc3Rhc2hcIjtcbiAgc3VtbWFyeTogc3RyaW5nO1xuICB0aW1lc3RhbXA6IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDeExpZmVjeWNsZVJlY29yZCB7XG4gIGlkOiBzdHJpbmc7XG4gIGJyYW5kTmFtZTogc3RyaW5nO1xuICBjbGllbnROYW1lOiBzdHJpbmc7XG4gIHN0YWdlMUxhdW5jaFNvdXJjZTogc3RyaW5nO1xuICBzdGFnZTJTY2FuT3JQb3N0U2lnbmFsOiBzdHJpbmc7XG4gIGluaXRpYWxWZXJkaWN0OiBcInRyYXNoXCIgfCBcInN0YXNoXCI7XG4gIG9wZXJhdG9yQXNzaWduZWQ6IHN0cmluZztcbiAgYWN0aW9uVGFrZW46IHN0cmluZztcbiAgdm91Y2hlckNvZGU/OiBzdHJpbmc7XG4gIGZpbmFsVmVyZGljdDogXCJzdGFzaFwiIHwgXCJ0cmFzaFwiIHwgXCJwZW5kaW5nXCI7XG4gIHJldmVudWVSZXRhaW5lZFphcjogbnVtYmVyO1xuICB1cGRhdGVkQXQ6IHN0cmluZztcbn1cblxuZXhwb3J0IHR5cGUgQnJhbmRQbGFuVGllcklkID0gXCJmcmVlX3B1YmxpY192b2ljZVwiIHwgXCJwdWxzZV9zdGFydGVyXCIgfCBcImN4X2xhdW5jaF9tYXRyaXhcIiB8IFwiZW50ZXJwcmlzZV9pbnRlbGxpZ2VuY2VcIjtcblxuZXhwb3J0IGludGVyZmFjZSBCcmFuZFN1YnNjcmlwdGlvblBsYW4ge1xuICBpZDogQnJhbmRQbGFuVGllcklkO1xuICBuYW1lOiBzdHJpbmc7XG4gIHRhZ2xpbmU6IHN0cmluZztcbiAgdGFyZ2V0QXVkaWVuY2U6IHN0cmluZztcbiAgcHJpY2VaYXJNb250aGx5OiBudW1iZXI7XG4gIHByaWNlVXNkTW9udGhseTogbnVtYmVyO1xuICBicm9hZGNhc3RMaW1pdExhYmVsOiBzdHJpbmc7XG4gIG9wZXJhdG9yU2VhdHNMYWJlbDogc3RyaW5nO1xuICBkYXRhRXh0cmFjdGlvbkZlYXR1cmVzOiBzdHJpbmdbXTtcbiAgaGlnaGxpZ2h0ZWQ/OiBib29sZWFuO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEJyYW5kU3Vic2NyaXB0aW9uUmVjZWlwdCB7XG4gIGlkOiBzdHJpbmc7XG4gIGJyYW5kTmFtZTogc3RyaW5nO1xuICBwbGFuSWQ6IEJyYW5kUGxhblRpZXJJZDtcbiAgcGxhbk5hbWU6IHN0cmluZztcbiAgcGF5bWVudE1ldGhvZDogXCJnb29nbGVfcGF5XCIgfCBcInBheXN0YWNrX2VmdFwiIHwgXCJzdHJpcGVfY2FyZFwiIHwgXCJjb3Jwb3JhdGVfaW52b2ljZVwiO1xuICBhbW91bnREaXNwbGF5OiBzdHJpbmc7XG4gIHJlZmVyZW5jZUNvZGU6IHN0cmluZztcbiAgb3BlcmF0b3JPbkR1dHk6IHN0cmluZztcbiAgc3RhdHVzOiBcImFjdGl2ZVwiIHwgXCJwcm9fZm9ybWFfaXNzdWVkXCI7XG4gIGNyZWF0ZWRBdDogc3RyaW5nO1xufVxuXG5jb25zdCBPUEVSQVRPUlNfS0VZID0gXCJzb3RfYnJhbmRfZGVza19vcGVyYXRvcnNfdjFcIjtcbmNvbnN0IEFDVElWRV9PUEVSQVRPUl9JRF9LRVkgPSBcInNvdF9hY3RpdmVfZGVza19vcGVyYXRvcl9pZF92MVwiO1xuY29uc3QgT1BFUkFUT1JfTE9HX0tFWSA9IFwic290X2JyYW5kX29wZXJhdG9yX2xvZ3NfdjFcIjtcbmNvbnN0IENYX0xJRkVDWUNMRV9LRVkgPSBcInNvdF9icmFuZF9jeF9saWZlY3ljbGVfdjFcIjtcbmNvbnN0IEJSQU5EX1NVQlNDUklQVElPTl9LRVkgPSBcInNvdF9icmFuZF9zdWJzY3JpcHRpb25fc3RhdGVfdjFcIjtcbmNvbnN0IFJFR0lTVEVSRURfQlJBTkRfS0VZID0gXCJzb3RfcmVnaXN0ZXJlZF9icmFuZF9pZGVudGl0eV92MVwiO1xuXG5leHBvcnQgaW50ZXJmYWNlIFJlZ2lzdGVyZWRCcmFuZElkZW50aXR5IHtcbiAgaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBzbHVnOiBzdHJpbmc7XG4gIGNhdGVnb3J5OiBzdHJpbmc7XG4gIGNvdW50cnk6IHN0cmluZztcbiAgd2Vic2l0ZTogc3RyaW5nO1xuICB0cnVzdF9zY29yZTogbnVtYmVyO1xuICB2ZXJpZmllZDogYm9vbGVhbjtcbiAgb3duZXJFbWFpbD86IHN0cmluZztcbn1cblxuY29uc3QgREVGQVVMVF9SRUdJU1RFUkVEX0JSQU5EOiBSZWdpc3RlcmVkQnJhbmRJZGVudGl0eSA9IHtcbiAgaWQ6IFwicmVnaXN0ZXJlZC1icmFuZC1uYW5kb3MtemFcIixcbiAgbmFtZTogXCJOYW5kbydzIFNvdXRoIEFmcmljYVwiLFxuICBzbHVnOiBcIm5hbmRvc1wiLFxuICBjYXRlZ29yeTogXCJGb29kICYgRmFzdCBGb29kXCIsXG4gIGNvdW50cnk6IFwiWkFcIixcbiAgd2Vic2l0ZTogXCJodHRwczovL3d3dy5uYW5kb3MuY28uemFcIixcbiAgdHJ1c3Rfc2NvcmU6IDg2LFxuICB2ZXJpZmllZDogdHJ1ZSxcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRSZWdpc3RlcmVkQnJhbmRJZGVudGl0eSgpOiBSZWdpc3RlcmVkQnJhbmRJZGVudGl0eSB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gREVGQVVMVF9SRUdJU1RFUkVEX0JSQU5EO1xuICB0cnkge1xuICAgIGNvbnN0IHJhdyA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShSRUdJU1RFUkVEX0JSQU5EX0tFWSk7XG4gICAgaWYgKCFyYXcpIHJldHVybiBERUZBVUxUX1JFR0lTVEVSRURfQlJBTkQ7XG4gICAgY29uc3QgcGFyc2VkID0gSlNPTi5wYXJzZShyYXcpIGFzIFBhcnRpYWw8UmVnaXN0ZXJlZEJyYW5kSWRlbnRpdHk+O1xuICAgIGlmIChwYXJzZWQgJiYgdHlwZW9mIHBhcnNlZC5uYW1lID09PSBcInN0cmluZ1wiICYmIHBhcnNlZC5uYW1lLnRyaW0oKSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uREVGQVVMVF9SRUdJU1RFUkVEX0JSQU5ELFxuICAgICAgICAuLi5wYXJzZWQsXG4gICAgICAgIG5hbWU6IHBhcnNlZC5uYW1lLnRyaW0oKSxcbiAgICAgICAgc2x1ZzpcbiAgICAgICAgICBwYXJzZWQuc2x1Zz8udHJpbSgpIHx8XG4gICAgICAgICAgcGFyc2VkLm5hbWVcbiAgICAgICAgICAgIC50cmltKClcbiAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXG4gICAgICAgICAgICAucmVwbGFjZSgvW15hLXowLTldKy9nLCBcIi1cIilcbiAgICAgICAgICAgIC5yZXBsYWNlKC8oXi18LSQpL2csIFwiXCIpIHx8XG4gICAgICAgICAgXCJvZmZpY2lhbC1icmFuZFwiLFxuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIERFRkFVTFRfUkVHSVNURVJFRF9CUkFORDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIERFRkFVTFRfUkVHSVNURVJFRF9CUkFORDtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gc2V0UmVnaXN0ZXJlZEJyYW5kSWRlbnRpdHkoXG4gIHBhcnRpYWw6IFBhcnRpYWw8UmVnaXN0ZXJlZEJyYW5kSWRlbnRpdHk+ICYgeyBuYW1lOiBzdHJpbmcgfSxcbik6IFJlZ2lzdGVyZWRCcmFuZElkZW50aXR5IHtcbiAgY29uc3QgY3VycmVudCA9IGdldFJlZ2lzdGVyZWRCcmFuZElkZW50aXR5KCk7XG4gIGNvbnN0IGNsZWFuTmFtZSA9IHBhcnRpYWwubmFtZS50cmltKCkgfHwgY3VycmVudC5uYW1lO1xuICBjb25zdCBjbGVhblNsdWcgPVxuICAgIHBhcnRpYWwuc2x1Zz8udHJpbSgpIHx8XG4gICAgY2xlYW5OYW1lXG4gICAgICAudG9Mb3dlckNhc2UoKVxuICAgICAgLnJlcGxhY2UoL1teYS16MC05XSsvZywgXCItXCIpXG4gICAgICAucmVwbGFjZSgvKF4tfC0kKS9nLCBcIlwiKSB8fFxuICAgIFwib2ZmaWNpYWwtYnJhbmRcIjtcbiAgY29uc3QgdXBkYXRlZDogUmVnaXN0ZXJlZEJyYW5kSWRlbnRpdHkgPSB7XG4gICAgLi4uY3VycmVudCxcbiAgICAuLi5wYXJ0aWFsLFxuICAgIGlkOiBwYXJ0aWFsLmlkIHx8IGByZWctYnJhbmQtJHtjbGVhblNsdWd9YCxcbiAgICBuYW1lOiBjbGVhbk5hbWUsXG4gICAgc2x1ZzogY2xlYW5TbHVnLFxuICAgIGNhdGVnb3J5OiBwYXJ0aWFsLmNhdGVnb3J5IHx8IGN1cnJlbnQuY2F0ZWdvcnkgfHwgXCJDb25zdW1lciBCcmFuZFwiLFxuICAgIGNvdW50cnk6IHBhcnRpYWwuY291bnRyeSB8fCBjdXJyZW50LmNvdW50cnkgfHwgXCJaQVwiLFxuICAgIHdlYnNpdGU6IHBhcnRpYWwud2Vic2l0ZSA/PyBjdXJyZW50LndlYnNpdGUsXG4gICAgdHJ1c3Rfc2NvcmU6IE51bWJlcihwYXJ0aWFsLnRydXN0X3Njb3JlKSA+IDAgPyBOdW1iZXIocGFydGlhbC50cnVzdF9zY29yZSkgOiBjdXJyZW50LnRydXN0X3Njb3JlLFxuICAgIHZlcmlmaWVkOiBwYXJ0aWFsLnZlcmlmaWVkID8/IHRydWUsXG4gIH07XG4gIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgdHJ5IHtcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShSRUdJU1RFUkVEX0JSQU5EX0tFWSwgSlNPTi5zdHJpbmdpZnkodXBkYXRlZCkpO1xuICAgICAgd2luZG93LmRpc3BhdGNoRXZlbnQobmV3IEN1c3RvbUV2ZW50KFwic290LXJlZ2lzdGVyZWQtYnJhbmQtdXBkYXRlZFwiLCB7IGRldGFpbDogdXBkYXRlZCB9KSk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBpZ25vcmVcbiAgICB9XG4gIH1cbiAgZW1pdE9wZXJhdG9yVXBkYXRlKCk7XG4gIHJldHVybiB1cGRhdGVkO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0VGllclJhbmsocGxhbklkOiBCcmFuZFBsYW5UaWVySWQpOiBudW1iZXIge1xuICBpZiAocGxhbklkID09PSBcImVudGVycHJpc2VfaW50ZWxsaWdlbmNlXCIpIHJldHVybiAzO1xuICBpZiAocGxhbklkID09PSBcImN4X2xhdW5jaF9tYXRyaXhcIikgcmV0dXJuIDI7XG4gIGlmIChwbGFuSWQgPT09IFwicHVsc2Vfc3RhcnRlclwiKSByZXR1cm4gMTtcbiAgcmV0dXJuIDA7IC8vIGZyZWVfcHVibGljX3ZvaWNlXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc1RpZXJFbnRpdGxlZChcbiAgYWN0aXZlVGllcjogQnJhbmRQbGFuVGllcklkLFxuICByZXF1aXJlZFRpZXI6IEJyYW5kUGxhblRpZXJJZCxcbik6IGJvb2xlYW4ge1xuICByZXR1cm4gZ2V0VGllclJhbmsoYWN0aXZlVGllcikgPj0gZ2V0VGllclJhbmsocmVxdWlyZWRUaWVyKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNldEFjdGl2ZUJyYW5kUGxhblRpZXIocGxhbklkOiBCcmFuZFBsYW5UaWVySWQsIGJyYW5kTmFtZT86IHN0cmluZykge1xuICBjb25zdCBjdXJyZW50ID0gZ2V0QWN0aXZlQnJhbmRTdWJzY3JpcHRpb24oKTtcbiAgY29uc3QgbmV4dFN0YXRlID0ge1xuICAgIC4uLmN1cnJlbnQsXG4gICAgYWN0aXZlUGxhbklkOiBwbGFuSWQsXG4gIH07XG4gIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgdHJ5IHtcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShCUkFORF9TVUJTQ1JJUFRJT05fS0VZLCBKU09OLnN0cmluZ2lmeShuZXh0U3RhdGUpKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGlnbm9yZVxuICAgIH1cbiAgfVxuICBpZiAoYnJhbmROYW1lKSB7XG4gICAgY29uc3QgcGxhbiA9IEIyQl9CUkFORF9QTEFOUy5maW5kKChwKSA9PiBwLmlkID09PSBwbGFuSWQpO1xuICAgIGNvbnN0IGFjdGl2ZU9wID0gZ2V0QWN0aXZlRGVza09wZXJhdG9yKCk7XG4gICAgbG9nT3BlcmF0b3JBY3Rpb24oe1xuICAgICAgb3BlcmF0b3JJZDogYWN0aXZlT3AuaWQsXG4gICAgICBvcGVyYXRvck5hbWU6IGFjdGl2ZU9wLm5hbWUsXG4gICAgICBvcGVyYXRvclJvbGU6IGFjdGl2ZU9wLnJvbGVUaXRsZSxcbiAgICAgIGFjdGlvblR5cGU6IFwic2hpZnRfaGFuZG92ZXJcIixcbiAgICAgIHN1bW1hcnk6IGBVcGRhdGVkICR7YnJhbmROYW1lfSBCMkIgU3Vic2NyaXB0aW9uIFRpZXIgdG8gJHtwbGFuPy5uYW1lID8/IHBsYW5JZH0uYCxcbiAgICB9KTtcbiAgfVxuICBlbWl0T3BlcmF0b3JVcGRhdGUoKTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBCcmFuZEJyYW5jaE1ldHJpYyB7XG4gIGJyYW5jaE5hbWU6IHN0cmluZztcbiAgcmVnaW9uOiBzdHJpbmc7XG4gIHN0YXNoQ291bnQ6IG51bWJlcjtcbiAgdHJhc2hDb3VudDogbnVtYmVyO1xuICB0cnVzdFBjdDogbnVtYmVyO1xuICBvcGVuRXNjYWxhdGlvbnM6IG51bWJlcjtcbiAgdG9wU2lnbmFsOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQnJhbmRDb3VudGVyZmVpdEFsZXJ0IHtcbiAgaWQ6IHN0cmluZztcbiAgYmF0Y2hDb2RlOiBzdHJpbmc7XG4gIGxvY2F0aW9uOiBzdHJpbmc7XG4gIHNjYW5TdGF0dXM6IFwiU3VzcGVjdGVkIEdyZXktTWFya2V0IExlYWtcIiB8IFwiVmVyaWZpZWQgQXV0aGVudGljIEJhdGNoXCIgfCBcIlBhY2thZ2luZyBTZWFsIEZsYWdnZWRcIjtcbiAgc2NhbnNDb3VudDogbnVtYmVyO1xuICBhY3Rpb25SZWNvbW1lbmRlZDogc3RyaW5nO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0QnJhbmRTcGVjaWZpY1RlbGVtZXRyeShicmFuZE5hbWU6IHN0cmluZyk6IHtcbiAgYnJhbmNoZXM6IEJyYW5kQnJhbmNoTWV0cmljW107XG4gIGNvdW50ZXJmZWl0UmFkYXI6IEJyYW5kQ291bnRlcmZlaXRBbGVydFtdO1xufSB7XG4gIGNvbnN0IGNsZWFuID0gYnJhbmROYW1lLnRyaW0oKSB8fCBcIlJlZ2lzdGVyZWQgQnJhbmRcIjtcbiAgY29uc3QgcHJlZml4ID0gY2xlYW4udG9VcHBlckNhc2UoKS5yZXBsYWNlKC9bXkEtWjAtOV0vZywgXCJcIikuc2xpY2UoMCwgNSkgfHwgXCJCUkFORFwiO1xuICByZXR1cm4ge1xuICAgIGJyYW5jaGVzOiBbXG4gICAgICB7XG4gICAgICAgIGJyYW5jaE5hbWU6IGAke2NsZWFufSDigJQgU2FuZHRvbiBGbGFnc2hpcCAmIERpZ2l0YWwgSHViYCxcbiAgICAgICAgcmVnaW9uOiBcIkdhdXRlbmcgwrcgSkhCIE5vcnRoXCIsXG4gICAgICAgIHN0YXNoQ291bnQ6IDE4NCxcbiAgICAgICAgdHJhc2hDb3VudDogMTQsXG4gICAgICAgIHRydXN0UGN0OiA5MyxcbiAgICAgICAgb3BlbkVzY2FsYXRpb25zOiAwLFxuICAgICAgICB0b3BTaWduYWw6IFwiRmFzdCB0dXJuYXJvdW5kICYgaGlnaCBsYXVuY2ggdm91Y2hlciByZWRlbXB0aW9uXCIsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBicmFuY2hOYW1lOiBgJHtjbGVhbn0g4oCUIFJvc2ViYW5rICYgTWFsbCBvZiBBZnJpY2FgLFxuICAgICAgICByZWdpb246IFwiR2F1dGVuZyDCtyBNZXRyb1wiLFxuICAgICAgICBzdGFzaENvdW50OiAxNDIsXG4gICAgICAgIHRyYXNoQ291bnQ6IDE5LFxuICAgICAgICB0cnVzdFBjdDogODgsXG4gICAgICAgIG9wZW5Fc2NhbGF0aW9uczogMSxcbiAgICAgICAgdG9wU2lnbmFsOiBcIjIgcGFja2FnaW5nIHNlYWwgY2hlY2tzIHJlc29sdmVkIHdpdGhpbiAxNSBtaW5zXCIsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBicmFuY2hOYW1lOiBgJHtjbGVhbn0g4oCUIFYmQSBXYXRlcmZyb250ICYgQ2FuYWwgV2Fsa2AsXG4gICAgICAgIHJlZ2lvbjogXCJXZXN0ZXJuIENhcGUgwrcgQ1BUXCIsXG4gICAgICAgIHN0YXNoQ291bnQ6IDE2OCxcbiAgICAgICAgdHJhc2hDb3VudDogMTEsXG4gICAgICAgIHRydXN0UGN0OiA5NCxcbiAgICAgICAgb3BlbkVzY2FsYXRpb25zOiAwLFxuICAgICAgICB0b3BTaWduYWw6IFwiVG9wLXJhdGVkIGN1c3RvbWVyIHNlcnZpY2UgZGVzayB0aGlzIHdlZWtcIixcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGJyYW5jaE5hbWU6IGAke2NsZWFufSDigJQgVW1obGFuZ2EgQXJjaCAmIEdhdGV3YXlgLFxuICAgICAgICByZWdpb246IFwiS3dhWnVsdS1OYXRhbCDCtyBEQk5cIixcbiAgICAgICAgc3Rhc2hDb3VudDogMTE5LFxuICAgICAgICB0cmFzaENvdW50OiAyMSxcbiAgICAgICAgdHJ1c3RQY3Q6IDg1LFxuICAgICAgICBvcGVuRXNjYWxhdGlvbnM6IDIsXG4gICAgICAgIHRvcFNpZ25hbDogXCJQZWFrIHdlZWtlbmQgcXVldWUgZmVlZGJhY2sgdW5kZXIgYWN0aXZlIENYIHJldmlld1wiLFxuICAgICAgfSxcbiAgICBdLFxuICAgIGNvdW50ZXJmZWl0UmFkYXI6IFtcbiAgICAgIHtcbiAgICAgICAgaWQ6IFwiY2YtMVwiLFxuICAgICAgICBiYXRjaENvZGU6IGAjJHtwcmVmaXh9LUxPVC04ODRgLFxuICAgICAgICBsb2NhdGlvbjogXCJKb2hhbm5lc2J1cmcgQ0JEIEluZm9ybWFsIFRyYWRlciBDbHVzdGVyXCIsXG4gICAgICAgIHNjYW5TdGF0dXM6IFwiU3VzcGVjdGVkIEdyZXktTWFya2V0IExlYWtcIixcbiAgICAgICAgc2NhbnNDb3VudDogMTQsXG4gICAgICAgIGFjdGlvblJlY29tbWVuZGVkOiBcIklzc3VlIEdlbnVpbmUgU3RvcmUgUmVjb3ZlcnkgVm91Y2hlciAmIGFsZXJ0IHN1cHBseS1jaGFpbiBhdWRpdG9yXCIsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBpZDogXCJjZi0yXCIsXG4gICAgICAgIGJhdGNoQ29kZTogYCMke3ByZWZpeH0tTE9ULTkxMGAsXG4gICAgICAgIGxvY2F0aW9uOiBcIlByZXRvcmlhIEVhc3QgUmV0YWlsIFBhcnRuZXJcIixcbiAgICAgICAgc2NhblN0YXR1czogXCJQYWNrYWdpbmcgU2VhbCBGbGFnZ2VkXCIsXG4gICAgICAgIHNjYW5zQ291bnQ6IDYsXG4gICAgICAgIGFjdGlvblJlY29tbWVuZGVkOiBcIlZpZGVvLWluc3BlY3QgYmF0Y2ggd2l0aCBjdXN0b21lciB2aWEgWmVyby1QaG9uZS1OdW1iZXIgQ2FsbFwiLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6IFwiY2YtM1wiLFxuICAgICAgICBiYXRjaENvZGU6IGAjJHtwcmVmaXh9LUxPVC05NDVgLFxuICAgICAgICBsb2NhdGlvbjogXCJOYXRpb25hbCBBdXRob3Jpc2VkIERpc3RyaWJ1dGlvbiBDaGFubmVsc1wiLFxuICAgICAgICBzY2FuU3RhdHVzOiBcIlZlcmlmaWVkIEF1dGhlbnRpYyBCYXRjaFwiLFxuICAgICAgICBzY2Fuc0NvdW50OiA0MTIsXG4gICAgICAgIGFjdGlvblJlY29tbWVuZGVkOiBcIjEwMCUgYXV0aGVudGljIGJhcmNvZGUgc2NhbnMg4oCUIDk0JSBTdGFzaCBjb252ZXJzaW9uXCIsXG4gICAgICB9LFxuICAgIF0sXG4gIH07XG59XG5cbmV4cG9ydCBjb25zdCBCMkJfQlJBTkRfUExBTlM6IEJyYW5kU3Vic2NyaXB0aW9uUGxhbltdID0gW1xuICB7XG4gICAgaWQ6IFwiZnJlZV9wdWJsaWNfdm9pY2VcIixcbiAgICBuYW1lOiBcIjAwLiBGcmVlIFB1YmxpYyBWb2ljZSAoRmFpcm5lc3MgJiBQdWJsaWMgTW91dGhwaWVjZSlcIixcbiAgICB0YWdsaW5lOiBcIlVucmVzdHJpY3RlZCBwdWJsaWMgcmlnaHQgb2YgcmVwbHkg4oCUIHRleHQgaW4gcHVibGljLCBkZWZlbmQgcHJvZHVjdHMgJiBzdGF0ZSB5b3VyIHRydXRoIGZvciBmcmVlXCIsXG4gICAgdGFyZ2V0QXVkaWVuY2U6IFwiRm9yIFNwYXphcywgRW1lcmdpbmcgQnJhbmRzLCBTdGFydHVwcyAmIEFueSBCdXNpbmVzcyAoMTAwJSBGcmVlIEZvcmV2ZXIpXCIsXG4gICAgcHJpY2VaYXJNb250aGx5OiAwLFxuICAgIHByaWNlVXNkTW9udGhseTogMCxcbiAgICBicm9hZGNhc3RMaW1pdExhYmVsOiBcIlB1YmxpYyBUZXh0IFJlc3BvbnNlcyAoTm8gTGl2ZSBWaWRlbyBCcm9hZGNhc3RzKVwiLFxuICAgIG9wZXJhdG9yU2VhdHNMYWJlbDogXCIxIE9mZmljaWFsIFB1YmxpYyBCcmFuZCBNb3V0aHBpZWNlIERlc2tcIixcbiAgICBkYXRhRXh0cmFjdGlvbkZlYXR1cmVzOiBbXG4gICAgICBcIk9mZmljaWFsIENsYWltZWQgQnJhbmQgUHJvZmlsZSAmIFZlcmlmaWVkIFB1YmxpYyBWb2ljZSBCYWRnZVwiLFxuICAgICAgXCJQdWJsaWMgUmlnaHQgb2YgUmVwbHk6IFRleHQgcHVibGljIHJlc3BvbnNlcyBvbiBjb21tdW5pdHkgVHJhc2ggJiBTdGFzaCBwb3N0c1wiLFxuICAgICAgXCJQdWJsaWMgQnJhbmQgV2FsbCAmIENvbW11bml0eSBFbmdhZ2VtZW50IERlc2tcIixcbiAgICAgIFwiTGl2ZSBQdWJsaWMgU3Rhc2ggdnMgVHJhc2ggU2VudGltZW50IEJhcm9tZXRlciAmIFBlb3BsZSdzIEdyYWRlXCIsXG4gICAgICBcIjEwMCUgRnJlZSBGb3JldmVyIOKAlCBGcmVlZG9tICYgRmFpcm5lc3MgKFplcm8gQ3JlZGl0IENhcmQgUmVxdWlyZWQpXCIsXG4gICAgICBcIvCflJIgUHJpdmF0ZSBDWCBEYXRhIEV4dHJhY3Rpb24gJiBDU1YgUmVwb3J0cyAoUmVxdWlyZXMgUGFpZCBUaWVyKVwiLFxuICAgICAgXCLwn5SSIFplcm8tTnVtYmVyIFByaXZhdGUgQ2FsbGluZyAmIExpdmUgVmlkZW8gU3R1ZGlvcyAoUmVxdWlyZXMgUGFpZCBUaWVyKVwiLFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBpZDogXCJwdWxzZV9zdGFydGVyXCIsXG4gICAgbmFtZTogXCIwMS4gUHVsc2UgU3RhcnRlciAoU01FICYgTG9jYWwgSGVybylcIixcbiAgICB0YWdsaW5lOiBcIkVzc2VudGlhbCBicmFuZCBwcmVzZW5jZSAmIHZlcmlmaWVkIHB1YmxpYyByZXNwb25zZXNcIixcbiAgICB0YXJnZXRBdWRpZW5jZTogXCJGb3IgU3BhemFzLCBMb2NhbCBTdG9yZXMgJiBFbWVyZ2luZyBTTUVzXCIsXG4gICAgcHJpY2VaYXJNb250aGx5OiAxNDUwLFxuICAgIHByaWNlVXNkTW9udGhseTogODUsXG4gICAgYnJvYWRjYXN0TGltaXRMYWJlbDogXCIxNS1NaW4gTGl2ZSBCcm9hZGNhc3RzICgyIC8gbW8pXCIsXG4gICAgb3BlcmF0b3JTZWF0c0xhYmVsOiBcIlVwIHRvIDIgQWN0aXZlIERlc2sgT3BlcmF0b3JzXCIsXG4gICAgZGF0YUV4dHJhY3Rpb25GZWF0dXJlczogW1xuICAgICAgXCJPZmZpY2lhbCBDbGFpbWVkIEJyYW5kIFByb2ZpbGUgJiBWZXJpZmllZCBUcnVzdCBTZWFsXCIsXG4gICAgICBcIkxpdmUgU3Rhc2ggdnMgVHJhc2ggQmFyb21ldGVyICYgUGVvcGxlJ3MgU09UIEdyYWRlXCIsXG4gICAgICBcIlN3aXRjaCBBY3RpdmUgT3BlcmF0b3IgKDIgU3RhZmYgU2hpZnQgU2VhdHMpXCIsXG4gICAgICBcIjE1LU1pbnV0ZSBQcm9kdWN0IFNob3djYXNlIEJyb2FkY2FzdHNcIixcbiAgICBdLFxuICB9LFxuICB7XG4gICAgaWQ6IFwiY3hfbGF1bmNoX21hdHJpeFwiLFxuICAgIG5hbWU6IFwiMDIuIEZ1bGwtQ3ljbGUgQ1ggJiBMYXVuY2ggTWF0cml4XCIsXG4gICAgdGFnbGluZTogXCJDb21wbGV0ZSBMYXVuY2gtdG8tUmVzb2x1dGlvbiBkYXRhIGV4dHJhY3Rpb24gJiBjbGllbnQgY2FsbGluZ1wiLFxuICAgIHRhcmdldEF1ZGllbmNlOiBcIkZvciBOYXRpb25hbCBSZXRhaWxlcnMsIEZhc3QgRm9vZCwgRk1DRyAmIEdyb3d0aCBCcmFuZHNcIixcbiAgICBwcmljZVphck1vbnRobHk6IDQ5NTAsXG4gICAgcHJpY2VVc2RNb250aGx5OiAyOTAsXG4gICAgYnJvYWRjYXN0TGltaXRMYWJlbDogXCI2MC1NaW4gQ29tbWVyY2lhbCBMYXVuY2ggJiBSZWxhdW5jaCBTdHVkaW9cIixcbiAgICBvcGVyYXRvclNlYXRzTGFiZWw6IFwiVXAgdG8gMTAgQWN0aXZlIERlc2sgT3BlcmF0b3JzICsgTGVhZGVyYm9hcmRcIixcbiAgICBoaWdobGlnaHRlZDogdHJ1ZSxcbiAgICBkYXRhRXh0cmFjdGlvbkZlYXR1cmVzOiBbXG4gICAgICBcIkZ1bGwtQ3ljbGUgQ1ggRGF0YSBNYXRyaXggKExhdW5jaCDinpQgVHJhc2ggQ2FsbG91dCDinpQgVm91Y2hlciDinpQgU3Rhc2ggRmxpcClcIixcbiAgICAgIFwiNjAtTWluIExpdmUgUHJvZHVjdCBMYXVuY2ggJiBSZWxhdW5jaCBTdHVkaW8gKyAxLUNsaWNrIFByb21vIERyb3BzXCIsXG4gICAgICBcIlplcm8tUGhvbmUtTnVtYmVyIERpcmVjdCBDbGllbnQgQ2FsbGluZyAmIFJlcXVlc3QtdG8tQ2FsbCBEZXNrXCIsXG4gICAgICBcIkVtcGxveWVlICYgT3BlcmF0b3IgUGVyZm9ybWFuY2UgTGVhZGVyYm9hcmQgKFRyYWNrIFRyYXNoLXRvLVN0YXNoIFJPSSlcIixcbiAgICAgIFwiRXhwb3J0YWJsZSBDU1YgLyBFeGVjdXRpdmUgQ1ggSW50ZWxsaWdlbmNlIFJlcG9ydHNcIixcbiAgICBdLFxuICB9LFxuICB7XG4gICAgaWQ6IFwiZW50ZXJwcmlzZV9pbnRlbGxpZ2VuY2VcIixcbiAgICBuYW1lOiBcIjAzLiBFbnRlcnByaXNlIEludGVsbGlnZW5jZSAmIEF3YXJkcyBTdWl0ZVwiLFxuICAgIHRhZ2xpbmU6IFwiVW5saW1pdGVkIGJyb2FkY2FzdHMsIGNvdW50ZXJmZWl0IHJhZGFyICYgU09yVCBFbXBsb3llZSBBd2FyZHNcIixcbiAgICB0YXJnZXRBdWRpZW5jZTogXCJGb3IgQmFua3MsIFRlbGNvcywgQWlybGluZXMsIE11bHRpbmF0aW9uYWxzICYgQWdlbmNpZXNcIixcbiAgICBwcmljZVphck1vbnRobHk6IDE0OTAwLFxuICAgIHByaWNlVXNkTW9udGhseTogODkwLFxuICAgIGJyb2FkY2FzdExpbWl0TGFiZWw6IFwiVW5saW1pdGVkIEhEIENvbW1lcmNpYWwgQnJvYWRjYXN0cyArIEhvbWUgU3RhZ2UgUHJpb3JpdHlcIixcbiAgICBvcGVyYXRvclNlYXRzTGFiZWw6IFwiVW5saW1pdGVkIERlc2sgT3BlcmF0b3JzICsgT2ZmaWNpYWwgU09yVCBTdGFmZiBBd2FyZHNcIixcbiAgICBkYXRhRXh0cmFjdGlvbkZlYXR1cmVzOiBbXG4gICAgICBcIkV2ZXJ5dGhpbmcgaW4gQ1ggJiBMYXVuY2ggTWF0cml4ICsgUHJpb3JpdHkgSG9tZSBGZWVkIEJyb2FkY2FzdCBTdGFnZVwiLFxuICAgICAgXCJDb3VudGVyZmVpdCAmIEdyZXktTWFya2V0IExlYWsgUmFkYXIgKFN0b3JlLCBCYXRjaCAmIEdlbyBTY2FuIEV4dHJhY3Rpb24pXCIsXG4gICAgICBcIk9mZmljaWFsIFNPclQgRW1wbG95ZWUgUmVjb2duaXRpb24gQXdhcmRzICYgRG93bmxvYWRhYmxlIFN0YWZmIENlcnRpZmljYXRlc1wiLFxuICAgICAgXCIxNOKAkzIwIEJ1c2luZXNzIERheSBDUEEgUHJlLUVzY2FsYXRpb24gU2hpZWxkIChCZWZvcmUgQ0dTTyAvIE5DQylcIixcbiAgICAgIFwiQUkgQ1ggQ29waWxvdCAmIE11bHRpLUJyYW5jaCBFeGVjdXRpdmUgVGVsZW1ldHJ5IEFQSVwiLFxuICAgIF0sXG4gIH0sXG5dO1xuXG5jb25zdCBERUZBVUxUX09QRVJBVE9SUzogQnJhbmREZXNrT3BlcmF0b3JbXSA9IFtcbiAge1xuICAgIGlkOiBcIm9wLWxlcmF0b1wiLFxuICAgIG5hbWU6IFwiTGVyYXRvIE1va29lbmFcIixcbiAgICByb2xlVGl0bGU6IFwiU2VuaW9yIENYICYgTGF1bmNoIERlc2sgTGVhZFwiLFxuICAgIHNoaWZ0TGFiZWw6IFwiRGF5IFNoaWZ0ICgwODowMOKAkzE3OjAwKVwiLFxuICAgIGFjdGl2ZVNpbmNlOiBcIjIwMjYtMDEtMTVcIixcbiAgICB0cmFzaGVzVHVybmVkVG9TdGFzaDogNDIsXG4gICAgdm91Y2hlcnNJc3N1ZWQ6IDM4LFxuICAgIG1lZGlhblJlc3BvbnNlTWludXRlczogMTEsXG4gICAgY2xpZW50Q2FsbFJhdGluZzogNC45NSxcbiAgICBsaXZlQnJvYWRjYXN0c0hvc3RlZDogOSxcbiAgICBzb3RPcGVyYXRvclNjb3JlOiA5NyxcbiAgICBhd2FyZEJhZGdlOiBcIvCfj4YgU09yVCBTdGFyIENYIE9wZXJhdG9yIG9mIHRoZSBNb250aFwiLFxuICB9LFxuICB7XG4gICAgaWQ6IFwib3Atc2lwaG9cIixcbiAgICBuYW1lOiBcIlNpcGhvIERsYW1pbmlcIixcbiAgICByb2xlVGl0bGU6IFwiQ2xpZW50IFJlc29sdXRpb24gJiBSZWNvdmVyeSBTcGVjaWFsaXN0XCIsXG4gICAgc2hpZnRMYWJlbDogXCJBZnRlcm5vb24gLyBFdmVuaW5nIFNoaWZ0XCIsXG4gICAgYWN0aXZlU2luY2U6IFwiMjAyNi0wMi0xMFwiLFxuICAgIHRyYXNoZXNUdXJuZWRUb1N0YXNoOiAzMSxcbiAgICB2b3VjaGVyc0lzc3VlZDogMjksXG4gICAgbWVkaWFuUmVzcG9uc2VNaW51dGVzOiAxNixcbiAgICBjbGllbnRDYWxsUmF0aW5nOiA0Ljg1LFxuICAgIGxpdmVCcm9hZGNhc3RzSG9zdGVkOiA1LFxuICAgIHNvdE9wZXJhdG9yU2NvcmU6IDkxLFxuICAgIGF3YXJkQmFkZ2U6IFwi4pqhIFJhcGlkIFRyYXNoLXRvLVN0YXNoIFR1cm5hcm91bmQgQXdhcmRcIixcbiAgfSxcbiAge1xuICAgIGlkOiBcIm9wLXRoYW5kaVwiLFxuICAgIG5hbWU6IFwiVGhhbmRpIE5kbG92dVwiLFxuICAgIHJvbGVUaXRsZTogXCJDb3VudGVyZmVpdCAmIEJhdGNoIFF1YWxpdHkgQXVkaXRvclwiLFxuICAgIHNoaWZ0TGFiZWw6IFwiUXVhbGl0eSAmIFN1cHBseSBDaGFpbiBEZXNrXCIsXG4gICAgYWN0aXZlU2luY2U6IFwiMjAyNi0wMy0wMVwiLFxuICAgIHRyYXNoZXNUdXJuZWRUb1N0YXNoOiAyNCxcbiAgICB2b3VjaGVyc0lzc3VlZDogMjIsXG4gICAgbWVkaWFuUmVzcG9uc2VNaW51dGVzOiAxOSxcbiAgICBjbGllbnRDYWxsUmF0aW5nOiA0LjgsXG4gICAgbGl2ZUJyb2FkY2FzdHNIb3N0ZWQ6IDYsXG4gICAgc290T3BlcmF0b3JTY29yZTogODgsXG4gICAgYXdhcmRCYWRnZTogXCLwn5uh77iPIENvdW50ZXJmZWl0IEludGVyY2VwdCBDaGFtcGlvblwiLFxuICB9LFxuXTtcblxuY29uc3QgREVGQVVMVF9DWF9MSUZFQ1lDTEU6IEN4TGlmZWN5Y2xlUmVjb3JkW10gPSBbXG4gIHtcbiAgICBpZDogXCJjeC0xMDFcIixcbiAgICBicmFuZE5hbWU6IFwiTmFuZG8nc1wiLFxuICAgIGNsaWVudE5hbWU6IFwiVGhhYm8gTS4gKFZlcmlmaWVkIFZvdGVyKVwiLFxuICAgIHN0YWdlMUxhdW5jaFNvdXJjZTogXCJXYXRjaGVkICdQZXJpLUhvbmV5IExhdW5jaCBCcm9hZGNhc3QnIChDbGFpbWVkIDI1JSBDb2RlKVwiLFxuICAgIHN0YWdlMlNjYW5PclBvc3RTaWduYWw6IFwiUG9zdGVkIFRyYXNoIENhbGxvdXQ6IERyaXZlLXRocnUgbWlzc2luZyBwZXJpLWNoaXBzIGF0IFNhbmR0b25cIixcbiAgICBpbml0aWFsVmVyZGljdDogXCJ0cmFzaFwiLFxuICAgIG9wZXJhdG9yQXNzaWduZWQ6IFwiTGVyYXRvIE1va29lbmEgKFNlbmlvciBDWCBEZXNrKVwiLFxuICAgIGFjdGlvblRha2VuOiBcIlplcm8tUGhvbmUtTnVtYmVyIFNPVCBWaWRlbyBDYWxsICsgSXNzdWVkIFJlY292ZXJ5IFZvdWNoZXJcIixcbiAgICB2b3VjaGVyQ29kZTogXCJTT1RfUkVDT1ZFUl9OQU5ET1NfNDEyXCIsXG4gICAgZmluYWxWZXJkaWN0OiBcInN0YXNoXCIsXG4gICAgcmV2ZW51ZVJldGFpbmVkWmFyOiAxODUwLFxuICAgIHVwZGF0ZWRBdDogXCIxNCBtaW5zIGFnb1wiLFxuICB9LFxuICB7XG4gICAgaWQ6IFwiY3gtMTAyXCIsXG4gICAgYnJhbmROYW1lOiBcIlRha2VhbG90XCIsXG4gICAgY2xpZW50TmFtZTogXCJaYW5lbGUgSy4gKEdvbGQgQXJiaXRyYXRvcilcIixcbiAgICBzdGFnZTFMYXVuY2hTb3VyY2U6IFwiV2F0Y2hlZCAnNDUtTWluIExvY2tlciBSZWxhdW5jaCBCcm9hZGNhc3QnXCIsXG4gICAgc3RhZ2UyU2Nhbk9yUG9zdFNpZ25hbDogXCJTY2FubmVkIEJhcmNvZGUgI0xPVC04ODIgb24gL3NjYW4g4oCUIEZsYWdnZWQgZGFtYWdlZCBvdXRlciBib3hcIixcbiAgICBpbml0aWFsVmVyZGljdDogXCJ0cmFzaFwiLFxuICAgIG9wZXJhdG9yQXNzaWduZWQ6IFwiU2lwaG8gRGxhbWluaSAoUmVzb2x1dGlvbiBEZXNrKVwiLFxuICAgIGFjdGlvblRha2VuOiBcIjEtQ2xpY2sgUmVxdWVzdC10by1DYWxsIEFwcHJvdmVkICsgRXhwcmVzcyBSZXBsYWNlbWVudCBEaXNwYXRjaGVkXCIsXG4gICAgdm91Y2hlckNvZGU6IFwiU09UX1JFQ09WRVJfVEFLRUFMXzgwOVwiLFxuICAgIGZpbmFsVmVyZGljdDogXCJzdGFzaFwiLFxuICAgIHJldmVudWVSZXRhaW5lZFphcjogMzQwMCxcbiAgICB1cGRhdGVkQXQ6IFwiNDIgbWlucyBhZ29cIixcbiAgfSxcbiAge1xuICAgIGlkOiBcImN4LTEwM1wiLFxuICAgIGJyYW5kTmFtZTogXCJCYXRodVwiLFxuICAgIGNsaWVudE5hbWU6IFwiS2FiZWxvIFMuIChMZXZlbCA0IFdhdGNoZG9nKVwiLFxuICAgIHN0YWdlMUxhdW5jaFNvdXJjZTogXCJXYXRjaGVkICdNaWRyYW5kIEZhY3RvcnkgUXVhbGl0eSBUb3VyJ1wiLFxuICAgIHN0YWdlMlNjYW5PclBvc3RTaWduYWw6IFwiUmVwb3J0ZWQgc3VzcGVjdGVkIGdyZXktbWFya2V0IHNuZWFrZXIgc3RhbGwgaW4gQ0JEIHZpYSAvc2NhblwiLFxuICAgIGluaXRpYWxWZXJkaWN0OiBcInRyYXNoXCIsXG4gICAgb3BlcmF0b3JBc3NpZ25lZDogXCJUaGFuZGkgTmRsb3Z1IChRdWFsaXR5IEF1ZGl0b3IpXCIsXG4gICAgYWN0aW9uVGFrZW46IFwiTG9nZ2VkIENvdW50ZXJmZWl0IExlYWsgTG9jYXRpb24gKyBJc3N1ZWQgR2VudWluZSBTdG9yZSBWb3VjaGVyXCIsXG4gICAgdm91Y2hlckNvZGU6IFwiQkFUSFVfUkVBTF8yNTBcIixcbiAgICBmaW5hbFZlcmRpY3Q6IFwic3Rhc2hcIixcbiAgICByZXZlbnVlUmV0YWluZWRaYXI6IDIyMDAsXG4gICAgdXBkYXRlZEF0OiBcIjIgaG91cnMgYWdvXCIsXG4gIH0sXG5dO1xuXG5mdW5jdGlvbiBlbWl0T3BlcmF0b3JVcGRhdGUoKSB7XG4gIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgd2luZG93LmRpc3BhdGNoRXZlbnQobmV3IEN1c3RvbUV2ZW50KFwic290LWJyYW5kLW9wZXJhdG9yLXVwZGF0ZWRcIikpO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRCcmFuZERlc2tPcGVyYXRvcnMoKTogQnJhbmREZXNrT3BlcmF0b3JbXSB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gREVGQVVMVF9PUEVSQVRPUlM7XG4gIHRyeSB7XG4gICAgY29uc3QgcmF3ID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKE9QRVJBVE9SU19LRVkpO1xuICAgIGlmICghcmF3KSB7XG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oT1BFUkFUT1JTX0tFWSwgSlNPTi5zdHJpbmdpZnkoREVGQVVMVF9PUEVSQVRPUlMpKTtcbiAgICAgIHJldHVybiBERUZBVUxUX09QRVJBVE9SUztcbiAgICB9XG4gICAgY29uc3QgcGFyc2VkID0gSlNPTi5wYXJzZShyYXcpIGFzIEJyYW5kRGVza09wZXJhdG9yW107XG4gICAgcmV0dXJuIEFycmF5LmlzQXJyYXkocGFyc2VkKSAmJiBwYXJzZWQubGVuZ3RoID4gMCA/IHBhcnNlZCA6IERFRkFVTFRfT1BFUkFUT1JTO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gREVGQVVMVF9PUEVSQVRPUlM7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldEFjdGl2ZURlc2tPcGVyYXRvcigpOiBCcmFuZERlc2tPcGVyYXRvciB7XG4gIGNvbnN0IGxpc3QgPSBnZXRCcmFuZERlc2tPcGVyYXRvcnMoKTtcbiAgaWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBsaXN0WzBdO1xuICB0cnkge1xuICAgIGNvbnN0IGFjdGl2ZUlkID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKEFDVElWRV9PUEVSQVRPUl9JRF9LRVkpO1xuICAgIHJldHVybiBsaXN0LmZpbmQoKG8pID0+IG8uaWQgPT09IGFjdGl2ZUlkKSA/PyBsaXN0WzBdO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbGlzdFswXTtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gc3dpdGNoQWN0aXZlRGVza09wZXJhdG9yKG9wZXJhdG9ySWQ6IHN0cmluZyk6IEJyYW5kRGVza09wZXJhdG9yIHtcbiAgY29uc3QgbGlzdCA9IGdldEJyYW5kRGVza09wZXJhdG9ycygpO1xuICBjb25zdCBjaG9zZW4gPSBsaXN0LmZpbmQoKG8pID0+IG8uaWQgPT09IG9wZXJhdG9ySWQpID8/IGxpc3RbMF07XG4gIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgdHJ5IHtcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShBQ1RJVkVfT1BFUkFUT1JfSURfS0VZLCBjaG9zZW4uaWQpO1xuICAgICAgbG9nT3BlcmF0b3JBY3Rpb24oe1xuICAgICAgICBvcGVyYXRvcklkOiBjaG9zZW4uaWQsXG4gICAgICAgIG9wZXJhdG9yTmFtZTogY2hvc2VuLm5hbWUsXG4gICAgICAgIG9wZXJhdG9yUm9sZTogY2hvc2VuLnJvbGVUaXRsZSxcbiAgICAgICAgYWN0aW9uVHlwZTogXCJzaGlmdF9oYW5kb3ZlclwiLFxuICAgICAgICBzdW1tYXJ5OiBgQWN0aXZlIEJyYW5kIERlc2sgaGFuZGVkIG92ZXIgdG8gJHtjaG9zZW4ubmFtZX0gKCR7Y2hvc2VuLnJvbGVUaXRsZX0gwrcgJHtjaG9zZW4uc2hpZnRMYWJlbH0pLiBQZXJzb25hbCB1c2VyIHByb2ZpbGUgcmVtYWlucyAxMDAlIHNlcGFyYXRlZC5gLFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBpZ25vcmVcbiAgICB9XG4gIH1cbiAgZW1pdE9wZXJhdG9yVXBkYXRlKCk7XG4gIHJldHVybiBjaG9zZW47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhZGRBbmRTd2l0Y2hEZXNrT3BlcmF0b3IocGFyYW1zOiB7XG4gIG5hbWU6IHN0cmluZztcbiAgcm9sZVRpdGxlOiBzdHJpbmc7XG4gIHNoaWZ0TGFiZWw/OiBzdHJpbmc7XG59KTogQnJhbmREZXNrT3BlcmF0b3Ige1xuICBjb25zdCBsaXN0ID0gZ2V0QnJhbmREZXNrT3BlcmF0b3JzKCk7XG4gIGNvbnN0IG5ld09wOiBCcmFuZERlc2tPcGVyYXRvciA9IHtcbiAgICBpZDogYG9wLSR7RGF0ZS5ub3coKX1gLFxuICAgIG5hbWU6IHBhcmFtcy5uYW1lLnRyaW0oKSxcbiAgICByb2xlVGl0bGU6IHBhcmFtcy5yb2xlVGl0bGUudHJpbSgpIHx8IFwiQXV0aG9yaXplZCBCcmFuZCBDWCBPcGVyYXRvclwiLFxuICAgIHNoaWZ0TGFiZWw6IHBhcmFtcy5zaGlmdExhYmVsPy50cmltKCkgfHwgXCJBY3RpdmUgU2hpZnQgRGVza1wiLFxuICAgIGFjdGl2ZVNpbmNlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApLFxuICAgIHRyYXNoZXNUdXJuZWRUb1N0YXNoOiAxLFxuICAgIHZvdWNoZXJzSXNzdWVkOiAxLFxuICAgIG1lZGlhblJlc3BvbnNlTWludXRlczogMTIsXG4gICAgY2xpZW50Q2FsbFJhdGluZzogNS4wLFxuICAgIGxpdmVCcm9hZGNhc3RzSG9zdGVkOiAxLFxuICAgIHNvdE9wZXJhdG9yU2NvcmU6IDkwLFxuICAgIGF3YXJkQmFkZ2U6IFwi8J+MnyBWZXJpZmllZCBCcmFuZCBEZXNrIEN1c3RvZGlhblwiLFxuICB9O1xuICBjb25zdCBuZXh0ID0gW25ld09wLCAuLi5saXN0XTtcbiAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICB0cnkge1xuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKE9QRVJBVE9SU19LRVksIEpTT04uc3RyaW5naWZ5KG5leHQpKTtcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShBQ1RJVkVfT1BFUkFUT1JfSURfS0VZLCBuZXdPcC5pZCk7XG4gICAgICBsb2dPcGVyYXRvckFjdGlvbih7XG4gICAgICAgIG9wZXJhdG9ySWQ6IG5ld09wLmlkLFxuICAgICAgICBvcGVyYXRvck5hbWU6IG5ld09wLm5hbWUsXG4gICAgICAgIG9wZXJhdG9yUm9sZTogbmV3T3Aucm9sZVRpdGxlLFxuICAgICAgICBhY3Rpb25UeXBlOiBcInNoaWZ0X2hhbmRvdmVyXCIsXG4gICAgICAgIHN1bW1hcnk6IGBSZWdpc3RlcmVkICYgYWN0aXZhdGVkIG5ldyBCcmFuZCBEZXNrIE9wZXJhdG9yOiAke25ld09wLm5hbWV9ICgke25ld09wLnJvbGVUaXRsZX0pLmAsXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGlnbm9yZVxuICAgIH1cbiAgfVxuICBlbWl0T3BlcmF0b3JVcGRhdGUoKTtcbiAgcmV0dXJuIG5ld09wO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVjb3JkT3BlcmF0b3JSZXNvbHV0aW9uTWV0cmljKFxuICBhY3Rpb25UeXBlOiBcImNsaWVudF9jYWxsXCIgfCBcInZvdWNoZXJfaXNzdWVkXCIgfCBcImxhdW5jaF9icm9hZGNhc3RcIiB8IFwidHJhc2hfdG9fc3Rhc2hcIixcbiAgZGV0YWlsU3VtbWFyeTogc3RyaW5nLFxuKSB7XG4gIGNvbnN0IGFjdGl2ZSA9IGdldEFjdGl2ZURlc2tPcGVyYXRvcigpO1xuICBjb25zdCBsaXN0ID0gZ2V0QnJhbmREZXNrT3BlcmF0b3JzKCkubWFwKChvcCkgPT4ge1xuICAgIGlmIChvcC5pZCAhPT0gYWN0aXZlLmlkKSByZXR1cm4gb3A7XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLm9wLFxuICAgICAgdHJhc2hlc1R1cm5lZFRvU3Rhc2g6XG4gICAgICAgIGFjdGlvblR5cGUgPT09IFwidHJhc2hfdG9fc3Rhc2hcIiA/IG9wLnRyYXNoZXNUdXJuZWRUb1N0YXNoICsgMSA6IG9wLnRyYXNoZXNUdXJuZWRUb1N0YXNoLFxuICAgICAgdm91Y2hlcnNJc3N1ZWQ6XG4gICAgICAgIGFjdGlvblR5cGUgPT09IFwidm91Y2hlcl9pc3N1ZWRcIiA/IG9wLnZvdWNoZXJzSXNzdWVkICsgMSA6IG9wLnZvdWNoZXJzSXNzdWVkLFxuICAgICAgbGl2ZUJyb2FkY2FzdHNIb3N0ZWQ6XG4gICAgICAgIGFjdGlvblR5cGUgPT09IFwibGF1bmNoX2Jyb2FkY2FzdFwiID8gb3AubGl2ZUJyb2FkY2FzdHNIb3N0ZWQgKyAxIDogb3AubGl2ZUJyb2FkY2FzdHNIb3N0ZWQsXG4gICAgICBzb3RPcGVyYXRvclNjb3JlOiBNYXRoLm1pbigxMDAsIG9wLnNvdE9wZXJhdG9yU2NvcmUgKyAxKSxcbiAgICB9O1xuICB9KTtcblxuICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgIHRyeSB7XG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oT1BFUkFUT1JTX0tFWSwgSlNPTi5zdHJpbmdpZnkobGlzdCkpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gaWdub3JlXG4gICAgfVxuICB9XG4gIGxvZ09wZXJhdG9yQWN0aW9uKHtcbiAgICBvcGVyYXRvcklkOiBhY3RpdmUuaWQsXG4gICAgb3BlcmF0b3JOYW1lOiBhY3RpdmUubmFtZSxcbiAgICBvcGVyYXRvclJvbGU6IGFjdGl2ZS5yb2xlVGl0bGUsXG4gICAgYWN0aW9uVHlwZSxcbiAgICBzdW1tYXJ5OiBkZXRhaWxTdW1tYXJ5LFxuICB9KTtcbiAgZW1pdE9wZXJhdG9yVXBkYXRlKCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBsb2dPcGVyYXRvckFjdGlvbihcbiAgZW50cnk6IE9taXQ8T3BlcmF0b3JTaGlmdExvZ0VudHJ5LCBcImlkXCIgfCBcInRpbWVzdGFtcFwiPixcbik6IE9wZXJhdG9yU2hpZnRMb2dFbnRyeSB7XG4gIGNvbnN0IGZ1bGw6IE9wZXJhdG9yU2hpZnRMb2dFbnRyeSA9IHtcbiAgICAuLi5lbnRyeSxcbiAgICBpZDogYGxvZy0ke0RhdGUubm93KCl9YCxcbiAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKFtdLCB7IGhvdXI6IFwiMi1kaWdpdFwiLCBtaW51dGU6IFwiMi1kaWdpdFwiIH0pLFxuICB9O1xuICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBleGlzdGluZyA9IGdldE9wZXJhdG9yU2hpZnRMb2dzKCk7XG4gICAgICBjb25zdCB1cGRhdGVkID0gW2Z1bGwsIC4uLmV4aXN0aW5nXS5zbGljZSgwLCAyNSk7XG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oT1BFUkFUT1JfTE9HX0tFWSwgSlNPTi5zdHJpbmdpZnkodXBkYXRlZCkpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gaWdub3JlXG4gICAgfVxuICB9XG4gIHJldHVybiBmdWxsO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0T3BlcmF0b3JTaGlmdExvZ3MoKTogT3BlcmF0b3JTaGlmdExvZ0VudHJ5W10ge1xuICBjb25zdCBzZWVkOiBPcGVyYXRvclNoaWZ0TG9nRW50cnlbXSA9IFtcbiAgICB7XG4gICAgICBpZDogXCJzZWVkLWxvZy0xXCIsXG4gICAgICBvcGVyYXRvcklkOiBcIm9wLWxlcmF0b1wiLFxuICAgICAgb3BlcmF0b3JOYW1lOiBcIkxlcmF0byBNb2tvZW5hXCIsXG4gICAgICBvcGVyYXRvclJvbGU6IFwiU2VuaW9yIENYICYgTGF1bmNoIERlc2sgTGVhZFwiLFxuICAgICAgYWN0aW9uVHlwZTogXCJ0cmFzaF90b19zdGFzaFwiLFxuICAgICAgc3VtbWFyeTpcbiAgICAgICAgXCJSZXNvbHZlZCBTYW5kdG9uIGRyaXZlLXRocnUgVHJhc2ggY2FsbG91dCB2aWEgU09UIFZpZGVvIENhbGwgJiBmbGlwcGVkIGNsaWVudCB2ZXJkaWN0IHRvIFN0YXNoLlwiLFxuICAgICAgdGltZXN0YW1wOiBcIjA5OjQyXCIsXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogXCJzZWVkLWxvZy0yXCIsXG4gICAgICBvcGVyYXRvcklkOiBcIm9wLXNpcGhvXCIsXG4gICAgICBvcGVyYXRvck5hbWU6IFwiU2lwaG8gRGxhbWluaVwiLFxuICAgICAgb3BlcmF0b3JSb2xlOiBcIkNsaWVudCBSZXNvbHV0aW9uIFNwZWNpYWxpc3RcIixcbiAgICAgIGFjdGlvblR5cGU6IFwidm91Y2hlcl9pc3N1ZWRcIixcbiAgICAgIHN1bW1hcnk6IFwiSXNzdWVkIFJldmVudWUgUmVjb3ZlcnkgVm91Y2hlciBTT1RfUkVDT1ZFUl9UQUtFQUxfODA5IGFmdGVyIGJhcmNvZGUgc2NhbiBhbGVydC5cIixcbiAgICAgIHRpbWVzdGFtcDogXCIwOToxNVwiLFxuICAgIH0sXG4gIF07XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gc2VlZDtcbiAgdHJ5IHtcbiAgICBjb25zdCByYXcgPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oT1BFUkFUT1JfTE9HX0tFWSk7XG4gICAgaWYgKCFyYXcpIHJldHVybiBzZWVkO1xuICAgIGNvbnN0IHBhcnNlZCA9IEpTT04ucGFyc2UocmF3KTtcbiAgICByZXR1cm4gQXJyYXkuaXNBcnJheShwYXJzZWQpICYmIHBhcnNlZC5sZW5ndGggPiAwID8gcGFyc2VkIDogc2VlZDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIHNlZWQ7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldEN4TGlmZWN5Y2xlTWF0cml4KGJyYW5kTmFtZT86IHN0cmluZyk6IEN4TGlmZWN5Y2xlUmVjb3JkW10ge1xuICBjb25zdCB0YXJnZXRCcmFuZCA9IGJyYW5kTmFtZT8udHJpbSgpIHx8IGdldFJlZ2lzdGVyZWRCcmFuZElkZW50aXR5KCkubmFtZTtcbiAgY29uc3QgcHJlZml4ID0gdGFyZ2V0QnJhbmQudG9VcHBlckNhc2UoKS5yZXBsYWNlKC9bXkEtWjAtOV0vZywgXCJcIikuc2xpY2UoMCwgNikgfHwgXCJCUkFORFwiO1xuXG4gIGNvbnN0IHNjb3BlZERlZmF1bHRzOiBDeExpZmVjeWNsZVJlY29yZFtdID0gW1xuICAgIHtcbiAgICAgIGlkOiBcImN4LTEwMVwiLFxuICAgICAgYnJhbmROYW1lOiB0YXJnZXRCcmFuZCxcbiAgICAgIGNsaWVudE5hbWU6IFwiVGhhYm8gTS4gKFZlcmlmaWVkIFZvdGVyKVwiLFxuICAgICAgc3RhZ2UxTGF1bmNoU291cmNlOiBgV2F0Y2hlZCAnJHt0YXJnZXRCcmFuZH0gUHJvZHVjdCBMYXVuY2ggQnJvYWRjYXN0JyAoQ2xhaW1lZCAyNSUgQ29kZSlgLFxuICAgICAgc3RhZ2UyU2Nhbk9yUG9zdFNpZ25hbDogYFBvc3RlZCBUcmFzaCBDYWxsb3V0OiBPcmRlciBmdWxmaWxsbWVudCBkZWxheSBhdCAke3RhcmdldEJyYW5kfSBTYW5kdG9uIGJyYW5jaGAsXG4gICAgICBpbml0aWFsVmVyZGljdDogXCJ0cmFzaFwiLFxuICAgICAgb3BlcmF0b3JBc3NpZ25lZDogXCJMZXJhdG8gTW9rb2VuYSAoU2VuaW9yIENYIERlc2spXCIsXG4gICAgICBhY3Rpb25UYWtlbjogXCJaZXJvLVBob25lLU51bWJlciBTT1QgVmlkZW8gQ2FsbCArIElzc3VlZCBSZWNvdmVyeSBWb3VjaGVyXCIsXG4gICAgICB2b3VjaGVyQ29kZTogYFNPVF9SRUNPVkVSXyR7cHJlZml4fV80MTJgLFxuICAgICAgZmluYWxWZXJkaWN0OiBcInN0YXNoXCIsXG4gICAgICByZXZlbnVlUmV0YWluZWRaYXI6IDE4NTAsXG4gICAgICB1cGRhdGVkQXQ6IFwiMTQgbWlucyBhZ29cIixcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiBcImN4LTEwMlwiLFxuICAgICAgYnJhbmROYW1lOiB0YXJnZXRCcmFuZCxcbiAgICAgIGNsaWVudE5hbWU6IFwiWmFuZWxlIEsuIChHb2xkIEFyYml0cmF0b3IpXCIsXG4gICAgICBzdGFnZTFMYXVuY2hTb3VyY2U6IGBXYXRjaGVkICcke3RhcmdldEJyYW5kfSA0NS1NaW4gUmVsYXVuY2ggQnJvYWRjYXN0J2AsXG4gICAgICBzdGFnZTJTY2FuT3JQb3N0U2lnbmFsOiBgU2Nhbm5lZCAke3RhcmdldEJyYW5kfSBCYXJjb2RlICMke3ByZWZpeH0tODgyIG9uIC9zY2FuIOKAlCBGbGFnZ2VkIG91dGVyIHNlYWxgLFxuICAgICAgaW5pdGlhbFZlcmRpY3Q6IFwidHJhc2hcIixcbiAgICAgIG9wZXJhdG9yQXNzaWduZWQ6IFwiU2lwaG8gRGxhbWluaSAoUmVzb2x1dGlvbiBEZXNrKVwiLFxuICAgICAgYWN0aW9uVGFrZW46IFwiMS1DbGljayBSZXF1ZXN0LXRvLUNhbGwgQXBwcm92ZWQgKyBFeHByZXNzIFJlcGxhY2VtZW50IERpc3BhdGNoZWRcIixcbiAgICAgIHZvdWNoZXJDb2RlOiBgU09UX1JFQ09WRVJfJHtwcmVmaXh9XzgwOWAsXG4gICAgICBmaW5hbFZlcmRpY3Q6IFwic3Rhc2hcIixcbiAgICAgIHJldmVudWVSZXRhaW5lZFphcjogMzQwMCxcbiAgICAgIHVwZGF0ZWRBdDogXCI0MiBtaW5zIGFnb1wiLFxuICAgIH0sXG4gICAge1xuICAgICAgaWQ6IFwiY3gtMTAzXCIsXG4gICAgICBicmFuZE5hbWU6IHRhcmdldEJyYW5kLFxuICAgICAgY2xpZW50TmFtZTogXCJLYWJlbG8gUy4gKExldmVsIDQgV2F0Y2hkb2cpXCIsXG4gICAgICBzdGFnZTFMYXVuY2hTb3VyY2U6IGBXYXRjaGVkICcke3RhcmdldEJyYW5kfSBCZWhpbmQtdGhlLVNjZW5lcyBRdWFsaXR5IFRvdXInYCxcbiAgICAgIHN0YWdlMlNjYW5PclBvc3RTaWduYWw6IGBSZXBvcnRlZCBzdXNwZWN0ZWQgZ3JleS1tYXJrZXQgJHt0YXJnZXRCcmFuZH0gYmF0Y2ggaW4gQ0JEIHZpYSAvc2NhbmAsXG4gICAgICBpbml0aWFsVmVyZGljdDogXCJ0cmFzaFwiLFxuICAgICAgb3BlcmF0b3JBc3NpZ25lZDogXCJUaGFuZGkgTmRsb3Z1IChRdWFsaXR5IEF1ZGl0b3IpXCIsXG4gICAgICBhY3Rpb25UYWtlbjogXCJMb2dnZWQgQ291bnRlcmZlaXQgTGVhayBMb2NhdGlvbiArIElzc3VlZCBHZW51aW5lIFN0b3JlIFZvdWNoZXJcIixcbiAgICAgIHZvdWNoZXJDb2RlOiBgJHtwcmVmaXh9X1JFQUxfMjUwYCxcbiAgICAgIGZpbmFsVmVyZGljdDogXCJzdGFzaFwiLFxuICAgICAgcmV2ZW51ZVJldGFpbmVkWmFyOiAyMjAwLFxuICAgICAgdXBkYXRlZEF0OiBcIjIgaG91cnMgYWdvXCIsXG4gICAgfSxcbiAgXTtcblxuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIHNjb3BlZERlZmF1bHRzO1xuICB0cnkge1xuICAgIGNvbnN0IHJhdyA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShDWF9MSUZFQ1lDTEVfS0VZKTtcbiAgICBpZiAoIXJhdykge1xuICAgICAgcmV0dXJuIHNjb3BlZERlZmF1bHRzO1xuICAgIH1cbiAgICBjb25zdCBwYXJzZWQgPSBKU09OLnBhcnNlKHJhdykgYXMgQ3hMaWZlY3ljbGVSZWNvcmRbXTtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkocGFyc2VkKSB8fCBwYXJzZWQubGVuZ3RoID09PSAwKSByZXR1cm4gc2NvcGVkRGVmYXVsdHM7XG4gICAgY29uc3QgY3VzdG9tRm9yQnJhbmQgPSBwYXJzZWQuZmlsdGVyKFxuICAgICAgKHIpID0+XG4gICAgICAgIHIuaWQgJiZcbiAgICAgICAgIVtcImN4LTEwMVwiLCBcImN4LTEwMlwiLCBcImN4LTEwM1wiXS5pbmNsdWRlcyhyLmlkKSAmJlxuICAgICAgICAoIWJyYW5kTmFtZSB8fCByLmJyYW5kTmFtZS50b0xvd2VyQ2FzZSgpID09PSB0YXJnZXRCcmFuZC50b0xvd2VyQ2FzZSgpKSxcbiAgICApO1xuICAgIHJldHVybiBbLi4uY3VzdG9tRm9yQnJhbmQsIC4uLnNjb3BlZERlZmF1bHRzXTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIHNjb3BlZERlZmF1bHRzO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhZGRDeExpZmVjeWNsZVJlc29sdXRpb24ocmVjb3JkOiBPbWl0PEN4TGlmZWN5Y2xlUmVjb3JkLCBcImlkXCIgfCBcInVwZGF0ZWRBdFwiPikge1xuICBjb25zdCBleGlzdGluZyA9IGdldEN4TGlmZWN5Y2xlTWF0cml4KCk7XG4gIGNvbnN0IGNyZWF0ZWQ6IEN4TGlmZWN5Y2xlUmVjb3JkID0ge1xuICAgIC4uLnJlY29yZCxcbiAgICBpZDogYGN4LSR7RGF0ZS5ub3coKX1gLFxuICAgIHVwZGF0ZWRBdDogXCJKdXN0IG5vd1wiLFxuICB9O1xuICBjb25zdCBuZXh0ID0gW2NyZWF0ZWQsIC4uLmV4aXN0aW5nXTtcbiAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICB0cnkge1xuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKENYX0xJRkVDWUNMRV9LRVksIEpTT04uc3RyaW5naWZ5KG5leHQpKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGlnbm9yZVxuICAgIH1cbiAgfVxuICBlbWl0T3BlcmF0b3JVcGRhdGUoKTtcbiAgcmV0dXJuIGNyZWF0ZWQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRBY3RpdmVCcmFuZFN1YnNjcmlwdGlvbigpOiB7XG4gIGFjdGl2ZVBsYW5JZDogQnJhbmRQbGFuVGllcklkO1xuICByZWNlaXB0czogQnJhbmRTdWJzY3JpcHRpb25SZWNlaXB0W107XG59IHtcbiAgY29uc3QgZmFsbGJhY2sgPSB7XG4gICAgYWN0aXZlUGxhbklkOiBcImN4X2xhdW5jaF9tYXRyaXhcIiBhcyBCcmFuZFBsYW5UaWVySWQsXG4gICAgcmVjZWlwdHM6IFtdIGFzIEJyYW5kU3Vic2NyaXB0aW9uUmVjZWlwdFtdLFxuICB9O1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIGZhbGxiYWNrO1xuICB0cnkge1xuICAgIGNvbnN0IHJhdyA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShCUkFORF9TVUJTQ1JJUFRJT05fS0VZKTtcbiAgICBpZiAoIXJhdykgcmV0dXJuIGZhbGxiYWNrO1xuICAgIHJldHVybiBKU09OLnBhcnNlKHJhdyk7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBmYWxsYmFjaztcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVjb3JkQnJhbmRTdWJzY3JpcHRpb25QYXltZW50KHBhcmFtczoge1xuICBicmFuZE5hbWU6IHN0cmluZztcbiAgcGxhbklkOiBCcmFuZFBsYW5UaWVySWQ7XG4gIHBheW1lbnRNZXRob2Q6IEJyYW5kU3Vic2NyaXB0aW9uUmVjZWlwdFtcInBheW1lbnRNZXRob2RcIl07XG4gIGN1cnJlbmN5OiBcIlpBUlwiIHwgXCJVU0RcIjtcbn0pOiBCcmFuZFN1YnNjcmlwdGlvblJlY2VpcHQge1xuICBjb25zdCBwbGFuID0gQjJCX0JSQU5EX1BMQU5TLmZpbmQoKHApID0+IHAuaWQgPT09IHBhcmFtcy5wbGFuSWQpID8/IEIyQl9CUkFORF9QTEFOU1sxXTtcbiAgY29uc3QgYWN0aXZlT3AgPSBnZXRBY3RpdmVEZXNrT3BlcmF0b3IoKTtcbiAgY29uc3QgYW1vdW50RGlzcGxheSA9XG4gICAgcGFyYW1zLmN1cnJlbmN5ID09PSBcIlpBUlwiXG4gICAgICA/IGBSJHtwbGFuLnByaWNlWmFyTW9udGhseS50b0xvY2FsZVN0cmluZygpfSAvIG1vYFxuICAgICAgOiBgJCR7cGxhbi5wcmljZVVzZE1vbnRobHkudG9Mb2NhbGVTdHJpbmcoKX0gLyBtb2A7XG5cbiAgY29uc3QgcmVjZWlwdDogQnJhbmRTdWJzY3JpcHRpb25SZWNlaXB0ID0ge1xuICAgIGlkOiBgcmNwdC0ke0RhdGUubm93KCl9YCxcbiAgICBicmFuZE5hbWU6IHBhcmFtcy5icmFuZE5hbWUsXG4gICAgcGxhbklkOiBwbGFuLmlkLFxuICAgIHBsYW5OYW1lOiBwbGFuLm5hbWUsXG4gICAgcGF5bWVudE1ldGhvZDogcGFyYW1zLnBheW1lbnRNZXRob2QsXG4gICAgYW1vdW50RGlzcGxheSxcbiAgICByZWZlcmVuY2VDb2RlOiBgU09ULUIyQi0ke01hdGguZmxvb3IoMTAwMDAwICsgTWF0aC5yYW5kb20oKSAqIDg5OTk5OSl9YCxcbiAgICBvcGVyYXRvck9uRHV0eTogYCR7YWN0aXZlT3AubmFtZX0gKCR7YWN0aXZlT3Aucm9sZVRpdGxlfSlgLFxuICAgIHN0YXR1czogcGFyYW1zLnBheW1lbnRNZXRob2QgPT09IFwiY29ycG9yYXRlX2ludm9pY2VcIiA/IFwicHJvX2Zvcm1hX2lzc3VlZFwiIDogXCJhY3RpdmVcIixcbiAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgfTtcblxuICBjb25zdCBjdXJyZW50ID0gZ2V0QWN0aXZlQnJhbmRTdWJzY3JpcHRpb24oKTtcbiAgY29uc3QgbmV4dFN0YXRlID0ge1xuICAgIGFjdGl2ZVBsYW5JZDogcGxhbi5pZCxcbiAgICByZWNlaXB0czogW3JlY2VpcHQsIC4uLmN1cnJlbnQucmVjZWlwdHNdLnNsaWNlKDAsIDE1KSxcbiAgfTtcblxuICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgIHRyeSB7XG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oQlJBTkRfU1VCU0NSSVBUSU9OX0tFWSwgSlNPTi5zdHJpbmdpZnkobmV4dFN0YXRlKSk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBpZ25vcmVcbiAgICB9XG4gIH1cbiAgZW1pdE9wZXJhdG9yVXBkYXRlKCk7XG4gIHJldHVybiByZWNlaXB0O1xufVxuXG5leHBvcnQgdHlwZSBCcmFuZERpcmVjdENhbGxpbmdNb2RlID0gXCJvcGVuXCIgfCBcInJlcXVlc3Rfb25seVwiIHwgXCJkaXNhYmxlZFwiO1xuXG5leHBvcnQgaW50ZXJmYWNlIEJyYW5kSW5ib3VuZENvbnRhY3RTZXR0aW5ncyB7XG4gIGJyYW5kU2x1Zzogc3RyaW5nO1xuICBkaXJlY3RDYWxsaW5nTW9kZTogQnJhbmREaXJlY3RDYWxsaW5nTW9kZTtcbiAgb3BlcmF0aW5nSG91cnM6IHN0cmluZztcbiAgcmVxdWlyZU9yZGVyT3JCYXRjaE51bWJlcjogYm9vbGVhbjtcbiAgY29udGFjdE5vdGljZTogc3RyaW5nO1xuICBhbGxvd2VkQ2FsbFR5cGVzOiBcInZvaWNlX2FuZF92aWRlb1wiIHwgXCJ2b2ljZV9vbmx5XCIgfCBcIm1lc3NhZ2VzX29ubHlcIjtcbiAgYXV0b0RlY2xpbmVPZmZIb3VyczogYm9vbGVhbjtcbiAgdXBkYXRlZEF0OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSW5ib3VuZEN1c3RvbWVyQ2FsbFJlcXVlc3Qge1xuICBpZDogc3RyaW5nO1xuICBicmFuZFNsdWc6IHN0cmluZztcbiAgYnJhbmROYW1lOiBzdHJpbmc7XG4gIGN1c3RvbWVySWQ6IHN0cmluZztcbiAgY3VzdG9tZXJOYW1lOiBzdHJpbmc7XG4gIGlzc3VlVG9waWM6IHN0cmluZztcbiAgcHJvZHVjdE5hbWU/OiBzdHJpbmc7XG4gIGJhdGNoT3JSZWNlaXB0TnVtYmVyPzogc3RyaW5nO1xuICB1cmdlbmN5OiBcImxvd1wiIHwgXCJtZWRpdW1cIiB8IFwiaGlnaFwiIHwgXCJ1cmdlbnRfY3BhXCI7XG4gIHJlcXVlc3RlZENhbGxNb2RlOiBcInZvaWNlXCIgfCBcInZpZGVvXCI7XG4gIHN0YXR1czogXCJwZW5kaW5nXCIgfCBcIm9wZXJhdG9yX2NhbGxpbmdcIiB8IFwicmVzb2x2ZWRcIiB8IFwiZGVjbGluZWRcIjtcbiAgY3JlYXRlZEF0OiBzdHJpbmc7XG4gIG9wZXJhdG9yTm90ZXM/OiBzdHJpbmc7XG59XG5cbmNvbnN0IEJSQU5EX0NPTlRBQ1RfU0VUVElOR1NfUFJFRklYID0gXCJzb3RfYnJhbmRfY29udGFjdF9zZXR0aW5nc192MV9cIjtcbmNvbnN0IElOQk9VTkRfQ0FMTF9SRVFVRVNUU19LRVkgPSBcInNvdF9pbmJvdW5kX2NhbGxfcmVxdWVzdHNfdjFcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIGdldEJyYW5kQ29udGFjdFNldHRpbmdzKGJyYW5kU2x1Zzogc3RyaW5nKTogQnJhbmRJbmJvdW5kQ29udGFjdFNldHRpbmdzIHtcbiAgY29uc3Qgbm9ybVNsdWcgPSAoYnJhbmRTbHVnIHx8IFwib2ZmaWNpYWwtYnJhbmRcIikudG9Mb3dlckNhc2UoKS50cmltKCk7XG4gIGNvbnN0IHN1YiA9IGdldEFjdGl2ZUJyYW5kU3Vic2NyaXB0aW9uKCk7XG4gIGNvbnN0IGlzRnJlZVRpZXIgPSBzdWIuYWN0aXZlUGxhbklkID09PSBcImZyZWVfcHVibGljX3ZvaWNlXCI7XG5cbiAgY29uc3QgZGVmYXVsdFNldHRpbmdzOiBCcmFuZEluYm91bmRDb250YWN0U2V0dGluZ3MgPSB7XG4gICAgYnJhbmRTbHVnOiBub3JtU2x1ZyxcbiAgICBkaXJlY3RDYWxsaW5nTW9kZTogaXNGcmVlVGllciA/IFwiZGlzYWJsZWRcIiA6IFwicmVxdWVzdF9vbmx5XCIsXG4gICAgb3BlcmF0aW5nSG91cnM6IFwiMDg6MDAgLSAxNzowMCAoU0FTVCBEZXNrKVwiLFxuICAgIHJlcXVpcmVPcmRlck9yQmF0Y2hOdW1iZXI6IGZhbHNlLFxuICAgIGNvbnRhY3ROb3RpY2U6IGlzRnJlZVRpZXJcbiAgICAgID8gXCJQdWJsaWMgdGV4dCByaWdodC1vZi1yZXBseSBvbmx5LiBVcGdyYWRlIHRvIFB1bHNlIFN0YXJ0ZXIgb3IgaGlnaGVyIHRvIHVubG9jayBaZXJvLVBob25lIEluYm91bmQgQ2FsbGluZyAmIFJlcXVlc3QtdG8tQ2FsbCBEZXNrLlwiXG4gICAgICA6IFwiT3VyIHZlcmlmaWVkIGRlc2sgb3BlcmF0b3JzIHJlc3BvbmQgdG8gY2FsbCByZXF1ZXN0cyB3aXRoaW4gMTUgbWludXRlcyBkdXJpbmcgZGVzayBob3Vycy5cIixcbiAgICBhbGxvd2VkQ2FsbFR5cGVzOiBcInZvaWNlX2FuZF92aWRlb1wiLFxuICAgIGF1dG9EZWNsaW5lT2ZmSG91cnM6IGZhbHNlLFxuICAgIHVwZGF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICB9O1xuXG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gZGVmYXVsdFNldHRpbmdzO1xuICB0cnkge1xuICAgIGNvbnN0IHJhdyA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShgJHtCUkFORF9DT05UQUNUX1NFVFRJTkdTX1BSRUZJWH0ke25vcm1TbHVnfWApO1xuICAgIGlmICghcmF3KSByZXR1cm4gZGVmYXVsdFNldHRpbmdzO1xuICAgIGNvbnN0IHBhcnNlZCA9IEpTT04ucGFyc2UocmF3KTtcbiAgICByZXR1cm4ge1xuICAgICAgLi4uZGVmYXVsdFNldHRpbmdzLFxuICAgICAgLi4ucGFyc2VkLFxuICAgIH07XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBkZWZhdWx0U2V0dGluZ3M7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNhdmVCcmFuZENvbnRhY3RTZXR0aW5ncyhcbiAgYnJhbmRTbHVnOiBzdHJpbmcsXG4gIHVwZGF0ZXM6IFBhcnRpYWw8QnJhbmRJbmJvdW5kQ29udGFjdFNldHRpbmdzPixcbik6IEJyYW5kSW5ib3VuZENvbnRhY3RTZXR0aW5ncyB7XG4gIGNvbnN0IG5vcm1TbHVnID0gKGJyYW5kU2x1ZyB8fCBcIm9mZmljaWFsLWJyYW5kXCIpLnRvTG93ZXJDYXNlKCkudHJpbSgpO1xuICBjb25zdCBjdXJyZW50ID0gZ2V0QnJhbmRDb250YWN0U2V0dGluZ3Mobm9ybVNsdWcpO1xuICBjb25zdCB1cGRhdGVkOiBCcmFuZEluYm91bmRDb250YWN0U2V0dGluZ3MgPSB7XG4gICAgLi4uY3VycmVudCxcbiAgICAuLi51cGRhdGVzLFxuICAgIGJyYW5kU2x1Zzogbm9ybVNsdWcsXG4gICAgdXBkYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gIH07XG5cbiAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICB0cnkge1xuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFxuICAgICAgICBgJHtCUkFORF9DT05UQUNUX1NFVFRJTkdTX1BSRUZJWH0ke25vcm1TbHVnfWAsXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHVwZGF0ZWQpLFxuICAgICAgKTtcbiAgICAgIHdpbmRvdy5kaXNwYXRjaEV2ZW50KFxuICAgICAgICBuZXcgQ3VzdG9tRXZlbnQoXCJzb3QtYnJhbmQtY29udGFjdC1zZXR0aW5ncy11cGRhdGVkXCIsIHsgZGV0YWlsOiB1cGRhdGVkIH0pLFxuICAgICAgKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGlnbm9yZVxuICAgIH1cbiAgfVxuICBlbWl0T3BlcmF0b3JVcGRhdGUoKTtcbiAgcmV0dXJuIHVwZGF0ZWQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRJbmJvdW5kQ2FsbFJlcXVlc3RzKGJyYW5kU2x1Zz86IHN0cmluZyk6IEluYm91bmRDdXN0b21lckNhbGxSZXF1ZXN0W10ge1xuICBjb25zdCBub3JtU2x1ZyA9IGJyYW5kU2x1ZyA/IGJyYW5kU2x1Zy50b0xvd2VyQ2FzZSgpLnRyaW0oKSA6IHVuZGVmaW5lZDtcbiAgaWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBbXTtcbiAgdHJ5IHtcbiAgICBjb25zdCByYXcgPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oSU5CT1VORF9DQUxMX1JFUVVFU1RTX0tFWSk7XG4gICAgaWYgKCFyYXcpIHJldHVybiBbXTtcbiAgICBjb25zdCBsaXN0OiBJbmJvdW5kQ3VzdG9tZXJDYWxsUmVxdWVzdFtdID0gSlNPTi5wYXJzZShyYXcpO1xuICAgIGlmICghQXJyYXkuaXNBcnJheShsaXN0KSkgcmV0dXJuIFtdO1xuICAgIGlmICghbm9ybVNsdWcpIHJldHVybiBsaXN0O1xuICAgIHJldHVybiBsaXN0LmZpbHRlcigocikgPT4gci5icmFuZFNsdWcudG9Mb3dlckNhc2UoKSA9PT0gbm9ybVNsdWcpO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gW107XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHN1Ym1pdEluYm91bmRDYWxsUmVxdWVzdChcbiAgcmVxdWVzdDogT21pdDxJbmJvdW5kQ3VzdG9tZXJDYWxsUmVxdWVzdCwgXCJpZFwiIHwgXCJzdGF0dXNcIiB8IFwiY3JlYXRlZEF0XCI+LFxuKTogSW5ib3VuZEN1c3RvbWVyQ2FsbFJlcXVlc3Qge1xuICBjb25zdCBjcmVhdGVkOiBJbmJvdW5kQ3VzdG9tZXJDYWxsUmVxdWVzdCA9IHtcbiAgICAuLi5yZXF1ZXN0LFxuICAgIGlkOiBgY2FsbC1yZXEtJHtEYXRlLm5vdygpfS0ke01hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDEwMDApfWAsXG4gICAgc3RhdHVzOiBcInBlbmRpbmdcIixcbiAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgfTtcblxuICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBhbGwgPSBnZXRJbmJvdW5kQ2FsbFJlcXVlc3RzKCk7XG4gICAgICBjb25zdCB1cGRhdGVkID0gW2NyZWF0ZWQsIC4uLmFsbF0uc2xpY2UoMCwgMTAwKTtcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShJTkJPVU5EX0NBTExfUkVRVUVTVFNfS0VZLCBKU09OLnN0cmluZ2lmeSh1cGRhdGVkKSk7XG4gICAgICB3aW5kb3cuZGlzcGF0Y2hFdmVudChcbiAgICAgICAgbmV3IEN1c3RvbUV2ZW50KFwic290LWluYm91bmQtY2FsbC1yZXF1ZXN0LWNyZWF0ZWRcIiwgeyBkZXRhaWw6IGNyZWF0ZWQgfSksXG4gICAgICApO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gaWdub3JlXG4gICAgfVxuICB9XG4gIGVtaXRPcGVyYXRvclVwZGF0ZSgpO1xuICByZXR1cm4gY3JlYXRlZDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZUluYm91bmRDYWxsUmVxdWVzdFN0YXR1cyhcbiAgcmVxdWVzdElkOiBzdHJpbmcsXG4gIHN0YXR1czogSW5ib3VuZEN1c3RvbWVyQ2FsbFJlcXVlc3RbXCJzdGF0dXNcIl0sXG4gIG5vdGVzPzogc3RyaW5nLFxuKTogdm9pZCB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm47XG4gIHRyeSB7XG4gICAgY29uc3QgYWxsID0gZ2V0SW5ib3VuZENhbGxSZXF1ZXN0cygpO1xuICAgIGNvbnN0IHVwZGF0ZWQgPSBhbGwubWFwKChyKSA9PlxuICAgICAgci5pZCA9PT0gcmVxdWVzdElkID8geyAuLi5yLCBzdGF0dXMsIC4uLihub3RlcyA/IHsgb3BlcmF0b3JOb3Rlczogbm90ZXMgfSA6IHt9KSB9IDogcixcbiAgICApO1xuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShJTkJPVU5EX0NBTExfUkVRVUVTVFNfS0VZLCBKU09OLnN0cmluZ2lmeSh1cGRhdGVkKSk7XG4gICAgd2luZG93LmRpc3BhdGNoRXZlbnQoXG4gICAgICBuZXcgQ3VzdG9tRXZlbnQoXCJzb3QtaW5ib3VuZC1jYWxsLXJlcXVlc3QtdXBkYXRlZFwiLCB7IGRldGFpbDogeyByZXF1ZXN0SWQsIHN0YXR1cyB9IH0pLFxuICAgICk7XG4gIH0gY2F0Y2gge1xuICAgIC8vIGlnbm9yZVxuICB9XG4gIGVtaXRPcGVyYXRvclVwZGF0ZSgpO1xufVxuXG4iXX0=