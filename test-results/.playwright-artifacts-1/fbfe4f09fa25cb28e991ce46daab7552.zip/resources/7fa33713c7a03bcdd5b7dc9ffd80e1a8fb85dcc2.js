import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SubmitDialog.tsx");const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport18_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport18_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=a8030269";
import { useAuth } from "/src/hooks/useAuth.tsx";
import { createItem } from "/src/lib/stash.ts";
import { BrandSearch } from "/src/components/BrandSearch.tsx";
import { ProductScannerModal } from "/src/components/ProductScannerModal.tsx";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "/src/components/ui/dialog.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Textarea } from "/src/components/ui/textarea.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { Plus, ImagePlus, Scan, Sparkles, Building2, ShieldCheck, AlertTriangle, CheckCircle2, X } from "/node_modules/.vite/deps/lucide-react.js?v=a8030269";
import coinIcon from "/src/assets/icon-coin.png?import";
import binIcon from "/src/assets/icon-bin.png?import";
import { cn } from "/src/lib/utils.ts";
import { playStashSound, playTrashSound } from "/src/lib/verdict-sounds.ts";
import { VerdictSuccess, triggerVerdictSuccess } from "/src/components/VerdictSuccess.tsx";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=a8030269";
var _jsxFileName = "/app/applet/src/components/SubmitDialog.tsx";
import __vite__cjsImport18_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
var _s = $RefreshSig$();
const NO_BRAND = "__none__";
const FEEDBACK_TYPES = [
	"Concern",
	"Compliment",
	"Idea",
	"Question"
];
export function SubmitDialog({ onPosted, defaultBrandId, open: controlledOpen, onOpenChange: setControlledOpen, initialValues }) {
	_s();
	const { user } = useAuth();
	const { t } = useTranslation();
	const [uncontrolledOpen, setUncontrolledOpen] = useState(false);
	const isControlled = controlledOpen !== undefined;
	const open = isControlled ? controlledOpen : uncontrolledOpen;
	const setOpen = isControlled ? setControlledOpen ?? (() => {}) : setUncontrolledOpen;
	const [scannerOpen, setScannerOpen] = useState(false);
	const [title, setTitle] = useState(initialValues?.title ?? "");
	const [description, setDescription] = useState(initialValues?.description ?? "");
	const [category, setCategory] = useState(initialValues?.category ?? "");
	const [brandId, setBrandId] = useState(defaultBrandId ?? NO_BRAND);
	const [file, setFile] = useState(initialValues?.file ?? null);
	const [aiScanResult, setAiScanResult] = useState(initialValues?.aiScanResult ?? null);
	const [verdict, setVerdict] = useState(null);
	const [submitting, setSubmitting] = useState(false);
	useEffect(() => {
		if (initialValues) {
			if (initialValues.title !== undefined) setTitle(initialValues.title);
			if (initialValues.description !== undefined) setDescription(initialValues.description);
			if (initialValues.category !== undefined) setCategory(initialValues.category);
			if (initialValues.file !== undefined) setFile(initialValues.file);
			if (initialValues.aiScanResult !== undefined) setAiScanResult(initialValues.aiScanResult);
		}
	}, [initialValues]);
	const reset = () => {
		setTitle("");
		setDescription("");
		setCategory("");
		setBrandId(defaultBrandId ?? NO_BRAND);
		setFile(null);
		setAiScanResult(null);
		setVerdict(null);
	};
	const handleScannerApply = (data) => {
		if (data.matchedBrandId) {
			setBrandId(data.matchedBrandId);
		}
		setTitle(data.productName ? `${data.brandName} — ${data.productName}` : `${data.brandName} Experience`);
		setDescription(`Product: ${data.productName || data.brandName}\nCorporate Owner: ${data.brandOwner}\n${data.scanResult.brandInfo.parentCompanyContext}\n[Forensic Authenticity Score: ${data.scanResult.authenticity.score}% - ${data.scanResult.authenticity.badgeLabel}]`);
		if (data.category) {
			setCategory(data.category);
		}
		if (data.file) {
			setFile(data.file);
		}
		setAiScanResult(data.scanResult);
		toast.success(`Auto-filled: ${data.brandName} (Corporate Owner: ${data.brandOwner})`);
	};
	const handleSubmit = async () => {
		if (!user) return;
		if (!title.trim()) {
			toast.error(t("submit.needTitle"));
			return;
		}
		if (!verdict) {
			toast.error(t("submit.needVerdict"));
			return;
		}
		setSubmitting(true);
		try {
			await createItem({
				userId: user.id,
				title,
				description,
				file,
				brandId: brandId === NO_BRAND ? null : brandId,
				category,
				verdict,
				aiScanResult
			});
			toast.success(t("submit.posted"));
			reset();
			setOpen(false);
			onPosted?.();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : t("submit.error"));
		} finally {
			setSubmitting(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Dialog, {
		open,
		onOpenChange: setOpen,
		"data-tsd-source": "/src/components/SubmitDialog.tsx:172:7",
		children: [!isControlled && /* @__PURE__ */ _jsxDEV(DialogTrigger, {
			asChild: true,
			"data-tsd-source": "/src/components/SubmitDialog.tsx:174:11",
			children: /* @__PURE__ */ _jsxDEV(Button, {
				size: "sm",
				className: "gap-1.5 font-semibold",
				"data-tsd-source": "/src/components/SubmitDialog.tsx:175:13",
				children: [
					/* @__PURE__ */ _jsxDEV(Plus, {
						className: "h-4 w-4",
						"data-tsd-source": "/src/components/SubmitDialog.tsx:176:15"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 176,
						columnNumber: 15
					}, this),
					" ",
					t("submit.trigger")
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 175,
				columnNumber: 13
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 174,
			columnNumber: 11
		}, this), /* @__PURE__ */ _jsxDEV(DialogContent, {
			className: "max-w-xl max-h-[90vh] overflow-y-auto",
			"data-tsd-source": "/src/components/SubmitDialog.tsx:180:9",
			children: [
				/* @__PURE__ */ _jsxDEV(DialogHeader, {
					"data-tsd-source": "/src/components/SubmitDialog.tsx:181:11",
					children: [/* @__PURE__ */ _jsxDEV(DialogTitle, {
						className: "font-display text-2xl",
						"data-tsd-source": "/src/components/SubmitDialog.tsx:182:13",
						children: t("submit.title")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 182,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(DialogDescription, {
						"data-tsd-source": "/src/components/SubmitDialog.tsx:183:13",
						children: t("submit.intro")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 183,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 181,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-4 py-2",
					"data-tsd-source": "/src/components/SubmitDialog.tsx:186:11",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "rounded-xl border border-primary/30 bg-primary/5 p-3 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs",
							"data-tsd-source": "/src/components/SubmitDialog.tsx:188:13",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-0.5 text-center sm:text-left",
								"data-tsd-source": "/src/components/SubmitDialog.tsx:189:15",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-center sm:justify-start gap-1.5 font-bold text-xs text-primary",
									"data-tsd-source": "/src/components/SubmitDialog.tsx:190:17",
									children: [/* @__PURE__ */ _jsxDEV(Scan, {
										className: "h-3.5 w-3.5",
										"data-tsd-source": "/src/components/SubmitDialog.tsx:191:19"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 191,
										columnNumber: 19
									}, this), " Auto-Identify Brand & Owner"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 190,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-muted-foreground",
									"data-tsd-source": "/src/components/SubmitDialog.tsx:193:17",
									children: "Scan the product packaging, QR code, or barcode. AI detects the parent company and verifies authenticity."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 193,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 189,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Button, {
								type: "button",
								size: "sm",
								onClick: () => setScannerOpen(true),
								className: "gap-1.5 text-xs font-semibold shrink-0 shadow-sm",
								"data-tsd-source": "/src/components/SubmitDialog.tsx:197:15",
								children: [/* @__PURE__ */ _jsxDEV(Sparkles, {
									className: "h-3.5 w-3.5",
									"data-tsd-source": "/src/components/SubmitDialog.tsx:203:17"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 203,
									columnNumber: 17
								}, this), " Scan Product / QR"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 197,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 188,
							columnNumber: 13
						}, this),
						aiScanResult && /* @__PURE__ */ _jsxDEV("div", {
							className: "rounded-xl border border-border bg-card p-3 space-y-2 shadow-xs",
							"data-tsd-source": "/src/components/SubmitDialog.tsx:209:15",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								"data-tsd-source": "/src/components/SubmitDialog.tsx:210:17",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold flex items-center gap-1.5 text-primary",
									"data-tsd-source": "/src/components/SubmitDialog.tsx:211:19",
									children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, {
										className: "h-3.5 w-3.5 text-primary",
										"data-tsd-source": "/src/components/SubmitDialog.tsx:212:21"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 212,
										columnNumber: 21
									}, this), " AI Verified Brand & Evidence"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 211,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV(Button, {
									type: "button",
									variant: "ghost",
									size: "icon",
									className: "h-6 w-6 text-muted-foreground hover:text-foreground",
									onClick: () => setAiScanResult(null),
									title: "Remove AI metadata",
									"data-tsd-source": "/src/components/SubmitDialog.tsx:214:19",
									children: /* @__PURE__ */ _jsxDEV(X, {
										className: "h-3.5 w-3.5",
										"data-tsd-source": "/src/components/SubmitDialog.tsx:222:21"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 222,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 214,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 210,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs",
								"data-tsd-source": "/src/components/SubmitDialog.tsx:226:17",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-2 rounded bg-muted/40 border border-border/50",
									"data-tsd-source": "/src/components/SubmitDialog.tsx:227:19",
									children: [
										/* @__PURE__ */ _jsxDEV("p", {
											className: "font-semibold text-foreground flex items-center gap-1",
											"data-tsd-source": "/src/components/SubmitDialog.tsx:228:21",
											children: [/* @__PURE__ */ _jsxDEV(Building2, {
												className: "h-3.5 w-3.5 text-amber-600",
												"data-tsd-source": "/src/components/SubmitDialog.tsx:229:23"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 229,
												columnNumber: 23
											}, this), " Corporate Owner:"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 228,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[11px] font-bold text-foreground mt-0.5",
											"data-tsd-source": "/src/components/SubmitDialog.tsx:231:21",
											children: aiScanResult.brandInfo.brandOwner
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 231,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] text-muted-foreground mt-0.5 line-clamp-1",
											"data-tsd-source": "/src/components/SubmitDialog.tsx:234:21",
											children: aiScanResult.brandInfo.parentCompanyContext
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 234,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 227,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "p-2 rounded bg-muted/40 border border-border/50",
									"data-tsd-source": "/src/components/SubmitDialog.tsx:239:19",
									children: [
										/* @__PURE__ */ _jsxDEV("p", {
											className: "font-semibold text-foreground flex items-center gap-1",
											"data-tsd-source": "/src/components/SubmitDialog.tsx:240:21",
											children: [aiScanResult.authenticity.isLegitimate ? /* @__PURE__ */ _jsxDEV(ShieldCheck, {
												className: "h-3.5 w-3.5 text-emerald-600",
												"data-tsd-source": "/src/components/SubmitDialog.tsx:242:25"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 242,
												columnNumber: 25
											}, this) : /* @__PURE__ */ _jsxDEV(AlertTriangle, {
												className: "h-3.5 w-3.5 text-rose-600",
												"data-tsd-source": "/src/components/SubmitDialog.tsx:244:25"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 244,
												columnNumber: 25
											}, this), "Evidence Legitimacy:"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 240,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[11px] font-bold text-foreground mt-0.5",
											"data-tsd-source": "/src/components/SubmitDialog.tsx:248:21",
											children: [aiScanResult.authenticity.score, "% Authentic"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 248,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] text-muted-foreground mt-0.5 line-clamp-1",
											"data-tsd-source": "/src/components/SubmitDialog.tsx:251:21",
											children: aiScanResult.authenticity.badgeLabel
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 251,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 239,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 226,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 209,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							"data-tsd-source": "/src/components/SubmitDialog.tsx:259:13",
							children: [/* @__PURE__ */ _jsxDEV(Label, {
								htmlFor: "title",
								"data-tsd-source": "/src/components/SubmitDialog.tsx:260:15",
								children: t("submit.fieldTitle")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 260,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Input, {
								id: "title",
								value: title,
								onChange: (e) => setTitle(e.target.value),
								placeholder: t("submit.titlePh"),
								maxLength: 120,
								"data-tsd-source": "/src/components/SubmitDialog.tsx:261:15"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 261,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 259,
							columnNumber: 13
						}, this),
						!defaultBrandId && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							"data-tsd-source": "/src/components/SubmitDialog.tsx:271:15",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									"data-tsd-source": "/src/components/SubmitDialog.tsx:272:17",
									children: [/* @__PURE__ */ _jsxDEV(Label, {
										"data-tsd-source": "/src/components/SubmitDialog.tsx:273:19",
										children: t("submit.brand")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 273,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-muted-foreground",
										"data-tsd-source": "/src/components/SubmitDialog.tsx:274:19",
										children: "Auto-filled if scanned"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 274,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 272,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV(BrandSearch, {
									onSelectBrand: (b) => setBrandId(b.id),
									selectedId: brandId === NO_BRAND ? undefined : brandId,
									placeholder: t("submit.brandPh"),
									"data-tsd-source": "/src/components/SubmitDialog.tsx:278:17"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 278,
									columnNumber: 17
								}, this),
								brandId !== NO_BRAND && /* @__PURE__ */ _jsxDEV(Button, {
									type: "button",
									variant: "ghost",
									size: "sm",
									className: "h-8 px-2",
									onClick: () => setBrandId(NO_BRAND),
									"data-tsd-source": "/src/components/SubmitDialog.tsx:284:19",
									children: t("submit.noBrand")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 284,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 271,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "relative space-y-2 overflow-hidden rounded-xl",
							"data-tsd-source": "/src/components/SubmitDialog.tsx:297:13",
							children: [
								/* @__PURE__ */ _jsxDEV(VerdictSuccess, {
									active: verdict === "stash",
									inline: true,
									duration: 1800,
									label: "STASH SELECTED!",
									sublabel: "Keep what serves you · Gold standard",
									"data-tsd-source": "/src/components/SubmitDialog.tsx:298:15"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 298,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Label, {
									"data-tsd-source": "/src/components/SubmitDialog.tsx:305:15",
									children: t("submit.verdict")
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 305,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-3",
									"data-tsd-source": "/src/components/SubmitDialog.tsx:306:15",
									children: [/* @__PURE__ */ _jsxDEV(Button, {
										type: "button",
										variant: "stash",
										size: "lg",
										onClick: () => {
											playStashSound();
											setVerdict("stash");
											triggerVerdictSuccess({
												label: "STASH VERDICT!",
												sublabel: "Keep what serves you · Gold standard selected"
											});
										},
										className: cn("gap-2", verdict === "stash" && "verdict-picked", verdict === "trash" && "verdict-dimmed"),
										"data-tsd-source": "/src/components/SubmitDialog.tsx:307:17",
										children: [
											/* @__PURE__ */ _jsxDEV("img", {
												src: coinIcon,
												alt: "",
												"aria-hidden": true,
												className: "verdict-icon",
												"data-tsd-source": "/src/components/SubmitDialog.tsx:325:19"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 325,
												columnNumber: 19
											}, this),
											" ",
											t("vote.stash")
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 307,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV(Button, {
										type: "button",
										variant: "trash",
										size: "lg",
										onClick: () => {
											playTrashSound();
											setVerdict("trash");
										},
										className: cn("gap-2", verdict === "trash" && "verdict-picked", verdict === "stash" && "verdict-dimmed"),
										"data-tsd-source": "/src/components/SubmitDialog.tsx:327:17",
										children: [
											/* @__PURE__ */ _jsxDEV("img", {
												src: binIcon,
												alt: "",
												"aria-hidden": true,
												className: "verdict-icon",
												"data-tsd-source": "/src/components/SubmitDialog.tsx:341:19"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 341,
												columnNumber: 19
											}, this),
											" ",
											t("vote.trash")
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 327,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 306,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 297,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							"data-tsd-source": "/src/components/SubmitDialog.tsx:346:13",
							children: [
								/* @__PURE__ */ _jsxDEV(Label, {
									htmlFor: "category",
									"data-tsd-source": "/src/components/SubmitDialog.tsx:347:15",
									children: "What kind of feedback is this?"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 347,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
									"data-tsd-source": "/src/components/SubmitDialog.tsx:348:15",
									children: FEEDBACK_TYPES.map((type) => /* @__PURE__ */ _jsxDEV(Button, {
										type: "button",
										variant: category === type ? "default" : "outline",
										size: "sm",
										onClick: () => setCategory(type),
										"data-tsd-source": "/src/components/SubmitDialog.tsx:350:19",
										children: type
									}, type, false, {
										fileName: _jsxFileName,
										lineNumber: 350,
										columnNumber: 19
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 348,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Input, {
									id: "category",
									value: category,
									onChange: (e) => setCategory(e.target.value),
									placeholder: "Add a more specific topic, if useful",
									maxLength: 40,
									"data-tsd-source": "/src/components/SubmitDialog.tsx:361:15"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 361,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 346,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							"data-tsd-source": "/src/components/SubmitDialog.tsx:370:13",
							children: [/* @__PURE__ */ _jsxDEV(Label, {
								htmlFor: "desc",
								"data-tsd-source": "/src/components/SubmitDialog.tsx:371:15",
								children: t("submit.description")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 371,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Textarea, {
								id: "desc",
								value: description,
								onChange: (e) => setDescription(e.target.value),
								placeholder: t("submit.descriptionPh"),
								rows: 3,
								maxLength: 600,
								"data-tsd-source": "/src/components/SubmitDialog.tsx:372:15"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 372,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 370,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							"data-tsd-source": "/src/components/SubmitDialog.tsx:382:13",
							children: [
								/* @__PURE__ */ _jsxDEV(Label, {
									htmlFor: "file",
									className: "flex items-center justify-between",
									"data-tsd-source": "/src/components/SubmitDialog.tsx:383:15",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-2",
										"data-tsd-source": "/src/components/SubmitDialog.tsx:384:17",
										children: [
											/* @__PURE__ */ _jsxDEV(ImagePlus, {
												className: "h-4 w-4",
												"data-tsd-source": "/src/components/SubmitDialog.tsx:385:19"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 385,
												columnNumber: 19
											}, this),
											" ",
											t("submit.photo"),
											" / Video Evidence"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 384,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-muted-foreground",
										"data-tsd-source": "/src/components/SubmitDialog.tsx:387:17",
										children: "AI scans pictures or video frames"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 387,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 383,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Input, {
									id: "file",
									type: "file",
									accept: "image/*,video/*",
									onChange: (e) => setFile(e.target.files?.[0] ?? null),
									"data-tsd-source": "/src/components/SubmitDialog.tsx:391:15"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 391,
									columnNumber: 15
								}, this),
								file && /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-muted-foreground flex items-center gap-1.5",
									"data-tsd-source": "/src/components/SubmitDialog.tsx:398:17",
									children: [
										/* @__PURE__ */ _jsxDEV(CheckCircle2, {
											className: "h-3.5 w-3.5 text-emerald-600",
											"data-tsd-source": "/src/components/SubmitDialog.tsx:399:19"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 399,
											columnNumber: 19
										}, this),
										" Attached: ",
										file.name
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 398,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 382,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 186,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(DialogFooter, {
					"data-tsd-source": "/src/components/SubmitDialog.tsx:405:11",
					children: /* @__PURE__ */ _jsxDEV(Button, {
						onClick: handleSubmit,
						disabled: submitting,
						className: "w-full",
						"data-tsd-source": "/src/components/SubmitDialog.tsx:406:13",
						children: submitting ? t("submit.posting") : t("submit.submit")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 406,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 405,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 180,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 172,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV(ProductScannerModal, {
		open: scannerOpen,
		onOpenChange: setScannerOpen,
		onApplyToPost: handleScannerApply,
		"data-tsd-source": "/src/components/SubmitDialog.tsx:414:7"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 414,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 171,
		columnNumber: 5
	}, this);
}
_s(SubmitDialog, "dDeYLYzEnrUlcUTqXHXoD2PM874=", false, function() {
	return [useAuth, useTranslation];
});
_c = SubmitDialog;
var _c;
$RefreshReg$(_c, "SubmitDialog");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SubmitDialog.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/SubmitDialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/SubmitDialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/SubmitDialog.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FDQSxRQUNBLGVBQ0EsY0FDQSxhQUNBLG1CQUNBLGNBQ0EscUJBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBLFNBQ0EsTUFDQSxXQUNBLE1BQ0EsVUFDQSxXQUNBLGFBQ0EsZUFDQSxjQUNBLFNBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7Ozs7QUFFQTtBQUNBO0NBQUE7Q0FBQTtDQUFBO0NBQUE7QUFBQTtBQWdCQSwrQkFDQSxVQUNBLGdCQUNBLHNCQUNBLGlDQUNBLGlCQUNBOztDQUNBO0NBQ0E7Q0FFQTtDQUNBO0NBQ0E7Q0FDQTtDQUVBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLGlEQUNBLG1DQUNBO0NBQ0E7Q0FDQTtDQUVBO0VBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0E7Q0FDQTtDQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDQTtDQUVBLHFDQVFBO0VBQ0E7R0FDQTtFQUNBO0VBQ0EsU0FDQSxtQkFDQSw0Q0FDQSw4QkFDQTtFQUNBLGVBQ0EsNFBBQ0E7RUFDQTtHQUNBO0VBQ0E7RUFDQTtHQUNBO0VBQ0E7RUFDQTtFQUNBLGNBQ0Esc0VBQ0E7Q0FDQTtDQUVBO0VBQ0E7RUFDQTtHQUNBO0dBQ0E7RUFDQTtFQUNBO0dBQ0E7R0FDQTtFQUNBO0VBQ0E7RUFDQTtHQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDQTtHQUNBO0VBQ0E7R0FDQTtFQUNBO0NBQ0E7Q0FFQSxPQUNBLGdEQUNBO0VBQUE7RUFBQTtFQUFBO1lBQUEsQ0FDQSxpQkFDQTtHQUFBO0dBQUE7YUFDQTtJQUFBO0lBQUE7SUFBQTtjQUFBO0tBQ0E7TUFBQTtNQUFBO0tBQXdDOzs7OztLQUFBO0tBQUE7SUFDeEM7Ozs7OztFQUNBOzs7O1lBRUE7R0FBQTtHQUFBO2FBQUE7SUFDQTtLQUFBO2VBQUEsQ0FDQTtNQUFBO01BQUE7Z0JBQTBEO0tBQUE7Ozs7ZUFDMUQ7TUFBQTtnQkFBOEI7S0FBQTs7OzthQUM5Qjs7Ozs7O0lBRUE7S0FBQTtLQUFBO2VBQUE7TUFFQTtPQUFBO09BQUE7aUJBQUEsQ0FDQTtRQUFBO1FBQUE7a0JBQUEsQ0FDQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQTtVQUFBO1VBQUE7U0FBZ0Q7Ozs7bUJBQUEsOEJBQ2hEOzs7OztrQkFDQTtTQUFBO1NBQUE7bUJBQWdFO1FBRWhFOzs7O2dCQUNBOzs7OztpQkFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7a0JBTEEsQ0FNQTtTQUFBO1NBQUE7UUFBa0Q7Ozs7a0JBQUEsb0JBQ2xEOzs7OztlQUNBOzs7Ozs7TUFHQSxnQkFDQTtPQUFBO09BQUE7aUJBQUEsQ0FDQTtRQUFBO1FBQUE7a0JBQUEsQ0FDQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQTtVQUFBO1VBQUE7U0FBdUU7Ozs7bUJBQUEsK0JBQ3ZFOzs7OztrQkFDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO21CQUNBO1VBQUE7VUFBQTtTQUErQzs7Ozs7UUFDL0M7Ozs7Z0JBQ0E7Ozs7O2lCQUVBO1FBQUE7UUFBQTtrQkFBQSxDQUNBO1NBQUE7U0FBQTttQkFBQTtVQUNBO1dBQUE7V0FBQTtxQkFBQSxDQUNBO1lBQUE7WUFBQTtXQUF3RTs7OztxQkFBQSxtQkFDeEU7Ozs7OztVQUNBO1dBQUE7V0FBQTtxQkFDQTtVQUNBOzs7OztVQUNBO1dBQUE7V0FBQTtxQkFDQTtVQUNBOzs7OztTQUNBOzs7OztrQkFFQTtTQUFBO1NBQUE7bUJBQUE7VUFDQTtXQUFBO1dBQUE7cUJBQUEsQ0FDQSx5Q0FDQTtZQUFBO1lBQUE7V0FBOEU7Ozs7c0JBRTlFO1lBQUE7WUFBQTtXQUE2RTs7OztxQkFDN0Usc0JBRUE7Ozs7OztVQUNBO1dBQUE7V0FBQTtxQkFBQSxDQUNBLDhDQUNBOzs7Ozs7VUFDQTtXQUFBO1dBQUE7cUJBQ0E7VUFDQTs7Ozs7U0FDQTs7Ozs7Z0JBQ0E7Ozs7O2VBQ0E7Ozs7OztNQUdBO09BQUE7T0FBQTtpQkFBQSxDQUNBO1FBQUE7UUFBQTtrQkFBb0M7T0FBQTs7OztpQkFDcEM7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7T0FBYzs7OztlQUNkOzs7Ozs7TUFFQSxtQkFDQTtPQUFBO09BQUE7aUJBQUE7UUFDQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQTtVQUFBO29CQUF3QjtTQUFBOzs7O21CQUN4QjtVQUFBO1VBQUE7b0JBQXFFO1NBRXJFOzs7O2lCQUNBOzs7Ozs7UUFDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1FBQWdCOzs7OztRQUNoQix3QkFDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7U0FDQTttQkFDQTtRQUNBOzs7OztPQUVBOzs7Ozs7TUFHQTtPQUFBO09BQUE7aUJBQUE7UUFDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7U0FDQTtRQUFjOzs7OztRQUNkO1NBQUE7bUJBQW9CO1FBQUE7Ozs7O1FBQ3BCO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7V0FDQTtXQUNBO1dBQ0E7WUFDQTtZQUNBO1dBQ0E7VUFDQTtVQUNBLGNBQ0EsU0FDQSx5Q0FDQSx1Q0FDQTtVQUNBO29CQWpCQTtXQWtCQTtZQUFBO1lBQUE7WUFBQTtZQUFBO1lBQUE7V0FBa0Y7Ozs7O1dBQUE7V0FBQTtVQUNsRjs7Ozs7bUJBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtXQUNBO1dBQ0E7VUFDQTtVQUNBLGNBQ0EsU0FDQSx5Q0FDQSx1Q0FDQTtVQUNBO29CQWJBO1dBY0E7WUFBQTtZQUFBO1lBQUE7WUFBQTtZQUFBO1dBQWlGOzs7OztXQUFBO1dBQUE7VUFDakY7Ozs7O2lCQUNBOzs7Ozs7T0FDQTs7Ozs7O01BRUE7T0FBQTtPQUFBO2lCQUFBO1FBQ0E7U0FBQTtTQUFBO21CQUF1QztRQUFBOzs7OztRQUN2QztTQUFBO1NBQUE7bUJBQ0EsNkJBQ0E7VUFFQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO29CQUNBO1NBQ0EsR0FQQTs7OztnQkFPQSxDQUNBO1FBQ0E7Ozs7O1FBQ0E7U0FDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7UUFBYzs7Ozs7T0FDZDs7Ozs7O01BRUE7T0FBQTtPQUFBO2lCQUFBLENBQ0E7UUFBQTtRQUFBO2tCQUFtQztPQUFBOzs7O2lCQUNuQztRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO09BQWM7Ozs7ZUFDZDs7Ozs7O01BRUE7T0FBQTtPQUFBO2lCQUFBO1FBQ0E7U0FBQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQTtVQUFBO1VBQUE7b0JBQUE7V0FDQTtZQUFBO1lBQUE7V0FBaUQ7Ozs7O1dBQUE7V0FBQTtXQUFBO1VBQ2pEOzs7OzttQkFDQTtVQUFBO1VBQUE7b0JBQW1FO1NBRW5FOzs7O2lCQUNBOzs7Ozs7UUFDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7UUFBYzs7Ozs7UUFDZCxRQUNBO1NBQUE7U0FBQTttQkFBQTtVQUNBO1dBQUE7V0FBQTtVQUF5RTs7Ozs7VUFBQTtVQUFBO1NBQ3pFOzs7Ozs7T0FFQTs7Ozs7O0tBQ0E7Ozs7OztJQUVBO0tBQUE7ZUFDQTtNQUFBO01BQUE7TUFBQTtNQUFBO2dCQUNBO0tBQ0E7Ozs7O0lBQ0E7Ozs7O0dBQ0E7Ozs7O1VBQ0E7Ozs7O1dBR0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUFNOzs7O1NBQ047Ozs7O0FBRUEiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlN1Ym1pdERpYWxvZy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlVHJhbnNsYXRpb24gfSBmcm9tIFwicmVhY3QtaTE4bmV4dFwiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCJAL2hvb2tzL3VzZUF1dGhcIjtcbmltcG9ydCB7IGNyZWF0ZUl0ZW0gfSBmcm9tIFwiQC9saWIvc3Rhc2hcIjtcbmltcG9ydCB7IEJyYW5kU2VhcmNoIH0gZnJvbSBcIkAvY29tcG9uZW50cy9CcmFuZFNlYXJjaFwiO1xuaW1wb3J0IHsgUHJvZHVjdFNjYW5uZXJNb2RhbCB9IGZyb20gXCJAL2NvbXBvbmVudHMvUHJvZHVjdFNjYW5uZXJNb2RhbFwiO1xuaW1wb3J0IHtcbiAgRGlhbG9nLFxuICBEaWFsb2dDb250ZW50LFxuICBEaWFsb2dIZWFkZXIsXG4gIERpYWxvZ1RpdGxlLFxuICBEaWFsb2dEZXNjcmlwdGlvbixcbiAgRGlhbG9nRm9vdGVyLFxuICBEaWFsb2dUcmlnZ2VyLFxufSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2RpYWxvZ1wiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9idXR0b25cIjtcbmltcG9ydCB7IElucHV0IH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9pbnB1dFwiO1xuaW1wb3J0IHsgVGV4dGFyZWEgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL3RleHRhcmVhXCI7XG5pbXBvcnQgeyBMYWJlbCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvbGFiZWxcIjtcbmltcG9ydCB7IEJhZGdlIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9iYWRnZVwiO1xuaW1wb3J0IHtcbiAgUGx1cyxcbiAgSW1hZ2VQbHVzLFxuICBTY2FuLFxuICBTcGFya2xlcyxcbiAgQnVpbGRpbmcyLFxuICBTaGllbGRDaGVjayxcbiAgQWxlcnRUcmlhbmdsZSxcbiAgQ2hlY2tDaXJjbGUyLFxuICBYLFxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgY29pbkljb24gZnJvbSBcIkAvYXNzZXRzL2ljb24tY29pbi5wbmdcIjtcbmltcG9ydCBiaW5JY29uIGZyb20gXCJAL2Fzc2V0cy9pY29uLWJpbi5wbmdcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5pbXBvcnQgeyBwbGF5U3Rhc2hTb3VuZCwgcGxheVRyYXNoU291bmQgfSBmcm9tIFwiQC9saWIvdmVyZGljdC1zb3VuZHNcIjtcbmltcG9ydCB7IFZlcmRpY3RTdWNjZXNzLCB0cmlnZ2VyVmVyZGljdFN1Y2Nlc3MgfSBmcm9tIFwiQC9jb21wb25lbnRzL1ZlcmRpY3RTdWNjZXNzXCI7XG5pbXBvcnQgdHlwZSB7IFZlcmRpY3QgfSBmcm9tIFwiQC9saWIvc3Rhc2hcIjtcbmltcG9ydCB0eXBlIHsgQWlTY2FuUmVzdWx0IH0gZnJvbSBcIkAvbGliL2FpLXNjYW5uZXJcIjtcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSBcInNvbm5lclwiO1xuXG5jb25zdCBOT19CUkFORCA9IFwiX19ub25lX19cIjtcbmNvbnN0IEZFRURCQUNLX1RZUEVTID0gW1wiQ29uY2VyblwiLCBcIkNvbXBsaW1lbnRcIiwgXCJJZGVhXCIsIFwiUXVlc3Rpb25cIl0gYXMgY29uc3Q7XG5cbmV4cG9ydCBpbnRlcmZhY2UgU3VibWl0RGlhbG9nUHJvcHMge1xuICBvblBvc3RlZD86ICgpID0+IHZvaWQ7XG4gIGRlZmF1bHRCcmFuZElkPzogc3RyaW5nO1xuICBvcGVuPzogYm9vbGVhbjtcbiAgb25PcGVuQ2hhbmdlPzogKG9wZW46IGJvb2xlYW4pID0+IHZvaWQ7XG4gIGluaXRpYWxWYWx1ZXM/OiB7XG4gICAgdGl0bGU/OiBzdHJpbmc7XG4gICAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gICAgY2F0ZWdvcnk/OiBzdHJpbmc7XG4gICAgZmlsZT86IEZpbGUgfCBudWxsO1xuICAgIGFpU2NhblJlc3VsdD86IEFpU2NhblJlc3VsdCB8IG51bGw7XG4gIH07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBTdWJtaXREaWFsb2coe1xuICBvblBvc3RlZCxcbiAgZGVmYXVsdEJyYW5kSWQsXG4gIG9wZW46IGNvbnRyb2xsZWRPcGVuLFxuICBvbk9wZW5DaGFuZ2U6IHNldENvbnRyb2xsZWRPcGVuLFxuICBpbml0aWFsVmFsdWVzLFxufTogU3VibWl0RGlhbG9nUHJvcHMpIHtcbiAgY29uc3QgeyB1c2VyIH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IHsgdCB9ID0gdXNlVHJhbnNsYXRpb24oKTtcblxuICBjb25zdCBbdW5jb250cm9sbGVkT3Blbiwgc2V0VW5jb250cm9sbGVkT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IGlzQ29udHJvbGxlZCA9IGNvbnRyb2xsZWRPcGVuICE9PSB1bmRlZmluZWQ7XG4gIGNvbnN0IG9wZW4gPSBpc0NvbnRyb2xsZWQgPyBjb250cm9sbGVkT3BlbiA6IHVuY29udHJvbGxlZE9wZW47XG4gIGNvbnN0IHNldE9wZW4gPSBpc0NvbnRyb2xsZWQgPyAoc2V0Q29udHJvbGxlZE9wZW4gPz8gKCgpID0+IHt9KSkgOiBzZXRVbmNvbnRyb2xsZWRPcGVuO1xuXG4gIGNvbnN0IFtzY2FubmVyT3Blbiwgc2V0U2Nhbm5lck9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbdGl0bGUsIHNldFRpdGxlXSA9IHVzZVN0YXRlKGluaXRpYWxWYWx1ZXM/LnRpdGxlID8/IFwiXCIpO1xuICBjb25zdCBbZGVzY3JpcHRpb24sIHNldERlc2NyaXB0aW9uXSA9IHVzZVN0YXRlKGluaXRpYWxWYWx1ZXM/LmRlc2NyaXB0aW9uID8/IFwiXCIpO1xuICBjb25zdCBbY2F0ZWdvcnksIHNldENhdGVnb3J5XSA9IHVzZVN0YXRlKGluaXRpYWxWYWx1ZXM/LmNhdGVnb3J5ID8/IFwiXCIpO1xuICBjb25zdCBbYnJhbmRJZCwgc2V0QnJhbmRJZF0gPSB1c2VTdGF0ZTxzdHJpbmc+KGRlZmF1bHRCcmFuZElkID8/IE5PX0JSQU5EKTtcbiAgY29uc3QgW2ZpbGUsIHNldEZpbGVdID0gdXNlU3RhdGU8RmlsZSB8IG51bGw+KGluaXRpYWxWYWx1ZXM/LmZpbGUgPz8gbnVsbCk7XG4gIGNvbnN0IFthaVNjYW5SZXN1bHQsIHNldEFpU2NhblJlc3VsdF0gPSB1c2VTdGF0ZTxBaVNjYW5SZXN1bHQgfCBudWxsPihcbiAgICBpbml0aWFsVmFsdWVzPy5haVNjYW5SZXN1bHQgPz8gbnVsbFxuICApO1xuICBjb25zdCBbdmVyZGljdCwgc2V0VmVyZGljdF0gPSB1c2VTdGF0ZTxWZXJkaWN0IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtzdWJtaXR0aW5nLCBzZXRTdWJtaXR0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpbml0aWFsVmFsdWVzKSB7XG4gICAgICBpZiAoaW5pdGlhbFZhbHVlcy50aXRsZSAhPT0gdW5kZWZpbmVkKSBzZXRUaXRsZShpbml0aWFsVmFsdWVzLnRpdGxlKTtcbiAgICAgIGlmIChpbml0aWFsVmFsdWVzLmRlc2NyaXB0aW9uICE9PSB1bmRlZmluZWQpIHNldERlc2NyaXB0aW9uKGluaXRpYWxWYWx1ZXMuZGVzY3JpcHRpb24pO1xuICAgICAgaWYgKGluaXRpYWxWYWx1ZXMuY2F0ZWdvcnkgIT09IHVuZGVmaW5lZCkgc2V0Q2F0ZWdvcnkoaW5pdGlhbFZhbHVlcy5jYXRlZ29yeSk7XG4gICAgICBpZiAoaW5pdGlhbFZhbHVlcy5maWxlICE9PSB1bmRlZmluZWQpIHNldEZpbGUoaW5pdGlhbFZhbHVlcy5maWxlKTtcbiAgICAgIGlmIChpbml0aWFsVmFsdWVzLmFpU2NhblJlc3VsdCAhPT0gdW5kZWZpbmVkKSBzZXRBaVNjYW5SZXN1bHQoaW5pdGlhbFZhbHVlcy5haVNjYW5SZXN1bHQpO1xuICAgIH1cbiAgfSwgW2luaXRpYWxWYWx1ZXNdKTtcblxuICBjb25zdCByZXNldCA9ICgpID0+IHtcbiAgICBzZXRUaXRsZShcIlwiKTtcbiAgICBzZXREZXNjcmlwdGlvbihcIlwiKTtcbiAgICBzZXRDYXRlZ29yeShcIlwiKTtcbiAgICBzZXRCcmFuZElkKGRlZmF1bHRCcmFuZElkID8/IE5PX0JSQU5EKTtcbiAgICBzZXRGaWxlKG51bGwpO1xuICAgIHNldEFpU2NhblJlc3VsdChudWxsKTtcbiAgICBzZXRWZXJkaWN0KG51bGwpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVNjYW5uZXJBcHBseSA9IChkYXRhOiB7XG4gICAgYnJhbmROYW1lOiBzdHJpbmc7XG4gICAgYnJhbmRPd25lcjogc3RyaW5nO1xuICAgIHByb2R1Y3ROYW1lOiBzdHJpbmc7XG4gICAgY2F0ZWdvcnk6IHN0cmluZztcbiAgICBtYXRjaGVkQnJhbmRJZD86IHN0cmluZztcbiAgICBmaWxlPzogRmlsZSB8IG51bGw7XG4gICAgc2NhblJlc3VsdDogQWlTY2FuUmVzdWx0O1xuICB9KSA9PiB7XG4gICAgaWYgKGRhdGEubWF0Y2hlZEJyYW5kSWQpIHtcbiAgICAgIHNldEJyYW5kSWQoZGF0YS5tYXRjaGVkQnJhbmRJZCk7XG4gICAgfVxuICAgIHNldFRpdGxlKFxuICAgICAgZGF0YS5wcm9kdWN0TmFtZVxuICAgICAgICA/IGAke2RhdGEuYnJhbmROYW1lfSDigJQgJHtkYXRhLnByb2R1Y3ROYW1lfWBcbiAgICAgICAgOiBgJHtkYXRhLmJyYW5kTmFtZX0gRXhwZXJpZW5jZWBcbiAgICApO1xuICAgIHNldERlc2NyaXB0aW9uKFxuICAgICAgYFByb2R1Y3Q6ICR7ZGF0YS5wcm9kdWN0TmFtZSB8fCBkYXRhLmJyYW5kTmFtZX1cXG5Db3Jwb3JhdGUgT3duZXI6ICR7ZGF0YS5icmFuZE93bmVyfVxcbiR7ZGF0YS5zY2FuUmVzdWx0LmJyYW5kSW5mby5wYXJlbnRDb21wYW55Q29udGV4dH1cXG5bRm9yZW5zaWMgQXV0aGVudGljaXR5IFNjb3JlOiAke2RhdGEuc2NhblJlc3VsdC5hdXRoZW50aWNpdHkuc2NvcmV9JSAtICR7ZGF0YS5zY2FuUmVzdWx0LmF1dGhlbnRpY2l0eS5iYWRnZUxhYmVsfV1gXG4gICAgKTtcbiAgICBpZiAoZGF0YS5jYXRlZ29yeSkge1xuICAgICAgc2V0Q2F0ZWdvcnkoZGF0YS5jYXRlZ29yeSk7XG4gICAgfVxuICAgIGlmIChkYXRhLmZpbGUpIHtcbiAgICAgIHNldEZpbGUoZGF0YS5maWxlKTtcbiAgICB9XG4gICAgc2V0QWlTY2FuUmVzdWx0KGRhdGEuc2NhblJlc3VsdCk7XG4gICAgdG9hc3Quc3VjY2VzcyhcbiAgICAgIGBBdXRvLWZpbGxlZDogJHtkYXRhLmJyYW5kTmFtZX0gKENvcnBvcmF0ZSBPd25lcjogJHtkYXRhLmJyYW5kT3duZXJ9KWBcbiAgICApO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXVzZXIpIHJldHVybjtcbiAgICBpZiAoIXRpdGxlLnRyaW0oKSkge1xuICAgICAgdG9hc3QuZXJyb3IodChcInN1Ym1pdC5uZWVkVGl0bGVcIikpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoIXZlcmRpY3QpIHtcbiAgICAgIHRvYXN0LmVycm9yKHQoXCJzdWJtaXQubmVlZFZlcmRpY3RcIikpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzZXRTdWJtaXR0aW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBjcmVhdGVJdGVtKHtcbiAgICAgICAgdXNlcklkOiB1c2VyLmlkLFxuICAgICAgICB0aXRsZSxcbiAgICAgICAgZGVzY3JpcHRpb24sXG4gICAgICAgIGZpbGUsXG4gICAgICAgIGJyYW5kSWQ6IGJyYW5kSWQgPT09IE5PX0JSQU5EID8gbnVsbCA6IGJyYW5kSWQsXG4gICAgICAgIGNhdGVnb3J5LFxuICAgICAgICB2ZXJkaWN0LFxuICAgICAgICBhaVNjYW5SZXN1bHQsXG4gICAgICB9KTtcbiAgICAgIHRvYXN0LnN1Y2Nlc3ModChcInN1Ym1pdC5wb3N0ZWRcIikpO1xuICAgICAgcmVzZXQoKTtcbiAgICAgIHNldE9wZW4oZmFsc2UpO1xuICAgICAgb25Qb3N0ZWQ/LigpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHRvYXN0LmVycm9yKGUgaW5zdGFuY2VvZiBFcnJvciA/IGUubWVzc2FnZSA6IHQoXCJzdWJtaXQuZXJyb3JcIikpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTdWJtaXR0aW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPERpYWxvZyBvcGVuPXtvcGVufSBvbk9wZW5DaGFuZ2U9e3NldE9wZW59PlxuICAgICAgICB7IWlzQ29udHJvbGxlZCAmJiAoXG4gICAgICAgICAgPERpYWxvZ1RyaWdnZXIgYXNDaGlsZD5cbiAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgY2xhc3NOYW1lPVwiZ2FwLTEuNSBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPiB7dChcInN1Ym1pdC50cmlnZ2VyXCIpfVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9EaWFsb2dUcmlnZ2VyPlxuICAgICAgICApfVxuICAgICAgICA8RGlhbG9nQ29udGVudCBjbGFzc05hbWU9XCJtYXgtdy14bCBtYXgtaC1bOTB2aF0gb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgPERpYWxvZ0hlYWRlcj5cbiAgICAgICAgICAgIDxEaWFsb2dUaXRsZSBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC0yeGxcIj57dChcInN1Ym1pdC50aXRsZVwiKX08L0RpYWxvZ1RpdGxlPlxuICAgICAgICAgICAgPERpYWxvZ0Rlc2NyaXB0aW9uPnt0KFwic3VibWl0LmludHJvXCIpfTwvRGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgICAgPC9EaWFsb2dIZWFkZXI+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCBweS0yXCI+XG4gICAgICAgICAgICB7LyogRkFTVCBBSSBTQ0FOTkVSIFRSSUdHRVIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1wcmltYXJ5LzMwIGJnLXByaW1hcnkvNSBwLTMgZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMC41IHRleHQtY2VudGVyIHNtOnRleHQtbGVmdFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc206anVzdGlmeS1zdGFydCBnYXAtMS41IGZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtcHJpbWFyeVwiPlxuICAgICAgICAgICAgICAgICAgPFNjYW4gY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPiBBdXRvLUlkZW50aWZ5IEJyYW5kICYgT3duZXJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgIFNjYW4gdGhlIHByb2R1Y3QgcGFja2FnaW5nLCBRUiBjb2RlLCBvciBiYXJjb2RlLiBBSSBkZXRlY3RzIHRoZSBwYXJlbnQgY29tcGFueSBhbmQgdmVyaWZpZXMgYXV0aGVudGljaXR5LlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNjYW5uZXJPcGVuKHRydWUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdhcC0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHNocmluay0wIHNoYWRvdy1zbVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPiBTY2FuIFByb2R1Y3QgLyBRUlxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQUkgVkVSSUZJQ0FUSU9OICYgQ09SUE9SQVRFIE9XTkVSIERPU1NJRVIgQ0hJUCAqL31cbiAgICAgICAgICAgIHthaVNjYW5SZXN1bHQgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctY2FyZCBwLTMgc3BhY2UteS0yIHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtcHJpbWFyeVwiPlxuICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHRleHQtcHJpbWFyeVwiIC8+IEFJIFZlcmlmaWVkIEJyYW5kICYgRXZpZGVuY2VcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJpY29uXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC02IHctNiB0ZXh0LW11dGVkLWZvcmVncm91bmQgaG92ZXI6dGV4dC1mb3JlZ3JvdW5kXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWlTY2FuUmVzdWx0KG51bGwpfVxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlJlbW92ZSBBSSBtZXRhZGF0YVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC0yIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQgYmctbXV0ZWQvNDAgYm9yZGVyIGJvcmRlci1ib3JkZXIvNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWZvcmVncm91bmQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8QnVpbGRpbmcyIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHRleHQtYW1iZXItNjAwXCIgLz4gQ29ycG9yYXRlIE93bmVyOlxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LWZvcmVncm91bmQgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAge2FpU2NhblJlc3VsdC5icmFuZEluZm8uYnJhbmRPd25lcn1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LW11dGVkLWZvcmVncm91bmQgbXQtMC41IGxpbmUtY2xhbXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHthaVNjYW5SZXN1bHQuYnJhbmRJbmZvLnBhcmVudENvbXBhbnlDb250ZXh0fVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgcm91bmRlZCBiZy1tdXRlZC80MCBib3JkZXIgYm9yZGVyLWJvcmRlci81MFwiPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZm9yZWdyb3VuZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHthaVNjYW5SZXN1bHQuYXV0aGVudGljaXR5LmlzTGVnaXRpbWF0ZSA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSB0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgdGV4dC1yb3NlLTYwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICBFdmlkZW5jZSBMZWdpdGltYWN5OlxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LWZvcmVncm91bmQgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAge2FpU2NhblJlc3VsdC5hdXRoZW50aWNpdHkuc2NvcmV9JSBBdXRoZW50aWNcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LW11dGVkLWZvcmVncm91bmQgbXQtMC41IGxpbmUtY2xhbXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHthaVNjYW5SZXN1bHQuYXV0aGVudGljaXR5LmJhZGdlTGFiZWx9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwidGl0bGVcIj57dChcInN1Ym1pdC5maWVsZFRpdGxlXCIpfTwvTGFiZWw+XG4gICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgIGlkPVwidGl0bGVcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXt0aXRsZX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRpdGxlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17dChcInN1Ym1pdC50aXRsZVBoXCIpfVxuICAgICAgICAgICAgICAgIG1heExlbmd0aD17MTIwfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHshZGVmYXVsdEJyYW5kSWQgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICA8TGFiZWw+e3QoXCJzdWJtaXQuYnJhbmRcIil9PC9MYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICBBdXRvLWZpbGxlZCBpZiBzY2FubmVkXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPEJyYW5kU2VhcmNoXG4gICAgICAgICAgICAgICAgICBvblNlbGVjdEJyYW5kPXsoYikgPT4gc2V0QnJhbmRJZChiLmlkKX1cbiAgICAgICAgICAgICAgICAgIHNlbGVjdGVkSWQ9e2JyYW5kSWQgPT09IE5PX0JSQU5EID8gdW5kZWZpbmVkIDogYnJhbmRJZH1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXt0KFwic3VibWl0LmJyYW5kUGhcIil9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICB7YnJhbmRJZCAhPT0gTk9fQlJBTkQgJiYgKFxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHB4LTJcIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRCcmFuZElkKE5PX0JSQU5EKX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge3QoXCJzdWJtaXQubm9CcmFuZFwiKX1cbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBzcGFjZS15LTIgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQteGxcIj5cbiAgICAgICAgICAgICAgPFZlcmRpY3RTdWNjZXNzXG4gICAgICAgICAgICAgICAgYWN0aXZlPXt2ZXJkaWN0ID09PSBcInN0YXNoXCJ9XG4gICAgICAgICAgICAgICAgaW5saW5lXG4gICAgICAgICAgICAgICAgZHVyYXRpb249ezE4MDB9XG4gICAgICAgICAgICAgICAgbGFiZWw9XCJTVEFTSCBTRUxFQ1RFRCFcIlxuICAgICAgICAgICAgICAgIHN1YmxhYmVsPVwiS2VlcCB3aGF0IHNlcnZlcyB5b3UgwrcgR29sZCBzdGFuZGFyZFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxMYWJlbD57dChcInN1Ym1pdC52ZXJkaWN0XCIpfTwvTGFiZWw+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInN0YXNoXCJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJsZ1wiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHBsYXlTdGFzaFNvdW5kKCk7XG4gICAgICAgICAgICAgICAgICAgIHNldFZlcmRpY3QoXCJzdGFzaFwiKTtcbiAgICAgICAgICAgICAgICAgICAgdHJpZ2dlclZlcmRpY3RTdWNjZXNzKHtcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogXCJTVEFTSCBWRVJESUNUIVwiLFxuICAgICAgICAgICAgICAgICAgICAgIHN1YmxhYmVsOiBcIktlZXAgd2hhdCBzZXJ2ZXMgeW91IMK3IEdvbGQgc3RhbmRhcmQgc2VsZWN0ZWRcIixcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgXCJnYXAtMlwiLFxuICAgICAgICAgICAgICAgICAgICB2ZXJkaWN0ID09PSBcInN0YXNoXCIgJiYgXCJ2ZXJkaWN0LXBpY2tlZFwiLFxuICAgICAgICAgICAgICAgICAgICB2ZXJkaWN0ID09PSBcInRyYXNoXCIgJiYgXCJ2ZXJkaWN0LWRpbW1lZFwiLFxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8aW1nIHNyYz17Y29pbkljb259IGFsdD1cIlwiIGFyaWEtaGlkZGVuIGNsYXNzTmFtZT1cInZlcmRpY3QtaWNvblwiIC8+IHt0KFwidm90ZS5zdGFzaFwiKX1cbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJ0cmFzaFwiXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGdcIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBwbGF5VHJhc2hTb3VuZCgpO1xuICAgICAgICAgICAgICAgICAgICBzZXRWZXJkaWN0KFwidHJhc2hcIik7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgXCJnYXAtMlwiLFxuICAgICAgICAgICAgICAgICAgICB2ZXJkaWN0ID09PSBcInRyYXNoXCIgJiYgXCJ2ZXJkaWN0LXBpY2tlZFwiLFxuICAgICAgICAgICAgICAgICAgICB2ZXJkaWN0ID09PSBcInN0YXNoXCIgJiYgXCJ2ZXJkaWN0LWRpbW1lZFwiLFxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8aW1nIHNyYz17YmluSWNvbn0gYWx0PVwiXCIgYXJpYS1oaWRkZW4gY2xhc3NOYW1lPVwidmVyZGljdC1pY29uXCIgLz4ge3QoXCJ2b3RlLnRyYXNoXCIpfVxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cImNhdGVnb3J5XCI+V2hhdCBraW5kIG9mIGZlZWRiYWNrIGlzIHRoaXM/PC9MYWJlbD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0yIHNtOmdyaWQtY29scy00XCI+XG4gICAgICAgICAgICAgICAge0ZFRURCQUNLX1RZUEVTLm1hcCgodHlwZSkgPT4gKFxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBrZXk9e3R5cGV9XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PXtjYXRlZ29yeSA9PT0gdHlwZSA/IFwiZGVmYXVsdFwiIDogXCJvdXRsaW5lXCJ9XG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENhdGVnb3J5KHR5cGUpfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7dHlwZX1cbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgaWQ9XCJjYXRlZ29yeVwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2NhdGVnb3J5fVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2F0ZWdvcnkoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWRkIGEgbW9yZSBzcGVjaWZpYyB0b3BpYywgaWYgdXNlZnVsXCJcbiAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezQwfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwiZGVzY1wiPnt0KFwic3VibWl0LmRlc2NyaXB0aW9uXCIpfTwvTGFiZWw+XG4gICAgICAgICAgICAgIDxUZXh0YXJlYVxuICAgICAgICAgICAgICAgIGlkPVwiZGVzY1wiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Rlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RGVzY3JpcHRpb24oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXt0KFwic3VibWl0LmRlc2NyaXB0aW9uUGhcIil9XG4gICAgICAgICAgICAgICAgcm93cz17M31cbiAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezYwMH1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cImZpbGVcIiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPEltYWdlUGx1cyBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz4ge3QoXCJzdWJtaXQucGhvdG9cIil9IC8gVmlkZW8gRXZpZGVuY2VcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICBBSSBzY2FucyBwaWN0dXJlcyBvciB2aWRlbyBmcmFtZXNcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvTGFiZWw+XG4gICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgIGlkPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxuICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLyosdmlkZW8vKlwiXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGaWxlKGUudGFyZ2V0LmZpbGVzPy5bMF0gPz8gbnVsbCl9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIHtmaWxlICYmIChcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHRleHQtZW1lcmFsZC02MDBcIiAvPiBBdHRhY2hlZDoge2ZpbGUubmFtZX1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxEaWFsb2dGb290ZXI+XG4gICAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9e2hhbmRsZVN1Ym1pdH0gZGlzYWJsZWQ9e3N1Ym1pdHRpbmd9IGNsYXNzTmFtZT1cInctZnVsbFwiPlxuICAgICAgICAgICAgICB7c3VibWl0dGluZyA/IHQoXCJzdWJtaXQucG9zdGluZ1wiKSA6IHQoXCJzdWJtaXQuc3VibWl0XCIpfVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9EaWFsb2dGb290ZXI+XG4gICAgICAgIDwvRGlhbG9nQ29udGVudD5cbiAgICAgIDwvRGlhbG9nPlxuXG4gICAgICB7LyogRW1iZWRkZWQgU2Nhbm5lciBNb2RhbCAqL31cbiAgICAgIDxQcm9kdWN0U2Nhbm5lck1vZGFsXG4gICAgICAgIG9wZW49e3NjYW5uZXJPcGVufVxuICAgICAgICBvbk9wZW5DaGFuZ2U9e3NldFNjYW5uZXJPcGVufVxuICAgICAgICBvbkFwcGx5VG9Qb3N0PXtoYW5kbGVTY2FubmVyQXBwbHl9XG4gICAgICAvPlxuICAgIDwvPlxuICApO1xufVxuIl0sImZpbGUiOiIvYXBwL2FwcGxldC9zcmMvY29tcG9uZW50cy9TdWJtaXREaWFsb2cudHN4In0=