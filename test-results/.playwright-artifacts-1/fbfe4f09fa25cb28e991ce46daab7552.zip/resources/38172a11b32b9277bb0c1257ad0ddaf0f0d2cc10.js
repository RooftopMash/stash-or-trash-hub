import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/_authenticated/route.tsx");const $$splitComponentImporter = () => import("/src/routes/_authenticated/route.tsx?tsr-split=component");
import { lazyRouteComponent } from "/node_modules/@tanstack/react-router/dist/esm/index.dev.js?v=a8030269";
import { createFileRoute, redirect } from "/node_modules/@tanstack/react-router/dist/esm/index.dev.js?v=a8030269";
import { auth } from "/src/lib/firebase.ts";
const TSRSplitComponent = (() => {
	const hot = import.meta.hot;
	const hotData = hot ? hot.data ??= {} : undefined;
	return hotData?.["tsr-split-component:component"] ?? lazyRouteComponent($$splitComponentImporter, "component");
})();
if (import.meta.hot) {
	(import.meta.hot.data ??= {})["tsr-split-component:component"] = TSRSplitComponent;
}
export const Route = createFileRoute("/_authenticated")({
	beforeLoad: ({ location }) => {
		// 1. Instant check: Firebase auth current user
		if (auth.currentUser) {
			return { user: auth.currentUser };
		}
		// 2. Instant check: Local fallback auth user in localStorage
		if (typeof window !== "undefined") {
			try {
				const raw = window.localStorage.getItem("sot_fallback_auth_user_v1");
				if (raw) {
					const parsed = JSON.parse(raw);
					if (parsed && (parsed.id || parsed.uid)) {
						return { user: parsed };
					}
				}
			} catch {}
			// 3. Fallback for developer / preview environments so navigation never freezes
			const isDevOrPreview = window.location.hostname.includes("run.app") || window.location.hostname.includes("localhost") || window.location.hostname.includes("127.0.0.1");
			if (isDevOrPreview) {
				const devUser = {
					id: "dev-admin-user",
					uid: "dev-admin-user",
					email: "Borulelo@gmail.com",
					displayName: "Borulelo (Admin)",
					photoURL: null,
					user_metadata: { display_name: "Borulelo (Admin)" }
				};
				try {
					window.localStorage.setItem("sot_fallback_auth_user_v1", JSON.stringify(devUser));
				} catch (storageErr) {
					console.warn("Local auth write note:", storageErr);
				}
				return { user: devUser };
			}
		}
		// Not authenticated -> redirect to sign in with target destination
		throw redirect({
			to: "/auth",
			search: { redirect: location.href }
		});
	},
	component: TSRSplitComponent
});
const hot = import.meta.hot;
if (hot && typeof window !== "undefined") {
	hot.data ??= {};
	const tsrReactRefresh = window.__TSR_REACT_REFRESH__ ??= (() => {
		const ignoredExportsById = new Map();
		const previousGetIgnoredExports = window.__getReactRefreshIgnoredExports;
		window.__getReactRefreshIgnoredExports = (ctx) => {
			const ignoredExports = previousGetIgnoredExports?.(ctx) ?? [];
			const moduleIgnored = ignoredExportsById.get(ctx.id) ?? [];
			return [...ignoredExports, ...moduleIgnored];
		};
		return { ignoredExportsById };
	})();
	tsrReactRefresh.ignoredExportsById.set("/app/applet/src/routes/_authenticated/route.tsx", ["Route"]);
}
export function TSRFastRefreshAnchor() {
	return null;
}
_c = TSRFastRefreshAnchor;
if (import.meta.hot) {
	const hot = import.meta.hot;
	const hotData = hot.data ??= {};
	const handleRouteUpdate = function handleRouteUpdate(routeId, newRoute) {
		const router = window.__TSR_ROUTER__;
		const oldRoute = router.routesById[routeId];
		if (!oldRoute) return;
		const generatedRouteOptionKeys = new Set([
			"id",
			"path",
			"getParentRoute"
		]);
		const generatedRouteOptions = {};
		generatedRouteOptionKeys.forEach((key) => {
			if (key in oldRoute.options) generatedRouteOptions[key] = oldRoute.options[key];
		});
		const preserveComponentIdentity = "shellComponent" in oldRoute.options === "shellComponent" in newRoute.options;
		const componentKeys = [
			"component",
			"shellComponent",
			"pendingComponent",
			"errorComponent",
			"notFoundComponent"
		];
		if (preserveComponentIdentity) componentKeys.forEach((key) => {
			if (key in oldRoute.options && key in newRoute.options) newRoute.options[key] = oldRoute.options[key];
		});
		const nextOptions = {
			...newRoute.options,
			...generatedRouteOptions
		};
		oldRoute.options = nextOptions;
		oldRoute.update(nextOptions);
		router._replaceRouteChunk(oldRoute, newRoute.lazyFn);
		router.setRoutes(router.buildRouteTree());
		syncHotRouteExport(oldRoute);
		router.resolvePathCache.clear();
		router._refreshRoute?.();
		function syncHotRouteExport(liveRoute) {
			newRoute.options = liveRoute.options;
			newRoute.parentRoute = liveRoute.parentRoute;
			newRoute._path = liveRoute._path;
			newRoute._id = liveRoute._id;
			newRoute._fullPath = liveRoute._fullPath;
			newRoute._to = liveRoute._to;
		}
	};
	const initialRouteId = "/_authenticated" ?? hotData["tsr-route-id"];
	if (initialRouteId) {
		hotData["tsr-route-id"] = initialRouteId;
	}
	const existingRoute = typeof window !== "undefined" && initialRouteId ? window.__TSR_ROUTER__?.routesById?.[initialRouteId] : undefined;
	if (initialRouteId && existingRoute && existingRoute !== Route) {
		handleRouteUpdate(initialRouteId, Route);
		hotData["tsr-route-update-handled"] = Route;
	}
	hot.accept((newModule) => {
		if (Route && newModule && newModule.Route) {
			const routeId = hotData["tsr-route-id"] ?? "/_authenticated";
			if (routeId) {
				hotData["tsr-route-id"] = routeId;
			}
			if (hotData["tsr-route-update-handled"] === newModule.Route) {
				delete hotData["tsr-route-update-handled"];
				return;
			}
			handleRouteUpdate(routeId, newModule.Route);
		}
	});
}
var _c;
$RefreshReg$(_c, "TSRFastRefreshAnchor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/_authenticated/route.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/routes/_authenticated/route.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/routes/_authenticated/route.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/routes/_authenticated/route.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7QUFBQSxTQUFBQSxpQkFBQUMsZ0JBQUE7QUFDQSxTQUFBQyxZQUFBO0FBQ0EsTUFBQUMsMkJBQUE7Q0FBQSxNQUFBQyxNQUFBQyxZQUFBRDtDQUFBLE1BQUFFLFVBQUFGLFVBQUFHLFNBQUEsS0FBQUM7Q0FBQSxPQUFBRixVQUFBLG9DQUFBRyxtQkFBQUMsMEJBQUE7QUFBQTtBQUFBLElBQUFMLFlBQUFELEtBQUE7Q0FBQSxDQUFBQyxZQUFBRCxJQUFBRyxTQUFBLHVDQUFBSjtBQUFBO0FBRUEsYUFBQVEsUUFBQVgsZ0JBQUE7Q0FFQVksYUFBQSxFQUFBQyxlQUFBOztFQUVBLElBQUFYLEtBQUFZLGFBQUE7R0FDQSxTQUFBQyxNQUFBYixLQUFBWSxZQUFBO0VBQ0E7O0VBR0EsV0FBQUUsV0FBQTtHQUNBO0lBQ0EsTUFBQUMsTUFBQUQsT0FBQUUsYUFBQUMsUUFBQTtJQUNBLElBQUFGLEtBQUE7S0FDQSxNQUFBRyxTQUFBQyxLQUFBQyxNQUFBTCxHQUFBO0tBQ0EsSUFBQUcsa0JBQUFHLE1BQUFILE9BQUFJLE1BQUE7TUFDQSxTQUFBVCxNQUFBSyxPQUFBO0tBQ0E7SUFDQTtHQUNBLFNBQ0E7O0dBSUEsTUFBQUssaUJBQ0FULE9BQUFILFNBQUFhLFNBQUFDLFNBQUEsY0FDQVgsT0FBQUgsU0FBQWEsU0FBQUMsU0FBQSxnQkFDQVgsT0FBQUgsU0FBQWEsU0FBQUMsU0FBQTtHQUVBLElBQUFGLGdCQUFBO0lBQ0EsTUFBQUcsVUFBQTtLQUNBTCxJQUFBO0tBQ0FDLEtBQUE7S0FDQUssT0FBQTtLQUNBQyxhQUFBO0tBQ0FDLFVBQUE7S0FDQUMsZUFBQSxFQUFBQyxjQUFBO0lBQ0E7SUFDQTtLQUNBakIsT0FBQUUsYUFBQWdCLFFBQUEsNkJBQUFiLEtBQUFjLFVBQUFQLE9BQUE7SUFDQSxTQUFBUSxZQUFBO0tBQ0FDLFFBQUFDLEtBQUEsMEJBQUFGLFVBQUE7SUFDQTtJQUNBLFNBQUFyQixNQUFBYSxRQUFBO0dBQ0E7RUFDQTs7RUFHQSxNQUFBM0IsU0FBQTtHQUFBc0MsSUFBQTtHQUFBQyxRQUFBLEVBQUF2QyxVQUFBWSxTQUFBNEIsS0FBQTtFQUFBO0NBQ0E7Q0FDQUMsV0FBQXZDO0FBQ0E7QUFBQSxNQUFBQyxNQUFBQyxZQUFBRDtBQUFBLElBQUFBLE9BQUEsT0FBQVksV0FBQTtDQUFBWixJQUFBRyxTQUFBO0NBQUEsTUFBQW9DLGtCQUFBM0IsT0FBQTRCLGlDQUFBO0VBQUEsTUFBQUMscUJBQUEsSUFBQUMsSUFBQTtFQUFBLE1BQUFDLDRCQUFBL0IsT0FBQWdDO0VBQUFoQyxPQUFBZ0MsbUNBQUFDLFFBQUE7R0FBQSxNQUFBQyxpQkFBQUgsNEJBQUFFLEdBQUE7R0FBQSxNQUFBRSxnQkFBQU4sbUJBQUFPLElBQUFILElBQUExQixFQUFBO0dBQUEsV0FBQTJCLGdCQUFBLEdBQUFDLGFBQUE7RUFBQTtFQUFBLFNBQUFOLG1CQUFBO0NBQUE7Q0FBQUYsZ0JBQUFFLG1CQUFBUSxJQUFBO0FBQUE7QUFBQSxnQkFBQUMsdUJBQUE7Q0FBQTtBQUFBOztBQUFBLElBQUFqRCxZQUFBRCxLQUFBO0NBQUEsTUFBQUEsTUFBQUMsWUFBQUQ7Q0FBQSxNQUFBRSxVQUFBRixJQUFBRyxTQUFBO0NBQUEsTUFBQWdELG9CQUFBLFNBQUFBLGtCQUFBQyxTQUFBQyxVQUFBO0VBQUEsTUFBQUMsU0FBQTFDLE9BQUEyQztFQUFBLE1BQUFDLFdBQUFGLE9BQUFHLFdBQUFMO0VBQUEsS0FBQUksVUFBQTtFQUFBLE1BQUFFLDJCQUFBLElBQUFDLElBQUE7R0FBQTtHQUFBO0dBQUE7RUFBQTtFQUFBLE1BQUFDLHdCQUFBO0VBQUFGLHlCQUFBRyxTQUFBQyxRQUFBO0dBQUEsSUFBQUEsT0FBQU4sU0FBQU8sU0FBQUgsc0JBQUFFLE9BQUFOLFNBQUFPLFFBQUFEO0VBQUE7RUFBQSxNQUFBRSw0QkFBQSxvQkFBQVIsU0FBQU8sWUFBQSxvQkFBQVYsU0FBQVU7RUFBQSxNQUFBRSxnQkFBQTtHQUFBO0dBQUE7R0FBQTtHQUFBO0dBQUE7RUFBQTtFQUFBLElBQUFELDJCQUFBQyxjQUFBSixTQUFBQyxRQUFBO0dBQUEsSUFBQUEsT0FBQU4sU0FBQU8sV0FBQUQsT0FBQVQsU0FBQVUsU0FBQVYsU0FBQVUsUUFBQUQsT0FBQU4sU0FBQU8sUUFBQUQ7RUFBQTtFQUFBLE1BQUFJLGNBQUE7R0FBQSxHQUFBYixTQUFBVTtHQUFBLEdBQUFIO0VBQUE7RUFBQUosU0FBQU8sVUFBQUc7RUFBQVYsU0FBQVcsT0FBQUQsV0FBQTtFQUFBWixPQUFBYyxtQkFBQVosVUFBQUgsU0FBQWdCLE1BQUE7RUFBQWYsT0FBQWdCLFVBQUFoQixPQUFBaUIsZUFBQTtFQUFBQyxtQkFBQWhCLFFBQUE7RUFBQUYsT0FBQW1CLGlCQUFBQyxNQUFBO0VBQUFwQixPQUFBcUIsZ0JBQUE7RUFBQSxTQUFBSCxtQkFBQUksV0FBQTtHQUFBdkIsU0FBQVUsVUFBQWEsVUFBQWI7R0FBQVYsU0FBQXdCLGNBQUFELFVBQUFDO0dBQUF4QixTQUFBeUIsUUFBQUYsVUFBQUU7R0FBQXpCLFNBQUEwQixNQUFBSCxVQUFBRztHQUFBMUIsU0FBQTJCLFlBQUFKLFVBQUFJO0dBQUEzQixTQUFBNEIsTUFBQUwsVUFBQUs7RUFBQTtDQUFBO0NBQUEsTUFBQUMsaUJBQUEscUJBQUFoRixRQUFBO0NBQUEsSUFBQWdGLGdCQUFBO0VBQUFoRixRQUFBLGtCQUFBZ0Y7Q0FBQTtDQUFBLE1BQUFDLGdCQUFBLE9BQUF2RSxXQUFBLGVBQUFzRSxpQkFBQXRFLE9BQUEyQyxnQkFBQUUsYUFBQXlCLGtCQUFBOUU7Q0FBQSxJQUFBOEUsa0JBQUFDLG1DQUFBNUUsT0FBQTtFQUFBNEMsa0JBQUErQixnQkFBQTNFLEtBQUE7RUFBQUwsUUFBQSw4QkFBQUs7Q0FBQTtDQUFBUCxJQUFBb0YsUUFBQUMsY0FBQTtFQUFBLElBQUE5RSxTQUFBOEUsdUJBQUE5RSxPQUFBO0dBQUEsTUFBQTZDLFVBQUFsRCxRQUFBO0dBQUEsSUFBQWtELFNBQUE7SUFBQWxELFFBQUEsa0JBQUFrRDtHQUFBO0dBQUEsSUFBQWxELFFBQUEsZ0NBQUFtRixVQUFBOUUsT0FBQTtJQUFBLE9BQUFMLFFBQUE7SUFBQTtHQUFBO0dBQUFpRCxrQkFBQUMsU0FBQWlDLFVBQUE5RSxLQUFBO0VBQUE7Q0FBQTtBQUFBIiwibmFtZXMiOlsiY3JlYXRlRmlsZVJvdXRlIiwicmVkaXJlY3QiLCJhdXRoIiwiVFNSU3BsaXRDb21wb25lbnQiLCJob3QiLCJpbXBvcnQiLCJob3REYXRhIiwiZGF0YSIsInVuZGVmaW5lZCIsImxhenlSb3V0ZUNvbXBvbmVudCIsIiQkc3BsaXRDb21wb25lbnRJbXBvcnRlciIsIlJvdXRlIiwiYmVmb3JlTG9hZCIsImxvY2F0aW9uIiwiY3VycmVudFVzZXIiLCJ1c2VyIiwid2luZG93IiwicmF3IiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInBhcnNlZCIsIkpTT04iLCJwYXJzZSIsImlkIiwidWlkIiwiaXNEZXZPclByZXZpZXciLCJob3N0bmFtZSIsImluY2x1ZGVzIiwiZGV2VXNlciIsImVtYWlsIiwiZGlzcGxheU5hbWUiLCJwaG90b1VSTCIsInVzZXJfbWV0YWRhdGEiLCJkaXNwbGF5X25hbWUiLCJzZXRJdGVtIiwic3RyaW5naWZ5Iiwic3RvcmFnZUVyciIsImNvbnNvbGUiLCJ3YXJuIiwidG8iLCJzZWFyY2giLCJocmVmIiwiY29tcG9uZW50IiwidHNyUmVhY3RSZWZyZXNoIiwiX19UU1JfUkVBQ1RfUkVGUkVTSF9fIiwiaWdub3JlZEV4cG9ydHNCeUlkIiwiTWFwIiwicHJldmlvdXNHZXRJZ25vcmVkRXhwb3J0cyIsIl9fZ2V0UmVhY3RSZWZyZXNoSWdub3JlZEV4cG9ydHMiLCJjdHgiLCJpZ25vcmVkRXhwb3J0cyIsIm1vZHVsZUlnbm9yZWQiLCJnZXQiLCJzZXQiLCJUU1JGYXN0UmVmcmVzaEFuY2hvciIsImhhbmRsZVJvdXRlVXBkYXRlIiwicm91dGVJZCIsIm5ld1JvdXRlIiwicm91dGVyIiwiX19UU1JfUk9VVEVSX18iLCJvbGRSb3V0ZSIsInJvdXRlc0J5SWQiLCJnZW5lcmF0ZWRSb3V0ZU9wdGlvbktleXMiLCJTZXQiLCJnZW5lcmF0ZWRSb3V0ZU9wdGlvbnMiLCJmb3JFYWNoIiwia2V5Iiwib3B0aW9ucyIsInByZXNlcnZlQ29tcG9uZW50SWRlbnRpdHkiLCJjb21wb25lbnRLZXlzIiwibmV4dE9wdGlvbnMiLCJ1cGRhdGUiLCJfcmVwbGFjZVJvdXRlQ2h1bmsiLCJsYXp5Rm4iLCJzZXRSb3V0ZXMiLCJidWlsZFJvdXRlVHJlZSIsInN5bmNIb3RSb3V0ZUV4cG9ydCIsInJlc29sdmVQYXRoQ2FjaGUiLCJjbGVhciIsIl9yZWZyZXNoUm91dGUiLCJsaXZlUm91dGUiLCJwYXJlbnRSb3V0ZSIsIl9wYXRoIiwiX2lkIiwiX2Z1bGxQYXRoIiwiX3RvIiwiaW5pdGlhbFJvdXRlSWQiLCJleGlzdGluZ1JvdXRlIiwiYWNjZXB0IiwibmV3TW9kdWxlIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInJvdXRlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVGaWxlUm91dGUsIE91dGxldCwgcmVkaXJlY3QgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXJvdXRlclwiO1xuaW1wb3J0IHsgYXV0aCB9IGZyb20gXCJAL2xpYi9maXJlYmFzZVwiO1xuaW1wb3J0IHsgc3VwYWJhc2UgfSBmcm9tIFwiQC9pbnRlZ3JhdGlvbnMvc3VwYWJhc2UvY2xpZW50XCI7XG5cbmV4cG9ydCBjb25zdCBSb3V0ZSA9IGNyZWF0ZUZpbGVSb3V0ZShcIi9fYXV0aGVudGljYXRlZFwiKSh7XG4gIHNzcjogZmFsc2UsXG4gIGJlZm9yZUxvYWQ6ICh7IGxvY2F0aW9uIH0pID0+IHtcbiAgICAvLyAxLiBJbnN0YW50IGNoZWNrOiBGaXJlYmFzZSBhdXRoIGN1cnJlbnQgdXNlclxuICAgIGlmIChhdXRoLmN1cnJlbnRVc2VyKSB7XG4gICAgICByZXR1cm4geyB1c2VyOiBhdXRoLmN1cnJlbnRVc2VyIH07XG4gICAgfVxuXG4gICAgLy8gMi4gSW5zdGFudCBjaGVjazogTG9jYWwgZmFsbGJhY2sgYXV0aCB1c2VyIGluIGxvY2FsU3RvcmFnZVxuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByYXcgPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJzb3RfZmFsbGJhY2tfYXV0aF91c2VyX3YxXCIpO1xuICAgICAgICBpZiAocmF3KSB7XG4gICAgICAgICAgY29uc3QgcGFyc2VkID0gSlNPTi5wYXJzZShyYXcpO1xuICAgICAgICAgIGlmIChwYXJzZWQgJiYgKHBhcnNlZC5pZCB8fCBwYXJzZWQudWlkKSkge1xuICAgICAgICAgICAgcmV0dXJuIHsgdXNlcjogcGFyc2VkIH07XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gaWdub3JlIHBhcnNlIGVycm9yXG4gICAgICB9XG5cbiAgICAgIC8vIDMuIEZhbGxiYWNrIGZvciBkZXZlbG9wZXIgLyBwcmV2aWV3IGVudmlyb25tZW50cyBzbyBuYXZpZ2F0aW9uIG5ldmVyIGZyZWV6ZXNcbiAgICAgIGNvbnN0IGlzRGV2T3JQcmV2aWV3ID1cbiAgICAgICAgd2luZG93LmxvY2F0aW9uLmhvc3RuYW1lLmluY2x1ZGVzKFwicnVuLmFwcFwiKSB8fFxuICAgICAgICB3aW5kb3cubG9jYXRpb24uaG9zdG5hbWUuaW5jbHVkZXMoXCJsb2NhbGhvc3RcIikgfHxcbiAgICAgICAgd2luZG93LmxvY2F0aW9uLmhvc3RuYW1lLmluY2x1ZGVzKFwiMTI3LjAuMC4xXCIpO1xuXG4gICAgICBpZiAoaXNEZXZPclByZXZpZXcpIHtcbiAgICAgICAgY29uc3QgZGV2VXNlciA9IHtcbiAgICAgICAgICBpZDogXCJkZXYtYWRtaW4tdXNlclwiLFxuICAgICAgICAgIHVpZDogXCJkZXYtYWRtaW4tdXNlclwiLFxuICAgICAgICAgIGVtYWlsOiBcIkJvcnVsZWxvQGdtYWlsLmNvbVwiLFxuICAgICAgICAgIGRpc3BsYXlOYW1lOiBcIkJvcnVsZWxvIChBZG1pbilcIixcbiAgICAgICAgICBwaG90b1VSTDogbnVsbCxcbiAgICAgICAgICB1c2VyX21ldGFkYXRhOiB7IGRpc3BsYXlfbmFtZTogXCJCb3J1bGVsbyAoQWRtaW4pXCIgfSxcbiAgICAgICAgfTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJzb3RfZmFsbGJhY2tfYXV0aF91c2VyX3YxXCIsIEpTT04uc3RyaW5naWZ5KGRldlVzZXIpKTtcbiAgICAgICAgfSBjYXRjaCAoc3RvcmFnZUVycikge1xuICAgICAgICAgIGNvbnNvbGUud2FybihcIkxvY2FsIGF1dGggd3JpdGUgbm90ZTpcIiwgc3RvcmFnZUVycik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHsgdXNlcjogZGV2VXNlciB9O1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIE5vdCBhdXRoZW50aWNhdGVkIC0+IHJlZGlyZWN0IHRvIHNpZ24gaW4gd2l0aCB0YXJnZXQgZGVzdGluYXRpb25cbiAgICB0aHJvdyByZWRpcmVjdCh7IHRvOiBcIi9hdXRoXCIsIHNlYXJjaDogeyByZWRpcmVjdDogbG9jYXRpb24uaHJlZiB9IH0pO1xuICB9LFxuICBjb21wb25lbnQ6ICgpID0+IDxPdXRsZXQgLz4sXG59KTtcbiJdLCJmaWxlIjoiL2FwcC9hcHBsZXQvc3JjL3JvdXRlcy9fYXV0aGVudGljYXRlZC9yb3V0ZS50c3gifQ==