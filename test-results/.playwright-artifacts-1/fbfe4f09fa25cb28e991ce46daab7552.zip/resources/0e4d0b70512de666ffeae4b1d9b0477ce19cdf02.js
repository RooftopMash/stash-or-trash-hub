import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MessengerPrivateCallModal.tsx");const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { Mic, MicOff, Video, VideoOff, PhoneOff, MonitorUp, Minimize2, Maximize2, ShieldCheck, Lock, Building2 } from "/node_modules/.vite/deps/lucide-react.js?v=a8030269";
import { Button } from "/src/components/ui/button.tsx";
import { Badge } from "/src/components/ui/badge.tsx";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=a8030269";
import { supabase } from "/src/integrations/supabase/client.ts";
import { useAuth } from "/src/hooks/useAuth.tsx";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "/app/applet/src/components/MessengerPrivateCallModal.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
var _s = $RefreshSig$();
const DEFAULT_GOOGLE_ICE = [
	{ urls: "stun:stun.l.google.com:19302" },
	{ urls: "stun:stun1.l.google.com:19302" },
	{ urls: "stun:stun2.l.google.com:19302" }
];
export function MessengerPrivateCallModal({ open, onOpenChange, session, onCallEnded }) {
	_s();
	const { user } = useAuth();
	const [callState, setCallState] = useState("ringing");
	const [minimized, setMinimized] = useState(false);
	const [callDuration, setCallDuration] = useState(0);
	const [isMuted, setIsMuted] = useState(false);
	const [isVideoDisabled, setIsVideoDisabled] = useState(false);
	const [isScreenSharing, setIsScreenSharing] = useState(false);
	const [engineType, setEngineType] = useState("agora");
	const agoraClientRef = useRef(null);
	const agoraAudioRef = useRef(null);
	const agoraVideoRef = useRef(null);
	const pcRef = useRef(null);
	const localStreamRef = useRef(null);
	const localVideoElRef = useRef(null);
	const remoteVideoElRef = useRef(null);
	const supaChannelRef = useRef(null);
	const localPipVideoElRef = useRef(null);
	const remotePipVideoElRef = useRef(null);
	// Call timer
	useEffect(() => {
		if (callState !== "connected") {
			setCallDuration(0);
			return;
		}
		const interval = setInterval(() => {
			setCallDuration((prev) => prev + 1);
		}, 1e3);
		return () => clearInterval(interval);
	}, [callState]);
	// Clean shutdown
	const hangupCall = useCallback(async () => {
		try {
			agoraAudioRef.current?.close();
			agoraVideoRef.current?.close();
			agoraAudioRef.current = null;
			agoraVideoRef.current = null;
			if (agoraClientRef.current) {
				await agoraClientRef.current.leave();
				agoraClientRef.current = null;
			}
		} catch {}
		if (localStreamRef.current) {
			localStreamRef.current.getTracks().forEach((t) => t.stop());
			localStreamRef.current = null;
		}
		if (pcRef.current) {
			pcRef.current.close();
			pcRef.current = null;
		}
		if (supaChannelRef.current) {
			void supabase.removeChannel(supaChannelRef.current);
			supaChannelRef.current = null;
		}
		setCallState("ended");
		setMinimized(false);
		onOpenChange(false);
		onCallEnded?.();
		toast.info("Private call ended.");
	}, [onOpenChange, onCallEnded]);
	// Connect engine
	useEffect(() => {
		if (!open || !session) return;
		setCallState("ringing");
		setIsMuted(false);
		setIsVideoDisabled(session.mode === "voice");
		setIsScreenSharing(false);
		let isSubscribed = true;
		async function startConnection() {
			if (!session) return;
			const room = session.roomChannel;
			// 1. Try Agora RTC Token API
			try {
				const res = await fetch("/api/agora-token", {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						channelName: room,
						uid: Math.floor(Math.random() * 1e5) + 1,
						role: "publisher"
					})
				});
				if (res.ok) {
					const data = await res.json();
					if (data?.provider === "agora" && data?.appId && data?.token && data?.uid && isSubscribed) {
						setEngineType("agora");
						const { default: AgoraRTC } = await import('/node_modules/.vite/deps/agora-rtc-sdk-ng.js?v=a8030269').then(m => ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(m.default, 1));
						const client = AgoraRTC.createClient({
							mode: "rtc",
							codec: "vp8"
						});
						agoraClientRef.current = client;
						client.on("user-published", async (remoteUser, mediaType) => {
							await client.subscribe(remoteUser, mediaType);
							if (mediaType === "video" && remoteVideoElRef.current) {
								remoteUser.videoTrack?.play(remoteVideoElRef.current);
							}
							if (mediaType === "audio") {
								remoteUser.audioTrack?.play();
							}
							setCallState("connected");
						});
						client.on("user-unpublished", () => {
							// Partner stopped video or left
						});
						client.on("user-left", () => {
							void hangupCall();
						});
						await client.join(data.appId, room, data.token, data.uid);
						const audioTrack = await AgoraRTC.createMicrophoneAudioTrack();
						agoraAudioRef.current = audioTrack;
						await client.publish(audioTrack);
						if (session.mode !== "voice") {
							const videoTrack = await AgoraRTC.createCameraVideoTrack();
							agoraVideoRef.current = videoTrack;
							if (localVideoElRef.current) {
								videoTrack.play(localVideoElRef.current);
							}
							await client.publish(videoTrack);
						}
						// Assume connected after joining and publishing
						setTimeout(() => {
							if (isSubscribed) setCallState("connected");
						}, 1800);
						return;
					}
				}
			} catch (err) {
				console.warn("Agora connection fell back to Google WebRTC:", err);
			}
			// 2. Google WebRTC Fallback
			if (!isSubscribed) return;
			setEngineType("webrtc");
			try {
				const stream = await navigator.mediaDevices.getUserMedia({
					audio: true,
					video: session.mode !== "voice"
				});
				localStreamRef.current = stream;
				if (localVideoElRef.current && session.mode !== "voice") {
					localVideoElRef.current.srcObject = stream;
				}
				const pc = new RTCPeerConnection({ iceServers: DEFAULT_GOOGLE_ICE });
				pcRef.current = pc;
				stream.getTracks().forEach((track) => pc.addTrack(track, stream));
				pc.ontrack = (event) => {
					const [remoteStream] = event.streams;
					if (remoteStream && remoteVideoElRef.current) {
						remoteVideoElRef.current.srcObject = remoteStream;
						setCallState("connected");
					}
				};
				const chan = supabase.channel(`sot-rtc-${room}`);
				supaChannelRef.current = chan;
				chan.on("broadcast", { event: "signal" }, async ({ payload }) => {
					if (!pcRef.current || payload.sender === user?.id) return;
					try {
						if (payload.type === "offer") {
							await pcRef.current.setRemoteDescription(new RTCSessionDescription(payload.sdp));
							const answer = await pcRef.current.createAnswer();
							await pcRef.current.setLocalDescription(answer);
							void chan.send({
								type: "broadcast",
								event: "signal",
								payload: {
									type: "answer",
									sdp: answer,
									sender: user?.id
								}
							});
							setCallState("connected");
						} else if (payload.type === "answer") {
							await pcRef.current.setRemoteDescription(new RTCSessionDescription(payload.sdp));
							setCallState("connected");
						} else if (payload.type === "candidate" && payload.candidate) {
							await pcRef.current.addIceCandidate(new RTCIceCandidate(payload.candidate));
						}
					} catch (e) {
						console.warn("WebRTC message warn:", e);
					}
				}).subscribe(async (status) => {
					if (status === "SUBSCRIBED") {
						const offer = await pc.createOffer();
						await pc.setLocalDescription(offer);
						void chan.send({
							type: "broadcast",
							event: "signal",
							payload: {
								type: "offer",
								sdp: offer,
								sender: user?.id
							}
						});
					}
				});
				pc.onicecandidate = (event) => {
					if (event.candidate) {
						void chan.send({
							type: "broadcast",
							event: "signal",
							payload: {
								type: "candidate",
								candidate: event.candidate.toJSON(),
								sender: user?.id
							}
						});
					}
				};
			} catch (err) {
				console.error("WebRTC mic/cam access error:", err);
				toast.error("Could not access microphone or camera. Check browser permissions.");
				void hangupCall();
			}
		}
		void startConnection();
		return () => {
			isSubscribed = false;
		};
	}, [
		open,
		session,
		user?.id,
		hangupCall
	]);
	// Toggle Microphone
	const toggleMute = () => {
		const next = !isMuted;
		setIsMuted(next);
		if (agoraAudioRef.current) {
			void agoraAudioRef.current.setEnabled(!next);
		}
		if (localStreamRef.current) {
			localStreamRef.current.getAudioTracks().forEach((t) => {
				t.enabled = !next;
			});
		}
		toast.info(next ? "Microphone muted" : "Microphone active");
	};
	// Toggle Camera
	const toggleVideo = async () => {
		const next = !isVideoDisabled;
		setIsVideoDisabled(next);
		if (agoraVideoRef.current) {
			void agoraVideoRef.current.setEnabled(!next);
		}
		if (localStreamRef.current) {
			localStreamRef.current.getVideoTracks().forEach((t) => {
				t.enabled = !next;
			});
		}
	};
	// Toggle Screen Sharing
	const toggleScreenShare = async () => {
		if (isScreenSharing) {
			setIsScreenSharing(false);
			return;
		}
		try {
			const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
			setIsScreenSharing(true);
			if (localVideoElRef.current) {
				localVideoElRef.current.srcObject = screenStream;
			}
			screenStream.getVideoTracks()[0].onended = () => {
				setIsScreenSharing(false);
			};
		} catch {
			toast.info("Screen sharing cancelled.");
		}
	};
	if (!open || !session) return null;
	const formatTimer = (seconds) => {
		const mins = Math.floor(seconds / 60);
		const secs = seconds % 60;
		return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
	};
	// ==========================================
	// 1. MINIMIZED PICTURE-IN-PICTURE BUBBLE
	// (Allows browsing SOT while on the call)
	// ==========================================
	if (minimized) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "fixed bottom-4 right-4 z-50 flex items-center gap-3 rounded-2xl border border-slate-700 bg-slate-950/95 p-3 shadow-2xl backdrop-blur-xl",
			"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:364:7",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "relative flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-slate-800 text-white font-black text-lg",
					"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:365:9",
					children: [session.partnerAvatar ? /* @__PURE__ */ _jsxDEV("img", {
						src: session.partnerAvatar,
						alt: session.partnerName,
						className: "h-full w-full object-cover",
						"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:367:13"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 367,
						columnNumber: 13
					}, this) : session.partnerName.charAt(0).toUpperCase(), session.mode === "video" && !isVideoDisabled && /* @__PURE__ */ _jsxDEV("div", {
						className: "absolute inset-0 bg-black/40 flex items-center justify-center",
						"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:372:13",
						children: /* @__PURE__ */ _jsxDEV(Video, {
							className: "h-4 w-4 text-emerald-400",
							"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:373:15"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 373,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 372,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 365,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "min-w-0 pr-2",
					"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:378:9",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-1.5",
						"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:379:11",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "truncate text-xs font-bold text-white max-w-[120px]",
							"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:380:13",
							children: session.partnerName
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 380,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse",
							"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:383:13"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 383,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 379,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-[11px] font-mono text-emerald-400 font-bold",
						"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:385:11",
						children: callState === "ringing" ? "Ringing..." : formatTimer(callDuration)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 385,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 378,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-1",
					"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:390:9",
					children: [
						/* @__PURE__ */ _jsxDEV(Button, {
							size: "icon",
							variant: "ghost",
							onClick: toggleMute,
							className: cn("h-8 w-8 rounded-full text-slate-300 hover:text-white", isMuted && "bg-rose-500/20 text-rose-400"),
							"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:391:11",
							children: isMuted ? /* @__PURE__ */ _jsxDEV(MicOff, {
								className: "h-4 w-4",
								"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:397:24"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 397,
								columnNumber: 24
							}, this) : /* @__PURE__ */ _jsxDEV(Mic, {
								className: "h-4 w-4",
								"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:397:57"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 397,
								columnNumber: 128
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 391,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							size: "icon",
							variant: "ghost",
							onClick: () => setMinimized(false),
							className: "h-8 w-8 rounded-full text-slate-300 hover:text-white",
							title: "Maximize call window",
							"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:399:11",
							children: /* @__PURE__ */ _jsxDEV(Maximize2, {
								className: "h-4 w-4",
								"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:406:13"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 406,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 399,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Button, {
							size: "icon",
							onClick: () => void hangupCall(),
							className: "h-8 w-8 rounded-full bg-rose-600 hover:bg-rose-500 text-white",
							title: "End call",
							"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:408:11",
							children: /* @__PURE__ */ _jsxDEV(PhoneOff, {
								className: "h-4 w-4",
								"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:414:13"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 414,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 408,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 390,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 364,
			columnNumber: 7
		}, this);
	}
	// ==========================================
	// 2. FULL MESSENGER-STYLE PRIVATE CALL WINDOW
	// ==========================================
	return /* @__PURE__ */ _jsxDEV("div", {
		role: "dialog",
		"aria-modal": "true",
		"aria-label": `Private call with ${session.partnerName}`,
		className: "fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-3 backdrop-blur-md sm:p-6",
		"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:425:5",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "relative flex h-full max-h-[800px] w-full max-w-4xl flex-col overflow-hidden rounded-3xl border border-slate-800 bg-slate-950 text-white shadow-2xl",
			"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:431:7",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between border-b border-slate-800/80 px-6 py-4 bg-slate-900/60",
					"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:433:9",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:434:11",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-800 text-white font-black text-sm",
							"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:435:13",
							children: session.partnerAvatar ? /* @__PURE__ */ _jsxDEV("img", {
								src: session.partnerAvatar,
								alt: session.partnerName,
								className: "h-full w-full rounded-xl object-cover",
								"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:437:17"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 437,
								columnNumber: 17
							}, this) : session.partnerName.charAt(0).toUpperCase()
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 435,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:442:13",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:443:15",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-display text-base font-bold tracking-tight text-white",
									"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:444:17",
									children: session.partnerName
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 444,
									columnNumber: 17
								}, this), session.isBrandCall && /* @__PURE__ */ _jsxDEV(Badge, {
									variant: "outline",
									className: "border-[#d6a928]/40 bg-[#d6a928]/10 text-[10px] text-[#f5d061] font-bold",
									"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:448:19",
									children: [/* @__PURE__ */ _jsxDEV(Building2, {
										className: "mr-1 h-3 w-3",
										"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:449:21"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 449,
										columnNumber: 21
									}, this), " Brand Desk Line"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 448,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 443,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-xs text-slate-400",
								"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:453:15",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "inline-flex items-center gap-1 text-emerald-400 font-semibold",
										"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:454:17",
										children: [/* @__PURE__ */ _jsxDEV(Lock, {
											className: "h-3 w-3",
											"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:455:19"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 455,
											columnNumber: 19
										}, this), " Private 1-on-1 Call"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 454,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:457:17",
										children: "·"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 457,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono text-slate-300",
										"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:458:17",
										children: callState === "ringing" ? /* @__PURE__ */ _jsxDEV("span", {
											className: "text-amber-400 animate-pulse",
											"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:460:21",
											children: "Calling & Ringing..."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 460,
											columnNumber: 21
										}, this) : `Connected ${formatTimer(callDuration)}`
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 458,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 453,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 442,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 434,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:469:11",
						children: /* @__PURE__ */ _jsxDEV(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => setMinimized(true),
							className: "gap-1.5 border-slate-700 bg-slate-900 text-xs text-slate-300 hover:bg-slate-800 hover:text-white",
							title: "Minimize to floating window while you browse",
							"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:470:13",
							children: [/* @__PURE__ */ _jsxDEV(Minimize2, {
								className: "h-3.5 w-3.5",
								"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:477:15"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 477,
								columnNumber: 15
							}, this), " Minimize"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 470,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 469,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 433,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "relative flex-1 bg-slate-950 flex items-center justify-center overflow-hidden",
					"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:483:9",
					children: [
						/* @__PURE__ */ _jsxDEV("video", {
							ref: remoteVideoElRef,
							autoPlay: true,
							playsInline: true,
							className: cn("h-full w-full object-cover", session.mode === "voice" || isVideoDisabled ? "hidden" : "block"),
							"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:485:11"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 485,
							columnNumber: 11
						}, this),
						(session.mode === "voice" || isVideoDisabled) && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col items-center justify-center p-8 text-center",
							"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:497:13",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "relative mb-4 flex h-28 w-28 items-center justify-center rounded-full bg-slate-900 border-2 border-slate-700 text-3xl font-black text-white shadow-2xl",
									"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:498:15",
									children: [session.partnerAvatar ? /* @__PURE__ */ _jsxDEV("img", {
										src: session.partnerAvatar,
										alt: session.partnerName,
										className: "h-full w-full rounded-full object-cover",
										"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:500:19"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 500,
										columnNumber: 19
									}, this) : session.partnerName.charAt(0).toUpperCase(), /* @__PURE__ */ _jsxDEV("div", {
										className: "absolute inset-0 rounded-full border border-emerald-500/30 animate-ping pointer-events-none",
										"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:508:17"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 508,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 498,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-display text-2xl font-black text-white",
									"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:510:15",
									children: session.partnerName
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 510,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "mt-1 text-sm text-slate-400 max-w-md",
									"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:511:15",
									children: session.isBrandCall ? `Speaking directly with ${session.brandName || "Brand"} Desk Operator via SOT Zero-Phone private calling.` : "Private peer-to-peer audio call connected via encrypted WebRTC."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 511,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mt-3 inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-xs font-bold text-emerald-400",
									"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:516:15",
									children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, {
										className: "h-3.5 w-3.5",
										"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:517:17"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 517,
										columnNumber: 17
									}, this), " Zero Phone Numbers Shared · 100% Private"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 516,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 497,
							columnNumber: 13
						}, this),
						session.mode === "video" && !isVideoDisabled && /* @__PURE__ */ _jsxDEV("div", {
							className: "absolute bottom-4 right-4 h-32 w-48 overflow-hidden rounded-2xl border-2 border-slate-700 bg-slate-900 shadow-2xl",
							"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:524:13",
							children: [/* @__PURE__ */ _jsxDEV("video", {
								ref: localVideoElRef,
								autoPlay: true,
								playsInline: true,
								muted: true,
								className: "h-full w-full object-cover -scale-x-100",
								"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:525:15"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 525,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "absolute bottom-1 left-2 text-[10px] font-bold text-white/80 bg-black/60 px-1 rounded",
								"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:532:15",
								children: "You (Private)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 532,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 524,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 483,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-center justify-between border-t border-slate-800 bg-slate-900 px-6 py-4",
					"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:540:9",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "hidden sm:flex items-center gap-2 text-xs text-slate-400",
							"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:541:11",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "flex h-2 w-2 rounded-full bg-emerald-400",
								"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:542:13"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 542,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:543:13",
								children: ["Engine: ", engineType === "agora" ? "Agora Secure RTC" : "Google WebRTC P2P"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 543,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 541,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-center gap-3 mx-auto sm:mx-0",
							"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:546:11",
							children: [
								/* @__PURE__ */ _jsxDEV(Button, {
									size: "icon",
									variant: "outline",
									onClick: toggleMute,
									className: cn("h-12 w-12 rounded-full border-slate-700 text-white transition", isMuted ? "bg-rose-500/20 text-rose-400 border-rose-500/40" : "bg-slate-800 hover:bg-slate-700"),
									title: isMuted ? "Unmute microphone" : "Mute microphone",
									"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:548:13",
									children: isMuted ? /* @__PURE__ */ _jsxDEV(MicOff, {
										className: "h-5 w-5",
										"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:558:26"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 558,
										columnNumber: 26
									}, this) : /* @__PURE__ */ _jsxDEV(Mic, {
										className: "h-5 w-5",
										"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:558:59"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 558,
										columnNumber: 130
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 548,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV(Button, {
									size: "icon",
									variant: "outline",
									onClick: () => void toggleVideo(),
									className: cn("h-12 w-12 rounded-full border-slate-700 text-white transition", isVideoDisabled ? "bg-rose-500/20 text-rose-400 border-rose-500/40" : "bg-slate-800 hover:bg-slate-700"),
									title: isVideoDisabled ? "Turn on camera" : "Turn off camera",
									"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:562:13",
									children: isVideoDisabled ? /* @__PURE__ */ _jsxDEV(VideoOff, {
										className: "h-5 w-5",
										"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:572:34"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 572,
										columnNumber: 34
									}, this) : /* @__PURE__ */ _jsxDEV(Video, {
										className: "h-5 w-5",
										"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:572:69"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 572,
										columnNumber: 140
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 562,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV(Button, {
									size: "icon",
									variant: "outline",
									onClick: () => void toggleScreenShare(),
									className: cn("h-12 w-12 rounded-full border-slate-700 text-white transition", isScreenSharing ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/40" : "bg-slate-800 hover:bg-slate-700"),
									title: "Share screen to inspect product or receipt",
									"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:576:13",
									children: /* @__PURE__ */ _jsxDEV(MonitorUp, {
										className: "h-5 w-5",
										"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:586:15"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 586,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 576,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV(Button, {
									size: "icon",
									onClick: () => void hangupCall(),
									className: "h-12 w-16 rounded-full bg-rose-600 hover:bg-rose-500 text-white shadow-lg transition",
									title: "End call",
									"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:590:13",
									children: /* @__PURE__ */ _jsxDEV(PhoneOff, {
										className: "h-5 w-5",
										"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:596:15"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 596,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 590,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 546,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "hidden sm:block text-right",
							"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:600:11",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-400 block",
								"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:601:13",
								children: "End-to-End Secure"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 601,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-bold text-slate-200",
								"data-tsd-source": "/src/components/MessengerPrivateCallModal.tsx:602:13",
								children: "SOrT Private Line"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 602,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 600,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 540,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 431,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 425,
		columnNumber: 5
	}, this);
}
_s(MessengerPrivateCallModal, "rer7onCW5/42kdR6gs3KoGJsfHY=", false, function() {
	return [useAuth];
});
_c = MessengerPrivateCallModal;
var _c;
$RefreshReg$(_c, "MessengerPrivateCallModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/MessengerPrivateCallModal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/MessengerPrivateCallModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/MessengerPrivateCallModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/MessengerPrivateCallModal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFNQSxTQUNBLEtBQ0EsUUFDQSxPQUNBLFVBQ0EsVUFDQSxXQUNBLFdBQ0EsV0FDQSxhQUNBLE1BS0EsaUJBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUFxQkE7Q0FDQTtDQUNBO0NBQ0E7QUFDQTtBQUVBLDRDQUNBLE1BQ0EsY0FDQSxTQUNBLGVBQ0E7O0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUVBO0NBQ0E7Q0FDQTtDQUVBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBOztDQUdBO0VBQ0E7R0FDQTtHQUNBO0VBQ0E7RUFDQTtHQUNBO0VBQ0E7RUFDQTtDQUNBOztDQUdBO0VBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0lBQ0E7SUFDQTtHQUNBO0VBQ0EsU0FFQTtFQUVBO0dBQ0E7R0FDQTtFQUNBO0VBQ0E7R0FDQTtHQUNBO0VBQ0E7RUFDQTtHQUNBO0dBQ0E7RUFDQTtFQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDQTs7Q0FHQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUVBO0dBQ0E7R0FDQTs7R0FHQTtJQUNBO0tBQ0E7S0FDQTtLQUNBO01BQ0E7TUFDQTtNQUNBO0tBQ0E7SUFDQTtJQUVBO0tBQ0E7S0FDQTtNQUNBO01BQ0E7TUFDQTtPQUFBO09BQUE7TUFBQTtNQUNBO01BRUE7T0FDQTtPQUNBO1FBQ0E7T0FDQTtPQUNBO1FBQ0E7T0FDQTtPQUNBO01BQ0E7TUFFQTs7TUFFQTtNQUVBO09BQ0E7TUFDQTtNQUVBO01BRUE7TUFDQTtNQUNBO01BRUE7T0FDQTtPQUNBO09BQ0E7UUFDQTtPQUNBO09BQ0E7TUFDQTs7TUFHQTtPQUNBO01BQ0E7TUFDQTtLQUNBO0lBQ0E7R0FDQTtJQUNBO0dBQ0E7O0dBR0E7R0FDQTtHQUNBO0lBQ0E7S0FDQTtLQUNBO0lBQ0E7SUFDQTtJQUNBO0tBQ0E7SUFDQTtJQUVBO0lBQ0E7SUFDQTtJQUVBO0tBQ0E7S0FDQTtNQUNBO01BQ0E7S0FDQTtJQUNBO0lBRUE7SUFDQTtJQUVBLEtBQ0E7S0FDQTtLQUNBO01BQ0E7T0FDQTtPQUNBO09BQ0E7T0FDQTtRQUNBO1FBQ0E7UUFDQTtTQUFBO1NBQUE7U0FBQTtRQUFBO09BQ0E7T0FDQTtNQUNBO09BQ0E7T0FDQTtNQUNBO09BQ0E7TUFDQTtLQUNBO01BQ0E7S0FDQTtJQUNBLEdBQ0E7S0FDQTtNQUNBO01BQ0E7TUFDQTtPQUNBO09BQ0E7T0FDQTtRQUFBO1FBQUE7UUFBQTtPQUFBO01BQ0E7S0FDQTtJQUNBO0lBRUE7S0FDQTtNQUNBO09BQ0E7T0FDQTtPQUNBO1FBQ0E7UUFDQTtRQUNBO09BQ0E7TUFDQTtLQUNBO0lBQ0E7R0FDQTtJQUNBO0lBQ0E7SUFDQTtHQUNBO0VBQ0E7RUFFQTtFQUVBO0dBQ0E7RUFDQTtDQUNBO0VBQUE7RUFBQTtFQUFBO0VBQUE7Q0FBQTs7Q0FHQTtFQUNBO0VBQ0E7RUFDQTtHQUNBO0VBQ0E7RUFDQTtHQUNBO0lBQ0E7R0FDQTtFQUNBO0VBQ0E7Q0FDQTs7Q0FHQTtFQUNBO0VBQ0E7RUFDQTtHQUNBO0VBQ0E7RUFDQTtHQUNBO0lBQ0E7R0FDQTtFQUNBO0NBQ0E7O0NBR0E7RUFDQTtHQUNBO0dBQ0E7RUFDQTtFQUNBO0dBQ0E7R0FDQTtHQUNBO0lBQ0E7R0FDQTtHQUNBO0lBQ0E7R0FDQTtFQUNBO0dBQ0E7RUFDQTtDQUNBO0NBRUE7Q0FFQTtFQUNBO0VBQ0E7RUFDQTtDQUNBOzs7OztDQU1BO0VBQ0EsT0FDQTtHQUFBO0dBQUE7YUFBQTtJQUNBO0tBQUE7S0FBQTtlQUFBLENBQ0Esd0JBQ0E7TUFBQTtNQUFBO01BQUE7TUFBQTtLQUE4Rzs7OztnQkFFOUcsNkNBRUEsZ0RBQ0E7TUFBQTtNQUFBO2dCQUNBO09BQUE7T0FBQTtNQUEwRDs7Ozs7S0FDMUQ7Ozs7YUFFQTs7Ozs7O0lBRUE7S0FBQTtLQUFBO2VBQUEsQ0FDQTtNQUFBO01BQUE7Z0JBQUEsQ0FDQTtPQUFBO09BQUE7aUJBQ0E7TUFDQTs7OztnQkFDQTtPQUFBO09BQUE7TUFBcUY7Ozs7Y0FDckY7Ozs7O2VBQ0E7TUFBQTtNQUFBO2dCQUNBO0tBQ0E7Ozs7YUFDQTs7Ozs7O0lBRUE7S0FBQTtLQUFBO2VBQUE7TUFDQTtPQUNBO09BQ0E7T0FDQTtPQUNBO09BQ0E7aUJBQ0E7UUFBQTtRQUFBO09BQW1EOzs7O2tCQUFBO1FBQUE7UUFBQTtPQUE4Qjs7Ozs7TUFDakY7Ozs7O01BQ0E7T0FDQTtPQUNBO09BQ0E7T0FDQTtPQUNBO09BQ0E7aUJBQ0E7UUFBQTtRQUFBO09BQTJDOzs7OztNQUMzQzs7Ozs7TUFDQTtPQUNBO09BQ0E7T0FDQTtPQUNBO09BQ0E7aUJBQ0E7UUFBQTtRQUFBO09BQTBDOzs7OztNQUMxQzs7Ozs7S0FDQTs7Ozs7O0dBQ0E7Ozs7OztDQUVBOzs7O0NBS0EsT0FDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7WUFDQTtHQUFBO0dBQUE7YUFBQTtJQUVBO0tBQUE7S0FBQTtlQUFBLENBQ0E7TUFBQTtNQUFBO2dCQUFBLENBQ0E7T0FBQTtPQUFBO2lCQUNBLHdCQUNBO1FBQUE7UUFBQTtRQUFBO1FBQUE7T0FBNkg7Ozs7a0JBRTdIO01BRUE7Ozs7Z0JBQ0E7T0FBQTtpQkFBQSxDQUNBO1FBQUE7UUFBQTtrQkFBQSxDQUNBO1NBQUE7U0FBQTttQkFDQTtRQUNBOzs7O2tCQUNBLHVCQUNBO1NBQUE7U0FBQTtTQUFBO21CQUFBLENBQ0E7VUFBQTtVQUFBO1NBQXdEOzs7O21CQUFBLGtCQUN4RDs7Ozs7Z0JBRUE7Ozs7O2lCQUNBO1FBQUE7UUFBQTtrQkFBQTtTQUNBO1VBQUE7VUFBQTtvQkFBQSxDQUNBO1dBQUE7V0FBQTtVQUE0Qzs7OztvQkFBQSxzQkFDNUM7Ozs7OztTQUNBO1VBQUE7b0JBQXFCO1NBQUE7Ozs7O1NBQ3JCO1VBQUE7VUFBQTtvQkFDQSwwQkFDQTtXQUFBO1dBQUE7cUJBQWtFO1VBQUE7Ozs7cUJBRWxFO1NBRUE7Ozs7O1FBQ0E7Ozs7O2VBQ0E7Ozs7O2NBQ0E7Ozs7O2VBRUE7TUFBQTtNQUFBO2dCQUNBO09BQ0E7T0FDQTtPQUNBO09BQ0E7T0FDQTtPQUNBO2lCQU5BLENBT0E7UUFBQTtRQUFBO09BQWlEOzs7O2lCQUFBLFdBQ2pEOzs7Ozs7S0FDQTs7OzthQUNBOzs7Ozs7SUFHQTtLQUFBO0tBQUE7ZUFBQTtNQUVBO09BQ0E7T0FDQTtPQUNBO09BQ0EsY0FDQSw4QkFDQSxnRUFDQTtPQUNBO01BQVU7Ozs7O09BR1YsZ0RBQ0E7T0FBQTtPQUFBO2lCQUFBO1FBQ0E7U0FBQTtTQUFBO21CQUFBLENBQ0Esd0JBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtTQUFrQjs7OztvQkFFbEIsNkNBRUE7VUFBQTtVQUFBO1NBQTZIOzs7O2lCQUM3SDs7Ozs7O1FBQ0E7U0FBQTtTQUFBO21CQUF5RTtRQUFBOzs7OztRQUN6RTtTQUFBO1NBQUE7bUJBQ0Esc0JBQ0EsNkdBQ0E7UUFDQTs7Ozs7UUFDQTtTQUFBO1NBQUE7bUJBQUEsQ0FDQTtVQUFBO1VBQUE7U0FBcUQ7Ozs7bUJBQUEsMkNBQ3JEOzs7Ozs7T0FDQTs7Ozs7O01BSUEsZ0RBQ0E7T0FBQTtPQUFBO2lCQUFBLENBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7T0FBYzs7OztpQkFDZDtRQUFBO1FBQUE7a0JBQXFIO09BRXJIOzs7O2VBQ0E7Ozs7OztLQUVBOzs7Ozs7SUFHQTtLQUFBO0tBQUE7ZUFBQTtNQUNBO09BQUE7T0FBQTtpQkFBQSxDQUNBO1FBQUE7UUFBQTtPQUF1RTs7OztpQkFDdkU7UUFBQTtrQkFBQSxDQUFpQjs7Ozs7ZUFDakI7Ozs7OztNQUVBO09BQUE7T0FBQTtpQkFBQTtRQUVBO1NBQ0E7U0FDQTtTQUNBO1NBQ0EsY0FDQSxpRUFDQSwrRkFDQTtTQUNBO1NBQ0E7bUJBQ0E7VUFBQTtVQUFBO1NBQXFEOzs7O29CQUFBO1VBQUE7VUFBQTtTQUE4Qjs7Ozs7UUFDbkY7Ozs7O1FBR0E7U0FDQTtTQUNBO1NBQ0E7U0FDQSxjQUNBLGlFQUNBLHVHQUNBO1NBQ0E7U0FDQTttQkFDQTtVQUFBO1VBQUE7U0FBK0Q7Ozs7b0JBQUE7VUFBQTtVQUFBO1NBQWdDOzs7OztRQUMvRjs7Ozs7UUFHQTtTQUNBO1NBQ0E7U0FDQTtTQUNBLGNBQ0EsaUVBQ0EsZ0hBQ0E7U0FDQTtTQUNBO21CQUNBO1VBQUE7VUFBQTtTQUE2Qzs7Ozs7UUFDN0M7Ozs7O1FBR0E7U0FDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO21CQUNBO1VBQUE7VUFBQTtTQUE0Qzs7Ozs7UUFDNUM7Ozs7O09BQ0E7Ozs7OztNQUVBO09BQUE7T0FBQTtpQkFBQSxDQUNBO1FBQUE7UUFBQTtrQkFBOEQ7T0FBQTs7OztpQkFDOUQ7UUFBQTtRQUFBO2tCQUE4RDtPQUFBOzs7O2VBQzlEOzs7Ozs7S0FDQTs7Ozs7O0dBQ0E7Ozs7OztDQUNBOzs7OztBQUVBIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJNZXNzZW5nZXJQcml2YXRlQ2FsbE1vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlUmVmLCB1c2VFZmZlY3QsIHVzZUNhbGxiYWNrIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgdHlwZSB7XG4gIElBZ29yYVJUQ0NsaWVudCxcbiAgSUNhbWVyYVZpZGVvVHJhY2ssXG4gIElNaWNyb3Bob25lQXVkaW9UcmFjayxcbn0gZnJvbSBcImFnb3JhLXJ0Yy1zZGstbmdcIjtcbmltcG9ydCB7XG4gIE1pYyxcbiAgTWljT2ZmLFxuICBWaWRlbyxcbiAgVmlkZW9PZmYsXG4gIFBob25lT2ZmLFxuICBNb25pdG9yVXAsXG4gIE1pbmltaXplMixcbiAgTWF4aW1pemUyLFxuICBTaGllbGRDaGVjayxcbiAgTG9jayxcbiAgVm9sdW1lMixcbiAgVXNlcixcbiAgU3BhcmtsZXMsXG4gIE1lc3NhZ2VTcXVhcmUsXG4gIEJ1aWxkaW5nMixcbiAgQ2hlY2tDaXJjbGUyLFxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuaW1wb3J0IHsgQmFkZ2UgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2JhZGdlXCI7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gXCJzb25uZXJcIjtcbmltcG9ydCB7IHN1cGFiYXNlIH0gZnJvbSBcIkAvaW50ZWdyYXRpb25zL3N1cGFiYXNlL2NsaWVudFwiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCJAL2hvb2tzL3VzZUF1dGhcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWVzc2VuZ2VyQ2FsbFNlc3Npb24ge1xuICByb29tQ2hhbm5lbDogc3RyaW5nO1xuICBwYXJ0bmVySWQ6IHN0cmluZztcbiAgcGFydG5lck5hbWU6IHN0cmluZztcbiAgcGFydG5lckF2YXRhcj86IHN0cmluZztcbiAgcGFydG5lclJvbGU/OiBzdHJpbmc7XG4gIGlzQnJhbmRDYWxsPzogYm9vbGVhbjtcbiAgYnJhbmROYW1lPzogc3RyaW5nO1xuICBtb2RlOiBcInZvaWNlXCIgfCBcInZpZGVvXCI7XG4gIGNhbGxEaXJlY3Rpb246IFwidXNlcl90b191c2VyXCIgfCBcImJyYW5kX3RvX3VzZXJcIiB8IFwidXNlcl90b19icmFuZFwiO1xufVxuXG5pbnRlcmZhY2UgTWVzc2VuZ2VyUHJpdmF0ZUNhbGxNb2RhbFByb3BzIHtcbiAgb3BlbjogYm9vbGVhbjtcbiAgb25PcGVuQ2hhbmdlOiAob3BlbjogYm9vbGVhbikgPT4gdm9pZDtcbiAgc2Vzc2lvbjogTWVzc2VuZ2VyQ2FsbFNlc3Npb24gfCBudWxsO1xuICBvbkNhbGxFbmRlZD86ICgpID0+IHZvaWQ7XG59XG5cbmNvbnN0IERFRkFVTFRfR09PR0xFX0lDRTogUlRDSWNlU2VydmVyW10gPSBbXG4gIHsgdXJsczogXCJzdHVuOnN0dW4ubC5nb29nbGUuY29tOjE5MzAyXCIgfSxcbiAgeyB1cmxzOiBcInN0dW46c3R1bjEubC5nb29nbGUuY29tOjE5MzAyXCIgfSxcbiAgeyB1cmxzOiBcInN0dW46c3R1bjIubC5nb29nbGUuY29tOjE5MzAyXCIgfSxcbl07XG5cbmV4cG9ydCBmdW5jdGlvbiBNZXNzZW5nZXJQcml2YXRlQ2FsbE1vZGFsKHtcbiAgb3BlbixcbiAgb25PcGVuQ2hhbmdlLFxuICBzZXNzaW9uLFxuICBvbkNhbGxFbmRlZCxcbn06IE1lc3NlbmdlclByaXZhdGVDYWxsTW9kYWxQcm9wcykge1xuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgW2NhbGxTdGF0ZSwgc2V0Q2FsbFN0YXRlXSA9IHVzZVN0YXRlPFwicmluZ2luZ1wiIHwgXCJjb25uZWN0ZWRcIiB8IFwiZW5kZWRcIj4oXCJyaW5naW5nXCIpO1xuICBjb25zdCBbbWluaW1pemVkLCBzZXRNaW5pbWl6ZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbY2FsbER1cmF0aW9uLCBzZXRDYWxsRHVyYXRpb25dID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtpc011dGVkLCBzZXRJc011dGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzVmlkZW9EaXNhYmxlZCwgc2V0SXNWaWRlb0Rpc2FibGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzU2NyZWVuU2hhcmluZywgc2V0SXNTY3JlZW5TaGFyaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2VuZ2luZVR5cGUsIHNldEVuZ2luZVR5cGVdID0gdXNlU3RhdGU8XCJhZ29yYVwiIHwgXCJ3ZWJydGNcIj4oXCJhZ29yYVwiKTtcblxuICBjb25zdCBhZ29yYUNsaWVudFJlZiA9IHVzZVJlZjxJQWdvcmFSVENDbGllbnQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgYWdvcmFBdWRpb1JlZiA9IHVzZVJlZjxJTWljcm9waG9uZUF1ZGlvVHJhY2sgfCBudWxsPihudWxsKTtcbiAgY29uc3QgYWdvcmFWaWRlb1JlZiA9IHVzZVJlZjxJQ2FtZXJhVmlkZW9UcmFjayB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IHBjUmVmID0gdXNlUmVmPFJUQ1BlZXJDb25uZWN0aW9uIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IGxvY2FsU3RyZWFtUmVmID0gdXNlUmVmPE1lZGlhU3RyZWFtIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IGxvY2FsVmlkZW9FbFJlZiA9IHVzZVJlZjxIVE1MVmlkZW9FbGVtZW50IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHJlbW90ZVZpZGVvRWxSZWYgPSB1c2VSZWY8SFRNTFZpZGVvRWxlbWVudCB8IG51bGw+KG51bGwpO1xuICBjb25zdCBzdXBhQ2hhbm5lbFJlZiA9IHVzZVJlZjxSZXR1cm5UeXBlPHR5cGVvZiBzdXBhYmFzZS5jaGFubmVsPiB8IG51bGw+KG51bGwpO1xuICBjb25zdCBsb2NhbFBpcFZpZGVvRWxSZWYgPSB1c2VSZWY8SFRNTFZpZGVvRWxlbWVudCB8IG51bGw+KG51bGwpO1xuICBjb25zdCByZW1vdGVQaXBWaWRlb0VsUmVmID0gdXNlUmVmPEhUTUxWaWRlb0VsZW1lbnQgfCBudWxsPihudWxsKTtcblxuICAvLyBDYWxsIHRpbWVyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGNhbGxTdGF0ZSAhPT0gXCJjb25uZWN0ZWRcIikge1xuICAgICAgc2V0Q2FsbER1cmF0aW9uKDApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBpbnRlcnZhbCA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgIHNldENhbGxEdXJhdGlvbigocHJldikgPT4gcHJldiArIDEpO1xuICAgIH0sIDEwMDApO1xuICAgIHJldHVybiAoKSA9PiBjbGVhckludGVydmFsKGludGVydmFsKTtcbiAgfSwgW2NhbGxTdGF0ZV0pO1xuXG4gIC8vIENsZWFuIHNodXRkb3duXG4gIGNvbnN0IGhhbmd1cENhbGwgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGFnb3JhQXVkaW9SZWYuY3VycmVudD8uY2xvc2UoKTtcbiAgICAgIGFnb3JhVmlkZW9SZWYuY3VycmVudD8uY2xvc2UoKTtcbiAgICAgIGFnb3JhQXVkaW9SZWYuY3VycmVudCA9IG51bGw7XG4gICAgICBhZ29yYVZpZGVvUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgaWYgKGFnb3JhQ2xpZW50UmVmLmN1cnJlbnQpIHtcbiAgICAgICAgYXdhaXQgYWdvcmFDbGllbnRSZWYuY3VycmVudC5sZWF2ZSgpO1xuICAgICAgICBhZ29yYUNsaWVudFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIH1cbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIG5vbi1mYXRhbFxuICAgIH1cblxuICAgIGlmIChsb2NhbFN0cmVhbVJlZi5jdXJyZW50KSB7XG4gICAgICBsb2NhbFN0cmVhbVJlZi5jdXJyZW50LmdldFRyYWNrcygpLmZvckVhY2goKHQpID0+IHQuc3RvcCgpKTtcbiAgICAgIGxvY2FsU3RyZWFtUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH1cbiAgICBpZiAocGNSZWYuY3VycmVudCkge1xuICAgICAgcGNSZWYuY3VycmVudC5jbG9zZSgpO1xuICAgICAgcGNSZWYuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICAgIGlmIChzdXBhQ2hhbm5lbFJlZi5jdXJyZW50KSB7XG4gICAgICB2b2lkIHN1cGFiYXNlLnJlbW92ZUNoYW5uZWwoc3VwYUNoYW5uZWxSZWYuY3VycmVudCk7XG4gICAgICBzdXBhQ2hhbm5lbFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG5cbiAgICBzZXRDYWxsU3RhdGUoXCJlbmRlZFwiKTtcbiAgICBzZXRNaW5pbWl6ZWQoZmFsc2UpO1xuICAgIG9uT3BlbkNoYW5nZShmYWxzZSk7XG4gICAgb25DYWxsRW5kZWQ/LigpO1xuICAgIHRvYXN0LmluZm8oXCJQcml2YXRlIGNhbGwgZW5kZWQuXCIpO1xuICB9LCBbb25PcGVuQ2hhbmdlLCBvbkNhbGxFbmRlZF0pO1xuXG4gIC8vIENvbm5lY3QgZW5naW5lXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFvcGVuIHx8ICFzZXNzaW9uKSByZXR1cm47XG4gICAgc2V0Q2FsbFN0YXRlKFwicmluZ2luZ1wiKTtcbiAgICBzZXRJc011dGVkKGZhbHNlKTtcbiAgICBzZXRJc1ZpZGVvRGlzYWJsZWQoc2Vzc2lvbi5tb2RlID09PSBcInZvaWNlXCIpO1xuICAgIHNldElzU2NyZWVuU2hhcmluZyhmYWxzZSk7XG5cbiAgICBsZXQgaXNTdWJzY3JpYmVkID0gdHJ1ZTtcblxuICAgIGFzeW5jIGZ1bmN0aW9uIHN0YXJ0Q29ubmVjdGlvbigpIHtcbiAgICAgIGlmICghc2Vzc2lvbikgcmV0dXJuO1xuICAgICAgY29uc3Qgcm9vbSA9IHNlc3Npb24ucm9vbUNoYW5uZWw7XG5cbiAgICAgIC8vIDEuIFRyeSBBZ29yYSBSVEMgVG9rZW4gQVBJXG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcIi9hcGkvYWdvcmEtdG9rZW5cIiwge1xuICAgICAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICAgICAgaGVhZGVyczogeyBcImNvbnRlbnQtdHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxuICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgIGNoYW5uZWxOYW1lOiByb29tLFxuICAgICAgICAgICAgdWlkOiBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAxMDAwMDApICsgMSxcbiAgICAgICAgICAgIHJvbGU6IFwicHVibGlzaGVyXCIsXG4gICAgICAgICAgfSksXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcbiAgICAgICAgICBpZiAoZGF0YT8ucHJvdmlkZXIgPT09IFwiYWdvcmFcIiAmJiBkYXRhPy5hcHBJZCAmJiBkYXRhPy50b2tlbiAmJiBkYXRhPy51aWQgJiYgaXNTdWJzY3JpYmVkKSB7XG4gICAgICAgICAgICBzZXRFbmdpbmVUeXBlKFwiYWdvcmFcIik7XG4gICAgICAgICAgICBjb25zdCB7IGRlZmF1bHQ6IEFnb3JhUlRDIH0gPSBhd2FpdCBpbXBvcnQoXCJhZ29yYS1ydGMtc2RrLW5nXCIpO1xuICAgICAgICAgICAgY29uc3QgY2xpZW50ID0gQWdvcmFSVEMuY3JlYXRlQ2xpZW50KHsgbW9kZTogXCJydGNcIiwgY29kZWM6IFwidnA4XCIgfSk7XG4gICAgICAgICAgICBhZ29yYUNsaWVudFJlZi5jdXJyZW50ID0gY2xpZW50O1xuXG4gICAgICAgICAgICBjbGllbnQub24oXCJ1c2VyLXB1Ymxpc2hlZFwiLCBhc3luYyAocmVtb3RlVXNlciwgbWVkaWFUeXBlKSA9PiB7XG4gICAgICAgICAgICAgIGF3YWl0IGNsaWVudC5zdWJzY3JpYmUocmVtb3RlVXNlciwgbWVkaWFUeXBlKTtcbiAgICAgICAgICAgICAgaWYgKG1lZGlhVHlwZSA9PT0gXCJ2aWRlb1wiICYmIHJlbW90ZVZpZGVvRWxSZWYuY3VycmVudCkge1xuICAgICAgICAgICAgICAgIHJlbW90ZVVzZXIudmlkZW9UcmFjaz8ucGxheShyZW1vdGVWaWRlb0VsUmVmLmN1cnJlbnQpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGlmIChtZWRpYVR5cGUgPT09IFwiYXVkaW9cIikge1xuICAgICAgICAgICAgICAgIHJlbW90ZVVzZXIuYXVkaW9UcmFjaz8ucGxheSgpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHNldENhbGxTdGF0ZShcImNvbm5lY3RlZFwiKTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBjbGllbnQub24oXCJ1c2VyLXVucHVibGlzaGVkXCIsICgpID0+IHtcbiAgICAgICAgICAgICAgLy8gUGFydG5lciBzdG9wcGVkIHZpZGVvIG9yIGxlZnRcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBjbGllbnQub24oXCJ1c2VyLWxlZnRcIiwgKCkgPT4ge1xuICAgICAgICAgICAgICB2b2lkIGhhbmd1cENhbGwoKTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBhd2FpdCBjbGllbnQuam9pbihkYXRhLmFwcElkLCByb29tLCBkYXRhLnRva2VuLCBkYXRhLnVpZCk7XG5cbiAgICAgICAgICAgIGNvbnN0IGF1ZGlvVHJhY2sgPSBhd2FpdCBBZ29yYVJUQy5jcmVhdGVNaWNyb3Bob25lQXVkaW9UcmFjaygpO1xuICAgICAgICAgICAgYWdvcmFBdWRpb1JlZi5jdXJyZW50ID0gYXVkaW9UcmFjaztcbiAgICAgICAgICAgIGF3YWl0IGNsaWVudC5wdWJsaXNoKGF1ZGlvVHJhY2spO1xuXG4gICAgICAgICAgICBpZiAoc2Vzc2lvbi5tb2RlICE9PSBcInZvaWNlXCIpIHtcbiAgICAgICAgICAgICAgY29uc3QgdmlkZW9UcmFjayA9IGF3YWl0IEFnb3JhUlRDLmNyZWF0ZUNhbWVyYVZpZGVvVHJhY2soKTtcbiAgICAgICAgICAgICAgYWdvcmFWaWRlb1JlZi5jdXJyZW50ID0gdmlkZW9UcmFjaztcbiAgICAgICAgICAgICAgaWYgKGxvY2FsVmlkZW9FbFJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICAgICAgdmlkZW9UcmFjay5wbGF5KGxvY2FsVmlkZW9FbFJlZi5jdXJyZW50KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBhd2FpdCBjbGllbnQucHVibGlzaCh2aWRlb1RyYWNrKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gQXNzdW1lIGNvbm5lY3RlZCBhZnRlciBqb2luaW5nIGFuZCBwdWJsaXNoaW5nXG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgaWYgKGlzU3Vic2NyaWJlZCkgc2V0Q2FsbFN0YXRlKFwiY29ubmVjdGVkXCIpO1xuICAgICAgICAgICAgfSwgMTgwMCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgY29uc29sZS53YXJuKFwiQWdvcmEgY29ubmVjdGlvbiBmZWxsIGJhY2sgdG8gR29vZ2xlIFdlYlJUQzpcIiwgZXJyKTtcbiAgICAgIH1cblxuICAgICAgLy8gMi4gR29vZ2xlIFdlYlJUQyBGYWxsYmFja1xuICAgICAgaWYgKCFpc1N1YnNjcmliZWQpIHJldHVybjtcbiAgICAgIHNldEVuZ2luZVR5cGUoXCJ3ZWJydGNcIik7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBzdHJlYW0gPSBhd2FpdCBuYXZpZ2F0b3IubWVkaWFEZXZpY2VzLmdldFVzZXJNZWRpYSh7XG4gICAgICAgICAgYXVkaW86IHRydWUsXG4gICAgICAgICAgdmlkZW86IHNlc3Npb24ubW9kZSAhPT0gXCJ2b2ljZVwiLFxuICAgICAgICB9KTtcbiAgICAgICAgbG9jYWxTdHJlYW1SZWYuY3VycmVudCA9IHN0cmVhbTtcbiAgICAgICAgaWYgKGxvY2FsVmlkZW9FbFJlZi5jdXJyZW50ICYmIHNlc3Npb24ubW9kZSAhPT0gXCJ2b2ljZVwiKSB7XG4gICAgICAgICAgbG9jYWxWaWRlb0VsUmVmLmN1cnJlbnQuc3JjT2JqZWN0ID0gc3RyZWFtO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcGMgPSBuZXcgUlRDUGVlckNvbm5lY3Rpb24oeyBpY2VTZXJ2ZXJzOiBERUZBVUxUX0dPT0dMRV9JQ0UgfSk7XG4gICAgICAgIHBjUmVmLmN1cnJlbnQgPSBwYztcbiAgICAgICAgc3RyZWFtLmdldFRyYWNrcygpLmZvckVhY2goKHRyYWNrKSA9PiBwYy5hZGRUcmFjayh0cmFjaywgc3RyZWFtKSk7XG5cbiAgICAgICAgcGMub250cmFjayA9IChldmVudCkgPT4ge1xuICAgICAgICAgIGNvbnN0IFtyZW1vdGVTdHJlYW1dID0gZXZlbnQuc3RyZWFtcztcbiAgICAgICAgICBpZiAocmVtb3RlU3RyZWFtICYmIHJlbW90ZVZpZGVvRWxSZWYuY3VycmVudCkge1xuICAgICAgICAgICAgcmVtb3RlVmlkZW9FbFJlZi5jdXJyZW50LnNyY09iamVjdCA9IHJlbW90ZVN0cmVhbTtcbiAgICAgICAgICAgIHNldENhbGxTdGF0ZShcImNvbm5lY3RlZFwiKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgY29uc3QgY2hhbiA9IHN1cGFiYXNlLmNoYW5uZWwoYHNvdC1ydGMtJHtyb29tfWApO1xuICAgICAgICBzdXBhQ2hhbm5lbFJlZi5jdXJyZW50ID0gY2hhbjtcblxuICAgICAgICBjaGFuXG4gICAgICAgICAgLm9uKFwiYnJvYWRjYXN0XCIsIHsgZXZlbnQ6IFwic2lnbmFsXCIgfSwgYXN5bmMgKHsgcGF5bG9hZCB9KSA9PiB7XG4gICAgICAgICAgICBpZiAoIXBjUmVmLmN1cnJlbnQgfHwgcGF5bG9hZC5zZW5kZXIgPT09IHVzZXI/LmlkKSByZXR1cm47XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICBpZiAocGF5bG9hZC50eXBlID09PSBcIm9mZmVyXCIpIHtcbiAgICAgICAgICAgICAgICBhd2FpdCBwY1JlZi5jdXJyZW50LnNldFJlbW90ZURlc2NyaXB0aW9uKG5ldyBSVENTZXNzaW9uRGVzY3JpcHRpb24ocGF5bG9hZC5zZHApKTtcbiAgICAgICAgICAgICAgICBjb25zdCBhbnN3ZXIgPSBhd2FpdCBwY1JlZi5jdXJyZW50LmNyZWF0ZUFuc3dlcigpO1xuICAgICAgICAgICAgICAgIGF3YWl0IHBjUmVmLmN1cnJlbnQuc2V0TG9jYWxEZXNjcmlwdGlvbihhbnN3ZXIpO1xuICAgICAgICAgICAgICAgIHZvaWQgY2hhbi5zZW5kKHtcbiAgICAgICAgICAgICAgICAgIHR5cGU6IFwiYnJvYWRjYXN0XCIsXG4gICAgICAgICAgICAgICAgICBldmVudDogXCJzaWduYWxcIixcbiAgICAgICAgICAgICAgICAgIHBheWxvYWQ6IHsgdHlwZTogXCJhbnN3ZXJcIiwgc2RwOiBhbnN3ZXIsIHNlbmRlcjogdXNlcj8uaWQgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBzZXRDYWxsU3RhdGUoXCJjb25uZWN0ZWRcIik7XG4gICAgICAgICAgICAgIH0gZWxzZSBpZiAocGF5bG9hZC50eXBlID09PSBcImFuc3dlclwiKSB7XG4gICAgICAgICAgICAgICAgYXdhaXQgcGNSZWYuY3VycmVudC5zZXRSZW1vdGVEZXNjcmlwdGlvbihuZXcgUlRDU2Vzc2lvbkRlc2NyaXB0aW9uKHBheWxvYWQuc2RwKSk7XG4gICAgICAgICAgICAgICAgc2V0Q2FsbFN0YXRlKFwiY29ubmVjdGVkXCIpO1xuICAgICAgICAgICAgICB9IGVsc2UgaWYgKHBheWxvYWQudHlwZSA9PT0gXCJjYW5kaWRhdGVcIiAmJiBwYXlsb2FkLmNhbmRpZGF0ZSkge1xuICAgICAgICAgICAgICAgIGF3YWl0IHBjUmVmLmN1cnJlbnQuYWRkSWNlQ2FuZGlkYXRlKG5ldyBSVENJY2VDYW5kaWRhdGUocGF5bG9hZC5jYW5kaWRhdGUpKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICBjb25zb2xlLndhcm4oXCJXZWJSVEMgbWVzc2FnZSB3YXJuOlwiLCBlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KVxuICAgICAgICAgIC5zdWJzY3JpYmUoYXN5bmMgKHN0YXR1cykgPT4ge1xuICAgICAgICAgICAgaWYgKHN0YXR1cyA9PT0gXCJTVUJTQ1JJQkVEXCIpIHtcbiAgICAgICAgICAgICAgY29uc3Qgb2ZmZXIgPSBhd2FpdCBwYy5jcmVhdGVPZmZlcigpO1xuICAgICAgICAgICAgICBhd2FpdCBwYy5zZXRMb2NhbERlc2NyaXB0aW9uKG9mZmVyKTtcbiAgICAgICAgICAgICAgdm9pZCBjaGFuLnNlbmQoe1xuICAgICAgICAgICAgICAgIHR5cGU6IFwiYnJvYWRjYXN0XCIsXG4gICAgICAgICAgICAgICAgZXZlbnQ6IFwic2lnbmFsXCIsXG4gICAgICAgICAgICAgICAgcGF5bG9hZDogeyB0eXBlOiBcIm9mZmVyXCIsIHNkcDogb2ZmZXIsIHNlbmRlcjogdXNlcj8uaWQgfSxcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgcGMub25pY2VjYW5kaWRhdGUgPSAoZXZlbnQpID0+IHtcbiAgICAgICAgICBpZiAoZXZlbnQuY2FuZGlkYXRlKSB7XG4gICAgICAgICAgICB2b2lkIGNoYW4uc2VuZCh7XG4gICAgICAgICAgICAgIHR5cGU6IFwiYnJvYWRjYXN0XCIsXG4gICAgICAgICAgICAgIGV2ZW50OiBcInNpZ25hbFwiLFxuICAgICAgICAgICAgICBwYXlsb2FkOiB7XG4gICAgICAgICAgICAgICAgdHlwZTogXCJjYW5kaWRhdGVcIixcbiAgICAgICAgICAgICAgICBjYW5kaWRhdGU6IGV2ZW50LmNhbmRpZGF0ZS50b0pTT04oKSxcbiAgICAgICAgICAgICAgICBzZW5kZXI6IHVzZXI/LmlkLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJXZWJSVEMgbWljL2NhbSBhY2Nlc3MgZXJyb3I6XCIsIGVycik7XG4gICAgICAgIHRvYXN0LmVycm9yKFwiQ291bGQgbm90IGFjY2VzcyBtaWNyb3Bob25lIG9yIGNhbWVyYS4gQ2hlY2sgYnJvd3NlciBwZXJtaXNzaW9ucy5cIik7XG4gICAgICAgIHZvaWQgaGFuZ3VwQ2FsbCgpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHZvaWQgc3RhcnRDb25uZWN0aW9uKCk7XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaXNTdWJzY3JpYmVkID0gZmFsc2U7XG4gICAgfTtcbiAgfSwgW29wZW4sIHNlc3Npb24sIHVzZXI/LmlkLCBoYW5ndXBDYWxsXSk7XG5cbiAgLy8gVG9nZ2xlIE1pY3JvcGhvbmVcbiAgY29uc3QgdG9nZ2xlTXV0ZSA9ICgpID0+IHtcbiAgICBjb25zdCBuZXh0ID0gIWlzTXV0ZWQ7XG4gICAgc2V0SXNNdXRlZChuZXh0KTtcbiAgICBpZiAoYWdvcmFBdWRpb1JlZi5jdXJyZW50KSB7XG4gICAgICB2b2lkIGFnb3JhQXVkaW9SZWYuY3VycmVudC5zZXRFbmFibGVkKCFuZXh0KTtcbiAgICB9XG4gICAgaWYgKGxvY2FsU3RyZWFtUmVmLmN1cnJlbnQpIHtcbiAgICAgIGxvY2FsU3RyZWFtUmVmLmN1cnJlbnQuZ2V0QXVkaW9UcmFja3MoKS5mb3JFYWNoKCh0KSA9PiB7XG4gICAgICAgIHQuZW5hYmxlZCA9ICFuZXh0O1xuICAgICAgfSk7XG4gICAgfVxuICAgIHRvYXN0LmluZm8obmV4dCA/IFwiTWljcm9waG9uZSBtdXRlZFwiIDogXCJNaWNyb3Bob25lIGFjdGl2ZVwiKTtcbiAgfTtcblxuICAvLyBUb2dnbGUgQ2FtZXJhXG4gIGNvbnN0IHRvZ2dsZVZpZGVvID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IG5leHQgPSAhaXNWaWRlb0Rpc2FibGVkO1xuICAgIHNldElzVmlkZW9EaXNhYmxlZChuZXh0KTtcbiAgICBpZiAoYWdvcmFWaWRlb1JlZi5jdXJyZW50KSB7XG4gICAgICB2b2lkIGFnb3JhVmlkZW9SZWYuY3VycmVudC5zZXRFbmFibGVkKCFuZXh0KTtcbiAgICB9XG4gICAgaWYgKGxvY2FsU3RyZWFtUmVmLmN1cnJlbnQpIHtcbiAgICAgIGxvY2FsU3RyZWFtUmVmLmN1cnJlbnQuZ2V0VmlkZW9UcmFja3MoKS5mb3JFYWNoKCh0KSA9PiB7XG4gICAgICAgIHQuZW5hYmxlZCA9ICFuZXh0O1xuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIFRvZ2dsZSBTY3JlZW4gU2hhcmluZ1xuICBjb25zdCB0b2dnbGVTY3JlZW5TaGFyZSA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoaXNTY3JlZW5TaGFyaW5nKSB7XG4gICAgICBzZXRJc1NjcmVlblNoYXJpbmcoZmFsc2UpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgY29uc3Qgc2NyZWVuU3RyZWFtID0gYXdhaXQgbmF2aWdhdG9yLm1lZGlhRGV2aWNlcy5nZXREaXNwbGF5TWVkaWEoeyB2aWRlbzogdHJ1ZSB9KTtcbiAgICAgIHNldElzU2NyZWVuU2hhcmluZyh0cnVlKTtcbiAgICAgIGlmIChsb2NhbFZpZGVvRWxSZWYuY3VycmVudCkge1xuICAgICAgICBsb2NhbFZpZGVvRWxSZWYuY3VycmVudC5zcmNPYmplY3QgPSBzY3JlZW5TdHJlYW07XG4gICAgICB9XG4gICAgICBzY3JlZW5TdHJlYW0uZ2V0VmlkZW9UcmFja3MoKVswXS5vbmVuZGVkID0gKCkgPT4ge1xuICAgICAgICBzZXRJc1NjcmVlblNoYXJpbmcoZmFsc2UpO1xuICAgICAgfTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHRvYXN0LmluZm8oXCJTY3JlZW4gc2hhcmluZyBjYW5jZWxsZWQuXCIpO1xuICAgIH1cbiAgfTtcblxuICBpZiAoIW9wZW4gfHwgIXNlc3Npb24pIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IGZvcm1hdFRpbWVyID0gKHNlY29uZHM6IG51bWJlcikgPT4ge1xuICAgIGNvbnN0IG1pbnMgPSBNYXRoLmZsb29yKHNlY29uZHMgLyA2MCk7XG4gICAgY29uc3Qgc2VjcyA9IHNlY29uZHMgJSA2MDtcbiAgICByZXR1cm4gYCR7U3RyaW5nKG1pbnMpLnBhZFN0YXJ0KDIsIFwiMFwiKX06JHtTdHJpbmcoc2VjcykucGFkU3RhcnQoMiwgXCIwXCIpfWA7XG4gIH07XG5cbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gIC8vIDEuIE1JTklNSVpFRCBQSUNUVVJFLUlOLVBJQ1RVUkUgQlVCQkxFXG4gIC8vIChBbGxvd3MgYnJvd3NpbmcgU09UIHdoaWxlIG9uIHRoZSBjYWxsKVxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgaWYgKG1pbmltaXplZCkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGJvdHRvbS00IHJpZ2h0LTQgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBiZy1zbGF0ZS05NTAvOTUgcC0zIHNoYWRvdy0yeGwgYmFja2Ryb3AtYmx1ci14bFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggaC0xMiB3LTEyIHNocmluay0wIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBiZy1zbGF0ZS04MDAgdGV4dC13aGl0ZSBmb250LWJsYWNrIHRleHQtbGdcIj5cbiAgICAgICAgICB7c2Vzc2lvbi5wYXJ0bmVyQXZhdGFyID8gKFxuICAgICAgICAgICAgPGltZyBzcmM9e3Nlc3Npb24ucGFydG5lckF2YXRhcn0gYWx0PXtzZXNzaW9uLnBhcnRuZXJOYW1lfSBjbGFzc05hbWU9XCJoLWZ1bGwgdy1mdWxsIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIHNlc3Npb24ucGFydG5lck5hbWUuY2hhckF0KDApLnRvVXBwZXJDYXNlKClcbiAgICAgICAgICApfVxuICAgICAgICAgIHtzZXNzaW9uLm1vZGUgPT09IFwidmlkZW9cIiAmJiAhaXNWaWRlb0Rpc2FibGVkICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ibGFjay80MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8VmlkZW8gY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBwci0yXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIG1heC13LVsxMjBweF1cIj5cbiAgICAgICAgICAgICAge3Nlc3Npb24ucGFydG5lck5hbWV9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGgtMiB3LTIgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNTAwIGFuaW1hdGUtcHVsc2VcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtbW9ubyB0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAge2NhbGxTdGF0ZSA9PT0gXCJyaW5naW5nXCIgPyBcIlJpbmdpbmcuLi5cIiA6IGZvcm1hdFRpbWVyKGNhbGxEdXJhdGlvbil9XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgc2l6ZT1cImljb25cIlxuICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcbiAgICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZU11dGV9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2NuKFwiaC04IHctOCByb3VuZGVkLWZ1bGwgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC13aGl0ZVwiLCBpc011dGVkICYmIFwiYmctcm9zZS01MDAvMjAgdGV4dC1yb3NlLTQwMFwiKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7aXNNdXRlZCA/IDxNaWNPZmYgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IDogPE1pYyBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz59XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgc2l6ZT1cImljb25cIlxuICAgICAgICAgICAgdmFyaWFudD1cImdob3N0XCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1pbmltaXplZChmYWxzZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggdy04IHJvdW5kZWQtZnVsbCB0ZXh0LXNsYXRlLTMwMCBob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgIHRpdGxlPVwiTWF4aW1pemUgY2FsbCB3aW5kb3dcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxNYXhpbWl6ZTIgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgc2l6ZT1cImljb25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBoYW5ndXBDYWxsKCl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggdy04IHJvdW5kZWQtZnVsbCBiZy1yb3NlLTYwMCBob3ZlcjpiZy1yb3NlLTUwMCB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgIHRpdGxlPVwiRW5kIGNhbGxcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxQaG9uZU9mZiBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gIC8vIDIuIEZVTEwgTUVTU0VOR0VSLVNUWUxFIFBSSVZBVEUgQ0FMTCBXSU5ET1dcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgcm9sZT1cImRpYWxvZ1wiXG4gICAgICBhcmlhLW1vZGFsPVwidHJ1ZVwiXG4gICAgICBhcmlhLWxhYmVsPXtgUHJpdmF0ZSBjYWxsIHdpdGggJHtzZXNzaW9uLnBhcnRuZXJOYW1lfWB9XG4gICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYmxhY2svODUgcC0zIGJhY2tkcm9wLWJsdXItbWQgc206cC02XCJcbiAgICA+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggaC1mdWxsIG1heC1oLVs4MDBweF0gdy1mdWxsIG1heC13LTR4bCBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0zeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgYmctc2xhdGUtOTUwIHRleHQtd2hpdGUgc2hhZG93LTJ4bFwiPlxuICAgICAgICB7LyogVG9wIEhlYWRlcjogUHJpdmFjeSBiYWRnZSwgcGFydG5lciBpZGVudGl0eSAmIG1pbmltaXplIGJ1dHRvbiAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMC84MCBweC02IHB5LTQgYmctc2xhdGUtOTAwLzYwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtMTAgdy0xMCBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBiZy1zbGF0ZS04MDAgdGV4dC13aGl0ZSBmb250LWJsYWNrIHRleHQtc21cIj5cbiAgICAgICAgICAgICAge3Nlc3Npb24ucGFydG5lckF2YXRhciA/IChcbiAgICAgICAgICAgICAgICA8aW1nIHNyYz17c2Vzc2lvbi5wYXJ0bmVyQXZhdGFyfSBhbHQ9e3Nlc3Npb24ucGFydG5lck5hbWV9IGNsYXNzTmFtZT1cImgtZnVsbCB3LWZ1bGwgcm91bmRlZC14bCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIHNlc3Npb24ucGFydG5lck5hbWUuY2hhckF0KDApLnRvVXBwZXJDYXNlKClcbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC1iYXNlIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICB7c2Vzc2lvbi5wYXJ0bmVyTmFtZX1cbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIHtzZXNzaW9uLmlzQnJhbmRDYWxsICYmIChcbiAgICAgICAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwib3V0bGluZVwiIGNsYXNzTmFtZT1cImJvcmRlci1bI2Q2YTkyOF0vNDAgYmctWyNkNmE5MjhdLzEwIHRleHQtWzEwcHhdIHRleHQtWyNmNWQwNjFdIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICA8QnVpbGRpbmcyIGNsYXNzTmFtZT1cIm1yLTEgaC0zIHctM1wiIC8+IEJyYW5kIERlc2sgTGluZVxuICAgICAgICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtZW1lcmFsZC00MDAgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgPExvY2sgY2xhc3NOYW1lPVwiaC0zIHctM1wiIC8+IFByaXZhdGUgMS1vbi0xIENhbGxcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4+wrc8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICB7Y2FsbFN0YXRlID09PSBcInJpbmdpbmdcIiA/IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1hbWJlci00MDAgYW5pbWF0ZS1wdWxzZVwiPkNhbGxpbmcgJmFtcDsgUmluZ2luZy4uLjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIGBDb25uZWN0ZWQgJHtmb3JtYXRUaW1lcihjYWxsRHVyYXRpb24pfWBcbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1pbmltaXplZCh0cnVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2FwLTEuNSBib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTkwMCB0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTgwMCBob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgdGl0bGU9XCJNaW5pbWl6ZSB0byBmbG9hdGluZyB3aW5kb3cgd2hpbGUgeW91IGJyb3dzZVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxNaW5pbWl6ZTIgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPiBNaW5pbWl6ZVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBWaWRlbyAvIENhbGwgQ2VudGVyc3RhZ2UgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleC0xIGJnLXNsYXRlLTk1MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICB7LyogUmVtb3RlIFZpZGVvIFRyYWNrICovfVxuICAgICAgICAgIDx2aWRlb1xuICAgICAgICAgICAgcmVmPXtyZW1vdGVWaWRlb0VsUmVmfVxuICAgICAgICAgICAgYXV0b1BsYXlcbiAgICAgICAgICAgIHBsYXlzSW5saW5lXG4gICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICBcImgtZnVsbCB3LWZ1bGwgb2JqZWN0LWNvdmVyXCIsXG4gICAgICAgICAgICAgIHNlc3Npb24ubW9kZSA9PT0gXCJ2b2ljZVwiIHx8IGlzVmlkZW9EaXNhYmxlZCA/IFwiaGlkZGVuXCIgOiBcImJsb2NrXCIsXG4gICAgICAgICAgICApfVxuICAgICAgICAgIC8+XG5cbiAgICAgICAgICB7LyogVm9pY2Utb25seSBvciBBdWRpbyBDYWxsIEF2YXRhciBHcmFwaGljICovfVxuICAgICAgICAgIHsoc2Vzc2lvbi5tb2RlID09PSBcInZvaWNlXCIgfHwgaXNWaWRlb0Rpc2FibGVkKSAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtOCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG1iLTQgZmxleCBoLTI4IHctMjggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyLTIgYm9yZGVyLXNsYXRlLTcwMCB0ZXh0LTN4bCBmb250LWJsYWNrIHRleHQtd2hpdGUgc2hhZG93LTJ4bFwiPlxuICAgICAgICAgICAgICAgIHtzZXNzaW9uLnBhcnRuZXJBdmF0YXIgPyAoXG4gICAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICAgIHNyYz17c2Vzc2lvbi5wYXJ0bmVyQXZhdGFyfVxuICAgICAgICAgICAgICAgICAgICBhbHQ9e3Nlc3Npb24ucGFydG5lck5hbWV9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtZnVsbCB3LWZ1bGwgcm91bmRlZC1mdWxsIG9iamVjdC1jb3ZlclwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICBzZXNzaW9uLnBhcnRuZXJOYW1lLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgYW5pbWF0ZS1waW5nIHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtd2hpdGVcIj57c2Vzc2lvbi5wYXJ0bmVyTmFtZX08L2g0PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1zbGF0ZS00MDAgbWF4LXctbWRcIj5cbiAgICAgICAgICAgICAgICB7c2Vzc2lvbi5pc0JyYW5kQ2FsbFxuICAgICAgICAgICAgICAgICAgPyBgU3BlYWtpbmcgZGlyZWN0bHkgd2l0aCAke3Nlc3Npb24uYnJhbmROYW1lIHx8IFwiQnJhbmRcIn0gRGVzayBPcGVyYXRvciB2aWEgU09UIFplcm8tUGhvbmUgcHJpdmF0ZSBjYWxsaW5nLmBcbiAgICAgICAgICAgICAgICAgIDogXCJQcml2YXRlIHBlZXItdG8tcGVlciBhdWRpbyBjYWxsIGNvbm5lY3RlZCB2aWEgZW5jcnlwdGVkIFdlYlJUQy5cIn1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgYmctZW1lcmFsZC01MDAvMTAgcHgtMyBweS0xIHRleHQteHMgZm9udC1ib2xkIHRleHQtZW1lcmFsZC00MDBcIj5cbiAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPiBaZXJvIFBob25lIE51bWJlcnMgU2hhcmVkIMK3IDEwMCUgUHJpdmF0ZVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogTG9jYWwgUGljdHVyZS1pbi1QaWN0dXJlIFZpZGVvIFByZXZpZXcgKi99XG4gICAgICAgICAge3Nlc3Npb24ubW9kZSA9PT0gXCJ2aWRlb1wiICYmICFpc1ZpZGVvRGlzYWJsZWQgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tNCByaWdodC00IGgtMzIgdy00OCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgYm9yZGVyLTIgYm9yZGVyLXNsYXRlLTcwMCBiZy1zbGF0ZS05MDAgc2hhZG93LTJ4bFwiPlxuICAgICAgICAgICAgICA8dmlkZW9cbiAgICAgICAgICAgICAgICByZWY9e2xvY2FsVmlkZW9FbFJlZn1cbiAgICAgICAgICAgICAgICBhdXRvUGxheVxuICAgICAgICAgICAgICAgIHBsYXlzSW5saW5lXG4gICAgICAgICAgICAgICAgbXV0ZWRcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgdy1mdWxsIG9iamVjdC1jb3ZlciAtc2NhbGUteC0xMDBcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMSBsZWZ0LTIgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtd2hpdGUvODAgYmctYmxhY2svNjAgcHgtMSByb3VuZGVkXCI+XG4gICAgICAgICAgICAgICAgWW91IChQcml2YXRlKVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQm90dG9tIE1lc3NlbmdlciBDYWxsaW5nIENvbnRyb2wgQmFyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBiZy1zbGF0ZS05MDAgcHgtNiBweS00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gc206ZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBoLTIgdy0yIHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTQwMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5FbmdpbmU6IHtlbmdpbmVUeXBlID09PSBcImFnb3JhXCIgPyBcIkFnb3JhIFNlY3VyZSBSVENcIiA6IFwiR29vZ2xlIFdlYlJUQyBQMlBcIn08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0zIG14LWF1dG8gc206bXgtMFwiPlxuICAgICAgICAgICAgey8qIE1pYyBUb2dnbGUgKi99XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHNpemU9XCJpY29uXCJcbiAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVNdXRlfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgIFwiaC0xMiB3LTEyIHJvdW5kZWQtZnVsbCBib3JkZXItc2xhdGUtNzAwIHRleHQtd2hpdGUgdHJhbnNpdGlvblwiLFxuICAgICAgICAgICAgICAgIGlzTXV0ZWQgPyBcImJnLXJvc2UtNTAwLzIwIHRleHQtcm9zZS00MDAgYm9yZGVyLXJvc2UtNTAwLzQwXCIgOiBcImJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDBcIixcbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgdGl0bGU9e2lzTXV0ZWQgPyBcIlVubXV0ZSBtaWNyb3Bob25lXCIgOiBcIk11dGUgbWljcm9waG9uZVwifVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7aXNNdXRlZCA/IDxNaWNPZmYgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+IDogPE1pYyBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz59XG4gICAgICAgICAgICA8L0J1dHRvbj5cblxuICAgICAgICAgICAgey8qIFZpZGVvIFRvZ2dsZSAqL31cbiAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgc2l6ZT1cImljb25cIlxuICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHZvaWQgdG9nZ2xlVmlkZW8oKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICBcImgtMTIgdy0xMiByb3VuZGVkLWZ1bGwgYm9yZGVyLXNsYXRlLTcwMCB0ZXh0LXdoaXRlIHRyYW5zaXRpb25cIixcbiAgICAgICAgICAgICAgICBpc1ZpZGVvRGlzYWJsZWQgPyBcImJnLXJvc2UtNTAwLzIwIHRleHQtcm9zZS00MDAgYm9yZGVyLXJvc2UtNTAwLzQwXCIgOiBcImJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDBcIixcbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgdGl0bGU9e2lzVmlkZW9EaXNhYmxlZCA/IFwiVHVybiBvbiBjYW1lcmFcIiA6IFwiVHVybiBvZmYgY2FtZXJhXCJ9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtpc1ZpZGVvRGlzYWJsZWQgPyA8VmlkZW9PZmYgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+IDogPFZpZGVvIGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPn1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuXG4gICAgICAgICAgICB7LyogU2NyZWVuIFNoYXJpbmcgVG9nZ2xlICovfVxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICBzaXplPVwiaWNvblwiXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCB0b2dnbGVTY3JlZW5TaGFyZSgpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgIFwiaC0xMiB3LTEyIHJvdW5kZWQtZnVsbCBib3JkZXItc2xhdGUtNzAwIHRleHQtd2hpdGUgdHJhbnNpdGlvblwiLFxuICAgICAgICAgICAgICAgIGlzU2NyZWVuU2hhcmluZyA/IFwiYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTQwMCBib3JkZXItZW1lcmFsZC01MDAvNDBcIiA6IFwiYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMFwiLFxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICB0aXRsZT1cIlNoYXJlIHNjcmVlbiB0byBpbnNwZWN0IHByb2R1Y3Qgb3IgcmVjZWlwdFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxNb25pdG9yVXAgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgICA8L0J1dHRvbj5cblxuICAgICAgICAgICAgey8qIFJlZCBFbmQgQ2FsbCBCdXR0b24gKi99XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHNpemU9XCJpY29uXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBoYW5ndXBDYWxsKCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTIgdy0xNiByb3VuZGVkLWZ1bGwgYmctcm9zZS02MDAgaG92ZXI6Ymctcm9zZS01MDAgdGV4dC13aGl0ZSBzaGFkb3ctbGcgdHJhbnNpdGlvblwiXG4gICAgICAgICAgICAgIHRpdGxlPVwiRW5kIGNhbGxcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8UGhvbmVPZmYgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmJsb2NrIHRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGJsb2NrXCI+RW5kLXRvLUVuZCBTZWN1cmU8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTIwMFwiPlNPclQgUHJpdmF0ZSBMaW5lPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvYXBwL2FwcGxldC9zcmMvY29tcG9uZW50cy9NZXNzZW5nZXJQcml2YXRlQ2FsbE1vZGFsLnRzeCJ9