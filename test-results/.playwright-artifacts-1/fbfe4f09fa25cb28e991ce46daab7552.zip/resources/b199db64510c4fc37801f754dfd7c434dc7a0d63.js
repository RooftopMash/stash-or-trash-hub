import i18n from "/node_modules/.vite/deps/i18next.js?v=a8030269";
import { initReactI18next } from "/node_modules/.vite/deps/react-i18next.js?v=a8030269";
import LanguageDetector from "/node_modules/.vite/deps/i18next-browser-languagedetector.js?v=a8030269";
import { en } from "/src/lib/locale-en.ts";
import { translations } from "/src/lib/locales.ts";
import { socialTranslations } from "/src/lib/locale-social.ts";
import { extraTranslations } from "/src/lib/locales-extra.ts";
import { appTranslations } from "/src/lib/locale-app.ts";
import { COUNTRY_FLAGSHIP_APP_BUNDLES } from "/src/lib/country-languages.ts";
// Full list of 52 selectable launch languages (native names & RTL metadata)
export const LANGUAGES = [
	{
		code: "en",
		label: "English"
	},
	{
		code: "es",
		label: "Español"
	},
	{
		code: "fr",
		label: "Français"
	},
	{
		code: "de",
		label: "Deutsch"
	},
	{
		code: "pt",
		label: "Português"
	},
	{
		code: "it",
		label: "Italiano"
	},
	{
		code: "nl",
		label: "Nederlands"
	},
	{
		code: "pl",
		label: "Polski"
	},
	{
		code: "ro",
		label: "Română"
	},
	{
		code: "sv",
		label: "Svenska"
	},
	{
		code: "no",
		label: "Norsk"
	},
	{
		code: "da",
		label: "Dansk"
	},
	{
		code: "fi",
		label: "Suomi"
	},
	{
		code: "cs",
		label: "Čeština"
	},
	{
		code: "hu",
		label: "Magyar"
	},
	{
		code: "el",
		label: "Ελληνικά"
	},
	{
		code: "uk",
		label: "Українська"
	},
	{
		code: "ru",
		label: "Русский"
	},
	{
		code: "tr",
		label: "Türkçe"
	},
	{
		code: "ar",
		label: "العربية",
		direction: "rtl"
	},
	{
		code: "he",
		label: "עברית",
		direction: "rtl"
	},
	{
		code: "fa",
		label: "فارسی",
		direction: "rtl"
	},
	{
		code: "ur",
		label: "اردو",
		direction: "rtl"
	},
	{
		code: "hi",
		label: "हिन्दी"
	},
	{
		code: "bn",
		label: "বাংলা"
	},
	{
		code: "ta",
		label: "தமிழ்"
	},
	{
		code: "te",
		label: "తెలుగు"
	},
	{
		code: "mr",
		label: "मराठी"
	},
	{
		code: "gu",
		label: "ગુજરાતી"
	},
	{
		code: "pa",
		label: "ਪੰਜਾਬੀ"
	},
	{
		code: "th",
		label: "ไทย"
	},
	{
		code: "vi",
		label: "Tiếng Việt"
	},
	{
		code: "id",
		label: "Bahasa Indonesia"
	},
	{
		code: "ms",
		label: "Bahasa Melayu"
	},
	{
		code: "fil",
		label: "Filipino"
	},
	{
		code: "zh-CN",
		label: "简体中文（中国大陆）"
	},
	{
		code: "zh-TW",
		label: "繁體中文（台灣）"
	},
	{
		code: "ja",
		label: "日本語"
	},
	{
		code: "ko",
		label: "한국어"
	},
	{
		code: "sw",
		label: "Kiswahili"
	},
	{
		code: "am",
		label: "አማርኛ"
	},
	{
		code: "zu",
		label: "isiZulu"
	},
	{
		code: "xh",
		label: "isiXhosa"
	},
	{
		code: "st",
		label: "Sesotho"
	},
	{
		code: "tn",
		label: "Setswana"
	},
	{
		code: "af",
		label: "Afrikaans"
	},
	{
		code: "ha",
		label: "Hausa"
	},
	{
		code: "yo",
		label: "Yorùbá"
	},
	{
		code: "ig",
		label: "Igbo"
	},
	{
		code: "nso",
		label: "Sepedi"
	},
	{
		code: "sk",
		label: "Slovenčina"
	},
	{
		code: "bg",
		label: "Български"
	}
];
export const RTL_LANGUAGES = [
	"ar",
	"he",
	"fa",
	"ur"
];
export const LANGUAGE_COUNT = LANGUAGES.length;
const resources = { en: { translation: en } };
const allCodes = new Set([
	...LANGUAGES.map((l) => l.code),
	...Object.keys(translations),
	...Object.keys(socialTranslations),
	...Object.keys(extraTranslations),
	...Object.keys(appTranslations),
	...Object.keys(COUNTRY_FLAGSHIP_APP_BUNDLES)
]);
for (const code of allCodes) {
	const primaryBundle = { ...translations[code] ?? {} };
	const extraBundle = extraTranslations[code];
	const social = socialTranslations[code];
	const appBundle = appTranslations[code];
	const flagshipBundle = COUNTRY_FLAGSHIP_APP_BUNDLES[code];
	if (social) primaryBundle.social = {
		...primaryBundle.social,
		...social
	};
	if (extraBundle) {
		for (const [sec, val] of Object.entries(extraBundle)) {
			primaryBundle[sec] = {
				...primaryBundle[sec],
				...val
			};
		}
	}
	if (appBundle) {
		for (const [sec, val] of Object.entries(appBundle)) {
			primaryBundle[sec] = {
				...primaryBundle[sec],
				...val
			};
		}
	}
	if (flagshipBundle) {
		for (const [sec, val] of Object.entries(flagshipBundle)) {
			primaryBundle[sec] = {
				...primaryBundle[sec],
				...val
			};
		}
	}
	const merged = { ...en };
	for (const [section, values] of Object.entries(primaryBundle)) {
		merged[section] = {
			...en[section],
			...values
		};
	}
	// Ensure every non-English locale has complete native Hero, Feed & Nav strings
	// derived from its native vocabulary if not already overridden
	if (code !== "en") {
		const stashWord = merged.vote?.stash || "Stash";
		const trashWord = merged.vote?.trash || "Trash";
		const brandsWord = merged.brand?.title || merged.nav?.brands || "Brands";
		const trustWord = merged.brand?.trustScore || "Trust score";
		const awardsTitle = merged.awards?.title || "SOT Awards";
		const dashboardTitle = merged.dashboard?.title || merged.nav?.dashboard || "Dashboard";
		const feedWord = merged.nav?.feed || "Feed";
		const homeSubtitle = merged.home?.subtitle || en.home.subtitle;
		const homeHook = merged.home?.hook || en.home.hook;
		merged.nav = {
			...merged.nav,
			home: merged.nav?.home && merged.nav.home !== "Home" ? merged.nav.home : feedWord,
			scan: merged.nav?.scan || "Scan"
		};
		const existingHero = primaryBundle.hero ?? {};
		merged.hero = {
			...en.hero,
			...appTranslations.en.hero ?? {},
			badge: existingHero.badge || `${brandsWord} · ${trustWord}`,
			headlineBlack: existingHero.headlineBlack || `${stashWord} · ${brandsWord}`,
			headlineGold: existingHero.headlineGold || `${trashWord} · ${trustWord}`,
			subtitle: existingHero.subtitle || homeSubtitle,
			tagline: existingHero.tagline || homeHook,
			tapCoin: existingHero.tapCoin || `🪙 ${stashWord}`,
			tapBin: existingHero.tapBin || `🗑️ ${trashWord}`,
			trustScore: existingHero.trustScore || trustWord,
			liveSentiment: existingHero.liveSentiment || `${brandsWord} — ${trustWord}`,
			liveSentimentDesc: existingHero.liveSentimentDesc || homeSubtitle,
			searchOrBrowse: existingHero.searchOrBrowse || (merged.brand?.searchPlaceholder ?? "Search..."),
			gettingStashed: existingHero.gettingStashed || `🪙 ${stashWord}`,
			gettingTrashed: existingHero.gettingTrashed || `🗑️ ${trashWord}`,
			sotAwards: existingHero.sotAwards || awardsTitle,
			crowningBrand: existingHero.crowningBrand || (merged.awards?.tagline ?? ""),
			seeStandings: existingHero.seeStandings || (merged.awards?.leaderboard ?? ""),
			goToDashboard: existingHero.goToDashboard || dashboardTitle,
			exploreFeed: existingHero.exploreFeed || feedWord,
			stashes: existingHero.stashes || stashWord,
			trashes: existingHero.trashes || trashWord,
			...existingHero
		};
		const existingFeed = primaryBundle.feed ?? {};
		merged.feed = {
			...appTranslations.es.feed ?? {},
			pulse: existingFeed.pulse || brandsWord,
			title: "Stash Or Trash",
			subtitle: existingFeed.subtitle || homeSubtitle,
			hook: existingFeed.hook || homeHook,
			searchPlaceholder: existingFeed.searchPlaceholder || (merged.brand?.searchPlaceholder ?? "Search..."),
			allVerdicts: existingFeed.allVerdicts || `${stashWord} / ${trashWord}`,
			stashesOfDay: existingFeed.stashesOfDay || `🪙 ${stashWord}`,
			trashesOfDay: existingFeed.trashesOfDay || `🗑️ ${trashWord}`,
			...existingFeed
		};
	}
	resources[code] = { translation: merged };
}
// Regional Chinese variants
resources["zh-CN"] = resources.zh ?? { translation: en };
resources["zh-TW"] = resources["zh-TW"] ?? resources.zh ?? { translation: en };
if (!i18n.isInitialized) {
	i18n.use(LanguageDetector).use(initReactI18next).init({
		resources,
		fallbackLng: "en",
		supportedLngs: LANGUAGES.map((l) => l.code),
		nonExplicitSupportedLngs: true,
		interpolation: { escapeValue: false },
		initImmediate: false,
		detection: {
			order: ["localStorage", "navigator"],
			caches: ["localStorage"],
			lookupLocalStorage: "sot-lang"
		}
	});
}
export default i18n;

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxVQUFVO0FBQ2pCLFNBQVMsd0JBQXdCO0FBQ2pDLE9BQU8sc0JBQXNCO0FBQzdCLFNBQVMsVUFBVTtBQUNuQixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLG9DQUFvQzs7QUFHN0MsT0FBTyxNQUFNLFlBQTJGO0NBQ3RHO0VBQUUsTUFBTTtFQUFNLE9BQU87Q0FBVTtDQUMvQjtFQUFFLE1BQU07RUFBTSxPQUFPO0NBQVU7Q0FDL0I7RUFBRSxNQUFNO0VBQU0sT0FBTztDQUFXO0NBQ2hDO0VBQUUsTUFBTTtFQUFNLE9BQU87Q0FBVTtDQUMvQjtFQUFFLE1BQU07RUFBTSxPQUFPO0NBQVk7Q0FDakM7RUFBRSxNQUFNO0VBQU0sT0FBTztDQUFXO0NBQ2hDO0VBQUUsTUFBTTtFQUFNLE9BQU87Q0FBYTtDQUNsQztFQUFFLE1BQU07RUFBTSxPQUFPO0NBQVM7Q0FDOUI7RUFBRSxNQUFNO0VBQU0sT0FBTztDQUFTO0NBQzlCO0VBQUUsTUFBTTtFQUFNLE9BQU87Q0FBVTtDQUMvQjtFQUFFLE1BQU07RUFBTSxPQUFPO0NBQVE7Q0FDN0I7RUFBRSxNQUFNO0VBQU0sT0FBTztDQUFRO0NBQzdCO0VBQUUsTUFBTTtFQUFNLE9BQU87Q0FBUTtDQUM3QjtFQUFFLE1BQU07RUFBTSxPQUFPO0NBQVU7Q0FDL0I7RUFBRSxNQUFNO0VBQU0sT0FBTztDQUFTO0NBQzlCO0VBQUUsTUFBTTtFQUFNLE9BQU87Q0FBVztDQUNoQztFQUFFLE1BQU07RUFBTSxPQUFPO0NBQWE7Q0FDbEM7RUFBRSxNQUFNO0VBQU0sT0FBTztDQUFVO0NBQy9CO0VBQUUsTUFBTTtFQUFNLE9BQU87Q0FBUztDQUM5QjtFQUFFLE1BQU07RUFBTSxPQUFPO0VBQVcsV0FBVztDQUFNO0NBQ2pEO0VBQUUsTUFBTTtFQUFNLE9BQU87RUFBUyxXQUFXO0NBQU07Q0FDL0M7RUFBRSxNQUFNO0VBQU0sT0FBTztFQUFTLFdBQVc7Q0FBTTtDQUMvQztFQUFFLE1BQU07RUFBTSxPQUFPO0VBQVEsV0FBVztDQUFNO0NBQzlDO0VBQUUsTUFBTTtFQUFNLE9BQU87Q0FBUztDQUM5QjtFQUFFLE1BQU07RUFBTSxPQUFPO0NBQVE7Q0FDN0I7RUFBRSxNQUFNO0VBQU0sT0FBTztDQUFRO0NBQzdCO0VBQUUsTUFBTTtFQUFNLE9BQU87Q0FBUztDQUM5QjtFQUFFLE1BQU07RUFBTSxPQUFPO0NBQVE7Q0FDN0I7RUFBRSxNQUFNO0VBQU0sT0FBTztDQUFVO0NBQy9CO0VBQUUsTUFBTTtFQUFNLE9BQU87Q0FBUztDQUM5QjtFQUFFLE1BQU07RUFBTSxPQUFPO0NBQU07Q0FDM0I7RUFBRSxNQUFNO0VBQU0sT0FBTztDQUFhO0NBQ2xDO0VBQUUsTUFBTTtFQUFNLE9BQU87Q0FBbUI7Q0FDeEM7RUFBRSxNQUFNO0VBQU0sT0FBTztDQUFnQjtDQUNyQztFQUFFLE1BQU07RUFBTyxPQUFPO0NBQVc7Q0FDakM7RUFBRSxNQUFNO0VBQVMsT0FBTztDQUFhO0NBQ3JDO0VBQUUsTUFBTTtFQUFTLE9BQU87Q0FBVztDQUNuQztFQUFFLE1BQU07RUFBTSxPQUFPO0NBQU07Q0FDM0I7RUFBRSxNQUFNO0VBQU0sT0FBTztDQUFNO0NBQzNCO0VBQUUsTUFBTTtFQUFNLE9BQU87Q0FBWTtDQUNqQztFQUFFLE1BQU07RUFBTSxPQUFPO0NBQU87Q0FDNUI7RUFBRSxNQUFNO0VBQU0sT0FBTztDQUFVO0NBQy9CO0VBQUUsTUFBTTtFQUFNLE9BQU87Q0FBVztDQUNoQztFQUFFLE1BQU07RUFBTSxPQUFPO0NBQVU7Q0FDL0I7RUFBRSxNQUFNO0VBQU0sT0FBTztDQUFXO0NBQ2hDO0VBQUUsTUFBTTtFQUFNLE9BQU87Q0FBWTtDQUNqQztFQUFFLE1BQU07RUFBTSxPQUFPO0NBQVE7Q0FDN0I7RUFBRSxNQUFNO0VBQU0sT0FBTztDQUFTO0NBQzlCO0VBQUUsTUFBTTtFQUFNLE9BQU87Q0FBTztDQUM1QjtFQUFFLE1BQU07RUFBTyxPQUFPO0NBQVM7Q0FDL0I7RUFBRSxNQUFNO0VBQU0sT0FBTztDQUFhO0NBQ2xDO0VBQUUsTUFBTTtFQUFNLE9BQU87Q0FBWTtBQUNuQztBQUVBLE9BQU8sTUFBTSxnQkFBZ0I7Q0FBQztDQUFNO0NBQU07Q0FBTTtBQUFJO0FBRXBELE9BQU8sTUFBTSxpQkFBaUIsVUFBVTtBQUV4QyxNQUFNLFlBQXdELEVBQUUsSUFBSSxFQUFFLGFBQWEsR0FBRyxFQUFFO0FBQ3hGLE1BQU0sV0FBVyxJQUFJLElBQUk7Q0FDdkIsR0FBRyxVQUFVLEtBQUssTUFBTSxFQUFFLElBQUk7Q0FDOUIsR0FBRyxPQUFPLEtBQUssWUFBWTtDQUMzQixHQUFHLE9BQU8sS0FBSyxrQkFBa0I7Q0FDakMsR0FBRyxPQUFPLEtBQUssaUJBQWlCO0NBQ2hDLEdBQUcsT0FBTyxLQUFLLGVBQWU7Q0FDOUIsR0FBRyxPQUFPLEtBQUssNEJBQTRCO0FBQzdDLENBQUM7QUFFRCxLQUFLLE1BQU0sUUFBUSxVQUFVO0NBQzNCLE1BQU0sZ0JBQXFDLEVBQUUsR0FBSSxhQUFhLFNBQVMsQ0FBQyxFQUFHO0NBQzNFLE1BQU0sY0FBYyxrQkFBa0I7Q0FDdEMsTUFBTSxTQUFTLG1CQUFtQjtDQUNsQyxNQUFNLFlBQVksZ0JBQWdCO0NBQ2xDLE1BQU0saUJBQWlCLDZCQUE2QjtDQUVwRCxJQUFJLFFBQVEsY0FBYyxTQUFTO0VBQUUsR0FBSSxjQUFjO0VBQW1CLEdBQUc7Q0FBTztDQUNwRixJQUFJLGFBQWE7RUFDZixLQUFLLE1BQU0sQ0FBQyxLQUFLLFFBQVEsT0FBTyxRQUFRLFdBQVcsR0FBRztHQUNwRCxjQUFjLE9BQU87SUFBRSxHQUFJLGNBQWM7SUFBaUIsR0FBSTtHQUFlO0VBQy9FO0NBQ0Y7Q0FDQSxJQUFJLFdBQVc7RUFDYixLQUFLLE1BQU0sQ0FBQyxLQUFLLFFBQVEsT0FBTyxRQUFRLFNBQVMsR0FBRztHQUNsRCxjQUFjLE9BQU87SUFBRSxHQUFJLGNBQWM7SUFBaUIsR0FBSTtHQUFlO0VBQy9FO0NBQ0Y7Q0FDQSxJQUFJLGdCQUFnQjtFQUNsQixLQUFLLE1BQU0sQ0FBQyxLQUFLLFFBQVEsT0FBTyxRQUFRLGNBQWMsR0FBRztHQUN2RCxjQUFjLE9BQU87SUFBRSxHQUFJLGNBQWM7SUFBaUIsR0FBSTtHQUFlO0VBQy9FO0NBQ0Y7Q0FFQSxNQUFNLFNBQThCLEVBQUUsR0FBRyxHQUFHO0NBQzVDLEtBQUssTUFBTSxDQUFDLFNBQVMsV0FBVyxPQUFPLFFBQVEsYUFBYSxHQUFHO0VBQzdELE9BQU8sV0FBVztHQUFFLEdBQUksR0FBMkI7R0FBVSxHQUFJO0VBQWtCO0NBQ3JGOzs7Q0FJQSxJQUFJLFNBQVMsTUFBTTtFQUNqQixNQUFNLFlBQVksT0FBTyxNQUFNLFNBQVM7RUFDeEMsTUFBTSxZQUFZLE9BQU8sTUFBTSxTQUFTO0VBQ3hDLE1BQU0sYUFBYSxPQUFPLE9BQU8sU0FBUyxPQUFPLEtBQUssVUFBVTtFQUNoRSxNQUFNLFlBQVksT0FBTyxPQUFPLGNBQWM7RUFDOUMsTUFBTSxjQUFjLE9BQU8sUUFBUSxTQUFTO0VBQzVDLE1BQU0saUJBQWlCLE9BQU8sV0FBVyxTQUFTLE9BQU8sS0FBSyxhQUFhO0VBQzNFLE1BQU0sV0FBVyxPQUFPLEtBQUssUUFBUTtFQUNyQyxNQUFNLGVBQWUsT0FBTyxNQUFNLFlBQVksR0FBRyxLQUFLO0VBQ3RELE1BQU0sV0FBVyxPQUFPLE1BQU0sUUFBUSxHQUFHLEtBQUs7RUFFOUMsT0FBTyxNQUFNO0dBQ1gsR0FBRyxPQUFPO0dBQ1YsTUFBTSxPQUFPLEtBQUssUUFBUSxPQUFPLElBQUksU0FBUyxTQUFTLE9BQU8sSUFBSSxPQUFPO0dBQ3pFLE1BQU0sT0FBTyxLQUFLLFFBQVE7RUFDNUI7RUFFQSxNQUFNLGVBQWdCLGNBQWMsUUFBUSxDQUFDO0VBQzdDLE9BQU8sT0FBTztHQUNaLEdBQUksR0FBVztHQUNmLEdBQUksZ0JBQWdCLEdBQUcsUUFBUSxDQUFDO0dBQ2hDLE9BQU8sYUFBYSxTQUFTLEdBQUcsV0FBVyxLQUFLO0dBQ2hELGVBQWUsYUFBYSxpQkFBaUIsR0FBRyxVQUFVLEtBQUs7R0FDL0QsY0FBYyxhQUFhLGdCQUFnQixHQUFHLFVBQVUsS0FBSztHQUM3RCxVQUFVLGFBQWEsWUFBWTtHQUNuQyxTQUFTLGFBQWEsV0FBVztHQUNqQyxTQUFTLGFBQWEsV0FBVyxNQUFNO0dBQ3ZDLFFBQVEsYUFBYSxVQUFVLE9BQU87R0FDdEMsWUFBWSxhQUFhLGNBQWM7R0FDdkMsZUFBZSxhQUFhLGlCQUFpQixHQUFHLFdBQVcsS0FBSztHQUNoRSxtQkFBbUIsYUFBYSxxQkFBcUI7R0FDckQsZ0JBQWdCLGFBQWEsbUJBQW1CLE9BQU8sT0FBTyxxQkFBcUI7R0FDbkYsZ0JBQWdCLGFBQWEsa0JBQWtCLE1BQU07R0FDckQsZ0JBQWdCLGFBQWEsa0JBQWtCLE9BQU87R0FDdEQsV0FBVyxhQUFhLGFBQWE7R0FDckMsZUFBZSxhQUFhLGtCQUFrQixPQUFPLFFBQVEsV0FBVztHQUN4RSxjQUFjLGFBQWEsaUJBQWlCLE9BQU8sUUFBUSxlQUFlO0dBQzFFLGVBQWUsYUFBYSxpQkFBaUI7R0FDN0MsYUFBYSxhQUFhLGVBQWU7R0FDekMsU0FBUyxhQUFhLFdBQVc7R0FDakMsU0FBUyxhQUFhLFdBQVc7R0FDakMsR0FBRztFQUNMO0VBRUEsTUFBTSxlQUFnQixjQUFjLFFBQVEsQ0FBQztFQUM3QyxPQUFPLE9BQU87R0FDWixHQUFJLGdCQUFnQixHQUFHLFFBQVEsQ0FBQztHQUNoQyxPQUFPLGFBQWEsU0FBUztHQUM3QixPQUFPO0dBQ1AsVUFBVSxhQUFhLFlBQVk7R0FDbkMsTUFBTSxhQUFhLFFBQVE7R0FDM0IsbUJBQW1CLGFBQWEsc0JBQXNCLE9BQU8sT0FBTyxxQkFBcUI7R0FDekYsYUFBYSxhQUFhLGVBQWUsR0FBRyxVQUFVLEtBQUs7R0FDM0QsY0FBYyxhQUFhLGdCQUFnQixNQUFNO0dBQ2pELGNBQWMsYUFBYSxnQkFBZ0IsT0FBTztHQUNsRCxHQUFHO0VBQ0w7Q0FDRjtDQUVBLFVBQVUsUUFBUSxFQUFFLGFBQWEsT0FBb0I7QUFDdkQ7O0FBR0EsVUFBVSxXQUFXLFVBQVUsTUFBTSxFQUFFLGFBQWEsR0FBRztBQUN2RCxVQUFVLFdBQVcsVUFBVSxZQUFZLFVBQVUsTUFBTSxFQUFFLGFBQWEsR0FBRztBQUU3RSxJQUFJLENBQUMsS0FBSyxlQUFlO0NBQ3ZCLEtBQ0csSUFBSSxnQkFBZ0IsQ0FBQyxDQUNyQixJQUFJLGdCQUFnQixDQUFDLENBQ3JCLEtBQUs7RUFDSjtFQUNBLGFBQWE7RUFDYixlQUFlLFVBQVUsS0FBSyxNQUFNLEVBQUUsSUFBSTtFQUMxQywwQkFBMEI7RUFDMUIsZUFBZSxFQUFFLGFBQWEsTUFBTTtFQUNwQyxlQUFlO0VBQ2YsV0FBVztHQUNULE9BQU8sQ0FBQyxnQkFBZ0IsV0FBVztHQUNuQyxRQUFRLENBQUMsY0FBYztHQUN2QixvQkFBb0I7RUFDdEI7Q0FDRixDQUFRO0FBQ1o7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImkxOG4udHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGkxOG4gZnJvbSBcImkxOG5leHRcIjtcbmltcG9ydCB7IGluaXRSZWFjdEkxOG5leHQgfSBmcm9tIFwicmVhY3QtaTE4bmV4dFwiO1xuaW1wb3J0IExhbmd1YWdlRGV0ZWN0b3IgZnJvbSBcImkxOG5leHQtYnJvd3Nlci1sYW5ndWFnZWRldGVjdG9yXCI7XG5pbXBvcnQgeyBlbiB9IGZyb20gXCIuL2xvY2FsZS1lblwiO1xuaW1wb3J0IHsgdHJhbnNsYXRpb25zIH0gZnJvbSBcIi4vbG9jYWxlc1wiO1xuaW1wb3J0IHsgc29jaWFsVHJhbnNsYXRpb25zIH0gZnJvbSBcIi4vbG9jYWxlLXNvY2lhbFwiO1xuaW1wb3J0IHsgZXh0cmFUcmFuc2xhdGlvbnMgfSBmcm9tIFwiLi9sb2NhbGVzLWV4dHJhXCI7XG5pbXBvcnQgeyBhcHBUcmFuc2xhdGlvbnMgfSBmcm9tIFwiLi9sb2NhbGUtYXBwXCI7XG5pbXBvcnQgeyBDT1VOVFJZX0ZMQUdTSElQX0FQUF9CVU5ETEVTIH0gZnJvbSBcIi4vY291bnRyeS1sYW5ndWFnZXNcIjtcblxuLy8gRnVsbCBsaXN0IG9mIDUyIHNlbGVjdGFibGUgbGF1bmNoIGxhbmd1YWdlcyAobmF0aXZlIG5hbWVzICYgUlRMIG1ldGFkYXRhKVxuZXhwb3J0IGNvbnN0IExBTkdVQUdFUzogeyBjb2RlOiBzdHJpbmc7IGxhYmVsOiBzdHJpbmc7IG5hdGl2ZT86IHN0cmluZzsgZGlyZWN0aW9uPzogXCJsdHJcIiB8IFwicnRsXCIgfVtdID0gW1xuICB7IGNvZGU6IFwiZW5cIiwgbGFiZWw6IFwiRW5nbGlzaFwiIH0sXG4gIHsgY29kZTogXCJlc1wiLCBsYWJlbDogXCJFc3Bhw7FvbFwiIH0sXG4gIHsgY29kZTogXCJmclwiLCBsYWJlbDogXCJGcmFuw6dhaXNcIiB9LFxuICB7IGNvZGU6IFwiZGVcIiwgbGFiZWw6IFwiRGV1dHNjaFwiIH0sXG4gIHsgY29kZTogXCJwdFwiLCBsYWJlbDogXCJQb3J0dWd1w6pzXCIgfSxcbiAgeyBjb2RlOiBcIml0XCIsIGxhYmVsOiBcIkl0YWxpYW5vXCIgfSxcbiAgeyBjb2RlOiBcIm5sXCIsIGxhYmVsOiBcIk5lZGVybGFuZHNcIiB9LFxuICB7IGNvZGU6IFwicGxcIiwgbGFiZWw6IFwiUG9sc2tpXCIgfSxcbiAgeyBjb2RlOiBcInJvXCIsIGxhYmVsOiBcIlJvbcOibsSDXCIgfSxcbiAgeyBjb2RlOiBcInN2XCIsIGxhYmVsOiBcIlN2ZW5za2FcIiB9LFxuICB7IGNvZGU6IFwibm9cIiwgbGFiZWw6IFwiTm9yc2tcIiB9LFxuICB7IGNvZGU6IFwiZGFcIiwgbGFiZWw6IFwiRGFuc2tcIiB9LFxuICB7IGNvZGU6IFwiZmlcIiwgbGFiZWw6IFwiU3VvbWlcIiB9LFxuICB7IGNvZGU6IFwiY3NcIiwgbGFiZWw6IFwixIxlxaF0aW5hXCIgfSxcbiAgeyBjb2RlOiBcImh1XCIsIGxhYmVsOiBcIk1hZ3lhclwiIH0sXG4gIHsgY29kZTogXCJlbFwiLCBsYWJlbDogXCLOlc67zrvOt869zrnOus6sXCIgfSxcbiAgeyBjb2RlOiBcInVrXCIsIGxhYmVsOiBcItCj0LrRgNCw0ZfQvdGB0YzQutCwXCIgfSxcbiAgeyBjb2RlOiBcInJ1XCIsIGxhYmVsOiBcItCg0YPRgdGB0LrQuNC5XCIgfSxcbiAgeyBjb2RlOiBcInRyXCIsIGxhYmVsOiBcIlTDvHJrw6dlXCIgfSxcbiAgeyBjb2RlOiBcImFyXCIsIGxhYmVsOiBcItin2YTYudix2KjZitipXCIsIGRpcmVjdGlvbjogXCJydGxcIiB9LFxuICB7IGNvZGU6IFwiaGVcIiwgbGFiZWw6IFwi16LXkdeo15nXqlwiLCBkaXJlY3Rpb246IFwicnRsXCIgfSxcbiAgeyBjb2RlOiBcImZhXCIsIGxhYmVsOiBcItmB2KfYsdiz24xcIiwgZGlyZWN0aW9uOiBcInJ0bFwiIH0sXG4gIHsgY29kZTogXCJ1clwiLCBsYWJlbDogXCLYp9ix2K/ZiFwiLCBkaXJlY3Rpb246IFwicnRsXCIgfSxcbiAgeyBjb2RlOiBcImhpXCIsIGxhYmVsOiBcIuCkueCkv+CkqOCljeCkpuClgFwiIH0sXG4gIHsgY29kZTogXCJiblwiLCBsYWJlbDogXCLgpqzgpr7gpoLgprLgpr5cIiB9LFxuICB7IGNvZGU6IFwidGFcIiwgbGFiZWw6IFwi4K6k4K6u4K6/4K604K+NXCIgfSxcbiAgeyBjb2RlOiBcInRlXCIsIGxhYmVsOiBcIuCwpOCxhuCwsuCxgeCwl+CxgVwiIH0sXG4gIHsgY29kZTogXCJtclwiLCBsYWJlbDogXCLgpK7gpLDgpL7gpKDgpYBcIiB9LFxuICB7IGNvZGU6IFwiZ3VcIiwgbGFiZWw6IFwi4KqX4KuB4Kqc4Kqw4Kq+4Kqk4KuAXCIgfSxcbiAgeyBjb2RlOiBcInBhXCIsIGxhYmVsOiBcIuCoquCpsOConOCovuCorOCpgFwiIH0sXG4gIHsgY29kZTogXCJ0aFwiLCBsYWJlbDogXCLguYTguJfguKJcIiB9LFxuICB7IGNvZGU6IFwidmlcIiwgbGFiZWw6IFwiVGnhur9uZyBWaeG7h3RcIiB9LFxuICB7IGNvZGU6IFwiaWRcIiwgbGFiZWw6IFwiQmFoYXNhIEluZG9uZXNpYVwiIH0sXG4gIHsgY29kZTogXCJtc1wiLCBsYWJlbDogXCJCYWhhc2EgTWVsYXl1XCIgfSxcbiAgeyBjb2RlOiBcImZpbFwiLCBsYWJlbDogXCJGaWxpcGlub1wiIH0sXG4gIHsgY29kZTogXCJ6aC1DTlwiLCBsYWJlbDogXCLnroDkvZPkuK3mlofvvIjkuK3lm73lpKfpmYbvvIlcIiB9LFxuICB7IGNvZGU6IFwiemgtVFdcIiwgbGFiZWw6IFwi57mB6auU5Lit5paH77yI5Y+w54Gj77yJXCIgfSxcbiAgeyBjb2RlOiBcImphXCIsIGxhYmVsOiBcIuaXpeacrOiqnlwiIH0sXG4gIHsgY29kZTogXCJrb1wiLCBsYWJlbDogXCLtlZzqta3slrRcIiB9LFxuICB7IGNvZGU6IFwic3dcIiwgbGFiZWw6IFwiS2lzd2FoaWxpXCIgfSxcbiAgeyBjb2RlOiBcImFtXCIsIGxhYmVsOiBcIuGKoOGIm+GIreGKm1wiIH0sXG4gIHsgY29kZTogXCJ6dVwiLCBsYWJlbDogXCJpc2ladWx1XCIgfSxcbiAgeyBjb2RlOiBcInhoXCIsIGxhYmVsOiBcImlzaVhob3NhXCIgfSxcbiAgeyBjb2RlOiBcInN0XCIsIGxhYmVsOiBcIlNlc290aG9cIiB9LFxuICB7IGNvZGU6IFwidG5cIiwgbGFiZWw6IFwiU2V0c3dhbmFcIiB9LFxuICB7IGNvZGU6IFwiYWZcIiwgbGFiZWw6IFwiQWZyaWthYW5zXCIgfSxcbiAgeyBjb2RlOiBcImhhXCIsIGxhYmVsOiBcIkhhdXNhXCIgfSxcbiAgeyBjb2RlOiBcInlvXCIsIGxhYmVsOiBcIllvcsO5YsOhXCIgfSxcbiAgeyBjb2RlOiBcImlnXCIsIGxhYmVsOiBcIklnYm9cIiB9LFxuICB7IGNvZGU6IFwibnNvXCIsIGxhYmVsOiBcIlNlcGVkaVwiIH0sXG4gIHsgY29kZTogXCJza1wiLCBsYWJlbDogXCJTbG92ZW7EjWluYVwiIH0sXG4gIHsgY29kZTogXCJiZ1wiLCBsYWJlbDogXCLQkdGK0LvQs9Cw0YDRgdC60LhcIiB9LFxuXTtcblxuZXhwb3J0IGNvbnN0IFJUTF9MQU5HVUFHRVMgPSBbXCJhclwiLCBcImhlXCIsIFwiZmFcIiwgXCJ1clwiXTtcblxuZXhwb3J0IGNvbnN0IExBTkdVQUdFX0NPVU5UID0gTEFOR1VBR0VTLmxlbmd0aDtcblxuY29uc3QgcmVzb3VyY2VzOiBSZWNvcmQ8c3RyaW5nLCB7IHRyYW5zbGF0aW9uOiB0eXBlb2YgZW4gfT4gPSB7IGVuOiB7IHRyYW5zbGF0aW9uOiBlbiB9IH07XG5jb25zdCBhbGxDb2RlcyA9IG5ldyBTZXQoW1xuICAuLi5MQU5HVUFHRVMubWFwKChsKSA9PiBsLmNvZGUpLFxuICAuLi5PYmplY3Qua2V5cyh0cmFuc2xhdGlvbnMpLFxuICAuLi5PYmplY3Qua2V5cyhzb2NpYWxUcmFuc2xhdGlvbnMpLFxuICAuLi5PYmplY3Qua2V5cyhleHRyYVRyYW5zbGF0aW9ucyksXG4gIC4uLk9iamVjdC5rZXlzKGFwcFRyYW5zbGF0aW9ucyksXG4gIC4uLk9iamVjdC5rZXlzKENPVU5UUllfRkxBR1NISVBfQVBQX0JVTkRMRVMpLFxuXSk7XG5cbmZvciAoY29uc3QgY29kZSBvZiBhbGxDb2Rlcykge1xuICBjb25zdCBwcmltYXJ5QnVuZGxlOiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0geyAuLi4odHJhbnNsYXRpb25zW2NvZGVdID8/IHt9KSB9O1xuICBjb25zdCBleHRyYUJ1bmRsZSA9IGV4dHJhVHJhbnNsYXRpb25zW2NvZGVdO1xuICBjb25zdCBzb2NpYWwgPSBzb2NpYWxUcmFuc2xhdGlvbnNbY29kZV07XG4gIGNvbnN0IGFwcEJ1bmRsZSA9IGFwcFRyYW5zbGF0aW9uc1tjb2RlXTtcbiAgY29uc3QgZmxhZ3NoaXBCdW5kbGUgPSBDT1VOVFJZX0ZMQUdTSElQX0FQUF9CVU5ETEVTW2NvZGVdO1xuXG4gIGlmIChzb2NpYWwpIHByaW1hcnlCdW5kbGUuc29jaWFsID0geyAuLi4ocHJpbWFyeUJ1bmRsZS5zb2NpYWwgYXMgb2JqZWN0KSwgLi4uc29jaWFsIH07XG4gIGlmIChleHRyYUJ1bmRsZSkge1xuICAgIGZvciAoY29uc3QgW3NlYywgdmFsXSBvZiBPYmplY3QuZW50cmllcyhleHRyYUJ1bmRsZSkpIHtcbiAgICAgIHByaW1hcnlCdW5kbGVbc2VjXSA9IHsgLi4uKHByaW1hcnlCdW5kbGVbc2VjXSBhcyBvYmplY3QpLCAuLi4odmFsIGFzIG9iamVjdCkgfTtcbiAgICB9XG4gIH1cbiAgaWYgKGFwcEJ1bmRsZSkge1xuICAgIGZvciAoY29uc3QgW3NlYywgdmFsXSBvZiBPYmplY3QuZW50cmllcyhhcHBCdW5kbGUpKSB7XG4gICAgICBwcmltYXJ5QnVuZGxlW3NlY10gPSB7IC4uLihwcmltYXJ5QnVuZGxlW3NlY10gYXMgb2JqZWN0KSwgLi4uKHZhbCBhcyBvYmplY3QpIH07XG4gICAgfVxuICB9XG4gIGlmIChmbGFnc2hpcEJ1bmRsZSkge1xuICAgIGZvciAoY29uc3QgW3NlYywgdmFsXSBvZiBPYmplY3QuZW50cmllcyhmbGFnc2hpcEJ1bmRsZSkpIHtcbiAgICAgIHByaW1hcnlCdW5kbGVbc2VjXSA9IHsgLi4uKHByaW1hcnlCdW5kbGVbc2VjXSBhcyBvYmplY3QpLCAuLi4odmFsIGFzIG9iamVjdCkgfTtcbiAgICB9XG4gIH1cblxuICBjb25zdCBtZXJnZWQ6IFJlY29yZDxzdHJpbmcsIGFueT4gPSB7IC4uLmVuIH07XG4gIGZvciAoY29uc3QgW3NlY3Rpb24sIHZhbHVlc10gb2YgT2JqZWN0LmVudHJpZXMocHJpbWFyeUJ1bmRsZSkpIHtcbiAgICBtZXJnZWRbc2VjdGlvbl0gPSB7IC4uLihlbiBhcyBSZWNvcmQ8c3RyaW5nLCBhbnk+KVtzZWN0aW9uXSwgLi4uKHZhbHVlcyBhcyBvYmplY3QpIH07XG4gIH1cblxuICAvLyBFbnN1cmUgZXZlcnkgbm9uLUVuZ2xpc2ggbG9jYWxlIGhhcyBjb21wbGV0ZSBuYXRpdmUgSGVybywgRmVlZCAmIE5hdiBzdHJpbmdzXG4gIC8vIGRlcml2ZWQgZnJvbSBpdHMgbmF0aXZlIHZvY2FidWxhcnkgaWYgbm90IGFscmVhZHkgb3ZlcnJpZGRlblxuICBpZiAoY29kZSAhPT0gXCJlblwiKSB7XG4gICAgY29uc3Qgc3Rhc2hXb3JkID0gbWVyZ2VkLnZvdGU/LnN0YXNoIHx8IFwiU3Rhc2hcIjtcbiAgICBjb25zdCB0cmFzaFdvcmQgPSBtZXJnZWQudm90ZT8udHJhc2ggfHwgXCJUcmFzaFwiO1xuICAgIGNvbnN0IGJyYW5kc1dvcmQgPSBtZXJnZWQuYnJhbmQ/LnRpdGxlIHx8IG1lcmdlZC5uYXY/LmJyYW5kcyB8fCBcIkJyYW5kc1wiO1xuICAgIGNvbnN0IHRydXN0V29yZCA9IG1lcmdlZC5icmFuZD8udHJ1c3RTY29yZSB8fCBcIlRydXN0IHNjb3JlXCI7XG4gICAgY29uc3QgYXdhcmRzVGl0bGUgPSBtZXJnZWQuYXdhcmRzPy50aXRsZSB8fCBcIlNPVCBBd2FyZHNcIjtcbiAgICBjb25zdCBkYXNoYm9hcmRUaXRsZSA9IG1lcmdlZC5kYXNoYm9hcmQ/LnRpdGxlIHx8IG1lcmdlZC5uYXY/LmRhc2hib2FyZCB8fCBcIkRhc2hib2FyZFwiO1xuICAgIGNvbnN0IGZlZWRXb3JkID0gbWVyZ2VkLm5hdj8uZmVlZCB8fCBcIkZlZWRcIjtcbiAgICBjb25zdCBob21lU3VidGl0bGUgPSBtZXJnZWQuaG9tZT8uc3VidGl0bGUgfHwgZW4uaG9tZS5zdWJ0aXRsZTtcbiAgICBjb25zdCBob21lSG9vayA9IG1lcmdlZC5ob21lPy5ob29rIHx8IGVuLmhvbWUuaG9vaztcblxuICAgIG1lcmdlZC5uYXYgPSB7XG4gICAgICAuLi5tZXJnZWQubmF2LFxuICAgICAgaG9tZTogbWVyZ2VkLm5hdj8uaG9tZSAmJiBtZXJnZWQubmF2LmhvbWUgIT09IFwiSG9tZVwiID8gbWVyZ2VkLm5hdi5ob21lIDogZmVlZFdvcmQsXG4gICAgICBzY2FuOiBtZXJnZWQubmF2Py5zY2FuIHx8IFwiU2NhblwiLFxuICAgIH07XG5cbiAgICBjb25zdCBleGlzdGluZ0hlcm8gPSAocHJpbWFyeUJ1bmRsZS5oZXJvID8/IHt9KSBhcyBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xuICAgIG1lcmdlZC5oZXJvID0ge1xuICAgICAgLi4uKGVuIGFzIGFueSkuaGVybyxcbiAgICAgIC4uLihhcHBUcmFuc2xhdGlvbnMuZW4uaGVybyA/PyB7fSksXG4gICAgICBiYWRnZTogZXhpc3RpbmdIZXJvLmJhZGdlIHx8IGAke2JyYW5kc1dvcmR9IMK3ICR7dHJ1c3RXb3JkfWAsXG4gICAgICBoZWFkbGluZUJsYWNrOiBleGlzdGluZ0hlcm8uaGVhZGxpbmVCbGFjayB8fCBgJHtzdGFzaFdvcmR9IMK3ICR7YnJhbmRzV29yZH1gLFxuICAgICAgaGVhZGxpbmVHb2xkOiBleGlzdGluZ0hlcm8uaGVhZGxpbmVHb2xkIHx8IGAke3RyYXNoV29yZH0gwrcgJHt0cnVzdFdvcmR9YCxcbiAgICAgIHN1YnRpdGxlOiBleGlzdGluZ0hlcm8uc3VidGl0bGUgfHwgaG9tZVN1YnRpdGxlLFxuICAgICAgdGFnbGluZTogZXhpc3RpbmdIZXJvLnRhZ2xpbmUgfHwgaG9tZUhvb2ssXG4gICAgICB0YXBDb2luOiBleGlzdGluZ0hlcm8udGFwQ29pbiB8fCBg8J+qmSAke3N0YXNoV29yZH1gLFxuICAgICAgdGFwQmluOiBleGlzdGluZ0hlcm8udGFwQmluIHx8IGDwn5eR77iPICR7dHJhc2hXb3JkfWAsXG4gICAgICB0cnVzdFNjb3JlOiBleGlzdGluZ0hlcm8udHJ1c3RTY29yZSB8fCB0cnVzdFdvcmQsXG4gICAgICBsaXZlU2VudGltZW50OiBleGlzdGluZ0hlcm8ubGl2ZVNlbnRpbWVudCB8fCBgJHticmFuZHNXb3JkfSDigJQgJHt0cnVzdFdvcmR9YCxcbiAgICAgIGxpdmVTZW50aW1lbnREZXNjOiBleGlzdGluZ0hlcm8ubGl2ZVNlbnRpbWVudERlc2MgfHwgaG9tZVN1YnRpdGxlLFxuICAgICAgc2VhcmNoT3JCcm93c2U6IGV4aXN0aW5nSGVyby5zZWFyY2hPckJyb3dzZSB8fCAobWVyZ2VkLmJyYW5kPy5zZWFyY2hQbGFjZWhvbGRlciA/PyBcIlNlYXJjaC4uLlwiKSxcbiAgICAgIGdldHRpbmdTdGFzaGVkOiBleGlzdGluZ0hlcm8uZ2V0dGluZ1N0YXNoZWQgfHwgYPCfqpkgJHtzdGFzaFdvcmR9YCxcbiAgICAgIGdldHRpbmdUcmFzaGVkOiBleGlzdGluZ0hlcm8uZ2V0dGluZ1RyYXNoZWQgfHwgYPCfl5HvuI8gJHt0cmFzaFdvcmR9YCxcbiAgICAgIHNvdEF3YXJkczogZXhpc3RpbmdIZXJvLnNvdEF3YXJkcyB8fCBhd2FyZHNUaXRsZSxcbiAgICAgIGNyb3duaW5nQnJhbmQ6IGV4aXN0aW5nSGVyby5jcm93bmluZ0JyYW5kIHx8IChtZXJnZWQuYXdhcmRzPy50YWdsaW5lID8/IFwiXCIpLFxuICAgICAgc2VlU3RhbmRpbmdzOiBleGlzdGluZ0hlcm8uc2VlU3RhbmRpbmdzIHx8IChtZXJnZWQuYXdhcmRzPy5sZWFkZXJib2FyZCA/PyBcIlwiKSxcbiAgICAgIGdvVG9EYXNoYm9hcmQ6IGV4aXN0aW5nSGVyby5nb1RvRGFzaGJvYXJkIHx8IGRhc2hib2FyZFRpdGxlLFxuICAgICAgZXhwbG9yZUZlZWQ6IGV4aXN0aW5nSGVyby5leHBsb3JlRmVlZCB8fCBmZWVkV29yZCxcbiAgICAgIHN0YXNoZXM6IGV4aXN0aW5nSGVyby5zdGFzaGVzIHx8IHN0YXNoV29yZCxcbiAgICAgIHRyYXNoZXM6IGV4aXN0aW5nSGVyby50cmFzaGVzIHx8IHRyYXNoV29yZCxcbiAgICAgIC4uLmV4aXN0aW5nSGVybyxcbiAgICB9O1xuXG4gICAgY29uc3QgZXhpc3RpbmdGZWVkID0gKHByaW1hcnlCdW5kbGUuZmVlZCA/PyB7fSkgYXMgUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcbiAgICBtZXJnZWQuZmVlZCA9IHtcbiAgICAgIC4uLihhcHBUcmFuc2xhdGlvbnMuZXMuZmVlZCA/PyB7fSksXG4gICAgICBwdWxzZTogZXhpc3RpbmdGZWVkLnB1bHNlIHx8IGJyYW5kc1dvcmQsXG4gICAgICB0aXRsZTogXCJTdGFzaCBPciBUcmFzaFwiLFxuICAgICAgc3VidGl0bGU6IGV4aXN0aW5nRmVlZC5zdWJ0aXRsZSB8fCBob21lU3VidGl0bGUsXG4gICAgICBob29rOiBleGlzdGluZ0ZlZWQuaG9vayB8fCBob21lSG9vayxcbiAgICAgIHNlYXJjaFBsYWNlaG9sZGVyOiBleGlzdGluZ0ZlZWQuc2VhcmNoUGxhY2Vob2xkZXIgfHwgKG1lcmdlZC5icmFuZD8uc2VhcmNoUGxhY2Vob2xkZXIgPz8gXCJTZWFyY2guLi5cIiksXG4gICAgICBhbGxWZXJkaWN0czogZXhpc3RpbmdGZWVkLmFsbFZlcmRpY3RzIHx8IGAke3N0YXNoV29yZH0gLyAke3RyYXNoV29yZH1gLFxuICAgICAgc3Rhc2hlc09mRGF5OiBleGlzdGluZ0ZlZWQuc3Rhc2hlc09mRGF5IHx8IGDwn6qZICR7c3Rhc2hXb3JkfWAsXG4gICAgICB0cmFzaGVzT2ZEYXk6IGV4aXN0aW5nRmVlZC50cmFzaGVzT2ZEYXkgfHwgYPCfl5HvuI8gJHt0cmFzaFdvcmR9YCxcbiAgICAgIC4uLmV4aXN0aW5nRmVlZCxcbiAgICB9O1xuICB9XG5cbiAgcmVzb3VyY2VzW2NvZGVdID0geyB0cmFuc2xhdGlvbjogbWVyZ2VkIGFzIHR5cGVvZiBlbiB9O1xufVxuXG4vLyBSZWdpb25hbCBDaGluZXNlIHZhcmlhbnRzXG5yZXNvdXJjZXNbXCJ6aC1DTlwiXSA9IHJlc291cmNlcy56aCA/PyB7IHRyYW5zbGF0aW9uOiBlbiB9O1xucmVzb3VyY2VzW1wiemgtVFdcIl0gPSByZXNvdXJjZXNbXCJ6aC1UV1wiXSA/PyByZXNvdXJjZXMuemggPz8geyB0cmFuc2xhdGlvbjogZW4gfTtcblxuaWYgKCFpMThuLmlzSW5pdGlhbGl6ZWQpIHtcbiAgaTE4blxuICAgIC51c2UoTGFuZ3VhZ2VEZXRlY3RvcilcbiAgICAudXNlKGluaXRSZWFjdEkxOG5leHQpXG4gICAgLmluaXQoe1xuICAgICAgcmVzb3VyY2VzLFxuICAgICAgZmFsbGJhY2tMbmc6IFwiZW5cIixcbiAgICAgIHN1cHBvcnRlZExuZ3M6IExBTkdVQUdFUy5tYXAoKGwpID0+IGwuY29kZSksXG4gICAgICBub25FeHBsaWNpdFN1cHBvcnRlZExuZ3M6IHRydWUsXG4gICAgICBpbnRlcnBvbGF0aW9uOiB7IGVzY2FwZVZhbHVlOiBmYWxzZSB9LFxuICAgICAgaW5pdEltbWVkaWF0ZTogZmFsc2UsXG4gICAgICBkZXRlY3Rpb246IHtcbiAgICAgICAgb3JkZXI6IFtcImxvY2FsU3RvcmFnZVwiLCBcIm5hdmlnYXRvclwiXSxcbiAgICAgICAgY2FjaGVzOiBbXCJsb2NhbFN0b3JhZ2VcIl0sXG4gICAgICAgIGxvb2t1cExvY2FsU3RvcmFnZTogXCJzb3QtbGFuZ1wiLFxuICAgICAgfSxcbiAgICB9IGFzIGFueSk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGkxOG47XG4iXX0=