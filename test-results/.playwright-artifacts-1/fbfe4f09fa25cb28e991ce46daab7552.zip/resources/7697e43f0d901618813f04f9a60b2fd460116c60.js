//#region src/qss.ts
/**
* Program is a reimplementation of the `qss` package:
* Copyright (c) Luke Edwards luke.edwards05@gmail.com, MIT License
* https://github.com/lukeed/qss/blob/master/license.md
*
* This reimplementation uses modern browser APIs
* (namely URLSearchParams) and TypeScript while still
* maintaining the original functionality and interface.
*
* Update: this implementation has also been mangled to
* fit exactly our use-case (single value per key in encoding).
*/
/**
* Encodes an object into a query string.
* @param obj - The object to encode into a query string.
* @param stringify - An optional custom stringify function.
* @returns The encoded query string.
* @example
* ```
* // Example input: encode({ token: 'foo', key: 'value' })
* // Expected output: "token=foo&key=value"
* ```
*/
function encode(obj, stringify = String) {
	let result;
	for (const key in obj) {
		const val = obj[key];
		if (val !== void 0) (result ||= new URLSearchParams()).set(key, stringify(val));
	}
	return result ? result.toString() : "";
}
/**
* Converts a string value to its appropriate type (string, number, boolean).
* @param mix - The string value to convert.
* @returns The converted value.
* @example
* // Example input: toValue("123")
* // Expected output: 123
*/
function toValue(str) {
	if (!str) return "";
	if (str === "false") return false;
	if (str === "true") return true;
	return +str * 0 === 0 && +str + "" === str ? +str : str;
}
/**
* Decodes a query string into an object.
* @param str - The query string to decode.
* @returns The decoded key-value pairs in an object format.
* @example
* // Example input: decode("token=foo&key=value")
* // Expected output: { "token": "foo", "key": "value" }
*/
function decode(str) {
	const searchParams = new URLSearchParams(str);
	const result = Object.create(null);
	for (const [key, value] of searchParams.entries()) {
		const previousValue = result[key];
		if (previousValue == null) result[key] = toValue(value);
		else if (Array.isArray(previousValue)) previousValue.push(toValue(value));
		else result[key] = [previousValue, toValue(value)];
	}
	return result;
}
//#endregion
export { decode, encode };

                               
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicXNzLmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9xc3MudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBQcm9ncmFtIGlzIGEgcmVpbXBsZW1lbnRhdGlvbiBvZiB0aGUgYHFzc2AgcGFja2FnZTpcbiAqIENvcHlyaWdodCAoYykgTHVrZSBFZHdhcmRzIGx1a2UuZWR3YXJkczA1QGdtYWlsLmNvbSwgTUlUIExpY2Vuc2VcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9sdWtlZWQvcXNzL2Jsb2IvbWFzdGVyL2xpY2Vuc2UubWRcbiAqXG4gKiBUaGlzIHJlaW1wbGVtZW50YXRpb24gdXNlcyBtb2Rlcm4gYnJvd3NlciBBUElzXG4gKiAobmFtZWx5IFVSTFNlYXJjaFBhcmFtcykgYW5kIFR5cGVTY3JpcHQgd2hpbGUgc3RpbGxcbiAqIG1haW50YWluaW5nIHRoZSBvcmlnaW5hbCBmdW5jdGlvbmFsaXR5IGFuZCBpbnRlcmZhY2UuXG4gKlxuICogVXBkYXRlOiB0aGlzIGltcGxlbWVudGF0aW9uIGhhcyBhbHNvIGJlZW4gbWFuZ2xlZCB0b1xuICogZml0IGV4YWN0bHkgb3VyIHVzZS1jYXNlIChzaW5nbGUgdmFsdWUgcGVyIGtleSBpbiBlbmNvZGluZykuXG4gKi9cblxuLyoqXG4gKiBFbmNvZGVzIGFuIG9iamVjdCBpbnRvIGEgcXVlcnkgc3RyaW5nLlxuICogQHBhcmFtIG9iaiAtIFRoZSBvYmplY3QgdG8gZW5jb2RlIGludG8gYSBxdWVyeSBzdHJpbmcuXG4gKiBAcGFyYW0gc3RyaW5naWZ5IC0gQW4gb3B0aW9uYWwgY3VzdG9tIHN0cmluZ2lmeSBmdW5jdGlvbi5cbiAqIEByZXR1cm5zIFRoZSBlbmNvZGVkIHF1ZXJ5IHN0cmluZy5cbiAqIEBleGFtcGxlXG4gKiBgYGBcbiAqIC8vIEV4YW1wbGUgaW5wdXQ6IGVuY29kZSh7IHRva2VuOiAnZm9vJywga2V5OiAndmFsdWUnIH0pXG4gKiAvLyBFeHBlY3RlZCBvdXRwdXQ6IFwidG9rZW49Zm9vJmtleT12YWx1ZVwiXG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVuY29kZShcbiAgb2JqOiBSZWNvcmQ8c3RyaW5nLCBhbnk+LFxuICBzdHJpbmdpZnk6ICh2YWx1ZTogYW55KSA9PiBzdHJpbmcgPSBTdHJpbmcsXG4pOiBzdHJpbmcge1xuICBsZXQgcmVzdWx0OiBVUkxTZWFyY2hQYXJhbXMgfCB1bmRlZmluZWRcblxuICBmb3IgKGNvbnN0IGtleSBpbiBvYmopIHtcbiAgICBjb25zdCB2YWwgPSBvYmpba2V5XVxuICAgIGlmICh2YWwgIT09IHVuZGVmaW5lZCkge1xuICAgICAgOyhyZXN1bHQgfHw9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKSkuc2V0KGtleSwgc3RyaW5naWZ5KHZhbCkpXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHJlc3VsdCA/IHJlc3VsdC50b1N0cmluZygpIDogJydcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhIHN0cmluZyB2YWx1ZSB0byBpdHMgYXBwcm9wcmlhdGUgdHlwZSAoc3RyaW5nLCBudW1iZXIsIGJvb2xlYW4pLlxuICogQHBhcmFtIG1peCAtIFRoZSBzdHJpbmcgdmFsdWUgdG8gY29udmVydC5cbiAqIEByZXR1cm5zIFRoZSBjb252ZXJ0ZWQgdmFsdWUuXG4gKiBAZXhhbXBsZVxuICogLy8gRXhhbXBsZSBpbnB1dDogdG9WYWx1ZShcIjEyM1wiKVxuICogLy8gRXhwZWN0ZWQgb3V0cHV0OiAxMjNcbiAqL1xuZnVuY3Rpb24gdG9WYWx1ZShzdHI6IHVua25vd24pIHtcbiAgaWYgKCFzdHIpIHJldHVybiAnJ1xuXG4gIGlmIChzdHIgPT09ICdmYWxzZScpIHJldHVybiBmYWxzZVxuICBpZiAoc3RyID09PSAndHJ1ZScpIHJldHVybiB0cnVlXG4gIHJldHVybiArc3RyICogMCA9PT0gMCAmJiArc3RyICsgJycgPT09IHN0ciA/ICtzdHIgOiBzdHJcbn1cbi8qKlxuICogRGVjb2RlcyBhIHF1ZXJ5IHN0cmluZyBpbnRvIGFuIG9iamVjdC5cbiAqIEBwYXJhbSBzdHIgLSBUaGUgcXVlcnkgc3RyaW5nIHRvIGRlY29kZS5cbiAqIEByZXR1cm5zIFRoZSBkZWNvZGVkIGtleS12YWx1ZSBwYWlycyBpbiBhbiBvYmplY3QgZm9ybWF0LlxuICogQGV4YW1wbGVcbiAqIC8vIEV4YW1wbGUgaW5wdXQ6IGRlY29kZShcInRva2VuPWZvbyZrZXk9dmFsdWVcIilcbiAqIC8vIEV4cGVjdGVkIG91dHB1dDogeyBcInRva2VuXCI6IFwiZm9vXCIsIFwia2V5XCI6IFwidmFsdWVcIiB9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZWNvZGUoc3RyOiBhbnkpOiBhbnkge1xuICBjb25zdCBzZWFyY2hQYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHN0cilcblxuICBjb25zdCByZXN1bHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0gT2JqZWN0LmNyZWF0ZShudWxsKVxuXG4gIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIHNlYXJjaFBhcmFtcy5lbnRyaWVzKCkpIHtcbiAgICBjb25zdCBwcmV2aW91c1ZhbHVlID0gcmVzdWx0W2tleV1cbiAgICBpZiAocHJldmlvdXNWYWx1ZSA9PSBudWxsKSB7XG4gICAgICByZXN1bHRba2V5XSA9IHRvVmFsdWUodmFsdWUpXG4gICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHByZXZpb3VzVmFsdWUpKSB7XG4gICAgICBwcmV2aW91c1ZhbHVlLnB1c2godG9WYWx1ZSh2YWx1ZSkpXG4gICAgfSBlbHNlIHtcbiAgICAgIHJlc3VsdFtrZXldID0gW3ByZXZpb3VzVmFsdWUsIHRvVmFsdWUodmFsdWUpXVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiByZXN1bHRcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBd0JBLFNBQWdCLE9BQ2QsS0FDQSxZQUFvQyxRQUM1QjtDQUNSLElBQUk7Q0FFSixLQUFLLE1BQU0sT0FBTyxLQUFLO0VBQ3JCLE1BQU0sTUFBTSxJQUFJO0VBQ2hCLElBQUksUUFBUSxLQUFBLEdBQ1QsQ0FBQyxXQUFXLElBQUksZ0JBQWdCLEdBQUcsSUFBSSxLQUFLLFVBQVUsR0FBRyxDQUFDO0NBRS9EO0NBRUEsT0FBTyxTQUFTLE9BQU8sU0FBUyxJQUFJO0FBQ3RDOzs7Ozs7Ozs7QUFVQSxTQUFTLFFBQVEsS0FBYztDQUM3QixJQUFJLENBQUMsS0FBSyxPQUFPO0NBRWpCLElBQUksUUFBUSxTQUFTLE9BQU87Q0FDNUIsSUFBSSxRQUFRLFFBQVEsT0FBTztDQUMzQixPQUFPLENBQUMsTUFBTSxNQUFNLEtBQUssQ0FBQyxNQUFNLE9BQU8sTUFBTSxDQUFDLE1BQU07QUFDdEQ7Ozs7Ozs7OztBQVNBLFNBQWdCLE9BQU8sS0FBZTtDQUNwQyxNQUFNLGVBQWUsSUFBSSxnQkFBZ0IsR0FBRztDQUU1QyxNQUFNLFNBQWtDLE9BQU8sT0FBTyxJQUFJO0NBRTFELEtBQUssTUFBTSxDQUFDLEtBQUssVUFBVSxhQUFhLFFBQVEsR0FBRztFQUNqRCxNQUFNLGdCQUFnQixPQUFPO0VBQzdCLElBQUksaUJBQWlCLE1BQ25CLE9BQU8sT0FBTyxRQUFRLEtBQUs7T0FDdEIsSUFBSSxNQUFNLFFBQVEsYUFBYSxHQUNwQyxjQUFjLEtBQUssUUFBUSxLQUFLLENBQUM7T0FFakMsT0FBTyxPQUFPLENBQUMsZUFBZSxRQUFRLEtBQUssQ0FBQztDQUVoRDtDQUVBLE9BQU87QUFDVCIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=