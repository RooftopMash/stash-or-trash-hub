import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PeopleTrustFactor.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { BarChart3, Info, ShieldCheck } from "/node_modules/.vite/deps/lucide-react.js?v=a8030269";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "/app/applet/src/components/PeopleTrustFactor.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
export function calculatePeopleTrustFactor(signals) {
	const values = Object.values(signals);
	const score = Math.round(values.reduce((sum, value) => sum + value, 0) / values.length);
	return {
		score,
		signals
	};
}
export function PeopleTrustFactor({ signals, compact = false }) {
	const { score } = calculatePeopleTrustFactor(signals);
	const status = score >= 75 ? "Strong" : score >= 55 ? "Developing" : "Insufficient data";
	const scoreColor = score >= 75 ? "text-emerald-600" : score >= 55 ? "text-amber-600" : "text-muted-foreground";
	return /* @__PURE__ */ _jsxDEV("section", {
		className: cn("rounded-2xl border border-stash/20 bg-stash/5", compact ? "p-4" : "p-5"),
		"aria-labelledby": "people-trust-factor-title",
		"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:30:5",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-start justify-between gap-4",
				"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:34:7",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:35:9",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 text-stash",
						"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:36:11",
						children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, {
							className: "h-4 w-4",
							"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:37:13"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 37,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold uppercase tracking-[0.16em]",
							"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:38:13",
							children: "People Trust Factor"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 38,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("h3", {
						id: "people-trust-factor-title",
						className: "mt-2 font-display text-xl font-bold",
						"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:42:11",
						children: "A transparent people-to-brand signal"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "text-right",
					"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:46:9",
					children: [/* @__PURE__ */ _jsxDEV("p", {
						className: cn("text-3xl font-extrabold", scoreColor),
						"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:47:11",
						children: score
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs font-semibold text-muted-foreground",
						"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:48:11",
						children: status
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "mt-3 text-sm leading-relaxed text-muted-foreground",
				"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:51:7",
				children: "An internal SOT framework combining evidence quality, brand response, lived experience, and trust signals. It is not an external certification or endorsement."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 7
			}, this),
			!compact && /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-4 grid gap-2 sm:grid-cols-4",
				"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:56:9",
				children: Object.entries(signals).map(([label, value]) => /* @__PURE__ */ _jsxDEV("div", {
					className: "rounded-xl border border-border bg-background p-3",
					"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:58:13",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between gap-2",
						"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:59:15",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs capitalize text-muted-foreground",
							"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:60:17",
							children: label
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-sm font-bold",
							"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:61:17",
							children: value
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "mt-2 h-1.5 overflow-hidden rounded-full bg-secondary",
						"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:63:15",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "h-full rounded-full bg-stash",
							style: { width: `${value}%` },
							"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:64:17"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 15
					}, this)]
				}, label, true, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-4 flex items-center gap-2 text-xs text-muted-foreground",
				"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:70:7",
				children: [/* @__PURE__ */ _jsxDEV(Info, {
					className: "h-3.5 w-3.5",
					"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:71:9"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 9
				}, this), "Scores require sufficient, comparable data and should be read with the supporting evidence."]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 5
	}, this);
}
_c = PeopleTrustFactor;
export function PeopleTrustFactorLink() {
	return /* @__PURE__ */ _jsxDEV("span", {
		className: "inline-flex items-center gap-1 text-xs font-semibold text-stash",
		"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:80:5",
		children: [/* @__PURE__ */ _jsxDEV(BarChart3, {
			className: "h-3.5 w-3.5",
			"data-tsd-source": "/src/components/PeopleTrustFactor.tsx:81:7"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 81,
			columnNumber: 7
		}, this), "People Trust framework"]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 80,
		columnNumber: 5
	}, this);
}
_c2 = PeopleTrustFactorLink;
var _c, _c2;
$RefreshReg$(_c, "PeopleTrustFactor");
$RefreshReg$(_c2, "PeopleTrustFactorLink");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/PeopleTrustFactor.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/PeopleTrustFactor.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/PeopleTrustFactor.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/PeopleTrustFactor.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTs7O0FBU0E7Q0FDQTtDQUNBO0NBQ0E7RUFBQTtFQUFBO0NBQUE7QUFDQTtBQUVBLG9DQUNBLFNBQ0EsbUJBSUE7Q0FDQTtDQUNBO0NBQ0EsbUJBQ0E7Q0FFQSxPQUNBO0VBQ0E7RUFDQTtFQUNBO1lBSEE7R0FJQTtJQUFBO0lBQUE7Y0FBQSxDQUNBO0tBQUE7ZUFBQSxDQUNBO01BQUE7TUFBQTtnQkFBQSxDQUNBO09BQUE7T0FBQTtNQUE2Qzs7OztnQkFDN0M7T0FBQTtPQUFBO2lCQUEyRTtNQUUzRTs7OztjQUNBOzs7OztlQUNBO01BQUE7TUFBQTtNQUFBO2dCQUE0RjtLQUU1Rjs7OzthQUNBOzs7OztjQUNBO0tBQUE7S0FBQTtlQUFBLENBQ0E7TUFBQTtNQUFBO2dCQUFrRTtLQUFBOzs7O2VBQ2xFO01BQUE7TUFBQTtnQkFBb0U7S0FBQTs7OzthQUNwRTs7Ozs7WUFDQTs7Ozs7O0dBQ0E7SUFBQTtJQUFBO2NBQXVFO0dBR3ZFOzs7OztHQUNBLFlBQ0E7SUFBQTtJQUFBO2NBQ0EsZ0RBQ0E7S0FBQTtLQUFBO2VBQUEsQ0FDQTtNQUFBO01BQUE7Z0JBQUEsQ0FDQTtPQUFBO09BQUE7aUJBQTBFO01BQUE7Ozs7Z0JBQzFFO09BQUE7T0FBQTtpQkFBbUQ7TUFBQTs7OztjQUNuRDs7Ozs7ZUFDQTtNQUFBO01BQUE7Z0JBQ0E7T0FBQTtPQUFBO09BQUE7TUFBNkY7Ozs7O0tBQzdGOzs7O2FBQ0E7T0FSQTs7OztXQVFBLENBQ0E7R0FDQTs7Ozs7R0FFQTtJQUFBO0lBQUE7Y0FBQSxDQUNBO0tBQUE7S0FBQTtJQUFzQzs7OztjQUFBLDZGQUV0Qzs7Ozs7O0VBQ0E7Ozs7OztBQUVBOztBQUVBO0NBQ0EsT0FDQTtFQUFBO0VBQUE7WUFBQSxDQUNBO0dBQUE7R0FBQTtFQUF5Qzs7OztZQUFBLHdCQUV6Qzs7Ozs7O0FBRUEiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBlb3BsZVRydXN0RmFjdG9yLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCYXJDaGFydDMsIENoZWNrQ2lyY2xlMiwgSW5mbywgU2hpZWxkQ2hlY2sgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuXG50eXBlIEZhY3RvclNpZ25hbHMgPSB7XG4gIGV2aWRlbmNlOiBudW1iZXI7XG4gIHJlc3BvbnNlOiBudW1iZXI7XG4gIGV4cGVyaWVuY2U6IG51bWJlcjtcbiAgdHJ1c3Q6IG51bWJlcjtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBjYWxjdWxhdGVQZW9wbGVUcnVzdEZhY3RvcihzaWduYWxzOiBGYWN0b3JTaWduYWxzKSB7XG4gIGNvbnN0IHZhbHVlcyA9IE9iamVjdC52YWx1ZXMoc2lnbmFscyk7XG4gIGNvbnN0IHNjb3JlID0gTWF0aC5yb3VuZCh2YWx1ZXMucmVkdWNlKChzdW0sIHZhbHVlKSA9PiBzdW0gKyB2YWx1ZSwgMCkgLyB2YWx1ZXMubGVuZ3RoKTtcbiAgcmV0dXJuIHsgc2NvcmUsIHNpZ25hbHMgfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFBlb3BsZVRydXN0RmFjdG9yKHtcbiAgc2lnbmFscyxcbiAgY29tcGFjdCA9IGZhbHNlLFxufToge1xuICBzaWduYWxzOiBGYWN0b3JTaWduYWxzO1xuICBjb21wYWN0PzogYm9vbGVhbjtcbn0pIHtcbiAgY29uc3QgeyBzY29yZSB9ID0gY2FsY3VsYXRlUGVvcGxlVHJ1c3RGYWN0b3Ioc2lnbmFscyk7XG4gIGNvbnN0IHN0YXR1cyA9IHNjb3JlID49IDc1ID8gXCJTdHJvbmdcIiA6IHNjb3JlID49IDU1ID8gXCJEZXZlbG9waW5nXCIgOiBcIkluc3VmZmljaWVudCBkYXRhXCI7XG4gIGNvbnN0IHNjb3JlQ29sb3IgPVxuICAgIHNjb3JlID49IDc1ID8gXCJ0ZXh0LWVtZXJhbGQtNjAwXCIgOiBzY29yZSA+PSA1NSA/IFwidGV4dC1hbWJlci02MDBcIiA6IFwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI7XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvblxuICAgICAgY2xhc3NOYW1lPXtjbihcInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc3Rhc2gvMjAgYmctc3Rhc2gvNVwiLCBjb21wYWN0ID8gXCJwLTRcIiA6IFwicC01XCIpfVxuICAgICAgYXJpYS1sYWJlbGxlZGJ5PVwicGVvcGxlLXRydXN0LWZhY3Rvci10aXRsZVwiXG4gICAgPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zdGFzaFwiPlxuICAgICAgICAgICAgPFNoaWVsZENoZWNrIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLVswLjE2ZW1dXCI+XG4gICAgICAgICAgICAgIFBlb3BsZSBUcnVzdCBGYWN0b3JcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8aDMgaWQ9XCJwZW9wbGUtdHJ1c3QtZmFjdG9yLXRpdGxlXCIgY2xhc3NOYW1lPVwibXQtMiBmb250LWRpc3BsYXkgdGV4dC14bCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgIEEgdHJhbnNwYXJlbnQgcGVvcGxlLXRvLWJyYW5kIHNpZ25hbFxuICAgICAgICAgIDwvaDM+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9e2NuKFwidGV4dC0zeGwgZm9udC1leHRyYWJvbGRcIiwgc2NvcmVDb2xvcil9PntzY29yZX08L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntzdGF0dXN9PC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgQW4gaW50ZXJuYWwgU09UIGZyYW1ld29yayBjb21iaW5pbmcgZXZpZGVuY2UgcXVhbGl0eSwgYnJhbmQgcmVzcG9uc2UsIGxpdmVkIGV4cGVyaWVuY2UsIGFuZFxuICAgICAgICB0cnVzdCBzaWduYWxzLiBJdCBpcyBub3QgYW4gZXh0ZXJuYWwgY2VydGlmaWNhdGlvbiBvciBlbmRvcnNlbWVudC5cbiAgICAgIDwvcD5cbiAgICAgIHshY29tcGFjdCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBncmlkIGdhcC0yIHNtOmdyaWQtY29scy00XCI+XG4gICAgICAgICAge09iamVjdC5lbnRyaWVzKHNpZ25hbHMpLm1hcCgoW2xhYmVsLCB2YWx1ZV0pID0+IChcbiAgICAgICAgICAgIDxkaXYga2V5PXtsYWJlbH0gY2xhc3NOYW1lPVwicm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1iYWNrZ3JvdW5kIHAtM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgY2FwaXRhbGl6ZSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57bGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkXCI+e3ZhbHVlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBoLTEuNSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1mdWxsIGJnLXNlY29uZGFyeVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIHJvdW5kZWQtZnVsbCBiZy1zdGFzaFwiIHN0eWxlPXt7IHdpZHRoOiBgJHt2YWx1ZX0lYCB9fSAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgPEluZm8gY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICBTY29yZXMgcmVxdWlyZSBzdWZmaWNpZW50LCBjb21wYXJhYmxlIGRhdGEgYW5kIHNob3VsZCBiZSByZWFkIHdpdGggdGhlIHN1cHBvcnRpbmcgZXZpZGVuY2UuXG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBQZW9wbGVUcnVzdEZhY3RvckxpbmsoKSB7XG4gIHJldHVybiAoXG4gICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXN0YXNoXCI+XG4gICAgICA8QmFyQ2hhcnQzIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgIFBlb3BsZSBUcnVzdCBmcmFtZXdvcmtcbiAgICA8L3NwYW4+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9hcHAvYXBwbGV0L3NyYy9jb21wb25lbnRzL1Blb3BsZVRydXN0RmFjdG9yLnRzeCJ9