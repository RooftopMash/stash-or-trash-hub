import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/skeleton.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "/app/applet/src/components/ui/skeleton.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: cn("animate-pulse rounded-md bg-primary/10", className),
		...props
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 4,
		columnNumber: 10
	}, this);
}
_c = Skeleton;
export { Skeleton };
var _c;
$RefreshReg$(_c, "Skeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/skeleton.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/ui/skeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/ui/skeleton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/ui/skeleton.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVOzs7QUFFbkIsU0FBUyxTQUFTLEVBQUUsV0FBVyxHQUFHLFNBQStDO0NBQy9FLE9BQU8sd0JBQUMsT0FBRDtFQUFLLFdBQVcsR0FBRywwQ0FBMEMsU0FBUztFQUFHLEdBQUk7Q0FBUTs7Ozs7QUFDOUY7O0FBRUEsU0FBUyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJza2VsZXRvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvdXRpbHNcIjtcblxuZnVuY3Rpb24gU2tlbGV0b24oeyBjbGFzc05hbWUsIC4uLnByb3BzIH06IFJlYWN0LkhUTUxBdHRyaWJ1dGVzPEhUTUxEaXZFbGVtZW50Pikge1xuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9e2NuKFwiYW5pbWF0ZS1wdWxzZSByb3VuZGVkLW1kIGJnLXByaW1hcnkvMTBcIiwgY2xhc3NOYW1lKX0gey4uLnByb3BzfSAvPjtcbn1cblxuZXhwb3J0IHsgU2tlbGV0b24gfTtcbiJdfQ==