const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { supabase } from "/src/integrations/supabase/client.ts";
var _s = $RefreshSig$();
/** Live unread notification count for the signed-in user. */
export function useUnreadNotifications(userId) {
	_s();
	const [count, setCount] = useState(0);
	useEffect(() => {
		if (!userId) {
			setCount(0);
			return;
		}
		let mounted = true;
		const load = async () => {
			const { count: c } = await supabase.from("notifications").select("id", {
				count: "exact",
				head: true
			}).eq("user_id", userId).is("read_at", null);
			if (mounted) setCount(c ?? 0);
		};
		load();
		const channel = supabase.channel(`unread-notifs-${userId}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "notifications",
			filter: `user_id=eq.${userId}`
		}, () => load()).subscribe();
		return () => {
			mounted = false;
			supabase.removeChannel(channel);
		};
	}, [userId]);
	return count;
}
_s(useUnreadNotifications, "8FkJzHhZsFmVL5otHHrie84nHpk=");

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLGdCQUFnQjs7O0FBR3pCLE9BQU8sU0FBUyx1QkFBdUIsUUFBbUM7O0NBQ3hFLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxDQUFDO0NBRXBDLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxRQUFRO0dBQ1gsU0FBUyxDQUFDO0dBQ1Y7RUFDRjtFQUNBLElBQUksVUFBVTtFQUVkLE1BQU0sT0FBTyxZQUFZO0dBQ3ZCLE1BQU0sRUFBRSxPQUFPLE1BQU0sTUFBTSxTQUN4QixLQUFLLGVBQWUsQ0FBQyxDQUNyQixPQUFPLE1BQU07SUFBRSxPQUFPO0lBQVMsTUFBTTtHQUFLLENBQUMsQ0FBQyxDQUM1QyxHQUFHLFdBQVcsTUFBTSxDQUFDLENBQ3JCLEdBQUcsV0FBVyxJQUFJO0dBQ3JCLElBQUksU0FBUyxTQUFTLEtBQUssQ0FBQztFQUM5QjtFQUNBLEtBQUs7RUFFTCxNQUFNLFVBQVUsU0FDYixRQUFRLGlCQUFpQixRQUFRLENBQUMsQ0FDbEMsR0FDQyxvQkFDQTtHQUFFLE9BQU87R0FBSyxRQUFRO0dBQVUsT0FBTztHQUFpQixRQUFRLGNBQWM7RUFBUyxTQUNqRixLQUFLLENBQ2IsQ0FBQyxDQUNBLFVBQVU7RUFFYixhQUFhO0dBQ1gsVUFBVTtHQUNWLFNBQVMsY0FBYyxPQUFPO0VBQ2hDO0NBQ0YsR0FBRyxDQUFDLE1BQU0sQ0FBQztDQUVYLE9BQU87QUFDVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJ1c2VVbnJlYWROb3RpZmljYXRpb25zLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBzdXBhYmFzZSB9IGZyb20gXCJAL2ludGVncmF0aW9ucy9zdXBhYmFzZS9jbGllbnRcIjtcblxuLyoqIExpdmUgdW5yZWFkIG5vdGlmaWNhdGlvbiBjb3VudCBmb3IgdGhlIHNpZ25lZC1pbiB1c2VyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVVucmVhZE5vdGlmaWNhdGlvbnModXNlcklkOiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkKSB7XG4gIGNvbnN0IFtjb3VudCwgc2V0Q291bnRdID0gdXNlU3RhdGUoMCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXVzZXJJZCkge1xuICAgICAgc2V0Q291bnQoMCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGxldCBtb3VudGVkID0gdHJ1ZTtcblxuICAgIGNvbnN0IGxvYWQgPSBhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCB7IGNvdW50OiBjIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbShcIm5vdGlmaWNhdGlvbnNcIilcbiAgICAgICAgLnNlbGVjdChcImlkXCIsIHsgY291bnQ6IFwiZXhhY3RcIiwgaGVhZDogdHJ1ZSB9KVxuICAgICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZClcbiAgICAgICAgLmlzKFwicmVhZF9hdFwiLCBudWxsKTtcbiAgICAgIGlmIChtb3VudGVkKSBzZXRDb3VudChjID8/IDApO1xuICAgIH07XG4gICAgbG9hZCgpO1xuXG4gICAgY29uc3QgY2hhbm5lbCA9IHN1cGFiYXNlXG4gICAgICAuY2hhbm5lbChgdW5yZWFkLW5vdGlmcy0ke3VzZXJJZH1gKVxuICAgICAgLm9uKFxuICAgICAgICBcInBvc3RncmVzX2NoYW5nZXNcIixcbiAgICAgICAgeyBldmVudDogXCIqXCIsIHNjaGVtYTogXCJwdWJsaWNcIiwgdGFibGU6IFwibm90aWZpY2F0aW9uc1wiLCBmaWx0ZXI6IGB1c2VyX2lkPWVxLiR7dXNlcklkfWAgfSxcbiAgICAgICAgKCkgPT4gbG9hZCgpLFxuICAgICAgKVxuICAgICAgLnN1YnNjcmliZSgpO1xuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIG1vdW50ZWQgPSBmYWxzZTtcbiAgICAgIHN1cGFiYXNlLnJlbW92ZUNoYW5uZWwoY2hhbm5lbCk7XG4gICAgfTtcbiAgfSwgW3VzZXJJZF0pO1xuXG4gIHJldHVybiBjb3VudDtcbn1cbiJdfQ==