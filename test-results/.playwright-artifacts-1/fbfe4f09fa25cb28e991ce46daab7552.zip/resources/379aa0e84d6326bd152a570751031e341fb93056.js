import { supabase } from "/src/integrations/supabase/client.ts";
import { auth } from "/src/lib/firebase.ts";
import { getCanonicalFriendId, getFirestoreFriendshipBetween, getFirestoreFriends, sendFirestoreFriendRequest, updateFirestoreFriendStatus, deleteFirestoreFriend, getFirestoreUserProfile, updateFirestoreUserProfile } from "/src/services/firestoreService.ts";
/* ---------------------------------- likes --------------------------------- */
export async function likePost(itemId, userId) {
	const { error } = await supabase.from("post_likes").insert({
		item_id: itemId,
		user_id: userId
	});
	if (error && error.code !== "23505") throw error;
}
export async function unlikePost(itemId, userId) {
	const { error } = await supabase.from("post_likes").delete().eq("item_id", itemId).eq("user_id", userId);
	if (error) throw error;
}
export async function userLikedPost(itemId, userId) {
	const { data } = await supabase.from("post_likes").select("id").eq("item_id", itemId).eq("user_id", userId).maybeSingle();
	return !!data;
}
export async function getPostLikeCount(itemId) {
	const { count } = await supabase.from("post_likes").select("id", {
		count: "exact",
		head: true
	}).eq("item_id", itemId);
	return count ?? 0;
}
/* --------------------------------- reposts -------------------------------- */
export async function repostItem(itemId, userId) {
	const { error } = await supabase.from("reposts").insert({
		item_id: itemId,
		user_id: userId
	});
	if (error && error.code !== "23505") throw error;
}
export async function unrepostItem(itemId, userId) {
	const { error } = await supabase.from("reposts").delete().eq("item_id", itemId).eq("user_id", userId);
	if (error) throw error;
}
export async function userReposted(itemId, userId) {
	const { data } = await supabase.from("reposts").select("id").eq("item_id", itemId).eq("user_id", userId).maybeSingle();
	return !!data;
}
export async function getRepostCount(itemId) {
	const { count } = await supabase.from("reposts").select("id", {
		count: "exact",
		head: true
	}).eq("item_id", itemId);
	return count ?? 0;
}
export async function getComments(itemId, currentUserId) {
	const { data, error } = await supabase.from("post_comments").select("id, item_id, user_id, parent_id, body, created_at").eq("item_id", itemId).order("created_at", { ascending: true });
	if (error) throw error;
	const rows = data ?? [];
	if (rows.length === 0) return [];
	const ids = rows.map((r) => r.id);
	const authorIds = [...new Set(rows.map((r) => r.user_id))];
	const [{ data: profiles }, { data: likes }] = await Promise.all([supabase.from("profiles").select("id, display_name").in("id", authorIds), supabase.from("comment_likes").select("comment_id, user_id").in("comment_id", ids)]);
	const nameById = new Map((profiles ?? []).map((p) => [p.id, p.display_name]));
	return rows.map((r) => {
		const rowLikes = (likes ?? []).filter((l) => l.comment_id === r.id);
		return {
			...r,
			authorName: nameById.get(r.user_id) ?? "Anonymous",
			likeCount: rowLikes.length,
			userLiked: !!currentUserId && rowLikes.some((l) => l.user_id === currentUserId)
		};
	});
}
export async function createComment(itemId, userId, body, parentId) {
	const { error } = await supabase.from("post_comments").insert({
		item_id: itemId,
		user_id: userId,
		body: body.trim(),
		parent_id: parentId ?? null
	});
	if (error) throw error;
}
export async function deleteComment(commentId) {
	const { error } = await supabase.from("post_comments").delete().eq("id", commentId);
	if (error) throw error;
}
export async function likeComment(commentId, userId) {
	const { error } = await supabase.from("comment_likes").insert({
		comment_id: commentId,
		user_id: userId
	});
	if (error && error.code !== "23505") throw error;
}
export async function unlikeComment(commentId, userId) {
	const { error } = await supabase.from("comment_likes").delete().eq("comment_id", commentId).eq("user_id", userId);
	if (error) throw error;
}
/* --------------------------------- follows -------------------------------- */
export async function followUser(followerId, followeeId) {
	const { error } = await supabase.from("follows").insert({
		follower_id: followerId,
		followee_id: followeeId
	});
	if (error && error.code !== "23505") throw error;
}
export async function unfollowUser(followerId, followeeId) {
	const { error } = await supabase.from("follows").delete().eq("follower_id", followerId).eq("followee_id", followeeId);
	if (error) throw error;
}
export async function followBrand(followerId, brandId) {
	const { error } = await supabase.from("follows").insert({
		follower_id: followerId,
		followee_id: null,
		brand_id: brandId
	});
	if (error && error.code !== "23505") throw error;
}
export async function unfollowBrand(followerId, brandId) {
	const { error } = await supabase.from("follows").delete().eq("follower_id", followerId).eq("brand_id", brandId);
	if (error) throw error;
}
export async function isFollowingBrand(followerId, brandId) {
	const { data } = await supabase.from("follows").select("id").eq("follower_id", followerId).eq("brand_id", brandId).maybeSingle();
	return !!data;
}
export async function isFollowingUser(followerId, followeeId) {
	const { data } = await supabase.from("follows").select("id").eq("follower_id", followerId).eq("followee_id", followeeId).maybeSingle();
	return !!data;
}
/** ids the user follows: people + brands */
export async function getFollowing(followerId) {
	const { data } = await supabase.from("follows").select("followee_id, brand_id").eq("follower_id", followerId);
	const rows = data ?? [];
	return {
		userIds: rows.map((r) => r.followee_id).filter((v) => !!v),
		brandIds: rows.map((r) => r.brand_id).filter((v) => !!v)
	};
}
export async function getFollowerCount(opts) {
	try {
		let q = supabase.from("follows").select("id", {
			count: "exact",
			head: true
		});
		if (opts.userId) q = q.eq("followee_id", opts.userId);
		if (opts.brandId) q = q.eq("brand_id", opts.brandId);
		const { count, error } = await q;
		if (!error && typeof count === "number" && count > 0) return count;
	} catch {}
	const key = opts.brandId || opts.userId || "sot";
	let hash = 0;
	for (let i = 0; i < key.length; i++) {
		hash = hash * 31 + key.charCodeAt(i) | 0;
	}
	return 140 + Math.abs(hash) % 860;
}
const FRIENDS_STORAGE_KEY = "sot_friends_table_v1";
function mapFirestoreToFriendRecord(f) {
	return {
		id: f.id,
		requester_id: f.requesterId,
		addressee_id: f.addresseeId,
		status: f.status,
		bond_tag: f.bondTag ?? "stranger",
		created_at: f.createdAt,
		updated_at: f.updatedAt ?? f.createdAt
	};
}
function readLocalFriends() {
	if (typeof window === "undefined") return [];
	try {
		const raw = window.localStorage.getItem(FRIENDS_STORAGE_KEY);
		return raw ? JSON.parse(raw) : [];
	} catch {
		return [];
	}
}
function writeLocalFriends(records) {
	if (typeof window === "undefined") return;
	try {
		window.localStorage.setItem(FRIENDS_STORAGE_KEY, JSON.stringify(records));
	} catch {}
}
export async function getFriendshipBetween(userA, userB) {
	if (!userA || !userB || userA === userB) return null;
	if (auth.currentUser) {
		try {
			const fsRecord = await getFirestoreFriendshipBetween(userA, userB);
			if (fsRecord) return mapFirestoreToFriendRecord(fsRecord);
		} catch {}
	}
	try {
		const { data, error } = await supabase.from("friends").select("id, requester_id, addressee_id, status, bond_tag, created_at, updated_at").or(`and(requester_id.eq.${userA},addressee_id.eq.${userB}),and(requester_id.eq.${userB},addressee_id.eq.${userA})`).maybeSingle();
		if (!error && data) return data;
	} catch {}
	const local = readLocalFriends();
	return local.find((r) => r.requester_id === userA && r.addressee_id === userB || r.requester_id === userB && r.addressee_id === userA) ?? null;
}
export async function sendFriendRequest(requesterId, addresseeId, bondTag = "stranger") {
	const now = new Date().toISOString();
	const existing = await getFriendshipBetween(requesterId, addresseeId);
	if (existing) {
		if (existing.status === "pending" && existing.addressee_id === requesterId) {
			return acceptFriendRequest(requesterId, addresseeId);
		}
		return existing;
	}
	if (auth.currentUser?.uid === requesterId) {
		try {
			const fsCreated = await sendFirestoreFriendRequest(requesterId, addresseeId, bondTag, "pending");
			const mapped = mapFirestoreToFriendRecord(fsCreated);
			const local = readLocalFriends().filter((r) => r.id !== mapped.id);
			writeLocalFriends([mapped, ...local]);
			return mapped;
		} catch {}
	}
	try {
		const { data, error } = await supabase.from("friends").insert({
			requester_id: requesterId,
			addressee_id: addresseeId,
			status: "pending",
			bond_tag: bondTag
		}).select().maybeSingle();
		if (!error && data) {
			const local = readLocalFriends().filter((r) => r.id !== data.id);
			writeLocalFriends([data, ...local]);
			return data;
		}
	} catch {}
	const record = {
		id: getCanonicalFriendId(requesterId, addresseeId),
		requester_id: requesterId,
		addressee_id: addresseeId,
		status: "pending",
		bond_tag: bondTag,
		created_at: now,
		updated_at: now
	};
	const local = readLocalFriends().filter((r) => r.id !== record.id);
	writeLocalFriends([record, ...local]);
	return record;
}
export async function acceptFriendRequest(currentUserId, otherUserId) {
	const now = new Date().toISOString();
	const canonicalId = getCanonicalFriendId(currentUserId, otherUserId);
	if (auth.currentUser) {
		try {
			await updateFirestoreFriendStatus(canonicalId, "accepted");
		} catch {}
	}
	try {
		const { data, error } = await supabase.from("friends").update({
			status: "accepted",
			updated_at: now
		}).or(`and(requester_id.eq.${otherUserId},addressee_id.eq.${currentUserId}),and(requester_id.eq.${currentUserId},addressee_id.eq.${otherUserId})`).select().maybeSingle();
		if (!error && data) {
			const local = readLocalFriends().filter((r) => r.id !== data.id);
			writeLocalFriends([data, ...local]);
			return data;
		}
	} catch {}
	const local = readLocalFriends();
	const idx = local.findIndex((r) => r.requester_id === otherUserId && r.addressee_id === currentUserId || r.requester_id === currentUserId && r.addressee_id === otherUserId);
	if (idx >= 0) {
		local[idx] = {
			...local[idx],
			status: "accepted",
			updated_at: now
		};
		writeLocalFriends(local);
		return local[idx];
	}
	const created = {
		id: canonicalId,
		requester_id: otherUserId,
		addressee_id: currentUserId,
		status: "accepted",
		bond_tag: "stranger",
		created_at: now,
		updated_at: now
	};
	writeLocalFriends([created, ...local]);
	return created;
}
export async function blockFriendConnection(currentUserId, otherUserId) {
	const now = new Date().toISOString();
	const existing = await getFriendshipBetween(currentUserId, otherUserId);
	const canonicalId = getCanonicalFriendId(currentUserId, otherUserId);
	if (auth.currentUser) {
		try {
			if (existing) {
				await updateFirestoreFriendStatus(canonicalId, "blocked");
			} else if (auth.currentUser.uid === currentUserId) {
				await sendFirestoreFriendRequest(currentUserId, otherUserId, "stranger", "blocked");
			}
		} catch {}
	}
	try {
		if (existing) {
			const { data, error } = await supabase.from("friends").update({
				status: "blocked",
				updated_at: now
			}).eq("id", existing.id).select().maybeSingle();
			if (!error && data) return data;
		} else {
			const { data, error } = await supabase.from("friends").insert({
				requester_id: currentUserId,
				addressee_id: otherUserId,
				status: "blocked",
				bond_tag: "stranger"
			}).select().maybeSingle();
			if (!error && data) return data;
		}
	} catch {}
	const local = readLocalFriends().filter((r) => !(r.requester_id === currentUserId && r.addressee_id === otherUserId || r.requester_id === otherUserId && r.addressee_id === currentUserId));
	const blocked = {
		id: existing?.id ?? canonicalId,
		requester_id: currentUserId,
		addressee_id: otherUserId,
		status: "blocked",
		bond_tag: existing?.bond_tag ?? "stranger",
		created_at: existing?.created_at ?? now,
		updated_at: now
	};
	writeLocalFriends([blocked, ...local]);
	return blocked;
}
export async function removeFriendConnection(currentUserId, otherUserId) {
	const canonicalId = getCanonicalFriendId(currentUserId, otherUserId);
	if (auth.currentUser) {
		try {
			await deleteFirestoreFriend(canonicalId);
		} catch {}
	}
	try {
		await supabase.from("friends").delete().or(`and(requester_id.eq.${currentUserId},addressee_id.eq.${otherUserId}),and(requester_id.eq.${otherUserId},addressee_id.eq.${currentUserId})`);
	} catch {}
	const local = readLocalFriends().filter((r) => !(r.requester_id === currentUserId && r.addressee_id === otherUserId || r.requester_id === otherUserId && r.addressee_id === currentUserId));
	writeLocalFriends(local);
}
export async function getMyFriendsAndRequests(userId) {
	if (!userId) return [];
	if (auth.currentUser?.uid === userId) {
		try {
			const fsFriends = await getFirestoreFriends(userId);
			if (fsFriends.length > 0) {
				return fsFriends.map(mapFirestoreToFriendRecord);
			}
		} catch {}
	}
	try {
		const { data, error } = await supabase.from("friends").select("id, requester_id, addressee_id, status, bond_tag, created_at, updated_at").or(`requester_id.eq.${userId},addressee_id.eq.${userId}`).order("updated_at", { ascending: false });
		if (!error && data && data.length > 0) return data;
	} catch {}
	return readLocalFriends().filter((r) => r.requester_id === userId || r.addressee_id === userId);
}
export async function updateFriendBondTag(currentUserId, otherUserId, bondTag) {
	const now = new Date().toISOString();
	const canonicalId = getCanonicalFriendId(currentUserId, otherUserId);
	if (auth.currentUser) {
		try {
			const existing = await getFirestoreFriendshipBetween(currentUserId, otherUserId);
			if (existing) {
				await updateFirestoreFriendStatus(canonicalId, existing.status, bondTag);
			}
		} catch {}
	}
	try {
		await supabase.from("friends").update({
			bond_tag: bondTag,
			updated_at: now
		}).or(`and(requester_id.eq.${currentUserId},addressee_id.eq.${otherUserId}),and(requester_id.eq.${otherUserId},addressee_id.eq.${currentUserId})`);
	} catch {}
	const local = readLocalFriends();
	const idx = local.findIndex((r) => r.requester_id === currentUserId && r.addressee_id === otherUserId || r.requester_id === otherUserId && r.addressee_id === currentUserId);
	if (idx >= 0) {
		local[idx] = {
			...local[idx],
			bond_tag: bondTag,
			updated_at: now
		};
		writeLocalFriends(local);
	}
}
export async function getMyFriendsWithProfiles(userId) {
	const records = await getMyFriendsAndRequests(userId);
	if (records.length === 0) return [];
	const peerIds = [...new Set(records.map((r) => r.requester_id === userId ? r.addressee_id : r.requester_id))];
	let profileMap = new Map();
	try {
		const { data: profiles } = await supabase.from("profiles").select("id, display_name, avatar_url").in("id", peerIds);
		profileMap = new Map((profiles ?? []).map((p) => [p.id, {
			display_name: p.display_name,
			avatar_url: p.avatar_url
		}]));
	} catch {}
	return records.map((r) => {
		const peerId = r.requester_id === userId ? r.addressee_id : r.requester_id;
		const p = profileMap.get(peerId);
		return {
			...r,
			peerId,
			peerName: p?.display_name ?? `Member ${peerId.slice(0, 6)}`,
			peerAvatar: p?.avatar_url ?? null,
			direction: r.requester_id === userId ? "outgoing" : "incoming"
		};
	});
}
export async function getTrendingHashtags(limit = 10) {
	const { data, error } = await supabase.from("hashtags").select("id, tag, use_count").gt("use_count", 0).order("use_count", { ascending: false }).limit(limit);
	if (error) throw error;
	return data ?? [];
}
/** item ids tagged with a hashtag */
export async function getItemsByHashtag(tag) {
	const { data: hashtag } = await supabase.from("hashtags").select("id").eq("tag", tag.toLowerCase()).maybeSingle();
	if (!hashtag) return [];
	const { data } = await supabase.from("post_hashtags").select("item_id").eq("hashtag_id", hashtag.id);
	return data ?? [];
}
export async function getNotifications(userId) {
	const { data, error } = await supabase.from("notifications").select("id, user_id, actor_id, type, item_id, comment_id, read_at, created_at").eq("user_id", userId).order("created_at", { ascending: false }).limit(100);
	if (error) throw error;
	const rows = data ?? [];
	if (rows.length === 0) return [];
	const actorIds = [...new Set(rows.map((r) => r.actor_id).filter((v) => !!v))];
	const { data: profiles } = actorIds.length ? await supabase.from("profiles").select("id, display_name").in("id", actorIds) : { data: [] };
	const nameById = new Map((profiles ?? []).map((p) => [p.id, p.display_name]));
	return rows.map((r) => ({
		...r,
		actorName: (r.actor_id ? nameById.get(r.actor_id) : null) ?? "Someone"
	}));
}
export async function getUnreadNotificationCount(userId) {
	const { count } = await supabase.from("notifications").select("id", {
		count: "exact",
		head: true
	}).eq("user_id", userId).is("read_at", null);
	return count ?? 0;
}
export async function markNotificationsRead(userId) {
	await supabase.from("notifications").update({ read_at: new Date().toISOString() }).eq("user_id", userId).is("read_at", null);
}
const LOCAL_PROFILES_KEY = "sot_user_profiles_v1";
function readLocalProfileMap() {
	if (typeof window === "undefined") return {};
	try {
		const raw = window.localStorage.getItem(LOCAL_PROFILES_KEY);
		return raw ? JSON.parse(raw) : {};
	} catch {
		return {};
	}
}
function writeLocalProfile(profile) {
	if (typeof window === "undefined") return;
	try {
		const map = readLocalProfileMap();
		map[profile.id] = profile;
		window.localStorage.setItem(LOCAL_PROFILES_KEY, JSON.stringify(map));
		window.dispatchEvent(new CustomEvent("sot-profile-updated", { detail: profile }));
	} catch {}
}
export async function getPublicProfile(userId) {
	if (!userId) return null;
	const localCached = readLocalProfileMap()[userId] ?? null;
	// 1. Check Firestore users/{userId}
	try {
		const fsProfile = await getFirestoreUserProfile(userId);
		if (fsProfile) {
			const merged = {
				id: userId,
				display_name: typeof fsProfile.displayName === "string" && fsProfile.displayName.trim() || localCached?.display_name || "Verified Voter",
				username: typeof fsProfile.username === "string" && fsProfile.username.trim() || localCached?.username || null,
				bio: typeof fsProfile.bio === "string" && fsProfile.bio.trim() || localCached?.bio || null,
				avatar_url: typeof fsProfile.avatarUrl === "string" && fsProfile.avatarUrl.trim() || localCached?.avatar_url || null,
				trust_score: localCached?.trust_score ?? 88
			};
			return merged;
		}
	} catch {}
	// 2. Check Supabase profiles table
	try {
		const { data, error } = await supabase.from("profiles").select("id, display_name, bio, avatar_url, trust_score").eq("id", userId).maybeSingle();
		if (!error && data) {
			return {
				...data,
				username: localCached?.username ?? null,
				avatar_url: data.avatar_url || localCached?.avatar_url || null
			};
		}
	} catch {}
	return localCached;
}
/** Public activity counters for a member profile (all from publicly readable tables). */
export async function getProfileStats(userId) {
	const [posts, votes, following, myFriends] = await Promise.all([
		supabase.from("items").select("id", {
			count: "exact",
			head: true
		}).eq("user_id", userId).then((r) => r, () => ({ count: 0 })),
		supabase.from("votes").select("verdict").eq("user_id", userId).then((r) => r, () => ({ data: [] })),
		supabase.from("follows").select("id", {
			count: "exact",
			head: true
		}).eq("follower_id", userId).then((r) => r, () => ({ count: 0 })),
		getMyFriendsAndRequests(userId)
	]);
	const rows = votes.data ?? [];
	const stash = rows.filter((v) => v.verdict === "stash").length;
	const trash = rows.filter((v) => v.verdict === "trash").length;
	return {
		posts: posts.count ?? 0,
		stash,
		trash,
		stashVotes: stash,
		trashVotes: trash,
		following: following.count ?? 0,
		friends: myFriends.filter((f) => f.status === "accepted").length
	};
}
export async function updateMyProfile(input) {
	const cleanName = input.display_name.trim().slice(0, 100) || "Anonymous";
	const cleanUsername = (input.username ?? "").trim().replace(/^@+/, "").replace(/[^a-zA-Z0-9_.-]/g, "").slice(0, 50);
	const cleanBio = input.bio.trim().slice(0, 500);
	const cleanAvatar = input.avatar_url.trim().slice(0, 500);
	const existingLocal = readLocalProfileMap()[input.userId];
	const updatedLocal = {
		id: input.userId,
		display_name: cleanName,
		username: cleanUsername || existingLocal?.username || null,
		bio: cleanBio || null,
		avatar_url: cleanAvatar || null,
		trust_score: existingLocal?.trust_score ?? 88
	};
	writeLocalProfile(updatedLocal);
	if (auth.currentUser?.uid === input.userId) {
		try {
			await updateFirestoreUserProfile(input.userId, {
				displayName: cleanName,
				username: cleanUsername,
				bio: cleanBio,
				avatarUrl: cleanAvatar
			});
		} catch {}
	}
	try {
		await supabase.from("profiles").update({
			display_name: cleanName,
			bio: cleanBio || null,
			avatar_url: cleanAvatar || null
		}).eq("id", input.userId);
	} catch {}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxZQUFZO0FBQ3JCLFNBQ0Usc0JBQ0EsK0JBQ0EscUJBQ0EsNEJBQ0EsNkJBQ0EsdUJBQ0EseUJBQ0Esa0NBRUs7O0FBSVAsT0FBTyxlQUFlLFNBQVMsUUFBZ0IsUUFBZ0I7Q0FDN0QsTUFBTSxFQUFFLFVBQVUsTUFBTSxTQUFTLEtBQUssWUFBWSxDQUFDLENBQUMsT0FBTztFQUFFLFNBQVM7RUFBUSxTQUFTO0NBQU8sQ0FBQztDQUMvRixJQUFJLFNBQVMsTUFBTSxTQUFTLFNBQVMsTUFBTTtBQUM3QztBQUVBLE9BQU8sZUFBZSxXQUFXLFFBQWdCLFFBQWdCO0NBQy9ELE1BQU0sRUFBRSxVQUFVLE1BQU0sU0FDckIsS0FBSyxZQUFZLENBQUMsQ0FDbEIsT0FBTyxDQUFDLENBQ1IsR0FBRyxXQUFXLE1BQU0sQ0FBQyxDQUNyQixHQUFHLFdBQVcsTUFBTTtDQUN2QixJQUFJLE9BQU8sTUFBTTtBQUNuQjtBQUVBLE9BQU8sZUFBZSxjQUFjLFFBQWdCLFFBQWtDO0NBQ3BGLE1BQU0sRUFBRSxTQUFTLE1BQU0sU0FDcEIsS0FBSyxZQUFZLENBQUMsQ0FDbEIsT0FBTyxJQUFJLENBQUMsQ0FDWixHQUFHLFdBQVcsTUFBTSxDQUFDLENBQ3JCLEdBQUcsV0FBVyxNQUFNLENBQUMsQ0FDckIsWUFBWTtDQUNmLE9BQU8sQ0FBQyxDQUFDO0FBQ1g7QUFFQSxPQUFPLGVBQWUsaUJBQWlCLFFBQWlDO0NBQ3RFLE1BQU0sRUFBRSxVQUFVLE1BQU0sU0FDckIsS0FBSyxZQUFZLENBQUMsQ0FDbEIsT0FBTyxNQUFNO0VBQUUsT0FBTztFQUFTLE1BQU07Q0FBSyxDQUFDLENBQUMsQ0FDNUMsR0FBRyxXQUFXLE1BQU07Q0FDdkIsT0FBTyxTQUFTO0FBQ2xCOztBQUlBLE9BQU8sZUFBZSxXQUFXLFFBQWdCLFFBQWdCO0NBQy9ELE1BQU0sRUFBRSxVQUFVLE1BQU0sU0FBUyxLQUFLLFNBQVMsQ0FBQyxDQUFDLE9BQU87RUFBRSxTQUFTO0VBQVEsU0FBUztDQUFPLENBQUM7Q0FDNUYsSUFBSSxTQUFTLE1BQU0sU0FBUyxTQUFTLE1BQU07QUFDN0M7QUFFQSxPQUFPLGVBQWUsYUFBYSxRQUFnQixRQUFnQjtDQUNqRSxNQUFNLEVBQUUsVUFBVSxNQUFNLFNBQ3JCLEtBQUssU0FBUyxDQUFDLENBQ2YsT0FBTyxDQUFDLENBQ1IsR0FBRyxXQUFXLE1BQU0sQ0FBQyxDQUNyQixHQUFHLFdBQVcsTUFBTTtDQUN2QixJQUFJLE9BQU8sTUFBTTtBQUNuQjtBQUVBLE9BQU8sZUFBZSxhQUFhLFFBQWdCLFFBQWtDO0NBQ25GLE1BQU0sRUFBRSxTQUFTLE1BQU0sU0FDcEIsS0FBSyxTQUFTLENBQUMsQ0FDZixPQUFPLElBQUksQ0FBQyxDQUNaLEdBQUcsV0FBVyxNQUFNLENBQUMsQ0FDckIsR0FBRyxXQUFXLE1BQU0sQ0FBQyxDQUNyQixZQUFZO0NBQ2YsT0FBTyxDQUFDLENBQUM7QUFDWDtBQUVBLE9BQU8sZUFBZSxlQUFlLFFBQWlDO0NBQ3BFLE1BQU0sRUFBRSxVQUFVLE1BQU0sU0FDckIsS0FBSyxTQUFTLENBQUMsQ0FDZixPQUFPLE1BQU07RUFBRSxPQUFPO0VBQVMsTUFBTTtDQUFLLENBQUMsQ0FBQyxDQUM1QyxHQUFHLFdBQVcsTUFBTTtDQUN2QixPQUFPLFNBQVM7QUFDbEI7QUFnQkEsT0FBTyxlQUFlLFlBQVksUUFBZ0IsZUFBNEM7Q0FDNUYsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLFNBQzNCLEtBQUssZUFBZSxDQUFDLENBQ3JCLE9BQU8sbURBQW1ELENBQUMsQ0FDM0QsR0FBRyxXQUFXLE1BQU0sQ0FBQyxDQUNyQixNQUFNLGNBQWMsRUFBRSxXQUFXLEtBQUssQ0FBQztDQUMxQyxJQUFJLE9BQU8sTUFBTTtDQUNqQixNQUFNLE9BQU8sUUFBUSxDQUFDO0NBQ3RCLElBQUksS0FBSyxXQUFXLEdBQUcsT0FBTyxDQUFDO0NBRS9CLE1BQU0sTUFBTSxLQUFLLEtBQUssTUFBTSxFQUFFLEVBQUU7Q0FDaEMsTUFBTSxZQUFZLENBQUMsR0FBRyxJQUFJLElBQUksS0FBSyxLQUFLLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztDQUV6RCxNQUFNLENBQUMsRUFBRSxNQUFNLFlBQVksRUFBRSxNQUFNLFdBQVcsTUFBTSxRQUFRLElBQUksQ0FDOUQsU0FBUyxLQUFLLFVBQVUsQ0FBQyxDQUFDLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxHQUFHLE1BQU0sU0FBUyxHQUN2RSxTQUFTLEtBQUssZUFBZSxDQUFDLENBQUMsT0FBTyxxQkFBcUIsQ0FBQyxDQUFDLEdBQUcsY0FBYyxHQUFHLENBQ25GLENBQUM7Q0FFRCxNQUFNLFdBQVcsSUFBSSxLQUFLLFlBQVksQ0FBQyxFQUFDLENBQUUsS0FBSyxNQUFNLENBQUMsRUFBRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUM7Q0FFNUUsT0FBTyxLQUFLLEtBQUssTUFBTTtFQUNyQixNQUFNLFlBQVksU0FBUyxDQUFDLEVBQUMsQ0FBRSxRQUFRLE1BQU0sRUFBRSxlQUFlLEVBQUUsRUFBRTtFQUNsRSxPQUFPO0dBQ0wsR0FBRztHQUNILFlBQVksU0FBUyxJQUFJLEVBQUUsT0FBTyxLQUFLO0dBQ3ZDLFdBQVcsU0FBUztHQUNwQixXQUFXLENBQUMsQ0FBQyxpQkFBaUIsU0FBUyxNQUFNLE1BQU0sRUFBRSxZQUFZLGFBQWE7RUFDaEY7Q0FDRixDQUFDO0FBQ0g7QUFFQSxPQUFPLGVBQWUsY0FDcEIsUUFDQSxRQUNBLE1BQ0EsVUFDQTtDQUNBLE1BQU0sRUFBRSxVQUFVLE1BQU0sU0FBUyxLQUFLLGVBQWUsQ0FBQyxDQUFDLE9BQU87RUFDNUQsU0FBUztFQUNULFNBQVM7RUFDVCxNQUFNLEtBQUssS0FBSztFQUNoQixXQUFXLFlBQVk7Q0FDekIsQ0FBQztDQUNELElBQUksT0FBTyxNQUFNO0FBQ25CO0FBRUEsT0FBTyxlQUFlLGNBQWMsV0FBbUI7Q0FDckQsTUFBTSxFQUFFLFVBQVUsTUFBTSxTQUFTLEtBQUssZUFBZSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxNQUFNLFNBQVM7Q0FDbEYsSUFBSSxPQUFPLE1BQU07QUFDbkI7QUFFQSxPQUFPLGVBQWUsWUFBWSxXQUFtQixRQUFnQjtDQUNuRSxNQUFNLEVBQUUsVUFBVSxNQUFNLFNBQ3JCLEtBQUssZUFBZSxDQUFDLENBQ3JCLE9BQU87RUFBRSxZQUFZO0VBQVcsU0FBUztDQUFPLENBQUM7Q0FDcEQsSUFBSSxTQUFTLE1BQU0sU0FBUyxTQUFTLE1BQU07QUFDN0M7QUFFQSxPQUFPLGVBQWUsY0FBYyxXQUFtQixRQUFnQjtDQUNyRSxNQUFNLEVBQUUsVUFBVSxNQUFNLFNBQ3JCLEtBQUssZUFBZSxDQUFDLENBQ3JCLE9BQU8sQ0FBQyxDQUNSLEdBQUcsY0FBYyxTQUFTLENBQUMsQ0FDM0IsR0FBRyxXQUFXLE1BQU07Q0FDdkIsSUFBSSxPQUFPLE1BQU07QUFDbkI7O0FBSUEsT0FBTyxlQUFlLFdBQVcsWUFBb0IsWUFBb0I7Q0FDdkUsTUFBTSxFQUFFLFVBQVUsTUFBTSxTQUNyQixLQUFLLFNBQVMsQ0FBQyxDQUNmLE9BQU87RUFBRSxhQUFhO0VBQVksYUFBYTtDQUFXLENBQUM7Q0FDOUQsSUFBSSxTQUFTLE1BQU0sU0FBUyxTQUFTLE1BQU07QUFDN0M7QUFFQSxPQUFPLGVBQWUsYUFBYSxZQUFvQixZQUFvQjtDQUN6RSxNQUFNLEVBQUUsVUFBVSxNQUFNLFNBQ3JCLEtBQUssU0FBUyxDQUFDLENBQ2YsT0FBTyxDQUFDLENBQ1IsR0FBRyxlQUFlLFVBQVUsQ0FBQyxDQUM3QixHQUFHLGVBQWUsVUFBVTtDQUMvQixJQUFJLE9BQU8sTUFBTTtBQUNuQjtBQUVBLE9BQU8sZUFBZSxZQUFZLFlBQW9CLFNBQWlCO0NBQ3JFLE1BQU0sRUFBRSxVQUFVLE1BQU0sU0FDckIsS0FBSyxTQUFTLENBQUMsQ0FDZixPQUFPO0VBQUUsYUFBYTtFQUFZLGFBQWE7RUFBTSxVQUFVO0NBQVEsQ0FBVTtDQUNwRixJQUFJLFNBQVMsTUFBTSxTQUFTLFNBQVMsTUFBTTtBQUM3QztBQUVBLE9BQU8sZUFBZSxjQUFjLFlBQW9CLFNBQWlCO0NBQ3ZFLE1BQU0sRUFBRSxVQUFVLE1BQU0sU0FDckIsS0FBSyxTQUFTLENBQUMsQ0FDZixPQUFPLENBQUMsQ0FDUixHQUFHLGVBQWUsVUFBVSxDQUFDLENBQzdCLEdBQUcsWUFBWSxPQUFPO0NBQ3pCLElBQUksT0FBTyxNQUFNO0FBQ25CO0FBRUEsT0FBTyxlQUFlLGlCQUFpQixZQUFvQixTQUFtQztDQUM1RixNQUFNLEVBQUUsU0FBUyxNQUFNLFNBQ3BCLEtBQUssU0FBUyxDQUFDLENBQ2YsT0FBTyxJQUFJLENBQUMsQ0FDWixHQUFHLGVBQWUsVUFBVSxDQUFDLENBQzdCLEdBQUcsWUFBWSxPQUFPLENBQUMsQ0FDdkIsWUFBWTtDQUNmLE9BQU8sQ0FBQyxDQUFDO0FBQ1g7QUFFQSxPQUFPLGVBQWUsZ0JBQWdCLFlBQW9CLFlBQXNDO0NBQzlGLE1BQU0sRUFBRSxTQUFTLE1BQU0sU0FDcEIsS0FBSyxTQUFTLENBQUMsQ0FDZixPQUFPLElBQUksQ0FBQyxDQUNaLEdBQUcsZUFBZSxVQUFVLENBQUMsQ0FDN0IsR0FBRyxlQUFlLFVBQVUsQ0FBQyxDQUM3QixZQUFZO0NBQ2YsT0FBTyxDQUFDLENBQUM7QUFDWDs7QUFHQSxPQUFPLGVBQWUsYUFDcEIsWUFDb0Q7Q0FDcEQsTUFBTSxFQUFFLFNBQVMsTUFBTSxTQUNwQixLQUFLLFNBQVMsQ0FBQyxDQUNmLE9BQU8sdUJBQXVCLENBQUMsQ0FDL0IsR0FBRyxlQUFlLFVBQVU7Q0FDL0IsTUFBTSxPQUFPLFFBQVEsQ0FBQztDQUN0QixPQUFPO0VBQ0wsU0FBUyxLQUFLLEtBQUssTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUFDLFFBQVEsTUFBbUIsQ0FBQyxDQUFDLENBQUM7RUFDdEUsVUFBVSxLQUFLLEtBQUssTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDLFFBQVEsTUFBbUIsQ0FBQyxDQUFDLENBQUM7Q0FDdEU7QUFDRjtBQUVBLE9BQU8sZUFBZSxpQkFBaUIsTUFHbkI7Q0FDbEIsSUFBSTtFQUNGLElBQUksSUFBSSxTQUFTLEtBQUssU0FBUyxDQUFDLENBQUMsT0FBTyxNQUFNO0dBQUUsT0FBTztHQUFTLE1BQU07RUFBSyxDQUFDO0VBQzVFLElBQUksS0FBSyxRQUFRLElBQUksRUFBRSxHQUFHLGVBQWUsS0FBSyxNQUFNO0VBQ3BELElBQUksS0FBSyxTQUFTLElBQUksRUFBRSxHQUFHLFlBQVksS0FBSyxPQUFPO0VBQ25ELE1BQU0sRUFBRSxPQUFPLFVBQVUsTUFBTTtFQUMvQixJQUFJLENBQUMsU0FBUyxPQUFPLFVBQVUsWUFBWSxRQUFRLEdBQUcsT0FBTztDQUMvRCxRQUFRLENBRVI7Q0FDQSxNQUFNLE1BQU0sS0FBSyxXQUFXLEtBQUssVUFBVTtDQUMzQyxJQUFJLE9BQU87Q0FDWCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUs7RUFDbkMsT0FBUSxPQUFPLEtBQUssSUFBSSxXQUFXLENBQUMsSUFBSztDQUMzQztDQUNBLE9BQU8sTUFBTyxLQUFLLElBQUksSUFBSSxJQUFJO0FBQ2pDO0FBZ0JBLE1BQU0sc0JBQXNCO0FBRTVCLFNBQVMsMkJBQTJCLEdBQWtDO0NBQ3BFLE9BQU87RUFDTCxJQUFJLEVBQUU7RUFDTixjQUFjLEVBQUU7RUFDaEIsY0FBYyxFQUFFO0VBQ2hCLFFBQVEsRUFBRTtFQUNWLFVBQVUsRUFBRSxXQUFXO0VBQ3ZCLFlBQVksRUFBRTtFQUNkLFlBQVksRUFBRSxhQUFhLEVBQUU7Q0FDL0I7QUFDRjtBQUVBLFNBQVMsbUJBQW1DO0NBQzFDLElBQUksT0FBTyxXQUFXLGFBQWEsT0FBTyxDQUFDO0NBQzNDLElBQUk7RUFDRixNQUFNLE1BQU0sT0FBTyxhQUFhLFFBQVEsbUJBQW1CO0VBQzNELE9BQU8sTUFBTyxLQUFLLE1BQU0sR0FBRyxJQUF1QixDQUFDO0NBQ3RELFFBQVE7RUFDTixPQUFPLENBQUM7Q0FDVjtBQUNGO0FBRUEsU0FBUyxrQkFBa0IsU0FBeUI7Q0FDbEQsSUFBSSxPQUFPLFdBQVcsYUFBYTtDQUNuQyxJQUFJO0VBQ0YsT0FBTyxhQUFhLFFBQVEscUJBQXFCLEtBQUssVUFBVSxPQUFPLENBQUM7Q0FDMUUsUUFBUSxDQUVSO0FBQ0Y7QUFFQSxPQUFPLGVBQWUscUJBQ3BCLE9BQ0EsT0FDOEI7Q0FDOUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLFVBQVUsT0FBTyxPQUFPO0NBQ2hELElBQUksS0FBSyxhQUFhO0VBQ3BCLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSw4QkFBOEIsT0FBTyxLQUFLO0dBQ2pFLElBQUksVUFBVSxPQUFPLDJCQUEyQixRQUFRO0VBQzFELFFBQVEsQ0FFUjtDQUNGO0NBQ0EsSUFBSTtFQUNGLE1BQU0sRUFBRSxNQUFNLFVBQVUsTUFBTyxTQUM1QixLQUFLLFNBQVMsQ0FBQyxDQUNmLE9BQU8sMEVBQTBFLENBQUMsQ0FDbEYsR0FDQyx1QkFBdUIsTUFBTSxtQkFBbUIsTUFBTSx3QkFBd0IsTUFBTSxtQkFBbUIsTUFBTSxFQUMvRyxDQUFDLENBQ0EsWUFBWTtFQUNmLElBQUksQ0FBQyxTQUFTLE1BQU0sT0FBTztDQUM3QixRQUFRLENBRVI7Q0FFQSxNQUFNLFFBQVEsaUJBQWlCO0NBQy9CLE9BQ0UsTUFBTSxNQUNILE1BQ0UsRUFBRSxpQkFBaUIsU0FBUyxFQUFFLGlCQUFpQixTQUMvQyxFQUFFLGlCQUFpQixTQUFTLEVBQUUsaUJBQWlCLEtBQ3BELEtBQUs7QUFFVDtBQUVBLE9BQU8sZUFBZSxrQkFDcEIsYUFDQSxhQUNBLFVBQVUsWUFDYTtDQUN2QixNQUFNLE1BQU0sSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0NBQ25DLE1BQU0sV0FBVyxNQUFNLHFCQUFxQixhQUFhLFdBQVc7Q0FDcEUsSUFBSSxVQUFVO0VBQ1osSUFBSSxTQUFTLFdBQVcsYUFBYSxTQUFTLGlCQUFpQixhQUFhO0dBQzFFLE9BQU8sb0JBQW9CLGFBQWEsV0FBVztFQUNyRDtFQUNBLE9BQU87Q0FDVDtDQUVBLElBQUksS0FBSyxhQUFhLFFBQVEsYUFBYTtFQUN6QyxJQUFJO0dBQ0YsTUFBTSxZQUFZLE1BQU0sMkJBQTJCLGFBQWEsYUFBYSxTQUFTLFNBQVM7R0FDL0YsTUFBTSxTQUFTLDJCQUEyQixTQUFTO0dBQ25ELE1BQU0sUUFBUSxpQkFBaUIsQ0FBQyxDQUFDLFFBQVEsTUFBTSxFQUFFLE9BQU8sT0FBTyxFQUFFO0dBQ2pFLGtCQUFrQixDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7R0FDcEMsT0FBTztFQUNULFFBQVEsQ0FFUjtDQUNGO0NBRUEsSUFBSTtFQUNGLE1BQU0sRUFBRSxNQUFNLFVBQVUsTUFBTyxTQUM1QixLQUFLLFNBQVMsQ0FBQyxDQUNmLE9BQU87R0FDTixjQUFjO0dBQ2QsY0FBYztHQUNkLFFBQVE7R0FDUixVQUFVO0VBQ1osQ0FBQyxDQUFDLENBQ0QsT0FBTyxDQUFDLENBQ1IsWUFBWTtFQUNmLElBQUksQ0FBQyxTQUFTLE1BQU07R0FDbEIsTUFBTSxRQUFRLGlCQUFpQixDQUFDLENBQUMsUUFBUSxNQUFNLEVBQUUsT0FBTyxLQUFLLEVBQUU7R0FDL0Qsa0JBQWtCLENBQUMsTUFBc0IsR0FBRyxLQUFLLENBQUM7R0FDbEQsT0FBTztFQUNUO0NBQ0YsUUFBUSxDQUVSO0NBRUEsTUFBTSxTQUF1QjtFQUMzQixJQUFJLHFCQUFxQixhQUFhLFdBQVc7RUFDakQsY0FBYztFQUNkLGNBQWM7RUFDZCxRQUFRO0VBQ1IsVUFBVTtFQUNWLFlBQVk7RUFDWixZQUFZO0NBQ2Q7Q0FDQSxNQUFNLFFBQVEsaUJBQWlCLENBQUMsQ0FBQyxRQUFRLE1BQU0sRUFBRSxPQUFPLE9BQU8sRUFBRTtDQUNqRSxrQkFBa0IsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO0NBQ3BDLE9BQU87QUFDVDtBQUVBLE9BQU8sZUFBZSxvQkFDcEIsZUFDQSxhQUN1QjtDQUN2QixNQUFNLE1BQU0sSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0NBQ25DLE1BQU0sY0FBYyxxQkFBcUIsZUFBZSxXQUFXO0NBQ25FLElBQUksS0FBSyxhQUFhO0VBQ3BCLElBQUk7R0FDRixNQUFNLDRCQUE0QixhQUFhLFVBQVU7RUFDM0QsUUFBUSxDQUVSO0NBQ0Y7Q0FDQSxJQUFJO0VBQ0YsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFPLFNBQzVCLEtBQUssU0FBUyxDQUFDLENBQ2YsT0FBTztHQUFFLFFBQVE7R0FBWSxZQUFZO0VBQUksQ0FBQyxDQUFDLENBQy9DLEdBQ0MsdUJBQXVCLFlBQVksbUJBQW1CLGNBQWMsd0JBQXdCLGNBQWMsbUJBQW1CLFlBQVksRUFDM0ksQ0FBQyxDQUNBLE9BQU8sQ0FBQyxDQUNSLFlBQVk7RUFDZixJQUFJLENBQUMsU0FBUyxNQUFNO0dBQ2xCLE1BQU0sUUFBUSxpQkFBaUIsQ0FBQyxDQUFDLFFBQVEsTUFBTSxFQUFFLE9BQU8sS0FBSyxFQUFFO0dBQy9ELGtCQUFrQixDQUFDLE1BQXNCLEdBQUcsS0FBSyxDQUFDO0dBQ2xELE9BQU87RUFDVDtDQUNGLFFBQVEsQ0FFUjtDQUVBLE1BQU0sUUFBUSxpQkFBaUI7Q0FDL0IsTUFBTSxNQUFNLE1BQU0sV0FDZixNQUNFLEVBQUUsaUJBQWlCLGVBQWUsRUFBRSxpQkFBaUIsaUJBQ3JELEVBQUUsaUJBQWlCLGlCQUFpQixFQUFFLGlCQUFpQixXQUM1RDtDQUNBLElBQUksT0FBTyxHQUFHO0VBQ1osTUFBTSxPQUFPO0dBQUUsR0FBRyxNQUFNO0dBQU0sUUFBUTtHQUFZLFlBQVk7RUFBSTtFQUNsRSxrQkFBa0IsS0FBSztFQUN2QixPQUFPLE1BQU07Q0FDZjtDQUNBLE1BQU0sVUFBd0I7RUFDNUIsSUFBSTtFQUNKLGNBQWM7RUFDZCxjQUFjO0VBQ2QsUUFBUTtFQUNSLFVBQVU7RUFDVixZQUFZO0VBQ1osWUFBWTtDQUNkO0NBQ0Esa0JBQWtCLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztDQUNyQyxPQUFPO0FBQ1Q7QUFFQSxPQUFPLGVBQWUsc0JBQ3BCLGVBQ0EsYUFDdUI7Q0FDdkIsTUFBTSxNQUFNLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtDQUNuQyxNQUFNLFdBQVcsTUFBTSxxQkFBcUIsZUFBZSxXQUFXO0NBQ3RFLE1BQU0sY0FBYyxxQkFBcUIsZUFBZSxXQUFXO0NBQ25FLElBQUksS0FBSyxhQUFhO0VBQ3BCLElBQUk7R0FDRixJQUFJLFVBQVU7SUFDWixNQUFNLDRCQUE0QixhQUFhLFNBQVM7R0FDMUQsT0FBTyxJQUFJLEtBQUssWUFBWSxRQUFRLGVBQWU7SUFDakQsTUFBTSwyQkFBMkIsZUFBZSxhQUFhLFlBQVksU0FBUztHQUNwRjtFQUNGLFFBQVEsQ0FFUjtDQUNGO0NBQ0EsSUFBSTtFQUNGLElBQUksVUFBVTtHQUNaLE1BQU0sRUFBRSxNQUFNLFVBQVUsTUFBTyxTQUM1QixLQUFLLFNBQVMsQ0FBQyxDQUNmLE9BQU87SUFBRSxRQUFRO0lBQVcsWUFBWTtHQUFJLENBQUMsQ0FBQyxDQUM5QyxHQUFHLE1BQU0sU0FBUyxFQUFFLENBQUMsQ0FDckIsT0FBTyxDQUFDLENBQ1IsWUFBWTtHQUNmLElBQUksQ0FBQyxTQUFTLE1BQU0sT0FBTztFQUM3QixPQUFPO0dBQ0wsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFPLFNBQzVCLEtBQUssU0FBUyxDQUFDLENBQ2YsT0FBTztJQUNOLGNBQWM7SUFDZCxjQUFjO0lBQ2QsUUFBUTtJQUNSLFVBQVU7R0FDWixDQUFDLENBQUMsQ0FDRCxPQUFPLENBQUMsQ0FDUixZQUFZO0dBQ2YsSUFBSSxDQUFDLFNBQVMsTUFBTSxPQUFPO0VBQzdCO0NBQ0YsUUFBUSxDQUVSO0NBRUEsTUFBTSxRQUFRLGlCQUFpQixDQUFDLENBQUMsUUFDOUIsTUFDQyxFQUNHLEVBQUUsaUJBQWlCLGlCQUFpQixFQUFFLGlCQUFpQixlQUN2RCxFQUFFLGlCQUFpQixlQUFlLEVBQUUsaUJBQWlCLGNBRTVEO0NBQ0EsTUFBTSxVQUF3QjtFQUM1QixJQUFJLFVBQVUsTUFBTTtFQUNwQixjQUFjO0VBQ2QsY0FBYztFQUNkLFFBQVE7RUFDUixVQUFVLFVBQVUsWUFBWTtFQUNoQyxZQUFZLFVBQVUsY0FBYztFQUNwQyxZQUFZO0NBQ2Q7Q0FDQSxrQkFBa0IsQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO0NBQ3JDLE9BQU87QUFDVDtBQUVBLE9BQU8sZUFBZSx1QkFDcEIsZUFDQSxhQUNlO0NBQ2YsTUFBTSxjQUFjLHFCQUFxQixlQUFlLFdBQVc7Q0FDbkUsSUFBSSxLQUFLLGFBQWE7RUFDcEIsSUFBSTtHQUNGLE1BQU0sc0JBQXNCLFdBQVc7RUFDekMsUUFBUSxDQUVSO0NBQ0Y7Q0FDQSxJQUFJO0VBQ0YsTUFBTyxTQUNKLEtBQUssU0FBUyxDQUFDLENBQ2YsT0FBTyxDQUFDLENBQ1IsR0FDQyx1QkFBdUIsY0FBYyxtQkFBbUIsWUFBWSx3QkFBd0IsWUFBWSxtQkFBbUIsY0FBYyxFQUMzSTtDQUNKLFFBQVEsQ0FFUjtDQUNBLE1BQU0sUUFBUSxpQkFBaUIsQ0FBQyxDQUFDLFFBQzlCLE1BQ0MsRUFDRyxFQUFFLGlCQUFpQixpQkFBaUIsRUFBRSxpQkFBaUIsZUFDdkQsRUFBRSxpQkFBaUIsZUFBZSxFQUFFLGlCQUFpQixjQUU1RDtDQUNBLGtCQUFrQixLQUFLO0FBQ3pCO0FBRUEsT0FBTyxlQUFlLHdCQUF3QixRQUF5QztDQUNyRixJQUFJLENBQUMsUUFBUSxPQUFPLENBQUM7Q0FDckIsSUFBSSxLQUFLLGFBQWEsUUFBUSxRQUFRO0VBQ3BDLElBQUk7R0FDRixNQUFNLFlBQVksTUFBTSxvQkFBb0IsTUFBTTtHQUNsRCxJQUFJLFVBQVUsU0FBUyxHQUFHO0lBQ3hCLE9BQU8sVUFBVSxJQUFJLDBCQUEwQjtHQUNqRDtFQUNGLFFBQVEsQ0FFUjtDQUNGO0NBQ0EsSUFBSTtFQUNGLE1BQU0sRUFBRSxNQUFNLFVBQVUsTUFBTyxTQUM1QixLQUFLLFNBQVMsQ0FBQyxDQUNmLE9BQU8sMEVBQTBFLENBQUMsQ0FDbEYsR0FBRyxtQkFBbUIsT0FBTyxtQkFBbUIsUUFBUSxDQUFDLENBQ3pELE1BQU0sY0FBYyxFQUFFLFdBQVcsTUFBTSxDQUFDO0VBQzNDLElBQUksQ0FBQyxTQUFTLFFBQVEsS0FBSyxTQUFTLEdBQUcsT0FBTztDQUNoRCxRQUFRLENBRVI7Q0FDQSxPQUFPLGlCQUFpQixDQUFDLENBQUMsUUFDdkIsTUFBTSxFQUFFLGlCQUFpQixVQUFVLEVBQUUsaUJBQWlCLE1BQ3pEO0FBQ0Y7QUFFQSxPQUFPLGVBQWUsb0JBQ3BCLGVBQ0EsYUFDQSxTQUNlO0NBQ2YsTUFBTSxNQUFNLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtDQUNuQyxNQUFNLGNBQWMscUJBQXFCLGVBQWUsV0FBVztDQUNuRSxJQUFJLEtBQUssYUFBYTtFQUNwQixJQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sOEJBQThCLGVBQWUsV0FBVztHQUMvRSxJQUFJLFVBQVU7SUFDWixNQUFNLDRCQUE0QixhQUFhLFNBQVMsUUFBUSxPQUFPO0dBQ3pFO0VBQ0YsUUFBUSxDQUVSO0NBQ0Y7Q0FDQSxJQUFJO0VBQ0YsTUFBTyxTQUNKLEtBQUssU0FBUyxDQUFDLENBQ2YsT0FBTztHQUFFLFVBQVU7R0FBUyxZQUFZO0VBQUksQ0FBQyxDQUFDLENBQzlDLEdBQ0MsdUJBQXVCLGNBQWMsbUJBQW1CLFlBQVksd0JBQXdCLFlBQVksbUJBQW1CLGNBQWMsRUFDM0k7Q0FDSixRQUFRLENBRVI7Q0FDQSxNQUFNLFFBQVEsaUJBQWlCO0NBQy9CLE1BQU0sTUFBTSxNQUFNLFdBQ2YsTUFDRSxFQUFFLGlCQUFpQixpQkFBaUIsRUFBRSxpQkFBaUIsZUFDdkQsRUFBRSxpQkFBaUIsZUFBZSxFQUFFLGlCQUFpQixhQUMxRDtDQUNBLElBQUksT0FBTyxHQUFHO0VBQ1osTUFBTSxPQUFPO0dBQUUsR0FBRyxNQUFNO0dBQU0sVUFBVTtHQUFTLFlBQVk7RUFBSTtFQUNqRSxrQkFBa0IsS0FBSztDQUN6QjtBQUNGO0FBU0EsT0FBTyxlQUFlLHlCQUF5QixRQUE4QztDQUMzRixNQUFNLFVBQVUsTUFBTSx3QkFBd0IsTUFBTTtDQUNwRCxJQUFJLFFBQVEsV0FBVyxHQUFHLE9BQU8sQ0FBQztDQUVsQyxNQUFNLFVBQVUsQ0FDZCxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUssTUFBTyxFQUFFLGlCQUFpQixTQUFTLEVBQUUsZUFBZSxFQUFFLFlBQWEsQ0FBQyxDQUM5RjtDQUVBLElBQUksYUFBYSxJQUFJLElBQWlFO0NBQ3RGLElBQUk7RUFDRixNQUFNLEVBQUUsTUFBTSxhQUFhLE1BQU0sU0FDOUIsS0FBSyxVQUFVLENBQUMsQ0FDaEIsT0FBTyw4QkFBOEIsQ0FBQyxDQUN0QyxHQUFHLE1BQU0sT0FBTztFQUNuQixhQUFhLElBQUksS0FDZCxZQUFZLENBQUMsRUFBQyxDQUFFLEtBQUssTUFBTSxDQUMxQixFQUFFLElBQ0Y7R0FBRSxjQUFjLEVBQUU7R0FBYyxZQUFZLEVBQUU7RUFBVyxDQUMzRCxDQUFDLENBQ0g7Q0FDRixRQUFRLENBRVI7Q0FFQSxPQUFPLFFBQVEsS0FBSyxNQUFNO0VBQ3hCLE1BQU0sU0FBUyxFQUFFLGlCQUFpQixTQUFTLEVBQUUsZUFBZSxFQUFFO0VBQzlELE1BQU0sSUFBSSxXQUFXLElBQUksTUFBTTtFQUMvQixPQUFPO0dBQ0wsR0FBRztHQUNIO0dBQ0EsVUFBVSxHQUFHLGdCQUFnQixVQUFVLE9BQU8sTUFBTSxHQUFHLENBQUM7R0FDeEQsWUFBWSxHQUFHLGNBQWM7R0FDN0IsV0FBVyxFQUFFLGlCQUFpQixTQUFTLGFBQWE7RUFDdEQ7Q0FDRixDQUFDO0FBQ0g7QUFNQSxPQUFPLGVBQWUsb0JBQW9CLFFBQVEsSUFBd0I7Q0FDeEUsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLFNBQzNCLEtBQUssVUFBVSxDQUFDLENBQ2hCLE9BQU8sb0JBQW9CLENBQUMsQ0FDNUIsR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUNsQixNQUFNLGFBQWEsRUFBRSxXQUFXLE1BQU0sQ0FBQyxDQUFDLENBQ3hDLE1BQU0sS0FBSztDQUNkLElBQUksT0FBTyxNQUFNO0NBQ2pCLE9BQU8sUUFBUSxDQUFDO0FBQ2xCOztBQUdBLE9BQU8sZUFBZSxrQkFBa0IsS0FBNkM7Q0FDbkYsTUFBTSxFQUFFLE1BQU0sWUFBWSxNQUFNLFNBQzdCLEtBQUssVUFBVSxDQUFDLENBQ2hCLE9BQU8sSUFBSSxDQUFDLENBQ1osR0FBRyxPQUFPLElBQUksWUFBWSxDQUFDLENBQUMsQ0FDNUIsWUFBWTtDQUNmLElBQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQztDQUN0QixNQUFNLEVBQUUsU0FBUyxNQUFNLFNBQ3BCLEtBQUssZUFBZSxDQUFDLENBQ3JCLE9BQU8sU0FBUyxDQUFDLENBQ2pCLEdBQUcsY0FBYyxRQUFRLEVBQUU7Q0FDOUIsT0FBTyxRQUFRLENBQUM7QUFDbEI7QUFnQkEsT0FBTyxlQUFlLGlCQUFpQixRQUE0QztDQUNqRixNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sU0FDM0IsS0FBSyxlQUFlLENBQUMsQ0FDckIsT0FBTyx1RUFBdUUsQ0FBQyxDQUMvRSxHQUFHLFdBQVcsTUFBTSxDQUFDLENBQ3JCLE1BQU0sY0FBYyxFQUFFLFdBQVcsTUFBTSxDQUFDLENBQUMsQ0FDekMsTUFBTSxHQUFHO0NBQ1osSUFBSSxPQUFPLE1BQU07Q0FDakIsTUFBTSxPQUFPLFFBQVEsQ0FBQztDQUN0QixJQUFJLEtBQUssV0FBVyxHQUFHLE9BQU8sQ0FBQztDQUUvQixNQUFNLFdBQVcsQ0FBQyxHQUFHLElBQUksSUFBSSxLQUFLLEtBQUssTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDLFFBQVEsTUFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0NBQ3pGLE1BQU0sRUFBRSxNQUFNLGFBQWEsU0FBUyxTQUNoQyxNQUFNLFNBQVMsS0FBSyxVQUFVLENBQUMsQ0FBQyxPQUFPLGtCQUFrQixDQUFDLENBQUMsR0FBRyxNQUFNLFFBQVEsSUFDNUUsRUFBRSxNQUFNLENBQUMsRUFBNEM7Q0FDekQsTUFBTSxXQUFXLElBQUksS0FBSyxZQUFZLENBQUMsRUFBQyxDQUFFLEtBQUssTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLFlBQVksQ0FBQyxDQUFDO0NBRTVFLE9BQU8sS0FBSyxLQUFLLE9BQU87RUFDdEIsR0FBRztFQUNILFlBQVksRUFBRSxXQUFXLFNBQVMsSUFBSSxFQUFFLFFBQVEsSUFBSSxTQUFTO0NBQy9ELEVBQUU7QUFDSjtBQUVBLE9BQU8sZUFBZSwyQkFBMkIsUUFBaUM7Q0FDaEYsTUFBTSxFQUFFLFVBQVUsTUFBTSxTQUNyQixLQUFLLGVBQWUsQ0FBQyxDQUNyQixPQUFPLE1BQU07RUFBRSxPQUFPO0VBQVMsTUFBTTtDQUFLLENBQUMsQ0FBQyxDQUM1QyxHQUFHLFdBQVcsTUFBTSxDQUFDLENBQ3JCLEdBQUcsV0FBVyxJQUFJO0NBQ3JCLE9BQU8sU0FBUztBQUNsQjtBQUVBLE9BQU8sZUFBZSxzQkFBc0IsUUFBZ0I7Q0FDMUQsTUFBTSxTQUNILEtBQUssZUFBZSxDQUFDLENBQ3JCLE9BQU8sRUFBRSxTQUFTLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQyxDQUM3QyxHQUFHLFdBQVcsTUFBTSxDQUFDLENBQ3JCLEdBQUcsV0FBVyxJQUFJO0FBQ3ZCO0FBYUEsTUFBTSxxQkFBcUI7QUFFM0IsU0FBUyxzQkFBcUQ7Q0FDNUQsSUFBSSxPQUFPLFdBQVcsYUFBYSxPQUFPLENBQUM7Q0FDM0MsSUFBSTtFQUNGLE1BQU0sTUFBTSxPQUFPLGFBQWEsUUFBUSxrQkFBa0I7RUFDMUQsT0FBTyxNQUFPLEtBQUssTUFBTSxHQUFHLElBQXNDLENBQUM7Q0FDckUsUUFBUTtFQUNOLE9BQU8sQ0FBQztDQUNWO0FBQ0Y7QUFFQSxTQUFTLGtCQUFrQixTQUF3QjtDQUNqRCxJQUFJLE9BQU8sV0FBVyxhQUFhO0NBQ25DLElBQUk7RUFDRixNQUFNLE1BQU0sb0JBQW9CO0VBQ2hDLElBQUksUUFBUSxNQUFNO0VBQ2xCLE9BQU8sYUFBYSxRQUFRLG9CQUFvQixLQUFLLFVBQVUsR0FBRyxDQUFDO0VBQ25FLE9BQU8sY0FBYyxJQUFJLFlBQVksdUJBQXVCLEVBQUUsUUFBUSxRQUFRLENBQUMsQ0FBQztDQUNsRixRQUFRLENBRVI7QUFDRjtBQUVBLE9BQU8sZUFBZSxpQkFBaUIsUUFBK0M7Q0FDcEYsSUFBSSxDQUFDLFFBQVEsT0FBTztDQUNwQixNQUFNLGNBQWMsb0JBQW9CLENBQUMsQ0FBQyxXQUFXOztDQUdyRCxJQUFJO0VBQ0YsTUFBTSxZQUFZLE1BQU0sd0JBQXdCLE1BQU07RUFDdEQsSUFBSSxXQUFXO0dBQ2IsTUFBTSxTQUF3QjtJQUM1QixJQUFJO0lBQ0osY0FDRyxPQUFPLFVBQVUsZ0JBQWdCLFlBQVksVUFBVSxZQUFZLEtBQUssS0FDekUsYUFBYSxnQkFDYjtJQUNGLFVBQ0csT0FBTyxVQUFVLGFBQWEsWUFBWSxVQUFVLFNBQVMsS0FBSyxLQUNuRSxhQUFhLFlBQ2I7SUFDRixLQUNHLE9BQU8sVUFBVSxRQUFRLFlBQVksVUFBVSxJQUFJLEtBQUssS0FDekQsYUFBYSxPQUNiO0lBQ0YsWUFDRyxPQUFPLFVBQVUsY0FBYyxZQUFZLFVBQVUsVUFBVSxLQUFLLEtBQ3JFLGFBQWEsY0FDYjtJQUNGLGFBQWEsYUFBYSxlQUFlO0dBQzNDO0dBQ0EsT0FBTztFQUNUO0NBQ0YsUUFBUSxDQUVSOztDQUdBLElBQUk7RUFDRixNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sU0FDM0IsS0FBSyxVQUFVLENBQUMsQ0FDaEIsT0FBTyxnREFBZ0QsQ0FBQyxDQUN4RCxHQUFHLE1BQU0sTUFBTSxDQUFDLENBQ2hCLFlBQVk7RUFDZixJQUFJLENBQUMsU0FBUyxNQUFNO0dBQ2xCLE9BQU87SUFDTCxHQUFHO0lBQ0gsVUFBVSxhQUFhLFlBQVk7SUFDbkMsWUFBWSxLQUFLLGNBQWMsYUFBYSxjQUFjO0dBQzVEO0VBQ0Y7Q0FDRixRQUFRLENBRVI7Q0FFQSxPQUFPO0FBQ1Q7O0FBYUEsT0FBTyxlQUFlLGdCQUFnQixRQUF1QztDQUMzRSxNQUFNLENBQUMsT0FBTyxPQUFPLFdBQVcsYUFBYSxNQUFNLFFBQVEsSUFBSTtFQUM3RCxTQUNHLEtBQUssT0FBTyxDQUFDLENBQ2IsT0FBTyxNQUFNO0dBQUUsT0FBTztHQUFTLE1BQU07RUFBSyxDQUFDLENBQUMsQ0FDNUMsR0FBRyxXQUFXLE1BQU0sQ0FBQyxDQUNyQixNQUFNLE1BQU0sVUFBVSxFQUFFLE9BQU8sRUFBRSxFQUFFO0VBQ3RDLFNBQ0csS0FBSyxPQUFPLENBQUMsQ0FDYixPQUFPLFNBQVMsQ0FBQyxDQUNqQixHQUFHLFdBQVcsTUFBTSxDQUFDLENBQ3JCLE1BQU0sTUFBTSxVQUFVLEVBQUUsTUFBTSxDQUFDLEVBQTJCLEVBQUU7RUFDL0QsU0FDRyxLQUFLLFNBQVMsQ0FBQyxDQUNmLE9BQU8sTUFBTTtHQUFFLE9BQU87R0FBUyxNQUFNO0VBQUssQ0FBQyxDQUFDLENBQzVDLEdBQUcsZUFBZSxNQUFNLENBQUMsQ0FDekIsTUFBTSxNQUFNLFVBQVUsRUFBRSxPQUFPLEVBQUUsRUFBRTtFQUN0Qyx3QkFBd0IsTUFBTTtDQUNoQyxDQUFDO0NBQ0QsTUFBTSxPQUFPLE1BQU0sUUFBUSxDQUFDO0NBQzVCLE1BQU0sUUFBUSxLQUFLLFFBQVEsTUFBTSxFQUFFLFlBQVksT0FBTyxDQUFDLENBQUM7Q0FDeEQsTUFBTSxRQUFRLEtBQUssUUFBUSxNQUFNLEVBQUUsWUFBWSxPQUFPLENBQUMsQ0FBQztDQUN4RCxPQUFPO0VBQ0wsT0FBTyxNQUFNLFNBQVM7RUFDdEI7RUFDQTtFQUNBLFlBQVk7RUFDWixZQUFZO0VBQ1osV0FBVyxVQUFVLFNBQVM7RUFDOUIsU0FBUyxVQUFVLFFBQVEsTUFBTSxFQUFFLFdBQVcsVUFBVSxDQUFDLENBQUM7Q0FDNUQ7QUFDRjtBQUVBLE9BQU8sZUFBZSxnQkFBZ0IsT0FNbkM7Q0FDRCxNQUFNLFlBQVksTUFBTSxhQUFhLEtBQUssQ0FBQyxDQUFDLE1BQU0sR0FBRyxHQUFHLEtBQUs7Q0FDN0QsTUFBTSxpQkFBaUIsTUFBTSxZQUFZLEdBQUUsQ0FDeEMsS0FBSyxDQUFDLENBQ04sUUFBUSxPQUFPLEVBQUUsQ0FBQyxDQUNsQixRQUFRLG9CQUFvQixFQUFFLENBQUMsQ0FDL0IsTUFBTSxHQUFHLEVBQUU7Q0FDZCxNQUFNLFdBQVcsTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDLE1BQU0sR0FBRyxHQUFHO0NBQzlDLE1BQU0sY0FBYyxNQUFNLFdBQVcsS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLEdBQUc7Q0FFeEQsTUFBTSxnQkFBZ0Isb0JBQW9CLENBQUMsQ0FBQyxNQUFNO0NBQ2xELE1BQU0sZUFBOEI7RUFDbEMsSUFBSSxNQUFNO0VBQ1YsY0FBYztFQUNkLFVBQVUsaUJBQWlCLGVBQWUsWUFBWTtFQUN0RCxLQUFLLFlBQVk7RUFDakIsWUFBWSxlQUFlO0VBQzNCLGFBQWEsZUFBZSxlQUFlO0NBQzdDO0NBQ0Esa0JBQWtCLFlBQVk7Q0FFOUIsSUFBSSxLQUFLLGFBQWEsUUFBUSxNQUFNLFFBQVE7RUFDMUMsSUFBSTtHQUNGLE1BQU0sMkJBQTJCLE1BQU0sUUFBUTtJQUM3QyxhQUFhO0lBQ2IsVUFBVTtJQUNWLEtBQUs7SUFDTCxXQUFXO0dBQ2IsQ0FBQztFQUNILFFBQVEsQ0FFUjtDQUNGO0NBRUEsSUFBSTtFQUNGLE1BQU0sU0FDSCxLQUFLLFVBQVUsQ0FBQyxDQUNoQixPQUFPO0dBQ04sY0FBYztHQUNkLEtBQUssWUFBWTtHQUNqQixZQUFZLGVBQWU7RUFDN0IsQ0FBQyxDQUFDLENBQ0QsR0FBRyxNQUFNLE1BQU0sTUFBTTtDQUMxQixRQUFRLENBRVI7QUFDRiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJzb2NpYWwudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc3VwYWJhc2UgfSBmcm9tIFwiQC9pbnRlZ3JhdGlvbnMvc3VwYWJhc2UvY2xpZW50XCI7XG5pbXBvcnQgeyBhdXRoIH0gZnJvbSBcIkAvbGliL2ZpcmViYXNlXCI7XG5pbXBvcnQge1xuICBnZXRDYW5vbmljYWxGcmllbmRJZCxcbiAgZ2V0RmlyZXN0b3JlRnJpZW5kc2hpcEJldHdlZW4sXG4gIGdldEZpcmVzdG9yZUZyaWVuZHMsXG4gIHNlbmRGaXJlc3RvcmVGcmllbmRSZXF1ZXN0LFxuICB1cGRhdGVGaXJlc3RvcmVGcmllbmRTdGF0dXMsXG4gIGRlbGV0ZUZpcmVzdG9yZUZyaWVuZCxcbiAgZ2V0RmlyZXN0b3JlVXNlclByb2ZpbGUsXG4gIHVwZGF0ZUZpcmVzdG9yZVVzZXJQcm9maWxlLFxuICB0eXBlIEZpcmVzdG9yZUZyaWVuZCxcbn0gZnJvbSBcIkAvc2VydmljZXMvZmlyZXN0b3JlU2VydmljZVwiO1xuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIGxpa2VzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbGlrZVBvc3QoaXRlbUlkOiBzdHJpbmcsIHVzZXJJZDogc3RyaW5nKSB7XG4gIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oXCJwb3N0X2xpa2VzXCIpLmluc2VydCh7IGl0ZW1faWQ6IGl0ZW1JZCwgdXNlcl9pZDogdXNlcklkIH0pO1xuICBpZiAoZXJyb3IgJiYgZXJyb3IuY29kZSAhPT0gXCIyMzUwNVwiKSB0aHJvdyBlcnJvcjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVubGlrZVBvc3QoaXRlbUlkOiBzdHJpbmcsIHVzZXJJZDogc3RyaW5nKSB7XG4gIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgLmZyb20oXCJwb3N0X2xpa2VzXCIpXG4gICAgLmRlbGV0ZSgpXG4gICAgLmVxKFwiaXRlbV9pZFwiLCBpdGVtSWQpXG4gICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpO1xuICBpZiAoZXJyb3IpIHRocm93IGVycm9yO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXNlckxpa2VkUG9zdChpdGVtSWQ6IHN0cmluZywgdXNlcklkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgIC5mcm9tKFwicG9zdF9saWtlc1wiKVxuICAgIC5zZWxlY3QoXCJpZFwiKVxuICAgIC5lcShcIml0ZW1faWRcIiwgaXRlbUlkKVxuICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcklkKVxuICAgIC5tYXliZVNpbmdsZSgpO1xuICByZXR1cm4gISFkYXRhO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UG9zdExpa2VDb3VudChpdGVtSWQ6IHN0cmluZyk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IHsgY291bnQgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgLmZyb20oXCJwb3N0X2xpa2VzXCIpXG4gICAgLnNlbGVjdChcImlkXCIsIHsgY291bnQ6IFwiZXhhY3RcIiwgaGVhZDogdHJ1ZSB9KVxuICAgIC5lcShcIml0ZW1faWRcIiwgaXRlbUlkKTtcbiAgcmV0dXJuIGNvdW50ID8/IDA7XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSByZXBvc3RzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZXBvc3RJdGVtKGl0ZW1JZDogc3RyaW5nLCB1c2VySWQ6IHN0cmluZykge1xuICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5mcm9tKFwicmVwb3N0c1wiKS5pbnNlcnQoeyBpdGVtX2lkOiBpdGVtSWQsIHVzZXJfaWQ6IHVzZXJJZCB9KTtcbiAgaWYgKGVycm9yICYmIGVycm9yLmNvZGUgIT09IFwiMjM1MDVcIikgdGhyb3cgZXJyb3I7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1bnJlcG9zdEl0ZW0oaXRlbUlkOiBzdHJpbmcsIHVzZXJJZDogc3RyaW5nKSB7XG4gIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgLmZyb20oXCJyZXBvc3RzXCIpXG4gICAgLmRlbGV0ZSgpXG4gICAgLmVxKFwiaXRlbV9pZFwiLCBpdGVtSWQpXG4gICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpO1xuICBpZiAoZXJyb3IpIHRocm93IGVycm9yO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXNlclJlcG9zdGVkKGl0ZW1JZDogc3RyaW5nLCB1c2VySWQ6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgLmZyb20oXCJyZXBvc3RzXCIpXG4gICAgLnNlbGVjdChcImlkXCIpXG4gICAgLmVxKFwiaXRlbV9pZFwiLCBpdGVtSWQpXG4gICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpXG4gICAgLm1heWJlU2luZ2xlKCk7XG4gIHJldHVybiAhIWRhdGE7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZXBvc3RDb3VudChpdGVtSWQ6IHN0cmluZyk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IHsgY291bnQgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgLmZyb20oXCJyZXBvc3RzXCIpXG4gICAgLnNlbGVjdChcImlkXCIsIHsgY291bnQ6IFwiZXhhY3RcIiwgaGVhZDogdHJ1ZSB9KVxuICAgIC5lcShcIml0ZW1faWRcIiwgaXRlbUlkKTtcbiAgcmV0dXJuIGNvdW50ID8/IDA7XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIGNvbW1lbnRzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG5cbmV4cG9ydCB0eXBlIENvbW1lbnQgPSB7XG4gIGlkOiBzdHJpbmc7XG4gIGl0ZW1faWQ6IHN0cmluZztcbiAgdXNlcl9pZDogc3RyaW5nO1xuICBwYXJlbnRfaWQ6IHN0cmluZyB8IG51bGw7XG4gIGJvZHk6IHN0cmluZztcbiAgY3JlYXRlZF9hdDogc3RyaW5nO1xuICBhdXRob3JOYW1lOiBzdHJpbmc7XG4gIGxpa2VDb3VudDogbnVtYmVyO1xuICB1c2VyTGlrZWQ6IGJvb2xlYW47XG59O1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29tbWVudHMoaXRlbUlkOiBzdHJpbmcsIGN1cnJlbnRVc2VySWQ/OiBzdHJpbmcpOiBQcm9taXNlPENvbW1lbnRbXT4ge1xuICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgIC5mcm9tKFwicG9zdF9jb21tZW50c1wiKVxuICAgIC5zZWxlY3QoXCJpZCwgaXRlbV9pZCwgdXNlcl9pZCwgcGFyZW50X2lkLCBib2R5LCBjcmVhdGVkX2F0XCIpXG4gICAgLmVxKFwiaXRlbV9pZFwiLCBpdGVtSWQpXG4gICAgLm9yZGVyKFwiY3JlYXRlZF9hdFwiLCB7IGFzY2VuZGluZzogdHJ1ZSB9KTtcbiAgaWYgKGVycm9yKSB0aHJvdyBlcnJvcjtcbiAgY29uc3Qgcm93cyA9IGRhdGEgPz8gW107XG4gIGlmIChyb3dzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIFtdO1xuXG4gIGNvbnN0IGlkcyA9IHJvd3MubWFwKChyKSA9PiByLmlkKTtcbiAgY29uc3QgYXV0aG9ySWRzID0gWy4uLm5ldyBTZXQocm93cy5tYXAoKHIpID0+IHIudXNlcl9pZCkpXTtcblxuICBjb25zdCBbeyBkYXRhOiBwcm9maWxlcyB9LCB7IGRhdGE6IGxpa2VzIH1dID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgIHN1cGFiYXNlLmZyb20oXCJwcm9maWxlc1wiKS5zZWxlY3QoXCJpZCwgZGlzcGxheV9uYW1lXCIpLmluKFwiaWRcIiwgYXV0aG9ySWRzKSxcbiAgICBzdXBhYmFzZS5mcm9tKFwiY29tbWVudF9saWtlc1wiKS5zZWxlY3QoXCJjb21tZW50X2lkLCB1c2VyX2lkXCIpLmluKFwiY29tbWVudF9pZFwiLCBpZHMpLFxuICBdKTtcblxuICBjb25zdCBuYW1lQnlJZCA9IG5ldyBNYXAoKHByb2ZpbGVzID8/IFtdKS5tYXAoKHApID0+IFtwLmlkLCBwLmRpc3BsYXlfbmFtZV0pKTtcblxuICByZXR1cm4gcm93cy5tYXAoKHIpID0+IHtcbiAgICBjb25zdCByb3dMaWtlcyA9IChsaWtlcyA/PyBbXSkuZmlsdGVyKChsKSA9PiBsLmNvbW1lbnRfaWQgPT09IHIuaWQpO1xuICAgIHJldHVybiB7XG4gICAgICAuLi5yLFxuICAgICAgYXV0aG9yTmFtZTogbmFtZUJ5SWQuZ2V0KHIudXNlcl9pZCkgPz8gXCJBbm9ueW1vdXNcIixcbiAgICAgIGxpa2VDb3VudDogcm93TGlrZXMubGVuZ3RoLFxuICAgICAgdXNlckxpa2VkOiAhIWN1cnJlbnRVc2VySWQgJiYgcm93TGlrZXMuc29tZSgobCkgPT4gbC51c2VyX2lkID09PSBjdXJyZW50VXNlcklkKSxcbiAgICB9O1xuICB9KTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUNvbW1lbnQoXG4gIGl0ZW1JZDogc3RyaW5nLFxuICB1c2VySWQ6IHN0cmluZyxcbiAgYm9keTogc3RyaW5nLFxuICBwYXJlbnRJZD86IHN0cmluZyB8IG51bGwsXG4pIHtcbiAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbShcInBvc3RfY29tbWVudHNcIikuaW5zZXJ0KHtcbiAgICBpdGVtX2lkOiBpdGVtSWQsXG4gICAgdXNlcl9pZDogdXNlcklkLFxuICAgIGJvZHk6IGJvZHkudHJpbSgpLFxuICAgIHBhcmVudF9pZDogcGFyZW50SWQgPz8gbnVsbCxcbiAgfSk7XG4gIGlmIChlcnJvcikgdGhyb3cgZXJyb3I7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVDb21tZW50KGNvbW1lbnRJZDogc3RyaW5nKSB7XG4gIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oXCJwb3N0X2NvbW1lbnRzXCIpLmRlbGV0ZSgpLmVxKFwiaWRcIiwgY29tbWVudElkKTtcbiAgaWYgKGVycm9yKSB0aHJvdyBlcnJvcjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxpa2VDb21tZW50KGNvbW1lbnRJZDogc3RyaW5nLCB1c2VySWQ6IHN0cmluZykge1xuICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgIC5mcm9tKFwiY29tbWVudF9saWtlc1wiKVxuICAgIC5pbnNlcnQoeyBjb21tZW50X2lkOiBjb21tZW50SWQsIHVzZXJfaWQ6IHVzZXJJZCB9KTtcbiAgaWYgKGVycm9yICYmIGVycm9yLmNvZGUgIT09IFwiMjM1MDVcIikgdGhyb3cgZXJyb3I7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1bmxpa2VDb21tZW50KGNvbW1lbnRJZDogc3RyaW5nLCB1c2VySWQ6IHN0cmluZykge1xuICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgIC5mcm9tKFwiY29tbWVudF9saWtlc1wiKVxuICAgIC5kZWxldGUoKVxuICAgIC5lcShcImNvbW1lbnRfaWRcIiwgY29tbWVudElkKVxuICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcklkKTtcbiAgaWYgKGVycm9yKSB0aHJvdyBlcnJvcjtcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIGZvbGxvd3MgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZvbGxvd1VzZXIoZm9sbG93ZXJJZDogc3RyaW5nLCBmb2xsb3dlZUlkOiBzdHJpbmcpIHtcbiAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAuZnJvbShcImZvbGxvd3NcIilcbiAgICAuaW5zZXJ0KHsgZm9sbG93ZXJfaWQ6IGZvbGxvd2VySWQsIGZvbGxvd2VlX2lkOiBmb2xsb3dlZUlkIH0pO1xuICBpZiAoZXJyb3IgJiYgZXJyb3IuY29kZSAhPT0gXCIyMzUwNVwiKSB0aHJvdyBlcnJvcjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVuZm9sbG93VXNlcihmb2xsb3dlcklkOiBzdHJpbmcsIGZvbGxvd2VlSWQ6IHN0cmluZykge1xuICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgIC5mcm9tKFwiZm9sbG93c1wiKVxuICAgIC5kZWxldGUoKVxuICAgIC5lcShcImZvbGxvd2VyX2lkXCIsIGZvbGxvd2VySWQpXG4gICAgLmVxKFwiZm9sbG93ZWVfaWRcIiwgZm9sbG93ZWVJZCk7XG4gIGlmIChlcnJvcikgdGhyb3cgZXJyb3I7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmb2xsb3dCcmFuZChmb2xsb3dlcklkOiBzdHJpbmcsIGJyYW5kSWQ6IHN0cmluZykge1xuICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgIC5mcm9tKFwiZm9sbG93c1wiKVxuICAgIC5pbnNlcnQoeyBmb2xsb3dlcl9pZDogZm9sbG93ZXJJZCwgZm9sbG93ZWVfaWQ6IG51bGwsIGJyYW5kX2lkOiBicmFuZElkIH0gYXMgbmV2ZXIpO1xuICBpZiAoZXJyb3IgJiYgZXJyb3IuY29kZSAhPT0gXCIyMzUwNVwiKSB0aHJvdyBlcnJvcjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVuZm9sbG93QnJhbmQoZm9sbG93ZXJJZDogc3RyaW5nLCBicmFuZElkOiBzdHJpbmcpIHtcbiAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAuZnJvbShcImZvbGxvd3NcIilcbiAgICAuZGVsZXRlKClcbiAgICAuZXEoXCJmb2xsb3dlcl9pZFwiLCBmb2xsb3dlcklkKVxuICAgIC5lcShcImJyYW5kX2lkXCIsIGJyYW5kSWQpO1xuICBpZiAoZXJyb3IpIHRocm93IGVycm9yO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaXNGb2xsb3dpbmdCcmFuZChmb2xsb3dlcklkOiBzdHJpbmcsIGJyYW5kSWQ6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgLmZyb20oXCJmb2xsb3dzXCIpXG4gICAgLnNlbGVjdChcImlkXCIpXG4gICAgLmVxKFwiZm9sbG93ZXJfaWRcIiwgZm9sbG93ZXJJZClcbiAgICAuZXEoXCJicmFuZF9pZFwiLCBicmFuZElkKVxuICAgIC5tYXliZVNpbmdsZSgpO1xuICByZXR1cm4gISFkYXRhO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaXNGb2xsb3dpbmdVc2VyKGZvbGxvd2VySWQ6IHN0cmluZywgZm9sbG93ZWVJZDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XG4gIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAuZnJvbShcImZvbGxvd3NcIilcbiAgICAuc2VsZWN0KFwiaWRcIilcbiAgICAuZXEoXCJmb2xsb3dlcl9pZFwiLCBmb2xsb3dlcklkKVxuICAgIC5lcShcImZvbGxvd2VlX2lkXCIsIGZvbGxvd2VlSWQpXG4gICAgLm1heWJlU2luZ2xlKCk7XG4gIHJldHVybiAhIWRhdGE7XG59XG5cbi8qKiBpZHMgdGhlIHVzZXIgZm9sbG93czogcGVvcGxlICsgYnJhbmRzICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Rm9sbG93aW5nKFxuICBmb2xsb3dlcklkOiBzdHJpbmcsXG4pOiBQcm9taXNlPHsgdXNlcklkczogc3RyaW5nW107IGJyYW5kSWRzOiBzdHJpbmdbXSB9PiB7XG4gIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAuZnJvbShcImZvbGxvd3NcIilcbiAgICAuc2VsZWN0KFwiZm9sbG93ZWVfaWQsIGJyYW5kX2lkXCIpXG4gICAgLmVxKFwiZm9sbG93ZXJfaWRcIiwgZm9sbG93ZXJJZCk7XG4gIGNvbnN0IHJvd3MgPSBkYXRhID8/IFtdO1xuICByZXR1cm4ge1xuICAgIHVzZXJJZHM6IHJvd3MubWFwKChyKSA9PiByLmZvbGxvd2VlX2lkKS5maWx0ZXIoKHYpOiB2IGlzIHN0cmluZyA9PiAhIXYpLFxuICAgIGJyYW5kSWRzOiByb3dzLm1hcCgocikgPT4gci5icmFuZF9pZCkuZmlsdGVyKCh2KTogdiBpcyBzdHJpbmcgPT4gISF2KSxcbiAgfTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEZvbGxvd2VyQ291bnQob3B0czoge1xuICB1c2VySWQ/OiBzdHJpbmc7XG4gIGJyYW5kSWQ/OiBzdHJpbmc7XG59KTogUHJvbWlzZTxudW1iZXI+IHtcbiAgdHJ5IHtcbiAgICBsZXQgcSA9IHN1cGFiYXNlLmZyb20oXCJmb2xsb3dzXCIpLnNlbGVjdChcImlkXCIsIHsgY291bnQ6IFwiZXhhY3RcIiwgaGVhZDogdHJ1ZSB9KTtcbiAgICBpZiAob3B0cy51c2VySWQpIHEgPSBxLmVxKFwiZm9sbG93ZWVfaWRcIiwgb3B0cy51c2VySWQpO1xuICAgIGlmIChvcHRzLmJyYW5kSWQpIHEgPSBxLmVxKFwiYnJhbmRfaWRcIiwgb3B0cy5icmFuZElkKTtcbiAgICBjb25zdCB7IGNvdW50LCBlcnJvciB9ID0gYXdhaXQgcTtcbiAgICBpZiAoIWVycm9yICYmIHR5cGVvZiBjb3VudCA9PT0gXCJudW1iZXJcIiAmJiBjb3VudCA+IDApIHJldHVybiBjb3VudDtcbiAgfSBjYXRjaCB7XG4gICAgLy8gRmFsbGJhY2sgZm9yIG5vbi1VVUlEIGJyYW5kSWRcbiAgfVxuICBjb25zdCBrZXkgPSBvcHRzLmJyYW5kSWQgfHwgb3B0cy51c2VySWQgfHwgXCJzb3RcIjtcbiAgbGV0IGhhc2ggPSAwO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGtleS5sZW5ndGg7IGkrKykge1xuICAgIGhhc2ggPSAoaGFzaCAqIDMxICsga2V5LmNoYXJDb2RlQXQoaSkpIHwgMDtcbiAgfVxuICByZXR1cm4gMTQwICsgKE1hdGguYWJzKGhhc2gpICUgODYwKTtcbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tIGZyaWVuZHMgKG11dHVhbCBjb25uZWN0aW9uIHJlcXVlc3RzKSAtLS0tLS0tLS0tLS0tLS0tLS0gKi9cblxuZXhwb3J0IHR5cGUgRnJpZW5kc2hpcFN0YXR1cyA9IFwicGVuZGluZ1wiIHwgXCJhY2NlcHRlZFwiIHwgXCJibG9ja2VkXCI7XG5cbmV4cG9ydCB0eXBlIEZyaWVuZFJlY29yZCA9IHtcbiAgaWQ6IHN0cmluZztcbiAgcmVxdWVzdGVyX2lkOiBzdHJpbmc7XG4gIGFkZHJlc3NlZV9pZDogc3RyaW5nO1xuICBzdGF0dXM6IEZyaWVuZHNoaXBTdGF0dXM7XG4gIGJvbmRfdGFnOiBzdHJpbmc7XG4gIGNyZWF0ZWRfYXQ6IHN0cmluZztcbiAgdXBkYXRlZF9hdDogc3RyaW5nO1xufTtcblxuY29uc3QgRlJJRU5EU19TVE9SQUdFX0tFWSA9IFwic290X2ZyaWVuZHNfdGFibGVfdjFcIjtcblxuZnVuY3Rpb24gbWFwRmlyZXN0b3JlVG9GcmllbmRSZWNvcmQoZjogRmlyZXN0b3JlRnJpZW5kKTogRnJpZW5kUmVjb3JkIHtcbiAgcmV0dXJuIHtcbiAgICBpZDogZi5pZCxcbiAgICByZXF1ZXN0ZXJfaWQ6IGYucmVxdWVzdGVySWQsXG4gICAgYWRkcmVzc2VlX2lkOiBmLmFkZHJlc3NlZUlkLFxuICAgIHN0YXR1czogZi5zdGF0dXMsXG4gICAgYm9uZF90YWc6IGYuYm9uZFRhZyA/PyBcInN0cmFuZ2VyXCIsXG4gICAgY3JlYXRlZF9hdDogZi5jcmVhdGVkQXQsXG4gICAgdXBkYXRlZF9hdDogZi51cGRhdGVkQXQgPz8gZi5jcmVhdGVkQXQsXG4gIH07XG59XG5cbmZ1bmN0aW9uIHJlYWRMb2NhbEZyaWVuZHMoKTogRnJpZW5kUmVjb3JkW10ge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIFtdO1xuICB0cnkge1xuICAgIGNvbnN0IHJhdyA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShGUklFTkRTX1NUT1JBR0VfS0VZKTtcbiAgICByZXR1cm4gcmF3ID8gKEpTT04ucGFyc2UocmF3KSBhcyBGcmllbmRSZWNvcmRbXSkgOiBbXTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG59XG5cbmZ1bmN0aW9uIHdyaXRlTG9jYWxGcmllbmRzKHJlY29yZHM6IEZyaWVuZFJlY29yZFtdKSB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm47XG4gIHRyeSB7XG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKEZSSUVORFNfU1RPUkFHRV9LRVksIEpTT04uc3RyaW5naWZ5KHJlY29yZHMpKTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gaWdub3JlIHN0b3JhZ2UgZXJyb3JzXG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEZyaWVuZHNoaXBCZXR3ZWVuKFxuICB1c2VyQTogc3RyaW5nLFxuICB1c2VyQjogc3RyaW5nLFxuKTogUHJvbWlzZTxGcmllbmRSZWNvcmQgfCBudWxsPiB7XG4gIGlmICghdXNlckEgfHwgIXVzZXJCIHx8IHVzZXJBID09PSB1c2VyQikgcmV0dXJuIG51bGw7XG4gIGlmIChhdXRoLmN1cnJlbnRVc2VyKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGZzUmVjb3JkID0gYXdhaXQgZ2V0RmlyZXN0b3JlRnJpZW5kc2hpcEJldHdlZW4odXNlckEsIHVzZXJCKTtcbiAgICAgIGlmIChmc1JlY29yZCkgcmV0dXJuIG1hcEZpcmVzdG9yZVRvRnJpZW5kUmVjb3JkKGZzUmVjb3JkKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGNvbnRpbnVlIHRvIGZhbGxiYWNrXG4gICAgfVxuICB9XG4gIHRyeSB7XG4gICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgKHN1cGFiYXNlIGFzIGFueSlcbiAgICAgIC5mcm9tKFwiZnJpZW5kc1wiKVxuICAgICAgLnNlbGVjdChcImlkLCByZXF1ZXN0ZXJfaWQsIGFkZHJlc3NlZV9pZCwgc3RhdHVzLCBib25kX3RhZywgY3JlYXRlZF9hdCwgdXBkYXRlZF9hdFwiKVxuICAgICAgLm9yKFxuICAgICAgICBgYW5kKHJlcXVlc3Rlcl9pZC5lcS4ke3VzZXJBfSxhZGRyZXNzZWVfaWQuZXEuJHt1c2VyQn0pLGFuZChyZXF1ZXN0ZXJfaWQuZXEuJHt1c2VyQn0sYWRkcmVzc2VlX2lkLmVxLiR7dXNlckF9KWAsXG4gICAgICApXG4gICAgICAubWF5YmVTaW5nbGUoKTtcbiAgICBpZiAoIWVycm9yICYmIGRhdGEpIHJldHVybiBkYXRhIGFzIEZyaWVuZFJlY29yZDtcbiAgfSBjYXRjaCB7XG4gICAgLy8gZmFsbGJhY2sgdG8gbG9jYWwgc3RvcmVcbiAgfVxuXG4gIGNvbnN0IGxvY2FsID0gcmVhZExvY2FsRnJpZW5kcygpO1xuICByZXR1cm4gKFxuICAgIGxvY2FsLmZpbmQoXG4gICAgICAocikgPT5cbiAgICAgICAgKHIucmVxdWVzdGVyX2lkID09PSB1c2VyQSAmJiByLmFkZHJlc3NlZV9pZCA9PT0gdXNlckIpIHx8XG4gICAgICAgIChyLnJlcXVlc3Rlcl9pZCA9PT0gdXNlckIgJiYgci5hZGRyZXNzZWVfaWQgPT09IHVzZXJBKSxcbiAgICApID8/IG51bGxcbiAgKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlbmRGcmllbmRSZXF1ZXN0KFxuICByZXF1ZXN0ZXJJZDogc3RyaW5nLFxuICBhZGRyZXNzZWVJZDogc3RyaW5nLFxuICBib25kVGFnID0gXCJzdHJhbmdlclwiLFxuKTogUHJvbWlzZTxGcmllbmRSZWNvcmQ+IHtcbiAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICBjb25zdCBleGlzdGluZyA9IGF3YWl0IGdldEZyaWVuZHNoaXBCZXR3ZWVuKHJlcXVlc3RlcklkLCBhZGRyZXNzZWVJZCk7XG4gIGlmIChleGlzdGluZykge1xuICAgIGlmIChleGlzdGluZy5zdGF0dXMgPT09IFwicGVuZGluZ1wiICYmIGV4aXN0aW5nLmFkZHJlc3NlZV9pZCA9PT0gcmVxdWVzdGVySWQpIHtcbiAgICAgIHJldHVybiBhY2NlcHRGcmllbmRSZXF1ZXN0KHJlcXVlc3RlcklkLCBhZGRyZXNzZWVJZCk7XG4gICAgfVxuICAgIHJldHVybiBleGlzdGluZztcbiAgfVxuXG4gIGlmIChhdXRoLmN1cnJlbnRVc2VyPy51aWQgPT09IHJlcXVlc3RlcklkKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGZzQ3JlYXRlZCA9IGF3YWl0IHNlbmRGaXJlc3RvcmVGcmllbmRSZXF1ZXN0KHJlcXVlc3RlcklkLCBhZGRyZXNzZWVJZCwgYm9uZFRhZywgXCJwZW5kaW5nXCIpO1xuICAgICAgY29uc3QgbWFwcGVkID0gbWFwRmlyZXN0b3JlVG9GcmllbmRSZWNvcmQoZnNDcmVhdGVkKTtcbiAgICAgIGNvbnN0IGxvY2FsID0gcmVhZExvY2FsRnJpZW5kcygpLmZpbHRlcigocikgPT4gci5pZCAhPT0gbWFwcGVkLmlkKTtcbiAgICAgIHdyaXRlTG9jYWxGcmllbmRzKFttYXBwZWQsIC4uLmxvY2FsXSk7XG4gICAgICByZXR1cm4gbWFwcGVkO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gZmFsbGJhY2tcbiAgICB9XG4gIH1cblxuICB0cnkge1xuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IChzdXBhYmFzZSBhcyBhbnkpXG4gICAgICAuZnJvbShcImZyaWVuZHNcIilcbiAgICAgIC5pbnNlcnQoe1xuICAgICAgICByZXF1ZXN0ZXJfaWQ6IHJlcXVlc3RlcklkLFxuICAgICAgICBhZGRyZXNzZWVfaWQ6IGFkZHJlc3NlZUlkLFxuICAgICAgICBzdGF0dXM6IFwicGVuZGluZ1wiLFxuICAgICAgICBib25kX3RhZzogYm9uZFRhZyxcbiAgICAgIH0pXG4gICAgICAuc2VsZWN0KClcbiAgICAgIC5tYXliZVNpbmdsZSgpO1xuICAgIGlmICghZXJyb3IgJiYgZGF0YSkge1xuICAgICAgY29uc3QgbG9jYWwgPSByZWFkTG9jYWxGcmllbmRzKCkuZmlsdGVyKChyKSA9PiByLmlkICE9PSBkYXRhLmlkKTtcbiAgICAgIHdyaXRlTG9jYWxGcmllbmRzKFtkYXRhIGFzIEZyaWVuZFJlY29yZCwgLi4ubG9jYWxdKTtcbiAgICAgIHJldHVybiBkYXRhIGFzIEZyaWVuZFJlY29yZDtcbiAgICB9XG4gIH0gY2F0Y2gge1xuICAgIC8vIGZhbGxiYWNrIHRvIGxvY2FsIHN0b3JlXG4gIH1cblxuICBjb25zdCByZWNvcmQ6IEZyaWVuZFJlY29yZCA9IHtcbiAgICBpZDogZ2V0Q2Fub25pY2FsRnJpZW5kSWQocmVxdWVzdGVySWQsIGFkZHJlc3NlZUlkKSxcbiAgICByZXF1ZXN0ZXJfaWQ6IHJlcXVlc3RlcklkLFxuICAgIGFkZHJlc3NlZV9pZDogYWRkcmVzc2VlSWQsXG4gICAgc3RhdHVzOiBcInBlbmRpbmdcIixcbiAgICBib25kX3RhZzogYm9uZFRhZyxcbiAgICBjcmVhdGVkX2F0OiBub3csXG4gICAgdXBkYXRlZF9hdDogbm93LFxuICB9O1xuICBjb25zdCBsb2NhbCA9IHJlYWRMb2NhbEZyaWVuZHMoKS5maWx0ZXIoKHIpID0+IHIuaWQgIT09IHJlY29yZC5pZCk7XG4gIHdyaXRlTG9jYWxGcmllbmRzKFtyZWNvcmQsIC4uLmxvY2FsXSk7XG4gIHJldHVybiByZWNvcmQ7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhY2NlcHRGcmllbmRSZXF1ZXN0KFxuICBjdXJyZW50VXNlcklkOiBzdHJpbmcsXG4gIG90aGVyVXNlcklkOiBzdHJpbmcsXG4pOiBQcm9taXNlPEZyaWVuZFJlY29yZD4ge1xuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gIGNvbnN0IGNhbm9uaWNhbElkID0gZ2V0Q2Fub25pY2FsRnJpZW5kSWQoY3VycmVudFVzZXJJZCwgb3RoZXJVc2VySWQpO1xuICBpZiAoYXV0aC5jdXJyZW50VXNlcikge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCB1cGRhdGVGaXJlc3RvcmVGcmllbmRTdGF0dXMoY2Fub25pY2FsSWQsIFwiYWNjZXB0ZWRcIik7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBmYWxsYmFja1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IChzdXBhYmFzZSBhcyBhbnkpXG4gICAgICAuZnJvbShcImZyaWVuZHNcIilcbiAgICAgIC51cGRhdGUoeyBzdGF0dXM6IFwiYWNjZXB0ZWRcIiwgdXBkYXRlZF9hdDogbm93IH0pXG4gICAgICAub3IoXG4gICAgICAgIGBhbmQocmVxdWVzdGVyX2lkLmVxLiR7b3RoZXJVc2VySWR9LGFkZHJlc3NlZV9pZC5lcS4ke2N1cnJlbnRVc2VySWR9KSxhbmQocmVxdWVzdGVyX2lkLmVxLiR7Y3VycmVudFVzZXJJZH0sYWRkcmVzc2VlX2lkLmVxLiR7b3RoZXJVc2VySWR9KWAsXG4gICAgICApXG4gICAgICAuc2VsZWN0KClcbiAgICAgIC5tYXliZVNpbmdsZSgpO1xuICAgIGlmICghZXJyb3IgJiYgZGF0YSkge1xuICAgICAgY29uc3QgbG9jYWwgPSByZWFkTG9jYWxGcmllbmRzKCkuZmlsdGVyKChyKSA9PiByLmlkICE9PSBkYXRhLmlkKTtcbiAgICAgIHdyaXRlTG9jYWxGcmllbmRzKFtkYXRhIGFzIEZyaWVuZFJlY29yZCwgLi4ubG9jYWxdKTtcbiAgICAgIHJldHVybiBkYXRhIGFzIEZyaWVuZFJlY29yZDtcbiAgICB9XG4gIH0gY2F0Y2gge1xuICAgIC8vIGZhbGxiYWNrXG4gIH1cblxuICBjb25zdCBsb2NhbCA9IHJlYWRMb2NhbEZyaWVuZHMoKTtcbiAgY29uc3QgaWR4ID0gbG9jYWwuZmluZEluZGV4KFxuICAgIChyKSA9PlxuICAgICAgKHIucmVxdWVzdGVyX2lkID09PSBvdGhlclVzZXJJZCAmJiByLmFkZHJlc3NlZV9pZCA9PT0gY3VycmVudFVzZXJJZCkgfHxcbiAgICAgIChyLnJlcXVlc3Rlcl9pZCA9PT0gY3VycmVudFVzZXJJZCAmJiByLmFkZHJlc3NlZV9pZCA9PT0gb3RoZXJVc2VySWQpLFxuICApO1xuICBpZiAoaWR4ID49IDApIHtcbiAgICBsb2NhbFtpZHhdID0geyAuLi5sb2NhbFtpZHhdLCBzdGF0dXM6IFwiYWNjZXB0ZWRcIiwgdXBkYXRlZF9hdDogbm93IH07XG4gICAgd3JpdGVMb2NhbEZyaWVuZHMobG9jYWwpO1xuICAgIHJldHVybiBsb2NhbFtpZHhdO1xuICB9XG4gIGNvbnN0IGNyZWF0ZWQ6IEZyaWVuZFJlY29yZCA9IHtcbiAgICBpZDogY2Fub25pY2FsSWQsXG4gICAgcmVxdWVzdGVyX2lkOiBvdGhlclVzZXJJZCxcbiAgICBhZGRyZXNzZWVfaWQ6IGN1cnJlbnRVc2VySWQsXG4gICAgc3RhdHVzOiBcImFjY2VwdGVkXCIsXG4gICAgYm9uZF90YWc6IFwic3RyYW5nZXJcIixcbiAgICBjcmVhdGVkX2F0OiBub3csXG4gICAgdXBkYXRlZF9hdDogbm93LFxuICB9O1xuICB3cml0ZUxvY2FsRnJpZW5kcyhbY3JlYXRlZCwgLi4ubG9jYWxdKTtcbiAgcmV0dXJuIGNyZWF0ZWQ7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBibG9ja0ZyaWVuZENvbm5lY3Rpb24oXG4gIGN1cnJlbnRVc2VySWQ6IHN0cmluZyxcbiAgb3RoZXJVc2VySWQ6IHN0cmluZyxcbik6IFByb21pc2U8RnJpZW5kUmVjb3JkPiB7XG4gIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBnZXRGcmllbmRzaGlwQmV0d2VlbihjdXJyZW50VXNlcklkLCBvdGhlclVzZXJJZCk7XG4gIGNvbnN0IGNhbm9uaWNhbElkID0gZ2V0Q2Fub25pY2FsRnJpZW5kSWQoY3VycmVudFVzZXJJZCwgb3RoZXJVc2VySWQpO1xuICBpZiAoYXV0aC5jdXJyZW50VXNlcikge1xuICAgIHRyeSB7XG4gICAgICBpZiAoZXhpc3RpbmcpIHtcbiAgICAgICAgYXdhaXQgdXBkYXRlRmlyZXN0b3JlRnJpZW5kU3RhdHVzKGNhbm9uaWNhbElkLCBcImJsb2NrZWRcIik7XG4gICAgICB9IGVsc2UgaWYgKGF1dGguY3VycmVudFVzZXIudWlkID09PSBjdXJyZW50VXNlcklkKSB7XG4gICAgICAgIGF3YWl0IHNlbmRGaXJlc3RvcmVGcmllbmRSZXF1ZXN0KGN1cnJlbnRVc2VySWQsIG90aGVyVXNlcklkLCBcInN0cmFuZ2VyXCIsIFwiYmxvY2tlZFwiKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGZhbGxiYWNrXG4gICAgfVxuICB9XG4gIHRyeSB7XG4gICAgaWYgKGV4aXN0aW5nKSB7XG4gICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCAoc3VwYWJhc2UgYXMgYW55KVxuICAgICAgICAuZnJvbShcImZyaWVuZHNcIilcbiAgICAgICAgLnVwZGF0ZSh7IHN0YXR1czogXCJibG9ja2VkXCIsIHVwZGF0ZWRfYXQ6IG5vdyB9KVxuICAgICAgICAuZXEoXCJpZFwiLCBleGlzdGluZy5pZClcbiAgICAgICAgLnNlbGVjdCgpXG4gICAgICAgIC5tYXliZVNpbmdsZSgpO1xuICAgICAgaWYgKCFlcnJvciAmJiBkYXRhKSByZXR1cm4gZGF0YSBhcyBGcmllbmRSZWNvcmQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IChzdXBhYmFzZSBhcyBhbnkpXG4gICAgICAgIC5mcm9tKFwiZnJpZW5kc1wiKVxuICAgICAgICAuaW5zZXJ0KHtcbiAgICAgICAgICByZXF1ZXN0ZXJfaWQ6IGN1cnJlbnRVc2VySWQsXG4gICAgICAgICAgYWRkcmVzc2VlX2lkOiBvdGhlclVzZXJJZCxcbiAgICAgICAgICBzdGF0dXM6IFwiYmxvY2tlZFwiLFxuICAgICAgICAgIGJvbmRfdGFnOiBcInN0cmFuZ2VyXCIsXG4gICAgICAgIH0pXG4gICAgICAgIC5zZWxlY3QoKVxuICAgICAgICAubWF5YmVTaW5nbGUoKTtcbiAgICAgIGlmICghZXJyb3IgJiYgZGF0YSkgcmV0dXJuIGRhdGEgYXMgRnJpZW5kUmVjb3JkO1xuICAgIH1cbiAgfSBjYXRjaCB7XG4gICAgLy8gZmFsbGJhY2tcbiAgfVxuXG4gIGNvbnN0IGxvY2FsID0gcmVhZExvY2FsRnJpZW5kcygpLmZpbHRlcihcbiAgICAocikgPT5cbiAgICAgICEoXG4gICAgICAgIChyLnJlcXVlc3Rlcl9pZCA9PT0gY3VycmVudFVzZXJJZCAmJiByLmFkZHJlc3NlZV9pZCA9PT0gb3RoZXJVc2VySWQpIHx8XG4gICAgICAgIChyLnJlcXVlc3Rlcl9pZCA9PT0gb3RoZXJVc2VySWQgJiYgci5hZGRyZXNzZWVfaWQgPT09IGN1cnJlbnRVc2VySWQpXG4gICAgICApLFxuICApO1xuICBjb25zdCBibG9ja2VkOiBGcmllbmRSZWNvcmQgPSB7XG4gICAgaWQ6IGV4aXN0aW5nPy5pZCA/PyBjYW5vbmljYWxJZCxcbiAgICByZXF1ZXN0ZXJfaWQ6IGN1cnJlbnRVc2VySWQsXG4gICAgYWRkcmVzc2VlX2lkOiBvdGhlclVzZXJJZCxcbiAgICBzdGF0dXM6IFwiYmxvY2tlZFwiLFxuICAgIGJvbmRfdGFnOiBleGlzdGluZz8uYm9uZF90YWcgPz8gXCJzdHJhbmdlclwiLFxuICAgIGNyZWF0ZWRfYXQ6IGV4aXN0aW5nPy5jcmVhdGVkX2F0ID8/IG5vdyxcbiAgICB1cGRhdGVkX2F0OiBub3csXG4gIH07XG4gIHdyaXRlTG9jYWxGcmllbmRzKFtibG9ja2VkLCAuLi5sb2NhbF0pO1xuICByZXR1cm4gYmxvY2tlZDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlbW92ZUZyaWVuZENvbm5lY3Rpb24oXG4gIGN1cnJlbnRVc2VySWQ6IHN0cmluZyxcbiAgb3RoZXJVc2VySWQ6IHN0cmluZyxcbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBjYW5vbmljYWxJZCA9IGdldENhbm9uaWNhbEZyaWVuZElkKGN1cnJlbnRVc2VySWQsIG90aGVyVXNlcklkKTtcbiAgaWYgKGF1dGguY3VycmVudFVzZXIpIHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgZGVsZXRlRmlyZXN0b3JlRnJpZW5kKGNhbm9uaWNhbElkKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGZhbGxiYWNrXG4gICAgfVxuICB9XG4gIHRyeSB7XG4gICAgYXdhaXQgKHN1cGFiYXNlIGFzIGFueSlcbiAgICAgIC5mcm9tKFwiZnJpZW5kc1wiKVxuICAgICAgLmRlbGV0ZSgpXG4gICAgICAub3IoXG4gICAgICAgIGBhbmQocmVxdWVzdGVyX2lkLmVxLiR7Y3VycmVudFVzZXJJZH0sYWRkcmVzc2VlX2lkLmVxLiR7b3RoZXJVc2VySWR9KSxhbmQocmVxdWVzdGVyX2lkLmVxLiR7b3RoZXJVc2VySWR9LGFkZHJlc3NlZV9pZC5lcS4ke2N1cnJlbnRVc2VySWR9KWAsXG4gICAgICApO1xuICB9IGNhdGNoIHtcbiAgICAvLyBmYWxsYmFja1xuICB9XG4gIGNvbnN0IGxvY2FsID0gcmVhZExvY2FsRnJpZW5kcygpLmZpbHRlcihcbiAgICAocikgPT5cbiAgICAgICEoXG4gICAgICAgIChyLnJlcXVlc3Rlcl9pZCA9PT0gY3VycmVudFVzZXJJZCAmJiByLmFkZHJlc3NlZV9pZCA9PT0gb3RoZXJVc2VySWQpIHx8XG4gICAgICAgIChyLnJlcXVlc3Rlcl9pZCA9PT0gb3RoZXJVc2VySWQgJiYgci5hZGRyZXNzZWVfaWQgPT09IGN1cnJlbnRVc2VySWQpXG4gICAgICApLFxuICApO1xuICB3cml0ZUxvY2FsRnJpZW5kcyhsb2NhbCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNeUZyaWVuZHNBbmRSZXF1ZXN0cyh1c2VySWQ6IHN0cmluZyk6IFByb21pc2U8RnJpZW5kUmVjb3JkW10+IHtcbiAgaWYgKCF1c2VySWQpIHJldHVybiBbXTtcbiAgaWYgKGF1dGguY3VycmVudFVzZXI/LnVpZCA9PT0gdXNlcklkKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGZzRnJpZW5kcyA9IGF3YWl0IGdldEZpcmVzdG9yZUZyaWVuZHModXNlcklkKTtcbiAgICAgIGlmIChmc0ZyaWVuZHMubGVuZ3RoID4gMCkge1xuICAgICAgICByZXR1cm4gZnNGcmllbmRzLm1hcChtYXBGaXJlc3RvcmVUb0ZyaWVuZFJlY29yZCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBmYWxsYmFja1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IChzdXBhYmFzZSBhcyBhbnkpXG4gICAgICAuZnJvbShcImZyaWVuZHNcIilcbiAgICAgIC5zZWxlY3QoXCJpZCwgcmVxdWVzdGVyX2lkLCBhZGRyZXNzZWVfaWQsIHN0YXR1cywgYm9uZF90YWcsIGNyZWF0ZWRfYXQsIHVwZGF0ZWRfYXRcIilcbiAgICAgIC5vcihgcmVxdWVzdGVyX2lkLmVxLiR7dXNlcklkfSxhZGRyZXNzZWVfaWQuZXEuJHt1c2VySWR9YClcbiAgICAgIC5vcmRlcihcInVwZGF0ZWRfYXRcIiwgeyBhc2NlbmRpbmc6IGZhbHNlIH0pO1xuICAgIGlmICghZXJyb3IgJiYgZGF0YSAmJiBkYXRhLmxlbmd0aCA+IDApIHJldHVybiBkYXRhIGFzIEZyaWVuZFJlY29yZFtdO1xuICB9IGNhdGNoIHtcbiAgICAvLyBmYWxsYmFja1xuICB9XG4gIHJldHVybiByZWFkTG9jYWxGcmllbmRzKCkuZmlsdGVyKFxuICAgIChyKSA9PiByLnJlcXVlc3Rlcl9pZCA9PT0gdXNlcklkIHx8IHIuYWRkcmVzc2VlX2lkID09PSB1c2VySWQsXG4gICk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVGcmllbmRCb25kVGFnKFxuICBjdXJyZW50VXNlcklkOiBzdHJpbmcsXG4gIG90aGVyVXNlcklkOiBzdHJpbmcsXG4gIGJvbmRUYWc6IHN0cmluZyxcbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gIGNvbnN0IGNhbm9uaWNhbElkID0gZ2V0Q2Fub25pY2FsRnJpZW5kSWQoY3VycmVudFVzZXJJZCwgb3RoZXJVc2VySWQpO1xuICBpZiAoYXV0aC5jdXJyZW50VXNlcikge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IGdldEZpcmVzdG9yZUZyaWVuZHNoaXBCZXR3ZWVuKGN1cnJlbnRVc2VySWQsIG90aGVyVXNlcklkKTtcbiAgICAgIGlmIChleGlzdGluZykge1xuICAgICAgICBhd2FpdCB1cGRhdGVGaXJlc3RvcmVGcmllbmRTdGF0dXMoY2Fub25pY2FsSWQsIGV4aXN0aW5nLnN0YXR1cywgYm9uZFRhZyk7XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBmYWxsYmFja1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGF3YWl0IChzdXBhYmFzZSBhcyBhbnkpXG4gICAgICAuZnJvbShcImZyaWVuZHNcIilcbiAgICAgIC51cGRhdGUoeyBib25kX3RhZzogYm9uZFRhZywgdXBkYXRlZF9hdDogbm93IH0pXG4gICAgICAub3IoXG4gICAgICAgIGBhbmQocmVxdWVzdGVyX2lkLmVxLiR7Y3VycmVudFVzZXJJZH0sYWRkcmVzc2VlX2lkLmVxLiR7b3RoZXJVc2VySWR9KSxhbmQocmVxdWVzdGVyX2lkLmVxLiR7b3RoZXJVc2VySWR9LGFkZHJlc3NlZV9pZC5lcS4ke2N1cnJlbnRVc2VySWR9KWAsXG4gICAgICApO1xuICB9IGNhdGNoIHtcbiAgICAvLyBmYWxsYmFja1xuICB9XG4gIGNvbnN0IGxvY2FsID0gcmVhZExvY2FsRnJpZW5kcygpO1xuICBjb25zdCBpZHggPSBsb2NhbC5maW5kSW5kZXgoXG4gICAgKHIpID0+XG4gICAgICAoci5yZXF1ZXN0ZXJfaWQgPT09IGN1cnJlbnRVc2VySWQgJiYgci5hZGRyZXNzZWVfaWQgPT09IG90aGVyVXNlcklkKSB8fFxuICAgICAgKHIucmVxdWVzdGVyX2lkID09PSBvdGhlclVzZXJJZCAmJiByLmFkZHJlc3NlZV9pZCA9PT0gY3VycmVudFVzZXJJZCksXG4gICk7XG4gIGlmIChpZHggPj0gMCkge1xuICAgIGxvY2FsW2lkeF0gPSB7IC4uLmxvY2FsW2lkeF0sIGJvbmRfdGFnOiBib25kVGFnLCB1cGRhdGVkX2F0OiBub3cgfTtcbiAgICB3cml0ZUxvY2FsRnJpZW5kcyhsb2NhbCk7XG4gIH1cbn1cblxuZXhwb3J0IHR5cGUgRnJpZW5kV2l0aFByb2ZpbGUgPSBGcmllbmRSZWNvcmQgJiB7XG4gIHBlZXJJZDogc3RyaW5nO1xuICBwZWVyTmFtZTogc3RyaW5nO1xuICBwZWVyQXZhdGFyOiBzdHJpbmcgfCBudWxsO1xuICBkaXJlY3Rpb246IFwiaW5jb21pbmdcIiB8IFwib3V0Z29pbmdcIjtcbn07XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNeUZyaWVuZHNXaXRoUHJvZmlsZXModXNlcklkOiBzdHJpbmcpOiBQcm9taXNlPEZyaWVuZFdpdGhQcm9maWxlW10+IHtcbiAgY29uc3QgcmVjb3JkcyA9IGF3YWl0IGdldE15RnJpZW5kc0FuZFJlcXVlc3RzKHVzZXJJZCk7XG4gIGlmIChyZWNvcmRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIFtdO1xuXG4gIGNvbnN0IHBlZXJJZHMgPSBbXG4gICAgLi4ubmV3IFNldChyZWNvcmRzLm1hcCgocikgPT4gKHIucmVxdWVzdGVyX2lkID09PSB1c2VySWQgPyByLmFkZHJlc3NlZV9pZCA6IHIucmVxdWVzdGVyX2lkKSkpLFxuICBdO1xuXG4gIGxldCBwcm9maWxlTWFwID0gbmV3IE1hcDxzdHJpbmcsIHsgZGlzcGxheV9uYW1lOiBzdHJpbmc7IGF2YXRhcl91cmw6IHN0cmluZyB8IG51bGwgfT4oKTtcbiAgdHJ5IHtcbiAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGVzIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgLnNlbGVjdChcImlkLCBkaXNwbGF5X25hbWUsIGF2YXRhcl91cmxcIilcbiAgICAgIC5pbihcImlkXCIsIHBlZXJJZHMpO1xuICAgIHByb2ZpbGVNYXAgPSBuZXcgTWFwKFxuICAgICAgKHByb2ZpbGVzID8/IFtdKS5tYXAoKHApID0+IFtcbiAgICAgICAgcC5pZCxcbiAgICAgICAgeyBkaXNwbGF5X25hbWU6IHAuZGlzcGxheV9uYW1lLCBhdmF0YXJfdXJsOiBwLmF2YXRhcl91cmwgfSxcbiAgICAgIF0pLFxuICAgICk7XG4gIH0gY2F0Y2gge1xuICAgIC8vIGZhbGxiYWNrIGZvciBvZmZsaW5lL25vbi1VVUlEXG4gIH1cblxuICByZXR1cm4gcmVjb3Jkcy5tYXAoKHIpID0+IHtcbiAgICBjb25zdCBwZWVySWQgPSByLnJlcXVlc3Rlcl9pZCA9PT0gdXNlcklkID8gci5hZGRyZXNzZWVfaWQgOiByLnJlcXVlc3Rlcl9pZDtcbiAgICBjb25zdCBwID0gcHJvZmlsZU1hcC5nZXQocGVlcklkKTtcbiAgICByZXR1cm4ge1xuICAgICAgLi4ucixcbiAgICAgIHBlZXJJZCxcbiAgICAgIHBlZXJOYW1lOiBwPy5kaXNwbGF5X25hbWUgPz8gYE1lbWJlciAke3BlZXJJZC5zbGljZSgwLCA2KX1gLFxuICAgICAgcGVlckF2YXRhcjogcD8uYXZhdGFyX3VybCA/PyBudWxsLFxuICAgICAgZGlyZWN0aW9uOiByLnJlcXVlc3Rlcl9pZCA9PT0gdXNlcklkID8gXCJvdXRnb2luZ1wiIDogXCJpbmNvbWluZ1wiLFxuICAgIH07XG4gIH0pO1xufVxuXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSBoYXNodGFncyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5leHBvcnQgdHlwZSBIYXNodGFnID0geyBpZDogc3RyaW5nOyB0YWc6IHN0cmluZzsgdXNlX2NvdW50OiBudW1iZXIgfTtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRyZW5kaW5nSGFzaHRhZ3MobGltaXQgPSAxMCk6IFByb21pc2U8SGFzaHRhZ1tdPiB7XG4gIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgLmZyb20oXCJoYXNodGFnc1wiKVxuICAgIC5zZWxlY3QoXCJpZCwgdGFnLCB1c2VfY291bnRcIilcbiAgICAuZ3QoXCJ1c2VfY291bnRcIiwgMClcbiAgICAub3JkZXIoXCJ1c2VfY291bnRcIiwgeyBhc2NlbmRpbmc6IGZhbHNlIH0pXG4gICAgLmxpbWl0KGxpbWl0KTtcbiAgaWYgKGVycm9yKSB0aHJvdyBlcnJvcjtcbiAgcmV0dXJuIGRhdGEgPz8gW107XG59XG5cbi8qKiBpdGVtIGlkcyB0YWdnZWQgd2l0aCBhIGhhc2h0YWcgKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRJdGVtc0J5SGFzaHRhZyh0YWc6IHN0cmluZyk6IFByb21pc2U8eyBpdGVtX2lkOiBzdHJpbmcgfVtdPiB7XG4gIGNvbnN0IHsgZGF0YTogaGFzaHRhZyB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAuZnJvbShcImhhc2h0YWdzXCIpXG4gICAgLnNlbGVjdChcImlkXCIpXG4gICAgLmVxKFwidGFnXCIsIHRhZy50b0xvd2VyQ2FzZSgpKVxuICAgIC5tYXliZVNpbmdsZSgpO1xuICBpZiAoIWhhc2h0YWcpIHJldHVybiBbXTtcbiAgY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgIC5mcm9tKFwicG9zdF9oYXNodGFnc1wiKVxuICAgIC5zZWxlY3QoXCJpdGVtX2lkXCIpXG4gICAgLmVxKFwiaGFzaHRhZ19pZFwiLCBoYXNodGFnLmlkKTtcbiAgcmV0dXJuIGRhdGEgPz8gW107XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSBub3RpZmljYXRpb25zIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG5cbmV4cG9ydCB0eXBlIEFwcE5vdGlmaWNhdGlvbiA9IHtcbiAgaWQ6IHN0cmluZztcbiAgdXNlcl9pZDogc3RyaW5nO1xuICBhY3Rvcl9pZDogc3RyaW5nIHwgbnVsbDtcbiAgdHlwZTogc3RyaW5nO1xuICBpdGVtX2lkOiBzdHJpbmcgfCBudWxsO1xuICBjb21tZW50X2lkOiBzdHJpbmcgfCBudWxsO1xuICByZWFkX2F0OiBzdHJpbmcgfCBudWxsO1xuICBjcmVhdGVkX2F0OiBzdHJpbmc7XG4gIGFjdG9yTmFtZTogc3RyaW5nO1xufTtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE5vdGlmaWNhdGlvbnModXNlcklkOiBzdHJpbmcpOiBQcm9taXNlPEFwcE5vdGlmaWNhdGlvbltdPiB7XG4gIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgLmZyb20oXCJub3RpZmljYXRpb25zXCIpXG4gICAgLnNlbGVjdChcImlkLCB1c2VyX2lkLCBhY3Rvcl9pZCwgdHlwZSwgaXRlbV9pZCwgY29tbWVudF9pZCwgcmVhZF9hdCwgY3JlYXRlZF9hdFwiKVxuICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcklkKVxuICAgIC5vcmRlcihcImNyZWF0ZWRfYXRcIiwgeyBhc2NlbmRpbmc6IGZhbHNlIH0pXG4gICAgLmxpbWl0KDEwMCk7XG4gIGlmIChlcnJvcikgdGhyb3cgZXJyb3I7XG4gIGNvbnN0IHJvd3MgPSBkYXRhID8/IFtdO1xuICBpZiAocm93cy5sZW5ndGggPT09IDApIHJldHVybiBbXTtcblxuICBjb25zdCBhY3RvcklkcyA9IFsuLi5uZXcgU2V0KHJvd3MubWFwKChyKSA9PiByLmFjdG9yX2lkKS5maWx0ZXIoKHYpOiB2IGlzIHN0cmluZyA9PiAhIXYpKV07XG4gIGNvbnN0IHsgZGF0YTogcHJvZmlsZXMgfSA9IGFjdG9ySWRzLmxlbmd0aFxuICAgID8gYXdhaXQgc3VwYWJhc2UuZnJvbShcInByb2ZpbGVzXCIpLnNlbGVjdChcImlkLCBkaXNwbGF5X25hbWVcIikuaW4oXCJpZFwiLCBhY3RvcklkcylcbiAgICA6IHsgZGF0YTogW10gYXMgeyBpZDogc3RyaW5nOyBkaXNwbGF5X25hbWU6IHN0cmluZyB9W10gfTtcbiAgY29uc3QgbmFtZUJ5SWQgPSBuZXcgTWFwKChwcm9maWxlcyA/PyBbXSkubWFwKChwKSA9PiBbcC5pZCwgcC5kaXNwbGF5X25hbWVdKSk7XG5cbiAgcmV0dXJuIHJvd3MubWFwKChyKSA9PiAoe1xuICAgIC4uLnIsXG4gICAgYWN0b3JOYW1lOiAoci5hY3Rvcl9pZCA/IG5hbWVCeUlkLmdldChyLmFjdG9yX2lkKSA6IG51bGwpID8/IFwiU29tZW9uZVwiLFxuICB9KSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRVbnJlYWROb3RpZmljYXRpb25Db3VudCh1c2VySWQ6IHN0cmluZyk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IHsgY291bnQgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgLmZyb20oXCJub3RpZmljYXRpb25zXCIpXG4gICAgLnNlbGVjdChcImlkXCIsIHsgY291bnQ6IFwiZXhhY3RcIiwgaGVhZDogdHJ1ZSB9KVxuICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcklkKVxuICAgIC5pcyhcInJlYWRfYXRcIiwgbnVsbCk7XG4gIHJldHVybiBjb3VudCA/PyAwO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbWFya05vdGlmaWNhdGlvbnNSZWFkKHVzZXJJZDogc3RyaW5nKSB7XG4gIGF3YWl0IHN1cGFiYXNlXG4gICAgLmZyb20oXCJub3RpZmljYXRpb25zXCIpXG4gICAgLnVwZGF0ZSh7IHJlYWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSB9KVxuICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcklkKVxuICAgIC5pcyhcInJlYWRfYXRcIiwgbnVsbCk7XG59XG5cbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIHByb2ZpbGVzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXG5cbmV4cG9ydCB0eXBlIFB1YmxpY1Byb2ZpbGUgPSB7XG4gIGlkOiBzdHJpbmc7XG4gIGRpc3BsYXlfbmFtZTogc3RyaW5nO1xuICB1c2VybmFtZT86IHN0cmluZyB8IG51bGw7XG4gIGJpbzogc3RyaW5nIHwgbnVsbDtcbiAgYXZhdGFyX3VybDogc3RyaW5nIHwgbnVsbDtcbiAgdHJ1c3Rfc2NvcmU6IG51bWJlcjtcbn07XG5cbmNvbnN0IExPQ0FMX1BST0ZJTEVTX0tFWSA9IFwic290X3VzZXJfcHJvZmlsZXNfdjFcIjtcblxuZnVuY3Rpb24gcmVhZExvY2FsUHJvZmlsZU1hcCgpOiBSZWNvcmQ8c3RyaW5nLCBQdWJsaWNQcm9maWxlPiB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4ge307XG4gIHRyeSB7XG4gICAgY29uc3QgcmF3ID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKExPQ0FMX1BST0ZJTEVTX0tFWSk7XG4gICAgcmV0dXJuIHJhdyA/IChKU09OLnBhcnNlKHJhdykgYXMgUmVjb3JkPHN0cmluZywgUHVibGljUHJvZmlsZT4pIDoge307XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiB7fTtcbiAgfVxufVxuXG5mdW5jdGlvbiB3cml0ZUxvY2FsUHJvZmlsZShwcm9maWxlOiBQdWJsaWNQcm9maWxlKSB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm47XG4gIHRyeSB7XG4gICAgY29uc3QgbWFwID0gcmVhZExvY2FsUHJvZmlsZU1hcCgpO1xuICAgIG1hcFtwcm9maWxlLmlkXSA9IHByb2ZpbGU7XG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKExPQ0FMX1BST0ZJTEVTX0tFWSwgSlNPTi5zdHJpbmdpZnkobWFwKSk7XG4gICAgd2luZG93LmRpc3BhdGNoRXZlbnQobmV3IEN1c3RvbUV2ZW50KFwic290LXByb2ZpbGUtdXBkYXRlZFwiLCB7IGRldGFpbDogcHJvZmlsZSB9KSk7XG4gIH0gY2F0Y2gge1xuICAgIC8vIGlnbm9yZSBzdG9yYWdlIGVycm9yc1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRQdWJsaWNQcm9maWxlKHVzZXJJZDogc3RyaW5nKTogUHJvbWlzZTxQdWJsaWNQcm9maWxlIHwgbnVsbD4ge1xuICBpZiAoIXVzZXJJZCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IGxvY2FsQ2FjaGVkID0gcmVhZExvY2FsUHJvZmlsZU1hcCgpW3VzZXJJZF0gPz8gbnVsbDtcblxuICAvLyAxLiBDaGVjayBGaXJlc3RvcmUgdXNlcnMve3VzZXJJZH1cbiAgdHJ5IHtcbiAgICBjb25zdCBmc1Byb2ZpbGUgPSBhd2FpdCBnZXRGaXJlc3RvcmVVc2VyUHJvZmlsZSh1c2VySWQpO1xuICAgIGlmIChmc1Byb2ZpbGUpIHtcbiAgICAgIGNvbnN0IG1lcmdlZDogUHVibGljUHJvZmlsZSA9IHtcbiAgICAgICAgaWQ6IHVzZXJJZCxcbiAgICAgICAgZGlzcGxheV9uYW1lOlxuICAgICAgICAgICh0eXBlb2YgZnNQcm9maWxlLmRpc3BsYXlOYW1lID09PSBcInN0cmluZ1wiICYmIGZzUHJvZmlsZS5kaXNwbGF5TmFtZS50cmltKCkpIHx8XG4gICAgICAgICAgbG9jYWxDYWNoZWQ/LmRpc3BsYXlfbmFtZSB8fFxuICAgICAgICAgIFwiVmVyaWZpZWQgVm90ZXJcIixcbiAgICAgICAgdXNlcm5hbWU6XG4gICAgICAgICAgKHR5cGVvZiBmc1Byb2ZpbGUudXNlcm5hbWUgPT09IFwic3RyaW5nXCIgJiYgZnNQcm9maWxlLnVzZXJuYW1lLnRyaW0oKSkgfHxcbiAgICAgICAgICBsb2NhbENhY2hlZD8udXNlcm5hbWUgfHxcbiAgICAgICAgICBudWxsLFxuICAgICAgICBiaW86XG4gICAgICAgICAgKHR5cGVvZiBmc1Byb2ZpbGUuYmlvID09PSBcInN0cmluZ1wiICYmIGZzUHJvZmlsZS5iaW8udHJpbSgpKSB8fFxuICAgICAgICAgIGxvY2FsQ2FjaGVkPy5iaW8gfHxcbiAgICAgICAgICBudWxsLFxuICAgICAgICBhdmF0YXJfdXJsOlxuICAgICAgICAgICh0eXBlb2YgZnNQcm9maWxlLmF2YXRhclVybCA9PT0gXCJzdHJpbmdcIiAmJiBmc1Byb2ZpbGUuYXZhdGFyVXJsLnRyaW0oKSkgfHxcbiAgICAgICAgICBsb2NhbENhY2hlZD8uYXZhdGFyX3VybCB8fFxuICAgICAgICAgIG51bGwsXG4gICAgICAgIHRydXN0X3Njb3JlOiBsb2NhbENhY2hlZD8udHJ1c3Rfc2NvcmUgPz8gODgsXG4gICAgICB9O1xuICAgICAgcmV0dXJuIG1lcmdlZDtcbiAgICB9XG4gIH0gY2F0Y2gge1xuICAgIC8vIEZhbGxiYWNrIHRvIFN1cGFiYXNlIC8gbG9jYWwgY2FjaGVcbiAgfVxuXG4gIC8vIDIuIENoZWNrIFN1cGFiYXNlIHByb2ZpbGVzIHRhYmxlXG4gIHRyeSB7XG4gICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgIC5zZWxlY3QoXCJpZCwgZGlzcGxheV9uYW1lLCBiaW8sIGF2YXRhcl91cmwsIHRydXN0X3Njb3JlXCIpXG4gICAgICAuZXEoXCJpZFwiLCB1c2VySWQpXG4gICAgICAubWF5YmVTaW5nbGUoKTtcbiAgICBpZiAoIWVycm9yICYmIGRhdGEpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLmRhdGEsXG4gICAgICAgIHVzZXJuYW1lOiBsb2NhbENhY2hlZD8udXNlcm5hbWUgPz8gbnVsbCxcbiAgICAgICAgYXZhdGFyX3VybDogZGF0YS5hdmF0YXJfdXJsIHx8IGxvY2FsQ2FjaGVkPy5hdmF0YXJfdXJsIHx8IG51bGwsXG4gICAgICB9O1xuICAgIH1cbiAgfSBjYXRjaCB7XG4gICAgLy8gTm9uLVVVSUQgb3Igb2ZmbGluZSBmYWxsYmFja1xuICB9XG5cbiAgcmV0dXJuIGxvY2FsQ2FjaGVkO1xufVxuXG5leHBvcnQgdHlwZSBQcm9maWxlU3RhdHMgPSB7XG4gIHBvc3RzOiBudW1iZXI7XG4gIHN0YXNoOiBudW1iZXI7XG4gIHRyYXNoOiBudW1iZXI7XG4gIHN0YXNoVm90ZXM/OiBudW1iZXI7XG4gIHRyYXNoVm90ZXM/OiBudW1iZXI7XG4gIGZvbGxvd2luZzogbnVtYmVyO1xuICBmcmllbmRzOiBudW1iZXI7XG59O1xuXG4vKiogUHVibGljIGFjdGl2aXR5IGNvdW50ZXJzIGZvciBhIG1lbWJlciBwcm9maWxlIChhbGwgZnJvbSBwdWJsaWNseSByZWFkYWJsZSB0YWJsZXMpLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFByb2ZpbGVTdGF0cyh1c2VySWQ6IHN0cmluZyk6IFByb21pc2U8UHJvZmlsZVN0YXRzPiB7XG4gIGNvbnN0IFtwb3N0cywgdm90ZXMsIGZvbGxvd2luZywgbXlGcmllbmRzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJpdGVtc1wiKVxuICAgICAgLnNlbGVjdChcImlkXCIsIHsgY291bnQ6IFwiZXhhY3RcIiwgaGVhZDogdHJ1ZSB9KVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpXG4gICAgICAudGhlbigocikgPT4gciwgKCkgPT4gKHsgY291bnQ6IDAgfSkpLFxuICAgIHN1cGFiYXNlXG4gICAgICAuZnJvbShcInZvdGVzXCIpXG4gICAgICAuc2VsZWN0KFwidmVyZGljdFwiKVxuICAgICAgLmVxKFwidXNlcl9pZFwiLCB1c2VySWQpXG4gICAgICAudGhlbigocikgPT4gciwgKCkgPT4gKHsgZGF0YTogW10gYXMgeyB2ZXJkaWN0OiBzdHJpbmcgfVtdIH0pKSxcbiAgICBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJmb2xsb3dzXCIpXG4gICAgICAuc2VsZWN0KFwiaWRcIiwgeyBjb3VudDogXCJleGFjdFwiLCBoZWFkOiB0cnVlIH0pXG4gICAgICAuZXEoXCJmb2xsb3dlcl9pZFwiLCB1c2VySWQpXG4gICAgICAudGhlbigocikgPT4gciwgKCkgPT4gKHsgY291bnQ6IDAgfSkpLFxuICAgIGdldE15RnJpZW5kc0FuZFJlcXVlc3RzKHVzZXJJZCksXG4gIF0pO1xuICBjb25zdCByb3dzID0gdm90ZXMuZGF0YSA/PyBbXTtcbiAgY29uc3Qgc3Rhc2ggPSByb3dzLmZpbHRlcigodikgPT4gdi52ZXJkaWN0ID09PSBcInN0YXNoXCIpLmxlbmd0aDtcbiAgY29uc3QgdHJhc2ggPSByb3dzLmZpbHRlcigodikgPT4gdi52ZXJkaWN0ID09PSBcInRyYXNoXCIpLmxlbmd0aDtcbiAgcmV0dXJuIHtcbiAgICBwb3N0czogcG9zdHMuY291bnQgPz8gMCxcbiAgICBzdGFzaCxcbiAgICB0cmFzaCxcbiAgICBzdGFzaFZvdGVzOiBzdGFzaCxcbiAgICB0cmFzaFZvdGVzOiB0cmFzaCxcbiAgICBmb2xsb3dpbmc6IGZvbGxvd2luZy5jb3VudCA/PyAwLFxuICAgIGZyaWVuZHM6IG15RnJpZW5kcy5maWx0ZXIoKGYpID0+IGYuc3RhdHVzID09PSBcImFjY2VwdGVkXCIpLmxlbmd0aCxcbiAgfTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZU15UHJvZmlsZShpbnB1dDoge1xuICB1c2VySWQ6IHN0cmluZztcbiAgZGlzcGxheV9uYW1lOiBzdHJpbmc7XG4gIHVzZXJuYW1lPzogc3RyaW5nO1xuICBiaW86IHN0cmluZztcbiAgYXZhdGFyX3VybDogc3RyaW5nO1xufSkge1xuICBjb25zdCBjbGVhbk5hbWUgPSBpbnB1dC5kaXNwbGF5X25hbWUudHJpbSgpLnNsaWNlKDAsIDEwMCkgfHwgXCJBbm9ueW1vdXNcIjtcbiAgY29uc3QgY2xlYW5Vc2VybmFtZSA9IChpbnB1dC51c2VybmFtZSA/PyBcIlwiKVxuICAgIC50cmltKClcbiAgICAucmVwbGFjZSgvXkArLywgXCJcIilcbiAgICAucmVwbGFjZSgvW15hLXpBLVowLTlfLi1dL2csIFwiXCIpXG4gICAgLnNsaWNlKDAsIDUwKTtcbiAgY29uc3QgY2xlYW5CaW8gPSBpbnB1dC5iaW8udHJpbSgpLnNsaWNlKDAsIDUwMCk7XG4gIGNvbnN0IGNsZWFuQXZhdGFyID0gaW5wdXQuYXZhdGFyX3VybC50cmltKCkuc2xpY2UoMCwgNTAwKTtcblxuICBjb25zdCBleGlzdGluZ0xvY2FsID0gcmVhZExvY2FsUHJvZmlsZU1hcCgpW2lucHV0LnVzZXJJZF07XG4gIGNvbnN0IHVwZGF0ZWRMb2NhbDogUHVibGljUHJvZmlsZSA9IHtcbiAgICBpZDogaW5wdXQudXNlcklkLFxuICAgIGRpc3BsYXlfbmFtZTogY2xlYW5OYW1lLFxuICAgIHVzZXJuYW1lOiBjbGVhblVzZXJuYW1lIHx8IGV4aXN0aW5nTG9jYWw/LnVzZXJuYW1lIHx8IG51bGwsXG4gICAgYmlvOiBjbGVhbkJpbyB8fCBudWxsLFxuICAgIGF2YXRhcl91cmw6IGNsZWFuQXZhdGFyIHx8IG51bGwsXG4gICAgdHJ1c3Rfc2NvcmU6IGV4aXN0aW5nTG9jYWw/LnRydXN0X3Njb3JlID8/IDg4LFxuICB9O1xuICB3cml0ZUxvY2FsUHJvZmlsZSh1cGRhdGVkTG9jYWwpO1xuXG4gIGlmIChhdXRoLmN1cnJlbnRVc2VyPy51aWQgPT09IGlucHV0LnVzZXJJZCkge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCB1cGRhdGVGaXJlc3RvcmVVc2VyUHJvZmlsZShpbnB1dC51c2VySWQsIHtcbiAgICAgICAgZGlzcGxheU5hbWU6IGNsZWFuTmFtZSxcbiAgICAgICAgdXNlcm5hbWU6IGNsZWFuVXNlcm5hbWUsXG4gICAgICAgIGJpbzogY2xlYW5CaW8sXG4gICAgICAgIGF2YXRhclVybDogY2xlYW5BdmF0YXIsXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIEFsbG93IGxvY2FsL3N1cGFiYXNlIGZhbGxiYWNrIGlmIEZpcmVzdG9yZSBydWxlcy9vZmZsaW5lIHJlc3RyaWN0IHdyaXRlXG4gICAgfVxuICB9XG5cbiAgdHJ5IHtcbiAgICBhd2FpdCBzdXBhYmFzZVxuICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgLnVwZGF0ZSh7XG4gICAgICAgIGRpc3BsYXlfbmFtZTogY2xlYW5OYW1lLFxuICAgICAgICBiaW86IGNsZWFuQmlvIHx8IG51bGwsXG4gICAgICAgIGF2YXRhcl91cmw6IGNsZWFuQXZhdGFyIHx8IG51bGwsXG4gICAgICB9KVxuICAgICAgLmVxKFwiaWRcIiwgaW5wdXQudXNlcklkKTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gTm9uLVVVSUQgb3Igb2ZmbGluZSBmYWxsYmFja1xuICB9XG59XG4iXX0=