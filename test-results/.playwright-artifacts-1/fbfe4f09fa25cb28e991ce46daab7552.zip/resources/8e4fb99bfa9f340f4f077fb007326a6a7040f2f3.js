import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LanguageSwitcher.tsx");const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=a8030269";
import { LANGUAGES, RTL_LANGUAGES } from "/src/lib/i18n.ts";
import { APP_CORE_LOCALES } from "/src/lib/locale-app.ts";
import { COUNTRY_LANGUAGE_DIRECTORY } from "/src/lib/country-languages.ts";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "/src/components/ui/dropdown-menu.tsx";
import { Check, ChevronDown, Globe, MapPin } from "/node_modules/.vite/deps/lucide-react.js?v=a8030269";
import { cn } from "/src/lib/utils.ts";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=a8030269";
var _jsxFileName = "/app/applet/src/components/LanguageSwitcher.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
var _s = $RefreshSig$();
export async function switchAppLanguage(i18nInstance, code) {
	await i18nInstance.changeLanguage(code);
	if (typeof window !== "undefined") {
		window.localStorage.setItem("sot-lang", code);
	}
	if (typeof document !== "undefined") {
		document.documentElement.lang = code;
		document.documentElement.dir = RTL_LANGUAGES.includes(code) ? "rtl" : "ltr";
	}
}
const FEATURED_CODES = new Set(APP_CORE_LOCALES.map((l) => l.code));
/**
* Single unified top-of-screen language bar for the 8 core locales in src/lib/locale-app.ts
* plus a "Country -> Local Languages" directory (1–2+ accurate flagship languages per country)
* and a searchable "More" menu for all 52 languages.
*/
export function TopLanguageStrip() {
	_s();
	const { i18n } = useTranslation();
	const [query, setQuery] = useState("");
	const [countryQuery, setCountryQuery] = useState("");
	const activeCode = (i18n.language || "en").split("-")[0];
	const extraLanguages = useMemo(() => {
		const others = LANGUAGES.filter((l) => !FEATURED_CODES.has(l.code));
		const normalized = query.trim().toLowerCase();
		if (!normalized) return others;
		return others.filter((l) => `${l.label} ${l.native ?? ""} ${l.code}`.toLowerCase().includes(normalized));
	}, [query]);
	const filteredCountries = useMemo(() => {
		const q = countryQuery.trim().toLowerCase();
		if (!q) return COUNTRY_LANGUAGE_DIRECTORY;
		return COUNTRY_LANGUAGE_DIRECTORY.filter((c) => `${c.countryName} ${c.countryCode} ${c.languages.map((l) => `${l.nativeName} ${l.englishName}`).join(" ")}`.toLowerCase().includes(q));
	}, [countryQuery]);
	const activeExtra = !FEATURED_CODES.has(activeCode) ? LANGUAGES.find((l) => l.code === activeCode || l.code.startsWith(activeCode)) : null;
	return /* @__PURE__ */ _jsxDEV("div", {
		role: "region",
		"aria-label": "Language switcher",
		className: "w-full border-b border-[#d6a928]/25 bg-slate-950 text-white",
		"data-tsd-source": "/src/components/LanguageSwitcher.tsx:67:5",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "mx-auto flex max-w-[1440px] items-center justify-between gap-2 overflow-x-auto px-4 py-1 sm:px-6 lg:px-8 no-scrollbar",
			"data-tsd-source": "/src/components/LanguageSwitcher.tsx:72:7",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex shrink-0 items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[#d6a928]",
				"data-tsd-source": "/src/components/LanguageSwitcher.tsx:73:9",
				children: [/* @__PURE__ */ _jsxDEV(Globe, {
					className: "h-3 w-3 shrink-0 text-[#d6a928]",
					"aria-hidden": "true",
					"data-tsd-source": "/src/components/LanguageSwitcher.tsx:74:11"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "hidden sm:inline",
					"data-tsd-source": "/src/components/LanguageSwitcher.tsx:75:11",
					children: "Language"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 73,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-1",
				"data-tsd-source": "/src/components/LanguageSwitcher.tsx:78:9",
				children: [
					APP_CORE_LOCALES.map((locale) => {
						const isActive = activeCode === locale.code;
						return /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => void switchAppLanguage(i18n, locale.code),
							"aria-pressed": isActive,
							"aria-label": `Switch language to ${locale.label}`,
							"data-lang": locale.code,
							className: cn("inline-flex shrink-0 items-center rounded-md px-2.5 py-0.5 text-xs font-bold whitespace-nowrap transition-all cursor-pointer", isActive ? "bg-[#d6a928] text-slate-950 shadow-xs" : "text-slate-300 hover:bg-white/10 hover:text-white"),
							"data-tsd-source": "/src/components/LanguageSwitcher.tsx:82:15",
							children: locale.label
						}, locale.code, false, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 15
						}, this);
					}),
					/* @__PURE__ */ _jsxDEV(DropdownMenu, {
						"data-tsd-source": "/src/components/LanguageSwitcher.tsx:102:11",
						children: [/* @__PURE__ */ _jsxDEV(DropdownMenuTrigger, {
							asChild: true,
							"data-tsd-source": "/src/components/LanguageSwitcher.tsx:103:13",
							children: /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								"aria-label": "Languages by Country",
								className: "inline-flex shrink-0 items-center gap-1 rounded-md border border-[#d6a928]/40 bg-[#d6a928]/15 px-2 py-0.5 text-[11px] font-bold text-[#f5d061] whitespace-nowrap transition-colors hover:bg-[#d6a928]/25 cursor-pointer",
								"data-tsd-source": "/src/components/LanguageSwitcher.tsx:104:15",
								children: [
									/* @__PURE__ */ _jsxDEV(MapPin, {
										className: "h-3 w-3 text-[#d6a928]",
										"data-tsd-source": "/src/components/LanguageSwitcher.tsx:109:17"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 109,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										"data-tsd-source": "/src/components/LanguageSwitcher.tsx:110:17",
										children: "By Country"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 110,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV(ChevronDown, {
										className: "h-3 w-3",
										"data-tsd-source": "/src/components/LanguageSwitcher.tsx:111:17"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 111,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(DropdownMenuContent, {
							align: "end",
							className: "w-72 p-2",
							"data-tsd-source": "/src/components/LanguageSwitcher.tsx:114:13",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "border-b border-border px-2 pb-1.5",
								"data-tsd-source": "/src/components/LanguageSwitcher.tsx:115:15",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[10px] font-extrabold uppercase tracking-wider text-[#b88914]",
									"data-tsd-source": "/src/components/LanguageSwitcher.tsx:116:17",
									children: "🌍 Country → Flagship Local Languages"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 116,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									value: countryQuery,
									onChange: (e) => setCountryQuery(e.target.value),
									placeholder: "Search country or language...",
									"aria-label": "Search country languages",
									className: "mt-1 h-7 w-full rounded border border-border bg-background px-2 text-xs outline-none placeholder:text-muted-foreground",
									"data-tsd-source": "/src/components/LanguageSwitcher.tsx:119:17"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 119,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 115,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "max-h-72 overflow-y-auto pt-1 space-y-1.5",
								"data-tsd-source": "/src/components/LanguageSwitcher.tsx:127:15",
								children: filteredCountries.map((country) => /* @__PURE__ */ _jsxDEV("div", {
									className: "rounded-lg border border-border/60 bg-secondary/30 p-2",
									"data-tsd-source": "/src/components/LanguageSwitcher.tsx:129:19",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs font-extrabold text-foreground",
										"data-tsd-source": "/src/components/LanguageSwitcher.tsx:133:21",
										children: [
											country.flag,
											" ",
											country.countryName
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 133,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "mt-1.5 flex flex-wrap gap-1",
										"data-tsd-source": "/src/components/LanguageSwitcher.tsx:136:21",
										children: country.languages.map((lang) => {
											const selected = activeCode === lang.code || i18n.language === lang.code;
											return /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => {
													void switchAppLanguage(i18n, lang.code);
													toast.success(`${country.flag} Switched to ${lang.nativeName} (${lang.englishName}) for ${country.countryName}`);
												},
												className: cn("rounded-md px-2 py-0.5 text-[11px] font-bold transition cursor-pointer", selected ? "bg-[#d6a928] text-slate-950" : "bg-background text-foreground border border-border hover:bg-secondary"),
												"data-tsd-source": "/src/components/LanguageSwitcher.tsx:141:27",
												children: [
													lang.nativeName,
													" (",
													lang.englishName,
													")"
												]
											}, `${country.countryCode}-${lang.code}`, true, {
												fileName: _jsxFileName,
												lineNumber: 141,
												columnNumber: 27
											}, this);
										})
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 136,
										columnNumber: 21
									}, this)]
								}, country.countryCode, true, {
									fileName: _jsxFileName,
									lineNumber: 129,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 102,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(DropdownMenu, {
						"data-tsd-source": "/src/components/LanguageSwitcher.tsx:168:11",
						children: [/* @__PURE__ */ _jsxDEV(DropdownMenuTrigger, {
							asChild: true,
							"data-tsd-source": "/src/components/LanguageSwitcher.tsx:169:13",
							children: /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								"aria-label": "More languages",
								className: cn("inline-flex shrink-0 items-center gap-1 rounded-md px-2 py-0.5 text-[11px] font-semibold whitespace-nowrap transition-colors cursor-pointer", activeExtra ? "bg-[#d6a928] text-slate-950 font-bold" : "text-slate-400 hover:bg-white/10 hover:text-white"),
								"data-tsd-source": "/src/components/LanguageSwitcher.tsx:170:15",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									"data-tsd-source": "/src/components/LanguageSwitcher.tsx:180:17",
									children: activeExtra ? activeExtra.label : "More"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 180,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV(ChevronDown, {
									className: "h-3 w-3",
									"data-tsd-source": "/src/components/LanguageSwitcher.tsx:181:17"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 181,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 170,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 169,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(DropdownMenuContent, {
							align: "end",
							className: "w-56 p-2",
							"data-tsd-source": "/src/components/LanguageSwitcher.tsx:184:13",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "border-b border-border px-2 pb-1.5",
								"data-tsd-source": "/src/components/LanguageSwitcher.tsx:185:15",
								children: /* @__PURE__ */ _jsxDEV("input", {
									value: query,
									onChange: (event) => setQuery(event.target.value),
									placeholder: "Search all 52 languages...",
									"aria-label": "Search languages",
									className: "h-7 w-full bg-transparent text-xs outline-none placeholder:text-muted-foreground",
									"data-tsd-source": "/src/components/LanguageSwitcher.tsx:186:17"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 186,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 185,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "max-h-56 overflow-y-auto pt-1",
								"data-tsd-source": "/src/components/LanguageSwitcher.tsx:194:15",
								children: [extraLanguages.map((l) => /* @__PURE__ */ _jsxDEV(DropdownMenuItem, {
									onClick: () => void switchAppLanguage(i18n, l.code),
									className: l.code === activeCode ? "justify-between font-semibold text-primary" : "justify-between",
									dir: RTL_LANGUAGES.includes(l.code) ? "rtl" : "ltr",
									"data-tsd-source": "/src/components/LanguageSwitcher.tsx:196:19",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										"data-tsd-source": "/src/components/LanguageSwitcher.tsx:206:21",
										children: l.label
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 206,
										columnNumber: 21
									}, this), l.code === activeCode && /* @__PURE__ */ _jsxDEV(Check, {
										className: "h-3.5 w-3.5",
										"data-tsd-source": "/src/components/LanguageSwitcher.tsx:207:47"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 207,
										columnNumber: 47
									}, this)]
								}, l.code, true, {
									fileName: _jsxFileName,
									lineNumber: 196,
									columnNumber: 19
								}, this)), extraLanguages.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
									className: "px-2 py-3 text-xs text-muted-foreground",
									"data-tsd-source": "/src/components/LanguageSwitcher.tsx:211:19",
									children: "No matching language."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 211,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 194,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 184,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 168,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 72,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 67,
		columnNumber: 5
	}, this);
}
_s(TopLanguageStrip, "3q7qFKW2Ty7oCFZWOLPJEtHnF9s=", false, function() {
	return [useTranslation];
});
_c = TopLanguageStrip;
export function LanguageSwitcher() {
	return /* @__PURE__ */ _jsxDEV(TopLanguageStrip, { "data-tsd-source": "/src/components/LanguageSwitcher.tsx:223:10" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 223,
		columnNumber: 10
	}, this);
}
_c2 = LanguageSwitcher;
var _c, _c2;
$RefreshReg$(_c, "TopLanguageStrip");
$RefreshReg$(_c2, "LanguageSwitcher");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/LanguageSwitcher.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/LanguageSwitcher.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/LanguageSwitcher.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/LanguageSwitcher.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQ0EsY0FDQSxxQkFDQSxrQkFDQSwyQkFDQTtBQUNBO0FBQ0E7QUFDQTs7OztBQUVBLHdDQUNBLGNBQ0EsTUFDQTtDQUNBO0NBQ0E7RUFDQTtDQUNBO0NBQ0E7RUFDQTtFQUNBO0NBQ0E7QUFDQTtBQUVBOzs7Ozs7QUFPQTs7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsNEJBQ0EsMkVBQ0E7Q0FDQTtDQUVBO0VBQ0E7RUFDQTtFQUNBLGdEQUNBLDRHQUNBLGNBQ0EsV0FDQTtDQUNBO0NBRUEsc0RBQ0EsZ0ZBQ0E7Q0FFQSxPQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7WUFDQTtHQUFBO0dBQUE7YUFBQSxDQUNBO0lBQUE7SUFBQTtjQUFBLENBQ0E7S0FBQTtLQUFBO0tBQUE7SUFBZ0Y7Ozs7Y0FDaEY7S0FBQTtLQUFBO2VBQTRDO0lBQUE7Ozs7WUFDNUM7Ozs7O2FBRUE7SUFBQTtJQUFBO2NBQUE7S0FDQTtNQUNBO01BQ0EsT0FDQTtPQUVBO09BQ0E7T0FDQTtPQUNBO09BQ0E7T0FDQSxjQUNBLGdJQUNBLFdBQ0EsMENBQ0EsbURBQ0E7T0FDQTtpQkFDQTtNQUNBLEdBZEE7Ozs7YUFjQTtLQUVBO0tBR0E7TUFBQTtnQkFBQSxDQUNBO09BQUE7T0FBQTtpQkFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO2tCQUpBO1NBS0E7VUFBQTtVQUFBO1NBQTJEOzs7OztTQUMzRDtVQUFBO29CQUFxQjtTQUFBOzs7OztTQUNyQjtVQUFBO1VBQUE7U0FBaUQ7Ozs7O1FBQ2pEOzs7Ozs7TUFDQTs7OztnQkFDQTtPQUFBO09BQUE7T0FBQTtpQkFBQSxDQUNBO1FBQUE7UUFBQTtrQkFBQSxDQUNBO1NBQUE7U0FBQTttQkFBaUc7UUFFakc7Ozs7a0JBQ0E7U0FDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7UUFBZ0I7Ozs7Z0JBQ2hCOzs7OztpQkFDQTtRQUFBO1FBQUE7a0JBQ0EsbUNBQ0E7U0FFQTtTQUNBO21CQUhBLENBSUE7VUFBQTtVQUFBO29CQUFBO1dBQ0E7V0FBQTtXQUFBO1VBQ0E7Ozs7O21CQUNBO1VBQUE7VUFBQTtvQkFDQTtXQUNBLGlCQUNBO1dBQ0EsT0FDQTtZQUVBO1lBQ0E7YUFDQTthQUNBLGNBQ0EsaUdBQ0E7WUFDQTtZQUNBLGNBQ0EsMEVBQ0EsV0FDQSxnQ0FDQSx1RUFDQTtZQUNBO3NCQWZBO2FBZ0JBO2FBQUE7YUFBQTthQUFBO1lBQ0E7Y0FoQkE7Ozs7a0JBZ0JBO1VBRUE7U0FDQTs7OztpQkFDQTtXQWhDQTs7OztlQWdDQSxDQUNBO09BQ0E7Ozs7ZUFDQTs7Ozs7Y0FDQTs7Ozs7O0tBRUE7TUFBQTtnQkFBQSxDQUNBO09BQUE7T0FBQTtpQkFDQTtRQUNBO1FBQ0E7UUFDQSxjQUNBLCtJQUNBLGNBQ0EsMENBQ0EsbURBQ0E7UUFDQTtrQkFUQSxDQVVBO1NBQUE7bUJBQXFCO1FBQUE7Ozs7a0JBQ3JCO1NBQUE7U0FBQTtRQUFpRDs7OztnQkFDakQ7Ozs7OztNQUNBOzs7O2dCQUNBO09BQUE7T0FBQTtPQUFBO2lCQUFBLENBQ0E7UUFBQTtRQUFBO2tCQUNBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1FBQWdCOzs7OztPQUNoQjs7OztpQkFDQTtRQUFBO1FBQUE7a0JBQUEsQ0FDQSwwQkFDQTtTQUVBO1NBQ0EsV0FDQSx3QkFDQSwrQ0FDQTtTQUVBO1NBQ0E7bUJBVEEsQ0FVQTtVQUFBO29CQUF5QjtTQUFBOzs7O21CQUN6QjtVQUFBO1VBQUE7U0FBNkU7Ozs7aUJBQzdFO1dBWEE7Ozs7ZUFXQSxDQUNBLEdBQ0EsK0JBQ0E7U0FBQTtTQUFBO21CQUF3RTtRQUFBOzs7O2dCQUV4RTs7Ozs7ZUFDQTs7Ozs7Y0FDQTs7Ozs7O0lBQ0E7Ozs7O1dBQ0E7Ozs7OztDQUNBOzs7OztBQUVBOzs7OztBQUVBO0NBQ0Esb0hBQTJCOzs7OztBQUMzQiIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTGFuZ3VhZ2VTd2l0Y2hlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZVRyYW5zbGF0aW9uIH0gZnJvbSBcInJlYWN0LWkxOG5leHRcIjtcbmltcG9ydCB7IExBTkdVQUdFUywgUlRMX0xBTkdVQUdFUyB9IGZyb20gXCJAL2xpYi9pMThuXCI7XG5pbXBvcnQgeyBBUFBfU1VQUE9SVEVEX0xPQ0FMRVMsIEFQUF9DT1JFX0xPQ0FMRVMgfSBmcm9tIFwiQC9saWIvbG9jYWxlLWFwcFwiO1xuaW1wb3J0IHsgQ09VTlRSWV9MQU5HVUFHRV9ESVJFQ1RPUlkgfSBmcm9tIFwiQC9saWIvY291bnRyeS1sYW5ndWFnZXNcIjtcbmltcG9ydCB7XG4gIERyb3Bkb3duTWVudSxcbiAgRHJvcGRvd25NZW51Q29udGVudCxcbiAgRHJvcGRvd25NZW51SXRlbSxcbiAgRHJvcGRvd25NZW51VHJpZ2dlcixcbn0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9kcm9wZG93bi1tZW51XCI7XG5pbXBvcnQgeyBDaGVjaywgQ2hldnJvbkRvd24sIEdsb2JlLCBNYXBQaW4gfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi91dGlsc1wiO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tIFwic29ubmVyXCI7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzd2l0Y2hBcHBMYW5ndWFnZShcbiAgaTE4bkluc3RhbmNlOiB7IGNoYW5nZUxhbmd1YWdlOiAobG5nOiBzdHJpbmcpID0+IFByb21pc2U8dW5rbm93bj4gfSxcbiAgY29kZTogc3RyaW5nLFxuKSB7XG4gIGF3YWl0IGkxOG5JbnN0YW5jZS5jaGFuZ2VMYW5ndWFnZShjb2RlKTtcbiAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJzb3QtbGFuZ1wiLCBjb2RlKTtcbiAgfVxuICBpZiAodHlwZW9mIGRvY3VtZW50ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmxhbmcgPSBjb2RlO1xuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5kaXIgPSBSVExfTEFOR1VBR0VTLmluY2x1ZGVzKGNvZGUpID8gXCJydGxcIiA6IFwibHRyXCI7XG4gIH1cbn1cblxuY29uc3QgRkVBVFVSRURfQ09ERVMgPSBuZXcgU2V0PHN0cmluZz4oQVBQX0NPUkVfTE9DQUxFUy5tYXAoKGwpID0+IGwuY29kZSkpO1xuXG4vKipcbiAqIFNpbmdsZSB1bmlmaWVkIHRvcC1vZi1zY3JlZW4gbGFuZ3VhZ2UgYmFyIGZvciB0aGUgOCBjb3JlIGxvY2FsZXMgaW4gc3JjL2xpYi9sb2NhbGUtYXBwLnRzXG4gKiBwbHVzIGEgXCJDb3VudHJ5IC0+IExvY2FsIExhbmd1YWdlc1wiIGRpcmVjdG9yeSAoMeKAkzIrIGFjY3VyYXRlIGZsYWdzaGlwIGxhbmd1YWdlcyBwZXIgY291bnRyeSlcbiAqIGFuZCBhIHNlYXJjaGFibGUgXCJNb3JlXCIgbWVudSBmb3IgYWxsIDUyIGxhbmd1YWdlcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFRvcExhbmd1YWdlU3RyaXAoKSB7XG4gIGNvbnN0IHsgaTE4biB9ID0gdXNlVHJhbnNsYXRpb24oKTtcbiAgY29uc3QgW3F1ZXJ5LCBzZXRRdWVyeV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2NvdW50cnlRdWVyeSwgc2V0Q291bnRyeVF1ZXJ5XSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBhY3RpdmVDb2RlID0gKGkxOG4ubGFuZ3VhZ2UgfHwgXCJlblwiKS5zcGxpdChcIi1cIilbMF07XG5cbiAgY29uc3QgZXh0cmFMYW5ndWFnZXMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCBvdGhlcnMgPSBMQU5HVUFHRVMuZmlsdGVyKChsKSA9PiAhRkVBVFVSRURfQ09ERVMuaGFzKGwuY29kZSkpO1xuICAgIGNvbnN0IG5vcm1hbGl6ZWQgPSBxdWVyeS50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICBpZiAoIW5vcm1hbGl6ZWQpIHJldHVybiBvdGhlcnM7XG4gICAgcmV0dXJuIG90aGVycy5maWx0ZXIoKGwpID0+XG4gICAgICBgJHtsLmxhYmVsfSAke2wubmF0aXZlID8/IFwiXCJ9ICR7bC5jb2RlfWAudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhub3JtYWxpemVkKSxcbiAgICApO1xuICB9LCBbcXVlcnldKTtcblxuICBjb25zdCBmaWx0ZXJlZENvdW50cmllcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGNvbnN0IHEgPSBjb3VudHJ5UXVlcnkudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKCFxKSByZXR1cm4gQ09VTlRSWV9MQU5HVUFHRV9ESVJFQ1RPUlk7XG4gICAgcmV0dXJuIENPVU5UUllfTEFOR1VBR0VfRElSRUNUT1JZLmZpbHRlcigoYykgPT5cbiAgICAgIGAke2MuY291bnRyeU5hbWV9ICR7Yy5jb3VudHJ5Q29kZX0gJHtjLmxhbmd1YWdlcy5tYXAoKGwpID0+IGAke2wubmF0aXZlTmFtZX0gJHtsLmVuZ2xpc2hOYW1lfWApLmpvaW4oXCIgXCIpfWBcbiAgICAgICAgLnRvTG93ZXJDYXNlKClcbiAgICAgICAgLmluY2x1ZGVzKHEpLFxuICAgICk7XG4gIH0sIFtjb3VudHJ5UXVlcnldKTtcblxuICBjb25zdCBhY3RpdmVFeHRyYSA9ICFGRUFUVVJFRF9DT0RFUy5oYXMoYWN0aXZlQ29kZSlcbiAgICA/IExBTkdVQUdFUy5maW5kKChsKSA9PiBsLmNvZGUgPT09IGFjdGl2ZUNvZGUgfHwgbC5jb2RlLnN0YXJ0c1dpdGgoYWN0aXZlQ29kZSkpXG4gICAgOiBudWxsO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgcm9sZT1cInJlZ2lvblwiXG4gICAgICBhcmlhLWxhYmVsPVwiTGFuZ3VhZ2Ugc3dpdGNoZXJcIlxuICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlci1iIGJvcmRlci1bI2Q2YTkyOF0vMjUgYmctc2xhdGUtOTUwIHRleHQtd2hpdGVcIlxuICAgID5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXgtYXV0byBmbGV4IG1heC13LVsxNDQwcHhdIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgb3ZlcmZsb3cteC1hdXRvIHB4LTQgcHktMSBzbTpweC02IGxnOnB4LTggbm8tc2Nyb2xsYmFyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzaHJpbmstMCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtWyNkNmE5MjhdXCI+XG4gICAgICAgICAgPEdsb2JlIGNsYXNzTmFtZT1cImgtMyB3LTMgc2hyaW5rLTAgdGV4dC1bI2Q2YTkyOF1cIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmVcIj5MYW5ndWFnZTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgIHtBUFBfQ09SRV9MT0NBTEVTLm1hcCgobG9jYWxlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IGFjdGl2ZUNvZGUgPT09IGxvY2FsZS5jb2RlO1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIGtleT17bG9jYWxlLmNvZGV9XG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBzd2l0Y2hBcHBMYW5ndWFnZShpMThuLCBsb2NhbGUuY29kZSl9XG4gICAgICAgICAgICAgICAgYXJpYS1wcmVzc2VkPXtpc0FjdGl2ZX1cbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgU3dpdGNoIGxhbmd1YWdlIHRvICR7bG9jYWxlLmxhYmVsfWB9XG4gICAgICAgICAgICAgICAgZGF0YS1sYW5nPXtsb2NhbGUuY29kZX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgXCJpbmxpbmUtZmxleCBzaHJpbmstMCBpdGVtcy1jZW50ZXIgcm91bmRlZC1tZCBweC0yLjUgcHktMC41IHRleHQteHMgZm9udC1ib2xkIHdoaXRlc3BhY2Utbm93cmFwIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCIsXG4gICAgICAgICAgICAgICAgICBpc0FjdGl2ZVxuICAgICAgICAgICAgICAgICAgICA/IFwiYmctWyNkNmE5MjhdIHRleHQtc2xhdGUtOTUwIHNoYWRvdy14c1wiXG4gICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy13aGl0ZS8xMCBob3Zlcjp0ZXh0LXdoaXRlXCIsXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtsb2NhbGUubGFiZWx9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9KX1cblxuICAgICAgICAgIHsvKiBDb3VudHJ5IC0+IEZsYWdzaGlwIExvY2FsIExhbmd1YWdlcyBQaWNrZXIgKi99XG4gICAgICAgICAgPERyb3Bkb3duTWVudT5cbiAgICAgICAgICAgIDxEcm9wZG93bk1lbnVUcmlnZ2VyIGFzQ2hpbGQ+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiTGFuZ3VhZ2VzIGJ5IENvdW50cnlcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHNocmluay0wIGl0ZW1zLWNlbnRlciBnYXAtMSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItWyNkNmE5MjhdLzQwIGJnLVsjZDZhOTI4XS8xNSBweC0yIHB5LTAuNSB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1bI2Y1ZDA2MV0gd2hpdGVzcGFjZS1ub3dyYXAgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6YmctWyNkNmE5MjhdLzI1IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxNYXBQaW4gY2xhc3NOYW1lPVwiaC0zIHctMyB0ZXh0LVsjZDZhOTI4XVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+QnkgQ291bnRyeTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8Q2hldnJvbkRvd24gY2xhc3NOYW1lPVwiaC0zIHctM1wiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVUcmlnZ2VyPlxuICAgICAgICAgICAgPERyb3Bkb3duTWVudUNvbnRlbnQgYWxpZ249XCJlbmRcIiBjbGFzc05hbWU9XCJ3LTcyIHAtMlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ib3JkZXIgcHgtMiBwYi0xLjVcIj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWV4dHJhYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1bI2I4ODkxNF1cIj5cbiAgICAgICAgICAgICAgICAgIPCfjI0gQ291bnRyeSDihpIgRmxhZ3NoaXAgTG9jYWwgTGFuZ3VhZ2VzXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvdW50cnlRdWVyeX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q291bnRyeVF1ZXJ5KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGNvdW50cnkgb3IgbGFuZ3VhZ2UuLi5cIlxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlNlYXJjaCBjb3VudHJ5IGxhbmd1YWdlc1wiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGgtNyB3LWZ1bGwgcm91bmRlZCBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1iYWNrZ3JvdW5kIHB4LTIgdGV4dC14cyBvdXRsaW5lLW5vbmUgcGxhY2Vob2xkZXI6dGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtaC03MiBvdmVyZmxvdy15LWF1dG8gcHQtMSBzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgIHtmaWx0ZXJlZENvdW50cmllcy5tYXAoKGNvdW50cnkpID0+IChcbiAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAga2V5PXtjb3VudHJ5LmNvdW50cnlDb2RlfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYm9yZGVyLzYwIGJnLXNlY29uZGFyeS8zMCBwLTJcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtZXh0cmFib2xkIHRleHQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtjb3VudHJ5LmZsYWd9IHtjb3VudHJ5LmNvdW50cnlOYW1lfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMS41IGZsZXggZmxleC13cmFwIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2NvdW50cnkubGFuZ3VhZ2VzLm1hcCgobGFuZykgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc2VsZWN0ZWQgPVxuICAgICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmVDb2RlID09PSBsYW5nLmNvZGUgfHwgaTE4bi5sYW5ndWFnZSA9PT0gbGFuZy5jb2RlO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17YCR7Y291bnRyeS5jb3VudHJ5Q29kZX0tJHtsYW5nLmNvZGV9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b2lkIHN3aXRjaEFwcExhbmd1YWdlKGkxOG4sIGxhbmcuY29kZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b2FzdC5zdWNjZXNzKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgJHtjb3VudHJ5LmZsYWd9IFN3aXRjaGVkIHRvICR7bGFuZy5uYXRpdmVOYW1lfSAoJHtsYW5nLmVuZ2xpc2hOYW1lfSkgZm9yICR7Y291bnRyeS5jb3VudHJ5TmFtZX1gLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInJvdW5kZWQtbWQgcHgtMiBweS0wLjUgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1bI2Q2YTkyOF0gdGV4dC1zbGF0ZS05NTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctYmFja2dyb3VuZCB0ZXh0LWZvcmVncm91bmQgYm9yZGVyIGJvcmRlci1ib3JkZXIgaG92ZXI6Ymctc2Vjb25kYXJ5XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsYW5nLm5hdGl2ZU5hbWV9ICh7bGFuZy5lbmdsaXNoTmFtZX0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L0Ryb3Bkb3duTWVudUNvbnRlbnQ+XG4gICAgICAgICAgPC9Ecm9wZG93bk1lbnU+XG5cbiAgICAgICAgICA8RHJvcGRvd25NZW51PlxuICAgICAgICAgICAgPERyb3Bkb3duTWVudVRyaWdnZXIgYXNDaGlsZD5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJNb3JlIGxhbmd1YWdlc1wiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgIFwiaW5saW5lLWZsZXggc2hyaW5rLTAgaXRlbXMtY2VudGVyIGdhcC0xIHJvdW5kZWQtbWQgcHgtMiBweS0wLjUgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB3aGl0ZXNwYWNlLW5vd3JhcCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiLFxuICAgICAgICAgICAgICAgICAgYWN0aXZlRXh0cmFcbiAgICAgICAgICAgICAgICAgICAgPyBcImJnLVsjZDZhOTI4XSB0ZXh0LXNsYXRlLTk1MCBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1zbGF0ZS00MDAgaG92ZXI6Ymctd2hpdGUvMTAgaG92ZXI6dGV4dC13aGl0ZVwiLFxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3Bhbj57YWN0aXZlRXh0cmEgPyBhY3RpdmVFeHRyYS5sYWJlbCA6IFwiTW9yZVwifTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8Q2hldnJvbkRvd24gY2xhc3NOYW1lPVwiaC0zIHctM1wiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVUcmlnZ2VyPlxuICAgICAgICAgICAgPERyb3Bkb3duTWVudUNvbnRlbnQgYWxpZ249XCJlbmRcIiBjbGFzc05hbWU9XCJ3LTU2IHAtMlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ib3JkZXIgcHgtMiBwYi0xLjVcIj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtxdWVyeX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFF1ZXJ5KGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBhbGwgNTIgbGFuZ3VhZ2VzLi4uXCJcbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJTZWFyY2ggbGFuZ3VhZ2VzXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtNyB3LWZ1bGwgYmctdHJhbnNwYXJlbnQgdGV4dC14cyBvdXRsaW5lLW5vbmUgcGxhY2Vob2xkZXI6dGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtaC01NiBvdmVyZmxvdy15LWF1dG8gcHQtMVwiPlxuICAgICAgICAgICAgICAgIHtleHRyYUxhbmd1YWdlcy5tYXAoKGwpID0+IChcbiAgICAgICAgICAgICAgICAgIDxEcm9wZG93bk1lbnVJdGVtXG4gICAgICAgICAgICAgICAgICAgIGtleT17bC5jb2RlfVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHN3aXRjaEFwcExhbmd1YWdlKGkxOG4sIGwuY29kZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17XG4gICAgICAgICAgICAgICAgICAgICAgbC5jb2RlID09PSBhY3RpdmVDb2RlXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwianVzdGlmeS1iZXR3ZWVuIGZvbnQtc2VtaWJvbGQgdGV4dC1wcmltYXJ5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJqdXN0aWZ5LWJldHdlZW5cIlxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGRpcj17UlRMX0xBTkdVQUdFUy5pbmNsdWRlcyhsLmNvZGUpID8gXCJydGxcIiA6IFwibHRyXCJ9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPntsLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAge2wuY29kZSA9PT0gYWN0aXZlQ29kZSAmJiA8Q2hlY2sgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPn1cbiAgICAgICAgICAgICAgICAgIDwvRHJvcGRvd25NZW51SXRlbT5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICB7ZXh0cmFMYW5ndWFnZXMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInB4LTIgcHktMyB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPk5vIG1hdGNoaW5nIGxhbmd1YWdlLjwvcD5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvRHJvcGRvd25NZW51Q29udGVudD5cbiAgICAgICAgICA8L0Ryb3Bkb3duTWVudT5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIExhbmd1YWdlU3dpdGNoZXIoKSB7XG4gIHJldHVybiA8VG9wTGFuZ3VhZ2VTdHJpcCAvPjtcbn1cbiJdLCJmaWxlIjoiL2FwcC9hcHBsZXQvc3JjL2NvbXBvbmVudHMvTGFuZ3VhZ2VTd2l0Y2hlci50c3gifQ==