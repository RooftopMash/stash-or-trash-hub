import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=a8030269";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=a8030269";
import { t as require_react_dom } from "/node_modules/.vite/deps/react-dom.js?v=a8030269";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/react_jsx-runtime.js?v=a8030269";
import { t as useCallbackRef$1 } from "/node_modules/.vite/deps/dist-BEvKR6kC.js?v=a8030269";
import { t as useLayoutEffect2 } from "/node_modules/.vite/deps/dist-qLH82T-0.js?v=a8030269";
import { o as useComposedRefs } from "/node_modules/.vite/deps/dist-DIAF6ZLP.js?v=a8030269";
import { n as dispatchDiscreteCustomEvent, t as Primitive } from "/node_modules/.vite/deps/dist-uZEDRbDH.js?v=a8030269";
import { n as composeEventHandlers } from "/node_modules/.vite/deps/dist-Cy5nHrbn.js?v=a8030269";
import { i as __spreadArray, r as __rest, t as __assign } from "/node_modules/.vite/deps/tslib.es6-B1NP4NDs.js?v=a8030269";
//#region node_modules/@radix-ui/react-dismissable-layer/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var __defProp$3 = Object.defineProperty;
var __name$3 = (target, value) => __defProp$3(target, "name", {
	value,
	configurable: true
});
var CONTEXT_UPDATE = "dismissableLayer.update";
var POINTER_DOWN_OUTSIDE = "dismissableLayer.pointerDownOutside";
var FOCUS_OUTSIDE = "dismissableLayer.focusOutside";
var originalBodyPointerEvents;
var DismissableLayerContext = import_react.createContext({
	layers: /* @__PURE__ */ new Set(),
	layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
	branches: /* @__PURE__ */ new Set(),
	dismissableSurfaces: /* @__PURE__ */ new Set()
});
var DismissableLayer = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$3(function DismissableLayer2(props, forwardedRef) {
	const { disableOutsidePointerEvents = false, deferPointerDownOutside = false, onEscapeKeyDown, onPointerDownOutside, onFocusOutside, onInteractOutside, onDismiss, ...layerProps } = props;
	const context = import_react.useContext(DismissableLayerContext);
	const [node, setNode] = import_react.useState(null);
	const ownerDocument = node?.ownerDocument ?? globalThis?.document;
	const [, force] = import_react.useState({});
	const composedRefs = useComposedRefs(forwardedRef, setNode);
	const layers = Array.from(context.layers);
	const [highestLayerWithOutsidePointerEventsDisabled] = [...context.layersWithOutsidePointerEventsDisabled].slice(-1);
	const highestLayerWithOutsidePointerEventsDisabledIndex = highestLayerWithOutsidePointerEventsDisabled ? layers.indexOf(highestLayerWithOutsidePointerEventsDisabled) : -1;
	const index = node ? layers.indexOf(node) : -1;
	const isBodyPointerEventsDisabled = context.layersWithOutsidePointerEventsDisabled.size > 0;
	const isPointerEventsEnabled = index >= highestLayerWithOutsidePointerEventsDisabledIndex;
	const isDeferredPointerDownOutsideRef = import_react.useRef(false);
	const pointerDownOutside = usePointerDownOutside((event) => {
		onPointerDownOutside?.(event);
		onInteractOutside?.(event);
		if (!event.defaultPrevented) onDismiss?.();
	}, {
		ownerDocument,
		deferPointerDownOutside,
		isDeferredPointerDownOutsideRef,
		dismissableSurfaces: context.dismissableSurfaces,
		shouldHandlePointerDownOutside: import_react.useCallback((target) => {
			if (!(target instanceof Node)) return false;
			const isPointerDownOnBranch = [...context.branches].some((branch) => branch.contains(target));
			return isPointerEventsEnabled && !isPointerDownOnBranch;
		}, [context.branches, isPointerEventsEnabled])
	});
	const focusOutside = useFocusOutside((event) => {
		if (deferPointerDownOutside && isDeferredPointerDownOutsideRef.current) return;
		const target = event.target;
		if ([...context.branches].some((branch) => branch.contains(target))) return;
		onFocusOutside?.(event);
		onInteractOutside?.(event);
		if (!event.defaultPrevented) onDismiss?.();
	}, ownerDocument);
	const isHighestLayer = node ? index === layers.length - 1 : false;
	const handleKeyDown = useCallbackRef$1((event) => {
		if (event.key !== "Escape") return;
		onEscapeKeyDown?.(event);
		if (!event.defaultPrevented && onDismiss) {
			event.preventDefault();
			onDismiss();
		}
	});
	import_react.useEffect(() => {
		if (!isHighestLayer) return;
		ownerDocument.addEventListener("keydown", handleKeyDown, { capture: true });
		return () => ownerDocument.removeEventListener("keydown", handleKeyDown, { capture: true });
	}, [
		ownerDocument,
		isHighestLayer,
		handleKeyDown
	]);
	import_react.useEffect(() => {
		if (!node) return;
		if (disableOutsidePointerEvents) {
			if (context.layersWithOutsidePointerEventsDisabled.size === 0) {
				originalBodyPointerEvents = ownerDocument.body.style.pointerEvents;
				ownerDocument.body.style.pointerEvents = "none";
			}
			context.layersWithOutsidePointerEventsDisabled.add(node);
		}
		context.layers.add(node);
		dispatchUpdate();
		return () => {
			if (disableOutsidePointerEvents) {
				context.layersWithOutsidePointerEventsDisabled.delete(node);
				if (context.layersWithOutsidePointerEventsDisabled.size === 0) ownerDocument.body.style.pointerEvents = originalBodyPointerEvents;
			}
		};
	}, [
		node,
		ownerDocument,
		disableOutsidePointerEvents,
		context
	]);
	import_react.useEffect(() => {
		return () => {
			if (!node) return;
			context.layers.delete(node);
			context.layersWithOutsidePointerEventsDisabled.delete(node);
			dispatchUpdate();
		};
	}, [node, context]);
	import_react.useEffect(() => {
		const handleUpdate = /* @__PURE__ */ __name$3(() => force({}), "handleUpdate");
		document.addEventListener(CONTEXT_UPDATE, handleUpdate);
		return () => document.removeEventListener(CONTEXT_UPDATE, handleUpdate);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		...layerProps,
		ref: composedRefs,
		style: {
			pointerEvents: isBodyPointerEventsDisabled ? isPointerEventsEnabled ? "auto" : "none" : void 0,
			...props.style
		},
		onFocusCapture: composeEventHandlers(props.onFocusCapture, focusOutside.onFocusCapture),
		onBlurCapture: composeEventHandlers(props.onBlurCapture, focusOutside.onBlurCapture),
		onPointerDownCapture: composeEventHandlers(props.onPointerDownCapture, pointerDownOutside.onPointerDownCapture)
	});
}, "DismissableLayer"));
function useDismissableLayerSurface() {
	const context = import_react.useContext(DismissableLayerContext);
	const [node, setNode] = import_react.useState(null);
	import_react.useEffect(() => {
		if (!node) return;
		context.dismissableSurfaces.add(node);
		return () => {
			context.dismissableSurfaces.delete(node);
		};
	}, [node, context.dismissableSurfaces]);
	return setNode;
}
__name$3(useDismissableLayerSurface, "useDismissableLayerSurface");
var IS_TRUE = /* @__PURE__ */ __name$3(() => true, "IS_TRUE");
function usePointerDownOutside(onPointerDownOutside, args) {
	const { ownerDocument = globalThis?.document, deferPointerDownOutside = false, isDeferredPointerDownOutsideRef, dismissableSurfaces, shouldHandlePointerDownOutside = IS_TRUE } = args;
	const handlePointerDownOutside = useCallbackRef$1(onPointerDownOutside);
	const isPointerInsideReactTreeRef = import_react.useRef(false);
	const isPointerDownOutsideRef = import_react.useRef(false);
	const interceptedOutsideInteractionEventsRef = import_react.useRef(/* @__PURE__ */ new Map());
	const handleClickRef = import_react.useRef(() => {});
	import_react.useEffect(() => {
		function resetOutsideInteraction() {
			isPointerDownOutsideRef.current = false;
			isDeferredPointerDownOutsideRef.current = false;
			interceptedOutsideInteractionEventsRef.current.clear();
		}
		__name$3(resetOutsideInteraction, "resetOutsideInteraction");
		function isOutsideInteractionIntercepted() {
			return Array.from(interceptedOutsideInteractionEventsRef.current.values()).some(Boolean);
		}
		__name$3(isOutsideInteractionIntercepted, "isOutsideInteractionIntercepted");
		function handleInteractionCapture(event) {
			if (!isPointerDownOutsideRef.current) return;
			const target = event.target;
			if (!(target instanceof Node && [...dismissableSurfaces].some((surface) => surface.contains(target)))) interceptedOutsideInteractionEventsRef.current.set(event.type, true);
			if (event.type === "click") window.setTimeout(() => {
				if (isPointerDownOutsideRef.current) handleClickRef.current();
			}, 0);
		}
		__name$3(handleInteractionCapture, "handleInteractionCapture");
		function handleInteractionBubble(event) {
			if (isPointerDownOutsideRef.current) interceptedOutsideInteractionEventsRef.current.set(event.type, false);
		}
		__name$3(handleInteractionBubble, "handleInteractionBubble");
		const handlePointerDown = /* @__PURE__ */ __name$3((event) => {
			if (event.target && !isPointerInsideReactTreeRef.current) {
				let handleAndDispatchPointerDownOutsideEvent2 = function() {
					ownerDocument.removeEventListener("click", handleClickRef.current);
					const wasOutsideInteractionIntercepted = isOutsideInteractionIntercepted();
					resetOutsideInteraction();
					if (!wasOutsideInteractionIntercepted) handleAndDispatchCustomEvent(POINTER_DOWN_OUTSIDE, handlePointerDownOutside, eventDetail, { discrete: true });
				};
				__name$3(handleAndDispatchPointerDownOutsideEvent2, "handleAndDispatchPointerDownOutsideEvent");
				if (!shouldHandlePointerDownOutside(event.target)) {
					ownerDocument.removeEventListener("click", handleClickRef.current);
					resetOutsideInteraction();
					isPointerInsideReactTreeRef.current = false;
					return;
				}
				const eventDetail = { originalEvent: event };
				isPointerDownOutsideRef.current = true;
				isDeferredPointerDownOutsideRef.current = deferPointerDownOutside && event.button === 0;
				interceptedOutsideInteractionEventsRef.current.clear();
				if (!deferPointerDownOutside || event.button !== 0) handleAndDispatchPointerDownOutsideEvent2();
				else {
					ownerDocument.removeEventListener("click", handleClickRef.current);
					handleClickRef.current = handleAndDispatchPointerDownOutsideEvent2;
					ownerDocument.addEventListener("click", handleClickRef.current, { once: true });
				}
			} else {
				ownerDocument.removeEventListener("click", handleClickRef.current);
				resetOutsideInteraction();
			}
			isPointerInsideReactTreeRef.current = false;
		}, "handlePointerDown");
		const outsideInteractionEvents = [
			"pointerup",
			"mousedown",
			"mouseup",
			"touchstart",
			"touchend",
			"click"
		];
		for (const eventName of outsideInteractionEvents) {
			ownerDocument.addEventListener(eventName, handleInteractionCapture, true);
			ownerDocument.addEventListener(eventName, handleInteractionBubble);
		}
		const timerId = window.setTimeout(() => {
			ownerDocument.addEventListener("pointerdown", handlePointerDown);
		}, 0);
		return () => {
			window.clearTimeout(timerId);
			ownerDocument.removeEventListener("pointerdown", handlePointerDown);
			ownerDocument.removeEventListener("click", handleClickRef.current);
			for (const eventName of outsideInteractionEvents) {
				ownerDocument.removeEventListener(eventName, handleInteractionCapture, true);
				ownerDocument.removeEventListener(eventName, handleInteractionBubble);
			}
		};
	}, [
		ownerDocument,
		handlePointerDownOutside,
		deferPointerDownOutside,
		isDeferredPointerDownOutsideRef,
		dismissableSurfaces,
		shouldHandlePointerDownOutside
	]);
	return { onPointerDownCapture: /* @__PURE__ */ __name$3(() => isPointerInsideReactTreeRef.current = true, "onPointerDownCapture") };
}
__name$3(usePointerDownOutside, "usePointerDownOutside");
function useFocusOutside(onFocusOutside, ownerDocument = globalThis?.document) {
	const handleFocusOutside = useCallbackRef$1(onFocusOutside);
	const isFocusInsideReactTreeRef = import_react.useRef(false);
	import_react.useEffect(() => {
		const handleFocus = /* @__PURE__ */ __name$3((event) => {
			if (event.target && !isFocusInsideReactTreeRef.current) handleAndDispatchCustomEvent(FOCUS_OUTSIDE, handleFocusOutside, { originalEvent: event }, { discrete: false });
		}, "handleFocus");
		ownerDocument.addEventListener("focusin", handleFocus);
		return () => ownerDocument.removeEventListener("focusin", handleFocus);
	}, [ownerDocument, handleFocusOutside]);
	return {
		onFocusCapture: /* @__PURE__ */ __name$3(() => isFocusInsideReactTreeRef.current = true, "onFocusCapture"),
		onBlurCapture: /* @__PURE__ */ __name$3(() => isFocusInsideReactTreeRef.current = false, "onBlurCapture")
	};
}
__name$3(useFocusOutside, "useFocusOutside");
function dispatchUpdate() {
	const event = new CustomEvent(CONTEXT_UPDATE);
	document.dispatchEvent(event);
}
__name$3(dispatchUpdate, "dispatchUpdate");
function handleAndDispatchCustomEvent(name, handler, detail, { discrete }) {
	const target = detail.originalEvent.target;
	const event = new CustomEvent(name, {
		bubbles: false,
		cancelable: true,
		detail
	});
	if (handler) target.addEventListener(name, handler, { once: true });
	if (discrete) dispatchDiscreteCustomEvent(target, event);
	else target.dispatchEvent(event);
}
__name$3(handleAndDispatchCustomEvent, "handleAndDispatchCustomEvent");
//#endregion
//#region node_modules/@radix-ui/react-focus-scope/dist/index.mjs
var __defProp$2 = Object.defineProperty;
var __name$2 = (target, value) => __defProp$2(target, "name", {
	value,
	configurable: true
});
var AUTOFOCUS_ON_MOUNT = "focusScope.autoFocusOnMount";
var AUTOFOCUS_ON_UNMOUNT = "focusScope.autoFocusOnUnmount";
var EVENT_OPTIONS = {
	bubbles: false,
	cancelable: true
};
var FocusScope = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$2(function FocusScope2(props, forwardedRef) {
	const { loop = false, trapped = false, onMountAutoFocus: onMountAutoFocusProp, onUnmountAutoFocus: onUnmountAutoFocusProp, ...scopeProps } = props;
	const [container, setContainer] = import_react.useState(null);
	const onMountAutoFocus = useCallbackRef$1(onMountAutoFocusProp);
	const onUnmountAutoFocus = useCallbackRef$1(onUnmountAutoFocusProp);
	const lastFocusedElementRef = import_react.useRef(null);
	const composedRefs = useComposedRefs(forwardedRef, setContainer);
	const focusScope = import_react.useRef({
		paused: false,
		pause() {
			this.paused = true;
		},
		resume() {
			this.paused = false;
		}
	}).current;
	import_react.useEffect(() => {
		if (trapped) {
			let handleFocusIn2 = function(event) {
				if (focusScope.paused || !container) return;
				const target = event.target;
				if (container.contains(target)) lastFocusedElementRef.current = target;
				else focus(lastFocusedElementRef.current, { select: true });
			}, handleFocusOut2 = function(event) {
				if (focusScope.paused || !container) return;
				const relatedTarget = event.relatedTarget;
				if (relatedTarget === null) return;
				if (!container.contains(relatedTarget)) focus(lastFocusedElementRef.current, { select: true });
			}, handleMutations2 = function(mutations) {
				if (document.activeElement !== document.body) return;
				for (const mutation of mutations) if (mutation.removedNodes.length > 0) focus(container);
			};
			__name$2(handleFocusIn2, "handleFocusIn");
			__name$2(handleFocusOut2, "handleFocusOut");
			__name$2(handleMutations2, "handleMutations");
			document.addEventListener("focusin", handleFocusIn2);
			document.addEventListener("focusout", handleFocusOut2);
			const mutationObserver = new MutationObserver(handleMutations2);
			if (container) mutationObserver.observe(container, {
				childList: true,
				subtree: true
			});
			return () => {
				document.removeEventListener("focusin", handleFocusIn2);
				document.removeEventListener("focusout", handleFocusOut2);
				mutationObserver.disconnect();
			};
		}
	}, [
		trapped,
		container,
		focusScope.paused
	]);
	import_react.useEffect(() => {
		if (container) {
			focusScopesStack.add(focusScope);
			const previouslyFocusedElement = document.activeElement;
			if (!container.contains(previouslyFocusedElement)) {
				const mountEvent = new CustomEvent(AUTOFOCUS_ON_MOUNT, EVENT_OPTIONS);
				container.addEventListener(AUTOFOCUS_ON_MOUNT, onMountAutoFocus);
				container.dispatchEvent(mountEvent);
				if (!mountEvent.defaultPrevented) {
					focusFirst(removeLinks(getTabbableCandidates(container)), { select: true });
					if (document.activeElement === previouslyFocusedElement) focus(container);
				}
			}
			return () => {
				container.removeEventListener(AUTOFOCUS_ON_MOUNT, onMountAutoFocus);
				setTimeout(() => {
					const unmountEvent = new CustomEvent(AUTOFOCUS_ON_UNMOUNT, EVENT_OPTIONS);
					container.addEventListener(AUTOFOCUS_ON_UNMOUNT, onUnmountAutoFocus);
					container.dispatchEvent(unmountEvent);
					if (!unmountEvent.defaultPrevented) focus(previouslyFocusedElement ?? document.body, { select: true });
					container.removeEventListener(AUTOFOCUS_ON_UNMOUNT, onUnmountAutoFocus);
					focusScopesStack.remove(focusScope);
				}, 0);
			};
		}
	}, [
		container,
		onMountAutoFocus,
		onUnmountAutoFocus,
		focusScope
	]);
	const handleKeyDown = import_react.useCallback((event) => {
		if (!loop && !trapped) return;
		if (focusScope.paused) return;
		const isTabKey = event.key === "Tab" && !event.altKey && !event.ctrlKey && !event.metaKey;
		const focusedElement = document.activeElement;
		if (isTabKey && focusedElement) {
			const container2 = event.currentTarget;
			const [first, last] = getTabbableEdges(container2);
			if (!(first && last)) {
				if (focusedElement === container2) event.preventDefault();
			} else if (!event.shiftKey && focusedElement === last) {
				event.preventDefault();
				if (loop) focus(first, { select: true });
			} else if (event.shiftKey && focusedElement === first) {
				event.preventDefault();
				if (loop) focus(last, { select: true });
			}
		}
	}, [
		loop,
		trapped,
		focusScope.paused
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		tabIndex: -1,
		...scopeProps,
		ref: composedRefs,
		onKeyDown: handleKeyDown
	});
}, "FocusScope"));
function focusFirst(candidates, { select = false } = {}) {
	const previouslyFocusedElement = document.activeElement;
	for (const candidate of candidates) {
		focus(candidate, { select });
		if (document.activeElement !== previouslyFocusedElement) return;
	}
}
__name$2(focusFirst, "focusFirst");
function getTabbableEdges(container) {
	const candidates = getTabbableCandidates(container);
	return [findVisible(candidates, container), findVisible(candidates.reverse(), container)];
}
__name$2(getTabbableEdges, "getTabbableEdges");
function getTabbableCandidates(container) {
	const nodes = [];
	const walker = document.createTreeWalker(container, NodeFilter.SHOW_ELEMENT, { acceptNode: /* @__PURE__ */ __name$2((node) => {
		const isHiddenInput = node.tagName === "INPUT" && node.type === "hidden";
		if (node.disabled || node.hidden || isHiddenInput) return NodeFilter.FILTER_SKIP;
		return node.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
	}, "acceptNode") });
	while (walker.nextNode()) nodes.push(walker.currentNode);
	return nodes;
}
__name$2(getTabbableCandidates, "getTabbableCandidates");
function findVisible(elements, container) {
	const canUseCheckVisibility = typeof container.checkVisibility === "function" && container.checkVisibility({ checkVisibilityCSS: true });
	for (const element of elements) if (!(canUseCheckVisibility ? !element.checkVisibility({ checkVisibilityCSS: true }) : isHidden(element, { upTo: container }))) return element;
}
__name$2(findVisible, "findVisible");
function isHidden(node, { upTo }) {
	if (getComputedStyle(node).visibility === "hidden") return true;
	while (node) {
		if (upTo !== void 0 && node === upTo) return false;
		if (getComputedStyle(node).display === "none") return true;
		node = node.parentElement;
	}
	return false;
}
__name$2(isHidden, "isHidden");
function isSelectableInput(element) {
	return element instanceof HTMLInputElement && "select" in element;
}
__name$2(isSelectableInput, "isSelectableInput");
function focus(element, { select = false } = {}) {
	if (element && element.focus) {
		const previouslyFocusedElement = document.activeElement;
		element.focus({ preventScroll: true });
		if (element !== previouslyFocusedElement && isSelectableInput(element) && select) element.select();
	}
}
__name$2(focus, "focus");
var focusScopesStack = createFocusScopesStack();
function createFocusScopesStack() {
	let stack = [];
	return {
		add(focusScope) {
			const activeFocusScope = stack[0];
			if (focusScope !== activeFocusScope) activeFocusScope?.pause();
			stack = arrayRemove(stack, focusScope);
			stack.unshift(focusScope);
		},
		remove(focusScope) {
			stack = arrayRemove(stack, focusScope);
			stack[0]?.resume();
		}
	};
}
__name$2(createFocusScopesStack, "createFocusScopesStack");
function arrayRemove(array, item) {
	const updatedArray = [...array];
	const index = updatedArray.indexOf(item);
	if (index !== -1) updatedArray.splice(index, 1);
	return updatedArray;
}
__name$2(arrayRemove, "arrayRemove");
function removeLinks(items) {
	return items.filter((item) => item.tagName !== "A");
}
__name$2(removeLinks, "removeLinks");
//#endregion
//#region node_modules/@radix-ui/react-portal/dist/index.mjs
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
var __defProp$1 = Object.defineProperty;
var __name$1 = (target, value) => __defProp$1(target, "name", {
	value,
	configurable: true
});
var Portal = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function Portal2(props, forwardedRef) {
	const { container: containerProp, ...portalProps } = props;
	const [mounted, setMounted] = import_react.useState(false);
	useLayoutEffect2(() => setMounted(true), []);
	const container = containerProp || mounted && globalThis?.document?.body;
	return container ? import_react_dom.createPortal(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		...portalProps,
		ref: forwardedRef
	}), container) : null;
}, "Portal"));
//#endregion
//#region node_modules/@radix-ui/react-focus-guards/dist/index.mjs
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", {
	value,
	configurable: true
});
var count = 0;
var guards = null;
function FocusGuards(props) {
	useFocusGuards();
	return props.children;
}
__name(FocusGuards, "FocusGuards");
function useFocusGuards() {
	import_react.useEffect(() => {
		if (!guards) guards = {
			start: createFocusGuard(),
			end: createFocusGuard()
		};
		const { start, end } = guards;
		if (document.body.firstElementChild !== start) document.body.insertAdjacentElement("afterbegin", start);
		if (document.body.lastElementChild !== end) document.body.insertAdjacentElement("beforeend", end);
		count++;
		return () => {
			if (count === 1) {
				guards?.start.remove();
				guards?.end.remove();
				guards = null;
			}
			count = Math.max(0, count - 1);
		};
	}, []);
}
__name(useFocusGuards, "useFocusGuards");
function createFocusGuard() {
	const element = document.createElement("span");
	element.setAttribute("data-radix-focus-guard", "");
	element.tabIndex = 0;
	element.style.outline = "none";
	element.style.opacity = "0";
	element.style.position = "fixed";
	element.style.pointerEvents = "none";
	return element;
}
__name(createFocusGuard, "createFocusGuard");
//#endregion
//#region node_modules/react-remove-scroll-bar/dist/es2015/constants.js
var zeroRightClassName = "right-scroll-bar-position";
var fullWidthClassName = "width-before-scroll-bar";
var noScrollbarsClassName = "with-scroll-bars-hidden";
/**
* Name of a CSS variable containing the amount of "hidden" scrollbar
* ! might be undefined ! use will fallback!
*/
var removedBarSizeVariable = "--removed-body-scroll-bar-size";
//#endregion
//#region node_modules/use-callback-ref/dist/es2015/assignRef.js
/**
* Assigns a value for a given ref, no matter of the ref format
* @param {RefObject} ref - a callback function or ref object
* @param value - a new value
*
* @see https://github.com/theKashey/use-callback-ref#assignref
* @example
* const refObject = useRef();
* const refFn = (ref) => {....}
*
* assignRef(refObject, "refValue");
* assignRef(refFn, "refValue");
*/
function assignRef(ref, value) {
	if (typeof ref === "function") ref(value);
	else if (ref) ref.current = value;
	return ref;
}
//#endregion
//#region node_modules/use-callback-ref/dist/es2015/useRef.js
/**
* creates a MutableRef with ref change callback
* @param initialValue - initial ref value
* @param {Function} callback - a callback to run when value changes
*
* @example
* const ref = useCallbackRef(0, (newValue, oldValue) => console.log(oldValue, '->', newValue);
* ref.current = 1;
* // prints 0 -> 1
*
* @see https://reactjs.org/docs/hooks-reference.html#useref
* @see https://github.com/theKashey/use-callback-ref#usecallbackref---to-replace-reactuseref
* @returns {MutableRefObject}
*/
function useCallbackRef(initialValue, callback) {
	var ref = (0, import_react.useState)(function() {
		return {
			value: initialValue,
			callback,
			facade: {
				get current() {
					return ref.value;
				},
				set current(value) {
					var last = ref.value;
					if (last !== value) {
						ref.value = value;
						ref.callback(value, last);
					}
				}
			}
		};
	})[0];
	ref.callback = callback;
	return ref.facade;
}
//#endregion
//#region node_modules/use-callback-ref/dist/es2015/useMergeRef.js
var useIsomorphicLayoutEffect = typeof window !== "undefined" ? import_react.useLayoutEffect : import_react.useEffect;
var currentValues = /* @__PURE__ */ new WeakMap();
/**
* Merges two or more refs together providing a single interface to set their value
* @param {RefObject|Ref} refs
* @returns {MutableRefObject} - a new ref, which translates all changes to {refs}
*
* @see {@link mergeRefs} a version without buit-in memoization
* @see https://github.com/theKashey/use-callback-ref#usemergerefs
* @example
* const Component = React.forwardRef((props, ref) => {
*   const ownRef = useRef();
*   const domRef = useMergeRefs([ref, ownRef]); // 👈 merge together
*   return <div ref={domRef}>...</div>
* }
*/
function useMergeRefs(refs, defaultValue) {
	var callbackRef = useCallbackRef(defaultValue || null, function(newValue) {
		return refs.forEach(function(ref) {
			return assignRef(ref, newValue);
		});
	});
	useIsomorphicLayoutEffect(function() {
		var oldValue = currentValues.get(callbackRef);
		if (oldValue) {
			var prevRefs_1 = new Set(oldValue);
			var nextRefs_1 = new Set(refs);
			var current_1 = callbackRef.current;
			prevRefs_1.forEach(function(ref) {
				if (!nextRefs_1.has(ref)) assignRef(ref, null);
			});
			nextRefs_1.forEach(function(ref) {
				if (!prevRefs_1.has(ref)) assignRef(ref, current_1);
			});
		}
		currentValues.set(callbackRef, refs);
	}, [refs]);
	return callbackRef;
}
//#endregion
//#region node_modules/use-sidecar/dist/es2015/medium.js
function ItoI(a) {
	return a;
}
function innerCreateMedium(defaults, middleware) {
	if (middleware === void 0) middleware = ItoI;
	var buffer = [];
	var assigned = false;
	return {
		read: function() {
			if (assigned) throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
			if (buffer.length) return buffer[buffer.length - 1];
			return defaults;
		},
		useMedium: function(data) {
			var item = middleware(data, assigned);
			buffer.push(item);
			return function() {
				buffer = buffer.filter(function(x) {
					return x !== item;
				});
			};
		},
		assignSyncMedium: function(cb) {
			assigned = true;
			while (buffer.length) {
				var cbs = buffer;
				buffer = [];
				cbs.forEach(cb);
			}
			buffer = {
				push: function(x) {
					return cb(x);
				},
				filter: function() {
					return buffer;
				}
			};
		},
		assignMedium: function(cb) {
			assigned = true;
			var pendingQueue = [];
			if (buffer.length) {
				var cbs = buffer;
				buffer = [];
				cbs.forEach(cb);
				pendingQueue = buffer;
			}
			var executeQueue = function() {
				var cbs = pendingQueue;
				pendingQueue = [];
				cbs.forEach(cb);
			};
			var cycle = function() {
				return Promise.resolve().then(executeQueue);
			};
			cycle();
			buffer = {
				push: function(x) {
					pendingQueue.push(x);
					cycle();
				},
				filter: function(filter) {
					pendingQueue = pendingQueue.filter(filter);
					return buffer;
				}
			};
		}
	};
}
function createSidecarMedium(options) {
	if (options === void 0) options = {};
	var medium = innerCreateMedium(null);
	medium.options = __assign({
		async: true,
		ssr: false
	}, options);
	return medium;
}
//#endregion
//#region node_modules/use-sidecar/dist/es2015/exports.js
var SideCar = function(_a) {
	var sideCar = _a.sideCar, rest = __rest(_a, ["sideCar"]);
	if (!sideCar) throw new Error("Sidecar: please provide `sideCar` property to import the right car");
	var Target = sideCar.read();
	if (!Target) throw new Error("Sidecar medium not found");
	return import_react.createElement(Target, __assign({}, rest));
};
SideCar.isSideCarExport = true;
function exportSidecar(medium, exported) {
	medium.useMedium(exported);
	return SideCar;
}
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/medium.js
var effectCar = createSidecarMedium();
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/UI.js
var nothing = function() {};
/**
* Removes scrollbar from the page and contain the scroll within the Lock
*/
var RemoveScroll = import_react.forwardRef(function(props, parentRef) {
	var ref = import_react.useRef(null);
	var _a = import_react.useState({
		onScrollCapture: nothing,
		onWheelCapture: nothing,
		onTouchMoveCapture: nothing
	}), callbacks = _a[0], setCallbacks = _a[1];
	var forwardProps = props.forwardProps, children = props.children, className = props.className, removeScrollBar = props.removeScrollBar, enabled = props.enabled, shards = props.shards, sideCar = props.sideCar, noRelative = props.noRelative, noIsolation = props.noIsolation, inert = props.inert, allowPinchZoom = props.allowPinchZoom, _b = props.as, Container = _b === void 0 ? "div" : _b, gapMode = props.gapMode, rest = __rest(props, [
		"forwardProps",
		"children",
		"className",
		"removeScrollBar",
		"enabled",
		"shards",
		"sideCar",
		"noRelative",
		"noIsolation",
		"inert",
		"allowPinchZoom",
		"as",
		"gapMode"
	]);
	var SideCar = sideCar;
	var containerRef = useMergeRefs([ref, parentRef]);
	var containerProps = __assign(__assign({}, rest), callbacks);
	return import_react.createElement(import_react.Fragment, null, enabled && import_react.createElement(SideCar, {
		sideCar: effectCar,
		removeScrollBar,
		shards,
		noRelative,
		noIsolation,
		inert,
		setCallbacks,
		allowPinchZoom: !!allowPinchZoom,
		lockRef: ref,
		gapMode
	}), forwardProps ? import_react.cloneElement(import_react.Children.only(children), __assign(__assign({}, containerProps), { ref: containerRef })) : import_react.createElement(Container, __assign({}, containerProps, {
		className,
		ref: containerRef
	}), children));
});
RemoveScroll.defaultProps = {
	enabled: true,
	removeScrollBar: true,
	inert: false
};
RemoveScroll.classNames = {
	fullWidth: fullWidthClassName,
	zeroRight: zeroRightClassName
};
var getNonce = function() {
	if (typeof __webpack_nonce__ !== "undefined") return __webpack_nonce__;
};
//#endregion
//#region node_modules/react-style-singleton/dist/es2015/singleton.js
function makeStyleTag() {
	if (!document) return null;
	var tag = document.createElement("style");
	tag.type = "text/css";
	var nonce = getNonce();
	if (nonce) tag.setAttribute("nonce", nonce);
	return tag;
}
function injectStyles(tag, css) {
	if (tag.styleSheet) tag.styleSheet.cssText = css;
	else tag.appendChild(document.createTextNode(css));
}
function insertStyleTag(tag) {
	(document.head || document.getElementsByTagName("head")[0]).appendChild(tag);
}
var stylesheetSingleton = function() {
	var counter = 0;
	var stylesheet = null;
	return {
		add: function(style) {
			if (counter == 0) {
				if (stylesheet = makeStyleTag()) {
					injectStyles(stylesheet, style);
					insertStyleTag(stylesheet);
				}
			}
			counter++;
		},
		remove: function() {
			counter--;
			if (!counter && stylesheet) {
				stylesheet.parentNode && stylesheet.parentNode.removeChild(stylesheet);
				stylesheet = null;
			}
		}
	};
};
//#endregion
//#region node_modules/react-style-singleton/dist/es2015/hook.js
/**
* creates a hook to control style singleton
* @see {@link styleSingleton} for a safer component version
* @example
* ```tsx
* const useStyle = styleHookSingleton();
* ///
* useStyle('body { overflow: hidden}');
*/
var styleHookSingleton = function() {
	var sheet = stylesheetSingleton();
	return function(styles, isDynamic) {
		import_react.useEffect(function() {
			sheet.add(styles);
			return function() {
				sheet.remove();
			};
		}, [styles && isDynamic]);
	};
};
//#endregion
//#region node_modules/react-style-singleton/dist/es2015/component.js
/**
* create a Component to add styles on demand
* - styles are added when first instance is mounted
* - styles are removed when the last instance is unmounted
* - changing styles in runtime does nothing unless dynamic is set. But with multiple components that can lead to the undefined behavior
*/
var styleSingleton = function() {
	var useStyle = styleHookSingleton();
	var Sheet = function(_a) {
		var styles = _a.styles, dynamic = _a.dynamic;
		useStyle(styles, dynamic);
		return null;
	};
	return Sheet;
};
//#endregion
//#region node_modules/react-remove-scroll-bar/dist/es2015/utils.js
var zeroGap = {
	left: 0,
	top: 0,
	right: 0,
	gap: 0
};
var parse = function(x) {
	return parseInt(x || "", 10) || 0;
};
var getOffset = function(gapMode) {
	var cs = window.getComputedStyle(document.body);
	var left = cs[gapMode === "padding" ? "paddingLeft" : "marginLeft"];
	var top = cs[gapMode === "padding" ? "paddingTop" : "marginTop"];
	var right = cs[gapMode === "padding" ? "paddingRight" : "marginRight"];
	return [
		parse(left),
		parse(top),
		parse(right)
	];
};
var getGapWidth = function(gapMode) {
	if (gapMode === void 0) gapMode = "margin";
	if (typeof window === "undefined") return zeroGap;
	var offsets = getOffset(gapMode);
	var documentWidth = document.documentElement.clientWidth;
	var windowWidth = window.innerWidth;
	return {
		left: offsets[0],
		top: offsets[1],
		right: offsets[2],
		gap: Math.max(0, windowWidth - documentWidth + offsets[2] - offsets[0])
	};
};
//#endregion
//#region node_modules/react-remove-scroll-bar/dist/es2015/component.js
var Style = styleSingleton();
var lockAttribute = "data-scroll-locked";
var getStyles = function(_a, allowRelative, gapMode, important) {
	var left = _a.left, top = _a.top, right = _a.right, gap = _a.gap;
	if (gapMode === void 0) gapMode = "margin";
	return "\n  .".concat(noScrollbarsClassName, " {\n   overflow: hidden ").concat(important, ";\n   padding-right: ").concat(gap, "px ").concat(important, ";\n  }\n  body[").concat(lockAttribute, "] {\n    overflow: hidden ").concat(important, ";\n    overscroll-behavior: contain;\n    ").concat([
		allowRelative && "position: relative ".concat(important, ";"),
		gapMode === "margin" && "\n    padding-left: ".concat(left, "px;\n    padding-top: ").concat(top, "px;\n    padding-right: ").concat(right, "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: ").concat(gap, "px ").concat(important, ";\n    "),
		gapMode === "padding" && "padding-right: ".concat(gap, "px ").concat(important, ";")
	].filter(Boolean).join(""), "\n  }\n  \n  .").concat(zeroRightClassName, " {\n    right: ").concat(gap, "px ").concat(important, ";\n  }\n  \n  .").concat(fullWidthClassName, " {\n    margin-right: ").concat(gap, "px ").concat(important, ";\n  }\n  \n  .").concat(zeroRightClassName, " .").concat(zeroRightClassName, " {\n    right: 0 ").concat(important, ";\n  }\n  \n  .").concat(fullWidthClassName, " .").concat(fullWidthClassName, " {\n    margin-right: 0 ").concat(important, ";\n  }\n  \n  body[").concat(lockAttribute, "] {\n    ").concat(removedBarSizeVariable, ": ").concat(gap, "px;\n  }\n");
};
var getCurrentUseCounter = function() {
	var counter = parseInt(document.body.getAttribute("data-scroll-locked") || "0", 10);
	return isFinite(counter) ? counter : 0;
};
var useLockAttribute = function() {
	import_react.useEffect(function() {
		document.body.setAttribute(lockAttribute, (getCurrentUseCounter() + 1).toString());
		return function() {
			var newCounter = getCurrentUseCounter() - 1;
			if (newCounter <= 0) document.body.removeAttribute(lockAttribute);
			else document.body.setAttribute(lockAttribute, newCounter.toString());
		};
	}, []);
};
/**
* Removes page scrollbar and blocks page scroll when mounted
*/
var RemoveScrollBar = function(_a) {
	var noRelative = _a.noRelative, noImportant = _a.noImportant, _b = _a.gapMode, gapMode = _b === void 0 ? "margin" : _b;
	useLockAttribute();
	var gap = import_react.useMemo(function() {
		return getGapWidth(gapMode);
	}, [gapMode]);
	return import_react.createElement(Style, { styles: getStyles(gap, !noRelative, gapMode, !noImportant ? "!important" : "") });
};
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/aggresiveCapture.js
var passiveSupported = false;
if (typeof window !== "undefined") try {
	var options = Object.defineProperty({}, "passive", { get: function() {
		passiveSupported = true;
		return true;
	} });
	window.addEventListener("test", options, options);
	window.removeEventListener("test", options, options);
} catch (err) {
	passiveSupported = false;
}
var nonPassive = passiveSupported ? { passive: false } : false;
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/handleScroll.js
var alwaysContainsScroll = function(node) {
	return node.tagName === "TEXTAREA";
};
var elementCanBeScrolled = function(node, overflow) {
	if (!(node instanceof Element)) return false;
	var styles = window.getComputedStyle(node);
	return styles[overflow] !== "hidden" && !(styles.overflowY === styles.overflowX && !alwaysContainsScroll(node) && styles[overflow] === "visible");
};
var elementCouldBeVScrolled = function(node) {
	return elementCanBeScrolled(node, "overflowY");
};
var elementCouldBeHScrolled = function(node) {
	return elementCanBeScrolled(node, "overflowX");
};
var locationCouldBeScrolled = function(axis, node) {
	var ownerDocument = node.ownerDocument;
	var current = node;
	do {
		if (typeof ShadowRoot !== "undefined" && current instanceof ShadowRoot) current = current.host;
		if (elementCouldBeScrolled(axis, current)) {
			var _a = getScrollVariables(axis, current);
			if (_a[1] > _a[2]) return true;
		}
		current = current.parentNode;
	} while (current && current !== ownerDocument.body);
	return false;
};
var getVScrollVariables = function(_a) {
	return [
		_a.scrollTop,
		_a.scrollHeight,
		_a.clientHeight
	];
};
var getHScrollVariables = function(_a) {
	return [
		_a.scrollLeft,
		_a.scrollWidth,
		_a.clientWidth
	];
};
var elementCouldBeScrolled = function(axis, node) {
	return axis === "v" ? elementCouldBeVScrolled(node) : elementCouldBeHScrolled(node);
};
var getScrollVariables = function(axis, node) {
	return axis === "v" ? getVScrollVariables(node) : getHScrollVariables(node);
};
var getDirectionFactor = function(axis, direction) {
	/**
	* If the element's direction is rtl (right-to-left), then scrollLeft is 0 when the scrollbar is at its rightmost position,
	* and then increasingly negative as you scroll towards the end of the content.
	* @see https://developer.mozilla.org/en-US/docs/Web/API/Element/scrollLeft
	*/
	return axis === "h" && direction === "rtl" ? -1 : 1;
};
var handleScroll = function(axis, endTarget, event, sourceDelta, noOverscroll) {
	var directionFactor = getDirectionFactor(axis, window.getComputedStyle(endTarget).direction);
	var delta = directionFactor * sourceDelta;
	var target = event.target;
	var targetInLock = endTarget.contains(target);
	var shouldCancelScroll = false;
	var isDeltaPositive = delta > 0;
	var availableScroll = 0;
	var availableScrollTop = 0;
	do {
		if (!target) break;
		var _a = getScrollVariables(axis, target), position = _a[0];
		var elementScroll = _a[1] - _a[2] - directionFactor * position;
		if (position || elementScroll) {
			if (elementCouldBeScrolled(axis, target)) {
				availableScroll += elementScroll;
				availableScrollTop += position;
			}
		}
		var parent_1 = target.parentNode;
		target = parent_1 && parent_1.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? parent_1.host : parent_1;
	} while (!targetInLock && target !== document.body || targetInLock && (endTarget.contains(target) || endTarget === target));
	if (isDeltaPositive && (noOverscroll && Math.abs(availableScroll) < 1 || !noOverscroll && delta > availableScroll)) shouldCancelScroll = true;
	else if (!isDeltaPositive && (noOverscroll && Math.abs(availableScrollTop) < 1 || !noOverscroll && -delta > availableScrollTop)) shouldCancelScroll = true;
	return shouldCancelScroll;
};
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/SideEffect.js
var getTouchXY = function(event) {
	return "changedTouches" in event ? [event.changedTouches[0].clientX, event.changedTouches[0].clientY] : [0, 0];
};
var getDeltaXY = function(event) {
	return [event.deltaX, event.deltaY];
};
var extractRef = function(ref) {
	return ref && "current" in ref ? ref.current : ref;
};
var deltaCompare = function(x, y) {
	return x[0] === y[0] && x[1] === y[1];
};
var generateStyle = function(id) {
	return "\n  .block-interactivity-".concat(id, " {pointer-events: none;}\n  .allow-interactivity-").concat(id, " {pointer-events: all;}\n");
};
var idCounter = 0;
var lockStack = [];
function RemoveScrollSideCar(props) {
	var shouldPreventQueue = import_react.useRef([]);
	var touchStartRef = import_react.useRef([0, 0]);
	var activeAxis = import_react.useRef();
	var id = import_react.useState(idCounter++)[0];
	var Style = import_react.useState(styleSingleton)[0];
	var lastProps = import_react.useRef(props);
	import_react.useEffect(function() {
		lastProps.current = props;
	}, [props]);
	import_react.useEffect(function() {
		if (props.inert) {
			document.body.classList.add("block-interactivity-".concat(id));
			var allow_1 = __spreadArray([props.lockRef.current], (props.shards || []).map(extractRef), true).filter(Boolean);
			allow_1.forEach(function(el) {
				return el.classList.add("allow-interactivity-".concat(id));
			});
			return function() {
				document.body.classList.remove("block-interactivity-".concat(id));
				allow_1.forEach(function(el) {
					return el.classList.remove("allow-interactivity-".concat(id));
				});
			};
		}
	}, [
		props.inert,
		props.lockRef.current,
		props.shards
	]);
	var shouldCancelEvent = import_react.useCallback(function(event, parent) {
		if ("touches" in event && event.touches.length === 2 || event.type === "wheel" && event.ctrlKey) return !lastProps.current.allowPinchZoom;
		var touch = getTouchXY(event);
		var touchStart = touchStartRef.current;
		var deltaX = "deltaX" in event ? event.deltaX : touchStart[0] - touch[0];
		var deltaY = "deltaY" in event ? event.deltaY : touchStart[1] - touch[1];
		var currentAxis;
		var target = event.target;
		var moveDirection = Math.abs(deltaX) > Math.abs(deltaY) ? "h" : "v";
		if ("touches" in event && moveDirection === "h" && target.type === "range") return false;
		var selection = window.getSelection();
		var anchorNode = selection && selection.anchorNode;
		if (anchorNode ? anchorNode === target || anchorNode.contains(target) : false) return false;
		var canBeScrolledInMainDirection = locationCouldBeScrolled(moveDirection, target);
		if (!canBeScrolledInMainDirection) return true;
		if (canBeScrolledInMainDirection) currentAxis = moveDirection;
		else {
			currentAxis = moveDirection === "v" ? "h" : "v";
			canBeScrolledInMainDirection = locationCouldBeScrolled(moveDirection, target);
		}
		if (!canBeScrolledInMainDirection) return false;
		if (!activeAxis.current && "changedTouches" in event && (deltaX || deltaY)) activeAxis.current = currentAxis;
		if (!currentAxis) return true;
		var cancelingAxis = activeAxis.current || currentAxis;
		return handleScroll(cancelingAxis, parent, event, cancelingAxis === "h" ? deltaX : deltaY, true);
	}, []);
	var shouldPrevent = import_react.useCallback(function(_event) {
		var event = _event;
		if (!lockStack.length || lockStack[lockStack.length - 1] !== Style) return;
		var delta = "deltaY" in event ? getDeltaXY(event) : getTouchXY(event);
		var sourceEvent = shouldPreventQueue.current.filter(function(e) {
			return e.name === event.type && (e.target === event.target || event.target === e.shadowParent) && deltaCompare(e.delta, delta);
		})[0];
		if (sourceEvent && sourceEvent.should) {
			if (event.cancelable) event.preventDefault();
			return;
		}
		if (!sourceEvent) {
			var shardNodes = (lastProps.current.shards || []).map(extractRef).filter(Boolean).filter(function(node) {
				return node.contains(event.target);
			});
			if (shardNodes.length > 0 ? shouldCancelEvent(event, shardNodes[0]) : !lastProps.current.noIsolation) {
				if (event.cancelable) event.preventDefault();
			}
		}
	}, []);
	var shouldCancel = import_react.useCallback(function(name, delta, target, should) {
		var event = {
			name,
			delta,
			target,
			should,
			shadowParent: getOutermostShadowParent(target)
		};
		shouldPreventQueue.current.push(event);
		setTimeout(function() {
			shouldPreventQueue.current = shouldPreventQueue.current.filter(function(e) {
				return e !== event;
			});
		}, 1);
	}, []);
	var scrollTouchStart = import_react.useCallback(function(event) {
		touchStartRef.current = getTouchXY(event);
		activeAxis.current = void 0;
	}, []);
	var scrollWheel = import_react.useCallback(function(event) {
		shouldCancel(event.type, getDeltaXY(event), event.target, shouldCancelEvent(event, props.lockRef.current));
	}, []);
	var scrollTouchMove = import_react.useCallback(function(event) {
		shouldCancel(event.type, getTouchXY(event), event.target, shouldCancelEvent(event, props.lockRef.current));
	}, []);
	import_react.useEffect(function() {
		lockStack.push(Style);
		props.setCallbacks({
			onScrollCapture: scrollWheel,
			onWheelCapture: scrollWheel,
			onTouchMoveCapture: scrollTouchMove
		});
		document.addEventListener("wheel", shouldPrevent, nonPassive);
		document.addEventListener("touchmove", shouldPrevent, nonPassive);
		document.addEventListener("touchstart", scrollTouchStart, nonPassive);
		return function() {
			lockStack = lockStack.filter(function(inst) {
				return inst !== Style;
			});
			document.removeEventListener("wheel", shouldPrevent, nonPassive);
			document.removeEventListener("touchmove", shouldPrevent, nonPassive);
			document.removeEventListener("touchstart", scrollTouchStart, nonPassive);
		};
	}, []);
	var removeScrollBar = props.removeScrollBar, inert = props.inert;
	return import_react.createElement(import_react.Fragment, null, inert ? import_react.createElement(Style, { styles: generateStyle(id) }) : null, removeScrollBar ? import_react.createElement(RemoveScrollBar, {
		noRelative: props.noRelative,
		gapMode: props.gapMode
	}) : null);
}
function getOutermostShadowParent(node) {
	var shadowParent = null;
	while (node !== null) {
		if (node instanceof ShadowRoot) {
			shadowParent = node.host;
			node = node.host;
		}
		node = node.parentNode;
	}
	return shadowParent;
}
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/sidecar.js
var sidecar_default = exportSidecar(effectCar, RemoveScrollSideCar);
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/Combination.js
var ReactRemoveScroll = import_react.forwardRef(function(props, ref) {
	return import_react.createElement(RemoveScroll, __assign({}, props, {
		ref,
		sideCar: sidecar_default
	}));
});
ReactRemoveScroll.classNames = RemoveScroll.classNames;
//#endregion
//#region node_modules/aria-hidden/dist/es2015/index.js
var getDefaultParent = function(originalTarget) {
	if (typeof document === "undefined") return null;
	return (Array.isArray(originalTarget) ? originalTarget[0] : originalTarget).ownerDocument.body;
};
var counterMap = /* @__PURE__ */ new WeakMap();
var uncontrolledNodes = /* @__PURE__ */ new WeakMap();
var markerMap = {};
var lockCount = 0;
var unwrapHost = function(node) {
	return node && (node.host || unwrapHost(node.parentNode));
};
var correctTargets = function(parent, targets) {
	return targets.map(function(target) {
		if (parent.contains(target)) return target;
		var correctedTarget = unwrapHost(target);
		if (correctedTarget && parent.contains(correctedTarget)) return correctedTarget;
		console.error("aria-hidden", target, "in not contained inside", parent, ". Doing nothing");
		return null;
	}).filter(function(x) {
		return Boolean(x);
	});
};
/**
* Marks everything except given node(or nodes) as aria-hidden
* @param {Element | Element[]} originalTarget - elements to keep on the page
* @param [parentNode] - top element, defaults to document.body
* @param {String} [markerName] - a special attribute to mark every node
* @param {String} [controlAttribute] - html Attribute to control
* @return {Undo} undo command
*/
var applyAttributeToOthers = function(originalTarget, parentNode, markerName, controlAttribute) {
	var targets = correctTargets(parentNode, Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
	if (!markerMap[markerName]) markerMap[markerName] = /* @__PURE__ */ new WeakMap();
	var markerCounter = markerMap[markerName];
	var hiddenNodes = [];
	var elementsToKeep = /* @__PURE__ */ new Set();
	var elementsToStop = new Set(targets);
	var keep = function(el) {
		if (!el || elementsToKeep.has(el)) return;
		elementsToKeep.add(el);
		keep(el.parentNode);
	};
	targets.forEach(keep);
	var deep = function(parent) {
		if (!parent || elementsToStop.has(parent)) return;
		Array.prototype.forEach.call(parent.children, function(node) {
			if (elementsToKeep.has(node)) deep(node);
			else try {
				var attr = node.getAttribute(controlAttribute);
				var alreadyHidden = attr !== null && attr !== "false";
				var counterValue = (counterMap.get(node) || 0) + 1;
				var markerValue = (markerCounter.get(node) || 0) + 1;
				counterMap.set(node, counterValue);
				markerCounter.set(node, markerValue);
				hiddenNodes.push(node);
				if (counterValue === 1 && alreadyHidden) uncontrolledNodes.set(node, true);
				if (markerValue === 1) node.setAttribute(markerName, "true");
				if (!alreadyHidden) node.setAttribute(controlAttribute, "true");
			} catch (e) {
				console.error("aria-hidden: cannot operate on ", node, e);
			}
		});
	};
	deep(parentNode);
	elementsToKeep.clear();
	lockCount++;
	return function() {
		hiddenNodes.forEach(function(node) {
			var counterValue = counterMap.get(node) - 1;
			var markerValue = markerCounter.get(node) - 1;
			counterMap.set(node, counterValue);
			markerCounter.set(node, markerValue);
			if (!counterValue) {
				if (!uncontrolledNodes.has(node)) node.removeAttribute(controlAttribute);
				uncontrolledNodes.delete(node);
			}
			if (!markerValue) node.removeAttribute(markerName);
		});
		lockCount--;
		if (!lockCount) {
			counterMap = /* @__PURE__ */ new WeakMap();
			counterMap = /* @__PURE__ */ new WeakMap();
			uncontrolledNodes = /* @__PURE__ */ new WeakMap();
			markerMap = {};
		}
	};
};
/**
* Marks everything except given node(or nodes) as aria-hidden
* @param {Element | Element[]} originalTarget - elements to keep on the page
* @param [parentNode] - top element, defaults to document.body
* @param {String} [markerName] - a special attribute to mark every node
* @return {Undo} undo command
*/
var hideOthers = function(originalTarget, parentNode, markerName) {
	if (markerName === void 0) markerName = "data-aria-hidden";
	var targets = Array.from(Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
	var activeParentNode = parentNode || getDefaultParent(originalTarget);
	if (!activeParentNode) return function() {
		return null;
	};
	targets.push.apply(targets, Array.from(activeParentNode.querySelectorAll("[aria-live], script")));
	return applyAttributeToOthers(targets, activeParentNode, markerName, "aria-hidden");
};
//#endregion
export { FocusScope as a, Portal as i, ReactRemoveScroll as n, DismissableLayer as o, useFocusGuards as r, useDismissableLayerSurface as s, hideOthers as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXMyMDE1LURMV1lJQ1V0LmpzIiwibmFtZXMiOlsiX19kZWZQcm9wIiwiX19uYW1lIiwidXNlQ2FsbGJhY2tSZWYiLCJfX2RlZlByb3AiLCJfX25hbWUiLCJ1c2VDYWxsYmFja1JlZiIsIl9fZGVmUHJvcCIsIl9fbmFtZSIsInVzZVN0YXRlIiwiU2lkZUNhciJdLCJzb3VyY2VzIjpbIi4uLy4uL0ByYWRpeC11aS9yZWFjdC1kaXNtaXNzYWJsZS1sYXllci9kaXN0L2luZGV4Lm1qcyIsIi4uLy4uL0ByYWRpeC11aS9yZWFjdC1mb2N1cy1zY29wZS9kaXN0L2luZGV4Lm1qcyIsIi4uLy4uL0ByYWRpeC11aS9yZWFjdC1wb3J0YWwvZGlzdC9pbmRleC5tanMiLCIuLi8uLi9AcmFkaXgtdWkvcmVhY3QtZm9jdXMtZ3VhcmRzL2Rpc3QvaW5kZXgubWpzIiwiLi4vLi4vcmVhY3QtcmVtb3ZlLXNjcm9sbC1iYXIvZGlzdC9lczIwMTUvY29uc3RhbnRzLmpzIiwiLi4vLi4vdXNlLWNhbGxiYWNrLXJlZi9kaXN0L2VzMjAxNS9hc3NpZ25SZWYuanMiLCIuLi8uLi91c2UtY2FsbGJhY2stcmVmL2Rpc3QvZXMyMDE1L3VzZVJlZi5qcyIsIi4uLy4uL3VzZS1jYWxsYmFjay1yZWYvZGlzdC9lczIwMTUvdXNlTWVyZ2VSZWYuanMiLCIuLi8uLi91c2Utc2lkZWNhci9kaXN0L2VzMjAxNS9tZWRpdW0uanMiLCIuLi8uLi91c2Utc2lkZWNhci9kaXN0L2VzMjAxNS9leHBvcnRzLmpzIiwiLi4vLi4vcmVhY3QtcmVtb3ZlLXNjcm9sbC9kaXN0L2VzMjAxNS9tZWRpdW0uanMiLCIuLi8uLi9yZWFjdC1yZW1vdmUtc2Nyb2xsL2Rpc3QvZXMyMDE1L1VJLmpzIiwiLi4vLi4vZ2V0LW5vbmNlL2Rpc3QvZXMyMDE1L2luZGV4LmpzIiwiLi4vLi4vcmVhY3Qtc3R5bGUtc2luZ2xldG9uL2Rpc3QvZXMyMDE1L3NpbmdsZXRvbi5qcyIsIi4uLy4uL3JlYWN0LXN0eWxlLXNpbmdsZXRvbi9kaXN0L2VzMjAxNS9ob29rLmpzIiwiLi4vLi4vcmVhY3Qtc3R5bGUtc2luZ2xldG9uL2Rpc3QvZXMyMDE1L2NvbXBvbmVudC5qcyIsIi4uLy4uL3JlYWN0LXJlbW92ZS1zY3JvbGwtYmFyL2Rpc3QvZXMyMDE1L3V0aWxzLmpzIiwiLi4vLi4vcmVhY3QtcmVtb3ZlLXNjcm9sbC1iYXIvZGlzdC9lczIwMTUvY29tcG9uZW50LmpzIiwiLi4vLi4vcmVhY3QtcmVtb3ZlLXNjcm9sbC9kaXN0L2VzMjAxNS9hZ2dyZXNpdmVDYXB0dXJlLmpzIiwiLi4vLi4vcmVhY3QtcmVtb3ZlLXNjcm9sbC9kaXN0L2VzMjAxNS9oYW5kbGVTY3JvbGwuanMiLCIuLi8uLi9yZWFjdC1yZW1vdmUtc2Nyb2xsL2Rpc3QvZXMyMDE1L1NpZGVFZmZlY3QuanMiLCIuLi8uLi9yZWFjdC1yZW1vdmUtc2Nyb2xsL2Rpc3QvZXMyMDE1L3NpZGVjYXIuanMiLCIuLi8uLi9yZWFjdC1yZW1vdmUtc2Nyb2xsL2Rpc3QvZXMyMDE1L0NvbWJpbmF0aW9uLmpzIiwiLi4vLi4vYXJpYS1oaWRkZW4vZGlzdC9lczIwMTUvaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2UgY2xpZW50XCI7XG52YXIgX19kZWZQcm9wID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fbmFtZSA9ICh0YXJnZXQsIHZhbHVlKSA9PiBfX2RlZlByb3AodGFyZ2V0LCBcIm5hbWVcIiwgeyB2YWx1ZSwgY29uZmlndXJhYmxlOiB0cnVlIH0pO1xuXG4vLyBzcmMvZGlzbWlzc2FibGUtbGF5ZXIudHN4XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNvbXBvc2VFdmVudEhhbmRsZXJzIH0gZnJvbSBcIkByYWRpeC11aS9wcmltaXRpdmVcIjtcbmltcG9ydCB7IFByaW1pdGl2ZSwgZGlzcGF0Y2hEaXNjcmV0ZUN1c3RvbUV2ZW50IH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1wcmltaXRpdmVcIjtcbmltcG9ydCB7IHVzZUNvbXBvc2VkUmVmcyB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtY29tcG9zZS1yZWZzXCI7XG5pbXBvcnQgeyB1c2VDYWxsYmFja1JlZiB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtdXNlLWNhbGxiYWNrLXJlZlwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG52YXIgQ09OVEVYVF9VUERBVEUgPSBcImRpc21pc3NhYmxlTGF5ZXIudXBkYXRlXCI7XG52YXIgUE9JTlRFUl9ET1dOX09VVFNJREUgPSBcImRpc21pc3NhYmxlTGF5ZXIucG9pbnRlckRvd25PdXRzaWRlXCI7XG52YXIgRk9DVVNfT1VUU0lERSA9IFwiZGlzbWlzc2FibGVMYXllci5mb2N1c091dHNpZGVcIjtcbnZhciBvcmlnaW5hbEJvZHlQb2ludGVyRXZlbnRzO1xudmFyIERpc21pc3NhYmxlTGF5ZXJDb250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dCh7XG4gIGxheWVyczogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSxcbiAgbGF5ZXJzV2l0aE91dHNpZGVQb2ludGVyRXZlbnRzRGlzYWJsZWQ6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCksXG4gIGJyYW5jaGVzOiAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpLFxuICAvLyBPdXRzaWRlIGVsZW1lbnRzIHRoYXQgYmVsb25nIHRvIGEgbGF5ZXIncyBvd24gZGlzbWlzcyBhZmZvcmRhbmNlIChlZywgYVxuICAvLyBkaWFsb2cgb3ZlcmxheSkuIFByZXNzaW5nIHRoZW0gc2hvdWxkIGRpc21pc3MgdGhlIGxheWVyIHJlZ2FyZGxlc3Mgb2ZcbiAgLy8gd2hldGhlciBvciBub3QgdGhleSBzdG9wIHByb3BhZ2F0aW9uLlxuICAvL1xuICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL3JhZGl4LXVpL3ByaW1pdGl2ZXMvaXNzdWVzLzMzNDZcbiAgZGlzbWlzc2FibGVTdXJmYWNlczogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKVxufSk7XG52YXIgRGlzbWlzc2FibGVMYXllciA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvLyBibGFuayBsaW5lIHRvIHJlZHVjZSBkaWZmIG5vaXNlXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gRGlzbWlzc2FibGVMYXllcjIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHtcbiAgICAgIGRpc2FibGVPdXRzaWRlUG9pbnRlckV2ZW50cyA9IGZhbHNlLFxuICAgICAgZGVmZXJQb2ludGVyRG93bk91dHNpZGUgPSBmYWxzZSxcbiAgICAgIG9uRXNjYXBlS2V5RG93bixcbiAgICAgIG9uUG9pbnRlckRvd25PdXRzaWRlLFxuICAgICAgb25Gb2N1c091dHNpZGUsXG4gICAgICBvbkludGVyYWN0T3V0c2lkZSxcbiAgICAgIG9uRGlzbWlzcyxcbiAgICAgIC4uLmxheWVyUHJvcHNcbiAgICB9ID0gcHJvcHM7XG4gICAgY29uc3QgY29udGV4dCA9IFJlYWN0LnVzZUNvbnRleHQoRGlzbWlzc2FibGVMYXllckNvbnRleHQpO1xuICAgIGNvbnN0IFtub2RlLCBzZXROb2RlXSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IG93bmVyRG9jdW1lbnQgPSBub2RlPy5vd25lckRvY3VtZW50ID8/IGdsb2JhbFRoaXM/LmRvY3VtZW50O1xuICAgIGNvbnN0IFssIGZvcmNlXSA9IFJlYWN0LnVzZVN0YXRlKHt9KTtcbiAgICBjb25zdCBjb21wb3NlZFJlZnMgPSB1c2VDb21wb3NlZFJlZnMoZm9yd2FyZGVkUmVmLCBzZXROb2RlKTtcbiAgICBjb25zdCBsYXllcnMgPSBBcnJheS5mcm9tKGNvbnRleHQubGF5ZXJzKTtcbiAgICBjb25zdCBbaGlnaGVzdExheWVyV2l0aE91dHNpZGVQb2ludGVyRXZlbnRzRGlzYWJsZWRdID0gW1xuICAgICAgLi4uY29udGV4dC5sYXllcnNXaXRoT3V0c2lkZVBvaW50ZXJFdmVudHNEaXNhYmxlZFxuICAgIF0uc2xpY2UoLTEpO1xuICAgIGNvbnN0IGhpZ2hlc3RMYXllcldpdGhPdXRzaWRlUG9pbnRlckV2ZW50c0Rpc2FibGVkSW5kZXggPSBoaWdoZXN0TGF5ZXJXaXRoT3V0c2lkZVBvaW50ZXJFdmVudHNEaXNhYmxlZCA/IGxheWVycy5pbmRleE9mKGhpZ2hlc3RMYXllcldpdGhPdXRzaWRlUG9pbnRlckV2ZW50c0Rpc2FibGVkKSA6IC0xO1xuICAgIGNvbnN0IGluZGV4ID0gbm9kZSA/IGxheWVycy5pbmRleE9mKG5vZGUpIDogLTE7XG4gICAgY29uc3QgaXNCb2R5UG9pbnRlckV2ZW50c0Rpc2FibGVkID0gY29udGV4dC5sYXllcnNXaXRoT3V0c2lkZVBvaW50ZXJFdmVudHNEaXNhYmxlZC5zaXplID4gMDtcbiAgICBjb25zdCBpc1BvaW50ZXJFdmVudHNFbmFibGVkID0gaW5kZXggPj0gaGlnaGVzdExheWVyV2l0aE91dHNpZGVQb2ludGVyRXZlbnRzRGlzYWJsZWRJbmRleDtcbiAgICBjb25zdCBpc0RlZmVycmVkUG9pbnRlckRvd25PdXRzaWRlUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgICBjb25zdCBwb2ludGVyRG93bk91dHNpZGUgPSB1c2VQb2ludGVyRG93bk91dHNpZGUoXG4gICAgICAoZXZlbnQpID0+IHtcbiAgICAgICAgb25Qb2ludGVyRG93bk91dHNpZGU/LihldmVudCk7XG4gICAgICAgIG9uSW50ZXJhY3RPdXRzaWRlPy4oZXZlbnQpO1xuICAgICAgICBpZiAoIWV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQpIG9uRGlzbWlzcz8uKCk7XG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBvd25lckRvY3VtZW50LFxuICAgICAgICBkZWZlclBvaW50ZXJEb3duT3V0c2lkZSxcbiAgICAgICAgaXNEZWZlcnJlZFBvaW50ZXJEb3duT3V0c2lkZVJlZixcbiAgICAgICAgZGlzbWlzc2FibGVTdXJmYWNlczogY29udGV4dC5kaXNtaXNzYWJsZVN1cmZhY2VzLFxuICAgICAgICBzaG91bGRIYW5kbGVQb2ludGVyRG93bk91dHNpZGU6IFJlYWN0LnVzZUNhbGxiYWNrKFxuICAgICAgICAgICh0YXJnZXQpID0+IHtcbiAgICAgICAgICAgIGlmICghKHRhcmdldCBpbnN0YW5jZW9mIE5vZGUpKSB7XG4gICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGlzUG9pbnRlckRvd25PbkJyYW5jaCA9IFsuLi5jb250ZXh0LmJyYW5jaGVzXS5zb21lKFxuICAgICAgICAgICAgICAoYnJhbmNoKSA9PiBicmFuY2guY29udGFpbnModGFyZ2V0KVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIHJldHVybiBpc1BvaW50ZXJFdmVudHNFbmFibGVkICYmICFpc1BvaW50ZXJEb3duT25CcmFuY2g7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBbY29udGV4dC5icmFuY2hlcywgaXNQb2ludGVyRXZlbnRzRW5hYmxlZF1cbiAgICAgICAgKVxuICAgICAgfVxuICAgICk7XG4gICAgY29uc3QgZm9jdXNPdXRzaWRlID0gdXNlRm9jdXNPdXRzaWRlKChldmVudCkgPT4ge1xuICAgICAgaWYgKGRlZmVyUG9pbnRlckRvd25PdXRzaWRlICYmIGlzRGVmZXJyZWRQb2ludGVyRG93bk91dHNpZGVSZWYuY3VycmVudCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCB0YXJnZXQgPSBldmVudC50YXJnZXQ7XG4gICAgICBjb25zdCBpc0ZvY3VzSW5CcmFuY2ggPSBbLi4uY29udGV4dC5icmFuY2hlc10uc29tZSgoYnJhbmNoKSA9PiBicmFuY2guY29udGFpbnModGFyZ2V0KSk7XG4gICAgICBpZiAoaXNGb2N1c0luQnJhbmNoKSByZXR1cm47XG4gICAgICBvbkZvY3VzT3V0c2lkZT8uKGV2ZW50KTtcbiAgICAgIG9uSW50ZXJhY3RPdXRzaWRlPy4oZXZlbnQpO1xuICAgICAgaWYgKCFldmVudC5kZWZhdWx0UHJldmVudGVkKSBvbkRpc21pc3M/LigpO1xuICAgIH0sIG93bmVyRG9jdW1lbnQpO1xuICAgIGNvbnN0IGlzSGlnaGVzdExheWVyID0gbm9kZSA/IGluZGV4ID09PSBsYXllcnMubGVuZ3RoIC0gMSA6IGZhbHNlO1xuICAgIGNvbnN0IGhhbmRsZUtleURvd24gPSB1c2VDYWxsYmFja1JlZigoZXZlbnQpID0+IHtcbiAgICAgIGlmIChldmVudC5rZXkgIT09IFwiRXNjYXBlXCIpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgb25Fc2NhcGVLZXlEb3duPy4oZXZlbnQpO1xuICAgICAgaWYgKCFldmVudC5kZWZhdWx0UHJldmVudGVkICYmIG9uRGlzbWlzcykge1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBvbkRpc21pc3MoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgaWYgKCFpc0hpZ2hlc3RMYXllcikge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBvd25lckRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGhhbmRsZUtleURvd24sIHsgY2FwdHVyZTogdHJ1ZSB9KTtcbiAgICAgIHJldHVybiAoKSA9PiBvd25lckRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGhhbmRsZUtleURvd24sIHsgY2FwdHVyZTogdHJ1ZSB9KTtcbiAgICB9LCBbb3duZXJEb2N1bWVudCwgaXNIaWdoZXN0TGF5ZXIsIGhhbmRsZUtleURvd25dKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgaWYgKCFub2RlKSByZXR1cm47XG4gICAgICBpZiAoZGlzYWJsZU91dHNpZGVQb2ludGVyRXZlbnRzKSB7XG4gICAgICAgIGlmIChjb250ZXh0LmxheWVyc1dpdGhPdXRzaWRlUG9pbnRlckV2ZW50c0Rpc2FibGVkLnNpemUgPT09IDApIHtcbiAgICAgICAgICBvcmlnaW5hbEJvZHlQb2ludGVyRXZlbnRzID0gb3duZXJEb2N1bWVudC5ib2R5LnN0eWxlLnBvaW50ZXJFdmVudHM7XG4gICAgICAgICAgb3duZXJEb2N1bWVudC5ib2R5LnN0eWxlLnBvaW50ZXJFdmVudHMgPSBcIm5vbmVcIjtcbiAgICAgICAgfVxuICAgICAgICBjb250ZXh0LmxheWVyc1dpdGhPdXRzaWRlUG9pbnRlckV2ZW50c0Rpc2FibGVkLmFkZChub2RlKTtcbiAgICAgIH1cbiAgICAgIGNvbnRleHQubGF5ZXJzLmFkZChub2RlKTtcbiAgICAgIGRpc3BhdGNoVXBkYXRlKCk7XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZU91dHNpZGVQb2ludGVyRXZlbnRzKSB7XG4gICAgICAgICAgY29udGV4dC5sYXllcnNXaXRoT3V0c2lkZVBvaW50ZXJFdmVudHNEaXNhYmxlZC5kZWxldGUobm9kZSk7XG4gICAgICAgICAgaWYgKGNvbnRleHQubGF5ZXJzV2l0aE91dHNpZGVQb2ludGVyRXZlbnRzRGlzYWJsZWQuc2l6ZSA9PT0gMCkge1xuICAgICAgICAgICAgb3duZXJEb2N1bWVudC5ib2R5LnN0eWxlLnBvaW50ZXJFdmVudHMgPSBvcmlnaW5hbEJvZHlQb2ludGVyRXZlbnRzO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9LCBbbm9kZSwgb3duZXJEb2N1bWVudCwgZGlzYWJsZU91dHNpZGVQb2ludGVyRXZlbnRzLCBjb250ZXh0XSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgIGlmICghbm9kZSkgcmV0dXJuO1xuICAgICAgICBjb250ZXh0LmxheWVycy5kZWxldGUobm9kZSk7XG4gICAgICAgIGNvbnRleHQubGF5ZXJzV2l0aE91dHNpZGVQb2ludGVyRXZlbnRzRGlzYWJsZWQuZGVsZXRlKG5vZGUpO1xuICAgICAgICBkaXNwYXRjaFVwZGF0ZSgpO1xuICAgICAgfTtcbiAgICB9LCBbbm9kZSwgY29udGV4dF0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICBjb25zdCBoYW5kbGVVcGRhdGUgPSAvKiBAX19QVVJFX18gKi8gX19uYW1lKCgpID0+IGZvcmNlKHt9KSwgXCJoYW5kbGVVcGRhdGVcIik7XG4gICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKENPTlRFWFRfVVBEQVRFLCBoYW5kbGVVcGRhdGUpO1xuICAgICAgcmV0dXJuICgpID0+IGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoQ09OVEVYVF9VUERBVEUsIGhhbmRsZVVwZGF0ZSk7XG4gICAgfSwgW10pO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgUHJpbWl0aXZlLmRpdixcbiAgICAgIHtcbiAgICAgICAgLi4ubGF5ZXJQcm9wcyxcbiAgICAgICAgcmVmOiBjb21wb3NlZFJlZnMsXG4gICAgICAgIHN0eWxlOiB7XG4gICAgICAgICAgcG9pbnRlckV2ZW50czogaXNCb2R5UG9pbnRlckV2ZW50c0Rpc2FibGVkID8gaXNQb2ludGVyRXZlbnRzRW5hYmxlZCA/IFwiYXV0b1wiIDogXCJub25lXCIgOiB2b2lkIDAsXG4gICAgICAgICAgLi4ucHJvcHMuc3R5bGVcbiAgICAgICAgfSxcbiAgICAgICAgb25Gb2N1c0NhcHR1cmU6IGNvbXBvc2VFdmVudEhhbmRsZXJzKHByb3BzLm9uRm9jdXNDYXB0dXJlLCBmb2N1c091dHNpZGUub25Gb2N1c0NhcHR1cmUpLFxuICAgICAgICBvbkJsdXJDYXB0dXJlOiBjb21wb3NlRXZlbnRIYW5kbGVycyhwcm9wcy5vbkJsdXJDYXB0dXJlLCBmb2N1c091dHNpZGUub25CbHVyQ2FwdHVyZSksXG4gICAgICAgIG9uUG9pbnRlckRvd25DYXB0dXJlOiBjb21wb3NlRXZlbnRIYW5kbGVycyhcbiAgICAgICAgICBwcm9wcy5vblBvaW50ZXJEb3duQ2FwdHVyZSxcbiAgICAgICAgICBwb2ludGVyRG93bk91dHNpZGUub25Qb2ludGVyRG93bkNhcHR1cmVcbiAgICAgICAgKVxuICAgICAgfVxuICAgICk7XG4gIH0sIFwiRGlzbWlzc2FibGVMYXllclwiKVxuKTtcbnZhciBEaXNtaXNzYWJsZUxheWVyQnJhbmNoID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBEaXNtaXNzYWJsZUxheWVyQnJhbmNoMihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IGNvbnRleHQgPSBSZWFjdC51c2VDb250ZXh0KERpc21pc3NhYmxlTGF5ZXJDb250ZXh0KTtcbiAgY29uc3QgcmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBjb21wb3NlZFJlZnMgPSB1c2VDb21wb3NlZFJlZnMoZm9yd2FyZGVkUmVmLCByZWYpO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IG5vZGUgPSByZWYuY3VycmVudDtcbiAgICBpZiAobm9kZSkge1xuICAgICAgY29udGV4dC5icmFuY2hlcy5hZGQobm9kZSk7XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBjb250ZXh0LmJyYW5jaGVzLmRlbGV0ZShub2RlKTtcbiAgICAgIH07XG4gICAgfVxuICB9LCBbY29udGV4dC5icmFuY2hlc10pO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChQcmltaXRpdmUuZGl2LCB7IC4uLnByb3BzLCByZWY6IGNvbXBvc2VkUmVmcyB9KTtcbn0sIFwiRGlzbWlzc2FibGVMYXllckJyYW5jaFwiKSk7XG5mdW5jdGlvbiB1c2VEaXNtaXNzYWJsZUxheWVyU3VyZmFjZSgpIHtcbiAgY29uc3QgY29udGV4dCA9IFJlYWN0LnVzZUNvbnRleHQoRGlzbWlzc2FibGVMYXllckNvbnRleHQpO1xuICBjb25zdCBbbm9kZSwgc2V0Tm9kZV0gPSBSZWFjdC51c2VTdGF0ZShudWxsKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIW5vZGUpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29udGV4dC5kaXNtaXNzYWJsZVN1cmZhY2VzLmFkZChub2RlKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgY29udGV4dC5kaXNtaXNzYWJsZVN1cmZhY2VzLmRlbGV0ZShub2RlKTtcbiAgICB9O1xuICB9LCBbbm9kZSwgY29udGV4dC5kaXNtaXNzYWJsZVN1cmZhY2VzXSk7XG4gIHJldHVybiBzZXROb2RlO1xufVxuX19uYW1lKHVzZURpc21pc3NhYmxlTGF5ZXJTdXJmYWNlLCBcInVzZURpc21pc3NhYmxlTGF5ZXJTdXJmYWNlXCIpO1xudmFyIElTX1RSVUUgPSAvKiBAX19QVVJFX18gKi8gX19uYW1lKCgpID0+IHRydWUsIFwiSVNfVFJVRVwiKTtcbmZ1bmN0aW9uIHVzZVBvaW50ZXJEb3duT3V0c2lkZShvblBvaW50ZXJEb3duT3V0c2lkZSwgYXJncykge1xuICBjb25zdCB7XG4gICAgb3duZXJEb2N1bWVudCA9IGdsb2JhbFRoaXM/LmRvY3VtZW50LFxuICAgIGRlZmVyUG9pbnRlckRvd25PdXRzaWRlID0gZmFsc2UsXG4gICAgaXNEZWZlcnJlZFBvaW50ZXJEb3duT3V0c2lkZVJlZixcbiAgICBkaXNtaXNzYWJsZVN1cmZhY2VzLFxuICAgIHNob3VsZEhhbmRsZVBvaW50ZXJEb3duT3V0c2lkZSA9IElTX1RSVUVcbiAgfSA9IGFyZ3M7XG4gIGNvbnN0IGhhbmRsZVBvaW50ZXJEb3duT3V0c2lkZSA9IHVzZUNhbGxiYWNrUmVmKG9uUG9pbnRlckRvd25PdXRzaWRlKTtcbiAgY29uc3QgaXNQb2ludGVySW5zaWRlUmVhY3RUcmVlUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgaXNQb2ludGVyRG93bk91dHNpZGVSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICBjb25zdCBpbnRlcmNlcHRlZE91dHNpZGVJbnRlcmFjdGlvbkV2ZW50c1JlZiA9IFJlYWN0LnVzZVJlZigvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpKTtcbiAgY29uc3QgaGFuZGxlQ2xpY2tSZWYgPSBSZWFjdC51c2VSZWYoKCkgPT4ge1xuICB9KTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBmdW5jdGlvbiByZXNldE91dHNpZGVJbnRlcmFjdGlvbigpIHtcbiAgICAgIGlzUG9pbnRlckRvd25PdXRzaWRlUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIGlzRGVmZXJyZWRQb2ludGVyRG93bk91dHNpZGVSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgaW50ZXJjZXB0ZWRPdXRzaWRlSW50ZXJhY3Rpb25FdmVudHNSZWYuY3VycmVudC5jbGVhcigpO1xuICAgIH1cbiAgICBfX25hbWUocmVzZXRPdXRzaWRlSW50ZXJhY3Rpb24sIFwicmVzZXRPdXRzaWRlSW50ZXJhY3Rpb25cIik7XG4gICAgZnVuY3Rpb24gaXNPdXRzaWRlSW50ZXJhY3Rpb25JbnRlcmNlcHRlZCgpIHtcbiAgICAgIHJldHVybiBBcnJheS5mcm9tKGludGVyY2VwdGVkT3V0c2lkZUludGVyYWN0aW9uRXZlbnRzUmVmLmN1cnJlbnQudmFsdWVzKCkpLnNvbWUoQm9vbGVhbik7XG4gICAgfVxuICAgIF9fbmFtZShpc091dHNpZGVJbnRlcmFjdGlvbkludGVyY2VwdGVkLCBcImlzT3V0c2lkZUludGVyYWN0aW9uSW50ZXJjZXB0ZWRcIik7XG4gICAgZnVuY3Rpb24gaGFuZGxlSW50ZXJhY3Rpb25DYXB0dXJlKGV2ZW50KSB7XG4gICAgICBpZiAoIWlzUG9pbnRlckRvd25PdXRzaWRlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgdGFyZ2V0ID0gZXZlbnQudGFyZ2V0O1xuICAgICAgY29uc3QgaXNEaXNtaXNzYWJsZVN1cmZhY2UgPSB0YXJnZXQgaW5zdGFuY2VvZiBOb2RlICYmIFsuLi5kaXNtaXNzYWJsZVN1cmZhY2VzXS5zb21lKChzdXJmYWNlKSA9PiBzdXJmYWNlLmNvbnRhaW5zKHRhcmdldCkpO1xuICAgICAgaWYgKCFpc0Rpc21pc3NhYmxlU3VyZmFjZSkge1xuICAgICAgICBpbnRlcmNlcHRlZE91dHNpZGVJbnRlcmFjdGlvbkV2ZW50c1JlZi5jdXJyZW50LnNldChldmVudC50eXBlLCB0cnVlKTtcbiAgICAgIH1cbiAgICAgIGlmIChldmVudC50eXBlID09PSBcImNsaWNrXCIpIHtcbiAgICAgICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIGlmIChpc1BvaW50ZXJEb3duT3V0c2lkZVJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICBoYW5kbGVDbGlja1JlZi5jdXJyZW50KCk7XG4gICAgICAgICAgfVxuICAgICAgICB9LCAwKTtcbiAgICAgIH1cbiAgICB9XG4gICAgX19uYW1lKGhhbmRsZUludGVyYWN0aW9uQ2FwdHVyZSwgXCJoYW5kbGVJbnRlcmFjdGlvbkNhcHR1cmVcIik7XG4gICAgZnVuY3Rpb24gaGFuZGxlSW50ZXJhY3Rpb25CdWJibGUoZXZlbnQpIHtcbiAgICAgIGlmIChpc1BvaW50ZXJEb3duT3V0c2lkZVJlZi5jdXJyZW50KSB7XG4gICAgICAgIGludGVyY2VwdGVkT3V0c2lkZUludGVyYWN0aW9uRXZlbnRzUmVmLmN1cnJlbnQuc2V0KGV2ZW50LnR5cGUsIGZhbHNlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgX19uYW1lKGhhbmRsZUludGVyYWN0aW9uQnViYmxlLCBcImhhbmRsZUludGVyYWN0aW9uQnViYmxlXCIpO1xuICAgIGNvbnN0IGhhbmRsZVBvaW50ZXJEb3duID0gLyogQF9fUFVSRV9fICovIF9fbmFtZSgoZXZlbnQpID0+IHtcbiAgICAgIGlmIChldmVudC50YXJnZXQgJiYgIWlzUG9pbnRlckluc2lkZVJlYWN0VHJlZVJlZi5jdXJyZW50KSB7XG4gICAgICAgIGxldCBoYW5kbGVBbmREaXNwYXRjaFBvaW50ZXJEb3duT3V0c2lkZUV2ZW50MiA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgIG93bmVyRG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGhhbmRsZUNsaWNrUmVmLmN1cnJlbnQpO1xuICAgICAgICAgIGNvbnN0IHdhc091dHNpZGVJbnRlcmFjdGlvbkludGVyY2VwdGVkID0gaXNPdXRzaWRlSW50ZXJhY3Rpb25JbnRlcmNlcHRlZCgpO1xuICAgICAgICAgIHJlc2V0T3V0c2lkZUludGVyYWN0aW9uKCk7XG4gICAgICAgICAgaWYgKCF3YXNPdXRzaWRlSW50ZXJhY3Rpb25JbnRlcmNlcHRlZCkge1xuICAgICAgICAgICAgaGFuZGxlQW5kRGlzcGF0Y2hDdXN0b21FdmVudChcbiAgICAgICAgICAgICAgUE9JTlRFUl9ET1dOX09VVFNJREUsXG4gICAgICAgICAgICAgIGhhbmRsZVBvaW50ZXJEb3duT3V0c2lkZSxcbiAgICAgICAgICAgICAgZXZlbnREZXRhaWwsXG4gICAgICAgICAgICAgIHsgZGlzY3JldGU6IHRydWUgfVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHZhciBoYW5kbGVBbmREaXNwYXRjaFBvaW50ZXJEb3duT3V0c2lkZUV2ZW50ID0gaGFuZGxlQW5kRGlzcGF0Y2hQb2ludGVyRG93bk91dHNpZGVFdmVudDI7XG4gICAgICAgIF9fbmFtZShoYW5kbGVBbmREaXNwYXRjaFBvaW50ZXJEb3duT3V0c2lkZUV2ZW50MiwgXCJoYW5kbGVBbmREaXNwYXRjaFBvaW50ZXJEb3duT3V0c2lkZUV2ZW50XCIpO1xuICAgICAgICBpZiAoIXNob3VsZEhhbmRsZVBvaW50ZXJEb3duT3V0c2lkZShldmVudC50YXJnZXQpKSB7XG4gICAgICAgICAgb3duZXJEb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgaGFuZGxlQ2xpY2tSZWYuY3VycmVudCk7XG4gICAgICAgICAgcmVzZXRPdXRzaWRlSW50ZXJhY3Rpb24oKTtcbiAgICAgICAgICBpc1BvaW50ZXJJbnNpZGVSZWFjdFRyZWVSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBldmVudERldGFpbCA9IHsgb3JpZ2luYWxFdmVudDogZXZlbnQgfTtcbiAgICAgICAgaXNQb2ludGVyRG93bk91dHNpZGVSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgIGlzRGVmZXJyZWRQb2ludGVyRG93bk91dHNpZGVSZWYuY3VycmVudCA9IGRlZmVyUG9pbnRlckRvd25PdXRzaWRlICYmIGV2ZW50LmJ1dHRvbiA9PT0gMDtcbiAgICAgICAgaW50ZXJjZXB0ZWRPdXRzaWRlSW50ZXJhY3Rpb25FdmVudHNSZWYuY3VycmVudC5jbGVhcigpO1xuICAgICAgICBpZiAoIWRlZmVyUG9pbnRlckRvd25PdXRzaWRlIHx8IGV2ZW50LmJ1dHRvbiAhPT0gMCkge1xuICAgICAgICAgIGhhbmRsZUFuZERpc3BhdGNoUG9pbnRlckRvd25PdXRzaWRlRXZlbnQyKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgb3duZXJEb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgaGFuZGxlQ2xpY2tSZWYuY3VycmVudCk7XG4gICAgICAgICAgaGFuZGxlQ2xpY2tSZWYuY3VycmVudCA9IGhhbmRsZUFuZERpc3BhdGNoUG9pbnRlckRvd25PdXRzaWRlRXZlbnQyO1xuICAgICAgICAgIG93bmVyRG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGhhbmRsZUNsaWNrUmVmLmN1cnJlbnQsIHsgb25jZTogdHJ1ZSB9KTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgb3duZXJEb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgaGFuZGxlQ2xpY2tSZWYuY3VycmVudCk7XG4gICAgICAgIHJlc2V0T3V0c2lkZUludGVyYWN0aW9uKCk7XG4gICAgICB9XG4gICAgICBpc1BvaW50ZXJJbnNpZGVSZWFjdFRyZWVSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgIH0sIFwiaGFuZGxlUG9pbnRlckRvd25cIik7XG4gICAgY29uc3Qgb3V0c2lkZUludGVyYWN0aW9uRXZlbnRzID0gW1xuICAgICAgXCJwb2ludGVydXBcIixcbiAgICAgIFwibW91c2Vkb3duXCIsXG4gICAgICBcIm1vdXNldXBcIixcbiAgICAgIFwidG91Y2hzdGFydFwiLFxuICAgICAgXCJ0b3VjaGVuZFwiLFxuICAgICAgXCJjbGlja1wiXG4gICAgXTtcbiAgICBmb3IgKGNvbnN0IGV2ZW50TmFtZSBvZiBvdXRzaWRlSW50ZXJhY3Rpb25FdmVudHMpIHtcbiAgICAgIG93bmVyRG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihldmVudE5hbWUsIGhhbmRsZUludGVyYWN0aW9uQ2FwdHVyZSwgdHJ1ZSk7XG4gICAgICBvd25lckRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoZXZlbnROYW1lLCBoYW5kbGVJbnRlcmFjdGlvbkJ1YmJsZSk7XG4gICAgfVxuICAgIGNvbnN0IHRpbWVySWQgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBvd25lckRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJwb2ludGVyZG93blwiLCBoYW5kbGVQb2ludGVyRG93bik7XG4gICAgfSwgMCk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHdpbmRvdy5jbGVhclRpbWVvdXQodGltZXJJZCk7XG4gICAgICBvd25lckRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwb2ludGVyZG93blwiLCBoYW5kbGVQb2ludGVyRG93bik7XG4gICAgICBvd25lckRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBoYW5kbGVDbGlja1JlZi5jdXJyZW50KTtcbiAgICAgIGZvciAoY29uc3QgZXZlbnROYW1lIG9mIG91dHNpZGVJbnRlcmFjdGlvbkV2ZW50cykge1xuICAgICAgICBvd25lckRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoZXZlbnROYW1lLCBoYW5kbGVJbnRlcmFjdGlvbkNhcHR1cmUsIHRydWUpO1xuICAgICAgICBvd25lckRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoZXZlbnROYW1lLCBoYW5kbGVJbnRlcmFjdGlvbkJ1YmJsZSk7XG4gICAgICB9XG4gICAgfTtcbiAgfSwgW1xuICAgIG93bmVyRG9jdW1lbnQsXG4gICAgaGFuZGxlUG9pbnRlckRvd25PdXRzaWRlLFxuICAgIGRlZmVyUG9pbnRlckRvd25PdXRzaWRlLFxuICAgIGlzRGVmZXJyZWRQb2ludGVyRG93bk91dHNpZGVSZWYsXG4gICAgZGlzbWlzc2FibGVTdXJmYWNlcyxcbiAgICBzaG91bGRIYW5kbGVQb2ludGVyRG93bk91dHNpZGVcbiAgXSk7XG4gIHJldHVybiB7XG4gICAgLy8gZW5zdXJlcyB3ZSBjaGVjayBSZWFjdCBjb21wb25lbnQgdHJlZSAobm90IGp1c3QgRE9NIHRyZWUpXG4gICAgb25Qb2ludGVyRG93bkNhcHR1cmU6IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKCkgPT4gaXNQb2ludGVySW5zaWRlUmVhY3RUcmVlUmVmLmN1cnJlbnQgPSB0cnVlLCBcIm9uUG9pbnRlckRvd25DYXB0dXJlXCIpXG4gIH07XG59XG5fX25hbWUodXNlUG9pbnRlckRvd25PdXRzaWRlLCBcInVzZVBvaW50ZXJEb3duT3V0c2lkZVwiKTtcbmZ1bmN0aW9uIHVzZUZvY3VzT3V0c2lkZShvbkZvY3VzT3V0c2lkZSwgb3duZXJEb2N1bWVudCA9IGdsb2JhbFRoaXM/LmRvY3VtZW50KSB7XG4gIGNvbnN0IGhhbmRsZUZvY3VzT3V0c2lkZSA9IHVzZUNhbGxiYWNrUmVmKG9uRm9jdXNPdXRzaWRlKTtcbiAgY29uc3QgaXNGb2N1c0luc2lkZVJlYWN0VHJlZVJlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaGFuZGxlRm9jdXMgPSAvKiBAX19QVVJFX18gKi8gX19uYW1lKChldmVudCkgPT4ge1xuICAgICAgaWYgKGV2ZW50LnRhcmdldCAmJiAhaXNGb2N1c0luc2lkZVJlYWN0VHJlZVJlZi5jdXJyZW50KSB7XG4gICAgICAgIGNvbnN0IGV2ZW50RGV0YWlsID0geyBvcmlnaW5hbEV2ZW50OiBldmVudCB9O1xuICAgICAgICBoYW5kbGVBbmREaXNwYXRjaEN1c3RvbUV2ZW50KEZPQ1VTX09VVFNJREUsIGhhbmRsZUZvY3VzT3V0c2lkZSwgZXZlbnREZXRhaWwsIHtcbiAgICAgICAgICBkaXNjcmV0ZTogZmFsc2VcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSwgXCJoYW5kbGVGb2N1c1wiKTtcbiAgICBvd25lckRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJmb2N1c2luXCIsIGhhbmRsZUZvY3VzKTtcbiAgICByZXR1cm4gKCkgPT4gb3duZXJEb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwiZm9jdXNpblwiLCBoYW5kbGVGb2N1cyk7XG4gIH0sIFtvd25lckRvY3VtZW50LCBoYW5kbGVGb2N1c091dHNpZGVdKTtcbiAgcmV0dXJuIHtcbiAgICBvbkZvY3VzQ2FwdHVyZTogLyogQF9fUFVSRV9fICovIF9fbmFtZSgoKSA9PiBpc0ZvY3VzSW5zaWRlUmVhY3RUcmVlUmVmLmN1cnJlbnQgPSB0cnVlLCBcIm9uRm9jdXNDYXB0dXJlXCIpLFxuICAgIG9uQmx1ckNhcHR1cmU6IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKCkgPT4gaXNGb2N1c0luc2lkZVJlYWN0VHJlZVJlZi5jdXJyZW50ID0gZmFsc2UsIFwib25CbHVyQ2FwdHVyZVwiKVxuICB9O1xufVxuX19uYW1lKHVzZUZvY3VzT3V0c2lkZSwgXCJ1c2VGb2N1c091dHNpZGVcIik7XG5mdW5jdGlvbiBkaXNwYXRjaFVwZGF0ZSgpIHtcbiAgY29uc3QgZXZlbnQgPSBuZXcgQ3VzdG9tRXZlbnQoQ09OVEVYVF9VUERBVEUpO1xuICBkb2N1bWVudC5kaXNwYXRjaEV2ZW50KGV2ZW50KTtcbn1cbl9fbmFtZShkaXNwYXRjaFVwZGF0ZSwgXCJkaXNwYXRjaFVwZGF0ZVwiKTtcbmZ1bmN0aW9uIGhhbmRsZUFuZERpc3BhdGNoQ3VzdG9tRXZlbnQobmFtZSwgaGFuZGxlciwgZGV0YWlsLCB7IGRpc2NyZXRlIH0pIHtcbiAgY29uc3QgdGFyZ2V0ID0gZGV0YWlsLm9yaWdpbmFsRXZlbnQudGFyZ2V0O1xuICBjb25zdCBldmVudCA9IG5ldyBDdXN0b21FdmVudChuYW1lLCB7IGJ1YmJsZXM6IGZhbHNlLCBjYW5jZWxhYmxlOiB0cnVlLCBkZXRhaWwgfSk7XG4gIGlmIChoYW5kbGVyKSB0YXJnZXQuYWRkRXZlbnRMaXN0ZW5lcihuYW1lLCBoYW5kbGVyLCB7IG9uY2U6IHRydWUgfSk7XG4gIGlmIChkaXNjcmV0ZSkge1xuICAgIGRpc3BhdGNoRGlzY3JldGVDdXN0b21FdmVudCh0YXJnZXQsIGV2ZW50KTtcbiAgfSBlbHNlIHtcbiAgICB0YXJnZXQuZGlzcGF0Y2hFdmVudChldmVudCk7XG4gIH1cbn1cbl9fbmFtZShoYW5kbGVBbmREaXNwYXRjaEN1c3RvbUV2ZW50LCBcImhhbmRsZUFuZERpc3BhdGNoQ3VzdG9tRXZlbnRcIik7XG52YXIgUm9vdCA9IERpc21pc3NhYmxlTGF5ZXI7XG52YXIgQnJhbmNoID0gRGlzbWlzc2FibGVMYXllckJyYW5jaDtcbmV4cG9ydCB7XG4gIEJyYW5jaCxcbiAgRGlzbWlzc2FibGVMYXllcixcbiAgRGlzbWlzc2FibGVMYXllckJyYW5jaCxcbiAgUm9vdCxcbiAgdXNlRGlzbWlzc2FibGVMYXllclN1cmZhY2Vcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5tanMubWFwXG4iLCJcInVzZSBjbGllbnRcIjtcbnZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19uYW1lID0gKHRhcmdldCwgdmFsdWUpID0+IF9fZGVmUHJvcCh0YXJnZXQsIFwibmFtZVwiLCB7IHZhbHVlLCBjb25maWd1cmFibGU6IHRydWUgfSk7XG5cbi8vIHNyYy9mb2N1cy1zY29wZS50c3hcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlQ29tcG9zZWRSZWZzIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1jb21wb3NlLXJlZnNcIjtcbmltcG9ydCB7IFByaW1pdGl2ZSB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtcHJpbWl0aXZlXCI7XG5pbXBvcnQgeyB1c2VDYWxsYmFja1JlZiB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtdXNlLWNhbGxiYWNrLXJlZlwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG52YXIgQVVUT0ZPQ1VTX09OX01PVU5UID0gXCJmb2N1c1Njb3BlLmF1dG9Gb2N1c09uTW91bnRcIjtcbnZhciBBVVRPRk9DVVNfT05fVU5NT1VOVCA9IFwiZm9jdXNTY29wZS5hdXRvRm9jdXNPblVubW91bnRcIjtcbnZhciBFVkVOVF9PUFRJT05TID0geyBidWJibGVzOiBmYWxzZSwgY2FuY2VsYWJsZTogdHJ1ZSB9O1xudmFyIEZvY3VzU2NvcGUgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBGb2N1c1Njb3BlMihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gICAgY29uc3Qge1xuICAgICAgbG9vcCA9IGZhbHNlLFxuICAgICAgdHJhcHBlZCA9IGZhbHNlLFxuICAgICAgb25Nb3VudEF1dG9Gb2N1czogb25Nb3VudEF1dG9Gb2N1c1Byb3AsXG4gICAgICBvblVubW91bnRBdXRvRm9jdXM6IG9uVW5tb3VudEF1dG9Gb2N1c1Byb3AsXG4gICAgICAuLi5zY29wZVByb3BzXG4gICAgfSA9IHByb3BzO1xuICAgIGNvbnN0IFtjb250YWluZXIsIHNldENvbnRhaW5lcl0gPSBSZWFjdC51c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBvbk1vdW50QXV0b0ZvY3VzID0gdXNlQ2FsbGJhY2tSZWYob25Nb3VudEF1dG9Gb2N1c1Byb3ApO1xuICAgIGNvbnN0IG9uVW5tb3VudEF1dG9Gb2N1cyA9IHVzZUNhbGxiYWNrUmVmKG9uVW5tb3VudEF1dG9Gb2N1c1Byb3ApO1xuICAgIGNvbnN0IGxhc3RGb2N1c2VkRWxlbWVudFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgICBjb25zdCBjb21wb3NlZFJlZnMgPSB1c2VDb21wb3NlZFJlZnMoZm9yd2FyZGVkUmVmLCBzZXRDb250YWluZXIpO1xuICAgIGNvbnN0IGZvY3VzU2NvcGUgPSBSZWFjdC51c2VSZWYoe1xuICAgICAgcGF1c2VkOiBmYWxzZSxcbiAgICAgIHBhdXNlKCkge1xuICAgICAgICB0aGlzLnBhdXNlZCA9IHRydWU7XG4gICAgICB9LFxuICAgICAgcmVzdW1lKCkge1xuICAgICAgICB0aGlzLnBhdXNlZCA9IGZhbHNlO1xuICAgICAgfVxuICAgIH0pLmN1cnJlbnQ7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgIGlmICh0cmFwcGVkKSB7XG4gICAgICAgIGxldCBoYW5kbGVGb2N1c0luMiA9IGZ1bmN0aW9uKGV2ZW50KSB7XG4gICAgICAgICAgaWYgKGZvY3VzU2NvcGUucGF1c2VkIHx8ICFjb250YWluZXIpIHJldHVybjtcbiAgICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC50YXJnZXQ7XG4gICAgICAgICAgaWYgKGNvbnRhaW5lci5jb250YWlucyh0YXJnZXQpKSB7XG4gICAgICAgICAgICBsYXN0Rm9jdXNlZEVsZW1lbnRSZWYuY3VycmVudCA9IHRhcmdldDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZm9jdXMobGFzdEZvY3VzZWRFbGVtZW50UmVmLmN1cnJlbnQsIHsgc2VsZWN0OiB0cnVlIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSwgaGFuZGxlRm9jdXNPdXQyID0gZnVuY3Rpb24oZXZlbnQpIHtcbiAgICAgICAgICBpZiAoZm9jdXNTY29wZS5wYXVzZWQgfHwgIWNvbnRhaW5lcikgcmV0dXJuO1xuICAgICAgICAgIGNvbnN0IHJlbGF0ZWRUYXJnZXQgPSBldmVudC5yZWxhdGVkVGFyZ2V0O1xuICAgICAgICAgIGlmIChyZWxhdGVkVGFyZ2V0ID09PSBudWxsKSByZXR1cm47XG4gICAgICAgICAgaWYgKCFjb250YWluZXIuY29udGFpbnMocmVsYXRlZFRhcmdldCkpIHtcbiAgICAgICAgICAgIGZvY3VzKGxhc3RGb2N1c2VkRWxlbWVudFJlZi5jdXJyZW50LCB7IHNlbGVjdDogdHJ1ZSB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sIGhhbmRsZU11dGF0aW9uczIgPSBmdW5jdGlvbihtdXRhdGlvbnMpIHtcbiAgICAgICAgICBjb25zdCBmb2N1c2VkRWxlbWVudCA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQ7XG4gICAgICAgICAgaWYgKGZvY3VzZWRFbGVtZW50ICE9PSBkb2N1bWVudC5ib2R5KSByZXR1cm47XG4gICAgICAgICAgZm9yIChjb25zdCBtdXRhdGlvbiBvZiBtdXRhdGlvbnMpIHtcbiAgICAgICAgICAgIGlmIChtdXRhdGlvbi5yZW1vdmVkTm9kZXMubGVuZ3RoID4gMCkgZm9jdXMoY29udGFpbmVyKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHZhciBoYW5kbGVGb2N1c0luID0gaGFuZGxlRm9jdXNJbjIsIGhhbmRsZUZvY3VzT3V0ID0gaGFuZGxlRm9jdXNPdXQyLCBoYW5kbGVNdXRhdGlvbnMgPSBoYW5kbGVNdXRhdGlvbnMyO1xuICAgICAgICBfX25hbWUoaGFuZGxlRm9jdXNJbjIsIFwiaGFuZGxlRm9jdXNJblwiKTtcbiAgICAgICAgX19uYW1lKGhhbmRsZUZvY3VzT3V0MiwgXCJoYW5kbGVGb2N1c091dFwiKTtcbiAgICAgICAgX19uYW1lKGhhbmRsZU11dGF0aW9uczIsIFwiaGFuZGxlTXV0YXRpb25zXCIpO1xuICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiZm9jdXNpblwiLCBoYW5kbGVGb2N1c0luMik7XG4gICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJmb2N1c291dFwiLCBoYW5kbGVGb2N1c091dDIpO1xuICAgICAgICBjb25zdCBtdXRhdGlvbk9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoaGFuZGxlTXV0YXRpb25zMik7XG4gICAgICAgIGlmIChjb250YWluZXIpIG11dGF0aW9uT2JzZXJ2ZXIub2JzZXJ2ZShjb250YWluZXIsIHsgY2hpbGRMaXN0OiB0cnVlLCBzdWJ0cmVlOiB0cnVlIH0pO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJmb2N1c2luXCIsIGhhbmRsZUZvY3VzSW4yKTtcbiAgICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwiZm9jdXNvdXRcIiwgaGFuZGxlRm9jdXNPdXQyKTtcbiAgICAgICAgICBtdXRhdGlvbk9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9LCBbdHJhcHBlZCwgY29udGFpbmVyLCBmb2N1c1Njb3BlLnBhdXNlZF0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICBpZiAoY29udGFpbmVyKSB7XG4gICAgICAgIGZvY3VzU2NvcGVzU3RhY2suYWRkKGZvY3VzU2NvcGUpO1xuICAgICAgICBjb25zdCBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQgPSBkb2N1bWVudC5hY3RpdmVFbGVtZW50O1xuICAgICAgICBjb25zdCBoYXNGb2N1c2VkQ2FuZGlkYXRlID0gY29udGFpbmVyLmNvbnRhaW5zKHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCk7XG4gICAgICAgIGlmICghaGFzRm9jdXNlZENhbmRpZGF0ZSkge1xuICAgICAgICAgIGNvbnN0IG1vdW50RXZlbnQgPSBuZXcgQ3VzdG9tRXZlbnQoQVVUT0ZPQ1VTX09OX01PVU5ULCBFVkVOVF9PUFRJT05TKTtcbiAgICAgICAgICBjb250YWluZXIuYWRkRXZlbnRMaXN0ZW5lcihBVVRPRk9DVVNfT05fTU9VTlQsIG9uTW91bnRBdXRvRm9jdXMpO1xuICAgICAgICAgIGNvbnRhaW5lci5kaXNwYXRjaEV2ZW50KG1vdW50RXZlbnQpO1xuICAgICAgICAgIGlmICghbW91bnRFdmVudC5kZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICAgICAgICBmb2N1c0ZpcnN0KHJlbW92ZUxpbmtzKGdldFRhYmJhYmxlQ2FuZGlkYXRlcyhjb250YWluZXIpKSwgeyBzZWxlY3Q6IHRydWUgfSk7XG4gICAgICAgICAgICBpZiAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCA9PT0gcHJldmlvdXNseUZvY3VzZWRFbGVtZW50KSB7XG4gICAgICAgICAgICAgIGZvY3VzKGNvbnRhaW5lcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgY29udGFpbmVyLnJlbW92ZUV2ZW50TGlzdGVuZXIoQVVUT0ZPQ1VTX09OX01PVU5ULCBvbk1vdW50QXV0b0ZvY3VzKTtcbiAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHVubW91bnRFdmVudCA9IG5ldyBDdXN0b21FdmVudChBVVRPRk9DVVNfT05fVU5NT1VOVCwgRVZFTlRfT1BUSU9OUyk7XG4gICAgICAgICAgICBjb250YWluZXIuYWRkRXZlbnRMaXN0ZW5lcihBVVRPRk9DVVNfT05fVU5NT1VOVCwgb25Vbm1vdW50QXV0b0ZvY3VzKTtcbiAgICAgICAgICAgIGNvbnRhaW5lci5kaXNwYXRjaEV2ZW50KHVubW91bnRFdmVudCk7XG4gICAgICAgICAgICBpZiAoIXVubW91bnRFdmVudC5kZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICAgICAgICAgIGZvY3VzKHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCA/PyBkb2N1bWVudC5ib2R5LCB7IHNlbGVjdDogdHJ1ZSB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnRhaW5lci5yZW1vdmVFdmVudExpc3RlbmVyKEFVVE9GT0NVU19PTl9VTk1PVU5ULCBvblVubW91bnRBdXRvRm9jdXMpO1xuICAgICAgICAgICAgZm9jdXNTY29wZXNTdGFjay5yZW1vdmUoZm9jdXNTY29wZSk7XG4gICAgICAgICAgfSwgMCk7XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfSwgW2NvbnRhaW5lciwgb25Nb3VudEF1dG9Gb2N1cywgb25Vbm1vdW50QXV0b0ZvY3VzLCBmb2N1c1Njb3BlXSk7XG4gICAgY29uc3QgaGFuZGxlS2V5RG93biA9IFJlYWN0LnVzZUNhbGxiYWNrKFxuICAgICAgKGV2ZW50KSA9PiB7XG4gICAgICAgIGlmICghbG9vcCAmJiAhdHJhcHBlZCkgcmV0dXJuO1xuICAgICAgICBpZiAoZm9jdXNTY29wZS5wYXVzZWQpIHJldHVybjtcbiAgICAgICAgY29uc3QgaXNUYWJLZXkgPSBldmVudC5rZXkgPT09IFwiVGFiXCIgJiYgIWV2ZW50LmFsdEtleSAmJiAhZXZlbnQuY3RybEtleSAmJiAhZXZlbnQubWV0YUtleTtcbiAgICAgICAgY29uc3QgZm9jdXNlZEVsZW1lbnQgPSBkb2N1bWVudC5hY3RpdmVFbGVtZW50O1xuICAgICAgICBpZiAoaXNUYWJLZXkgJiYgZm9jdXNlZEVsZW1lbnQpIHtcbiAgICAgICAgICBjb25zdCBjb250YWluZXIyID0gZXZlbnQuY3VycmVudFRhcmdldDtcbiAgICAgICAgICBjb25zdCBbZmlyc3QsIGxhc3RdID0gZ2V0VGFiYmFibGVFZGdlcyhjb250YWluZXIyKTtcbiAgICAgICAgICBjb25zdCBoYXNUYWJiYWJsZUVsZW1lbnRzSW5zaWRlID0gZmlyc3QgJiYgbGFzdDtcbiAgICAgICAgICBpZiAoIWhhc1RhYmJhYmxlRWxlbWVudHNJbnNpZGUpIHtcbiAgICAgICAgICAgIGlmIChmb2N1c2VkRWxlbWVudCA9PT0gY29udGFpbmVyMikgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKCFldmVudC5zaGlmdEtleSAmJiBmb2N1c2VkRWxlbWVudCA9PT0gbGFzdCkge1xuICAgICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICBpZiAobG9vcCkgZm9jdXMoZmlyc3QsIHsgc2VsZWN0OiB0cnVlIH0pO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChldmVudC5zaGlmdEtleSAmJiBmb2N1c2VkRWxlbWVudCA9PT0gZmlyc3QpIHtcbiAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgaWYgKGxvb3ApIGZvY3VzKGxhc3QsIHsgc2VsZWN0OiB0cnVlIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIFtsb29wLCB0cmFwcGVkLCBmb2N1c1Njb3BlLnBhdXNlZF1cbiAgICApO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFByaW1pdGl2ZS5kaXYsIHsgdGFiSW5kZXg6IC0xLCAuLi5zY29wZVByb3BzLCByZWY6IGNvbXBvc2VkUmVmcywgb25LZXlEb3duOiBoYW5kbGVLZXlEb3duIH0pO1xuICB9LCBcIkZvY3VzU2NvcGVcIilcbik7XG5mdW5jdGlvbiBmb2N1c0ZpcnN0KGNhbmRpZGF0ZXMsIHsgc2VsZWN0ID0gZmFsc2UgfSA9IHt9KSB7XG4gIGNvbnN0IHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQ7XG4gIGZvciAoY29uc3QgY2FuZGlkYXRlIG9mIGNhbmRpZGF0ZXMpIHtcbiAgICBmb2N1cyhjYW5kaWRhdGUsIHsgc2VsZWN0IH0pO1xuICAgIGlmIChkb2N1bWVudC5hY3RpdmVFbGVtZW50ICE9PSBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQpIHJldHVybjtcbiAgfVxufVxuX19uYW1lKGZvY3VzRmlyc3QsIFwiZm9jdXNGaXJzdFwiKTtcbmZ1bmN0aW9uIGdldFRhYmJhYmxlRWRnZXMoY29udGFpbmVyKSB7XG4gIGNvbnN0IGNhbmRpZGF0ZXMgPSBnZXRUYWJiYWJsZUNhbmRpZGF0ZXMoY29udGFpbmVyKTtcbiAgY29uc3QgZmlyc3QgPSBmaW5kVmlzaWJsZShjYW5kaWRhdGVzLCBjb250YWluZXIpO1xuICBjb25zdCBsYXN0ID0gZmluZFZpc2libGUoY2FuZGlkYXRlcy5yZXZlcnNlKCksIGNvbnRhaW5lcik7XG4gIHJldHVybiBbZmlyc3QsIGxhc3RdO1xufVxuX19uYW1lKGdldFRhYmJhYmxlRWRnZXMsIFwiZ2V0VGFiYmFibGVFZGdlc1wiKTtcbmZ1bmN0aW9uIGdldFRhYmJhYmxlQ2FuZGlkYXRlcyhjb250YWluZXIpIHtcbiAgY29uc3Qgbm9kZXMgPSBbXTtcbiAgY29uc3Qgd2Fsa2VyID0gZG9jdW1lbnQuY3JlYXRlVHJlZVdhbGtlcihjb250YWluZXIsIE5vZGVGaWx0ZXIuU0hPV19FTEVNRU5ULCB7XG4gICAgYWNjZXB0Tm9kZTogLyogQF9fUFVSRV9fICovIF9fbmFtZSgobm9kZSkgPT4ge1xuICAgICAgY29uc3QgaXNIaWRkZW5JbnB1dCA9IG5vZGUudGFnTmFtZSA9PT0gXCJJTlBVVFwiICYmIG5vZGUudHlwZSA9PT0gXCJoaWRkZW5cIjtcbiAgICAgIGlmIChub2RlLmRpc2FibGVkIHx8IG5vZGUuaGlkZGVuIHx8IGlzSGlkZGVuSW5wdXQpIHJldHVybiBOb2RlRmlsdGVyLkZJTFRFUl9TS0lQO1xuICAgICAgcmV0dXJuIG5vZGUudGFiSW5kZXggPj0gMCA/IE5vZGVGaWx0ZXIuRklMVEVSX0FDQ0VQVCA6IE5vZGVGaWx0ZXIuRklMVEVSX1NLSVA7XG4gICAgfSwgXCJhY2NlcHROb2RlXCIpXG4gIH0pO1xuICB3aGlsZSAod2Fsa2VyLm5leHROb2RlKCkpIG5vZGVzLnB1c2god2Fsa2VyLmN1cnJlbnROb2RlKTtcbiAgcmV0dXJuIG5vZGVzO1xufVxuX19uYW1lKGdldFRhYmJhYmxlQ2FuZGlkYXRlcywgXCJnZXRUYWJiYWJsZUNhbmRpZGF0ZXNcIik7XG5mdW5jdGlvbiBmaW5kVmlzaWJsZShlbGVtZW50cywgY29udGFpbmVyKSB7XG4gIGNvbnN0IGNhblVzZUNoZWNrVmlzaWJpbGl0eSA9IHR5cGVvZiBjb250YWluZXIuY2hlY2tWaXNpYmlsaXR5ID09PSBcImZ1bmN0aW9uXCIgJiYgY29udGFpbmVyLmNoZWNrVmlzaWJpbGl0eSh7IGNoZWNrVmlzaWJpbGl0eUNTUzogdHJ1ZSB9KTtcbiAgZm9yIChjb25zdCBlbGVtZW50IG9mIGVsZW1lbnRzKSB7XG4gICAgY29uc3QgaGlkZGVuID0gY2FuVXNlQ2hlY2tWaXNpYmlsaXR5ID8gIWVsZW1lbnQuY2hlY2tWaXNpYmlsaXR5KHsgY2hlY2tWaXNpYmlsaXR5Q1NTOiB0cnVlIH0pIDogaXNIaWRkZW4oZWxlbWVudCwgeyB1cFRvOiBjb250YWluZXIgfSk7XG4gICAgaWYgKCFoaWRkZW4pIHtcbiAgICAgIHJldHVybiBlbGVtZW50O1xuICAgIH1cbiAgfVxufVxuX19uYW1lKGZpbmRWaXNpYmxlLCBcImZpbmRWaXNpYmxlXCIpO1xuZnVuY3Rpb24gaXNIaWRkZW4obm9kZSwgeyB1cFRvIH0pIHtcbiAgaWYgKGdldENvbXB1dGVkU3R5bGUobm9kZSkudmlzaWJpbGl0eSA9PT0gXCJoaWRkZW5cIikgcmV0dXJuIHRydWU7XG4gIHdoaWxlIChub2RlKSB7XG4gICAgaWYgKHVwVG8gIT09IHZvaWQgMCAmJiBub2RlID09PSB1cFRvKSByZXR1cm4gZmFsc2U7XG4gICAgaWYgKGdldENvbXB1dGVkU3R5bGUobm9kZSkuZGlzcGxheSA9PT0gXCJub25lXCIpIHJldHVybiB0cnVlO1xuICAgIG5vZGUgPSBub2RlLnBhcmVudEVsZW1lbnQ7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuX19uYW1lKGlzSGlkZGVuLCBcImlzSGlkZGVuXCIpO1xuZnVuY3Rpb24gaXNTZWxlY3RhYmxlSW5wdXQoZWxlbWVudCkge1xuICByZXR1cm4gZWxlbWVudCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQgJiYgXCJzZWxlY3RcIiBpbiBlbGVtZW50O1xufVxuX19uYW1lKGlzU2VsZWN0YWJsZUlucHV0LCBcImlzU2VsZWN0YWJsZUlucHV0XCIpO1xuZnVuY3Rpb24gZm9jdXMoZWxlbWVudCwgeyBzZWxlY3QgPSBmYWxzZSB9ID0ge30pIHtcbiAgaWYgKGVsZW1lbnQgJiYgZWxlbWVudC5mb2N1cykge1xuICAgIGNvbnN0IHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQ7XG4gICAgZWxlbWVudC5mb2N1cyh7IHByZXZlbnRTY3JvbGw6IHRydWUgfSk7XG4gICAgaWYgKGVsZW1lbnQgIT09IHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCAmJiBpc1NlbGVjdGFibGVJbnB1dChlbGVtZW50KSAmJiBzZWxlY3QpXG4gICAgICBlbGVtZW50LnNlbGVjdCgpO1xuICB9XG59XG5fX25hbWUoZm9jdXMsIFwiZm9jdXNcIik7XG52YXIgZm9jdXNTY29wZXNTdGFjayA9IGNyZWF0ZUZvY3VzU2NvcGVzU3RhY2soKTtcbmZ1bmN0aW9uIGNyZWF0ZUZvY3VzU2NvcGVzU3RhY2soKSB7XG4gIGxldCBzdGFjayA9IFtdO1xuICByZXR1cm4ge1xuICAgIGFkZChmb2N1c1Njb3BlKSB7XG4gICAgICBjb25zdCBhY3RpdmVGb2N1c1Njb3BlID0gc3RhY2tbMF07XG4gICAgICBpZiAoZm9jdXNTY29wZSAhPT0gYWN0aXZlRm9jdXNTY29wZSkge1xuICAgICAgICBhY3RpdmVGb2N1c1Njb3BlPy5wYXVzZSgpO1xuICAgICAgfVxuICAgICAgc3RhY2sgPSBhcnJheVJlbW92ZShzdGFjaywgZm9jdXNTY29wZSk7XG4gICAgICBzdGFjay51bnNoaWZ0KGZvY3VzU2NvcGUpO1xuICAgIH0sXG4gICAgcmVtb3ZlKGZvY3VzU2NvcGUpIHtcbiAgICAgIHN0YWNrID0gYXJyYXlSZW1vdmUoc3RhY2ssIGZvY3VzU2NvcGUpO1xuICAgICAgc3RhY2tbMF0/LnJlc3VtZSgpO1xuICAgIH1cbiAgfTtcbn1cbl9fbmFtZShjcmVhdGVGb2N1c1Njb3Blc1N0YWNrLCBcImNyZWF0ZUZvY3VzU2NvcGVzU3RhY2tcIik7XG5mdW5jdGlvbiBhcnJheVJlbW92ZShhcnJheSwgaXRlbSkge1xuICBjb25zdCB1cGRhdGVkQXJyYXkgPSBbLi4uYXJyYXldO1xuICBjb25zdCBpbmRleCA9IHVwZGF0ZWRBcnJheS5pbmRleE9mKGl0ZW0pO1xuICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgdXBkYXRlZEFycmF5LnNwbGljZShpbmRleCwgMSk7XG4gIH1cbiAgcmV0dXJuIHVwZGF0ZWRBcnJheTtcbn1cbl9fbmFtZShhcnJheVJlbW92ZSwgXCJhcnJheVJlbW92ZVwiKTtcbmZ1bmN0aW9uIHJlbW92ZUxpbmtzKGl0ZW1zKSB7XG4gIHJldHVybiBpdGVtcy5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0udGFnTmFtZSAhPT0gXCJBXCIpO1xufVxuX19uYW1lKHJlbW92ZUxpbmtzLCBcInJlbW92ZUxpbmtzXCIpO1xudmFyIFJvb3QgPSBGb2N1c1Njb3BlO1xuZXhwb3J0IHtcbiAgRm9jdXNTY29wZSxcbiAgUm9vdFxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4Lm1qcy5tYXBcbiIsIlwidXNlIGNsaWVudFwiO1xudmFyIF9fZGVmUHJvcCA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX25hbWUgPSAodGFyZ2V0LCB2YWx1ZSkgPT4gX19kZWZQcm9wKHRhcmdldCwgXCJuYW1lXCIsIHsgdmFsdWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSB9KTtcblxuLy8gc3JjL3BvcnRhbC50c3hcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0ICogYXMgUmVhY3RET00gZnJvbSBcInJlYWN0LWRvbVwiO1xuaW1wb3J0IHsgUHJpbWl0aXZlIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1wcmltaXRpdmVcIjtcbmltcG9ydCB7IHVzZUxheW91dEVmZmVjdCB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtdXNlLWxheW91dC1lZmZlY3RcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xudmFyIFBvcnRhbCA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIFBvcnRhbDIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHsgY29udGFpbmVyOiBjb250YWluZXJQcm9wLCAuLi5wb3J0YWxQcm9wcyB9ID0gcHJvcHM7XG4gICAgY29uc3QgW21vdW50ZWQsIHNldE1vdW50ZWRdID0gUmVhY3QudXNlU3RhdGUoZmFsc2UpO1xuICAgIHVzZUxheW91dEVmZmVjdCgoKSA9PiBzZXRNb3VudGVkKHRydWUpLCBbXSk7XG4gICAgY29uc3QgY29udGFpbmVyID0gY29udGFpbmVyUHJvcCB8fCBtb3VudGVkICYmIGdsb2JhbFRoaXM/LmRvY3VtZW50Py5ib2R5O1xuICAgIHJldHVybiBjb250YWluZXIgPyBSZWFjdERPTS5jcmVhdGVQb3J0YWwoLyogQF9fUFVSRV9fICovIGpzeChQcmltaXRpdmUuZGl2LCB7IC4uLnBvcnRhbFByb3BzLCByZWY6IGZvcndhcmRlZFJlZiB9KSwgY29udGFpbmVyKSA6IG51bGw7XG4gIH0sIFwiUG9ydGFsXCIpXG4pO1xudmFyIFJvb3QgPSBQb3J0YWw7XG5leHBvcnQge1xuICBQb3J0YWwsXG4gIFJvb3Rcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5tanMubWFwXG4iLCJcInVzZSBjbGllbnRcIjtcbnZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19uYW1lID0gKHRhcmdldCwgdmFsdWUpID0+IF9fZGVmUHJvcCh0YXJnZXQsIFwibmFtZVwiLCB7IHZhbHVlLCBjb25maWd1cmFibGU6IHRydWUgfSk7XG5cbi8vIHNyYy9mb2N1cy1ndWFyZHMudHN4XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbnZhciBjb3VudCA9IDA7XG52YXIgZ3VhcmRzID0gbnVsbDtcbmZ1bmN0aW9uIEZvY3VzR3VhcmRzKHByb3BzKSB7XG4gIHVzZUZvY3VzR3VhcmRzKCk7XG4gIHJldHVybiBwcm9wcy5jaGlsZHJlbjtcbn1cbl9fbmFtZShGb2N1c0d1YXJkcywgXCJGb2N1c0d1YXJkc1wiKTtcbmZ1bmN0aW9uIHVzZUZvY3VzR3VhcmRzKCkge1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZ3VhcmRzKSB7XG4gICAgICBndWFyZHMgPSB7IHN0YXJ0OiBjcmVhdGVGb2N1c0d1YXJkKCksIGVuZDogY3JlYXRlRm9jdXNHdWFyZCgpIH07XG4gICAgfVxuICAgIGNvbnN0IHsgc3RhcnQsIGVuZCB9ID0gZ3VhcmRzO1xuICAgIGlmIChkb2N1bWVudC5ib2R5LmZpcnN0RWxlbWVudENoaWxkICE9PSBzdGFydCkge1xuICAgICAgZG9jdW1lbnQuYm9keS5pbnNlcnRBZGphY2VudEVsZW1lbnQoXCJhZnRlcmJlZ2luXCIsIHN0YXJ0KTtcbiAgICB9XG4gICAgaWYgKGRvY3VtZW50LmJvZHkubGFzdEVsZW1lbnRDaGlsZCAhPT0gZW5kKSB7XG4gICAgICBkb2N1bWVudC5ib2R5Lmluc2VydEFkamFjZW50RWxlbWVudChcImJlZm9yZWVuZFwiLCBlbmQpO1xuICAgIH1cbiAgICBjb3VudCsrO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBpZiAoY291bnQgPT09IDEpIHtcbiAgICAgICAgZ3VhcmRzPy5zdGFydC5yZW1vdmUoKTtcbiAgICAgICAgZ3VhcmRzPy5lbmQucmVtb3ZlKCk7XG4gICAgICAgIGd1YXJkcyA9IG51bGw7XG4gICAgICB9XG4gICAgICBjb3VudCA9IE1hdGgubWF4KDAsIGNvdW50IC0gMSk7XG4gICAgfTtcbiAgfSwgW10pO1xufVxuX19uYW1lKHVzZUZvY3VzR3VhcmRzLCBcInVzZUZvY3VzR3VhcmRzXCIpO1xuZnVuY3Rpb24gY3JlYXRlRm9jdXNHdWFyZCgpIHtcbiAgY29uc3QgZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICBlbGVtZW50LnNldEF0dHJpYnV0ZShcImRhdGEtcmFkaXgtZm9jdXMtZ3VhcmRcIiwgXCJcIik7XG4gIGVsZW1lbnQudGFiSW5kZXggPSAwO1xuICBlbGVtZW50LnN0eWxlLm91dGxpbmUgPSBcIm5vbmVcIjtcbiAgZWxlbWVudC5zdHlsZS5vcGFjaXR5ID0gXCIwXCI7XG4gIGVsZW1lbnQuc3R5bGUucG9zaXRpb24gPSBcImZpeGVkXCI7XG4gIGVsZW1lbnQuc3R5bGUucG9pbnRlckV2ZW50cyA9IFwibm9uZVwiO1xuICByZXR1cm4gZWxlbWVudDtcbn1cbl9fbmFtZShjcmVhdGVGb2N1c0d1YXJkLCBcImNyZWF0ZUZvY3VzR3VhcmRcIik7XG5leHBvcnQge1xuICBGb2N1c0d1YXJkcyxcbiAgRm9jdXNHdWFyZHMgYXMgUm9vdCxcbiAgdXNlRm9jdXNHdWFyZHNcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5tanMubWFwXG4iLCJleHBvcnQgdmFyIHplcm9SaWdodENsYXNzTmFtZSA9ICdyaWdodC1zY3JvbGwtYmFyLXBvc2l0aW9uJztcbmV4cG9ydCB2YXIgZnVsbFdpZHRoQ2xhc3NOYW1lID0gJ3dpZHRoLWJlZm9yZS1zY3JvbGwtYmFyJztcbmV4cG9ydCB2YXIgbm9TY3JvbGxiYXJzQ2xhc3NOYW1lID0gJ3dpdGgtc2Nyb2xsLWJhcnMtaGlkZGVuJztcbi8qKlxuICogTmFtZSBvZiBhIENTUyB2YXJpYWJsZSBjb250YWluaW5nIHRoZSBhbW91bnQgb2YgXCJoaWRkZW5cIiBzY3JvbGxiYXJcbiAqICEgbWlnaHQgYmUgdW5kZWZpbmVkICEgdXNlIHdpbGwgZmFsbGJhY2shXG4gKi9cbmV4cG9ydCB2YXIgcmVtb3ZlZEJhclNpemVWYXJpYWJsZSA9ICctLXJlbW92ZWQtYm9keS1zY3JvbGwtYmFyLXNpemUnO1xuIiwiLyoqXG4gKiBBc3NpZ25zIGEgdmFsdWUgZm9yIGEgZ2l2ZW4gcmVmLCBubyBtYXR0ZXIgb2YgdGhlIHJlZiBmb3JtYXRcbiAqIEBwYXJhbSB7UmVmT2JqZWN0fSByZWYgLSBhIGNhbGxiYWNrIGZ1bmN0aW9uIG9yIHJlZiBvYmplY3RcbiAqIEBwYXJhbSB2YWx1ZSAtIGEgbmV3IHZhbHVlXG4gKlxuICogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vdGhlS2FzaGV5L3VzZS1jYWxsYmFjay1yZWYjYXNzaWducmVmXG4gKiBAZXhhbXBsZVxuICogY29uc3QgcmVmT2JqZWN0ID0gdXNlUmVmKCk7XG4gKiBjb25zdCByZWZGbiA9IChyZWYpID0+IHsuLi4ufVxuICpcbiAqIGFzc2lnblJlZihyZWZPYmplY3QsIFwicmVmVmFsdWVcIik7XG4gKiBhc3NpZ25SZWYocmVmRm4sIFwicmVmVmFsdWVcIik7XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhc3NpZ25SZWYocmVmLCB2YWx1ZSkge1xuICAgIGlmICh0eXBlb2YgcmVmID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIHJlZih2YWx1ZSk7XG4gICAgfVxuICAgIGVsc2UgaWYgKHJlZikge1xuICAgICAgICByZWYuY3VycmVudCA9IHZhbHVlO1xuICAgIH1cbiAgICByZXR1cm4gcmVmO1xufVxuIiwiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG4vKipcbiAqIGNyZWF0ZXMgYSBNdXRhYmxlUmVmIHdpdGggcmVmIGNoYW5nZSBjYWxsYmFja1xuICogQHBhcmFtIGluaXRpYWxWYWx1ZSAtIGluaXRpYWwgcmVmIHZhbHVlXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFjayAtIGEgY2FsbGJhY2sgdG8gcnVuIHdoZW4gdmFsdWUgY2hhbmdlc1xuICpcbiAqIEBleGFtcGxlXG4gKiBjb25zdCByZWYgPSB1c2VDYWxsYmFja1JlZigwLCAobmV3VmFsdWUsIG9sZFZhbHVlKSA9PiBjb25zb2xlLmxvZyhvbGRWYWx1ZSwgJy0+JywgbmV3VmFsdWUpO1xuICogcmVmLmN1cnJlbnQgPSAxO1xuICogLy8gcHJpbnRzIDAgLT4gMVxuICpcbiAqIEBzZWUgaHR0cHM6Ly9yZWFjdGpzLm9yZy9kb2NzL2hvb2tzLXJlZmVyZW5jZS5odG1sI3VzZXJlZlxuICogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vdGhlS2FzaGV5L3VzZS1jYWxsYmFjay1yZWYjdXNlY2FsbGJhY2tyZWYtLS10by1yZXBsYWNlLXJlYWN0dXNlcmVmXG4gKiBAcmV0dXJucyB7TXV0YWJsZVJlZk9iamVjdH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUNhbGxiYWNrUmVmKGluaXRpYWxWYWx1ZSwgY2FsbGJhY2spIHtcbiAgICB2YXIgcmVmID0gdXNlU3RhdGUoZnVuY3Rpb24gKCkgeyByZXR1cm4gKHtcbiAgICAgICAgLy8gdmFsdWVcbiAgICAgICAgdmFsdWU6IGluaXRpYWxWYWx1ZSxcbiAgICAgICAgLy8gbGFzdCBjYWxsYmFja1xuICAgICAgICBjYWxsYmFjazogY2FsbGJhY2ssXG4gICAgICAgIC8vIFwibWVtb2l6ZWRcIiBwdWJsaWMgaW50ZXJmYWNlXG4gICAgICAgIGZhY2FkZToge1xuICAgICAgICAgICAgZ2V0IGN1cnJlbnQoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlZi52YWx1ZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzZXQgY3VycmVudCh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIHZhciBsYXN0ID0gcmVmLnZhbHVlO1xuICAgICAgICAgICAgICAgIGlmIChsYXN0ICE9PSB2YWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICByZWYudmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgcmVmLmNhbGxiYWNrKHZhbHVlLCBsYXN0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgIH0pOyB9KVswXTtcbiAgICAvLyB1cGRhdGUgY2FsbGJhY2tcbiAgICByZWYuY2FsbGJhY2sgPSBjYWxsYmFjaztcbiAgICByZXR1cm4gcmVmLmZhY2FkZTtcbn1cbiIsImltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGFzc2lnblJlZiB9IGZyb20gJy4vYXNzaWduUmVmJztcbmltcG9ydCB7IHVzZUNhbGxiYWNrUmVmIH0gZnJvbSAnLi91c2VSZWYnO1xudmFyIHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyA/IFJlYWN0LnVzZUxheW91dEVmZmVjdCA6IFJlYWN0LnVzZUVmZmVjdDtcbnZhciBjdXJyZW50VmFsdWVzID0gbmV3IFdlYWtNYXAoKTtcbi8qKlxuICogTWVyZ2VzIHR3byBvciBtb3JlIHJlZnMgdG9nZXRoZXIgcHJvdmlkaW5nIGEgc2luZ2xlIGludGVyZmFjZSB0byBzZXQgdGhlaXIgdmFsdWVcbiAqIEBwYXJhbSB7UmVmT2JqZWN0fFJlZn0gcmVmc1xuICogQHJldHVybnMge011dGFibGVSZWZPYmplY3R9IC0gYSBuZXcgcmVmLCB3aGljaCB0cmFuc2xhdGVzIGFsbCBjaGFuZ2VzIHRvIHtyZWZzfVxuICpcbiAqIEBzZWUge0BsaW5rIG1lcmdlUmVmc30gYSB2ZXJzaW9uIHdpdGhvdXQgYnVpdC1pbiBtZW1vaXphdGlvblxuICogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vdGhlS2FzaGV5L3VzZS1jYWxsYmFjay1yZWYjdXNlbWVyZ2VyZWZzXG4gKiBAZXhhbXBsZVxuICogY29uc3QgQ29tcG9uZW50ID0gUmVhY3QuZm9yd2FyZFJlZigocHJvcHMsIHJlZikgPT4ge1xuICogICBjb25zdCBvd25SZWYgPSB1c2VSZWYoKTtcbiAqICAgY29uc3QgZG9tUmVmID0gdXNlTWVyZ2VSZWZzKFtyZWYsIG93blJlZl0pOyAvLyDwn5GIIG1lcmdlIHRvZ2V0aGVyXG4gKiAgIHJldHVybiA8ZGl2IHJlZj17ZG9tUmVmfT4uLi48L2Rpdj5cbiAqIH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZU1lcmdlUmVmcyhyZWZzLCBkZWZhdWx0VmFsdWUpIHtcbiAgICB2YXIgY2FsbGJhY2tSZWYgPSB1c2VDYWxsYmFja1JlZihkZWZhdWx0VmFsdWUgfHwgbnVsbCwgZnVuY3Rpb24gKG5ld1ZhbHVlKSB7XG4gICAgICAgIHJldHVybiByZWZzLmZvckVhY2goZnVuY3Rpb24gKHJlZikgeyByZXR1cm4gYXNzaWduUmVmKHJlZiwgbmV3VmFsdWUpOyB9KTtcbiAgICB9KTtcbiAgICAvLyBoYW5kbGUgcmVmcyBjaGFuZ2VzIC0gYWRkZWQgb3IgcmVtb3ZlZFxuICAgIHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QoZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgb2xkVmFsdWUgPSBjdXJyZW50VmFsdWVzLmdldChjYWxsYmFja1JlZik7XG4gICAgICAgIGlmIChvbGRWYWx1ZSkge1xuICAgICAgICAgICAgdmFyIHByZXZSZWZzXzEgPSBuZXcgU2V0KG9sZFZhbHVlKTtcbiAgICAgICAgICAgIHZhciBuZXh0UmVmc18xID0gbmV3IFNldChyZWZzKTtcbiAgICAgICAgICAgIHZhciBjdXJyZW50XzEgPSBjYWxsYmFja1JlZi5jdXJyZW50O1xuICAgICAgICAgICAgcHJldlJlZnNfMS5mb3JFYWNoKGZ1bmN0aW9uIChyZWYpIHtcbiAgICAgICAgICAgICAgICBpZiAoIW5leHRSZWZzXzEuaGFzKHJlZikpIHtcbiAgICAgICAgICAgICAgICAgICAgYXNzaWduUmVmKHJlZiwgbnVsbCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBuZXh0UmVmc18xLmZvckVhY2goZnVuY3Rpb24gKHJlZikge1xuICAgICAgICAgICAgICAgIGlmICghcHJldlJlZnNfMS5oYXMocmVmKSkge1xuICAgICAgICAgICAgICAgICAgICBhc3NpZ25SZWYocmVmLCBjdXJyZW50XzEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGN1cnJlbnRWYWx1ZXMuc2V0KGNhbGxiYWNrUmVmLCByZWZzKTtcbiAgICB9LCBbcmVmc10pO1xuICAgIHJldHVybiBjYWxsYmFja1JlZjtcbn1cbiIsImltcG9ydCB7IF9fYXNzaWduIH0gZnJvbSBcInRzbGliXCI7XG5mdW5jdGlvbiBJdG9JKGEpIHtcbiAgICByZXR1cm4gYTtcbn1cbmZ1bmN0aW9uIGlubmVyQ3JlYXRlTWVkaXVtKGRlZmF1bHRzLCBtaWRkbGV3YXJlKSB7XG4gICAgaWYgKG1pZGRsZXdhcmUgPT09IHZvaWQgMCkgeyBtaWRkbGV3YXJlID0gSXRvSTsgfVxuICAgIHZhciBidWZmZXIgPSBbXTtcbiAgICB2YXIgYXNzaWduZWQgPSBmYWxzZTtcbiAgICB2YXIgbWVkaXVtID0ge1xuICAgICAgICByZWFkOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoYXNzaWduZWQpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1NpZGVjYXI6IGNvdWxkIG5vdCBgcmVhZGAgZnJvbSBhbiBgYXNzaWduZWRgIG1lZGl1bS4gYHJlYWRgIGNvdWxkIGJlIHVzZWQgb25seSB3aXRoIGB1c2VNZWRpdW1gLicpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGJ1ZmZlci5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYnVmZmVyW2J1ZmZlci5sZW5ndGggLSAxXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBkZWZhdWx0cztcbiAgICAgICAgfSxcbiAgICAgICAgdXNlTWVkaXVtOiBmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgICAgdmFyIGl0ZW0gPSBtaWRkbGV3YXJlKGRhdGEsIGFzc2lnbmVkKTtcbiAgICAgICAgICAgIGJ1ZmZlci5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBidWZmZXIgPSBidWZmZXIuZmlsdGVyKGZ1bmN0aW9uICh4KSB7IHJldHVybiB4ICE9PSBpdGVtOyB9KTtcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0sXG4gICAgICAgIGFzc2lnblN5bmNNZWRpdW06IGZ1bmN0aW9uIChjYikge1xuICAgICAgICAgICAgYXNzaWduZWQgPSB0cnVlO1xuICAgICAgICAgICAgd2hpbGUgKGJ1ZmZlci5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICB2YXIgY2JzID0gYnVmZmVyO1xuICAgICAgICAgICAgICAgIGJ1ZmZlciA9IFtdO1xuICAgICAgICAgICAgICAgIGNicy5mb3JFYWNoKGNiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJ1ZmZlciA9IHtcbiAgICAgICAgICAgICAgICBwdXNoOiBmdW5jdGlvbiAoeCkgeyByZXR1cm4gY2IoeCk7IH0sXG4gICAgICAgICAgICAgICAgZmlsdGVyOiBmdW5jdGlvbiAoKSB7IHJldHVybiBidWZmZXI7IH0sXG4gICAgICAgICAgICB9O1xuICAgICAgICB9LFxuICAgICAgICBhc3NpZ25NZWRpdW06IGZ1bmN0aW9uIChjYikge1xuICAgICAgICAgICAgYXNzaWduZWQgPSB0cnVlO1xuICAgICAgICAgICAgdmFyIHBlbmRpbmdRdWV1ZSA9IFtdO1xuICAgICAgICAgICAgaWYgKGJ1ZmZlci5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICB2YXIgY2JzID0gYnVmZmVyO1xuICAgICAgICAgICAgICAgIGJ1ZmZlciA9IFtdO1xuICAgICAgICAgICAgICAgIGNicy5mb3JFYWNoKGNiKTtcbiAgICAgICAgICAgICAgICBwZW5kaW5nUXVldWUgPSBidWZmZXI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgZXhlY3V0ZVF1ZXVlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHZhciBjYnMgPSBwZW5kaW5nUXVldWU7XG4gICAgICAgICAgICAgICAgcGVuZGluZ1F1ZXVlID0gW107XG4gICAgICAgICAgICAgICAgY2JzLmZvckVhY2goY2IpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHZhciBjeWNsZSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpLnRoZW4oZXhlY3V0ZVF1ZXVlKTsgfTtcbiAgICAgICAgICAgIGN5Y2xlKCk7XG4gICAgICAgICAgICBidWZmZXIgPSB7XG4gICAgICAgICAgICAgICAgcHVzaDogZnVuY3Rpb24gKHgpIHtcbiAgICAgICAgICAgICAgICAgICAgcGVuZGluZ1F1ZXVlLnB1c2goeCk7XG4gICAgICAgICAgICAgICAgICAgIGN5Y2xlKCk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBmaWx0ZXI6IGZ1bmN0aW9uIChmaWx0ZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgcGVuZGluZ1F1ZXVlID0gcGVuZGluZ1F1ZXVlLmZpbHRlcihmaWx0ZXIpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYnVmZmVyO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9O1xuICAgICAgICB9LFxuICAgIH07XG4gICAgcmV0dXJuIG1lZGl1bTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVNZWRpdW0oZGVmYXVsdHMsIG1pZGRsZXdhcmUpIHtcbiAgICBpZiAobWlkZGxld2FyZSA9PT0gdm9pZCAwKSB7IG1pZGRsZXdhcmUgPSBJdG9JOyB9XG4gICAgcmV0dXJuIGlubmVyQ3JlYXRlTWVkaXVtKGRlZmF1bHRzLCBtaWRkbGV3YXJlKTtcbn1cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXR5cGVzXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlU2lkZWNhck1lZGl1bShvcHRpb25zKSB7XG4gICAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkgeyBvcHRpb25zID0ge307IH1cbiAgICB2YXIgbWVkaXVtID0gaW5uZXJDcmVhdGVNZWRpdW0obnVsbCk7XG4gICAgbWVkaXVtLm9wdGlvbnMgPSBfX2Fzc2lnbih7IGFzeW5jOiB0cnVlLCBzc3I6IGZhbHNlIH0sIG9wdGlvbnMpO1xuICAgIHJldHVybiBtZWRpdW07XG59XG4iLCJpbXBvcnQgeyBfX2Fzc2lnbiwgX19yZXN0IH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG52YXIgU2lkZUNhciA9IGZ1bmN0aW9uIChfYSkge1xuICAgIHZhciBzaWRlQ2FyID0gX2Euc2lkZUNhciwgcmVzdCA9IF9fcmVzdChfYSwgW1wic2lkZUNhclwiXSk7XG4gICAgaWYgKCFzaWRlQ2FyKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignU2lkZWNhcjogcGxlYXNlIHByb3ZpZGUgYHNpZGVDYXJgIHByb3BlcnR5IHRvIGltcG9ydCB0aGUgcmlnaHQgY2FyJyk7XG4gICAgfVxuICAgIHZhciBUYXJnZXQgPSBzaWRlQ2FyLnJlYWQoKTtcbiAgICBpZiAoIVRhcmdldCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1NpZGVjYXIgbWVkaXVtIG5vdCBmb3VuZCcpO1xuICAgIH1cbiAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChUYXJnZXQsIF9fYXNzaWduKHt9LCByZXN0KSk7XG59O1xuU2lkZUNhci5pc1NpZGVDYXJFeHBvcnQgPSB0cnVlO1xuZXhwb3J0IGZ1bmN0aW9uIGV4cG9ydFNpZGVjYXIobWVkaXVtLCBleHBvcnRlZCkge1xuICAgIG1lZGl1bS51c2VNZWRpdW0oZXhwb3J0ZWQpO1xuICAgIHJldHVybiBTaWRlQ2FyO1xufVxuIiwiaW1wb3J0IHsgY3JlYXRlU2lkZWNhck1lZGl1bSB9IGZyb20gJ3VzZS1zaWRlY2FyJztcbmV4cG9ydCB2YXIgZWZmZWN0Q2FyID0gY3JlYXRlU2lkZWNhck1lZGl1bSgpO1xuIiwiaW1wb3J0IHsgX19hc3NpZ24sIF9fcmVzdCB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgZnVsbFdpZHRoQ2xhc3NOYW1lLCB6ZXJvUmlnaHRDbGFzc05hbWUgfSBmcm9tICdyZWFjdC1yZW1vdmUtc2Nyb2xsLWJhci9jb25zdGFudHMnO1xuaW1wb3J0IHsgdXNlTWVyZ2VSZWZzIH0gZnJvbSAndXNlLWNhbGxiYWNrLXJlZic7XG5pbXBvcnQgeyBlZmZlY3RDYXIgfSBmcm9tICcuL21lZGl1bSc7XG52YXIgbm90aGluZyA9IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm47XG59O1xuLyoqXG4gKiBSZW1vdmVzIHNjcm9sbGJhciBmcm9tIHRoZSBwYWdlIGFuZCBjb250YWluIHRoZSBzY3JvbGwgd2l0aGluIHRoZSBMb2NrXG4gKi9cbnZhciBSZW1vdmVTY3JvbGwgPSBSZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIChwcm9wcywgcGFyZW50UmVmKSB7XG4gICAgdmFyIHJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgICB2YXIgX2EgPSBSZWFjdC51c2VTdGF0ZSh7XG4gICAgICAgIG9uU2Nyb2xsQ2FwdHVyZTogbm90aGluZyxcbiAgICAgICAgb25XaGVlbENhcHR1cmU6IG5vdGhpbmcsXG4gICAgICAgIG9uVG91Y2hNb3ZlQ2FwdHVyZTogbm90aGluZyxcbiAgICB9KSwgY2FsbGJhY2tzID0gX2FbMF0sIHNldENhbGxiYWNrcyA9IF9hWzFdO1xuICAgIHZhciBmb3J3YXJkUHJvcHMgPSBwcm9wcy5mb3J3YXJkUHJvcHMsIGNoaWxkcmVuID0gcHJvcHMuY2hpbGRyZW4sIGNsYXNzTmFtZSA9IHByb3BzLmNsYXNzTmFtZSwgcmVtb3ZlU2Nyb2xsQmFyID0gcHJvcHMucmVtb3ZlU2Nyb2xsQmFyLCBlbmFibGVkID0gcHJvcHMuZW5hYmxlZCwgc2hhcmRzID0gcHJvcHMuc2hhcmRzLCBzaWRlQ2FyID0gcHJvcHMuc2lkZUNhciwgbm9SZWxhdGl2ZSA9IHByb3BzLm5vUmVsYXRpdmUsIG5vSXNvbGF0aW9uID0gcHJvcHMubm9Jc29sYXRpb24sIGluZXJ0ID0gcHJvcHMuaW5lcnQsIGFsbG93UGluY2hab29tID0gcHJvcHMuYWxsb3dQaW5jaFpvb20sIF9iID0gcHJvcHMuYXMsIENvbnRhaW5lciA9IF9iID09PSB2b2lkIDAgPyAnZGl2JyA6IF9iLCBnYXBNb2RlID0gcHJvcHMuZ2FwTW9kZSwgcmVzdCA9IF9fcmVzdChwcm9wcywgW1wiZm9yd2FyZFByb3BzXCIsIFwiY2hpbGRyZW5cIiwgXCJjbGFzc05hbWVcIiwgXCJyZW1vdmVTY3JvbGxCYXJcIiwgXCJlbmFibGVkXCIsIFwic2hhcmRzXCIsIFwic2lkZUNhclwiLCBcIm5vUmVsYXRpdmVcIiwgXCJub0lzb2xhdGlvblwiLCBcImluZXJ0XCIsIFwiYWxsb3dQaW5jaFpvb21cIiwgXCJhc1wiLCBcImdhcE1vZGVcIl0pO1xuICAgIHZhciBTaWRlQ2FyID0gc2lkZUNhcjtcbiAgICB2YXIgY29udGFpbmVyUmVmID0gdXNlTWVyZ2VSZWZzKFtyZWYsIHBhcmVudFJlZl0pO1xuICAgIHZhciBjb250YWluZXJQcm9wcyA9IF9fYXNzaWduKF9fYXNzaWduKHt9LCByZXN0KSwgY2FsbGJhY2tzKTtcbiAgICByZXR1cm4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGwsXG4gICAgICAgIGVuYWJsZWQgJiYgKFJlYWN0LmNyZWF0ZUVsZW1lbnQoU2lkZUNhciwgeyBzaWRlQ2FyOiBlZmZlY3RDYXIsIHJlbW92ZVNjcm9sbEJhcjogcmVtb3ZlU2Nyb2xsQmFyLCBzaGFyZHM6IHNoYXJkcywgbm9SZWxhdGl2ZTogbm9SZWxhdGl2ZSwgbm9Jc29sYXRpb246IG5vSXNvbGF0aW9uLCBpbmVydDogaW5lcnQsIHNldENhbGxiYWNrczogc2V0Q2FsbGJhY2tzLCBhbGxvd1BpbmNoWm9vbTogISFhbGxvd1BpbmNoWm9vbSwgbG9ja1JlZjogcmVmLCBnYXBNb2RlOiBnYXBNb2RlIH0pKSxcbiAgICAgICAgZm9yd2FyZFByb3BzID8gKFJlYWN0LmNsb25lRWxlbWVudChSZWFjdC5DaGlsZHJlbi5vbmx5KGNoaWxkcmVuKSwgX19hc3NpZ24oX19hc3NpZ24oe30sIGNvbnRhaW5lclByb3BzKSwgeyByZWY6IGNvbnRhaW5lclJlZiB9KSkpIDogKFJlYWN0LmNyZWF0ZUVsZW1lbnQoQ29udGFpbmVyLCBfX2Fzc2lnbih7fSwgY29udGFpbmVyUHJvcHMsIHsgY2xhc3NOYW1lOiBjbGFzc05hbWUsIHJlZjogY29udGFpbmVyUmVmIH0pLCBjaGlsZHJlbikpKSk7XG59KTtcblJlbW92ZVNjcm9sbC5kZWZhdWx0UHJvcHMgPSB7XG4gICAgZW5hYmxlZDogdHJ1ZSxcbiAgICByZW1vdmVTY3JvbGxCYXI6IHRydWUsXG4gICAgaW5lcnQ6IGZhbHNlLFxufTtcblJlbW92ZVNjcm9sbC5jbGFzc05hbWVzID0ge1xuICAgIGZ1bGxXaWR0aDogZnVsbFdpZHRoQ2xhc3NOYW1lLFxuICAgIHplcm9SaWdodDogemVyb1JpZ2h0Q2xhc3NOYW1lLFxufTtcbmV4cG9ydCB7IFJlbW92ZVNjcm9sbCB9O1xuIiwidmFyIGN1cnJlbnROb25jZTtcbmV4cG9ydCB2YXIgc2V0Tm9uY2UgPSBmdW5jdGlvbiAobm9uY2UpIHtcbiAgICBjdXJyZW50Tm9uY2UgPSBub25jZTtcbn07XG5leHBvcnQgdmFyIGdldE5vbmNlID0gZnVuY3Rpb24gKCkge1xuICAgIGlmIChjdXJyZW50Tm9uY2UpIHtcbiAgICAgICAgcmV0dXJuIGN1cnJlbnROb25jZTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBfX3dlYnBhY2tfbm9uY2VfXyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgcmV0dXJuIF9fd2VicGFja19ub25jZV9fO1xuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xufTtcbiIsImltcG9ydCB7IGdldE5vbmNlIH0gZnJvbSAnZ2V0LW5vbmNlJztcbmZ1bmN0aW9uIG1ha2VTdHlsZVRhZygpIHtcbiAgICBpZiAoIWRvY3VtZW50KVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB2YXIgdGFnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3R5bGUnKTtcbiAgICB0YWcudHlwZSA9ICd0ZXh0L2Nzcyc7XG4gICAgdmFyIG5vbmNlID0gZ2V0Tm9uY2UoKTtcbiAgICBpZiAobm9uY2UpIHtcbiAgICAgICAgdGFnLnNldEF0dHJpYnV0ZSgnbm9uY2UnLCBub25jZSk7XG4gICAgfVxuICAgIHJldHVybiB0YWc7XG59XG5mdW5jdGlvbiBpbmplY3RTdHlsZXModGFnLCBjc3MpIHtcbiAgICAvLyBAdHMtaWdub3JlXG4gICAgaWYgKHRhZy5zdHlsZVNoZWV0KSB7XG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgdGFnLnN0eWxlU2hlZXQuY3NzVGV4dCA9IGNzcztcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHRhZy5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShjc3MpKTtcbiAgICB9XG59XG5mdW5jdGlvbiBpbnNlcnRTdHlsZVRhZyh0YWcpIHtcbiAgICB2YXIgaGVhZCA9IGRvY3VtZW50LmhlYWQgfHwgZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2hlYWQnKVswXTtcbiAgICBoZWFkLmFwcGVuZENoaWxkKHRhZyk7XG59XG5leHBvcnQgdmFyIHN0eWxlc2hlZXRTaW5nbGV0b24gPSBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIGNvdW50ZXIgPSAwO1xuICAgIHZhciBzdHlsZXNoZWV0ID0gbnVsbDtcbiAgICByZXR1cm4ge1xuICAgICAgICBhZGQ6IGZ1bmN0aW9uIChzdHlsZSkge1xuICAgICAgICAgICAgaWYgKGNvdW50ZXIgPT0gMCkge1xuICAgICAgICAgICAgICAgIGlmICgoc3R5bGVzaGVldCA9IG1ha2VTdHlsZVRhZygpKSkge1xuICAgICAgICAgICAgICAgICAgICBpbmplY3RTdHlsZXMoc3R5bGVzaGVldCwgc3R5bGUpO1xuICAgICAgICAgICAgICAgICAgICBpbnNlcnRTdHlsZVRhZyhzdHlsZXNoZWV0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb3VudGVyKys7XG4gICAgICAgIH0sXG4gICAgICAgIHJlbW92ZTogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgY291bnRlci0tO1xuICAgICAgICAgICAgaWYgKCFjb3VudGVyICYmIHN0eWxlc2hlZXQpIHtcbiAgICAgICAgICAgICAgICBzdHlsZXNoZWV0LnBhcmVudE5vZGUgJiYgc3R5bGVzaGVldC5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHN0eWxlc2hlZXQpO1xuICAgICAgICAgICAgICAgIHN0eWxlc2hlZXQgPSBudWxsO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgIH07XG59O1xuIiwiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgc3R5bGVzaGVldFNpbmdsZXRvbiB9IGZyb20gJy4vc2luZ2xldG9uJztcbi8qKlxuICogY3JlYXRlcyBhIGhvb2sgdG8gY29udHJvbCBzdHlsZSBzaW5nbGV0b25cbiAqIEBzZWUge0BsaW5rIHN0eWxlU2luZ2xldG9ufSBmb3IgYSBzYWZlciBjb21wb25lbnQgdmVyc2lvblxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogY29uc3QgdXNlU3R5bGUgPSBzdHlsZUhvb2tTaW5nbGV0b24oKTtcbiAqIC8vL1xuICogdXNlU3R5bGUoJ2JvZHkgeyBvdmVyZmxvdzogaGlkZGVufScpO1xuICovXG5leHBvcnQgdmFyIHN0eWxlSG9va1NpbmdsZXRvbiA9IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2hlZXQgPSBzdHlsZXNoZWV0U2luZ2xldG9uKCk7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIChzdHlsZXMsIGlzRHluYW1pYykge1xuICAgICAgICBSZWFjdC51c2VFZmZlY3QoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgc2hlZXQuYWRkKHN0eWxlcyk7XG4gICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHNoZWV0LnJlbW92ZSgpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfSwgW3N0eWxlcyAmJiBpc0R5bmFtaWNdKTtcbiAgICB9O1xufTtcbiIsImltcG9ydCB7IHN0eWxlSG9va1NpbmdsZXRvbiB9IGZyb20gJy4vaG9vayc7XG4vKipcbiAqIGNyZWF0ZSBhIENvbXBvbmVudCB0byBhZGQgc3R5bGVzIG9uIGRlbWFuZFxuICogLSBzdHlsZXMgYXJlIGFkZGVkIHdoZW4gZmlyc3QgaW5zdGFuY2UgaXMgbW91bnRlZFxuICogLSBzdHlsZXMgYXJlIHJlbW92ZWQgd2hlbiB0aGUgbGFzdCBpbnN0YW5jZSBpcyB1bm1vdW50ZWRcbiAqIC0gY2hhbmdpbmcgc3R5bGVzIGluIHJ1bnRpbWUgZG9lcyBub3RoaW5nIHVubGVzcyBkeW5hbWljIGlzIHNldC4gQnV0IHdpdGggbXVsdGlwbGUgY29tcG9uZW50cyB0aGF0IGNhbiBsZWFkIHRvIHRoZSB1bmRlZmluZWQgYmVoYXZpb3JcbiAqL1xuZXhwb3J0IHZhciBzdHlsZVNpbmdsZXRvbiA9IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgdXNlU3R5bGUgPSBzdHlsZUhvb2tTaW5nbGV0b24oKTtcbiAgICB2YXIgU2hlZXQgPSBmdW5jdGlvbiAoX2EpIHtcbiAgICAgICAgdmFyIHN0eWxlcyA9IF9hLnN0eWxlcywgZHluYW1pYyA9IF9hLmR5bmFtaWM7XG4gICAgICAgIHVzZVN0eWxlKHN0eWxlcywgZHluYW1pYyk7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH07XG4gICAgcmV0dXJuIFNoZWV0O1xufTtcbiIsImV4cG9ydCB2YXIgemVyb0dhcCA9IHtcbiAgICBsZWZ0OiAwLFxuICAgIHRvcDogMCxcbiAgICByaWdodDogMCxcbiAgICBnYXA6IDAsXG59O1xudmFyIHBhcnNlID0gZnVuY3Rpb24gKHgpIHsgcmV0dXJuIHBhcnNlSW50KHggfHwgJycsIDEwKSB8fCAwOyB9O1xudmFyIGdldE9mZnNldCA9IGZ1bmN0aW9uIChnYXBNb2RlKSB7XG4gICAgdmFyIGNzID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoZG9jdW1lbnQuYm9keSk7XG4gICAgdmFyIGxlZnQgPSBjc1tnYXBNb2RlID09PSAncGFkZGluZycgPyAncGFkZGluZ0xlZnQnIDogJ21hcmdpbkxlZnQnXTtcbiAgICB2YXIgdG9wID0gY3NbZ2FwTW9kZSA9PT0gJ3BhZGRpbmcnID8gJ3BhZGRpbmdUb3AnIDogJ21hcmdpblRvcCddO1xuICAgIHZhciByaWdodCA9IGNzW2dhcE1vZGUgPT09ICdwYWRkaW5nJyA/ICdwYWRkaW5nUmlnaHQnIDogJ21hcmdpblJpZ2h0J107XG4gICAgcmV0dXJuIFtwYXJzZShsZWZ0KSwgcGFyc2UodG9wKSwgcGFyc2UocmlnaHQpXTtcbn07XG5leHBvcnQgdmFyIGdldEdhcFdpZHRoID0gZnVuY3Rpb24gKGdhcE1vZGUpIHtcbiAgICBpZiAoZ2FwTW9kZSA9PT0gdm9pZCAwKSB7IGdhcE1vZGUgPSAnbWFyZ2luJzsgfVxuICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICByZXR1cm4gemVyb0dhcDtcbiAgICB9XG4gICAgdmFyIG9mZnNldHMgPSBnZXRPZmZzZXQoZ2FwTW9kZSk7XG4gICAgdmFyIGRvY3VtZW50V2lkdGggPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xpZW50V2lkdGg7XG4gICAgdmFyIHdpbmRvd1dpZHRoID0gd2luZG93LmlubmVyV2lkdGg7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgbGVmdDogb2Zmc2V0c1swXSxcbiAgICAgICAgdG9wOiBvZmZzZXRzWzFdLFxuICAgICAgICByaWdodDogb2Zmc2V0c1syXSxcbiAgICAgICAgZ2FwOiBNYXRoLm1heCgwLCB3aW5kb3dXaWR0aCAtIGRvY3VtZW50V2lkdGggKyBvZmZzZXRzWzJdIC0gb2Zmc2V0c1swXSksXG4gICAgfTtcbn07XG4iLCJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBzdHlsZVNpbmdsZXRvbiB9IGZyb20gJ3JlYWN0LXN0eWxlLXNpbmdsZXRvbic7XG5pbXBvcnQgeyBmdWxsV2lkdGhDbGFzc05hbWUsIHplcm9SaWdodENsYXNzTmFtZSwgbm9TY3JvbGxiYXJzQ2xhc3NOYW1lLCByZW1vdmVkQmFyU2l6ZVZhcmlhYmxlIH0gZnJvbSAnLi9jb25zdGFudHMnO1xuaW1wb3J0IHsgZ2V0R2FwV2lkdGggfSBmcm9tICcuL3V0aWxzJztcbnZhciBTdHlsZSA9IHN0eWxlU2luZ2xldG9uKCk7XG5leHBvcnQgdmFyIGxvY2tBdHRyaWJ1dGUgPSAnZGF0YS1zY3JvbGwtbG9ja2VkJztcbi8vIGltcG9ydGFudCB0aXAgLSBvbmNlIHdlIG1lYXN1cmUgc2Nyb2xsQmFyIHdpZHRoIGFuZCByZW1vdmUgdGhlbVxuLy8gd2UgY291bGQgbm90IHJlcGVhdCB0aGlzIG9wZXJhdGlvblxuLy8gdGh1cyB3ZSBhcmUgdXNpbmcgc3R5bGUtc2luZ2xldG9uIC0gb25seSB0aGUgZmlyc3QgXCJ5ZXQgY29ycmVjdFwiIHN0eWxlIHdpbGwgYmUgYXBwbGllZC5cbnZhciBnZXRTdHlsZXMgPSBmdW5jdGlvbiAoX2EsIGFsbG93UmVsYXRpdmUsIGdhcE1vZGUsIGltcG9ydGFudCkge1xuICAgIHZhciBsZWZ0ID0gX2EubGVmdCwgdG9wID0gX2EudG9wLCByaWdodCA9IF9hLnJpZ2h0LCBnYXAgPSBfYS5nYXA7XG4gICAgaWYgKGdhcE1vZGUgPT09IHZvaWQgMCkgeyBnYXBNb2RlID0gJ21hcmdpbic7IH1cbiAgICByZXR1cm4gXCJcXG4gIC5cIi5jb25jYXQobm9TY3JvbGxiYXJzQ2xhc3NOYW1lLCBcIiB7XFxuICAgb3ZlcmZsb3c6IGhpZGRlbiBcIikuY29uY2F0KGltcG9ydGFudCwgXCI7XFxuICAgcGFkZGluZy1yaWdodDogXCIpLmNvbmNhdChnYXAsIFwicHggXCIpLmNvbmNhdChpbXBvcnRhbnQsIFwiO1xcbiAgfVxcbiAgYm9keVtcIikuY29uY2F0KGxvY2tBdHRyaWJ1dGUsIFwiXSB7XFxuICAgIG92ZXJmbG93OiBoaWRkZW4gXCIpLmNvbmNhdChpbXBvcnRhbnQsIFwiO1xcbiAgICBvdmVyc2Nyb2xsLWJlaGF2aW9yOiBjb250YWluO1xcbiAgICBcIikuY29uY2F0KFtcbiAgICAgICAgYWxsb3dSZWxhdGl2ZSAmJiBcInBvc2l0aW9uOiByZWxhdGl2ZSBcIi5jb25jYXQoaW1wb3J0YW50LCBcIjtcIiksXG4gICAgICAgIGdhcE1vZGUgPT09ICdtYXJnaW4nICYmXG4gICAgICAgICAgICBcIlxcbiAgICBwYWRkaW5nLWxlZnQ6IFwiLmNvbmNhdChsZWZ0LCBcInB4O1xcbiAgICBwYWRkaW5nLXRvcDogXCIpLmNvbmNhdCh0b3AsIFwicHg7XFxuICAgIHBhZGRpbmctcmlnaHQ6IFwiKS5jb25jYXQocmlnaHQsIFwicHg7XFxuICAgIG1hcmdpbi1sZWZ0OjA7XFxuICAgIG1hcmdpbi10b3A6MDtcXG4gICAgbWFyZ2luLXJpZ2h0OiBcIikuY29uY2F0KGdhcCwgXCJweCBcIikuY29uY2F0KGltcG9ydGFudCwgXCI7XFxuICAgIFwiKSxcbiAgICAgICAgZ2FwTW9kZSA9PT0gJ3BhZGRpbmcnICYmIFwicGFkZGluZy1yaWdodDogXCIuY29uY2F0KGdhcCwgXCJweCBcIikuY29uY2F0KGltcG9ydGFudCwgXCI7XCIpLFxuICAgIF1cbiAgICAgICAgLmZpbHRlcihCb29sZWFuKVxuICAgICAgICAuam9pbignJyksIFwiXFxuICB9XFxuICBcXG4gIC5cIikuY29uY2F0KHplcm9SaWdodENsYXNzTmFtZSwgXCIge1xcbiAgICByaWdodDogXCIpLmNvbmNhdChnYXAsIFwicHggXCIpLmNvbmNhdChpbXBvcnRhbnQsIFwiO1xcbiAgfVxcbiAgXFxuICAuXCIpLmNvbmNhdChmdWxsV2lkdGhDbGFzc05hbWUsIFwiIHtcXG4gICAgbWFyZ2luLXJpZ2h0OiBcIikuY29uY2F0KGdhcCwgXCJweCBcIikuY29uY2F0KGltcG9ydGFudCwgXCI7XFxuICB9XFxuICBcXG4gIC5cIikuY29uY2F0KHplcm9SaWdodENsYXNzTmFtZSwgXCIgLlwiKS5jb25jYXQoemVyb1JpZ2h0Q2xhc3NOYW1lLCBcIiB7XFxuICAgIHJpZ2h0OiAwIFwiKS5jb25jYXQoaW1wb3J0YW50LCBcIjtcXG4gIH1cXG4gIFxcbiAgLlwiKS5jb25jYXQoZnVsbFdpZHRoQ2xhc3NOYW1lLCBcIiAuXCIpLmNvbmNhdChmdWxsV2lkdGhDbGFzc05hbWUsIFwiIHtcXG4gICAgbWFyZ2luLXJpZ2h0OiAwIFwiKS5jb25jYXQoaW1wb3J0YW50LCBcIjtcXG4gIH1cXG4gIFxcbiAgYm9keVtcIikuY29uY2F0KGxvY2tBdHRyaWJ1dGUsIFwiXSB7XFxuICAgIFwiKS5jb25jYXQocmVtb3ZlZEJhclNpemVWYXJpYWJsZSwgXCI6IFwiKS5jb25jYXQoZ2FwLCBcInB4O1xcbiAgfVxcblwiKTtcbn07XG52YXIgZ2V0Q3VycmVudFVzZUNvdW50ZXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIGNvdW50ZXIgPSBwYXJzZUludChkb2N1bWVudC5ib2R5LmdldEF0dHJpYnV0ZShsb2NrQXR0cmlidXRlKSB8fCAnMCcsIDEwKTtcbiAgICByZXR1cm4gaXNGaW5pdGUoY291bnRlcikgPyBjb3VudGVyIDogMDtcbn07XG5leHBvcnQgdmFyIHVzZUxvY2tBdHRyaWJ1dGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgUmVhY3QudXNlRWZmZWN0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgZG9jdW1lbnQuYm9keS5zZXRBdHRyaWJ1dGUobG9ja0F0dHJpYnV0ZSwgKGdldEN1cnJlbnRVc2VDb3VudGVyKCkgKyAxKS50b1N0cmluZygpKTtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBuZXdDb3VudGVyID0gZ2V0Q3VycmVudFVzZUNvdW50ZXIoKSAtIDE7XG4gICAgICAgICAgICBpZiAobmV3Q291bnRlciA8PSAwKSB7XG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuYm9keS5yZW1vdmVBdHRyaWJ1dGUobG9ja0F0dHJpYnV0ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5ib2R5LnNldEF0dHJpYnV0ZShsb2NrQXR0cmlidXRlLCBuZXdDb3VudGVyLnRvU3RyaW5nKCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0sIFtdKTtcbn07XG4vKipcbiAqIFJlbW92ZXMgcGFnZSBzY3JvbGxiYXIgYW5kIGJsb2NrcyBwYWdlIHNjcm9sbCB3aGVuIG1vdW50ZWRcbiAqL1xuZXhwb3J0IHZhciBSZW1vdmVTY3JvbGxCYXIgPSBmdW5jdGlvbiAoX2EpIHtcbiAgICB2YXIgbm9SZWxhdGl2ZSA9IF9hLm5vUmVsYXRpdmUsIG5vSW1wb3J0YW50ID0gX2Eubm9JbXBvcnRhbnQsIF9iID0gX2EuZ2FwTW9kZSwgZ2FwTW9kZSA9IF9iID09PSB2b2lkIDAgPyAnbWFyZ2luJyA6IF9iO1xuICAgIHVzZUxvY2tBdHRyaWJ1dGUoKTtcbiAgICAvKlxuICAgICBnYXAgd2lsbCBiZSBtZWFzdXJlZCBvbiBldmVyeSBjb21wb25lbnQgbW91bnRcbiAgICAgaG93ZXZlciBpdCB3aWxsIGJlIHVzZWQgb25seSBieSB0aGUgXCJmaXJzdFwiIGludm9jYXRpb25cbiAgICAgZHVlIHRvIHNpbmdsZXRvbiBuYXR1cmUgb2YgPFN0eWxlXG4gICAgICovXG4gICAgdmFyIGdhcCA9IFJlYWN0LnVzZU1lbW8oZnVuY3Rpb24gKCkgeyByZXR1cm4gZ2V0R2FwV2lkdGgoZ2FwTW9kZSk7IH0sIFtnYXBNb2RlXSk7XG4gICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoU3R5bGUsIHsgc3R5bGVzOiBnZXRTdHlsZXMoZ2FwLCAhbm9SZWxhdGl2ZSwgZ2FwTW9kZSwgIW5vSW1wb3J0YW50ID8gJyFpbXBvcnRhbnQnIDogJycpIH0pO1xufTtcbiIsInZhciBwYXNzaXZlU3VwcG9ydGVkID0gZmFsc2U7XG5pZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICB0cnkge1xuICAgICAgICB2YXIgb3B0aW9ucyA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh7fSwgJ3Bhc3NpdmUnLCB7XG4gICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBwYXNzaXZlU3VwcG9ydGVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCd0ZXN0Jywgb3B0aW9ucywgb3B0aW9ucyk7XG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Rlc3QnLCBvcHRpb25zLCBvcHRpb25zKTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycikge1xuICAgICAgICBwYXNzaXZlU3VwcG9ydGVkID0gZmFsc2U7XG4gICAgfVxufVxuZXhwb3J0IHZhciBub25QYXNzaXZlID0gcGFzc2l2ZVN1cHBvcnRlZCA/IHsgcGFzc2l2ZTogZmFsc2UgfSA6IGZhbHNlO1xuIiwidmFyIGFsd2F5c0NvbnRhaW5zU2Nyb2xsID0gZnVuY3Rpb24gKG5vZGUpIHtcbiAgICAvLyB0ZXh0YXJlYSB3aWxsIGFsd2F5cyBfY29udGFpbl8gc2Nyb2xsIGluc2lkZSBzZWxmLiBJdCBvbmx5IGNhbiBiZSBoaWRkZW5cbiAgICByZXR1cm4gbm9kZS50YWdOYW1lID09PSAnVEVYVEFSRUEnO1xufTtcbnZhciBlbGVtZW50Q2FuQmVTY3JvbGxlZCA9IGZ1bmN0aW9uIChub2RlLCBvdmVyZmxvdykge1xuICAgIGlmICghKG5vZGUgaW5zdGFuY2VvZiBFbGVtZW50KSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHZhciBzdHlsZXMgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShub2RlKTtcbiAgICByZXR1cm4gKFxuICAgIC8vIG5vdC1ub3Qtc2Nyb2xsYWJsZVxuICAgIHN0eWxlc1tvdmVyZmxvd10gIT09ICdoaWRkZW4nICYmXG4gICAgICAgIC8vIGNvbnRhaW5zIHNjcm9sbCBpbnNpZGUgc2VsZlxuICAgICAgICAhKHN0eWxlcy5vdmVyZmxvd1kgPT09IHN0eWxlcy5vdmVyZmxvd1ggJiYgIWFsd2F5c0NvbnRhaW5zU2Nyb2xsKG5vZGUpICYmIHN0eWxlc1tvdmVyZmxvd10gPT09ICd2aXNpYmxlJykpO1xufTtcbnZhciBlbGVtZW50Q291bGRCZVZTY3JvbGxlZCA9IGZ1bmN0aW9uIChub2RlKSB7IHJldHVybiBlbGVtZW50Q2FuQmVTY3JvbGxlZChub2RlLCAnb3ZlcmZsb3dZJyk7IH07XG52YXIgZWxlbWVudENvdWxkQmVIU2Nyb2xsZWQgPSBmdW5jdGlvbiAobm9kZSkgeyByZXR1cm4gZWxlbWVudENhbkJlU2Nyb2xsZWQobm9kZSwgJ292ZXJmbG93WCcpOyB9O1xuZXhwb3J0IHZhciBsb2NhdGlvbkNvdWxkQmVTY3JvbGxlZCA9IGZ1bmN0aW9uIChheGlzLCBub2RlKSB7XG4gICAgdmFyIG93bmVyRG9jdW1lbnQgPSBub2RlLm93bmVyRG9jdW1lbnQ7XG4gICAgdmFyIGN1cnJlbnQgPSBub2RlO1xuICAgIGRvIHtcbiAgICAgICAgLy8gU2tpcCBvdmVyIHNoYWRvdyByb290XG4gICAgICAgIGlmICh0eXBlb2YgU2hhZG93Um9vdCAhPT0gJ3VuZGVmaW5lZCcgJiYgY3VycmVudCBpbnN0YW5jZW9mIFNoYWRvd1Jvb3QpIHtcbiAgICAgICAgICAgIGN1cnJlbnQgPSBjdXJyZW50Lmhvc3Q7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGlzU2Nyb2xsYWJsZSA9IGVsZW1lbnRDb3VsZEJlU2Nyb2xsZWQoYXhpcywgY3VycmVudCk7XG4gICAgICAgIGlmIChpc1Njcm9sbGFibGUpIHtcbiAgICAgICAgICAgIHZhciBfYSA9IGdldFNjcm9sbFZhcmlhYmxlcyhheGlzLCBjdXJyZW50KSwgc2Nyb2xsSGVpZ2h0ID0gX2FbMV0sIGNsaWVudEhlaWdodCA9IF9hWzJdO1xuICAgICAgICAgICAgaWYgKHNjcm9sbEhlaWdodCA+IGNsaWVudEhlaWdodCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGN1cnJlbnQgPSBjdXJyZW50LnBhcmVudE5vZGU7XG4gICAgfSB3aGlsZSAoY3VycmVudCAmJiBjdXJyZW50ICE9PSBvd25lckRvY3VtZW50LmJvZHkpO1xuICAgIHJldHVybiBmYWxzZTtcbn07XG52YXIgZ2V0VlNjcm9sbFZhcmlhYmxlcyA9IGZ1bmN0aW9uIChfYSkge1xuICAgIHZhciBzY3JvbGxUb3AgPSBfYS5zY3JvbGxUb3AsIHNjcm9sbEhlaWdodCA9IF9hLnNjcm9sbEhlaWdodCwgY2xpZW50SGVpZ2h0ID0gX2EuY2xpZW50SGVpZ2h0O1xuICAgIHJldHVybiBbXG4gICAgICAgIHNjcm9sbFRvcCxcbiAgICAgICAgc2Nyb2xsSGVpZ2h0LFxuICAgICAgICBjbGllbnRIZWlnaHQsXG4gICAgXTtcbn07XG52YXIgZ2V0SFNjcm9sbFZhcmlhYmxlcyA9IGZ1bmN0aW9uIChfYSkge1xuICAgIHZhciBzY3JvbGxMZWZ0ID0gX2Euc2Nyb2xsTGVmdCwgc2Nyb2xsV2lkdGggPSBfYS5zY3JvbGxXaWR0aCwgY2xpZW50V2lkdGggPSBfYS5jbGllbnRXaWR0aDtcbiAgICByZXR1cm4gW1xuICAgICAgICBzY3JvbGxMZWZ0LFxuICAgICAgICBzY3JvbGxXaWR0aCxcbiAgICAgICAgY2xpZW50V2lkdGgsXG4gICAgXTtcbn07XG52YXIgZWxlbWVudENvdWxkQmVTY3JvbGxlZCA9IGZ1bmN0aW9uIChheGlzLCBub2RlKSB7XG4gICAgcmV0dXJuIGF4aXMgPT09ICd2JyA/IGVsZW1lbnRDb3VsZEJlVlNjcm9sbGVkKG5vZGUpIDogZWxlbWVudENvdWxkQmVIU2Nyb2xsZWQobm9kZSk7XG59O1xudmFyIGdldFNjcm9sbFZhcmlhYmxlcyA9IGZ1bmN0aW9uIChheGlzLCBub2RlKSB7XG4gICAgcmV0dXJuIGF4aXMgPT09ICd2JyA/IGdldFZTY3JvbGxWYXJpYWJsZXMobm9kZSkgOiBnZXRIU2Nyb2xsVmFyaWFibGVzKG5vZGUpO1xufTtcbnZhciBnZXREaXJlY3Rpb25GYWN0b3IgPSBmdW5jdGlvbiAoYXhpcywgZGlyZWN0aW9uKSB7XG4gICAgLyoqXG4gICAgICogSWYgdGhlIGVsZW1lbnQncyBkaXJlY3Rpb24gaXMgcnRsIChyaWdodC10by1sZWZ0KSwgdGhlbiBzY3JvbGxMZWZ0IGlzIDAgd2hlbiB0aGUgc2Nyb2xsYmFyIGlzIGF0IGl0cyByaWdodG1vc3QgcG9zaXRpb24sXG4gICAgICogYW5kIHRoZW4gaW5jcmVhc2luZ2x5IG5lZ2F0aXZlIGFzIHlvdSBzY3JvbGwgdG93YXJkcyB0aGUgZW5kIG9mIHRoZSBjb250ZW50LlxuICAgICAqIEBzZWUgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0VsZW1lbnQvc2Nyb2xsTGVmdFxuICAgICAqL1xuICAgIHJldHVybiBheGlzID09PSAnaCcgJiYgZGlyZWN0aW9uID09PSAncnRsJyA/IC0xIDogMTtcbn07XG5leHBvcnQgdmFyIGhhbmRsZVNjcm9sbCA9IGZ1bmN0aW9uIChheGlzLCBlbmRUYXJnZXQsIGV2ZW50LCBzb3VyY2VEZWx0YSwgbm9PdmVyc2Nyb2xsKSB7XG4gICAgdmFyIGRpcmVjdGlvbkZhY3RvciA9IGdldERpcmVjdGlvbkZhY3RvcihheGlzLCB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShlbmRUYXJnZXQpLmRpcmVjdGlvbik7XG4gICAgdmFyIGRlbHRhID0gZGlyZWN0aW9uRmFjdG9yICogc291cmNlRGVsdGE7XG4gICAgLy8gZmluZCBzY3JvbGxhYmxlIHRhcmdldFxuICAgIHZhciB0YXJnZXQgPSBldmVudC50YXJnZXQ7XG4gICAgdmFyIHRhcmdldEluTG9jayA9IGVuZFRhcmdldC5jb250YWlucyh0YXJnZXQpO1xuICAgIHZhciBzaG91bGRDYW5jZWxTY3JvbGwgPSBmYWxzZTtcbiAgICB2YXIgaXNEZWx0YVBvc2l0aXZlID0gZGVsdGEgPiAwO1xuICAgIHZhciBhdmFpbGFibGVTY3JvbGwgPSAwO1xuICAgIHZhciBhdmFpbGFibGVTY3JvbGxUb3AgPSAwO1xuICAgIGRvIHtcbiAgICAgICAgaWYgKCF0YXJnZXQpIHtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIHZhciBfYSA9IGdldFNjcm9sbFZhcmlhYmxlcyhheGlzLCB0YXJnZXQpLCBwb3NpdGlvbiA9IF9hWzBdLCBzY3JvbGxfMSA9IF9hWzFdLCBjYXBhY2l0eSA9IF9hWzJdO1xuICAgICAgICB2YXIgZWxlbWVudFNjcm9sbCA9IHNjcm9sbF8xIC0gY2FwYWNpdHkgLSBkaXJlY3Rpb25GYWN0b3IgKiBwb3NpdGlvbjtcbiAgICAgICAgaWYgKHBvc2l0aW9uIHx8IGVsZW1lbnRTY3JvbGwpIHtcbiAgICAgICAgICAgIGlmIChlbGVtZW50Q291bGRCZVNjcm9sbGVkKGF4aXMsIHRhcmdldCkpIHtcbiAgICAgICAgICAgICAgICBhdmFpbGFibGVTY3JvbGwgKz0gZWxlbWVudFNjcm9sbDtcbiAgICAgICAgICAgICAgICBhdmFpbGFibGVTY3JvbGxUb3AgKz0gcG9zaXRpb247XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHBhcmVudF8xID0gdGFyZ2V0LnBhcmVudE5vZGU7XG4gICAgICAgIC8vIHdlIHdpbGwgXCJidWJibGVcIiBmcm9tIFNoYWRvd0RvbSBpbiBjYXNlIHdlIGFyZSwgb3IganVzdCB0byB0aGUgcGFyZW50IGluIG5vcm1hbCBjYXNlXG4gICAgICAgIC8vIHRoaXMgaXMgdGhlIHNhbWUgbG9naWMgdXNlZCBpbiBmb2N1cy1sb2NrXG4gICAgICAgIHRhcmdldCA9IChwYXJlbnRfMSAmJiBwYXJlbnRfMS5ub2RlVHlwZSA9PT0gTm9kZS5ET0NVTUVOVF9GUkFHTUVOVF9OT0RFID8gcGFyZW50XzEuaG9zdCA6IHBhcmVudF8xKTtcbiAgICB9IHdoaWxlIChcbiAgICAvLyBwb3J0YWxlZCBjb250ZW50XG4gICAgKCF0YXJnZXRJbkxvY2sgJiYgdGFyZ2V0ICE9PSBkb2N1bWVudC5ib2R5KSB8fFxuICAgICAgICAvLyBzZWxmIGNvbnRlbnRcbiAgICAgICAgKHRhcmdldEluTG9jayAmJiAoZW5kVGFyZ2V0LmNvbnRhaW5zKHRhcmdldCkgfHwgZW5kVGFyZ2V0ID09PSB0YXJnZXQpKSk7XG4gICAgLy8gaGFuZGxlIGVwc2lsb24gYXJvdW5kIDAgKG5vbiBzdGFuZGFyZCB6b29tIGxldmVscylcbiAgICBpZiAoaXNEZWx0YVBvc2l0aXZlICYmXG4gICAgICAgICgobm9PdmVyc2Nyb2xsICYmIE1hdGguYWJzKGF2YWlsYWJsZVNjcm9sbCkgPCAxKSB8fCAoIW5vT3ZlcnNjcm9sbCAmJiBkZWx0YSA+IGF2YWlsYWJsZVNjcm9sbCkpKSB7XG4gICAgICAgIHNob3VsZENhbmNlbFNjcm9sbCA9IHRydWU7XG4gICAgfVxuICAgIGVsc2UgaWYgKCFpc0RlbHRhUG9zaXRpdmUgJiZcbiAgICAgICAgKChub092ZXJzY3JvbGwgJiYgTWF0aC5hYnMoYXZhaWxhYmxlU2Nyb2xsVG9wKSA8IDEpIHx8ICghbm9PdmVyc2Nyb2xsICYmIC1kZWx0YSA+IGF2YWlsYWJsZVNjcm9sbFRvcCkpKSB7XG4gICAgICAgIHNob3VsZENhbmNlbFNjcm9sbCA9IHRydWU7XG4gICAgfVxuICAgIHJldHVybiBzaG91bGRDYW5jZWxTY3JvbGw7XG59O1xuIiwiaW1wb3J0IHsgX19zcHJlYWRBcnJheSB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgUmVtb3ZlU2Nyb2xsQmFyIH0gZnJvbSAncmVhY3QtcmVtb3ZlLXNjcm9sbC1iYXInO1xuaW1wb3J0IHsgc3R5bGVTaW5nbGV0b24gfSBmcm9tICdyZWFjdC1zdHlsZS1zaW5nbGV0b24nO1xuaW1wb3J0IHsgbm9uUGFzc2l2ZSB9IGZyb20gJy4vYWdncmVzaXZlQ2FwdHVyZSc7XG5pbXBvcnQgeyBoYW5kbGVTY3JvbGwsIGxvY2F0aW9uQ291bGRCZVNjcm9sbGVkIH0gZnJvbSAnLi9oYW5kbGVTY3JvbGwnO1xuZXhwb3J0IHZhciBnZXRUb3VjaFhZID0gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgcmV0dXJuICdjaGFuZ2VkVG91Y2hlcycgaW4gZXZlbnQgPyBbZXZlbnQuY2hhbmdlZFRvdWNoZXNbMF0uY2xpZW50WCwgZXZlbnQuY2hhbmdlZFRvdWNoZXNbMF0uY2xpZW50WV0gOiBbMCwgMF07XG59O1xuZXhwb3J0IHZhciBnZXREZWx0YVhZID0gZnVuY3Rpb24gKGV2ZW50KSB7IHJldHVybiBbZXZlbnQuZGVsdGFYLCBldmVudC5kZWx0YVldOyB9O1xudmFyIGV4dHJhY3RSZWYgPSBmdW5jdGlvbiAocmVmKSB7XG4gICAgcmV0dXJuIHJlZiAmJiAnY3VycmVudCcgaW4gcmVmID8gcmVmLmN1cnJlbnQgOiByZWY7XG59O1xudmFyIGRlbHRhQ29tcGFyZSA9IGZ1bmN0aW9uICh4LCB5KSB7IHJldHVybiB4WzBdID09PSB5WzBdICYmIHhbMV0gPT09IHlbMV07IH07XG52YXIgZ2VuZXJhdGVTdHlsZSA9IGZ1bmN0aW9uIChpZCkgeyByZXR1cm4gXCJcXG4gIC5ibG9jay1pbnRlcmFjdGl2aXR5LVwiLmNvbmNhdChpZCwgXCIge3BvaW50ZXItZXZlbnRzOiBub25lO31cXG4gIC5hbGxvdy1pbnRlcmFjdGl2aXR5LVwiKS5jb25jYXQoaWQsIFwiIHtwb2ludGVyLWV2ZW50czogYWxsO31cXG5cIik7IH07XG52YXIgaWRDb3VudGVyID0gMDtcbnZhciBsb2NrU3RhY2sgPSBbXTtcbmV4cG9ydCBmdW5jdGlvbiBSZW1vdmVTY3JvbGxTaWRlQ2FyKHByb3BzKSB7XG4gICAgdmFyIHNob3VsZFByZXZlbnRRdWV1ZSA9IFJlYWN0LnVzZVJlZihbXSk7XG4gICAgdmFyIHRvdWNoU3RhcnRSZWYgPSBSZWFjdC51c2VSZWYoWzAsIDBdKTtcbiAgICB2YXIgYWN0aXZlQXhpcyA9IFJlYWN0LnVzZVJlZigpO1xuICAgIHZhciBpZCA9IFJlYWN0LnVzZVN0YXRlKGlkQ291bnRlcisrKVswXTtcbiAgICB2YXIgU3R5bGUgPSBSZWFjdC51c2VTdGF0ZShzdHlsZVNpbmdsZXRvbilbMF07XG4gICAgdmFyIGxhc3RQcm9wcyA9IFJlYWN0LnVzZVJlZihwcm9wcyk7XG4gICAgUmVhY3QudXNlRWZmZWN0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgbGFzdFByb3BzLmN1cnJlbnQgPSBwcm9wcztcbiAgICB9LCBbcHJvcHNdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAocHJvcHMuaW5lcnQpIHtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LmFkZChcImJsb2NrLWludGVyYWN0aXZpdHktXCIuY29uY2F0KGlkKSk7XG4gICAgICAgICAgICB2YXIgYWxsb3dfMSA9IF9fc3ByZWFkQXJyYXkoW3Byb3BzLmxvY2tSZWYuY3VycmVudF0sIChwcm9wcy5zaGFyZHMgfHwgW10pLm1hcChleHRyYWN0UmVmKSwgdHJ1ZSkuZmlsdGVyKEJvb2xlYW4pO1xuICAgICAgICAgICAgYWxsb3dfMS5mb3JFYWNoKGZ1bmN0aW9uIChlbCkgeyByZXR1cm4gZWwuY2xhc3NMaXN0LmFkZChcImFsbG93LWludGVyYWN0aXZpdHktXCIuY29uY2F0KGlkKSk7IH0pO1xuICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5yZW1vdmUoXCJibG9jay1pbnRlcmFjdGl2aXR5LVwiLmNvbmNhdChpZCkpO1xuICAgICAgICAgICAgICAgIGFsbG93XzEuZm9yRWFjaChmdW5jdGlvbiAoZWwpIHsgcmV0dXJuIGVsLmNsYXNzTGlzdC5yZW1vdmUoXCJhbGxvdy1pbnRlcmFjdGl2aXR5LVwiLmNvbmNhdChpZCkpOyB9KTtcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgIH0sIFtwcm9wcy5pbmVydCwgcHJvcHMubG9ja1JlZi5jdXJyZW50LCBwcm9wcy5zaGFyZHNdKTtcbiAgICB2YXIgc2hvdWxkQ2FuY2VsRXZlbnQgPSBSZWFjdC51c2VDYWxsYmFjayhmdW5jdGlvbiAoZXZlbnQsIHBhcmVudCkge1xuICAgICAgICBpZiAoKCd0b3VjaGVzJyBpbiBldmVudCAmJiBldmVudC50b3VjaGVzLmxlbmd0aCA9PT0gMikgfHwgKGV2ZW50LnR5cGUgPT09ICd3aGVlbCcgJiYgZXZlbnQuY3RybEtleSkpIHtcbiAgICAgICAgICAgIHJldHVybiAhbGFzdFByb3BzLmN1cnJlbnQuYWxsb3dQaW5jaFpvb207XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHRvdWNoID0gZ2V0VG91Y2hYWShldmVudCk7XG4gICAgICAgIHZhciB0b3VjaFN0YXJ0ID0gdG91Y2hTdGFydFJlZi5jdXJyZW50O1xuICAgICAgICB2YXIgZGVsdGFYID0gJ2RlbHRhWCcgaW4gZXZlbnQgPyBldmVudC5kZWx0YVggOiB0b3VjaFN0YXJ0WzBdIC0gdG91Y2hbMF07XG4gICAgICAgIHZhciBkZWx0YVkgPSAnZGVsdGFZJyBpbiBldmVudCA/IGV2ZW50LmRlbHRhWSA6IHRvdWNoU3RhcnRbMV0gLSB0b3VjaFsxXTtcbiAgICAgICAgdmFyIGN1cnJlbnRBeGlzO1xuICAgICAgICB2YXIgdGFyZ2V0ID0gZXZlbnQudGFyZ2V0O1xuICAgICAgICB2YXIgbW92ZURpcmVjdGlvbiA9IE1hdGguYWJzKGRlbHRhWCkgPiBNYXRoLmFicyhkZWx0YVkpID8gJ2gnIDogJ3YnO1xuICAgICAgICAvLyBhbGxvdyBob3Jpem9udGFsIHRvdWNoIG1vdmUgb24gUmFuZ2UgaW5wdXRzLiBUaGV5IHdpbGwgbm90IGNhdXNlIGFueSBzY3JvbGxcbiAgICAgICAgaWYgKCd0b3VjaGVzJyBpbiBldmVudCAmJiBtb3ZlRGlyZWN0aW9uID09PSAnaCcgJiYgdGFyZ2V0LnR5cGUgPT09ICdyYW5nZScpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBhbGxvdyBkcmFnIHNlbGVjdGlvbiAoaU9TKTsgY2hlY2sgaWYgc2VsZWN0aW9uJ3MgYW5jaG9yTm9kZSBpcyB0aGUgc2FtZSBhcyB0YXJnZXQgb3IgY29udGFpbnMgdGFyZ2V0XG4gICAgICAgIHZhciBzZWxlY3Rpb24gPSB3aW5kb3cuZ2V0U2VsZWN0aW9uKCk7XG4gICAgICAgIHZhciBhbmNob3JOb2RlID0gc2VsZWN0aW9uICYmIHNlbGVjdGlvbi5hbmNob3JOb2RlO1xuICAgICAgICB2YXIgaXNUb3VjaGluZ1NlbGVjdGlvbiA9IGFuY2hvck5vZGUgPyBhbmNob3JOb2RlID09PSB0YXJnZXQgfHwgYW5jaG9yTm9kZS5jb250YWlucyh0YXJnZXQpIDogZmFsc2U7XG4gICAgICAgIGlmIChpc1RvdWNoaW5nU2VsZWN0aW9uKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGNhbkJlU2Nyb2xsZWRJbk1haW5EaXJlY3Rpb24gPSBsb2NhdGlvbkNvdWxkQmVTY3JvbGxlZChtb3ZlRGlyZWN0aW9uLCB0YXJnZXQpO1xuICAgICAgICBpZiAoIWNhbkJlU2Nyb2xsZWRJbk1haW5EaXJlY3Rpb24pIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjYW5CZVNjcm9sbGVkSW5NYWluRGlyZWN0aW9uKSB7XG4gICAgICAgICAgICBjdXJyZW50QXhpcyA9IG1vdmVEaXJlY3Rpb247XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjdXJyZW50QXhpcyA9IG1vdmVEaXJlY3Rpb24gPT09ICd2JyA/ICdoJyA6ICd2JztcbiAgICAgICAgICAgIGNhbkJlU2Nyb2xsZWRJbk1haW5EaXJlY3Rpb24gPSBsb2NhdGlvbkNvdWxkQmVTY3JvbGxlZChtb3ZlRGlyZWN0aW9uLCB0YXJnZXQpO1xuICAgICAgICAgICAgLy8gb3RoZXIgYXhpcyBtaWdodCBiZSBub3Qgc2Nyb2xsYWJsZVxuICAgICAgICB9XG4gICAgICAgIGlmICghY2FuQmVTY3JvbGxlZEluTWFpbkRpcmVjdGlvbikge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGlmICghYWN0aXZlQXhpcy5jdXJyZW50ICYmICdjaGFuZ2VkVG91Y2hlcycgaW4gZXZlbnQgJiYgKGRlbHRhWCB8fCBkZWx0YVkpKSB7XG4gICAgICAgICAgICBhY3RpdmVBeGlzLmN1cnJlbnQgPSBjdXJyZW50QXhpcztcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWN1cnJlbnRBeGlzKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgY2FuY2VsaW5nQXhpcyA9IGFjdGl2ZUF4aXMuY3VycmVudCB8fCBjdXJyZW50QXhpcztcbiAgICAgICAgcmV0dXJuIGhhbmRsZVNjcm9sbChjYW5jZWxpbmdBeGlzLCBwYXJlbnQsIGV2ZW50LCBjYW5jZWxpbmdBeGlzID09PSAnaCcgPyBkZWx0YVggOiBkZWx0YVksIHRydWUpO1xuICAgIH0sIFtdKTtcbiAgICB2YXIgc2hvdWxkUHJldmVudCA9IFJlYWN0LnVzZUNhbGxiYWNrKGZ1bmN0aW9uIChfZXZlbnQpIHtcbiAgICAgICAgdmFyIGV2ZW50ID0gX2V2ZW50O1xuICAgICAgICBpZiAoIWxvY2tTdGFjay5sZW5ndGggfHwgbG9ja1N0YWNrW2xvY2tTdGFjay5sZW5ndGggLSAxXSAhPT0gU3R5bGUpIHtcbiAgICAgICAgICAgIC8vIG5vdCB0aGUgbGFzdCBhY3RpdmVcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB2YXIgZGVsdGEgPSAnZGVsdGFZJyBpbiBldmVudCA/IGdldERlbHRhWFkoZXZlbnQpIDogZ2V0VG91Y2hYWShldmVudCk7XG4gICAgICAgIHZhciBzb3VyY2VFdmVudCA9IHNob3VsZFByZXZlbnRRdWV1ZS5jdXJyZW50LmZpbHRlcihmdW5jdGlvbiAoZSkgeyByZXR1cm4gZS5uYW1lID09PSBldmVudC50eXBlICYmIChlLnRhcmdldCA9PT0gZXZlbnQudGFyZ2V0IHx8IGV2ZW50LnRhcmdldCA9PT0gZS5zaGFkb3dQYXJlbnQpICYmIGRlbHRhQ29tcGFyZShlLmRlbHRhLCBkZWx0YSk7IH0pWzBdO1xuICAgICAgICAvLyBzZWxmIGV2ZW50LCBhbmQgc2hvdWxkIGJlIGNhbmNlbGVkXG4gICAgICAgIGlmIChzb3VyY2VFdmVudCAmJiBzb3VyY2VFdmVudC5zaG91bGQpIHtcbiAgICAgICAgICAgIGlmIChldmVudC5jYW5jZWxhYmxlKSB7XG4gICAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyBvdXRzaWRlIG9yIHNoYXJkIGV2ZW50XG4gICAgICAgIGlmICghc291cmNlRXZlbnQpIHtcbiAgICAgICAgICAgIHZhciBzaGFyZE5vZGVzID0gKGxhc3RQcm9wcy5jdXJyZW50LnNoYXJkcyB8fCBbXSlcbiAgICAgICAgICAgICAgICAubWFwKGV4dHJhY3RSZWYpXG4gICAgICAgICAgICAgICAgLmZpbHRlcihCb29sZWFuKVxuICAgICAgICAgICAgICAgIC5maWx0ZXIoZnVuY3Rpb24gKG5vZGUpIHsgcmV0dXJuIG5vZGUuY29udGFpbnMoZXZlbnQudGFyZ2V0KTsgfSk7XG4gICAgICAgICAgICB2YXIgc2hvdWxkU3RvcCA9IHNoYXJkTm9kZXMubGVuZ3RoID4gMCA/IHNob3VsZENhbmNlbEV2ZW50KGV2ZW50LCBzaGFyZE5vZGVzWzBdKSA6ICFsYXN0UHJvcHMuY3VycmVudC5ub0lzb2xhdGlvbjtcbiAgICAgICAgICAgIGlmIChzaG91bGRTdG9wKSB7XG4gICAgICAgICAgICAgICAgaWYgKGV2ZW50LmNhbmNlbGFibGUpIHtcbiAgICAgICAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbXSk7XG4gICAgdmFyIHNob3VsZENhbmNlbCA9IFJlYWN0LnVzZUNhbGxiYWNrKGZ1bmN0aW9uIChuYW1lLCBkZWx0YSwgdGFyZ2V0LCBzaG91bGQpIHtcbiAgICAgICAgdmFyIGV2ZW50ID0geyBuYW1lOiBuYW1lLCBkZWx0YTogZGVsdGEsIHRhcmdldDogdGFyZ2V0LCBzaG91bGQ6IHNob3VsZCwgc2hhZG93UGFyZW50OiBnZXRPdXRlcm1vc3RTaGFkb3dQYXJlbnQodGFyZ2V0KSB9O1xuICAgICAgICBzaG91bGRQcmV2ZW50UXVldWUuY3VycmVudC5wdXNoKGV2ZW50KTtcbiAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBzaG91bGRQcmV2ZW50UXVldWUuY3VycmVudCA9IHNob3VsZFByZXZlbnRRdWV1ZS5jdXJyZW50LmZpbHRlcihmdW5jdGlvbiAoZSkgeyByZXR1cm4gZSAhPT0gZXZlbnQ7IH0pO1xuICAgICAgICB9LCAxKTtcbiAgICB9LCBbXSk7XG4gICAgdmFyIHNjcm9sbFRvdWNoU3RhcnQgPSBSZWFjdC51c2VDYWxsYmFjayhmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgdG91Y2hTdGFydFJlZi5jdXJyZW50ID0gZ2V0VG91Y2hYWShldmVudCk7XG4gICAgICAgIGFjdGl2ZUF4aXMuY3VycmVudCA9IHVuZGVmaW5lZDtcbiAgICB9LCBbXSk7XG4gICAgdmFyIHNjcm9sbFdoZWVsID0gUmVhY3QudXNlQ2FsbGJhY2soZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICAgIHNob3VsZENhbmNlbChldmVudC50eXBlLCBnZXREZWx0YVhZKGV2ZW50KSwgZXZlbnQudGFyZ2V0LCBzaG91bGRDYW5jZWxFdmVudChldmVudCwgcHJvcHMubG9ja1JlZi5jdXJyZW50KSk7XG4gICAgfSwgW10pO1xuICAgIHZhciBzY3JvbGxUb3VjaE1vdmUgPSBSZWFjdC51c2VDYWxsYmFjayhmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgc2hvdWxkQ2FuY2VsKGV2ZW50LnR5cGUsIGdldFRvdWNoWFkoZXZlbnQpLCBldmVudC50YXJnZXQsIHNob3VsZENhbmNlbEV2ZW50KGV2ZW50LCBwcm9wcy5sb2NrUmVmLmN1cnJlbnQpKTtcbiAgICB9LCBbXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgbG9ja1N0YWNrLnB1c2goU3R5bGUpO1xuICAgICAgICBwcm9wcy5zZXRDYWxsYmFja3Moe1xuICAgICAgICAgICAgb25TY3JvbGxDYXB0dXJlOiBzY3JvbGxXaGVlbCxcbiAgICAgICAgICAgIG9uV2hlZWxDYXB0dXJlOiBzY3JvbGxXaGVlbCxcbiAgICAgICAgICAgIG9uVG91Y2hNb3ZlQ2FwdHVyZTogc2Nyb2xsVG91Y2hNb3ZlLFxuICAgICAgICB9KTtcbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignd2hlZWwnLCBzaG91bGRQcmV2ZW50LCBub25QYXNzaXZlKTtcbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigndG91Y2htb3ZlJywgc2hvdWxkUHJldmVudCwgbm9uUGFzc2l2ZSk7XG4gICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3RvdWNoc3RhcnQnLCBzY3JvbGxUb3VjaFN0YXJ0LCBub25QYXNzaXZlKTtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGxvY2tTdGFjayA9IGxvY2tTdGFjay5maWx0ZXIoZnVuY3Rpb24gKGluc3QpIHsgcmV0dXJuIGluc3QgIT09IFN0eWxlOyB9KTtcbiAgICAgICAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3doZWVsJywgc2hvdWxkUHJldmVudCwgbm9uUGFzc2l2ZSk7XG4gICAgICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCd0b3VjaG1vdmUnLCBzaG91bGRQcmV2ZW50LCBub25QYXNzaXZlKTtcbiAgICAgICAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3RvdWNoc3RhcnQnLCBzY3JvbGxUb3VjaFN0YXJ0LCBub25QYXNzaXZlKTtcbiAgICAgICAgfTtcbiAgICB9LCBbXSk7XG4gICAgdmFyIHJlbW92ZVNjcm9sbEJhciA9IHByb3BzLnJlbW92ZVNjcm9sbEJhciwgaW5lcnQgPSBwcm9wcy5pbmVydDtcbiAgICByZXR1cm4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGwsXG4gICAgICAgIGluZXJ0ID8gUmVhY3QuY3JlYXRlRWxlbWVudChTdHlsZSwgeyBzdHlsZXM6IGdlbmVyYXRlU3R5bGUoaWQpIH0pIDogbnVsbCxcbiAgICAgICAgcmVtb3ZlU2Nyb2xsQmFyID8gUmVhY3QuY3JlYXRlRWxlbWVudChSZW1vdmVTY3JvbGxCYXIsIHsgbm9SZWxhdGl2ZTogcHJvcHMubm9SZWxhdGl2ZSwgZ2FwTW9kZTogcHJvcHMuZ2FwTW9kZSB9KSA6IG51bGwpKTtcbn1cbmZ1bmN0aW9uIGdldE91dGVybW9zdFNoYWRvd1BhcmVudChub2RlKSB7XG4gICAgdmFyIHNoYWRvd1BhcmVudCA9IG51bGw7XG4gICAgd2hpbGUgKG5vZGUgIT09IG51bGwpIHtcbiAgICAgICAgaWYgKG5vZGUgaW5zdGFuY2VvZiBTaGFkb3dSb290KSB7XG4gICAgICAgICAgICBzaGFkb3dQYXJlbnQgPSBub2RlLmhvc3Q7XG4gICAgICAgICAgICBub2RlID0gbm9kZS5ob3N0O1xuICAgICAgICB9XG4gICAgICAgIG5vZGUgPSBub2RlLnBhcmVudE5vZGU7XG4gICAgfVxuICAgIHJldHVybiBzaGFkb3dQYXJlbnQ7XG59XG4iLCJpbXBvcnQgeyBleHBvcnRTaWRlY2FyIH0gZnJvbSAndXNlLXNpZGVjYXInO1xuaW1wb3J0IHsgUmVtb3ZlU2Nyb2xsU2lkZUNhciB9IGZyb20gJy4vU2lkZUVmZmVjdCc7XG5pbXBvcnQgeyBlZmZlY3RDYXIgfSBmcm9tICcuL21lZGl1bSc7XG5leHBvcnQgZGVmYXVsdCBleHBvcnRTaWRlY2FyKGVmZmVjdENhciwgUmVtb3ZlU2Nyb2xsU2lkZUNhcik7XG4iLCJpbXBvcnQgeyBfX2Fzc2lnbiB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgUmVtb3ZlU2Nyb2xsIH0gZnJvbSAnLi9VSSc7XG5pbXBvcnQgU2lkZUNhciBmcm9tICcuL3NpZGVjYXInO1xudmFyIFJlYWN0UmVtb3ZlU2Nyb2xsID0gUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiAocHJvcHMsIHJlZikgeyByZXR1cm4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVtb3ZlU2Nyb2xsLCBfX2Fzc2lnbih7fSwgcHJvcHMsIHsgcmVmOiByZWYsIHNpZGVDYXI6IFNpZGVDYXIgfSkpKTsgfSk7XG5SZWFjdFJlbW92ZVNjcm9sbC5jbGFzc05hbWVzID0gUmVtb3ZlU2Nyb2xsLmNsYXNzTmFtZXM7XG5leHBvcnQgZGVmYXVsdCBSZWFjdFJlbW92ZVNjcm9sbDtcbiIsInZhciBnZXREZWZhdWx0UGFyZW50ID0gZnVuY3Rpb24gKG9yaWdpbmFsVGFyZ2V0KSB7XG4gICAgaWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHZhciBzYW1wbGVUYXJnZXQgPSBBcnJheS5pc0FycmF5KG9yaWdpbmFsVGFyZ2V0KSA/IG9yaWdpbmFsVGFyZ2V0WzBdIDogb3JpZ2luYWxUYXJnZXQ7XG4gICAgcmV0dXJuIHNhbXBsZVRhcmdldC5vd25lckRvY3VtZW50LmJvZHk7XG59O1xudmFyIGNvdW50ZXJNYXAgPSBuZXcgV2Vha01hcCgpO1xudmFyIHVuY29udHJvbGxlZE5vZGVzID0gbmV3IFdlYWtNYXAoKTtcbnZhciBtYXJrZXJNYXAgPSB7fTtcbnZhciBsb2NrQ291bnQgPSAwO1xudmFyIHVud3JhcEhvc3QgPSBmdW5jdGlvbiAobm9kZSkge1xuICAgIHJldHVybiBub2RlICYmIChub2RlLmhvc3QgfHwgdW53cmFwSG9zdChub2RlLnBhcmVudE5vZGUpKTtcbn07XG52YXIgY29ycmVjdFRhcmdldHMgPSBmdW5jdGlvbiAocGFyZW50LCB0YXJnZXRzKSB7XG4gICAgcmV0dXJuIHRhcmdldHNcbiAgICAgICAgLm1hcChmdW5jdGlvbiAodGFyZ2V0KSB7XG4gICAgICAgIGlmIChwYXJlbnQuY29udGFpbnModGFyZ2V0KSkge1xuICAgICAgICAgICAgcmV0dXJuIHRhcmdldDtcbiAgICAgICAgfVxuICAgICAgICB2YXIgY29ycmVjdGVkVGFyZ2V0ID0gdW53cmFwSG9zdCh0YXJnZXQpO1xuICAgICAgICBpZiAoY29ycmVjdGVkVGFyZ2V0ICYmIHBhcmVudC5jb250YWlucyhjb3JyZWN0ZWRUYXJnZXQpKSB7XG4gICAgICAgICAgICByZXR1cm4gY29ycmVjdGVkVGFyZ2V0O1xuICAgICAgICB9XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ2FyaWEtaGlkZGVuJywgdGFyZ2V0LCAnaW4gbm90IGNvbnRhaW5lZCBpbnNpZGUnLCBwYXJlbnQsICcuIERvaW5nIG5vdGhpbmcnKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfSlcbiAgICAgICAgLmZpbHRlcihmdW5jdGlvbiAoeCkgeyByZXR1cm4gQm9vbGVhbih4KTsgfSk7XG59O1xuLyoqXG4gKiBNYXJrcyBldmVyeXRoaW5nIGV4Y2VwdCBnaXZlbiBub2RlKG9yIG5vZGVzKSBhcyBhcmlhLWhpZGRlblxuICogQHBhcmFtIHtFbGVtZW50IHwgRWxlbWVudFtdfSBvcmlnaW5hbFRhcmdldCAtIGVsZW1lbnRzIHRvIGtlZXAgb24gdGhlIHBhZ2VcbiAqIEBwYXJhbSBbcGFyZW50Tm9kZV0gLSB0b3AgZWxlbWVudCwgZGVmYXVsdHMgdG8gZG9jdW1lbnQuYm9keVxuICogQHBhcmFtIHtTdHJpbmd9IFttYXJrZXJOYW1lXSAtIGEgc3BlY2lhbCBhdHRyaWJ1dGUgdG8gbWFyayBldmVyeSBub2RlXG4gKiBAcGFyYW0ge1N0cmluZ30gW2NvbnRyb2xBdHRyaWJ1dGVdIC0gaHRtbCBBdHRyaWJ1dGUgdG8gY29udHJvbFxuICogQHJldHVybiB7VW5kb30gdW5kbyBjb21tYW5kXG4gKi9cbnZhciBhcHBseUF0dHJpYnV0ZVRvT3RoZXJzID0gZnVuY3Rpb24gKG9yaWdpbmFsVGFyZ2V0LCBwYXJlbnROb2RlLCBtYXJrZXJOYW1lLCBjb250cm9sQXR0cmlidXRlKSB7XG4gICAgdmFyIHRhcmdldHMgPSBjb3JyZWN0VGFyZ2V0cyhwYXJlbnROb2RlLCBBcnJheS5pc0FycmF5KG9yaWdpbmFsVGFyZ2V0KSA/IG9yaWdpbmFsVGFyZ2V0IDogW29yaWdpbmFsVGFyZ2V0XSk7XG4gICAgaWYgKCFtYXJrZXJNYXBbbWFya2VyTmFtZV0pIHtcbiAgICAgICAgbWFya2VyTWFwW21hcmtlck5hbWVdID0gbmV3IFdlYWtNYXAoKTtcbiAgICB9XG4gICAgdmFyIG1hcmtlckNvdW50ZXIgPSBtYXJrZXJNYXBbbWFya2VyTmFtZV07XG4gICAgdmFyIGhpZGRlbk5vZGVzID0gW107XG4gICAgdmFyIGVsZW1lbnRzVG9LZWVwID0gbmV3IFNldCgpO1xuICAgIHZhciBlbGVtZW50c1RvU3RvcCA9IG5ldyBTZXQodGFyZ2V0cyk7XG4gICAgdmFyIGtlZXAgPSBmdW5jdGlvbiAoZWwpIHtcbiAgICAgICAgaWYgKCFlbCB8fCBlbGVtZW50c1RvS2VlcC5oYXMoZWwpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgZWxlbWVudHNUb0tlZXAuYWRkKGVsKTtcbiAgICAgICAga2VlcChlbC5wYXJlbnROb2RlKTtcbiAgICB9O1xuICAgIHRhcmdldHMuZm9yRWFjaChrZWVwKTtcbiAgICB2YXIgZGVlcCA9IGZ1bmN0aW9uIChwYXJlbnQpIHtcbiAgICAgICAgaWYgKCFwYXJlbnQgfHwgZWxlbWVudHNUb1N0b3AuaGFzKHBhcmVudCkpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBBcnJheS5wcm90b3R5cGUuZm9yRWFjaC5jYWxsKHBhcmVudC5jaGlsZHJlbiwgZnVuY3Rpb24gKG5vZGUpIHtcbiAgICAgICAgICAgIGlmIChlbGVtZW50c1RvS2VlcC5oYXMobm9kZSkpIHtcbiAgICAgICAgICAgICAgICBkZWVwKG5vZGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGF0dHIgPSBub2RlLmdldEF0dHJpYnV0ZShjb250cm9sQXR0cmlidXRlKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGFscmVhZHlIaWRkZW4gPSBhdHRyICE9PSBudWxsICYmIGF0dHIgIT09ICdmYWxzZSc7XG4gICAgICAgICAgICAgICAgICAgIHZhciBjb3VudGVyVmFsdWUgPSAoY291bnRlck1hcC5nZXQobm9kZSkgfHwgMCkgKyAxO1xuICAgICAgICAgICAgICAgICAgICB2YXIgbWFya2VyVmFsdWUgPSAobWFya2VyQ291bnRlci5nZXQobm9kZSkgfHwgMCkgKyAxO1xuICAgICAgICAgICAgICAgICAgICBjb3VudGVyTWFwLnNldChub2RlLCBjb3VudGVyVmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICBtYXJrZXJDb3VudGVyLnNldChub2RlLCBtYXJrZXJWYWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIGhpZGRlbk5vZGVzLnB1c2gobm9kZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb3VudGVyVmFsdWUgPT09IDEgJiYgYWxyZWFkeUhpZGRlbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgdW5jb250cm9sbGVkTm9kZXMuc2V0KG5vZGUsIHRydWUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChtYXJrZXJWYWx1ZSA9PT0gMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbm9kZS5zZXRBdHRyaWJ1dGUobWFya2VyTmFtZSwgJ3RydWUnKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoIWFscmVhZHlIaWRkZW4pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vZGUuc2V0QXR0cmlidXRlKGNvbnRyb2xBdHRyaWJ1dGUsICd0cnVlJyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignYXJpYS1oaWRkZW46IGNhbm5vdCBvcGVyYXRlIG9uICcsIG5vZGUsIGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBkZWVwKHBhcmVudE5vZGUpO1xuICAgIGVsZW1lbnRzVG9LZWVwLmNsZWFyKCk7XG4gICAgbG9ja0NvdW50Kys7XG4gICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaGlkZGVuTm9kZXMuZm9yRWFjaChmdW5jdGlvbiAobm9kZSkge1xuICAgICAgICAgICAgdmFyIGNvdW50ZXJWYWx1ZSA9IGNvdW50ZXJNYXAuZ2V0KG5vZGUpIC0gMTtcbiAgICAgICAgICAgIHZhciBtYXJrZXJWYWx1ZSA9IG1hcmtlckNvdW50ZXIuZ2V0KG5vZGUpIC0gMTtcbiAgICAgICAgICAgIGNvdW50ZXJNYXAuc2V0KG5vZGUsIGNvdW50ZXJWYWx1ZSk7XG4gICAgICAgICAgICBtYXJrZXJDb3VudGVyLnNldChub2RlLCBtYXJrZXJWYWx1ZSk7XG4gICAgICAgICAgICBpZiAoIWNvdW50ZXJWYWx1ZSkge1xuICAgICAgICAgICAgICAgIGlmICghdW5jb250cm9sbGVkTm9kZXMuaGFzKG5vZGUpKSB7XG4gICAgICAgICAgICAgICAgICAgIG5vZGUucmVtb3ZlQXR0cmlidXRlKGNvbnRyb2xBdHRyaWJ1dGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB1bmNvbnRyb2xsZWROb2Rlcy5kZWxldGUobm9kZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIW1hcmtlclZhbHVlKSB7XG4gICAgICAgICAgICAgICAgbm9kZS5yZW1vdmVBdHRyaWJ1dGUobWFya2VyTmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICBsb2NrQ291bnQtLTtcbiAgICAgICAgaWYgKCFsb2NrQ291bnQpIHtcbiAgICAgICAgICAgIC8vIGNsZWFyXG4gICAgICAgICAgICBjb3VudGVyTWFwID0gbmV3IFdlYWtNYXAoKTtcbiAgICAgICAgICAgIGNvdW50ZXJNYXAgPSBuZXcgV2Vha01hcCgpO1xuICAgICAgICAgICAgdW5jb250cm9sbGVkTm9kZXMgPSBuZXcgV2Vha01hcCgpO1xuICAgICAgICAgICAgbWFya2VyTWFwID0ge307XG4gICAgICAgIH1cbiAgICB9O1xufTtcbi8qKlxuICogTWFya3MgZXZlcnl0aGluZyBleGNlcHQgZ2l2ZW4gbm9kZShvciBub2RlcykgYXMgYXJpYS1oaWRkZW5cbiAqIEBwYXJhbSB7RWxlbWVudCB8IEVsZW1lbnRbXX0gb3JpZ2luYWxUYXJnZXQgLSBlbGVtZW50cyB0byBrZWVwIG9uIHRoZSBwYWdlXG4gKiBAcGFyYW0gW3BhcmVudE5vZGVdIC0gdG9wIGVsZW1lbnQsIGRlZmF1bHRzIHRvIGRvY3VtZW50LmJvZHlcbiAqIEBwYXJhbSB7U3RyaW5nfSBbbWFya2VyTmFtZV0gLSBhIHNwZWNpYWwgYXR0cmlidXRlIHRvIG1hcmsgZXZlcnkgbm9kZVxuICogQHJldHVybiB7VW5kb30gdW5kbyBjb21tYW5kXG4gKi9cbmV4cG9ydCB2YXIgaGlkZU90aGVycyA9IGZ1bmN0aW9uIChvcmlnaW5hbFRhcmdldCwgcGFyZW50Tm9kZSwgbWFya2VyTmFtZSkge1xuICAgIGlmIChtYXJrZXJOYW1lID09PSB2b2lkIDApIHsgbWFya2VyTmFtZSA9ICdkYXRhLWFyaWEtaGlkZGVuJzsgfVxuICAgIHZhciB0YXJnZXRzID0gQXJyYXkuZnJvbShBcnJheS5pc0FycmF5KG9yaWdpbmFsVGFyZ2V0KSA/IG9yaWdpbmFsVGFyZ2V0IDogW29yaWdpbmFsVGFyZ2V0XSk7XG4gICAgdmFyIGFjdGl2ZVBhcmVudE5vZGUgPSBwYXJlbnROb2RlIHx8IGdldERlZmF1bHRQYXJlbnQob3JpZ2luYWxUYXJnZXQpO1xuICAgIGlmICghYWN0aXZlUGFyZW50Tm9kZSkge1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gKCkgeyByZXR1cm4gbnVsbDsgfTtcbiAgICB9XG4gICAgLy8gd2Ugc2hvdWxkIG5vdCBoaWRlIGFyaWEtbGl2ZSBlbGVtZW50cyAtIGh0dHBzOi8vZ2l0aHViLmNvbS90aGVLYXNoZXkvYXJpYS1oaWRkZW4vaXNzdWVzLzEwXG4gICAgLy8gYW5kIHNjcmlwdCBlbGVtZW50cywgYXMgdGhleSBoYXZlIG5vIGltcGFjdCBvbiBhY2Nlc3NpYmlsaXR5LlxuICAgIHRhcmdldHMucHVzaC5hcHBseSh0YXJnZXRzLCBBcnJheS5mcm9tKGFjdGl2ZVBhcmVudE5vZGUucXVlcnlTZWxlY3RvckFsbCgnW2FyaWEtbGl2ZV0sIHNjcmlwdCcpKSk7XG4gICAgcmV0dXJuIGFwcGx5QXR0cmlidXRlVG9PdGhlcnModGFyZ2V0cywgYWN0aXZlUGFyZW50Tm9kZSwgbWFya2VyTmFtZSwgJ2FyaWEtaGlkZGVuJyk7XG59O1xuLyoqXG4gKiBNYXJrcyBldmVyeXRoaW5nIGV4Y2VwdCBnaXZlbiBub2RlKG9yIG5vZGVzKSBhcyBpbmVydFxuICogQHBhcmFtIHtFbGVtZW50IHwgRWxlbWVudFtdfSBvcmlnaW5hbFRhcmdldCAtIGVsZW1lbnRzIHRvIGtlZXAgb24gdGhlIHBhZ2VcbiAqIEBwYXJhbSBbcGFyZW50Tm9kZV0gLSB0b3AgZWxlbWVudCwgZGVmYXVsdHMgdG8gZG9jdW1lbnQuYm9keVxuICogQHBhcmFtIHtTdHJpbmd9IFttYXJrZXJOYW1lXSAtIGEgc3BlY2lhbCBhdHRyaWJ1dGUgdG8gbWFyayBldmVyeSBub2RlXG4gKiBAcmV0dXJuIHtVbmRvfSB1bmRvIGNvbW1hbmRcbiAqL1xuZXhwb3J0IHZhciBpbmVydE90aGVycyA9IGZ1bmN0aW9uIChvcmlnaW5hbFRhcmdldCwgcGFyZW50Tm9kZSwgbWFya2VyTmFtZSkge1xuICAgIGlmIChtYXJrZXJOYW1lID09PSB2b2lkIDApIHsgbWFya2VyTmFtZSA9ICdkYXRhLWluZXJ0LWVkJzsgfVxuICAgIHZhciBhY3RpdmVQYXJlbnROb2RlID0gcGFyZW50Tm9kZSB8fCBnZXREZWZhdWx0UGFyZW50KG9yaWdpbmFsVGFyZ2V0KTtcbiAgICBpZiAoIWFjdGl2ZVBhcmVudE5vZGUpIHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHsgcmV0dXJuIG51bGw7IH07XG4gICAgfVxuICAgIHJldHVybiBhcHBseUF0dHJpYnV0ZVRvT3RoZXJzKG9yaWdpbmFsVGFyZ2V0LCBhY3RpdmVQYXJlbnROb2RlLCBtYXJrZXJOYW1lLCAnaW5lcnQnKTtcbn07XG4vKipcbiAqIEByZXR1cm5zIGlmIGN1cnJlbnQgYnJvd3NlciBzdXBwb3J0cyBpbmVydFxuICovXG5leHBvcnQgdmFyIHN1cHBvcnRzSW5lcnQgPSBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIHR5cGVvZiBIVE1MRWxlbWVudCAhPT0gJ3VuZGVmaW5lZCcgJiYgSFRNTEVsZW1lbnQucHJvdG90eXBlLmhhc093blByb3BlcnR5KCdpbmVydCcpO1xufTtcbi8qKlxuICogQXV0b21hdGljIGZ1bmN0aW9uIHRvIFwic3VwcHJlc3NcIiBET00gZWxlbWVudHMgLSBfaGlkZV8gb3IgX2luZXJ0XyBpbiB0aGUgYmVzdCBwb3NzaWJsZSB3YXlcbiAqIEBwYXJhbSB7RWxlbWVudCB8IEVsZW1lbnRbXX0gb3JpZ2luYWxUYXJnZXQgLSBlbGVtZW50cyB0byBrZWVwIG9uIHRoZSBwYWdlXG4gKiBAcGFyYW0gW3BhcmVudE5vZGVdIC0gdG9wIGVsZW1lbnQsIGRlZmF1bHRzIHRvIGRvY3VtZW50LmJvZHlcbiAqIEBwYXJhbSB7U3RyaW5nfSBbbWFya2VyTmFtZV0gLSBhIHNwZWNpYWwgYXR0cmlidXRlIHRvIG1hcmsgZXZlcnkgbm9kZVxuICogQHJldHVybiB7VW5kb30gdW5kbyBjb21tYW5kXG4gKi9cbmV4cG9ydCB2YXIgc3VwcHJlc3NPdGhlcnMgPSBmdW5jdGlvbiAob3JpZ2luYWxUYXJnZXQsIHBhcmVudE5vZGUsIG1hcmtlck5hbWUpIHtcbiAgICBpZiAobWFya2VyTmFtZSA9PT0gdm9pZCAwKSB7IG1hcmtlck5hbWUgPSAnZGF0YS1zdXBwcmVzc2VkJzsgfVxuICAgIHJldHVybiAoc3VwcG9ydHNJbmVydCgpID8gaW5lcnRPdGhlcnMgOiBoaWRlT3RoZXJzKShvcmlnaW5hbFRhcmdldCwgcGFyZW50Tm9kZSwgbWFya2VyTmFtZSk7XG59O1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQ0EsSUFBSUEsY0FBWSxPQUFPO0FBQ3ZCLElBQUlDLFlBQVUsUUFBUSxVQUFVRCxZQUFVLFFBQVEsUUFBUTtDQUFFO0NBQU8sY0FBYztBQUFLLENBQUM7QUFTdkYsSUFBSSxpQkFBaUI7QUFDckIsSUFBSSx1QkFBdUI7QUFDM0IsSUFBSSxnQkFBZ0I7QUFDcEIsSUFBSTtBQUNKLElBQUksMEJBQUEsYUFBZ0MsY0FBYztDQUNoRCx3QkFBd0IsSUFBSSxJQUFJO0NBQ2hDLHdEQUF3RCxJQUFJLElBQUk7Q0FDaEUsMEJBQTBCLElBQUksSUFBSTtDQU1sQyxxQ0FBcUMsSUFBSSxJQUFJO0FBQy9DLENBQUM7QUFDRCxJQUFJLG1CQUFtQyw2QkFBTSxXQUUzQix5QkFBTyxTQUFTLGtCQUFrQixPQUFPLGNBQWM7Q0FDckUsTUFBTSxFQUNKLDhCQUE4QixPQUM5QiwwQkFBMEIsT0FDMUIsaUJBQ0Esc0JBQ0EsZ0JBQ0EsbUJBQ0EsV0FDQSxHQUFHLGVBQ0Q7Q0FDSixNQUFNLFVBQUEsYUFBZ0IsV0FBVyx1QkFBdUI7Q0FDeEQsTUFBTSxDQUFDLE1BQU0sV0FBQSxhQUFpQixTQUFTLElBQUk7Q0FDM0MsTUFBTSxnQkFBZ0IsTUFBTSxpQkFBaUIsWUFBWTtDQUN6RCxNQUFNLEdBQUcsU0FBQSxhQUFlLFNBQVMsQ0FBQyxDQUFDO0NBQ25DLE1BQU0sZUFBZSxnQkFBZ0IsY0FBYyxPQUFPO0NBQzFELE1BQU0sU0FBUyxNQUFNLEtBQUssUUFBUSxNQUFNO0NBQ3hDLE1BQU0sQ0FBQyxnREFBZ0QsQ0FDckQsR0FBRyxRQUFRLHNDQUNiLENBQUMsQ0FBQyxNQUFNLEVBQUU7Q0FDVixNQUFNLG9EQUFvRCwrQ0FBK0MsT0FBTyxRQUFRLDRDQUE0QyxJQUFJO0NBQ3hLLE1BQU0sUUFBUSxPQUFPLE9BQU8sUUFBUSxJQUFJLElBQUk7Q0FDNUMsTUFBTSw4QkFBOEIsUUFBUSx1Q0FBdUMsT0FBTztDQUMxRixNQUFNLHlCQUF5QixTQUFTO0NBQ3hDLE1BQU0sa0NBQUEsYUFBd0MsT0FBTyxLQUFLO0NBQzFELE1BQU0scUJBQXFCLHVCQUN4QixVQUFVO0VBQ1QsdUJBQXVCLEtBQUs7RUFDNUIsb0JBQW9CLEtBQUs7RUFDekIsSUFBSSxDQUFDLE1BQU0sa0JBQWtCLFlBQVk7Q0FDM0MsR0FDQTtFQUNFO0VBQ0E7RUFDQTtFQUNBLHFCQUFxQixRQUFRO0VBQzdCLGdDQUFBLGFBQXNDLGFBQ25DLFdBQVc7R0FDVixJQUFJLEVBQUUsa0JBQWtCLE9BQ3RCLE9BQU87R0FFVCxNQUFNLHdCQUF3QixDQUFDLEdBQUcsUUFBUSxRQUFRLENBQUMsQ0FBQyxNQUNqRCxXQUFXLE9BQU8sU0FBUyxNQUFNLENBQ3BDO0dBQ0EsT0FBTywwQkFBMEIsQ0FBQztFQUNwQyxHQUNBLENBQUMsUUFBUSxVQUFVLHNCQUFzQixDQUMzQztDQUNGLENBQ0Y7Q0FDQSxNQUFNLGVBQWUsaUJBQWlCLFVBQVU7RUFDOUMsSUFBSSwyQkFBMkIsZ0NBQWdDLFNBQzdEO0VBRUYsTUFBTSxTQUFTLE1BQU07RUFFckIsSUFEd0IsQ0FBQyxHQUFHLFFBQVEsUUFBUSxDQUFDLENBQUMsTUFBTSxXQUFXLE9BQU8sU0FBUyxNQUFNLENBQ25FLEdBQUc7RUFDckIsaUJBQWlCLEtBQUs7RUFDdEIsb0JBQW9CLEtBQUs7RUFDekIsSUFBSSxDQUFDLE1BQU0sa0JBQWtCLFlBQVk7Q0FDM0MsR0FBRyxhQUFhO0NBQ2hCLE1BQU0saUJBQWlCLE9BQU8sVUFBVSxPQUFPLFNBQVMsSUFBSTtDQUM1RCxNQUFNLGdCQUFnQkUsa0JBQWdCLFVBQVU7RUFDOUMsSUFBSSxNQUFNLFFBQVEsVUFDaEI7RUFFRixrQkFBa0IsS0FBSztFQUN2QixJQUFJLENBQUMsTUFBTSxvQkFBb0IsV0FBVztHQUN4QyxNQUFNLGVBQWU7R0FDckIsVUFBVTtFQUNaO0NBQ0YsQ0FBQztDQUNELGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksQ0FBQyxnQkFDSDtFQUVGLGNBQWMsaUJBQWlCLFdBQVcsZUFBZSxFQUFFLFNBQVMsS0FBSyxDQUFDO0VBQzFFLGFBQWEsY0FBYyxvQkFBb0IsV0FBVyxlQUFlLEVBQUUsU0FBUyxLQUFLLENBQUM7Q0FDNUYsR0FBRztFQUFDO0VBQWU7RUFBZ0I7Q0FBYSxDQUFDO0NBQ2pELGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksQ0FBQyxNQUFNO0VBQ1gsSUFBSSw2QkFBNkI7R0FDL0IsSUFBSSxRQUFRLHVDQUF1QyxTQUFTLEdBQUc7SUFDN0QsNEJBQTRCLGNBQWMsS0FBSyxNQUFNO0lBQ3JELGNBQWMsS0FBSyxNQUFNLGdCQUFnQjtHQUMzQztHQUNBLFFBQVEsdUNBQXVDLElBQUksSUFBSTtFQUN6RDtFQUNBLFFBQVEsT0FBTyxJQUFJLElBQUk7RUFDdkIsZUFBZTtFQUNmLGFBQWE7R0FDWCxJQUFJLDZCQUE2QjtJQUMvQixRQUFRLHVDQUF1QyxPQUFPLElBQUk7SUFDMUQsSUFBSSxRQUFRLHVDQUF1QyxTQUFTLEdBQzFELGNBQWMsS0FBSyxNQUFNLGdCQUFnQjtHQUU3QztFQUNGO0NBQ0YsR0FBRztFQUFDO0VBQU07RUFBZTtFQUE2QjtDQUFPLENBQUM7Q0FDOUQsYUFBTSxnQkFBZ0I7RUFDcEIsYUFBYTtHQUNYLElBQUksQ0FBQyxNQUFNO0dBQ1gsUUFBUSxPQUFPLE9BQU8sSUFBSTtHQUMxQixRQUFRLHVDQUF1QyxPQUFPLElBQUk7R0FDMUQsZUFBZTtFQUNqQjtDQUNGLEdBQUcsQ0FBQyxNQUFNLE9BQU8sQ0FBQztDQUNsQixhQUFNLGdCQUFnQjtFQUNwQixNQUFNLGVBQStCLCtCQUFhLE1BQU0sQ0FBQyxDQUFDLEdBQUcsY0FBYztFQUMzRSxTQUFTLGlCQUFpQixnQkFBZ0IsWUFBWTtFQUN0RCxhQUFhLFNBQVMsb0JBQW9CLGdCQUFnQixZQUFZO0NBQ3hFLEdBQUcsQ0FBQyxDQUFDO0NBQ0wsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ3JCLFVBQVUsS0FDVjtFQUNFLEdBQUc7RUFDSCxLQUFLO0VBQ0wsT0FBTztHQUNMLGVBQWUsOEJBQThCLHlCQUF5QixTQUFTLFNBQVMsS0FBSztHQUM3RixHQUFHLE1BQU07RUFDWDtFQUNBLGdCQUFnQixxQkFBcUIsTUFBTSxnQkFBZ0IsYUFBYSxjQUFjO0VBQ3RGLGVBQWUscUJBQXFCLE1BQU0sZUFBZSxhQUFhLGFBQWE7RUFDbkYsc0JBQXNCLHFCQUNwQixNQUFNLHNCQUNOLG1CQUFtQixvQkFDckI7Q0FDRixDQUNGO0FBQ0YsR0FBRyxrQkFBa0IsQ0FDdkI7QUFnQkEsU0FBUyw2QkFBNkI7Q0FDcEMsTUFBTSxVQUFBLGFBQWdCLFdBQVcsdUJBQXVCO0NBQ3hELE1BQU0sQ0FBQyxNQUFNLFdBQUEsYUFBaUIsU0FBUyxJQUFJO0NBQzNDLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksQ0FBQyxNQUNIO0VBRUYsUUFBUSxvQkFBb0IsSUFBSSxJQUFJO0VBQ3BDLGFBQWE7R0FDWCxRQUFRLG9CQUFvQixPQUFPLElBQUk7RUFDekM7Q0FDRixHQUFHLENBQUMsTUFBTSxRQUFRLG1CQUFtQixDQUFDO0NBQ3RDLE9BQU87QUFDVDtBQUNBRCxTQUFPLDRCQUE0Qiw0QkFBNEI7QUFDL0QsSUFBSSxVQUEwQiwrQkFBYSxNQUFNLFNBQVM7QUFDMUQsU0FBUyxzQkFBc0Isc0JBQXNCLE1BQU07Q0FDekQsTUFBTSxFQUNKLGdCQUFnQixZQUFZLFVBQzVCLDBCQUEwQixPQUMxQixpQ0FDQSxxQkFDQSxpQ0FBaUMsWUFDL0I7Q0FDSixNQUFNLDJCQUEyQkMsaUJBQWUsb0JBQW9CO0NBQ3BFLE1BQU0sOEJBQUEsYUFBb0MsT0FBTyxLQUFLO0NBQ3RELE1BQU0sMEJBQUEsYUFBZ0MsT0FBTyxLQUFLO0NBQ2xELE1BQU0seUNBQUEsYUFBK0MsdUJBQXVCLElBQUksSUFBSSxDQUFDO0NBQ3JGLE1BQU0saUJBQUEsYUFBdUIsYUFBYSxDQUMxQyxDQUFDO0NBQ0QsYUFBTSxnQkFBZ0I7RUFDcEIsU0FBUywwQkFBMEI7R0FDakMsd0JBQXdCLFVBQVU7R0FDbEMsZ0NBQWdDLFVBQVU7R0FDMUMsdUNBQXVDLFFBQVEsTUFBTTtFQUN2RDtFQUNBLFNBQU8seUJBQXlCLHlCQUF5QjtFQUN6RCxTQUFTLGtDQUFrQztHQUN6QyxPQUFPLE1BQU0sS0FBSyx1Q0FBdUMsUUFBUSxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTztFQUN6RjtFQUNBLFNBQU8saUNBQWlDLGlDQUFpQztFQUN6RSxTQUFTLHlCQUF5QixPQUFPO0dBQ3ZDLElBQUksQ0FBQyx3QkFBd0IsU0FDM0I7R0FFRixNQUFNLFNBQVMsTUFBTTtHQUVyQixJQUFJLEVBRHlCLGtCQUFrQixRQUFRLENBQUMsR0FBRyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU0sWUFBWSxRQUFRLFNBQVMsTUFBTSxDQUFDLElBRXhILHVDQUF1QyxRQUFRLElBQUksTUFBTSxNQUFNLElBQUk7R0FFckUsSUFBSSxNQUFNLFNBQVMsU0FDakIsT0FBTyxpQkFBaUI7SUFDdEIsSUFBSSx3QkFBd0IsU0FDMUIsZUFBZSxRQUFRO0dBRTNCLEdBQUcsQ0FBQztFQUVSO0VBQ0EsU0FBTywwQkFBMEIsMEJBQTBCO0VBQzNELFNBQVMsd0JBQXdCLE9BQU87R0FDdEMsSUFBSSx3QkFBd0IsU0FDMUIsdUNBQXVDLFFBQVEsSUFBSSxNQUFNLE1BQU0sS0FBSztFQUV4RTtFQUNBLFNBQU8seUJBQXlCLHlCQUF5QjtFQUN6RCxNQUFNLG9CQUFvQywwQkFBUSxVQUFVO0dBQzFELElBQUksTUFBTSxVQUFVLENBQUMsNEJBQTRCLFNBQVM7SUFDeEQsSUFBSSw0Q0FBNEMsV0FBVztLQUN6RCxjQUFjLG9CQUFvQixTQUFTLGVBQWUsT0FBTztLQUNqRSxNQUFNLG1DQUFtQyxnQ0FBZ0M7S0FDekUsd0JBQXdCO0tBQ3hCLElBQUksQ0FBQyxrQ0FDSCw2QkFDRSxzQkFDQSwwQkFDQSxhQUNBLEVBQUUsVUFBVSxLQUFLLENBQ25CO0lBRUo7SUFFQSxTQUFPLDJDQUEyQywwQ0FBMEM7SUFDNUYsSUFBSSxDQUFDLCtCQUErQixNQUFNLE1BQU0sR0FBRztLQUNqRCxjQUFjLG9CQUFvQixTQUFTLGVBQWUsT0FBTztLQUNqRSx3QkFBd0I7S0FDeEIsNEJBQTRCLFVBQVU7S0FDdEM7SUFDRjtJQUNBLE1BQU0sY0FBYyxFQUFFLGVBQWUsTUFBTTtJQUMzQyx3QkFBd0IsVUFBVTtJQUNsQyxnQ0FBZ0MsVUFBVSwyQkFBMkIsTUFBTSxXQUFXO0lBQ3RGLHVDQUF1QyxRQUFRLE1BQU07SUFDckQsSUFBSSxDQUFDLDJCQUEyQixNQUFNLFdBQVcsR0FDL0MsMENBQTBDO1NBQ3JDO0tBQ0wsY0FBYyxvQkFBb0IsU0FBUyxlQUFlLE9BQU87S0FDakUsZUFBZSxVQUFVO0tBQ3pCLGNBQWMsaUJBQWlCLFNBQVMsZUFBZSxTQUFTLEVBQUUsTUFBTSxLQUFLLENBQUM7SUFDaEY7R0FDRixPQUFPO0lBQ0wsY0FBYyxvQkFBb0IsU0FBUyxlQUFlLE9BQU87SUFDakUsd0JBQXdCO0dBQzFCO0dBQ0EsNEJBQTRCLFVBQVU7RUFDeEMsR0FBRyxtQkFBbUI7RUFDdEIsTUFBTSwyQkFBMkI7R0FDL0I7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7RUFDQSxLQUFLLE1BQU0sYUFBYSwwQkFBMEI7R0FDaEQsY0FBYyxpQkFBaUIsV0FBVywwQkFBMEIsSUFBSTtHQUN4RSxjQUFjLGlCQUFpQixXQUFXLHVCQUF1QjtFQUNuRTtFQUNBLE1BQU0sVUFBVSxPQUFPLGlCQUFpQjtHQUN0QyxjQUFjLGlCQUFpQixlQUFlLGlCQUFpQjtFQUNqRSxHQUFHLENBQUM7RUFDSixhQUFhO0dBQ1gsT0FBTyxhQUFhLE9BQU87R0FDM0IsY0FBYyxvQkFBb0IsZUFBZSxpQkFBaUI7R0FDbEUsY0FBYyxvQkFBb0IsU0FBUyxlQUFlLE9BQU87R0FDakUsS0FBSyxNQUFNLGFBQWEsMEJBQTBCO0lBQ2hELGNBQWMsb0JBQW9CLFdBQVcsMEJBQTBCLElBQUk7SUFDM0UsY0FBYyxvQkFBb0IsV0FBVyx1QkFBdUI7R0FDdEU7RUFDRjtDQUNGLEdBQUc7RUFDRDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRixDQUFDO0NBQ0QsT0FBTyxFQUVMLHNCQUFzQywrQkFBYSw0QkFBNEIsVUFBVSxNQUFNLHNCQUFzQixFQUN2SDtBQUNGO0FBQ0FELFNBQU8sdUJBQXVCLHVCQUF1QjtBQUNyRCxTQUFTLGdCQUFnQixnQkFBZ0IsZ0JBQWdCLFlBQVksVUFBVTtDQUM3RSxNQUFNLHFCQUFxQkMsaUJBQWUsY0FBYztDQUN4RCxNQUFNLDRCQUFBLGFBQWtDLE9BQU8sS0FBSztDQUNwRCxhQUFNLGdCQUFnQjtFQUNwQixNQUFNLGNBQThCLDBCQUFRLFVBQVU7R0FDcEQsSUFBSSxNQUFNLFVBQVUsQ0FBQywwQkFBMEIsU0FFN0MsNkJBQTZCLGVBQWUsb0JBQW9CLEVBRDFDLGVBQWUsTUFDcUMsR0FBRyxFQUMzRSxVQUFVLE1BQ1osQ0FBQztFQUVMLEdBQUcsYUFBYTtFQUNoQixjQUFjLGlCQUFpQixXQUFXLFdBQVc7RUFDckQsYUFBYSxjQUFjLG9CQUFvQixXQUFXLFdBQVc7Q0FDdkUsR0FBRyxDQUFDLGVBQWUsa0JBQWtCLENBQUM7Q0FDdEMsT0FBTztFQUNMLGdCQUFnQywrQkFBYSwwQkFBMEIsVUFBVSxNQUFNLGdCQUFnQjtFQUN2RyxlQUErQiwrQkFBYSwwQkFBMEIsVUFBVSxPQUFPLGVBQWU7Q0FDeEc7QUFDRjtBQUNBRCxTQUFPLGlCQUFpQixpQkFBaUI7QUFDekMsU0FBUyxpQkFBaUI7Q0FDeEIsTUFBTSxRQUFRLElBQUksWUFBWSxjQUFjO0NBQzVDLFNBQVMsY0FBYyxLQUFLO0FBQzlCO0FBQ0FBLFNBQU8sZ0JBQWdCLGdCQUFnQjtBQUN2QyxTQUFTLDZCQUE2QixNQUFNLFNBQVMsUUFBUSxFQUFFLFlBQVk7Q0FDekUsTUFBTSxTQUFTLE9BQU8sY0FBYztDQUNwQyxNQUFNLFFBQVEsSUFBSSxZQUFZLE1BQU07RUFBRSxTQUFTO0VBQU8sWUFBWTtFQUFNO0NBQU8sQ0FBQztDQUNoRixJQUFJLFNBQVMsT0FBTyxpQkFBaUIsTUFBTSxTQUFTLEVBQUUsTUFBTSxLQUFLLENBQUM7Q0FDbEUsSUFBSSxVQUNGLDRCQUE0QixRQUFRLEtBQUs7TUFFekMsT0FBTyxjQUFjLEtBQUs7QUFFOUI7QUFDQUEsU0FBTyw4QkFBOEIsOEJBQThCOzs7QUNoV25FLElBQUlFLGNBQVksT0FBTztBQUN2QixJQUFJQyxZQUFVLFFBQVEsVUFBVUQsWUFBVSxRQUFRLFFBQVE7Q0FBRTtDQUFPLGNBQWM7QUFBSyxDQUFDO0FBUXZGLElBQUkscUJBQXFCO0FBQ3pCLElBQUksdUJBQXVCO0FBQzNCLElBQUksZ0JBQWdCO0NBQUUsU0FBUztDQUFPLFlBQVk7QUFBSztBQUN2RCxJQUFJLGFBQTZCLDZCQUFNLFdBQ3JCLHlCQUFPLFNBQVMsWUFBWSxPQUFPLGNBQWM7Q0FDL0QsTUFBTSxFQUNKLE9BQU8sT0FDUCxVQUFVLE9BQ1Ysa0JBQWtCLHNCQUNsQixvQkFBb0Isd0JBQ3BCLEdBQUcsZUFDRDtDQUNKLE1BQU0sQ0FBQyxXQUFXLGdCQUFBLGFBQXNCLFNBQVMsSUFBSTtDQUNyRCxNQUFNLG1CQUFtQkUsaUJBQWUsb0JBQW9CO0NBQzVELE1BQU0scUJBQXFCQSxpQkFBZSxzQkFBc0I7Q0FDaEUsTUFBTSx3QkFBQSxhQUE4QixPQUFPLElBQUk7Q0FDL0MsTUFBTSxlQUFlLGdCQUFnQixjQUFjLFlBQVk7Q0FDL0QsTUFBTSxhQUFBLGFBQW1CLE9BQU87RUFDOUIsUUFBUTtFQUNSLFFBQVE7R0FDTixLQUFLLFNBQVM7RUFDaEI7RUFDQSxTQUFTO0dBQ1AsS0FBSyxTQUFTO0VBQ2hCO0NBQ0YsQ0FBQyxDQUFDLENBQUM7Q0FDSCxhQUFNLGdCQUFnQjtFQUNwQixJQUFJLFNBQVM7R0FDWCxJQUFJLGlCQUFpQixTQUFTLE9BQU87SUFDbkMsSUFBSSxXQUFXLFVBQVUsQ0FBQyxXQUFXO0lBQ3JDLE1BQU0sU0FBUyxNQUFNO0lBQ3JCLElBQUksVUFBVSxTQUFTLE1BQU0sR0FDM0Isc0JBQXNCLFVBQVU7U0FFaEMsTUFBTSxzQkFBc0IsU0FBUyxFQUFFLFFBQVEsS0FBSyxDQUFDO0dBRXpELEdBQUcsa0JBQWtCLFNBQVMsT0FBTztJQUNuQyxJQUFJLFdBQVcsVUFBVSxDQUFDLFdBQVc7SUFDckMsTUFBTSxnQkFBZ0IsTUFBTTtJQUM1QixJQUFJLGtCQUFrQixNQUFNO0lBQzVCLElBQUksQ0FBQyxVQUFVLFNBQVMsYUFBYSxHQUNuQyxNQUFNLHNCQUFzQixTQUFTLEVBQUUsUUFBUSxLQUFLLENBQUM7R0FFekQsR0FBRyxtQkFBbUIsU0FBUyxXQUFXO0lBRXhDLElBRHVCLFNBQVMsa0JBQ1QsU0FBUyxNQUFNO0lBQ3RDLEtBQUssTUFBTSxZQUFZLFdBQ3JCLElBQUksU0FBUyxhQUFhLFNBQVMsR0FBRyxNQUFNLFNBQVM7R0FFekQ7R0FFQSxTQUFPLGdCQUFnQixlQUFlO0dBQ3RDLFNBQU8saUJBQWlCLGdCQUFnQjtHQUN4QyxTQUFPLGtCQUFrQixpQkFBaUI7R0FDMUMsU0FBUyxpQkFBaUIsV0FBVyxjQUFjO0dBQ25ELFNBQVMsaUJBQWlCLFlBQVksZUFBZTtHQUNyRCxNQUFNLG1CQUFtQixJQUFJLGlCQUFpQixnQkFBZ0I7R0FDOUQsSUFBSSxXQUFXLGlCQUFpQixRQUFRLFdBQVc7SUFBRSxXQUFXO0lBQU0sU0FBUztHQUFLLENBQUM7R0FDckYsYUFBYTtJQUNYLFNBQVMsb0JBQW9CLFdBQVcsY0FBYztJQUN0RCxTQUFTLG9CQUFvQixZQUFZLGVBQWU7SUFDeEQsaUJBQWlCLFdBQVc7R0FDOUI7RUFDRjtDQUNGLEdBQUc7RUFBQztFQUFTO0VBQVcsV0FBVztDQUFNLENBQUM7Q0FDMUMsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxXQUFXO0dBQ2IsaUJBQWlCLElBQUksVUFBVTtHQUMvQixNQUFNLDJCQUEyQixTQUFTO0dBRTFDLElBQUksQ0FEd0IsVUFBVSxTQUFTLHdCQUN4QixHQUFHO0lBQ3hCLE1BQU0sYUFBYSxJQUFJLFlBQVksb0JBQW9CLGFBQWE7SUFDcEUsVUFBVSxpQkFBaUIsb0JBQW9CLGdCQUFnQjtJQUMvRCxVQUFVLGNBQWMsVUFBVTtJQUNsQyxJQUFJLENBQUMsV0FBVyxrQkFBa0I7S0FDaEMsV0FBVyxZQUFZLHNCQUFzQixTQUFTLENBQUMsR0FBRyxFQUFFLFFBQVEsS0FBSyxDQUFDO0tBQzFFLElBQUksU0FBUyxrQkFBa0IsMEJBQzdCLE1BQU0sU0FBUztJQUVuQjtHQUNGO0dBQ0EsYUFBYTtJQUNYLFVBQVUsb0JBQW9CLG9CQUFvQixnQkFBZ0I7SUFDbEUsaUJBQWlCO0tBQ2YsTUFBTSxlQUFlLElBQUksWUFBWSxzQkFBc0IsYUFBYTtLQUN4RSxVQUFVLGlCQUFpQixzQkFBc0Isa0JBQWtCO0tBQ25FLFVBQVUsY0FBYyxZQUFZO0tBQ3BDLElBQUksQ0FBQyxhQUFhLGtCQUNoQixNQUFNLDRCQUE0QixTQUFTLE1BQU0sRUFBRSxRQUFRLEtBQUssQ0FBQztLQUVuRSxVQUFVLG9CQUFvQixzQkFBc0Isa0JBQWtCO0tBQ3RFLGlCQUFpQixPQUFPLFVBQVU7SUFDcEMsR0FBRyxDQUFDO0dBQ047RUFDRjtDQUNGLEdBQUc7RUFBQztFQUFXO0VBQWtCO0VBQW9CO0NBQVUsQ0FBQztDQUNoRSxNQUFNLGdCQUFBLGFBQXNCLGFBQ3pCLFVBQVU7RUFDVCxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVM7RUFDdkIsSUFBSSxXQUFXLFFBQVE7RUFDdkIsTUFBTSxXQUFXLE1BQU0sUUFBUSxTQUFTLENBQUMsTUFBTSxVQUFVLENBQUMsTUFBTSxXQUFXLENBQUMsTUFBTTtFQUNsRixNQUFNLGlCQUFpQixTQUFTO0VBQ2hDLElBQUksWUFBWSxnQkFBZ0I7R0FDOUIsTUFBTSxhQUFhLE1BQU07R0FDekIsTUFBTSxDQUFDLE9BQU8sUUFBUSxpQkFBaUIsVUFBVTtHQUVqRCxJQUFJLEVBRDhCLFNBQVMsT0FFckM7UUFBQSxtQkFBbUIsWUFBWSxNQUFNLGVBQWU7R0FBQSxPQUV4RCxJQUFJLENBQUMsTUFBTSxZQUFZLG1CQUFtQixNQUFNO0lBQzlDLE1BQU0sZUFBZTtJQUNyQixJQUFJLE1BQU0sTUFBTSxPQUFPLEVBQUUsUUFBUSxLQUFLLENBQUM7R0FDekMsT0FBTyxJQUFJLE1BQU0sWUFBWSxtQkFBbUIsT0FBTztJQUNyRCxNQUFNLGVBQWU7SUFDckIsSUFBSSxNQUFNLE1BQU0sTUFBTSxFQUFFLFFBQVEsS0FBSyxDQUFDO0dBQ3hDO0VBRUo7Q0FDRixHQUNBO0VBQUM7RUFBTTtFQUFTLFdBQVc7Q0FBTSxDQUNuQztDQUNBLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFVBQVUsS0FBSztFQUFFLFVBQVU7RUFBSSxHQUFHO0VBQVksS0FBSztFQUFjLFdBQVc7Q0FBYyxDQUFDO0FBQ3hILEdBQUcsWUFBWSxDQUNqQjtBQUNBLFNBQVMsV0FBVyxZQUFZLEVBQUUsU0FBUyxVQUFVLENBQUMsR0FBRztDQUN2RCxNQUFNLDJCQUEyQixTQUFTO0NBQzFDLEtBQUssTUFBTSxhQUFhLFlBQVk7RUFDbEMsTUFBTSxXQUFXLEVBQUUsT0FBTyxDQUFDO0VBQzNCLElBQUksU0FBUyxrQkFBa0IsMEJBQTBCO0NBQzNEO0FBQ0Y7QUFDQUQsU0FBTyxZQUFZLFlBQVk7QUFDL0IsU0FBUyxpQkFBaUIsV0FBVztDQUNuQyxNQUFNLGFBQWEsc0JBQXNCLFNBQVM7Q0FHbEQsT0FBTyxDQUZPLFlBQVksWUFBWSxTQUUxQixHQURDLFlBQVksV0FBVyxRQUFRLEdBQUcsU0FDN0IsQ0FBQztBQUNyQjtBQUNBQSxTQUFPLGtCQUFrQixrQkFBa0I7QUFDM0MsU0FBUyxzQkFBc0IsV0FBVztDQUN4QyxNQUFNLFFBQVEsQ0FBQztDQUNmLE1BQU0sU0FBUyxTQUFTLGlCQUFpQixXQUFXLFdBQVcsY0FBYyxFQUMzRSxZQUE0QiwwQkFBUSxTQUFTO0VBQzNDLE1BQU0sZ0JBQWdCLEtBQUssWUFBWSxXQUFXLEtBQUssU0FBUztFQUNoRSxJQUFJLEtBQUssWUFBWSxLQUFLLFVBQVUsZUFBZSxPQUFPLFdBQVc7RUFDckUsT0FBTyxLQUFLLFlBQVksSUFBSSxXQUFXLGdCQUFnQixXQUFXO0NBQ3BFLEdBQUcsWUFBWSxFQUNqQixDQUFDO0NBQ0QsT0FBTyxPQUFPLFNBQVMsR0FBRyxNQUFNLEtBQUssT0FBTyxXQUFXO0NBQ3ZELE9BQU87QUFDVDtBQUNBQSxTQUFPLHVCQUF1Qix1QkFBdUI7QUFDckQsU0FBUyxZQUFZLFVBQVUsV0FBVztDQUN4QyxNQUFNLHdCQUF3QixPQUFPLFVBQVUsb0JBQW9CLGNBQWMsVUFBVSxnQkFBZ0IsRUFBRSxvQkFBb0IsS0FBSyxDQUFDO0NBQ3ZJLEtBQUssTUFBTSxXQUFXLFVBRXBCLElBQUksRUFEVyx3QkFBd0IsQ0FBQyxRQUFRLGdCQUFnQixFQUFFLG9CQUFvQixLQUFLLENBQUMsSUFBSSxTQUFTLFNBQVMsRUFBRSxNQUFNLFVBQVUsQ0FBQyxJQUVuSSxPQUFPO0FBR2I7QUFDQUEsU0FBTyxhQUFhLGFBQWE7QUFDakMsU0FBUyxTQUFTLE1BQU0sRUFBRSxRQUFRO0NBQ2hDLElBQUksaUJBQWlCLElBQUksQ0FBQyxDQUFDLGVBQWUsVUFBVSxPQUFPO0NBQzNELE9BQU8sTUFBTTtFQUNYLElBQUksU0FBUyxLQUFLLEtBQUssU0FBUyxNQUFNLE9BQU87RUFDN0MsSUFBSSxpQkFBaUIsSUFBSSxDQUFDLENBQUMsWUFBWSxRQUFRLE9BQU87RUFDdEQsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxPQUFPO0FBQ1Q7QUFDQUEsU0FBTyxVQUFVLFVBQVU7QUFDM0IsU0FBUyxrQkFBa0IsU0FBUztDQUNsQyxPQUFPLG1CQUFtQixvQkFBb0IsWUFBWTtBQUM1RDtBQUNBQSxTQUFPLG1CQUFtQixtQkFBbUI7QUFDN0MsU0FBUyxNQUFNLFNBQVMsRUFBRSxTQUFTLFVBQVUsQ0FBQyxHQUFHO0NBQy9DLElBQUksV0FBVyxRQUFRLE9BQU87RUFDNUIsTUFBTSwyQkFBMkIsU0FBUztFQUMxQyxRQUFRLE1BQU0sRUFBRSxlQUFlLEtBQUssQ0FBQztFQUNyQyxJQUFJLFlBQVksNEJBQTRCLGtCQUFrQixPQUFPLEtBQUssUUFDeEUsUUFBUSxPQUFPO0NBQ25CO0FBQ0Y7QUFDQUEsU0FBTyxPQUFPLE9BQU87QUFDckIsSUFBSSxtQkFBbUIsdUJBQXVCO0FBQzlDLFNBQVMseUJBQXlCO0NBQ2hDLElBQUksUUFBUSxDQUFDO0NBQ2IsT0FBTztFQUNMLElBQUksWUFBWTtHQUNkLE1BQU0sbUJBQW1CLE1BQU07R0FDL0IsSUFBSSxlQUFlLGtCQUNqQixrQkFBa0IsTUFBTTtHQUUxQixRQUFRLFlBQVksT0FBTyxVQUFVO0dBQ3JDLE1BQU0sUUFBUSxVQUFVO0VBQzFCO0VBQ0EsT0FBTyxZQUFZO0dBQ2pCLFFBQVEsWUFBWSxPQUFPLFVBQVU7R0FDckMsTUFBTSxFQUFFLEVBQUUsT0FBTztFQUNuQjtDQUNGO0FBQ0Y7QUFDQUEsU0FBTyx3QkFBd0Isd0JBQXdCO0FBQ3ZELFNBQVMsWUFBWSxPQUFPLE1BQU07Q0FDaEMsTUFBTSxlQUFlLENBQUMsR0FBRyxLQUFLO0NBQzlCLE1BQU0sUUFBUSxhQUFhLFFBQVEsSUFBSTtDQUN2QyxJQUFJLFVBQVUsSUFDWixhQUFhLE9BQU8sT0FBTyxDQUFDO0NBRTlCLE9BQU87QUFDVDtBQUNBQSxTQUFPLGFBQWEsYUFBYTtBQUNqQyxTQUFTLFlBQVksT0FBTztDQUMxQixPQUFPLE1BQU0sUUFBUSxTQUFTLEtBQUssWUFBWSxHQUFHO0FBQ3BEO0FBQ0FBLFNBQU8sYUFBYSxhQUFhOzs7O0FDak9qQyxJQUFJRSxjQUFZLE9BQU87QUFDdkIsSUFBSUMsWUFBVSxRQUFRLFVBQVVELFlBQVUsUUFBUSxRQUFRO0NBQUU7Q0FBTyxjQUFjO0FBQUssQ0FBQztBQVF2RixJQUFJLFNBQXlCLDZCQUFNLFdBQ2pCLHlCQUFPLFNBQVMsUUFBUSxPQUFPLGNBQWM7Q0FDM0QsTUFBTSxFQUFFLFdBQVcsZUFBZSxHQUFHLGdCQUFnQjtDQUNyRCxNQUFNLENBQUMsU0FBUyxjQUFBLGFBQW9CLFNBQVMsS0FBSztDQUNsRCx1QkFBc0IsV0FBVyxJQUFJLEdBQUcsQ0FBQyxDQUFDO0NBQzFDLE1BQU0sWUFBWSxpQkFBaUIsV0FBVyxZQUFZLFVBQVU7Q0FDcEUsT0FBTyxZQUFBLGlCQUFxQixhQUE2QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxVQUFVLEtBQUs7RUFBRSxHQUFHO0VBQWEsS0FBSztDQUFhLENBQUMsR0FBRyxTQUFTLElBQUk7QUFDbkksR0FBRyxRQUFRLENBQ2I7OztBQ2pCQSxJQUFJLFlBQVksT0FBTztBQUN2QixJQUFJLFVBQVUsUUFBUSxVQUFVLFVBQVUsUUFBUSxRQUFRO0NBQUU7Q0FBTyxjQUFjO0FBQUssQ0FBQztBQUl2RixJQUFJLFFBQVE7QUFDWixJQUFJLFNBQVM7QUFDYixTQUFTLFlBQVksT0FBTztDQUMxQixlQUFlO0NBQ2YsT0FBTyxNQUFNO0FBQ2Y7QUFDQSxPQUFPLGFBQWEsYUFBYTtBQUNqQyxTQUFTLGlCQUFpQjtDQUN4QixhQUFNLGdCQUFnQjtFQUNwQixJQUFJLENBQUMsUUFDSCxTQUFTO0dBQUUsT0FBTyxpQkFBaUI7R0FBRyxLQUFLLGlCQUFpQjtFQUFFO0VBRWhFLE1BQU0sRUFBRSxPQUFPLFFBQVE7RUFDdkIsSUFBSSxTQUFTLEtBQUssc0JBQXNCLE9BQ3RDLFNBQVMsS0FBSyxzQkFBc0IsY0FBYyxLQUFLO0VBRXpELElBQUksU0FBUyxLQUFLLHFCQUFxQixLQUNyQyxTQUFTLEtBQUssc0JBQXNCLGFBQWEsR0FBRztFQUV0RDtFQUNBLGFBQWE7R0FDWCxJQUFJLFVBQVUsR0FBRztJQUNmLFFBQVEsTUFBTSxPQUFPO0lBQ3JCLFFBQVEsSUFBSSxPQUFPO0lBQ25CLFNBQVM7R0FDWDtHQUNBLFFBQVEsS0FBSyxJQUFJLEdBQUcsUUFBUSxDQUFDO0VBQy9CO0NBQ0YsR0FBRyxDQUFDLENBQUM7QUFDUDtBQUNBLE9BQU8sZ0JBQWdCLGdCQUFnQjtBQUN2QyxTQUFTLG1CQUFtQjtDQUMxQixNQUFNLFVBQVUsU0FBUyxjQUFjLE1BQU07Q0FDN0MsUUFBUSxhQUFhLDBCQUEwQixFQUFFO0NBQ2pELFFBQVEsV0FBVztDQUNuQixRQUFRLE1BQU0sVUFBVTtDQUN4QixRQUFRLE1BQU0sVUFBVTtDQUN4QixRQUFRLE1BQU0sV0FBVztDQUN6QixRQUFRLE1BQU0sZ0JBQWdCO0NBQzlCLE9BQU87QUFDVDtBQUNBLE9BQU8sa0JBQWtCLGtCQUFrQjs7O0FDL0MzQyxJQUFXLHFCQUFxQjtBQUNoQyxJQUFXLHFCQUFxQjtBQUNoQyxJQUFXLHdCQUF3Qjs7Ozs7QUFLbkMsSUFBVyx5QkFBeUI7Ozs7Ozs7Ozs7Ozs7Ozs7QUNNcEMsU0FBZ0IsVUFBVSxLQUFLLE9BQU87Q0FDbEMsSUFBSSxPQUFPLFFBQVEsWUFDZixJQUFJLEtBQUs7TUFFUixJQUFJLEtBQ0wsSUFBSSxVQUFVO0NBRWxCLE9BQU87QUFDWDs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNOQSxTQUFnQixlQUFlLGNBQWMsVUFBVTtDQUNuRCxJQUFJLE9BQUEsR0FBTUUsYUFBQUEsU0FBQUEsQ0FBUyxXQUFZO0VBQUUsT0FBUTtHQUVyQyxPQUFPO0dBRUc7R0FFVixRQUFRO0lBQ0osSUFBSSxVQUFVO0tBQ1YsT0FBTyxJQUFJO0lBQ2Y7SUFDQSxJQUFJLFFBQVEsT0FBTztLQUNmLElBQUksT0FBTyxJQUFJO0tBQ2YsSUFBSSxTQUFTLE9BQU87TUFDaEIsSUFBSSxRQUFRO01BQ1osSUFBSSxTQUFTLE9BQU8sSUFBSTtLQUM1QjtJQUNKO0dBQ0o7RUFDSjtDQUFJLENBQUMsQ0FBQyxDQUFDO0NBRVAsSUFBSSxXQUFXO0NBQ2YsT0FBTyxJQUFJO0FBQ2Y7OztBQ25DQSxJQUFJLDRCQUE0QixPQUFPLFdBQVcsY0FBQSxhQUFvQixrQkFBQSxhQUF3QjtBQUM5RixJQUFJLGdDQUFnQixJQUFJLFFBQVE7Ozs7Ozs7Ozs7Ozs7OztBQWVoQyxTQUFnQixhQUFhLE1BQU0sY0FBYztDQUM3QyxJQUFJLGNBQWMsZUFBZSxnQkFBZ0IsTUFBTSxTQUFVLFVBQVU7RUFDdkUsT0FBTyxLQUFLLFFBQVEsU0FBVSxLQUFLO0dBQUUsT0FBTyxVQUFVLEtBQUssUUFBUTtFQUFHLENBQUM7Q0FDM0UsQ0FBQztDQUVELDBCQUEwQixXQUFZO0VBQ2xDLElBQUksV0FBVyxjQUFjLElBQUksV0FBVztFQUM1QyxJQUFJLFVBQVU7R0FDVixJQUFJLGFBQWEsSUFBSSxJQUFJLFFBQVE7R0FDakMsSUFBSSxhQUFhLElBQUksSUFBSSxJQUFJO0dBQzdCLElBQUksWUFBWSxZQUFZO0dBQzVCLFdBQVcsUUFBUSxTQUFVLEtBQUs7SUFDOUIsSUFBSSxDQUFDLFdBQVcsSUFBSSxHQUFHLEdBQ25CLFVBQVUsS0FBSyxJQUFJO0dBRTNCLENBQUM7R0FDRCxXQUFXLFFBQVEsU0FBVSxLQUFLO0lBQzlCLElBQUksQ0FBQyxXQUFXLElBQUksR0FBRyxHQUNuQixVQUFVLEtBQUssU0FBUztHQUVoQyxDQUFDO0VBQ0w7RUFDQSxjQUFjLElBQUksYUFBYSxJQUFJO0NBQ3ZDLEdBQUcsQ0FBQyxJQUFJLENBQUM7Q0FDVCxPQUFPO0FBQ1g7OztBQzNDQSxTQUFTLEtBQUssR0FBRztDQUNiLE9BQU87QUFDWDtBQUNBLFNBQVMsa0JBQWtCLFVBQVUsWUFBWTtDQUM3QyxJQUFJLGVBQWUsS0FBSyxHQUFLLGFBQWE7Q0FDMUMsSUFBSSxTQUFTLENBQUM7Q0FDZCxJQUFJLFdBQVc7Q0EwRGYsT0FBTztFQXhESCxNQUFNLFdBQVk7R0FDZCxJQUFJLFVBQ0EsTUFBTSxJQUFJLE1BQU0sa0dBQWtHO0dBRXRILElBQUksT0FBTyxRQUNQLE9BQU8sT0FBTyxPQUFPLFNBQVM7R0FFbEMsT0FBTztFQUNYO0VBQ0EsV0FBVyxTQUFVLE1BQU07R0FDdkIsSUFBSSxPQUFPLFdBQVcsTUFBTSxRQUFRO0dBQ3BDLE9BQU8sS0FBSyxJQUFJO0dBQ2hCLE9BQU8sV0FBWTtJQUNmLFNBQVMsT0FBTyxPQUFPLFNBQVUsR0FBRztLQUFFLE9BQU8sTUFBTTtJQUFNLENBQUM7R0FDOUQ7RUFDSjtFQUNBLGtCQUFrQixTQUFVLElBQUk7R0FDNUIsV0FBVztHQUNYLE9BQU8sT0FBTyxRQUFRO0lBQ2xCLElBQUksTUFBTTtJQUNWLFNBQVMsQ0FBQztJQUNWLElBQUksUUFBUSxFQUFFO0dBQ2xCO0dBQ0EsU0FBUztJQUNMLE1BQU0sU0FBVSxHQUFHO0tBQUUsT0FBTyxHQUFHLENBQUM7SUFBRztJQUNuQyxRQUFRLFdBQVk7S0FBRSxPQUFPO0lBQVE7R0FDekM7RUFDSjtFQUNBLGNBQWMsU0FBVSxJQUFJO0dBQ3hCLFdBQVc7R0FDWCxJQUFJLGVBQWUsQ0FBQztHQUNwQixJQUFJLE9BQU8sUUFBUTtJQUNmLElBQUksTUFBTTtJQUNWLFNBQVMsQ0FBQztJQUNWLElBQUksUUFBUSxFQUFFO0lBQ2QsZUFBZTtHQUNuQjtHQUNBLElBQUksZUFBZSxXQUFZO0lBQzNCLElBQUksTUFBTTtJQUNWLGVBQWUsQ0FBQztJQUNoQixJQUFJLFFBQVEsRUFBRTtHQUNsQjtHQUNBLElBQUksUUFBUSxXQUFZO0lBQUUsT0FBTyxRQUFRLFFBQVEsQ0FBQyxDQUFDLEtBQUssWUFBWTtHQUFHO0dBQ3ZFLE1BQU07R0FDTixTQUFTO0lBQ0wsTUFBTSxTQUFVLEdBQUc7S0FDZixhQUFhLEtBQUssQ0FBQztLQUNuQixNQUFNO0lBQ1Y7SUFDQSxRQUFRLFNBQVUsUUFBUTtLQUN0QixlQUFlLGFBQWEsT0FBTyxNQUFNO0tBQ3pDLE9BQU87SUFDWDtHQUNKO0VBQ0o7Q0FFUTtBQUNoQjtBQU1BLFNBQWdCLG9CQUFvQixTQUFTO0NBQ3pDLElBQUksWUFBWSxLQUFLLEdBQUssVUFBVSxDQUFDO0NBQ3JDLElBQUksU0FBUyxrQkFBa0IsSUFBSTtDQUNuQyxPQUFPLFVBQVUsU0FBUztFQUFFLE9BQU87RUFBTSxLQUFLO0NBQU0sR0FBRyxPQUFPO0NBQzlELE9BQU87QUFDWDs7O0FDM0VBLElBQUksVUFBVSxTQUFVLElBQUk7Q0FDeEIsSUFBSSxVQUFVLEdBQUcsU0FBUyxPQUFPLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQztDQUN2RCxJQUFJLENBQUMsU0FDRCxNQUFNLElBQUksTUFBTSxvRUFBb0U7Q0FFeEYsSUFBSSxTQUFTLFFBQVEsS0FBSztDQUMxQixJQUFJLENBQUMsUUFDRCxNQUFNLElBQUksTUFBTSwwQkFBMEI7Q0FFOUMsT0FBQSxhQUFhLGNBQWMsUUFBUSxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUM7QUFDekQ7QUFDQSxRQUFRLGtCQUFrQjtBQUMxQixTQUFnQixjQUFjLFFBQVEsVUFBVTtDQUM1QyxPQUFPLFVBQVUsUUFBUTtDQUN6QixPQUFPO0FBQ1g7OztBQ2hCQSxJQUFXLFlBQVksb0JBQW9COzs7QUNJM0MsSUFBSSxVQUFVLFdBQVksQ0FFMUI7Ozs7QUFJQSxJQUFJLGVBQUEsYUFBcUIsV0FBVyxTQUFVLE9BQU8sV0FBVztDQUM1RCxJQUFJLE1BQUEsYUFBWSxPQUFPLElBQUk7Q0FDM0IsSUFBSSxLQUFBLGFBQVcsU0FBUztFQUNwQixpQkFBaUI7RUFDakIsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtDQUN4QixDQUFDLEdBQUcsWUFBWSxHQUFHLElBQUksZUFBZSxHQUFHO0NBQ3pDLElBQUksZUFBZSxNQUFNLGNBQWMsV0FBVyxNQUFNLFVBQVUsWUFBWSxNQUFNLFdBQVcsa0JBQWtCLE1BQU0saUJBQWlCLFVBQVUsTUFBTSxTQUFTLFNBQVMsTUFBTSxRQUFRLFVBQVUsTUFBTSxTQUFTLGFBQWEsTUFBTSxZQUFZLGNBQWMsTUFBTSxhQUFhLFFBQVEsTUFBTSxPQUFPLGlCQUFpQixNQUFNLGdCQUFnQixLQUFLLE1BQU0sSUFBSSxZQUFZLE9BQU8sS0FBSyxJQUFJLFFBQVEsSUFBSSxVQUFVLE1BQU0sU0FBUyxPQUFPLE9BQU8sT0FBTztFQUFDO0VBQWdCO0VBQVk7RUFBYTtFQUFtQjtFQUFXO0VBQVU7RUFBVztFQUFjO0VBQWU7RUFBUztFQUFrQjtFQUFNO0NBQVMsQ0FBQztDQUN2bEIsSUFBSSxVQUFVO0NBQ2QsSUFBSSxlQUFlLGFBQWEsQ0FBQyxLQUFLLFNBQVMsQ0FBQztDQUNoRCxJQUFJLGlCQUFpQixTQUFTLFNBQVMsQ0FBQyxHQUFHLElBQUksR0FBRyxTQUFTO0NBQzNELE9BQUEsYUFBYyxjQUFBLGFBQW9CLFVBQVUsTUFDeEMsV0FBQSxhQUFrQixjQUFjLFNBQVM7RUFBRSxTQUFTO0VBQTRCO0VBQXlCO0VBQW9CO0VBQXlCO0VBQW9CO0VBQXFCO0VBQWMsZ0JBQWdCLENBQUMsQ0FBQztFQUFnQixTQUFTO0VBQWM7Q0FBUSxDQUFDLEdBQy9RLGVBQUEsYUFBc0IsYUFBQSxhQUFtQixTQUFTLEtBQUssUUFBUSxHQUFHLFNBQVMsU0FBUyxDQUFDLEdBQUcsY0FBYyxHQUFHLEVBQUUsS0FBSyxhQUFhLENBQUMsQ0FBQyxJQUFBLGFBQVksY0FBYyxXQUFXLFNBQVMsQ0FBQyxHQUFHLGdCQUFnQjtFQUFhO0VBQVcsS0FBSztDQUFhLENBQUMsR0FBRyxRQUFRLENBQUU7QUFDalEsQ0FBQztBQUNELGFBQWEsZUFBZTtDQUN4QixTQUFTO0NBQ1QsaUJBQWlCO0NBQ2pCLE9BQU87QUFDWDtBQUNBLGFBQWEsYUFBYTtDQUN0QixXQUFXO0NBQ1gsV0FBVztBQUNmO0FDOUJBLElBQVcsV0FBVyxXQUFZO0NBSTlCLElBQUksT0FBTyxzQkFBc0IsYUFDN0IsT0FBTztBQUdmOzs7QUNYQSxTQUFTLGVBQWU7Q0FDcEIsSUFBSSxDQUFDLFVBQ0QsT0FBTztDQUNYLElBQUksTUFBTSxTQUFTLGNBQWMsT0FBTztDQUN4QyxJQUFJLE9BQU87Q0FDWCxJQUFJLFFBQVEsU0FBUztDQUNyQixJQUFJLE9BQ0EsSUFBSSxhQUFhLFNBQVMsS0FBSztDQUVuQyxPQUFPO0FBQ1g7QUFDQSxTQUFTLGFBQWEsS0FBSyxLQUFLO0NBRTVCLElBQUksSUFBSSxZQUVKLElBQUksV0FBVyxVQUFVO01BR3pCLElBQUksWUFBWSxTQUFTLGVBQWUsR0FBRyxDQUFDO0FBRXBEO0FBQ0EsU0FBUyxlQUFlLEtBQUs7Q0FFekIsQ0FEVyxTQUFTLFFBQVEsU0FBUyxxQkFBcUIsTUFBTSxDQUFDLENBQUMsR0FBQSxDQUM3RCxZQUFZLEdBQUc7QUFDeEI7QUFDQSxJQUFXLHNCQUFzQixXQUFZO0NBQ3pDLElBQUksVUFBVTtDQUNkLElBQUksYUFBYTtDQUNqQixPQUFPO0VBQ0gsS0FBSyxTQUFVLE9BQU87R0FDbEIsSUFBSSxXQUFXLEdBQ047UUFBQSxhQUFhLGFBQWEsR0FBSTtLQUMvQixhQUFhLFlBQVksS0FBSztLQUM5QixlQUFlLFVBQVU7SUFDN0I7O0dBRUo7RUFDSjtFQUNBLFFBQVEsV0FBWTtHQUNoQjtHQUNBLElBQUksQ0FBQyxXQUFXLFlBQVk7SUFDeEIsV0FBVyxjQUFjLFdBQVcsV0FBVyxZQUFZLFVBQVU7SUFDckUsYUFBYTtHQUNqQjtFQUNKO0NBQ0o7QUFDSjs7Ozs7Ozs7Ozs7O0FDcENBLElBQVcscUJBQXFCLFdBQVk7Q0FDeEMsSUFBSSxRQUFRLG9CQUFvQjtDQUNoQyxPQUFPLFNBQVUsUUFBUSxXQUFXO0VBQ2hDLGFBQU0sVUFBVSxXQUFZO0dBQ3hCLE1BQU0sSUFBSSxNQUFNO0dBQ2hCLE9BQU8sV0FBWTtJQUNmLE1BQU0sT0FBTztHQUNqQjtFQUNKLEdBQUcsQ0FBQyxVQUFVLFNBQVMsQ0FBQztDQUM1QjtBQUNKOzs7Ozs7Ozs7QUNkQSxJQUFXLGlCQUFpQixXQUFZO0NBQ3BDLElBQUksV0FBVyxtQkFBbUI7Q0FDbEMsSUFBSSxRQUFRLFNBQVUsSUFBSTtFQUN0QixJQUFJLFNBQVMsR0FBRyxRQUFRLFVBQVUsR0FBRztFQUNyQyxTQUFTLFFBQVEsT0FBTztFQUN4QixPQUFPO0NBQ1g7Q0FDQSxPQUFPO0FBQ1g7OztBQ2ZBLElBQVcsVUFBVTtDQUNqQixNQUFNO0NBQ04sS0FBSztDQUNMLE9BQU87Q0FDUCxLQUFLO0FBQ1Q7QUFDQSxJQUFJLFFBQVEsU0FBVSxHQUFHO0NBQUUsT0FBTyxTQUFTLEtBQUssSUFBSSxFQUFFLEtBQUs7QUFBRztBQUM5RCxJQUFJLFlBQVksU0FBVSxTQUFTO0NBQy9CLElBQUksS0FBSyxPQUFPLGlCQUFpQixTQUFTLElBQUk7Q0FDOUMsSUFBSSxPQUFPLEdBQUcsWUFBWSxZQUFZLGdCQUFnQjtDQUN0RCxJQUFJLE1BQU0sR0FBRyxZQUFZLFlBQVksZUFBZTtDQUNwRCxJQUFJLFFBQVEsR0FBRyxZQUFZLFlBQVksaUJBQWlCO0NBQ3hELE9BQU87RUFBQyxNQUFNLElBQUk7RUFBRyxNQUFNLEdBQUc7RUFBRyxNQUFNLEtBQUs7Q0FBQztBQUNqRDtBQUNBLElBQVcsY0FBYyxTQUFVLFNBQVM7Q0FDeEMsSUFBSSxZQUFZLEtBQUssR0FBSyxVQUFVO0NBQ3BDLElBQUksT0FBTyxXQUFXLGFBQ2xCLE9BQU87Q0FFWCxJQUFJLFVBQVUsVUFBVSxPQUFPO0NBQy9CLElBQUksZ0JBQWdCLFNBQVMsZ0JBQWdCO0NBQzdDLElBQUksY0FBYyxPQUFPO0NBQ3pCLE9BQU87RUFDSCxNQUFNLFFBQVE7RUFDZCxLQUFLLFFBQVE7RUFDYixPQUFPLFFBQVE7RUFDZixLQUFLLEtBQUssSUFBSSxHQUFHLGNBQWMsZ0JBQWdCLFFBQVEsS0FBSyxRQUFRLEVBQUU7Q0FDMUU7QUFDSjs7O0FDeEJBLElBQUksUUFBUSxlQUFlO0FBQzNCLElBQVcsZ0JBQWdCO0FBSTNCLElBQUksWUFBWSxTQUFVLElBQUksZUFBZSxTQUFTLFdBQVc7Q0FDN0QsSUFBSSxPQUFPLEdBQUcsTUFBTSxNQUFNLEdBQUcsS0FBSyxRQUFRLEdBQUcsT0FBTyxNQUFNLEdBQUc7Q0FDN0QsSUFBSSxZQUFZLEtBQUssR0FBSyxVQUFVO0NBQ3BDLE9BQU8sUUFBUSxPQUFPLHVCQUF1QiwwQkFBMEIsQ0FBQyxDQUFDLE9BQU8sV0FBVyx1QkFBdUIsQ0FBQyxDQUFDLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxPQUFPLFdBQVcsaUJBQWlCLENBQUMsQ0FBQyxPQUFPLGVBQWUsNEJBQTRCLENBQUMsQ0FBQyxPQUFPLFdBQVcsNENBQTRDLENBQUMsQ0FBQyxPQUFPO0VBQ25TLGlCQUFpQixzQkFBc0IsT0FBTyxXQUFXLEdBQUc7RUFDNUQsWUFBWSxZQUNSLHVCQUF1QixPQUFPLE1BQU0sd0JBQXdCLENBQUMsQ0FBQyxPQUFPLEtBQUssMEJBQTBCLENBQUMsQ0FBQyxPQUFPLE9BQU8sZ0VBQWdFLENBQUMsQ0FBQyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsT0FBTyxXQUFXLFNBQVM7RUFDeE8sWUFBWSxhQUFhLGtCQUFrQixPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsT0FBTyxXQUFXLEdBQUc7Q0FDdkYsQ0FBQyxDQUNJLE9BQU8sT0FBTyxDQUFDLENBQ2YsS0FBSyxFQUFFLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLG9CQUFvQixpQkFBaUIsQ0FBQyxDQUFDLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxPQUFPLFdBQVcsaUJBQWlCLENBQUMsQ0FBQyxPQUFPLG9CQUFvQix3QkFBd0IsQ0FBQyxDQUFDLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxPQUFPLFdBQVcsaUJBQWlCLENBQUMsQ0FBQyxPQUFPLG9CQUFvQixJQUFJLENBQUMsQ0FBQyxPQUFPLG9CQUFvQixtQkFBbUIsQ0FBQyxDQUFDLE9BQU8sV0FBVyxpQkFBaUIsQ0FBQyxDQUFDLE9BQU8sb0JBQW9CLElBQUksQ0FBQyxDQUFDLE9BQU8sb0JBQW9CLDBCQUEwQixDQUFDLENBQUMsT0FBTyxXQUFXLHFCQUFxQixDQUFDLENBQUMsT0FBTyxlQUFlLFdBQVcsQ0FBQyxDQUFDLE9BQU8sd0JBQXdCLElBQUksQ0FBQyxDQUFDLE9BQU8sS0FBSyxZQUFZO0FBQy9rQjtBQUNBLElBQUksdUJBQXVCLFdBQVk7Q0FDbkMsSUFBSSxVQUFVLFNBQVMsU0FBUyxLQUFLLGFBQUEsb0JBQTBCLEtBQUssS0FBSyxFQUFFO0NBQzNFLE9BQU8sU0FBUyxPQUFPLElBQUksVUFBVTtBQUN6QztBQUNBLElBQVcsbUJBQW1CLFdBQVk7Q0FDdEMsYUFBTSxVQUFVLFdBQVk7RUFDeEIsU0FBUyxLQUFLLGFBQWEsZ0JBQWdCLHFCQUFxQixJQUFJLEVBQUEsQ0FBRyxTQUFTLENBQUM7RUFDakYsT0FBTyxXQUFZO0dBQ2YsSUFBSSxhQUFhLHFCQUFxQixJQUFJO0dBQzFDLElBQUksY0FBYyxHQUNkLFNBQVMsS0FBSyxnQkFBZ0IsYUFBYTtRQUczQyxTQUFTLEtBQUssYUFBYSxlQUFlLFdBQVcsU0FBUyxDQUFDO0VBRXZFO0NBQ0osR0FBRyxDQUFDLENBQUM7QUFDVDs7OztBQUlBLElBQVcsa0JBQWtCLFNBQVUsSUFBSTtDQUN2QyxJQUFJLGFBQWEsR0FBRyxZQUFZLGNBQWMsR0FBRyxhQUFhLEtBQUssR0FBRyxTQUFTLFVBQVUsT0FBTyxLQUFLLElBQUksV0FBVztDQUNwSCxpQkFBaUI7Q0FNakIsSUFBSSxNQUFBLGFBQVksUUFBUSxXQUFZO0VBQUUsT0FBTyxZQUFZLE9BQU87Q0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDO0NBQy9FLE9BQUEsYUFBYSxjQUFjLE9BQU8sRUFBRSxRQUFRLFVBQVUsS0FBSyxDQUFDLFlBQVksU0FBUyxDQUFDLGNBQWMsZUFBZSxFQUFFLEVBQUUsQ0FBQztBQUN4SDs7O0FDcERBLElBQUksbUJBQW1CO0FBQ3ZCLElBQUksT0FBTyxXQUFXLGFBQ2xCLElBQUk7Q0FDQSxJQUFJLFVBQVUsT0FBTyxlQUFlLENBQUMsR0FBRyxXQUFXLEVBQy9DLEtBQUssV0FBWTtFQUNiLG1CQUFtQjtFQUNuQixPQUFPO0NBQ1gsRUFDSixDQUFDO0NBRUQsT0FBTyxpQkFBaUIsUUFBUSxTQUFTLE9BQU87Q0FFaEQsT0FBTyxvQkFBb0IsUUFBUSxTQUFTLE9BQU87QUFDdkQsU0FDTyxLQUFLO0NBQ1IsbUJBQW1CO0FBQ3ZCO0FBRUosSUFBVyxhQUFhLG1CQUFtQixFQUFFLFNBQVMsTUFBTSxJQUFJOzs7QUNsQmhFLElBQUksdUJBQXVCLFNBQVUsTUFBTTtDQUV2QyxPQUFPLEtBQUssWUFBWTtBQUM1QjtBQUNBLElBQUksdUJBQXVCLFNBQVUsTUFBTSxVQUFVO0NBQ2pELElBQUksRUFBRSxnQkFBZ0IsVUFDbEIsT0FBTztDQUVYLElBQUksU0FBUyxPQUFPLGlCQUFpQixJQUFJO0NBQ3pDLE9BRUEsT0FBTyxjQUFjLFlBRWpCLEVBQUUsT0FBTyxjQUFjLE9BQU8sYUFBYSxDQUFDLHFCQUFxQixJQUFJLEtBQUssT0FBTyxjQUFjO0FBQ3ZHO0FBQ0EsSUFBSSwwQkFBMEIsU0FBVSxNQUFNO0NBQUUsT0FBTyxxQkFBcUIsTUFBTSxXQUFXO0FBQUc7QUFDaEcsSUFBSSwwQkFBMEIsU0FBVSxNQUFNO0NBQUUsT0FBTyxxQkFBcUIsTUFBTSxXQUFXO0FBQUc7QUFDaEcsSUFBVywwQkFBMEIsU0FBVSxNQUFNLE1BQU07Q0FDdkQsSUFBSSxnQkFBZ0IsS0FBSztDQUN6QixJQUFJLFVBQVU7Q0FDZCxHQUFHO0VBRUMsSUFBSSxPQUFPLGVBQWUsZUFBZSxtQkFBbUIsWUFDeEQsVUFBVSxRQUFRO0VBR3RCLElBRG1CLHVCQUF1QixNQUFNLE9BQ2pDLEdBQUc7R0FDZCxJQUFJLEtBQUssbUJBQW1CLE1BQU0sT0FBTztHQUN6QyxJQUQyRCxHQUFHLEtBQW1CLEdBQUcsSUFFaEYsT0FBTztFQUVmO0VBQ0EsVUFBVSxRQUFRO0NBQ3RCLFNBQVMsV0FBVyxZQUFZLGNBQWM7Q0FDOUMsT0FBTztBQUNYO0FBQ0EsSUFBSSxzQkFBc0IsU0FBVSxJQUFJO0NBRXBDLE9BQU87RUFEUyxHQUFHO0VBQTBCLEdBQUc7RUFBNkIsR0FBRztDQUtoRjtBQUNKO0FBQ0EsSUFBSSxzQkFBc0IsU0FBVSxJQUFJO0NBRXBDLE9BQU87RUFEVSxHQUFHO0VBQTBCLEdBQUc7RUFBMkIsR0FBRztDQUsvRTtBQUNKO0FBQ0EsSUFBSSx5QkFBeUIsU0FBVSxNQUFNLE1BQU07Q0FDL0MsT0FBTyxTQUFTLE1BQU0sd0JBQXdCLElBQUksSUFBSSx3QkFBd0IsSUFBSTtBQUN0RjtBQUNBLElBQUkscUJBQXFCLFNBQVUsTUFBTSxNQUFNO0NBQzNDLE9BQU8sU0FBUyxNQUFNLG9CQUFvQixJQUFJLElBQUksb0JBQW9CLElBQUk7QUFDOUU7QUFDQSxJQUFJLHFCQUFxQixTQUFVLE1BQU0sV0FBVzs7Ozs7O0NBTWhELE9BQU8sU0FBUyxPQUFPLGNBQWMsUUFBUSxLQUFLO0FBQ3REO0FBQ0EsSUFBVyxlQUFlLFNBQVUsTUFBTSxXQUFXLE9BQU8sYUFBYSxjQUFjO0NBQ25GLElBQUksa0JBQWtCLG1CQUFtQixNQUFNLE9BQU8saUJBQWlCLFNBQVMsQ0FBQyxDQUFDLFNBQVM7Q0FDM0YsSUFBSSxRQUFRLGtCQUFrQjtDQUU5QixJQUFJLFNBQVMsTUFBTTtDQUNuQixJQUFJLGVBQWUsVUFBVSxTQUFTLE1BQU07Q0FDNUMsSUFBSSxxQkFBcUI7Q0FDekIsSUFBSSxrQkFBa0IsUUFBUTtDQUM5QixJQUFJLGtCQUFrQjtDQUN0QixJQUFJLHFCQUFxQjtDQUN6QixHQUFHO0VBQ0MsSUFBSSxDQUFDLFFBQ0Q7RUFFSixJQUFJLEtBQUssbUJBQW1CLE1BQU0sTUFBTSxHQUFHLFdBQVcsR0FBRztFQUN6RCxJQUFJLGdCQURvRSxHQUFHLEtBQWUsR0FBRyxLQUNuRCxrQkFBa0I7RUFDNUQsSUFBSSxZQUFZLGVBQ1I7T0FBQSx1QkFBdUIsTUFBTSxNQUFNLEdBQUc7SUFDdEMsbUJBQW1CO0lBQ25CLHNCQUFzQjtHQUMxQjs7RUFFSixJQUFJLFdBQVcsT0FBTztFQUd0QixTQUFVLFlBQVksU0FBUyxhQUFhLEtBQUsseUJBQXlCLFNBQVMsT0FBTztDQUM5RixTQUVDLENBQUMsZ0JBQWdCLFdBQVcsU0FBUyxRQUVqQyxpQkFBaUIsVUFBVSxTQUFTLE1BQU0sS0FBSyxjQUFjO0NBRWxFLElBQUksb0JBQ0UsZ0JBQWdCLEtBQUssSUFBSSxlQUFlLElBQUksS0FBTyxDQUFDLGdCQUFnQixRQUFRLGtCQUM5RSxxQkFBcUI7TUFFcEIsSUFBSSxDQUFDLG9CQUNKLGdCQUFnQixLQUFLLElBQUksa0JBQWtCLElBQUksS0FBTyxDQUFDLGdCQUFnQixDQUFDLFFBQVEscUJBQ2xGLHFCQUFxQjtDQUV6QixPQUFPO0FBQ1g7OztBQ3JHQSxJQUFXLGFBQWEsU0FBVSxPQUFPO0NBQ3JDLE9BQU8sb0JBQW9CLFFBQVEsQ0FBQyxNQUFNLGVBQWUsRUFBRSxDQUFDLFNBQVMsTUFBTSxlQUFlLEVBQUUsQ0FBQyxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDakg7QUFDQSxJQUFXLGFBQWEsU0FBVSxPQUFPO0NBQUUsT0FBTyxDQUFDLE1BQU0sUUFBUSxNQUFNLE1BQU07QUFBRztBQUNoRixJQUFJLGFBQWEsU0FBVSxLQUFLO0NBQzVCLE9BQU8sT0FBTyxhQUFhLE1BQU0sSUFBSSxVQUFVO0FBQ25EO0FBQ0EsSUFBSSxlQUFlLFNBQVUsR0FBRyxHQUFHO0NBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFO0FBQUk7QUFDNUUsSUFBSSxnQkFBZ0IsU0FBVSxJQUFJO0NBQUUsT0FBTyw0QkFBNEIsT0FBTyxJQUFJLG1EQUFtRCxDQUFDLENBQUMsT0FBTyxJQUFJLDJCQUEyQjtBQUFHO0FBQ2hMLElBQUksWUFBWTtBQUNoQixJQUFJLFlBQVksQ0FBQztBQUNqQixTQUFnQixvQkFBb0IsT0FBTztDQUN2QyxJQUFJLHFCQUFBLGFBQTJCLE9BQU8sQ0FBQyxDQUFDO0NBQ3hDLElBQUksZ0JBQUEsYUFBc0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0NBQ3ZDLElBQUksYUFBQSxhQUFtQixPQUFPO0NBQzlCLElBQUksS0FBQSxhQUFXLFNBQVMsV0FBVyxDQUFDLENBQUM7Q0FDckMsSUFBSSxRQUFBLGFBQWMsU0FBUyxjQUFjLENBQUMsQ0FBQztDQUMzQyxJQUFJLFlBQUEsYUFBa0IsT0FBTyxLQUFLO0NBQ2xDLGFBQU0sVUFBVSxXQUFZO0VBQ3hCLFVBQVUsVUFBVTtDQUN4QixHQUFHLENBQUMsS0FBSyxDQUFDO0NBQ1YsYUFBTSxVQUFVLFdBQVk7RUFDeEIsSUFBSSxNQUFNLE9BQU87R0FDYixTQUFTLEtBQUssVUFBVSxJQUFJLHVCQUF1QixPQUFPLEVBQUUsQ0FBQztHQUM3RCxJQUFJLFVBQVUsY0FBYyxDQUFDLE1BQU0sUUFBUSxPQUFPLElBQUksTUFBTSxVQUFVLENBQUMsRUFBQSxDQUFHLElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxDQUFDLE9BQU8sT0FBTztHQUMvRyxRQUFRLFFBQVEsU0FBVSxJQUFJO0lBQUUsT0FBTyxHQUFHLFVBQVUsSUFBSSx1QkFBdUIsT0FBTyxFQUFFLENBQUM7R0FBRyxDQUFDO0dBQzdGLE9BQU8sV0FBWTtJQUNmLFNBQVMsS0FBSyxVQUFVLE9BQU8sdUJBQXVCLE9BQU8sRUFBRSxDQUFDO0lBQ2hFLFFBQVEsUUFBUSxTQUFVLElBQUk7S0FBRSxPQUFPLEdBQUcsVUFBVSxPQUFPLHVCQUF1QixPQUFPLEVBQUUsQ0FBQztJQUFHLENBQUM7R0FDcEc7RUFDSjtDQUVKLEdBQUc7RUFBQyxNQUFNO0VBQU8sTUFBTSxRQUFRO0VBQVMsTUFBTTtDQUFNLENBQUM7Q0FDckQsSUFBSSxvQkFBQSxhQUEwQixZQUFZLFNBQVUsT0FBTyxRQUFRO0VBQy9ELElBQUssYUFBYSxTQUFTLE1BQU0sUUFBUSxXQUFXLEtBQU8sTUFBTSxTQUFTLFdBQVcsTUFBTSxTQUN2RixPQUFPLENBQUMsVUFBVSxRQUFRO0VBRTlCLElBQUksUUFBUSxXQUFXLEtBQUs7RUFDNUIsSUFBSSxhQUFhLGNBQWM7RUFDL0IsSUFBSSxTQUFTLFlBQVksUUFBUSxNQUFNLFNBQVMsV0FBVyxLQUFLLE1BQU07RUFDdEUsSUFBSSxTQUFTLFlBQVksUUFBUSxNQUFNLFNBQVMsV0FBVyxLQUFLLE1BQU07RUFDdEUsSUFBSTtFQUNKLElBQUksU0FBUyxNQUFNO0VBQ25CLElBQUksZ0JBQWdCLEtBQUssSUFBSSxNQUFNLElBQUksS0FBSyxJQUFJLE1BQU0sSUFBSSxNQUFNO0VBRWhFLElBQUksYUFBYSxTQUFTLGtCQUFrQixPQUFPLE9BQU8sU0FBUyxTQUMvRCxPQUFPO0VBR1gsSUFBSSxZQUFZLE9BQU8sYUFBYTtFQUNwQyxJQUFJLGFBQWEsYUFBYSxVQUFVO0VBRXhDLElBRDBCLGFBQWEsZUFBZSxVQUFVLFdBQVcsU0FBUyxNQUFNLElBQUksT0FFMUYsT0FBTztFQUVYLElBQUksK0JBQStCLHdCQUF3QixlQUFlLE1BQU07RUFDaEYsSUFBSSxDQUFDLDhCQUNELE9BQU87RUFFWCxJQUFJLDhCQUNBLGNBQWM7T0FFYjtHQUNELGNBQWMsa0JBQWtCLE1BQU0sTUFBTTtHQUM1QywrQkFBK0Isd0JBQXdCLGVBQWUsTUFBTTtFQUVoRjtFQUNBLElBQUksQ0FBQyw4QkFDRCxPQUFPO0VBRVgsSUFBSSxDQUFDLFdBQVcsV0FBVyxvQkFBb0IsVUFBVSxVQUFVLFNBQy9ELFdBQVcsVUFBVTtFQUV6QixJQUFJLENBQUMsYUFDRCxPQUFPO0VBRVgsSUFBSSxnQkFBZ0IsV0FBVyxXQUFXO0VBQzFDLE9BQU8sYUFBYSxlQUFlLFFBQVEsT0FBTyxrQkFBa0IsTUFBTSxTQUFTLFFBQVEsSUFBSTtDQUNuRyxHQUFHLENBQUMsQ0FBQztDQUNMLElBQUksZ0JBQUEsYUFBc0IsWUFBWSxTQUFVLFFBQVE7RUFDcEQsSUFBSSxRQUFRO0VBQ1osSUFBSSxDQUFDLFVBQVUsVUFBVSxVQUFVLFVBQVUsU0FBUyxPQUFPLE9BRXpEO0VBRUosSUFBSSxRQUFRLFlBQVksUUFBUSxXQUFXLEtBQUssSUFBSSxXQUFXLEtBQUs7RUFDcEUsSUFBSSxjQUFjLG1CQUFtQixRQUFRLE9BQU8sU0FBVSxHQUFHO0dBQUUsT0FBTyxFQUFFLFNBQVMsTUFBTSxTQUFTLEVBQUUsV0FBVyxNQUFNLFVBQVUsTUFBTSxXQUFXLEVBQUUsaUJBQWlCLGFBQWEsRUFBRSxPQUFPLEtBQUs7RUFBRyxDQUFDLENBQUMsQ0FBQztFQUV0TSxJQUFJLGVBQWUsWUFBWSxRQUFRO0dBQ25DLElBQUksTUFBTSxZQUNOLE1BQU0sZUFBZTtHQUV6QjtFQUNKO0VBRUEsSUFBSSxDQUFDLGFBQWE7R0FDZCxJQUFJLGNBQWMsVUFBVSxRQUFRLFVBQVUsQ0FBQyxFQUFBLENBQzFDLElBQUksVUFBVSxDQUFDLENBQ2YsT0FBTyxPQUFPLENBQUMsQ0FDZixPQUFPLFNBQVUsTUFBTTtJQUFFLE9BQU8sS0FBSyxTQUFTLE1BQU0sTUFBTTtHQUFHLENBQUM7R0FFbkUsSUFEaUIsV0FBVyxTQUFTLElBQUksa0JBQWtCLE9BQU8sV0FBVyxFQUFFLElBQUksQ0FBQyxVQUFVLFFBQVEsYUFFOUY7UUFBQSxNQUFNLFlBQ04sTUFBTSxlQUFlO0dBQUE7RUFHakM7Q0FDSixHQUFHLENBQUMsQ0FBQztDQUNMLElBQUksZUFBQSxhQUFxQixZQUFZLFNBQVUsTUFBTSxPQUFPLFFBQVEsUUFBUTtFQUN4RSxJQUFJLFFBQVE7R0FBUTtHQUFhO0dBQWU7R0FBZ0I7R0FBUSxjQUFjLHlCQUF5QixNQUFNO0VBQUU7RUFDdkgsbUJBQW1CLFFBQVEsS0FBSyxLQUFLO0VBQ3JDLFdBQVcsV0FBWTtHQUNuQixtQkFBbUIsVUFBVSxtQkFBbUIsUUFBUSxPQUFPLFNBQVUsR0FBRztJQUFFLE9BQU8sTUFBTTtHQUFPLENBQUM7RUFDdkcsR0FBRyxDQUFDO0NBQ1IsR0FBRyxDQUFDLENBQUM7Q0FDTCxJQUFJLG1CQUFBLGFBQXlCLFlBQVksU0FBVSxPQUFPO0VBQ3RELGNBQWMsVUFBVSxXQUFXLEtBQUs7RUFDeEMsV0FBVyxVQUFVLEtBQUE7Q0FDekIsR0FBRyxDQUFDLENBQUM7Q0FDTCxJQUFJLGNBQUEsYUFBb0IsWUFBWSxTQUFVLE9BQU87RUFDakQsYUFBYSxNQUFNLE1BQU0sV0FBVyxLQUFLLEdBQUcsTUFBTSxRQUFRLGtCQUFrQixPQUFPLE1BQU0sUUFBUSxPQUFPLENBQUM7Q0FDN0csR0FBRyxDQUFDLENBQUM7Q0FDTCxJQUFJLGtCQUFBLGFBQXdCLFlBQVksU0FBVSxPQUFPO0VBQ3JELGFBQWEsTUFBTSxNQUFNLFdBQVcsS0FBSyxHQUFHLE1BQU0sUUFBUSxrQkFBa0IsT0FBTyxNQUFNLFFBQVEsT0FBTyxDQUFDO0NBQzdHLEdBQUcsQ0FBQyxDQUFDO0NBQ0wsYUFBTSxVQUFVLFdBQVk7RUFDeEIsVUFBVSxLQUFLLEtBQUs7RUFDcEIsTUFBTSxhQUFhO0dBQ2YsaUJBQWlCO0dBQ2pCLGdCQUFnQjtHQUNoQixvQkFBb0I7RUFDeEIsQ0FBQztFQUNELFNBQVMsaUJBQWlCLFNBQVMsZUFBZSxVQUFVO0VBQzVELFNBQVMsaUJBQWlCLGFBQWEsZUFBZSxVQUFVO0VBQ2hFLFNBQVMsaUJBQWlCLGNBQWMsa0JBQWtCLFVBQVU7RUFDcEUsT0FBTyxXQUFZO0dBQ2YsWUFBWSxVQUFVLE9BQU8sU0FBVSxNQUFNO0lBQUUsT0FBTyxTQUFTO0dBQU8sQ0FBQztHQUN2RSxTQUFTLG9CQUFvQixTQUFTLGVBQWUsVUFBVTtHQUMvRCxTQUFTLG9CQUFvQixhQUFhLGVBQWUsVUFBVTtHQUNuRSxTQUFTLG9CQUFvQixjQUFjLGtCQUFrQixVQUFVO0VBQzNFO0NBQ0osR0FBRyxDQUFDLENBQUM7Q0FDTCxJQUFJLGtCQUFrQixNQUFNLGlCQUFpQixRQUFRLE1BQU07Q0FDM0QsT0FBQSxhQUFjLGNBQUEsYUFBb0IsVUFBVSxNQUN4QyxRQUFBLGFBQWMsY0FBYyxPQUFPLEVBQUUsUUFBUSxjQUFjLEVBQUUsRUFBRSxDQUFDLElBQUksTUFDcEUsa0JBQUEsYUFBd0IsY0FBYyxpQkFBaUI7RUFBRSxZQUFZLE1BQU07RUFBWSxTQUFTLE1BQU07Q0FBUSxDQUFDLElBQUksSUFBSTtBQUMvSDtBQUNBLFNBQVMseUJBQXlCLE1BQU07Q0FDcEMsSUFBSSxlQUFlO0NBQ25CLE9BQU8sU0FBUyxNQUFNO0VBQ2xCLElBQUksZ0JBQWdCLFlBQVk7R0FDNUIsZUFBZSxLQUFLO0dBQ3BCLE9BQU8sS0FBSztFQUNoQjtFQUNBLE9BQU8sS0FBSztDQUNoQjtDQUNBLE9BQU87QUFDWDs7O0FDaEtBLElBQUEsa0JBQWUsY0FBYyxXQUFXLG1CQUFtQjs7O0FDQzNELElBQUksb0JBQUEsYUFBMEIsV0FBVyxTQUFVLE9BQU8sS0FBSztDQUFFLE9BQUEsYUFBYyxjQUFjLGNBQWMsU0FBUyxDQUFDLEdBQUcsT0FBTztFQUFPO0VBQUssU0FBU0M7Q0FBUSxDQUFDLENBQUM7QUFBSSxDQUFDO0FBQ25LLGtCQUFrQixhQUFhLGFBQWE7OztBQ0w1QyxJQUFJLG1CQUFtQixTQUFVLGdCQUFnQjtDQUM3QyxJQUFJLE9BQU8sYUFBYSxhQUNwQixPQUFPO0NBR1gsUUFEbUIsTUFBTSxRQUFRLGNBQWMsSUFBSSxlQUFlLEtBQUssZUFBQSxDQUNuRCxjQUFjO0FBQ3RDO0FBQ0EsSUFBSSw2QkFBYSxJQUFJLFFBQVE7QUFDN0IsSUFBSSxvQ0FBb0IsSUFBSSxRQUFRO0FBQ3BDLElBQUksWUFBWSxDQUFDO0FBQ2pCLElBQUksWUFBWTtBQUNoQixJQUFJLGFBQWEsU0FBVSxNQUFNO0NBQzdCLE9BQU8sU0FBUyxLQUFLLFFBQVEsV0FBVyxLQUFLLFVBQVU7QUFDM0Q7QUFDQSxJQUFJLGlCQUFpQixTQUFVLFFBQVEsU0FBUztDQUM1QyxPQUFPLFFBQ0YsSUFBSSxTQUFVLFFBQVE7RUFDdkIsSUFBSSxPQUFPLFNBQVMsTUFBTSxHQUN0QixPQUFPO0VBRVgsSUFBSSxrQkFBa0IsV0FBVyxNQUFNO0VBQ3ZDLElBQUksbUJBQW1CLE9BQU8sU0FBUyxlQUFlLEdBQ2xELE9BQU87RUFFWCxRQUFRLE1BQU0sZUFBZSxRQUFRLDJCQUEyQixRQUFRLGlCQUFpQjtFQUN6RixPQUFPO0NBQ1gsQ0FBQyxDQUFDLENBQ0csT0FBTyxTQUFVLEdBQUc7RUFBRSxPQUFPLFFBQVEsQ0FBQztDQUFHLENBQUM7QUFDbkQ7Ozs7Ozs7OztBQVNBLElBQUkseUJBQXlCLFNBQVUsZ0JBQWdCLFlBQVksWUFBWSxrQkFBa0I7Q0FDN0YsSUFBSSxVQUFVLGVBQWUsWUFBWSxNQUFNLFFBQVEsY0FBYyxJQUFJLGlCQUFpQixDQUFDLGNBQWMsQ0FBQztDQUMxRyxJQUFJLENBQUMsVUFBVSxhQUNYLFVBQVUsOEJBQWMsSUFBSSxRQUFRO0NBRXhDLElBQUksZ0JBQWdCLFVBQVU7Q0FDOUIsSUFBSSxjQUFjLENBQUM7Q0FDbkIsSUFBSSxpQ0FBaUIsSUFBSSxJQUFJO0NBQzdCLElBQUksaUJBQWlCLElBQUksSUFBSSxPQUFPO0NBQ3BDLElBQUksT0FBTyxTQUFVLElBQUk7RUFDckIsSUFBSSxDQUFDLE1BQU0sZUFBZSxJQUFJLEVBQUUsR0FDNUI7RUFFSixlQUFlLElBQUksRUFBRTtFQUNyQixLQUFLLEdBQUcsVUFBVTtDQUN0QjtDQUNBLFFBQVEsUUFBUSxJQUFJO0NBQ3BCLElBQUksT0FBTyxTQUFVLFFBQVE7RUFDekIsSUFBSSxDQUFDLFVBQVUsZUFBZSxJQUFJLE1BQU0sR0FDcEM7RUFFSixNQUFNLFVBQVUsUUFBUSxLQUFLLE9BQU8sVUFBVSxTQUFVLE1BQU07R0FDMUQsSUFBSSxlQUFlLElBQUksSUFBSSxHQUN2QixLQUFLLElBQUk7UUFHVCxJQUFJO0lBQ0EsSUFBSSxPQUFPLEtBQUssYUFBYSxnQkFBZ0I7SUFDN0MsSUFBSSxnQkFBZ0IsU0FBUyxRQUFRLFNBQVM7SUFDOUMsSUFBSSxnQkFBZ0IsV0FBVyxJQUFJLElBQUksS0FBSyxLQUFLO0lBQ2pELElBQUksZUFBZSxjQUFjLElBQUksSUFBSSxLQUFLLEtBQUs7SUFDbkQsV0FBVyxJQUFJLE1BQU0sWUFBWTtJQUNqQyxjQUFjLElBQUksTUFBTSxXQUFXO0lBQ25DLFlBQVksS0FBSyxJQUFJO0lBQ3JCLElBQUksaUJBQWlCLEtBQUssZUFDdEIsa0JBQWtCLElBQUksTUFBTSxJQUFJO0lBRXBDLElBQUksZ0JBQWdCLEdBQ2hCLEtBQUssYUFBYSxZQUFZLE1BQU07SUFFeEMsSUFBSSxDQUFDLGVBQ0QsS0FBSyxhQUFhLGtCQUFrQixNQUFNO0dBRWxELFNBQ08sR0FBRztJQUNOLFFBQVEsTUFBTSxtQ0FBbUMsTUFBTSxDQUFDO0dBQzVEO0VBRVIsQ0FBQztDQUNMO0NBQ0EsS0FBSyxVQUFVO0NBQ2YsZUFBZSxNQUFNO0NBQ3JCO0NBQ0EsT0FBTyxXQUFZO0VBQ2YsWUFBWSxRQUFRLFNBQVUsTUFBTTtHQUNoQyxJQUFJLGVBQWUsV0FBVyxJQUFJLElBQUksSUFBSTtHQUMxQyxJQUFJLGNBQWMsY0FBYyxJQUFJLElBQUksSUFBSTtHQUM1QyxXQUFXLElBQUksTUFBTSxZQUFZO0dBQ2pDLGNBQWMsSUFBSSxNQUFNLFdBQVc7R0FDbkMsSUFBSSxDQUFDLGNBQWM7SUFDZixJQUFJLENBQUMsa0JBQWtCLElBQUksSUFBSSxHQUMzQixLQUFLLGdCQUFnQixnQkFBZ0I7SUFFekMsa0JBQWtCLE9BQU8sSUFBSTtHQUNqQztHQUNBLElBQUksQ0FBQyxhQUNELEtBQUssZ0JBQWdCLFVBQVU7RUFFdkMsQ0FBQztFQUNEO0VBQ0EsSUFBSSxDQUFDLFdBQVc7R0FFWiw2QkFBYSxJQUFJLFFBQVE7R0FDekIsNkJBQWEsSUFBSSxRQUFRO0dBQ3pCLG9DQUFvQixJQUFJLFFBQVE7R0FDaEMsWUFBWSxDQUFDO0VBQ2pCO0NBQ0o7QUFDSjs7Ozs7Ozs7QUFRQSxJQUFXLGFBQWEsU0FBVSxnQkFBZ0IsWUFBWSxZQUFZO0NBQ3RFLElBQUksZUFBZSxLQUFLLEdBQUssYUFBYTtDQUMxQyxJQUFJLFVBQVUsTUFBTSxLQUFLLE1BQU0sUUFBUSxjQUFjLElBQUksaUJBQWlCLENBQUMsY0FBYyxDQUFDO0NBQzFGLElBQUksbUJBQW1CLGNBQWMsaUJBQWlCLGNBQWM7Q0FDcEUsSUFBSSxDQUFDLGtCQUNELE9BQU8sV0FBWTtFQUFFLE9BQU87Q0FBTTtDQUl0QyxRQUFRLEtBQUssTUFBTSxTQUFTLE1BQU0sS0FBSyxpQkFBaUIsaUJBQWlCLHFCQUFxQixDQUFDLENBQUM7Q0FDaEcsT0FBTyx1QkFBdUIsU0FBUyxrQkFBa0IsWUFBWSxhQUFhO0FBQ3RGIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDYsNyw4LDksMTAsMTEsMTIsMTMsMTQsMTUsMTYsMTcsMTgsMTksMjAsMjEsMjIsMjNdfQ==