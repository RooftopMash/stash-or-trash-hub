import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PWAInstallButton.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { Download, Smartphone, X } from "/node_modules/.vite/deps/lucide-react.js?v=a8030269";
import { usePWAInstall } from "/src/hooks/usePWAInstall.ts";
import { Button } from "/src/components/ui/button.tsx";
var _jsxFileName = "/app/applet/src/components/PWAInstallButton.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
var _s = $RefreshSig$();
export function PWAInstallButton() {
	_s();
	const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
	const [showIOSGuide, setShowIOSGuide] = useState(false);
	// If already installed, hide the button
	if (isInstalled) {
		return null;
	}
	// Android / Windows / Desktop / Chrome flow
	if (isInstallable) {
		return /* @__PURE__ */ _jsxDEV(Button, {
			variant: "outline",
			size: "sm",
			onClick: () => void install(),
			className: "h-8 shrink-0 gap-1.5 border-[#d6a928]/40 bg-[#d6a928]/10 text-xs font-bold text-slate-900 hover:bg-[#d6a928]/20 dark:text-[#d6a928]",
			title: "Install SOrT App to Home Screen",
			"data-tsd-source": "/src/components/PWAInstallButton.tsx:18:7",
			children: [/* @__PURE__ */ _jsxDEV(Download, {
				className: "h-3.5 w-3.5 text-[#d6a928]",
				"data-tsd-source": "/src/components/PWAInstallButton.tsx:25:9"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "hidden sm:inline",
				"data-tsd-source": "/src/components/PWAInstallButton.tsx:26:9",
				children: "Install App"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 26,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 7
		}, this);
	}
	// iOS Safari flow
	if (isIOS) {
		return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Button, {
			variant: "outline",
			size: "sm",
			onClick: () => setShowIOSGuide(true),
			className: "h-8 shrink-0 gap-1.5 border-[#d6a928]/40 bg-[#d6a928]/10 text-xs font-bold text-slate-900 hover:bg-[#d6a928]/20 dark:text-[#d6a928]",
			title: "Install SOrT on iPhone or iPad",
			"data-tsd-source": "/src/components/PWAInstallButton.tsx:35:9",
			children: [/* @__PURE__ */ _jsxDEV(Smartphone, {
				className: "h-3.5 w-3.5 text-[#d6a928]",
				"data-tsd-source": "/src/components/PWAInstallButton.tsx:42:11"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "hidden sm:inline",
				"data-tsd-source": "/src/components/PWAInstallButton.tsx:43:11",
				children: "Get App"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 35,
			columnNumber: 9
		}, this), showIOSGuide && /* @__PURE__ */ _jsxDEV("div", {
			className: "fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs",
			"data-tsd-source": "/src/components/PWAInstallButton.tsx:47:11",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "relative w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-950",
				"data-tsd-source": "/src/components/PWAInstallButton.tsx:48:13",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setShowIOSGuide(false),
						className: "absolute right-4 top-4 rounded-full p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800",
						"aria-label": "Close",
						"data-tsd-source": "/src/components/PWAInstallButton.tsx:49:15",
						children: /* @__PURE__ */ _jsxDEV(X, {
							className: "h-4 w-4",
							"data-tsd-source": "/src/components/PWAInstallButton.tsx:54:17"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 54,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						"data-tsd-source": "/src/components/PWAInstallButton.tsx:57:15",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex h-10 w-10 items-center justify-center rounded-xl bg-[#d6a928]/20 text-[#d6a928]",
							"data-tsd-source": "/src/components/PWAInstallButton.tsx:58:17",
							children: /* @__PURE__ */ _jsxDEV(Download, {
								className: "h-5 w-5",
								"data-tsd-source": "/src/components/PWAInstallButton.tsx:59:19"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 59,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 58,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							"data-tsd-source": "/src/components/PWAInstallButton.tsx:61:17",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-display text-base font-bold text-slate-900 dark:text-white",
								"data-tsd-source": "/src/components/PWAInstallButton.tsx:62:19",
								children: "Install on iPhone / iPad"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500",
								"data-tsd-source": "/src/components/PWAInstallButton.tsx:65:19",
								children: "Run full-screen without app store limits"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-4 space-y-3 rounded-xl bg-slate-50 p-4 text-xs text-slate-700 dark:bg-slate-900 dark:text-slate-300",
						"data-tsd-source": "/src/components/PWAInstallButton.tsx:69:15",
						children: [
							/* @__PURE__ */ _jsxDEV("p", {
								className: "flex items-start gap-2",
								"data-tsd-source": "/src/components/PWAInstallButton.tsx:70:17",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-slate-200 text-[11px] font-bold text-slate-700 dark:bg-slate-800 dark:text-slate-300",
									"data-tsd-source": "/src/components/PWAInstallButton.tsx:71:19",
									children: "1"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 71,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									"data-tsd-source": "/src/components/PWAInstallButton.tsx:74:19",
									children: [
										"Tap the ",
										/* @__PURE__ */ _jsxDEV("strong", {
											"data-tsd-source": "/src/components/PWAInstallButton.tsx:75:29",
											children: "Share"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 75,
											columnNumber: 29
										}, this),
										" button at the bottom of Safari."
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 74,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 70,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "flex items-start gap-2",
								"data-tsd-source": "/src/components/PWAInstallButton.tsx:78:17",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-slate-200 text-[11px] font-bold text-slate-700 dark:bg-slate-800 dark:text-slate-300",
									"data-tsd-source": "/src/components/PWAInstallButton.tsx:79:19",
									children: "2"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									"data-tsd-source": "/src/components/PWAInstallButton.tsx:82:19",
									children: [
										"Scroll down and tap ",
										/* @__PURE__ */ _jsxDEV("strong", {
											"data-tsd-source": "/src/components/PWAInstallButton.tsx:83:41",
											children: "Add to Home Screen"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 83,
											columnNumber: 41
										}, this),
										"."
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 82,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "flex items-start gap-2",
								"data-tsd-source": "/src/components/PWAInstallButton.tsx:86:17",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-slate-200 text-[11px] font-bold text-slate-700 dark:bg-slate-800 dark:text-slate-300",
									"data-tsd-source": "/src/components/PWAInstallButton.tsx:87:19",
									children: "3"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 87,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									"data-tsd-source": "/src/components/PWAInstallButton.tsx:90:19",
									children: [
										"Tap ",
										/* @__PURE__ */ _jsxDEV("strong", {
											"data-tsd-source": "/src/components/PWAInstallButton.tsx:91:25",
											children: "Add"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 91,
											columnNumber: 25
										}, this),
										" in the top-right corner to launch SOrT as a native app!"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 90,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => setShowIOSGuide(false),
						className: "mt-5 w-full bg-slate-950 font-bold text-[#d6a928] hover:bg-slate-900",
						"data-tsd-source": "/src/components/PWAInstallButton.tsx:96:15",
						children: "Got It"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 96,
						columnNumber: 15
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 13
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 11
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 34,
			columnNumber: 7
		}, this);
	}
	return null;
}
_s(PWAInstallButton, "ZAH7gocAHpimxe++lNWUWsyp0eU=", false, function() {
	return [usePWAInstall];
});
_c = PWAInstallButton;
var _c;
$RefreshReg$(_c, "PWAInstallButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/PWAInstallButton.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/PWAInstallButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/PWAInstallButton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/PWAInstallButton.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7Ozs7QUFFQTs7Q0FDQTtDQUNBOztDQUdBO0VBQ0E7Q0FDQTs7Q0FHQTtFQUNBLE9BQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7YUFOQSxDQU9BO0lBQUE7SUFBQTtHQUF5RDs7OzthQUN6RDtJQUFBO0lBQUE7Y0FBMEM7R0FBQTs7OztXQUMxQzs7Ozs7O0NBRUE7O0NBR0E7RUFDQSxPQUNBLGdEQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO2FBTkEsQ0FPQTtJQUFBO0lBQUE7R0FBNkQ7Ozs7YUFDN0Q7SUFBQTtJQUFBO2NBQTRDO0dBQUE7Ozs7V0FDNUM7Ozs7O1lBRUEsZ0JBQ0E7R0FBQTtHQUFBO2FBQ0E7SUFBQTtJQUFBO2NBQUE7S0FDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO2dCQUNBO09BQUE7T0FBQTtNQUF1Qzs7Ozs7S0FDdkM7Ozs7O0tBRUE7TUFBQTtNQUFBO2dCQUFBLENBQ0E7T0FBQTtPQUFBO2lCQUNBO1FBQUE7UUFBQTtPQUFnRDs7Ozs7TUFDaEQ7Ozs7Z0JBQ0E7T0FBQTtpQkFBQSxDQUNBO1FBQUE7UUFBQTtrQkFBaUc7T0FFakc7Ozs7aUJBQ0E7UUFBQTtRQUFBO2tCQUF1RDtPQUFBOzs7O2VBQ3ZEOzs7OztjQUNBOzs7Ozs7S0FFQTtNQUFBO01BQUE7Z0JBQUE7T0FDQTtRQUFBO1FBQUE7a0JBQUEsQ0FDQTtTQUFBO1NBQUE7bUJBQTBMO1FBRTFMOzs7O2tCQUNBO1NBQUE7bUJBQUE7VUFBdUI7VUFDdkI7V0FBQTtxQkFBbUM7VUFBQTs7Ozs7VUFBQTtTQUNuQzs7Ozs7Z0JBQ0E7Ozs7OztPQUNBO1FBQUE7UUFBQTtrQkFBQSxDQUNBO1NBQUE7U0FBQTttQkFBMEw7UUFFMUw7Ozs7a0JBQ0E7U0FBQTttQkFBQTtVQUF1QjtVQUN2QjtXQUFBO3FCQUErQztVQUFBOzs7OztVQUFBO1NBQy9DOzs7OztnQkFDQTs7Ozs7O09BQ0E7UUFBQTtRQUFBO2tCQUFBLENBQ0E7U0FBQTtTQUFBO21CQUEwTDtRQUUxTDs7OztrQkFDQTtTQUFBO21CQUFBO1VBQXVCO1VBQ3ZCO1dBQUE7cUJBQStCO1VBQUE7Ozs7O1VBQUE7U0FDL0I7Ozs7O2dCQUNBOzs7Ozs7TUFDQTs7Ozs7O0tBRUE7TUFDQTtNQUNBO01BQ0E7Z0JBQWM7S0FFZDs7Ozs7SUFDQTs7Ozs7O0VBQ0E7Ozs7VUFFQTs7Ozs7Q0FFQTtDQUVBO0FBQ0EiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBXQUluc3RhbGxCdXR0b24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBEb3dubG9hZCwgU21hcnRwaG9uZSwgWCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHVzZVBXQUluc3RhbGwgfSBmcm9tIFwiQC9ob29rcy91c2VQV0FJbnN0YWxsXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuXG5leHBvcnQgZnVuY3Rpb24gUFdBSW5zdGFsbEJ1dHRvbigpIHtcbiAgY29uc3QgeyBpc0luc3RhbGxhYmxlLCBpc0luc3RhbGxlZCwgaXNJT1MsIGluc3RhbGwgfSA9IHVzZVBXQUluc3RhbGwoKTtcbiAgY29uc3QgW3Nob3dJT1NHdWlkZSwgc2V0U2hvd0lPU0d1aWRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyBJZiBhbHJlYWR5IGluc3RhbGxlZCwgaGlkZSB0aGUgYnV0dG9uXG4gIGlmIChpc0luc3RhbGxlZCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgLy8gQW5kcm9pZCAvIFdpbmRvd3MgLyBEZXNrdG9wIC8gQ2hyb21lIGZsb3dcbiAgaWYgKGlzSW5zdGFsbGFibGUpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPEJ1dHRvblxuICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IHZvaWQgaW5zdGFsbCgpfVxuICAgICAgICBjbGFzc05hbWU9XCJoLTggc2hyaW5rLTAgZ2FwLTEuNSBib3JkZXItWyNkNmE5MjhdLzQwIGJnLVsjZDZhOTI4XS8xMCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBob3ZlcjpiZy1bI2Q2YTkyOF0vMjAgZGFyazp0ZXh0LVsjZDZhOTI4XVwiXG4gICAgICAgIHRpdGxlPVwiSW5zdGFsbCBTT3JUIEFwcCB0byBIb21lIFNjcmVlblwiXG4gICAgICA+XG4gICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSB0ZXh0LVsjZDZhOTI4XVwiIC8+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmVcIj5JbnN0YWxsIEFwcDwvc3Bhbj5cbiAgICAgIDwvQnV0dG9uPlxuICAgICk7XG4gIH1cblxuICAvLyBpT1MgU2FmYXJpIGZsb3dcbiAgaWYgKGlzSU9TKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDw+XG4gICAgICAgIDxCdXR0b25cbiAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93SU9TR3VpZGUodHJ1ZSl9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHNocmluay0wIGdhcC0xLjUgYm9yZGVyLVsjZDZhOTI4XS80MCBiZy1bI2Q2YTkyOF0vMTAgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgaG92ZXI6YmctWyNkNmE5MjhdLzIwIGRhcms6dGV4dC1bI2Q2YTkyOF1cIlxuICAgICAgICAgIHRpdGxlPVwiSW5zdGFsbCBTT3JUIG9uIGlQaG9uZSBvciBpUGFkXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxTbWFydHBob25lIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHRleHQtWyNkNmE5MjhdXCIgLz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+R2V0IEFwcDwvc3Bhbj5cbiAgICAgICAgPC9CdXR0b24+XG5cbiAgICAgICAge3Nob3dJT1NHdWlkZSAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYmxhY2svNjAgcC00IGJhY2tkcm9wLWJsdXIteHNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LXNtIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXdoaXRlIHAtNiBzaGFkb3ctMnhsIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBkYXJrOmJnLXNsYXRlLTk1MFwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0lPU0d1aWRlKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC00IHRvcC00IHJvdW5kZWQtZnVsbCBwLTEgdGV4dC1zbGF0ZS00MDAgaG92ZXI6Ymctc2xhdGUtMTAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwXCJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiQ2xvc2VcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC0xMCB3LTEwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJnLVsjZDZhOTI4XS8yMCB0ZXh0LVsjZDZhOTI4XVwiPlxuICAgICAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgIEluc3RhbGwgb24gaVBob25lIC8gaVBhZFxuICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5SdW4gZnVsbC1zY3JlZW4gd2l0aG91dCBhcHAgc3RvcmUgbGltaXRzPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS0zIHJvdW5kZWQteGwgYmctc2xhdGUtNTAgcC00IHRleHQteHMgdGV4dC1zbGF0ZS03MDAgZGFyazpiZy1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaC01IHctNSBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLXNsYXRlLTIwMCB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazpiZy1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgVGFwIHRoZSA8c3Ryb25nPlNoYXJlPC9zdHJvbmc+IGJ1dHRvbiBhdCB0aGUgYm90dG9tIG9mIFNhZmFyaS5cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBoLTUgdy01IHNocmluay0wIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgYmctc2xhdGUtMjAwIHRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOmJnLXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICBTY3JvbGwgZG93biBhbmQgdGFwIDxzdHJvbmc+QWRkIHRvIEhvbWUgU2NyZWVuPC9zdHJvbmc+LlxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGgtNSB3LTUgc2hyaW5rLTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS0yMDAgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6Ymctc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgM1xuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgIFRhcCA8c3Ryb25nPkFkZDwvc3Ryb25nPiBpbiB0aGUgdG9wLXJpZ2h0IGNvcm5lciB0byBsYXVuY2ggU09yVCBhcyBhIG5hdGl2ZSBhcHAhXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0lPU0d1aWRlKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC01IHctZnVsbCBiZy1zbGF0ZS05NTAgZm9udC1ib2xkIHRleHQtWyNkNmE5MjhdIGhvdmVyOmJnLXNsYXRlLTkwMFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBHb3QgSXRcbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvPlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gbnVsbDtcbn1cbiJdLCJmaWxlIjoiL2FwcC9hcHBsZXQvc3JjL2NvbXBvbmVudHMvUFdBSW5zdGFsbEJ1dHRvbi50c3gifQ==