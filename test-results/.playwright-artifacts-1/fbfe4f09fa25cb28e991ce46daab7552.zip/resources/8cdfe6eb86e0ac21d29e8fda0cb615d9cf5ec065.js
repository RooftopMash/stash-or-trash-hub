"use client";
import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=a8030269";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=a8030269";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/react_jsx-runtime.js?v=a8030269";
import { t as Primitive } from "/node_modules/.vite/deps/dist-uZEDRbDH.js?v=a8030269";
//#region node_modules/@radix-ui/react-label/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", {
	value,
	configurable: true
});
var Label = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function Label2(props, forwardedRef) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.label, {
		...props,
		ref: forwardedRef,
		onMouseDown: (event) => {
			if (event.target.closest("button, input, select, textarea")) return;
			props.onMouseDown?.(event);
			if (!event.defaultPrevented && event.detail > 1) event.preventDefault();
		}
	});
}, "Label"));
var Root = Label;
//#endregion
export { Label, Root };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHJhZGl4LXVpX3JlYWN0LWxhYmVsLmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uL0ByYWRpeC11aS9yZWFjdC1sYWJlbC9kaXN0L2luZGV4Lm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBjbGllbnRcIjtcbnZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19uYW1lID0gKHRhcmdldCwgdmFsdWUpID0+IF9fZGVmUHJvcCh0YXJnZXQsIFwibmFtZVwiLCB7IHZhbHVlLCBjb25maWd1cmFibGU6IHRydWUgfSk7XG5cbi8vIHNyYy9sYWJlbC50c3hcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgUHJpbWl0aXZlIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1wcmltaXRpdmVcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xudmFyIExhYmVsID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gTGFiZWwyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgIFByaW1pdGl2ZS5sYWJlbCxcbiAgICAgIHtcbiAgICAgICAgLi4ucHJvcHMsXG4gICAgICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgICAgICBvbk1vdXNlRG93bjogKGV2ZW50KSA9PiB7XG4gICAgICAgICAgY29uc3QgdGFyZ2V0ID0gZXZlbnQudGFyZ2V0O1xuICAgICAgICAgIGlmICh0YXJnZXQuY2xvc2VzdChcImJ1dHRvbiwgaW5wdXQsIHNlbGVjdCwgdGV4dGFyZWFcIikpIHJldHVybjtcbiAgICAgICAgICBwcm9wcy5vbk1vdXNlRG93bj8uKGV2ZW50KTtcbiAgICAgICAgICBpZiAoIWV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQgJiYgZXZlbnQuZGV0YWlsID4gMSkgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICk7XG4gIH0sIFwiTGFiZWxcIilcbik7XG52YXIgUm9vdCA9IExhYmVsO1xuZXhwb3J0IHtcbiAgTGFiZWwsXG4gIFJvb3Rcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5tanMubWFwXG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQ0EsSUFBSSxZQUFZLE9BQU87QUFDdkIsSUFBSSxVQUFVLFFBQVEsVUFBVSxVQUFVLFFBQVEsUUFBUTtDQUFFO0NBQU8sY0FBYztBQUFLLENBQUM7QUFNdkYsSUFBSSxRQUF3Qiw2QkFBTSxXQUNoQix1QkFBTyxTQUFTLE9BQU8sT0FBTyxjQUFjO0NBQzFELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUNyQixVQUFVLE9BQ1Y7RUFDRSxHQUFHO0VBQ0gsS0FBSztFQUNMLGNBQWMsVUFBVTtHQUV0QixJQURlLE1BQU0sT0FDVixRQUFRLGlDQUFpQyxHQUFHO0dBQ3ZELE1BQU0sY0FBYyxLQUFLO0dBQ3pCLElBQUksQ0FBQyxNQUFNLG9CQUFvQixNQUFNLFNBQVMsR0FBRyxNQUFNLGVBQWU7RUFDeEU7Q0FDRixDQUNGO0FBQ0YsR0FBRyxPQUFPLENBQ1o7QUFDQSxJQUFJLE9BQU8iLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19