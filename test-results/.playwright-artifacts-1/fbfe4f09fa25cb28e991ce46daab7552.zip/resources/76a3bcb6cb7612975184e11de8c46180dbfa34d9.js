import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ProductScannerModal.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Dialog, DialogContent } from "/src/components/ui/dialog.tsx";
import { ProductAuthenticityCameraScanner } from "/src/components/ProductAuthenticityCameraScanner.tsx";
var _jsxFileName = "/app/applet/src/components/ProductScannerModal.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
export function ProductScannerModal({ open, onOpenChange, onApplyToPost }) {
	return /* @__PURE__ */ _jsxDEV(Dialog, {
		open,
		onOpenChange,
		"data-tsd-source": "/src/components/ProductScannerModal.tsx:28:5",
		children: /* @__PURE__ */ _jsxDEV(DialogContent, {
			className: "max-w-3xl max-h-[92vh] overflow-y-auto p-0 gap-0 border-border/80 bg-card",
			"data-tsd-source": "/src/components/ProductScannerModal.tsx:29:7",
			children: open && /* @__PURE__ */ _jsxDEV(ProductAuthenticityCameraScanner, {
				onApplyToPost,
				onClose: () => onOpenChange(false),
				"data-tsd-source": "/src/components/ProductScannerModal.tsx:31:11"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 5
	}, this);
}
_c = ProductScannerModal;
var _c;
$RefreshReg$(_c, "ProductScannerModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ProductScannerModal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/ProductScannerModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/ProductScannerModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/ProductScannerModal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsU0FDQSxRQUNBLHFCQUNBO0FBQ0E7OztBQWlCQSxzQ0FDQSxNQUNBLGNBQ0EsaUJBQ0E7Q0FDQSxPQUNBO0VBQUE7RUFBQTtFQUFBO1lBQ0E7R0FBQTtHQUFBO2FBQ0EsUUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUFVOzs7OztFQUVWOzs7OztDQUNBOzs7OztBQUVBIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcm9kdWN0U2Nhbm5lck1vZGFsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBEaWFsb2csXG4gIERpYWxvZ0NvbnRlbnQsXG59IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvZGlhbG9nXCI7XG5pbXBvcnQgeyBQcm9kdWN0QXV0aGVudGljaXR5Q2FtZXJhU2Nhbm5lciB9IGZyb20gXCJAL2NvbXBvbmVudHMvUHJvZHVjdEF1dGhlbnRpY2l0eUNhbWVyYVNjYW5uZXJcIjtcbmltcG9ydCB0eXBlIHsgQWlTY2FuUmVzdWx0IH0gZnJvbSBcIkAvbGliL2FpLXNjYW5uZXJcIjtcblxuaW50ZXJmYWNlIFByb2R1Y3RTY2FubmVyTW9kYWxQcm9wcyB7XG4gIG9wZW46IGJvb2xlYW47XG4gIG9uT3BlbkNoYW5nZTogKG9wZW46IGJvb2xlYW4pID0+IHZvaWQ7XG4gIG9uQXBwbHlUb1Bvc3Q/OiAocGFyYW1zOiB7XG4gICAgYnJhbmROYW1lOiBzdHJpbmc7XG4gICAgYnJhbmRPd25lcjogc3RyaW5nO1xuICAgIHByb2R1Y3ROYW1lOiBzdHJpbmc7XG4gICAgY2F0ZWdvcnk6IHN0cmluZztcbiAgICBtYXRjaGVkQnJhbmRJZD86IHN0cmluZztcbiAgICBmaWxlPzogRmlsZSB8IG51bGw7XG4gICAgc2NhblJlc3VsdDogQWlTY2FuUmVzdWx0O1xuICB9KSA9PiB2b2lkO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gUHJvZHVjdFNjYW5uZXJNb2RhbCh7XG4gIG9wZW4sXG4gIG9uT3BlbkNoYW5nZSxcbiAgb25BcHBseVRvUG9zdCxcbn06IFByb2R1Y3RTY2FubmVyTW9kYWxQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxEaWFsb2cgb3Blbj17b3Blbn0gb25PcGVuQ2hhbmdlPXtvbk9wZW5DaGFuZ2V9PlxuICAgICAgPERpYWxvZ0NvbnRlbnQgY2xhc3NOYW1lPVwibWF4LXctM3hsIG1heC1oLVs5MnZoXSBvdmVyZmxvdy15LWF1dG8gcC0wIGdhcC0wIGJvcmRlci1ib3JkZXIvODAgYmctY2FyZFwiPlxuICAgICAgICB7b3BlbiAmJiAoXG4gICAgICAgICAgPFByb2R1Y3RBdXRoZW50aWNpdHlDYW1lcmFTY2FubmVyXG4gICAgICAgICAgICBvbkFwcGx5VG9Qb3N0PXtvbkFwcGx5VG9Qb3N0fVxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gb25PcGVuQ2hhbmdlKGZhbHNlKX1cbiAgICAgICAgICAvPlxuICAgICAgICApfVxuICAgICAgPC9EaWFsb2dDb250ZW50PlxuICAgIDwvRGlhbG9nPlxuICApO1xufVxuIl0sImZpbGUiOiIvYXBwL2FwcGxldC9zcmMvY29tcG9uZW50cy9Qcm9kdWN0U2Nhbm5lck1vZGFsLnRzeCJ9