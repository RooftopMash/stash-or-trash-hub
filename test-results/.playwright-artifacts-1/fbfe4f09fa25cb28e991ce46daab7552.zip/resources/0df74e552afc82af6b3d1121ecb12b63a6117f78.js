import { isNotFound } from "/node_modules/@tanstack/router-core/dist/esm/not-found.js?v=a8030269";
import { isRedirect } from "/node_modules/@tanstack/router-core/dist/esm/redirect.js?v=a8030269";
import { hydrateSsrMatchId } from "/node_modules/@tanstack/router-core/dist/esm/ssr/ssr-match-id.js?v=a8030269";
import { getLocationChangeInfo, lifecycleEnd, runRouteLifecycle } from "/node_modules/@tanstack/router-core/dist/esm/router.js?v=a8030269";
//#region src/load-client.ts
function replaceRouteChunk(route, lazyFn) {
	route.lazyFn = lazyFn ?? route.lazyFn;
	route._lazy = void 0;
}
function preloadComponent(route, type) {
	return route.options[type]?.preload?.();
}
function loadComponents(route, onPendingReady) {
	const component = preloadComponent(route, "component");
	let pending = preloadComponent(route, "pendingComponent");
	if (onPendingReady) if (pending) pending = pending.then(onPendingReady);
	else onPendingReady();
	if (component && pending) return Promise.all([component, pending]).then(() => {});
	return component ?? pending;
}
function loadRouteChunk(route, componentType, onPendingReady) {
	const afterLazy = () => componentType === false ? void 0 : componentType ? preloadComponent(route, componentType) : loadComponents(route, onPendingReady);
	const current = route._lazy;
	if (current) return current === true ? afterLazy() : current.then(afterLazy);
	if (!route.lazyFn) return afterLazy();
	const promise = route.lazyFn().then((lazyRoute) => {
		if ("development" === "production" || route._lazy === promise) {
			const { id: _id, ...options } = lazyRoute.options;
			Object.assign(route.options, options);
			route._lazy = true;
		}
	}, (error) => {
		if ("development" === "production" || route._lazy === promise) route._lazy = void 0;
		throw error;
	});
	route._lazy = promise;
	return promise.then(afterLazy);
}
/** Return the structural lane through the first terminal render boundary. */
function _getRenderedMatches(matches) {
	const end = matches.findIndex((match) => match.status !== "success" || match._notFound) + 1;
	return end && end < matches.length ? matches.slice(0, end) : matches;
}
/** Return the lane whose document assets belong to the current presentation. */
function _getAssetMatches(matches) {
	let end = matches.length;
	for (let index = 0; index < end; index++) {
		const match = matches[index];
		if (match._assetEnd !== void 0) {
			end = Math.min(end, Math.max(index + 1, match._assetEnd));
			continue;
		}
		if (match.status !== "success" || match._notFound) {
			end = index + 1;
			break;
		}
	}
	return end < matches.length ? matches.slice(0, end) : matches;
}
const SUCCESS = 0;
const ERROR = 1;
const NOT_FOUND = 2;
const REDIRECTED = 3;
const CANCELED_OUTCOME = [4];
function isControl(result) {
	return typeof result[0] === "number";
}
function waitFor(value, signal) {
	if (signal.aborted) return Promise.race([Promise.reject(signal), value]);
	return new Promise((resolve, reject) => {
		const abort = () => reject(signal);
		signal.addEventListener("abort", abort, { once: true });
		Promise.resolve(value).then(resolve, reject).then(() => signal.removeEventListener("abort", abort));
	});
}
function getRoute(router, match) {
	return router.routesById[match.routeId];
}
function normalize(value, rejected, routeId) {
	if (isRedirect(value)) return [REDIRECTED, value];
	if (isNotFound(value)) {
		value.routeId ||= routeId;
		return [NOT_FOUND, value];
	}
	if (!rejected) return [SUCCESS, value];
	if (typeof value?.then === "function") value = new Error("A Promise was thrown", { cause: value });
	return [ERROR, value];
}
function normalizeError(route, cause) {
	let outcome = normalize(cause, true, route.id);
	if (outcome[0] !== ERROR) return outcome;
	try {
		route.options.onError?.(outcome[1]);
	} catch (onErrorCause) {
		outcome = normalize(onErrorCause, true, route.id);
	}
	return outcome;
}
function normalizeLaneError(router, lane, route, cause, options) {
	if (options[0].signal.aborted) return CANCELED_OUTCOME;
	return materializeRedirect(router, lane, route, normalizeError(route, cause), options);
}
async function contextualize(router, lane, options, end, planSuccessfulLane, retainedEnd) {
	const [location, matches] = lane;
	const signal = options[0].signal;
	const preload = !!options[3];
	for (let index = options[6] ?? 0; index < end; index++) {
		const match = matches[index];
		const route = getRoute(router, match);
		match.abortController = options[0];
		const parentContext = matches[index - 1]?.context ?? router.options.context ?? {};
		const common = {
			params: match.params,
			location,
			navigate: (opts) => router.navigate({
				...opts,
				_fromLocation: location
			}),
			buildLocation: router.buildLocation,
			cause: preload ? "preload" : match.cause,
			abortController: options[0],
			preload,
			matches,
			routeId: route.id
		};
		try {
			const routeContext = match._ctx ||= route.options.context ? route.options.context({
				...common,
				deps: match.loaderDeps,
				context: parentContext
			}) || {} : void 0;
			match.context = {
				...parentContext,
				...routeContext
			};
		} catch (cause) {
			releaseFlight(router, match);
			return [index, normalizeLaneError(router, lane, route, cause, options)];
		}
		if (signal.aborted) return [index, CANCELED_OUTCOME];
		const validationError = match.paramsError ?? match.searchError;
		if (validationError !== void 0) {
			releaseFlight(router, match);
			return [index, normalizeLaneError(router, lane, route, validationError, options)];
		}
		const beforeLoad = route.options.beforeLoad;
		if (!beforeLoad) continue;
		const previousStatus = match.status;
		if (index >= retainedEnd) {
			match.status = "pending";
			options[7]?.();
		}
		try {
			setFetching(router, match, "beforeLoad", options[0]);
			const value = beforeLoad({
				...common,
				search: match.search,
				context: match.context,
				...router.options.additionalContext
			});
			const result = await (typeof value?.then === "function" ? waitFor(value, signal) : value);
			if (signal.aborted) return [index, CANCELED_OUTCOME];
			const outcome = materializeRedirect(router, lane, route, normalize(result, false, route.id), options);
			if (outcome[0] !== SUCCESS) {
				releaseFlight(router, match);
				return [index, outcome];
			}
			match.context = {
				...match.context,
				...result
			};
		} catch (cause) {
			releaseFlight(router, match);
			return [index, normalizeLaneError(router, lane, route, cause, options)];
		} finally {
			match.status = previousStatus;
			setFetching(router, match, false, options[0]);
		}
	}
	planSuccessfulLane();
}
function releaseOwnedFlight(router, match, flight) {
	if (!flight || --flight[2]) return;
	if (router._flights?.get(match.id) === flight) {
		const current = router._tx;
		if (current && !current[0].signal.aborted && !current[3].includes(match) && current[3].some((candidate) => candidate.id === match.id) && current[3].some((candidate) => candidate.isFetching === "beforeLoad")) return;
		router._flights.delete(match.id);
	}
	return flight[1];
}
function releaseFlight(router, match) {
	const flight = match._flight;
	match._flight = void 0;
	releaseOwnedFlight(router, match, flight)?.abort();
}
/**
* Not passing in a `next` ownership recipient
* is equivalent to discarding the match resources
*/
function transferMatchResources(router, previous, next, deferSameIdFlight) {
	const abort = [];
	for (const match of previous) if (!next?.includes(match)) {
		const flight = match._flight;
		match._flight = void 0;
		if (deferSameIdFlight && flight?.[2] === 1 && router._flights?.get(match.id) === flight && next?.some((candidate) => candidate.id === match.id)) flight[2] = 0;
		else {
			const controller = releaseOwnedFlight(router, match, flight);
			if (controller) abort.push(controller);
		}
	}
	for (const controller of abort) controller.abort();
}
function acquireMatchResources(matches) {
	for (const match of matches) {
		const flight = match._flight;
		if (flight) flight[2]++;
	}
}
function setFetching(router, match, value, owner) {
	match.isFetching = value;
	if (owner && router._tx?.[0] !== owner) return;
	const store = router.stores.byRoute.get(match.routeId);
	const presented = store?.get();
	if (presented?.id === match.id) store.set({
		...presented,
		isFetching: value
	});
}
function getLoaderContext(router, lane, match, route, controller, parentMatchPromise, preload) {
	const location = lane[0];
	return {
		params: match.params,
		location,
		navigate: (opts) => router.navigate({
			...opts,
			_fromLocation: location
		}),
		cause: preload ? "preload" : match.cause,
		abortController: controller,
		preload,
		deps: match.loaderDeps,
		parentMatchPromise,
		context: match.context,
		route,
		...router.options.additionalContext
	};
}
async function loadResource(router, lane, match, route, loader, parentMatchPromise, options) {
	const owner = options[0];
	const signal = owner.signal;
	if (signal.aborted) return CANCELED_OUTCOME;
	if (!loader) return [SUCCESS, void 0];
	let flight = match._flight;
	setFetching(router, match, "loader", owner);
	try {
		if (!flight) {
			const controller = new AbortController();
			flight = [
				Promise.resolve().then(() => loader(getLoaderContext(router, lane, match, route, controller, parentMatchPromise, !!options[3]))).then((value) => normalize(value, false, route.id), (cause) => normalize(cause, true, route.id)).then((result) => {
					if (result[0] !== SUCCESS && router._flights?.get(match.id) === flight) {
						router._flights.delete(match.id);
						if (!flight[2]) controller.abort();
					}
					return result[0] === ERROR && flight[2] ? normalizeError(route, result[1]) : result;
				}),
				controller,
				1
			];
			(router._flights ??= /* @__PURE__ */ new Map()).set(match.id, flight);
		}
		match._flight = flight;
		match.abortController = flight[1];
		return materializeRedirect(router, lane, route, await waitFor(flight[0], signal), options);
	} catch (cause) {
		if (cause !== signal || !signal.aborted) throw cause;
		releaseFlight(router, match);
		return CANCELED_OUTCOME;
	} finally {
		setFetching(router, match, false, owner);
	}
}
function settleInto(match, result, preload) {
	if (result[0] === REDIRECTED) return;
	match.status = "success";
	match.error = void 0;
	if (result[0] === SUCCESS) {
		match.loaderData = result[1];
		match.invalid = false;
		match.updatedAt = Date.now();
		match.preload = preload;
	} else match.invalid = true;
}
function cacheLoaderMatch(router, match, planned) {
	const current = router._cache.get(match.id);
	if (current !== planned || router._committed.some((candidate) => candidate.id === match.id && candidate._flight === match._flight)) return;
	const cached = {
		...match,
		_notFound: void 0,
		context: {}
	};
	if (cached._flight) cached._flight[2]++;
	router._cache.set(match.id, cached);
	if (current) releaseFlight(router, current);
}
function getParentSnapshot(match, outcome) {
	if (outcome[0] === ERROR || outcome[0] === NOT_FOUND) return {
		...match,
		status: outcome[0] === ERROR ? "error" : "notFound",
		error: outcome[1],
		_flight: void 0
	};
	return match;
}
function createLoaderTask(router, lane, index, tasks, semanticParent, options, retainedEnd) {
	const match = lane[1][index];
	const route = getRoute(router, match);
	const preload = !!options[3];
	const plannedCacheMatch = router._cache.get(match.id);
	let configured;
	let reload = false;
	let reloadFailure;
	try {
		if (match.status === "success") {
			configured = route.options.shouldReload;
			if (typeof configured === "function") configured = configured(getLoaderContext(router, lane, match, route, options[0], semanticParent, preload));
			if (options[0].signal.aborted) reloadFailure = CANCELED_OUTCOME;
		}
		if (!reloadFailure) if (match.status !== "success") reload = true;
		else {
			const staleAge = preload || match.preload ? route.options.preloadStaleTime ?? router.options.defaultPreloadStaleTime ?? 3e4 : route.options.staleTime ?? router.options.defaultStaleTime ?? 0;
			reload = !!(match.invalid || configured || configured === void 0 && Date.now() - match.updatedAt >= staleAge && (options[5] || match.cause === "enter" || options[2].some((candidate) => candidate.routeId === match.routeId && candidate.id !== match.id)));
		}
	} catch (cause) {
		match.invalid = true;
		releaseFlight(router, match);
		reloadFailure = normalizeLaneError(router, lane, route, cause, options);
	}
	const routeLoader = route.options.loader;
	const isLoaderFn = typeof routeLoader === "function";
	const loader = isLoaderFn ? routeLoader : routeLoader?.handler;
	const preloadable = !preload || route.options.preload !== false;
	let donor = preloadable && routeLoader && !("development" !== "production" && router._tx?.[6]) ? router._flights?.get(match.id) : void 0;
	if (donor === match._flight || reloadFailure) donor = void 0;
	else if (donor && !reload && !preload && configured === void 0) reload = true;
	else if (!reload) donor = void 0;
	const background = !!(routeLoader && reload && match.status === "success" && !preload && !options[4] && ((isLoaderFn ? void 0 : routeLoader.staleReloadMode) ?? router.options.defaultStaleReloadMode) !== "blocking");
	const loaded = reload && preloadable;
	const blocking = loaded && !background && (match.status !== "success" || !!routeLoader);
	const onReady = index >= retainedEnd ? options[7] : void 0;
	const onLazyReady = route.lazyFn && route._lazy !== true ? onReady : void 0;
	if (loaded && !routeLoader) {
		match.invalid = false;
		match.updatedAt = Date.now();
	}
	if (donor) donor[2]++;
	if (blocking) {
		const acceptedFlight = match._flight;
		match._flight = donor;
		releaseOwnedFlight(router, match, acceptedFlight)?.abort();
		if (index >= retainedEnd) match.status = "pending";
		onReady?.();
	}
	if (!loaded) match.isFetching = false;
	const outcome = !reloadFailure && blocking ? loadResource(router, lane, match, route, loader, semanticParent, options).then((result) => {
		settleInto(match, result, preload);
		if (result[0] === SUCCESS) {
			if (routeLoader && !options[0].signal.aborted) cacheLoaderMatch(router, match, plannedCacheMatch);
			if (index >= retainedEnd) match.status = "pending";
		}
		return result;
	}) : Promise.resolve(reloadFailure ?? [SUCCESS, match.loaderData]);
	const chunkFailure = (async () => {
		try {
			const chunk = loadRouteChunk(route, void 0, onLazyReady);
			if (chunk) await waitFor(chunk, options[0].signal);
		} catch (cause) {
			if (!lane[1].some((candidate, candidateIndex) => candidateIndex <= index && (candidate.status === "error" || candidate.status === "notFound" || candidate._notFound))) return [index, normalizeLaneError(router, lane, route, cause, options)];
		}
		const result = await outcome;
		if (blocking && result[0] === SUCCESS && match.status === "pending" && !options[0].signal.aborted) {
			match.status = "success";
			onReady?.();
		}
	})();
	tasks.push([
		index,
		outcome,
		chunkFailure
	]);
	if (!background) return outcome.then((result) => getParentSnapshot(match, result));
	const candidate = {
		...match,
		status: "pending",
		preload: false,
		_flight: donor
	};
	match.invalid = false;
	match.isFetching = "loader";
	const backgroundOutcome = loadResource(router, lane, candidate, route, loader, semanticParent, options).then((result) => {
		match.isFetching = false;
		settleInto(candidate, result, false);
		return result;
	});
	(lane[2] ??= []).push([
		index,
		backgroundOutcome,
		chunkFailure,
		candidate
	]);
	return backgroundOutcome.then((result) => getParentSnapshot(candidate, result));
}
async function getNotFoundBoundary(router, matches, indexed, signal, fallback = 0) {
	const cause = indexed?.[1][1];
	let index = cause?.routeId ? matches.findIndex((match) => match.routeId === cause.routeId) : indexed?.[0] ?? matches.length - 1;
	if (index < 0) index = 0;
	for (let i = index; i >= 0; i--) {
		const route = getRoute(router, matches[i]);
		try {
			const loading = loadRouteChunk(route, false);
			if (loading) await waitFor(loading, signal);
		} catch (cause) {
			if (cause === signal && signal.aborted) throw cause;
		}
		if (route.options.notFoundComponent) return i;
	}
	return cause?.routeId ? index : fallback;
}
function discardBackground(router, lane) {
	if (lane[2]) {
		transferMatchResources(router, lane[2].map((task) => task[3]));
		lane[2] = void 0;
	}
}
async function settleTasks(tasks, serialFailure, redirectTasks, gate) {
	let loaderFailure;
	try {
		await Promise.all(tasks.map((task) => task[1].then(async (outcome) => {
			const taskIndex = task[0];
			if (gate && taskIndex >= await gate) return;
			if (outcome[0] >= REDIRECTED) throw [taskIndex, outcome];
			if (!loaderFailure && outcome[0] !== SUCCESS) {
				loaderFailure = [taskIndex, outcome];
				await Promise.all((redirectTasks ?? []).map((nextTask) => {
					if (nextTask[0] <= taskIndex) return;
					return nextTask[1].then((nextOutcome) => {
						if (nextOutcome[0] === REDIRECTED) throw [nextTask[0], nextOutcome];
					});
				}));
			}
		})));
	} catch (cause) {
		return cause;
	}
	return serialFailure ?? loaderFailure;
}
function materializeRedirect(router, lane, route, outcome, options, failed) {
	while (outcome[0] === REDIRECTED) {
		const redirect = outcome[1];
		const redirectOptions = redirect.options;
		try {
			if (redirectOptions.href || redirect.headers.has("Location")) {
				router.resolveRedirect(redirect);
				if (redirectOptions.reloadDocument) return outcome;
			}
			if (redirectOptions.reloadDocument ? options[3] : options[1] >= 20) return outcome;
			const location = router.buildLocation({
				...redirectOptions,
				_fromLocation: lane[0],
				_includeValidateSearch: true
			});
			const publicLocation = location.maskedLocation ?? location;
			if (publicLocation.external) {
				const resolved = redirect.clone();
				resolved.options = { ...redirectOptions };
				resolved.headers.set("Location", publicLocation.publicHref);
				router.resolveRedirect(resolved);
				return options[3] ? [REDIRECTED, resolved] : [
					REDIRECTED,
					resolved,
					publicLocation
				];
			}
			return [
				REDIRECTED,
				redirect,
				location
			];
		} catch (cause) {
			outcome = failed ? [ERROR, cause] : normalizeError(route, cause);
			failed = true;
		}
	}
	return outcome;
}
async function reduceLane(router, lane, tasks, controller, settlement, onReady) {
	const matches = lane[1];
	let failure = await settlement;
	let redirectLimitExceeded = false;
	const plannedBoundary = matches.findIndex((match) => match._notFound);
	const boundaryOf = (found) => found[1][0] === NOT_FOUND ? getNotFoundBoundary(router, matches, found, controller.signal) : found[0];
	let readinessEnd = plannedBoundary < 0 ? matches.length : plannedBoundary;
	if ((failure?.[1][0] ?? 0) >= REDIRECTED) readinessEnd = 0;
	else if (failure) {
		readinessEnd = failure[2] ??= await boundaryOf(failure);
		for (const task of tasks) {
			if (task[0] >= readinessEnd) break;
			const outcome = await task[1];
			if (outcome[0] !== SUCCESS && outcome[0] < REDIRECTED && !("loaderData" in matches[task[0]])) {
				failure = [task[0], outcome];
				readinessEnd = failure[2] = await boundaryOf(failure);
				break;
			}
		}
	}
	for (const task of tasks) {
		if (task[0] >= readinessEnd) break;
		const chunkFailure = await task[2];
		if (!chunkFailure) continue;
		failure = chunkFailure;
		break;
	}
	if ((failure?.[1][0] ?? 0) >= REDIRECTED) {
		const outcome = failure[1];
		if (outcome[0] !== REDIRECTED || outcome[1].options.reloadDocument || outcome[2]) {
			discardBackground(router, lane);
			return outcome;
		}
		redirectLimitExceeded = true;
		failure = [0, [ERROR, /* @__PURE__ */ new Error("Too many redirects")]];
	}
	const boundary = failure ? failure[2] ?? await boundaryOf(failure) : plannedBoundary;
	if (boundary >= 0) {
		const outcome = failure?.[1];
		const kind = outcome?.[0];
		const match = matches[boundary];
		const cause = outcome?.[1];
		const install = () => {
			if (outcome) {
				match._notFound = void 0;
				if (kind === ERROR) match.status = "error";
				else {
					cause.routeId = match.routeId;
					if (match.routeId === router.routeTree.id) {
						match.status = "success";
						match._notFound = true;
					} else match.status = "notFound";
				}
				match.error = cause;
				match.isFetching = false;
			}
		};
		install();
		if (!outcome) onReady?.();
		const route = getRoute(router, match);
		try {
			await waitFor(outcome ? Promise.resolve().then(() => loadRouteChunk(route, kind === ERROR ? "errorComponent" : "notFoundComponent")) : Promise.all([loadRouteChunk(route), loadRouteChunk(route, "notFoundComponent")]), controller.signal);
		} catch (cause) {
			if (cause === controller.signal && controller.signal.aborted) {
				discardBackground(router, lane);
				return CANCELED_OUTCOME;
			}
		}
		if (!outcome) match.status = "success";
		else if (redirectLimitExceeded) {
			controller.abort();
			await Promise.all([
				...tasks.map((task) => task[1]),
				...tasks.map((task) => task[2]),
				...(lane[2] ?? []).map((task) => task[1])
			]);
			discardBackground(router, lane);
			transferMatchResources(router, matches);
			install();
		}
	}
	return lane;
}
async function projectLane(router, lane, signal, start = 0, end = lane[1].length) {
	const matches = lane[1];
	for (let index = start; index < end; index++) {
		const match = matches[index];
		const routeOptions = getRoute(router, match).options;
		if (routeOptions.head || routeOptions.scripts) try {
			const context = {
				ssr: router.options.ssr,
				matches,
				match,
				params: match.params,
				loaderData: match.loaderData
			};
			const [head, scripts] = await waitFor(Promise.all([routeOptions.head?.(context), routeOptions.scripts?.(context)]), signal);
			match.meta = head?.meta;
			match.links = head?.links;
			match.headScripts = head?.scripts;
			match.styles = head?.styles;
			match.scripts = scripts;
		} catch (cause) {
			if (cause === signal && signal.aborted) break;
			console.error(cause);
		}
		if (match.status !== "success" || match._notFound) break;
	}
	return lane;
}
async function executeClientLane(router, location, matches, options) {
	const matched = [location, matches];
	const signal = options[0].signal;
	let reduced;
	try {
		const presented = router.stores.matches.get();
		let plannedBoundary = matches.findIndex((match) => match._notFound);
		if (router.options.notFoundMode !== "root" && plannedBoundary >= 0) {
			const boundary = await getNotFoundBoundary(router, matches, void 0, signal, plannedBoundary);
			matches[plannedBoundary]._notFound = void 0;
			matches[boundary]._notFound = true;
			plannedBoundary = boundary;
		}
		let end = plannedBoundary < 0 ? matches.length : plannedBoundary + 1;
		let retainedEnd = 0;
		while (retainedEnd < end && retainedEnd !== plannedBoundary) {
			const match = matches[retainedEnd];
			const committed = options[2][retainedEnd];
			const visible = presented[retainedEnd];
			if (committed?.id !== match.id || committed.status !== "success" || match.preload || visible?.id !== match.id || visible.status !== "success") break;
			retainedEnd++;
			if (committed._notFound || visible._notFound) break;
		}
		const tasks = [];
		const start = options[6] ?? 0;
		let semanticParent = start ? Promise.resolve(matches[start - 1]) : void 0;
		const planSuccessfulLane = () => {
			for (let index = start; index < end; index++) {
				if (signal.aborted) break;
				semanticParent = createLoaderTask(router, matched, index, tasks, semanticParent, options, retainedEnd);
			}
		};
		const failure = await contextualize(router, matched, options, end, planSuccessfulLane, retainedEnd);
		if (failure) {
			options[4] = true;
			end = failure[0];
			if (failure[1][0] === NOT_FOUND) {
				const boundary = await getNotFoundBoundary(router, matches, failure, signal);
				failure[2] = boundary;
				end = Math.min(end, boundary + 1);
			} else if (failure[1][0] >= REDIRECTED) end = 0;
			planSuccessfulLane();
		}
		if (!signal.aborted && !options[3]) {
			const abort = [];
			for (const [id, flight] of router._flights ?? []) if (!flight[2]) {
				router._flights.delete(id);
				abort.push(flight[1]);
			}
			for (const controller of abort) controller.abort();
		}
		const reduction = reduceLane(router, matched, tasks, options[0], settleTasks(tasks, failure, matched[2]), options[7]);
		if (matched[2]?.length) matched[3] = settleTasks(matched[2], void 0, void 0, reduction.then((foreground) => isControl(foreground) ? 0 : _getRenderedMatches(matches).length, () => 0));
		reduced = await reduction;
	} catch (cause) {
		discardBackground(router, matched);
		if (cause === signal && signal.aborted) return CANCELED_OUTCOME;
		throw cause;
	}
	if (isControl(reduced)) return reduced;
	return projectLane(router, reduced, signal, options[6] === matches.length ? options[6] : 0);
}
/**
* Waits for `pendingMs`, then presents the complete lane. Rendering applies the
* selected boundary cutoff while retaining every match's structural state.
* A replacement load for the same match keeps the timer; choosing a different
* match resets it. `pendingMinMs` starts after the fallback renders.
*/
function offerPending(router, tx) {
	if (router._tx !== tx) return;
	const matches = tx[3];
	const presented = router.stores.matches.get();
	let session = router._pending;
	for (let index = 0; index < matches.length; index++) {
		const match = matches[index];
		const success = match.status === "success" && !match._notFound;
		const presentedPending = presented[index]?.id === match.id && presented[index]?.status === "pending";
		if (success && !presentedPending) continue;
		const route = getRoute(router, match);
		const delay = success || match.invalid ? 0 : route.options.pendingMs ?? router.options.defaultPendingMs;
		const component = route.options.pendingComponent ?? router.options.defaultPendingComponent;
		if (!component || typeof delay !== "number" || delay === Infinity) {
			if (session) {
				session[0] = tx;
				session[2] = 0;
				session[4] = true;
			}
			return;
		}
		const min = route.options.pendingMinMs ?? router.options.defaultPendingMinMs ?? 0;
		let tookOver = false;
		if (session?.[1] === match.id) {
			tookOver = session[0] !== tx;
			session[0] = tx;
		} else {
			clearTimeout(session?.[3]);
			router._pending = session = void 0;
		}
		if (!session) router._pending = session = [
			tx,
			match.id,
			presentedPending ? Date.now() + min : tx[4] + delay,
			void 0,
			presentedPending || void 0,
			component
		];
		if (session[4] && !tookOver && session[5] === component) return;
		session[5] = component;
		if (!session[4]) {
			clearTimeout(session[3]);
			const remaining = session[2] - Date.now();
			if (remaining > 0) {
				session[3] = setTimeout(() => offerPending(router, tx), remaining);
				return;
			}
			session[2] = 0;
		}
		const offered = matches.map((match) => ({
			...match,
			_flight: void 0
		}));
		offered[index].status = "pending";
		const ack = session[4] = router.startTransition(() => router.stores.setMatches(offered), offered).then((rendered) => {
			if (rendered && router._pending === session && session[4] === ack && !session[2]) session[2] = Date.now() + min;
			return rendered;
		});
		return;
	}
}
/**
* Cancels pending UI timing unless the current successor can take over the
* same boundary that remains painted.
*/
function finishPending(router, tx) {
	const session = router._pending;
	if (router._tx === tx || !router._tx?.[3].some((match) => match.id === session?.[1])) {
		clearTimeout(session?.[3]);
		router._pending = void 0;
	}
}
async function awaitPendingMinimum(router, tx) {
	const session = router._pending;
	if (!session) return;
	clearTimeout(session[3]);
	const remaining = session[2] - Date.now();
	if (!session[4] || remaining <= 0 || !_getRenderedMatches(tx[3]).some((match) => match.id === session[1])) return;
	let timer;
	try {
		await waitFor(new Promise((resolve) => {
			timer = setTimeout(resolve, remaining);
		}), tx[0].signal);
	} catch {}
	clearTimeout(timer);
}
function publishMatches(router, matches) {
	router._committed = matches;
	router.stores.setMatches(matches);
}
function commitMatches(router, tx, matches, resolvedPrefix) {
	const previous = router._committed;
	const previousEnd = router._lifecycleEnd;
	const previousCached = router._cache;
	for (const match of matches) {
		match.preload = false;
		if (resolvedPrefix) match._assetEnd = void 0;
	}
	const cut = _getRenderedMatches(matches).length;
	const cached = /* @__PURE__ */ new Map();
	if ("development" === "production" || !tx[6]) {
		const now = Date.now();
		const superseded = /* @__PURE__ */ new Set();
		for (let index = 0; index < matches.length; index++) {
			const match = matches[index];
			if (index < cut || match.status === "success") superseded.add(match.id);
		}
		for (const match of [...previous, ...previousCached.values()]) {
			if (match.status !== "success" || superseded.has(match.id)) continue;
			const route = getRoute(router, match);
			if (!route.options.loader || now - match.updatedAt >= (match.preload ? route.options.preloadGcTime ?? router.options.defaultPreloadGcTime ?? 3e5 : route.options.gcTime ?? router.options.defaultGcTime ?? 3e5)) continue;
			cached.set(match.id, previousCached.get(match.id) === match ? match : {
				...match,
				_flight: void 0,
				isFetching: false,
				context: {}
			});
		}
	}
	tx[3] = [];
	router._cache = cached;
	const nextEnd = router._lifecycleEnd = lifecycleEnd(matches);
	publishMatches(router, matches);
	transferMatchResources(router, [...previousCached.values(), ...previous].filter((match) => match._flight && cached.get(match.id) !== match), matches);
	if ("development" !== "production") {
		const handoff = tx[6]?.[0];
		if (handoff && router._handoff === handoff) handoff[1]();
	}
	runRouteLifecycle(router, previous, matches, previousEnd, nextEnd, tx);
}
/**
* Resolve once the router has settled on a transaction other than `owner`.
* Each transaction's completion follows its current successor, so all waiters
* share the same chain instead of polling every successor independently.
*/
async function awaitCurrent(router, owner) {
	let current = router._tx;
	while (current && current !== owner) {
		owner = current;
		await current[5];
		current = router._tx;
	}
}
function followRedirect(router, tx, outcome) {
	const options = outcome[1].options;
	const location = outcome[2];
	if (!location) return router.navigate({
		...options,
		replace: true,
		ignoreBlocker: true
	});
	if (options.reloadDocument) return router.navigate({
		href: (location.maskedLocation ?? location).publicHref,
		reloadDocument: true,
		replace: true,
		ignoreBlocker: true
	});
	location._redirects = tx[1] + 1;
	router._pendingLocation = location;
	const committed = router.commitLocation({
		...location,
		viewTransition: options.viewTransition,
		replace: true,
		resetScroll: options.resetScroll,
		hashScrollIntoView: options.hashScrollIntoView,
		ignoreBlocker: true
	});
	queueMicrotask(() => {
		if (router._pendingLocation === location) router._pendingLocation = void 0;
	});
	return committed;
}
async function runBackground(router, tx, base, tasks, settlement) {
	const next = base.map((match) => ({ ...match }));
	acquireMatchResources(next);
	for (const task of tasks) {
		releaseFlight(router, next[task[0]]);
		next[task[0]] = task[3];
	}
	const lane = [tx[2], next];
	let reduced;
	try {
		reduced = await reduceLane(router, lane, tasks, tx[0], settlement);
	} catch (cause) {
		transferMatchResources(router, next);
		throw cause;
	}
	if (isControl(reduced)) {
		transferMatchResources(router, next);
		if (reduced[0] === REDIRECTED && router._tx === tx && router._committed === base) await followRedirect(router, tx, reduced);
		return;
	}
	await projectLane(router, reduced, tx[0].signal);
	if (router._tx !== tx || router._committed !== base) {
		transferMatchResources(router, next);
		return;
	}
	for (const match of next) {
		const cached = router._cache.get(match.id);
		if (cached?._flight && cached._flight === match._flight) {
			router._cache.delete(match.id);
			releaseFlight(router, cached);
		}
	}
	publishMatches(router, next);
	transferMatchResources(router, base, next);
}
async function runClientTransaction(router, tx, forceStaleReload, onReady, sync, resolvedPrefix) {
	const result = await executeClientLane(router, tx[2], tx[3], [
		tx[0],
		tx[1],
		router._committed,
		void 0,
		sync,
		forceStaleReload,
		resolvedPrefix,
		onReady
	]);
	if (isControl(result)) {
		const follow = result[0] === REDIRECTED && router._tx === tx;
		if (!follow || result[1].options.reloadDocument) finishPending(router, tx);
		transferMatchResources(router, tx[3]);
		tx[3] = [];
		if (!follow) return;
		if (router._tx !== tx) {
			finishPending(router, tx);
			return;
		}
		if ("development" !== "production" && tx[6]) router._refreshNextLoad = true;
		await followRedirect(router, tx, result);
		return;
	}
	const matches = result[1];
	if (router._tx === tx) await awaitPendingMinimum(router, tx);
	if (router._tx !== tx) {
		finishPending(router, tx);
		transferMatchResources(router, matches);
		discardBackground(router, result);
		return;
	}
	const toLocation = tx[2];
	const changeInfo = getLocationChangeInfo(toLocation, router.stores.resolvedLocation.get());
	const background = result[2];
	await router.startViewTransition(async () => {
		if (router._tx === tx) await awaitPendingMinimum(router, tx);
		if (router._tx !== tx) {
			finishPending(router, tx);
			transferMatchResources(router, matches);
			discardBackground(router, result);
			return;
		}
		const commit = () => {
			finishPending(router, tx);
			commitMatches(router, tx, matches, resolvedPrefix);
			if (router._tx !== tx) return;
			router.emit({
				type: "onLoad",
				...changeInfo
			});
			if (router._tx === tx) router.emit({
				type: "onBeforeRouteMount",
				...changeInfo
			});
		};
		const rendered = await router.startTransition(commit, matches);
		if ("development" !== "production" && tx[6]) tx[6] = void 0;
		if (router._tx !== tx) {
			discardBackground(router, result);
			return;
		}
		if (background?.length) runBackground(router, tx, matches, background, result[3]).catch(console.error);
		router.batch(() => {
			router.stores.resolvedLocation.set(toLocation);
			router.stores.status.set("idle");
			if (router._tx === tx) router.emit({
				type: "onResolved",
				...changeInfo
			});
			if (rendered && router._tx === tx) router.emit({
				type: "onRendered",
				...changeInfo
			});
		});
		if (router._tx !== tx) return;
		router._commitPromise?.resolve();
		router._commitPromise = void 0;
	});
}
async function loadClientRoute(router, opts) {
	let rematerialize = false;
	if ("development" !== "production") rematerialize = !!router._refreshNextLoad || !!router._tx?.[6];
	const previousOwner = router._tx;
	const resolvedLocation = router.stores.resolvedLocation.get();
	const previousLocation = resolvedLocation ?? router.stores.location.get();
	const location = router.latestLocation;
	const pendingLocation = router._pendingLocation;
	const redirects = pendingLocation?.href === location.href ? pendingLocation._redirects ?? 0 : 0;
	const handoff = router._handoff;
	const hydrationController = rematerialize ? void 0 : handoff?.[0]();
	const preflight = new AbortController();
	const previousPreflight = router._preflight;
	router._preflight = preflight;
	if (!rematerialize && !hydrationController) handoff?.[1]();
	previousPreflight?.abort();
	if (!preflight.signal.aborted) {
		const changeInfo = getLocationChangeInfo(location, resolvedLocation);
		router.emit({
			type: "onBeforeNavigate",
			...changeInfo
		});
		if (!preflight.signal.aborted) router.emit({
			type: "onBeforeLoad",
			...changeInfo
		});
	}
	if (preflight.signal.aborted) {
		await awaitCurrent(router, previousOwner);
		return;
	}
	const sameHref = previousLocation.href === location.href;
	let controller = preflight;
	const matches = "development" !== "production" && rematerialize ? router.matchRoutes(location, {
		_controller: preflight,
		_rematerialize: true
	}) : router.matchRoutes(location, { _controller: preflight });
	acquireMatchResources(matches);
	const resolvedPrefix = hydrationController ? handoff[1](matches) : void 0;
	if (resolvedPrefix) controller = hydrationController;
	else hydrationController?.abort();
	if (preflight.signal.aborted) {
		transferMatchResources(router, matches);
		await awaitCurrent(router, previousOwner);
		return;
	}
	router._preflight = void 0;
	let settle;
	const run = () => runClientTransaction(router, tx, sameHref, () => offerPending(router, tx), opts?.sync, resolvedPrefix);
	const done = opts?.sync ? new Promise((resolve) => settle = resolve) : Promise.resolve().then(run);
	const tx = [
		controller,
		redirects,
		location,
		matches,
		Date.now(),
		done.then(() => awaitCurrent(router, tx))
	];
	if ("development" !== "production" && rematerialize) {
		tx[6] = [handoff];
		router._refreshNextLoad = void 0;
	}
	router._tx = tx;
	if (previousOwner) {
		for (const match of router.stores.matches.get()) {
			if (router._tx !== tx) break;
			if (match.isFetching) setFetching(router, match, false);
		}
		previousOwner[0].abort();
		transferMatchResources(router, previousOwner[3], tx[3], true);
	}
	if (router._tx !== tx) {
		transferMatchResources(router, tx[3]);
		tx[3] = [];
		settle?.();
		await awaitCurrent(router, tx);
		return;
	}
	router.batch(() => {
		router.stores.status.set("pending");
		router.stores.location.set(location);
	});
	if (resolvedPrefix || !router._committed.length && matches[0]?.status !== "success" && !matches.some((match) => match._notFound)) offerPending(router, tx);
	settle?.(run());
	await tx[5];
}
async function refreshClientRoute(router) {
	const pending = router._tx;
	if (pending && !pending[6] && router.stores.status.get() === "pending") {
		await pending[5];
		if (router._tx !== pending) await awaitCurrent(router, pending);
	}
	router._flights?.clear();
	router.clearCache();
	router._refreshNextLoad = true;
	await loadClientRoute(router, { sync: true });
}
async function preloadClientRoute(router, opts) {
	if ("development" !== "production" && (router._refreshNextLoad || router._tx?.[6])) return;
	let location = router.buildLocation(opts);
	for (let redirects = 0;; redirects++) {
		const base = router._committed;
		const controller = new AbortController();
		let matches;
		let active;
		let result;
		try {
			try {
				matches = router.matchRoutes(location, { _controller: controller });
				acquireMatchResources(matches);
				active = (router._preloads ??= /* @__PURE__ */ new Map()).set(controller, matches);
				result = await executeClientLane(router, location, matches, [
					controller,
					redirects,
					base,
					true
				]);
			} finally {
				if (active) {
					active = active.delete(controller);
					transferMatchResources(router, matches);
				}
				controller.abort();
			}
			if (!isControl(result)) return result[1];
			if (!active || result.length < 3 || "development" !== "production" && (router._refreshNextLoad || router._tx?.[6])) return;
			location = result[2];
		} catch (cause) {
			if (!isNotFound(cause)) console.error(cause);
			return;
		}
	}
}
async function hydrate(router) {
	if ("development" !== "production" && !window.$_TSR) throw new Error("Invariant failed: Expected to find bootstrap data on window.$_TSR, but we did not. Please file an issue!");
	const tsr = window.$_TSR;
	const adapters = router.options.serializationAdapters;
	if (adapters?.length) {
		tsr.t = new Map(adapters.map((adapter) => [adapter.key, adapter.fromSerializable]));
		tsr.buffer.forEach((script) => script());
	}
	tsr.initialized = true;
	const dehydratedRouter = tsr.router;
	if ("development" !== "production" && !dehydratedRouter) throw new Error("Invariant failed: Expected to find a dehydrated data on window.$_TSR.router, but we did not. Please file an issue!");
	router.ssr = { manifest: dehydratedRouter.manifest };
	router.options.ssr = { nonce: document.querySelector("meta[property=\"csp-nonce\"]")?.content };
	const dehydratedMatches = dehydratedRouter.matches;
	const controller = new AbortController();
	const previousPreflight = router._preflight;
	router._preflight = controller;
	previousPreflight?.abort();
	const isCurrent = () => router._preflight === controller;
	let location;
	let candidates;
	let handoffHistoryHref;
	let handoffHistoryState;
	try {
		await waitFor(router.options.hydrate?.(dehydratedRouter.dehydratedData), controller.signal);
		if (!isCurrent()) return;
		const historyLocation = router.history.location;
		handoffHistoryHref = historyLocation.href;
		handoffHistoryState = historyLocation.state;
		router.updateLatestLocation();
		location = router.latestLocation;
		router.stores.location.set(location);
		candidates = router.matchRoutes(location, { _controller: controller });
	} catch (cause) {
		if (isCurrent()) router._preflight = void 0;
		controller.abort(cause);
		if (cause !== controller.signal) throw cause;
	}
	if (!isCurrent()) return;
	const committed = [];
	let pendingBoundary;
	let verifiedAssetEnd = 0;
	const retryFrom = (index) => {
		verifiedAssetEnd = Math.min(verifiedAssetEnd, index + 1);
		const removed = committed.splice(index);
		for (const match of removed) if (getRoute(router, match).options.loader && (match.status === "success" || !match.invalid && "loaderData" in match)) cacheLoaderMatch(router, {
			...match,
			status: "success",
			error: void 0,
			preload: true
		}, router._cache.get(match.id));
		transferMatchResources(router, removed);
	};
	const shared = dehydratedMatches.length > candidates.length ? candidates.findIndex((match) => match._notFound) + 1 : dehydratedMatches.length;
	let isTerminal = false;
	for (let index = 0; index < shared; index++) {
		const candidate = candidates[index];
		const dehydrated = dehydratedMatches[index];
		if (typeof dehydrated.i !== "string" || hydrateSsrMatchId(dehydrated.i) !== candidate.id) {
			pendingBoundary ??= index;
			break;
		}
		verifiedAssetEnd = index + 1;
		const route = getRoute(router, candidate);
		if ("l" in dehydrated || dehydrated.s === "success" && dehydrated.e === void 0 && route.options.loader) candidate.loaderData = dehydrated.l;
		candidate.status = dehydrated.s;
		candidate.ssr = dehydrated.ssr;
		route.options.ssr = candidate.ssr;
		candidate.updatedAt = dehydrated.u;
		candidate.error = dehydrated.e;
		candidate._notFound ||= dehydrated.g;
		if (candidate.status === "error" || candidate.status === "notFound" || candidate._notFound) {
			isTerminal = true;
			committed.push(candidate);
			if (candidate.ssr === false || candidate.ssr === "data-only") pendingBoundary ??= index;
			break;
		}
		if (candidate.status === "pending") {
			pendingBoundary ??= index;
			break;
		}
		committed.push(candidate);
		if (candidate.ssr === "data-only") pendingBoundary ??= index;
	}
	if (!isTerminal && committed.length === shared && shared < candidates.length) pendingBoundary = shared;
	const chunks = committed.map(async (match) => {
		try {
			const route = getRoute(router, match);
			await (match._notFound ? Promise.all([loadRouteChunk(route), loadRouteChunk(route, "notFoundComponent")]) : loadRouteChunk(route, match.status === "error" ? "errorComponent" : match.status === "notFound" ? "notFoundComponent" : void 0));
			return true;
		} catch {
			return false;
		}
	});
	let chunkFailure = 0;
	try {
		while (chunkFailure < chunks.length && await waitFor(chunks[chunkFailure], controller.signal)) chunkFailure++;
	} catch {
		return;
	}
	if (!isCurrent()) return;
	if (chunkFailure < committed.length) retryFrom(chunkFailure);
	const contextEnd = Math.max(pendingBoundary === committed.length ? committed.length + 1 : committed.length, chunkFailure < chunks.length ? chunkFailure : verifiedAssetEnd);
	for (let index = 0; index < contextEnd; index++) {
		const match = candidates[index];
		const route = getRoute(router, match);
		const parentContext = candidates[index - 1]?.context ?? router.options.context ?? {};
		let routeContext;
		if (route.options.context) {
			try {
				routeContext = match._ctx = route.options.context({
					deps: match.loaderDeps,
					params: match.params,
					context: parentContext,
					location,
					navigate: (opts) => router.navigate({
						...opts,
						_fromLocation: location
					}),
					buildLocation: router.buildLocation,
					cause: match.cause,
					abortController: controller,
					preload: false,
					matches: candidates,
					routeId: route.id
				}) || {};
			} catch {
				if (!isCurrent()) return;
				if (match.status !== "error" && match.status !== "notFound" && !match._notFound) {
					pendingBoundary = Math.min(pendingBoundary ?? index, index);
					retryFrom(index);
					break;
				}
			}
			if (!isCurrent()) return;
		}
		match.context = {
			...parentContext,
			...routeContext,
			...committed[index] && dehydratedMatches[index].b
		};
	}
	await projectLane(router, [location, candidates], controller.signal, 0, verifiedAssetEnd);
	if (!isCurrent()) return;
	const needsClientLoad = pendingBoundary !== void 0 || committed.length < shared;
	const committedMatches = isTerminal && committed.length === shared ? candidates : committed;
	let presented = needsClientLoad ? candidates : committedMatches;
	let dataOnlyAssetEnd;
	if (needsClientLoad && pendingBoundary !== void 0) {
		const boundary = presented[pendingBoundary];
		dataOnlyAssetEnd = boundary.ssr === "data-only" && verifiedAssetEnd > pendingBoundary + 1 ? verifiedAssetEnd : void 0;
		presented = presented.slice();
		presented[pendingBoundary] = {
			...boundary,
			status: "pending",
			ssr: boundary.ssr === "data-only" ? "data-only" : false,
			_assetEnd: dataOnlyAssetEnd
		};
	}
	const claim = () => {
		const historyLocation = router.history.location;
		return needsClientLoad && !router._tx && historyLocation.href === handoffHistoryHref && historyLocation.state === handoffHistoryState && router._committed === committedMatches && committedMatches.length && !controller.signal.aborted ? controller : void 0;
	};
	const handoff = [claim, (matches) => {
		if (router._handoff !== handoff) return;
		router._handoff = void 0;
		const prefix = committedMatches.length;
		if (!matches || !claim() || committedMatches.some((match, index) => match.id !== matches[index]?.id)) {
			controller.abort();
			return;
		}
		let handoffAssetEnd = dataOnlyAssetEnd;
		if (handoffAssetEnd !== void 0) {
			for (let index = prefix; index < handoffAssetEnd; index++) if (candidates[index]?.id !== matches[index]?.id) {
				handoffAssetEnd = index > pendingBoundary + 1 ? index : void 0;
				break;
			}
		}
		const clones = committedMatches.map((match) => ({ ...match }));
		if (handoffAssetEnd !== void 0) clones[pendingBoundary]._assetEnd = handoffAssetEnd;
		transferMatchResources(router, matches.splice(0, prefix, ...clones));
		for (let index = prefix; index < matches.length; index++) {
			const match = matches[index];
			const hydrated = candidates[index];
			if (hydrated?.id === match.id && hydrated._ctx) match._ctx = hydrated._ctx;
			match.abortController = controller;
		}
		return prefix;
	}];
	router._committed = committedMatches;
	router._lifecycleEnd = lifecycleEnd(committedMatches);
	router._handoff = handoff;
	router._preflight = void 0;
	router.batch(() => {
		router.stores.setMatches(presented);
		router.stores.status.set("idle");
		if (!needsClientLoad) router.stores.resolvedLocation.set(router.stores.location.get());
	});
}
//#endregion
export { _getAssetMatches, _getRenderedMatches, hydrate, loadClientRoute, loadRouteChunk, preloadClientRoute, refreshClientRoute, replaceRouteChunk };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7QUFpQ0EsU0FBZ0Isa0JBQ2QsT0FDQSxRQUNNO0NBQ04sTUFBTSxTQUFTLFVBQVUsTUFBTTtDQUMvQixNQUFNLFFBQVE7QUFDaEI7QUFFQSxTQUFTLGlCQUNQLE9BQ0EsTUFDMkI7Q0FDM0IsT0FBUSxNQUFNLFFBQVEsT0FBZSxVQUFVO0FBQ2pEO0FBRUEsU0FBUyxlQUNQLE9BQ0EsZ0JBQzJCO0NBQzNCLE1BQU0sWUFBWSxpQkFBaUIsT0FBTyxXQUFXO0NBQ3JELElBQUksVUFBVSxpQkFBaUIsT0FBTyxrQkFBa0I7Q0FDeEQsSUFBSSxnQkFDRixJQUFJLFNBQ0YsVUFBVSxRQUFRLEtBQUssY0FBYztNQUVyQyxlQUFlO0NBR25CLElBQUksYUFBYSxTQUNmLE9BQU8sUUFBUSxJQUFJLENBQUMsV0FBVyxPQUFPLENBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQztDQUV4RCxPQUFPLGFBQWE7QUFDdEI7QUFFQSxTQUFnQixlQUNkLE9BRUEsZUFDQSxnQkFDMkI7Q0FDM0IsTUFBTSxrQkFDSixrQkFBa0IsUUFDZCxTQUNBLGdCQUNFLGlCQUFpQixPQUFPLGFBQWEsSUFDckMsZUFBZSxPQUFPLGNBQWM7Q0FDNUMsTUFBTSxVQUFVLE1BQU07Q0FDdEIsSUFBSSxTQUNGLE9BQU8sWUFBWSxPQUFPLFVBQVUsSUFBSSxRQUFRLEtBQUssU0FBUztDQUVoRSxJQUFJLENBQUMsTUFBTSxRQUNULE9BQU8sVUFBVTtDQUduQixNQUFNLFVBQVUsTUFBTSxPQUFPLEVBQUUsTUFDNUIsY0FBYztFQUViLHNCQUE2QixnQkFBZ0IsTUFBTSxVQUFVLFNBQVM7R0FDcEUsTUFBTSxFQUFFLElBQUksS0FBSyxHQUFHLFlBQVksVUFBVTtHQUMxQyxPQUFPLE9BQU8sTUFBTSxTQUFTLE9BQU87R0FDcEMsTUFBTSxRQUFRO0VBQ2hCO0NBQ0YsSUFDQyxVQUFVO0VBQ1Qsc0JBQTZCLGdCQUFnQixNQUFNLFVBQVUsU0FDM0QsTUFBTSxRQUFRO0VBRWhCLE1BQU07Q0FDUixDQUNGO0NBQ0EsTUFBTSxRQUFRO0NBQ2QsT0FBTyxRQUFRLEtBQUssU0FBUztBQUMvQjs7QUFHQSxTQUFnQixvQkFDZCxTQUNzQjtDQUN0QixNQUFNLE1BQ0osUUFBUSxXQUNMLFVBQVUsTUFBTSxXQUFXLGFBQWEsTUFBTSxTQUNqRCxJQUFJO0NBQ04sT0FBTyxPQUFPLE1BQU0sUUFBUSxTQUFTLFFBQVEsTUFBTSxHQUFHLEdBQUcsSUFBSTtBQUMvRDs7QUFHQSxTQUFnQixpQkFDZCxTQUNzQjtDQUN0QixJQUFJLE1BQU0sUUFBUTtDQUNsQixLQUFLLElBQUksUUFBUSxHQUFHLFFBQVEsS0FBSyxTQUFTO0VBQ3hDLE1BQU0sUUFBUSxRQUFRO0VBSXRCLElBQUksTUFBTSxjQUFjLFFBQVc7R0FDakMsTUFBTSxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksUUFBUSxHQUFHLE1BQU0sU0FBUyxDQUFDO0dBQ3hEO0VBQ0Y7RUFDQSxJQUFJLE1BQU0sV0FBVyxhQUFhLE1BQU0sV0FBVztHQUNqRCxNQUFNLFFBQVE7R0FDZDtFQUNGO0NBQ0Y7Q0FFQSxPQUFPLE1BQU0sUUFBUSxTQUFTLFFBQVEsTUFBTSxHQUFHLEdBQUcsSUFBSTtBQUN4RDtBQTJCQSxNQUFNLFVBQVU7QUFDaEIsTUFBTSxRQUFRO0FBQ2QsTUFBTSxZQUFZO0FBRWxCLE1BQU0sYUFBYTtBQUVuQixNQUFNLG1CQUE0QyxDQUFDLENBQVE7QUF1RzNELFNBQVMsVUFDUCxRQUMwQjtDQUMxQixPQUFPLE9BQU8sT0FBTyxPQUE4QjtBQUNyRDtBQUVBLFNBQWdCLFFBQ2QsT0FDQSxRQUNZO0NBQ1osSUFBSSxPQUFPLFNBQ1QsT0FBTyxRQUFRLEtBQUssQ0FBQyxRQUFRLE9BQU8sTUFBTSxHQUFHLEtBQUssQ0FBQztDQUVyRCxPQUFPLElBQUksU0FBWSxTQUFTLFdBQVc7RUFDekMsTUFBTSxjQUFjLE9BQU8sTUFBTTtFQUNqQyxPQUFPLGlCQUFpQixTQUFTLE9BQU8sRUFBRSxNQUFNLEtBQUssQ0FBQztFQUN0RCxRQUFRLFFBQVEsS0FBSyxFQUNsQixLQUFLLFNBQVMsTUFBTSxFQUVwQixXQUFXLE9BQU8sb0JBQW9CLFNBQVMsS0FBSyxDQUFDO0NBQzFELENBQUM7QUFDSDtBQUVBLFNBQWdCLFNBQVMsUUFBbUIsT0FBNEI7Q0FDdEUsT0FBUSxPQUFPLFdBQXdDLE1BQU07QUFDL0Q7QUFFQSxTQUFTLFVBQ1AsT0FDQSxVQUNBLFNBQ2tCO0NBQ2xCLElBQUksV0FBVyxLQUFLLEdBQ2xCLE9BQU8sQ0FBQyxZQUFZLEtBQUs7Q0FFM0IsSUFBSSxXQUFXLEtBQUssR0FBRztFQUNyQixNQUFNLFlBQVk7RUFDbEIsT0FBTyxDQUFDLFdBQVcsS0FBSztDQUMxQjtDQUNBLElBQUksQ0FBQyxVQUNILE9BQU8sQ0FBQyxTQUFTLEtBQUs7Q0FFeEIsSUFBSSxPQUFRLE9BQWUsU0FBUyxZQUNsQyxRQUFRLElBQUksTUFBTSx3QkFBd0IsRUFBRSxPQUFPLE1BQU0sQ0FBQztDQUU1RCxPQUFPLENBQUMsT0FBTyxLQUFLO0FBQ3RCO0FBRUEsU0FBUyxlQUFlLE9BQWlCLE9BQWtDO0NBQ3pFLElBQUksVUFBVSxVQUFVLE9BQU8sTUFBTSxNQUFNLEVBQUU7Q0FDN0MsSUFBSSxRQUFRLE9BQWtCLE9BQzVCLE9BQU87Q0FFVCxJQUFJO0VBQ0YsTUFBTSxRQUFRLFVBQVUsUUFBUSxFQUFjO0NBQ2hELFNBQVMsY0FBYztFQUNyQixVQUFVLFVBQVUsY0FBYyxNQUFNLE1BQU0sRUFBRTtDQUNsRDtDQUNBLE9BQU87QUFDVDtBQUVBLFNBQVMsbUJBQ1AsUUFDQSxNQUNBLE9BQ0EsT0FDQSxTQUNlO0NBQ2YsSUFBSSxRQUFRLEdBQW9CLE9BQU8sU0FDckMsT0FBTztDQUVULE9BQU8sb0JBQ0wsUUFDQSxNQUNBLE9BQ0EsZUFBZSxPQUFPLEtBQUssR0FDM0IsT0FDRjtBQUNGO0FBRUEsZUFBZSxjQUNiLFFBQ0EsTUFDQSxTQUNBLEtBQ0Esb0JBQ0EsYUFDcUM7Q0FDckMsTUFBTSxDQUFDLFVBQVUsV0FBVztDQUM1QixNQUFNLFNBQVMsUUFBUSxHQUFvQjtDQUMzQyxNQUFNLFVBQVUsQ0FBQyxDQUFDLFFBQVE7Q0FDMUIsS0FBSyxJQUFJLFFBQVEsUUFBUSxNQUEyQixHQUFHLFFBQVEsS0FBSyxTQUFTO0VBQzNFLE1BQU0sUUFBUSxRQUFRO0VBQ3RCLE1BQU0sUUFBUSxTQUFTLFFBQVEsS0FBSztFQUVwQyxNQUFNLGtCQUFrQixRQUFRO0VBR2hDLE1BQU0sZ0JBQ0osUUFBUSxRQUFRLElBQUksV0FBVyxPQUFPLFFBQVEsV0FBVyxDQUFDO0VBQzVELE1BQU0sU0FBUztHQUNiLFFBQVEsTUFBTTtHQUNkO0dBQ0EsV0FBVyxTQUNULE9BQU8sU0FBUztJQUNkLEdBQUc7SUFDSCxlQUFlO0dBQ2pCLENBQUM7R0FDSCxlQUFlLE9BQU87R0FDdEIsT0FBTyxVQUFXLFlBQXNCLE1BQU07R0FDOUMsaUJBQWlCLFFBQVE7R0FDekI7R0FDQTtHQUNBLFNBQVMsTUFBTTtFQUNqQjtFQUNBLElBQUk7R0FFRixNQUFNLGVBQWdCLE1BQU0sU0FBUyxNQUFNLFFBQVEsVUFDL0MsTUFBTSxRQUFRLFFBQVE7SUFDcEIsR0FBRztJQUNILE1BQU0sTUFBTTtJQUNaLFNBQVM7R0FDWCxDQUF3RCxLQUFLLENBQUMsSUFDOUQ7R0FDSixNQUFNLFVBQVU7SUFDZCxHQUFHO0lBQ0gsR0FBRztHQUNMO0VBQ0YsU0FBUyxPQUFPO0dBQ2QsY0FBYyxRQUFRLEtBQUs7R0FDM0IsT0FBTyxDQUFDLE9BQU8sbUJBQW1CLFFBQVEsTUFBTSxPQUFPLE9BQU8sT0FBTyxDQUFDO0VBQ3hFO0VBQ0EsSUFBSSxPQUFPLFNBQ1QsT0FBTyxDQUFDLE9BQU8sZ0JBQWdCO0VBRWpDLE1BQU0sa0JBQWtCLE1BQU0sZUFBZSxNQUFNO0VBQ25ELElBQUksb0JBQW9CLFFBQVc7R0FDakMsY0FBYyxRQUFRLEtBQUs7R0FDM0IsT0FBTyxDQUNMLE9BQ0EsbUJBQW1CLFFBQVEsTUFBTSxPQUFPLGlCQUFpQixPQUFPLENBQ2xFO0VBQ0Y7RUFDQSxNQUFNLGFBQWEsTUFBTSxRQUFRO0VBQ2pDLElBQUksQ0FBQyxZQUNIO0VBR0YsTUFBTSxpQkFBaUIsTUFBTTtFQUM3QixJQUFJLFNBQVMsYUFBYTtHQUN4QixNQUFNLFNBQVM7R0FDZixRQUFRLEtBQW1CO0VBQzdCO0VBQ0EsSUFBSTtHQUNGLFlBQVksUUFBUSxPQUFPLGNBQWMsUUFBUSxFQUFtQjtHQUNwRSxNQUFNLFFBQVEsV0FBVztJQUN2QixHQUFHO0lBQ0gsUUFBUSxNQUFNO0lBQ2QsU0FBUyxNQUFNO0lBQ2YsR0FBRyxPQUFPLFFBQVE7R0FDcEIsQ0FBQztHQUdELE1BQU0sU0FBUyxPQUFPLE9BQU8sT0FBTyxTQUFTLGFBQ3pDLFFBQVEsT0FBTyxNQUFNLElBQ3JCO0dBQ0osSUFBSSxPQUFPLFNBQ1QsT0FBTyxDQUFDLE9BQU8sZ0JBQWdCO0dBRWpDLE1BQU0sVUFBVSxvQkFDZCxRQUNBLE1BQ0EsT0FDQSxVQUFVLFFBQVEsT0FBTyxNQUFNLEVBQUUsR0FDakMsT0FDRjtHQUNBLElBQUksUUFBUSxPQUFrQixTQUFTO0lBQ3JDLGNBQWMsUUFBUSxLQUFLO0lBQzNCLE9BQU8sQ0FBQyxPQUFPLE9BQU87R0FDeEI7R0FDQSxNQUFNLFVBQVU7SUFDZCxHQUFHLE1BQU07SUFDVCxHQUFHO0dBQ0w7RUFDRixTQUFTLE9BQU87R0FDZCxjQUFjLFFBQVEsS0FBSztHQUMzQixPQUFPLENBQUMsT0FBTyxtQkFBbUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxPQUFPLENBQUM7RUFDeEUsVUFBVTtHQUNSLE1BQU0sU0FBUztHQUNmLFlBQVksUUFBUSxPQUFPLE9BQU8sUUFBUSxFQUFtQjtFQUMvRDtDQUNGO0NBR0EsbUJBQW1CO0FBRXJCO0FBRUEsU0FBUyxtQkFDUCxRQUNBLE9BQ0EsUUFDNkI7Q0FDN0IsSUFBSSxDQUFDLFVBQVUsRUFBRSxPQUFPLElBQ3RCO0NBRUYsSUFBSSxPQUFPLFVBQVUsSUFBSSxNQUFNLEVBQUUsTUFBTSxRQUFRO0VBQzdDLE1BQU0sVUFBVSxPQUFPO0VBQ3ZCLElBQ0UsV0FDQSxDQUFDLFFBQVEsR0FBb0IsT0FBTyxXQUNwQyxDQUFDLFFBQVEsR0FBaUIsU0FBUyxLQUFLLEtBQ3hDLFFBQVEsR0FBaUIsTUFBTSxjQUFjLFVBQVUsT0FBTyxNQUFNLEVBQUUsS0FDdEUsUUFBUSxHQUFpQixNQUN0QixjQUFjLFVBQVUsZUFBZSxZQUMxQyxHQUlBO0VBRUYsT0FBTyxTQUFTLE9BQU8sTUFBTSxFQUFFO0NBQ2pDO0NBQ0EsT0FBTyxPQUFPO0FBQ2hCO0FBRUEsU0FBUyxjQUFjLFFBQW1CLE9BQXdCO0NBQ2hFLE1BQU0sU0FBUyxNQUFNO0NBQ3JCLE1BQU0sVUFBVTtDQUNoQixtQkFBbUIsUUFBUSxPQUFPLE1BQU0sR0FBRyxNQUFNO0FBQ25EOzs7OztBQUtBLFNBQVMsdUJBQ1AsUUFDQSxVQUNBLE1BQ0EsbUJBQ007Q0FDTixNQUFNLFFBQWdDLENBQUM7Q0FDdkMsS0FBSyxNQUFNLFNBQVMsVUFDbEIsSUFBSSxDQUFDLE1BQU0sU0FBUyxLQUFLLEdBQUc7RUFDMUIsTUFBTSxTQUFTLE1BQU07RUFDckIsTUFBTSxVQUFVO0VBQ2hCLElBQ0UscUJBQ0EsU0FBUyxPQUFvQixLQUM3QixPQUFPLFVBQVUsSUFBSSxNQUFNLEVBQUUsTUFBTSxVQUNuQyxNQUFNLE1BQU0sY0FBYyxVQUFVLE9BQU8sTUFBTSxFQUFFLEdBR25ELE9BQU8sS0FBa0I7T0FDcEI7R0FDTCxNQUFNLGFBQWEsbUJBQW1CLFFBQVEsT0FBTyxNQUFNO0dBQzNELElBQUksWUFDRixNQUFNLEtBQUssVUFBVTtFQUV6QjtDQUNGO0NBRUYsS0FBSyxNQUFNLGNBQWMsT0FDdkIsV0FBVyxNQUFNO0FBRXJCO0FBRUEsU0FBUyxzQkFBc0IsU0FBcUM7Q0FDbEUsS0FBSyxNQUFNLFNBQVMsU0FBNkI7RUFDL0MsTUFBTSxTQUFTLE1BQU07RUFDckIsSUFBSSxRQUNGLE9BQU87Q0FFWDtBQUNGO0FBRUEsU0FBUyxZQUNQLFFBQ0EsT0FDQSxPQUNBLE9BQ007Q0FDTixNQUFNLGFBQWE7Q0FDbkIsSUFBSSxTQUFTLE9BQU8sTUFBTSxPQUF3QixPQUNoRDtDQUVGLE1BQU0sUUFBUSxPQUFPLE9BQU8sUUFBUSxJQUFJLE1BQU0sT0FBTztDQUNyRCxNQUFNLFlBQVksT0FBTyxJQUFJO0NBQzdCLElBQUksV0FBVyxPQUFPLE1BQU0sSUFDMUIsTUFBTyxJQUFJO0VBQUUsR0FBRztFQUFXLFlBQVk7Q0FBTSxDQUFDO0FBRWxEO0FBRUEsU0FBUyxpQkFDUCxRQUNBLE1BQ0EsT0FDQSxPQUNBLFlBQ0Esb0JBQ0EsU0FDaUI7Q0FDakIsTUFBTSxXQUFXLEtBQUs7Q0FDdEIsT0FBTztFQUNMLFFBQVEsTUFBTTtFQUNkO0VBQ0EsV0FBVyxTQUNULE9BQU8sU0FBUztHQUNkLEdBQUc7R0FDSCxlQUFlO0VBQ2pCLENBQUM7RUFDSCxPQUFPLFVBQVcsWUFBc0IsTUFBTTtFQUM5QyxpQkFBaUI7RUFDakI7RUFDQSxNQUFNLE1BQU07RUFDUTtFQUNwQixTQUFTLE1BQU07RUFDZjtFQUNBLEdBQUcsT0FBTyxRQUFRO0NBQ3BCO0FBQ0Y7QUFFQSxlQUFlLGFBQ2IsUUFDQSxNQUNBLE9BQ0EsT0FDQSxRQUNBLG9CQUNBLFNBQ3dCO0NBQ3hCLE1BQU0sUUFBUSxRQUFRO0NBQ3RCLE1BQU0sU0FBUyxNQUFNO0NBQ3JCLElBQUksT0FBTyxTQUNULE9BQU87Q0FFVCxJQUFJLENBQUMsUUFDSCxPQUFPLENBQUMsU0FBUyxNQUFTO0NBRzVCLElBQUksU0FBUyxNQUFNO0NBQ25CLFlBQVksUUFBUSxPQUFPLFVBQVUsS0FBSztDQUMxQyxJQUFJO0VBQ0YsSUFBSSxDQUFDLFFBQVE7R0FDWCxNQUFNLGFBQWEsSUFBSSxnQkFBZ0I7R0FDdkMsU0FBUztJQUNQLFFBQVEsUUFBUSxFQUNiLFdBQ0MsT0FDRSxpQkFDRSxRQUNBLE1BQ0EsT0FDQSxPQUNBLFlBQ0Esb0JBQ0EsQ0FBQyxDQUFDLFFBQVEsRUFDWixDQUNGLENBQ0YsRUFDQyxNQUNFLFVBQVUsVUFBVSxPQUFPLE9BQU8sTUFBTSxFQUFFLElBQzFDLFVBQVUsVUFBVSxPQUFPLE1BQU0sTUFBTSxFQUFFLENBQzVDLEVBQ0MsTUFBTSxXQUE2QjtLQUdsQyxJQUNFLE9BQU8sT0FBa0IsV0FDekIsT0FBTyxVQUFVLElBQUksTUFBTSxFQUFFLE1BQU0sUUFDbkM7TUFDQSxPQUFPLFNBQVUsT0FBTyxNQUFNLEVBQUU7TUFDaEMsSUFBSSxDQUFDLE9BQVEsSUFDWCxXQUFXLE1BQU07S0FFckI7S0FDQSxPQUFPLE9BQU8sT0FBa0IsU0FBUyxPQUFRLEtBQzdDLGVBQWUsT0FBTyxPQUFPLEVBQWMsSUFDM0M7SUFDTixDQUFDO0lBQ0g7SUFDQTtHQUNGO0dBQ0MsQ0FBQyxPQUFPLDZCQUFhLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxJQUFJLE1BQU07RUFDdkQ7RUFDQSxNQUFNLFVBQVU7RUFDaEIsTUFBTSxrQkFBa0IsT0FBTztFQUMvQixPQUFPLG9CQUNMLFFBQ0EsTUFDQSxPQUNBLE1BQU0sUUFBUSxPQUFPLElBQWtCLE1BQU0sR0FDN0MsT0FDRjtDQUNGLFNBQVMsT0FBTztFQUNkLElBQUksVUFBVSxVQUFVLENBQUMsT0FBTyxTQUM5QixNQUFNO0VBRVIsY0FBYyxRQUFRLEtBQUs7RUFDM0IsT0FBTztDQUNULFVBQVU7RUFDUixZQUFZLFFBQVEsT0FBTyxPQUFPLEtBQUs7Q0FDekM7QUFDRjtBQUVBLFNBQVMsV0FDUCxPQUNBLFFBQ0EsU0FDK0I7Q0FDL0IsSUFBSSxPQUFPLE9BQWtCLFlBQzNCO0NBSUYsTUFBTSxTQUFTO0NBQ2YsTUFBTSxRQUFRO0NBQ2QsSUFBSSxPQUFPLE9BQWtCLFNBQVM7RUFDcEMsTUFBTSxhQUFhLE9BQU87RUFDMUIsTUFBTSxVQUFVO0VBQ2hCLE1BQU0sWUFBWSxLQUFLLElBQUk7RUFDM0IsTUFBTSxVQUFVO0NBQ2xCLE9BQ0UsTUFBTSxVQUFVO0FBRXBCO0FBRUEsU0FBZ0IsaUJBQ2QsUUFDQSxPQUNBLFNBQ007Q0FDTixNQUFNLFVBQVUsT0FBTyxPQUFPLElBQUksTUFBTSxFQUFFO0NBQzFDLElBQ0UsWUFBWSxXQUNaLE9BQU8sV0FBVyxNQUNmLGNBQ0MsVUFBVSxPQUFPLE1BQU0sTUFDdEIsVUFBd0IsWUFBWSxNQUFNLE9BQy9DLEdBRUE7Q0FFRixNQUFNLFNBQVM7RUFDYixHQUFHO0VBQ0gsV0FBVztFQUNYLFNBQVMsQ0FBQztDQUNaO0NBQ0EsSUFBSSxPQUFPLFNBQ1QsT0FBTyxRQUFRO0NBRWpCLE9BQU8sT0FBTyxJQUFJLE1BQU0sSUFBSSxNQUFNO0NBQ2xDLElBQUksU0FDRixjQUFjLFFBQVEsT0FBTztBQUVqQztBQUVBLFNBQVMsa0JBQ1AsT0FDQSxTQUNXO0NBQ1gsSUFBSSxRQUFRLE9BQWtCLFNBQVMsUUFBUSxPQUFrQixXQUMvRCxPQUFPO0VBQ0wsR0FBRztFQUNILFFBQVEsUUFBUSxPQUFrQixRQUFRLFVBQVU7RUFDcEQsT0FBTyxRQUFRO0VBQ2YsU0FBUztDQUNYO0NBRUYsT0FBTztBQUNUO0FBRUEsU0FBUyxpQkFDUCxRQUNBLE1BQ0EsT0FDQSxPQUNBLGdCQUNBLFNBQ0EsYUFDb0I7Q0FDcEIsTUFBTSxRQUFRLEtBQUssR0FBaUI7Q0FDcEMsTUFBTSxRQUFRLFNBQVMsUUFBUSxLQUFLO0NBQ3BDLE1BQU0sVUFBVSxDQUFDLENBQUMsUUFBUTtDQUMxQixNQUFNLG9CQUFvQixPQUFPLE9BQU8sSUFBSSxNQUFNLEVBQUU7Q0FDcEQsSUFBSTtDQUNKLElBQUksU0FBUztDQUNiLElBQUk7Q0FDSixJQUFJO0VBQ0YsSUFBSSxNQUFNLFdBQVcsV0FBVztHQUM5QixhQUFhLE1BQU0sUUFBUTtHQUMzQixJQUFJLE9BQU8sZUFBZSxZQUN4QixhQUFhLFdBQ1gsaUJBQ0UsUUFDQSxNQUNBLE9BQ0EsT0FDQSxRQUFRLElBQ1IsZ0JBQ0EsT0FDRixDQUNGO0dBRUYsSUFBSSxRQUFRLEdBQW9CLE9BQU8sU0FDckMsZ0JBQWdCO0VBRXBCO0VBQ0EsSUFBSSxDQUFDLGVBQ0gsSUFBSSxNQUFNLFdBQVcsV0FDbkIsU0FBUztPQUNKO0dBQ0wsTUFBTSxXQUNKLFdBQVcsTUFBTSxVQUNaLE1BQU0sUUFBUSxvQkFDZixPQUFPLFFBQVEsMkJBQ2YsTUFDQyxNQUFNLFFBQVEsYUFBYSxPQUFPLFFBQVEsb0JBQW9CO0dBQ3JFLFNBQVMsQ0FBQyxFQUNSLE1BQU0sV0FDTixjQUNDLGVBQWUsVUFDZCxLQUFLLElBQUksSUFBSSxNQUFNLGFBQWEsYUFDL0IsUUFBUSxNQUNQLE1BQU0sVUFBVSxXQUNoQixRQUFRLEdBQWMsTUFDbkIsY0FDQyxVQUFVLFlBQVksTUFBTSxXQUM1QixVQUFVLE9BQU8sTUFBTSxFQUMzQjtFQUVSO0NBRUosU0FBUyxPQUFPO0VBQ2QsTUFBTSxVQUFVO0VBQ2hCLGNBQWMsUUFBUSxLQUFLO0VBQzNCLGdCQUFnQixtQkFBbUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxPQUFPO0NBQ3hFO0NBQ0EsTUFBTSxjQUFjLE1BQU0sUUFBUTtDQUNsQyxNQUFNLGFBQWEsT0FBTyxnQkFBZ0I7Q0FDMUMsTUFBTSxTQUFTLGFBQWEsY0FBYyxhQUFhO0NBQ3ZELE1BQU0sY0FBYyxDQUFDLFdBQVcsTUFBTSxRQUFRLFlBQVk7Q0FDMUQsSUFBSSxRQUNGLGVBQ0EsZUFDQSxvQkFBMkIsZ0JBQWdCLE9BQU8sTUFBTSxNQUNwRCxPQUFPLFVBQVUsSUFBSSxNQUFNLEVBQUUsSUFDN0I7Q0FDTixJQUFJLFVBQVUsTUFBTSxXQUFXLGVBQzdCLFFBQVE7TUFDSCxJQUFJLFNBQVMsQ0FBQyxVQUFVLENBQUMsV0FBVyxlQUFlLFFBR3hELFNBQVM7TUFDSixJQUFJLENBQUMsUUFDVixRQUFRO0NBRVYsTUFBTSxhQUFhLENBQUMsRUFDbEIsZUFDQSxVQUNBLE1BQU0sV0FBVyxhQUNqQixDQUFDLFdBQ0QsQ0FBQyxRQUFRLFFBQ1AsYUFBYSxTQUFZLFlBQVksb0JBQ3JDLE9BQU8sUUFBUSw0QkFBNEI7Q0FFL0MsTUFBTSxTQUFTLFVBQVU7Q0FDekIsTUFBTSxXQUNKLFVBQVUsQ0FBQyxlQUFlLE1BQU0sV0FBVyxhQUFhLENBQUMsQ0FBQztDQUM1RCxNQUFNLFVBQVUsU0FBUyxjQUFjLFFBQVEsS0FBbUI7Q0FDbEUsTUFBTSxjQUFjLE1BQU0sVUFBVSxNQUFNLFVBQVUsT0FBTyxVQUFVO0NBQ3JFLElBQUksVUFBVSxDQUFDLGFBQWE7RUFDMUIsTUFBTSxVQUFVO0VBQ2hCLE1BQU0sWUFBWSxLQUFLLElBQUk7Q0FDN0I7Q0FDQSxJQUFJLE9BQ0YsTUFBTTtDQUVSLElBQUksVUFBVTtFQUNaLE1BQU0saUJBQWlCLE1BQU07RUFDN0IsTUFBTSxVQUFVO0VBQ2hCLG1CQUFtQixRQUFRLE9BQU8sY0FBYyxHQUFHLE1BQU07RUFHekQsSUFBSSxTQUFTLGFBQ1gsTUFBTSxTQUFTO0VBRWpCLFVBQVU7Q0FDWjtDQUNBLElBQUksQ0FBQyxRQUNILE1BQU0sYUFBYTtDQUVyQixNQUFNLFVBQ0osQ0FBQyxpQkFBaUIsV0FDZCxhQUNFLFFBQ0EsTUFDQSxPQUNBLE9BQ0EsUUFDQSxnQkFDQSxPQUNGLEVBQUUsTUFBTSxXQUFXO0VBQ2pCLFdBQVcsT0FBTyxRQUFRLE9BQU87RUFDakMsSUFBSSxPQUFPLE9BQWtCLFNBQVM7R0FHcEMsSUFBSSxlQUFlLENBQUMsUUFBUSxHQUFvQixPQUFPLFNBQ3JELGlCQUFpQixRQUFRLE9BQU8saUJBQWlCO0dBSW5ELElBQUksU0FBUyxhQUNYLE1BQU0sU0FBUztFQUVuQjtFQUNBLE9BQU87Q0FDVCxDQUFDLElBQ0QsUUFBUSxRQUNOLGlCQUFpQixDQUFDLFNBQVMsTUFBTSxVQUFVLENBQzdDO0NBR04sTUFBTSxnQkFBZ0IsWUFBNEM7RUFDaEUsSUFBSTtHQUNGLE1BQU0sUUFBUSxlQUFlLE9BQU8sUUFBVyxXQUFXO0dBQzFELElBQUksT0FDRixNQUFNLFFBQVEsT0FBTyxRQUFRLEdBQW9CLE1BQU07RUFFM0QsU0FBUyxPQUFPO0dBQ2QsSUFDRSxDQUFDLEtBQUssR0FBaUIsTUFDcEIsV0FBVyxtQkFDVixrQkFBa0IsVUFDakIsVUFBVSxXQUFXLFdBQ3BCLFVBQVUsV0FBVyxjQUNyQixVQUFVLFVBQ2hCLEdBRUEsT0FBTyxDQUNMLE9BQ0EsbUJBQW1CLFFBQVEsTUFBTSxPQUFPLE9BQU8sT0FBTyxDQUN4RDtFQUVKO0VBRUEsTUFBTSxTQUFTLE1BQU07RUFDckIsSUFDRSxZQUNBLE9BQU8sT0FBa0IsV0FDekIsTUFBTSxXQUFXLGFBQ2pCLENBQUMsUUFBUSxHQUFvQixPQUFPLFNBQ3BDO0dBQ0EsTUFBTSxTQUFTO0dBQ2YsVUFBVTtFQUNaO0NBQ0YsR0FBRztDQUNILE1BQU0sS0FBSztFQUFDO0VBQU87RUFBUztDQUFZLENBQUM7Q0FDekMsSUFBSSxDQUFDLFlBQ0gsT0FBTyxRQUFRLE1BQU0sV0FBVyxrQkFBa0IsT0FBTyxNQUFNLENBQUM7Q0FFbEUsTUFBTSxZQUF1QjtFQUMzQixHQUFHO0VBQ0gsUUFBUTtFQUNSLFNBQVM7RUFDVCxTQUFTO0NBQ1g7Q0FDQSxNQUFNLFVBQVU7Q0FDaEIsTUFBTSxhQUFhO0NBQ25CLE1BQU0sb0JBQW9CLGFBQ3hCLFFBQ0EsTUFDQSxXQUNBLE9BQ0EsUUFDQSxnQkFDQSxPQUNGLEVBQUUsTUFBTSxXQUFXO0VBQ2pCLE1BQU0sYUFBYTtFQUNuQixXQUFXLFdBQVcsUUFBUSxLQUFLO0VBQ25DLE9BQU87Q0FDVCxDQUFDO0NBQ0EsQ0FBQyxLQUFLLE9BQXdCLENBQUMsR0FBRyxLQUFLO0VBQ3RDO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsQ0FBQztDQUNELE9BQU8sa0JBQWtCLE1BQU0sV0FDN0Isa0JBQWtCLFdBQVcsTUFBTSxDQUNyQztBQUNGO0FBRUEsZUFBZSxvQkFDYixRQUNBLFNBQ0EsU0FDQSxRQUNBLFdBQVcsR0FDTTtDQUNqQixNQUFNLFFBQVEsVUFBVSxHQUFpQjtDQUd6QyxJQUFJLFFBQVEsT0FBTyxVQUNmLFFBQVEsV0FBVyxVQUFVLE1BQU0sWUFBWSxNQUFNLE9BQU8sSUFDM0QsVUFBVSxNQUFrQixRQUFRLFNBQVM7Q0FDbEQsSUFBSSxRQUFRLEdBQ1YsUUFBUTtDQUVWLEtBQUssSUFBSSxJQUFJLE9BQU8sS0FBSyxHQUFHLEtBQUs7RUFDL0IsTUFBTSxRQUFRLFNBQVMsUUFBUSxRQUFRLEVBQUc7RUFDMUMsSUFBSTtHQUNGLE1BQU0sVUFBVSxlQUFlLE9BQU8sS0FBSztHQUMzQyxJQUFJLFNBQ0YsTUFBTSxRQUFRLFNBQVMsTUFBTTtFQUVqQyxTQUFTLE9BQU87R0FDZCxJQUFJLFVBQVUsVUFBVSxPQUFPLFNBQzdCLE1BQU07RUFFVjtFQUNBLElBQUksTUFBTSxRQUFRLG1CQUNoQixPQUFPO0NBRVg7Q0FDQSxPQUFPLE9BQU8sVUFBVSxRQUFRO0FBQ2xDO0FBRUEsU0FBUyxrQkFBa0IsUUFBbUIsTUFBdUI7Q0FDbkUsSUFBSSxLQUFLLElBQXFCO0VBQzVCLHVCQUNFLFFBQ0EsS0FBSyxHQUFvQixLQUFLLFNBQVMsS0FBSyxFQUFrQixDQUNoRTtFQUNBLEtBQUssS0FBc0I7Q0FDN0I7QUFDRjtBQUVBLGVBQWUsWUFDYixPQUNBLGVBQ0EsZUFDQSxNQUNxQztDQUNyQyxJQUFJO0NBRUosSUFBSTtFQUNGLE1BQU0sUUFBUSxJQUNaLE1BQU0sS0FBSyxTQUNULEtBQUssR0FBaUIsS0FBSyxPQUFPLFlBQVk7R0FDNUMsTUFBTSxZQUFZLEtBQUs7R0FDdkIsSUFBSSxRQUFRLGFBQWMsTUFBTSxNQUM5QjtHQUVGLElBQUksUUFBUSxNQUFpQixZQUMzQixNQUFNLENBQUMsV0FBVyxPQUFPO0dBRTNCLElBQUksQ0FBQyxpQkFBaUIsUUFBUSxPQUFrQixTQUFTO0lBQ3ZELGdCQUFnQixDQUFDLFdBQVcsT0FBTztJQUduQyxNQUFNLFFBQVEsS0FDWCxpQkFBaUIsQ0FBQyxHQUFHLEtBQUssYUFBYTtLQUN0QyxJQUFJLFNBQVMsTUFBa0IsV0FDN0I7S0FFRixPQUFPLFNBQVMsR0FBaUIsTUFBTSxnQkFBZ0I7TUFDckQsSUFBSSxZQUFZLE9BQWtCLFlBQ2hDLE1BQU0sQ0FDSixTQUFTLElBQ1QsV0FDRjtLQUVKLENBQUM7SUFDSCxDQUFDLENBQ0g7R0FDRjtFQUNGLENBQUMsQ0FDSCxDQUNGO0NBQ0YsU0FBUyxPQUFPO0VBQ2QsT0FBTztDQUNUO0NBQ0EsT0FBTyxpQkFBaUI7QUFDMUI7QUFFQSxTQUFTLG9CQUNQLFFBQ0EsTUFDQSxPQUNBLFNBQ0EsU0FDQSxRQUNlO0NBQ2YsT0FBTyxRQUFRLE9BQWtCLFlBQVk7RUFDM0MsTUFBTSxXQUFXLFFBQVE7RUFDekIsTUFBTSxrQkFBa0IsU0FBUztFQUNqQyxJQUFJO0dBQ0YsSUFBSSxnQkFBZ0IsUUFBUSxTQUFTLFFBQVEsSUFBSSxVQUFVLEdBQUc7SUFDNUQsT0FBTyxnQkFBZ0IsUUFBUTtJQUMvQixJQUFJLGdCQUFnQixnQkFDbEIsT0FBTztHQUVYO0dBQ0EsSUFDRSxnQkFBZ0IsaUJBQ1osUUFBUSxLQUNSLFFBQVEsTUFBc0IsSUFFbEMsT0FBTztHQUVULE1BQU0sV0FBVyxPQUFPLGNBQWM7SUFDcEMsR0FBRztJQUNILGVBQWUsS0FBSztJQUNwQix3QkFBd0I7R0FDMUIsQ0FBQztHQUNELE1BQU0saUJBQWlCLFNBQVMsa0JBQWtCO0dBQ2xELElBQUksZUFBZSxVQUFVO0lBRzNCLE1BQU0sV0FBVyxTQUFTLE1BQU07SUFDaEMsU0FBUyxVQUFVLEVBQUUsR0FBRyxnQkFBZ0I7SUFDeEMsU0FBUyxRQUFRLElBQUksWUFBWSxlQUFlLFVBQVU7SUFDMUQsT0FBTyxnQkFBZ0IsUUFBUTtJQUUvQixPQUFPLFFBQVEsS0FDWCxDQUFDLFlBQVksUUFBUSxJQUNyQjtLQUFDO0tBQVk7S0FBVTtJQUFjO0dBQzNDO0dBQ0EsT0FBTztJQUFDO0lBQVk7SUFBVTtHQUFRO0VBQ3hDLFNBQVMsT0FBTztHQUNkLFVBQVUsU0FBUyxDQUFDLE9BQU8sS0FBSyxJQUFJLGVBQWUsT0FBTyxLQUFLO0dBQy9ELFNBQVM7RUFDWDtDQUNGO0NBQ0EsT0FBTztBQUNUO0FBRUEsZUFBZSxXQUNiLFFBQ0EsTUFDQSxPQUNBLFlBQ0EsWUFDQSxTQUN1QztDQUN2QyxNQUFNLFVBQVUsS0FBSztDQUNyQixJQUFJLFVBQVUsTUFBTTtDQUNwQixJQUFJLHdCQUF3QjtDQUM1QixNQUFNLGtCQUFrQixRQUFRLFdBQVcsVUFBVSxNQUFNLFNBQVM7Q0FDcEUsTUFBTSxjQUFjLFVBQ2xCLE1BQU0sR0FBaUIsT0FBa0IsWUFDckMsb0JBQW9CLFFBQVEsU0FBUyxPQUFPLFdBQVcsTUFBTSxJQUM3RCxNQUFNO0NBQ1osSUFBSSxlQUFlLGtCQUFrQixJQUFJLFFBQVEsU0FBUztDQUUxRCxLQUFLLFVBQVUsR0FBaUIsTUFBaUIsTUFBTSxZQUNyRCxlQUFlO01BQ1YsSUFBSSxTQUFTO0VBQ2xCLGVBQWUsUUFBUSxPQUFzQixNQUFNLFdBQVcsT0FBTztFQUNyRSxLQUFLLE1BQU0sUUFBUSxPQUFPO0dBQ3hCLElBQUksS0FBSyxNQUFrQixjQUN6QjtHQUVGLE1BQU0sVUFBVSxNQUFNLEtBQUs7R0FFM0IsSUFDRSxRQUFRLE9BQWtCLFdBQzFCLFFBQVEsS0FBZ0IsY0FDeEIsRUFBRSxnQkFBZ0IsUUFBUSxLQUFLLE1BQy9CO0lBQ0EsVUFBVSxDQUFDLEtBQUssSUFBZ0IsT0FBTztJQUN2QyxlQUFlLFFBQVEsS0FBb0IsTUFBTSxXQUFXLE9BQU87SUFDbkU7R0FDRjtFQUNGO0NBQ0Y7Q0FFQSxLQUFLLE1BQU0sUUFBUSxPQUFPO0VBQ3hCLElBQUksS0FBSyxNQUFrQixjQUN6QjtFQUVGLE1BQU0sZUFBZSxNQUFNLEtBQUs7RUFDaEMsSUFBSSxDQUFDLGNBQ0g7RUFFRixVQUFVO0VBQ1Y7Q0FDRjtDQUVBLEtBQUssVUFBVSxHQUFpQixNQUFpQixNQUFNLFlBQVk7RUFDakUsTUFBTSxVQUFVLFFBQVM7RUFDekIsSUFDRSxRQUFRLE9BQWtCLGNBQzFCLFFBQVEsR0FBa0IsUUFBUSxrQkFDbEMsUUFBUSxJQUNSO0dBQ0Esa0JBQWtCLFFBQVEsSUFBSTtHQUM5QixPQUFPO0VBQ1Q7RUFDQSx3QkFBd0I7RUFDeEIsVUFBVSxDQUFDLEdBQUcsQ0FBQyx1QkFBTyxJQUFJLE1BQU0sb0JBQW9CLENBQUMsQ0FBQztDQUN4RDtDQUVBLE1BQU0sV0FBVyxVQUNaLFFBQVEsTUFBc0IsTUFBTSxXQUFXLE9BQU8sSUFDdkQ7Q0FDSixJQUFJLFlBQVksR0FBRztFQUNqQixNQUFNLFVBQVUsVUFBVTtFQUMxQixNQUFNLE9BQU8sVUFBVTtFQUN2QixNQUFNLFFBQVEsUUFBUTtFQUN0QixNQUFNLFFBQVEsVUFBVTtFQUN4QixNQUFNLGdCQUFnQjtHQUNwQixJQUFJLFNBQVM7SUFDWCxNQUFNLFlBQVk7SUFDbEIsSUFBSSxTQUFTLE9BQ1gsTUFBTSxTQUFTO1NBQ1Y7S0FDSixNQUF5QixVQUFVLE1BQU07S0FDMUMsSUFBSSxNQUFNLFlBQVksT0FBTyxVQUFVLElBQUk7TUFDekMsTUFBTSxTQUFTO01BQ2YsTUFBTSxZQUFZO0tBQ3BCLE9BQ0UsTUFBTSxTQUFTO0lBRW5CO0lBQ0EsTUFBTSxRQUFRO0lBQ2QsTUFBTSxhQUFhO0dBQ3JCO0VBQ0Y7RUFDQSxRQUFRO0VBQ1IsSUFBSSxDQUFDLFNBQ0gsVUFBVTtFQUVaLE1BQU0sUUFBUSxTQUFTLFFBQVEsS0FBSztFQUNwQyxJQUFJO0dBQ0YsTUFBTSxRQUNKLFVBQ0ksUUFBUSxRQUFRLEVBQUUsV0FDaEIsZUFDRSxPQUNBLFNBQVMsUUFBUSxtQkFBbUIsbUJBQ3RDLENBQ0YsSUFDQSxRQUFRLElBQUksQ0FDVixlQUFlLEtBQUssR0FDcEIsZUFBZSxPQUFPLG1CQUFtQixDQUMzQyxDQUFDLEdBQ0wsV0FBVyxNQUNiO0VBQ0YsU0FBUyxPQUFPO0dBQ2QsSUFBSSxVQUFVLFdBQVcsVUFBVSxXQUFXLE9BQU8sU0FBUztJQUM1RCxrQkFBa0IsUUFBUSxJQUFJO0lBQzlCLE9BQU87R0FDVDtFQUNGO0VBQ0EsSUFBSSxDQUFDLFNBQ0gsTUFBTSxTQUFTO09BQ1YsSUFBSSx1QkFBdUI7R0FDaEMsV0FBVyxNQUFNO0dBQ2pCLE1BQU0sUUFBUSxJQUFJO0lBQ2hCLEdBQUcsTUFBTSxLQUFLLFNBQVMsS0FBSyxFQUFnQjtJQUM1QyxHQUFHLE1BQU0sS0FBSyxTQUFTLEtBQUssRUFBcUI7SUFDakQsSUFBSSxLQUFLLE1BQXVCLENBQUMsR0FBRyxLQUNqQyxTQUFTLEtBQUssRUFDakI7R0FDRixDQUFDO0dBQ0Qsa0JBQWtCLFFBQVEsSUFBSTtHQUM5Qix1QkFBdUIsUUFBUSxPQUFPO0dBQ3RDLFFBQVE7RUFDVjtDQUNGO0NBRUEsT0FBTztBQUNUO0FBRUEsZUFBc0IsWUFDcEIsUUFDQSxNQUNBLFFBQ0EsUUFBUSxHQUNSLE1BQU0sS0FBSyxHQUFpQixRQUNKO0NBQ3hCLE1BQU0sVUFBVSxLQUFLO0NBQ3JCLEtBQUssSUFBSSxRQUFRLE9BQU8sUUFBUSxLQUFLLFNBQVM7RUFDNUMsTUFBTSxRQUFRLFFBQVE7RUFDdEIsTUFBTSxlQUFlLFNBQVMsUUFBUSxLQUFLLEVBQUU7RUFDN0MsSUFBSSxhQUFhLFFBQVEsYUFBYSxTQUNwQyxJQUFJO0dBQ0YsTUFBTSxVQUFVO0lBQ2QsS0FBSyxPQUFPLFFBQVE7SUFDcEI7SUFDQTtJQUNBLFFBQVEsTUFBTTtJQUNkLFlBQVksTUFBTTtHQUNwQjtHQUNBLE1BQU0sQ0FBQyxNQUFNLFdBQVcsTUFBTSxRQUM1QixRQUFRLElBQUksQ0FDVixhQUFhLE9BQU8sT0FBTyxHQUMzQixhQUFhLFVBQVUsT0FBTyxDQUNoQyxDQUFDLEdBQ0QsTUFDRjtHQUNBLE1BQU0sT0FBTyxNQUFNO0dBQ25CLE1BQU0sUUFBUSxNQUFNO0dBQ3BCLE1BQU0sY0FBYyxNQUFNO0dBQzFCLE1BQU0sU0FBUyxNQUFNO0dBQ3JCLE1BQU0sVUFBVTtFQUNsQixTQUFTLE9BQU87R0FDZCxJQUFJLFVBQVUsVUFBVSxPQUFPLFNBQzdCO0dBRUYsUUFBUSxNQUFNLEtBQUs7RUFDckI7RUFFRixJQUFJLE1BQU0sV0FBVyxhQUFhLE1BQU0sV0FDdEM7Q0FFSjtDQUNBLE9BQU87QUFDVDtBQUVBLGVBQWUsa0JBQ2IsUUFDQSxVQUNBLFNBQ0EsU0FDcUI7Q0FDckIsTUFBTSxVQUFVLENBQUMsVUFBVSxPQUEyQjtDQUN0RCxNQUFNLFNBQVMsUUFBUSxHQUFvQjtDQUMzQyxJQUFJO0NBQ0osSUFBSTtFQUNGLE1BQU0sWUFBWSxPQUFPLE9BQU8sUUFBUSxJQUFJO0VBQzVDLElBQUksa0JBQWtCLFFBQVEsV0FBVyxVQUFVLE1BQU0sU0FBUztFQUNsRSxJQUFJLE9BQU8sUUFBUSxpQkFBaUIsVUFBVSxtQkFBbUIsR0FBRztHQUNsRSxNQUFNLFdBQVcsTUFBTSxvQkFDckIsUUFDQSxTQUNBLFFBQ0EsUUFDQSxlQUNGO0dBQ0EsUUFBUSxpQkFBa0IsWUFBWTtHQUN0QyxRQUFRLFVBQVcsWUFBWTtHQUMvQixrQkFBa0I7RUFDcEI7RUFDQSxJQUFJLE1BQU0sa0JBQWtCLElBQUksUUFBUSxTQUFTLGtCQUFrQjtFQUNuRSxJQUFJLGNBQWM7RUFDbEIsT0FBTyxjQUFjLE9BQU8sZ0JBQWdCLGlCQUFpQjtHQUMzRCxNQUFNLFFBQVEsUUFBUTtHQUN0QixNQUFNLFlBQVksUUFBUSxHQUFjO0dBQ3hDLE1BQU0sVUFBVSxVQUFVO0dBQzFCLElBQ0UsV0FBVyxPQUFPLE1BQU0sTUFDeEIsVUFBVSxXQUFXLGFBQ3JCLE1BQU0sV0FDTixTQUFTLE9BQU8sTUFBTSxNQUN0QixRQUFRLFdBQVcsV0FFbkI7R0FFRjtHQUNBLElBQUksVUFBVSxhQUFhLFFBQVEsV0FDakM7RUFFSjtFQUNBLE1BQU0sUUFBMkIsQ0FBQztFQUNsQyxNQUFNLFFBQVEsUUFBUSxNQUEyQjtFQUNqRCxJQUFJLGlCQUFpQixRQUNqQixRQUFRLFFBQVEsUUFBUSxRQUFRLEVBQWUsSUFDL0M7RUFDSixNQUFNLDJCQUEyQjtHQUMvQixLQUFLLElBQUksUUFBUSxPQUFPLFFBQVEsS0FBSyxTQUFTO0lBQzVDLElBQUksT0FBTyxTQUNUO0lBRUYsaUJBQWlCLGlCQUNmLFFBQ0EsU0FDQSxPQUNBLE9BQ0EsZ0JBQ0EsU0FDQSxXQUNGO0dBQ0Y7RUFDRjtFQUlBLE1BQU0sVUFBVSxNQUFNLGNBQ3BCLFFBQ0EsU0FDQSxTQUNBLEtBQ0Esb0JBQ0EsV0FDRjtFQUNBLElBQUksU0FBUztHQUNYLFFBQVEsS0FBZ0I7R0FDeEIsTUFBTSxRQUFRO0dBQ2QsSUFBSSxRQUFRLEdBQWlCLE9BQWtCLFdBQVc7SUFDeEQsTUFBTSxXQUFXLE1BQU0sb0JBQ3JCLFFBQ0EsU0FDQSxTQUNBLE1BQ0Y7SUFDQSxRQUFRLEtBQW9CO0lBQzVCLE1BQU0sS0FBSyxJQUFJLEtBQUssV0FBVyxDQUFDO0dBQ2xDLE9BQU8sSUFBSSxRQUFRLEdBQWlCLE1BQWlCLFlBQ25ELE1BQU07R0FFUixtQkFBbUI7RUFDckI7RUFDQSxJQUFJLENBQUMsT0FBTyxXQUFXLENBQUMsUUFBUSxJQUFrQjtHQUNoRCxNQUFNLFFBQWdDLENBQUM7R0FDdkMsS0FBSyxNQUFNLENBQUMsSUFBSSxXQUFXLE9BQU8sWUFBWSxDQUFDLEdBQzdDLElBQUksQ0FBQyxPQUFPLElBQWlCO0lBQzNCLE9BQU8sU0FBVSxPQUFPLEVBQUU7SUFDMUIsTUFBTSxLQUFLLE9BQU8sRUFBbUI7R0FDdkM7R0FFRixLQUFLLE1BQU0sY0FBYyxPQUN2QixXQUFXLE1BQU07RUFFckI7RUFDQSxNQUFNLFlBQVksV0FDaEIsUUFDQSxTQUNBLE9BQ0EsUUFBUSxJQUNSLFlBQVksT0FBTyxTQUFTLFFBQVEsRUFBbUIsR0FDdkQsUUFBUSxFQUNWO0VBQ0EsSUFBSSxRQUFRLElBQXFCLFFBQy9CLFFBQVEsS0FBZ0MsWUFDdEMsUUFBUSxJQUNSLFFBQ0EsUUFDQSxVQUFVLE1BQ1AsZUFDQyxVQUFVLFVBQVUsSUFBSSxJQUFJLG9CQUFvQixPQUFPLEVBQUUsY0FDckQsQ0FDUixDQUNGO0VBRUYsVUFBVSxNQUFNO0NBQ2xCLFNBQVMsT0FBTztFQUNkLGtCQUFrQixRQUFRLE9BQU87RUFDakMsSUFBSSxVQUFVLFVBQVUsT0FBTyxTQUM3QixPQUFPO0VBRVQsTUFBTTtDQUNSO0NBQ0EsSUFBSSxVQUFVLE9BQU8sR0FDbkIsT0FBTztDQUVULE9BQU8sWUFDTCxRQUNBLFNBQ0EsUUFDQSxRQUFRLE9BQTRCLFFBQVEsU0FDeEMsUUFBUSxLQUNSLENBQ047QUFDRjs7Ozs7OztBQVFBLFNBQVMsYUFBYSxRQUEyQixJQUEyQjtDQUMxRSxJQUFJLE9BQU8sUUFBUSxJQUNqQjtDQUVGLE1BQU0sVUFBVSxHQUFHO0NBQ25CLE1BQU0sWUFBWSxPQUFPLE9BQU8sUUFBUSxJQUFJO0NBQzVDLElBQUksVUFBVSxPQUFPO0NBQ3JCLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxRQUFRLFFBQVEsU0FBUztFQUNuRCxNQUFNLFFBQVEsUUFBUTtFQUN0QixNQUFNLFVBQVUsTUFBTSxXQUFXLGFBQWEsQ0FBQyxNQUFNO0VBQ3JELE1BQU0sbUJBQ0osVUFBVSxRQUFRLE9BQU8sTUFBTSxNQUMvQixVQUFVLFFBQVEsV0FBVztFQUMvQixJQUFJLFdBQVcsQ0FBQyxrQkFDZDtFQUVGLE1BQU0sUUFBUSxTQUFTLFFBQVEsS0FBa0I7RUFDakQsTUFBTSxRQUNKLFdBQVcsTUFBTSxVQUNiLElBQ0MsTUFBTSxRQUFRLGFBQWEsT0FBTyxRQUFRO0VBQ2pELE1BQU0sWUFDSixNQUFNLFFBQVEsb0JBQ2IsT0FBTyxRQUFnQjtFQUMxQixJQUFJLENBQUMsYUFBYSxPQUFPLFVBQVUsWUFBWSxVQUFVLFVBQVU7R0FDakUsSUFBSSxTQUFTO0lBQ1gsUUFBUSxLQUFzQjtJQUM5QixRQUFRLEtBQW9CO0lBQzVCLFFBQVEsS0FBZTtHQUN6QjtHQUNBO0VBQ0Y7RUFDQSxNQUFNLE1BQ0osTUFBTSxRQUFRLGdCQUFnQixPQUFPLFFBQVEsdUJBQXVCO0VBQ3RFLElBQUksV0FBVztFQUNmLElBQUksVUFBVSxPQUF3QixNQUFNLElBQUk7R0FDOUMsV0FBVyxRQUFRLE9BQXdCO0dBQzNDLFFBQVEsS0FBc0I7RUFDaEMsT0FBTztHQUNMLGFBQWEsVUFBVSxFQUFvQjtHQUMzQyxPQUFPLFdBQVcsVUFBVTtFQUM5QjtFQUNBLElBQUksQ0FBQyxTQUdILE9BQU8sV0FBVyxVQUFVO0dBQzFCO0dBQ0EsTUFBTTtHQUNOLG1CQUFtQixLQUFLLElBQUksSUFBSSxNQUFNLEdBQUcsS0FBcUI7R0FDOUQ7R0FDQSxvQkFBb0I7R0FDcEI7RUFDRjtFQUVGLElBQ0UsUUFBUSxNQUNSLENBQUMsWUFDRCxRQUFRLE9BQXVCLFdBRS9CO0VBRUYsUUFBUSxLQUFxQjtFQUM3QixJQUFJLENBQUMsUUFBUSxJQUFjO0dBQ3pCLGFBQWEsUUFBUSxFQUFvQjtHQUN6QyxNQUFNLFlBQVksUUFBUSxLQUFvQixLQUFLLElBQUk7R0FDdkQsSUFBSSxZQUFZLEdBQUc7SUFDakIsUUFBUSxLQUF1QixpQkFDdkIsYUFBYSxRQUFRLEVBQUUsR0FDN0IsU0FDRjtJQUNBO0dBQ0Y7R0FDQSxRQUFRLEtBQW9CO0VBQzlCO0VBQ0EsTUFBTSxVQUFVLFFBQVEsS0FBSyxXQUFXO0dBQ3RDLEdBQUc7R0FDSCxTQUFTO0VBQ1gsRUFBRTtFQUNGLFFBQVEsT0FBUSxTQUFTO0VBQ3pCLE1BQU0sTUFBTyxRQUFRLEtBQWUsT0FDakMsc0JBQXNCLE9BQU8sT0FBTyxXQUFXLE9BQU8sR0FBRyxPQUFPLEVBQ2hFLE1BQU0sYUFBYTtHQUNsQixJQUNFLFlBQ0EsT0FBTyxhQUFhLFdBQ3BCLFFBQVMsT0FBaUIsT0FDMUIsQ0FBQyxRQUFTLElBRVYsUUFBUyxLQUFvQixLQUFLLElBQUksSUFBSTtHQUU1QyxPQUFPO0VBQ1QsQ0FBQztFQUNIO0NBQ0Y7QUFDRjs7Ozs7QUFNQSxTQUFTLGNBQWMsUUFBMkIsSUFBMkI7Q0FDM0UsTUFBTSxVQUFVLE9BQU87Q0FDdkIsSUFDRSxPQUFPLFFBQVEsTUFDZixDQUFDLE9BQU8sTUFBTSxHQUFpQixNQUM1QixVQUFVLE1BQU0sT0FBTyxVQUFVLEVBQ3BDLEdBQ0E7RUFDQSxhQUFhLFVBQVUsRUFBb0I7RUFDM0MsT0FBTyxXQUFXO0NBQ3BCO0FBQ0Y7QUFFQSxlQUFlLG9CQUNiLFFBQ0EsSUFDZTtDQUNmLE1BQU0sVUFBVSxPQUFPO0NBQ3ZCLElBQUksQ0FBQyxTQUNIO0NBRUYsYUFBYSxRQUFRLEVBQW9CO0NBQ3pDLE1BQU0sWUFBWSxRQUFRLEtBQW9CLEtBQUssSUFBSTtDQUN2RCxJQUNFLENBQUMsUUFBUSxNQUNULGFBQWEsS0FDYixDQUFDLG9CQUFvQixHQUFHLEVBQWdCLEVBQUUsTUFDdkMsVUFBVSxNQUFNLE9BQU8sUUFBUSxFQUNsQyxHQUVBO0NBRUYsSUFBSTtDQUNKLElBQUk7RUFDRixNQUFNLFFBQ0osSUFBSSxTQUFlLFlBQVk7R0FDN0IsUUFBUSxXQUFXLFNBQVMsU0FBUztFQUN2QyxDQUFDLEdBQ0QsR0FBRyxHQUFvQixNQUN6QjtDQUNGLFFBQVEsQ0FBQztDQUNULGFBQWEsS0FBSztBQUNwQjtBQUVBLFNBQVMsZUFDUCxRQUNBLFNBQ007Q0FDTixPQUFPLGFBQWE7Q0FDcEIsT0FBTyxPQUFPLFdBQVcsT0FBTztBQUNsQztBQUVBLFNBQWdCLGNBQ2QsUUFDQSxJQUNBLFNBQ0EsZ0JBQ007Q0FDTixNQUFNLFdBQVcsT0FBTztDQUN4QixNQUFNLGNBQWMsT0FBTztDQUMzQixNQUFNLGlCQUFpQixPQUFPO0NBQzlCLEtBQUssTUFBTSxTQUFTLFNBQVM7RUFDM0IsTUFBTSxVQUFVO0VBQ2hCLElBQUksZ0JBQ0YsTUFBTSxZQUFZO0NBRXRCO0NBQ0EsTUFBTSxNQUFNLG9CQUFvQixPQUFPLEVBQUU7Q0FDekMsTUFBTSx5QkFBUyxJQUFJLElBQTJCO0NBQzlDLHNCQUE2QixnQkFBZ0IsQ0FBQyxHQUFHLElBQWtCO0VBQ2pFLE1BQU0sTUFBTSxLQUFLLElBQUk7RUFHckIsTUFBTSw2QkFBYSxJQUFJLElBQVk7RUFDbkMsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLFFBQVEsUUFBUSxTQUFTO0dBQ25ELE1BQU0sUUFBUSxRQUFRO0dBQ3RCLElBQUksUUFBUSxPQUFPLE1BQU0sV0FBVyxXQUNsQyxXQUFXLElBQUksTUFBTSxFQUFFO0VBRTNCO0VBQ0EsS0FBSyxNQUFNLFNBQVMsQ0FBQyxHQUFHLFVBQVUsR0FBRyxlQUFlLE9BQU8sQ0FBQyxHQUFHO0dBQzdELElBQUksTUFBTSxXQUFXLGFBQWEsV0FBVyxJQUFJLE1BQU0sRUFBRSxHQUN2RDtHQUdGLE1BQU0sUUFBUSxTQUFTLFFBQVEsS0FBSTtHQUNuQyxJQUNFLENBQUMsTUFBTSxRQUFRLFVBQ2YsTUFBTSxNQUFNLGNBQ1QsTUFBTSxVQUNGLE1BQU0sUUFBUSxpQkFDZixPQUFPLFFBQVEsd0JBQ2YsTUFDQyxNQUFNLFFBQVEsVUFBVSxPQUFPLFFBQVEsaUJBQWlCLE1BRS9EO0dBRUYsT0FBTyxJQUNMLE1BQU0sSUFDTixlQUFlLElBQUksTUFBTSxFQUFFLE1BQU0sUUFDN0IsUUFDQztJQUNDLEdBQUc7SUFDSCxTQUFTO0lBQ1QsWUFBWTtJQUNaLFNBQVMsQ0FBQztHQUNaLENBQ047RUFDRjtDQUNGO0NBRUEsR0FBRyxLQUFtQixDQUFDO0NBQ3ZCLE9BQU8sU0FBUztDQUVoQixNQUFNLFVBQVcsT0FBTyxnQkFBZ0IsYUFBYSxPQUFPO0NBQzVELGVBQWUsUUFBUSxPQUFPO0NBRzlCLHVCQUNFLFFBQ0EsQ0FIdUIsR0FBRyxlQUFlLE9BQU8sR0FBRyxHQUFHLFFBR3RELEVBQWdCLFFBQ2IsVUFBcUIsTUFBTSxXQUFXLE9BQU8sSUFBSSxNQUFNLEVBQUUsTUFBTSxLQUNsRSxHQUNBLE9BQ0Y7Q0FDQSxzQkFBNkIsY0FBYztFQUN6QyxNQUFNLFVBQVUsR0FBRyxLQUFtQjtFQUN0QyxJQUFJLFdBQVcsT0FBTyxhQUFhLFNBQ2pDLFFBQVEsR0FBZ0I7Q0FFNUI7Q0FDQSxrQkFBa0IsUUFBUSxVQUFVLFNBQVMsYUFBYSxTQUFTLEVBQUU7QUFDdkU7Ozs7OztBQU9BLGVBQWUsYUFDYixRQUNBLE9BQ2U7Q0FDZixJQUFJLFVBQVUsT0FBTztDQUNyQixPQUFPLFdBQVcsWUFBWSxPQUFPO0VBQ25DLFFBQVE7RUFDUixNQUFNLFFBQVE7RUFDZCxVQUFVLE9BQU87Q0FDbkI7QUFDRjtBQUVBLFNBQVMsZUFDUCxRQUNBLElBQ0EsU0FDZTtDQUNmLE1BQU0sVUFBVSxRQUFRLEdBQWtCO0NBQzFDLE1BQU0sV0FBVyxRQUFRO0NBQ3pCLElBQUksQ0FBQyxVQUNILE9BQU8sT0FBTyxTQUFTO0VBQ3JCLEdBQUc7RUFDSCxTQUFTO0VBQ1QsZUFBZTtDQUNqQixDQUFRO0NBRVYsSUFBSSxRQUFRLGdCQUNWLE9BQU8sT0FBTyxTQUFTO0VBQ3JCLE9BQU8sU0FBUyxrQkFBa0IsVUFBVTtFQUM1QyxnQkFBZ0I7RUFDaEIsU0FBUztFQUNULGVBQWU7Q0FDakIsQ0FBUTtDQUVULFNBQXVELGFBQ3RELEdBQUcsS0FBcUI7Q0FDMUIsT0FBTyxtQkFBbUI7Q0FDMUIsTUFBTSxZQUFZLE9BQU8sZUFBZTtFQUN0QyxHQUFHO0VBQ0gsZ0JBQWdCLFFBQVE7RUFDeEIsU0FBUztFQUNULGFBQWEsUUFBUTtFQUNyQixvQkFBb0IsUUFBUTtFQUM1QixlQUFlO0NBQ2pCLENBQUM7Q0FDRCxxQkFBcUI7RUFDbkIsSUFBSSxPQUFPLHFCQUFxQixVQUM5QixPQUFPLG1CQUFtQjtDQUU5QixDQUFDO0NBQ0QsT0FBTztBQUNUO0FBRUEsZUFBZSxjQUNiLFFBQ0EsSUFDQSxNQUNBLE9BQ0EsWUFDZTtDQUNmLE1BQU0sT0FBTyxLQUFLLEtBQUssV0FBVyxFQUFFLEdBQUcsTUFBTSxFQUFFO0NBQy9DLHNCQUFzQixJQUFJO0NBQzFCLEtBQUssTUFBTSxRQUFRLE9BQU87RUFDeEIsY0FBYyxRQUFRLEtBQUssS0FBSyxHQUFnQjtFQUNoRCxLQUFLLEtBQUssTUFBa0IsS0FBSztDQUNuQztDQUdBLE1BQU0sT0FBTyxDQUFDLEdBQUcsSUFBbUIsSUFBSTtDQUN4QyxJQUFJO0NBQ0osSUFBSTtFQUNGLFVBQVUsTUFBTSxXQUNkLFFBQ0EsTUFDQSxPQUNBLEdBQUcsSUFDSCxVQUNGO0NBQ0YsU0FBUyxPQUFPO0VBQ2QsdUJBQXVCLFFBQVEsSUFBSTtFQUNuQyxNQUFNO0NBQ1I7Q0FDQSxJQUFJLFVBQVUsT0FBTyxHQUFHO0VBQ3RCLHVCQUF1QixRQUFRLElBQUk7RUFDbkMsSUFDRSxRQUFRLE9BQWtCLGNBQzFCLE9BQU8sUUFBUSxNQUNmLE9BQU8sZUFBZSxNQUV0QixNQUFNLGVBQWUsUUFBUSxJQUFJLE9BQU87RUFFMUM7Q0FDRjtDQUNBLE1BQU0sWUFBWSxRQUFRLFNBQVMsR0FBRyxHQUFvQixNQUFNO0NBQ2hFLElBQUksT0FBTyxRQUFRLE1BQU0sT0FBTyxlQUFlLE1BQU07RUFDbkQsdUJBQXVCLFFBQVEsSUFBSTtFQUNuQztDQUNGO0NBQ0EsS0FBSyxNQUFNLFNBQVMsTUFBMEI7RUFDNUMsTUFBTSxTQUFTLE9BQU8sT0FBTyxJQUFJLE1BQU0sRUFBRTtFQUN6QyxJQUFJLFFBQVEsV0FBVyxPQUFPLFlBQVksTUFBTSxTQUFTO0dBQ3ZELE9BQU8sT0FBTyxPQUFPLE1BQU0sRUFBRTtHQUM3QixjQUFjLFFBQVEsTUFBTTtFQUM5QjtDQUNGO0NBQ0EsZUFBZSxRQUFRLElBQUk7Q0FDM0IsdUJBQXVCLFFBQVEsTUFBTSxJQUFJO0FBQzNDO0FBRUEsZUFBZSxxQkFDYixRQUNBLElBQ0Esa0JBQ0EsU0FDQSxNQUNBLGdCQUNlO0NBQ2YsTUFBTSxTQUFTLE1BQU0sa0JBQ25CLFFBQ0EsR0FBRyxJQUNILEdBQUcsSUFDSDtFQUNFLEdBQUc7RUFDSCxHQUFHO0VBQ0gsT0FBTztFQUNQO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRixDQUNGO0NBRUEsSUFBSSxVQUFVLE1BQU0sR0FBRztFQUNyQixNQUFNLFNBQVMsT0FBTyxPQUFrQixjQUFjLE9BQU8sUUFBUTtFQUNyRSxJQUFJLENBQUMsVUFBVSxPQUFPLEdBQWtCLFFBQVEsZ0JBQzlDLGNBQWMsUUFBUSxFQUFFO0VBRTFCLHVCQUF1QixRQUFRLEdBQUcsRUFBZ0I7RUFDbEQsR0FBRyxLQUFtQixDQUFDO0VBQ3ZCLElBQUksQ0FBQyxRQUNIO0VBRUYsSUFBSSxPQUFPLFFBQVEsSUFBSTtHQUNyQixjQUFjLFFBQVEsRUFBRTtHQUN4QjtFQUNGO0VBQ0Esc0JBQTZCLGdCQUFnQixHQUFHLElBQzlDLE9BQU8sbUJBQW1CO0VBRTVCLE1BQU0sZUFBZSxRQUFRLElBQUksTUFBTTtFQUN2QztDQUNGO0NBQ0EsTUFBTSxVQUFVLE9BQU87Q0FDdkIsSUFBSSxPQUFPLFFBQVEsSUFHakIsTUFBTSxvQkFBb0IsUUFBUSxFQUFFO0NBRXRDLElBQUksT0FBTyxRQUFRLElBQUk7RUFDckIsY0FBYyxRQUFRLEVBQUU7RUFDeEIsdUJBQXVCLFFBQVEsT0FBTztFQUN0QyxrQkFBa0IsUUFBUSxNQUFNO0VBQ2hDO0NBQ0Y7Q0FDQSxNQUFNLGFBQWEsR0FBRztDQUN0QixNQUFNLGFBQWEsc0JBQ2pCLFlBQ0EsT0FBTyxPQUFPLGlCQUFpQixJQUFJLENBQ3JDO0NBQ0EsTUFBTSxhQUFhLE9BQU87Q0FDMUIsTUFBTSxPQUFPLG9CQUFvQixZQUFZO0VBQzNDLElBQUksT0FBTyxRQUFRLElBQ2pCLE1BQU0sb0JBQW9CLFFBQVEsRUFBRTtFQUV0QyxJQUFJLE9BQU8sUUFBUSxJQUFJO0dBQ3JCLGNBQWMsUUFBUSxFQUFFO0dBQ3hCLHVCQUF1QixRQUFRLE9BQU87R0FDdEMsa0JBQWtCLFFBQVEsTUFBTTtHQUNoQztFQUNGO0VBQ0EsTUFBTSxlQUFlO0dBQ25CLGNBQWMsUUFBUSxFQUFFO0dBQ3hCLGNBQWMsUUFBUSxJQUFJLFNBQVMsY0FBYztHQUNqRCxJQUFJLE9BQU8sUUFBUSxJQUNqQjtHQUVGLE9BQU8sS0FBSztJQUFFLE1BQU07SUFBVSxHQUFHO0dBQVcsQ0FBQztHQUM3QyxJQUFJLE9BQU8sUUFBUSxJQUNqQixPQUFPLEtBQUs7SUFBRSxNQUFNO0lBQXNCLEdBQUc7R0FBVyxDQUFDO0VBRTdEO0VBQ0EsTUFBTSxXQUFXLE1BQU0sT0FBTyxnQkFBZ0IsUUFBUSxPQUFPO0VBQzdELHNCQUE2QixnQkFBZ0IsR0FBRyxJQUM5QyxHQUFHLEtBQW1CO0VBRXhCLElBQUksT0FBTyxRQUFRLElBQUk7R0FDckIsa0JBQWtCLFFBQVEsTUFBTTtHQUNoQztFQUNGO0VBQ0EsSUFBSSxZQUFZLFFBSWQsY0FDRSxRQUNBLElBQ0EsU0FDQSxZQUNBLE9BQU8sRUFDVCxFQUFFLE1BQU0sUUFBUSxLQUFLO0VBRXZCLE9BQU8sWUFBWTtHQUNqQixPQUFPLE9BQU8saUJBQWlCLElBQUksVUFBVTtHQUM3QyxPQUFPLE9BQU8sT0FBTyxJQUFJLE1BQU07R0FDL0IsSUFBSSxPQUFPLFFBQVEsSUFDakIsT0FBTyxLQUFLO0lBQUUsTUFBTTtJQUFjLEdBQUc7R0FBVyxDQUFDO0dBRW5ELElBQUksWUFBWSxPQUFPLFFBQVEsSUFDN0IsT0FBTyxLQUFLO0lBQUUsTUFBTTtJQUFjLEdBQUc7R0FBVyxDQUFDO0VBRXJELENBQUM7RUFDRCxJQUFJLE9BQU8sUUFBUSxJQUNqQjtFQUVGLE9BQU8sZ0JBQWdCLFFBQVE7RUFDL0IsT0FBTyxpQkFBaUI7Q0FDMUIsQ0FBQztBQUNIO0FBRUEsZUFBc0IsZ0JBQ3BCLFFBQ0EsTUFDZTtDQUNmLElBQUksZ0JBQWdCO0NBQ3BCLHNCQUE2QixjQUMzQixnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sb0JBQW9CLENBQUMsQ0FBQyxPQUFPLE1BQU07Q0FFOUQsTUFBTSxnQkFBZ0IsT0FBTztDQUM3QixNQUFNLG1CQUFtQixPQUFPLE9BQU8saUJBQWlCLElBQUk7Q0FDNUQsTUFBTSxtQkFBbUIsb0JBQW9CLE9BQU8sT0FBTyxTQUFTLElBQUk7Q0FDeEUsTUFBTSxXQUFXLE9BQU87Q0FDeEIsTUFBTSxrQkFBa0IsT0FBTztDQUcvQixNQUFNLFlBQ0osaUJBQWlCLFNBQVMsU0FBUyxPQUM5QixnQkFBZ0IsY0FBYyxJQUMvQjtDQUNOLE1BQU0sVUFBVSxPQUFPO0NBQ3ZCLE1BQU0sc0JBQXNCLGdCQUN4QixTQUNBLFVBQVUsR0FBZTtDQUM3QixNQUFNLFlBQVksSUFBSSxnQkFBZ0I7Q0FDdEMsTUFBTSxvQkFBb0IsT0FBTztDQUNqQyxPQUFPLGFBQWE7Q0FDcEIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLHFCQUNyQixVQUFVLEdBQWdCO0NBRTVCLG1CQUFtQixNQUFNO0NBR3pCLElBQUksQ0FBQyxVQUFVLE9BQU8sU0FBUztFQUM3QixNQUFNLGFBQWEsc0JBQXNCLFVBQVUsZ0JBQWdCO0VBQ25FLE9BQU8sS0FBSztHQUFFLE1BQU07R0FBb0IsR0FBRztFQUFXLENBQUM7RUFDdkQsSUFBSSxDQUFDLFVBQVUsT0FBTyxTQUNwQixPQUFPLEtBQUs7R0FBRSxNQUFNO0dBQWdCLEdBQUc7RUFBVyxDQUFDO0NBRXZEO0NBQ0EsSUFBSSxVQUFVLE9BQU8sU0FBUztFQUM1QixNQUFNLGFBQWEsUUFBUSxhQUFhO0VBQ3hDO0NBQ0Y7Q0FDQSxNQUFNLFdBQVcsaUJBQWlCLFNBQVMsU0FBUztDQUNwRCxJQUFJLGFBQWE7Q0FDakIsTUFBTSw0QkFDcUIsZ0JBQWdCLGdCQUNyQyxPQUFPLFlBQVksVUFBVTtFQUMzQixhQUFhO0VBQ2IsZ0JBQWdCO0NBQ2xCLENBQUMsSUFDRCxPQUFPLFlBQVksVUFBVSxFQUFFLGFBQWEsVUFBVSxDQUFDO0NBQzdELHNCQUFzQixPQUFPO0NBQzdCLE1BQU0saUJBQWlCLHNCQUNuQixRQUFTLEdBQWdCLE9BQU8sSUFDaEM7Q0FDSixJQUFJLGdCQUNGLGFBQWE7TUFFYixxQkFBcUIsTUFBTTtDQUU3QixJQUFJLFVBQVUsT0FBTyxTQUFTO0VBQzVCLHVCQUF1QixRQUFRLE9BQU87RUFDdEMsTUFBTSxhQUFhLFFBQVEsYUFBYTtFQUN4QztDQUNGO0NBQ0EsT0FBTyxhQUFhO0NBRXBCLElBQUk7Q0FDSixNQUFNLFlBQ0oscUJBQ0UsUUFDQSxJQUNBLGdCQUNNLGFBQWEsUUFBUSxFQUFFLEdBQzdCLE1BQU0sTUFDTixjQUNGO0NBQ0YsTUFBTSxPQUFPLE1BQU0sT0FDZixJQUFJLFNBQWUsWUFBYSxTQUFTLE9BQVEsSUFDakQsUUFBUSxRQUFRLEVBQUUsS0FBSyxHQUFHO0NBQzlCLE1BQU0sS0FBc0I7RUFDMUI7RUFDQTtFQUNBO0VBQ0E7RUFDQSxLQUFLLElBQUk7RUFDVCxLQUFLLFdBQVcsYUFBYSxRQUFRLEVBQUUsQ0FBQztDQUMxQztDQUNBLHNCQUE2QixnQkFBZ0IsZUFBZTtFQUMxRCxHQUFHLEtBQW1CLENBQUMsT0FBTztFQUM5QixPQUFPLG1CQUFtQjtDQUM1QjtDQUNBLE9BQU8sTUFBTTtDQUNiLElBQUksZUFBZTtFQUNqQixLQUFLLE1BQU0sU0FBUyxPQUFPLE9BQU8sUUFBUSxJQUFJLEdBQXVCO0dBQ25FLElBQUksT0FBTyxRQUFRLElBQ2pCO0dBRUYsSUFBSSxNQUFNLFlBQ1IsWUFBWSxRQUFRLE9BQU8sS0FBSztFQUVwQztFQUNBLGNBQWMsR0FBb0IsTUFBTTtFQUN4Qyx1QkFDRSxRQUNBLGNBQWMsSUFDZCxHQUFHLElBQ0gsSUFDRjtDQUNGO0NBQ0EsSUFBSSxPQUFPLFFBQVEsSUFBSTtFQUNyQix1QkFBdUIsUUFBUSxHQUFHLEVBQWdCO0VBQ2xELEdBQUcsS0FBbUIsQ0FBQztFQUN2QixTQUFTO0VBQ1QsTUFBTSxhQUFhLFFBQVEsRUFBRTtFQUM3QjtDQUNGO0NBQ0EsT0FBTyxZQUFZO0VBQ2pCLE9BQU8sT0FBTyxPQUFPLElBQUksU0FBUztFQUNsQyxPQUFPLE9BQU8sU0FBUyxJQUFJLFFBQVE7Q0FDckMsQ0FBQztDQUdELElBQ0Usa0JBQ0MsQ0FBQyxPQUFPLFdBQVcsVUFDbEIsUUFBUSxJQUFJLFdBQVcsYUFDdkIsQ0FBQyxRQUFRLE1BQU0sVUFBVSxNQUFNLFNBQVMsR0FFMUMsYUFBYSxRQUFRLEVBQUU7Q0FHekIsU0FBUyxJQUFJLENBQUM7Q0FDZCxNQUFNLEdBQUc7QUFDWDtBQUVBLGVBQXNCLG1CQUNwQixRQUNlO0NBQ2YsTUFBTSxVQUFVLE9BQU87Q0FDdkIsSUFDRSxXQUNBLENBQUMsUUFBUSxNQUNULE9BQU8sT0FBTyxPQUFPLElBQUksTUFBTSxXQUMvQjtFQUNBLE1BQU0sUUFBUTtFQUNkLElBQUksT0FBTyxRQUFRLFNBQ2pCLE1BQU0sYUFBYSxRQUFRLE9BQU87Q0FFdEM7Q0FFQSxPQUFPLFVBQVUsTUFBTTtDQUN2QixPQUFPLFdBQVc7Q0FDbEIsT0FBTyxtQkFBbUI7Q0FDMUIsTUFBTSxnQkFBZ0IsUUFBUSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQzlDO0FBRUEsZUFBc0IsbUJBV3BCLFFBT0EsTUFhMkM7Q0FDM0Msc0JBQzJCLGlCQUN2QixPQUE2QixvQkFDN0IsT0FBTyxNQUFNLEtBRWY7Q0FFRixJQUFJLFdBQVcsT0FBTyxjQUNwQixJQUNGO0NBQ0EsS0FBSyxJQUFJLFlBQVksSUFBSyxhQUFhO0VBQ3JDLE1BQU0sT0FBTyxPQUFPO0VBQ3BCLE1BQU0sYUFBYSxJQUFJLGdCQUFnQjtFQUN2QyxJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJO0dBQ0YsSUFBSTtJQUNGLFVBQVUsT0FBTyxZQUFZLFVBQVUsRUFDckMsYUFBYSxXQUNmLENBQUM7SUFDRCxzQkFBc0IsT0FBTztJQUM3QixVQUFVLE9BQU8sOEJBQWMsSUFBSSxJQUFJLEdBQUcsSUFBSSxZQUFZLE9BQU87SUFDakUsU0FBUyxNQUFNLGtCQUFrQixRQUFRLFVBQVUsU0FBUztLQUMxRDtLQUNBO0tBQ0E7S0FDQTtJQUNGLENBQUM7R0FDSCxVQUFVO0lBQ1IsSUFBSSxRQUFRO0tBQ1YsU0FDRSxPQUNBLE9BQU8sVUFBVTtLQUNuQix1QkFBdUIsUUFBUSxPQUFRO0lBQ3pDO0lBQ0EsV0FBVyxNQUFNO0dBQ25CO0dBQ0EsSUFBSSxDQUFDLFVBQVUsTUFBTSxHQUNuQixPQUFPLE9BQU87R0FHaEIsSUFDRSxDQUFDLFVBQ0QsT0FBTyxTQUFTLHVCQUNVLGlCQUN0QixPQUE2QixvQkFDN0IsT0FBTyxNQUFNLEtBRWpCO0dBRUYsV0FBVyxPQUFPO0VBQ3BCLFNBQVMsT0FBTztHQUNkLElBQUksQ0FBQyxXQUFXLEtBQUssR0FDbkIsUUFBUSxNQUFNLEtBQUs7R0FFckI7RUFDRjtDQUNGO0FBQ0Y7QUFXQSxlQUFzQixRQUFRLFFBQWtDO0NBQzlELHNCQUE2QixnQkFBZ0IsQ0FBQyxPQUFPLE9BQ25ELE1BQU0sSUFBSSxNQUNSLDBHQUNGO0NBRUYsTUFBTSxNQUFNLE9BQU87Q0FFbkIsTUFBTSxXQUFXLE9BQU8sUUFBUTtDQUNoQyxJQUFJLFVBQVUsUUFBUTtFQUNwQixJQUFJLElBQUksSUFBSSxJQUNWLFNBQVMsS0FBSyxZQUFZLENBQUMsUUFBUSxLQUFLLFFBQVEsZ0JBQWdCLENBQUMsQ0FDbkU7RUFDQSxJQUFJLE9BQU8sU0FBUyxXQUFXLE9BQU8sQ0FBQztDQUN6QztDQUNBLElBQUksY0FBYztDQUVsQixNQUFNLG1CQUFtQixJQUFJO0NBQzdCLHNCQUE2QixnQkFBZ0IsQ0FBQyxrQkFDNUMsTUFBTSxJQUFJLE1BQ1Isb0hBQ0Y7Q0FFRixPQUFPLE1BQU0sRUFBRSxVQUFVLGlCQUFrQixTQUFTO0NBQ3BELE9BQU8sUUFBUSxNQUFNLEVBQ25CLE9BQ0UsU0FBUyxjQUFjLDhCQUE0QixHQUdsRCxRQUNMO0NBRUEsTUFBTSxvQkFBb0IsaUJBQWtCO0NBRTVDLE1BQU0sYUFBYSxJQUFJLGdCQUFnQjtDQUN2QyxNQUFNLG9CQUFvQixPQUFPO0NBQ2pDLE9BQU8sYUFBYTtDQUNwQixtQkFBbUIsTUFBTTtDQUV6QixNQUFNLGtCQUFrQixPQUFPLGVBQWU7Q0FFOUMsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7RUFDRixNQUFNLFFBQ0osT0FBTyxRQUFRLFVBQVUsaUJBQWtCLGNBQWMsR0FDekQsV0FBVyxNQUNiO0VBQ0EsSUFBSSxDQUFDLFVBQVUsR0FDYjtFQUlGLE1BQU0sa0JBQWtCLE9BQU8sUUFBUTtFQUN2QyxxQkFBcUIsZ0JBQWdCO0VBQ3JDLHNCQUFzQixnQkFBZ0I7RUFDdEMsT0FBTyxxQkFBcUI7RUFDNUIsV0FBVyxPQUFPO0VBQ2xCLE9BQU8sT0FBTyxTQUFTLElBQUksUUFBUTtFQUNuQyxhQUFhLE9BQU8sWUFBWSxVQUFVLEVBQ3hDLGFBQWEsV0FDZixDQUFDO0NBQ0gsU0FBUyxPQUFPO0VBQ2QsSUFBSSxVQUFVLEdBQ1osT0FBTyxhQUFhO0VBRXRCLFdBQVcsTUFBTSxLQUFLO0VBQ3RCLElBQUksVUFBVSxXQUFXLFFBQ3ZCLE1BQU07Q0FFVjtDQUNBLElBQUksQ0FBQyxVQUFVLEdBQ2I7Q0FFRixNQUFNLFlBQWtDLENBQUM7Q0FDekMsSUFBSTtDQUNKLElBQUksbUJBQW1CO0NBQ3ZCLE1BQU0sYUFBYSxVQUFrQjtFQUVuQyxtQkFBbUIsS0FBSyxJQUFJLGtCQUFrQixRQUFRLENBQUM7RUFDdkQsTUFBTSxVQUFVLFVBQVUsT0FBTyxLQUFLO0VBQ3RDLEtBQUssTUFBTSxTQUFTLFNBQ2xCLElBQ0UsU0FBUyxRQUFRLEtBQUssRUFBRSxRQUFRLFdBQy9CLE1BQU0sV0FBVyxhQUNmLENBQUMsTUFBTSxXQUFXLGdCQUFnQixRQUVyQyxpQkFDRSxRQUlBO0dBQ0UsR0FBRztHQUNILFFBQVE7R0FDUixPQUFPO0dBQ1AsU0FBUztFQUNYLEdBQ0EsT0FBTyxPQUFPLElBQUksTUFBTSxFQUFFLENBQzVCO0VBR0osdUJBQXVCLFFBQVEsT0FBTztDQUN4QztDQUtBLE1BQU0sU0FDSixrQkFBa0IsU0FBUyxXQUFXLFNBQ2xDLFdBQVcsV0FBVyxVQUFVLE1BQU0sU0FBUyxJQUFJLElBQ25ELGtCQUFrQjtDQUN4QixJQUFJLGFBQWE7Q0FDakIsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLFFBQVEsU0FBUztFQUMzQyxNQUFNLFlBQVksV0FBVztFQUM3QixNQUFNLGFBQWEsa0JBQWtCO0VBQ3JDLElBQ0UsT0FBTyxXQUFXLE1BQU0sWUFDeEIsa0JBQWtCLFdBQVcsQ0FBQyxNQUFNLFVBQVUsSUFDOUM7R0FDQSxvQkFBb0I7R0FDcEI7RUFDRjtFQUNBLG1CQUFtQixRQUFRO0VBQzNCLE1BQU0sUUFBUSxTQUFTLFFBQVEsU0FBUztFQUN4QyxJQUNFLE9BQU8sY0FDTixXQUFXLE1BQU0sYUFDaEIsV0FBVyxNQUFNLFVBQ2pCLE1BQU0sUUFBUSxRQUVoQixVQUFVLGFBQWEsV0FBVztFQUVwQyxVQUFVLFNBQVMsV0FBVztFQUM5QixVQUFVLE1BQU0sV0FBVztFQUMzQixNQUFNLFFBQVEsTUFBTSxVQUFVO0VBQzlCLFVBQVUsWUFBWSxXQUFXO0VBQ2pDLFVBQVUsUUFBUSxXQUFXO0VBQzdCLFVBQVUsY0FBYyxXQUFXO0VBS25DLElBSEUsVUFBVSxXQUFXLFdBQ3JCLFVBQVUsV0FBVyxjQUNyQixVQUFVLFdBQ0U7R0FDWixhQUFhO0dBQ2IsVUFBVSxLQUFLLFNBQVM7R0FDeEIsSUFBSSxVQUFVLFFBQVEsU0FBUyxVQUFVLFFBQVEsYUFDL0Msb0JBQW9CO0dBRXRCO0VBQ0Y7RUFDQSxJQUFJLFVBQVUsV0FBVyxXQUFXO0dBQ2xDLG9CQUFvQjtHQUNwQjtFQUNGO0VBRUEsVUFBVSxLQUFLLFNBQVM7RUFDeEIsSUFBSSxVQUFVLFFBQVEsYUFDcEIsb0JBQW9CO0NBRXhCO0NBQ0EsSUFDRSxDQUFDLGNBQ0QsVUFBVSxXQUFXLFVBQ3JCLFNBQVMsV0FBVyxRQUVwQixrQkFBa0I7Q0FLcEIsTUFBTSxTQUFTLFVBQVUsSUFBSSxPQUFPLFVBQVU7RUFDNUMsSUFBSTtHQUNGLE1BQU0sUUFBUSxTQUFTLFFBQVEsS0FBSztHQUNwQyxPQUFPLE1BQU0sWUFDVCxRQUFRLElBQUksQ0FDVixlQUFlLEtBQUssR0FDcEIsZUFBZSxPQUFPLG1CQUFtQixDQUMzQyxDQUFDLElBQ0QsZUFDRSxPQUNBLE1BQU0sV0FBVyxVQUNiLG1CQUNBLE1BQU0sV0FBVyxhQUNmLHNCQUNBLE1BQ1I7R0FDSixPQUFPO0VBQ1QsUUFBUTtHQUNOLE9BQU87RUFDVDtDQUNGLENBQUM7Q0FDRCxJQUFJLGVBQWU7Q0FDbkIsSUFBSTtFQUNGLE9BQ0UsZUFBZSxPQUFPLFVBQ3JCLE1BQU0sUUFBUSxPQUFPLGVBQWdCLFdBQVcsTUFBTSxHQUV2RDtDQUVKLFFBQVE7RUFDTjtDQUNGO0NBQ0EsSUFBSSxDQUFDLFVBQVUsR0FDYjtDQUVGLElBQUksZUFBZSxVQUFVLFFBQzNCLFVBQVUsWUFBWTtDQUt4QixNQUFNLGFBQWEsS0FBSyxJQUN0QixvQkFBb0IsVUFBVSxTQUMxQixVQUFVLFNBQVMsSUFDbkIsVUFBVSxRQUdkLGVBQWUsT0FBTyxTQUFTLGVBQWUsZ0JBQ2hEO0NBQ0EsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLFlBQVksU0FBUztFQUMvQyxNQUFNLFFBQVEsV0FBVztFQUN6QixNQUFNLFFBQVEsU0FBUyxRQUFRLEtBQUs7RUFDcEMsTUFBTSxnQkFDSixXQUFXLFFBQVEsSUFBSSxXQUFXLE9BQU8sUUFBUSxXQUFXLENBQUM7RUFDL0QsSUFBSTtFQUNKLElBQUksTUFBTSxRQUFRLFNBQVM7R0FDekIsSUFBSTtJQUNGLGVBQWUsTUFBTSxPQUNuQixNQUFNLFFBQVEsUUFBUTtLQUNwQixNQUFNLE1BQU07S0FDWixRQUFRLE1BQU07S0FDZCxTQUFTO0tBQ1Q7S0FDQSxXQUFXLFNBQ1QsT0FBTyxTQUFTO01BQ2QsR0FBRztNQUNILGVBQWU7S0FDakIsQ0FBQztLQUNILGVBQWUsT0FBTztLQUN0QixPQUFPLE1BQU07S0FDYixpQkFBaUI7S0FDakIsU0FBUztLQUNULFNBQVM7S0FDVCxTQUFTLE1BQU07SUFDakIsQ0FBQyxLQUFLLENBQUM7R0FDWCxRQUFRO0lBQ04sSUFBSSxDQUFDLFVBQVUsR0FDYjtJQUVGLElBQ0UsTUFBTSxXQUFXLFdBQ2pCLE1BQU0sV0FBVyxjQUNqQixDQUFDLE1BQU0sV0FDUDtLQUVBLGtCQUFrQixLQUFLLElBQUksbUJBQW1CLE9BQU8sS0FBSztLQUMxRCxVQUFVLEtBQUs7S0FDZjtJQUNGO0dBQ0Y7R0FDQSxJQUFJLENBQUMsVUFBVSxHQUNiO0VBRUo7RUFDQSxNQUFNLFVBQVU7R0FDZCxHQUFHO0dBQ0gsR0FBRztHQUNILEdBQUksVUFBVSxVQUFVLGtCQUFrQixPQUFRO0VBQ3BEO0NBQ0Y7Q0FFQSxNQUFNLFlBQ0osUUFDQSxDQUFDLFVBQVUsVUFBVSxHQUNyQixXQUFXLFFBQ1gsR0FDQSxnQkFDRjtDQUNBLElBQUksQ0FBQyxVQUFVLEdBQ2I7Q0FFRixNQUFNLGtCQUNKLG9CQUFvQixVQUFhLFVBQVUsU0FBUztDQUN0RCxNQUFNLG1CQUNKLGNBQWMsVUFBVSxXQUFXLFNBQVMsYUFBYTtDQUMzRCxJQUFJLFlBQVksa0JBQWtCLGFBQWE7Q0FDL0MsSUFBSTtDQUNKLElBQUksbUJBQW1CLG9CQUFvQixRQUFXO0VBQ3BELE1BQU0sV0FBVyxVQUFVO0VBRTNCLG1CQUNFLFNBQVMsUUFBUSxlQUFlLG1CQUFtQixrQkFBa0IsSUFDakUsbUJBQ0E7RUFDTixZQUFZLFVBQVUsTUFBTTtFQUM1QixVQUFVLG1CQUFtQjtHQUMzQixHQUFHO0dBQ0gsUUFBUTtHQUNSLEtBQUssU0FBUyxRQUFRLGNBQWMsY0FBYztHQUNsRCxXQUFXO0VBQ2I7Q0FDRjtDQUVBLE1BQU0sY0FBYztFQUNsQixNQUFNLGtCQUFrQixPQUFPLFFBQVE7RUFDdkMsT0FBTyxtQkFDTCxDQUFDLE9BQU8sT0FDUixnQkFBZ0IsU0FBUyxzQkFDekIsZ0JBQWdCLFVBQVUsdUJBQzFCLE9BQU8sZUFBZSxvQkFDdEIsaUJBQWlCLFVBQ2pCLENBQUMsV0FBVyxPQUFPLFVBQ2pCLGFBQ0E7Q0FDTjtDQUNBLE1BQU0sVUFBOEMsQ0FDbEQsUUFDQyxZQUFZO0VBQ1gsSUFBSSxPQUFPLGFBQWEsU0FDdEI7RUFJRixPQUFPLFdBQVc7RUFDbEIsTUFBTSxTQUFTLGlCQUFpQjtFQUNoQyxJQUNFLENBQUMsV0FDRCxDQUFDLE1BQU0sS0FDUCxpQkFBaUIsTUFBTSxPQUFPLFVBQVUsTUFBTSxPQUFPLFFBQVEsUUFBUSxFQUFFLEdBQ3ZFO0dBQ0EsV0FBVyxNQUFNO0dBQ2pCO0VBQ0Y7RUFDQSxJQUFJLGtCQUFrQjtFQUN0QixJQUFJLG9CQUFvQjtRQUNqQixJQUFJLFFBQVEsUUFBUSxRQUFRLGlCQUFpQixTQUNoRCxJQUFJLFdBQVcsUUFBUSxPQUFPLFFBQVEsUUFBUSxJQUFJO0lBQ2hELGtCQUFrQixRQUFRLGtCQUFtQixJQUFJLFFBQVE7SUFDekQ7R0FDRjs7RUFHSixNQUFNLFNBQVMsaUJBQWlCLEtBQUssV0FBVyxFQUFFLEdBQUcsTUFBTSxFQUFFO0VBQzdELElBQUksb0JBQW9CLFFBQ3RCLE9BQU8saUJBQW1CLFlBQVk7RUFFeEMsdUJBQXVCLFFBQVEsUUFBUSxPQUFPLEdBQUcsUUFBUSxHQUFHLE1BQU0sQ0FBQztFQUNuRSxLQUFLLElBQUksUUFBUSxRQUFRLFFBQVEsUUFBUSxRQUFRLFNBQVM7R0FDeEQsTUFBTSxRQUFRLFFBQVE7R0FDdEIsTUFBTSxXQUFXLFdBQVc7R0FDNUIsSUFBSSxVQUFVLE9BQU8sTUFBTSxNQUFNLFNBQVMsTUFDeEMsTUFBTSxPQUFPLFNBQVM7R0FFeEIsTUFBTSxrQkFBa0I7RUFDMUI7RUFDQSxPQUFPO0NBQ1QsQ0FDRjtDQUNBLE9BQU8sYUFBYTtDQUNwQixPQUFPLGdCQUFnQixhQUFhLGdCQUFnQjtDQUNwRCxPQUFPLFdBQVc7Q0FDbEIsT0FBTyxhQUFhO0NBQ3BCLE9BQU8sWUFBWTtFQUNqQixPQUFPLE9BQU8sV0FBVyxTQUFTO0VBQ2xDLE9BQU8sT0FBTyxPQUFPLElBQUksTUFBTTtFQUMvQixJQUFJLENBQUMsaUJBQ0gsT0FBTyxPQUFPLGlCQUFpQixJQUFJLE9BQU8sT0FBTyxTQUFTLElBQUksQ0FBQztDQUVuRSxDQUFDO0FBQ0giLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9sb2FkLWNsaWVudC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBLZWVwIHRoaXMgZmlsZW5hbWUgZnJlZSBvZiBhIHNlY29uZGFyeSBleHRlbnNpb24gc28gZGVjbGFyYXRpb24gZ2VuZXJhdGlvblxuLy8gY2FuIHJld3JpdGUgcmVsYXRpdmUgaW1wb3J0cyBmb3IgYm90aCBFU00gYW5kIENKUy5cbmltcG9ydCB7IGlzTm90Rm91bmQgfSBmcm9tICcuL25vdC1mb3VuZCdcbmltcG9ydCB7IGlzUmVkaXJlY3QgfSBmcm9tICcuL3JlZGlyZWN0J1xuaW1wb3J0IHtcbiAgZ2V0TG9jYXRpb25DaGFuZ2VJbmZvLFxuICBsaWZlY3ljbGVFbmQsXG4gIHJ1blJvdXRlTGlmZWN5Y2xlLFxufSBmcm9tICcuL3JvdXRlcidcbmltcG9ydCB7IGh5ZHJhdGVTc3JNYXRjaElkIH0gZnJvbSAnLi9zc3Ivc3NyLW1hdGNoLWlkJ1xuaW1wb3J0IHR5cGUgeyBHTE9CQUxfU0VST1ZBTCwgR0xPQkFMX1RTUiB9IGZyb20gJy4vc3NyL2NvbnN0YW50cydcbmltcG9ydCB0eXBlIHsgVHNyU3NyR2xvYmFsIH0gZnJvbSAnLi9zc3IvdHlwZXMnXG5pbXBvcnQgdHlwZSB7IFBhcnNlZExvY2F0aW9uIH0gZnJvbSAnLi9sb2NhdGlvbidcbmltcG9ydCB0eXBlIHsgTmF2aWdhdGVPcHRpb25zIH0gZnJvbSAnLi9saW5rJ1xuaW1wb3J0IHR5cGUgeyBBbnlSb3V0ZU1hdGNoIH0gZnJvbSAnLi9NYXRjaGVzJ1xuaW1wb3J0IHR5cGUgeyBOb3RGb3VuZEVycm9yIH0gZnJvbSAnLi9ub3QtZm91bmQnXG5pbXBvcnQgdHlwZSB7XG4gIEFueVJvdXRlLFxuICBMb2FkZXJGbkNvbnRleHQsXG4gIFJvdXRlQ29udGV4dE9wdGlvbnMsXG4gIFJvdXRlTG9hZGVyRm4sXG59IGZyb20gJy4vcm91dGUnXG5pbXBvcnQgdHlwZSB7IEFueVJlZGlyZWN0IH0gZnJvbSAnLi9yZWRpcmVjdCdcbmltcG9ydCB0eXBlIHsgQW55Um91dGVyLCBSb3V0ZXJDb3JlLCBUcmFpbGluZ1NsYXNoT3B0aW9uIH0gZnJvbSAnLi9yb3V0ZXInXG5pbXBvcnQgdHlwZSB7IFJvdXRlUGF0aHMgfSBmcm9tICcuL3JvdXRlSW5mbydcbmltcG9ydCB0eXBlIHsgUm91dGVySGlzdG9yeSB9IGZyb20gJ0B0YW5zdGFjay9oaXN0b3J5J1xuXG50eXBlIFJvdXRlQ29tcG9uZW50VHlwZSA9XG4gIHwgJ2NvbXBvbmVudCdcbiAgfCAncGVuZGluZ0NvbXBvbmVudCdcbiAgfCAnZXJyb3JDb21wb25lbnQnXG4gIHwgJ25vdEZvdW5kQ29tcG9uZW50J1xuXG5leHBvcnQgZnVuY3Rpb24gcmVwbGFjZVJvdXRlQ2h1bmsoXG4gIHJvdXRlOiBBbnlSb3V0ZSxcbiAgbGF6eUZuOiBBbnlSb3V0ZVsnbGF6eUZuJ10sXG4pOiB2b2lkIHtcbiAgcm91dGUubGF6eUZuID0gbGF6eUZuID8/IHJvdXRlLmxhenlGblxuICByb3V0ZS5fbGF6eSA9IHVuZGVmaW5lZFxufVxuXG5mdW5jdGlvbiBwcmVsb2FkQ29tcG9uZW50KFxuICByb3V0ZTogQW55Um91dGUsXG4gIHR5cGU6IFJvdXRlQ29tcG9uZW50VHlwZSxcbik6IFByb21pc2U8dm9pZD4gfCB1bmRlZmluZWQge1xuICByZXR1cm4gKHJvdXRlLm9wdGlvbnNbdHlwZV0gYXMgYW55KT8ucHJlbG9hZD8uKClcbn1cblxuZnVuY3Rpb24gbG9hZENvbXBvbmVudHMoXG4gIHJvdXRlOiBBbnlSb3V0ZSxcbiAgb25QZW5kaW5nUmVhZHk/OiAoKSA9PiB2b2lkLFxuKTogUHJvbWlzZTx2b2lkPiB8IHVuZGVmaW5lZCB7XG4gIGNvbnN0IGNvbXBvbmVudCA9IHByZWxvYWRDb21wb25lbnQocm91dGUsICdjb21wb25lbnQnKVxuICBsZXQgcGVuZGluZyA9IHByZWxvYWRDb21wb25lbnQocm91dGUsICdwZW5kaW5nQ29tcG9uZW50JylcbiAgaWYgKG9uUGVuZGluZ1JlYWR5KSB7XG4gICAgaWYgKHBlbmRpbmcpIHtcbiAgICAgIHBlbmRpbmcgPSBwZW5kaW5nLnRoZW4ob25QZW5kaW5nUmVhZHkpXG4gICAgfSBlbHNlIHtcbiAgICAgIG9uUGVuZGluZ1JlYWR5KClcbiAgICB9XG4gIH1cbiAgaWYgKGNvbXBvbmVudCAmJiBwZW5kaW5nKSB7XG4gICAgcmV0dXJuIFByb21pc2UuYWxsKFtjb21wb25lbnQsIHBlbmRpbmddKS50aGVuKCgpID0+IHt9KVxuICB9XG4gIHJldHVybiBjb21wb25lbnQgPz8gcGVuZGluZ1xufVxuXG5leHBvcnQgZnVuY3Rpb24gbG9hZFJvdXRlQ2h1bmsoXG4gIHJvdXRlOiBBbnlSb3V0ZSxcbiAgLy8gYGZhbHNlYCB3YWl0cyBvbmx5IGZvciBsYXp5IHJvdXRlIG9wdGlvbnMsIGJlZm9yZSBhIGJvdW5kYXJ5IGlzIHNlbGVjdGVkLlxuICBjb21wb25lbnRUeXBlPzogJ2Vycm9yQ29tcG9uZW50JyB8ICdub3RGb3VuZENvbXBvbmVudCcgfCBmYWxzZSxcbiAgb25QZW5kaW5nUmVhZHk/OiAoKSA9PiB2b2lkLFxuKTogUHJvbWlzZTx2b2lkPiB8IHVuZGVmaW5lZCB7XG4gIGNvbnN0IGFmdGVyTGF6eSA9ICgpID0+XG4gICAgY29tcG9uZW50VHlwZSA9PT0gZmFsc2VcbiAgICAgID8gdW5kZWZpbmVkXG4gICAgICA6IGNvbXBvbmVudFR5cGVcbiAgICAgICAgPyBwcmVsb2FkQ29tcG9uZW50KHJvdXRlLCBjb21wb25lbnRUeXBlKVxuICAgICAgICA6IGxvYWRDb21wb25lbnRzKHJvdXRlLCBvblBlbmRpbmdSZWFkeSlcbiAgY29uc3QgY3VycmVudCA9IHJvdXRlLl9sYXp5XG4gIGlmIChjdXJyZW50KSB7XG4gICAgcmV0dXJuIGN1cnJlbnQgPT09IHRydWUgPyBhZnRlckxhenkoKSA6IGN1cnJlbnQudGhlbihhZnRlckxhenkpXG4gIH1cbiAgaWYgKCFyb3V0ZS5sYXp5Rm4pIHtcbiAgICByZXR1cm4gYWZ0ZXJMYXp5KClcbiAgfVxuXG4gIGNvbnN0IHByb21pc2UgPSByb3V0ZS5sYXp5Rm4oKS50aGVuKFxuICAgIChsYXp5Um91dGUpID0+IHtcbiAgICAgIC8vIEhNUiBjbGVhcnMgdGhlIG93bmVyIGJlZm9yZSBhbiBvYnNvbGV0ZSBpbXBvcnQgY2FuIHNldHRsZS5cbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ3Byb2R1Y3Rpb24nIHx8IHJvdXRlLl9sYXp5ID09PSBwcm9taXNlKSB7XG4gICAgICAgIGNvbnN0IHsgaWQ6IF9pZCwgLi4ub3B0aW9ucyB9ID0gbGF6eVJvdXRlLm9wdGlvbnNcbiAgICAgICAgT2JqZWN0LmFzc2lnbihyb3V0ZS5vcHRpb25zLCBvcHRpb25zKVxuICAgICAgICByb3V0ZS5fbGF6eSA9IHRydWVcbiAgICAgIH1cbiAgICB9LFxuICAgIChlcnJvcikgPT4ge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAncHJvZHVjdGlvbicgfHwgcm91dGUuX2xhenkgPT09IHByb21pc2UpIHtcbiAgICAgICAgcm91dGUuX2xhenkgPSB1bmRlZmluZWRcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yXG4gICAgfSxcbiAgKVxuICByb3V0ZS5fbGF6eSA9IHByb21pc2VcbiAgcmV0dXJuIHByb21pc2UudGhlbihhZnRlckxhenkpXG59XG5cbi8qKiBSZXR1cm4gdGhlIHN0cnVjdHVyYWwgbGFuZSB0aHJvdWdoIHRoZSBmaXJzdCB0ZXJtaW5hbCByZW5kZXIgYm91bmRhcnkuICovXG5leHBvcnQgZnVuY3Rpb24gX2dldFJlbmRlcmVkTWF0Y2hlcyhcbiAgbWF0Y2hlczogQXJyYXk8QW55Um91dGVNYXRjaD4sXG4pOiBBcnJheTxBbnlSb3V0ZU1hdGNoPiB7XG4gIGNvbnN0IGVuZCA9XG4gICAgbWF0Y2hlcy5maW5kSW5kZXgoXG4gICAgICAobWF0Y2gpID0+IG1hdGNoLnN0YXR1cyAhPT0gJ3N1Y2Nlc3MnIHx8IG1hdGNoLl9ub3RGb3VuZCxcbiAgICApICsgMVxuICByZXR1cm4gZW5kICYmIGVuZCA8IG1hdGNoZXMubGVuZ3RoID8gbWF0Y2hlcy5zbGljZSgwLCBlbmQpIDogbWF0Y2hlc1xufVxuXG4vKiogUmV0dXJuIHRoZSBsYW5lIHdob3NlIGRvY3VtZW50IGFzc2V0cyBiZWxvbmcgdG8gdGhlIGN1cnJlbnQgcHJlc2VudGF0aW9uLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIF9nZXRBc3NldE1hdGNoZXMoXG4gIG1hdGNoZXM6IEFycmF5PEFueVJvdXRlTWF0Y2g+LFxuKTogQXJyYXk8QW55Um91dGVNYXRjaD4ge1xuICBsZXQgZW5kID0gbWF0Y2hlcy5sZW5ndGhcbiAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGVuZDsgaW5kZXgrKykge1xuICAgIGNvbnN0IG1hdGNoID0gbWF0Y2hlc1tpbmRleF0hXG4gICAgLy8gYF9hc3NldEVuZGAgaXMgb25seSBldmVyIHNldCBvbiBoeWRyYXRpb24gcHJlc2VudGF0aW9uIGNsb25lcyB0aGF0IGFyZVxuICAgIC8vIGBzdGF0dXM6ICdwZW5kaW5nJ2AsIGBzc3I6ICdkYXRhLW9ubHknYCwgZXJyb3ItZnJlZSwgYW5kIG5vdCBub3QtZm91bmRcbiAgICAvLyAoc2VlIGh5ZHJhdGUudHMpLCBhbmQgY29tbWl0cyBjbGVhciBpdCDigJQgc28gaXRzIHByZXNlbmNlIGFsb25lIGlzIHRoZSBndWFyZC5cbiAgICBpZiAobWF0Y2guX2Fzc2V0RW5kICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGVuZCA9IE1hdGgubWluKGVuZCwgTWF0aC5tYXgoaW5kZXggKyAxLCBtYXRjaC5fYXNzZXRFbmQpKVxuICAgICAgY29udGludWVcbiAgICB9XG4gICAgaWYgKG1hdGNoLnN0YXR1cyAhPT0gJ3N1Y2Nlc3MnIHx8IG1hdGNoLl9ub3RGb3VuZCkge1xuICAgICAgZW5kID0gaW5kZXggKyAxXG4gICAgICBicmVha1xuICAgIH1cbiAgfVxuICAvLyBgZW5kYCBvbmx5IGV2ZXIgc2hyaW5rcyB0byBgaW5kZXggKyAxID49IDFgLCBzbyBubyB6ZXJvIGd1YXJkIGlzIG5lZWRlZC5cbiAgcmV0dXJuIGVuZCA8IG1hdGNoZXMubGVuZ3RoID8gbWF0Y2hlcy5zbGljZSgwLCBlbmQpIDogbWF0Y2hlc1xufVxuXG5kZWNsYXJlIGNvbnN0IGxhbmVQaGFzZTogdW5pcXVlIHN5bWJvbFxuXG50eXBlIExhbmVQaGFzZSA9ICdtYXRjaGVkJyB8ICdjb250ZXh0dWFsaXplZCcgfCAncmVkdWNlZCcgfCAncHJvamVjdGVkJ1xuXG4vKipcbiAqIExhbmUgbWF0Y2hlcyBjYXJyeSB0aGVpciBsYW5lJ3MgcGhhc2Ugc28gZnVuY3Rpb25zIGNhbiBkZW1hbmQgZXZpZGVuY2Ugb2ZcbiAqIHBpcGVsaW5lIHBvc2l0aW9uIChlLmcuIGBjb21taXRNYXRjaGVzYCBvbmx5IGFjY2VwdHMgYSBwcm9qZWN0ZWQgbGFuZSdzXG4gKiBtYXRjaGVzKS4gVGhlIGJyYW5kIGlzIHBoYW50b20g4oCUIGl0IG5ldmVyIGV4aXN0cyBhdCBydW50aW1lLlxuICovXG50eXBlIExhbmVNYXRjaGVzPFRQaGFzZSBleHRlbmRzIExhbmVQaGFzZT4gPSBBcnJheTxXb3JrTWF0Y2g+ICYge1xuICByZWFkb25seSBbbGFuZVBoYXNlXT86IFRQaGFzZVxufVxuXG50eXBlIExhbmU8VFBoYXNlIGV4dGVuZHMgTGFuZVBoYXNlPiA9IFtcbiAgbG9jYXRpb246IFBhcnNlZExvY2F0aW9uLFxuICBtYXRjaGVzOiBMYW5lTWF0Y2hlczxUUGhhc2U+LFxuICBiYWNrZ3JvdW5kPzogQXJyYXk8QmFja2dyb3VuZExvYWRlclRhc2s+LFxuICBiYWNrZ3JvdW5kU2V0dGxlbWVudD86IFByb21pc2U8SW5kZXhlZE91dGNvbWUgfCB1bmRlZmluZWQ+LFxuXSAmIHsgcmVhZG9ubHkgW2xhbmVQaGFzZV0/OiBUUGhhc2UgfVxuXG50eXBlIE1hdGNoZWRMYW5lID0gTGFuZTwnbWF0Y2hlZCc+XG50eXBlIENvbnRleHR1YWxpemVkTGFuZSA9IExhbmU8J2NvbnRleHR1YWxpemVkJz5cbnR5cGUgUmVkdWNlZExhbmUgPSBMYW5lPCdyZWR1Y2VkJz5cbnR5cGUgUHJvamVjdGVkTGFuZSA9IExhbmU8J3Byb2plY3RlZCc+XG5cbmNvbnN0IFNVQ0NFU1MgPSAwXG5jb25zdCBFUlJPUiA9IDFcbmNvbnN0IE5PVF9GT1VORCA9IDJcbi8vIENvbnRyb2wgb3V0Y29tZXMgc3RheSBjb250aWd1b3VzIHNvIHRoZSBob3QgcGF0aCBjYW4gdGVzdCB0aGVtIHRvZ2V0aGVyLlxuY29uc3QgUkVESVJFQ1RFRCA9IDNcbmNvbnN0IENBTkNFTEVEID0gNFxuY29uc3QgQ0FOQ0VMRURfT1VUQ09NRTogW2tpbmQ6IHR5cGVvZiBDQU5DRUxFRF0gPSBbQ0FOQ0VMRURdXG5cbnR5cGUgUmVkaXJlY3RPdXRjb21lID0gW1xuICBraW5kOiB0eXBlb2YgUkVESVJFQ1RFRCxcbiAgcmVkaXJlY3Q6IEFueVJlZGlyZWN0LFxuICBsb2NhdGlvbj86IFBhcnNlZExvY2F0aW9uLFxuXVxuXG50eXBlIE5vblJlZGlyZWN0T3V0Y29tZSA9XG4gIHwgW2tpbmQ6IHR5cGVvZiBTVUNDRVNTLCBkYXRhOiB1bmtub3duXVxuICB8IFtraW5kOiB0eXBlb2YgRVJST1IsIGVycm9yOiB1bmtub3duXVxuICB8IFtraW5kOiB0eXBlb2YgTk9UX0ZPVU5ELCBlcnJvcjogTm90Rm91bmRFcnJvcl1cbiAgfCBba2luZDogdHlwZW9mIENBTkNFTEVEXVxuXG50eXBlIFJhd0xvYWRlck91dGNvbWUgPVxuICB8IE5vblJlZGlyZWN0T3V0Y29tZVxuICB8IFtraW5kOiB0eXBlb2YgUkVESVJFQ1RFRCwgcmVkaXJlY3Q6IEFueVJlZGlyZWN0XVxuXG50eXBlIExvYWRlck91dGNvbWUgPSBOb25SZWRpcmVjdE91dGNvbWUgfCBSZWRpcmVjdE91dGNvbWVcblxudHlwZSBJbmRleGVkT3V0Y29tZSA9IFtpbmRleDogbnVtYmVyLCBvdXRjb21lOiBMb2FkZXJPdXRjb21lLCBib3VuZGFyeT86IG51bWJlcl1cblxuZXhwb3J0IHR5cGUgTG9hZGVyRmxpZ2h0ID0gW1xuICBvdXRjb21lOiBQcm9taXNlPFJhd0xvYWRlck91dGNvbWU+LFxuICBjb250cm9sbGVyOiBBYm9ydENvbnRyb2xsZXIsXG4gIGxlYXNlczogbnVtYmVyLFxuXVxuXG50eXBlIFdvcmtNYXRjaCA9IEFueVJvdXRlTWF0Y2ggJiB7XG4gIF9mbGlnaHQ/OiBMb2FkZXJGbGlnaHRcbn1cblxuZGVjbGFyZSBjb25zdCBtYXRjaFBoYXNlOiB1bmlxdWUgc3ltYm9sXG5cbi8qKlxuICogQSBtYXRjaCB3aG9zZSBsb2FkZXIgb3V0Y29tZSBoYXMgYmVlbiBhcHBsaWVkIGJ5IGBzZXR0bGVJbnRvYCwgd2hpY2ggaXMgdGhlXG4gKiBzb2xlIGdyYW50ZXIgb2YgdGhpcyBicmFuZCAocGhhbnRvbSwgemVyby1ydW50aW1lKS4gQ29uc3VtZXJzIHRoYXQgcmVxdWlyZVxuICogaXQg4oCUIGUuZy4gYGNhY2hlTG9hZGVyTWF0Y2hgIOKAlCBjYW4gb25seSBiZSByZWFjaGVkIGFmdGVyIHNldHRsZW1lbnQsIHNvIHRoZVxuICogY29tcGlsZXIgZW5mb3JjZXMgdGhlIGxvYWRlcuKGknNldHRsZeKGkmNhY2hlIG9yZGVyaW5nLiBTb3VyY2VzIHRoYXQgYXJyaXZlXG4gKiBhbHJlYWR5IHNldHRsZWQgKGRlaHlkcmF0ZWQgc2VydmVyIGRhdGEpIG11c3QgY2FzdCBhdCBhIG5hbWVkIGJvdW5kYXJ5LlxuICovXG50eXBlIFNldHRsZWRNYXRjaCA9IFdvcmtNYXRjaCAmIHsgcmVhZG9ubHkgW21hdGNoUGhhc2VdOiAnc2V0dGxlZCcgfVxuXG5leHBvcnQgdHlwZSBMb2FkVHJhbnNhY3Rpb24gPSBbXG4gIGNvbnRyb2xsZXI6IEFib3J0Q29udHJvbGxlcixcbiAgcmVkaXJlY3RzOiBudW1iZXIsXG4gIGxvY2F0aW9uOiBQYXJzZWRMb2NhdGlvbixcbiAgbWF0Y2hlczogQXJyYXk8QW55Um91dGVNYXRjaD4sXG4gIHN0YXJ0ZWRBdDogbnVtYmVyLFxuICBkb25lOiBQcm9taXNlPHZvaWQ+LFxuICAvKipcbiAgICogRGV2LW9ubHkgSE1SIHJlZnJlc2ggbW9kZS4gUHJlc2VuY2UgZm9yY2VzIHN1Y2Nlc3NvciByZW1hdGVyaWFsaXphdGlvblxuICAgKiB1bnRpbCB0aGlzIHB1YmxpY2F0aW9uIGlzIGFja25vd2xlZGdlZC4gVGhlIG9wdGlvbmFsIGh5ZHJhdGlvbiBoYW5kb2ZmIGlzXG4gICAqIHJldGlyZWQgd2hlbiB0aGUgcmVmcmVzaCBwdWJsaXNoZXMuXG4gICAqL1xuICByZWZyZXNoPzogW2hhbmRvZmY6IE5vbk51bGxhYmxlPEFueVJvdXRlclsnX2hhbmRvZmYnXT4gfCB1bmRlZmluZWRdLFxuXVxuXG5leHBvcnQgdHlwZSBQZW5kaW5nU2Vzc2lvbiA9IFtcbiAgZ2VuZXJhdGlvbjogTG9hZFRyYW5zYWN0aW9uLFxuICBib3VuZGFyeUlkOiBzdHJpbmcsXG4gIC8qKiBQZW5kaW5nIHJldmVhbCB0aW1lIHVudGlsIGFja25vd2xlZGdlZCwgdGhlbiBtaW5pbXVtLXZpc2libGUtdW50aWwgdGltZS4gKi9cbiAgZGVhZGxpbmU6IG51bWJlcixcbiAgcmV2ZWFsVGltZXI/OiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PixcbiAgYWNrPzogUHJvbWlzZTxib29sZWFuPiB8IHRydWUsXG4gIGNvbXBvbmVudD86IHVua25vd24sXG5dXG5cbnR5cGUgQ29vcmRpbmF0b3JSb3V0ZXIgPSBBbnlSb3V0ZXIgJiB7XG4gIC8qKiBBY3RpdmUgc3BlY3VsYXRpdmUgbGFuZXMgcmV0YWluZWQgZm9yIGNhbmNlbGxhdGlvbiwgaW52YWxpZGF0aW9uLCBhbmQgY2FjaGUgY2xlYXJpbmcuICovXG4gIF9wcmVsb2Fkcz86IE1hcDxBYm9ydENvbnRyb2xsZXIsIEFycmF5PEFueVJvdXRlTWF0Y2g+PlxuICBfcmVmcmVzaE5leHRMb2FkPzogYm9vbGVhblxufVxuXG50eXBlIExvYWRlclRhc2sgPSBbXG4gIGluZGV4OiBudW1iZXIsXG4gIG91dGNvbWU6IFByb21pc2U8TG9hZGVyT3V0Y29tZT4sXG4gIGNodW5rRmFpbHVyZTogUHJvbWlzZTxJbmRleGVkT3V0Y29tZSB8IHVuZGVmaW5lZCB8IHZvaWQ+LFxuICBjYW5kaWRhdGU/OiBXb3JrTWF0Y2gsXG5dXG5cbnR5cGUgQmFja2dyb3VuZExvYWRlclRhc2sgPSBbXG4gIGluZGV4OiBudW1iZXIsXG4gIG91dGNvbWU6IFByb21pc2U8TG9hZGVyT3V0Y29tZT4sXG4gIGNodW5rRmFpbHVyZTogUHJvbWlzZTxJbmRleGVkT3V0Y29tZSB8IHVuZGVmaW5lZCB8IHZvaWQ+LFxuICBjYW5kaWRhdGU6IFdvcmtNYXRjaCxcbl1cblxudHlwZSBFeGVjdXRlTGFuZU9wdGlvbnMgPSBbXG4gIGNvbnRyb2xsZXI6IEFib3J0Q29udHJvbGxlcixcbiAgcmVkaXJlY3RzOiBudW1iZXIsXG4gIGJhc2U6IEFycmF5PEFueVJvdXRlTWF0Y2g+LFxuICBwcmVsb2FkPzogYm9vbGVhbixcbiAgc3luYz86IGJvb2xlYW4sXG4gIGZvcmNlU3RhbGVSZWxvYWQ/OiBib29sZWFuLFxuICByZXNvbHZlZFByZWZpeD86IG51bWJlcixcbiAgb25SZWFkeT86ICgpID0+IHZvaWQsXG5dXG5cbnR5cGUgQ29udHJvbE91dGNvbWUgPSBSZWRpcmVjdE91dGNvbWUgfCBba2luZDogdHlwZW9mIENBTkNFTEVEXVxuXG50eXBlIExhbmVSZXN1bHQgPSBQcm9qZWN0ZWRMYW5lIHwgQ29udHJvbE91dGNvbWVcblxuZnVuY3Rpb24gaXNDb250cm9sKFxuICByZXN1bHQ6IExhbmU8YW55PiB8IENvbnRyb2xPdXRjb21lLFxuKTogcmVzdWx0IGlzIENvbnRyb2xPdXRjb21lIHtcbiAgcmV0dXJuIHR5cGVvZiByZXN1bHRbMCAvKiBsb2NhdGlvbiBvciBraW5kICovXSA9PT0gJ251bWJlcidcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHdhaXRGb3I8VD4oXG4gIHZhbHVlOiBUIHwgUHJvbWlzZUxpa2U8VD4sXG4gIHNpZ25hbDogQWJvcnRTaWduYWwsXG4pOiBQcm9taXNlPFQ+IHtcbiAgaWYgKHNpZ25hbC5hYm9ydGVkKSB7XG4gICAgcmV0dXJuIFByb21pc2UucmFjZShbUHJvbWlzZS5yZWplY3Qoc2lnbmFsKSwgdmFsdWVdKVxuICB9XG4gIHJldHVybiBuZXcgUHJvbWlzZTxUPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgY29uc3QgYWJvcnQgPSAoKSA9PiByZWplY3Qoc2lnbmFsKVxuICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsIGFib3J0LCB7IG9uY2U6IHRydWUgfSlcbiAgICBQcm9taXNlLnJlc29sdmUodmFsdWUpXG4gICAgICAudGhlbihyZXNvbHZlLCByZWplY3QpXG4gICAgICAvLyBCb3RoIHNldHRsZW1lbnQgY2FsbGJhY2tzIHJldHVybiBub3JtYWxseSwgc28gdGhpcyBjaGFpbiBmdWxmaWxscy5cbiAgICAgIC50aGVuKCgpID0+IHNpZ25hbC5yZW1vdmVFdmVudExpc3RlbmVyKCdhYm9ydCcsIGFib3J0KSlcbiAgfSlcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldFJvdXRlKHJvdXRlcjogQW55Um91dGVyLCBtYXRjaDogV29ya01hdGNoKTogQW55Um91dGUge1xuICByZXR1cm4gKHJvdXRlci5yb3V0ZXNCeUlkIGFzIFJlY29yZDxzdHJpbmcsIEFueVJvdXRlPilbbWF0Y2gucm91dGVJZF0hXG59XG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZShcbiAgdmFsdWU6IHVua25vd24sXG4gIHJlamVjdGVkOiBib29sZWFuLFxuICByb3V0ZUlkPzogc3RyaW5nLFxuKTogUmF3TG9hZGVyT3V0Y29tZSB7XG4gIGlmIChpc1JlZGlyZWN0KHZhbHVlKSkge1xuICAgIHJldHVybiBbUkVESVJFQ1RFRCwgdmFsdWVdXG4gIH1cbiAgaWYgKGlzTm90Rm91bmQodmFsdWUpKSB7XG4gICAgdmFsdWUucm91dGVJZCB8fD0gcm91dGVJZFxuICAgIHJldHVybiBbTk9UX0ZPVU5ELCB2YWx1ZV1cbiAgfVxuICBpZiAoIXJlamVjdGVkKSB7XG4gICAgcmV0dXJuIFtTVUNDRVNTLCB2YWx1ZV1cbiAgfVxuICBpZiAodHlwZW9mICh2YWx1ZSBhcyBhbnkpPy50aGVuID09PSAnZnVuY3Rpb24nKSB7XG4gICAgdmFsdWUgPSBuZXcgRXJyb3IoJ0EgUHJvbWlzZSB3YXMgdGhyb3duJywgeyBjYXVzZTogdmFsdWUgfSlcbiAgfVxuICByZXR1cm4gW0VSUk9SLCB2YWx1ZV1cbn1cblxuZnVuY3Rpb24gbm9ybWFsaXplRXJyb3Iocm91dGU6IEFueVJvdXRlLCBjYXVzZTogdW5rbm93bik6IFJhd0xvYWRlck91dGNvbWUge1xuICBsZXQgb3V0Y29tZSA9IG5vcm1hbGl6ZShjYXVzZSwgdHJ1ZSwgcm91dGUuaWQpXG4gIGlmIChvdXRjb21lWzAgLyoga2luZCAqL10gIT09IEVSUk9SKSB7XG4gICAgcmV0dXJuIG91dGNvbWVcbiAgfVxuICB0cnkge1xuICAgIHJvdXRlLm9wdGlvbnMub25FcnJvcj8uKG91dGNvbWVbMSAvKiBlcnJvciAqL10pXG4gIH0gY2F0Y2ggKG9uRXJyb3JDYXVzZSkge1xuICAgIG91dGNvbWUgPSBub3JtYWxpemUob25FcnJvckNhdXNlLCB0cnVlLCByb3V0ZS5pZClcbiAgfVxuICByZXR1cm4gb3V0Y29tZVxufVxuXG5mdW5jdGlvbiBub3JtYWxpemVMYW5lRXJyb3IoXG4gIHJvdXRlcjogQW55Um91dGVyLFxuICBsYW5lOiBMYW5lPGFueT4sXG4gIHJvdXRlOiBBbnlSb3V0ZSxcbiAgY2F1c2U6IHVua25vd24sXG4gIG9wdGlvbnM6IEV4ZWN1dGVMYW5lT3B0aW9ucyxcbik6IExvYWRlck91dGNvbWUge1xuICBpZiAob3B0aW9uc1swIC8qIGNvbnRyb2xsZXIgKi9dLnNpZ25hbC5hYm9ydGVkKSB7XG4gICAgcmV0dXJuIENBTkNFTEVEX09VVENPTUVcbiAgfVxuICByZXR1cm4gbWF0ZXJpYWxpemVSZWRpcmVjdChcbiAgICByb3V0ZXIsXG4gICAgbGFuZSxcbiAgICByb3V0ZSxcbiAgICBub3JtYWxpemVFcnJvcihyb3V0ZSwgY2F1c2UpLFxuICAgIG9wdGlvbnMsXG4gIClcbn1cblxuYXN5bmMgZnVuY3Rpb24gY29udGV4dHVhbGl6ZShcbiAgcm91dGVyOiBBbnlSb3V0ZXIsXG4gIGxhbmU6IE1hdGNoZWRMYW5lLFxuICBvcHRpb25zOiBFeGVjdXRlTGFuZU9wdGlvbnMsXG4gIGVuZDogbnVtYmVyLFxuICBwbGFuU3VjY2Vzc2Z1bExhbmU6ICgpID0+IHZvaWQsXG4gIHJldGFpbmVkRW5kOiBudW1iZXIsXG4pOiBQcm9taXNlPEluZGV4ZWRPdXRjb21lIHwgdW5kZWZpbmVkPiB7XG4gIGNvbnN0IFtsb2NhdGlvbiwgbWF0Y2hlc10gPSBsYW5lXG4gIGNvbnN0IHNpZ25hbCA9IG9wdGlvbnNbMCAvKiBjb250cm9sbGVyICovXS5zaWduYWxcbiAgY29uc3QgcHJlbG9hZCA9ICEhb3B0aW9uc1szIC8qIHByZWxvYWQgKi9dXG4gIGZvciAobGV0IGluZGV4ID0gb3B0aW9uc1s2IC8qIHJlc29sdmVkUHJlZml4ICovXSA/PyAwOyBpbmRleCA8IGVuZDsgaW5kZXgrKykge1xuICAgIGNvbnN0IG1hdGNoID0gbWF0Y2hlc1tpbmRleF0hXG4gICAgY29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKVxuXG4gICAgbWF0Y2guYWJvcnRDb250cm9sbGVyID0gb3B0aW9uc1swIC8qIGNvbnRyb2xsZXIgKi9dXG4gICAgLy8gQ29udGV4dHVhbGl6YXRpb24gaXMgc2VyaWFsLCBzbyB0aGUgcHJldmlvdXMgbWF0Y2ggYWxyZWFkeSBjb250YWlucyB0aGVcbiAgICAvLyBjb21wbGV0ZSBwYXJlbnQgY29udGV4dCBmb3IgdGhpcyByb3V0ZS5cbiAgICBjb25zdCBwYXJlbnRDb250ZXh0ID1cbiAgICAgIG1hdGNoZXNbaW5kZXggLSAxXT8uY29udGV4dCA/PyByb3V0ZXIub3B0aW9ucy5jb250ZXh0ID8/IHt9XG4gICAgY29uc3QgY29tbW9uID0ge1xuICAgICAgcGFyYW1zOiBtYXRjaC5wYXJhbXMsXG4gICAgICBsb2NhdGlvbixcbiAgICAgIG5hdmlnYXRlOiAob3B0czogYW55KSA9PlxuICAgICAgICByb3V0ZXIubmF2aWdhdGUoe1xuICAgICAgICAgIC4uLm9wdHMsXG4gICAgICAgICAgX2Zyb21Mb2NhdGlvbjogbG9jYXRpb24sXG4gICAgICAgIH0pLFxuICAgICAgYnVpbGRMb2NhdGlvbjogcm91dGVyLmJ1aWxkTG9jYXRpb24sXG4gICAgICBjYXVzZTogcHJlbG9hZCA/ICgncHJlbG9hZCcgYXMgY29uc3QpIDogbWF0Y2guY2F1c2UsXG4gICAgICBhYm9ydENvbnRyb2xsZXI6IG9wdGlvbnNbMCAvKiBjb250cm9sbGVyICovXSxcbiAgICAgIHByZWxvYWQsXG4gICAgICBtYXRjaGVzLFxuICAgICAgcm91dGVJZDogcm91dGUuaWQsXG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAvLyBSZXVzZSB0aGUgcm91dGUncyBjYWNoZWQgY29udHJpYnV0aW9uIHdoaWxlIHJlYnVpbGRpbmcgaXRzIGluaGVyaXRhbmNlLlxuICAgICAgY29uc3Qgcm91dGVDb250ZXh0ID0gKG1hdGNoLl9jdHggfHw9IHJvdXRlLm9wdGlvbnMuY29udGV4dFxuICAgICAgICA/IHJvdXRlLm9wdGlvbnMuY29udGV4dCh7XG4gICAgICAgICAgICAuLi5jb21tb24sXG4gICAgICAgICAgICBkZXBzOiBtYXRjaC5sb2FkZXJEZXBzLFxuICAgICAgICAgICAgY29udGV4dDogcGFyZW50Q29udGV4dCxcbiAgICAgICAgICB9IHNhdGlzZmllcyBSb3V0ZUNvbnRleHRPcHRpb25zPGFueSwgYW55LCBhbnksIGFueSwgYW55PikgfHwge31cbiAgICAgICAgOiB1bmRlZmluZWQpXG4gICAgICBtYXRjaC5jb250ZXh0ID0ge1xuICAgICAgICAuLi5wYXJlbnRDb250ZXh0LFxuICAgICAgICAuLi5yb3V0ZUNvbnRleHQsXG4gICAgICB9XG4gICAgfSBjYXRjaCAoY2F1c2UpIHtcbiAgICAgIHJlbGVhc2VGbGlnaHQocm91dGVyLCBtYXRjaClcbiAgICAgIHJldHVybiBbaW5kZXgsIG5vcm1hbGl6ZUxhbmVFcnJvcihyb3V0ZXIsIGxhbmUsIHJvdXRlLCBjYXVzZSwgb3B0aW9ucyldXG4gICAgfVxuICAgIGlmIChzaWduYWwuYWJvcnRlZCkge1xuICAgICAgcmV0dXJuIFtpbmRleCwgQ0FOQ0VMRURfT1VUQ09NRV1cbiAgICB9XG4gICAgY29uc3QgdmFsaWRhdGlvbkVycm9yID0gbWF0Y2gucGFyYW1zRXJyb3IgPz8gbWF0Y2guc2VhcmNoRXJyb3JcbiAgICBpZiAodmFsaWRhdGlvbkVycm9yICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHJlbGVhc2VGbGlnaHQocm91dGVyLCBtYXRjaClcbiAgICAgIHJldHVybiBbXG4gICAgICAgIGluZGV4LFxuICAgICAgICBub3JtYWxpemVMYW5lRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgdmFsaWRhdGlvbkVycm9yLCBvcHRpb25zKSxcbiAgICAgIF1cbiAgICB9XG4gICAgY29uc3QgYmVmb3JlTG9hZCA9IHJvdXRlLm9wdGlvbnMuYmVmb3JlTG9hZFxuICAgIGlmICghYmVmb3JlTG9hZCkge1xuICAgICAgY29udGludWVcbiAgICB9XG5cbiAgICBjb25zdCBwcmV2aW91c1N0YXR1cyA9IG1hdGNoLnN0YXR1c1xuICAgIGlmIChpbmRleCA+PSByZXRhaW5lZEVuZCkge1xuICAgICAgbWF0Y2guc3RhdHVzID0gJ3BlbmRpbmcnXG4gICAgICBvcHRpb25zWzcgLyogb25SZWFkeSAqL10/LigpXG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBzZXRGZXRjaGluZyhyb3V0ZXIsIG1hdGNoLCAnYmVmb3JlTG9hZCcsIG9wdGlvbnNbMCAvKiBjb250cm9sbGVyICovXSlcbiAgICAgIGNvbnN0IHZhbHVlID0gYmVmb3JlTG9hZCh7XG4gICAgICAgIC4uLmNvbW1vbixcbiAgICAgICAgc2VhcmNoOiBtYXRjaC5zZWFyY2gsXG4gICAgICAgIGNvbnRleHQ6IG1hdGNoLmNvbnRleHQsXG4gICAgICAgIC4uLnJvdXRlci5vcHRpb25zLmFkZGl0aW9uYWxDb250ZXh0LFxuICAgICAgfSlcbiAgICAgIC8vIEFsd2F5cyBhd2FpdCB0byBnaXZlIGEgcXVldWVkIHJlcGxhY2VtZW50IG5hdmlnYXRpb24gb25lIG1pY3JvdGFzayB0b1xuICAgICAgLy8ga2ljayBpbiBiZWZvcmUgY2hlY2tpbmcgY2FuY2VsbGF0aW9uLCBldmVuIGZvciBzeW5jaHJvbm91cyBjb250ZXh0LlxuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgKHR5cGVvZiB2YWx1ZT8udGhlbiA9PT0gJ2Z1bmN0aW9uJ1xuICAgICAgICA/IHdhaXRGb3IodmFsdWUsIHNpZ25hbClcbiAgICAgICAgOiB2YWx1ZSlcbiAgICAgIGlmIChzaWduYWwuYWJvcnRlZCkge1xuICAgICAgICByZXR1cm4gW2luZGV4LCBDQU5DRUxFRF9PVVRDT01FXVxuICAgICAgfVxuICAgICAgY29uc3Qgb3V0Y29tZSA9IG1hdGVyaWFsaXplUmVkaXJlY3QoXG4gICAgICAgIHJvdXRlcixcbiAgICAgICAgbGFuZSxcbiAgICAgICAgcm91dGUsXG4gICAgICAgIG5vcm1hbGl6ZShyZXN1bHQsIGZhbHNlLCByb3V0ZS5pZCksXG4gICAgICAgIG9wdGlvbnMsXG4gICAgICApXG4gICAgICBpZiAob3V0Y29tZVswIC8qIGtpbmQgKi9dICE9PSBTVUNDRVNTKSB7XG4gICAgICAgIHJlbGVhc2VGbGlnaHQocm91dGVyLCBtYXRjaClcbiAgICAgICAgcmV0dXJuIFtpbmRleCwgb3V0Y29tZV1cbiAgICAgIH1cbiAgICAgIG1hdGNoLmNvbnRleHQgPSB7XG4gICAgICAgIC4uLm1hdGNoLmNvbnRleHQsXG4gICAgICAgIC4uLnJlc3VsdCxcbiAgICAgIH1cbiAgICB9IGNhdGNoIChjYXVzZSkge1xuICAgICAgcmVsZWFzZUZsaWdodChyb3V0ZXIsIG1hdGNoKVxuICAgICAgcmV0dXJuIFtpbmRleCwgbm9ybWFsaXplTGFuZUVycm9yKHJvdXRlciwgbGFuZSwgcm91dGUsIGNhdXNlLCBvcHRpb25zKV1cbiAgICB9IGZpbmFsbHkge1xuICAgICAgbWF0Y2guc3RhdHVzID0gcHJldmlvdXNTdGF0dXNcbiAgICAgIHNldEZldGNoaW5nKHJvdXRlciwgbWF0Y2gsIGZhbHNlLCBvcHRpb25zWzAgLyogY29udHJvbGxlciAqL10pXG4gICAgfVxuICB9XG5cbiAgLy8gTGV0IGEgc3luY2hyb25vdXMgbGFuZSBjbGFpbSBwcmVkZWNlc3NvciBmbGlnaHRzIGJlZm9yZSB0aGlzIGZyYW1lIHlpZWxkcy5cbiAgcGxhblN1Y2Nlc3NmdWxMYW5lKClcbiAgcmV0dXJuXG59XG5cbmZ1bmN0aW9uIHJlbGVhc2VPd25lZEZsaWdodChcbiAgcm91dGVyOiBBbnlSb3V0ZXIsXG4gIG1hdGNoOiBXb3JrTWF0Y2gsXG4gIGZsaWdodD86IExvYWRlckZsaWdodCxcbik6IEFib3J0Q29udHJvbGxlciB8IHVuZGVmaW5lZCB7XG4gIGlmICghZmxpZ2h0IHx8IC0tZmxpZ2h0WzIgLyogbGVhc2VzICovXSkge1xuICAgIHJldHVyblxuICB9XG4gIGlmIChyb3V0ZXIuX2ZsaWdodHM/LmdldChtYXRjaC5pZCkgPT09IGZsaWdodCkge1xuICAgIGNvbnN0IGN1cnJlbnQgPSByb3V0ZXIuX3R4XG4gICAgaWYgKFxuICAgICAgY3VycmVudCAmJlxuICAgICAgIWN1cnJlbnRbMCAvKiBjb250cm9sbGVyICovXS5zaWduYWwuYWJvcnRlZCAmJlxuICAgICAgIWN1cnJlbnRbMyAvKiBtYXRjaGVzICovXS5pbmNsdWRlcyhtYXRjaCkgJiZcbiAgICAgIGN1cnJlbnRbMyAvKiBtYXRjaGVzICovXS5zb21lKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5pZCA9PT0gbWF0Y2guaWQpICYmXG4gICAgICBjdXJyZW50WzMgLyogbWF0Y2hlcyAqL10uc29tZShcbiAgICAgICAgKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlzRmV0Y2hpbmcgPT09ICdiZWZvcmVMb2FkJyxcbiAgICAgIClcbiAgICApIHtcbiAgICAgIC8vIEtlZXAgd29yayBkaXNjb3ZlcmFibGUgb25seSB3aGlsZSB0aGUgY3VycmVudCBsYW5lIGlzIHN0aWxsIHJ1bm5pbmdcbiAgICAgIC8vIGJlZm9yZUxvYWQuIExvYWRlciBwbGFubmluZyBwZXJmb3JtcyB0aGUgbWF0Y2hpbmcgemVyby1vd25lciBzd2VlcC5cbiAgICAgIHJldHVyblxuICAgIH1cbiAgICByb3V0ZXIuX2ZsaWdodHMuZGVsZXRlKG1hdGNoLmlkKVxuICB9XG4gIHJldHVybiBmbGlnaHRbMSAvKiBjb250cm9sbGVyICovXVxufVxuXG5mdW5jdGlvbiByZWxlYXNlRmxpZ2h0KHJvdXRlcjogQW55Um91dGVyLCBtYXRjaDogV29ya01hdGNoKTogdm9pZCB7XG4gIGNvbnN0IGZsaWdodCA9IG1hdGNoLl9mbGlnaHRcbiAgbWF0Y2guX2ZsaWdodCA9IHVuZGVmaW5lZFxuICByZWxlYXNlT3duZWRGbGlnaHQocm91dGVyLCBtYXRjaCwgZmxpZ2h0KT8uYWJvcnQoKVxufVxuLyoqXG4gKiBOb3QgcGFzc2luZyBpbiBhIGBuZXh0YCBvd25lcnNoaXAgcmVjaXBpZW50XG4gKiBpcyBlcXVpdmFsZW50IHRvIGRpc2NhcmRpbmcgdGhlIG1hdGNoIHJlc291cmNlc1xuICovXG5mdW5jdGlvbiB0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKFxuICByb3V0ZXI6IEFueVJvdXRlcixcbiAgcHJldmlvdXM6IEFycmF5PEFueVJvdXRlTWF0Y2g+LFxuICBuZXh0PzogQXJyYXk8QW55Um91dGVNYXRjaD4sXG4gIGRlZmVyU2FtZUlkRmxpZ2h0PzogdHJ1ZSxcbik6IHZvaWQge1xuICBjb25zdCBhYm9ydDogQXJyYXk8QWJvcnRDb250cm9sbGVyPiA9IFtdXG4gIGZvciAoY29uc3QgbWF0Y2ggb2YgcHJldmlvdXMgYXMgQXJyYXk8V29ya01hdGNoPikge1xuICAgIGlmICghbmV4dD8uaW5jbHVkZXMobWF0Y2gpKSB7XG4gICAgICBjb25zdCBmbGlnaHQgPSBtYXRjaC5fZmxpZ2h0XG4gICAgICBtYXRjaC5fZmxpZ2h0ID0gdW5kZWZpbmVkXG4gICAgICBpZiAoXG4gICAgICAgIGRlZmVyU2FtZUlkRmxpZ2h0ICYmXG4gICAgICAgIGZsaWdodD8uWzIgLyogbGVhc2VzICovXSA9PT0gMSAmJlxuICAgICAgICByb3V0ZXIuX2ZsaWdodHM/LmdldChtYXRjaC5pZCkgPT09IGZsaWdodCAmJlxuICAgICAgICBuZXh0Py5zb21lKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5pZCA9PT0gbWF0Y2guaWQpXG4gICAgICApIHtcbiAgICAgICAgLy8gVGhlIHN1Y2Nlc3NvciBoYXMgbm90IG1hZGUgaXRzIHNhbWUtSUQgcmVsb2FkIGRlY2lzaW9uIHlldC5cbiAgICAgICAgZmxpZ2h0WzIgLyogbGVhc2VzICovXSA9IDBcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IGNvbnRyb2xsZXIgPSByZWxlYXNlT3duZWRGbGlnaHQocm91dGVyLCBtYXRjaCwgZmxpZ2h0KVxuICAgICAgICBpZiAoY29udHJvbGxlcikge1xuICAgICAgICAgIGFib3J0LnB1c2goY29udHJvbGxlcilcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuICBmb3IgKGNvbnN0IGNvbnRyb2xsZXIgb2YgYWJvcnQpIHtcbiAgICBjb250cm9sbGVyLmFib3J0KClcbiAgfVxufVxuXG5mdW5jdGlvbiBhY3F1aXJlTWF0Y2hSZXNvdXJjZXMobWF0Y2hlczogQXJyYXk8QW55Um91dGVNYXRjaD4pOiB2b2lkIHtcbiAgZm9yIChjb25zdCBtYXRjaCBvZiBtYXRjaGVzIGFzIEFycmF5PFdvcmtNYXRjaD4pIHtcbiAgICBjb25zdCBmbGlnaHQgPSBtYXRjaC5fZmxpZ2h0XG4gICAgaWYgKGZsaWdodCkge1xuICAgICAgZmxpZ2h0WzIgLyogbGVhc2VzICovXSsrXG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIHNldEZldGNoaW5nKFxuICByb3V0ZXI6IEFueVJvdXRlcixcbiAgbWF0Y2g6IFdvcmtNYXRjaCxcbiAgdmFsdWU6IEFueVJvdXRlTWF0Y2hbJ2lzRmV0Y2hpbmcnXSxcbiAgb3duZXI/OiBBYm9ydENvbnRyb2xsZXIsXG4pOiB2b2lkIHtcbiAgbWF0Y2guaXNGZXRjaGluZyA9IHZhbHVlXG4gIGlmIChvd25lciAmJiByb3V0ZXIuX3R4Py5bMCAvKiBjb250cm9sbGVyICovXSAhPT0gb3duZXIpIHtcbiAgICByZXR1cm5cbiAgfVxuICBjb25zdCBzdG9yZSA9IHJvdXRlci5zdG9yZXMuYnlSb3V0ZS5nZXQobWF0Y2gucm91dGVJZClcbiAgY29uc3QgcHJlc2VudGVkID0gc3RvcmU/LmdldCgpXG4gIGlmIChwcmVzZW50ZWQ/LmlkID09PSBtYXRjaC5pZCkge1xuICAgIHN0b3JlIS5zZXQoeyAuLi5wcmVzZW50ZWQsIGlzRmV0Y2hpbmc6IHZhbHVlIH0pXG4gIH1cbn1cblxuZnVuY3Rpb24gZ2V0TG9hZGVyQ29udGV4dChcbiAgcm91dGVyOiBBbnlSb3V0ZXIsXG4gIGxhbmU6IENvbnRleHR1YWxpemVkTGFuZSxcbiAgbWF0Y2g6IFdvcmtNYXRjaCxcbiAgcm91dGU6IEFueVJvdXRlLFxuICBjb250cm9sbGVyOiBBYm9ydENvbnRyb2xsZXIsXG4gIHBhcmVudE1hdGNoUHJvbWlzZTogUHJvbWlzZTxXb3JrTWF0Y2g+IHwgdW5kZWZpbmVkLFxuICBwcmVsb2FkOiBib29sZWFuLFxuKTogTG9hZGVyRm5Db250ZXh0IHtcbiAgY29uc3QgbG9jYXRpb24gPSBsYW5lWzAgLyogbG9jYXRpb24gKi9dXG4gIHJldHVybiB7XG4gICAgcGFyYW1zOiBtYXRjaC5wYXJhbXMsXG4gICAgbG9jYXRpb24sXG4gICAgbmF2aWdhdGU6IChvcHRzOiBhbnkpID0+XG4gICAgICByb3V0ZXIubmF2aWdhdGUoe1xuICAgICAgICAuLi5vcHRzLFxuICAgICAgICBfZnJvbUxvY2F0aW9uOiBsb2NhdGlvbixcbiAgICAgIH0pLFxuICAgIGNhdXNlOiBwcmVsb2FkID8gKCdwcmVsb2FkJyBhcyBjb25zdCkgOiBtYXRjaC5jYXVzZSxcbiAgICBhYm9ydENvbnRyb2xsZXI6IGNvbnRyb2xsZXIsXG4gICAgcHJlbG9hZCxcbiAgICBkZXBzOiBtYXRjaC5sb2FkZXJEZXBzLFxuICAgIHBhcmVudE1hdGNoUHJvbWlzZTogcGFyZW50TWF0Y2hQcm9taXNlIGFzIGFueSxcbiAgICBjb250ZXh0OiBtYXRjaC5jb250ZXh0LFxuICAgIHJvdXRlLFxuICAgIC4uLnJvdXRlci5vcHRpb25zLmFkZGl0aW9uYWxDb250ZXh0LFxuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGxvYWRSZXNvdXJjZShcbiAgcm91dGVyOiBBbnlSb3V0ZXIsXG4gIGxhbmU6IENvbnRleHR1YWxpemVkTGFuZSxcbiAgbWF0Y2g6IFdvcmtNYXRjaCxcbiAgcm91dGU6IEFueVJvdXRlLFxuICBsb2FkZXI6IFJvdXRlTG9hZGVyRm48YW55PiB8IHVuZGVmaW5lZCxcbiAgcGFyZW50TWF0Y2hQcm9taXNlOiBQcm9taXNlPFdvcmtNYXRjaD4gfCB1bmRlZmluZWQsXG4gIG9wdGlvbnM6IEV4ZWN1dGVMYW5lT3B0aW9ucyxcbik6IFByb21pc2U8TG9hZGVyT3V0Y29tZT4ge1xuICBjb25zdCBvd25lciA9IG9wdGlvbnNbMCAvKiBjb250cm9sbGVyICovXVxuICBjb25zdCBzaWduYWwgPSBvd25lci5zaWduYWxcbiAgaWYgKHNpZ25hbC5hYm9ydGVkKSB7XG4gICAgcmV0dXJuIENBTkNFTEVEX09VVENPTUVcbiAgfVxuICBpZiAoIWxvYWRlcikge1xuICAgIHJldHVybiBbU1VDQ0VTUywgdW5kZWZpbmVkXVxuICB9XG5cbiAgbGV0IGZsaWdodCA9IG1hdGNoLl9mbGlnaHRcbiAgc2V0RmV0Y2hpbmcocm91dGVyLCBtYXRjaCwgJ2xvYWRlcicsIG93bmVyKVxuICB0cnkge1xuICAgIGlmICghZmxpZ2h0KSB7XG4gICAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpXG4gICAgICBmbGlnaHQgPSBbXG4gICAgICAgIFByb21pc2UucmVzb2x2ZSgpXG4gICAgICAgICAgLnRoZW4oKCkgPT5cbiAgICAgICAgICAgIGxvYWRlcihcbiAgICAgICAgICAgICAgZ2V0TG9hZGVyQ29udGV4dChcbiAgICAgICAgICAgICAgICByb3V0ZXIsXG4gICAgICAgICAgICAgICAgbGFuZSxcbiAgICAgICAgICAgICAgICBtYXRjaCxcbiAgICAgICAgICAgICAgICByb3V0ZSxcbiAgICAgICAgICAgICAgICBjb250cm9sbGVyLFxuICAgICAgICAgICAgICAgIHBhcmVudE1hdGNoUHJvbWlzZSxcbiAgICAgICAgICAgICAgICAhIW9wdGlvbnNbMyAvKiBwcmVsb2FkICovXSxcbiAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICksXG4gICAgICAgICAgKVxuICAgICAgICAgIC50aGVuKFxuICAgICAgICAgICAgKHZhbHVlKSA9PiBub3JtYWxpemUodmFsdWUsIGZhbHNlLCByb3V0ZS5pZCksXG4gICAgICAgICAgICAoY2F1c2UpID0+IG5vcm1hbGl6ZShjYXVzZSwgdHJ1ZSwgcm91dGUuaWQpLFxuICAgICAgICAgIClcbiAgICAgICAgICAudGhlbigocmVzdWx0KTogUmF3TG9hZGVyT3V0Y29tZSA9PiB7XG4gICAgICAgICAgICAvLyBUaGUgcmVnaXN0cnkgY29udHJvbHMgZGlzY292ZXJ5OyBsZWFzZXMga2VlcCBjdXJyZW50IGNvbnN1bWVyc1xuICAgICAgICAgICAgLy8gc2hhcmluZyB0aGUgc2FtZSB0ZXJtaW5hbCBvdXRjb21lLlxuICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICByZXN1bHRbMCAvKiBraW5kICovXSAhPT0gU1VDQ0VTUyAmJlxuICAgICAgICAgICAgICByb3V0ZXIuX2ZsaWdodHM/LmdldChtYXRjaC5pZCkgPT09IGZsaWdodFxuICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgIHJvdXRlci5fZmxpZ2h0cyEuZGVsZXRlKG1hdGNoLmlkKVxuICAgICAgICAgICAgICBpZiAoIWZsaWdodCFbMiAvKiBsZWFzZXMgKi9dKSB7XG4gICAgICAgICAgICAgICAgY29udHJvbGxlci5hYm9ydCgpXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiByZXN1bHRbMCAvKiBraW5kICovXSA9PT0gRVJST1IgJiYgZmxpZ2h0IVsyIC8qIGxlYXNlcyAqL11cbiAgICAgICAgICAgICAgPyBub3JtYWxpemVFcnJvcihyb3V0ZSwgcmVzdWx0WzEgLyogZXJyb3IgKi9dKVxuICAgICAgICAgICAgICA6IHJlc3VsdFxuICAgICAgICAgIH0pLFxuICAgICAgICBjb250cm9sbGVyLFxuICAgICAgICAxLFxuICAgICAgXVxuICAgICAgOyhyb3V0ZXIuX2ZsaWdodHMgPz89IG5ldyBNYXAoKSkuc2V0KG1hdGNoLmlkLCBmbGlnaHQpXG4gICAgfVxuICAgIG1hdGNoLl9mbGlnaHQgPSBmbGlnaHRcbiAgICBtYXRjaC5hYm9ydENvbnRyb2xsZXIgPSBmbGlnaHRbMSAvKiBjb250cm9sbGVyICovXVxuICAgIHJldHVybiBtYXRlcmlhbGl6ZVJlZGlyZWN0KFxuICAgICAgcm91dGVyLFxuICAgICAgbGFuZSxcbiAgICAgIHJvdXRlLFxuICAgICAgYXdhaXQgd2FpdEZvcihmbGlnaHRbMCAvKiBvdXRjb21lICovXSwgc2lnbmFsKSxcbiAgICAgIG9wdGlvbnMsXG4gICAgKVxuICB9IGNhdGNoIChjYXVzZSkge1xuICAgIGlmIChjYXVzZSAhPT0gc2lnbmFsIHx8ICFzaWduYWwuYWJvcnRlZCkge1xuICAgICAgdGhyb3cgY2F1c2VcbiAgICB9XG4gICAgcmVsZWFzZUZsaWdodChyb3V0ZXIsIG1hdGNoKVxuICAgIHJldHVybiBDQU5DRUxFRF9PVVRDT01FXG4gIH0gZmluYWxseSB7XG4gICAgc2V0RmV0Y2hpbmcocm91dGVyLCBtYXRjaCwgZmFsc2UsIG93bmVyKVxuICB9XG59XG5cbmZ1bmN0aW9uIHNldHRsZUludG8oXG4gIG1hdGNoOiBXb3JrTWF0Y2gsXG4gIHJlc3VsdDogTG9hZGVyT3V0Y29tZSxcbiAgcHJlbG9hZDogYm9vbGVhbixcbik6IGFzc2VydHMgbWF0Y2ggaXMgU2V0dGxlZE1hdGNoIHtcbiAgaWYgKHJlc3VsdFswIC8qIGtpbmQgKi9dID09PSBSRURJUkVDVEVEKSB7XG4gICAgcmV0dXJuXG4gIH1cbiAgLy8gUmVkdWN0aW9uIGluc3RhbGxzIG9ubHkgdGhlIHNlbGVjdGVkIHRlcm1pbmFsIGZhaWx1cmUuIEV2ZXJ5IG90aGVyXG4gIC8vIHNldHRsZWQgYXR0ZW1wdCByZW1haW5zIGEgcmVuZGVyYWJsZSwgc3RhbGUgbWF0Y2ggaW4gdGhhdCBsYW5lLlxuICBtYXRjaC5zdGF0dXMgPSAnc3VjY2VzcydcbiAgbWF0Y2guZXJyb3IgPSB1bmRlZmluZWRcbiAgaWYgKHJlc3VsdFswIC8qIGtpbmQgKi9dID09PSBTVUNDRVNTKSB7XG4gICAgbWF0Y2gubG9hZGVyRGF0YSA9IHJlc3VsdFsxIC8qIGRhdGEgKi9dXG4gICAgbWF0Y2guaW52YWxpZCA9IGZhbHNlXG4gICAgbWF0Y2gudXBkYXRlZEF0ID0gRGF0ZS5ub3coKVxuICAgIG1hdGNoLnByZWxvYWQgPSBwcmVsb2FkXG4gIH0gZWxzZSB7XG4gICAgbWF0Y2guaW52YWxpZCA9IHRydWVcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gY2FjaGVMb2FkZXJNYXRjaChcbiAgcm91dGVyOiBDb29yZGluYXRvclJvdXRlcixcbiAgbWF0Y2g6IFNldHRsZWRNYXRjaCxcbiAgcGxhbm5lZDogQW55Um91dGVNYXRjaCB8IHVuZGVmaW5lZCxcbik6IHZvaWQge1xuICBjb25zdCBjdXJyZW50ID0gcm91dGVyLl9jYWNoZS5nZXQobWF0Y2guaWQpIGFzIFdvcmtNYXRjaCB8IHVuZGVmaW5lZFxuICBpZiAoXG4gICAgY3VycmVudCAhPT0gcGxhbm5lZCB8fFxuICAgIHJvdXRlci5fY29tbWl0dGVkLnNvbWUoXG4gICAgICAoY2FuZGlkYXRlKSA9PlxuICAgICAgICBjYW5kaWRhdGUuaWQgPT09IG1hdGNoLmlkICYmXG4gICAgICAgIChjYW5kaWRhdGUgYXMgV29ya01hdGNoKS5fZmxpZ2h0ID09PSBtYXRjaC5fZmxpZ2h0LFxuICAgIClcbiAgKSB7XG4gICAgcmV0dXJuXG4gIH1cbiAgY29uc3QgY2FjaGVkID0ge1xuICAgIC4uLm1hdGNoLFxuICAgIF9ub3RGb3VuZDogdW5kZWZpbmVkLFxuICAgIGNvbnRleHQ6IHt9LFxuICB9IGFzIFdvcmtNYXRjaFxuICBpZiAoY2FjaGVkLl9mbGlnaHQpIHtcbiAgICBjYWNoZWQuX2ZsaWdodFsyIC8qIGxlYXNlcyAqL10rK1xuICB9XG4gIHJvdXRlci5fY2FjaGUuc2V0KG1hdGNoLmlkLCBjYWNoZWQpXG4gIGlmIChjdXJyZW50KSB7XG4gICAgcmVsZWFzZUZsaWdodChyb3V0ZXIsIGN1cnJlbnQpXG4gIH1cbn1cblxuZnVuY3Rpb24gZ2V0UGFyZW50U25hcHNob3QoXG4gIG1hdGNoOiBXb3JrTWF0Y2gsXG4gIG91dGNvbWU6IExvYWRlck91dGNvbWUsXG4pOiBXb3JrTWF0Y2gge1xuICBpZiAob3V0Y29tZVswIC8qIGtpbmQgKi9dID09PSBFUlJPUiB8fCBvdXRjb21lWzAgLyoga2luZCAqL10gPT09IE5PVF9GT1VORCkge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5tYXRjaCxcbiAgICAgIHN0YXR1czogb3V0Y29tZVswIC8qIGtpbmQgKi9dID09PSBFUlJPUiA/ICdlcnJvcicgOiAnbm90Rm91bmQnLFxuICAgICAgZXJyb3I6IG91dGNvbWVbMSAvKiBlcnJvciAqL10sXG4gICAgICBfZmxpZ2h0OiB1bmRlZmluZWQsXG4gICAgfVxuICB9XG4gIHJldHVybiBtYXRjaFxufVxuXG5mdW5jdGlvbiBjcmVhdGVMb2FkZXJUYXNrKFxuICByb3V0ZXI6IEFueVJvdXRlcixcbiAgbGFuZTogQ29udGV4dHVhbGl6ZWRMYW5lLFxuICBpbmRleDogbnVtYmVyLFxuICB0YXNrczogQXJyYXk8TG9hZGVyVGFzaz4sXG4gIHNlbWFudGljUGFyZW50OiBQcm9taXNlPFdvcmtNYXRjaD4gfCB1bmRlZmluZWQsXG4gIG9wdGlvbnM6IEV4ZWN1dGVMYW5lT3B0aW9ucyxcbiAgcmV0YWluZWRFbmQ6IG51bWJlcixcbik6IFByb21pc2U8V29ya01hdGNoPiB7XG4gIGNvbnN0IG1hdGNoID0gbGFuZVsxIC8qIG1hdGNoZXMgKi9dW2luZGV4XSFcbiAgY29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKVxuICBjb25zdCBwcmVsb2FkID0gISFvcHRpb25zWzMgLyogcHJlbG9hZCAqL11cbiAgY29uc3QgcGxhbm5lZENhY2hlTWF0Y2ggPSByb3V0ZXIuX2NhY2hlLmdldChtYXRjaC5pZClcbiAgbGV0IGNvbmZpZ3VyZWRcbiAgbGV0IHJlbG9hZCA9IGZhbHNlXG4gIGxldCByZWxvYWRGYWlsdXJlOiBMb2FkZXJPdXRjb21lIHwgdW5kZWZpbmVkXG4gIHRyeSB7XG4gICAgaWYgKG1hdGNoLnN0YXR1cyA9PT0gJ3N1Y2Nlc3MnKSB7XG4gICAgICBjb25maWd1cmVkID0gcm91dGUub3B0aW9ucy5zaG91bGRSZWxvYWRcbiAgICAgIGlmICh0eXBlb2YgY29uZmlndXJlZCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBjb25maWd1cmVkID0gY29uZmlndXJlZChcbiAgICAgICAgICBnZXRMb2FkZXJDb250ZXh0KFxuICAgICAgICAgICAgcm91dGVyLFxuICAgICAgICAgICAgbGFuZSxcbiAgICAgICAgICAgIG1hdGNoLFxuICAgICAgICAgICAgcm91dGUsXG4gICAgICAgICAgICBvcHRpb25zWzAgLyogY29udHJvbGxlciAqL10sXG4gICAgICAgICAgICBzZW1hbnRpY1BhcmVudCxcbiAgICAgICAgICAgIHByZWxvYWQsXG4gICAgICAgICAgKSxcbiAgICAgICAgKVxuICAgICAgfVxuICAgICAgaWYgKG9wdGlvbnNbMCAvKiBjb250cm9sbGVyICovXS5zaWduYWwuYWJvcnRlZCkge1xuICAgICAgICByZWxvYWRGYWlsdXJlID0gQ0FOQ0VMRURfT1VUQ09NRVxuICAgICAgfVxuICAgIH1cbiAgICBpZiAoIXJlbG9hZEZhaWx1cmUpIHtcbiAgICAgIGlmIChtYXRjaC5zdGF0dXMgIT09ICdzdWNjZXNzJykge1xuICAgICAgICByZWxvYWQgPSB0cnVlXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBzdGFsZUFnZSA9XG4gICAgICAgICAgcHJlbG9hZCB8fCBtYXRjaC5wcmVsb2FkXG4gICAgICAgICAgICA/IChyb3V0ZS5vcHRpb25zLnByZWxvYWRTdGFsZVRpbWUgPz9cbiAgICAgICAgICAgICAgcm91dGVyLm9wdGlvbnMuZGVmYXVsdFByZWxvYWRTdGFsZVRpbWUgPz9cbiAgICAgICAgICAgICAgMzBfMDAwKVxuICAgICAgICAgICAgOiAocm91dGUub3B0aW9ucy5zdGFsZVRpbWUgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFN0YWxlVGltZSA/PyAwKVxuICAgICAgICByZWxvYWQgPSAhIShcbiAgICAgICAgICBtYXRjaC5pbnZhbGlkIHx8XG4gICAgICAgICAgY29uZmlndXJlZCB8fFxuICAgICAgICAgIChjb25maWd1cmVkID09PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAgIERhdGUubm93KCkgLSBtYXRjaC51cGRhdGVkQXQgPj0gc3RhbGVBZ2UgJiZcbiAgICAgICAgICAgIChvcHRpb25zWzUgLyogZm9yY2VTdGFsZVJlbG9hZCAqL10gfHxcbiAgICAgICAgICAgICAgbWF0Y2guY2F1c2UgPT09ICdlbnRlcicgfHxcbiAgICAgICAgICAgICAgb3B0aW9uc1syIC8qIGJhc2UgKi9dLnNvbWUoXG4gICAgICAgICAgICAgICAgKGNhbmRpZGF0ZSkgPT5cbiAgICAgICAgICAgICAgICAgIGNhbmRpZGF0ZS5yb3V0ZUlkID09PSBtYXRjaC5yb3V0ZUlkICYmXG4gICAgICAgICAgICAgICAgICBjYW5kaWRhdGUuaWQgIT09IG1hdGNoLmlkLFxuICAgICAgICAgICAgICApKSlcbiAgICAgICAgKVxuICAgICAgfVxuICAgIH1cbiAgfSBjYXRjaCAoY2F1c2UpIHtcbiAgICBtYXRjaC5pbnZhbGlkID0gdHJ1ZVxuICAgIHJlbGVhc2VGbGlnaHQocm91dGVyLCBtYXRjaClcbiAgICByZWxvYWRGYWlsdXJlID0gbm9ybWFsaXplTGFuZUVycm9yKHJvdXRlciwgbGFuZSwgcm91dGUsIGNhdXNlLCBvcHRpb25zKVxuICB9XG4gIGNvbnN0IHJvdXRlTG9hZGVyID0gcm91dGUub3B0aW9ucy5sb2FkZXJcbiAgY29uc3QgaXNMb2FkZXJGbiA9IHR5cGVvZiByb3V0ZUxvYWRlciA9PT0gJ2Z1bmN0aW9uJ1xuICBjb25zdCBsb2FkZXIgPSBpc0xvYWRlckZuID8gcm91dGVMb2FkZXIgOiByb3V0ZUxvYWRlcj8uaGFuZGxlclxuICBjb25zdCBwcmVsb2FkYWJsZSA9ICFwcmVsb2FkIHx8IHJvdXRlLm9wdGlvbnMucHJlbG9hZCAhPT0gZmFsc2VcbiAgbGV0IGRvbm9yID1cbiAgICBwcmVsb2FkYWJsZSAmJlxuICAgIHJvdXRlTG9hZGVyICYmXG4gICAgIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nICYmIHJvdXRlci5fdHg/Lls2IC8qIHJlZnJlc2ggKi9dKVxuICAgICAgPyByb3V0ZXIuX2ZsaWdodHM/LmdldChtYXRjaC5pZClcbiAgICAgIDogdW5kZWZpbmVkXG4gIGlmIChkb25vciA9PT0gbWF0Y2guX2ZsaWdodCB8fCByZWxvYWRGYWlsdXJlKSB7XG4gICAgZG9ub3IgPSB1bmRlZmluZWRcbiAgfSBlbHNlIGlmIChkb25vciAmJiAhcmVsb2FkICYmICFwcmVsb2FkICYmIGNvbmZpZ3VyZWQgPT09IHVuZGVmaW5lZCkge1xuICAgIC8vIE5vcm1hbCBjYWNoZSBwb2xpY3kgYWNjZXB0cyBhbiBhbHJlYWR5LXJ1bm5pbmcgZ2VuZXJhdGlvbiBldmVuIHdoZW4gdGhpc1xuICAgIC8vIGxhbmUgaXRzZWxmIHdvdWxkIG5vdCBoYXZlIHN0YXJ0ZWQgYW5vdGhlciBsb2FkZXIuXG4gICAgcmVsb2FkID0gdHJ1ZVxuICB9IGVsc2UgaWYgKCFyZWxvYWQpIHtcbiAgICBkb25vciA9IHVuZGVmaW5lZFxuICB9XG4gIGNvbnN0IGJhY2tncm91bmQgPSAhIShcbiAgICByb3V0ZUxvYWRlciAmJlxuICAgIHJlbG9hZCAmJlxuICAgIG1hdGNoLnN0YXR1cyA9PT0gJ3N1Y2Nlc3MnICYmXG4gICAgIXByZWxvYWQgJiZcbiAgICAhb3B0aW9uc1s0IC8qIHN5bmMgKi9dICYmXG4gICAgKChpc0xvYWRlckZuID8gdW5kZWZpbmVkIDogcm91dGVMb2FkZXIuc3RhbGVSZWxvYWRNb2RlKSA/P1xuICAgICAgcm91dGVyLm9wdGlvbnMuZGVmYXVsdFN0YWxlUmVsb2FkTW9kZSkgIT09ICdibG9ja2luZydcbiAgKVxuICBjb25zdCBsb2FkZWQgPSByZWxvYWQgJiYgcHJlbG9hZGFibGVcbiAgY29uc3QgYmxvY2tpbmcgPVxuICAgIGxvYWRlZCAmJiAhYmFja2dyb3VuZCAmJiAobWF0Y2guc3RhdHVzICE9PSAnc3VjY2VzcycgfHwgISFyb3V0ZUxvYWRlcilcbiAgY29uc3Qgb25SZWFkeSA9IGluZGV4ID49IHJldGFpbmVkRW5kID8gb3B0aW9uc1s3IC8qIG9uUmVhZHkgKi9dIDogdW5kZWZpbmVkXG4gIGNvbnN0IG9uTGF6eVJlYWR5ID0gcm91dGUubGF6eUZuICYmIHJvdXRlLl9sYXp5ICE9PSB0cnVlID8gb25SZWFkeSA6IHVuZGVmaW5lZFxuICBpZiAobG9hZGVkICYmICFyb3V0ZUxvYWRlcikge1xuICAgIG1hdGNoLmludmFsaWQgPSBmYWxzZVxuICAgIG1hdGNoLnVwZGF0ZWRBdCA9IERhdGUubm93KClcbiAgfVxuICBpZiAoZG9ub3IpIHtcbiAgICBkb25vclsyIC8qIGxlYXNlcyAqL10rK1xuICB9XG4gIGlmIChibG9ja2luZykge1xuICAgIGNvbnN0IGFjY2VwdGVkRmxpZ2h0ID0gbWF0Y2guX2ZsaWdodFxuICAgIG1hdGNoLl9mbGlnaHQgPSBkb25vclxuICAgIHJlbGVhc2VPd25lZEZsaWdodChyb3V0ZXIsIG1hdGNoLCBhY2NlcHRlZEZsaWdodCk/LmFib3J0KClcbiAgICAvLyBBIG1vdW50ZWQgc3VjY2VzcyByZW1haW5zIHJlbmRlcmFibGUgd2hpbGUgaXRzIGxvYWRlciByZXZhbGlkYXRlcy4gRXZlcnlcbiAgICAvLyBub24tcmV0YWluZWQgYmxvY2tpbmcgZ2VuZXJhdGlvbiBwcmVzZW50cyBwZW5kaW5nIHN0YXRlLlxuICAgIGlmIChpbmRleCA+PSByZXRhaW5lZEVuZCkge1xuICAgICAgbWF0Y2guc3RhdHVzID0gJ3BlbmRpbmcnXG4gICAgfVxuICAgIG9uUmVhZHk/LigpXG4gIH1cbiAgaWYgKCFsb2FkZWQpIHtcbiAgICBtYXRjaC5pc0ZldGNoaW5nID0gZmFsc2VcbiAgfVxuICBjb25zdCBvdXRjb21lID1cbiAgICAhcmVsb2FkRmFpbHVyZSAmJiBibG9ja2luZ1xuICAgICAgPyBsb2FkUmVzb3VyY2UoXG4gICAgICAgICAgcm91dGVyLFxuICAgICAgICAgIGxhbmUsXG4gICAgICAgICAgbWF0Y2gsXG4gICAgICAgICAgcm91dGUsXG4gICAgICAgICAgbG9hZGVyLFxuICAgICAgICAgIHNlbWFudGljUGFyZW50LFxuICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICkudGhlbigocmVzdWx0KSA9PiB7XG4gICAgICAgICAgc2V0dGxlSW50byhtYXRjaCwgcmVzdWx0LCBwcmVsb2FkKVxuICAgICAgICAgIGlmIChyZXN1bHRbMCAvKiBraW5kICovXSA9PT0gU1VDQ0VTUykge1xuICAgICAgICAgICAgLy8gQSBzZXR0bGVkIGdlbmVyYXRpb24gY2FuIG91dGxpdmUgaXRzIGxhbmUgd2l0aG91dCBrZWVwaW5nIHVucmVzb2x2ZWRcbiAgICAgICAgICAgIC8vIG5hdmlnYXRpb24gd29yayBhbGl2ZS5cbiAgICAgICAgICAgIGlmIChyb3V0ZUxvYWRlciAmJiAhb3B0aW9uc1swIC8qIGNvbnRyb2xsZXIgKi9dLnNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICAgICAgICAgIGNhY2hlTG9hZGVyTWF0Y2gocm91dGVyLCBtYXRjaCwgcGxhbm5lZENhY2hlTWF0Y2gpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBBIHJvdXRlIGlzIHJlbmRlcmFibGUgb25seSBhZnRlciBib3RoIGl0cyBkYXRhIGFuZCBub3JtYWwgY29tcG9uZW50XG4gICAgICAgICAgICAvLyBjaHVuayBhcmUgcmVhZHkuIEl0cyBsb2FkZXIgZGF0YSBpcyBhbHJlYWR5IGF2YWlsYWJsZSB0byBkZXNjZW5kYW50cy5cbiAgICAgICAgICAgIGlmIChpbmRleCA+PSByZXRhaW5lZEVuZCkge1xuICAgICAgICAgICAgICBtYXRjaC5zdGF0dXMgPSAncGVuZGluZydcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHJlc3VsdFxuICAgICAgICB9KVxuICAgICAgOiBQcm9taXNlLnJlc29sdmU8TG9hZGVyT3V0Y29tZT4oXG4gICAgICAgICAgcmVsb2FkRmFpbHVyZSA/PyBbU1VDQ0VTUywgbWF0Y2gubG9hZGVyRGF0YV0sXG4gICAgICAgIClcblxuICAvLyBLZWVwIHRocm93biBwcmVsb2FkcyBhbmQgcmVqZWN0ZWQgY2h1bmtzIGluIHRoZSBzYW1lIHRhc2sgcHJvbWlzZS5cbiAgY29uc3QgY2h1bmtGYWlsdXJlID0gKGFzeW5jICgpOiBQcm9taXNlPEluZGV4ZWRPdXRjb21lIHwgdm9pZD4gPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjaHVuayA9IGxvYWRSb3V0ZUNodW5rKHJvdXRlLCB1bmRlZmluZWQsIG9uTGF6eVJlYWR5KVxuICAgICAgaWYgKGNodW5rKSB7XG4gICAgICAgIGF3YWl0IHdhaXRGb3IoY2h1bmssIG9wdGlvbnNbMCAvKiBjb250cm9sbGVyICovXS5zaWduYWwpXG4gICAgICB9XG4gICAgfSBjYXRjaCAoY2F1c2UpIHtcbiAgICAgIGlmIChcbiAgICAgICAgIWxhbmVbMSAvKiBtYXRjaGVzICovXS5zb21lKFxuICAgICAgICAgIChjYW5kaWRhdGUsIGNhbmRpZGF0ZUluZGV4KSA9PlxuICAgICAgICAgICAgY2FuZGlkYXRlSW5kZXggPD0gaW5kZXggJiZcbiAgICAgICAgICAgIChjYW5kaWRhdGUuc3RhdHVzID09PSAnZXJyb3InIHx8XG4gICAgICAgICAgICAgIGNhbmRpZGF0ZS5zdGF0dXMgPT09ICdub3RGb3VuZCcgfHxcbiAgICAgICAgICAgICAgY2FuZGlkYXRlLl9ub3RGb3VuZCksXG4gICAgICAgIClcbiAgICAgICkge1xuICAgICAgICByZXR1cm4gW1xuICAgICAgICAgIGluZGV4LFxuICAgICAgICAgIG5vcm1hbGl6ZUxhbmVFcnJvcihyb3V0ZXIsIGxhbmUsIHJvdXRlLCBjYXVzZSwgb3B0aW9ucyksXG4gICAgICAgIF0gc2F0aXNmaWVzIEluZGV4ZWRPdXRjb21lXG4gICAgICB9XG4gICAgfVxuICAgIC8vIFJlYWRpbmVzcyByZXF1aXJlcyBib3RoIHRoZSBjb21wb25lbnQgY2h1bmsgYW5kIGxvYWRlciBkYXRhLlxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG91dGNvbWVcbiAgICBpZiAoXG4gICAgICBibG9ja2luZyAmJlxuICAgICAgcmVzdWx0WzAgLyoga2luZCAqL10gPT09IFNVQ0NFU1MgJiZcbiAgICAgIG1hdGNoLnN0YXR1cyA9PT0gJ3BlbmRpbmcnICYmXG4gICAgICAhb3B0aW9uc1swIC8qIGNvbnRyb2xsZXIgKi9dLnNpZ25hbC5hYm9ydGVkXG4gICAgKSB7XG4gICAgICBtYXRjaC5zdGF0dXMgPSAnc3VjY2VzcydcbiAgICAgIG9uUmVhZHk/LigpXG4gICAgfVxuICB9KSgpXG4gIHRhc2tzLnB1c2goW2luZGV4LCBvdXRjb21lLCBjaHVua0ZhaWx1cmVdKVxuICBpZiAoIWJhY2tncm91bmQpIHtcbiAgICByZXR1cm4gb3V0Y29tZS50aGVuKChyZXN1bHQpID0+IGdldFBhcmVudFNuYXBzaG90KG1hdGNoLCByZXN1bHQpKVxuICB9XG4gIGNvbnN0IGNhbmRpZGF0ZTogV29ya01hdGNoID0ge1xuICAgIC4uLm1hdGNoLFxuICAgIHN0YXR1czogJ3BlbmRpbmcnLFxuICAgIHByZWxvYWQ6IGZhbHNlLFxuICAgIF9mbGlnaHQ6IGRvbm9yLFxuICB9XG4gIG1hdGNoLmludmFsaWQgPSBmYWxzZVxuICBtYXRjaC5pc0ZldGNoaW5nID0gJ2xvYWRlcidcbiAgY29uc3QgYmFja2dyb3VuZE91dGNvbWUgPSBsb2FkUmVzb3VyY2UoXG4gICAgcm91dGVyLFxuICAgIGxhbmUsXG4gICAgY2FuZGlkYXRlLFxuICAgIHJvdXRlLFxuICAgIGxvYWRlcixcbiAgICBzZW1hbnRpY1BhcmVudCxcbiAgICBvcHRpb25zLFxuICApLnRoZW4oKHJlc3VsdCkgPT4ge1xuICAgIG1hdGNoLmlzRmV0Y2hpbmcgPSBmYWxzZVxuICAgIHNldHRsZUludG8oY2FuZGlkYXRlLCByZXN1bHQsIGZhbHNlKVxuICAgIHJldHVybiByZXN1bHRcbiAgfSlcbiAgOyhsYW5lWzIgLyogYmFja2dyb3VuZCAqL10gPz89IFtdKS5wdXNoKFtcbiAgICBpbmRleCxcbiAgICBiYWNrZ3JvdW5kT3V0Y29tZSxcbiAgICBjaHVua0ZhaWx1cmUsXG4gICAgY2FuZGlkYXRlLFxuICBdKVxuICByZXR1cm4gYmFja2dyb3VuZE91dGNvbWUudGhlbigocmVzdWx0KSA9PlxuICAgIGdldFBhcmVudFNuYXBzaG90KGNhbmRpZGF0ZSwgcmVzdWx0KSxcbiAgKVxufVxuXG5hc3luYyBmdW5jdGlvbiBnZXROb3RGb3VuZEJvdW5kYXJ5KFxuICByb3V0ZXI6IEFueVJvdXRlcixcbiAgbWF0Y2hlczogQXJyYXk8V29ya01hdGNoPixcbiAgaW5kZXhlZDogSW5kZXhlZE91dGNvbWUgfCB1bmRlZmluZWQsXG4gIHNpZ25hbDogQWJvcnRTaWduYWwsXG4gIGZhbGxiYWNrID0gMCxcbik6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IGNhdXNlID0gaW5kZXhlZD8uWzEgLyogb3V0Y29tZSAqL11bMSAvKiBlcnJvciBvciByZWRpcmVjdCAqL10gYXNcbiAgICB8IE5vdEZvdW5kRXJyb3JcbiAgICB8IHVuZGVmaW5lZFxuICBsZXQgaW5kZXggPSBjYXVzZT8ucm91dGVJZFxuICAgID8gbWF0Y2hlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5yb3V0ZUlkID09PSBjYXVzZS5yb3V0ZUlkKVxuICAgIDogKGluZGV4ZWQ/LlswIC8qIGluZGV4ICovXSA/PyBtYXRjaGVzLmxlbmd0aCAtIDEpXG4gIGlmIChpbmRleCA8IDApIHtcbiAgICBpbmRleCA9IDBcbiAgfVxuICBmb3IgKGxldCBpID0gaW5kZXg7IGkgPj0gMDsgaS0tKSB7XG4gICAgY29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoZXNbaV0hKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBsb2FkaW5nID0gbG9hZFJvdXRlQ2h1bmsocm91dGUsIGZhbHNlKVxuICAgICAgaWYgKGxvYWRpbmcpIHtcbiAgICAgICAgYXdhaXQgd2FpdEZvcihsb2FkaW5nLCBzaWduYWwpXG4gICAgICB9XG4gICAgfSBjYXRjaCAoY2F1c2UpIHtcbiAgICAgIGlmIChjYXVzZSA9PT0gc2lnbmFsICYmIHNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICAgIHRocm93IGNhdXNlXG4gICAgICB9XG4gICAgfVxuICAgIGlmIChyb3V0ZS5vcHRpb25zLm5vdEZvdW5kQ29tcG9uZW50KSB7XG4gICAgICByZXR1cm4gaVxuICAgIH1cbiAgfVxuICByZXR1cm4gY2F1c2U/LnJvdXRlSWQgPyBpbmRleCA6IGZhbGxiYWNrXG59XG5cbmZ1bmN0aW9uIGRpc2NhcmRCYWNrZ3JvdW5kKHJvdXRlcjogQW55Um91dGVyLCBsYW5lOiBMYW5lPGFueT4pOiB2b2lkIHtcbiAgaWYgKGxhbmVbMiAvKiBiYWNrZ3JvdW5kICovXSkge1xuICAgIHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMoXG4gICAgICByb3V0ZXIsXG4gICAgICBsYW5lWzIgLyogYmFja2dyb3VuZCAqL10ubWFwKCh0YXNrKSA9PiB0YXNrWzMgLyogY2FuZGlkYXRlICovXSksXG4gICAgKVxuICAgIGxhbmVbMiAvKiBiYWNrZ3JvdW5kICovXSA9IHVuZGVmaW5lZFxuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNldHRsZVRhc2tzKFxuICB0YXNrczogQXJyYXk8TG9hZGVyVGFzaz4sXG4gIHNlcmlhbEZhaWx1cmU/OiBJbmRleGVkT3V0Y29tZSxcbiAgcmVkaXJlY3RUYXNrcz86IEFycmF5PEJhY2tncm91bmRMb2FkZXJUYXNrPixcbiAgZ2F0ZT86IG51bWJlciB8IFByb21pc2U8bnVtYmVyPixcbik6IFByb21pc2U8SW5kZXhlZE91dGNvbWUgfCB1bmRlZmluZWQ+IHtcbiAgbGV0IGxvYWRlckZhaWx1cmU6IEluZGV4ZWRPdXRjb21lIHwgdW5kZWZpbmVkXG5cbiAgdHJ5IHtcbiAgICBhd2FpdCBQcm9taXNlLmFsbChcbiAgICAgIHRhc2tzLm1hcCgodGFzaykgPT5cbiAgICAgICAgdGFza1sxIC8qIG91dGNvbWUgKi9dLnRoZW4oYXN5bmMgKG91dGNvbWUpID0+IHtcbiAgICAgICAgICBjb25zdCB0YXNrSW5kZXggPSB0YXNrWzAgLyogaW5kZXggKi9dXG4gICAgICAgICAgaWYgKGdhdGUgJiYgdGFza0luZGV4ID49IChhd2FpdCBnYXRlKSkge1xuICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChvdXRjb21lWzAgLyoga2luZCAqL10gPj0gUkVESVJFQ1RFRCkge1xuICAgICAgICAgICAgdGhyb3cgW3Rhc2tJbmRleCwgb3V0Y29tZV0gYXMgSW5kZXhlZE91dGNvbWVcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKCFsb2FkZXJGYWlsdXJlICYmIG91dGNvbWVbMCAvKiBraW5kICovXSAhPT0gU1VDQ0VTUykge1xuICAgICAgICAgICAgbG9hZGVyRmFpbHVyZSA9IFt0YXNrSW5kZXgsIG91dGNvbWVdXG4gICAgICAgICAgICAvLyBFdmVyeSBzdGFydGVkIGRlc2NlbmRhbnQgbXVzdCBzZXR0bGUgYmVmb3JlIGFuIG9yZGluYXJ5IGZhaWx1cmVcbiAgICAgICAgICAgIC8vIHdpbnMgYmVjYXVzZSBhIHJlZGlyZWN0IGZyb20gYW55IG9mIHRoZW0gcmVtYWlucyBjb250cm9sIGZsb3cuXG4gICAgICAgICAgICBhd2FpdCBQcm9taXNlLmFsbChcbiAgICAgICAgICAgICAgKHJlZGlyZWN0VGFza3MgPz8gW10pLm1hcCgobmV4dFRhc2spID0+IHtcbiAgICAgICAgICAgICAgICBpZiAobmV4dFRhc2tbMCAvKiBpbmRleCAqL10gPD0gdGFza0luZGV4KSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIG5leHRUYXNrWzEgLyogb3V0Y29tZSAqL10udGhlbigobmV4dE91dGNvbWUpID0+IHtcbiAgICAgICAgICAgICAgICAgIGlmIChuZXh0T3V0Y29tZVswIC8qIGtpbmQgKi9dID09PSBSRURJUkVDVEVEKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IFtcbiAgICAgICAgICAgICAgICAgICAgICBuZXh0VGFza1swIC8qIGluZGV4ICovXSxcbiAgICAgICAgICAgICAgICAgICAgICBuZXh0T3V0Y29tZSxcbiAgICAgICAgICAgICAgICAgICAgXSBhcyBJbmRleGVkT3V0Y29tZVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgKVxuICAgICAgICAgIH1cbiAgICAgICAgfSksXG4gICAgICApLFxuICAgIClcbiAgfSBjYXRjaCAoY2F1c2UpIHtcbiAgICByZXR1cm4gY2F1c2UgYXMgSW5kZXhlZE91dGNvbWVcbiAgfVxuICByZXR1cm4gc2VyaWFsRmFpbHVyZSA/PyBsb2FkZXJGYWlsdXJlXG59XG5cbmZ1bmN0aW9uIG1hdGVyaWFsaXplUmVkaXJlY3QoXG4gIHJvdXRlcjogQW55Um91dGVyLFxuICBsYW5lOiBMYW5lPGFueT4sXG4gIHJvdXRlOiBBbnlSb3V0ZSxcbiAgb3V0Y29tZTogUmF3TG9hZGVyT3V0Y29tZSxcbiAgb3B0aW9uczogRXhlY3V0ZUxhbmVPcHRpb25zLFxuICBmYWlsZWQ/OiB0cnVlLFxuKTogTG9hZGVyT3V0Y29tZSB7XG4gIHdoaWxlIChvdXRjb21lWzAgLyoga2luZCAqL10gPT09IFJFRElSRUNURUQpIHtcbiAgICBjb25zdCByZWRpcmVjdCA9IG91dGNvbWVbMSAvKiByZWRpcmVjdCAqL11cbiAgICBjb25zdCByZWRpcmVjdE9wdGlvbnMgPSByZWRpcmVjdC5vcHRpb25zXG4gICAgdHJ5IHtcbiAgICAgIGlmIChyZWRpcmVjdE9wdGlvbnMuaHJlZiB8fCByZWRpcmVjdC5oZWFkZXJzLmhhcygnTG9jYXRpb24nKSkge1xuICAgICAgICByb3V0ZXIucmVzb2x2ZVJlZGlyZWN0KHJlZGlyZWN0KVxuICAgICAgICBpZiAocmVkaXJlY3RPcHRpb25zLnJlbG9hZERvY3VtZW50KSB7XG4gICAgICAgICAgcmV0dXJuIG91dGNvbWVcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKFxuICAgICAgICByZWRpcmVjdE9wdGlvbnMucmVsb2FkRG9jdW1lbnRcbiAgICAgICAgICA/IG9wdGlvbnNbMyAvKiBwcmVsb2FkICovXVxuICAgICAgICAgIDogb3B0aW9uc1sxIC8qIHJlZGlyZWN0cyAqL10gPj0gMjBcbiAgICAgICkge1xuICAgICAgICByZXR1cm4gb3V0Y29tZVxuICAgICAgfVxuICAgICAgY29uc3QgbG9jYXRpb24gPSByb3V0ZXIuYnVpbGRMb2NhdGlvbih7XG4gICAgICAgIC4uLnJlZGlyZWN0T3B0aW9ucyxcbiAgICAgICAgX2Zyb21Mb2NhdGlvbjogbGFuZVswIC8qIGxvY2F0aW9uICovXSxcbiAgICAgICAgX2luY2x1ZGVWYWxpZGF0ZVNlYXJjaDogdHJ1ZSxcbiAgICAgIH0pXG4gICAgICBjb25zdCBwdWJsaWNMb2NhdGlvbiA9IGxvY2F0aW9uLm1hc2tlZExvY2F0aW9uID8/IGxvY2F0aW9uXG4gICAgICBpZiAocHVibGljTG9jYXRpb24uZXh0ZXJuYWwpIHtcbiAgICAgICAgLy8gTG9hZGVyIG91dGNvbWVzIGNhbiBiZSBzaGFyZWQgYnkgbGFuZXMgd2l0aCBkaWZmZXJlbnQgc2VhcmNoL3BhcmFtcy5cbiAgICAgICAgLy8gS2VlcCB0aGUgcmVzb2x2ZWQgZGVzdGluYXRpb24gbG9jYWwgdG8gdGhpcyBsYW5lLlxuICAgICAgICBjb25zdCByZXNvbHZlZCA9IHJlZGlyZWN0LmNsb25lKCkgYXMgQW55UmVkaXJlY3RcbiAgICAgICAgcmVzb2x2ZWQub3B0aW9ucyA9IHsgLi4ucmVkaXJlY3RPcHRpb25zIH1cbiAgICAgICAgcmVzb2x2ZWQuaGVhZGVycy5zZXQoJ0xvY2F0aW9uJywgcHVibGljTG9jYXRpb24ucHVibGljSHJlZilcbiAgICAgICAgcm91dGVyLnJlc29sdmVSZWRpcmVjdChyZXNvbHZlZClcbiAgICAgICAgLy8gQSB0d28taXRlbSBvdXRjb21lIG1hcmtzIGEgdGVybWluYWwgcmVkaXJlY3QgZm9yIHByZWxvYWRzLlxuICAgICAgICByZXR1cm4gb3B0aW9uc1szIC8qIHByZWxvYWQgKi9dXG4gICAgICAgICAgPyBbUkVESVJFQ1RFRCwgcmVzb2x2ZWRdXG4gICAgICAgICAgOiBbUkVESVJFQ1RFRCwgcmVzb2x2ZWQsIHB1YmxpY0xvY2F0aW9uXVxuICAgICAgfVxuICAgICAgcmV0dXJuIFtSRURJUkVDVEVELCByZWRpcmVjdCwgbG9jYXRpb25dXG4gICAgfSBjYXRjaCAoY2F1c2UpIHtcbiAgICAgIG91dGNvbWUgPSBmYWlsZWQgPyBbRVJST1IsIGNhdXNlXSA6IG5vcm1hbGl6ZUVycm9yKHJvdXRlLCBjYXVzZSlcbiAgICAgIGZhaWxlZCA9IHRydWVcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG91dGNvbWVcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVkdWNlTGFuZShcbiAgcm91dGVyOiBBbnlSb3V0ZXIsXG4gIGxhbmU6IENvbnRleHR1YWxpemVkTGFuZSxcbiAgdGFza3M6IEFycmF5PExvYWRlclRhc2s+LFxuICBjb250cm9sbGVyOiBBYm9ydENvbnRyb2xsZXIsXG4gIHNldHRsZW1lbnQ6IFByb21pc2U8SW5kZXhlZE91dGNvbWUgfCB1bmRlZmluZWQ+LFxuICBvblJlYWR5PzogKCkgPT4gdm9pZCxcbik6IFByb21pc2U8UmVkdWNlZExhbmUgfCBDb250cm9sT3V0Y29tZT4ge1xuICBjb25zdCBtYXRjaGVzID0gbGFuZVsxIC8qIG1hdGNoZXMgKi9dXG4gIGxldCBmYWlsdXJlID0gYXdhaXQgc2V0dGxlbWVudFxuICBsZXQgcmVkaXJlY3RMaW1pdEV4Y2VlZGVkID0gZmFsc2VcbiAgY29uc3QgcGxhbm5lZEJvdW5kYXJ5ID0gbWF0Y2hlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5fbm90Rm91bmQpXG4gIGNvbnN0IGJvdW5kYXJ5T2YgPSAoZm91bmQ6IEluZGV4ZWRPdXRjb21lKSA9PlxuICAgIGZvdW5kWzEgLyogb3V0Y29tZSAqL11bMCAvKiBraW5kICovXSA9PT0gTk9UX0ZPVU5EXG4gICAgICA/IGdldE5vdEZvdW5kQm91bmRhcnkocm91dGVyLCBtYXRjaGVzLCBmb3VuZCwgY29udHJvbGxlci5zaWduYWwpXG4gICAgICA6IGZvdW5kWzAgLyogaW5kZXggKi9dXG4gIGxldCByZWFkaW5lc3NFbmQgPSBwbGFubmVkQm91bmRhcnkgPCAwID8gbWF0Y2hlcy5sZW5ndGggOiBwbGFubmVkQm91bmRhcnlcblxuICBpZiAoKGZhaWx1cmU/LlsxIC8qIG91dGNvbWUgKi9dWzAgLyoga2luZCAqL10gPz8gMCkgPj0gUkVESVJFQ1RFRCkge1xuICAgIHJlYWRpbmVzc0VuZCA9IDBcbiAgfSBlbHNlIGlmIChmYWlsdXJlKSB7XG4gICAgcmVhZGluZXNzRW5kID0gZmFpbHVyZVsyIC8qIGJvdW5kYXJ5ICovXSA/Pz0gYXdhaXQgYm91bmRhcnlPZihmYWlsdXJlKVxuICAgIGZvciAoY29uc3QgdGFzayBvZiB0YXNrcykge1xuICAgICAgaWYgKHRhc2tbMCAvKiBpbmRleCAqL10gPj0gcmVhZGluZXNzRW5kKSB7XG4gICAgICAgIGJyZWFrXG4gICAgICB9XG4gICAgICBjb25zdCBvdXRjb21lID0gYXdhaXQgdGFza1sxIC8qIG91dGNvbWUgKi9dXG4gICAgICAvLyBQcmVzZW5jZSBtZWFucyBhIGxvYWRlciBwcmV2aW91c2x5IHN1Y2NlZWRlZCwgZXZlbiB3aXRoIGB1bmRlZmluZWRgLlxuICAgICAgaWYgKFxuICAgICAgICBvdXRjb21lWzAgLyoga2luZCAqL10gIT09IFNVQ0NFU1MgJiZcbiAgICAgICAgb3V0Y29tZVswIC8qIGtpbmQgKi9dIDwgUkVESVJFQ1RFRCAmJlxuICAgICAgICAhKCdsb2FkZXJEYXRhJyBpbiBtYXRjaGVzW3Rhc2tbMCAvKiBpbmRleCAqL11dISlcbiAgICAgICkge1xuICAgICAgICBmYWlsdXJlID0gW3Rhc2tbMCAvKiBpbmRleCAqL10sIG91dGNvbWVdXG4gICAgICAgIHJlYWRpbmVzc0VuZCA9IGZhaWx1cmVbMiAvKiBib3VuZGFyeSAqL10gPSBhd2FpdCBib3VuZGFyeU9mKGZhaWx1cmUpXG4gICAgICAgIGJyZWFrXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgZm9yIChjb25zdCB0YXNrIG9mIHRhc2tzKSB7XG4gICAgaWYgKHRhc2tbMCAvKiBpbmRleCAqL10gPj0gcmVhZGluZXNzRW5kKSB7XG4gICAgICBicmVha1xuICAgIH1cbiAgICBjb25zdCBjaHVua0ZhaWx1cmUgPSBhd2FpdCB0YXNrWzIgLyogY2h1bmtGYWlsdXJlICovXVxuICAgIGlmICghY2h1bmtGYWlsdXJlKSB7XG4gICAgICBjb250aW51ZVxuICAgIH1cbiAgICBmYWlsdXJlID0gY2h1bmtGYWlsdXJlXG4gICAgYnJlYWtcbiAgfVxuXG4gIGlmICgoZmFpbHVyZT8uWzEgLyogb3V0Y29tZSAqL11bMCAvKiBraW5kICovXSA/PyAwKSA+PSBSRURJUkVDVEVEKSB7XG4gICAgY29uc3Qgb3V0Y29tZSA9IGZhaWx1cmUhWzEgLyogb3V0Y29tZSAqL11cbiAgICBpZiAoXG4gICAgICBvdXRjb21lWzAgLyoga2luZCAqL10gIT09IFJFRElSRUNURUQgfHxcbiAgICAgIG91dGNvbWVbMSAvKiByZWRpcmVjdCAqL10ub3B0aW9ucy5yZWxvYWREb2N1bWVudCB8fFxuICAgICAgb3V0Y29tZVsyIC8qIGxvY2F0aW9uICovXVxuICAgICkge1xuICAgICAgZGlzY2FyZEJhY2tncm91bmQocm91dGVyLCBsYW5lKVxuICAgICAgcmV0dXJuIG91dGNvbWUgYXMgQ29udHJvbE91dGNvbWVcbiAgICB9XG4gICAgcmVkaXJlY3RMaW1pdEV4Y2VlZGVkID0gdHJ1ZVxuICAgIGZhaWx1cmUgPSBbMCwgW0VSUk9SLCBuZXcgRXJyb3IoJ1RvbyBtYW55IHJlZGlyZWN0cycpXV1cbiAgfVxuXG4gIGNvbnN0IGJvdW5kYXJ5ID0gZmFpbHVyZVxuICAgID8gKGZhaWx1cmVbMiAvKiBib3VuZGFyeSAqL10gPz8gKGF3YWl0IGJvdW5kYXJ5T2YoZmFpbHVyZSkpKVxuICAgIDogcGxhbm5lZEJvdW5kYXJ5XG4gIGlmIChib3VuZGFyeSA+PSAwKSB7XG4gICAgY29uc3Qgb3V0Y29tZSA9IGZhaWx1cmU/LlsxIC8qIG91dGNvbWUgKi9dXG4gICAgY29uc3Qga2luZCA9IG91dGNvbWU/LlswIC8qIGtpbmQgKi9dXG4gICAgY29uc3QgbWF0Y2ggPSBtYXRjaGVzW2JvdW5kYXJ5XSFcbiAgICBjb25zdCBjYXVzZSA9IG91dGNvbWU/LlsxIC8qIGVycm9yIG9yIHJlZGlyZWN0ICovXVxuICAgIGNvbnN0IGluc3RhbGwgPSAoKSA9PiB7XG4gICAgICBpZiAob3V0Y29tZSkge1xuICAgICAgICBtYXRjaC5fbm90Rm91bmQgPSB1bmRlZmluZWRcbiAgICAgICAgaWYgKGtpbmQgPT09IEVSUk9SKSB7XG4gICAgICAgICAgbWF0Y2guc3RhdHVzID0gJ2Vycm9yJ1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIDsoY2F1c2UgYXMgTm90Rm91bmRFcnJvcikucm91dGVJZCA9IG1hdGNoLnJvdXRlSWRcbiAgICAgICAgICBpZiAobWF0Y2gucm91dGVJZCA9PT0gcm91dGVyLnJvdXRlVHJlZS5pZCkge1xuICAgICAgICAgICAgbWF0Y2guc3RhdHVzID0gJ3N1Y2Nlc3MnXG4gICAgICAgICAgICBtYXRjaC5fbm90Rm91bmQgPSB0cnVlXG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG1hdGNoLnN0YXR1cyA9ICdub3RGb3VuZCdcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgbWF0Y2guZXJyb3IgPSBjYXVzZVxuICAgICAgICBtYXRjaC5pc0ZldGNoaW5nID0gZmFsc2VcbiAgICAgIH1cbiAgICB9XG4gICAgaW5zdGFsbCgpXG4gICAgaWYgKCFvdXRjb21lKSB7XG4gICAgICBvblJlYWR5Py4oKVxuICAgIH1cbiAgICBjb25zdCByb3V0ZSA9IGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHdhaXRGb3I8dW5rbm93bj4oXG4gICAgICAgIG91dGNvbWVcbiAgICAgICAgICA/IFByb21pc2UucmVzb2x2ZSgpLnRoZW4oKCkgPT5cbiAgICAgICAgICAgICAgbG9hZFJvdXRlQ2h1bmsoXG4gICAgICAgICAgICAgICAgcm91dGUsXG4gICAgICAgICAgICAgICAga2luZCA9PT0gRVJST1IgPyAnZXJyb3JDb21wb25lbnQnIDogJ25vdEZvdW5kQ29tcG9uZW50JyxcbiAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgIClcbiAgICAgICAgICA6IFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgICAgbG9hZFJvdXRlQ2h1bmsocm91dGUpLFxuICAgICAgICAgICAgICBsb2FkUm91dGVDaHVuayhyb3V0ZSwgJ25vdEZvdW5kQ29tcG9uZW50JyksXG4gICAgICAgICAgICBdKSxcbiAgICAgICAgY29udHJvbGxlci5zaWduYWwsXG4gICAgICApXG4gICAgfSBjYXRjaCAoY2F1c2UpIHtcbiAgICAgIGlmIChjYXVzZSA9PT0gY29udHJvbGxlci5zaWduYWwgJiYgY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkge1xuICAgICAgICBkaXNjYXJkQmFja2dyb3VuZChyb3V0ZXIsIGxhbmUpXG4gICAgICAgIHJldHVybiBDQU5DRUxFRF9PVVRDT01FXG4gICAgICB9XG4gICAgfVxuICAgIGlmICghb3V0Y29tZSkge1xuICAgICAgbWF0Y2guc3RhdHVzID0gJ3N1Y2Nlc3MnXG4gICAgfSBlbHNlIGlmIChyZWRpcmVjdExpbWl0RXhjZWVkZWQpIHtcbiAgICAgIGNvbnRyb2xsZXIuYWJvcnQoKVxuICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICAuLi50YXNrcy5tYXAoKHRhc2spID0+IHRhc2tbMSAvKiBvdXRjb21lICovXSksXG4gICAgICAgIC4uLnRhc2tzLm1hcCgodGFzaykgPT4gdGFza1syIC8qIGNodW5rRmFpbHVyZSAqL10pLFxuICAgICAgICAuLi4obGFuZVsyIC8qIGJhY2tncm91bmQgKi9dID8/IFtdKS5tYXAoXG4gICAgICAgICAgKHRhc2spID0+IHRhc2tbMSAvKiBvdXRjb21lICovXSxcbiAgICAgICAgKSxcbiAgICAgIF0pXG4gICAgICBkaXNjYXJkQmFja2dyb3VuZChyb3V0ZXIsIGxhbmUpXG4gICAgICB0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgbWF0Y2hlcylcbiAgICAgIGluc3RhbGwoKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBsYW5lIGFzIFJlZHVjZWRMYW5lXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcm9qZWN0TGFuZShcbiAgcm91dGVyOiBBbnlSb3V0ZXIsXG4gIGxhbmU6IFJlZHVjZWRMYW5lLFxuICBzaWduYWw6IEFib3J0U2lnbmFsLFxuICBzdGFydCA9IDAsXG4gIGVuZCA9IGxhbmVbMSAvKiBtYXRjaGVzICovXS5sZW5ndGgsXG4pOiBQcm9taXNlPFByb2plY3RlZExhbmU+IHtcbiAgY29uc3QgbWF0Y2hlcyA9IGxhbmVbMSAvKiBtYXRjaGVzICovXVxuICBmb3IgKGxldCBpbmRleCA9IHN0YXJ0OyBpbmRleCA8IGVuZDsgaW5kZXgrKykge1xuICAgIGNvbnN0IG1hdGNoID0gbWF0Y2hlc1tpbmRleF0hXG4gICAgY29uc3Qgcm91dGVPcHRpb25zID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaCkub3B0aW9uc1xuICAgIGlmIChyb3V0ZU9wdGlvbnMuaGVhZCB8fCByb3V0ZU9wdGlvbnMuc2NyaXB0cykge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY29udGV4dCA9IHtcbiAgICAgICAgICBzc3I6IHJvdXRlci5vcHRpb25zLnNzcixcbiAgICAgICAgICBtYXRjaGVzLFxuICAgICAgICAgIG1hdGNoLFxuICAgICAgICAgIHBhcmFtczogbWF0Y2gucGFyYW1zLFxuICAgICAgICAgIGxvYWRlckRhdGE6IG1hdGNoLmxvYWRlckRhdGEsXG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgW2hlYWQsIHNjcmlwdHNdID0gYXdhaXQgd2FpdEZvcihcbiAgICAgICAgICBQcm9taXNlLmFsbChbXG4gICAgICAgICAgICByb3V0ZU9wdGlvbnMuaGVhZD8uKGNvbnRleHQpLFxuICAgICAgICAgICAgcm91dGVPcHRpb25zLnNjcmlwdHM/Lihjb250ZXh0KSxcbiAgICAgICAgICBdKSxcbiAgICAgICAgICBzaWduYWwsXG4gICAgICAgIClcbiAgICAgICAgbWF0Y2gubWV0YSA9IGhlYWQ/Lm1ldGFcbiAgICAgICAgbWF0Y2gubGlua3MgPSBoZWFkPy5saW5rc1xuICAgICAgICBtYXRjaC5oZWFkU2NyaXB0cyA9IGhlYWQ/LnNjcmlwdHNcbiAgICAgICAgbWF0Y2guc3R5bGVzID0gaGVhZD8uc3R5bGVzXG4gICAgICAgIG1hdGNoLnNjcmlwdHMgPSBzY3JpcHRzXG4gICAgICB9IGNhdGNoIChjYXVzZSkge1xuICAgICAgICBpZiAoY2F1c2UgPT09IHNpZ25hbCAmJiBzaWduYWwuYWJvcnRlZCkge1xuICAgICAgICAgIGJyZWFrXG4gICAgICAgIH1cbiAgICAgICAgY29uc29sZS5lcnJvcihjYXVzZSlcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKG1hdGNoLnN0YXR1cyAhPT0gJ3N1Y2Nlc3MnIHx8IG1hdGNoLl9ub3RGb3VuZCkge1xuICAgICAgYnJlYWtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGxhbmUgYXMgUHJvamVjdGVkTGFuZVxufVxuXG5hc3luYyBmdW5jdGlvbiBleGVjdXRlQ2xpZW50TGFuZShcbiAgcm91dGVyOiBBbnlSb3V0ZXIsXG4gIGxvY2F0aW9uOiBQYXJzZWRMb2NhdGlvbixcbiAgbWF0Y2hlczogQXJyYXk8QW55Um91dGVNYXRjaD4sXG4gIG9wdGlvbnM6IEV4ZWN1dGVMYW5lT3B0aW9ucyxcbik6IFByb21pc2U8TGFuZVJlc3VsdD4ge1xuICBjb25zdCBtYXRjaGVkID0gW2xvY2F0aW9uLCBtYXRjaGVzIGFzIEFycmF5PFdvcmtNYXRjaD5dIGFzIE1hdGNoZWRMYW5lXG4gIGNvbnN0IHNpZ25hbCA9IG9wdGlvbnNbMCAvKiBjb250cm9sbGVyICovXS5zaWduYWxcbiAgbGV0IHJlZHVjZWQ6IFJlZHVjZWRMYW5lIHwgQ29udHJvbE91dGNvbWVcbiAgdHJ5IHtcbiAgICBjb25zdCBwcmVzZW50ZWQgPSByb3V0ZXIuc3RvcmVzLm1hdGNoZXMuZ2V0KClcbiAgICBsZXQgcGxhbm5lZEJvdW5kYXJ5ID0gbWF0Y2hlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5fbm90Rm91bmQpXG4gICAgaWYgKHJvdXRlci5vcHRpb25zLm5vdEZvdW5kTW9kZSAhPT0gJ3Jvb3QnICYmIHBsYW5uZWRCb3VuZGFyeSA+PSAwKSB7XG4gICAgICBjb25zdCBib3VuZGFyeSA9IGF3YWl0IGdldE5vdEZvdW5kQm91bmRhcnkoXG4gICAgICAgIHJvdXRlcixcbiAgICAgICAgbWF0Y2hlcyBhcyBBcnJheTxXb3JrTWF0Y2g+LFxuICAgICAgICB1bmRlZmluZWQsXG4gICAgICAgIHNpZ25hbCxcbiAgICAgICAgcGxhbm5lZEJvdW5kYXJ5LFxuICAgICAgKVxuICAgICAgbWF0Y2hlc1twbGFubmVkQm91bmRhcnldIS5fbm90Rm91bmQgPSB1bmRlZmluZWRcbiAgICAgIG1hdGNoZXNbYm91bmRhcnldIS5fbm90Rm91bmQgPSB0cnVlXG4gICAgICBwbGFubmVkQm91bmRhcnkgPSBib3VuZGFyeVxuICAgIH1cbiAgICBsZXQgZW5kID0gcGxhbm5lZEJvdW5kYXJ5IDwgMCA/IG1hdGNoZXMubGVuZ3RoIDogcGxhbm5lZEJvdW5kYXJ5ICsgMVxuICAgIGxldCByZXRhaW5lZEVuZCA9IDBcbiAgICB3aGlsZSAocmV0YWluZWRFbmQgPCBlbmQgJiYgcmV0YWluZWRFbmQgIT09IHBsYW5uZWRCb3VuZGFyeSkge1xuICAgICAgY29uc3QgbWF0Y2ggPSBtYXRjaGVzW3JldGFpbmVkRW5kXSFcbiAgICAgIGNvbnN0IGNvbW1pdHRlZCA9IG9wdGlvbnNbMiAvKiBiYXNlICovXVtyZXRhaW5lZEVuZF1cbiAgICAgIGNvbnN0IHZpc2libGUgPSBwcmVzZW50ZWRbcmV0YWluZWRFbmRdXG4gICAgICBpZiAoXG4gICAgICAgIGNvbW1pdHRlZD8uaWQgIT09IG1hdGNoLmlkIHx8XG4gICAgICAgIGNvbW1pdHRlZC5zdGF0dXMgIT09ICdzdWNjZXNzJyB8fFxuICAgICAgICBtYXRjaC5wcmVsb2FkIHx8XG4gICAgICAgIHZpc2libGU/LmlkICE9PSBtYXRjaC5pZCB8fFxuICAgICAgICB2aXNpYmxlLnN0YXR1cyAhPT0gJ3N1Y2Nlc3MnXG4gICAgICApIHtcbiAgICAgICAgYnJlYWtcbiAgICAgIH1cbiAgICAgIHJldGFpbmVkRW5kKytcbiAgICAgIGlmIChjb21taXR0ZWQuX25vdEZvdW5kIHx8IHZpc2libGUuX25vdEZvdW5kKSB7XG4gICAgICAgIGJyZWFrXG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHRhc2tzOiBBcnJheTxMb2FkZXJUYXNrPiA9IFtdXG4gICAgY29uc3Qgc3RhcnQgPSBvcHRpb25zWzYgLyogcmVzb2x2ZWRQcmVmaXggKi9dID8/IDBcbiAgICBsZXQgc2VtYW50aWNQYXJlbnQgPSBzdGFydFxuICAgICAgPyBQcm9taXNlLnJlc29sdmUobWF0Y2hlc1tzdGFydCAtIDFdIGFzIFdvcmtNYXRjaClcbiAgICAgIDogdW5kZWZpbmVkXG4gICAgY29uc3QgcGxhblN1Y2Nlc3NmdWxMYW5lID0gKCkgPT4ge1xuICAgICAgZm9yIChsZXQgaW5kZXggPSBzdGFydDsgaW5kZXggPCBlbmQ7IGluZGV4KyspIHtcbiAgICAgICAgaWYgKHNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgfVxuICAgICAgICBzZW1hbnRpY1BhcmVudCA9IGNyZWF0ZUxvYWRlclRhc2soXG4gICAgICAgICAgcm91dGVyLFxuICAgICAgICAgIG1hdGNoZWQgYXMgQ29udGV4dHVhbGl6ZWRMYW5lLFxuICAgICAgICAgIGluZGV4LFxuICAgICAgICAgIHRhc2tzLFxuICAgICAgICAgIHNlbWFudGljUGFyZW50LFxuICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICAgcmV0YWluZWRFbmQsXG4gICAgICAgIClcbiAgICAgIH1cbiAgICB9XG4gICAgLy8gRnJvbSBoZXJlIG9uIGBtYXRjaGVkYCBpcyBjb250ZXh0dWFsaXplZDogYGNvbnRleHR1YWxpemVgIGNvbW11bmljYXRlc1xuICAgIC8vIHRocm91Z2ggbXV0YXRpb24gcGx1cyBhIGZhaWx1cmUgcmV0dXJuLCBzbyB0aGUgcGhhc2UgYnJhbmQgaXMgYXNzZXJ0ZWQgYXRcbiAgICAvLyB0aGUgdHdvIHVzZSBzaXRlcyBiZWxvdyByYXRoZXIgdGhhbiBncmFudGVkIGJ5IGEgKGJ5dGUtY29zdGluZykgcmV0dXJuLlxuICAgIGNvbnN0IGZhaWx1cmUgPSBhd2FpdCBjb250ZXh0dWFsaXplKFxuICAgICAgcm91dGVyLFxuICAgICAgbWF0Y2hlZCxcbiAgICAgIG9wdGlvbnMsXG4gICAgICBlbmQsXG4gICAgICBwbGFuU3VjY2Vzc2Z1bExhbmUsXG4gICAgICByZXRhaW5lZEVuZCxcbiAgICApXG4gICAgaWYgKGZhaWx1cmUpIHtcbiAgICAgIG9wdGlvbnNbNCAvKiBzeW5jICovXSA9IHRydWVcbiAgICAgIGVuZCA9IGZhaWx1cmVbMCAvKiBpbmRleCAqL11cbiAgICAgIGlmIChmYWlsdXJlWzEgLyogb3V0Y29tZSAqL11bMCAvKiBraW5kICovXSA9PT0gTk9UX0ZPVU5EKSB7XG4gICAgICAgIGNvbnN0IGJvdW5kYXJ5ID0gYXdhaXQgZ2V0Tm90Rm91bmRCb3VuZGFyeShcbiAgICAgICAgICByb3V0ZXIsXG4gICAgICAgICAgbWF0Y2hlcyBhcyBBcnJheTxXb3JrTWF0Y2g+LFxuICAgICAgICAgIGZhaWx1cmUsXG4gICAgICAgICAgc2lnbmFsLFxuICAgICAgICApXG4gICAgICAgIGZhaWx1cmVbMiAvKiBib3VuZGFyeSAqL10gPSBib3VuZGFyeVxuICAgICAgICBlbmQgPSBNYXRoLm1pbihlbmQsIGJvdW5kYXJ5ICsgMSlcbiAgICAgIH0gZWxzZSBpZiAoZmFpbHVyZVsxIC8qIG91dGNvbWUgKi9dWzAgLyoga2luZCAqL10gPj0gUkVESVJFQ1RFRCkge1xuICAgICAgICBlbmQgPSAwXG4gICAgICB9XG4gICAgICBwbGFuU3VjY2Vzc2Z1bExhbmUoKVxuICAgIH1cbiAgICBpZiAoIXNpZ25hbC5hYm9ydGVkICYmICFvcHRpb25zWzMgLyogcHJlbG9hZCAqL10pIHtcbiAgICAgIGNvbnN0IGFib3J0OiBBcnJheTxBYm9ydENvbnRyb2xsZXI+ID0gW11cbiAgICAgIGZvciAoY29uc3QgW2lkLCBmbGlnaHRdIG9mIHJvdXRlci5fZmxpZ2h0cyA/PyBbXSkge1xuICAgICAgICBpZiAoIWZsaWdodFsyIC8qIGxlYXNlcyAqL10pIHtcbiAgICAgICAgICByb3V0ZXIuX2ZsaWdodHMhLmRlbGV0ZShpZClcbiAgICAgICAgICBhYm9ydC5wdXNoKGZsaWdodFsxIC8qIGNvbnRyb2xsZXIgKi9dKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IGNvbnRyb2xsZXIgb2YgYWJvcnQpIHtcbiAgICAgICAgY29udHJvbGxlci5hYm9ydCgpXG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHJlZHVjdGlvbiA9IHJlZHVjZUxhbmUoXG4gICAgICByb3V0ZXIsXG4gICAgICBtYXRjaGVkIGFzIENvbnRleHR1YWxpemVkTGFuZSxcbiAgICAgIHRhc2tzLFxuICAgICAgb3B0aW9uc1swIC8qIGNvbnRyb2xsZXIgKi9dLFxuICAgICAgc2V0dGxlVGFza3ModGFza3MsIGZhaWx1cmUsIG1hdGNoZWRbMiAvKiBiYWNrZ3JvdW5kICovXSksXG4gICAgICBvcHRpb25zWzcgLyogb25SZWFkeSAqL10sXG4gICAgKVxuICAgIGlmIChtYXRjaGVkWzIgLyogYmFja2dyb3VuZCAqL10/Lmxlbmd0aCkge1xuICAgICAgbWF0Y2hlZFszIC8qIGJhY2tncm91bmRTZXR0bGVtZW50ICovXSA9IHNldHRsZVRhc2tzKFxuICAgICAgICBtYXRjaGVkWzIgLyogYmFja2dyb3VuZCAqL10sXG4gICAgICAgIHVuZGVmaW5lZCxcbiAgICAgICAgdW5kZWZpbmVkLFxuICAgICAgICByZWR1Y3Rpb24udGhlbihcbiAgICAgICAgICAoZm9yZWdyb3VuZCkgPT5cbiAgICAgICAgICAgIGlzQ29udHJvbChmb3JlZ3JvdW5kKSA/IDAgOiBfZ2V0UmVuZGVyZWRNYXRjaGVzKG1hdGNoZXMpLmxlbmd0aCxcbiAgICAgICAgICAoKSA9PiAwLFxuICAgICAgICApLFxuICAgICAgKVxuICAgIH1cbiAgICByZWR1Y2VkID0gYXdhaXQgcmVkdWN0aW9uXG4gIH0gY2F0Y2ggKGNhdXNlKSB7XG4gICAgZGlzY2FyZEJhY2tncm91bmQocm91dGVyLCBtYXRjaGVkKVxuICAgIGlmIChjYXVzZSA9PT0gc2lnbmFsICYmIHNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICByZXR1cm4gQ0FOQ0VMRURfT1VUQ09NRVxuICAgIH1cbiAgICB0aHJvdyBjYXVzZVxuICB9XG4gIGlmIChpc0NvbnRyb2wocmVkdWNlZCkpIHtcbiAgICByZXR1cm4gcmVkdWNlZFxuICB9XG4gIHJldHVybiBwcm9qZWN0TGFuZShcbiAgICByb3V0ZXIsXG4gICAgcmVkdWNlZCxcbiAgICBzaWduYWwsXG4gICAgb3B0aW9uc1s2IC8qIHJlc29sdmVkUHJlZml4ICovXSA9PT0gbWF0Y2hlcy5sZW5ndGhcbiAgICAgID8gb3B0aW9uc1s2IC8qIHJlc29sdmVkUHJlZml4ICovXVxuICAgICAgOiAwLFxuICApXG59XG5cbi8qKlxuICogV2FpdHMgZm9yIGBwZW5kaW5nTXNgLCB0aGVuIHByZXNlbnRzIHRoZSBjb21wbGV0ZSBsYW5lLiBSZW5kZXJpbmcgYXBwbGllcyB0aGVcbiAqIHNlbGVjdGVkIGJvdW5kYXJ5IGN1dG9mZiB3aGlsZSByZXRhaW5pbmcgZXZlcnkgbWF0Y2gncyBzdHJ1Y3R1cmFsIHN0YXRlLlxuICogQSByZXBsYWNlbWVudCBsb2FkIGZvciB0aGUgc2FtZSBtYXRjaCBrZWVwcyB0aGUgdGltZXI7IGNob29zaW5nIGEgZGlmZmVyZW50XG4gKiBtYXRjaCByZXNldHMgaXQuIGBwZW5kaW5nTWluTXNgIHN0YXJ0cyBhZnRlciB0aGUgZmFsbGJhY2sgcmVuZGVycy5cbiAqL1xuZnVuY3Rpb24gb2ZmZXJQZW5kaW5nKHJvdXRlcjogQ29vcmRpbmF0b3JSb3V0ZXIsIHR4OiBMb2FkVHJhbnNhY3Rpb24pOiB2b2lkIHtcbiAgaWYgKHJvdXRlci5fdHggIT09IHR4KSB7XG4gICAgcmV0dXJuXG4gIH1cbiAgY29uc3QgbWF0Y2hlcyA9IHR4WzMgLyogbWF0Y2hlcyAqL11cbiAgY29uc3QgcHJlc2VudGVkID0gcm91dGVyLnN0b3Jlcy5tYXRjaGVzLmdldCgpXG4gIGxldCBzZXNzaW9uID0gcm91dGVyLl9wZW5kaW5nXG4gIGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCBtYXRjaGVzLmxlbmd0aDsgaW5kZXgrKykge1xuICAgIGNvbnN0IG1hdGNoID0gbWF0Y2hlc1tpbmRleF0hXG4gICAgY29uc3Qgc3VjY2VzcyA9IG1hdGNoLnN0YXR1cyA9PT0gJ3N1Y2Nlc3MnICYmICFtYXRjaC5fbm90Rm91bmRcbiAgICBjb25zdCBwcmVzZW50ZWRQZW5kaW5nID1cbiAgICAgIHByZXNlbnRlZFtpbmRleF0/LmlkID09PSBtYXRjaC5pZCAmJlxuICAgICAgcHJlc2VudGVkW2luZGV4XT8uc3RhdHVzID09PSAncGVuZGluZydcbiAgICBpZiAoc3VjY2VzcyAmJiAhcHJlc2VudGVkUGVuZGluZykge1xuICAgICAgY29udGludWVcbiAgICB9XG4gICAgY29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoIGFzIFdvcmtNYXRjaClcbiAgICBjb25zdCBkZWxheSA9XG4gICAgICBzdWNjZXNzIHx8IG1hdGNoLmludmFsaWRcbiAgICAgICAgPyAwXG4gICAgICAgIDogKHJvdXRlLm9wdGlvbnMucGVuZGluZ01zID8/IHJvdXRlci5vcHRpb25zLmRlZmF1bHRQZW5kaW5nTXMpXG4gICAgY29uc3QgY29tcG9uZW50ID1cbiAgICAgIHJvdXRlLm9wdGlvbnMucGVuZGluZ0NvbXBvbmVudCA/P1xuICAgICAgKHJvdXRlci5vcHRpb25zIGFzIGFueSkuZGVmYXVsdFBlbmRpbmdDb21wb25lbnRcbiAgICBpZiAoIWNvbXBvbmVudCB8fCB0eXBlb2YgZGVsYXkgIT09ICdudW1iZXInIHx8IGRlbGF5ID09PSBJbmZpbml0eSkge1xuICAgICAgaWYgKHNlc3Npb24pIHtcbiAgICAgICAgc2Vzc2lvblswIC8qIGdlbmVyYXRpb24gKi9dID0gdHhcbiAgICAgICAgc2Vzc2lvblsyIC8qIGRlYWRsaW5lICovXSA9IDBcbiAgICAgICAgc2Vzc2lvbls0IC8qIGFjayAqL10gPSB0cnVlXG4gICAgICB9XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgY29uc3QgbWluID1cbiAgICAgIHJvdXRlLm9wdGlvbnMucGVuZGluZ01pbk1zID8/IHJvdXRlci5vcHRpb25zLmRlZmF1bHRQZW5kaW5nTWluTXMgPz8gMFxuICAgIGxldCB0b29rT3ZlciA9IGZhbHNlXG4gICAgaWYgKHNlc3Npb24/LlsxIC8qIGJvdW5kYXJ5SWQgKi9dID09PSBtYXRjaC5pZCkge1xuICAgICAgdG9va092ZXIgPSBzZXNzaW9uWzAgLyogZ2VuZXJhdGlvbiAqL10gIT09IHR4XG4gICAgICBzZXNzaW9uWzAgLyogZ2VuZXJhdGlvbiAqL10gPSB0eFxuICAgIH0gZWxzZSB7XG4gICAgICBjbGVhclRpbWVvdXQoc2Vzc2lvbj8uWzMgLyogcmV2ZWFsVGltZXIgKi9dKVxuICAgICAgcm91dGVyLl9wZW5kaW5nID0gc2Vzc2lvbiA9IHVuZGVmaW5lZFxuICAgIH1cbiAgICBpZiAoIXNlc3Npb24pIHtcbiAgICAgIC8vIEh5ZHJhdGlvbiBhbmQgcmVkaXJlY3RzIGNhbiBwcmVzZXJ2ZSBwZW5kaW5nIHByZXNlbnRhdGlvbiB3aXRob3V0IGEgc2Vzc2lvbi5cbiAgICAgIC8vIERvIG5vdCBkZWxheSBpdCBhZ2FpbjsgY29uc2VydmF0aXZlbHkgc3RhcnQgcGVuZGluZ01pbk1zIGZyb20gbm93LlxuICAgICAgcm91dGVyLl9wZW5kaW5nID0gc2Vzc2lvbiA9IFtcbiAgICAgICAgdHgsXG4gICAgICAgIG1hdGNoLmlkLFxuICAgICAgICBwcmVzZW50ZWRQZW5kaW5nID8gRGF0ZS5ub3coKSArIG1pbiA6IHR4WzQgLyogc3RhcnRlZEF0ICovXSArIGRlbGF5LFxuICAgICAgICB1bmRlZmluZWQsXG4gICAgICAgIHByZXNlbnRlZFBlbmRpbmcgfHwgdW5kZWZpbmVkLFxuICAgICAgICBjb21wb25lbnQsXG4gICAgICBdXG4gICAgfVxuICAgIGlmIChcbiAgICAgIHNlc3Npb25bNCAvKiBhY2sgKi9dICYmXG4gICAgICAhdG9va092ZXIgJiZcbiAgICAgIHNlc3Npb25bNSAvKiBjb21wb25lbnQgKi9dID09PSBjb21wb25lbnRcbiAgICApIHtcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICBzZXNzaW9uWzUgLyogY29tcG9uZW50ICovXSA9IGNvbXBvbmVudFxuICAgIGlmICghc2Vzc2lvbls0IC8qIGFjayAqL10pIHtcbiAgICAgIGNsZWFyVGltZW91dChzZXNzaW9uWzMgLyogcmV2ZWFsVGltZXIgKi9dKVxuICAgICAgY29uc3QgcmVtYWluaW5nID0gc2Vzc2lvblsyIC8qIGRlYWRsaW5lICovXSAtIERhdGUubm93KClcbiAgICAgIGlmIChyZW1haW5pbmcgPiAwKSB7XG4gICAgICAgIHNlc3Npb25bMyAvKiByZXZlYWxUaW1lciAqL10gPSBzZXRUaW1lb3V0KFxuICAgICAgICAgICgpID0+IG9mZmVyUGVuZGluZyhyb3V0ZXIsIHR4KSxcbiAgICAgICAgICByZW1haW5pbmcsXG4gICAgICAgIClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgICBzZXNzaW9uWzIgLyogZGVhZGxpbmUgKi9dID0gMFxuICAgIH1cbiAgICBjb25zdCBvZmZlcmVkID0gbWF0Y2hlcy5tYXAoKG1hdGNoKSA9PiAoe1xuICAgICAgLi4ubWF0Y2gsXG4gICAgICBfZmxpZ2h0OiB1bmRlZmluZWQsXG4gICAgfSkpXG4gICAgb2ZmZXJlZFtpbmRleF0hLnN0YXR1cyA9ICdwZW5kaW5nJ1xuICAgIGNvbnN0IGFjayA9IChzZXNzaW9uWzQgLyogYWNrICovXSA9IHJvdXRlclxuICAgICAgLnN0YXJ0VHJhbnNpdGlvbigoKSA9PiByb3V0ZXIuc3RvcmVzLnNldE1hdGNoZXMob2ZmZXJlZCksIG9mZmVyZWQpXG4gICAgICAudGhlbigocmVuZGVyZWQpID0+IHtcbiAgICAgICAgaWYgKFxuICAgICAgICAgIHJlbmRlcmVkICYmXG4gICAgICAgICAgcm91dGVyLl9wZW5kaW5nID09PSBzZXNzaW9uICYmXG4gICAgICAgICAgc2Vzc2lvbiFbNCAvKiBhY2sgKi9dID09PSBhY2sgJiZcbiAgICAgICAgICAhc2Vzc2lvbiFbMiAvKiBkZWFkbGluZSAqL11cbiAgICAgICAgKSB7XG4gICAgICAgICAgc2Vzc2lvbiFbMiAvKiBkZWFkbGluZSAqL10gPSBEYXRlLm5vdygpICsgbWluXG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlbmRlcmVkXG4gICAgICB9KSlcbiAgICByZXR1cm5cbiAgfVxufVxuXG4vKipcbiAqIENhbmNlbHMgcGVuZGluZyBVSSB0aW1pbmcgdW5sZXNzIHRoZSBjdXJyZW50IHN1Y2Nlc3NvciBjYW4gdGFrZSBvdmVyIHRoZVxuICogc2FtZSBib3VuZGFyeSB0aGF0IHJlbWFpbnMgcGFpbnRlZC5cbiAqL1xuZnVuY3Rpb24gZmluaXNoUGVuZGluZyhyb3V0ZXI6IENvb3JkaW5hdG9yUm91dGVyLCB0eDogTG9hZFRyYW5zYWN0aW9uKTogdm9pZCB7XG4gIGNvbnN0IHNlc3Npb24gPSByb3V0ZXIuX3BlbmRpbmdcbiAgaWYgKFxuICAgIHJvdXRlci5fdHggPT09IHR4IHx8XG4gICAgIXJvdXRlci5fdHg/LlszIC8qIG1hdGNoZXMgKi9dLnNvbWUoXG4gICAgICAobWF0Y2gpID0+IG1hdGNoLmlkID09PSBzZXNzaW9uPy5bMSAvKiBib3VuZGFyeUlkICovXSxcbiAgICApXG4gICkge1xuICAgIGNsZWFyVGltZW91dChzZXNzaW9uPy5bMyAvKiByZXZlYWxUaW1lciAqL10pXG4gICAgcm91dGVyLl9wZW5kaW5nID0gdW5kZWZpbmVkXG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gYXdhaXRQZW5kaW5nTWluaW11bShcbiAgcm91dGVyOiBDb29yZGluYXRvclJvdXRlcixcbiAgdHg6IExvYWRUcmFuc2FjdGlvbixcbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXNzaW9uID0gcm91dGVyLl9wZW5kaW5nXG4gIGlmICghc2Vzc2lvbikge1xuICAgIHJldHVyblxuICB9XG4gIGNsZWFyVGltZW91dChzZXNzaW9uWzMgLyogcmV2ZWFsVGltZXIgKi9dKVxuICBjb25zdCByZW1haW5pbmcgPSBzZXNzaW9uWzIgLyogZGVhZGxpbmUgKi9dIC0gRGF0ZS5ub3coKVxuICBpZiAoXG4gICAgIXNlc3Npb25bNCAvKiBhY2sgKi9dIHx8XG4gICAgcmVtYWluaW5nIDw9IDAgfHxcbiAgICAhX2dldFJlbmRlcmVkTWF0Y2hlcyh0eFszIC8qIG1hdGNoZXMgKi9dKS5zb21lKFxuICAgICAgKG1hdGNoKSA9PiBtYXRjaC5pZCA9PT0gc2Vzc2lvblsxIC8qIGJvdW5kYXJ5SWQgKi9dLFxuICAgIClcbiAgKSB7XG4gICAgcmV0dXJuXG4gIH1cbiAgbGV0IHRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PiB8IHVuZGVmaW5lZFxuICB0cnkge1xuICAgIGF3YWl0IHdhaXRGb3IoXG4gICAgICBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSkgPT4ge1xuICAgICAgICB0aW1lciA9IHNldFRpbWVvdXQocmVzb2x2ZSwgcmVtYWluaW5nKVxuICAgICAgfSksXG4gICAgICB0eFswIC8qIGNvbnRyb2xsZXIgKi9dLnNpZ25hbCxcbiAgICApXG4gIH0gY2F0Y2gge31cbiAgY2xlYXJUaW1lb3V0KHRpbWVyKVxufVxuXG5mdW5jdGlvbiBwdWJsaXNoTWF0Y2hlcyhcbiAgcm91dGVyOiBDb29yZGluYXRvclJvdXRlcixcbiAgbWF0Y2hlczogQXJyYXk8QW55Um91dGVNYXRjaD4sXG4pOiB2b2lkIHtcbiAgcm91dGVyLl9jb21taXR0ZWQgPSBtYXRjaGVzXG4gIHJvdXRlci5zdG9yZXMuc2V0TWF0Y2hlcyhtYXRjaGVzKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gY29tbWl0TWF0Y2hlcyhcbiAgcm91dGVyOiBDb29yZGluYXRvclJvdXRlcixcbiAgdHg6IExvYWRUcmFuc2FjdGlvbixcbiAgbWF0Y2hlczogTGFuZU1hdGNoZXM8J3Byb2plY3RlZCc+LFxuICByZXNvbHZlZFByZWZpeD86IG51bWJlcixcbik6IHZvaWQge1xuICBjb25zdCBwcmV2aW91cyA9IHJvdXRlci5fY29tbWl0dGVkXG4gIGNvbnN0IHByZXZpb3VzRW5kID0gcm91dGVyLl9saWZlY3ljbGVFbmRcbiAgY29uc3QgcHJldmlvdXNDYWNoZWQgPSByb3V0ZXIuX2NhY2hlXG4gIGZvciAoY29uc3QgbWF0Y2ggb2YgbWF0Y2hlcykge1xuICAgIG1hdGNoLnByZWxvYWQgPSBmYWxzZVxuICAgIGlmIChyZXNvbHZlZFByZWZpeCkge1xuICAgICAgbWF0Y2guX2Fzc2V0RW5kID0gdW5kZWZpbmVkXG4gICAgfVxuICB9XG4gIGNvbnN0IGN1dCA9IF9nZXRSZW5kZXJlZE1hdGNoZXMobWF0Y2hlcykubGVuZ3RoXG4gIGNvbnN0IGNhY2hlZCA9IG5ldyBNYXA8c3RyaW5nLCBBbnlSb3V0ZU1hdGNoPigpXG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ3Byb2R1Y3Rpb24nIHx8ICF0eFs2IC8qIHJlZnJlc2ggKi9dKSB7XG4gICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKVxuICAgIC8vIFRoZSByZW5kZXJlZCBwcmVmaXggYW5kIHNldHRsZWQgZGVzY2VuZGFudHMgc3VwZXJzZWRlIG9sZGVyIGdlbmVyYXRpb25zLlxuICAgIC8vIFVuc2V0dGxlZCBtYXRjaGVzIGJleW9uZCBhIGZhbGxiYWNrIG11c3Qgbm90IGV2aWN0IGEgbmV3ZXIgcHJlbG9hZC5cbiAgICBjb25zdCBzdXBlcnNlZGVkID0gbmV3IFNldDxzdHJpbmc+KClcbiAgICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgbWF0Y2hlcy5sZW5ndGg7IGluZGV4KyspIHtcbiAgICAgIGNvbnN0IG1hdGNoID0gbWF0Y2hlc1tpbmRleF0hXG4gICAgICBpZiAoaW5kZXggPCBjdXQgfHwgbWF0Y2guc3RhdHVzID09PSAnc3VjY2VzcycpIHtcbiAgICAgICAgc3VwZXJzZWRlZC5hZGQobWF0Y2guaWQpXG4gICAgICB9XG4gICAgfVxuICAgIGZvciAoY29uc3QgbWF0Y2ggb2YgWy4uLnByZXZpb3VzLCAuLi5wcmV2aW91c0NhY2hlZC52YWx1ZXMoKV0pIHtcbiAgICAgIGlmIChtYXRjaC5zdGF0dXMgIT09ICdzdWNjZXNzJyB8fCBzdXBlcnNlZGVkLmhhcyhtYXRjaC5pZCkpIHtcbiAgICAgICAgY29udGludWVcbiAgICAgIH1cbiAgICAgIGNvbnN0IHdvcmsgPSBtYXRjaCBhcyBXb3JrTWF0Y2hcbiAgICAgIGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCB3b3JrKVxuICAgICAgaWYgKFxuICAgICAgICAhcm91dGUub3B0aW9ucy5sb2FkZXIgfHxcbiAgICAgICAgbm93IC0gbWF0Y2gudXBkYXRlZEF0ID49XG4gICAgICAgICAgKG1hdGNoLnByZWxvYWRcbiAgICAgICAgICAgID8gKHJvdXRlLm9wdGlvbnMucHJlbG9hZEdjVGltZSA/P1xuICAgICAgICAgICAgICByb3V0ZXIub3B0aW9ucy5kZWZhdWx0UHJlbG9hZEdjVGltZSA/P1xuICAgICAgICAgICAgICAzMDBfMDAwKVxuICAgICAgICAgICAgOiAocm91dGUub3B0aW9ucy5nY1RpbWUgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdEdjVGltZSA/PyAzMDBfMDAwKSlcbiAgICAgICkge1xuICAgICAgICBjb250aW51ZVxuICAgICAgfVxuICAgICAgY2FjaGVkLnNldChcbiAgICAgICAgbWF0Y2guaWQsXG4gICAgICAgIHByZXZpb3VzQ2FjaGVkLmdldChtYXRjaC5pZCkgPT09IG1hdGNoXG4gICAgICAgICAgPyBtYXRjaFxuICAgICAgICAgIDogKHtcbiAgICAgICAgICAgICAgLi4ubWF0Y2gsXG4gICAgICAgICAgICAgIF9mbGlnaHQ6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgaXNGZXRjaGluZzogZmFsc2UsXG4gICAgICAgICAgICAgIGNvbnRleHQ6IHt9LFxuICAgICAgICAgICAgfSBhcyBXb3JrTWF0Y2gpLFxuICAgICAgKVxuICAgIH1cbiAgfVxuICAvLyBUaGUgbGFuZSBiZWNvbWVzIGNvbW1pdHRlZCBiZWZvcmUgcHVibGljYXRpb24gY2FuIHN5bmNocm9ub3VzbHkgcmVlbnRlci5cbiAgdHhbMyAvKiBtYXRjaGVzICovXSA9IFtdXG4gIHJvdXRlci5fY2FjaGUgPSBjYWNoZWRcbiAgLy8gUHVibGlzaCBsaWZlY3ljbGUgbWVtYmVyc2hpcCB3aXRoIGl0cyBicmFuY2ggYmVmb3JlIG9ic2VydmVycyBjYW4gcmVlbnRlci5cbiAgY29uc3QgbmV4dEVuZCA9IChyb3V0ZXIuX2xpZmVjeWNsZUVuZCA9IGxpZmVjeWNsZUVuZChtYXRjaGVzKSlcbiAgcHVibGlzaE1hdGNoZXMocm91dGVyLCBtYXRjaGVzKVxuICAvLyBSZXRhaW5lZCBjYWNoZSBvYmplY3RzIGtlZXAgdGhlaXIgbGVhc2VzOyBvbmx5IGRlcGFydGluZyBvd25lcnMgbmVlZCBoYW5kb2ZmLlxuICBjb25zdCBwcmV2aW91c01hdGNoZXMgPSBbLi4ucHJldmlvdXNDYWNoZWQudmFsdWVzKCksIC4uLnByZXZpb3VzXVxuICB0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKFxuICAgIHJvdXRlcixcbiAgICBwcmV2aW91c01hdGNoZXMuZmlsdGVyKFxuICAgICAgKG1hdGNoOiBXb3JrTWF0Y2gpID0+IG1hdGNoLl9mbGlnaHQgJiYgY2FjaGVkLmdldChtYXRjaC5pZCkgIT09IG1hdGNoLFxuICAgICksXG4gICAgbWF0Y2hlcyxcbiAgKVxuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgIGNvbnN0IGhhbmRvZmYgPSB0eFs2IC8qIHJlZnJlc2ggKi9dPy5bMCAvKiBoYW5kb2ZmICovXVxuICAgIGlmIChoYW5kb2ZmICYmIHJvdXRlci5faGFuZG9mZiA9PT0gaGFuZG9mZikge1xuICAgICAgaGFuZG9mZlsxIC8qIGZpbmlzaCAqL10oKVxuICAgIH1cbiAgfVxuICBydW5Sb3V0ZUxpZmVjeWNsZShyb3V0ZXIsIHByZXZpb3VzLCBtYXRjaGVzLCBwcmV2aW91c0VuZCwgbmV4dEVuZCwgdHgpXG59XG5cbi8qKlxuICogUmVzb2x2ZSBvbmNlIHRoZSByb3V0ZXIgaGFzIHNldHRsZWQgb24gYSB0cmFuc2FjdGlvbiBvdGhlciB0aGFuIGBvd25lcmAuXG4gKiBFYWNoIHRyYW5zYWN0aW9uJ3MgY29tcGxldGlvbiBmb2xsb3dzIGl0cyBjdXJyZW50IHN1Y2Nlc3Nvciwgc28gYWxsIHdhaXRlcnNcbiAqIHNoYXJlIHRoZSBzYW1lIGNoYWluIGluc3RlYWQgb2YgcG9sbGluZyBldmVyeSBzdWNjZXNzb3IgaW5kZXBlbmRlbnRseS5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gYXdhaXRDdXJyZW50KFxuICByb3V0ZXI6IENvb3JkaW5hdG9yUm91dGVyLFxuICBvd25lcj86IExvYWRUcmFuc2FjdGlvbixcbik6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgY3VycmVudCA9IHJvdXRlci5fdHhcbiAgd2hpbGUgKGN1cnJlbnQgJiYgY3VycmVudCAhPT0gb3duZXIpIHtcbiAgICBvd25lciA9IGN1cnJlbnRcbiAgICBhd2FpdCBjdXJyZW50WzUgLyogZG9uZSAqL11cbiAgICBjdXJyZW50ID0gcm91dGVyLl90eFxuICB9XG59XG5cbmZ1bmN0aW9uIGZvbGxvd1JlZGlyZWN0KFxuICByb3V0ZXI6IENvb3JkaW5hdG9yUm91dGVyLFxuICB0eDogTG9hZFRyYW5zYWN0aW9uLFxuICBvdXRjb21lOiBSZWRpcmVjdE91dGNvbWUsXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3Qgb3B0aW9ucyA9IG91dGNvbWVbMSAvKiByZWRpcmVjdCAqL10ub3B0aW9uc1xuICBjb25zdCBsb2NhdGlvbiA9IG91dGNvbWVbMiAvKiBsb2NhdGlvbiAqL11cbiAgaWYgKCFsb2NhdGlvbikge1xuICAgIHJldHVybiByb3V0ZXIubmF2aWdhdGUoe1xuICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIHJlcGxhY2U6IHRydWUsXG4gICAgICBpZ25vcmVCbG9ja2VyOiB0cnVlLFxuICAgIH0gYXMgYW55KVxuICB9XG4gIGlmIChvcHRpb25zLnJlbG9hZERvY3VtZW50KSB7XG4gICAgcmV0dXJuIHJvdXRlci5uYXZpZ2F0ZSh7XG4gICAgICBocmVmOiAobG9jYXRpb24ubWFza2VkTG9jYXRpb24gPz8gbG9jYXRpb24pLnB1YmxpY0hyZWYsXG4gICAgICByZWxvYWREb2N1bWVudDogdHJ1ZSxcbiAgICAgIHJlcGxhY2U6IHRydWUsXG4gICAgICBpZ25vcmVCbG9ja2VyOiB0cnVlLFxuICAgIH0gYXMgYW55KVxuICB9XG4gIDsobG9jYXRpb24gYXMgUGFyc2VkTG9jYXRpb24gJiB7IF9yZWRpcmVjdHM/OiBudW1iZXIgfSkuX3JlZGlyZWN0cyA9XG4gICAgdHhbMSAvKiByZWRpcmVjdHMgKi9dICsgMVxuICByb3V0ZXIuX3BlbmRpbmdMb2NhdGlvbiA9IGxvY2F0aW9uXG4gIGNvbnN0IGNvbW1pdHRlZCA9IHJvdXRlci5jb21taXRMb2NhdGlvbih7XG4gICAgLi4ubG9jYXRpb24sXG4gICAgdmlld1RyYW5zaXRpb246IG9wdGlvbnMudmlld1RyYW5zaXRpb24sXG4gICAgcmVwbGFjZTogdHJ1ZSxcbiAgICByZXNldFNjcm9sbDogb3B0aW9ucy5yZXNldFNjcm9sbCxcbiAgICBoYXNoU2Nyb2xsSW50b1ZpZXc6IG9wdGlvbnMuaGFzaFNjcm9sbEludG9WaWV3LFxuICAgIGlnbm9yZUJsb2NrZXI6IHRydWUsXG4gIH0pXG4gIHF1ZXVlTWljcm90YXNrKCgpID0+IHtcbiAgICBpZiAocm91dGVyLl9wZW5kaW5nTG9jYXRpb24gPT09IGxvY2F0aW9uKSB7XG4gICAgICByb3V0ZXIuX3BlbmRpbmdMb2NhdGlvbiA9IHVuZGVmaW5lZFxuICAgIH1cbiAgfSlcbiAgcmV0dXJuIGNvbW1pdHRlZFxufVxuXG5hc3luYyBmdW5jdGlvbiBydW5CYWNrZ3JvdW5kKFxuICByb3V0ZXI6IENvb3JkaW5hdG9yUm91dGVyLFxuICB0eDogTG9hZFRyYW5zYWN0aW9uLFxuICBiYXNlOiBBcnJheTxBbnlSb3V0ZU1hdGNoPixcbiAgdGFza3M6IEFycmF5PEJhY2tncm91bmRMb2FkZXJUYXNrPixcbiAgc2V0dGxlbWVudDogUHJvbWlzZTxJbmRleGVkT3V0Y29tZSB8IHVuZGVmaW5lZD4sXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgbmV4dCA9IGJhc2UubWFwKChtYXRjaCkgPT4gKHsgLi4ubWF0Y2ggfSkpXG4gIGFjcXVpcmVNYXRjaFJlc291cmNlcyhuZXh0KVxuICBmb3IgKGNvbnN0IHRhc2sgb2YgdGFza3MpIHtcbiAgICByZWxlYXNlRmxpZ2h0KHJvdXRlciwgbmV4dFt0YXNrWzAgLyogaW5kZXggKi9dXSEpXG4gICAgbmV4dFt0YXNrWzAgLyogaW5kZXggKi9dXSA9IHRhc2tbMyAvKiBjYW5kaWRhdGUgKi9dXG4gIH1cbiAgLy8gUGhhc2UganVtcDogdGhlIGNsb25lcyBpbmhlcml0IGJlZm9yZUxvYWQgY29udGV4dCBmcm9tIHRoZSBjb21taXR0ZWRcbiAgLy8gZm9yZWdyb3VuZCBsYW5lLCB3aGljaCBhbHJlYWR5IHJhbiBgY29udGV4dHVhbGl6ZWAgZm9yIHRoZXNlIG1hdGNoZXMuXG4gIGNvbnN0IGxhbmUgPSBbdHhbMiAvKiBsb2NhdGlvbiAqL10sIG5leHRdIGFzIENvbnRleHR1YWxpemVkTGFuZVxuICBsZXQgcmVkdWNlZDogUmVkdWNlZExhbmUgfCBDb250cm9sT3V0Y29tZVxuICB0cnkge1xuICAgIHJlZHVjZWQgPSBhd2FpdCByZWR1Y2VMYW5lKFxuICAgICAgcm91dGVyLFxuICAgICAgbGFuZSxcbiAgICAgIHRhc2tzLFxuICAgICAgdHhbMCAvKiBjb250cm9sbGVyICovXSxcbiAgICAgIHNldHRsZW1lbnQsXG4gICAgKVxuICB9IGNhdGNoIChjYXVzZSkge1xuICAgIHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBuZXh0KVxuICAgIHRocm93IGNhdXNlXG4gIH1cbiAgaWYgKGlzQ29udHJvbChyZWR1Y2VkKSkge1xuICAgIHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBuZXh0KVxuICAgIGlmIChcbiAgICAgIHJlZHVjZWRbMCAvKiBraW5kICovXSA9PT0gUkVESVJFQ1RFRCAmJlxuICAgICAgcm91dGVyLl90eCA9PT0gdHggJiZcbiAgICAgIHJvdXRlci5fY29tbWl0dGVkID09PSBiYXNlXG4gICAgKSB7XG4gICAgICBhd2FpdCBmb2xsb3dSZWRpcmVjdChyb3V0ZXIsIHR4LCByZWR1Y2VkKVxuICAgIH1cbiAgICByZXR1cm5cbiAgfVxuICBhd2FpdCBwcm9qZWN0TGFuZShyb3V0ZXIsIHJlZHVjZWQsIHR4WzAgLyogY29udHJvbGxlciAqL10uc2lnbmFsKVxuICBpZiAocm91dGVyLl90eCAhPT0gdHggfHwgcm91dGVyLl9jb21taXR0ZWQgIT09IGJhc2UpIHtcbiAgICB0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgbmV4dClcbiAgICByZXR1cm5cbiAgfVxuICBmb3IgKGNvbnN0IG1hdGNoIG9mIG5leHQgYXMgQXJyYXk8V29ya01hdGNoPikge1xuICAgIGNvbnN0IGNhY2hlZCA9IHJvdXRlci5fY2FjaGUuZ2V0KG1hdGNoLmlkKSBhcyBXb3JrTWF0Y2ggfCB1bmRlZmluZWRcbiAgICBpZiAoY2FjaGVkPy5fZmxpZ2h0ICYmIGNhY2hlZC5fZmxpZ2h0ID09PSBtYXRjaC5fZmxpZ2h0KSB7XG4gICAgICByb3V0ZXIuX2NhY2hlLmRlbGV0ZShtYXRjaC5pZClcbiAgICAgIHJlbGVhc2VGbGlnaHQocm91dGVyLCBjYWNoZWQpXG4gICAgfVxuICB9XG4gIHB1Ymxpc2hNYXRjaGVzKHJvdXRlciwgbmV4dClcbiAgdHJhbnNmZXJNYXRjaFJlc291cmNlcyhyb3V0ZXIsIGJhc2UsIG5leHQpXG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJ1bkNsaWVudFRyYW5zYWN0aW9uKFxuICByb3V0ZXI6IENvb3JkaW5hdG9yUm91dGVyLFxuICB0eDogTG9hZFRyYW5zYWN0aW9uLFxuICBmb3JjZVN0YWxlUmVsb2FkOiBib29sZWFuLFxuICBvblJlYWR5PzogKCkgPT4gdm9pZCxcbiAgc3luYz86IGJvb2xlYW4sXG4gIHJlc29sdmVkUHJlZml4PzogbnVtYmVyLFxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGV4ZWN1dGVDbGllbnRMYW5lKFxuICAgIHJvdXRlcixcbiAgICB0eFsyIC8qIGxvY2F0aW9uICovXSxcbiAgICB0eFszIC8qIG1hdGNoZXMgKi9dLFxuICAgIFtcbiAgICAgIHR4WzAgLyogY29udHJvbGxlciAqL10sXG4gICAgICB0eFsxIC8qIHJlZGlyZWN0cyAqL10sXG4gICAgICByb3V0ZXIuX2NvbW1pdHRlZCxcbiAgICAgIHVuZGVmaW5lZCxcbiAgICAgIHN5bmMsXG4gICAgICBmb3JjZVN0YWxlUmVsb2FkLFxuICAgICAgcmVzb2x2ZWRQcmVmaXgsXG4gICAgICBvblJlYWR5LFxuICAgIF0sXG4gIClcblxuICBpZiAoaXNDb250cm9sKHJlc3VsdCkpIHtcbiAgICBjb25zdCBmb2xsb3cgPSByZXN1bHRbMCAvKiBraW5kICovXSA9PT0gUkVESVJFQ1RFRCAmJiByb3V0ZXIuX3R4ID09PSB0eFxuICAgIGlmICghZm9sbG93IHx8IHJlc3VsdFsxIC8qIHJlZGlyZWN0ICovXS5vcHRpb25zLnJlbG9hZERvY3VtZW50KSB7XG4gICAgICBmaW5pc2hQZW5kaW5nKHJvdXRlciwgdHgpXG4gICAgfVxuICAgIHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCB0eFszIC8qIG1hdGNoZXMgKi9dKVxuICAgIHR4WzMgLyogbWF0Y2hlcyAqL10gPSBbXVxuICAgIGlmICghZm9sbG93KSB7XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgaWYgKHJvdXRlci5fdHggIT09IHR4KSB7XG4gICAgICBmaW5pc2hQZW5kaW5nKHJvdXRlciwgdHgpXG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicgJiYgdHhbNiAvKiByZWZyZXNoICovXSkge1xuICAgICAgcm91dGVyLl9yZWZyZXNoTmV4dExvYWQgPSB0cnVlXG4gICAgfVxuICAgIGF3YWl0IGZvbGxvd1JlZGlyZWN0KHJvdXRlciwgdHgsIHJlc3VsdClcbiAgICByZXR1cm5cbiAgfVxuICBjb25zdCBtYXRjaGVzID0gcmVzdWx0WzEgLyogbWF0Y2hlcyAqL11cbiAgaWYgKHJvdXRlci5fdHggPT09IHR4KSB7XG4gICAgLy8gT25seSBhbiBhY2tub3dsZWRnZWQgZmFsbGJhY2sgb3ducyBhIG1pbmltdW0uIFJlY2hlY2sgYXQgdGhlIGNvbW1pdFxuICAgIC8vIGJvdW5kYXJ5IGJlY2F1c2UgbmF0aXZlIHZpZXcgdHJhbnNpdGlvbnMgY2FuIGRlZmVyIHRoZWlyIHVwZGF0ZSBjYWxsYmFjay5cbiAgICBhd2FpdCBhd2FpdFBlbmRpbmdNaW5pbXVtKHJvdXRlciwgdHgpXG4gIH1cbiAgaWYgKHJvdXRlci5fdHggIT09IHR4KSB7XG4gICAgZmluaXNoUGVuZGluZyhyb3V0ZXIsIHR4KVxuICAgIHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBtYXRjaGVzKVxuICAgIGRpc2NhcmRCYWNrZ3JvdW5kKHJvdXRlciwgcmVzdWx0KVxuICAgIHJldHVyblxuICB9XG4gIGNvbnN0IHRvTG9jYXRpb24gPSB0eFsyIC8qIGxvY2F0aW9uICovXVxuICBjb25zdCBjaGFuZ2VJbmZvID0gZ2V0TG9jYXRpb25DaGFuZ2VJbmZvKFxuICAgIHRvTG9jYXRpb24sXG4gICAgcm91dGVyLnN0b3Jlcy5yZXNvbHZlZExvY2F0aW9uLmdldCgpLFxuICApXG4gIGNvbnN0IGJhY2tncm91bmQgPSByZXN1bHRbMiAvKiBiYWNrZ3JvdW5kICovXVxuICBhd2FpdCByb3V0ZXIuc3RhcnRWaWV3VHJhbnNpdGlvbihhc3luYyAoKSA9PiB7XG4gICAgaWYgKHJvdXRlci5fdHggPT09IHR4KSB7XG4gICAgICBhd2FpdCBhd2FpdFBlbmRpbmdNaW5pbXVtKHJvdXRlciwgdHgpXG4gICAgfVxuICAgIGlmIChyb3V0ZXIuX3R4ICE9PSB0eCkge1xuICAgICAgZmluaXNoUGVuZGluZyhyb3V0ZXIsIHR4KVxuICAgICAgdHJhbnNmZXJNYXRjaFJlc291cmNlcyhyb3V0ZXIsIG1hdGNoZXMpXG4gICAgICBkaXNjYXJkQmFja2dyb3VuZChyb3V0ZXIsIHJlc3VsdClcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICBjb25zdCBjb21taXQgPSAoKSA9PiB7XG4gICAgICBmaW5pc2hQZW5kaW5nKHJvdXRlciwgdHgpXG4gICAgICBjb21taXRNYXRjaGVzKHJvdXRlciwgdHgsIG1hdGNoZXMsIHJlc29sdmVkUHJlZml4KVxuICAgICAgaWYgKHJvdXRlci5fdHggIT09IHR4KSB7XG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgcm91dGVyLmVtaXQoeyB0eXBlOiAnb25Mb2FkJywgLi4uY2hhbmdlSW5mbyB9KVxuICAgICAgaWYgKHJvdXRlci5fdHggPT09IHR4KSB7XG4gICAgICAgIHJvdXRlci5lbWl0KHsgdHlwZTogJ29uQmVmb3JlUm91dGVNb3VudCcsIC4uLmNoYW5nZUluZm8gfSlcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgcmVuZGVyZWQgPSBhd2FpdCByb3V0ZXIuc3RhcnRUcmFuc2l0aW9uKGNvbW1pdCwgbWF0Y2hlcylcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJyAmJiB0eFs2IC8qIHJlZnJlc2ggKi9dKSB7XG4gICAgICB0eFs2IC8qIHJlZnJlc2ggKi9dID0gdW5kZWZpbmVkXG4gICAgfVxuICAgIGlmIChyb3V0ZXIuX3R4ICE9PSB0eCkge1xuICAgICAgZGlzY2FyZEJhY2tncm91bmQocm91dGVyLCByZXN1bHQpXG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgaWYgKGJhY2tncm91bmQ/Lmxlbmd0aCkge1xuICAgICAgLy8gUHVibGlzaCBiYWNrZ3JvdW5kIG1hdGNoZXMgb25seSBhZnRlciB0aGUgZm9yZWdyb3VuZCBhY2tub3dsZWRnZW1lbnQuXG4gICAgICAvLyBPdGhlcndpc2UgZmFzdCB3b3JrIGNhbiByZXBsYWNlIHRoZSBhY2tub3dsZWRnZWQgZ2VuZXJhdGlvblxuICAgICAgLy8gYmVmb3JlIHRoZSBmcmFtZXdvcmsgY29tbWl0cyBpdCBhbmQgc3RyYW5kIHRoZSBuYXZpZ2F0aW9uLlxuICAgICAgcnVuQmFja2dyb3VuZChcbiAgICAgICAgcm91dGVyLFxuICAgICAgICB0eCxcbiAgICAgICAgbWF0Y2hlcyxcbiAgICAgICAgYmFja2dyb3VuZCxcbiAgICAgICAgcmVzdWx0WzMgLyogYmFja2dyb3VuZFNldHRsZW1lbnQgKi9dISxcbiAgICAgICkuY2F0Y2goY29uc29sZS5lcnJvcilcbiAgICB9XG4gICAgcm91dGVyLmJhdGNoKCgpID0+IHtcbiAgICAgIHJvdXRlci5zdG9yZXMucmVzb2x2ZWRMb2NhdGlvbi5zZXQodG9Mb2NhdGlvbilcbiAgICAgIHJvdXRlci5zdG9yZXMuc3RhdHVzLnNldCgnaWRsZScpXG4gICAgICBpZiAocm91dGVyLl90eCA9PT0gdHgpIHtcbiAgICAgICAgcm91dGVyLmVtaXQoeyB0eXBlOiAnb25SZXNvbHZlZCcsIC4uLmNoYW5nZUluZm8gfSlcbiAgICAgIH1cbiAgICAgIGlmIChyZW5kZXJlZCAmJiByb3V0ZXIuX3R4ID09PSB0eCkge1xuICAgICAgICByb3V0ZXIuZW1pdCh7IHR5cGU6ICdvblJlbmRlcmVkJywgLi4uY2hhbmdlSW5mbyB9KVxuICAgICAgfVxuICAgIH0pXG4gICAgaWYgKHJvdXRlci5fdHggIT09IHR4KSB7XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgcm91dGVyLl9jb21taXRQcm9taXNlPy5yZXNvbHZlKClcbiAgICByb3V0ZXIuX2NvbW1pdFByb21pc2UgPSB1bmRlZmluZWRcbiAgfSlcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxvYWRDbGllbnRSb3V0ZShcbiAgcm91dGVyOiBDb29yZGluYXRvclJvdXRlcixcbiAgb3B0cz86IHsgc3luYz86IGJvb2xlYW4gfSxcbik6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgcmVtYXRlcmlhbGl6ZSA9IGZhbHNlXG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgcmVtYXRlcmlhbGl6ZSA9ICEhcm91dGVyLl9yZWZyZXNoTmV4dExvYWQgfHwgISFyb3V0ZXIuX3R4Py5bNiAvKiByZWZyZXNoICovXVxuICB9XG4gIGNvbnN0IHByZXZpb3VzT3duZXIgPSByb3V0ZXIuX3R4XG4gIGNvbnN0IHJlc29sdmVkTG9jYXRpb24gPSByb3V0ZXIuc3RvcmVzLnJlc29sdmVkTG9jYXRpb24uZ2V0KClcbiAgY29uc3QgcHJldmlvdXNMb2NhdGlvbiA9IHJlc29sdmVkTG9jYXRpb24gPz8gcm91dGVyLnN0b3Jlcy5sb2NhdGlvbi5nZXQoKVxuICBjb25zdCBsb2NhdGlvbiA9IHJvdXRlci5sYXRlc3RMb2NhdGlvblxuICBjb25zdCBwZW5kaW5nTG9jYXRpb24gPSByb3V0ZXIuX3BlbmRpbmdMb2NhdGlvbiBhc1xuICAgIHwgKFBhcnNlZExvY2F0aW9uICYgeyBfcmVkaXJlY3RzPzogbnVtYmVyIH0pXG4gICAgfCB1bmRlZmluZWRcbiAgY29uc3QgcmVkaXJlY3RzID1cbiAgICBwZW5kaW5nTG9jYXRpb24/LmhyZWYgPT09IGxvY2F0aW9uLmhyZWZcbiAgICAgID8gKHBlbmRpbmdMb2NhdGlvbi5fcmVkaXJlY3RzID8/IDApXG4gICAgICA6IDBcbiAgY29uc3QgaGFuZG9mZiA9IHJvdXRlci5faGFuZG9mZlxuICBjb25zdCBoeWRyYXRpb25Db250cm9sbGVyID0gcmVtYXRlcmlhbGl6ZVxuICAgID8gdW5kZWZpbmVkXG4gICAgOiBoYW5kb2ZmPy5bMCAvKiBjbGFpbSAqL10oKVxuICBjb25zdCBwcmVmbGlnaHQgPSBuZXcgQWJvcnRDb250cm9sbGVyKClcbiAgY29uc3QgcHJldmlvdXNQcmVmbGlnaHQgPSByb3V0ZXIuX3ByZWZsaWdodFxuICByb3V0ZXIuX3ByZWZsaWdodCA9IHByZWZsaWdodFxuICBpZiAoIXJlbWF0ZXJpYWxpemUgJiYgIWh5ZHJhdGlvbkNvbnRyb2xsZXIpIHtcbiAgICBoYW5kb2ZmPy5bMSAvKiBmaW5pc2ggKi9dKClcbiAgfVxuICBwcmV2aW91c1ByZWZsaWdodD8uYWJvcnQoKVxuICAvLyBUaGUgcHJlZmxpZ2h0IGNvbnRyb2xsZXIgaXMgbm90IGV4cG9zZWQgdG8gcm91dGUgaG9va3MuIEV2ZXJ5IHJlcGxhY2VtZW50XG4gIC8vIGFib3J0cyBpdHMgcHJlZGVjZXNzb3IsIHNvIGEgbGl2ZSBzaWduYWwgaXMgdGhlIHNvbGUgYXV0aG9yaXR5IGhlcmUuXG4gIGlmICghcHJlZmxpZ2h0LnNpZ25hbC5hYm9ydGVkKSB7XG4gICAgY29uc3QgY2hhbmdlSW5mbyA9IGdldExvY2F0aW9uQ2hhbmdlSW5mbyhsb2NhdGlvbiwgcmVzb2x2ZWRMb2NhdGlvbilcbiAgICByb3V0ZXIuZW1pdCh7IHR5cGU6ICdvbkJlZm9yZU5hdmlnYXRlJywgLi4uY2hhbmdlSW5mbyB9KVxuICAgIGlmICghcHJlZmxpZ2h0LnNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICByb3V0ZXIuZW1pdCh7IHR5cGU6ICdvbkJlZm9yZUxvYWQnLCAuLi5jaGFuZ2VJbmZvIH0pXG4gICAgfVxuICB9XG4gIGlmIChwcmVmbGlnaHQuc2lnbmFsLmFib3J0ZWQpIHtcbiAgICBhd2FpdCBhd2FpdEN1cnJlbnQocm91dGVyLCBwcmV2aW91c093bmVyKVxuICAgIHJldHVyblxuICB9XG4gIGNvbnN0IHNhbWVIcmVmID0gcHJldmlvdXNMb2NhdGlvbi5ocmVmID09PSBsb2NhdGlvbi5ocmVmXG4gIGxldCBjb250cm9sbGVyID0gcHJlZmxpZ2h0XG4gIGNvbnN0IG1hdGNoZXMgPVxuICAgIHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicgJiYgcmVtYXRlcmlhbGl6ZVxuICAgICAgPyByb3V0ZXIubWF0Y2hSb3V0ZXMobG9jYXRpb24sIHtcbiAgICAgICAgICBfY29udHJvbGxlcjogcHJlZmxpZ2h0LFxuICAgICAgICAgIF9yZW1hdGVyaWFsaXplOiB0cnVlLFxuICAgICAgICB9KVxuICAgICAgOiByb3V0ZXIubWF0Y2hSb3V0ZXMobG9jYXRpb24sIHsgX2NvbnRyb2xsZXI6IHByZWZsaWdodCB9KVxuICBhY3F1aXJlTWF0Y2hSZXNvdXJjZXMobWF0Y2hlcylcbiAgY29uc3QgcmVzb2x2ZWRQcmVmaXggPSBoeWRyYXRpb25Db250cm9sbGVyXG4gICAgPyBoYW5kb2ZmIVsxIC8qIGZpbmlzaCAqL10obWF0Y2hlcylcbiAgICA6IHVuZGVmaW5lZFxuICBpZiAocmVzb2x2ZWRQcmVmaXgpIHtcbiAgICBjb250cm9sbGVyID0gaHlkcmF0aW9uQ29udHJvbGxlciFcbiAgfSBlbHNlIHtcbiAgICBoeWRyYXRpb25Db250cm9sbGVyPy5hYm9ydCgpXG4gIH1cbiAgaWYgKHByZWZsaWdodC5zaWduYWwuYWJvcnRlZCkge1xuICAgIHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBtYXRjaGVzKVxuICAgIGF3YWl0IGF3YWl0Q3VycmVudChyb3V0ZXIsIHByZXZpb3VzT3duZXIpXG4gICAgcmV0dXJuXG4gIH1cbiAgcm91dGVyLl9wcmVmbGlnaHQgPSB1bmRlZmluZWRcblxuICBsZXQgc2V0dGxlOiAoKHZhbHVlOiB2b2lkIHwgUHJvbWlzZUxpa2U8dm9pZD4pID0+IHZvaWQpIHwgdW5kZWZpbmVkXG4gIGNvbnN0IHJ1biA9ICgpID0+XG4gICAgcnVuQ2xpZW50VHJhbnNhY3Rpb24oXG4gICAgICByb3V0ZXIsXG4gICAgICB0eCxcbiAgICAgIHNhbWVIcmVmLFxuICAgICAgKCkgPT4gb2ZmZXJQZW5kaW5nKHJvdXRlciwgdHgpLFxuICAgICAgb3B0cz8uc3luYyxcbiAgICAgIHJlc29sdmVkUHJlZml4LFxuICAgIClcbiAgY29uc3QgZG9uZSA9IG9wdHM/LnN5bmNcbiAgICA/IG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlKSA9PiAoc2V0dGxlID0gcmVzb2x2ZSkpXG4gICAgOiBQcm9taXNlLnJlc29sdmUoKS50aGVuKHJ1bilcbiAgY29uc3QgdHg6IExvYWRUcmFuc2FjdGlvbiA9IFtcbiAgICBjb250cm9sbGVyLFxuICAgIHJlZGlyZWN0cyxcbiAgICBsb2NhdGlvbixcbiAgICBtYXRjaGVzLFxuICAgIERhdGUubm93KCksXG4gICAgZG9uZS50aGVuKCgpID0+IGF3YWl0Q3VycmVudChyb3V0ZXIsIHR4KSksXG4gIF1cbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicgJiYgcmVtYXRlcmlhbGl6ZSkge1xuICAgIHR4WzYgLyogcmVmcmVzaCAqL10gPSBbaGFuZG9mZl1cbiAgICByb3V0ZXIuX3JlZnJlc2hOZXh0TG9hZCA9IHVuZGVmaW5lZFxuICB9XG4gIHJvdXRlci5fdHggPSB0eFxuICBpZiAocHJldmlvdXNPd25lcikge1xuICAgIGZvciAoY29uc3QgbWF0Y2ggb2Ygcm91dGVyLnN0b3Jlcy5tYXRjaGVzLmdldCgpIGFzIEFycmF5PFdvcmtNYXRjaD4pIHtcbiAgICAgIGlmIChyb3V0ZXIuX3R4ICE9PSB0eCkge1xuICAgICAgICBicmVha1xuICAgICAgfVxuICAgICAgaWYgKG1hdGNoLmlzRmV0Y2hpbmcpIHtcbiAgICAgICAgc2V0RmV0Y2hpbmcocm91dGVyLCBtYXRjaCwgZmFsc2UpXG4gICAgICB9XG4gICAgfVxuICAgIHByZXZpb3VzT3duZXJbMCAvKiBjb250cm9sbGVyICovXS5hYm9ydCgpXG4gICAgdHJhbnNmZXJNYXRjaFJlc291cmNlcyhcbiAgICAgIHJvdXRlcixcbiAgICAgIHByZXZpb3VzT3duZXJbMyAvKiBtYXRjaGVzICovXSxcbiAgICAgIHR4WzMgLyogbWF0Y2hlcyAqL10sXG4gICAgICB0cnVlLFxuICAgIClcbiAgfVxuICBpZiAocm91dGVyLl90eCAhPT0gdHgpIHtcbiAgICB0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgdHhbMyAvKiBtYXRjaGVzICovXSlcbiAgICB0eFszIC8qIG1hdGNoZXMgKi9dID0gW11cbiAgICBzZXR0bGU/LigpXG4gICAgYXdhaXQgYXdhaXRDdXJyZW50KHJvdXRlciwgdHgpXG4gICAgcmV0dXJuXG4gIH1cbiAgcm91dGVyLmJhdGNoKCgpID0+IHtcbiAgICByb3V0ZXIuc3RvcmVzLnN0YXR1cy5zZXQoJ3BlbmRpbmcnKVxuICAgIHJvdXRlci5zdG9yZXMubG9jYXRpb24uc2V0KGxvY2F0aW9uKVxuICB9KVxuICAvLyBBbiB1bnJlc29sdmVkIGNvbGQgcm9vdCBoYXMgbm8gVUkgdG8gcmV0YWluLiBQcm92aXNpb25hbCBub3QtZm91bmQgd2FpdHNcbiAgLy8gZm9yIGxhenkgcm91dGVzIHRvIHBsYWNlIHRoZSBmaW5hbCBib3VuZGFyeS5cbiAgaWYgKFxuICAgIHJlc29sdmVkUHJlZml4IHx8XG4gICAgKCFyb3V0ZXIuX2NvbW1pdHRlZC5sZW5ndGggJiZcbiAgICAgIG1hdGNoZXNbMF0/LnN0YXR1cyAhPT0gJ3N1Y2Nlc3MnICYmXG4gICAgICAhbWF0Y2hlcy5zb21lKChtYXRjaCkgPT4gbWF0Y2guX25vdEZvdW5kKSlcbiAgKSB7XG4gICAgb2ZmZXJQZW5kaW5nKHJvdXRlciwgdHgpXG4gIH1cbiAgLy8gTGV0IGV4cGxpY2l0IHN5bmNocm9ub3VzIGxvYWRzIHB1Ymxpc2ggcmVhZHkgcGVuZGluZyB3b3JrIGJlZm9yZSBwYWludC5cbiAgc2V0dGxlPy4ocnVuKCkpXG4gIGF3YWl0IHR4WzUgLyogZG9uZSAqL11cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hDbGllbnRSb3V0ZShcbiAgcm91dGVyOiBDb29yZGluYXRvclJvdXRlcixcbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBwZW5kaW5nID0gcm91dGVyLl90eFxuICBpZiAoXG4gICAgcGVuZGluZyAmJlxuICAgICFwZW5kaW5nWzYgLyogcmVmcmVzaCAqL10gJiZcbiAgICByb3V0ZXIuc3RvcmVzLnN0YXR1cy5nZXQoKSA9PT0gJ3BlbmRpbmcnXG4gICkge1xuICAgIGF3YWl0IHBlbmRpbmdbNSAvKiBkb25lICovXVxuICAgIGlmIChyb3V0ZXIuX3R4ICE9PSBwZW5kaW5nKSB7XG4gICAgICBhd2FpdCBhd2FpdEN1cnJlbnQocm91dGVyLCBwZW5kaW5nKVxuICAgIH1cbiAgfVxuICAvLyBFeGlzdGluZyBvd25lcnMgcmVtYWluIHByZXNlbnRlZCBidXQgY2Fubm90IGRvbmF0ZSBzdGFsZSB3b3JrLlxuICByb3V0ZXIuX2ZsaWdodHM/LmNsZWFyKClcbiAgcm91dGVyLmNsZWFyQ2FjaGUoKVxuICByb3V0ZXIuX3JlZnJlc2hOZXh0TG9hZCA9IHRydWVcbiAgYXdhaXQgbG9hZENsaWVudFJvdXRlKHJvdXRlciwgeyBzeW5jOiB0cnVlIH0pXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcmVsb2FkQ2xpZW50Um91dGU8XG4gIFRSb3V0ZVRyZWUgZXh0ZW5kcyBBbnlSb3V0ZSxcbiAgVFRyYWlsaW5nU2xhc2hPcHRpb24gZXh0ZW5kcyBUcmFpbGluZ1NsYXNoT3B0aW9uLFxuICBURGVmYXVsdFN0cnVjdHVyYWxTaGFyaW5nT3B0aW9uIGV4dGVuZHMgYm9vbGVhbixcbiAgVFJvdXRlckhpc3RvcnkgZXh0ZW5kcyBSb3V0ZXJIaXN0b3J5LFxuICBURGVoeWRyYXRlZCBleHRlbmRzIFJlY29yZDxzdHJpbmcsIGFueT4gPSBSZWNvcmQ8c3RyaW5nLCBhbnk+LFxuICBURnJvbSBleHRlbmRzIFJvdXRlUGF0aHM8VFJvdXRlVHJlZT4gfCBzdHJpbmcgPSBzdHJpbmcsXG4gIFRUbyBleHRlbmRzIHN0cmluZyB8IHVuZGVmaW5lZCA9IHVuZGVmaW5lZCxcbiAgVE1hc2tGcm9tIGV4dGVuZHMgUm91dGVQYXRoczxUUm91dGVUcmVlPiB8IHN0cmluZyA9IFRGcm9tLFxuICBUTWFza1RvIGV4dGVuZHMgc3RyaW5nID0gJycsXG4+KFxuICByb3V0ZXI6IFJvdXRlckNvcmU8XG4gICAgVFJvdXRlVHJlZSxcbiAgICBUVHJhaWxpbmdTbGFzaE9wdGlvbixcbiAgICBURGVmYXVsdFN0cnVjdHVyYWxTaGFyaW5nT3B0aW9uLFxuICAgIFRSb3V0ZXJIaXN0b3J5LFxuICAgIFREZWh5ZHJhdGVkXG4gID4sXG4gIG9wdHM6IE5hdmlnYXRlT3B0aW9uczxcbiAgICBSb3V0ZXJDb3JlPFxuICAgICAgVFJvdXRlVHJlZSxcbiAgICAgIFRUcmFpbGluZ1NsYXNoT3B0aW9uLFxuICAgICAgVERlZmF1bHRTdHJ1Y3R1cmFsU2hhcmluZ09wdGlvbixcbiAgICAgIFRSb3V0ZXJIaXN0b3J5LFxuICAgICAgVERlaHlkcmF0ZWRcbiAgICA+LFxuICAgIFRGcm9tLFxuICAgIFRUbyxcbiAgICBUTWFza0Zyb20sXG4gICAgVE1hc2tUb1xuICA+LFxuKTogUHJvbWlzZTxBcnJheTxBbnlSb3V0ZU1hdGNoPiB8IHVuZGVmaW5lZD4ge1xuICBpZiAoXG4gICAgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJyAmJlxuICAgICgocm91dGVyIGFzIENvb3JkaW5hdG9yUm91dGVyKS5fcmVmcmVzaE5leHRMb2FkIHx8XG4gICAgICByb3V0ZXIuX3R4Py5bNiAvKiByZWZyZXNoICovXSlcbiAgKSB7XG4gICAgcmV0dXJuXG4gIH1cbiAgbGV0IGxvY2F0aW9uID0gcm91dGVyLmJ1aWxkTG9jYXRpb24oXG4gICAgb3B0cyBhcyBQYXJhbWV0ZXJzPHR5cGVvZiByb3V0ZXIuYnVpbGRMb2NhdGlvbj5bMF0sXG4gIClcbiAgZm9yIChsZXQgcmVkaXJlY3RzID0gMDsgOyByZWRpcmVjdHMrKykge1xuICAgIGNvbnN0IGJhc2UgPSByb3V0ZXIuX2NvbW1pdHRlZFxuICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKClcbiAgICBsZXQgbWF0Y2hlczogQXJyYXk8QW55Um91dGVNYXRjaD4gfCB1bmRlZmluZWRcbiAgICBsZXQgYWN0aXZlOiBib29sZWFuIHwgTWFwPEFib3J0Q29udHJvbGxlciwgQXJyYXk8QW55Um91dGVNYXRjaD4+IHwgdW5kZWZpbmVkXG4gICAgbGV0IHJlc3VsdDogTGFuZVJlc3VsdFxuICAgIHRyeSB7XG4gICAgICB0cnkge1xuICAgICAgICBtYXRjaGVzID0gcm91dGVyLm1hdGNoUm91dGVzKGxvY2F0aW9uLCB7XG4gICAgICAgICAgX2NvbnRyb2xsZXI6IGNvbnRyb2xsZXIsXG4gICAgICAgIH0pXG4gICAgICAgIGFjcXVpcmVNYXRjaFJlc291cmNlcyhtYXRjaGVzKVxuICAgICAgICBhY3RpdmUgPSAocm91dGVyLl9wcmVsb2FkcyA/Pz0gbmV3IE1hcCgpKS5zZXQoY29udHJvbGxlciwgbWF0Y2hlcylcbiAgICAgICAgcmVzdWx0ID0gYXdhaXQgZXhlY3V0ZUNsaWVudExhbmUocm91dGVyLCBsb2NhdGlvbiwgbWF0Y2hlcywgW1xuICAgICAgICAgIGNvbnRyb2xsZXIsXG4gICAgICAgICAgcmVkaXJlY3RzLFxuICAgICAgICAgIGJhc2UsXG4gICAgICAgICAgdHJ1ZSxcbiAgICAgICAgXSlcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIGlmIChhY3RpdmUpIHtcbiAgICAgICAgICBhY3RpdmUgPSAoXG4gICAgICAgICAgICBhY3RpdmUgYXMgTWFwPEFib3J0Q29udHJvbGxlciwgQXJyYXk8QW55Um91dGVNYXRjaD4+XG4gICAgICAgICAgKS5kZWxldGUoY29udHJvbGxlcilcbiAgICAgICAgICB0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgbWF0Y2hlcyEpXG4gICAgICAgIH1cbiAgICAgICAgY29udHJvbGxlci5hYm9ydCgpXG4gICAgICB9XG4gICAgICBpZiAoIWlzQ29udHJvbChyZXN1bHQpKSB7XG4gICAgICAgIHJldHVybiByZXN1bHRbMSAvKiBtYXRjaGVzICovXVxuICAgICAgfVxuICAgICAgLy8gT25seSBhIG1hdGVyaWFsaXplZCByZWRpcmVjdCBoYXMgYSB0aGlyZCB0dXBsZSBpdGVtLlxuICAgICAgaWYgKFxuICAgICAgICAhYWN0aXZlIHx8XG4gICAgICAgIHJlc3VsdC5sZW5ndGggPCAzIHx8XG4gICAgICAgIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nICYmXG4gICAgICAgICAgKChyb3V0ZXIgYXMgQ29vcmRpbmF0b3JSb3V0ZXIpLl9yZWZyZXNoTmV4dExvYWQgfHxcbiAgICAgICAgICAgIHJvdXRlci5fdHg/Lls2IC8qIHJlZnJlc2ggKi9dKSlcbiAgICAgICkge1xuICAgICAgICByZXR1cm5cbiAgICAgIH1cbiAgICAgIGxvY2F0aW9uID0gcmVzdWx0WzIgLyogbG9jYXRpb24gKi9dIVxuICAgIH0gY2F0Y2ggKGNhdXNlKSB7XG4gICAgICBpZiAoIWlzTm90Rm91bmQoY2F1c2UpKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoY2F1c2UpXG4gICAgICB9XG4gICAgICByZXR1cm5cbiAgICB9XG4gIH1cbn1cblxuLy8gLS0tIFNTUiBoeWRyYXRpb24gKGNsaWVudCBlbnRyeSB2aWEgQHRhbnN0YWNrL3JvdXRlci1jb3JlL3Nzci9jbGllbnQpIC0tLVxuXG5kZWNsYXJlIGdsb2JhbCB7XG4gIGludGVyZmFjZSBXaW5kb3cge1xuICAgIFtHTE9CQUxfVFNSXT86IFRzclNzckdsb2JhbFxuICAgIFtHTE9CQUxfU0VST1ZBTF0/OiBhbnlcbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaHlkcmF0ZShyb3V0ZXI6IEFueVJvdXRlcik6IFByb21pc2U8dm9pZD4ge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJyAmJiAhd2luZG93LiRfVFNSKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgJ0ludmFyaWFudCBmYWlsZWQ6IEV4cGVjdGVkIHRvIGZpbmQgYm9vdHN0cmFwIGRhdGEgb24gd2luZG93LiRfVFNSLCBidXQgd2UgZGlkIG5vdC4gUGxlYXNlIGZpbGUgYW4gaXNzdWUhJyxcbiAgICApXG4gIH1cbiAgY29uc3QgdHNyID0gd2luZG93LiRfVFNSIVxuXG4gIGNvbnN0IGFkYXB0ZXJzID0gcm91dGVyLm9wdGlvbnMuc2VyaWFsaXphdGlvbkFkYXB0ZXJzXG4gIGlmIChhZGFwdGVycz8ubGVuZ3RoKSB7XG4gICAgdHNyLnQgPSBuZXcgTWFwKFxuICAgICAgYWRhcHRlcnMubWFwKChhZGFwdGVyKSA9PiBbYWRhcHRlci5rZXksIGFkYXB0ZXIuZnJvbVNlcmlhbGl6YWJsZV0pLFxuICAgIClcbiAgICB0c3IuYnVmZmVyLmZvckVhY2goKHNjcmlwdCkgPT4gc2NyaXB0KCkpXG4gIH1cbiAgdHNyLmluaXRpYWxpemVkID0gdHJ1ZVxuXG4gIGNvbnN0IGRlaHlkcmF0ZWRSb3V0ZXIgPSB0c3Iucm91dGVyXG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nICYmICFkZWh5ZHJhdGVkUm91dGVyKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgJ0ludmFyaWFudCBmYWlsZWQ6IEV4cGVjdGVkIHRvIGZpbmQgYSBkZWh5ZHJhdGVkIGRhdGEgb24gd2luZG93LiRfVFNSLnJvdXRlciwgYnV0IHdlIGRpZCBub3QuIFBsZWFzZSBmaWxlIGFuIGlzc3VlIScsXG4gICAgKVxuICB9XG4gIHJvdXRlci5zc3IgPSB7IG1hbmlmZXN0OiBkZWh5ZHJhdGVkUm91dGVyIS5tYW5pZmVzdCB9XG4gIHJvdXRlci5vcHRpb25zLnNzciA9IHtcbiAgICBub25jZTogKFxuICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignbWV0YVtwcm9wZXJ0eT1cImNzcC1ub25jZVwiXScpIGFzXG4gICAgICAgIHwgSFRNTE1ldGFFbGVtZW50XG4gICAgICAgIHwgdW5kZWZpbmVkXG4gICAgKT8uY29udGVudCxcbiAgfVxuXG4gIGNvbnN0IGRlaHlkcmF0ZWRNYXRjaGVzID0gZGVoeWRyYXRlZFJvdXRlciEubWF0Y2hlc1xuXG4gIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKClcbiAgY29uc3QgcHJldmlvdXNQcmVmbGlnaHQgPSByb3V0ZXIuX3ByZWZsaWdodFxuICByb3V0ZXIuX3ByZWZsaWdodCA9IGNvbnRyb2xsZXJcbiAgcHJldmlvdXNQcmVmbGlnaHQ/LmFib3J0KClcbiAgLy8gT25seSBhIG5ldyBzbG90IG93bmVyIHN1cGVyc2VkZXMgaHlkcmF0aW9uLlxuICBjb25zdCBpc0N1cnJlbnQgPSAoKSA9PiByb3V0ZXIuX3ByZWZsaWdodCA9PT0gY29udHJvbGxlclxuXG4gIGxldCBsb2NhdGlvbiE6IEFueVJvdXRlclsnbGF0ZXN0TG9jYXRpb24nXVxuICBsZXQgY2FuZGlkYXRlcyE6IEFycmF5PEFueVJvdXRlTWF0Y2g+XG4gIGxldCBoYW5kb2ZmSGlzdG9yeUhyZWYhOiBzdHJpbmdcbiAgbGV0IGhhbmRvZmZIaXN0b3J5U3RhdGU6IHVua25vd25cbiAgdHJ5IHtcbiAgICBhd2FpdCB3YWl0Rm9yKFxuICAgICAgcm91dGVyLm9wdGlvbnMuaHlkcmF0ZT8uKGRlaHlkcmF0ZWRSb3V0ZXIhLmRlaHlkcmF0ZWREYXRhKSxcbiAgICAgIGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgIClcbiAgICBpZiAoIWlzQ3VycmVudCgpKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgLy8gSHlkcmF0aW9uIHRydXN0cyB0cmFuc3BvcnRlZCBjb250ZXh0IGFuZCBiZWZvcmVMb2FkLiBUaGUgcmF3IGhpc3RvcnlcbiAgICAvLyBlbnRyeSBvd25zIHRoZSBoYW5kb2ZmOyByb3V0ZSBzdHJ1Y3R1cmUgaXMgdmVyaWZpZWQgYWZ0ZXIgcmVtYXRjaGluZy5cbiAgICBjb25zdCBoaXN0b3J5TG9jYXRpb24gPSByb3V0ZXIuaGlzdG9yeS5sb2NhdGlvblxuICAgIGhhbmRvZmZIaXN0b3J5SHJlZiA9IGhpc3RvcnlMb2NhdGlvbi5ocmVmXG4gICAgaGFuZG9mZkhpc3RvcnlTdGF0ZSA9IGhpc3RvcnlMb2NhdGlvbi5zdGF0ZVxuICAgIHJvdXRlci51cGRhdGVMYXRlc3RMb2NhdGlvbigpXG4gICAgbG9jYXRpb24gPSByb3V0ZXIubGF0ZXN0TG9jYXRpb25cbiAgICByb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLnNldChsb2NhdGlvbilcbiAgICBjYW5kaWRhdGVzID0gcm91dGVyLm1hdGNoUm91dGVzKGxvY2F0aW9uLCB7XG4gICAgICBfY29udHJvbGxlcjogY29udHJvbGxlcixcbiAgICB9KVxuICB9IGNhdGNoIChjYXVzZSkge1xuICAgIGlmIChpc0N1cnJlbnQoKSkge1xuICAgICAgcm91dGVyLl9wcmVmbGlnaHQgPSB1bmRlZmluZWRcbiAgICB9XG4gICAgY29udHJvbGxlci5hYm9ydChjYXVzZSlcbiAgICBpZiAoY2F1c2UgIT09IGNvbnRyb2xsZXIuc2lnbmFsKSB7XG4gICAgICB0aHJvdyBjYXVzZVxuICAgIH1cbiAgfVxuICBpZiAoIWlzQ3VycmVudCgpKSB7XG4gICAgcmV0dXJuXG4gIH1cbiAgY29uc3QgY29tbWl0dGVkOiBBcnJheTxBbnlSb3V0ZU1hdGNoPiA9IFtdXG4gIGxldCBwZW5kaW5nQm91bmRhcnk6IG51bWJlciB8IHVuZGVmaW5lZFxuICBsZXQgdmVyaWZpZWRBc3NldEVuZCA9IDBcbiAgY29uc3QgcmV0cnlGcm9tID0gKGluZGV4OiBudW1iZXIpID0+IHtcbiAgICAvLyBUaGUgZmFpbGluZyByb3V0ZSdzIGlkZW50aXR5IGlzIHN0aWxsIHZlcmlmaWVkLCBidXQgbm8gZGVzY2VuZGFudCBpcy5cbiAgICB2ZXJpZmllZEFzc2V0RW5kID0gTWF0aC5taW4odmVyaWZpZWRBc3NldEVuZCwgaW5kZXggKyAxKVxuICAgIGNvbnN0IHJlbW92ZWQgPSBjb21taXR0ZWQuc3BsaWNlKGluZGV4KVxuICAgIGZvciAoY29uc3QgbWF0Y2ggb2YgcmVtb3ZlZCkge1xuICAgICAgaWYgKFxuICAgICAgICBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKS5vcHRpb25zLmxvYWRlciAmJlxuICAgICAgICAobWF0Y2guc3RhdHVzID09PSAnc3VjY2VzcycgfHxcbiAgICAgICAgICAoIW1hdGNoLmludmFsaWQgJiYgJ2xvYWRlckRhdGEnIGluIG1hdGNoKSlcbiAgICAgICkge1xuICAgICAgICBjYWNoZUxvYWRlck1hdGNoKFxuICAgICAgICAgIHJvdXRlcixcbiAgICAgICAgICAvLyBQaGFzZSBqdW1wOiBkZWh5ZHJhdGVkIHNlcnZlciBkYXRhIGlzIGFscmVhZHkgcGFzdCB0aGUgbG9hZGVyXG4gICAgICAgICAgLy8gcGhhc2Ug4oCUIHRoZSBndWFyZCBhYm92ZSB2ZXJpZmllZCBhIHNldHRsZWQgc3VjY2VzcyAob3IgdHJhbnNwb3J0ZWRcbiAgICAgICAgICAvLyBsb2FkZXJEYXRhKSwgc28gdGhpcyBjbG9uZSBpcyBzZXR0bGVkIHdpdGhvdXQgYSBjbGllbnQgc2V0dGxlSW50by5cbiAgICAgICAgICB7XG4gICAgICAgICAgICAuLi5tYXRjaCxcbiAgICAgICAgICAgIHN0YXR1czogJ3N1Y2Nlc3MnLFxuICAgICAgICAgICAgZXJyb3I6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgIHByZWxvYWQ6IHRydWUsXG4gICAgICAgICAgfSBhcyBTZXR0bGVkTWF0Y2gsXG4gICAgICAgICAgcm91dGVyLl9jYWNoZS5nZXQobWF0Y2guaWQpLFxuICAgICAgICApXG4gICAgICB9XG4gICAgfVxuICAgIHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCByZW1vdmVkKVxuICB9XG5cbiAgLy8gQSBsb25nZXIgc2VydmVyIGxhbmUgaXMgdmFsaWQgb25seSB3aGVuIHRoZSBsb2NhbCBtYXRjaCBhbHJlYWR5IGNhcHMgdGhlXG4gIC8vIGJyYW5jaCBhdCBhIGdsb2JhbCBub3QtZm91bmQgYm91bmRhcnkuIE90aGVyd2lzZSBubyB0cmFuc3BvcnRlZCB3b3JrIGlzXG4gIC8vIHNhZmUgdG8gYXR0YWNoIHRvIHRoZSBzaG9ydGVyIGNsaWVudCBsYW5lLlxuICBjb25zdCBzaGFyZWQgPVxuICAgIGRlaHlkcmF0ZWRNYXRjaGVzLmxlbmd0aCA+IGNhbmRpZGF0ZXMubGVuZ3RoXG4gICAgICA/IGNhbmRpZGF0ZXMuZmluZEluZGV4KChtYXRjaCkgPT4gbWF0Y2guX25vdEZvdW5kKSArIDFcbiAgICAgIDogZGVoeWRyYXRlZE1hdGNoZXMubGVuZ3RoXG4gIGxldCBpc1Rlcm1pbmFsID0gZmFsc2VcbiAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IHNoYXJlZDsgaW5kZXgrKykge1xuICAgIGNvbnN0IGNhbmRpZGF0ZSA9IGNhbmRpZGF0ZXNbaW5kZXhdIVxuICAgIGNvbnN0IGRlaHlkcmF0ZWQgPSBkZWh5ZHJhdGVkTWF0Y2hlc1tpbmRleF0hXG4gICAgaWYgKFxuICAgICAgdHlwZW9mIGRlaHlkcmF0ZWQuaSAhPT0gJ3N0cmluZycgfHxcbiAgICAgIGh5ZHJhdGVTc3JNYXRjaElkKGRlaHlkcmF0ZWQuaSkgIT09IGNhbmRpZGF0ZS5pZFxuICAgICkge1xuICAgICAgcGVuZGluZ0JvdW5kYXJ5ID8/PSBpbmRleFxuICAgICAgYnJlYWtcbiAgICB9XG4gICAgdmVyaWZpZWRBc3NldEVuZCA9IGluZGV4ICsgMVxuICAgIGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBjYW5kaWRhdGUpXG4gICAgaWYgKFxuICAgICAgJ2wnIGluIGRlaHlkcmF0ZWQgfHxcbiAgICAgIChkZWh5ZHJhdGVkLnMgPT09ICdzdWNjZXNzJyAmJlxuICAgICAgICBkZWh5ZHJhdGVkLmUgPT09IHVuZGVmaW5lZCAmJlxuICAgICAgICByb3V0ZS5vcHRpb25zLmxvYWRlcilcbiAgICApIHtcbiAgICAgIGNhbmRpZGF0ZS5sb2FkZXJEYXRhID0gZGVoeWRyYXRlZC5sXG4gICAgfVxuICAgIGNhbmRpZGF0ZS5zdGF0dXMgPSBkZWh5ZHJhdGVkLnNcbiAgICBjYW5kaWRhdGUuc3NyID0gZGVoeWRyYXRlZC5zc3JcbiAgICByb3V0ZS5vcHRpb25zLnNzciA9IGNhbmRpZGF0ZS5zc3JcbiAgICBjYW5kaWRhdGUudXBkYXRlZEF0ID0gZGVoeWRyYXRlZC51XG4gICAgY2FuZGlkYXRlLmVycm9yID0gZGVoeWRyYXRlZC5lXG4gICAgY2FuZGlkYXRlLl9ub3RGb3VuZCB8fD0gZGVoeWRyYXRlZC5nXG4gICAgY29uc3QgdGVybWluYWwgPVxuICAgICAgY2FuZGlkYXRlLnN0YXR1cyA9PT0gJ2Vycm9yJyB8fFxuICAgICAgY2FuZGlkYXRlLnN0YXR1cyA9PT0gJ25vdEZvdW5kJyB8fFxuICAgICAgY2FuZGlkYXRlLl9ub3RGb3VuZFxuICAgIGlmICh0ZXJtaW5hbCkge1xuICAgICAgaXNUZXJtaW5hbCA9IHRydWVcbiAgICAgIGNvbW1pdHRlZC5wdXNoKGNhbmRpZGF0ZSlcbiAgICAgIGlmIChjYW5kaWRhdGUuc3NyID09PSBmYWxzZSB8fCBjYW5kaWRhdGUuc3NyID09PSAnZGF0YS1vbmx5Jykge1xuICAgICAgICBwZW5kaW5nQm91bmRhcnkgPz89IGluZGV4XG4gICAgICB9XG4gICAgICBicmVha1xuICAgIH1cbiAgICBpZiAoY2FuZGlkYXRlLnN0YXR1cyA9PT0gJ3BlbmRpbmcnKSB7XG4gICAgICBwZW5kaW5nQm91bmRhcnkgPz89IGluZGV4XG4gICAgICBicmVha1xuICAgIH1cblxuICAgIGNvbW1pdHRlZC5wdXNoKGNhbmRpZGF0ZSlcbiAgICBpZiAoY2FuZGlkYXRlLnNzciA9PT0gJ2RhdGEtb25seScpIHtcbiAgICAgIHBlbmRpbmdCb3VuZGFyeSA/Pz0gaW5kZXhcbiAgICB9XG4gIH1cbiAgaWYgKFxuICAgICFpc1Rlcm1pbmFsICYmXG4gICAgY29tbWl0dGVkLmxlbmd0aCA9PT0gc2hhcmVkICYmXG4gICAgc2hhcmVkIDwgY2FuZGlkYXRlcy5sZW5ndGhcbiAgKSB7XG4gICAgcGVuZGluZ0JvdW5kYXJ5ID0gc2hhcmVkXG4gIH1cblxuICAvLyBIb29rcyBvYnNlcnZlIHN0cnVjdHVyYWwgbWVtYmVyc2hpcC4gRXhlY3V0aW9uIHJlbWFpbnMgbGltaXRlZCB0b1xuICAvLyBgY29tbWl0dGVkYCwgdGhlIGFjY2VwdGVkIHNlcnZlciBwcmVmaXguXG4gIGNvbnN0IGNodW5rcyA9IGNvbW1pdHRlZC5tYXAoYXN5bmMgKG1hdGNoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaClcbiAgICAgIGF3YWl0IChtYXRjaC5fbm90Rm91bmRcbiAgICAgICAgPyBQcm9taXNlLmFsbChbXG4gICAgICAgICAgICBsb2FkUm91dGVDaHVuayhyb3V0ZSksXG4gICAgICAgICAgICBsb2FkUm91dGVDaHVuayhyb3V0ZSwgJ25vdEZvdW5kQ29tcG9uZW50JyksXG4gICAgICAgICAgXSlcbiAgICAgICAgOiBsb2FkUm91dGVDaHVuayhcbiAgICAgICAgICAgIHJvdXRlLFxuICAgICAgICAgICAgbWF0Y2guc3RhdHVzID09PSAnZXJyb3InXG4gICAgICAgICAgICAgID8gJ2Vycm9yQ29tcG9uZW50J1xuICAgICAgICAgICAgICA6IG1hdGNoLnN0YXR1cyA9PT0gJ25vdEZvdW5kJ1xuICAgICAgICAgICAgICAgID8gJ25vdEZvdW5kQ29tcG9uZW50J1xuICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkLFxuICAgICAgICAgICkpXG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH0gY2F0Y2gge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuICB9KVxuICBsZXQgY2h1bmtGYWlsdXJlID0gMFxuICB0cnkge1xuICAgIHdoaWxlIChcbiAgICAgIGNodW5rRmFpbHVyZSA8IGNodW5rcy5sZW5ndGggJiZcbiAgICAgIChhd2FpdCB3YWl0Rm9yKGNodW5rc1tjaHVua0ZhaWx1cmVdISwgY29udHJvbGxlci5zaWduYWwpKVxuICAgICkge1xuICAgICAgY2h1bmtGYWlsdXJlKytcbiAgICB9XG4gIH0gY2F0Y2gge1xuICAgIHJldHVyblxuICB9XG4gIGlmICghaXNDdXJyZW50KCkpIHtcbiAgICByZXR1cm5cbiAgfVxuICBpZiAoY2h1bmtGYWlsdXJlIDwgY29tbWl0dGVkLmxlbmd0aCkge1xuICAgIHJldHJ5RnJvbShjaHVua0ZhaWx1cmUpXG4gIH1cblxuICAvLyBUaGUgZmlyc3QgcGVuZGluZyBtYXRjaCBpcyBhbHJlYWR5IHZpc2libGUsIHNvIHByZXBhcmUgaXRzIHJvdXRlIGNvbnRleHRcbiAgLy8gd2l0aG91dCBncmFudGluZyBpdHMgYmVmb3JlTG9hZCBvciBsb2FkZXIgYW55IGh5ZHJhdGlvbiBhdXRob3JpdHkuXG4gIGNvbnN0IGNvbnRleHRFbmQgPSBNYXRoLm1heChcbiAgICBwZW5kaW5nQm91bmRhcnkgPT09IGNvbW1pdHRlZC5sZW5ndGhcbiAgICAgID8gY29tbWl0dGVkLmxlbmd0aCArIDFcbiAgICAgIDogY29tbWl0dGVkLmxlbmd0aCxcbiAgICAvLyBgY2h1bmtzLmxlbmd0aGAga2VlcHMgdGhlIHByZS1yZXRyeSBjb21taXR0ZWQgbGVuZ3RoLCBzbyBhIHNtYWxsZXJcbiAgICAvLyBgY2h1bmtGYWlsdXJlYCBpcyB0aGUgZXhjbHVzaXZlIGJvdW5kIG9mIHRoZSB2ZXJpZmllZCBjb250ZXh0IHByZWZpeC5cbiAgICBjaHVua0ZhaWx1cmUgPCBjaHVua3MubGVuZ3RoID8gY2h1bmtGYWlsdXJlIDogdmVyaWZpZWRBc3NldEVuZCxcbiAgKVxuICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgY29udGV4dEVuZDsgaW5kZXgrKykge1xuICAgIGNvbnN0IG1hdGNoID0gY2FuZGlkYXRlc1tpbmRleF0hXG4gICAgY29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKVxuICAgIGNvbnN0IHBhcmVudENvbnRleHQgPVxuICAgICAgY2FuZGlkYXRlc1tpbmRleCAtIDFdPy5jb250ZXh0ID8/IHJvdXRlci5vcHRpb25zLmNvbnRleHQgPz8ge31cbiAgICBsZXQgcm91dGVDb250ZXh0XG4gICAgaWYgKHJvdXRlLm9wdGlvbnMuY29udGV4dCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcm91dGVDb250ZXh0ID0gbWF0Y2guX2N0eCA9XG4gICAgICAgICAgcm91dGUub3B0aW9ucy5jb250ZXh0KHtcbiAgICAgICAgICAgIGRlcHM6IG1hdGNoLmxvYWRlckRlcHMsXG4gICAgICAgICAgICBwYXJhbXM6IG1hdGNoLnBhcmFtcyxcbiAgICAgICAgICAgIGNvbnRleHQ6IHBhcmVudENvbnRleHQsXG4gICAgICAgICAgICBsb2NhdGlvbixcbiAgICAgICAgICAgIG5hdmlnYXRlOiAob3B0czogYW55KSA9PlxuICAgICAgICAgICAgICByb3V0ZXIubmF2aWdhdGUoe1xuICAgICAgICAgICAgICAgIC4uLm9wdHMsXG4gICAgICAgICAgICAgICAgX2Zyb21Mb2NhdGlvbjogbG9jYXRpb24sXG4gICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgYnVpbGRMb2NhdGlvbjogcm91dGVyLmJ1aWxkTG9jYXRpb24sXG4gICAgICAgICAgICBjYXVzZTogbWF0Y2guY2F1c2UsXG4gICAgICAgICAgICBhYm9ydENvbnRyb2xsZXI6IGNvbnRyb2xsZXIsXG4gICAgICAgICAgICBwcmVsb2FkOiBmYWxzZSxcbiAgICAgICAgICAgIG1hdGNoZXM6IGNhbmRpZGF0ZXMsXG4gICAgICAgICAgICByb3V0ZUlkOiByb3V0ZS5pZCxcbiAgICAgICAgICB9KSB8fCB7fVxuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIGlmICghaXNDdXJyZW50KCkpIHtcbiAgICAgICAgICByZXR1cm5cbiAgICAgICAgfVxuICAgICAgICBpZiAoXG4gICAgICAgICAgbWF0Y2guc3RhdHVzICE9PSAnZXJyb3InICYmXG4gICAgICAgICAgbWF0Y2guc3RhdHVzICE9PSAnbm90Rm91bmQnICYmXG4gICAgICAgICAgIW1hdGNoLl9ub3RGb3VuZFxuICAgICAgICApIHtcbiAgICAgICAgICAvLyBOZXZlciBwcmVzZW50IHRyYW5zcG9ydGVkIHN1Y2Nlc3Mgd2l0aG91dCByZWNvbnN0cnVjdGVkIGNvbnRleHQuXG4gICAgICAgICAgcGVuZGluZ0JvdW5kYXJ5ID0gTWF0aC5taW4ocGVuZGluZ0JvdW5kYXJ5ID8/IGluZGV4LCBpbmRleClcbiAgICAgICAgICByZXRyeUZyb20oaW5kZXgpXG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKCFpc0N1cnJlbnQoKSkge1xuICAgICAgICByZXR1cm5cbiAgICAgIH1cbiAgICB9XG4gICAgbWF0Y2guY29udGV4dCA9IHtcbiAgICAgIC4uLnBhcmVudENvbnRleHQsXG4gICAgICAuLi5yb3V0ZUNvbnRleHQsXG4gICAgICAuLi4oY29tbWl0dGVkW2luZGV4XSAmJiBkZWh5ZHJhdGVkTWF0Y2hlc1tpbmRleF0hLmIpLFxuICAgIH1cbiAgfVxuXG4gIGF3YWl0IHByb2plY3RMYW5lKFxuICAgIHJvdXRlcixcbiAgICBbbG9jYXRpb24sIGNhbmRpZGF0ZXNdIGFzIGFueSxcbiAgICBjb250cm9sbGVyLnNpZ25hbCxcbiAgICAwLFxuICAgIHZlcmlmaWVkQXNzZXRFbmQsXG4gIClcbiAgaWYgKCFpc0N1cnJlbnQoKSkge1xuICAgIHJldHVyblxuICB9XG4gIGNvbnN0IG5lZWRzQ2xpZW50TG9hZCA9XG4gICAgcGVuZGluZ0JvdW5kYXJ5ICE9PSB1bmRlZmluZWQgfHwgY29tbWl0dGVkLmxlbmd0aCA8IHNoYXJlZFxuICBjb25zdCBjb21taXR0ZWRNYXRjaGVzID1cbiAgICBpc1Rlcm1pbmFsICYmIGNvbW1pdHRlZC5sZW5ndGggPT09IHNoYXJlZCA/IGNhbmRpZGF0ZXMgOiBjb21taXR0ZWRcbiAgbGV0IHByZXNlbnRlZCA9IG5lZWRzQ2xpZW50TG9hZCA/IGNhbmRpZGF0ZXMgOiBjb21taXR0ZWRNYXRjaGVzXG4gIGxldCBkYXRhT25seUFzc2V0RW5kOiBudW1iZXIgfCB1bmRlZmluZWRcbiAgaWYgKG5lZWRzQ2xpZW50TG9hZCAmJiBwZW5kaW5nQm91bmRhcnkgIT09IHVuZGVmaW5lZCkge1xuICAgIGNvbnN0IGJvdW5kYXJ5ID0gcHJlc2VudGVkW3BlbmRpbmdCb3VuZGFyeV0hXG4gICAgLy8gQSB2ZXJpZmllZCBkZXNjZW5kYW50IHByb3ZlcyB0aGlzIGRhdGEtb25seSBib3VuZGFyeSB3YXMgbm9udGVybWluYWwuXG4gICAgZGF0YU9ubHlBc3NldEVuZCA9XG4gICAgICBib3VuZGFyeS5zc3IgPT09ICdkYXRhLW9ubHknICYmIHZlcmlmaWVkQXNzZXRFbmQgPiBwZW5kaW5nQm91bmRhcnkgKyAxXG4gICAgICAgID8gdmVyaWZpZWRBc3NldEVuZFxuICAgICAgICA6IHVuZGVmaW5lZFxuICAgIHByZXNlbnRlZCA9IHByZXNlbnRlZC5zbGljZSgpXG4gICAgcHJlc2VudGVkW3BlbmRpbmdCb3VuZGFyeV0gPSB7XG4gICAgICAuLi5ib3VuZGFyeSxcbiAgICAgIHN0YXR1czogJ3BlbmRpbmcnLFxuICAgICAgc3NyOiBib3VuZGFyeS5zc3IgPT09ICdkYXRhLW9ubHknID8gJ2RhdGEtb25seScgOiBmYWxzZSxcbiAgICAgIF9hc3NldEVuZDogZGF0YU9ubHlBc3NldEVuZCxcbiAgICB9XG4gIH1cblxuICBjb25zdCBjbGFpbSA9ICgpID0+IHtcbiAgICBjb25zdCBoaXN0b3J5TG9jYXRpb24gPSByb3V0ZXIuaGlzdG9yeS5sb2NhdGlvblxuICAgIHJldHVybiBuZWVkc0NsaWVudExvYWQgJiZcbiAgICAgICFyb3V0ZXIuX3R4ICYmXG4gICAgICBoaXN0b3J5TG9jYXRpb24uaHJlZiA9PT0gaGFuZG9mZkhpc3RvcnlIcmVmICYmXG4gICAgICBoaXN0b3J5TG9jYXRpb24uc3RhdGUgPT09IGhhbmRvZmZIaXN0b3J5U3RhdGUgJiZcbiAgICAgIHJvdXRlci5fY29tbWl0dGVkID09PSBjb21taXR0ZWRNYXRjaGVzICYmXG4gICAgICBjb21taXR0ZWRNYXRjaGVzLmxlbmd0aCAmJlxuICAgICAgIWNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWRcbiAgICAgID8gY29udHJvbGxlclxuICAgICAgOiB1bmRlZmluZWRcbiAgfVxuICBjb25zdCBoYW5kb2ZmOiBOb25OdWxsYWJsZTxBbnlSb3V0ZXJbJ19oYW5kb2ZmJ10+ID0gW1xuICAgIGNsYWltLFxuICAgIChtYXRjaGVzKSA9PiB7XG4gICAgICBpZiAocm91dGVyLl9oYW5kb2ZmICE9PSBoYW5kb2ZmKSB7XG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgLy8gYGZpbmlzaGAgaXMgc2luZ2xlLXVzZS4gQ29uc3VtZSB0aGUgc2xvdCBiZWZvcmUgdmFsaWRhdGluZyBvciBtb3ZpbmdcbiAgICAgIC8vIHJlc291cmNlcyBzbyByZWVudHJhbnQgd29yayBjYW5ub3QgY2xhaW0gdGhlIHNhbWUgaGFuZG9mZi5cbiAgICAgIHJvdXRlci5faGFuZG9mZiA9IHVuZGVmaW5lZFxuICAgICAgY29uc3QgcHJlZml4ID0gY29tbWl0dGVkTWF0Y2hlcy5sZW5ndGhcbiAgICAgIGlmIChcbiAgICAgICAgIW1hdGNoZXMgfHxcbiAgICAgICAgIWNsYWltKCkgfHxcbiAgICAgICAgY29tbWl0dGVkTWF0Y2hlcy5zb21lKChtYXRjaCwgaW5kZXgpID0+IG1hdGNoLmlkICE9PSBtYXRjaGVzW2luZGV4XT8uaWQpXG4gICAgICApIHtcbiAgICAgICAgY29udHJvbGxlci5hYm9ydCgpXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgbGV0IGhhbmRvZmZBc3NldEVuZCA9IGRhdGFPbmx5QXNzZXRFbmRcbiAgICAgIGlmIChoYW5kb2ZmQXNzZXRFbmQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBmb3IgKGxldCBpbmRleCA9IHByZWZpeDsgaW5kZXggPCBoYW5kb2ZmQXNzZXRFbmQ7IGluZGV4KyspIHtcbiAgICAgICAgICBpZiAoY2FuZGlkYXRlc1tpbmRleF0/LmlkICE9PSBtYXRjaGVzW2luZGV4XT8uaWQpIHtcbiAgICAgICAgICAgIGhhbmRvZmZBc3NldEVuZCA9IGluZGV4ID4gcGVuZGluZ0JvdW5kYXJ5ISArIDEgPyBpbmRleCA6IHVuZGVmaW5lZFxuICAgICAgICAgICAgYnJlYWtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGNvbnN0IGNsb25lcyA9IGNvbW1pdHRlZE1hdGNoZXMubWFwKChtYXRjaCkgPT4gKHsgLi4ubWF0Y2ggfSkpXG4gICAgICBpZiAoaGFuZG9mZkFzc2V0RW5kICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgY2xvbmVzW3BlbmRpbmdCb3VuZGFyeSFdIS5fYXNzZXRFbmQgPSBoYW5kb2ZmQXNzZXRFbmRcbiAgICAgIH1cbiAgICAgIHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBtYXRjaGVzLnNwbGljZSgwLCBwcmVmaXgsIC4uLmNsb25lcykpXG4gICAgICBmb3IgKGxldCBpbmRleCA9IHByZWZpeDsgaW5kZXggPCBtYXRjaGVzLmxlbmd0aDsgaW5kZXgrKykge1xuICAgICAgICBjb25zdCBtYXRjaCA9IG1hdGNoZXNbaW5kZXhdIVxuICAgICAgICBjb25zdCBoeWRyYXRlZCA9IGNhbmRpZGF0ZXNbaW5kZXhdXG4gICAgICAgIGlmIChoeWRyYXRlZD8uaWQgPT09IG1hdGNoLmlkICYmIGh5ZHJhdGVkLl9jdHgpIHtcbiAgICAgICAgICBtYXRjaC5fY3R4ID0gaHlkcmF0ZWQuX2N0eFxuICAgICAgICB9XG4gICAgICAgIG1hdGNoLmFib3J0Q29udHJvbGxlciA9IGNvbnRyb2xsZXJcbiAgICAgIH1cbiAgICAgIHJldHVybiBwcmVmaXhcbiAgICB9LFxuICBdXG4gIHJvdXRlci5fY29tbWl0dGVkID0gY29tbWl0dGVkTWF0Y2hlc1xuICByb3V0ZXIuX2xpZmVjeWNsZUVuZCA9IGxpZmVjeWNsZUVuZChjb21taXR0ZWRNYXRjaGVzKVxuICByb3V0ZXIuX2hhbmRvZmYgPSBoYW5kb2ZmXG4gIHJvdXRlci5fcHJlZmxpZ2h0ID0gdW5kZWZpbmVkXG4gIHJvdXRlci5iYXRjaCgoKSA9PiB7XG4gICAgcm91dGVyLnN0b3Jlcy5zZXRNYXRjaGVzKHByZXNlbnRlZClcbiAgICByb3V0ZXIuc3RvcmVzLnN0YXR1cy5zZXQoJ2lkbGUnKVxuICAgIGlmICghbmVlZHNDbGllbnRMb2FkKSB7XG4gICAgICByb3V0ZXIuc3RvcmVzLnJlc29sdmVkTG9jYXRpb24uc2V0KHJvdXRlci5zdG9yZXMubG9jYXRpb24uZ2V0KCkpXG4gICAgfVxuICB9KVxufVxuIl0sImZpbGUiOiIvYXBwL2FwcGxldC9ub2RlX21vZHVsZXMvQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL2xvYWQtY2xpZW50LmpzIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==