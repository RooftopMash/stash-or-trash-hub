"use client";
import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=a8030269";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=a8030269";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/react_jsx-runtime.js?v=a8030269";
import { t as createContextScope } from "/node_modules/.vite/deps/dist-Dic5YkbB.js?v=a8030269";
import { t as useCallbackRef } from "/node_modules/.vite/deps/dist-BEvKR6kC.js?v=a8030269";
import { o as useComposedRefs, r as createSlot } from "/node_modules/.vite/deps/dist-DIAF6ZLP.js?v=a8030269";
import { n as dispatchDiscreteCustomEvent, t as Primitive } from "/node_modules/.vite/deps/dist-uZEDRbDH.js?v=a8030269";
import { n as composeEventHandlers, t as useControllableState } from "/node_modules/.vite/deps/dist-Cy5nHrbn.js?v=a8030269";
import { t as Presence } from "/node_modules/.vite/deps/dist-DkJtUS0F.js?v=a8030269";
import { t as useId } from "/node_modules/.vite/deps/dist-CjPmzKtU.js?v=a8030269";
import { a as FocusScope, i as Portal$1, n as ReactRemoveScroll, o as DismissableLayer, r as useFocusGuards, t as hideOthers } from "/node_modules/.vite/deps/es2015-DLWYICUt.js?v=a8030269";
import { n as createCollection, t as useDirection } from "/node_modules/.vite/deps/dist-Dpa8aRCU.js?v=a8030269";
import { a as createPopperScope, i as Root2$1, n as Arrow, r as Content, t as Anchor } from "/node_modules/.vite/deps/dist-QClXUsTr.js?v=a8030269";
import { n as Root, r as createRovingFocusGroupScope, t as Item } from "/node_modules/.vite/deps/dist-Dqs1XppL.js?v=a8030269";
//#region node_modules/@radix-ui/react-menu/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var __defProp$1 = Object.defineProperty;
var __name$1 = (target, value) => __defProp$1(target, "name", {
	value,
	configurable: true
});
var SELECTION_KEYS = ["Enter", " "];
var FIRST_KEYS = [
	"ArrowDown",
	"PageUp",
	"Home"
];
var LAST_KEYS = [
	"ArrowUp",
	"PageDown",
	"End"
];
var FIRST_LAST_KEYS = [...FIRST_KEYS, ...LAST_KEYS];
var SUB_OPEN_KEYS = {
	ltr: [...SELECTION_KEYS, "ArrowRight"],
	rtl: [...SELECTION_KEYS, "ArrowLeft"]
};
var SUB_CLOSE_KEYS = {
	ltr: ["ArrowLeft"],
	rtl: ["ArrowRight"]
};
var MENU_NAME = "Menu";
var [Collection, useCollection, createCollectionScope] = createCollection(MENU_NAME);
var [createMenuContext, createMenuScope] = createContextScope(MENU_NAME, [
	createCollectionScope,
	createPopperScope,
	createRovingFocusGroupScope
]);
var usePopperScope = createPopperScope();
var useRovingFocusGroupScope = createRovingFocusGroupScope();
var [MenuProvider, useMenuContext] = createMenuContext(MENU_NAME);
var [MenuRootProvider, useMenuRootContext] = createMenuContext(MENU_NAME);
var Menu = /* @__PURE__ */ __name$1((props) => {
	const { __scopeMenu, open = false, children, dir, onOpenChange, modal = true } = props;
	const popperScope = usePopperScope(__scopeMenu);
	const [content, setContent] = import_react.useState(null);
	const isUsingKeyboardRef = import_react.useRef(false);
	const handleOpenChange = useCallbackRef(onOpenChange);
	const direction = useDirection(dir);
	import_react.useEffect(() => {
		const handleKeyDown = /* @__PURE__ */ __name$1(() => {
			isUsingKeyboardRef.current = true;
			document.addEventListener("pointerdown", handlePointer, {
				capture: true,
				once: true
			});
			document.addEventListener("pointermove", handlePointer, {
				capture: true,
				once: true
			});
		}, "handleKeyDown");
		const handlePointer = /* @__PURE__ */ __name$1(() => isUsingKeyboardRef.current = false, "handlePointer");
		document.addEventListener("keydown", handleKeyDown, { capture: true });
		return () => {
			document.removeEventListener("keydown", handleKeyDown, { capture: true });
			document.removeEventListener("pointerdown", handlePointer, { capture: true });
			document.removeEventListener("pointermove", handlePointer, { capture: true });
		};
	}, []);
	import_react.useEffect(() => {
		if (!open) return;
		const handleBlur = /* @__PURE__ */ __name$1(() => handleOpenChange(false), "handleBlur");
		window.addEventListener("blur", handleBlur);
		return () => window.removeEventListener("blur", handleBlur);
	}, [open, handleOpenChange]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root2$1, {
		...popperScope,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuProvider, {
			scope: __scopeMenu,
			open,
			onOpenChange: handleOpenChange,
			content,
			onContentChange: setContent,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRootProvider, {
				scope: __scopeMenu,
				onClose: import_react.useCallback(() => handleOpenChange(false), [handleOpenChange]),
				isUsingKeyboardRef,
				dir: direction,
				modal,
				children
			})
		})
	});
}, "Menu");
var MenuAnchor = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuAnchor2(props, forwardedRef) {
	const { __scopeMenu, ...anchorProps } = props;
	const popperScope = usePopperScope(__scopeMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Anchor, {
		...popperScope,
		...anchorProps,
		ref: forwardedRef
	});
}, "MenuAnchor"));
var PORTAL_NAME = "MenuPortal";
var [PortalProvider, usePortalContext] = createMenuContext(PORTAL_NAME, { forceMount: void 0 });
var MenuPortal = /* @__PURE__ */ __name$1((props) => {
	const { __scopeMenu, forceMount, children, container } = props;
	const context = useMenuContext(PORTAL_NAME, __scopeMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalProvider, {
		scope: __scopeMenu,
		forceMount,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presence, {
			present: forceMount || context.open,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal$1, {
				asChild: true,
				container,
				children
			})
		})
	});
}, "MenuPortal");
var CONTENT_NAME$1 = "MenuContent";
var [MenuContentProvider, useMenuContentContext] = createMenuContext(CONTENT_NAME$1);
var MenuContent = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuContent2(props, forwardedRef) {
	const portalContext = usePortalContext(CONTENT_NAME$1, props.__scopeMenu);
	const { forceMount = portalContext.forceMount, ...contentProps } = props;
	const context = useMenuContext(CONTENT_NAME$1, props.__scopeMenu);
	const rootContext = useMenuRootContext(CONTENT_NAME$1, props.__scopeMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.Provider, {
		scope: props.__scopeMenu,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presence, {
			present: forceMount || context.open,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.Slot, {
				scope: props.__scopeMenu,
				children: rootContext.modal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRootContentModal, {
					...contentProps,
					ref: forwardedRef
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRootContentNonModal, {
					...contentProps,
					ref: forwardedRef
				})
			})
		})
	});
}, "MenuContent"));
var MenuRootContentModal = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuRootContentModal2(props, forwardedRef) {
	const context = useMenuContext(CONTENT_NAME$1, props.__scopeMenu);
	const ref = import_react.useRef(null);
	const composedRefs = useComposedRefs(forwardedRef, ref);
	import_react.useEffect(() => {
		const content = ref.current;
		if (content) return hideOthers(content);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuContentImpl, {
		...props,
		ref: composedRefs,
		trapFocus: context.open,
		disableOutsidePointerEvents: context.open,
		disableOutsideScroll: true,
		onFocusOutside: composeEventHandlers(props.onFocusOutside, (event) => event.preventDefault(), { checkForDefaultPrevented: false }),
		onDismiss: () => context.onOpenChange(false)
	});
}, "MenuRootContentModal"));
var MenuRootContentNonModal = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuRootContentNonModal2(props, forwardedRef) {
	const context = useMenuContext(CONTENT_NAME$1, props.__scopeMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuContentImpl, {
		...props,
		ref: forwardedRef,
		trapFocus: false,
		disableOutsidePointerEvents: false,
		disableOutsideScroll: false,
		onDismiss: () => context.onOpenChange(false)
	});
}, "MenuRootContentNonModal"));
var Slot = createSlot("MenuContent.ScrollLock");
var MenuContentImpl = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuContentImpl2(props, forwardedRef) {
	const { __scopeMenu, loop = false, trapFocus, onOpenAutoFocus, onCloseAutoFocus, disableOutsidePointerEvents, onEntryFocus, onEscapeKeyDown, onPointerDownOutside, onFocusOutside, onInteractOutside, onDismiss, disableOutsideScroll, ...contentProps } = props;
	const context = useMenuContext(CONTENT_NAME$1, __scopeMenu);
	const rootContext = useMenuRootContext(CONTENT_NAME$1, __scopeMenu);
	const popperScope = usePopperScope(__scopeMenu);
	const rovingFocusGroupScope = useRovingFocusGroupScope(__scopeMenu);
	const getItems = useCollection(__scopeMenu);
	const [currentItemId, setCurrentItemId] = import_react.useState(null);
	const contentRef = import_react.useRef(null);
	const composedRefs = useComposedRefs(forwardedRef, contentRef, context.onContentChange);
	const timerRef = import_react.useRef(0);
	const searchRef = import_react.useRef("");
	const pointerGraceTimerRef = import_react.useRef(0);
	const pointerGraceIntentRef = import_react.useRef(null);
	const pointerDirRef = import_react.useRef("right");
	const lastPointerXRef = import_react.useRef(0);
	const ScrollLockWrapper = disableOutsideScroll ? ReactRemoveScroll : import_react.Fragment;
	const scrollLockWrapperProps = disableOutsideScroll ? {
		as: Slot,
		allowPinchZoom: true
	} : void 0;
	const handleTypeaheadSearch = /* @__PURE__ */ __name$1((key) => {
		const search = searchRef.current + key;
		const items = getItems().filter((item) => !item.disabled);
		const currentItem = document.activeElement;
		const currentMatch = items.find((item) => item.ref.current === currentItem)?.textValue;
		const nextMatch = getNextMatch(items.map((item) => item.textValue), search, currentMatch);
		const newItem = items.find((item) => item.textValue === nextMatch)?.ref.current;
		(/* @__PURE__ */ __name$1((function updateSearch(value) {
			searchRef.current = value;
			window.clearTimeout(timerRef.current);
			if (value !== "") timerRef.current = window.setTimeout(() => updateSearch(""), 1e3);
		}), "updateSearch"))(search);
		if (newItem) setTimeout(() => newItem.focus());
	}, "handleTypeaheadSearch");
	import_react.useEffect(() => {
		return () => window.clearTimeout(timerRef.current);
	}, []);
	useFocusGuards();
	const isPointerMovingToSubmenu = import_react.useCallback((event) => {
		return pointerDirRef.current === pointerGraceIntentRef.current?.side && isPointerInGraceArea(event, pointerGraceIntentRef.current?.area);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuContentProvider, {
		scope: __scopeMenu,
		searchRef,
		onItemEnter: import_react.useCallback((event) => {
			if (isPointerMovingToSubmenu(event)) event.preventDefault();
		}, [isPointerMovingToSubmenu]),
		onItemLeave: import_react.useCallback((event) => {
			if (isPointerMovingToSubmenu(event)) return;
			contentRef.current?.focus();
			setCurrentItemId(null);
		}, [isPointerMovingToSubmenu]),
		onTriggerLeave: import_react.useCallback((event) => {
			if (isPointerMovingToSubmenu(event)) event.preventDefault();
		}, [isPointerMovingToSubmenu]),
		pointerGraceTimerRef,
		onPointerGraceIntentChange: import_react.useCallback((intent) => {
			pointerGraceIntentRef.current = intent;
		}, []),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollLockWrapper, {
			...scrollLockWrapperProps,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FocusScope, {
				asChild: true,
				trapped: trapFocus,
				onMountAutoFocus: composeEventHandlers(onOpenAutoFocus, (event) => {
					event.preventDefault();
					contentRef.current?.focus({ preventScroll: true });
				}),
				onUnmountAutoFocus: onCloseAutoFocus,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DismissableLayer, {
					asChild: true,
					disableOutsidePointerEvents,
					onEscapeKeyDown,
					onPointerDownOutside,
					onFocusOutside,
					onInteractOutside,
					onDismiss,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
						asChild: true,
						...rovingFocusGroupScope,
						dir: rootContext.dir,
						orientation: "vertical",
						loop,
						currentTabStopId: currentItemId,
						onCurrentTabStopIdChange: setCurrentItemId,
						onEntryFocus: composeEventHandlers(onEntryFocus, (event) => {
							if (!rootContext.isUsingKeyboardRef.current) event.preventDefault();
						}),
						preventScrollOnEntryFocus: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
							role: "menu",
							"aria-orientation": "vertical",
							"data-state": getOpenState(context.open),
							"data-radix-menu-content": "",
							dir: rootContext.dir,
							...popperScope,
							...contentProps,
							ref: composedRefs,
							style: {
								outline: "none",
								...contentProps.style
							},
							onKeyDown: composeEventHandlers(contentProps.onKeyDown, (event) => {
								const isKeyDownInside = event.target.closest("[data-radix-menu-content]") === event.currentTarget;
								const isModifierKey = event.ctrlKey || event.altKey || event.metaKey;
								const isCharacterKey = event.key.length === 1;
								if (isKeyDownInside) {
									if (event.key === "Tab") event.preventDefault();
									if (!isModifierKey && isCharacterKey) handleTypeaheadSearch(event.key);
								}
								const content = contentRef.current;
								if (event.target !== content) return;
								if (!FIRST_LAST_KEYS.includes(event.key)) return;
								event.preventDefault();
								const candidateNodes = getItems().filter((item) => !item.disabled).map((item) => item.ref.current);
								if (LAST_KEYS.includes(event.key)) candidateNodes.reverse();
								focusFirst(candidateNodes);
							}),
							onBlur: composeEventHandlers(props.onBlur, (event) => {
								if (!event.currentTarget.contains(event.target)) {
									window.clearTimeout(timerRef.current);
									searchRef.current = "";
								}
							}),
							onPointerMove: composeEventHandlers(props.onPointerMove, whenMouse((event) => {
								const target = event.target;
								const pointerXHasChanged = lastPointerXRef.current !== event.clientX;
								if (event.currentTarget.contains(target) && pointerXHasChanged) {
									const newDir = event.clientX > lastPointerXRef.current ? "right" : "left";
									pointerDirRef.current = newDir;
									lastPointerXRef.current = event.clientX;
								}
							}))
						})
					})
				})
			})
		})
	});
}, "MenuContentImpl"));
var MenuGroup = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuGroup2(props, forwardedRef) {
	const { __scopeMenu, ...groupProps } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		role: "group",
		...groupProps,
		ref: forwardedRef
	});
}, "MenuGroup"));
var MenuLabel = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuLabel2(props, forwardedRef) {
	const { __scopeMenu, ...labelProps } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		...labelProps,
		ref: forwardedRef
	});
}, "MenuLabel"));
var ITEM_NAME = "MenuItem";
var ITEM_SELECT = "menu.itemSelect";
var MenuItem = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuItem2(props, forwardedRef) {
	const { disabled = false, onSelect, ...itemProps } = props;
	const ref = import_react.useRef(null);
	const rootContext = useMenuRootContext(ITEM_NAME, props.__scopeMenu);
	const contentContext = useMenuContentContext(ITEM_NAME, props.__scopeMenu);
	const composedRefs = useComposedRefs(forwardedRef, ref);
	const isPointerDownRef = import_react.useRef(false);
	const handleSelect = /* @__PURE__ */ __name$1(() => {
		const menuItem = ref.current;
		if (!disabled && menuItem) {
			const itemSelectEvent = new CustomEvent(ITEM_SELECT, {
				bubbles: true,
				cancelable: true
			});
			menuItem.addEventListener(ITEM_SELECT, (event) => onSelect?.(event), { once: true });
			dispatchDiscreteCustomEvent(menuItem, itemSelectEvent);
			if (itemSelectEvent.defaultPrevented) isPointerDownRef.current = false;
			else rootContext.onClose();
		}
	}, "handleSelect");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItemImpl, {
		...itemProps,
		ref: composedRefs,
		disabled,
		onClick: composeEventHandlers(props.onClick, handleSelect),
		onPointerDown: (event) => {
			props.onPointerDown?.(event);
			isPointerDownRef.current = true;
		},
		onPointerUp: composeEventHandlers(props.onPointerUp, (event) => {
			if (!isPointerDownRef.current) event.currentTarget?.click();
		}),
		onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
			if (disabled || event.target !== event.currentTarget) return;
			if (contentContext.searchRef.current !== "" && event.key === " ") return;
			if (SELECTION_KEYS.includes(event.key)) {
				event.currentTarget.click();
				event.preventDefault();
			}
		})
	});
}, "MenuItem"));
var MenuItemImpl = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuItemImpl2(props, forwardedRef) {
	const { __scopeMenu, disabled = false, textValue, ...itemProps } = props;
	const contentContext = useMenuContentContext(ITEM_NAME, __scopeMenu);
	const rovingFocusGroupScope = useRovingFocusGroupScope(__scopeMenu);
	const ref = import_react.useRef(null);
	const composedRefs = useComposedRefs(forwardedRef, ref);
	const [isFocused, setIsFocused] = import_react.useState(false);
	const [textContent, setTextContent] = import_react.useState("");
	import_react.useEffect(() => {
		const menuItem = ref.current;
		if (menuItem) setTextContent((menuItem.textContent ?? "").trim());
	}, [itemProps.children]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.ItemSlot, {
		scope: __scopeMenu,
		disabled,
		textValue: textValue ?? textContent,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
			asChild: true,
			...rovingFocusGroupScope,
			focusable: !disabled,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
				role: "menuitem",
				"data-highlighted": isFocused ? "" : void 0,
				"aria-disabled": disabled || void 0,
				"data-disabled": disabled ? "" : void 0,
				...itemProps,
				ref: composedRefs,
				onPointerMove: composeEventHandlers(props.onPointerMove, whenMouse((event) => {
					if (disabled) contentContext.onItemLeave(event);
					else {
						contentContext.onItemEnter(event);
						if (!event.defaultPrevented) event.currentTarget.focus({ preventScroll: true });
					}
				})),
				onPointerLeave: composeEventHandlers(props.onPointerLeave, whenMouse((event) => contentContext.onItemLeave(event))),
				onFocus: composeEventHandlers(props.onFocus, () => setIsFocused(true)),
				onBlur: composeEventHandlers(props.onBlur, () => setIsFocused(false))
			})
		})
	});
}, "MenuItemImpl"));
var MenuCheckboxItem = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuCheckboxItem2(props, forwardedRef) {
	const { checked = false, onCheckedChange, ...checkboxItemProps } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicatorProvider, {
		scope: props.__scopeMenu,
		checked,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
			role: "menuitemcheckbox",
			"aria-checked": isIndeterminate(checked) ? "mixed" : checked,
			...checkboxItemProps,
			ref: forwardedRef,
			"data-state": getCheckedState(checked),
			onSelect: composeEventHandlers(checkboxItemProps.onSelect, () => onCheckedChange?.(isIndeterminate(checked) ? true : !checked), { checkForDefaultPrevented: false })
		})
	});
}, "MenuCheckboxItem"));
var [RadioGroupProvider, useRadioGroupContext] = createMenuContext("MenuRadioGroup", {
	value: void 0,
	onValueChange: /* @__PURE__ */ __name$1(() => {}, "onValueChange")
});
var MenuRadioGroup = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuRadioGroup2(props, forwardedRef) {
	const { value, onValueChange, ...groupProps } = props;
	const handleValueChange = useCallbackRef(onValueChange);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupProvider, {
		scope: props.__scopeMenu,
		value,
		onValueChange: handleValueChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuGroup, {
			...groupProps,
			ref: forwardedRef
		})
	});
}, "MenuRadioGroup"));
var RADIO_ITEM_NAME = "MenuRadioItem";
var MenuRadioItem = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuRadioItem2(props, forwardedRef) {
	const { value, ...radioItemProps } = props;
	const context = useRadioGroupContext(RADIO_ITEM_NAME, props.__scopeMenu);
	const checked = value === context.value;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicatorProvider, {
		scope: props.__scopeMenu,
		checked,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
			role: "menuitemradio",
			"aria-checked": checked,
			...radioItemProps,
			ref: forwardedRef,
			"data-state": getCheckedState(checked),
			onSelect: composeEventHandlers(radioItemProps.onSelect, () => context.onValueChange?.(value), { checkForDefaultPrevented: false })
		})
	});
}, "MenuRadioItem"));
var ITEM_INDICATOR_NAME = "MenuItemIndicator";
var [ItemIndicatorProvider, useItemIndicatorContext] = createMenuContext(ITEM_INDICATOR_NAME, { checked: false });
var MenuItemIndicator = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuItemIndicator2(props, forwardedRef) {
	const { __scopeMenu, forceMount, ...itemIndicatorProps } = props;
	const indicatorContext = useItemIndicatorContext(ITEM_INDICATOR_NAME, __scopeMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presence, {
		present: forceMount || isIndeterminate(indicatorContext.checked) || indicatorContext.checked === true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.span, {
			...itemIndicatorProps,
			ref: forwardedRef,
			"data-state": getCheckedState(indicatorContext.checked)
		})
	});
}, "MenuItemIndicator"));
var MenuSeparator = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuSeparator2(props, forwardedRef) {
	const { __scopeMenu, ...separatorProps } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		role: "separator",
		"aria-orientation": "horizontal",
		...separatorProps,
		ref: forwardedRef
	});
}, "MenuSeparator"));
var MenuArrow = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuArrow2(props, forwardedRef) {
	const { __scopeMenu, ...arrowProps } = props;
	const popperScope = usePopperScope(__scopeMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arrow, {
		...popperScope,
		...arrowProps,
		ref: forwardedRef
	});
}, "MenuArrow"));
var SUB_NAME = "MenuSub";
var [MenuSubProvider, useMenuSubContext] = createMenuContext(SUB_NAME);
var MenuSub = /* @__PURE__ */ __name$1((props) => {
	const { __scopeMenu, children, open = false, onOpenChange } = props;
	const parentMenuContext = useMenuContext(SUB_NAME, __scopeMenu);
	const popperScope = usePopperScope(__scopeMenu);
	const [trigger, setTrigger] = import_react.useState(null);
	const [content, setContent] = import_react.useState(null);
	const handleOpenChange = useCallbackRef(onOpenChange);
	import_react.useEffect(() => {
		if (parentMenuContext.open === false) handleOpenChange(false);
		return () => handleOpenChange(false);
	}, [parentMenuContext.open, handleOpenChange]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root2$1, {
		...popperScope,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuProvider, {
			scope: __scopeMenu,
			open,
			onOpenChange: handleOpenChange,
			content,
			onContentChange: setContent,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuSubProvider, {
				scope: __scopeMenu,
				contentId: useId(),
				triggerId: useId(),
				trigger,
				onTriggerChange: setTrigger,
				children
			})
		})
	});
}, "MenuSub");
var SUB_TRIGGER_NAME = "MenuSubTrigger";
var MenuSubTrigger = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuSubTrigger2(props, forwardedRef) {
	const context = useMenuContext(SUB_TRIGGER_NAME, props.__scopeMenu);
	const rootContext = useMenuRootContext(SUB_TRIGGER_NAME, props.__scopeMenu);
	const subContext = useMenuSubContext(SUB_TRIGGER_NAME, props.__scopeMenu);
	const contentContext = useMenuContentContext(SUB_TRIGGER_NAME, props.__scopeMenu);
	const openTimerRef = import_react.useRef(null);
	const { pointerGraceTimerRef, onPointerGraceIntentChange } = contentContext;
	const scope = { __scopeMenu: props.__scopeMenu };
	const clearOpenTimer = import_react.useCallback(() => {
		if (openTimerRef.current) window.clearTimeout(openTimerRef.current);
		openTimerRef.current = null;
	}, []);
	import_react.useEffect(() => clearOpenTimer, [clearOpenTimer]);
	import_react.useEffect(() => {
		const pointerGraceTimer = pointerGraceTimerRef.current;
		return () => {
			window.clearTimeout(pointerGraceTimer);
			onPointerGraceIntentChange(null);
		};
	}, [pointerGraceTimerRef, onPointerGraceIntentChange]);
	const composedRefs = useComposedRefs(forwardedRef, subContext.onTriggerChange);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuAnchor, {
		asChild: true,
		...scope,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItemImpl, {
			id: subContext.triggerId,
			"aria-haspopup": "menu",
			"aria-expanded": context.open,
			"aria-controls": context.open ? subContext.contentId : void 0,
			"data-state": getOpenState(context.open),
			...props,
			ref: composedRefs,
			onClick: (event) => {
				props.onClick?.(event);
				if (props.disabled || event.defaultPrevented) return;
				event.currentTarget.focus();
				if (!context.open) context.onOpenChange(true);
			},
			onPointerMove: composeEventHandlers(props.onPointerMove, whenMouse((event) => {
				contentContext.onItemEnter(event);
				if (event.defaultPrevented) return;
				if (!props.disabled && !context.open && !openTimerRef.current) {
					contentContext.onPointerGraceIntentChange(null);
					openTimerRef.current = window.setTimeout(() => {
						context.onOpenChange(true);
						clearOpenTimer();
					}, 100);
				}
			})),
			onPointerLeave: composeEventHandlers(props.onPointerLeave, whenMouse((event) => {
				clearOpenTimer();
				const contentRect = context.content?.getBoundingClientRect();
				if (contentRect) {
					const side = context.content?.dataset.side;
					const rightSide = side === "right";
					const bleed = rightSide ? -5 : 5;
					const contentNearEdge = contentRect[rightSide ? "left" : "right"];
					const contentFarEdge = contentRect[rightSide ? "right" : "left"];
					contentContext.onPointerGraceIntentChange({
						area: [
							{
								x: event.clientX + bleed,
								y: event.clientY
							},
							{
								x: contentNearEdge,
								y: contentRect.top
							},
							{
								x: contentFarEdge,
								y: contentRect.top
							},
							{
								x: contentFarEdge,
								y: contentRect.bottom
							},
							{
								x: contentNearEdge,
								y: contentRect.bottom
							}
						],
						side
					});
					window.clearTimeout(pointerGraceTimerRef.current);
					pointerGraceTimerRef.current = window.setTimeout(() => contentContext.onPointerGraceIntentChange(null), 300);
				} else {
					contentContext.onTriggerLeave(event);
					if (event.defaultPrevented) return;
					contentContext.onPointerGraceIntentChange(null);
				}
			})),
			onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
				if (props.disabled || event.target !== event.currentTarget) return;
				if (contentContext.searchRef.current !== "" && event.key === " ") return;
				if (SUB_OPEN_KEYS[rootContext.dir].includes(event.key)) {
					context.onOpenChange(true);
					context.content?.focus();
					event.preventDefault();
				}
			})
		})
	});
}, "MenuSubTrigger"));
var SUB_CONTENT_NAME = "MenuSubContent";
var MenuSubContent = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function MenuSubContent2(props, forwardedRef) {
	const portalContext = usePortalContext(CONTENT_NAME$1, props.__scopeMenu);
	const { forceMount = portalContext.forceMount, align = "start", ...subContentProps } = props;
	const context = useMenuContext(CONTENT_NAME$1, props.__scopeMenu);
	const rootContext = useMenuRootContext(CONTENT_NAME$1, props.__scopeMenu);
	const subContext = useMenuSubContext(SUB_CONTENT_NAME, props.__scopeMenu);
	const ref = import_react.useRef(null);
	const composedRefs = useComposedRefs(forwardedRef, ref);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.Provider, {
		scope: props.__scopeMenu,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presence, {
			present: forceMount || context.open,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.Slot, {
				scope: props.__scopeMenu,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuContentImpl, {
					id: subContext.contentId,
					"aria-labelledby": subContext.triggerId,
					...subContentProps,
					ref: composedRefs,
					align,
					side: rootContext.dir === "rtl" ? "left" : "right",
					disableOutsidePointerEvents: false,
					disableOutsideScroll: false,
					trapFocus: false,
					onOpenAutoFocus: (event) => {
						if (rootContext.isUsingKeyboardRef.current) ref.current?.focus();
						event.preventDefault();
					},
					onCloseAutoFocus: (event) => event.preventDefault(),
					onFocusOutside: composeEventHandlers(props.onFocusOutside, (event) => {
						if (event.target !== subContext.trigger) context.onOpenChange(false);
					}),
					onEscapeKeyDown: composeEventHandlers(props.onEscapeKeyDown, (event) => {
						rootContext.onClose();
						event.preventDefault();
					}),
					onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
						const isKeyDownInside = event.currentTarget.contains(event.target);
						const isCloseKey = SUB_CLOSE_KEYS[rootContext.dir].includes(event.key);
						if (isKeyDownInside && isCloseKey) {
							context.onOpenChange(false);
							subContext.trigger?.focus();
							event.preventDefault();
						}
					})
				})
			})
		})
	});
}, "MenuSubContent"));
function getOpenState(open) {
	return open ? "open" : "closed";
}
__name$1(getOpenState, "getOpenState");
function isIndeterminate(checked) {
	return checked === "indeterminate";
}
__name$1(isIndeterminate, "isIndeterminate");
function getCheckedState(checked) {
	return isIndeterminate(checked) ? "indeterminate" : checked ? "checked" : "unchecked";
}
__name$1(getCheckedState, "getCheckedState");
function focusFirst(candidates) {
	const PREVIOUSLY_FOCUSED_ELEMENT = document.activeElement;
	for (const candidate of candidates) {
		if (candidate === PREVIOUSLY_FOCUSED_ELEMENT) return;
		candidate.focus();
		if (document.activeElement !== PREVIOUSLY_FOCUSED_ELEMENT) return;
	}
}
__name$1(focusFirst, "focusFirst");
function wrapArray(array, startIndex) {
	return array.map((_, index) => array[(startIndex + index) % array.length]);
}
__name$1(wrapArray, "wrapArray");
function getNextMatch(values, search, currentMatch) {
	const normalizedSearch = search.length > 1 && Array.from(search).every((char) => char === search[0]) ? search[0] : search;
	const currentMatchIndex = currentMatch ? values.indexOf(currentMatch) : -1;
	let wrappedValues = wrapArray(values, Math.max(currentMatchIndex, 0));
	if (normalizedSearch.length === 1) wrappedValues = wrappedValues.filter((v) => v !== currentMatch);
	const nextMatch = wrappedValues.find((value) => value.toLowerCase().startsWith(normalizedSearch.toLowerCase()));
	return nextMatch !== currentMatch ? nextMatch : void 0;
}
__name$1(getNextMatch, "getNextMatch");
function isPointInPolygon(point, polygon) {
	const { x, y } = point;
	let inside = false;
	for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
		const ii = polygon[i];
		const jj = polygon[j];
		const xi = ii.x;
		const yi = ii.y;
		const xj = jj.x;
		const yj = jj.y;
		if (yi > y !== yj > y && x < (xj - xi) * (y - yi) / (yj - yi) + xi) inside = !inside;
	}
	return inside;
}
__name$1(isPointInPolygon, "isPointInPolygon");
function isPointerInGraceArea(event, area) {
	if (!area) return false;
	return isPointInPolygon({
		x: event.clientX,
		y: event.clientY
	}, area);
}
__name$1(isPointerInGraceArea, "isPointerInGraceArea");
function whenMouse(handler) {
	return (event) => event.pointerType === "mouse" ? handler(event) : void 0;
}
__name$1(whenMouse, "whenMouse");
var Root3 = Menu;
var Anchor2 = MenuAnchor;
var Portal = MenuPortal;
var Content2$1 = MenuContent;
var Group = MenuGroup;
var Label = MenuLabel;
var Item2$1 = MenuItem;
var CheckboxItem = MenuCheckboxItem;
var RadioGroup = MenuRadioGroup;
var RadioItem = MenuRadioItem;
var ItemIndicator = MenuItemIndicator;
var Separator = MenuSeparator;
var Arrow2$1 = MenuArrow;
var Sub = MenuSub;
var SubTrigger = MenuSubTrigger;
var SubContent = MenuSubContent;
//#endregion
//#region node_modules/@radix-ui/react-dropdown-menu/dist/index.mjs
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", {
	value,
	configurable: true
});
var DROPDOWN_MENU_NAME = "DropdownMenu";
var [createDropdownMenuContext, createDropdownMenuScope] = createContextScope(DROPDOWN_MENU_NAME, [createMenuScope]);
var useMenuScope = createMenuScope();
var [DropdownMenuProvider, useDropdownMenuContext] = createDropdownMenuContext(DROPDOWN_MENU_NAME);
var DropdownMenu = /* @__PURE__ */ __name((props) => {
	const { __scopeDropdownMenu, children, dir, open: openProp, defaultOpen, onOpenChange, modal = true } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	const triggerRef = import_react.useRef(null);
	const [open, setOpen] = useControllableState({
		prop: openProp,
		defaultProp: defaultOpen ?? false,
		onChange: onOpenChange,
		caller: DROPDOWN_MENU_NAME
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuProvider, {
		scope: __scopeDropdownMenu,
		triggerId: useId(),
		triggerRef,
		contentId: useId(),
		open,
		onOpenChange: setOpen,
		onOpenToggle: import_react.useCallback(() => setOpen((prevOpen) => !prevOpen), [setOpen]),
		modal,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root3, {
			...menuScope,
			open,
			onOpenChange: setOpen,
			dir,
			modal,
			children
		})
	});
}, "DropdownMenu");
var TRIGGER_NAME = "DropdownMenuTrigger";
var DropdownMenuTrigger = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuTrigger2(props, forwardedRef) {
	const { __scopeDropdownMenu, disabled = false, ...triggerProps } = props;
	const context = useDropdownMenuContext(TRIGGER_NAME, __scopeDropdownMenu);
	const menuScope = useMenuScope(__scopeDropdownMenu);
	const composedRefs = useComposedRefs(forwardedRef, context.triggerRef);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Anchor2, {
		asChild: true,
		...menuScope,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.button, {
			type: "button",
			id: context.triggerId,
			"aria-haspopup": "menu",
			"aria-expanded": context.open,
			"aria-controls": context.open ? context.contentId : void 0,
			"data-state": context.open ? "open" : "closed",
			"data-disabled": disabled ? "" : void 0,
			disabled,
			...triggerProps,
			ref: composedRefs,
			onPointerDown: composeEventHandlers(props.onPointerDown, (event) => {
				if (!disabled && event.button === 0 && event.ctrlKey === false) {
					context.onOpenToggle();
					if (!context.open) event.preventDefault();
				}
			}),
			onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
				if (disabled) return;
				if (["Enter", " "].includes(event.key)) context.onOpenToggle();
				if (event.key === "ArrowDown") context.onOpenChange(true);
				if ([
					"Enter",
					" ",
					"ArrowDown"
				].includes(event.key)) event.preventDefault();
			})
		})
	});
}, "DropdownMenuTrigger"));
var DropdownMenuPortal = /* @__PURE__ */ __name((props) => {
	const { __scopeDropdownMenu, ...portalProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, {
		...menuScope,
		...portalProps
	});
}, "DropdownMenuPortal");
var CONTENT_NAME = "DropdownMenuContent";
var DropdownMenuContent = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuContent2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...contentProps } = props;
	const context = useDropdownMenuContext(CONTENT_NAME, __scopeDropdownMenu);
	const menuScope = useMenuScope(__scopeDropdownMenu);
	const hasInteractedOutsideRef = import_react.useRef(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2$1, {
		id: context.contentId,
		"aria-labelledby": context.triggerId,
		...menuScope,
		...contentProps,
		ref: forwardedRef,
		onCloseAutoFocus: composeEventHandlers(props.onCloseAutoFocus, (event) => {
			if (!hasInteractedOutsideRef.current) context.triggerRef.current?.focus();
			hasInteractedOutsideRef.current = false;
			event.preventDefault();
		}),
		onInteractOutside: composeEventHandlers(props.onInteractOutside, (event) => {
			const originalEvent = event.detail.originalEvent;
			const ctrlLeftClick = originalEvent.button === 0 && originalEvent.ctrlKey === true;
			const isRightClick = originalEvent.button === 2 || ctrlLeftClick;
			if (!context.modal || isRightClick) hasInteractedOutsideRef.current = true;
		}),
		style: {
			...props.style,
			"--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
			"--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
			"--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
			"--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
			"--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
		}
	});
}, "DropdownMenuContent"));
var DropdownMenuGroup = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuGroup2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...groupProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
		...menuScope,
		...groupProps,
		ref: forwardedRef
	});
}, "DropdownMenuGroup"));
var DropdownMenuLabel = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuLabel2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...labelProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
		...menuScope,
		...labelProps,
		ref: forwardedRef
	});
}, "DropdownMenuLabel"));
var DropdownMenuItem = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuItem2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...itemProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2$1, {
		...menuScope,
		...itemProps,
		ref: forwardedRef
	});
}, "DropdownMenuItem"));
var DropdownMenuCheckboxItem = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuCheckboxItem2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...checkboxItemProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckboxItem, {
		...menuScope,
		...checkboxItemProps,
		ref: forwardedRef
	});
}, "DropdownMenuCheckboxItem"));
var DropdownMenuRadioGroup = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuRadioGroup2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...radioGroupProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup, {
		...menuScope,
		...radioGroupProps,
		ref: forwardedRef
	});
}, "DropdownMenuRadioGroup"));
var DropdownMenuRadioItem = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuRadioItem2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...radioItemProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioItem, {
		...menuScope,
		...radioItemProps,
		ref: forwardedRef
	});
}, "DropdownMenuRadioItem"));
var DropdownMenuItemIndicator = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuItemIndicator2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...itemIndicatorProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicator, {
		...menuScope,
		...itemIndicatorProps,
		ref: forwardedRef
	});
}, "DropdownMenuItemIndicator"));
var DropdownMenuSeparator = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuSeparator2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...separatorProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {
		...menuScope,
		...separatorProps,
		ref: forwardedRef
	});
}, "DropdownMenuSeparator"));
var DropdownMenuArrow = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuArrow2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...arrowProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arrow2$1, {
		...menuScope,
		...arrowProps,
		ref: forwardedRef
	});
}, "DropdownMenuArrow"));
var DropdownMenuSub = /* @__PURE__ */ __name((props) => {
	const { __scopeDropdownMenu, children, open: openProp, onOpenChange, defaultOpen } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	const [open, setOpen] = useControllableState({
		prop: openProp,
		defaultProp: defaultOpen ?? false,
		onChange: onOpenChange,
		caller: "DropdownMenuSub"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sub, {
		...menuScope,
		open,
		onOpenChange: setOpen,
		children
	});
}, "DropdownMenuSub");
var DropdownMenuSubTrigger = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuSubTrigger2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...subTriggerProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubTrigger, {
		...menuScope,
		...subTriggerProps,
		ref: forwardedRef
	});
}, "DropdownMenuSubTrigger"));
var DropdownMenuSubContent = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DropdownMenuSubContent2(props, forwardedRef) {
	const { __scopeDropdownMenu, ...subContentProps } = props;
	const menuScope = useMenuScope(__scopeDropdownMenu);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubContent, {
		...menuScope,
		...subContentProps,
		ref: forwardedRef,
		style: {
			...props.style,
			"--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
			"--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
			"--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
			"--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
			"--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
		}
	});
}, "DropdownMenuSubContent"));
var Root2 = DropdownMenu;
var Trigger = DropdownMenuTrigger;
var Portal2 = DropdownMenuPortal;
var Content2 = DropdownMenuContent;
var Group2 = DropdownMenuGroup;
var Label2 = DropdownMenuLabel;
var Item2 = DropdownMenuItem;
var CheckboxItem2 = DropdownMenuCheckboxItem;
var RadioGroup2 = DropdownMenuRadioGroup;
var RadioItem2 = DropdownMenuRadioItem;
var ItemIndicator2 = DropdownMenuItemIndicator;
var Separator2 = DropdownMenuSeparator;
var Arrow2 = DropdownMenuArrow;
var Sub2 = DropdownMenuSub;
var SubTrigger2 = DropdownMenuSubTrigger;
var SubContent2 = DropdownMenuSubContent;
//#endregion
export { Arrow2 as Arrow, CheckboxItem2 as CheckboxItem, Content2 as Content, DropdownMenu, DropdownMenuArrow, DropdownMenuCheckboxItem, DropdownMenuContent, DropdownMenuGroup, DropdownMenuItem, DropdownMenuItemIndicator, DropdownMenuLabel, DropdownMenuPortal, DropdownMenuRadioGroup, DropdownMenuRadioItem, DropdownMenuSeparator, DropdownMenuSub, DropdownMenuSubContent, DropdownMenuSubTrigger, DropdownMenuTrigger, Group2 as Group, Item2 as Item, ItemIndicator2 as ItemIndicator, Label2 as Label, Portal2 as Portal, RadioGroup2 as RadioGroup, RadioItem2 as RadioItem, Root2 as Root, Separator2 as Separator, Sub2 as Sub, SubContent2 as SubContent, SubTrigger2 as SubTrigger, Trigger, createDropdownMenuScope };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHJhZGl4LXVpX3JlYWN0LWRyb3Bkb3duLW1lbnUuanMiLCJuYW1lcyI6WyJfX2RlZlByb3AiLCJfX25hbWUiLCJQb3BwZXJQcmltaXRpdmUuUm9vdCIsIlBvcHBlclByaW1pdGl2ZS5BbmNob3IiLCJQb3J0YWxQcmltaXRpdmUiLCJDT05URU5UX05BTUUiLCJSZW1vdmVTY3JvbGwiLCJSb3ZpbmdGb2N1c0dyb3VwLlJvb3QiLCJQb3BwZXJQcmltaXRpdmUuQ29udGVudCIsIlJvdmluZ0ZvY3VzR3JvdXAuSXRlbSIsIlBvcHBlclByaW1pdGl2ZS5BcnJvdyIsIkNvbnRlbnQyIiwiSXRlbTIiLCJBcnJvdzIiLCJNZW51UHJpbWl0aXZlLlJvb3QiLCJNZW51UHJpbWl0aXZlLkFuY2hvciIsIk1lbnVQcmltaXRpdmUuUG9ydGFsIiwiTWVudVByaW1pdGl2ZS5Db250ZW50IiwiTWVudVByaW1pdGl2ZS5Hcm91cCIsIk1lbnVQcmltaXRpdmUuTGFiZWwiLCJNZW51UHJpbWl0aXZlLkl0ZW0iLCJNZW51UHJpbWl0aXZlLkNoZWNrYm94SXRlbSIsIk1lbnVQcmltaXRpdmUuUmFkaW9Hcm91cCIsIk1lbnVQcmltaXRpdmUuUmFkaW9JdGVtIiwiTWVudVByaW1pdGl2ZS5JdGVtSW5kaWNhdG9yIiwiTWVudVByaW1pdGl2ZS5TZXBhcmF0b3IiLCJNZW51UHJpbWl0aXZlLkFycm93IiwiTWVudVByaW1pdGl2ZS5TdWIiLCJNZW51UHJpbWl0aXZlLlN1YlRyaWdnZXIiLCJNZW51UHJpbWl0aXZlLlN1YkNvbnRlbnQiXSwic291cmNlcyI6WyIuLi8uLi9AcmFkaXgtdWkvcmVhY3QtbWVudS9kaXN0L2luZGV4Lm1qcyIsIi4uLy4uL0ByYWRpeC11aS9yZWFjdC1kcm9wZG93bi1tZW51L2Rpc3QvaW5kZXgubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIGNsaWVudFwiO1xudmFyIF9fZGVmUHJvcCA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX25hbWUgPSAodGFyZ2V0LCB2YWx1ZSkgPT4gX19kZWZQcm9wKHRhcmdldCwgXCJuYW1lXCIsIHsgdmFsdWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSB9KTtcblxuLy8gc3JjL21lbnUudHN4XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNvbXBvc2VFdmVudEhhbmRsZXJzIH0gZnJvbSBcIkByYWRpeC11aS9wcmltaXRpdmVcIjtcbmltcG9ydCB7IGNyZWF0ZUNvbGxlY3Rpb24gfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LWNvbGxlY3Rpb25cIjtcbmltcG9ydCB7IHVzZUNvbXBvc2VkUmVmcyB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtY29tcG9zZS1yZWZzXCI7XG5pbXBvcnQgeyBjcmVhdGVDb250ZXh0U2NvcGUgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LWNvbnRleHRcIjtcbmltcG9ydCB7IHVzZURpcmVjdGlvbiB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtZGlyZWN0aW9uXCI7XG5pbXBvcnQgeyBEaXNtaXNzYWJsZUxheWVyIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1kaXNtaXNzYWJsZS1sYXllclwiO1xuaW1wb3J0IHsgdXNlRm9jdXNHdWFyZHMgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LWZvY3VzLWd1YXJkc1wiO1xuaW1wb3J0IHsgRm9jdXNTY29wZSB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtZm9jdXMtc2NvcGVcIjtcbmltcG9ydCB7IHVzZUlkIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1pZFwiO1xuaW1wb3J0ICogYXMgUG9wcGVyUHJpbWl0aXZlIGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtcG9wcGVyXCI7XG5pbXBvcnQgeyBjcmVhdGVQb3BwZXJTY29wZSB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtcG9wcGVyXCI7XG5pbXBvcnQgeyBQb3J0YWwgYXMgUG9ydGFsUHJpbWl0aXZlIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1wb3J0YWxcIjtcbmltcG9ydCB7IFByZXNlbmNlIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1wcmVzZW5jZVwiO1xuaW1wb3J0IHsgUHJpbWl0aXZlLCBkaXNwYXRjaERpc2NyZXRlQ3VzdG9tRXZlbnQgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXByaW1pdGl2ZVwiO1xuaW1wb3J0ICogYXMgUm92aW5nRm9jdXNHcm91cCBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXJvdmluZy1mb2N1c1wiO1xuaW1wb3J0IHsgY3JlYXRlUm92aW5nRm9jdXNHcm91cFNjb3BlIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC1yb3ZpbmctZm9jdXNcIjtcbmltcG9ydCB7IGNyZWF0ZVNsb3QgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXNsb3RcIjtcbmltcG9ydCB7IHVzZUNhbGxiYWNrUmVmIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC11c2UtY2FsbGJhY2stcmVmXCI7XG5pbXBvcnQgeyBoaWRlT3RoZXJzIH0gZnJvbSBcImFyaWEtaGlkZGVuXCI7XG5pbXBvcnQgeyBSZW1vdmVTY3JvbGwgfSBmcm9tIFwicmVhY3QtcmVtb3ZlLXNjcm9sbFwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG52YXIgU0VMRUNUSU9OX0tFWVMgPSBbXCJFbnRlclwiLCBcIiBcIl07XG52YXIgRklSU1RfS0VZUyA9IFtcIkFycm93RG93blwiLCBcIlBhZ2VVcFwiLCBcIkhvbWVcIl07XG52YXIgTEFTVF9LRVlTID0gW1wiQXJyb3dVcFwiLCBcIlBhZ2VEb3duXCIsIFwiRW5kXCJdO1xudmFyIEZJUlNUX0xBU1RfS0VZUyA9IFsuLi5GSVJTVF9LRVlTLCAuLi5MQVNUX0tFWVNdO1xudmFyIFNVQl9PUEVOX0tFWVMgPSB7XG4gIGx0cjogWy4uLlNFTEVDVElPTl9LRVlTLCBcIkFycm93UmlnaHRcIl0sXG4gIHJ0bDogWy4uLlNFTEVDVElPTl9LRVlTLCBcIkFycm93TGVmdFwiXVxufTtcbnZhciBTVUJfQ0xPU0VfS0VZUyA9IHtcbiAgbHRyOiBbXCJBcnJvd0xlZnRcIl0sXG4gIHJ0bDogW1wiQXJyb3dSaWdodFwiXVxufTtcbnZhciBNRU5VX05BTUUgPSBcIk1lbnVcIjtcbnZhciBbQ29sbGVjdGlvbiwgdXNlQ29sbGVjdGlvbiwgY3JlYXRlQ29sbGVjdGlvblNjb3BlXSA9IGNyZWF0ZUNvbGxlY3Rpb24oTUVOVV9OQU1FKTtcbnZhciBbY3JlYXRlTWVudUNvbnRleHQsIGNyZWF0ZU1lbnVTY29wZV0gPSBjcmVhdGVDb250ZXh0U2NvcGUoTUVOVV9OQU1FLCBbXG4gIGNyZWF0ZUNvbGxlY3Rpb25TY29wZSxcbiAgY3JlYXRlUG9wcGVyU2NvcGUsXG4gIGNyZWF0ZVJvdmluZ0ZvY3VzR3JvdXBTY29wZVxuXSk7XG52YXIgdXNlUG9wcGVyU2NvcGUgPSBjcmVhdGVQb3BwZXJTY29wZSgpO1xudmFyIHVzZVJvdmluZ0ZvY3VzR3JvdXBTY29wZSA9IGNyZWF0ZVJvdmluZ0ZvY3VzR3JvdXBTY29wZSgpO1xudmFyIFtNZW51UHJvdmlkZXIsIHVzZU1lbnVDb250ZXh0XSA9IGNyZWF0ZU1lbnVDb250ZXh0KE1FTlVfTkFNRSk7XG52YXIgW01lbnVSb290UHJvdmlkZXIsIHVzZU1lbnVSb290Q29udGV4dF0gPSBjcmVhdGVNZW51Q29udGV4dChNRU5VX05BTUUpO1xudmFyIE1lbnUgPSAvKiBAX19QVVJFX18gKi8gX19uYW1lKChwcm9wcykgPT4ge1xuICBjb25zdCB7IF9fc2NvcGVNZW51LCBvcGVuID0gZmFsc2UsIGNoaWxkcmVuLCBkaXIsIG9uT3BlbkNoYW5nZSwgbW9kYWwgPSB0cnVlIH0gPSBwcm9wcztcbiAgY29uc3QgcG9wcGVyU2NvcGUgPSB1c2VQb3BwZXJTY29wZShfX3Njb3BlTWVudSk7XG4gIGNvbnN0IFtjb250ZW50LCBzZXRDb250ZW50XSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBpc1VzaW5nS2V5Ym9hcmRSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICBjb25zdCBoYW5kbGVPcGVuQ2hhbmdlID0gdXNlQ2FsbGJhY2tSZWYob25PcGVuQ2hhbmdlKTtcbiAgY29uc3QgZGlyZWN0aW9uID0gdXNlRGlyZWN0aW9uKGRpcik7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaGFuZGxlS2V5RG93biA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKCkgPT4ge1xuICAgICAgaXNVc2luZ0tleWJvYXJkUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJkb3duXCIsIGhhbmRsZVBvaW50ZXIsIHsgY2FwdHVyZTogdHJ1ZSwgb25jZTogdHJ1ZSB9KTtcbiAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJwb2ludGVybW92ZVwiLCBoYW5kbGVQb2ludGVyLCB7IGNhcHR1cmU6IHRydWUsIG9uY2U6IHRydWUgfSk7XG4gICAgfSwgXCJoYW5kbGVLZXlEb3duXCIpO1xuICAgIGNvbnN0IGhhbmRsZVBvaW50ZXIgPSAvKiBAX19QVVJFX18gKi8gX19uYW1lKCgpID0+IGlzVXNpbmdLZXlib2FyZFJlZi5jdXJyZW50ID0gZmFsc2UsIFwiaGFuZGxlUG9pbnRlclwiKTtcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBoYW5kbGVLZXlEb3duLCB7IGNhcHR1cmU6IHRydWUgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGhhbmRsZUtleURvd24sIHsgY2FwdHVyZTogdHJ1ZSB9KTtcbiAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwb2ludGVyZG93blwiLCBoYW5kbGVQb2ludGVyLCB7IGNhcHR1cmU6IHRydWUgfSk7XG4gICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwicG9pbnRlcm1vdmVcIiwgaGFuZGxlUG9pbnRlciwgeyBjYXB0dXJlOiB0cnVlIH0pO1xuICAgIH07XG4gIH0sIFtdKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIW9wZW4pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgaGFuZGxlQmx1ciA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKCkgPT4gaGFuZGxlT3BlbkNoYW5nZShmYWxzZSksIFwiaGFuZGxlQmx1clwiKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImJsdXJcIiwgaGFuZGxlQmx1cik7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwiYmx1clwiLCBoYW5kbGVCbHVyKTtcbiAgfSwgW29wZW4sIGhhbmRsZU9wZW5DaGFuZ2VdKTtcbiAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goUG9wcGVyUHJpbWl0aXZlLlJvb3QsIHsgLi4ucG9wcGVyU2NvcGUsIGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgIE1lbnVQcm92aWRlcixcbiAgICB7XG4gICAgICBzY29wZTogX19zY29wZU1lbnUsXG4gICAgICBvcGVuLFxuICAgICAgb25PcGVuQ2hhbmdlOiBoYW5kbGVPcGVuQ2hhbmdlLFxuICAgICAgY29udGVudCxcbiAgICAgIG9uQ29udGVudENoYW5nZTogc2V0Q29udGVudCxcbiAgICAgIGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgICBNZW51Um9vdFByb3ZpZGVyLFxuICAgICAgICB7XG4gICAgICAgICAgc2NvcGU6IF9fc2NvcGVNZW51LFxuICAgICAgICAgIG9uQ2xvc2U6IFJlYWN0LnVzZUNhbGxiYWNrKCgpID0+IGhhbmRsZU9wZW5DaGFuZ2UoZmFsc2UpLCBbaGFuZGxlT3BlbkNoYW5nZV0pLFxuICAgICAgICAgIGlzVXNpbmdLZXlib2FyZFJlZixcbiAgICAgICAgICBkaXI6IGRpcmVjdGlvbixcbiAgICAgICAgICBtb2RhbCxcbiAgICAgICAgICBjaGlsZHJlblxuICAgICAgICB9XG4gICAgICApXG4gICAgfVxuICApIH0pO1xufSwgXCJNZW51XCIpO1xudmFyIE1lbnVBbmNob3IgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBNZW51QW5jaG9yMihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gICAgY29uc3QgeyBfX3Njb3BlTWVudSwgLi4uYW5jaG9yUHJvcHMgfSA9IHByb3BzO1xuICAgIGNvbnN0IHBvcHBlclNjb3BlID0gdXNlUG9wcGVyU2NvcGUoX19zY29wZU1lbnUpO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFBvcHBlclByaW1pdGl2ZS5BbmNob3IsIHsgLi4ucG9wcGVyU2NvcGUsIC4uLmFuY2hvclByb3BzLCByZWY6IGZvcndhcmRlZFJlZiB9KTtcbiAgfSwgXCJNZW51QW5jaG9yXCIpXG4pO1xudmFyIFBPUlRBTF9OQU1FID0gXCJNZW51UG9ydGFsXCI7XG52YXIgW1BvcnRhbFByb3ZpZGVyLCB1c2VQb3J0YWxDb250ZXh0XSA9IGNyZWF0ZU1lbnVDb250ZXh0KFBPUlRBTF9OQU1FLCB7XG4gIGZvcmNlTW91bnQ6IHZvaWQgMFxufSk7XG52YXIgTWVudVBvcnRhbCA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKHByb3BzKSA9PiB7XG4gIGNvbnN0IHsgX19zY29wZU1lbnUsIGZvcmNlTW91bnQsIGNoaWxkcmVuLCBjb250YWluZXIgfSA9IHByb3BzO1xuICBjb25zdCBjb250ZXh0ID0gdXNlTWVudUNvbnRleHQoUE9SVEFMX05BTUUsIF9fc2NvcGVNZW51KTtcbiAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goUG9ydGFsUHJvdmlkZXIsIHsgc2NvcGU6IF9fc2NvcGVNZW51LCBmb3JjZU1vdW50LCBjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGpzeChQcmVzZW5jZSwgeyBwcmVzZW50OiBmb3JjZU1vdW50IHx8IGNvbnRleHQub3BlbiwgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goUG9ydGFsUHJpbWl0aXZlLCB7IGFzQ2hpbGQ6IHRydWUsIGNvbnRhaW5lciwgY2hpbGRyZW4gfSkgfSkgfSk7XG59LCBcIk1lbnVQb3J0YWxcIik7XG52YXIgQ09OVEVOVF9OQU1FID0gXCJNZW51Q29udGVudFwiO1xudmFyIFtNZW51Q29udGVudFByb3ZpZGVyLCB1c2VNZW51Q29udGVudENvbnRleHRdID0gY3JlYXRlTWVudUNvbnRleHQoQ09OVEVOVF9OQU1FKTtcbnZhciBNZW51Q29udGVudCA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIE1lbnVDb250ZW50Mihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gICAgY29uc3QgcG9ydGFsQ29udGV4dCA9IHVzZVBvcnRhbENvbnRleHQoQ09OVEVOVF9OQU1FLCBwcm9wcy5fX3Njb3BlTWVudSk7XG4gICAgY29uc3QgeyBmb3JjZU1vdW50ID0gcG9ydGFsQ29udGV4dC5mb3JjZU1vdW50LCAuLi5jb250ZW50UHJvcHMgfSA9IHByb3BzO1xuICAgIGNvbnN0IGNvbnRleHQgPSB1c2VNZW51Q29udGV4dChDT05URU5UX05BTUUsIHByb3BzLl9fc2NvcGVNZW51KTtcbiAgICBjb25zdCByb290Q29udGV4dCA9IHVzZU1lbnVSb290Q29udGV4dChDT05URU5UX05BTUUsIHByb3BzLl9fc2NvcGVNZW51KTtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChDb2xsZWN0aW9uLlByb3ZpZGVyLCB7IHNjb3BlOiBwcm9wcy5fX3Njb3BlTWVudSwgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goUHJlc2VuY2UsIHsgcHJlc2VudDogZm9yY2VNb3VudCB8fCBjb250ZXh0Lm9wZW4sIGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4KENvbGxlY3Rpb24uU2xvdCwgeyBzY29wZTogcHJvcHMuX19zY29wZU1lbnUsIGNoaWxkcmVuOiByb290Q29udGV4dC5tb2RhbCA/IC8qIEBfX1BVUkVfXyAqLyBqc3goTWVudVJvb3RDb250ZW50TW9kYWwsIHsgLi4uY29udGVudFByb3BzLCByZWY6IGZvcndhcmRlZFJlZiB9KSA6IC8qIEBfX1BVUkVfXyAqLyBqc3goTWVudVJvb3RDb250ZW50Tm9uTW9kYWwsIHsgLi4uY29udGVudFByb3BzLCByZWY6IGZvcndhcmRlZFJlZiB9KSB9KSB9KSB9KTtcbiAgfSwgXCJNZW51Q29udGVudFwiKVxuKTtcbnZhciBNZW51Um9vdENvbnRlbnRNb2RhbCA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvLyBibGFuayBsaW5lIHRvIHJlZHVjZSBkaWZmIG5vaXNlXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gTWVudVJvb3RDb250ZW50TW9kYWwyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCBjb250ZXh0ID0gdXNlTWVudUNvbnRleHQoQ09OVEVOVF9OQU1FLCBwcm9wcy5fX3Njb3BlTWVudSk7XG4gICAgY29uc3QgcmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICAgIGNvbnN0IGNvbXBvc2VkUmVmcyA9IHVzZUNvbXBvc2VkUmVmcyhmb3J3YXJkZWRSZWYsIHJlZik7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgIGNvbnN0IGNvbnRlbnQgPSByZWYuY3VycmVudDtcbiAgICAgIGlmIChjb250ZW50KSByZXR1cm4gaGlkZU90aGVycyhjb250ZW50KTtcbiAgICB9LCBbXSk7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgICBNZW51Q29udGVudEltcGwsXG4gICAgICB7XG4gICAgICAgIC4uLnByb3BzLFxuICAgICAgICByZWY6IGNvbXBvc2VkUmVmcyxcbiAgICAgICAgdHJhcEZvY3VzOiBjb250ZXh0Lm9wZW4sXG4gICAgICAgIGRpc2FibGVPdXRzaWRlUG9pbnRlckV2ZW50czogY29udGV4dC5vcGVuLFxuICAgICAgICBkaXNhYmxlT3V0c2lkZVNjcm9sbDogdHJ1ZSxcbiAgICAgICAgb25Gb2N1c091dHNpZGU6IGNvbXBvc2VFdmVudEhhbmRsZXJzKFxuICAgICAgICAgIHByb3BzLm9uRm9jdXNPdXRzaWRlLFxuICAgICAgICAgIChldmVudCkgPT4gZXZlbnQucHJldmVudERlZmF1bHQoKSxcbiAgICAgICAgICB7IGNoZWNrRm9yRGVmYXVsdFByZXZlbnRlZDogZmFsc2UgfVxuICAgICAgICApLFxuICAgICAgICBvbkRpc21pc3M6ICgpID0+IGNvbnRleHQub25PcGVuQ2hhbmdlKGZhbHNlKVxuICAgICAgfVxuICAgICk7XG4gIH0sIFwiTWVudVJvb3RDb250ZW50TW9kYWxcIilcbik7XG52YXIgTWVudVJvb3RDb250ZW50Tm9uTW9kYWwgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZigvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIE1lbnVSb290Q29udGVudE5vbk1vZGFsMihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IGNvbnRleHQgPSB1c2VNZW51Q29udGV4dChDT05URU5UX05BTUUsIHByb3BzLl9fc2NvcGVNZW51KTtcbiAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgTWVudUNvbnRlbnRJbXBsLFxuICAgIHtcbiAgICAgIC4uLnByb3BzLFxuICAgICAgcmVmOiBmb3J3YXJkZWRSZWYsXG4gICAgICB0cmFwRm9jdXM6IGZhbHNlLFxuICAgICAgZGlzYWJsZU91dHNpZGVQb2ludGVyRXZlbnRzOiBmYWxzZSxcbiAgICAgIGRpc2FibGVPdXRzaWRlU2Nyb2xsOiBmYWxzZSxcbiAgICAgIG9uRGlzbWlzczogKCkgPT4gY29udGV4dC5vbk9wZW5DaGFuZ2UoZmFsc2UpXG4gICAgfVxuICApO1xufSwgXCJNZW51Um9vdENvbnRlbnROb25Nb2RhbFwiKSk7XG52YXIgU2xvdCA9IGNyZWF0ZVNsb3QoXCJNZW51Q29udGVudC5TY3JvbGxMb2NrXCIpO1xudmFyIE1lbnVDb250ZW50SW1wbCA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvLyBibGFuayBsaW5lIHRvIHJlZHVjZSBkaWZmIG5vaXNlXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gTWVudUNvbnRlbnRJbXBsMihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gICAgY29uc3Qge1xuICAgICAgX19zY29wZU1lbnUsXG4gICAgICBsb29wID0gZmFsc2UsXG4gICAgICB0cmFwRm9jdXMsXG4gICAgICBvbk9wZW5BdXRvRm9jdXMsXG4gICAgICBvbkNsb3NlQXV0b0ZvY3VzLFxuICAgICAgZGlzYWJsZU91dHNpZGVQb2ludGVyRXZlbnRzLFxuICAgICAgb25FbnRyeUZvY3VzLFxuICAgICAgb25Fc2NhcGVLZXlEb3duLFxuICAgICAgb25Qb2ludGVyRG93bk91dHNpZGUsXG4gICAgICBvbkZvY3VzT3V0c2lkZSxcbiAgICAgIG9uSW50ZXJhY3RPdXRzaWRlLFxuICAgICAgb25EaXNtaXNzLFxuICAgICAgZGlzYWJsZU91dHNpZGVTY3JvbGwsXG4gICAgICAuLi5jb250ZW50UHJvcHNcbiAgICB9ID0gcHJvcHM7XG4gICAgY29uc3QgY29udGV4dCA9IHVzZU1lbnVDb250ZXh0KENPTlRFTlRfTkFNRSwgX19zY29wZU1lbnUpO1xuICAgIGNvbnN0IHJvb3RDb250ZXh0ID0gdXNlTWVudVJvb3RDb250ZXh0KENPTlRFTlRfTkFNRSwgX19zY29wZU1lbnUpO1xuICAgIGNvbnN0IHBvcHBlclNjb3BlID0gdXNlUG9wcGVyU2NvcGUoX19zY29wZU1lbnUpO1xuICAgIGNvbnN0IHJvdmluZ0ZvY3VzR3JvdXBTY29wZSA9IHVzZVJvdmluZ0ZvY3VzR3JvdXBTY29wZShfX3Njb3BlTWVudSk7XG4gICAgY29uc3QgZ2V0SXRlbXMgPSB1c2VDb2xsZWN0aW9uKF9fc2NvcGVNZW51KTtcbiAgICBjb25zdCBbY3VycmVudEl0ZW1JZCwgc2V0Q3VycmVudEl0ZW1JZF0gPSBSZWFjdC51c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBjb250ZW50UmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICAgIGNvbnN0IGNvbXBvc2VkUmVmcyA9IHVzZUNvbXBvc2VkUmVmcyhmb3J3YXJkZWRSZWYsIGNvbnRlbnRSZWYsIGNvbnRleHQub25Db250ZW50Q2hhbmdlKTtcbiAgICBjb25zdCB0aW1lclJlZiA9IFJlYWN0LnVzZVJlZigwKTtcbiAgICBjb25zdCBzZWFyY2hSZWYgPSBSZWFjdC51c2VSZWYoXCJcIik7XG4gICAgY29uc3QgcG9pbnRlckdyYWNlVGltZXJSZWYgPSBSZWFjdC51c2VSZWYoMCk7XG4gICAgY29uc3QgcG9pbnRlckdyYWNlSW50ZW50UmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICAgIGNvbnN0IHBvaW50ZXJEaXJSZWYgPSBSZWFjdC51c2VSZWYoXCJyaWdodFwiKTtcbiAgICBjb25zdCBsYXN0UG9pbnRlclhSZWYgPSBSZWFjdC51c2VSZWYoMCk7XG4gICAgY29uc3QgU2Nyb2xsTG9ja1dyYXBwZXIgPSBkaXNhYmxlT3V0c2lkZVNjcm9sbCA/IFJlbW92ZVNjcm9sbCA6IFJlYWN0LkZyYWdtZW50O1xuICAgIGNvbnN0IHNjcm9sbExvY2tXcmFwcGVyUHJvcHMgPSBkaXNhYmxlT3V0c2lkZVNjcm9sbCA/IHsgYXM6IFNsb3QsIGFsbG93UGluY2hab29tOiB0cnVlIH0gOiB2b2lkIDA7XG4gICAgY29uc3QgaGFuZGxlVHlwZWFoZWFkU2VhcmNoID0gLyogQF9fUFVSRV9fICovIF9fbmFtZSgoa2V5KSA9PiB7XG4gICAgICBjb25zdCBzZWFyY2ggPSBzZWFyY2hSZWYuY3VycmVudCArIGtleTtcbiAgICAgIGNvbnN0IGl0ZW1zID0gZ2V0SXRlbXMoKS5maWx0ZXIoKGl0ZW0pID0+ICFpdGVtLmRpc2FibGVkKTtcbiAgICAgIGNvbnN0IGN1cnJlbnRJdGVtID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudDtcbiAgICAgIGNvbnN0IGN1cnJlbnRNYXRjaCA9IGl0ZW1zLmZpbmQoKGl0ZW0pID0+IGl0ZW0ucmVmLmN1cnJlbnQgPT09IGN1cnJlbnRJdGVtKT8udGV4dFZhbHVlO1xuICAgICAgY29uc3QgdmFsdWVzID0gaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLnRleHRWYWx1ZSk7XG4gICAgICBjb25zdCBuZXh0TWF0Y2ggPSBnZXROZXh0TWF0Y2godmFsdWVzLCBzZWFyY2gsIGN1cnJlbnRNYXRjaCk7XG4gICAgICBjb25zdCBuZXdJdGVtID0gaXRlbXMuZmluZCgoaXRlbSkgPT4gaXRlbS50ZXh0VmFsdWUgPT09IG5leHRNYXRjaCk/LnJlZi5jdXJyZW50O1xuICAgICAgKC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKGZ1bmN0aW9uIHVwZGF0ZVNlYXJjaCh2YWx1ZSkge1xuICAgICAgICBzZWFyY2hSZWYuY3VycmVudCA9IHZhbHVlO1xuICAgICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KHRpbWVyUmVmLmN1cnJlbnQpO1xuICAgICAgICBpZiAodmFsdWUgIT09IFwiXCIpIHRpbWVyUmVmLmN1cnJlbnQgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB1cGRhdGVTZWFyY2goXCJcIiksIDFlMyk7XG4gICAgICB9KSwgXCJ1cGRhdGVTZWFyY2hcIikpKHNlYXJjaCk7XG4gICAgICBpZiAobmV3SXRlbSkge1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IG5ld0l0ZW0uZm9jdXMoKSk7XG4gICAgICB9XG4gICAgfSwgXCJoYW5kbGVUeXBlYWhlYWRTZWFyY2hcIik7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgIHJldHVybiAoKSA9PiB3aW5kb3cuY2xlYXJUaW1lb3V0KHRpbWVyUmVmLmN1cnJlbnQpO1xuICAgIH0sIFtdKTtcbiAgICB1c2VGb2N1c0d1YXJkcygpO1xuICAgIGNvbnN0IGlzUG9pbnRlck1vdmluZ1RvU3VibWVudSA9IFJlYWN0LnVzZUNhbGxiYWNrKChldmVudCkgPT4ge1xuICAgICAgY29uc3QgaXNNb3ZpbmdUb3dhcmRzID0gcG9pbnRlckRpclJlZi5jdXJyZW50ID09PSBwb2ludGVyR3JhY2VJbnRlbnRSZWYuY3VycmVudD8uc2lkZTtcbiAgICAgIHJldHVybiBpc01vdmluZ1Rvd2FyZHMgJiYgaXNQb2ludGVySW5HcmFjZUFyZWEoZXZlbnQsIHBvaW50ZXJHcmFjZUludGVudFJlZi5jdXJyZW50Py5hcmVhKTtcbiAgICB9LCBbXSk7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgICBNZW51Q29udGVudFByb3ZpZGVyLFxuICAgICAge1xuICAgICAgICBzY29wZTogX19zY29wZU1lbnUsXG4gICAgICAgIHNlYXJjaFJlZixcbiAgICAgICAgb25JdGVtRW50ZXI6IFJlYWN0LnVzZUNhbGxiYWNrKFxuICAgICAgICAgIChldmVudCkgPT4ge1xuICAgICAgICAgICAgaWYgKGlzUG9pbnRlck1vdmluZ1RvU3VibWVudShldmVudCkpIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBbaXNQb2ludGVyTW92aW5nVG9TdWJtZW51XVxuICAgICAgICApLFxuICAgICAgICBvbkl0ZW1MZWF2ZTogUmVhY3QudXNlQ2FsbGJhY2soXG4gICAgICAgICAgKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICBpZiAoaXNQb2ludGVyTW92aW5nVG9TdWJtZW51KGV2ZW50KSkgcmV0dXJuO1xuICAgICAgICAgICAgY29udGVudFJlZi5jdXJyZW50Py5mb2N1cygpO1xuICAgICAgICAgICAgc2V0Q3VycmVudEl0ZW1JZChudWxsKTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIFtpc1BvaW50ZXJNb3ZpbmdUb1N1Ym1lbnVdXG4gICAgICAgICksXG4gICAgICAgIG9uVHJpZ2dlckxlYXZlOiBSZWFjdC51c2VDYWxsYmFjayhcbiAgICAgICAgICAoZXZlbnQpID0+IHtcbiAgICAgICAgICAgIGlmIChpc1BvaW50ZXJNb3ZpbmdUb1N1Ym1lbnUoZXZlbnQpKSBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgW2lzUG9pbnRlck1vdmluZ1RvU3VibWVudV1cbiAgICAgICAgKSxcbiAgICAgICAgcG9pbnRlckdyYWNlVGltZXJSZWYsXG4gICAgICAgIG9uUG9pbnRlckdyYWNlSW50ZW50Q2hhbmdlOiBSZWFjdC51c2VDYWxsYmFjaygoaW50ZW50KSA9PiB7XG4gICAgICAgICAgcG9pbnRlckdyYWNlSW50ZW50UmVmLmN1cnJlbnQgPSBpbnRlbnQ7XG4gICAgICAgIH0sIFtdKSxcbiAgICAgICAgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goU2Nyb2xsTG9ja1dyYXBwZXIsIHsgLi4uc2Nyb2xsTG9ja1dyYXBwZXJQcm9wcywgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgICAgICAgRm9jdXNTY29wZSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBhc0NoaWxkOiB0cnVlLFxuICAgICAgICAgICAgdHJhcHBlZDogdHJhcEZvY3VzLFxuICAgICAgICAgICAgb25Nb3VudEF1dG9Gb2N1czogY29tcG9zZUV2ZW50SGFuZGxlcnMob25PcGVuQXV0b0ZvY3VzLCAoZXZlbnQpID0+IHtcbiAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgY29udGVudFJlZi5jdXJyZW50Py5mb2N1cyh7IHByZXZlbnRTY3JvbGw6IHRydWUgfSk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIG9uVW5tb3VudEF1dG9Gb2N1czogb25DbG9zZUF1dG9Gb2N1cyxcbiAgICAgICAgICAgIGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgICAgICAgICBEaXNtaXNzYWJsZUxheWVyLFxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYXNDaGlsZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICBkaXNhYmxlT3V0c2lkZVBvaW50ZXJFdmVudHMsXG4gICAgICAgICAgICAgICAgb25Fc2NhcGVLZXlEb3duLFxuICAgICAgICAgICAgICAgIG9uUG9pbnRlckRvd25PdXRzaWRlLFxuICAgICAgICAgICAgICAgIG9uRm9jdXNPdXRzaWRlLFxuICAgICAgICAgICAgICAgIG9uSW50ZXJhY3RPdXRzaWRlLFxuICAgICAgICAgICAgICAgIG9uRGlzbWlzcyxcbiAgICAgICAgICAgICAgICBjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgICAgICAgICAgICAgIFJvdmluZ0ZvY3VzR3JvdXAuUm9vdCxcbiAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgYXNDaGlsZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgLi4ucm92aW5nRm9jdXNHcm91cFNjb3BlLFxuICAgICAgICAgICAgICAgICAgICBkaXI6IHJvb3RDb250ZXh0LmRpcixcbiAgICAgICAgICAgICAgICAgICAgb3JpZW50YXRpb246IFwidmVydGljYWxcIixcbiAgICAgICAgICAgICAgICAgICAgbG9vcCxcbiAgICAgICAgICAgICAgICAgICAgY3VycmVudFRhYlN0b3BJZDogY3VycmVudEl0ZW1JZCxcbiAgICAgICAgICAgICAgICAgICAgb25DdXJyZW50VGFiU3RvcElkQ2hhbmdlOiBzZXRDdXJyZW50SXRlbUlkLFxuICAgICAgICAgICAgICAgICAgICBvbkVudHJ5Rm9jdXM6IGNvbXBvc2VFdmVudEhhbmRsZXJzKG9uRW50cnlGb2N1cywgKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKCFyb290Q29udGV4dC5pc1VzaW5nS2V5Ym9hcmRSZWYuY3VycmVudCkgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICAgIHByZXZlbnRTY3JvbGxPbkVudHJ5Rm9jdXM6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgICAgICAgICAgICAgICAgIFBvcHBlclByaW1pdGl2ZS5Db250ZW50LFxuICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvbGU6IFwibWVudVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJhcmlhLW9yaWVudGF0aW9uXCI6IFwidmVydGljYWxcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiZGF0YS1zdGF0ZVwiOiBnZXRPcGVuU3RhdGUoY29udGV4dC5vcGVuKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiZGF0YS1yYWRpeC1tZW51LWNvbnRlbnRcIjogXCJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpcjogcm9vdENvbnRleHQuZGlyLFxuICAgICAgICAgICAgICAgICAgICAgICAgLi4ucG9wcGVyU2NvcGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5jb250ZW50UHJvcHMsXG4gICAgICAgICAgICAgICAgICAgICAgICByZWY6IGNvbXBvc2VkUmVmcyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlOiB7IG91dGxpbmU6IFwibm9uZVwiLCAuLi5jb250ZW50UHJvcHMuc3R5bGUgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uS2V5RG93bjogY29tcG9zZUV2ZW50SGFuZGxlcnMoY29udGVudFByb3BzLm9uS2V5RG93biwgKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LnRhcmdldDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNLZXlEb3duSW5zaWRlID0gdGFyZ2V0LmNsb3Nlc3QoXCJbZGF0YS1yYWRpeC1tZW51LWNvbnRlbnRdXCIpID09PSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc01vZGlmaWVyS2V5ID0gZXZlbnQuY3RybEtleSB8fCBldmVudC5hbHRLZXkgfHwgZXZlbnQubWV0YUtleTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNDaGFyYWN0ZXJLZXkgPSBldmVudC5rZXkubGVuZ3RoID09PSAxO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNLZXlEb3duSW5zaWRlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGV2ZW50LmtleSA9PT0gXCJUYWJcIikgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzTW9kaWZpZXJLZXkgJiYgaXNDaGFyYWN0ZXJLZXkpIGhhbmRsZVR5cGVhaGVhZFNlYXJjaChldmVudC5rZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNvbnRlbnQgPSBjb250ZW50UmVmLmN1cnJlbnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChldmVudC50YXJnZXQgIT09IGNvbnRlbnQpIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFGSVJTVF9MQVNUX0tFWVMuaW5jbHVkZXMoZXZlbnQua2V5KSkgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpdGVtcyA9IGdldEl0ZW1zKCkuZmlsdGVyKChpdGVtKSA9PiAhaXRlbS5kaXNhYmxlZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNhbmRpZGF0ZU5vZGVzID0gaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLnJlZi5jdXJyZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKExBU1RfS0VZUy5pbmNsdWRlcyhldmVudC5rZXkpKSBjYW5kaWRhdGVOb2Rlcy5yZXZlcnNlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvY3VzRmlyc3QoY2FuZGlkYXRlTm9kZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkJsdXI6IGNvbXBvc2VFdmVudEhhbmRsZXJzKHByb3BzLm9uQmx1ciwgKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghZXZlbnQuY3VycmVudFRhcmdldC5jb250YWlucyhldmVudC50YXJnZXQpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd2luZG93LmNsZWFyVGltZW91dCh0aW1lclJlZi5jdXJyZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWFyY2hSZWYuY3VycmVudCA9IFwiXCI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgb25Qb2ludGVyTW92ZTogY29tcG9zZUV2ZW50SGFuZGxlcnMoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHByb3BzLm9uUG9pbnRlck1vdmUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHdoZW5Nb3VzZSgoZXZlbnQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC50YXJnZXQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcG9pbnRlclhIYXNDaGFuZ2VkID0gbGFzdFBvaW50ZXJYUmVmLmN1cnJlbnQgIT09IGV2ZW50LmNsaWVudFg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGV2ZW50LmN1cnJlbnRUYXJnZXQuY29udGFpbnModGFyZ2V0KSAmJiBwb2ludGVyWEhhc0NoYW5nZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG5ld0RpciA9IGV2ZW50LmNsaWVudFggPiBsYXN0UG9pbnRlclhSZWYuY3VycmVudCA/IFwicmlnaHRcIiA6IFwibGVmdFwiO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9pbnRlckRpclJlZi5jdXJyZW50ID0gbmV3RGlyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFzdFBvaW50ZXJYUmVmLmN1cnJlbnQgPSBldmVudC5jbGllbnRYO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIClcbiAgICAgICAgICB9XG4gICAgICAgICkgfSlcbiAgICAgIH1cbiAgICApO1xuICB9LCBcIk1lbnVDb250ZW50SW1wbFwiKVxuKTtcbnZhciBNZW51R3JvdXAgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBNZW51R3JvdXAyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCB7IF9fc2NvcGVNZW51LCAuLi5ncm91cFByb3BzIH0gPSBwcm9wcztcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChQcmltaXRpdmUuZGl2LCB7IHJvbGU6IFwiZ3JvdXBcIiwgLi4uZ3JvdXBQcm9wcywgcmVmOiBmb3J3YXJkZWRSZWYgfSk7XG4gIH0sIFwiTWVudUdyb3VwXCIpXG4pO1xudmFyIE1lbnVMYWJlbCA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIE1lbnVMYWJlbDIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHsgX19zY29wZU1lbnUsIC4uLmxhYmVsUHJvcHMgfSA9IHByb3BzO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFByaW1pdGl2ZS5kaXYsIHsgLi4ubGFiZWxQcm9wcywgcmVmOiBmb3J3YXJkZWRSZWYgfSk7XG4gIH0sIFwiTWVudUxhYmVsXCIpXG4pO1xudmFyIElURU1fTkFNRSA9IFwiTWVudUl0ZW1cIjtcbnZhciBJVEVNX1NFTEVDVCA9IFwibWVudS5pdGVtU2VsZWN0XCI7XG52YXIgTWVudUl0ZW0gPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLy8gYmxhbmsgbGluZSB0byByZWR1Y2UgZGlmZiBub2lzZVxuICAvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIE1lbnVJdGVtMihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gICAgY29uc3QgeyBkaXNhYmxlZCA9IGZhbHNlLCBvblNlbGVjdCwgLi4uaXRlbVByb3BzIH0gPSBwcm9wcztcbiAgICBjb25zdCByZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gICAgY29uc3Qgcm9vdENvbnRleHQgPSB1c2VNZW51Um9vdENvbnRleHQoSVRFTV9OQU1FLCBwcm9wcy5fX3Njb3BlTWVudSk7XG4gICAgY29uc3QgY29udGVudENvbnRleHQgPSB1c2VNZW51Q29udGVudENvbnRleHQoSVRFTV9OQU1FLCBwcm9wcy5fX3Njb3BlTWVudSk7XG4gICAgY29uc3QgY29tcG9zZWRSZWZzID0gdXNlQ29tcG9zZWRSZWZzKGZvcndhcmRlZFJlZiwgcmVmKTtcbiAgICBjb25zdCBpc1BvaW50ZXJEb3duUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgICBjb25zdCBoYW5kbGVTZWxlY3QgPSAvKiBAX19QVVJFX18gKi8gX19uYW1lKCgpID0+IHtcbiAgICAgIGNvbnN0IG1lbnVJdGVtID0gcmVmLmN1cnJlbnQ7XG4gICAgICBpZiAoIWRpc2FibGVkICYmIG1lbnVJdGVtKSB7XG4gICAgICAgIGNvbnN0IGl0ZW1TZWxlY3RFdmVudCA9IG5ldyBDdXN0b21FdmVudChJVEVNX1NFTEVDVCwgeyBidWJibGVzOiB0cnVlLCBjYW5jZWxhYmxlOiB0cnVlIH0pO1xuICAgICAgICBtZW51SXRlbS5hZGRFdmVudExpc3RlbmVyKElURU1fU0VMRUNULCAoZXZlbnQpID0+IG9uU2VsZWN0Py4oZXZlbnQpLCB7IG9uY2U6IHRydWUgfSk7XG4gICAgICAgIGRpc3BhdGNoRGlzY3JldGVDdXN0b21FdmVudChtZW51SXRlbSwgaXRlbVNlbGVjdEV2ZW50KTtcbiAgICAgICAgaWYgKGl0ZW1TZWxlY3RFdmVudC5kZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICAgICAgaXNQb2ludGVyRG93blJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcm9vdENvbnRleHQub25DbG9zZSgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSwgXCJoYW5kbGVTZWxlY3RcIik7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgICBNZW51SXRlbUltcGwsXG4gICAgICB7XG4gICAgICAgIC4uLml0ZW1Qcm9wcyxcbiAgICAgICAgcmVmOiBjb21wb3NlZFJlZnMsXG4gICAgICAgIGRpc2FibGVkLFxuICAgICAgICBvbkNsaWNrOiBjb21wb3NlRXZlbnRIYW5kbGVycyhwcm9wcy5vbkNsaWNrLCBoYW5kbGVTZWxlY3QpLFxuICAgICAgICBvblBvaW50ZXJEb3duOiAoZXZlbnQpID0+IHtcbiAgICAgICAgICBwcm9wcy5vblBvaW50ZXJEb3duPy4oZXZlbnQpO1xuICAgICAgICAgIGlzUG9pbnRlckRvd25SZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgIH0sXG4gICAgICAgIG9uUG9pbnRlclVwOiBjb21wb3NlRXZlbnRIYW5kbGVycyhwcm9wcy5vblBvaW50ZXJVcCwgKGV2ZW50KSA9PiB7XG4gICAgICAgICAgaWYgKCFpc1BvaW50ZXJEb3duUmVmLmN1cnJlbnQpIGV2ZW50LmN1cnJlbnRUYXJnZXQ/LmNsaWNrKCk7XG4gICAgICAgIH0pLFxuICAgICAgICBvbktleURvd246IGNvbXBvc2VFdmVudEhhbmRsZXJzKHByb3BzLm9uS2V5RG93biwgKGV2ZW50KSA9PiB7XG4gICAgICAgICAgaWYgKGRpc2FibGVkIHx8IGV2ZW50LnRhcmdldCAhPT0gZXZlbnQuY3VycmVudFRhcmdldCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBpc1R5cGluZ0FoZWFkID0gY29udGVudENvbnRleHQuc2VhcmNoUmVmLmN1cnJlbnQgIT09IFwiXCI7XG4gICAgICAgICAgaWYgKGlzVHlwaW5nQWhlYWQgJiYgZXZlbnQua2V5ID09PSBcIiBcIikge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoU0VMRUNUSU9OX0tFWVMuaW5jbHVkZXMoZXZlbnQua2V5KSkge1xuICAgICAgICAgICAgZXZlbnQuY3VycmVudFRhcmdldC5jbGljaygpO1xuICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgKTtcbiAgfSwgXCJNZW51SXRlbVwiKVxuKTtcbnZhciBNZW51SXRlbUltcGwgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBNZW51SXRlbUltcGwyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCB7IF9fc2NvcGVNZW51LCBkaXNhYmxlZCA9IGZhbHNlLCB0ZXh0VmFsdWUsIC4uLml0ZW1Qcm9wcyB9ID0gcHJvcHM7XG4gICAgY29uc3QgY29udGVudENvbnRleHQgPSB1c2VNZW51Q29udGVudENvbnRleHQoSVRFTV9OQU1FLCBfX3Njb3BlTWVudSk7XG4gICAgY29uc3Qgcm92aW5nRm9jdXNHcm91cFNjb3BlID0gdXNlUm92aW5nRm9jdXNHcm91cFNjb3BlKF9fc2NvcGVNZW51KTtcbiAgICBjb25zdCByZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gICAgY29uc3QgY29tcG9zZWRSZWZzID0gdXNlQ29tcG9zZWRSZWZzKGZvcndhcmRlZFJlZiwgcmVmKTtcbiAgICBjb25zdCBbaXNGb2N1c2VkLCBzZXRJc0ZvY3VzZWRdID0gUmVhY3QudXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFt0ZXh0Q29udGVudCwgc2V0VGV4dENvbnRlbnRdID0gUmVhY3QudXNlU3RhdGUoXCJcIik7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgIGNvbnN0IG1lbnVJdGVtID0gcmVmLmN1cnJlbnQ7XG4gICAgICBpZiAobWVudUl0ZW0pIHtcbiAgICAgICAgc2V0VGV4dENvbnRlbnQoKG1lbnVJdGVtLnRleHRDb250ZW50ID8/IFwiXCIpLnRyaW0oKSk7XG4gICAgICB9XG4gICAgfSwgW2l0ZW1Qcm9wcy5jaGlsZHJlbl0pO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgQ29sbGVjdGlvbi5JdGVtU2xvdCxcbiAgICAgIHtcbiAgICAgICAgc2NvcGU6IF9fc2NvcGVNZW51LFxuICAgICAgICBkaXNhYmxlZCxcbiAgICAgICAgdGV4dFZhbHVlOiB0ZXh0VmFsdWUgPz8gdGV4dENvbnRlbnQsXG4gICAgICAgIGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4KFJvdmluZ0ZvY3VzR3JvdXAuSXRlbSwgeyBhc0NoaWxkOiB0cnVlLCAuLi5yb3ZpbmdGb2N1c0dyb3VwU2NvcGUsIGZvY3VzYWJsZTogIWRpc2FibGVkLCBjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgICAgICBQcmltaXRpdmUuZGl2LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHJvbGU6IFwibWVudWl0ZW1cIixcbiAgICAgICAgICAgIFwiZGF0YS1oaWdobGlnaHRlZFwiOiBpc0ZvY3VzZWQgPyBcIlwiIDogdm9pZCAwLFxuICAgICAgICAgICAgXCJhcmlhLWRpc2FibGVkXCI6IGRpc2FibGVkIHx8IHZvaWQgMCxcbiAgICAgICAgICAgIFwiZGF0YS1kaXNhYmxlZFwiOiBkaXNhYmxlZCA/IFwiXCIgOiB2b2lkIDAsXG4gICAgICAgICAgICAuLi5pdGVtUHJvcHMsXG4gICAgICAgICAgICByZWY6IGNvbXBvc2VkUmVmcyxcbiAgICAgICAgICAgIG9uUG9pbnRlck1vdmU6IGNvbXBvc2VFdmVudEhhbmRsZXJzKFxuICAgICAgICAgICAgICBwcm9wcy5vblBvaW50ZXJNb3ZlLFxuICAgICAgICAgICAgICB3aGVuTW91c2UoKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICAgICAgICAgICAgICBjb250ZW50Q29udGV4dC5vbkl0ZW1MZWF2ZShldmVudCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIGNvbnRlbnRDb250ZXh0Lm9uSXRlbUVudGVyKGV2ZW50KTtcbiAgICAgICAgICAgICAgICAgIGlmICghZXZlbnQuZGVmYXVsdFByZXZlbnRlZCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpdGVtID0gZXZlbnQuY3VycmVudFRhcmdldDtcbiAgICAgICAgICAgICAgICAgICAgaXRlbS5mb2N1cyh7IHByZXZlbnRTY3JvbGw6IHRydWUgfSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgKSxcbiAgICAgICAgICAgIG9uUG9pbnRlckxlYXZlOiBjb21wb3NlRXZlbnRIYW5kbGVycyhcbiAgICAgICAgICAgICAgcHJvcHMub25Qb2ludGVyTGVhdmUsXG4gICAgICAgICAgICAgIHdoZW5Nb3VzZSgoZXZlbnQpID0+IGNvbnRlbnRDb250ZXh0Lm9uSXRlbUxlYXZlKGV2ZW50KSlcbiAgICAgICAgICAgICksXG4gICAgICAgICAgICBvbkZvY3VzOiBjb21wb3NlRXZlbnRIYW5kbGVycyhwcm9wcy5vbkZvY3VzLCAoKSA9PiBzZXRJc0ZvY3VzZWQodHJ1ZSkpLFxuICAgICAgICAgICAgb25CbHVyOiBjb21wb3NlRXZlbnRIYW5kbGVycyhwcm9wcy5vbkJsdXIsICgpID0+IHNldElzRm9jdXNlZChmYWxzZSkpXG4gICAgICAgICAgfVxuICAgICAgICApIH0pXG4gICAgICB9XG4gICAgKTtcbiAgfSwgXCJNZW51SXRlbUltcGxcIilcbik7XG52YXIgTWVudUNoZWNrYm94SXRlbSA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvLyBibGFuayBsaW5lIHRvIHJlZHVjZSBkaWZmIG5vaXNlXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gTWVudUNoZWNrYm94SXRlbTIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHsgY2hlY2tlZCA9IGZhbHNlLCBvbkNoZWNrZWRDaGFuZ2UsIC4uLmNoZWNrYm94SXRlbVByb3BzIH0gPSBwcm9wcztcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChJdGVtSW5kaWNhdG9yUHJvdmlkZXIsIHsgc2NvcGU6IHByb3BzLl9fc2NvcGVNZW51LCBjaGVja2VkLCBjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgIE1lbnVJdGVtLFxuICAgICAge1xuICAgICAgICByb2xlOiBcIm1lbnVpdGVtY2hlY2tib3hcIixcbiAgICAgICAgXCJhcmlhLWNoZWNrZWRcIjogaXNJbmRldGVybWluYXRlKGNoZWNrZWQpID8gXCJtaXhlZFwiIDogY2hlY2tlZCxcbiAgICAgICAgLi4uY2hlY2tib3hJdGVtUHJvcHMsXG4gICAgICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgICAgICBcImRhdGEtc3RhdGVcIjogZ2V0Q2hlY2tlZFN0YXRlKGNoZWNrZWQpLFxuICAgICAgICBvblNlbGVjdDogY29tcG9zZUV2ZW50SGFuZGxlcnMoXG4gICAgICAgICAgY2hlY2tib3hJdGVtUHJvcHMub25TZWxlY3QsXG4gICAgICAgICAgKCkgPT4gb25DaGVja2VkQ2hhbmdlPy4oaXNJbmRldGVybWluYXRlKGNoZWNrZWQpID8gdHJ1ZSA6ICFjaGVja2VkKSxcbiAgICAgICAgICB7IGNoZWNrRm9yRGVmYXVsdFByZXZlbnRlZDogZmFsc2UgfVxuICAgICAgICApXG4gICAgICB9XG4gICAgKSB9KTtcbiAgfSwgXCJNZW51Q2hlY2tib3hJdGVtXCIpXG4pO1xudmFyIFJBRElPX0dST1VQX05BTUUgPSBcIk1lbnVSYWRpb0dyb3VwXCI7XG52YXIgW1JhZGlvR3JvdXBQcm92aWRlciwgdXNlUmFkaW9Hcm91cENvbnRleHRdID0gY3JlYXRlTWVudUNvbnRleHQoXG4gIFJBRElPX0dST1VQX05BTUUsXG4gIHsgdmFsdWU6IHZvaWQgMCwgb25WYWx1ZUNoYW5nZTogLyogQF9fUFVSRV9fICovIF9fbmFtZSgoKSA9PiB7XG4gIH0sIFwib25WYWx1ZUNoYW5nZVwiKSB9XG4pO1xudmFyIE1lbnVSYWRpb0dyb3VwID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gTWVudVJhZGlvR3JvdXAyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCB7IHZhbHVlLCBvblZhbHVlQ2hhbmdlLCAuLi5ncm91cFByb3BzIH0gPSBwcm9wcztcbiAgICBjb25zdCBoYW5kbGVWYWx1ZUNoYW5nZSA9IHVzZUNhbGxiYWNrUmVmKG9uVmFsdWVDaGFuZ2UpO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFJhZGlvR3JvdXBQcm92aWRlciwgeyBzY29wZTogcHJvcHMuX19zY29wZU1lbnUsIHZhbHVlLCBvblZhbHVlQ2hhbmdlOiBoYW5kbGVWYWx1ZUNoYW5nZSwgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goTWVudUdyb3VwLCB7IC4uLmdyb3VwUHJvcHMsIHJlZjogZm9yd2FyZGVkUmVmIH0pIH0pO1xuICB9LCBcIk1lbnVSYWRpb0dyb3VwXCIpXG4pO1xudmFyIFJBRElPX0lURU1fTkFNRSA9IFwiTWVudVJhZGlvSXRlbVwiO1xudmFyIE1lbnVSYWRpb0l0ZW0gPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBNZW51UmFkaW9JdGVtMihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gICAgY29uc3QgeyB2YWx1ZSwgLi4ucmFkaW9JdGVtUHJvcHMgfSA9IHByb3BzO1xuICAgIGNvbnN0IGNvbnRleHQgPSB1c2VSYWRpb0dyb3VwQ29udGV4dChSQURJT19JVEVNX05BTUUsIHByb3BzLl9fc2NvcGVNZW51KTtcbiAgICBjb25zdCBjaGVja2VkID0gdmFsdWUgPT09IGNvbnRleHQudmFsdWU7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goSXRlbUluZGljYXRvclByb3ZpZGVyLCB7IHNjb3BlOiBwcm9wcy5fX3Njb3BlTWVudSwgY2hlY2tlZCwgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgICBNZW51SXRlbSxcbiAgICAgIHtcbiAgICAgICAgcm9sZTogXCJtZW51aXRlbXJhZGlvXCIsXG4gICAgICAgIFwiYXJpYS1jaGVja2VkXCI6IGNoZWNrZWQsXG4gICAgICAgIC4uLnJhZGlvSXRlbVByb3BzLFxuICAgICAgICByZWY6IGZvcndhcmRlZFJlZixcbiAgICAgICAgXCJkYXRhLXN0YXRlXCI6IGdldENoZWNrZWRTdGF0ZShjaGVja2VkKSxcbiAgICAgICAgb25TZWxlY3Q6IGNvbXBvc2VFdmVudEhhbmRsZXJzKFxuICAgICAgICAgIHJhZGlvSXRlbVByb3BzLm9uU2VsZWN0LFxuICAgICAgICAgICgpID0+IGNvbnRleHQub25WYWx1ZUNoYW5nZT8uKHZhbHVlKSxcbiAgICAgICAgICB7IGNoZWNrRm9yRGVmYXVsdFByZXZlbnRlZDogZmFsc2UgfVxuICAgICAgICApXG4gICAgICB9XG4gICAgKSB9KTtcbiAgfSwgXCJNZW51UmFkaW9JdGVtXCIpXG4pO1xudmFyIElURU1fSU5ESUNBVE9SX05BTUUgPSBcIk1lbnVJdGVtSW5kaWNhdG9yXCI7XG52YXIgW0l0ZW1JbmRpY2F0b3JQcm92aWRlciwgdXNlSXRlbUluZGljYXRvckNvbnRleHRdID0gY3JlYXRlTWVudUNvbnRleHQoXG4gIElURU1fSU5ESUNBVE9SX05BTUUsXG4gIHsgY2hlY2tlZDogZmFsc2UgfVxuKTtcbnZhciBNZW51SXRlbUluZGljYXRvciA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvLyBibGFuayBsaW5lIHRvIHJlZHVjZSBkaWZmIG5vaXNlXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gTWVudUl0ZW1JbmRpY2F0b3IyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCB7IF9fc2NvcGVNZW51LCBmb3JjZU1vdW50LCAuLi5pdGVtSW5kaWNhdG9yUHJvcHMgfSA9IHByb3BzO1xuICAgIGNvbnN0IGluZGljYXRvckNvbnRleHQgPSB1c2VJdGVtSW5kaWNhdG9yQ29udGV4dChJVEVNX0lORElDQVRPUl9OQU1FLCBfX3Njb3BlTWVudSk7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgICBQcmVzZW5jZSxcbiAgICAgIHtcbiAgICAgICAgcHJlc2VudDogZm9yY2VNb3VudCB8fCBpc0luZGV0ZXJtaW5hdGUoaW5kaWNhdG9yQ29udGV4dC5jaGVja2VkKSB8fCBpbmRpY2F0b3JDb250ZXh0LmNoZWNrZWQgPT09IHRydWUsXG4gICAgICAgIGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgICAgIFByaW1pdGl2ZS5zcGFuLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIC4uLml0ZW1JbmRpY2F0b3JQcm9wcyxcbiAgICAgICAgICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgICAgICAgICAgXCJkYXRhLXN0YXRlXCI6IGdldENoZWNrZWRTdGF0ZShpbmRpY2F0b3JDb250ZXh0LmNoZWNrZWQpXG4gICAgICAgICAgfVxuICAgICAgICApXG4gICAgICB9XG4gICAgKTtcbiAgfSwgXCJNZW51SXRlbUluZGljYXRvclwiKVxuKTtcbnZhciBNZW51U2VwYXJhdG9yID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gTWVudVNlcGFyYXRvcjIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHsgX19zY29wZU1lbnUsIC4uLnNlcGFyYXRvclByb3BzIH0gPSBwcm9wcztcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgIFByaW1pdGl2ZS5kaXYsXG4gICAgICB7XG4gICAgICAgIHJvbGU6IFwic2VwYXJhdG9yXCIsXG4gICAgICAgIFwiYXJpYS1vcmllbnRhdGlvblwiOiBcImhvcml6b250YWxcIixcbiAgICAgICAgLi4uc2VwYXJhdG9yUHJvcHMsXG4gICAgICAgIHJlZjogZm9yd2FyZGVkUmVmXG4gICAgICB9XG4gICAgKTtcbiAgfSwgXCJNZW51U2VwYXJhdG9yXCIpXG4pO1xudmFyIE1lbnVBcnJvdyA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIE1lbnVBcnJvdzIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHsgX19zY29wZU1lbnUsIC4uLmFycm93UHJvcHMgfSA9IHByb3BzO1xuICAgIGNvbnN0IHBvcHBlclNjb3BlID0gdXNlUG9wcGVyU2NvcGUoX19zY29wZU1lbnUpO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFBvcHBlclByaW1pdGl2ZS5BcnJvdywgeyAuLi5wb3BwZXJTY29wZSwgLi4uYXJyb3dQcm9wcywgcmVmOiBmb3J3YXJkZWRSZWYgfSk7XG4gIH0sIFwiTWVudUFycm93XCIpXG4pO1xudmFyIFNVQl9OQU1FID0gXCJNZW51U3ViXCI7XG52YXIgW01lbnVTdWJQcm92aWRlciwgdXNlTWVudVN1YkNvbnRleHRdID0gY3JlYXRlTWVudUNvbnRleHQoU1VCX05BTUUpO1xudmFyIE1lbnVTdWIgPSAvKiBAX19QVVJFX18gKi8gX19uYW1lKChwcm9wcykgPT4ge1xuICBjb25zdCB7IF9fc2NvcGVNZW51LCBjaGlsZHJlbiwgb3BlbiA9IGZhbHNlLCBvbk9wZW5DaGFuZ2UgfSA9IHByb3BzO1xuICBjb25zdCBwYXJlbnRNZW51Q29udGV4dCA9IHVzZU1lbnVDb250ZXh0KFNVQl9OQU1FLCBfX3Njb3BlTWVudSk7XG4gIGNvbnN0IHBvcHBlclNjb3BlID0gdXNlUG9wcGVyU2NvcGUoX19zY29wZU1lbnUpO1xuICBjb25zdCBbdHJpZ2dlciwgc2V0VHJpZ2dlcl0gPSBSZWFjdC51c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW2NvbnRlbnQsIHNldENvbnRlbnRdID0gUmVhY3QudXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IGhhbmRsZU9wZW5DaGFuZ2UgPSB1c2VDYWxsYmFja1JlZihvbk9wZW5DaGFuZ2UpO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChwYXJlbnRNZW51Q29udGV4dC5vcGVuID09PSBmYWxzZSkgaGFuZGxlT3BlbkNoYW5nZShmYWxzZSk7XG4gICAgcmV0dXJuICgpID0+IGhhbmRsZU9wZW5DaGFuZ2UoZmFsc2UpO1xuICB9LCBbcGFyZW50TWVudUNvbnRleHQub3BlbiwgaGFuZGxlT3BlbkNoYW5nZV0pO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChQb3BwZXJQcmltaXRpdmUuUm9vdCwgeyAuLi5wb3BwZXJTY29wZSwgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgTWVudVByb3ZpZGVyLFxuICAgIHtcbiAgICAgIHNjb3BlOiBfX3Njb3BlTWVudSxcbiAgICAgIG9wZW4sXG4gICAgICBvbk9wZW5DaGFuZ2U6IGhhbmRsZU9wZW5DaGFuZ2UsXG4gICAgICBjb250ZW50LFxuICAgICAgb25Db250ZW50Q2hhbmdlOiBzZXRDb250ZW50LFxuICAgICAgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgICAgIE1lbnVTdWJQcm92aWRlcixcbiAgICAgICAge1xuICAgICAgICAgIHNjb3BlOiBfX3Njb3BlTWVudSxcbiAgICAgICAgICBjb250ZW50SWQ6IHVzZUlkKCksXG4gICAgICAgICAgdHJpZ2dlcklkOiB1c2VJZCgpLFxuICAgICAgICAgIHRyaWdnZXIsXG4gICAgICAgICAgb25UcmlnZ2VyQ2hhbmdlOiBzZXRUcmlnZ2VyLFxuICAgICAgICAgIGNoaWxkcmVuXG4gICAgICAgIH1cbiAgICAgIClcbiAgICB9XG4gICkgfSk7XG59LCBcIk1lbnVTdWJcIik7XG52YXIgU1VCX1RSSUdHRVJfTkFNRSA9IFwiTWVudVN1YlRyaWdnZXJcIjtcbnZhciBNZW51U3ViVHJpZ2dlciA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIE1lbnVTdWJUcmlnZ2VyMihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gICAgY29uc3QgY29udGV4dCA9IHVzZU1lbnVDb250ZXh0KFNVQl9UUklHR0VSX05BTUUsIHByb3BzLl9fc2NvcGVNZW51KTtcbiAgICBjb25zdCByb290Q29udGV4dCA9IHVzZU1lbnVSb290Q29udGV4dChTVUJfVFJJR0dFUl9OQU1FLCBwcm9wcy5fX3Njb3BlTWVudSk7XG4gICAgY29uc3Qgc3ViQ29udGV4dCA9IHVzZU1lbnVTdWJDb250ZXh0KFNVQl9UUklHR0VSX05BTUUsIHByb3BzLl9fc2NvcGVNZW51KTtcbiAgICBjb25zdCBjb250ZW50Q29udGV4dCA9IHVzZU1lbnVDb250ZW50Q29udGV4dChTVUJfVFJJR0dFUl9OQU1FLCBwcm9wcy5fX3Njb3BlTWVudSk7XG4gICAgY29uc3Qgb3BlblRpbWVyUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICAgIGNvbnN0IHsgcG9pbnRlckdyYWNlVGltZXJSZWYsIG9uUG9pbnRlckdyYWNlSW50ZW50Q2hhbmdlIH0gPSBjb250ZW50Q29udGV4dDtcbiAgICBjb25zdCBzY29wZSA9IHsgX19zY29wZU1lbnU6IHByb3BzLl9fc2NvcGVNZW51IH07XG4gICAgY29uc3QgY2xlYXJPcGVuVGltZXIgPSBSZWFjdC51c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgICBpZiAob3BlblRpbWVyUmVmLmN1cnJlbnQpIHdpbmRvdy5jbGVhclRpbWVvdXQob3BlblRpbWVyUmVmLmN1cnJlbnQpO1xuICAgICAgb3BlblRpbWVyUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH0sIFtdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4gY2xlYXJPcGVuVGltZXIsIFtjbGVhck9wZW5UaW1lcl0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICBjb25zdCBwb2ludGVyR3JhY2VUaW1lciA9IHBvaW50ZXJHcmFjZVRpbWVyUmVmLmN1cnJlbnQ7XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KHBvaW50ZXJHcmFjZVRpbWVyKTtcbiAgICAgICAgb25Qb2ludGVyR3JhY2VJbnRlbnRDaGFuZ2UobnVsbCk7XG4gICAgICB9O1xuICAgIH0sIFtwb2ludGVyR3JhY2VUaW1lclJlZiwgb25Qb2ludGVyR3JhY2VJbnRlbnRDaGFuZ2VdKTtcbiAgICBjb25zdCBjb21wb3NlZFJlZnMgPSB1c2VDb21wb3NlZFJlZnMoZm9yd2FyZGVkUmVmLCBzdWJDb250ZXh0Lm9uVHJpZ2dlckNoYW5nZSk7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goTWVudUFuY2hvciwgeyBhc0NoaWxkOiB0cnVlLCAuLi5zY29wZSwgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goXG4gICAgICBNZW51SXRlbUltcGwsXG4gICAgICB7XG4gICAgICAgIGlkOiBzdWJDb250ZXh0LnRyaWdnZXJJZCxcbiAgICAgICAgXCJhcmlhLWhhc3BvcHVwXCI6IFwibWVudVwiLFxuICAgICAgICBcImFyaWEtZXhwYW5kZWRcIjogY29udGV4dC5vcGVuLFxuICAgICAgICBcImFyaWEtY29udHJvbHNcIjogY29udGV4dC5vcGVuID8gc3ViQ29udGV4dC5jb250ZW50SWQgOiB2b2lkIDAsXG4gICAgICAgIFwiZGF0YS1zdGF0ZVwiOiBnZXRPcGVuU3RhdGUoY29udGV4dC5vcGVuKSxcbiAgICAgICAgLi4ucHJvcHMsXG4gICAgICAgIHJlZjogY29tcG9zZWRSZWZzLFxuICAgICAgICBvbkNsaWNrOiAoZXZlbnQpID0+IHtcbiAgICAgICAgICBwcm9wcy5vbkNsaWNrPy4oZXZlbnQpO1xuICAgICAgICAgIGlmIChwcm9wcy5kaXNhYmxlZCB8fCBldmVudC5kZWZhdWx0UHJldmVudGVkKSByZXR1cm47XG4gICAgICAgICAgZXZlbnQuY3VycmVudFRhcmdldC5mb2N1cygpO1xuICAgICAgICAgIGlmICghY29udGV4dC5vcGVuKSBjb250ZXh0Lm9uT3BlbkNoYW5nZSh0cnVlKTtcbiAgICAgICAgfSxcbiAgICAgICAgb25Qb2ludGVyTW92ZTogY29tcG9zZUV2ZW50SGFuZGxlcnMoXG4gICAgICAgICAgcHJvcHMub25Qb2ludGVyTW92ZSxcbiAgICAgICAgICB3aGVuTW91c2UoKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICBjb250ZW50Q29udGV4dC5vbkl0ZW1FbnRlcihldmVudCk7XG4gICAgICAgICAgICBpZiAoZXZlbnQuZGVmYXVsdFByZXZlbnRlZCkgcmV0dXJuO1xuICAgICAgICAgICAgaWYgKCFwcm9wcy5kaXNhYmxlZCAmJiAhY29udGV4dC5vcGVuICYmICFvcGVuVGltZXJSZWYuY3VycmVudCkge1xuICAgICAgICAgICAgICBjb250ZW50Q29udGV4dC5vblBvaW50ZXJHcmFjZUludGVudENoYW5nZShudWxsKTtcbiAgICAgICAgICAgICAgb3BlblRpbWVyUmVmLmN1cnJlbnQgPSB3aW5kb3cuc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29udGV4dC5vbk9wZW5DaGFuZ2UodHJ1ZSk7XG4gICAgICAgICAgICAgICAgY2xlYXJPcGVuVGltZXIoKTtcbiAgICAgICAgICAgICAgfSwgMTAwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KVxuICAgICAgICApLFxuICAgICAgICBvblBvaW50ZXJMZWF2ZTogY29tcG9zZUV2ZW50SGFuZGxlcnMoXG4gICAgICAgICAgcHJvcHMub25Qb2ludGVyTGVhdmUsXG4gICAgICAgICAgd2hlbk1vdXNlKChldmVudCkgPT4ge1xuICAgICAgICAgICAgY2xlYXJPcGVuVGltZXIoKTtcbiAgICAgICAgICAgIGNvbnN0IGNvbnRlbnRSZWN0ID0gY29udGV4dC5jb250ZW50Py5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgICAgIGlmIChjb250ZW50UmVjdCkge1xuICAgICAgICAgICAgICBjb25zdCBzaWRlID0gY29udGV4dC5jb250ZW50Py5kYXRhc2V0LnNpZGU7XG4gICAgICAgICAgICAgIGNvbnN0IHJpZ2h0U2lkZSA9IHNpZGUgPT09IFwicmlnaHRcIjtcbiAgICAgICAgICAgICAgY29uc3QgYmxlZWQgPSByaWdodFNpZGUgPyAtNSA6IDU7XG4gICAgICAgICAgICAgIGNvbnN0IGNvbnRlbnROZWFyRWRnZSA9IGNvbnRlbnRSZWN0W3JpZ2h0U2lkZSA/IFwibGVmdFwiIDogXCJyaWdodFwiXTtcbiAgICAgICAgICAgICAgY29uc3QgY29udGVudEZhckVkZ2UgPSBjb250ZW50UmVjdFtyaWdodFNpZGUgPyBcInJpZ2h0XCIgOiBcImxlZnRcIl07XG4gICAgICAgICAgICAgIGNvbnRlbnRDb250ZXh0Lm9uUG9pbnRlckdyYWNlSW50ZW50Q2hhbmdlKHtcbiAgICAgICAgICAgICAgICBhcmVhOiBbXG4gICAgICAgICAgICAgICAgICAvLyBBcHBseSBhIGJsZWVkIG9uIGNsaWVudFggdG8gZW5zdXJlIHRoYXQgb3VyIGV4aXQgcG9pbnQgaXNcbiAgICAgICAgICAgICAgICAgIC8vIGNvbnNpc3RlbnRseSB3aXRoaW4gcG9seWdvbiBib3VuZHNcbiAgICAgICAgICAgICAgICAgIHsgeDogZXZlbnQuY2xpZW50WCArIGJsZWVkLCB5OiBldmVudC5jbGllbnRZIH0sXG4gICAgICAgICAgICAgICAgICB7IHg6IGNvbnRlbnROZWFyRWRnZSwgeTogY29udGVudFJlY3QudG9wIH0sXG4gICAgICAgICAgICAgICAgICB7IHg6IGNvbnRlbnRGYXJFZGdlLCB5OiBjb250ZW50UmVjdC50b3AgfSxcbiAgICAgICAgICAgICAgICAgIHsgeDogY29udGVudEZhckVkZ2UsIHk6IGNvbnRlbnRSZWN0LmJvdHRvbSB9LFxuICAgICAgICAgICAgICAgICAgeyB4OiBjb250ZW50TmVhckVkZ2UsIHk6IGNvbnRlbnRSZWN0LmJvdHRvbSB9XG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICBzaWRlXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KHBvaW50ZXJHcmFjZVRpbWVyUmVmLmN1cnJlbnQpO1xuICAgICAgICAgICAgICBwb2ludGVyR3JhY2VUaW1lclJlZi5jdXJyZW50ID0gd2luZG93LnNldFRpbWVvdXQoXG4gICAgICAgICAgICAgICAgKCkgPT4gY29udGVudENvbnRleHQub25Qb2ludGVyR3JhY2VJbnRlbnRDaGFuZ2UobnVsbCksXG4gICAgICAgICAgICAgICAgMzAwXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBjb250ZW50Q29udGV4dC5vblRyaWdnZXJMZWF2ZShldmVudCk7XG4gICAgICAgICAgICAgIGlmIChldmVudC5kZWZhdWx0UHJldmVudGVkKSByZXR1cm47XG4gICAgICAgICAgICAgIGNvbnRlbnRDb250ZXh0Lm9uUG9pbnRlckdyYWNlSW50ZW50Q2hhbmdlKG51bGwpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pXG4gICAgICAgICksXG4gICAgICAgIG9uS2V5RG93bjogY29tcG9zZUV2ZW50SGFuZGxlcnMocHJvcHMub25LZXlEb3duLCAoZXZlbnQpID0+IHtcbiAgICAgICAgICBpZiAocHJvcHMuZGlzYWJsZWQgfHwgZXZlbnQudGFyZ2V0ICE9PSBldmVudC5jdXJyZW50VGFyZ2V0KSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IGlzVHlwaW5nQWhlYWQgPSBjb250ZW50Q29udGV4dC5zZWFyY2hSZWYuY3VycmVudCAhPT0gXCJcIjtcbiAgICAgICAgICBpZiAoaXNUeXBpbmdBaGVhZCAmJiBldmVudC5rZXkgPT09IFwiIFwiKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChTVUJfT1BFTl9LRVlTW3Jvb3RDb250ZXh0LmRpcl0uaW5jbHVkZXMoZXZlbnQua2V5KSkge1xuICAgICAgICAgICAgY29udGV4dC5vbk9wZW5DaGFuZ2UodHJ1ZSk7XG4gICAgICAgICAgICBjb250ZXh0LmNvbnRlbnQ/LmZvY3VzKCk7XG4gICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICApIH0pO1xuICB9LCBcIk1lbnVTdWJUcmlnZ2VyXCIpXG4pO1xudmFyIFNVQl9DT05URU5UX05BTUUgPSBcIk1lbnVTdWJDb250ZW50XCI7XG52YXIgTWVudVN1YkNvbnRlbnQgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBNZW51U3ViQ29udGVudDIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAgIGNvbnN0IHBvcnRhbENvbnRleHQgPSB1c2VQb3J0YWxDb250ZXh0KENPTlRFTlRfTkFNRSwgcHJvcHMuX19zY29wZU1lbnUpO1xuICAgIGNvbnN0IHsgZm9yY2VNb3VudCA9IHBvcnRhbENvbnRleHQuZm9yY2VNb3VudCwgYWxpZ24gPSBcInN0YXJ0XCIsIC4uLnN1YkNvbnRlbnRQcm9wcyB9ID0gcHJvcHM7XG4gICAgY29uc3QgY29udGV4dCA9IHVzZU1lbnVDb250ZXh0KENPTlRFTlRfTkFNRSwgcHJvcHMuX19zY29wZU1lbnUpO1xuICAgIGNvbnN0IHJvb3RDb250ZXh0ID0gdXNlTWVudVJvb3RDb250ZXh0KENPTlRFTlRfTkFNRSwgcHJvcHMuX19zY29wZU1lbnUpO1xuICAgIGNvbnN0IHN1YkNvbnRleHQgPSB1c2VNZW51U3ViQ29udGV4dChTVUJfQ09OVEVOVF9OQU1FLCBwcm9wcy5fX3Njb3BlTWVudSk7XG4gICAgY29uc3QgcmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICAgIGNvbnN0IGNvbXBvc2VkUmVmcyA9IHVzZUNvbXBvc2VkUmVmcyhmb3J3YXJkZWRSZWYsIHJlZik7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goQ29sbGVjdGlvbi5Qcm92aWRlciwgeyBzY29wZTogcHJvcHMuX19zY29wZU1lbnUsIGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4KFByZXNlbmNlLCB7IHByZXNlbnQ6IGZvcmNlTW91bnQgfHwgY29udGV4dC5vcGVuLCBjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGpzeChDb2xsZWN0aW9uLlNsb3QsIHsgc2NvcGU6IHByb3BzLl9fc2NvcGVNZW51LCBjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgIE1lbnVDb250ZW50SW1wbCxcbiAgICAgIHtcbiAgICAgICAgaWQ6IHN1YkNvbnRleHQuY29udGVudElkLFxuICAgICAgICBcImFyaWEtbGFiZWxsZWRieVwiOiBzdWJDb250ZXh0LnRyaWdnZXJJZCxcbiAgICAgICAgLi4uc3ViQ29udGVudFByb3BzLFxuICAgICAgICByZWY6IGNvbXBvc2VkUmVmcyxcbiAgICAgICAgYWxpZ24sXG4gICAgICAgIHNpZGU6IHJvb3RDb250ZXh0LmRpciA9PT0gXCJydGxcIiA/IFwibGVmdFwiIDogXCJyaWdodFwiLFxuICAgICAgICBkaXNhYmxlT3V0c2lkZVBvaW50ZXJFdmVudHM6IGZhbHNlLFxuICAgICAgICBkaXNhYmxlT3V0c2lkZVNjcm9sbDogZmFsc2UsXG4gICAgICAgIHRyYXBGb2N1czogZmFsc2UsXG4gICAgICAgIG9uT3BlbkF1dG9Gb2N1czogKGV2ZW50KSA9PiB7XG4gICAgICAgICAgaWYgKHJvb3RDb250ZXh0LmlzVXNpbmdLZXlib2FyZFJlZi5jdXJyZW50KSByZWYuY3VycmVudD8uZm9jdXMoKTtcbiAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICB9LFxuICAgICAgICBvbkNsb3NlQXV0b0ZvY3VzOiAoZXZlbnQpID0+IGV2ZW50LnByZXZlbnREZWZhdWx0KCksXG4gICAgICAgIG9uRm9jdXNPdXRzaWRlOiBjb21wb3NlRXZlbnRIYW5kbGVycyhwcm9wcy5vbkZvY3VzT3V0c2lkZSwgKGV2ZW50KSA9PiB7XG4gICAgICAgICAgaWYgKGV2ZW50LnRhcmdldCAhPT0gc3ViQ29udGV4dC50cmlnZ2VyKSBjb250ZXh0Lm9uT3BlbkNoYW5nZShmYWxzZSk7XG4gICAgICAgIH0pLFxuICAgICAgICBvbkVzY2FwZUtleURvd246IGNvbXBvc2VFdmVudEhhbmRsZXJzKHByb3BzLm9uRXNjYXBlS2V5RG93biwgKGV2ZW50KSA9PiB7XG4gICAgICAgICAgcm9vdENvbnRleHQub25DbG9zZSgpO1xuICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIH0pLFxuICAgICAgICBvbktleURvd246IGNvbXBvc2VFdmVudEhhbmRsZXJzKHByb3BzLm9uS2V5RG93biwgKGV2ZW50KSA9PiB7XG4gICAgICAgICAgY29uc3QgaXNLZXlEb3duSW5zaWRlID0gZXZlbnQuY3VycmVudFRhcmdldC5jb250YWlucyhldmVudC50YXJnZXQpO1xuICAgICAgICAgIGNvbnN0IGlzQ2xvc2VLZXkgPSBTVUJfQ0xPU0VfS0VZU1tyb290Q29udGV4dC5kaXJdLmluY2x1ZGVzKGV2ZW50LmtleSk7XG4gICAgICAgICAgaWYgKGlzS2V5RG93bkluc2lkZSAmJiBpc0Nsb3NlS2V5KSB7XG4gICAgICAgICAgICBjb250ZXh0Lm9uT3BlbkNoYW5nZShmYWxzZSk7XG4gICAgICAgICAgICBzdWJDb250ZXh0LnRyaWdnZXI/LmZvY3VzKCk7XG4gICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICApIH0pIH0pIH0pO1xuICB9LCBcIk1lbnVTdWJDb250ZW50XCIpXG4pO1xuZnVuY3Rpb24gZ2V0T3BlblN0YXRlKG9wZW4pIHtcbiAgcmV0dXJuIG9wZW4gPyBcIm9wZW5cIiA6IFwiY2xvc2VkXCI7XG59XG5fX25hbWUoZ2V0T3BlblN0YXRlLCBcImdldE9wZW5TdGF0ZVwiKTtcbmZ1bmN0aW9uIGlzSW5kZXRlcm1pbmF0ZShjaGVja2VkKSB7XG4gIHJldHVybiBjaGVja2VkID09PSBcImluZGV0ZXJtaW5hdGVcIjtcbn1cbl9fbmFtZShpc0luZGV0ZXJtaW5hdGUsIFwiaXNJbmRldGVybWluYXRlXCIpO1xuZnVuY3Rpb24gZ2V0Q2hlY2tlZFN0YXRlKGNoZWNrZWQpIHtcbiAgcmV0dXJuIGlzSW5kZXRlcm1pbmF0ZShjaGVja2VkKSA/IFwiaW5kZXRlcm1pbmF0ZVwiIDogY2hlY2tlZCA/IFwiY2hlY2tlZFwiIDogXCJ1bmNoZWNrZWRcIjtcbn1cbl9fbmFtZShnZXRDaGVja2VkU3RhdGUsIFwiZ2V0Q2hlY2tlZFN0YXRlXCIpO1xuZnVuY3Rpb24gZm9jdXNGaXJzdChjYW5kaWRhdGVzKSB7XG4gIGNvbnN0IFBSRVZJT1VTTFlfRk9DVVNFRF9FTEVNRU5UID0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudDtcbiAgZm9yIChjb25zdCBjYW5kaWRhdGUgb2YgY2FuZGlkYXRlcykge1xuICAgIGlmIChjYW5kaWRhdGUgPT09IFBSRVZJT1VTTFlfRk9DVVNFRF9FTEVNRU5UKSByZXR1cm47XG4gICAgY2FuZGlkYXRlLmZvY3VzKCk7XG4gICAgaWYgKGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgIT09IFBSRVZJT1VTTFlfRk9DVVNFRF9FTEVNRU5UKSByZXR1cm47XG4gIH1cbn1cbl9fbmFtZShmb2N1c0ZpcnN0LCBcImZvY3VzRmlyc3RcIik7XG5mdW5jdGlvbiB3cmFwQXJyYXkoYXJyYXksIHN0YXJ0SW5kZXgpIHtcbiAgcmV0dXJuIGFycmF5Lm1hcCgoXywgaW5kZXgpID0+IGFycmF5WyhzdGFydEluZGV4ICsgaW5kZXgpICUgYXJyYXkubGVuZ3RoXSk7XG59XG5fX25hbWUod3JhcEFycmF5LCBcIndyYXBBcnJheVwiKTtcbmZ1bmN0aW9uIGdldE5leHRNYXRjaCh2YWx1ZXMsIHNlYXJjaCwgY3VycmVudE1hdGNoKSB7XG4gIGNvbnN0IGlzUmVwZWF0ZWQgPSBzZWFyY2gubGVuZ3RoID4gMSAmJiBBcnJheS5mcm9tKHNlYXJjaCkuZXZlcnkoKGNoYXIpID0+IGNoYXIgPT09IHNlYXJjaFswXSk7XG4gIGNvbnN0IG5vcm1hbGl6ZWRTZWFyY2ggPSBpc1JlcGVhdGVkID8gc2VhcmNoWzBdIDogc2VhcmNoO1xuICBjb25zdCBjdXJyZW50TWF0Y2hJbmRleCA9IGN1cnJlbnRNYXRjaCA/IHZhbHVlcy5pbmRleE9mKGN1cnJlbnRNYXRjaCkgOiAtMTtcbiAgbGV0IHdyYXBwZWRWYWx1ZXMgPSB3cmFwQXJyYXkodmFsdWVzLCBNYXRoLm1heChjdXJyZW50TWF0Y2hJbmRleCwgMCkpO1xuICBjb25zdCBleGNsdWRlQ3VycmVudE1hdGNoID0gbm9ybWFsaXplZFNlYXJjaC5sZW5ndGggPT09IDE7XG4gIGlmIChleGNsdWRlQ3VycmVudE1hdGNoKSB3cmFwcGVkVmFsdWVzID0gd3JhcHBlZFZhbHVlcy5maWx0ZXIoKHYpID0+IHYgIT09IGN1cnJlbnRNYXRjaCk7XG4gIGNvbnN0IG5leHRNYXRjaCA9IHdyYXBwZWRWYWx1ZXMuZmluZChcbiAgICAodmFsdWUpID0+IHZhbHVlLnRvTG93ZXJDYXNlKCkuc3RhcnRzV2l0aChub3JtYWxpemVkU2VhcmNoLnRvTG93ZXJDYXNlKCkpXG4gICk7XG4gIHJldHVybiBuZXh0TWF0Y2ggIT09IGN1cnJlbnRNYXRjaCA/IG5leHRNYXRjaCA6IHZvaWQgMDtcbn1cbl9fbmFtZShnZXROZXh0TWF0Y2gsIFwiZ2V0TmV4dE1hdGNoXCIpO1xuZnVuY3Rpb24gaXNQb2ludEluUG9seWdvbihwb2ludCwgcG9seWdvbikge1xuICBjb25zdCB7IHgsIHkgfSA9IHBvaW50O1xuICBsZXQgaW5zaWRlID0gZmFsc2U7XG4gIGZvciAobGV0IGkgPSAwLCBqID0gcG9seWdvbi5sZW5ndGggLSAxOyBpIDwgcG9seWdvbi5sZW5ndGg7IGogPSBpKyspIHtcbiAgICBjb25zdCBpaSA9IHBvbHlnb25baV07XG4gICAgY29uc3QgamogPSBwb2x5Z29uW2pdO1xuICAgIGNvbnN0IHhpID0gaWkueDtcbiAgICBjb25zdCB5aSA9IGlpLnk7XG4gICAgY29uc3QgeGogPSBqai54O1xuICAgIGNvbnN0IHlqID0gamoueTtcbiAgICBjb25zdCBpbnRlcnNlY3QgPSB5aSA+IHkgIT09IHlqID4geSAmJiB4IDwgKHhqIC0geGkpICogKHkgLSB5aSkgLyAoeWogLSB5aSkgKyB4aTtcbiAgICBpZiAoaW50ZXJzZWN0KSBpbnNpZGUgPSAhaW5zaWRlO1xuICB9XG4gIHJldHVybiBpbnNpZGU7XG59XG5fX25hbWUoaXNQb2ludEluUG9seWdvbiwgXCJpc1BvaW50SW5Qb2x5Z29uXCIpO1xuZnVuY3Rpb24gaXNQb2ludGVySW5HcmFjZUFyZWEoZXZlbnQsIGFyZWEpIHtcbiAgaWYgKCFhcmVhKSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IGN1cnNvclBvcyA9IHsgeDogZXZlbnQuY2xpZW50WCwgeTogZXZlbnQuY2xpZW50WSB9O1xuICByZXR1cm4gaXNQb2ludEluUG9seWdvbihjdXJzb3JQb3MsIGFyZWEpO1xufVxuX19uYW1lKGlzUG9pbnRlckluR3JhY2VBcmVhLCBcImlzUG9pbnRlckluR3JhY2VBcmVhXCIpO1xuZnVuY3Rpb24gd2hlbk1vdXNlKGhhbmRsZXIpIHtcbiAgcmV0dXJuIChldmVudCkgPT4gZXZlbnQucG9pbnRlclR5cGUgPT09IFwibW91c2VcIiA/IGhhbmRsZXIoZXZlbnQpIDogdm9pZCAwO1xufVxuX19uYW1lKHdoZW5Nb3VzZSwgXCJ3aGVuTW91c2VcIik7XG52YXIgUm9vdDMgPSBNZW51O1xudmFyIEFuY2hvcjIgPSBNZW51QW5jaG9yO1xudmFyIFBvcnRhbCA9IE1lbnVQb3J0YWw7XG52YXIgQ29udGVudDIgPSBNZW51Q29udGVudDtcbnZhciBHcm91cCA9IE1lbnVHcm91cDtcbnZhciBMYWJlbCA9IE1lbnVMYWJlbDtcbnZhciBJdGVtMiA9IE1lbnVJdGVtO1xudmFyIENoZWNrYm94SXRlbSA9IE1lbnVDaGVja2JveEl0ZW07XG52YXIgUmFkaW9Hcm91cCA9IE1lbnVSYWRpb0dyb3VwO1xudmFyIFJhZGlvSXRlbSA9IE1lbnVSYWRpb0l0ZW07XG52YXIgSXRlbUluZGljYXRvciA9IE1lbnVJdGVtSW5kaWNhdG9yO1xudmFyIFNlcGFyYXRvciA9IE1lbnVTZXBhcmF0b3I7XG52YXIgQXJyb3cyID0gTWVudUFycm93O1xudmFyIFN1YiA9IE1lbnVTdWI7XG52YXIgU3ViVHJpZ2dlciA9IE1lbnVTdWJUcmlnZ2VyO1xudmFyIFN1YkNvbnRlbnQgPSBNZW51U3ViQ29udGVudDtcbmV4cG9ydCB7XG4gIEFuY2hvcjIgYXMgQW5jaG9yLFxuICBBcnJvdzIgYXMgQXJyb3csXG4gIENoZWNrYm94SXRlbSxcbiAgQ29udGVudDIgYXMgQ29udGVudCxcbiAgR3JvdXAsXG4gIEl0ZW0yIGFzIEl0ZW0sXG4gIEl0ZW1JbmRpY2F0b3IsXG4gIExhYmVsLFxuICBNZW51LFxuICBNZW51QW5jaG9yLFxuICBNZW51QXJyb3csXG4gIE1lbnVDaGVja2JveEl0ZW0sXG4gIE1lbnVDb250ZW50LFxuICBNZW51R3JvdXAsXG4gIE1lbnVJdGVtLFxuICBNZW51SXRlbUluZGljYXRvcixcbiAgTWVudUxhYmVsLFxuICBNZW51UG9ydGFsLFxuICBNZW51UmFkaW9Hcm91cCxcbiAgTWVudVJhZGlvSXRlbSxcbiAgTWVudVNlcGFyYXRvcixcbiAgTWVudVN1YixcbiAgTWVudVN1YkNvbnRlbnQsXG4gIE1lbnVTdWJUcmlnZ2VyLFxuICBQb3J0YWwsXG4gIFJhZGlvR3JvdXAsXG4gIFJhZGlvSXRlbSxcbiAgUm9vdDMgYXMgUm9vdCxcbiAgU2VwYXJhdG9yLFxuICBTdWIsXG4gIFN1YkNvbnRlbnQsXG4gIFN1YlRyaWdnZXIsXG4gIGNyZWF0ZU1lbnVTY29wZVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4Lm1qcy5tYXBcbiIsIlwidXNlIGNsaWVudFwiO1xudmFyIF9fZGVmUHJvcCA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX25hbWUgPSAodGFyZ2V0LCB2YWx1ZSkgPT4gX19kZWZQcm9wKHRhcmdldCwgXCJuYW1lXCIsIHsgdmFsdWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSB9KTtcblxuLy8gc3JjL2Ryb3Bkb3duLW1lbnUudHN4XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNvbXBvc2VFdmVudEhhbmRsZXJzIH0gZnJvbSBcIkByYWRpeC11aS9wcmltaXRpdmVcIjtcbmltcG9ydCB7IHVzZUNvbXBvc2VkUmVmcyB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtY29tcG9zZS1yZWZzXCI7XG5pbXBvcnQgeyBjcmVhdGVDb250ZXh0U2NvcGUgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LWNvbnRleHRcIjtcbmltcG9ydCB7IHVzZUNvbnRyb2xsYWJsZVN0YXRlIH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC11c2UtY29udHJvbGxhYmxlLXN0YXRlXCI7XG5pbXBvcnQgeyBQcmltaXRpdmUgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LXByaW1pdGl2ZVwiO1xuaW1wb3J0ICogYXMgTWVudVByaW1pdGl2ZSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LW1lbnVcIjtcbmltcG9ydCB7IGNyZWF0ZU1lbnVTY29wZSB9IGZyb20gXCJAcmFkaXgtdWkvcmVhY3QtbWVudVwiO1xuaW1wb3J0IHsgdXNlSWQgfSBmcm9tIFwiQHJhZGl4LXVpL3JlYWN0LWlkXCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbnZhciBEUk9QRE9XTl9NRU5VX05BTUUgPSBcIkRyb3Bkb3duTWVudVwiO1xudmFyIFtjcmVhdGVEcm9wZG93bk1lbnVDb250ZXh0LCBjcmVhdGVEcm9wZG93bk1lbnVTY29wZV0gPSBjcmVhdGVDb250ZXh0U2NvcGUoXG4gIERST1BET1dOX01FTlVfTkFNRSxcbiAgW2NyZWF0ZU1lbnVTY29wZV1cbik7XG52YXIgdXNlTWVudVNjb3BlID0gY3JlYXRlTWVudVNjb3BlKCk7XG52YXIgW0Ryb3Bkb3duTWVudVByb3ZpZGVyLCB1c2VEcm9wZG93bk1lbnVDb250ZXh0XSA9IGNyZWF0ZURyb3Bkb3duTWVudUNvbnRleHQoRFJPUERPV05fTUVOVV9OQU1FKTtcbnZhciBEcm9wZG93bk1lbnUgPSAvKiBAX19QVVJFX18gKi8gX19uYW1lKChwcm9wcykgPT4ge1xuICBjb25zdCB7XG4gICAgX19zY29wZURyb3Bkb3duTWVudSxcbiAgICBjaGlsZHJlbixcbiAgICBkaXIsXG4gICAgb3Blbjogb3BlblByb3AsXG4gICAgZGVmYXVsdE9wZW4sXG4gICAgb25PcGVuQ2hhbmdlLFxuICAgIG1vZGFsID0gdHJ1ZVxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IG1lbnVTY29wZSA9IHVzZU1lbnVTY29wZShfX3Njb3BlRHJvcGRvd25NZW51KTtcbiAgY29uc3QgdHJpZ2dlclJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlQ29udHJvbGxhYmxlU3RhdGUoe1xuICAgIHByb3A6IG9wZW5Qcm9wLFxuICAgIGRlZmF1bHRQcm9wOiBkZWZhdWx0T3BlbiA/PyBmYWxzZSxcbiAgICBvbkNoYW5nZTogb25PcGVuQ2hhbmdlLFxuICAgIGNhbGxlcjogRFJPUERPV05fTUVOVV9OQU1FXG4gIH0pO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcbiAgICBEcm9wZG93bk1lbnVQcm92aWRlcixcbiAgICB7XG4gICAgICBzY29wZTogX19zY29wZURyb3Bkb3duTWVudSxcbiAgICAgIHRyaWdnZXJJZDogdXNlSWQoKSxcbiAgICAgIHRyaWdnZXJSZWYsXG4gICAgICBjb250ZW50SWQ6IHVzZUlkKCksXG4gICAgICBvcGVuLFxuICAgICAgb25PcGVuQ2hhbmdlOiBzZXRPcGVuLFxuICAgICAgb25PcGVuVG9nZ2xlOiBSZWFjdC51c2VDYWxsYmFjaygoKSA9PiBzZXRPcGVuKChwcmV2T3BlbikgPT4gIXByZXZPcGVuKSwgW3NldE9wZW5dKSxcbiAgICAgIG1vZGFsLFxuICAgICAgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goTWVudVByaW1pdGl2ZS5Sb290LCB7IC4uLm1lbnVTY29wZSwgb3Blbiwgb25PcGVuQ2hhbmdlOiBzZXRPcGVuLCBkaXIsIG1vZGFsLCBjaGlsZHJlbiB9KVxuICAgIH1cbiAgKTtcbn0sIFwiRHJvcGRvd25NZW51XCIpO1xudmFyIFRSSUdHRVJfTkFNRSA9IFwiRHJvcGRvd25NZW51VHJpZ2dlclwiO1xudmFyIERyb3Bkb3duTWVudVRyaWdnZXIgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLy8gYmxhbmsgbGluZSB0byByZWR1Y2UgZGlmZiBub2lzZVxuICAvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIERyb3Bkb3duTWVudVRyaWdnZXIyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCB7IF9fc2NvcGVEcm9wZG93bk1lbnUsIGRpc2FibGVkID0gZmFsc2UsIC4uLnRyaWdnZXJQcm9wcyB9ID0gcHJvcHM7XG4gICAgY29uc3QgY29udGV4dCA9IHVzZURyb3Bkb3duTWVudUNvbnRleHQoVFJJR0dFUl9OQU1FLCBfX3Njb3BlRHJvcGRvd25NZW51KTtcbiAgICBjb25zdCBtZW51U2NvcGUgPSB1c2VNZW51U2NvcGUoX19zY29wZURyb3Bkb3duTWVudSk7XG4gICAgY29uc3QgY29tcG9zZWRSZWZzID0gdXNlQ29tcG9zZWRSZWZzKGZvcndhcmRlZFJlZiwgY29udGV4dC50cmlnZ2VyUmVmKTtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChNZW51UHJpbWl0aXZlLkFuY2hvciwgeyBhc0NoaWxkOiB0cnVlLCAuLi5tZW51U2NvcGUsIGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgICAgUHJpbWl0aXZlLmJ1dHRvbixcbiAgICAgIHtcbiAgICAgICAgdHlwZTogXCJidXR0b25cIixcbiAgICAgICAgaWQ6IGNvbnRleHQudHJpZ2dlcklkLFxuICAgICAgICBcImFyaWEtaGFzcG9wdXBcIjogXCJtZW51XCIsXG4gICAgICAgIFwiYXJpYS1leHBhbmRlZFwiOiBjb250ZXh0Lm9wZW4sXG4gICAgICAgIFwiYXJpYS1jb250cm9sc1wiOiBjb250ZXh0Lm9wZW4gPyBjb250ZXh0LmNvbnRlbnRJZCA6IHZvaWQgMCxcbiAgICAgICAgXCJkYXRhLXN0YXRlXCI6IGNvbnRleHQub3BlbiA/IFwib3BlblwiIDogXCJjbG9zZWRcIixcbiAgICAgICAgXCJkYXRhLWRpc2FibGVkXCI6IGRpc2FibGVkID8gXCJcIiA6IHZvaWQgMCxcbiAgICAgICAgZGlzYWJsZWQsXG4gICAgICAgIC4uLnRyaWdnZXJQcm9wcyxcbiAgICAgICAgcmVmOiBjb21wb3NlZFJlZnMsXG4gICAgICAgIG9uUG9pbnRlckRvd246IGNvbXBvc2VFdmVudEhhbmRsZXJzKHByb3BzLm9uUG9pbnRlckRvd24sIChldmVudCkgPT4ge1xuICAgICAgICAgIGlmICghZGlzYWJsZWQgJiYgZXZlbnQuYnV0dG9uID09PSAwICYmIGV2ZW50LmN0cmxLZXkgPT09IGZhbHNlKSB7XG4gICAgICAgICAgICBjb250ZXh0Lm9uT3BlblRvZ2dsZSgpO1xuICAgICAgICAgICAgaWYgKCFjb250ZXh0Lm9wZW4pIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgfVxuICAgICAgICB9KSxcbiAgICAgICAgb25LZXlEb3duOiBjb21wb3NlRXZlbnRIYW5kbGVycyhwcm9wcy5vbktleURvd24sIChldmVudCkgPT4ge1xuICAgICAgICAgIGlmIChkaXNhYmxlZCkgcmV0dXJuO1xuICAgICAgICAgIGlmIChbXCJFbnRlclwiLCBcIiBcIl0uaW5jbHVkZXMoZXZlbnQua2V5KSkgY29udGV4dC5vbk9wZW5Ub2dnbGUoKTtcbiAgICAgICAgICBpZiAoZXZlbnQua2V5ID09PSBcIkFycm93RG93blwiKSBjb250ZXh0Lm9uT3BlbkNoYW5nZSh0cnVlKTtcbiAgICAgICAgICBpZiAoW1wiRW50ZXJcIiwgXCIgXCIsIFwiQXJyb3dEb3duXCJdLmluY2x1ZGVzKGV2ZW50LmtleSkpIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgKSB9KTtcbiAgfSwgXCJEcm9wZG93bk1lbnVUcmlnZ2VyXCIpXG4pO1xudmFyIERyb3Bkb3duTWVudVBvcnRhbCA9IC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoKHByb3BzKSA9PiB7XG4gIGNvbnN0IHsgX19zY29wZURyb3Bkb3duTWVudSwgLi4ucG9ydGFsUHJvcHMgfSA9IHByb3BzO1xuICBjb25zdCBtZW51U2NvcGUgPSB1c2VNZW51U2NvcGUoX19zY29wZURyb3Bkb3duTWVudSk7XG4gIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KE1lbnVQcmltaXRpdmUuUG9ydGFsLCB7IC4uLm1lbnVTY29wZSwgLi4ucG9ydGFsUHJvcHMgfSk7XG59LCBcIkRyb3Bkb3duTWVudVBvcnRhbFwiKTtcbnZhciBDT05URU5UX05BTUUgPSBcIkRyb3Bkb3duTWVudUNvbnRlbnRcIjtcbnZhciBEcm9wZG93bk1lbnVDb250ZW50ID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoXG4gIC8vIGJsYW5rIGxpbmUgdG8gcmVkdWNlIGRpZmYgbm9pc2VcbiAgLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBEcm9wZG93bk1lbnVDb250ZW50Mihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gICAgY29uc3QgeyBfX3Njb3BlRHJvcGRvd25NZW51LCAuLi5jb250ZW50UHJvcHMgfSA9IHByb3BzO1xuICAgIGNvbnN0IGNvbnRleHQgPSB1c2VEcm9wZG93bk1lbnVDb250ZXh0KENPTlRFTlRfTkFNRSwgX19zY29wZURyb3Bkb3duTWVudSk7XG4gICAgY29uc3QgbWVudVNjb3BlID0gdXNlTWVudVNjb3BlKF9fc2NvcGVEcm9wZG93bk1lbnUpO1xuICAgIGNvbnN0IGhhc0ludGVyYWN0ZWRPdXRzaWRlUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcbiAgICAgIE1lbnVQcmltaXRpdmUuQ29udGVudCxcbiAgICAgIHtcbiAgICAgICAgaWQ6IGNvbnRleHQuY29udGVudElkLFxuICAgICAgICBcImFyaWEtbGFiZWxsZWRieVwiOiBjb250ZXh0LnRyaWdnZXJJZCxcbiAgICAgICAgLi4ubWVudVNjb3BlLFxuICAgICAgICAuLi5jb250ZW50UHJvcHMsXG4gICAgICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgICAgICBvbkNsb3NlQXV0b0ZvY3VzOiBjb21wb3NlRXZlbnRIYW5kbGVycyhwcm9wcy5vbkNsb3NlQXV0b0ZvY3VzLCAoZXZlbnQpID0+IHtcbiAgICAgICAgICBpZiAoIWhhc0ludGVyYWN0ZWRPdXRzaWRlUmVmLmN1cnJlbnQpIGNvbnRleHQudHJpZ2dlclJlZi5jdXJyZW50Py5mb2N1cygpO1xuICAgICAgICAgIGhhc0ludGVyYWN0ZWRPdXRzaWRlUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICB9KSxcbiAgICAgICAgb25JbnRlcmFjdE91dHNpZGU6IGNvbXBvc2VFdmVudEhhbmRsZXJzKHByb3BzLm9uSW50ZXJhY3RPdXRzaWRlLCAoZXZlbnQpID0+IHtcbiAgICAgICAgICBjb25zdCBvcmlnaW5hbEV2ZW50ID0gZXZlbnQuZGV0YWlsLm9yaWdpbmFsRXZlbnQ7XG4gICAgICAgICAgY29uc3QgY3RybExlZnRDbGljayA9IG9yaWdpbmFsRXZlbnQuYnV0dG9uID09PSAwICYmIG9yaWdpbmFsRXZlbnQuY3RybEtleSA9PT0gdHJ1ZTtcbiAgICAgICAgICBjb25zdCBpc1JpZ2h0Q2xpY2sgPSBvcmlnaW5hbEV2ZW50LmJ1dHRvbiA9PT0gMiB8fCBjdHJsTGVmdENsaWNrO1xuICAgICAgICAgIGlmICghY29udGV4dC5tb2RhbCB8fCBpc1JpZ2h0Q2xpY2spIGhhc0ludGVyYWN0ZWRPdXRzaWRlUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICB9KSxcbiAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICAuLi5wcm9wcy5zdHlsZSxcbiAgICAgICAgICAvLyByZS1uYW1lc3BhY2UgZXhwb3NlZCBjb250ZW50IGN1c3RvbSBwcm9wZXJ0aWVzXG4gICAgICAgICAgLi4ue1xuICAgICAgICAgICAgXCItLXJhZGl4LWRyb3Bkb3duLW1lbnUtY29udGVudC10cmFuc2Zvcm0tb3JpZ2luXCI6IFwidmFyKC0tcmFkaXgtcG9wcGVyLXRyYW5zZm9ybS1vcmlnaW4pXCIsXG4gICAgICAgICAgICBcIi0tcmFkaXgtZHJvcGRvd24tbWVudS1jb250ZW50LWF2YWlsYWJsZS13aWR0aFwiOiBcInZhcigtLXJhZGl4LXBvcHBlci1hdmFpbGFibGUtd2lkdGgpXCIsXG4gICAgICAgICAgICBcIi0tcmFkaXgtZHJvcGRvd24tbWVudS1jb250ZW50LWF2YWlsYWJsZS1oZWlnaHRcIjogXCJ2YXIoLS1yYWRpeC1wb3BwZXItYXZhaWxhYmxlLWhlaWdodClcIixcbiAgICAgICAgICAgIFwiLS1yYWRpeC1kcm9wZG93bi1tZW51LXRyaWdnZXItd2lkdGhcIjogXCJ2YXIoLS1yYWRpeC1wb3BwZXItYW5jaG9yLXdpZHRoKVwiLFxuICAgICAgICAgICAgXCItLXJhZGl4LWRyb3Bkb3duLW1lbnUtdHJpZ2dlci1oZWlnaHRcIjogXCJ2YXIoLS1yYWRpeC1wb3BwZXItYW5jaG9yLWhlaWdodClcIlxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICk7XG4gIH0sIFwiRHJvcGRvd25NZW51Q29udGVudFwiKVxuKTtcbnZhciBEcm9wZG93bk1lbnVHcm91cCA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvLyBibGFuayBsaW5lIHRvIHJlZHVjZSBkaWZmIG5vaXNlXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gRHJvcGRvd25NZW51R3JvdXAyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCB7IF9fc2NvcGVEcm9wZG93bk1lbnUsIC4uLmdyb3VwUHJvcHMgfSA9IHByb3BzO1xuICAgIGNvbnN0IG1lbnVTY29wZSA9IHVzZU1lbnVTY29wZShfX3Njb3BlRHJvcGRvd25NZW51KTtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChNZW51UHJpbWl0aXZlLkdyb3VwLCB7IC4uLm1lbnVTY29wZSwgLi4uZ3JvdXBQcm9wcywgcmVmOiBmb3J3YXJkZWRSZWYgfSk7XG4gIH0sIFwiRHJvcGRvd25NZW51R3JvdXBcIilcbik7XG52YXIgRHJvcGRvd25NZW51TGFiZWwgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLy8gYmxhbmsgbGluZSB0byByZWR1Y2UgZGlmZiBub2lzZVxuICAvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIERyb3Bkb3duTWVudUxhYmVsMihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gICAgY29uc3QgeyBfX3Njb3BlRHJvcGRvd25NZW51LCAuLi5sYWJlbFByb3BzIH0gPSBwcm9wcztcbiAgICBjb25zdCBtZW51U2NvcGUgPSB1c2VNZW51U2NvcGUoX19zY29wZURyb3Bkb3duTWVudSk7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goTWVudVByaW1pdGl2ZS5MYWJlbCwgeyAuLi5tZW51U2NvcGUsIC4uLmxhYmVsUHJvcHMsIHJlZjogZm9yd2FyZGVkUmVmIH0pO1xuICB9LCBcIkRyb3Bkb3duTWVudUxhYmVsXCIpXG4pO1xudmFyIERyb3Bkb3duTWVudUl0ZW0gPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZihcbiAgLy8gYmxhbmsgbGluZSB0byByZWR1Y2UgZGlmZiBub2lzZVxuICAvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIERyb3Bkb3duTWVudUl0ZW0yKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCB7IF9fc2NvcGVEcm9wZG93bk1lbnUsIC4uLml0ZW1Qcm9wcyB9ID0gcHJvcHM7XG4gICAgY29uc3QgbWVudVNjb3BlID0gdXNlTWVudVNjb3BlKF9fc2NvcGVEcm9wZG93bk1lbnUpO1xuICAgIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KE1lbnVQcmltaXRpdmUuSXRlbSwgeyAuLi5tZW51U2NvcGUsIC4uLml0ZW1Qcm9wcywgcmVmOiBmb3J3YXJkZWRSZWYgfSk7XG4gIH0sIFwiRHJvcGRvd25NZW51SXRlbVwiKVxuKTtcbnZhciBEcm9wZG93bk1lbnVDaGVja2JveEl0ZW0gPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZigvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIERyb3Bkb3duTWVudUNoZWNrYm94SXRlbTIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7IF9fc2NvcGVEcm9wZG93bk1lbnUsIC4uLmNoZWNrYm94SXRlbVByb3BzIH0gPSBwcm9wcztcbiAgY29uc3QgbWVudVNjb3BlID0gdXNlTWVudVNjb3BlKF9fc2NvcGVEcm9wZG93bk1lbnUpO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChNZW51UHJpbWl0aXZlLkNoZWNrYm94SXRlbSwgeyAuLi5tZW51U2NvcGUsIC4uLmNoZWNrYm94SXRlbVByb3BzLCByZWY6IGZvcndhcmRlZFJlZiB9KTtcbn0sIFwiRHJvcGRvd25NZW51Q2hlY2tib3hJdGVtXCIpKTtcbnZhciBEcm9wZG93bk1lbnVSYWRpb0dyb3VwID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBEcm9wZG93bk1lbnVSYWRpb0dyb3VwMihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHsgX19zY29wZURyb3Bkb3duTWVudSwgLi4ucmFkaW9Hcm91cFByb3BzIH0gPSBwcm9wcztcbiAgY29uc3QgbWVudVNjb3BlID0gdXNlTWVudVNjb3BlKF9fc2NvcGVEcm9wZG93bk1lbnUpO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChNZW51UHJpbWl0aXZlLlJhZGlvR3JvdXAsIHsgLi4ubWVudVNjb3BlLCAuLi5yYWRpb0dyb3VwUHJvcHMsIHJlZjogZm9yd2FyZGVkUmVmIH0pO1xufSwgXCJEcm9wZG93bk1lbnVSYWRpb0dyb3VwXCIpKTtcbnZhciBEcm9wZG93bk1lbnVSYWRpb0l0ZW0gPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZigvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIERyb3Bkb3duTWVudVJhZGlvSXRlbTIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7IF9fc2NvcGVEcm9wZG93bk1lbnUsIC4uLnJhZGlvSXRlbVByb3BzIH0gPSBwcm9wcztcbiAgY29uc3QgbWVudVNjb3BlID0gdXNlTWVudVNjb3BlKF9fc2NvcGVEcm9wZG93bk1lbnUpO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChNZW51UHJpbWl0aXZlLlJhZGlvSXRlbSwgeyAuLi5tZW51U2NvcGUsIC4uLnJhZGlvSXRlbVByb3BzLCByZWY6IGZvcndhcmRlZFJlZiB9KTtcbn0sIFwiRHJvcGRvd25NZW51UmFkaW9JdGVtXCIpKTtcbnZhciBEcm9wZG93bk1lbnVJdGVtSW5kaWNhdG9yID0gLyogQF9fUFVSRV9fICovIFJlYWN0LmZvcndhcmRSZWYoLyogQF9fUFVSRV9fICovIF9fbmFtZShmdW5jdGlvbiBEcm9wZG93bk1lbnVJdGVtSW5kaWNhdG9yMihwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHsgX19zY29wZURyb3Bkb3duTWVudSwgLi4uaXRlbUluZGljYXRvclByb3BzIH0gPSBwcm9wcztcbiAgY29uc3QgbWVudVNjb3BlID0gdXNlTWVudVNjb3BlKF9fc2NvcGVEcm9wZG93bk1lbnUpO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChNZW51UHJpbWl0aXZlLkl0ZW1JbmRpY2F0b3IsIHsgLi4ubWVudVNjb3BlLCAuLi5pdGVtSW5kaWNhdG9yUHJvcHMsIHJlZjogZm9yd2FyZGVkUmVmIH0pO1xufSwgXCJEcm9wZG93bk1lbnVJdGVtSW5kaWNhdG9yXCIpKTtcbnZhciBEcm9wZG93bk1lbnVTZXBhcmF0b3IgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZigvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIERyb3Bkb3duTWVudVNlcGFyYXRvcjIocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7IF9fc2NvcGVEcm9wZG93bk1lbnUsIC4uLnNlcGFyYXRvclByb3BzIH0gPSBwcm9wcztcbiAgY29uc3QgbWVudVNjb3BlID0gdXNlTWVudVNjb3BlKF9fc2NvcGVEcm9wZG93bk1lbnUpO1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChNZW51UHJpbWl0aXZlLlNlcGFyYXRvciwgeyAuLi5tZW51U2NvcGUsIC4uLnNlcGFyYXRvclByb3BzLCByZWY6IGZvcndhcmRlZFJlZiB9KTtcbn0sIFwiRHJvcGRvd25NZW51U2VwYXJhdG9yXCIpKTtcbnZhciBEcm9wZG93bk1lbnVBcnJvdyA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5mb3J3YXJkUmVmKFxuICAvLyBibGFuayBsaW5lIHRvIHJlZHVjZSBkaWZmIG5vaXNlXG4gIC8qIEBfX1BVUkVfXyAqLyBfX25hbWUoZnVuY3Rpb24gRHJvcGRvd25NZW51QXJyb3cyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCB7IF9fc2NvcGVEcm9wZG93bk1lbnUsIC4uLmFycm93UHJvcHMgfSA9IHByb3BzO1xuICAgIGNvbnN0IG1lbnVTY29wZSA9IHVzZU1lbnVTY29wZShfX3Njb3BlRHJvcGRvd25NZW51KTtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChNZW51UHJpbWl0aXZlLkFycm93LCB7IC4uLm1lbnVTY29wZSwgLi4uYXJyb3dQcm9wcywgcmVmOiBmb3J3YXJkZWRSZWYgfSk7XG4gIH0sIFwiRHJvcGRvd25NZW51QXJyb3dcIilcbik7XG52YXIgRHJvcGRvd25NZW51U3ViID0gLyogQF9fUFVSRV9fICovIF9fbmFtZSgocHJvcHMpID0+IHtcbiAgY29uc3QgeyBfX3Njb3BlRHJvcGRvd25NZW51LCBjaGlsZHJlbiwgb3Blbjogb3BlblByb3AsIG9uT3BlbkNoYW5nZSwgZGVmYXVsdE9wZW4gfSA9IHByb3BzO1xuICBjb25zdCBtZW51U2NvcGUgPSB1c2VNZW51U2NvcGUoX19zY29wZURyb3Bkb3duTWVudSk7XG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZUNvbnRyb2xsYWJsZVN0YXRlKHtcbiAgICBwcm9wOiBvcGVuUHJvcCxcbiAgICBkZWZhdWx0UHJvcDogZGVmYXVsdE9wZW4gPz8gZmFsc2UsXG4gICAgb25DaGFuZ2U6IG9uT3BlbkNoYW5nZSxcbiAgICBjYWxsZXI6IFwiRHJvcGRvd25NZW51U3ViXCJcbiAgfSk7XG4gIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KE1lbnVQcmltaXRpdmUuU3ViLCB7IC4uLm1lbnVTY29wZSwgb3Blbiwgb25PcGVuQ2hhbmdlOiBzZXRPcGVuLCBjaGlsZHJlbiB9KTtcbn0sIFwiRHJvcGRvd25NZW51U3ViXCIpO1xudmFyIERyb3Bkb3duTWVudVN1YlRyaWdnZXIgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZigvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIERyb3Bkb3duTWVudVN1YlRyaWdnZXIyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3QgeyBfX3Njb3BlRHJvcGRvd25NZW51LCAuLi5zdWJUcmlnZ2VyUHJvcHMgfSA9IHByb3BzO1xuICBjb25zdCBtZW51U2NvcGUgPSB1c2VNZW51U2NvcGUoX19zY29wZURyb3Bkb3duTWVudSk7XG4gIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KE1lbnVQcmltaXRpdmUuU3ViVHJpZ2dlciwgeyAuLi5tZW51U2NvcGUsIC4uLnN1YlRyaWdnZXJQcm9wcywgcmVmOiBmb3J3YXJkZWRSZWYgfSk7XG59LCBcIkRyb3Bkb3duTWVudVN1YlRyaWdnZXJcIikpO1xudmFyIERyb3Bkb3duTWVudVN1YkNvbnRlbnQgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuZm9yd2FyZFJlZigvKiBAX19QVVJFX18gKi8gX19uYW1lKGZ1bmN0aW9uIERyb3Bkb3duTWVudVN1YkNvbnRlbnQyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3QgeyBfX3Njb3BlRHJvcGRvd25NZW51LCAuLi5zdWJDb250ZW50UHJvcHMgfSA9IHByb3BzO1xuICBjb25zdCBtZW51U2NvcGUgPSB1c2VNZW51U2NvcGUoX19zY29wZURyb3Bkb3duTWVudSk7XG4gIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFxuICAgIE1lbnVQcmltaXRpdmUuU3ViQ29udGVudCxcbiAgICB7XG4gICAgICAuLi5tZW51U2NvcGUsXG4gICAgICAuLi5zdWJDb250ZW50UHJvcHMsXG4gICAgICByZWY6IGZvcndhcmRlZFJlZixcbiAgICAgIHN0eWxlOiB7XG4gICAgICAgIC4uLnByb3BzLnN0eWxlLFxuICAgICAgICAvLyByZS1uYW1lc3BhY2UgZXhwb3NlZCBjb250ZW50IGN1c3RvbSBwcm9wZXJ0aWVzXG4gICAgICAgIC4uLntcbiAgICAgICAgICBcIi0tcmFkaXgtZHJvcGRvd24tbWVudS1jb250ZW50LXRyYW5zZm9ybS1vcmlnaW5cIjogXCJ2YXIoLS1yYWRpeC1wb3BwZXItdHJhbnNmb3JtLW9yaWdpbilcIixcbiAgICAgICAgICBcIi0tcmFkaXgtZHJvcGRvd24tbWVudS1jb250ZW50LWF2YWlsYWJsZS13aWR0aFwiOiBcInZhcigtLXJhZGl4LXBvcHBlci1hdmFpbGFibGUtd2lkdGgpXCIsXG4gICAgICAgICAgXCItLXJhZGl4LWRyb3Bkb3duLW1lbnUtY29udGVudC1hdmFpbGFibGUtaGVpZ2h0XCI6IFwidmFyKC0tcmFkaXgtcG9wcGVyLWF2YWlsYWJsZS1oZWlnaHQpXCIsXG4gICAgICAgICAgXCItLXJhZGl4LWRyb3Bkb3duLW1lbnUtdHJpZ2dlci13aWR0aFwiOiBcInZhcigtLXJhZGl4LXBvcHBlci1hbmNob3Itd2lkdGgpXCIsXG4gICAgICAgICAgXCItLXJhZGl4LWRyb3Bkb3duLW1lbnUtdHJpZ2dlci1oZWlnaHRcIjogXCJ2YXIoLS1yYWRpeC1wb3BwZXItYW5jaG9yLWhlaWdodClcIlxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICApO1xufSwgXCJEcm9wZG93bk1lbnVTdWJDb250ZW50XCIpKTtcbnZhciBSb290MiA9IERyb3Bkb3duTWVudTtcbnZhciBUcmlnZ2VyID0gRHJvcGRvd25NZW51VHJpZ2dlcjtcbnZhciBQb3J0YWwyID0gRHJvcGRvd25NZW51UG9ydGFsO1xudmFyIENvbnRlbnQyID0gRHJvcGRvd25NZW51Q29udGVudDtcbnZhciBHcm91cDIgPSBEcm9wZG93bk1lbnVHcm91cDtcbnZhciBMYWJlbDIgPSBEcm9wZG93bk1lbnVMYWJlbDtcbnZhciBJdGVtMiA9IERyb3Bkb3duTWVudUl0ZW07XG52YXIgQ2hlY2tib3hJdGVtMiA9IERyb3Bkb3duTWVudUNoZWNrYm94SXRlbTtcbnZhciBSYWRpb0dyb3VwMiA9IERyb3Bkb3duTWVudVJhZGlvR3JvdXA7XG52YXIgUmFkaW9JdGVtMiA9IERyb3Bkb3duTWVudVJhZGlvSXRlbTtcbnZhciBJdGVtSW5kaWNhdG9yMiA9IERyb3Bkb3duTWVudUl0ZW1JbmRpY2F0b3I7XG52YXIgU2VwYXJhdG9yMiA9IERyb3Bkb3duTWVudVNlcGFyYXRvcjtcbnZhciBBcnJvdzIgPSBEcm9wZG93bk1lbnVBcnJvdztcbnZhciBTdWIyID0gRHJvcGRvd25NZW51U3ViO1xudmFyIFN1YlRyaWdnZXIyID0gRHJvcGRvd25NZW51U3ViVHJpZ2dlcjtcbnZhciBTdWJDb250ZW50MiA9IERyb3Bkb3duTWVudVN1YkNvbnRlbnQ7XG5leHBvcnQge1xuICBBcnJvdzIgYXMgQXJyb3csXG4gIENoZWNrYm94SXRlbTIgYXMgQ2hlY2tib3hJdGVtLFxuICBDb250ZW50MiBhcyBDb250ZW50LFxuICBEcm9wZG93bk1lbnUsXG4gIERyb3Bkb3duTWVudUFycm93LFxuICBEcm9wZG93bk1lbnVDaGVja2JveEl0ZW0sXG4gIERyb3Bkb3duTWVudUNvbnRlbnQsXG4gIERyb3Bkb3duTWVudUdyb3VwLFxuICBEcm9wZG93bk1lbnVJdGVtLFxuICBEcm9wZG93bk1lbnVJdGVtSW5kaWNhdG9yLFxuICBEcm9wZG93bk1lbnVMYWJlbCxcbiAgRHJvcGRvd25NZW51UG9ydGFsLFxuICBEcm9wZG93bk1lbnVSYWRpb0dyb3VwLFxuICBEcm9wZG93bk1lbnVSYWRpb0l0ZW0sXG4gIERyb3Bkb3duTWVudVNlcGFyYXRvcixcbiAgRHJvcGRvd25NZW51U3ViLFxuICBEcm9wZG93bk1lbnVTdWJDb250ZW50LFxuICBEcm9wZG93bk1lbnVTdWJUcmlnZ2VyLFxuICBEcm9wZG93bk1lbnVUcmlnZ2VyLFxuICBHcm91cDIgYXMgR3JvdXAsXG4gIEl0ZW0yIGFzIEl0ZW0sXG4gIEl0ZW1JbmRpY2F0b3IyIGFzIEl0ZW1JbmRpY2F0b3IsXG4gIExhYmVsMiBhcyBMYWJlbCxcbiAgUG9ydGFsMiBhcyBQb3J0YWwsXG4gIFJhZGlvR3JvdXAyIGFzIFJhZGlvR3JvdXAsXG4gIFJhZGlvSXRlbTIgYXMgUmFkaW9JdGVtLFxuICBSb290MiBhcyBSb290LFxuICBTZXBhcmF0b3IyIGFzIFNlcGFyYXRvcixcbiAgU3ViMiBhcyBTdWIsXG4gIFN1YkNvbnRlbnQyIGFzIFN1YkNvbnRlbnQsXG4gIFN1YlRyaWdnZXIyIGFzIFN1YlRyaWdnZXIsXG4gIFRyaWdnZXIsXG4gIGNyZWF0ZURyb3Bkb3duTWVudVNjb3BlXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXgubWpzLm1hcFxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSxJQUFJQSxjQUFZLE9BQU87QUFDdkIsSUFBSUMsWUFBVSxRQUFRLFVBQVVELFlBQVUsUUFBUSxRQUFRO0NBQUU7Q0FBTyxjQUFjO0FBQUssQ0FBQztBQXlCdkYsSUFBSSxpQkFBaUIsQ0FBQyxTQUFTLEdBQUc7QUFDbEMsSUFBSSxhQUFhO0NBQUM7Q0FBYTtDQUFVO0FBQU07QUFDL0MsSUFBSSxZQUFZO0NBQUM7Q0FBVztDQUFZO0FBQUs7QUFDN0MsSUFBSSxrQkFBa0IsQ0FBQyxHQUFHLFlBQVksR0FBRyxTQUFTO0FBQ2xELElBQUksZ0JBQWdCO0NBQ2xCLEtBQUssQ0FBQyxHQUFHLGdCQUFnQixZQUFZO0NBQ3JDLEtBQUssQ0FBQyxHQUFHLGdCQUFnQixXQUFXO0FBQ3RDO0FBQ0EsSUFBSSxpQkFBaUI7Q0FDbkIsS0FBSyxDQUFDLFdBQVc7Q0FDakIsS0FBSyxDQUFDLFlBQVk7QUFDcEI7QUFDQSxJQUFJLFlBQVk7QUFDaEIsSUFBSSxDQUFDLFlBQVksZUFBZSx5QkFBeUIsaUJBQWlCLFNBQVM7QUFDbkYsSUFBSSxDQUFDLG1CQUFtQixtQkFBbUIsbUJBQW1CLFdBQVc7Q0FDdkU7Q0FDQTtDQUNBO0FBQ0YsQ0FBQztBQUNELElBQUksaUJBQWlCLGtCQUFrQjtBQUN2QyxJQUFJLDJCQUEyQiw0QkFBNEI7QUFDM0QsSUFBSSxDQUFDLGNBQWMsa0JBQWtCLGtCQUFrQixTQUFTO0FBQ2hFLElBQUksQ0FBQyxrQkFBa0Isc0JBQXNCLGtCQUFrQixTQUFTO0FBQ3hFLElBQUksT0FBdUIsMEJBQVEsVUFBVTtDQUMzQyxNQUFNLEVBQUUsYUFBYSxPQUFPLE9BQU8sVUFBVSxLQUFLLGNBQWMsUUFBUSxTQUFTO0NBQ2pGLE1BQU0sY0FBYyxlQUFlLFdBQVc7Q0FDOUMsTUFBTSxDQUFDLFNBQVMsY0FBQSxhQUFvQixTQUFTLElBQUk7Q0FDakQsTUFBTSxxQkFBQSxhQUEyQixPQUFPLEtBQUs7Q0FDN0MsTUFBTSxtQkFBbUIsZUFBZSxZQUFZO0NBQ3BELE1BQU0sWUFBWSxhQUFhLEdBQUc7Q0FDbEMsYUFBTSxnQkFBZ0I7RUFDcEIsTUFBTSxnQkFBZ0MsK0JBQWE7R0FDakQsbUJBQW1CLFVBQVU7R0FDN0IsU0FBUyxpQkFBaUIsZUFBZSxlQUFlO0lBQUUsU0FBUztJQUFNLE1BQU07R0FBSyxDQUFDO0dBQ3JGLFNBQVMsaUJBQWlCLGVBQWUsZUFBZTtJQUFFLFNBQVM7SUFBTSxNQUFNO0dBQUssQ0FBQztFQUN2RixHQUFHLGVBQWU7RUFDbEIsTUFBTSxnQkFBZ0MsK0JBQWEsbUJBQW1CLFVBQVUsT0FBTyxlQUFlO0VBQ3RHLFNBQVMsaUJBQWlCLFdBQVcsZUFBZSxFQUFFLFNBQVMsS0FBSyxDQUFDO0VBQ3JFLGFBQWE7R0FDWCxTQUFTLG9CQUFvQixXQUFXLGVBQWUsRUFBRSxTQUFTLEtBQUssQ0FBQztHQUN4RSxTQUFTLG9CQUFvQixlQUFlLGVBQWUsRUFBRSxTQUFTLEtBQUssQ0FBQztHQUM1RSxTQUFTLG9CQUFvQixlQUFlLGVBQWUsRUFBRSxTQUFTLEtBQUssQ0FBQztFQUM5RTtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBQ0wsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxDQUFDLE1BQ0g7RUFFRixNQUFNLGFBQTZCLCtCQUFhLGlCQUFpQixLQUFLLEdBQUcsWUFBWTtFQUNyRixPQUFPLGlCQUFpQixRQUFRLFVBQVU7RUFDMUMsYUFBYSxPQUFPLG9CQUFvQixRQUFRLFVBQVU7Q0FDNUQsR0FBRyxDQUFDLE1BQU0sZ0JBQWdCLENBQUM7Q0FDM0IsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUlFLFNBQXNCO0VBQUUsR0FBRztFQUFhLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUMzRixjQUNBO0dBQ0UsT0FBTztHQUNQO0dBQ0EsY0FBYztHQUNkO0dBQ0EsaUJBQWlCO0dBQ2pCLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUN4QixrQkFDQTtJQUNFLE9BQU87SUFDUCxTQUFBLGFBQWUsa0JBQWtCLGlCQUFpQixLQUFLLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztJQUM1RTtJQUNBLEtBQUs7SUFDTDtJQUNBO0dBQ0YsQ0FDRjtFQUNGLENBQ0Y7Q0FBRSxDQUFDO0FBQ0wsR0FBRyxNQUFNO0FBQ1QsSUFBSSxhQUE2Qiw2QkFBTSxXQUNyQix5QkFBTyxTQUFTLFlBQVksT0FBTyxjQUFjO0NBQy9ELE1BQU0sRUFBRSxhQUFhLEdBQUcsZ0JBQWdCO0NBQ3hDLE1BQU0sY0FBYyxlQUFlLFdBQVc7Q0FDOUMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUlDLFFBQXdCO0VBQUUsR0FBRztFQUFhLEdBQUc7RUFBYSxLQUFLO0NBQWEsQ0FBQztBQUMxRyxHQUFHLFlBQVksQ0FDakI7QUFDQSxJQUFJLGNBQWM7QUFDbEIsSUFBSSxDQUFDLGdCQUFnQixvQkFBb0Isa0JBQWtCLGFBQWEsRUFDdEUsWUFBWSxLQUFLLEVBQ25CLENBQUM7QUFDRCxJQUFJLGFBQTZCLDBCQUFRLFVBQVU7Q0FDakQsTUFBTSxFQUFFLGFBQWEsWUFBWSxVQUFVLGNBQWM7Q0FDekQsTUFBTSxVQUFVLGVBQWUsYUFBYSxXQUFXO0NBQ3ZELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLGdCQUFnQjtFQUFFLE9BQU87RUFBYTtFQUFZLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFVBQVU7R0FBRSxTQUFTLGNBQWMsUUFBUTtHQUFNLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJQyxVQUFpQjtJQUFFLFNBQVM7SUFBTTtJQUFXO0dBQVMsQ0FBQztFQUFFLENBQUM7Q0FBRSxDQUFDO0FBQ3pQLEdBQUcsWUFBWTtBQUNmLElBQUlDLGlCQUFlO0FBQ25CLElBQUksQ0FBQyxxQkFBcUIseUJBQXlCLGtCQUFrQkEsY0FBWTtBQUNqRixJQUFJLGNBQThCLDZCQUFNLFdBQ3RCLHlCQUFPLFNBQVMsYUFBYSxPQUFPLGNBQWM7Q0FDaEUsTUFBTSxnQkFBZ0IsaUJBQWlCQSxnQkFBYyxNQUFNLFdBQVc7Q0FDdEUsTUFBTSxFQUFFLGFBQWEsY0FBYyxZQUFZLEdBQUcsaUJBQWlCO0NBQ25FLE1BQU0sVUFBVSxlQUFlQSxnQkFBYyxNQUFNLFdBQVc7Q0FDOUQsTUFBTSxjQUFjLG1CQUFtQkEsZ0JBQWMsTUFBTSxXQUFXO0NBQ3RFLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFdBQVcsVUFBVTtFQUFFLE9BQU8sTUFBTTtFQUFhLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFVBQVU7R0FBRSxTQUFTLGNBQWMsUUFBUTtHQUFNLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFdBQVcsTUFBTTtJQUFFLE9BQU8sTUFBTTtJQUFhLFVBQVUsWUFBWSxRQUF3QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxzQkFBc0I7S0FBRSxHQUFHO0tBQWMsS0FBSztJQUFhLENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUkseUJBQXlCO0tBQUUsR0FBRztLQUFjLEtBQUs7SUFBYSxDQUFDO0dBQUUsQ0FBQztFQUFFLENBQUM7Q0FBRSxDQUFDO0FBQ3RiLEdBQUcsYUFBYSxDQUNsQjtBQUNBLElBQUksdUJBQXVDLDZCQUFNLFdBRS9CLHlCQUFPLFNBQVMsc0JBQXNCLE9BQU8sY0FBYztDQUN6RSxNQUFNLFVBQVUsZUFBZUEsZ0JBQWMsTUFBTSxXQUFXO0NBQzlELE1BQU0sTUFBQSxhQUFZLE9BQU8sSUFBSTtDQUM3QixNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsR0FBRztDQUN0RCxhQUFNLGdCQUFnQjtFQUNwQixNQUFNLFVBQVUsSUFBSTtFQUNwQixJQUFJLFNBQVMsT0FBTyxXQUFXLE9BQU87Q0FDeEMsR0FBRyxDQUFDLENBQUM7Q0FDTCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDckIsaUJBQ0E7RUFDRSxHQUFHO0VBQ0gsS0FBSztFQUNMLFdBQVcsUUFBUTtFQUNuQiw2QkFBNkIsUUFBUTtFQUNyQyxzQkFBc0I7RUFDdEIsZ0JBQWdCLHFCQUNkLE1BQU0saUJBQ0wsVUFBVSxNQUFNLGVBQWUsR0FDaEMsRUFBRSwwQkFBMEIsTUFBTSxDQUNwQztFQUNBLGlCQUFpQixRQUFRLGFBQWEsS0FBSztDQUM3QyxDQUNGO0FBQ0YsR0FBRyxzQkFBc0IsQ0FDM0I7QUFDQSxJQUFJLDBCQUEwQyw2QkFBTSxXQUEyQix5QkFBTyxTQUFTLHlCQUF5QixPQUFPLGNBQWM7Q0FDM0ksTUFBTSxVQUFVLGVBQWVBLGdCQUFjLE1BQU0sV0FBVztDQUM5RCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDckIsaUJBQ0E7RUFDRSxHQUFHO0VBQ0gsS0FBSztFQUNMLFdBQVc7RUFDWCw2QkFBNkI7RUFDN0Isc0JBQXNCO0VBQ3RCLGlCQUFpQixRQUFRLGFBQWEsS0FBSztDQUM3QyxDQUNGO0FBQ0YsR0FBRyx5QkFBeUIsQ0FBQztBQUM3QixJQUFJLE9BQU8sV0FBVyx3QkFBd0I7QUFDOUMsSUFBSSxrQkFBa0MsNkJBQU0sV0FFMUIseUJBQU8sU0FBUyxpQkFBaUIsT0FBTyxjQUFjO0NBQ3BFLE1BQU0sRUFDSixhQUNBLE9BQU8sT0FDUCxXQUNBLGlCQUNBLGtCQUNBLDZCQUNBLGNBQ0EsaUJBQ0Esc0JBQ0EsZ0JBQ0EsbUJBQ0EsV0FDQSxzQkFDQSxHQUFHLGlCQUNEO0NBQ0osTUFBTSxVQUFVLGVBQWVBLGdCQUFjLFdBQVc7Q0FDeEQsTUFBTSxjQUFjLG1CQUFtQkEsZ0JBQWMsV0FBVztDQUNoRSxNQUFNLGNBQWMsZUFBZSxXQUFXO0NBQzlDLE1BQU0sd0JBQXdCLHlCQUF5QixXQUFXO0NBQ2xFLE1BQU0sV0FBVyxjQUFjLFdBQVc7Q0FDMUMsTUFBTSxDQUFDLGVBQWUsb0JBQUEsYUFBMEIsU0FBUyxJQUFJO0NBQzdELE1BQU0sYUFBQSxhQUFtQixPQUFPLElBQUk7Q0FDcEMsTUFBTSxlQUFlLGdCQUFnQixjQUFjLFlBQVksUUFBUSxlQUFlO0NBQ3RGLE1BQU0sV0FBQSxhQUFpQixPQUFPLENBQUM7Q0FDL0IsTUFBTSxZQUFBLGFBQWtCLE9BQU8sRUFBRTtDQUNqQyxNQUFNLHVCQUFBLGFBQTZCLE9BQU8sQ0FBQztDQUMzQyxNQUFNLHdCQUFBLGFBQThCLE9BQU8sSUFBSTtDQUMvQyxNQUFNLGdCQUFBLGFBQXNCLE9BQU8sT0FBTztDQUMxQyxNQUFNLGtCQUFBLGFBQXdCLE9BQU8sQ0FBQztDQUN0QyxNQUFNLG9CQUFvQix1QkFBdUJDLG9CQUFBQSxhQUFxQjtDQUN0RSxNQUFNLHlCQUF5Qix1QkFBdUI7RUFBRSxJQUFJO0VBQU0sZ0JBQWdCO0NBQUssSUFBSSxLQUFLO0NBQ2hHLE1BQU0sd0JBQXdDLDBCQUFRLFFBQVE7RUFDNUQsTUFBTSxTQUFTLFVBQVUsVUFBVTtFQUNuQyxNQUFNLFFBQVEsU0FBUyxDQUFDLENBQUMsUUFBUSxTQUFTLENBQUMsS0FBSyxRQUFRO0VBQ3hELE1BQU0sY0FBYyxTQUFTO0VBQzdCLE1BQU0sZUFBZSxNQUFNLE1BQU0sU0FBUyxLQUFLLElBQUksWUFBWSxXQUFXLENBQUMsRUFBRTtFQUU3RSxNQUFNLFlBQVksYUFESCxNQUFNLEtBQUssU0FBUyxLQUFLLFNBQ0osR0FBRyxRQUFRLFlBQVk7RUFDM0QsTUFBTSxVQUFVLE1BQU0sTUFBTSxTQUFTLEtBQUssY0FBYyxTQUFTLENBQUMsRUFBRSxJQUFJO0VBQ3hFLENBQWlCLDBCQUFRLFNBQVMsYUFBYSxPQUFPO0dBQ3BELFVBQVUsVUFBVTtHQUNwQixPQUFPLGFBQWEsU0FBUyxPQUFPO0dBQ3BDLElBQUksVUFBVSxJQUFJLFNBQVMsVUFBVSxPQUFPLGlCQUFpQixhQUFhLEVBQUUsR0FBRyxHQUFHO0VBQ3BGLElBQUksY0FBYyxFQUFBLENBQUcsTUFBTTtFQUMzQixJQUFJLFNBQ0YsaUJBQWlCLFFBQVEsTUFBTSxDQUFDO0NBRXBDLEdBQUcsdUJBQXVCO0NBQzFCLGFBQU0sZ0JBQWdCO0VBQ3BCLGFBQWEsT0FBTyxhQUFhLFNBQVMsT0FBTztDQUNuRCxHQUFHLENBQUMsQ0FBQztDQUNMLGVBQWU7Q0FDZixNQUFNLDJCQUFBLGFBQWlDLGFBQWEsVUFBVTtFQUU1RCxPQUR3QixjQUFjLFlBQVksc0JBQXNCLFNBQVMsUUFDdkQscUJBQXFCLE9BQU8sc0JBQXNCLFNBQVMsSUFBSTtDQUMzRixHQUFHLENBQUMsQ0FBQztDQUNMLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUNyQixxQkFDQTtFQUNFLE9BQU87RUFDUDtFQUNBLGFBQUEsYUFBbUIsYUFDaEIsVUFBVTtHQUNULElBQUkseUJBQXlCLEtBQUssR0FBRyxNQUFNLGVBQWU7RUFDNUQsR0FDQSxDQUFDLHdCQUF3QixDQUMzQjtFQUNBLGFBQUEsYUFBbUIsYUFDaEIsVUFBVTtHQUNULElBQUkseUJBQXlCLEtBQUssR0FBRztHQUNyQyxXQUFXLFNBQVMsTUFBTTtHQUMxQixpQkFBaUIsSUFBSTtFQUN2QixHQUNBLENBQUMsd0JBQXdCLENBQzNCO0VBQ0EsZ0JBQUEsYUFBc0IsYUFDbkIsVUFBVTtHQUNULElBQUkseUJBQXlCLEtBQUssR0FBRyxNQUFNLGVBQWU7RUFDNUQsR0FDQSxDQUFDLHdCQUF3QixDQUMzQjtFQUNBO0VBQ0EsNEJBQUEsYUFBa0MsYUFBYSxXQUFXO0dBQ3hELHNCQUFzQixVQUFVO0VBQ2xDLEdBQUcsQ0FBQyxDQUFDO0VBQ0wsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksbUJBQW1CO0dBQUUsR0FBRztHQUF3QixVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDdEcsWUFDQTtJQUNFLFNBQVM7SUFDVCxTQUFTO0lBQ1Qsa0JBQWtCLHFCQUFxQixrQkFBa0IsVUFBVTtLQUNqRSxNQUFNLGVBQWU7S0FDckIsV0FBVyxTQUFTLE1BQU0sRUFBRSxlQUFlLEtBQUssQ0FBQztJQUNuRCxDQUFDO0lBQ0Qsb0JBQW9CO0lBQ3BCLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUN4QixrQkFDQTtLQUNFLFNBQVM7S0FDVDtLQUNBO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7S0FDQSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDeEJDLE1BQ0E7TUFDRSxTQUFTO01BQ1QsR0FBRztNQUNILEtBQUssWUFBWTtNQUNqQixhQUFhO01BQ2I7TUFDQSxrQkFBa0I7TUFDbEIsMEJBQTBCO01BQzFCLGNBQWMscUJBQXFCLGVBQWUsVUFBVTtPQUMxRCxJQUFJLENBQUMsWUFBWSxtQkFBbUIsU0FBUyxNQUFNLGVBQWU7TUFDcEUsQ0FBQztNQUNELDJCQUEyQjtNQUMzQixVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDeEJDLFNBQ0E7T0FDRSxNQUFNO09BQ04sb0JBQW9CO09BQ3BCLGNBQWMsYUFBYSxRQUFRLElBQUk7T0FDdkMsMkJBQTJCO09BQzNCLEtBQUssWUFBWTtPQUNqQixHQUFHO09BQ0gsR0FBRztPQUNILEtBQUs7T0FDTCxPQUFPO1FBQUUsU0FBUztRQUFRLEdBQUcsYUFBYTtPQUFNO09BQ2hELFdBQVcscUJBQXFCLGFBQWEsWUFBWSxVQUFVO1FBRWpFLE1BQU0sa0JBRFMsTUFBTSxPQUNVLFFBQVEsMkJBQTJCLE1BQU0sTUFBTTtRQUM5RSxNQUFNLGdCQUFnQixNQUFNLFdBQVcsTUFBTSxVQUFVLE1BQU07UUFDN0QsTUFBTSxpQkFBaUIsTUFBTSxJQUFJLFdBQVc7UUFDNUMsSUFBSSxpQkFBaUI7U0FDbkIsSUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLGVBQWU7U0FDOUMsSUFBSSxDQUFDLGlCQUFpQixnQkFBZ0Isc0JBQXNCLE1BQU0sR0FBRztRQUN2RTtRQUNBLE1BQU0sVUFBVSxXQUFXO1FBQzNCLElBQUksTUFBTSxXQUFXLFNBQVM7UUFDOUIsSUFBSSxDQUFDLGdCQUFnQixTQUFTLE1BQU0sR0FBRyxHQUFHO1FBQzFDLE1BQU0sZUFBZTtRQUVyQixNQUFNLGlCQURRLFNBQVMsQ0FBQyxDQUFDLFFBQVEsU0FBUyxDQUFDLEtBQUssUUFDckIsQ0FBQyxDQUFDLEtBQUssU0FBUyxLQUFLLElBQUksT0FBTztRQUMzRCxJQUFJLFVBQVUsU0FBUyxNQUFNLEdBQUcsR0FBRyxlQUFlLFFBQVE7UUFDMUQsV0FBVyxjQUFjO09BQzNCLENBQUM7T0FDRCxRQUFRLHFCQUFxQixNQUFNLFNBQVMsVUFBVTtRQUNwRCxJQUFJLENBQUMsTUFBTSxjQUFjLFNBQVMsTUFBTSxNQUFNLEdBQUc7U0FDL0MsT0FBTyxhQUFhLFNBQVMsT0FBTztTQUNwQyxVQUFVLFVBQVU7UUFDdEI7T0FDRixDQUFDO09BQ0QsZUFBZSxxQkFDYixNQUFNLGVBQ04sV0FBVyxVQUFVO1FBQ25CLE1BQU0sU0FBUyxNQUFNO1FBQ3JCLE1BQU0scUJBQXFCLGdCQUFnQixZQUFZLE1BQU07UUFDN0QsSUFBSSxNQUFNLGNBQWMsU0FBUyxNQUFNLEtBQUssb0JBQW9CO1NBQzlELE1BQU0sU0FBUyxNQUFNLFVBQVUsZ0JBQWdCLFVBQVUsVUFBVTtTQUNuRSxjQUFjLFVBQVU7U0FDeEIsZ0JBQWdCLFVBQVUsTUFBTTtRQUNsQztPQUNGLENBQUMsQ0FDSDtNQUNGLENBQ0Y7S0FDRixDQUNGO0lBQ0YsQ0FDRjtHQUNGLENBQ0Y7RUFBRSxDQUFDO0NBQ0wsQ0FDRjtBQUNGLEdBQUcsaUJBQWlCLENBQ3RCO0FBQ0EsSUFBSSxZQUE0Qiw2QkFBTSxXQUNwQix5QkFBTyxTQUFTLFdBQVcsT0FBTyxjQUFjO0NBQzlELE1BQU0sRUFBRSxhQUFhLEdBQUcsZUFBZTtDQUN2QyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxVQUFVLEtBQUs7RUFBRSxNQUFNO0VBQVMsR0FBRztFQUFZLEtBQUs7Q0FBYSxDQUFDO0FBQy9GLEdBQUcsV0FBVyxDQUNoQjtBQUNBLElBQUksWUFBNEIsNkJBQU0sV0FDcEIseUJBQU8sU0FBUyxXQUFXLE9BQU8sY0FBYztDQUM5RCxNQUFNLEVBQUUsYUFBYSxHQUFHLGVBQWU7Q0FDdkMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksVUFBVSxLQUFLO0VBQUUsR0FBRztFQUFZLEtBQUs7Q0FBYSxDQUFDO0FBQ2hGLEdBQUcsV0FBVyxDQUNoQjtBQUNBLElBQUksWUFBWTtBQUNoQixJQUFJLGNBQWM7QUFDbEIsSUFBSSxXQUEyQiw2QkFBTSxXQUVuQix5QkFBTyxTQUFTLFVBQVUsT0FBTyxjQUFjO0NBQzdELE1BQU0sRUFBRSxXQUFXLE9BQU8sVUFBVSxHQUFHLGNBQWM7Q0FDckQsTUFBTSxNQUFBLGFBQVksT0FBTyxJQUFJO0NBQzdCLE1BQU0sY0FBYyxtQkFBbUIsV0FBVyxNQUFNLFdBQVc7Q0FDbkUsTUFBTSxpQkFBaUIsc0JBQXNCLFdBQVcsTUFBTSxXQUFXO0NBQ3pFLE1BQU0sZUFBZSxnQkFBZ0IsY0FBYyxHQUFHO0NBQ3RELE1BQU0sbUJBQUEsYUFBeUIsT0FBTyxLQUFLO0NBQzNDLE1BQU0sZUFBK0IsK0JBQWE7RUFDaEQsTUFBTSxXQUFXLElBQUk7RUFDckIsSUFBSSxDQUFDLFlBQVksVUFBVTtHQUN6QixNQUFNLGtCQUFrQixJQUFJLFlBQVksYUFBYTtJQUFFLFNBQVM7SUFBTSxZQUFZO0dBQUssQ0FBQztHQUN4RixTQUFTLGlCQUFpQixjQUFjLFVBQVUsV0FBVyxLQUFLLEdBQUcsRUFBRSxNQUFNLEtBQUssQ0FBQztHQUNuRiw0QkFBNEIsVUFBVSxlQUFlO0dBQ3JELElBQUksZ0JBQWdCLGtCQUNsQixpQkFBaUIsVUFBVTtRQUUzQixZQUFZLFFBQVE7RUFFeEI7Q0FDRixHQUFHLGNBQWM7Q0FDakIsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ3JCLGNBQ0E7RUFDRSxHQUFHO0VBQ0gsS0FBSztFQUNMO0VBQ0EsU0FBUyxxQkFBcUIsTUFBTSxTQUFTLFlBQVk7RUFDekQsZ0JBQWdCLFVBQVU7R0FDeEIsTUFBTSxnQkFBZ0IsS0FBSztHQUMzQixpQkFBaUIsVUFBVTtFQUM3QjtFQUNBLGFBQWEscUJBQXFCLE1BQU0sY0FBYyxVQUFVO0dBQzlELElBQUksQ0FBQyxpQkFBaUIsU0FBUyxNQUFNLGVBQWUsTUFBTTtFQUM1RCxDQUFDO0VBQ0QsV0FBVyxxQkFBcUIsTUFBTSxZQUFZLFVBQVU7R0FDMUQsSUFBSSxZQUFZLE1BQU0sV0FBVyxNQUFNLGVBQ3JDO0dBR0YsSUFEc0IsZUFBZSxVQUFVLFlBQVksTUFDdEMsTUFBTSxRQUFRLEtBQ2pDO0dBRUYsSUFBSSxlQUFlLFNBQVMsTUFBTSxHQUFHLEdBQUc7SUFDdEMsTUFBTSxjQUFjLE1BQU07SUFDMUIsTUFBTSxlQUFlO0dBQ3ZCO0VBQ0YsQ0FBQztDQUNILENBQ0Y7QUFDRixHQUFHLFVBQVUsQ0FDZjtBQUNBLElBQUksZUFBK0IsNkJBQU0sV0FDdkIseUJBQU8sU0FBUyxjQUFjLE9BQU8sY0FBYztDQUNqRSxNQUFNLEVBQUUsYUFBYSxXQUFXLE9BQU8sV0FBVyxHQUFHLGNBQWM7Q0FDbkUsTUFBTSxpQkFBaUIsc0JBQXNCLFdBQVcsV0FBVztDQUNuRSxNQUFNLHdCQUF3Qix5QkFBeUIsV0FBVztDQUNsRSxNQUFNLE1BQUEsYUFBWSxPQUFPLElBQUk7Q0FDN0IsTUFBTSxlQUFlLGdCQUFnQixjQUFjLEdBQUc7Q0FDdEQsTUFBTSxDQUFDLFdBQVcsZ0JBQUEsYUFBc0IsU0FBUyxLQUFLO0NBQ3RELE1BQU0sQ0FBQyxhQUFhLGtCQUFBLGFBQXdCLFNBQVMsRUFBRTtDQUN2RCxhQUFNLGdCQUFnQjtFQUNwQixNQUFNLFdBQVcsSUFBSTtFQUNyQixJQUFJLFVBQ0YsZ0JBQWdCLFNBQVMsZUFBZSxHQUFBLENBQUksS0FBSyxDQUFDO0NBRXRELEdBQUcsQ0FBQyxVQUFVLFFBQVEsQ0FBQztDQUN2QixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDckIsV0FBVyxVQUNYO0VBQ0UsT0FBTztFQUNQO0VBQ0EsV0FBVyxhQUFhO0VBQ3hCLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJQyxNQUF1QjtHQUFFLFNBQVM7R0FBTSxHQUFHO0dBQXVCLFdBQVcsQ0FBQztHQUFVLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUM5SSxVQUFVLEtBQ1Y7SUFDRSxNQUFNO0lBQ04sb0JBQW9CLFlBQVksS0FBSyxLQUFLO0lBQzFDLGlCQUFpQixZQUFZLEtBQUs7SUFDbEMsaUJBQWlCLFdBQVcsS0FBSyxLQUFLO0lBQ3RDLEdBQUc7SUFDSCxLQUFLO0lBQ0wsZUFBZSxxQkFDYixNQUFNLGVBQ04sV0FBVyxVQUFVO0tBQ25CLElBQUksVUFDRixlQUFlLFlBQVksS0FBSztVQUMzQjtNQUNMLGVBQWUsWUFBWSxLQUFLO01BQ2hDLElBQUksQ0FBQyxNQUFNLGtCQUVULE1BRG1CLGNBQ2QsTUFBTSxFQUFFLGVBQWUsS0FBSyxDQUFDO0tBRXRDO0lBQ0YsQ0FBQyxDQUNIO0lBQ0EsZ0JBQWdCLHFCQUNkLE1BQU0sZ0JBQ04sV0FBVyxVQUFVLGVBQWUsWUFBWSxLQUFLLENBQUMsQ0FDeEQ7SUFDQSxTQUFTLHFCQUFxQixNQUFNLGVBQWUsYUFBYSxJQUFJLENBQUM7SUFDckUsUUFBUSxxQkFBcUIsTUFBTSxjQUFjLGFBQWEsS0FBSyxDQUFDO0dBQ3RFLENBQ0Y7RUFBRSxDQUFDO0NBQ0wsQ0FDRjtBQUNGLEdBQUcsY0FBYyxDQUNuQjtBQUNBLElBQUksbUJBQW1DLDZCQUFNLFdBRTNCLHlCQUFPLFNBQVMsa0JBQWtCLE9BQU8sY0FBYztDQUNyRSxNQUFNLEVBQUUsVUFBVSxPQUFPLGlCQUFpQixHQUFHLHNCQUFzQjtDQUNuRSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSx1QkFBdUI7RUFBRSxPQUFPLE1BQU07RUFBYTtFQUFTLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUMvRyxVQUNBO0dBQ0UsTUFBTTtHQUNOLGdCQUFnQixnQkFBZ0IsT0FBTyxJQUFJLFVBQVU7R0FDckQsR0FBRztHQUNILEtBQUs7R0FDTCxjQUFjLGdCQUFnQixPQUFPO0dBQ3JDLFVBQVUscUJBQ1Isa0JBQWtCLGdCQUNaLGtCQUFrQixnQkFBZ0IsT0FBTyxJQUFJLE9BQU8sQ0FBQyxPQUFPLEdBQ2xFLEVBQUUsMEJBQTBCLE1BQU0sQ0FDcEM7RUFDRixDQUNGO0NBQUUsQ0FBQztBQUNMLEdBQUcsa0JBQWtCLENBQ3ZCO0FBRUEsSUFBSSxDQUFDLG9CQUFvQix3QkFBd0Isa0JBQy9DLGtCQUNBO0NBQUUsT0FBTyxLQUFLO0NBQUcsZUFBK0IsK0JBQWEsQ0FDN0QsR0FBRyxlQUFlO0FBQUUsQ0FDdEI7QUFDQSxJQUFJLGlCQUFpQyw2QkFBTSxXQUN6Qix5QkFBTyxTQUFTLGdCQUFnQixPQUFPLGNBQWM7Q0FDbkUsTUFBTSxFQUFFLE9BQU8sZUFBZSxHQUFHLGVBQWU7Q0FDaEQsTUFBTSxvQkFBb0IsZUFBZSxhQUFhO0NBQ3RELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLG9CQUFvQjtFQUFFLE9BQU8sTUFBTTtFQUFhO0VBQU8sZUFBZTtFQUFtQixVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxXQUFXO0dBQUUsR0FBRztHQUFZLEtBQUs7RUFBYSxDQUFDO0NBQUUsQ0FBQztBQUN0TSxHQUFHLGdCQUFnQixDQUNyQjtBQUNBLElBQUksa0JBQWtCO0FBQ3RCLElBQUksZ0JBQWdDLDZCQUFNLFdBQ3hCLHlCQUFPLFNBQVMsZUFBZSxPQUFPLGNBQWM7Q0FDbEUsTUFBTSxFQUFFLE9BQU8sR0FBRyxtQkFBbUI7Q0FDckMsTUFBTSxVQUFVLHFCQUFxQixpQkFBaUIsTUFBTSxXQUFXO0NBQ3ZFLE1BQU0sVUFBVSxVQUFVLFFBQVE7Q0FDbEMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksdUJBQXVCO0VBQUUsT0FBTyxNQUFNO0VBQWE7RUFBUyxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDL0csVUFDQTtHQUNFLE1BQU07R0FDTixnQkFBZ0I7R0FDaEIsR0FBRztHQUNILEtBQUs7R0FDTCxjQUFjLGdCQUFnQixPQUFPO0dBQ3JDLFVBQVUscUJBQ1IsZUFBZSxnQkFDVCxRQUFRLGdCQUFnQixLQUFLLEdBQ25DLEVBQUUsMEJBQTBCLE1BQU0sQ0FDcEM7RUFDRixDQUNGO0NBQUUsQ0FBQztBQUNMLEdBQUcsZUFBZSxDQUNwQjtBQUNBLElBQUksc0JBQXNCO0FBQzFCLElBQUksQ0FBQyx1QkFBdUIsMkJBQTJCLGtCQUNyRCxxQkFDQSxFQUFFLFNBQVMsTUFBTSxDQUNuQjtBQUNBLElBQUksb0JBQW9DLDZCQUFNLFdBRTVCLHlCQUFPLFNBQVMsbUJBQW1CLE9BQU8sY0FBYztDQUN0RSxNQUFNLEVBQUUsYUFBYSxZQUFZLEdBQUcsdUJBQXVCO0NBQzNELE1BQU0sbUJBQW1CLHdCQUF3QixxQkFBcUIsV0FBVztDQUNqRixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDckIsVUFDQTtFQUNFLFNBQVMsY0FBYyxnQkFBZ0IsaUJBQWlCLE9BQU8sS0FBSyxpQkFBaUIsWUFBWTtFQUNqRyxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDeEIsVUFBVSxNQUNWO0dBQ0UsR0FBRztHQUNILEtBQUs7R0FDTCxjQUFjLGdCQUFnQixpQkFBaUIsT0FBTztFQUN4RCxDQUNGO0NBQ0YsQ0FDRjtBQUNGLEdBQUcsbUJBQW1CLENBQ3hCO0FBQ0EsSUFBSSxnQkFBZ0MsNkJBQU0sV0FDeEIseUJBQU8sU0FBUyxlQUFlLE9BQU8sY0FBYztDQUNsRSxNQUFNLEVBQUUsYUFBYSxHQUFHLG1CQUFtQjtDQUMzQyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDckIsVUFBVSxLQUNWO0VBQ0UsTUFBTTtFQUNOLG9CQUFvQjtFQUNwQixHQUFHO0VBQ0gsS0FBSztDQUNQLENBQ0Y7QUFDRixHQUFHLGVBQWUsQ0FDcEI7QUFDQSxJQUFJLFlBQTRCLDZCQUFNLFdBQ3BCLHlCQUFPLFNBQVMsV0FBVyxPQUFPLGNBQWM7Q0FDOUQsTUFBTSxFQUFFLGFBQWEsR0FBRyxlQUFlO0NBQ3ZDLE1BQU0sY0FBYyxlQUFlLFdBQVc7Q0FDOUMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUlDLE9BQXVCO0VBQUUsR0FBRztFQUFhLEdBQUc7RUFBWSxLQUFLO0NBQWEsQ0FBQztBQUN4RyxHQUFHLFdBQVcsQ0FDaEI7QUFDQSxJQUFJLFdBQVc7QUFDZixJQUFJLENBQUMsaUJBQWlCLHFCQUFxQixrQkFBa0IsUUFBUTtBQUNyRSxJQUFJLFVBQTBCLDBCQUFRLFVBQVU7Q0FDOUMsTUFBTSxFQUFFLGFBQWEsVUFBVSxPQUFPLE9BQU8saUJBQWlCO0NBQzlELE1BQU0sb0JBQW9CLGVBQWUsVUFBVSxXQUFXO0NBQzlELE1BQU0sY0FBYyxlQUFlLFdBQVc7Q0FDOUMsTUFBTSxDQUFDLFNBQVMsY0FBQSxhQUFvQixTQUFTLElBQUk7Q0FDakQsTUFBTSxDQUFDLFNBQVMsY0FBQSxhQUFvQixTQUFTLElBQUk7Q0FDakQsTUFBTSxtQkFBbUIsZUFBZSxZQUFZO0NBQ3BELGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksa0JBQWtCLFNBQVMsT0FBTyxpQkFBaUIsS0FBSztFQUM1RCxhQUFhLGlCQUFpQixLQUFLO0NBQ3JDLEdBQUcsQ0FBQyxrQkFBa0IsTUFBTSxnQkFBZ0IsQ0FBQztDQUM3QyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSVIsU0FBc0I7RUFBRSxHQUFHO0VBQWEsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQzNGLGNBQ0E7R0FDRSxPQUFPO0dBQ1A7R0FDQSxjQUFjO0dBQ2Q7R0FDQSxpQkFBaUI7R0FDakIsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ3hCLGlCQUNBO0lBQ0UsT0FBTztJQUNQLFdBQVcsTUFBTTtJQUNqQixXQUFXLE1BQU07SUFDakI7SUFDQSxpQkFBaUI7SUFDakI7R0FDRixDQUNGO0VBQ0YsQ0FDRjtDQUFFLENBQUM7QUFDTCxHQUFHLFNBQVM7QUFDWixJQUFJLG1CQUFtQjtBQUN2QixJQUFJLGlCQUFpQyw2QkFBTSxXQUN6Qix5QkFBTyxTQUFTLGdCQUFnQixPQUFPLGNBQWM7Q0FDbkUsTUFBTSxVQUFVLGVBQWUsa0JBQWtCLE1BQU0sV0FBVztDQUNsRSxNQUFNLGNBQWMsbUJBQW1CLGtCQUFrQixNQUFNLFdBQVc7Q0FDMUUsTUFBTSxhQUFhLGtCQUFrQixrQkFBa0IsTUFBTSxXQUFXO0NBQ3hFLE1BQU0saUJBQWlCLHNCQUFzQixrQkFBa0IsTUFBTSxXQUFXO0NBQ2hGLE1BQU0sZUFBQSxhQUFxQixPQUFPLElBQUk7Q0FDdEMsTUFBTSxFQUFFLHNCQUFzQiwrQkFBK0I7Q0FDN0QsTUFBTSxRQUFRLEVBQUUsYUFBYSxNQUFNLFlBQVk7Q0FDL0MsTUFBTSxpQkFBQSxhQUF1QixrQkFBa0I7RUFDN0MsSUFBSSxhQUFhLFNBQVMsT0FBTyxhQUFhLGFBQWEsT0FBTztFQUNsRSxhQUFhLFVBQVU7Q0FDekIsR0FBRyxDQUFDLENBQUM7Q0FDTCxhQUFNLGdCQUFnQixnQkFBZ0IsQ0FBQyxjQUFjLENBQUM7Q0FDdEQsYUFBTSxnQkFBZ0I7RUFDcEIsTUFBTSxvQkFBb0IscUJBQXFCO0VBQy9DLGFBQWE7R0FDWCxPQUFPLGFBQWEsaUJBQWlCO0dBQ3JDLDJCQUEyQixJQUFJO0VBQ2pDO0NBQ0YsR0FBRyxDQUFDLHNCQUFzQiwwQkFBMEIsQ0FBQztDQUNyRCxNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsV0FBVyxlQUFlO0NBQzdFLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFlBQVk7RUFBRSxTQUFTO0VBQU0sR0FBRztFQUFPLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUMxRixjQUNBO0dBQ0UsSUFBSSxXQUFXO0dBQ2YsaUJBQWlCO0dBQ2pCLGlCQUFpQixRQUFRO0dBQ3pCLGlCQUFpQixRQUFRLE9BQU8sV0FBVyxZQUFZLEtBQUs7R0FDNUQsY0FBYyxhQUFhLFFBQVEsSUFBSTtHQUN2QyxHQUFHO0dBQ0gsS0FBSztHQUNMLFVBQVUsVUFBVTtJQUNsQixNQUFNLFVBQVUsS0FBSztJQUNyQixJQUFJLE1BQU0sWUFBWSxNQUFNLGtCQUFrQjtJQUM5QyxNQUFNLGNBQWMsTUFBTTtJQUMxQixJQUFJLENBQUMsUUFBUSxNQUFNLFFBQVEsYUFBYSxJQUFJO0dBQzlDO0dBQ0EsZUFBZSxxQkFDYixNQUFNLGVBQ04sV0FBVyxVQUFVO0lBQ25CLGVBQWUsWUFBWSxLQUFLO0lBQ2hDLElBQUksTUFBTSxrQkFBa0I7SUFDNUIsSUFBSSxDQUFDLE1BQU0sWUFBWSxDQUFDLFFBQVEsUUFBUSxDQUFDLGFBQWEsU0FBUztLQUM3RCxlQUFlLDJCQUEyQixJQUFJO0tBQzlDLGFBQWEsVUFBVSxPQUFPLGlCQUFpQjtNQUM3QyxRQUFRLGFBQWEsSUFBSTtNQUN6QixlQUFlO0tBQ2pCLEdBQUcsR0FBRztJQUNSO0dBQ0YsQ0FBQyxDQUNIO0dBQ0EsZ0JBQWdCLHFCQUNkLE1BQU0sZ0JBQ04sV0FBVyxVQUFVO0lBQ25CLGVBQWU7SUFDZixNQUFNLGNBQWMsUUFBUSxTQUFTLHNCQUFzQjtJQUMzRCxJQUFJLGFBQWE7S0FDZixNQUFNLE9BQU8sUUFBUSxTQUFTLFFBQVE7S0FDdEMsTUFBTSxZQUFZLFNBQVM7S0FDM0IsTUFBTSxRQUFRLFlBQVksS0FBSztLQUMvQixNQUFNLGtCQUFrQixZQUFZLFlBQVksU0FBUztLQUN6RCxNQUFNLGlCQUFpQixZQUFZLFlBQVksVUFBVTtLQUN6RCxlQUFlLDJCQUEyQjtNQUN4QyxNQUFNO09BR0o7UUFBRSxHQUFHLE1BQU0sVUFBVTtRQUFPLEdBQUcsTUFBTTtPQUFRO09BQzdDO1FBQUUsR0FBRztRQUFpQixHQUFHLFlBQVk7T0FBSTtPQUN6QztRQUFFLEdBQUc7UUFBZ0IsR0FBRyxZQUFZO09BQUk7T0FDeEM7UUFBRSxHQUFHO1FBQWdCLEdBQUcsWUFBWTtPQUFPO09BQzNDO1FBQUUsR0FBRztRQUFpQixHQUFHLFlBQVk7T0FBTztNQUM5QztNQUNBO0tBQ0YsQ0FBQztLQUNELE9BQU8sYUFBYSxxQkFBcUIsT0FBTztLQUNoRCxxQkFBcUIsVUFBVSxPQUFPLGlCQUM5QixlQUFlLDJCQUEyQixJQUFJLEdBQ3BELEdBQ0Y7SUFDRixPQUFPO0tBQ0wsZUFBZSxlQUFlLEtBQUs7S0FDbkMsSUFBSSxNQUFNLGtCQUFrQjtLQUM1QixlQUFlLDJCQUEyQixJQUFJO0lBQ2hEO0dBQ0YsQ0FBQyxDQUNIO0dBQ0EsV0FBVyxxQkFBcUIsTUFBTSxZQUFZLFVBQVU7SUFDMUQsSUFBSSxNQUFNLFlBQVksTUFBTSxXQUFXLE1BQU0sZUFDM0M7SUFHRixJQURzQixlQUFlLFVBQVUsWUFBWSxNQUN0QyxNQUFNLFFBQVEsS0FDakM7SUFFRixJQUFJLGNBQWMsWUFBWSxJQUFJLENBQUMsU0FBUyxNQUFNLEdBQUcsR0FBRztLQUN0RCxRQUFRLGFBQWEsSUFBSTtLQUN6QixRQUFRLFNBQVMsTUFBTTtLQUN2QixNQUFNLGVBQWU7SUFDdkI7R0FDRixDQUFDO0VBQ0gsQ0FDRjtDQUFFLENBQUM7QUFDTCxHQUFHLGdCQUFnQixDQUNyQjtBQUNBLElBQUksbUJBQW1CO0FBQ3ZCLElBQUksaUJBQWlDLDZCQUFNLFdBQ3pCLHlCQUFPLFNBQVMsZ0JBQWdCLE9BQU8sY0FBYztDQUNuRSxNQUFNLGdCQUFnQixpQkFBaUJHLGdCQUFjLE1BQU0sV0FBVztDQUN0RSxNQUFNLEVBQUUsYUFBYSxjQUFjLFlBQVksUUFBUSxTQUFTLEdBQUcsb0JBQW9CO0NBQ3ZGLE1BQU0sVUFBVSxlQUFlQSxnQkFBYyxNQUFNLFdBQVc7Q0FDOUQsTUFBTSxjQUFjLG1CQUFtQkEsZ0JBQWMsTUFBTSxXQUFXO0NBQ3RFLE1BQU0sYUFBYSxrQkFBa0Isa0JBQWtCLE1BQU0sV0FBVztDQUN4RSxNQUFNLE1BQUEsYUFBWSxPQUFPLElBQUk7Q0FDN0IsTUFBTSxlQUFlLGdCQUFnQixjQUFjLEdBQUc7Q0FDdEQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksV0FBVyxVQUFVO0VBQUUsT0FBTyxNQUFNO0VBQWEsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksVUFBVTtHQUFFLFNBQVMsY0FBYyxRQUFRO0dBQU0sVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksV0FBVyxNQUFNO0lBQUUsT0FBTyxNQUFNO0lBQWEsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQzlQLGlCQUNBO0tBQ0UsSUFBSSxXQUFXO0tBQ2YsbUJBQW1CLFdBQVc7S0FDOUIsR0FBRztLQUNILEtBQUs7S0FDTDtLQUNBLE1BQU0sWUFBWSxRQUFRLFFBQVEsU0FBUztLQUMzQyw2QkFBNkI7S0FDN0Isc0JBQXNCO0tBQ3RCLFdBQVc7S0FDWCxrQkFBa0IsVUFBVTtNQUMxQixJQUFJLFlBQVksbUJBQW1CLFNBQVMsSUFBSSxTQUFTLE1BQU07TUFDL0QsTUFBTSxlQUFlO0tBQ3ZCO0tBQ0EsbUJBQW1CLFVBQVUsTUFBTSxlQUFlO0tBQ2xELGdCQUFnQixxQkFBcUIsTUFBTSxpQkFBaUIsVUFBVTtNQUNwRSxJQUFJLE1BQU0sV0FBVyxXQUFXLFNBQVMsUUFBUSxhQUFhLEtBQUs7S0FDckUsQ0FBQztLQUNELGlCQUFpQixxQkFBcUIsTUFBTSxrQkFBa0IsVUFBVTtNQUN0RSxZQUFZLFFBQVE7TUFDcEIsTUFBTSxlQUFlO0tBQ3ZCLENBQUM7S0FDRCxXQUFXLHFCQUFxQixNQUFNLFlBQVksVUFBVTtNQUMxRCxNQUFNLGtCQUFrQixNQUFNLGNBQWMsU0FBUyxNQUFNLE1BQU07TUFDakUsTUFBTSxhQUFhLGVBQWUsWUFBWSxJQUFJLENBQUMsU0FBUyxNQUFNLEdBQUc7TUFDckUsSUFBSSxtQkFBbUIsWUFBWTtPQUNqQyxRQUFRLGFBQWEsS0FBSztPQUMxQixXQUFXLFNBQVMsTUFBTTtPQUMxQixNQUFNLGVBQWU7TUFDdkI7S0FDRixDQUFDO0lBQ0gsQ0FDRjtHQUFFLENBQUM7RUFBRSxDQUFDO0NBQUUsQ0FBQztBQUNYLEdBQUcsZ0JBQWdCLENBQ3JCO0FBQ0EsU0FBUyxhQUFhLE1BQU07Q0FDMUIsT0FBTyxPQUFPLFNBQVM7QUFDekI7QUFDQUosU0FBTyxjQUFjLGNBQWM7QUFDbkMsU0FBUyxnQkFBZ0IsU0FBUztDQUNoQyxPQUFPLFlBQVk7QUFDckI7QUFDQUEsU0FBTyxpQkFBaUIsaUJBQWlCO0FBQ3pDLFNBQVMsZ0JBQWdCLFNBQVM7Q0FDaEMsT0FBTyxnQkFBZ0IsT0FBTyxJQUFJLGtCQUFrQixVQUFVLFlBQVk7QUFDNUU7QUFDQUEsU0FBTyxpQkFBaUIsaUJBQWlCO0FBQ3pDLFNBQVMsV0FBVyxZQUFZO0NBQzlCLE1BQU0sNkJBQTZCLFNBQVM7Q0FDNUMsS0FBSyxNQUFNLGFBQWEsWUFBWTtFQUNsQyxJQUFJLGNBQWMsNEJBQTRCO0VBQzlDLFVBQVUsTUFBTTtFQUNoQixJQUFJLFNBQVMsa0JBQWtCLDRCQUE0QjtDQUM3RDtBQUNGO0FBQ0FBLFNBQU8sWUFBWSxZQUFZO0FBQy9CLFNBQVMsVUFBVSxPQUFPLFlBQVk7Q0FDcEMsT0FBTyxNQUFNLEtBQUssR0FBRyxVQUFVLE9BQU8sYUFBYSxTQUFTLE1BQU0sT0FBTztBQUMzRTtBQUNBQSxTQUFPLFdBQVcsV0FBVztBQUM3QixTQUFTLGFBQWEsUUFBUSxRQUFRLGNBQWM7Q0FFbEQsTUFBTSxtQkFEYSxPQUFPLFNBQVMsS0FBSyxNQUFNLEtBQUssTUFBTSxDQUFDLENBQUMsT0FBTyxTQUFTLFNBQVMsT0FBTyxFQUFFLElBQ3ZELE9BQU8sS0FBSztDQUNsRCxNQUFNLG9CQUFvQixlQUFlLE9BQU8sUUFBUSxZQUFZLElBQUk7Q0FDeEUsSUFBSSxnQkFBZ0IsVUFBVSxRQUFRLEtBQUssSUFBSSxtQkFBbUIsQ0FBQyxDQUFDO0NBRXBFLElBRDRCLGlCQUFpQixXQUFXLEdBQy9CLGdCQUFnQixjQUFjLFFBQVEsTUFBTSxNQUFNLFlBQVk7Q0FDdkYsTUFBTSxZQUFZLGNBQWMsTUFDN0IsVUFBVSxNQUFNLFlBQVksQ0FBQyxDQUFDLFdBQVcsaUJBQWlCLFlBQVksQ0FBQyxDQUMxRTtDQUNBLE9BQU8sY0FBYyxlQUFlLFlBQVksS0FBSztBQUN2RDtBQUNBQSxTQUFPLGNBQWMsY0FBYztBQUNuQyxTQUFTLGlCQUFpQixPQUFPLFNBQVM7Q0FDeEMsTUFBTSxFQUFFLEdBQUcsTUFBTTtDQUNqQixJQUFJLFNBQVM7Q0FDYixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxTQUFTLEdBQUcsSUFBSSxRQUFRLFFBQVEsSUFBSSxLQUFLO0VBQ25FLE1BQU0sS0FBSyxRQUFRO0VBQ25CLE1BQU0sS0FBSyxRQUFRO0VBQ25CLE1BQU0sS0FBSyxHQUFHO0VBQ2QsTUFBTSxLQUFLLEdBQUc7RUFDZCxNQUFNLEtBQUssR0FBRztFQUNkLE1BQU0sS0FBSyxHQUFHO0VBRWQsSUFEa0IsS0FBSyxNQUFNLEtBQUssS0FBSyxLQUFLLEtBQUssT0FBTyxJQUFJLE9BQU8sS0FBSyxNQUFNLElBQy9ELFNBQVMsQ0FBQztDQUMzQjtDQUNBLE9BQU87QUFDVDtBQUNBQSxTQUFPLGtCQUFrQixrQkFBa0I7QUFDM0MsU0FBUyxxQkFBcUIsT0FBTyxNQUFNO0NBQ3pDLElBQUksQ0FBQyxNQUFNLE9BQU87Q0FFbEIsT0FBTyxpQkFBaUI7RUFESixHQUFHLE1BQU07RUFBUyxHQUFHLE1BQU07Q0FDZixHQUFHLElBQUk7QUFDekM7QUFDQUEsU0FBTyxzQkFBc0Isc0JBQXNCO0FBQ25ELFNBQVMsVUFBVSxTQUFTO0NBQzFCLFFBQVEsVUFBVSxNQUFNLGdCQUFnQixVQUFVLFFBQVEsS0FBSyxJQUFJLEtBQUs7QUFDMUU7QUFDQUEsU0FBTyxXQUFXLFdBQVc7QUFDN0IsSUFBSSxRQUFRO0FBQ1osSUFBSSxVQUFVO0FBQ2QsSUFBSSxTQUFTO0FBQ2IsSUFBSVUsYUFBVztBQUNmLElBQUksUUFBUTtBQUNaLElBQUksUUFBUTtBQUNaLElBQUlDLFVBQVE7QUFDWixJQUFJLGVBQWU7QUFDbkIsSUFBSSxhQUFhO0FBQ2pCLElBQUksWUFBWTtBQUNoQixJQUFJLGdCQUFnQjtBQUNwQixJQUFJLFlBQVk7QUFDaEIsSUFBSUMsV0FBUztBQUNiLElBQUksTUFBTTtBQUNWLElBQUksYUFBYTtBQUNqQixJQUFJLGFBQWE7OztBQy8wQmpCLElBQUksWUFBWSxPQUFPO0FBQ3ZCLElBQUksVUFBVSxRQUFRLFVBQVUsVUFBVSxRQUFRLFFBQVE7Q0FBRTtDQUFPLGNBQWM7QUFBSyxDQUFDO0FBYXZGLElBQUkscUJBQXFCO0FBQ3pCLElBQUksQ0FBQywyQkFBMkIsMkJBQTJCLG1CQUN6RCxvQkFDQSxDQUFDLGVBQWUsQ0FDbEI7QUFDQSxJQUFJLGVBQWUsZ0JBQWdCO0FBQ25DLElBQUksQ0FBQyxzQkFBc0IsMEJBQTBCLDBCQUEwQixrQkFBa0I7QUFDakcsSUFBSSxlQUErQix3QkFBUSxVQUFVO0NBQ25ELE1BQU0sRUFDSixxQkFDQSxVQUNBLEtBQ0EsTUFBTSxVQUNOLGFBQ0EsY0FDQSxRQUFRLFNBQ047Q0FDSixNQUFNLFlBQVksYUFBYSxtQkFBbUI7Q0FDbEQsTUFBTSxhQUFBLGFBQW1CLE9BQU8sSUFBSTtDQUNwQyxNQUFNLENBQUMsTUFBTSxXQUFXLHFCQUFxQjtFQUMzQyxNQUFNO0VBQ04sYUFBYSxlQUFlO0VBQzVCLFVBQVU7RUFDVixRQUFRO0NBQ1YsQ0FBQztDQUNELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUNyQixzQkFDQTtFQUNFLE9BQU87RUFDUCxXQUFXLE1BQU07RUFDakI7RUFDQSxXQUFXLE1BQU07RUFDakI7RUFDQSxjQUFjO0VBQ2QsY0FBQSxhQUFvQixrQkFBa0IsU0FBUyxhQUFhLENBQUMsUUFBUSxHQUFHLENBQUMsT0FBTyxDQUFDO0VBQ2pGO0VBQ0EsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUlDLE9BQW9CO0dBQUUsR0FBRztHQUFXO0dBQU0sY0FBYztHQUFTO0dBQUs7R0FBTztFQUFTLENBQUM7Q0FDdkgsQ0FDRjtBQUNGLEdBQUcsY0FBYztBQUNqQixJQUFJLGVBQWU7QUFDbkIsSUFBSSxzQkFBc0MsNkJBQU0sV0FFOUIsdUJBQU8sU0FBUyxxQkFBcUIsT0FBTyxjQUFjO0NBQ3hFLE1BQU0sRUFBRSxxQkFBcUIsV0FBVyxPQUFPLEdBQUcsaUJBQWlCO0NBQ25FLE1BQU0sVUFBVSx1QkFBdUIsY0FBYyxtQkFBbUI7Q0FDeEUsTUFBTSxZQUFZLGFBQWEsbUJBQW1CO0NBQ2xELE1BQU0sZUFBZSxnQkFBZ0IsY0FBYyxRQUFRLFVBQVU7Q0FDckUsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUlDLFNBQXNCO0VBQUUsU0FBUztFQUFNLEdBQUc7RUFBVyxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FDeEcsVUFBVSxRQUNWO0dBQ0UsTUFBTTtHQUNOLElBQUksUUFBUTtHQUNaLGlCQUFpQjtHQUNqQixpQkFBaUIsUUFBUTtHQUN6QixpQkFBaUIsUUFBUSxPQUFPLFFBQVEsWUFBWSxLQUFLO0dBQ3pELGNBQWMsUUFBUSxPQUFPLFNBQVM7R0FDdEMsaUJBQWlCLFdBQVcsS0FBSyxLQUFLO0dBQ3RDO0dBQ0EsR0FBRztHQUNILEtBQUs7R0FDTCxlQUFlLHFCQUFxQixNQUFNLGdCQUFnQixVQUFVO0lBQ2xFLElBQUksQ0FBQyxZQUFZLE1BQU0sV0FBVyxLQUFLLE1BQU0sWUFBWSxPQUFPO0tBQzlELFFBQVEsYUFBYTtLQUNyQixJQUFJLENBQUMsUUFBUSxNQUFNLE1BQU0sZUFBZTtJQUMxQztHQUNGLENBQUM7R0FDRCxXQUFXLHFCQUFxQixNQUFNLFlBQVksVUFBVTtJQUMxRCxJQUFJLFVBQVU7SUFDZCxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxTQUFTLE1BQU0sR0FBRyxHQUFHLFFBQVEsYUFBYTtJQUM3RCxJQUFJLE1BQU0sUUFBUSxhQUFhLFFBQVEsYUFBYSxJQUFJO0lBQ3hELElBQUk7S0FBQztLQUFTO0tBQUs7SUFBVyxDQUFDLENBQUMsU0FBUyxNQUFNLEdBQUcsR0FBRyxNQUFNLGVBQWU7R0FDNUUsQ0FBQztFQUNILENBQ0Y7Q0FBRSxDQUFDO0FBQ0wsR0FBRyxxQkFBcUIsQ0FDMUI7QUFDQSxJQUFJLHFCQUFxQyx3QkFBUSxVQUFVO0NBQ3pELE1BQU0sRUFBRSxxQkFBcUIsR0FBRyxnQkFBZ0I7Q0FDaEQsTUFBTSxZQUFZLGFBQWEsbUJBQW1CO0NBQ2xELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJQyxRQUFzQjtFQUFFLEdBQUc7RUFBVyxHQUFHO0NBQVksQ0FBQztBQUNuRixHQUFHLG9CQUFvQjtBQUN2QixJQUFJLGVBQWU7QUFDbkIsSUFBSSxzQkFBc0MsNkJBQU0sV0FFOUIsdUJBQU8sU0FBUyxxQkFBcUIsT0FBTyxjQUFjO0NBQ3hFLE1BQU0sRUFBRSxxQkFBcUIsR0FBRyxpQkFBaUI7Q0FDakQsTUFBTSxVQUFVLHVCQUF1QixjQUFjLG1CQUFtQjtDQUN4RSxNQUFNLFlBQVksYUFBYSxtQkFBbUI7Q0FDbEQsTUFBTSwwQkFBQSxhQUFnQyxPQUFPLEtBQUs7Q0FDbEQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ3JCQyxZQUNBO0VBQ0UsSUFBSSxRQUFRO0VBQ1osbUJBQW1CLFFBQVE7RUFDM0IsR0FBRztFQUNILEdBQUc7RUFDSCxLQUFLO0VBQ0wsa0JBQWtCLHFCQUFxQixNQUFNLG1CQUFtQixVQUFVO0dBQ3hFLElBQUksQ0FBQyx3QkFBd0IsU0FBUyxRQUFRLFdBQVcsU0FBUyxNQUFNO0dBQ3hFLHdCQUF3QixVQUFVO0dBQ2xDLE1BQU0sZUFBZTtFQUN2QixDQUFDO0VBQ0QsbUJBQW1CLHFCQUFxQixNQUFNLG9CQUFvQixVQUFVO0dBQzFFLE1BQU0sZ0JBQWdCLE1BQU0sT0FBTztHQUNuQyxNQUFNLGdCQUFnQixjQUFjLFdBQVcsS0FBSyxjQUFjLFlBQVk7R0FDOUUsTUFBTSxlQUFlLGNBQWMsV0FBVyxLQUFLO0dBQ25ELElBQUksQ0FBQyxRQUFRLFNBQVMsY0FBYyx3QkFBd0IsVUFBVTtFQUN4RSxDQUFDO0VBQ0QsT0FBTztHQUNMLEdBQUcsTUFBTTtHQUdQLGtEQUFrRDtHQUNsRCxpREFBaUQ7R0FDakQsa0RBQWtEO0dBQ2xELHVDQUF1QztHQUN2Qyx3Q0FBd0M7RUFFNUM7Q0FDRixDQUNGO0FBQ0YsR0FBRyxxQkFBcUIsQ0FDMUI7QUFDQSxJQUFJLG9CQUFvQyw2QkFBTSxXQUU1Qix1QkFBTyxTQUFTLG1CQUFtQixPQUFPLGNBQWM7Q0FDdEUsTUFBTSxFQUFFLHFCQUFxQixHQUFHLGVBQWU7Q0FDL0MsTUFBTSxZQUFZLGFBQWEsbUJBQW1CO0NBQ2xELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJQyxPQUFxQjtFQUFFLEdBQUc7RUFBVyxHQUFHO0VBQVksS0FBSztDQUFhLENBQUM7QUFDcEcsR0FBRyxtQkFBbUIsQ0FDeEI7QUFDQSxJQUFJLG9CQUFvQyw2QkFBTSxXQUU1Qix1QkFBTyxTQUFTLG1CQUFtQixPQUFPLGNBQWM7Q0FDdEUsTUFBTSxFQUFFLHFCQUFxQixHQUFHLGVBQWU7Q0FDL0MsTUFBTSxZQUFZLGFBQWEsbUJBQW1CO0NBQ2xELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJQyxPQUFxQjtFQUFFLEdBQUc7RUFBVyxHQUFHO0VBQVksS0FBSztDQUFhLENBQUM7QUFDcEcsR0FBRyxtQkFBbUIsQ0FDeEI7QUFDQSxJQUFJLG1CQUFtQyw2QkFBTSxXQUUzQix1QkFBTyxTQUFTLGtCQUFrQixPQUFPLGNBQWM7Q0FDckUsTUFBTSxFQUFFLHFCQUFxQixHQUFHLGNBQWM7Q0FDOUMsTUFBTSxZQUFZLGFBQWEsbUJBQW1CO0NBQ2xELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJQyxTQUFvQjtFQUFFLEdBQUc7RUFBVyxHQUFHO0VBQVcsS0FBSztDQUFhLENBQUM7QUFDbEcsR0FBRyxrQkFBa0IsQ0FDdkI7QUFDQSxJQUFJLDJCQUEyQyw2QkFBTSxXQUEyQix1QkFBTyxTQUFTLDBCQUEwQixPQUFPLGNBQWM7Q0FDN0ksTUFBTSxFQUFFLHFCQUFxQixHQUFHLHNCQUFzQjtDQUN0RCxNQUFNLFlBQVksYUFBYSxtQkFBbUI7Q0FDbEQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUlDLGNBQTRCO0VBQUUsR0FBRztFQUFXLEdBQUc7RUFBbUIsS0FBSztDQUFhLENBQUM7QUFDbEgsR0FBRywwQkFBMEIsQ0FBQztBQUM5QixJQUFJLHlCQUF5Qyw2QkFBTSxXQUEyQix1QkFBTyxTQUFTLHdCQUF3QixPQUFPLGNBQWM7Q0FDekksTUFBTSxFQUFFLHFCQUFxQixHQUFHLG9CQUFvQjtDQUNwRCxNQUFNLFlBQVksYUFBYSxtQkFBbUI7Q0FDbEQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUlDLFlBQTBCO0VBQUUsR0FBRztFQUFXLEdBQUc7RUFBaUIsS0FBSztDQUFhLENBQUM7QUFDOUcsR0FBRyx3QkFBd0IsQ0FBQztBQUM1QixJQUFJLHdCQUF3Qyw2QkFBTSxXQUEyQix1QkFBTyxTQUFTLHVCQUF1QixPQUFPLGNBQWM7Q0FDdkksTUFBTSxFQUFFLHFCQUFxQixHQUFHLG1CQUFtQjtDQUNuRCxNQUFNLFlBQVksYUFBYSxtQkFBbUI7Q0FDbEQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUlDLFdBQXlCO0VBQUUsR0FBRztFQUFXLEdBQUc7RUFBZ0IsS0FBSztDQUFhLENBQUM7QUFDNUcsR0FBRyx1QkFBdUIsQ0FBQztBQUMzQixJQUFJLDRCQUE0Qyw2QkFBTSxXQUEyQix1QkFBTyxTQUFTLDJCQUEyQixPQUFPLGNBQWM7Q0FDL0ksTUFBTSxFQUFFLHFCQUFxQixHQUFHLHVCQUF1QjtDQUN2RCxNQUFNLFlBQVksYUFBYSxtQkFBbUI7Q0FDbEQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUlDLGVBQTZCO0VBQUUsR0FBRztFQUFXLEdBQUc7RUFBb0IsS0FBSztDQUFhLENBQUM7QUFDcEgsR0FBRywyQkFBMkIsQ0FBQztBQUMvQixJQUFJLHdCQUF3Qyw2QkFBTSxXQUEyQix1QkFBTyxTQUFTLHVCQUF1QixPQUFPLGNBQWM7Q0FDdkksTUFBTSxFQUFFLHFCQUFxQixHQUFHLG1CQUFtQjtDQUNuRCxNQUFNLFlBQVksYUFBYSxtQkFBbUI7Q0FDbEQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUlDLFdBQXlCO0VBQUUsR0FBRztFQUFXLEdBQUc7RUFBZ0IsS0FBSztDQUFhLENBQUM7QUFDNUcsR0FBRyx1QkFBdUIsQ0FBQztBQUMzQixJQUFJLG9CQUFvQyw2QkFBTSxXQUU1Qix1QkFBTyxTQUFTLG1CQUFtQixPQUFPLGNBQWM7Q0FDdEUsTUFBTSxFQUFFLHFCQUFxQixHQUFHLGVBQWU7Q0FDL0MsTUFBTSxZQUFZLGFBQWEsbUJBQW1CO0NBQ2xELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJQyxVQUFxQjtFQUFFLEdBQUc7RUFBVyxHQUFHO0VBQVksS0FBSztDQUFhLENBQUM7QUFDcEcsR0FBRyxtQkFBbUIsQ0FDeEI7QUFDQSxJQUFJLGtCQUFrQyx3QkFBUSxVQUFVO0NBQ3RELE1BQU0sRUFBRSxxQkFBcUIsVUFBVSxNQUFNLFVBQVUsY0FBYyxnQkFBZ0I7Q0FDckYsTUFBTSxZQUFZLGFBQWEsbUJBQW1CO0NBQ2xELE1BQU0sQ0FBQyxNQUFNLFdBQVcscUJBQXFCO0VBQzNDLE1BQU07RUFDTixhQUFhLGVBQWU7RUFDNUIsVUFBVTtFQUNWLFFBQVE7Q0FDVixDQUFDO0NBQ0QsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUlDLEtBQW1CO0VBQUUsR0FBRztFQUFXO0VBQU0sY0FBYztFQUFTO0NBQVMsQ0FBQztBQUN2RyxHQUFHLGlCQUFpQjtBQUNwQixJQUFJLHlCQUF5Qyw2QkFBTSxXQUEyQix1QkFBTyxTQUFTLHdCQUF3QixPQUFPLGNBQWM7Q0FDekksTUFBTSxFQUFFLHFCQUFxQixHQUFHLG9CQUFvQjtDQUNwRCxNQUFNLFlBQVksYUFBYSxtQkFBbUI7Q0FDbEQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUlDLFlBQTBCO0VBQUUsR0FBRztFQUFXLEdBQUc7RUFBaUIsS0FBSztDQUFhLENBQUM7QUFDOUcsR0FBRyx3QkFBd0IsQ0FBQztBQUM1QixJQUFJLHlCQUF5Qyw2QkFBTSxXQUEyQix1QkFBTyxTQUFTLHdCQUF3QixPQUFPLGNBQWM7Q0FDekksTUFBTSxFQUFFLHFCQUFxQixHQUFHLG9CQUFvQjtDQUNwRCxNQUFNLFlBQVksYUFBYSxtQkFBbUI7Q0FDbEQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQ3JCQyxZQUNBO0VBQ0UsR0FBRztFQUNILEdBQUc7RUFDSCxLQUFLO0VBQ0wsT0FBTztHQUNMLEdBQUcsTUFBTTtHQUdQLGtEQUFrRDtHQUNsRCxpREFBaUQ7R0FDakQsa0RBQWtEO0dBQ2xELHVDQUF1QztHQUN2Qyx3Q0FBd0M7RUFFNUM7Q0FDRixDQUNGO0FBQ0YsR0FBRyx3QkFBd0IsQ0FBQztBQUM1QixJQUFJLFFBQVE7QUFDWixJQUFJLFVBQVU7QUFDZCxJQUFJLFVBQVU7QUFDZCxJQUFJLFdBQVc7QUFDZixJQUFJLFNBQVM7QUFDYixJQUFJLFNBQVM7QUFDYixJQUFJLFFBQVE7QUFDWixJQUFJLGdCQUFnQjtBQUNwQixJQUFJLGNBQWM7QUFDbEIsSUFBSSxhQUFhO0FBQ2pCLElBQUksaUJBQWlCO0FBQ3JCLElBQUksYUFBYTtBQUNqQixJQUFJLFNBQVM7QUFDYixJQUFJLE9BQU87QUFDWCxJQUFJLGNBQWM7QUFDbEIsSUFBSSxjQUFjIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMV19