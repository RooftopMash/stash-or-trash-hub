import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LiveBroadcastModal.tsx");const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport15_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport15_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "/src/components/ui/dialog.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Badge } from "/src/components/ui/badge.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Video, Radio, Mic, MicOff, VideoOff, Eye, MessageSquare, Sparkles, Building2, Share2, ShieldCheck, CircleDot, Phone, MonitorUp, AlertTriangle, MapPin, Hash, UserCheck, BellRing, Rocket, Gift, Coins, Recycle, Check, Users } from "/node_modules/.vite/deps/lucide-react.js?v=a8030269";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=a8030269";
import { supabase } from "/src/integrations/supabase/client.ts";
import { useAuth } from "/src/hooks/useAuth.tsx";
import { useRoles } from "/src/hooks/useRoles.tsx";
import { fetchFeed } from "/src/lib/stash.ts";
import { sendMessage } from "/src/lib/messages.ts";
import { playCoinSpinSound, playTrashSound } from "/src/lib/verdict-sounds.ts";
import { BRAND_BROADCAST_CATEGORIES, CONSUMER_BROADCAST_CATEGORIES, publishLiveBroadcastSession, voteOnLiveBroadcast, claimLiveLaunchPerk, getLiveBroadcastSessions } from "/src/lib/live-broadcasts.ts";
import { getActiveDeskOperator, recordOperatorResolutionMetric } from "/src/lib/brand-operators.ts";
var _jsxFileName = "/app/applet/src/components/LiveBroadcastModal.tsx";
import __vite__cjsImport15_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
var _s = $RefreshSig$();
const GOOGLE_STUN_SERVERS = [
	{ urls: "stun:stun.l.google.com:19302" },
	{ urls: "stun:stun1.l.google.com:19302" },
	{ urls: "stun:stun2.l.google.com:19302" }
];
export function LiveBroadcastModal({ open, onOpenChange, brandName = "SOT Community Studio", brandSlug, brandOwner = "Verified Trust Network", productName = "Live Session", scanResult, recipientId: initialRecipientId, recipientName: initialRecipientName, defaultMode = "video_call", customRoomChannel, callDirection: initialCallDirection = "brand_to_user", initialPersona, initialBrandCategory = "product_launch", activeBroadcastId }) {
	_s();
	const { user } = useAuth();
	const { isBrand, isDeveloper } = useRoles();
	const [studioPersona, setStudioPersona] = useState(initialPersona ?? (isBrand ? "brand_owner" : "consumer"));
	const [brandCategory, setBrandCategory] = useState(initialBrandCategory);
	const [situationType, setSituationType] = useState("counterfeit");
	const [broadcastHeadline, setBroadcastHeadline] = useState(productName || `${brandName} Live Product Launch & Q&A`);
	const [broadcastSubtitle, setBroadcastSubtitle] = useState(`Tune in live with ${brandName} — cast your Stash or Trash verdict in real time and claim today's live viewer perk!`);
	// Live Launch Perk / Promo Drop Controls (for Brand Owners)
	const [enableLaunchPerk, setEnableLaunchPerk] = useState(true);
	const [perkTitle, setPerkTitle] = useState(`25% Off ${brandName} Launch Special`);
	const [perkPromoCode, setPerkPromoCode] = useState(`${brandName.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6) || "SOT"}_LAUNCH25`);
	const [perkDiscountLabel, setPerkDiscountLabel] = useState("25% OFF LAUNCH VOUCHER");
	const [perkClaimedCount, setPerkClaimedCount] = useState(18);
	const [perkTotalAvailable, setPerkTotalAvailable] = useState(150);
	const [hasClaimedInSession, setHasClaimedInSession] = useState(false);
	// Real-Time Launch Pulse (Stash vs Trash Market Research Meter)
	const [currentBroadcastId, setCurrentBroadcastId] = useState(activeBroadcastId || `live-${Date.now()}`);
	const [liveStashVotes, setLiveStashVotes] = useState(42);
	const [liveTrashVotes, setLiveTrashVotes] = useState(5);
	const [myLiveVerdict, setMyLiveVerdict] = useState(null);
	const [followersAlertedCount, setFollowersAlertedCount] = useState(0);
	const [isLive, setIsLive] = useState(false);
	const [consumerSecondsLeft, setConsumerSecondsLeft] = useState(90);
	const activeDeskOperator = getActiveDeskOperator();
	const [sessionMode, setSessionMode] = useState(defaultMode);
	const [callDirection, setCallDirection] = useState(initialCallDirection);
	const [targetRecipientId, setTargetRecipientId] = useState(initialRecipientId || "");
	const [targetRecipientName, setTargetRecipientName] = useState(initialRecipientName || "");
	const [platformContacts, setPlatformContacts] = useState([]);
	const [ringingSent, setRingingSent] = useState(false);
	const [cameraOn, setCameraOn] = useState(true);
	const [micOn, setMicOn] = useState(true);
	const [screenSharing, setScreenSharing] = useState(false);
	const [viewerCount, setViewerCount] = useState(14);
	const [engineUsed, setEngineUsed] = useState("Google WebRTC (stun.l.google.com)");
	const [roomChannel, setRoomChannel] = useState("");
	const [peerJoined, setPeerJoined] = useState(false);
	// Situation & Counterfeit Batch Metadata
	const [batchNumber, setBatchNumber] = useState("");
	const [storeLocation, setStoreLocation] = useState("");
	const [chatMessages, setChatMessages] = useState([]);
	const [chatInput, setChatInput] = useState("");
	const videoRef = useRef(null);
	const remoteVideoRef = useRef(null);
	const streamRef = useRef(null);
	const pcRef = useRef(null);
	const agoraClientRef = useRef(null);
	const agoraAudioRef = useRef(null);
	const agoraVideoRef = useRef(null);
	const bcRef = useRef(null);
	const supaChanRef = useRef(null);
	const cleanupSession = useCallback(async () => {
		try {
			agoraAudioRef.current?.close();
			agoraVideoRef.current?.close();
			agoraAudioRef.current = null;
			agoraVideoRef.current = null;
			if (agoraClientRef.current) {
				await agoraClientRef.current.leave();
				agoraClientRef.current = null;
			}
		} catch {}
		if (pcRef.current) {
			pcRef.current.close();
			pcRef.current = null;
		}
		if (bcRef.current) {
			bcRef.current.close();
			bcRef.current = null;
		}
		if (supaChanRef.current) {
			void supabase.removeChannel(supaChanRef.current);
			supaChanRef.current = null;
		}
		if (streamRef.current) {
			streamRef.current.getTracks().forEach((t) => t.stop());
			streamRef.current = null;
		}
		setIsLive(false);
		setPeerJoined(false);
		setScreenSharing(false);
	}, []);
	// Sync props when opened for a specific User, Brand, or Existing Live Session
	useEffect(() => {
		if (open) {
			if (initialRecipientId) setTargetRecipientId(initialRecipientId);
			if (initialRecipientName) setTargetRecipientName(initialRecipientName);
			if (defaultMode) setSessionMode(defaultMode);
			if (initialCallDirection) setCallDirection(initialCallDirection);
			if (initialPersona) {
				setStudioPersona(initialPersona);
			} else {
				setStudioPersona(isBrand ? "brand_owner" : "consumer");
			}
			if (initialBrandCategory) setBrandCategory(initialBrandCategory);
			setRingingSent(false);
			setHasClaimedInSession(false);
			// If joining an active broadcast from the Home/Feed Live Stage, hydrate its metrics
			if (activeBroadcastId) {
				setCurrentBroadcastId(activeBroadcastId);
				const existing = getLiveBroadcastSessions().find((s) => s.id === activeBroadcastId);
				if (existing) {
					setStudioPersona(existing.persona);
					setBroadcastHeadline(existing.title);
					setBroadcastSubtitle(existing.subtitle);
					setLiveStashVotes(existing.stashVotes);
					setLiveTrashVotes(existing.trashVotes);
					setViewerCount(existing.viewerCount + 1);
					if (existing.brandCategory) setBrandCategory(existing.brandCategory);
					if (existing.consumerCategory) setSituationType(existing.consumerCategory);
					if (existing.launchPerk) {
						setEnableLaunchPerk(true);
						setPerkTitle(existing.launchPerk.title);
						setPerkPromoCode(existing.launchPerk.promoCode);
						setPerkDiscountLabel(existing.launchPerk.discountLabel);
						setPerkClaimedCount(existing.launchPerk.claimedCount);
						setPerkTotalAvailable(existing.launchPerk.totalAvailable);
					}
				}
			} else {
				const cleanPrefix = brandName.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6) || "SOT";
				setBroadcastHeadline(productName && productName !== "Live Session" ? productName : `${brandName} Live Product Launch & Client Showcase`);
				setPerkTitle(`25% Off ${brandName} Launch Special`);
				setPerkPromoCode(`${cleanPrefix}_LAUNCH25`);
			}
			// Load active users/authors from feed so Brand Owners or Users can pick a client/peer to call
			void fetchFeed(null).then((items) => {
				const seen = new Set();
				const list = [];
				for (const it of items) {
					if (it.user_id && !seen.has(it.user_id)) {
						seen.add(it.user_id);
						list.push({
							id: it.user_id,
							name: it.authorName || `User ${it.user_id.slice(0, 6)}`,
							context: `${it.brandName ? `${it.brandName}: ` : ""}${it.title.slice(0, 40)}`
						});
					}
				}
				if (list.length === 0) {
					list.push({
						id: "client-thabo",
						name: "Thabo M. (Verified Client)",
						context: "Reported batch inquiry on SOT"
					}, {
						id: "client-lerato",
						name: "Lerato K. (Active Voter)",
						context: "Recent Stash/Trash reviewer"
					});
				}
				setPlatformContacts(list.slice(0, 20));
				if (!initialRecipientName && list[0]) {
					setTargetRecipientId(list[0].id);
					setTargetRecipientName(list[0].name);
				}
			}).catch(() => {
				// ignore
			});
		}
	}, [
		open,
		initialRecipientId,
		initialRecipientName,
		defaultMode,
		initialCallDirection,
		initialPersona,
		initialBrandCategory,
		activeBroadcastId,
		brandName,
		productName,
		isBrand
	]);
	// Setup camera/mic preview when modal is opened
	useEffect(() => {
		let active = true;
		if (open) {
			const slug = customRoomChannel || `sot-call-${(targetRecipientId || brandName).toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 22)}`;
			setRoomChannel(slug);
			navigator.mediaDevices?.getUserMedia({
				video: sessionMode !== "voice_call",
				audio: true
			}).then((s) => {
				if (!active) {
					s.getTracks().forEach((t) => t.stop());
					return;
				}
				streamRef.current = s;
				if (videoRef.current && sessionMode !== "voice_call") {
					videoRef.current.srcObject = s;
				}
			}).catch((err) => {
				console.warn("Camera/mic permission notice:", err);
				toast.warning("Camera or microphone permission not granted. Preview mode enabled.");
			});
		} else {
			void cleanupSession();
		}
		return () => {
			active = false;
		};
	}, [
		open,
		brandName,
		targetRecipientId,
		customRoomChannel,
		sessionMode,
		cleanupSession
	]);
	const handleCategoryPresetChange = (cat) => {
		setBrandCategory(cat);
		const cleanPrefix = brandName.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6) || "SOT";
		if (cat === "product_launch") {
			setBroadcastHeadline(`LIVE LAUNCH: ${brandName} New Product & Innovation Reveal`);
			setBroadcastSubtitle(`Unveiling our newest release live for SOT clients & prospects. Vote Stash or Trash live!`);
			setPerkTitle(`25% Off ${brandName} New Launch`);
			setPerkPromoCode(`${cleanPrefix}_LAUNCH25`);
			setPerkDiscountLabel("25% OFF LAUNCH VOUCHER");
		} else if (cat === "brand_relaunch") {
			setBroadcastHeadline(`RELAUNCH SPECIAL: ${brandName} Upgraded Service & Quality Promise`);
			setBroadcastSubtitle(`You spoke on SOT, and we listened! See the upgrades we made based on your verdicts.`);
			setPerkTitle(`${brandName} Comeback Recovery Voucher`);
			setPerkPromoCode(`${cleanPrefix}_RELAUNCH50`);
			setPerkDiscountLabel("COMEBACK VIP VOUCHER");
		} else if (cat === "behind_scenes") {
			setBroadcastHeadline(`BEHIND THE SCENES: Inside ${brandName} Quality & Authenticity Lab`);
			setBroadcastSubtitle(`Live walkthrough of our operations and batch verification standards.`);
			setPerkTitle(`Verified Authentic Buyer Pass`);
			setPerkPromoCode(`${cleanPrefix}_AUTH15`);
			setPerkDiscountLabel("15% AUTHENTIC PASS");
		} else if (cat === "townhall_qa") {
			setBroadcastHeadline(`LIVE TOWNHALL Q&A: ${brandName} Leadership Answering Your Questions`);
			setBroadcastSubtitle(`Ask us anything live in the chat or request to join on camera with our CX & Product team.`);
			setPerkTitle(`Townhall Participant Loyalty Reward`);
			setPerkPromoCode(`${cleanPrefix}_TOWNHALL`);
			setPerkDiscountLabel("VIP TOWNHALL PERK");
		} else if (cat === "flash_drop") {
			setBroadcastHeadline(`FLASH PERK DROP: ${brandName} Exclusive Live Viewer Giveaway`);
			setBroadcastSubtitle(`Limited-time reward drop for our SOT followers and live prospects!`);
			setPerkTitle(`Flash 40% Off VIP Code`);
			setPerkPromoCode(`${cleanPrefix}_FLASH40`);
			setPerkDiscountLabel("40% FLASH DROP");
		}
	};
	const ringRecipientOnPlatform = useCallback(async (channelToRing) => {
		const resolvedRecipientName = targetRecipientName.trim() || brandName || "SOT User";
		const resolvedRecipientId = targetRecipientId.trim() || "sot-community-member";
		const callerDisplay = callDirection === "brand_to_user" ? `${brandName} (Brand Owner / CX Desk)` : user?.email?.split("@")[0] || "SOT Member";
		const ringPayload = {
			callId: `call-${Date.now()}`,
			callerId: user?.id || "brand-operator",
			callerName: callerDisplay,
			callDirection,
			recipientId: resolvedRecipientId,
			recipientName: resolvedRecipientName,
			brandName,
			topic: broadcastHeadline || productName || `${brandName} Resolution Call`,
			mode: sessionMode,
			roomChannel: channelToRing,
			timestamp: new Date().toISOString()
		};
		// 1. Ring in real-time via BroadcastChannel (same browser / multi-tab preview)
		if (typeof BroadcastChannel !== "undefined") {
			const ringBc = new BroadcastChannel("sot-call-ring");
			ringBc.postMessage(ringPayload);
			ringBc.close();
		}
		// 2. Ring across devices via Supabase Realtime broadcast channel
		try {
			const ringChan = supabase.channel("sot-call-ring");
			ringChan.subscribe((status) => {
				if (status === "SUBSCRIBED") {
					void ringChan.send({
						type: "broadcast",
						event: "incoming-call",
						payload: ringPayload
					});
				}
			});
		} catch {}
		// 3. Also drop an automatic Direct Call Alert in the user's SOT Inbox (in case they aren't on their phone)
		if (user?.id && resolvedRecipientId && resolvedRecipientId !== user.id) {
			const origin = typeof window !== "undefined" ? window.location.origin : "https://sort.app";
			const callLink = `${origin}/messages?to=${encodeURIComponent(user.id)}&room=${encodeURIComponent(channelToRing)}`;
			const modeLabel = sessionMode === "voice_call" ? "Voice Call" : sessionMode === "video_call" ? "Video Call" : studioPersona === "brand_owner" ? "Live Brand Launch Broadcast" : "Live Situation Broadcast";
			void sendMessage({
				senderId: user.id,
				recipientId: resolvedRecipientId,
				body: `📞 INCOMING ${modeLabel.toUpperCase()} ON SOT from ${callerDisplay} (regarding ${brandName} — ${broadcastHeadline}). Click to join our live room (${channelToRing}): ${callLink}`
			});
		}
		setRingingSent(true);
		toast.success(`Ringing ${resolvedRecipientName} directly on SOT (${sessionMode === "voice_call" ? "Voice" : "Video"}) + sent direct link to their SOT Inbox!`);
	}, [
		targetRecipientName,
		targetRecipientId,
		brandName,
		broadcastHeadline,
		productName,
		callDirection,
		sessionMode,
		studioPersona,
		user
	]);
	const toggleCamera = () => {
		const next = !cameraOn;
		setCameraOn(next);
		if (streamRef.current) {
			streamRef.current.getVideoTracks().forEach((t) => {
				t.enabled = next;
			});
		}
		if (agoraVideoRef.current) {
			void agoraVideoRef.current.setEnabled(next);
		}
	};
	const toggleMic = () => {
		const next = !micOn;
		setMicOn(next);
		if (streamRef.current) {
			streamRef.current.getAudioTracks().forEach((t) => {
				t.enabled = next;
			});
		}
		if (agoraAudioRef.current) {
			void agoraAudioRef.current.setEnabled(next);
		}
	};
	const toggleScreenShare = async () => {
		if (!navigator.mediaDevices?.getDisplayMedia) {
			toast.error("Screen sharing is not supported on this browser.");
			return;
		}
		try {
			const displayStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
			const screenTrack = displayStream.getVideoTracks()[0];
			if (!screenTrack) return;
			if (videoRef.current) {
				videoRef.current.srcObject = displayStream;
			}
			if (pcRef.current) {
				const sender = pcRef.current.getSenders().find((s) => s.track?.kind === "video");
				if (sender) await sender.replaceTrack(screenTrack);
			}
			setScreenSharing(true);
			toast.success("Sharing screen / presentation deck live!");
			screenTrack.onended = () => {
				setScreenSharing(false);
				if (streamRef.current && videoRef.current) {
					videoRef.current.srcObject = streamRef.current;
				}
			};
		} catch {
			toast.info("Screen sharing cancelled.");
		}
	};
	const startBroadcast = async () => {
		try {
			const res = await fetch("/api/agora-token", {
				method: "POST",
				headers: { "content-type": "application/json" },
				body: JSON.stringify({
					channelName: roomChannel || `sot-live-${Date.now()}`,
					partnerId: brandName || "community",
					mode: sessionMode === "voice_call" ? "voice" : sessionMode === "video_call" ? "video" : "broadcast"
				})
			});
			const tokenData = await res.json();
			const channel = tokenData.channelName || roomChannel || "sot-live-room";
			setRoomChannel(channel);
			if (tokenData.provider === "agora" && tokenData.appId && tokenData.token && tokenData.uid) {
				setEngineUsed("Agora RTC + Google STUN");
				const { default: AgoraRTC } = await import('/node_modules/.vite/deps/agora-rtc-sdk-ng.js?v=a8030269').then(m => ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(m.default, 1));
				const client = AgoraRTC.createClient({
					mode: "rtc",
					codec: "vp8"
				});
				agoraClientRef.current = client;
				client.on("user-published", async (remoteUser, mediaType) => {
					await client.subscribe(remoteUser, mediaType);
					if (mediaType === "audio") remoteUser.audioTrack?.play();
					if (mediaType === "video" && remoteVideoRef.current) {
						remoteUser.videoTrack?.play(remoteVideoRef.current);
					}
					setPeerJoined(true);
					setViewerCount((c) => c + 1);
				});
				await client.join(tokenData.appId, channel, tokenData.token, tokenData.uid);
				agoraAudioRef.current = await AgoraRTC.createMicrophoneAudioTrack();
				await client.publish(agoraAudioRef.current);
				if (sessionMode !== "voice_call") {
					agoraVideoRef.current = await AgoraRTC.createCameraVideoTrack();
					await client.publish(agoraVideoRef.current);
				}
			} else {
				setEngineUsed("Google WebRTC (stun.l.google.com)");
				const pc = new RTCPeerConnection({ iceServers: tokenData.iceServers ?? GOOGLE_STUN_SERVERS });
				pcRef.current = pc;
				if (streamRef.current) {
					streamRef.current.getTracks().forEach((track) => {
						if (streamRef.current) pc.addTrack(track, streamRef.current);
					});
				}
				pc.ontrack = (ev) => {
					const [remoteStream] = ev.streams;
					if (remoteStream && remoteVideoRef.current) {
						remoteVideoRef.current.srcObject = remoteStream;
						setPeerJoined(true);
					}
				};
				const emitSignal = (payload) => {
					bcRef.current?.postMessage(payload);
					void supaChanRef.current?.send({
						type: "broadcast",
						event: "sot-live-signal",
						payload
					});
				};
				pc.onicecandidate = (ev) => {
					if (ev.candidate) {
						emitSignal({
							type: "candidate",
							candidate: ev.candidate.toJSON()
						});
					}
				};
				const handleSignal = async (data) => {
					if (!pcRef.current) return;
					try {
						if (data.type === "chat" && data.message) {
							setChatMessages((prev) => [...prev, data.message]);
							return;
						}
						if (data.type === "live-vote" && (data.verdict === "stash" || data.verdict === "trash")) {
							if (data.verdict === "stash") setLiveStashVotes((v) => v + 1);
							else setLiveTrashVotes((v) => v + 1);
							return;
						}
						if (data.type === "join") {
							setViewerCount((v) => v + 1);
							const offer = await pcRef.current.createOffer();
							await pcRef.current.setLocalDescription(offer);
							emitSignal({
								type: "offer",
								sdp: offer
							});
						} else if (data.type === "offer") {
							await pcRef.current.setRemoteDescription(new RTCSessionDescription(data.sdp));
							const answer = await pcRef.current.createAnswer();
							await pcRef.current.setLocalDescription(answer);
							emitSignal({
								type: "answer",
								sdp: answer
							});
							setPeerJoined(true);
						} else if (data.type === "answer" && pcRef.current.signalingState === "have-local-offer") {
							await pcRef.current.setRemoteDescription(new RTCSessionDescription(data.sdp));
							setPeerJoined(true);
						} else if (data.type === "candidate" && data.candidate) {
							await pcRef.current.addIceCandidate(new RTCIceCandidate(data.candidate));
						}
					} catch {}
				};
				if (typeof BroadcastChannel !== "undefined") {
					const bc = new BroadcastChannel(`sot-live-${channel}`);
					bc.onmessage = (e) => void handleSignal(e.data);
					bcRef.current = bc;
				}
				const supaChan = supabase.channel(`sot-live-${channel}`).on("broadcast", { event: "sot-live-signal" }, ({ payload }) => {
					if (payload) void handleSignal(payload);
				}).subscribe((status) => {
					if (status === "SUBSCRIBED") {
						emitSignal({ type: "join" });
					}
				});
				supaChanRef.current = supaChan;
				emitSignal({ type: "join" });
			}
			// Publish to the Home & Feed Live Broadcast Stage!
			const notifiedFollowers = studioPersona === "brand_owner" ? Math.floor(850 + Math.random() * 2400) : 0;
			setFollowersAlertedCount(notifiedFollowers);
			const published = publishLiveBroadcastSession({
				id: activeBroadcastId || currentBroadcastId,
				roomChannel: channel,
				persona: studioPersona,
				brandName,
				brandSlug: brandSlug || brandName.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
				brandOwner,
				hostName: studioPersona === "brand_owner" ? `${brandName} Official Broadcast Team` : user?.email?.split("@")[0] || "Verified SOT Member",
				hostRoleLabel: studioPersona === "brand_owner" ? "Verified Brand Owner · Executive Studio" : "Verified Consumer · Live Situation Cam",
				title: broadcastHeadline.trim() || `${brandName} Live Session`,
				subtitle: broadcastSubtitle.trim(),
				brandCategory: studioPersona === "brand_owner" ? brandCategory : undefined,
				consumerCategory: studioPersona === "consumer" ? situationType : undefined,
				batchNumber: batchNumber.trim() || undefined,
				storeLocation: storeLocation.trim() || undefined,
				viewerCount: Math.max(viewerCount, studioPersona === "brand_owner" ? 48 : 12),
				stashVotes: liveStashVotes,
				trashVotes: liveTrashVotes,
				followersNotified: notifiedFollowers,
				launchPerk: studioPersona === "brand_owner" && enableLaunchPerk && perkPromoCode.trim() ? {
					title: perkTitle.trim() || `${brandName} Launch Voucher`,
					promoCode: perkPromoCode.trim().toUpperCase(),
					discountLabel: perkDiscountLabel.trim() || "LIVE LAUNCH PERK",
					totalAvailable: perkTotalAvailable,
					claimedCount: perkClaimedCount
				} : undefined
			});
			setCurrentBroadcastId(published.id);
			setConsumerSecondsLeft(90);
			setIsLive(true);
			if (studioPersona === "brand_owner") {
				recordOperatorResolutionMetric("launch_broadcast", `Hosted live Brand Broadcast "${broadcastHeadline.trim() || brandName}" (${notifiedFollowers.toLocaleString()} followers alerted).`);
			}
			if (sessionMode !== "broadcast") {
				await ringRecipientOnPlatform(channel);
			}
			const initialMessages = [{
				sender: "SOT Live Studio",
				text: studioPersona === "brand_owner" ? `🚀 ${brandName} is now LIVE on the Home Feed & Brand Stage! Auto-alerted ${notifiedFollowers.toLocaleString()} followers & prospects. Viewers can now vote Stash or Trash live on your launch!` : `📹 Consumer Situation Stream is now LIVE on the SOT Feed via ${engineUsed}.`,
				time: new Date().toLocaleTimeString([], {
					hour: "2-digit",
					minute: "2-digit"
				})
			}];
			if (studioPersona === "brand_owner" && enableLaunchPerk && perkPromoCode.trim()) {
				initialMessages.push({
					sender: `${brandName} (Official Perk Drop)`,
					text: `🎁 LIVE LAUNCH PERK UNLOCKED: "${perkTitle}" — Use code ${perkPromoCode.toUpperCase()} (${perkDiscountLabel}). Click "Claim Launch Perk" on screen to save to your SOT Wallet!`,
					time: new Date().toLocaleTimeString([], {
						hour: "2-digit",
						minute: "2-digit"
					}),
					isHost: true,
					isPerkDrop: true
				});
			}
			setChatMessages(initialMessages);
			toast.success(studioPersona === "brand_owner" ? `🚀 ${brandName} Launch Broadcast is LIVE on the Home Feed! ${notifiedFollowers.toLocaleString()} followers notified.` : "📹 Live Situation Broadcast started on the SOT Feed!");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not start live session");
		}
	};
	const endBroadcast = useCallback(async () => {
		await cleanupSession();
		toast.info("Live session ended. Launch pulse metrics & audit log saved.");
		onOpenChange(false);
	}, [cleanupSession, onOpenChange]);
	// Enforce 90-second maximum duration on normal Consumer Situation Broadcasts
	// so Brand Owners cannot use free personal profiles for extended commercial product launches.
	useEffect(() => {
		if (!isLive || studioPersona !== "consumer" || sessionMode !== "broadcast") {
			return;
		}
		const timer = window.setInterval(() => {
			setConsumerSecondsLeft((prev) => {
				if (prev <= 1) {
					window.clearInterval(timer);
					toast.info("⏱️ 90-Second Personal Member Situation Clip completed! Extended 60-min+ commercial launch broadcasts are exclusive to Official Brand Accounts.");
					void endBroadcast();
					return 0;
				}
				return prev - 1;
			});
		}, 1e3);
		return () => window.clearInterval(timer);
	}, [
		isLive,
		studioPersona,
		sessionMode,
		endBroadcast
	]);
	const shareRoomLink = async () => {
		const link = typeof window !== "undefined" ? `${window.location.origin}/messages?to=${encodeURIComponent(brandName)}&room=${encodeURIComponent(roomChannel)}` : roomChannel;
		await navigator.clipboard?.writeText(link);
		toast.success("Live broadcast/call link copied! Share with clients or prospects.");
	};
	const handleCastLivePulse = (verdict) => {
		if (verdict === "stash") {
			playCoinSpinSound();
		} else {
			playTrashSound();
		}
		setMyLiveVerdict(verdict);
		const res = voteOnLiveBroadcast(currentBroadcastId, verdict);
		if (res.session) {
			setLiveStashVotes(res.session.stashVotes);
			setLiveTrashVotes(res.session.trashVotes);
		} else {
			if (verdict === "stash") setLiveStashVotes((v) => v + 1);
			else setLiveTrashVotes((v) => v + 1);
		}
		const pulseMsg = {
			sender: user?.email?.split("@")[0] || "Live Viewer",
			text: verdict === "stash" ? `🪙 Voted STASH on ${brandName}'s live showcase! Loving this launch!` : `🗑️ Voted TRASH on ${brandName}'s live stream — needs improvement.`,
			time: new Date().toLocaleTimeString([], {
				hour: "2-digit",
				minute: "2-digit"
			})
		};
		setChatMessages((prev) => [...prev, pulseMsg]);
		bcRef.current?.postMessage({
			type: "live-vote",
			verdict
		});
		bcRef.current?.postMessage({
			type: "chat",
			message: pulseMsg
		});
		toast.success(verdict === "stash" ? `🪙 Stashed! Your live verdict boosted ${brandName}'s Launch Pulse.` : `🗑️ Trashed! Your live feedback was recorded on ${brandName}'s Launch Pulse.`);
	};
	const handleClaimPerkInStudio = async () => {
		const res = claimLiveLaunchPerk(currentBroadcastId);
		setHasClaimedInSession(true);
		setPerkClaimedCount((c) => Math.min(perkTotalAvailable, c + (res.alreadyClaimed ? 0 : 1)));
		try {
			await navigator.clipboard?.writeText(perkPromoCode.toUpperCase());
		} catch {}
		toast.success(`🎁 Claimed "${perkTitle}" (${perkPromoCode.toUpperCase()})! Saved to your Consumer Profile Wallet & copied to clipboard.`);
	};
	const handleDropPerkAnnouncement = () => {
		const dropMsg = {
			sender: `${brandName} (Host Perk Drop)`,
			text: `🎁 FLASH LAUNCH DROP: Claim "${perkTitle}" with code ${perkPromoCode.toUpperCase()} (${perkTotalAvailable - perkClaimedCount} vouchers left)!`,
			time: new Date().toLocaleTimeString([], {
				hour: "2-digit",
				minute: "2-digit"
			}),
			isHost: true,
			isPerkDrop: true
		};
		setChatMessages((prev) => [...prev, dropMsg]);
		bcRef.current?.postMessage({
			type: "chat",
			message: dropMsg
		});
		toast.success("Dropped live launch voucher into the broadcast stream & chat!");
	};
	const sendChatMessage = (e) => {
		e.preventDefault();
		if (!chatInput.trim()) return;
		const msg = {
			sender: studioPersona === "brand_owner" ? `${brandName} (Official Host)` : "You (Host)",
			text: chatInput.trim(),
			time: new Date().toLocaleTimeString([], {
				hour: "2-digit",
				minute: "2-digit"
			}),
			isHost: true
		};
		setChatMessages((prev) => [...prev, msg]);
		bcRef.current?.postMessage({
			type: "chat",
			message: {
				...msg,
				isHost: false
			}
		});
		void supaChanRef.current?.send({
			type: "broadcast",
			event: "sot-live-signal",
			payload: {
				type: "chat",
				message: {
					...msg,
					isHost: false
				}
			}
		});
		setChatInput("");
	};
	const totalLiveVotes = Math.max(1, liveStashVotes + liveTrashVotes);
	const liveStashPct = Math.round(liveStashVotes / totalLiveVotes * 100);
	const activeBrandCatObj = BRAND_BROADCAST_CATEGORIES.find((c) => c.id === brandCategory);
	return /* @__PURE__ */ _jsxDEV(Dialog, {
		open,
		onOpenChange,
		"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:887:5",
		children: /* @__PURE__ */ _jsxDEV(DialogContent, {
			className: "max-w-5xl max-h-[94vh] overflow-y-auto p-0 gap-0 border-border/80",
			"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:888:7",
			children: [
				/* @__PURE__ */ _jsxDEV(DialogHeader, {
					className: "p-4 border-b border-border/60 bg-muted/20",
					"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:889:9",
					children: [
						isDeveloper && /* @__PURE__ */ _jsxDEV("div", {
							className: "mb-3 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-dashed border-[#d6a928]/60 bg-background p-1.5",
							"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:892:13",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1.5 text-xs font-bold px-2",
								"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:893:15",
								children: [/* @__PURE__ */ _jsxDEV(Sparkles, {
									className: "h-3.5 w-3.5 text-[#d6a928]",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:894:17"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 894,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:895:17",
									children: "🛠️ DEV Studio Mode Switcher:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 895,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 893,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap items-center gap-1",
								"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:897:15",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setStudioPersona("brand_owner");
										setSessionMode("broadcast");
									},
									className: `flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-extrabold transition cursor-pointer ${studioPersona === "brand_owner" ? "bg-slate-950 text-[#d6a928] shadow-xs" : "text-muted-foreground hover:text-foreground"}`,
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:898:17",
									children: [/* @__PURE__ */ _jsxDEV(Rocket, {
										className: "h-3.5 w-3.5",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:910:19"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 910,
										columnNumber: 19
									}, this), "DEV: Brand Launch Studio (B2B)"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 898,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setStudioPersona("consumer"),
									className: `flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-extrabold transition cursor-pointer ${studioPersona === "consumer" ? "bg-rose-600 text-white shadow-xs" : "text-muted-foreground hover:text-foreground"}`,
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:913:17",
									children: [/* @__PURE__ */ _jsxDEV(Video, {
										className: "h-3.5 w-3.5",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:922:19"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 922,
										columnNumber: 19
									}, this), "DEV: Consumer Situation Cam (User)"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 913,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 897,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 892,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:929:11",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2.5",
								"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:930:13",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: `flex h-10 w-10 items-center justify-center rounded-xl ${studioPersona === "brand_owner" ? "bg-slate-950 text-[#d6a928] border border-[#d6a928]/50" : "bg-red-500/10 text-red-600"}`,
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:931:15",
									children: studioPersona === "brand_owner" ? /* @__PURE__ */ _jsxDEV(Rocket, {
										className: "h-5 w-5",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:939:19"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 939,
										columnNumber: 19
									}, this) : /* @__PURE__ */ _jsxDEV(Radio, {
										className: "h-5 w-5",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:941:19"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 941,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 931,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:944:15",
									children: [/* @__PURE__ */ _jsxDEV(DialogTitle, {
										className: "text-lg font-display flex flex-wrap items-center gap-2",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:945:17",
										children: [studioPersona === "brand_owner" ? `${brandName} — Official Brand Launch & Client Engagement Studio` : "Live Voice, Video & Consumer Situation Studio", isLive ? /* @__PURE__ */ _jsxDEV(Badge, {
											variant: "destructive",
											className: "animate-pulse text-[10px] gap-1",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:950:21",
											children: [/* @__PURE__ */ _jsxDEV(CircleDot, {
												className: "h-2.5 w-2.5",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:951:23"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 951,
												columnNumber: 23
											}, this), " LIVE ON HOME & FEED"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 950,
											columnNumber: 21
										}, this) : /* @__PURE__ */ _jsxDEV(Badge, {
											variant: "outline",
											className: "text-[10px]",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:954:21",
											children: engineUsed
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 954,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 945,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV(DialogDescription, {
										className: "text-xs text-muted-foreground flex flex-wrap items-center gap-1.5",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:959:17",
										children: [
											/* @__PURE__ */ _jsxDEV("span", {
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:960:19",
												children: "Host:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 960,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "font-semibold text-foreground",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:961:19",
												children: brandName
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 961,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:962:19",
												children: "·"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 962,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "flex items-center gap-1 text-amber-600 dark:text-amber-400",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:963:19",
												children: [
													/* @__PURE__ */ _jsxDEV(Building2, {
														className: "h-3 w-3",
														"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:964:21"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 964,
														columnNumber: 21
													}, this),
													" ",
													brandOwner
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 963,
												columnNumber: 19
											}, this),
											studioPersona === "brand_owner" ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:968:23",
												children: "·"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 968,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-emerald-600 font-bold",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:969:23",
												children: [
													"👤 Desk Operator: ",
													activeDeskOperator.name,
													" (",
													activeDeskOperator.roleTitle,
													")"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 969,
												columnNumber: 23
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 967,
												columnNumber: 21
											}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:975:23",
												children: "·"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 975,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-rose-600 font-bold tabular-nums",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:976:23",
												children: [
													"⏱️ Free Member Situation Clip Cap: ",
													isLive ? `${consumerSecondsLeft}s left` : "90s Max",
													" (Extended Launches = Brand Plan)"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 976,
												columnNumber: 23
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 974,
												columnNumber: 21
											}, this),
											followersAlertedCount > 0 && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:983:23",
												children: "·"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 983,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-emerald-600 font-bold",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:984:23",
												children: [
													"🔔 ",
													followersAlertedCount.toLocaleString(),
													" Followers Alerted"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 984,
												columnNumber: 23
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 982,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 959,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 944,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 930,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap items-center gap-2",
								"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:993:13",
								children: [
									isLive && /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1.5 text-xs font-semibold bg-background/80 px-2.5 py-1 rounded-md border",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:995:17",
										children: [/* @__PURE__ */ _jsxDEV(Eye, {
											className: "h-3.5 w-3.5 text-emerald-500",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:996:19"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 996,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "tabular-nums",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:997:19",
											children: [viewerCount, " watching live"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 997,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 995,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV(Button, {
										type: "button",
										size: "sm",
										variant: "outline",
										onClick: () => void ringRecipientOnPlatform(roomChannel || "sot-live-room"),
										className: "h-8 gap-1.5 text-xs font-bold border-emerald-500/40 text-emerald-600 hover:bg-emerald-500/10",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1000:15",
										children: [/* @__PURE__ */ _jsxDEV(BellRing, {
											className: "h-3.5 w-3.5",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1007:17"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1007,
											columnNumber: 17
										}, this), ringingSent ? "Ring Sent (Ring Again)" : `Ring ${targetRecipientName || "Client"} on SOT`]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1e3,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV(Button, {
										type: "button",
										size: "sm",
										variant: "outline",
										onClick: () => void shareRoomLink(),
										className: "h-8 gap-1.5 text-xs font-semibold",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1010:15",
										children: [/* @__PURE__ */ _jsxDEV(Share2, {
											className: "h-3.5 w-3.5",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1017:17"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1017,
											columnNumber: 17
										}, this), " Share Stream Link"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1010,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 993,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 929,
							columnNumber: 11
						}, this),
						studioPersona === "brand_owner" ? /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-3 rounded-2xl border-2 border-[#d6a928]/50 bg-slate-950 p-3.5 text-white space-y-3",
							"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1024:13",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-wrap items-center justify-between gap-2",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1025:15",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-wider text-[#f5d061]",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1026:17",
										children: [/* @__PURE__ */ _jsxDEV(Rocket, {
											className: "h-3.5 w-3.5 text-[#d6a928]",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1027:19"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1027,
											columnNumber: 19
										}, this), "Brand Broadcast Purpose (Launches, Relaunches, Tours & Townhalls)"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1026,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-slate-300",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1030:17",
										children: "Streams live to the Home Page, Brand Page & alerts all followers"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1030,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1025,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-wrap gap-1.5",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1036:15",
									children: BRAND_BROADCAST_CATEGORIES.map((cat) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => handleCategoryPresetChange(cat.id),
										className: `rounded-lg border px-2.5 py-1.5 text-xs font-bold transition cursor-pointer ${brandCategory === cat.id ? "border-[#d6a928] bg-[#d6a928] text-slate-950 shadow-xs" : "border-slate-800 bg-slate-900 text-slate-300 hover:border-slate-700 hover:text-white"}`,
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1038:19",
										children: cat.shortBadge
									}, cat.id, false, {
										fileName: _jsxFileName,
										lineNumber: 1038,
										columnNumber: 19
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1036,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid gap-2.5 sm:grid-cols-12",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1054:15",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "sm:col-span-5",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1055:17",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "mb-1 block text-[10px] font-bold uppercase tracking-wider text-slate-400",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1056:19",
												children: "Launch / Broadcast Headline"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1056,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV(Input, {
												value: broadcastHeadline,
												onChange: (e) => setBroadcastHeadline(e.target.value),
												placeholder: "e.g. LIVE LAUNCH: New Peri-Honey Flame Reveal",
												className: "h-8 border-slate-700 bg-slate-900 text-xs font-bold text-white",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1059:19"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1059,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1055,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "sm:col-span-4",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1066:17",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "mb-1 flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-slate-400",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1067:19",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1068:21",
													children: "🎁 Live Viewer Perk / Voucher Title"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1068,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "checkbox",
													checked: enableLaunchPerk,
													onChange: (e) => setEnableLaunchPerk(e.target.checked),
													className: "h-3 w-3 accent-[#d6a928]",
													title: "Enable claimable launch voucher on screen",
													"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1069:21"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1069,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1067,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV(Input, {
												value: perkTitle,
												disabled: !enableLaunchPerk,
												onChange: (e) => setPerkTitle(e.target.value),
												placeholder: "e.g. 25% Off New Launch Meal",
												className: "h-8 border-slate-700 bg-slate-900 text-xs text-white",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1077:19"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1077,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1066,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "sm:col-span-3",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1085:17",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "mb-1 block text-[10px] font-bold uppercase tracking-wider text-slate-400",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1086:19",
												children: "Promo Code"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1086,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex gap-1",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1089:19",
												children: [/* @__PURE__ */ _jsxDEV(Input, {
													value: perkPromoCode,
													disabled: !enableLaunchPerk,
													onChange: (e) => setPerkPromoCode(e.target.value.toUpperCase()),
													placeholder: "SOT_LAUNCH25",
													className: "h-8 border-slate-700 bg-slate-900 font-mono text-xs font-bold text-[#f5d061]",
													"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1090:21"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1090,
													columnNumber: 21
												}, this), isLive && enableLaunchPerk && /* @__PURE__ */ _jsxDEV(Button, {
													type: "button",
													size: "sm",
													onClick: handleDropPerkAnnouncement,
													className: "h-8 shrink-0 bg-[#d6a928] px-2 text-[11px] font-extrabold text-slate-950 hover:bg-[#e5b935]",
													title: "Drop voucher into live chat now",
													"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1098:23",
													children: "Drop"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1098,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1089,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1085,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1054,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1024,
							columnNumber: 13
						}, this) : 
						/* Direct User-to-User & Brand-to-User Dialer Bar */
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-3 rounded-xl border border-[#d6a928]/40 bg-[#d6a928]/5 p-2.5 space-y-2",
							"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1114:13",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap items-center justify-between gap-2",
								"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1115:15",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-wider text-foreground",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1116:17",
									children: [/* @__PURE__ */ _jsxDEV(UserCheck, {
										className: "h-3.5 w-3.5 text-[#d6a928]",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1117:19"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1117,
										columnNumber: 19
									}, this), "Direct Platform Calling (No Phone Number Needed — Rings User In-App + SOT Inbox)"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1116,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1 rounded-lg bg-background/80 p-0.5 border border-border/60",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1120:17",
									children: [
										["brand_to_user", "Brand → User (Reach Client)"],
										["user_to_user", "User → User (Peer Call)"],
										["user_to_brand", "User → Brand"]
									].map(([dirKey, dirLabel]) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setCallDirection(dirKey),
										className: `rounded-md px-2 py-0.5 text-[10px] font-bold transition ${callDirection === dirKey ? "bg-slate-950 text-[#d6a928]" : "text-muted-foreground hover:text-foreground"}`,
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1128:21",
										children: dirLabel
									}, dirKey, false, {
										fileName: _jsxFileName,
										lineNumber: 1128,
										columnNumber: 21
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1120,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1115,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid gap-2 sm:grid-cols-2",
								"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1144:15",
								children: [/* @__PURE__ */ _jsxDEV("select", {
									value: targetRecipientId,
									onChange: (e) => {
										const chosen = platformContacts.find((c) => c.id === e.target.value);
										setTargetRecipientId(e.target.value);
										if (chosen) setTargetRecipientName(chosen.name);
									},
									className: "h-8 rounded-lg border border-border bg-background px-2.5 text-xs font-semibold outline-none",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1145:17",
									children: [/* @__PURE__ */ _jsxDEV("option", {
										value: "",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1154:19",
										children: "Select SOT User / Client from recent posts..."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1154,
										columnNumber: 19
									}, this), platformContacts.map((c) => /* @__PURE__ */ _jsxDEV("option", {
										value: c.id,
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1156:21",
										children: [
											c.name,
											" — (",
											c.context,
											")"
										]
									}, c.id, true, {
										fileName: _jsxFileName,
										lineNumber: 1156,
										columnNumber: 21
									}, this))]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1145,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV(Input, {
									value: targetRecipientName,
									onChange: (e) => setTargetRecipientName(e.target.value),
									placeholder: "Or type User / Client name or handle to call...",
									className: "h-8 text-xs bg-background",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1162:17"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1162,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1144,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1114,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mt-3 grid gap-2 pt-3 border-t border-border/60 sm:grid-cols-3",
							"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1173:11",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1 rounded-lg bg-secondary/60 p-1",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1174:13",
									children: [
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => setSessionMode("broadcast"),
											className: `flex-1 rounded-md px-2 py-1 text-[11px] font-bold transition-colors ${sessionMode === "broadcast" ? "bg-background text-foreground shadow-xs" : "text-muted-foreground hover:text-foreground"}`,
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1175:15",
											children: "Live Broadcast"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1175,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => setSessionMode("video_call"),
											className: `flex-1 rounded-md px-2 py-1 text-[11px] font-bold transition-colors ${sessionMode === "video_call" ? "bg-background text-foreground shadow-xs" : "text-muted-foreground hover:text-foreground"}`,
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1186:15",
											children: "Video Call"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1186,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => setSessionMode("voice_call"),
											className: `flex-1 rounded-md px-2 py-1 text-[11px] font-bold transition-colors ${sessionMode === "voice_call" ? "bg-background text-foreground shadow-xs" : "text-muted-foreground hover:text-foreground"}`,
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1197:15",
											children: "Voice Call"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1197,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1174,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "relative",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1210:13",
									children: [/* @__PURE__ */ _jsxDEV(Hash, {
										className: "pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1211:15"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1211,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV(Input, {
										value: batchNumber,
										onChange: (e) => setBatchNumber(e.target.value),
										placeholder: studioPersona === "brand_owner" ? "SKU / Edition / Batch Code (Optional)" : "Batch / Lot # or Barcode (Optional)",
										className: "h-8 pl-8 text-xs",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1212:15"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1212,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1210,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "relative",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1224:13",
									children: [/* @__PURE__ */ _jsxDEV(MapPin, {
										className: "pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1225:15"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1225,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV(Input, {
										value: storeLocation,
										onChange: (e) => setStoreLocation(e.target.value),
										placeholder: studioPersona === "brand_owner" ? "Launch Venue / Flagship Store / HQ" : "Store / Branch / Spaza Location",
										className: "h-8 pl-8 text-xs",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1226:15"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1226,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1224,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1173,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 889,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-3 gap-0",
					"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1240:9",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "md:col-span-2 relative bg-slate-950 aspect-video flex items-center justify-center overflow-hidden",
						"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1242:11",
						children: [
							sessionMode === "voice_call" ? /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col items-center justify-center gap-3 p-6 text-center text-white",
								"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1244:15",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex h-20 w-20 items-center justify-center rounded-full border-2 border-emerald-400/50 bg-emerald-500/10 text-emerald-400",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1245:17",
									children: /* @__PURE__ */ _jsxDEV(Phone, {
										className: `h-9 w-9 ${isLive ? "animate-bounce" : ""}`,
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1246:19"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1246,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1245,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1248:17",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "font-display text-lg font-bold",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1249:19",
										children: isLive ? "Live Voice Call & Audio Stream" : "Voice Call Ready"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1249,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "mt-1 text-xs text-slate-400",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1252:19",
										children: [
											"Room: ",
											/* @__PURE__ */ _jsxDEV("span", {
												className: "font-mono text-slate-200",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1253:27",
												children: roomChannel
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1253,
												columnNumber: 27
											}, this),
											" · ",
											engineUsed
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1252,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1248,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1244,
								columnNumber: 15
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: `grid h-full w-full ${peerJoined ? "grid-cols-2" : "grid-cols-1"}`,
								"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1258:15",
								children: [
									/* @__PURE__ */ _jsxDEV("video", {
										ref: videoRef,
										autoPlay: true,
										playsInline: true,
										muted: true,
										className: `w-full h-full object-cover ${!cameraOn && !screenSharing ? "hidden" : ""}`,
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1259:17"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1259,
										columnNumber: 17
									}, this),
									peerJoined && /* @__PURE__ */ _jsxDEV("video", {
										ref: remoteVideoRef,
										autoPlay: true,
										playsInline: true,
										className: "w-full h-full object-cover border-l border-white/10",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1267:19"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1267,
										columnNumber: 19
									}, this),
									!cameraOn && !screenSharing && /* @__PURE__ */ _jsxDEV("div", {
										className: "flex flex-col items-center justify-center text-slate-400 gap-2",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1275:19",
										children: [/* @__PURE__ */ _jsxDEV(VideoOff, {
											className: "h-10 w-10 opacity-60",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1276:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1276,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1277:21",
											children: "Camera is turned off (Audio active)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1277,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1275,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1258,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "absolute top-3 left-3 right-3 flex flex-col gap-1.5 pointer-events-none",
								"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1284:13",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex flex-wrap items-center justify-between gap-2",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1285:15",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-black/75 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/15 text-white text-xs flex flex-wrap items-center gap-2 max-w-xl",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1286:17",
											children: [
												studioPersona === "brand_owner" && activeBrandCatObj ? /* @__PURE__ */ _jsxDEV("span", {
													className: "rounded-md bg-[#d6a928] px-2 py-0.5 text-[10px] font-black text-slate-950",
													"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1288:21",
													children: activeBrandCatObj.shortBadge
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1288,
													columnNumber: 21
												}, this) : /* @__PURE__ */ _jsxDEV("span", {
													className: "rounded-md bg-rose-600 px-2 py-0.5 text-[10px] font-black text-white",
													"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1292:21",
													children: "📹 CONSUMER CAM"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1292,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "font-extrabold",
													"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1296:19",
													children: brandName
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1296,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "opacity-85 truncate max-w-[260px]",
													"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1297:19",
													children: broadcastHeadline
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1297,
													columnNumber: 19
												}, this),
												batchNumber && /* @__PURE__ */ _jsxDEV("span", {
													className: "rounded bg-amber-500/20 px-1.5 py-0.5 font-mono text-[10px] text-amber-300",
													"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1299:21",
													children: ["#", batchNumber]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1299,
													columnNumber: 21
												}, this),
												storeLocation && /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] text-slate-300",
													"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1304:21",
													children: ["📍 ", storeLocation]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1304,
													columnNumber: 21
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1286,
											columnNumber: 17
										}, this), studioPersona === "brand_owner" && enableLaunchPerk && perkPromoCode && /* @__PURE__ */ _jsxDEV("div", {
											className: "pointer-events-auto flex items-center gap-2 rounded-xl border border-[#d6a928] bg-slate-950/90 px-3 py-1.5 text-xs text-white shadow-lg backdrop-blur-md",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1310:19",
											children: [
												/* @__PURE__ */ _jsxDEV(Gift, {
													className: "h-4 w-4 shrink-0 text-[#d6a928]",
													"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1311:21"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1311,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "leading-tight",
													"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1312:21",
													children: [/* @__PURE__ */ _jsxDEV("p", {
														className: "text-[10px] font-extrabold uppercase tracking-wider text-[#f5d061]",
														"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1313:23",
														children: [
															perkDiscountLabel,
															" · ",
															perkTotalAvailable - perkClaimedCount,
															" left"
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1313,
														columnNumber: 23
													}, this), /* @__PURE__ */ _jsxDEV("p", {
														className: "font-bold text-white text-[11px]",
														"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1316:23",
														children: perkTitle
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1316,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1312,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ _jsxDEV(Button, {
													type: "button",
													size: "sm",
													onClick: () => void handleClaimPerkInStudio(),
													className: "h-7 bg-[#d6a928] px-2.5 text-[10px] font-black text-slate-950 hover:bg-[#e5b935]",
													"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1318:21",
													children: hasClaimedInSession ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
														/* @__PURE__ */ _jsxDEV(Check, {
															className: "mr-1 h-3 w-3",
															"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1326:27"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1326,
															columnNumber: 27
														}, this),
														" ",
														perkPromoCode
													] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1325,
														columnNumber: 25
													}, this) : "Claim Perk"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1318,
													columnNumber: 21
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1310,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1285,
										columnNumber: 15
									}, this),
									studioPersona === "consumer" && /* @__PURE__ */ _jsxDEV("div", {
										className: "flex flex-wrap gap-1.5 pointer-events-auto",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1338:17",
										children: CONSUMER_BROADCAST_CATEGORIES.map((cat) => /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => setSituationType(cat.id),
											className: `rounded px-2 py-0.5 text-[10px] font-semibold transition ${situationType === cat.id ? "bg-[#d6a928] text-slate-950 font-bold" : "bg-black/60 text-white/80 hover:bg-black/80"}`,
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1340:21",
											children: cat.label
										}, cat.id, false, {
											fileName: _jsxFileName,
											lineNumber: 1340,
											columnNumber: 21
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1338,
										columnNumber: 17
									}, this),
									scanResult && /* @__PURE__ */ _jsxDEV("div", {
										className: "bg-emerald-950/80 backdrop-blur-md px-2 py-0.5 rounded text-[10px] text-emerald-300 border border-emerald-500/30 flex items-center gap-1 w-fit",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1357:17",
										children: [
											/* @__PURE__ */ _jsxDEV(ShieldCheck, {
												className: "h-3 w-3 text-emerald-400",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1358:19"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1358,
												columnNumber: 19
											}, this),
											"Verified Evidence (",
											scanResult.authenticity.score,
											"% Authenticity)"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1357,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1284,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "absolute bottom-14 left-3 right-3 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/15 bg-black/75 px-3 py-2 text-white backdrop-blur-md",
								"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1365:13",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "min-w-[180px] flex-1",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1366:15",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-[10px] font-extrabold uppercase tracking-wider",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1367:17",
										children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[#f5d061]",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1368:19",
												children: [
													"🪙 ",
													liveStashPct,
													"% Stash (",
													liveStashVotes,
													")"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1368,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-300",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1371:19",
												children: ["Live ", studioPersona === "brand_owner" ? "Launch Reception Pulse" : "Community Verdict"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1371,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-rose-400",
												"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1374:19",
												children: [
													"🗑️ ",
													100 - liveStashPct,
													"% Trash (",
													liveTrashVotes,
													")"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1374,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1367,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "mt-1 flex h-2 w-full overflow-hidden rounded-full bg-slate-800",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1378:17",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-gradient-to-r from-amber-400 to-[#d6a928] transition-all duration-500",
											style: { width: `${liveStashPct}%` },
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1379:19"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1379,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "bg-rose-600 transition-all duration-500",
											style: { width: `${100 - liveStashPct}%` },
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1383:19"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1383,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1378,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1366,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1.5",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1390:15",
									children: [/* @__PURE__ */ _jsxDEV(Button, {
										type: "button",
										size: "sm",
										onClick: () => handleCastLivePulse("stash"),
										className: `h-7 gap-1 px-2.5 text-[11px] font-black ${myLiveVerdict === "stash" ? "bg-[#d6a928] text-slate-950 ring-2 ring-white" : "bg-[#d6a928]/90 text-slate-950 hover:bg-[#d6a928]"}`,
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1391:17",
										children: [/* @__PURE__ */ _jsxDEV(Coins, {
											className: "h-3 w-3",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1401:19"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1401,
											columnNumber: 19
										}, this), " Stash Launch"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1391,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV(Button, {
										type: "button",
										size: "sm",
										variant: "destructive",
										onClick: () => handleCastLivePulse("trash"),
										className: `h-7 gap-1 px-2.5 text-[11px] font-black ${myLiveVerdict === "trash" ? "ring-2 ring-white" : ""}`,
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1403:17",
										children: [/* @__PURE__ */ _jsxDEV(Recycle, {
											className: "h-3 w-3",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1412:19"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1412,
											columnNumber: 19
										}, this), " Trash"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1403,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1390,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1365,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "absolute bottom-2.5 left-0 right-0 flex items-center justify-center gap-2",
								"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1418:13",
								children: [
									sessionMode !== "voice_call" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Button, {
										type: "button",
										size: "icon",
										variant: cameraOn ? "secondary" : "destructive",
										className: "h-9 w-9 rounded-full shadow-lg",
										onClick: toggleCamera,
										title: "Toggle Camera",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1421:19",
										children: cameraOn ? /* @__PURE__ */ _jsxDEV(Video, {
											className: "h-4 w-4",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1429:33"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1429,
											columnNumber: 33
										}, this) : /* @__PURE__ */ _jsxDEV(VideoOff, {
											className: "h-4 w-4",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1429:65"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1429,
											columnNumber: 130
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1421,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV(Button, {
										type: "button",
										size: "icon",
										variant: screenSharing ? "default" : "secondary",
										className: "h-9 w-9 rounded-full shadow-lg",
										onClick: () => void toggleScreenShare(),
										title: "Share Screen, Product Slides or Receipt Evidence",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1431:19",
										children: /* @__PURE__ */ _jsxDEV(MonitorUp, {
											className: "h-4 w-4",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1439:21"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1439,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1431,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1420,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV(Button, {
										type: "button",
										size: "icon",
										variant: micOn ? "secondary" : "destructive",
										className: "h-9 w-9 rounded-full shadow-lg",
										onClick: toggleMic,
										title: "Toggle Microphone",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1443:15",
										children: micOn ? /* @__PURE__ */ _jsxDEV(Mic, {
											className: "h-4 w-4",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1451:26"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1451,
											columnNumber: 26
										}, this) : /* @__PURE__ */ _jsxDEV(MicOff, {
											className: "h-4 w-4",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1451:56"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1451,
											columnNumber: 121
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1443,
										columnNumber: 15
									}, this),
									!isLive ? /* @__PURE__ */ _jsxDEV(Button, {
										type: "button",
										size: "sm",
										onClick: () => void startBroadcast(),
										className: studioPersona === "brand_owner" ? "bg-[#d6a928] hover:bg-[#e5b935] text-slate-950 font-black gap-1.5 px-5 shadow-xl rounded-full" : "bg-red-600 hover:bg-red-700 text-white font-bold gap-1.5 px-4 shadow-xl rounded-full",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1455:17",
										children: studioPersona === "brand_owner" ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Rocket, {
											className: "h-4 w-4",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1467:23"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1467,
											columnNumber: 23
										}, this), "Go Live & Alert Followers"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1466,
											columnNumber: 21
										}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Radio, {
											className: "h-4 w-4 animate-pulse",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1472:23"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1472,
											columnNumber: 23
										}, this), sessionMode === "voice_call" ? "Start Voice Call" : sessionMode === "video_call" ? "Start Video Call" : "Go Live Now"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1471,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1455,
										columnNumber: 17
									}, this) : /* @__PURE__ */ _jsxDEV(Button, {
										type: "button",
										size: "sm",
										variant: "destructive",
										onClick: () => void endBroadcast(),
										className: "font-bold px-4 shadow-xl rounded-full",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1482:17",
										children: "End Session"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1482,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1418,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1242,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "border-l border-border flex flex-col h-80 md:h-auto bg-muted/10",
						"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1496:11",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 border-b border-border/60 flex items-center justify-between text-xs font-semibold",
								"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1497:13",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "flex items-center gap-1.5 text-foreground font-bold",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1498:15",
									children: [/* @__PURE__ */ _jsxDEV(MessageSquare, {
										className: "h-3.5 w-3.5 text-[#d6a928]",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1499:17"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1499,
										columnNumber: 17
									}, this), studioPersona === "brand_owner" ? "Live Launch Q&A & Perks" : "Live Situation Chat"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1498,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] font-mono text-muted-foreground",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1502:15",
									children: roomChannel
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1502,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1497,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex-1 p-3 overflow-y-auto space-y-2 text-xs",
								"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1505:13",
								children: chatMessages.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
									className: "text-center text-muted-foreground py-8 text-xs space-y-2",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1507:17",
									children: studioPersona === "brand_owner" ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
										/* @__PURE__ */ _jsxDEV(Users, {
											className: "h-6 w-6 mx-auto text-[#d6a928]",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1510:23"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1510,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "font-semibold text-foreground",
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1511:23",
											children: [
												"Ready to broadcast your ",
												activeBrandCatObj?.label.toLowerCase(),
												"!"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1511,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1514:23",
											children: [
												"Click ",
												/* @__PURE__ */ _jsxDEV("strong", {
													"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1515:31",
													children: "Go Live & Alert Followers"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1515,
													columnNumber: 31
												}, this),
												" to stream to the Home Feed, collect live Stash/Trash votes, and drop your launch promo code."
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1514,
											columnNumber: 23
										}, this)
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1509,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, {
										className: "h-5 w-5 mx-auto text-amber-500/80",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1520:23"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1520,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1521:23",
										children: isLive ? "No comments yet. Share your room link to invite peers or brand reps!" : "Start your voice call, video call, or situation broadcast to open live chat."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1521,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1519,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1507,
									columnNumber: 17
								}, this) : chatMessages.map((m, i) => /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-0.5",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1531:19",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-[10px] text-muted-foreground",
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1532:21",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: `font-bold ${m.isPerkDrop ? "text-[#b88914]" : m.isHost ? "text-primary" : "text-foreground"}`,
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1533:23",
											children: m.sender
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1533,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1544:23",
											children: m.time
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1544,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1532,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: `p-2 rounded-lg border text-[11px] leading-relaxed ${m.isPerkDrop ? "border-[#d6a928] bg-[#d6a928]/15 font-bold text-foreground" : "border-border/50 bg-background/80 text-foreground"}`,
										"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1546:21",
										children: m.text
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1546,
										columnNumber: 21
									}, this)]
								}, i, true, {
									fileName: _jsxFileName,
									lineNumber: 1531,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1505,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("form", {
								onSubmit: sendChatMessage,
								className: "p-2 border-t border-border/60 flex gap-1.5 bg-background",
								"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1560:13",
								children: [/* @__PURE__ */ _jsxDEV(Input, {
									placeholder: isLive ? studioPersona === "brand_owner" ? "Reply to clients & prospects live..." : "Type live situation note..." : "Start session to chat...",
									disabled: !isLive,
									value: chatInput,
									onChange: (e) => setChatInput(e.target.value),
									className: "h-8 text-xs",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1561:15"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1561,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV(Button, {
									type: "submit",
									size: "sm",
									disabled: !isLive || !chatInput.trim(),
									className: "h-8 px-3 text-xs",
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1574:15",
									children: "Send"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1574,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1560,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1496,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1240,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(DialogFooter, {
					className: "p-3 border-t border-border/60 bg-muted/10 sm:justify-between",
					"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1581:9",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "text-[11px] text-muted-foreground flex items-center gap-1.5",
						"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1582:11",
						children: [/* @__PURE__ */ _jsxDEV(Sparkles, {
							className: "h-3.5 w-3.5 text-[#d6a928]",
							"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1583:13"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1583,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1584:13",
							children: [
								"Powered by Google WebRTC (",
								/* @__PURE__ */ _jsxDEV("code", {
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1585:41",
									children: "stun.l.google.com"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1585,
									columnNumber: 41
								}, this),
								") & Agora RTC ·",
								" ",
								/* @__PURE__ */ _jsxDEV("strong", {
									"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1586:15",
									children: studioPersona === "brand_owner" ? "Executive Brand Launch & Engagement Broadcast" : "Consumer Live Situation Studio"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1586,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1584,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1582,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						variant: "ghost",
						size: "sm",
						onClick: () => onOpenChange(false),
						"data-tsd-source": "/src/components/LiveBroadcastModal.tsx:1593:11",
						children: "Close Studio"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1593,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1581,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 888,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 887,
		columnNumber: 5
	}, this);
}
_s(LiveBroadcastModal, "Q26U8G00O0ikOUzAMmsdLMaTpMY=", false, function() {
	return [useAuth, useRoles];
});
_c = LiveBroadcastModal;
var _c;
$RefreshReg$(_c, "LiveBroadcastModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/LiveBroadcastModal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/LiveBroadcastModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/LiveBroadcastModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/LiveBroadcastModal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFNQSxTQUNBLFFBQ0EsZUFDQSxjQUNBLGFBQ0EsbUJBQ0Esb0JBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUNBLE9BQ0EsT0FDQSxLQUNBLFFBQ0EsVUFDQSxLQUNBLGVBQ0EsVUFDQSxXQUNBLFFBQ0EsYUFDQSxXQUNBLE9BQ0EsV0FDQSxlQUNBLFFBQ0EsTUFDQSxXQUNBLFVBQ0EsUUFDQSxNQUNBLE9BQ0EsU0FDQSxPQUNBLGFBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQ0EsNEJBQ0EsK0JBQ0EsNkJBQ0EscUJBQ0EscUJBQ0EsZ0NBSUE7QUFDQSxTQUNBLHVCQUNBLHNDQUNBOzs7O0FBbUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0E7QUFFQSxxQ0FDQSxNQUNBLGNBQ0Esb0NBQ0EsV0FDQSx1Q0FDQSw4QkFDQSxZQUNBLGlDQUNBLHFDQUNBLDRCQUNBLG1CQUNBLHVEQUNBLGdCQUNBLHlDQUNBLHFCQUNBOztDQUNBO0NBQ0E7Q0FFQSxtREFDQSx3REFDQTtDQUNBO0NBQ0E7Q0FFQSwyREFDQSx1REFDQTtDQUNBLDJEQUNBLG9IQUNBOztDQUdBO0NBQ0E7Q0FDQSxtREFDQSxvRkFDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBOztDQUdBLDZEQUNBLHlDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FFQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLG1EQUNBLG9CQUNBO0NBQ0E7Q0FDQTtDQUNBLHlEQUVBO0NBQ0E7Q0FFQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTs7Q0FHQTtDQUNBO0NBRUEsaURBRUE7Q0FDQTtDQUVBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUVBO0VBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0lBQ0E7SUFDQTtHQUNBO0VBQ0EsU0FFQTtFQUNBO0dBQ0E7R0FDQTtFQUNBO0VBQ0E7R0FDQTtHQUNBO0VBQ0E7RUFDQTtHQUNBO0dBQ0E7RUFDQTtFQUNBO0dBQ0E7R0FDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0E7O0NBR0E7RUFDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7SUFDQTtHQUNBO0lBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTs7R0FHQTtJQUNBO0lBQ0E7SUFDQTtLQUNBO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7S0FDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtLQUNBO0lBQ0E7R0FDQTtJQUNBLG9CQUNBO0lBQ0EscUJBQ0EsZ0RBQ0EsY0FDQSxvREFDQTtJQUNBO0lBQ0E7R0FDQTs7R0FHQSxxQkFDQTtJQUNBO0lBQ0E7SUFDQTtLQUNBO01BQ0E7TUFDQTtPQUNBO09BQ0E7T0FDQTtNQUNBO0tBQ0E7SUFDQTtJQUNBO0tBQ0EsVUFDQTtNQUFBO01BQUE7TUFBQTtLQUFBLEdBQ0E7TUFBQTtNQUFBO01BQUE7S0FBQSxDQUNBO0lBQ0E7SUFDQTtJQUNBO0tBQ0E7S0FDQTtJQUNBO0dBQ0EsR0FDQTs7R0FFQTtFQUNBO0NBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0E7O0NBR0E7RUFDQTtFQUNBO0dBQ0EsYUFDQSxxQkFDQTtHQUNBO0dBQ0Esd0JBQ0E7SUFBQTtJQUFBO0dBQUEsR0FDQTtJQUNBO0tBQ0E7S0FDQTtJQUNBO0lBQ0E7SUFDQTtLQUNBO0lBQ0E7R0FDQSxHQUNBO0lBQ0E7SUFDQTtHQUNBO0VBQ0E7R0FDQTtFQUNBO0VBRUE7R0FDQTtFQUNBO0NBQ0E7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7Q0FBQTtDQUVBO0VBQ0E7RUFDQTtFQUNBO0dBQ0E7R0FDQSxxQkFDQSwwRkFDQTtHQUNBO0dBQ0E7R0FDQTtFQUNBO0dBQ0E7R0FDQSxxQkFDQSxxRkFDQTtHQUNBO0dBQ0E7R0FDQTtFQUNBO0dBQ0E7R0FDQSxxQkFDQSxzRUFDQTtHQUNBO0dBQ0E7R0FDQTtFQUNBO0dBQ0E7R0FDQSxxQkFDQSwyRkFDQTtHQUNBO0dBQ0E7R0FDQTtFQUNBO0dBQ0E7R0FDQSxxQkFDQSxvRUFDQTtHQUNBO0dBQ0E7R0FDQTtFQUNBO0NBQ0E7Q0FFQSw0Q0FDQTtFQUNBO0VBQ0E7RUFDQSxzQkFDQSxvQ0FDQSx5Q0FDQTtFQUVBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtFQUNBOztFQUdBO0dBQ0E7R0FDQTtHQUNBO0VBQ0E7O0VBR0E7R0FDQTtHQUNBO0lBQ0E7S0FDQTtNQUNBO01BQ0E7TUFDQTtLQUNBO0lBQ0E7R0FDQTtFQUNBLFNBRUE7O0VBR0E7R0FDQTtHQUNBO0dBQ0Esa0JBQ0EsK0JBQ0EsZUFDQSwrQkFDQSxlQUNBLGtDQUNBLGdDQUNBO0dBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FDQTtFQUNBO0VBRUE7RUFDQSxjQUNBLCtJQUNBO0NBQ0EsR0FDQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0VBQUE7RUFBQTtDQUFBLENBQ0E7Q0FFQTtFQUNBO0VBQ0E7RUFDQTtHQUNBO0lBQ0E7R0FDQTtFQUNBO0VBQ0E7R0FDQTtFQUNBO0NBQ0E7Q0FFQTtFQUNBO0VBQ0E7RUFDQTtHQUNBO0lBQ0E7R0FDQTtFQUNBO0VBQ0E7R0FDQTtFQUNBO0NBQ0E7Q0FFQTtFQUNBO0dBQ0E7R0FDQTtFQUNBO0VBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtJQUNBO0dBQ0E7R0FDQTtJQUNBO0lBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtJQUNBO0lBQ0E7S0FDQTtJQUNBO0dBQ0E7RUFDQTtHQUNBO0VBQ0E7Q0FDQTtDQUVBO0VBQ0E7R0FDQTtJQUNBO0lBQ0E7SUFDQTtLQUNBO0tBQ0E7S0FDQTtJQUNBO0dBQ0E7R0FDQTtHQVNBO0dBQ0E7R0FFQTtJQUNBO0lBQ0E7SUFDQTtLQUFBO0tBQUE7SUFBQTtJQUNBO0lBQ0E7S0FDQTtLQUNBO0tBQ0E7TUFDQTtLQUNBO0tBQ0E7S0FDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7S0FDQTtLQUNBO0lBQ0E7R0FDQTtJQUNBO0lBQ0EsbUNBQ0Esd0RBQ0E7SUFDQTtJQUVBO0tBQ0E7TUFDQTtLQUNBO0lBQ0E7SUFFQTtLQUNBO0tBQ0E7TUFDQTtNQUNBO0tBQ0E7SUFDQTtJQUVBO0tBQ0E7S0FDQTtNQUNBO01BQ0E7TUFDQTtLQUNBO0lBQ0E7SUFFQTtLQUNBO01BQ0E7T0FBQTtPQUFBO01BQUE7S0FDQTtJQUNBO0lBRUE7S0FDQTtLQUNBO01BQ0E7T0FDQTtPQUNBO01BQ0E7TUFDQTtPQUNBO1lBQ0E7T0FDQTtNQUNBO01BQ0E7T0FDQTtPQUNBO09BQ0E7T0FDQTtRQUFBO1FBQUE7T0FBQTtNQUNBO09BQ0E7T0FDQTtPQUNBO09BQ0E7UUFBQTtRQUFBO09BQUE7T0FDQTtNQUNBO09BQ0E7T0FDQTtNQUNBO09BQ0E7TUFDQTtLQUNBLFNBRUE7SUFDQTtJQUVBO0tBQ0E7S0FDQTtLQUNBO0lBQ0E7SUFFQSwwQkFDQSwrQkFDQTtLQUNBO0lBQ0EsR0FDQTtLQUNBO01BQ0E7S0FDQTtJQUNBO0lBQ0E7SUFDQTtHQUNBOztHQUdBO0dBQ0E7R0FFQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBLFVBQ0Esa0NBQ0EseUNBQ0E7SUFDQSxlQUNBLGtDQUNBLDRDQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQSxZQUNBLDhFQUNBO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7S0FDQTtJQUNBLElBQ0E7R0FDQTtHQUVBO0dBQ0E7R0FDQTtHQUVBO0lBQ0EsK0JBQ0Esb0JBQ0EsbUlBQ0E7R0FDQTtHQUVBO0lBQ0E7R0FDQTtHQUVBLHdCQU1BLENBQ0E7SUFDQTtJQUNBLE1BQ0Esa0NBQ0EsbU1BQ0E7SUFDQTtLQUFBO0tBQUE7SUFBQTtHQUNBLENBQ0E7R0FFQTtJQUNBO0tBQ0E7S0FDQTtLQUNBO01BQUE7TUFBQTtLQUFBO0tBQ0E7S0FDQTtJQUNBO0dBQ0E7R0FFQTtHQUNBLGNBQ0Esa0NBQ0EseUhBQ0Esc0RBQ0E7RUFDQTtHQUNBO0VBQ0E7Q0FDQTtDQUVBO0VBQ0E7RUFDQTtFQUNBO0NBQ0E7OztDQUlBO0VBQ0E7R0FDQTtFQUNBO0VBQ0E7R0FDQTtJQUNBO0tBQ0E7S0FDQSxXQUNBLGdKQUNBO0tBQ0E7S0FDQTtJQUNBO0lBQ0E7R0FDQTtFQUNBO0VBQ0E7Q0FDQTtFQUFBO0VBQUE7RUFBQTtFQUFBO0NBQUE7Q0FFQTtFQUNBLGFBQ0EsZ0NBQ0EsbUhBQ0E7RUFDQTtFQUNBO0NBQ0E7Q0FFQTtFQUNBO0dBQ0E7RUFDQTtHQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7R0FDQTtHQUNBO0VBQ0E7R0FDQTtRQUNBO0VBQ0E7RUFFQTtHQUNBO0dBQ0EsTUFDQSxzQkFDQSx3RUFDQTtHQUNBO0lBQUE7SUFBQTtHQUFBO0VBQ0E7RUFDQTtFQUNBO0dBQUE7R0FBQTtFQUFBO0VBQ0E7R0FBQTtHQUFBO0VBQUE7RUFDQSxjQUNBLHNCQUNBLHVFQUNBLDhFQUNBO0NBQ0E7Q0FFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0dBQ0E7RUFDQSxTQUVBO0VBQ0EsY0FDQSwwSEFDQTtDQUNBO0NBRUE7RUFDQTtHQUNBO0dBQ0E7R0FDQTtJQUFBO0lBQUE7R0FBQTtHQUNBO0dBQ0E7RUFDQTtFQUNBO0VBQ0E7R0FBQTtHQUFBO0VBQUE7RUFDQTtDQUNBO0NBRUE7RUFDQTtFQUNBO0VBQ0E7R0FDQTtHQUNBO0dBQ0E7SUFBQTtJQUFBO0dBQUE7R0FDQTtFQUNBO0VBQ0E7RUFDQTtHQUFBO0dBQUE7SUFBQTtJQUFBO0dBQUE7RUFBQTtFQUNBO0dBQ0E7R0FDQTtHQUNBO0lBQUE7SUFBQTtLQUFBO0tBQUE7SUFBQTtHQUFBO0VBQ0E7RUFDQTtDQUNBO0NBRUE7Q0FDQTtDQUNBO0NBRUEsT0FDQTtFQUFBO0VBQUE7RUFBQTtZQUNBO0dBQUE7R0FBQTthQUFBO0lBQ0E7S0FBQTtLQUFBO2VBQUE7TUFFQSxlQUNBO09BQUE7T0FBQTtpQkFBQSxDQUNBO1FBQUE7UUFBQTtrQkFBQSxDQUNBO1NBQUE7U0FBQTtRQUFpRTs7OztrQkFDakU7U0FBQTttQkFBcUI7UUFBQTs7OztnQkFDckI7Ozs7O2lCQUNBO1FBQUE7UUFBQTtrQkFBQSxDQUNBO1NBQ0E7U0FDQTtVQUNBO1VBQ0E7U0FDQTtTQUNBLGdIQUNBLGtDQUNBLDBDQUNBO1NBRUE7bUJBWEEsQ0FZQTtVQUFBO1VBQUE7U0FBa0Q7Ozs7bUJBQUEsZ0NBRWxEOzs7OztrQkFDQTtTQUNBO1NBQ0E7U0FDQSxnSEFDQSwrQkFDQSxxQ0FDQTtTQUVBO21CQVJBLENBU0E7VUFBQTtVQUFBO1NBQWlEOzs7O21CQUFBLG9DQUVqRDs7Ozs7Z0JBQ0E7Ozs7O2VBQ0E7Ozs7OztNQUdBO09BQUE7T0FBQTtpQkFBQSxDQUNBO1FBQUE7UUFBQTtrQkFBQSxDQUNBO1NBQ0Esb0VBQ0Esa0NBQ0EsMkRBQ0E7U0FFQTttQkFDQSxrQ0FDQTtVQUFBO1VBQUE7U0FBOEM7Ozs7b0JBRTlDO1VBQUE7VUFBQTtTQUE2Qzs7Ozs7UUFFN0M7Ozs7a0JBQ0E7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtvQkFBQSxDQUNBLGtDQUNBLG9FQUNBLGlEQUNBLFNBQ0E7V0FBQTtXQUFBO1dBQUE7cUJBQUEsQ0FDQTtZQUFBO1lBQUE7V0FBeUQ7Ozs7cUJBQUEsc0JBQ3pEOzs7OztxQkFFQTtXQUFBO1dBQUE7V0FBQTtxQkFDQTtVQUNBOzs7O2tCQUVBOzs7OzttQkFDQTtVQUFBO1VBQUE7b0JBQUE7V0FDQTtZQUFBO3NCQUF1QjtXQUFBOzs7OztXQUN2QjtZQUFBO1lBQUE7c0JBQWlFO1dBQUE7Ozs7O1dBQ2pFO1lBQUE7c0JBQXVCO1dBQUE7Ozs7O1dBQ3ZCO1lBQUE7WUFBQTtzQkFBQTthQUNBO2NBQUE7Y0FBQTthQUFtRDs7Ozs7YUFBQTthQUFBO1lBQ25EOzs7Ozs7V0FDQSxrQ0FDQSxnREFDQTtZQUFBO3NCQUEyQjtXQUFBOzs7O3FCQUMzQjtZQUFBO1lBQUE7c0JBQUE7YUFBa0U7YUFDbEU7YUFBQTthQUFBO2FBQUE7WUFDQTs7Ozs7bUJBQ0E7Ozs7c0JBRUEsZ0RBQ0E7WUFBQTtzQkFBMkI7V0FBQTs7OztxQkFDM0I7WUFBQTtZQUFBO3NCQUFBO2FBQTRFO2FBQzVFO2FBQUE7WUFDQTs7Ozs7bUJBQ0E7Ozs7O1dBRUEsNkJBQ0EsZ0RBQ0E7WUFBQTtzQkFBMkI7V0FBQTs7OztxQkFDM0I7WUFBQTtZQUFBO3NCQUFBO2FBQWtFO2FBQ2xFO2FBQUE7WUFDQTs7Ozs7bUJBQ0E7Ozs7O1VBRUE7Ozs7O2lCQUNBOzs7OztnQkFDQTs7Ozs7aUJBRUE7UUFBQTtRQUFBO2tCQUFBO1NBQ0EsVUFDQTtVQUFBO1VBQUE7b0JBQUEsQ0FDQTtXQUFBO1dBQUE7VUFBZ0U7Ozs7b0JBQ2hFO1dBQUE7V0FBQTtxQkFBQSxDQUFnRDs7Ozs7a0JBQ2hEOzs7Ozs7U0FFQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtvQkFOQSxDQU9BO1dBQUE7V0FBQTtVQUFrRDs7OztvQkFDbEQseUZBQ0E7Ozs7OztTQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO29CQU5BLENBT0E7V0FBQTtXQUFBO1VBQWdEOzs7O29CQUFBLG9CQUNoRDs7Ozs7O1FBQ0E7Ozs7O2VBQ0E7Ozs7OztNQUdBLGtDQUNBO09BQUE7T0FBQTtpQkFBQTtRQUNBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtvQkFBQSxDQUNBO1dBQUE7V0FBQTtVQUFpRTs7OztvQkFBQSxtRUFFakU7Ozs7O21CQUNBO1VBQUE7VUFBQTtvQkFBNEQ7U0FFNUQ7Ozs7aUJBQ0E7Ozs7OztRQUdBO1NBQUE7U0FBQTttQkFDQSx3Q0FDQTtVQUVBO1VBQ0E7VUFDQSwwRkFDQSwyQkFDQSwyREFDQTtVQUVBO29CQUNBO1NBQ0EsR0FWQTs7OztnQkFVQSxDQUNBO1FBQ0E7Ozs7O1FBR0E7U0FBQTtTQUFBO21CQUFBO1VBQ0E7V0FBQTtXQUFBO3FCQUFBLENBQ0E7WUFBQTtZQUFBO3NCQUE2RztXQUU3Rzs7OztxQkFDQTtZQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7V0FBa0I7Ozs7bUJBQ2xCOzs7Ozs7VUFDQTtXQUFBO1dBQUE7cUJBQUEsQ0FDQTtZQUFBO1lBQUE7c0JBQUEsQ0FDQTthQUFBO3VCQUF5QjtZQUFBOzs7O3NCQUN6QjthQUNBO2FBQ0E7YUFDQTthQUNBO2FBQ0E7YUFDQTtZQUFvQjs7OztvQkFDcEI7Ozs7O3FCQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7WUFDQTtZQUNBO1dBQWtCOzs7O21CQUNsQjs7Ozs7O1VBQ0E7V0FBQTtXQUFBO3FCQUFBLENBQ0E7WUFBQTtZQUFBO3NCQUE2RztXQUU3Rzs7OztxQkFDQTtZQUFBO1lBQUE7c0JBQUEsQ0FDQTthQUNBO2FBQ0E7YUFDQTthQUNBO2FBQ0E7YUFDQTtZQUFvQjs7OztzQkFDcEIsOEJBQ0E7YUFDQTthQUNBO2FBQ0E7YUFDQTthQUNBO2FBQ0E7dUJBQXNCO1lBRXRCOzs7O29CQUVBOzs7OzttQkFDQTs7Ozs7O1NBQ0E7Ozs7OztPQUNBOzs7Ozs7O01BR0E7T0FBQTtPQUFBO2lCQUFBLENBQ0E7UUFBQTtRQUFBO2tCQUFBLENBQ0E7U0FBQTtTQUFBO21CQUFBLENBQ0E7VUFBQTtVQUFBO1NBQW9FOzs7O21CQUFBLGtGQUVwRTs7Ozs7a0JBQ0E7U0FBQTtTQUFBO21CQUVBO1VBQ0E7VUFDQTtVQUNBO1NBQ0EsRUFDQSw0QkFDQTtVQUVBO1VBQ0E7VUFDQSxzRUFDQSwyQkFDQSxnQ0FDQTtVQUVBO29CQUNBO1NBQ0EsR0FWQTs7OztnQkFVQSxDQUNBO1FBQ0E7Ozs7Z0JBQ0E7Ozs7O2lCQUVBO1FBQUE7UUFBQTtrQkFBQSxDQUNBO1NBQ0E7U0FDQTtVQUNBO1VBQ0E7VUFDQTtTQUNBO1NBQ0E7U0FDQTttQkFSQSxDQVNBO1VBQUE7VUFBQTtvQkFBa0M7U0FBQTs7OzttQkFDbEMsNEJBQ0E7VUFBQTtVQUFBO29CQUFBO1dBQ0E7V0FBQTtXQUFBO1dBQUE7VUFDQTtZQUZBOzs7O2dCQUVBLENBQ0EsQ0FDQTs7Ozs7a0JBRUE7U0FDQTtTQUNBO1NBQ0E7U0FDQTtTQUNBO1FBQWdCOzs7O2dCQUNoQjs7Ozs7ZUFDQTs7Ozs7O01BSUE7T0FBQTtPQUFBO2lCQUFBO1FBQ0E7U0FBQTtTQUFBO21CQUFBO1VBQ0E7V0FDQTtXQUNBO1dBQ0Esa0ZBQ0EsOEJBQ0EsNENBQ0E7V0FFQTtxQkFBYztVQUVkOzs7OztVQUNBO1dBQ0E7V0FDQTtXQUNBLGtGQUNBLCtCQUNBLDRDQUNBO1dBRUE7cUJBQWM7VUFFZDs7Ozs7VUFDQTtXQUNBO1dBQ0E7V0FDQSxrRkFDQSwrQkFDQSw0Q0FDQTtXQUVBO3FCQUFjO1VBRWQ7Ozs7O1NBQ0E7Ozs7OztRQUVBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtTQUFpSTs7OzttQkFDakk7VUFDQTtVQUNBO1VBQ0EsYUFDQSxrQ0FDQSwwQ0FDQTtVQUVBO1VBQ0E7U0FBYzs7OztpQkFDZDs7Ozs7O1FBRUE7U0FBQTtTQUFBO21CQUFBLENBQ0E7VUFBQTtVQUFBO1NBQW1JOzs7O21CQUNuSTtVQUNBO1VBQ0E7VUFDQSxhQUNBLGtDQUNBLHVDQUNBO1VBRUE7VUFDQTtTQUFjOzs7O2lCQUNkOzs7Ozs7T0FDQTs7Ozs7O0tBQ0E7Ozs7OztJQUVBO0tBQUE7S0FBQTtlQUFBLENBRUE7TUFBQTtNQUFBO2dCQUFBO09BQ0EsK0JBQ0E7UUFBQTtRQUFBO2tCQUFBLENBQ0E7U0FBQTtTQUFBO21CQUNBO1VBQUE7VUFBQTtTQUFpRjs7Ozs7UUFDakY7Ozs7a0JBQ0E7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtvQkFDQTtTQUNBOzs7O21CQUNBO1VBQUE7VUFBQTtvQkFBQTtXQUE0RDtXQUM1RDtZQUFBO1lBQUE7c0JBQW9FO1dBQUE7Ozs7O1dBQUE7V0FBQTtVQUNwRTs7Ozs7aUJBQ0E7Ozs7O2dCQUNBOzs7OztrQkFFQTtRQUFBO1FBQUE7a0JBQUE7U0FDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtTQUFnQjs7Ozs7U0FDaEIsY0FDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7U0FBa0I7Ozs7O1NBRWxCLCtCQUNBO1VBQUE7VUFBQTtvQkFBQSxDQUNBO1dBQUE7V0FBQTtVQUErRDs7OztvQkFDL0Q7V0FBQTtXQUFBO3FCQUE2QztVQUFBOzs7O2tCQUM3Qzs7Ozs7O1FBRUE7Ozs7OztPQUlBO1FBQUE7UUFBQTtrQkFBQTtTQUNBO1VBQUE7VUFBQTtvQkFBQSxDQUNBO1dBQUE7V0FBQTtxQkFBQTtZQUNBLHVEQUNBO2FBQUE7YUFBQTt1QkFDQTtZQUNBOzs7O3VCQUVBO2FBQUE7YUFBQTt1QkFBMEc7WUFFMUc7Ozs7O1lBRUE7YUFBQTthQUFBO3VCQUFrRDtZQUFBOzs7OztZQUNsRDthQUFBO2FBQUE7dUJBQXFFO1lBQUE7Ozs7O1lBQ3JFLGVBQ0E7YUFBQTthQUFBO3VCQUFBLENBQWdILEtBQ2hILFdBQ0E7Ozs7OztZQUVBLGlCQUNBO2FBQUE7YUFBQTt1QkFBQSxDQUFnRTs7Ozs7O1dBRWhFOzs7OztvQkFHQSx3RUFDQTtXQUFBO1dBQUE7cUJBQUE7WUFDQTthQUFBO2FBQUE7WUFBc0U7Ozs7O1lBQ3RFO2FBQUE7YUFBQTt1QkFBQSxDQUNBO2NBQUE7Y0FBQTt3QkFBQTtlQUNBO2VBQUE7ZUFBQTtlQUFBO2NBQ0E7Ozs7O3VCQUNBO2NBQUE7Y0FBQTt3QkFBcUU7YUFBQTs7OztxQkFDckU7Ozs7OztZQUNBO2FBQ0E7YUFDQTthQUNBO2FBQ0E7YUFDQTt1QkFDQSxzQkFDQTtjQUNBO2VBQUE7ZUFBQTtjQUEwRDs7Ozs7Y0FBQTtjQUFBO2FBQzFEOzs7O3dCQUVBO1lBRUE7Ozs7O1dBQ0E7Ozs7O2tCQUVBOzs7Ozs7U0FHQSxnQ0FDQTtVQUFBO1VBQUE7b0JBQ0EsMkNBQ0E7V0FFQTtXQUNBO1dBQ0EsdUVBQ0EsMkJBQ0EsMENBQ0E7V0FFQTtxQkFDQTtVQUNBLEdBVkE7Ozs7aUJBVUEsQ0FDQTtTQUNBOzs7OztTQUdBLGNBQ0E7VUFBQTtVQUFBO29CQUFBO1dBQ0E7WUFBQTtZQUFBO1dBQW9FOzs7OztXQUFBO1dBQ3BFO1dBQUE7VUFDQTs7Ozs7O1FBRUE7Ozs7OztPQUdBO1FBQUE7UUFBQTtrQkFBQSxDQUNBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtvQkFBQTtXQUNBO1lBQUE7WUFBQTtzQkFBQTthQUFrRDthQUNsRDthQUFBO2FBQUE7YUFBQTtZQUNBOzs7Ozs7V0FDQTtZQUFBO1lBQUE7c0JBQUEsQ0FBa0QsU0FDbEQsZ0ZBQ0E7Ozs7OztXQUNBO1lBQUE7WUFBQTtzQkFBQTthQUFpRDthQUNqRDthQUFBO2FBQUE7YUFBQTtZQUNBOzs7Ozs7VUFDQTs7Ozs7bUJBQ0E7VUFBQTtVQUFBO29CQUFBLENBQ0E7V0FDQTtXQUNBO1dBQ0E7VUFBa0I7Ozs7b0JBQ2xCO1dBQ0E7V0FDQTtXQUNBO1VBQWtCOzs7O2tCQUNsQjs7Ozs7aUJBQ0E7Ozs7O2tCQUVBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0Esc0RBQ0EsNEJBQ0Esa0RBQ0E7VUFFQTtvQkFUQSxDQVVBO1dBQUE7V0FBQTtVQUE2Qzs7OztvQkFBQSxlQUM3Qzs7Ozs7bUJBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBLHNEQUNBO1VBRUE7b0JBUkEsQ0FTQTtXQUFBO1dBQUE7VUFBK0M7Ozs7b0JBQUEsUUFDL0M7Ozs7O2lCQUNBOzs7OztnQkFDQTs7Ozs7O09BR0E7UUFBQTtRQUFBO2tCQUFBO1NBQ0EsZ0NBQ0EsZ0RBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtvQkFDQTtXQUFBO1dBQUE7VUFBMkQ7Ozs7cUJBQUE7V0FBQTtXQUFBO1VBQW1DOzs7OztTQUM5Rjs7OzttQkFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO29CQUNBO1dBQUE7V0FBQTtVQUFtRDs7Ozs7U0FDbkQ7Ozs7aUJBQ0E7Ozs7O1NBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtvQkFDQTtXQUFBO1dBQUE7VUFBa0Q7Ozs7cUJBQUE7V0FBQTtXQUFBO1VBQWlDOzs7OztTQUNuRjs7Ozs7U0FFQSxVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0EsV0FDQSxrQ0FDQSxrR0FDQTtVQUVBO29CQUNBLGtDQUNBLGdEQUNBO1dBQUE7V0FBQTtVQUFrRDs7OztvQkFBQSwyQkFFbEQ7Ozs7cUJBRUEsZ0RBQ0E7V0FBQTtXQUFBO1VBQStEOzs7O29CQUMvRCwrQkFDQSxxQkFDQSwrQkFDQSxxQkFDQSxhQUNBOzs7OztTQUVBOzs7O29CQUVBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO29CQUFnQjtTQUVoQjs7Ozs7UUFFQTs7Ozs7O01BQ0E7Ozs7O2VBR0E7TUFBQTtNQUFBO2dCQUFBO09BQ0E7UUFBQTtRQUFBO2tCQUFBLENBQ0E7U0FBQTtTQUFBO21CQUFBLENBQ0E7VUFBQTtVQUFBO1NBQXNFOzs7O21CQUN0RSxtRkFDQTs7Ozs7a0JBQ0E7U0FBQTtTQUFBO21CQUEyRTtRQUFBOzs7O2dCQUMzRTs7Ozs7O09BRUE7UUFBQTtRQUFBO2tCQUNBLDRCQUNBO1NBQUE7U0FBQTttQkFDQSxrQ0FDQTtVQUNBO1dBQUE7V0FBQTtVQUF3RTs7Ozs7VUFDeEU7V0FBQTtXQUFBO3FCQUFBO1lBQWtFO1lBQ2xFO1lBQUE7V0FDQTs7Ozs7O1VBQ0E7V0FBQTtxQkFBQTtZQUF3QjtZQUN4QjthQUFBO3VCQUFxQztZQUFBOzs7OztZQUFBO1dBQ3JDOzs7Ozs7U0FDQTs7OztvQkFFQSxnREFDQTtVQUFBO1VBQUE7U0FBbUY7Ozs7bUJBQ25GO1VBQUE7b0JBQ0EsU0FDQSx5RUFDQTtTQUNBOzs7O2lCQUNBOzs7OztRQUVBOzs7O21CQUVBLDJCQUNBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtvQkFBQSxDQUNBO1dBQ0Esd0JBQ0EsZUFDQSxtQkFDQSxXQUNBLGlCQUNBO1dBRUE7cUJBQ0E7VUFDQTs7OztvQkFDQTtXQUFBO3FCQUEyQjtVQUFBOzs7O2tCQUMzQjs7Ozs7bUJBQ0E7VUFDQSxnRUFDQSxlQUNBLCtEQUNBO1VBRUE7b0JBQ0E7U0FDQTs7OztpQkFDQTtXQXhCQTs7OztlQXdCQSxDQUNBO09BRUE7Ozs7O09BRUE7UUFBQTtRQUFBO1FBQUE7a0JBQUEsQ0FDQTtTQUNBLGFBQ0EsU0FDQSxrQ0FDQSx5Q0FDQSxnQ0FDQTtTQUVBO1NBQ0E7U0FDQTtTQUNBO1NBQ0E7UUFBYzs7OztrQkFDZDtTQUFBO1NBQUE7U0FBQTtTQUFBO1NBQUE7bUJBQWtIO1FBRWxIOzs7O2dCQUNBOzs7Ozs7TUFDQTs7Ozs7YUFDQTs7Ozs7O0lBRUE7S0FBQTtLQUFBO2VBQUEsQ0FDQTtNQUFBO01BQUE7Z0JBQUEsQ0FDQTtPQUFBO09BQUE7TUFBNkQ7Ozs7Z0JBQzdEO09BQUE7aUJBQUE7UUFBaUI7UUFDakI7U0FBQTttQkFBNkM7UUFBQTs7Ozs7UUFBQTtRQUFBO1FBQzdDO1NBQUE7bUJBQ0Esa0NBQ0Esa0RBQ0E7UUFDQTs7Ozs7T0FDQTs7Ozs7Y0FDQTs7Ozs7ZUFDQTtNQUFBO01BQUE7TUFBQTtNQUFBO2dCQUErRTtLQUUvRTs7OzthQUNBOzs7Ozs7R0FDQTs7Ozs7O0NBQ0E7Ozs7O0FBRUEiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkxpdmVCcm9hZGNhc3RNb2RhbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZVJlZiwgdXNlRWZmZWN0LCB1c2VDYWxsYmFjayB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHR5cGUge1xuICBJQWdvcmFSVENDbGllbnQsXG4gIElDYW1lcmFWaWRlb1RyYWNrLFxuICBJTWljcm9waG9uZUF1ZGlvVHJhY2ssXG59IGZyb20gXCJhZ29yYS1ydGMtc2RrLW5nXCI7XG5pbXBvcnQge1xuICBEaWFsb2csXG4gIERpYWxvZ0NvbnRlbnQsXG4gIERpYWxvZ0hlYWRlcixcbiAgRGlhbG9nVGl0bGUsXG4gIERpYWxvZ0Rlc2NyaXB0aW9uLFxuICBEaWFsb2dGb290ZXIsXG59IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvZGlhbG9nXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiO1xuaW1wb3J0IHsgQmFkZ2UgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2JhZGdlXCI7XG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvaW5wdXRcIjtcbmltcG9ydCB7XG4gIFZpZGVvLFxuICBSYWRpbyxcbiAgTWljLFxuICBNaWNPZmYsXG4gIFZpZGVvT2ZmLFxuICBFeWUsXG4gIE1lc3NhZ2VTcXVhcmUsXG4gIFNwYXJrbGVzLFxuICBCdWlsZGluZzIsXG4gIFNoYXJlMixcbiAgU2hpZWxkQ2hlY2ssXG4gIENpcmNsZURvdCxcbiAgUGhvbmUsXG4gIE1vbml0b3JVcCxcbiAgQWxlcnRUcmlhbmdsZSxcbiAgTWFwUGluLFxuICBIYXNoLFxuICBVc2VyQ2hlY2ssXG4gIEJlbGxSaW5nLFxuICBSb2NrZXQsXG4gIEdpZnQsXG4gIENvaW5zLFxuICBSZWN5Y2xlLFxuICBDaGVjayxcbiAgVXNlcnMsXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSBcInNvbm5lclwiO1xuaW1wb3J0IHsgc3VwYWJhc2UgfSBmcm9tIFwiQC9pbnRlZ3JhdGlvbnMvc3VwYWJhc2UvY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIkAvaG9va3MvdXNlQXV0aFwiO1xuaW1wb3J0IHsgdXNlUm9sZXMgfSBmcm9tIFwiQC9ob29rcy91c2VSb2xlc1wiO1xuaW1wb3J0IHsgZmV0Y2hGZWVkIH0gZnJvbSBcIkAvbGliL3N0YXNoXCI7XG5pbXBvcnQgeyBzZW5kTWVzc2FnZSB9IGZyb20gXCJAL2xpYi9tZXNzYWdlc1wiO1xuaW1wb3J0IHsgcGxheUNvaW5TcGluU291bmQsIHBsYXlUcmFzaFNvdW5kIH0gZnJvbSBcIkAvbGliL3ZlcmRpY3Qtc291bmRzXCI7XG5pbXBvcnQge1xuICBCUkFORF9CUk9BRENBU1RfQ0FURUdPUklFUyxcbiAgQ09OU1VNRVJfQlJPQURDQVNUX0NBVEVHT1JJRVMsXG4gIHB1Ymxpc2hMaXZlQnJvYWRjYXN0U2Vzc2lvbixcbiAgdm90ZU9uTGl2ZUJyb2FkY2FzdCxcbiAgY2xhaW1MaXZlTGF1bmNoUGVyayxcbiAgZ2V0TGl2ZUJyb2FkY2FzdFNlc3Npb25zLFxuICB0eXBlIEJyb2FkY2FzdFBlcnNvbmEsXG4gIHR5cGUgQnJhbmRCcm9hZGNhc3RDYXRlZ29yeSxcbiAgdHlwZSBDb25zdW1lckJyb2FkY2FzdENhdGVnb3J5LFxufSBmcm9tIFwiQC9saWIvbGl2ZS1icm9hZGNhc3RzXCI7XG5pbXBvcnQge1xuICBnZXRBY3RpdmVEZXNrT3BlcmF0b3IsXG4gIHJlY29yZE9wZXJhdG9yUmVzb2x1dGlvbk1ldHJpYyxcbn0gZnJvbSBcIkAvbGliL2JyYW5kLW9wZXJhdG9yc1wiO1xuaW1wb3J0IHR5cGUgeyBBaVNjYW5SZXN1bHQgfSBmcm9tIFwiQC9saWIvYWktc2Nhbm5lclwiO1xuXG5leHBvcnQgaW50ZXJmYWNlIEluY29taW5nU290Q2FsbFBheWxvYWQge1xuICBjYWxsSWQ6IHN0cmluZztcbiAgY2FsbGVySWQ6IHN0cmluZztcbiAgY2FsbGVyTmFtZTogc3RyaW5nO1xuICBjYWxsRGlyZWN0aW9uOiBcImJyYW5kX3RvX3VzZXJcIiB8IFwidXNlcl90b191c2VyXCIgfCBcInVzZXJfdG9fYnJhbmRcIjtcbiAgcmVjaXBpZW50SWQ6IHN0cmluZztcbiAgcmVjaXBpZW50TmFtZTogc3RyaW5nO1xuICBicmFuZE5hbWU6IHN0cmluZztcbiAgdG9waWM6IHN0cmluZztcbiAgbW9kZTogXCJ2b2ljZV9jYWxsXCIgfCBcInZpZGVvX2NhbGxcIiB8IFwiYnJvYWRjYXN0XCI7XG4gIHJvb21DaGFubmVsOiBzdHJpbmc7XG4gIHRpbWVzdGFtcDogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgTGl2ZUJyb2FkY2FzdE1vZGFsUHJvcHMge1xuICBvcGVuOiBib29sZWFuO1xuICBvbk9wZW5DaGFuZ2U6IChvcGVuOiBib29sZWFuKSA9PiB2b2lkO1xuICBicmFuZE5hbWU/OiBzdHJpbmc7XG4gIGJyYW5kU2x1Zz86IHN0cmluZztcbiAgYnJhbmRPd25lcj86IHN0cmluZztcbiAgcHJvZHVjdE5hbWU/OiBzdHJpbmc7XG4gIHNjYW5SZXN1bHQ/OiBBaVNjYW5SZXN1bHQgfCBudWxsO1xuICByZWNpcGllbnRJZD86IHN0cmluZztcbiAgcmVjaXBpZW50TmFtZT86IHN0cmluZztcbiAgZGVmYXVsdE1vZGU/OiBcImJyb2FkY2FzdFwiIHwgXCJ2aWRlb19jYWxsXCIgfCBcInZvaWNlX2NhbGxcIjtcbiAgY3VzdG9tUm9vbUNoYW5uZWw/OiBzdHJpbmc7XG4gIGNhbGxEaXJlY3Rpb24/OiBcImJyYW5kX3RvX3VzZXJcIiB8IFwidXNlcl90b191c2VyXCIgfCBcInVzZXJfdG9fYnJhbmRcIjtcbiAgaW5pdGlhbFBlcnNvbmE/OiBCcm9hZGNhc3RQZXJzb25hO1xuICBpbml0aWFsQnJhbmRDYXRlZ29yeT86IEJyYW5kQnJvYWRjYXN0Q2F0ZWdvcnk7XG4gIGFjdGl2ZUJyb2FkY2FzdElkPzogc3RyaW5nO1xufVxuXG5jb25zdCBHT09HTEVfU1RVTl9TRVJWRVJTOiBSVENJY2VTZXJ2ZXJbXSA9IFtcbiAgeyB1cmxzOiBcInN0dW46c3R1bi5sLmdvb2dsZS5jb206MTkzMDJcIiB9LFxuICB7IHVybHM6IFwic3R1bjpzdHVuMS5sLmdvb2dsZS5jb206MTkzMDJcIiB9LFxuICB7IHVybHM6IFwic3R1bjpzdHVuMi5sLmdvb2dsZS5jb206MTkzMDJcIiB9LFxuXTtcblxuZXhwb3J0IGZ1bmN0aW9uIExpdmVCcm9hZGNhc3RNb2RhbCh7XG4gIG9wZW4sXG4gIG9uT3BlbkNoYW5nZSxcbiAgYnJhbmROYW1lID0gXCJTT1QgQ29tbXVuaXR5IFN0dWRpb1wiLFxuICBicmFuZFNsdWcsXG4gIGJyYW5kT3duZXIgPSBcIlZlcmlmaWVkIFRydXN0IE5ldHdvcmtcIixcbiAgcHJvZHVjdE5hbWUgPSBcIkxpdmUgU2Vzc2lvblwiLFxuICBzY2FuUmVzdWx0LFxuICByZWNpcGllbnRJZDogaW5pdGlhbFJlY2lwaWVudElkLFxuICByZWNpcGllbnROYW1lOiBpbml0aWFsUmVjaXBpZW50TmFtZSxcbiAgZGVmYXVsdE1vZGUgPSBcInZpZGVvX2NhbGxcIixcbiAgY3VzdG9tUm9vbUNoYW5uZWwsXG4gIGNhbGxEaXJlY3Rpb246IGluaXRpYWxDYWxsRGlyZWN0aW9uID0gXCJicmFuZF90b191c2VyXCIsXG4gIGluaXRpYWxQZXJzb25hLFxuICBpbml0aWFsQnJhbmRDYXRlZ29yeSA9IFwicHJvZHVjdF9sYXVuY2hcIixcbiAgYWN0aXZlQnJvYWRjYXN0SWQsXG59OiBMaXZlQnJvYWRjYXN0TW9kYWxQcm9wcykge1xuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgeyBpc0JyYW5kLCBpc0RldmVsb3BlciB9ID0gdXNlUm9sZXMoKTtcblxuICBjb25zdCBbc3R1ZGlvUGVyc29uYSwgc2V0U3R1ZGlvUGVyc29uYV0gPSB1c2VTdGF0ZTxCcm9hZGNhc3RQZXJzb25hPihcbiAgICBpbml0aWFsUGVyc29uYSA/PyAoaXNCcmFuZCA/IFwiYnJhbmRfb3duZXJcIiA6IFwiY29uc3VtZXJcIiksXG4gICk7XG4gIGNvbnN0IFticmFuZENhdGVnb3J5LCBzZXRCcmFuZENhdGVnb3J5XSA9IHVzZVN0YXRlPEJyYW5kQnJvYWRjYXN0Q2F0ZWdvcnk+KGluaXRpYWxCcmFuZENhdGVnb3J5KTtcbiAgY29uc3QgW3NpdHVhdGlvblR5cGUsIHNldFNpdHVhdGlvblR5cGVdID0gdXNlU3RhdGU8Q29uc3VtZXJCcm9hZGNhc3RDYXRlZ29yeT4oXCJjb3VudGVyZmVpdFwiKTtcblxuICBjb25zdCBbYnJvYWRjYXN0SGVhZGxpbmUsIHNldEJyb2FkY2FzdEhlYWRsaW5lXSA9IHVzZVN0YXRlPHN0cmluZz4oXG4gICAgcHJvZHVjdE5hbWUgfHwgYCR7YnJhbmROYW1lfSBMaXZlIFByb2R1Y3QgTGF1bmNoICYgUSZBYCxcbiAgKTtcbiAgY29uc3QgW2Jyb2FkY2FzdFN1YnRpdGxlLCBzZXRCcm9hZGNhc3RTdWJ0aXRsZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KFxuICAgIGBUdW5lIGluIGxpdmUgd2l0aCAke2JyYW5kTmFtZX0g4oCUIGNhc3QgeW91ciBTdGFzaCBvciBUcmFzaCB2ZXJkaWN0IGluIHJlYWwgdGltZSBhbmQgY2xhaW0gdG9kYXkncyBsaXZlIHZpZXdlciBwZXJrIWAsXG4gICk7XG5cbiAgLy8gTGl2ZSBMYXVuY2ggUGVyayAvIFByb21vIERyb3AgQ29udHJvbHMgKGZvciBCcmFuZCBPd25lcnMpXG4gIGNvbnN0IFtlbmFibGVMYXVuY2hQZXJrLCBzZXRFbmFibGVMYXVuY2hQZXJrXSA9IHVzZVN0YXRlKHRydWUpO1xuICBjb25zdCBbcGVya1RpdGxlLCBzZXRQZXJrVGl0bGVdID0gdXNlU3RhdGUoYDI1JSBPZmYgJHticmFuZE5hbWV9IExhdW5jaCBTcGVjaWFsYCk7XG4gIGNvbnN0IFtwZXJrUHJvbW9Db2RlLCBzZXRQZXJrUHJvbW9Db2RlXSA9IHVzZVN0YXRlKFxuICAgIGAke2JyYW5kTmFtZS50b1VwcGVyQ2FzZSgpLnJlcGxhY2UoL1teQS1aMC05XS9nLCBcIlwiKS5zbGljZSgwLCA2KSB8fCBcIlNPVFwifV9MQVVOQ0gyNWAsXG4gICk7XG4gIGNvbnN0IFtwZXJrRGlzY291bnRMYWJlbCwgc2V0UGVya0Rpc2NvdW50TGFiZWxdID0gdXNlU3RhdGUoXCIyNSUgT0ZGIExBVU5DSCBWT1VDSEVSXCIpO1xuICBjb25zdCBbcGVya0NsYWltZWRDb3VudCwgc2V0UGVya0NsYWltZWRDb3VudF0gPSB1c2VTdGF0ZSgxOCk7XG4gIGNvbnN0IFtwZXJrVG90YWxBdmFpbGFibGUsIHNldFBlcmtUb3RhbEF2YWlsYWJsZV0gPSB1c2VTdGF0ZSgxNTApO1xuICBjb25zdCBbaGFzQ2xhaW1lZEluU2Vzc2lvbiwgc2V0SGFzQ2xhaW1lZEluU2Vzc2lvbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgLy8gUmVhbC1UaW1lIExhdW5jaCBQdWxzZSAoU3Rhc2ggdnMgVHJhc2ggTWFya2V0IFJlc2VhcmNoIE1ldGVyKVxuICBjb25zdCBbY3VycmVudEJyb2FkY2FzdElkLCBzZXRDdXJyZW50QnJvYWRjYXN0SWRdID0gdXNlU3RhdGU8c3RyaW5nPihcbiAgICBhY3RpdmVCcm9hZGNhc3RJZCB8fCBgbGl2ZS0ke0RhdGUubm93KCl9YCxcbiAgKTtcbiAgY29uc3QgW2xpdmVTdGFzaFZvdGVzLCBzZXRMaXZlU3Rhc2hWb3Rlc10gPSB1c2VTdGF0ZSg0Mik7XG4gIGNvbnN0IFtsaXZlVHJhc2hWb3Rlcywgc2V0TGl2ZVRyYXNoVm90ZXNdID0gdXNlU3RhdGUoNSk7XG4gIGNvbnN0IFtteUxpdmVWZXJkaWN0LCBzZXRNeUxpdmVWZXJkaWN0XSA9IHVzZVN0YXRlPFwic3Rhc2hcIiB8IFwidHJhc2hcIiB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbZm9sbG93ZXJzQWxlcnRlZENvdW50LCBzZXRGb2xsb3dlcnNBbGVydGVkQ291bnRdID0gdXNlU3RhdGUoMCk7XG5cbiAgY29uc3QgW2lzTGl2ZSwgc2V0SXNMaXZlXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2NvbnN1bWVyU2Vjb25kc0xlZnQsIHNldENvbnN1bWVyU2Vjb25kc0xlZnRdID0gdXNlU3RhdGUoOTApO1xuICBjb25zdCBhY3RpdmVEZXNrT3BlcmF0b3IgPSBnZXRBY3RpdmVEZXNrT3BlcmF0b3IoKTtcbiAgY29uc3QgW3Nlc3Npb25Nb2RlLCBzZXRTZXNzaW9uTW9kZV0gPSB1c2VTdGF0ZTxcImJyb2FkY2FzdFwiIHwgXCJ2aWRlb19jYWxsXCIgfCBcInZvaWNlX2NhbGxcIj4oZGVmYXVsdE1vZGUpO1xuICBjb25zdCBbY2FsbERpcmVjdGlvbiwgc2V0Q2FsbERpcmVjdGlvbl0gPSB1c2VTdGF0ZTxcImJyYW5kX3RvX3VzZXJcIiB8IFwidXNlcl90b191c2VyXCIgfCBcInVzZXJfdG9fYnJhbmRcIj4oXG4gICAgaW5pdGlhbENhbGxEaXJlY3Rpb24sXG4gICk7XG4gIGNvbnN0IFt0YXJnZXRSZWNpcGllbnRJZCwgc2V0VGFyZ2V0UmVjaXBpZW50SWRdID0gdXNlU3RhdGU8c3RyaW5nPihpbml0aWFsUmVjaXBpZW50SWQgfHwgXCJcIik7XG4gIGNvbnN0IFt0YXJnZXRSZWNpcGllbnROYW1lLCBzZXRUYXJnZXRSZWNpcGllbnROYW1lXSA9IHVzZVN0YXRlPHN0cmluZz4oaW5pdGlhbFJlY2lwaWVudE5hbWUgfHwgXCJcIik7XG4gIGNvbnN0IFtwbGF0Zm9ybUNvbnRhY3RzLCBzZXRQbGF0Zm9ybUNvbnRhY3RzXSA9IHVzZVN0YXRlPFxuICAgIEFycmF5PHsgaWQ6IHN0cmluZzsgbmFtZTogc3RyaW5nOyBjb250ZXh0OiBzdHJpbmcgfT5cbiAgPihbXSk7XG4gIGNvbnN0IFtyaW5naW5nU2VudCwgc2V0UmluZ2luZ1NlbnRdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IFtjYW1lcmFPbiwgc2V0Q2FtZXJhT25dID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFttaWNPbiwgc2V0TWljT25dID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFtzY3JlZW5TaGFyaW5nLCBzZXRTY3JlZW5TaGFyaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3ZpZXdlckNvdW50LCBzZXRWaWV3ZXJDb3VudF0gPSB1c2VTdGF0ZSgxNCk7XG4gIGNvbnN0IFtlbmdpbmVVc2VkLCBzZXRFbmdpbmVVc2VkXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJHb29nbGUgV2ViUlRDIChzdHVuLmwuZ29vZ2xlLmNvbSlcIik7XG4gIGNvbnN0IFtyb29tQ2hhbm5lbCwgc2V0Um9vbUNoYW5uZWxdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcbiAgY29uc3QgW3BlZXJKb2luZWQsIHNldFBlZXJKb2luZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIC8vIFNpdHVhdGlvbiAmIENvdW50ZXJmZWl0IEJhdGNoIE1ldGFkYXRhXG4gIGNvbnN0IFtiYXRjaE51bWJlciwgc2V0QmF0Y2hOdW1iZXJdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtzdG9yZUxvY2F0aW9uLCBzZXRTdG9yZUxvY2F0aW9uXSA9IHVzZVN0YXRlKFwiXCIpO1xuXG4gIGNvbnN0IFtjaGF0TWVzc2FnZXMsIHNldENoYXRNZXNzYWdlc10gPSB1c2VTdGF0ZTxcbiAgICB7IHNlbmRlcjogc3RyaW5nOyB0ZXh0OiBzdHJpbmc7IHRpbWU6IHN0cmluZzsgaXNIb3N0PzogYm9vbGVhbjsgaXNQZXJrRHJvcD86IGJvb2xlYW4gfVtdXG4gID4oW10pO1xuICBjb25zdCBbY2hhdElucHV0LCBzZXRDaGF0SW5wdXRdID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgY29uc3QgdmlkZW9SZWYgPSB1c2VSZWY8SFRNTFZpZGVvRWxlbWVudCB8IG51bGw+KG51bGwpO1xuICBjb25zdCByZW1vdGVWaWRlb1JlZiA9IHVzZVJlZjxIVE1MVmlkZW9FbGVtZW50IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHN0cmVhbVJlZiA9IHVzZVJlZjxNZWRpYVN0cmVhbSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBwY1JlZiA9IHVzZVJlZjxSVENQZWVyQ29ubmVjdGlvbiB8IG51bGw+KG51bGwpO1xuICBjb25zdCBhZ29yYUNsaWVudFJlZiA9IHVzZVJlZjxJQWdvcmFSVENDbGllbnQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgYWdvcmFBdWRpb1JlZiA9IHVzZVJlZjxJTWljcm9waG9uZUF1ZGlvVHJhY2sgfCBudWxsPihudWxsKTtcbiAgY29uc3QgYWdvcmFWaWRlb1JlZiA9IHVzZVJlZjxJQ2FtZXJhVmlkZW9UcmFjayB8IG51bGw+KG51bGwpO1xuICBjb25zdCBiY1JlZiA9IHVzZVJlZjxCcm9hZGNhc3RDaGFubmVsIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHN1cGFDaGFuUmVmID0gdXNlUmVmPFJldHVyblR5cGU8dHlwZW9mIHN1cGFiYXNlLmNoYW5uZWw+IHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgY2xlYW51cFNlc3Npb24gPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGFnb3JhQXVkaW9SZWYuY3VycmVudD8uY2xvc2UoKTtcbiAgICAgIGFnb3JhVmlkZW9SZWYuY3VycmVudD8uY2xvc2UoKTtcbiAgICAgIGFnb3JhQXVkaW9SZWYuY3VycmVudCA9IG51bGw7XG4gICAgICBhZ29yYVZpZGVvUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgaWYgKGFnb3JhQ2xpZW50UmVmLmN1cnJlbnQpIHtcbiAgICAgICAgYXdhaXQgYWdvcmFDbGllbnRSZWYuY3VycmVudC5sZWF2ZSgpO1xuICAgICAgICBhZ29yYUNsaWVudFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIH1cbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGlnbm9yZVxuICAgIH1cbiAgICBpZiAocGNSZWYuY3VycmVudCkge1xuICAgICAgcGNSZWYuY3VycmVudC5jbG9zZSgpO1xuICAgICAgcGNSZWYuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICAgIGlmIChiY1JlZi5jdXJyZW50KSB7XG4gICAgICBiY1JlZi5jdXJyZW50LmNsb3NlKCk7XG4gICAgICBiY1JlZi5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gICAgaWYgKHN1cGFDaGFuUmVmLmN1cnJlbnQpIHtcbiAgICAgIHZvaWQgc3VwYWJhc2UucmVtb3ZlQ2hhbm5lbChzdXBhQ2hhblJlZi5jdXJyZW50KTtcbiAgICAgIHN1cGFDaGFuUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH1cbiAgICBpZiAoc3RyZWFtUmVmLmN1cnJlbnQpIHtcbiAgICAgIHN0cmVhbVJlZi5jdXJyZW50LmdldFRyYWNrcygpLmZvckVhY2goKHQpID0+IHQuc3RvcCgpKTtcbiAgICAgIHN0cmVhbVJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gICAgc2V0SXNMaXZlKGZhbHNlKTtcbiAgICBzZXRQZWVySm9pbmVkKGZhbHNlKTtcbiAgICBzZXRTY3JlZW5TaGFyaW5nKGZhbHNlKTtcbiAgfSwgW10pO1xuXG4gIC8vIFN5bmMgcHJvcHMgd2hlbiBvcGVuZWQgZm9yIGEgc3BlY2lmaWMgVXNlciwgQnJhbmQsIG9yIEV4aXN0aW5nIExpdmUgU2Vzc2lvblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChvcGVuKSB7XG4gICAgICBpZiAoaW5pdGlhbFJlY2lwaWVudElkKSBzZXRUYXJnZXRSZWNpcGllbnRJZChpbml0aWFsUmVjaXBpZW50SWQpO1xuICAgICAgaWYgKGluaXRpYWxSZWNpcGllbnROYW1lKSBzZXRUYXJnZXRSZWNpcGllbnROYW1lKGluaXRpYWxSZWNpcGllbnROYW1lKTtcbiAgICAgIGlmIChkZWZhdWx0TW9kZSkgc2V0U2Vzc2lvbk1vZGUoZGVmYXVsdE1vZGUpO1xuICAgICAgaWYgKGluaXRpYWxDYWxsRGlyZWN0aW9uKSBzZXRDYWxsRGlyZWN0aW9uKGluaXRpYWxDYWxsRGlyZWN0aW9uKTtcbiAgICAgIGlmIChpbml0aWFsUGVyc29uYSkge1xuICAgICAgICBzZXRTdHVkaW9QZXJzb25hKGluaXRpYWxQZXJzb25hKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNldFN0dWRpb1BlcnNvbmEoaXNCcmFuZCA/IFwiYnJhbmRfb3duZXJcIiA6IFwiY29uc3VtZXJcIik7XG4gICAgICB9XG4gICAgICBpZiAoaW5pdGlhbEJyYW5kQ2F0ZWdvcnkpIHNldEJyYW5kQ2F0ZWdvcnkoaW5pdGlhbEJyYW5kQ2F0ZWdvcnkpO1xuICAgICAgc2V0UmluZ2luZ1NlbnQoZmFsc2UpO1xuICAgICAgc2V0SGFzQ2xhaW1lZEluU2Vzc2lvbihmYWxzZSk7XG5cbiAgICAgIC8vIElmIGpvaW5pbmcgYW4gYWN0aXZlIGJyb2FkY2FzdCBmcm9tIHRoZSBIb21lL0ZlZWQgTGl2ZSBTdGFnZSwgaHlkcmF0ZSBpdHMgbWV0cmljc1xuICAgICAgaWYgKGFjdGl2ZUJyb2FkY2FzdElkKSB7XG4gICAgICAgIHNldEN1cnJlbnRCcm9hZGNhc3RJZChhY3RpdmVCcm9hZGNhc3RJZCk7XG4gICAgICAgIGNvbnN0IGV4aXN0aW5nID0gZ2V0TGl2ZUJyb2FkY2FzdFNlc3Npb25zKCkuZmluZCgocykgPT4gcy5pZCA9PT0gYWN0aXZlQnJvYWRjYXN0SWQpO1xuICAgICAgICBpZiAoZXhpc3RpbmcpIHtcbiAgICAgICAgICBzZXRTdHVkaW9QZXJzb25hKGV4aXN0aW5nLnBlcnNvbmEpO1xuICAgICAgICAgIHNldEJyb2FkY2FzdEhlYWRsaW5lKGV4aXN0aW5nLnRpdGxlKTtcbiAgICAgICAgICBzZXRCcm9hZGNhc3RTdWJ0aXRsZShleGlzdGluZy5zdWJ0aXRsZSk7XG4gICAgICAgICAgc2V0TGl2ZVN0YXNoVm90ZXMoZXhpc3Rpbmcuc3Rhc2hWb3Rlcyk7XG4gICAgICAgICAgc2V0TGl2ZVRyYXNoVm90ZXMoZXhpc3RpbmcudHJhc2hWb3Rlcyk7XG4gICAgICAgICAgc2V0Vmlld2VyQ291bnQoZXhpc3Rpbmcudmlld2VyQ291bnQgKyAxKTtcbiAgICAgICAgICBpZiAoZXhpc3RpbmcuYnJhbmRDYXRlZ29yeSkgc2V0QnJhbmRDYXRlZ29yeShleGlzdGluZy5icmFuZENhdGVnb3J5KTtcbiAgICAgICAgICBpZiAoZXhpc3RpbmcuY29uc3VtZXJDYXRlZ29yeSkgc2V0U2l0dWF0aW9uVHlwZShleGlzdGluZy5jb25zdW1lckNhdGVnb3J5KTtcbiAgICAgICAgICBpZiAoZXhpc3RpbmcubGF1bmNoUGVyaykge1xuICAgICAgICAgICAgc2V0RW5hYmxlTGF1bmNoUGVyayh0cnVlKTtcbiAgICAgICAgICAgIHNldFBlcmtUaXRsZShleGlzdGluZy5sYXVuY2hQZXJrLnRpdGxlKTtcbiAgICAgICAgICAgIHNldFBlcmtQcm9tb0NvZGUoZXhpc3RpbmcubGF1bmNoUGVyay5wcm9tb0NvZGUpO1xuICAgICAgICAgICAgc2V0UGVya0Rpc2NvdW50TGFiZWwoZXhpc3RpbmcubGF1bmNoUGVyay5kaXNjb3VudExhYmVsKTtcbiAgICAgICAgICAgIHNldFBlcmtDbGFpbWVkQ291bnQoZXhpc3RpbmcubGF1bmNoUGVyay5jbGFpbWVkQ291bnQpO1xuICAgICAgICAgICAgc2V0UGVya1RvdGFsQXZhaWxhYmxlKGV4aXN0aW5nLmxhdW5jaFBlcmsudG90YWxBdmFpbGFibGUpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgY2xlYW5QcmVmaXggPVxuICAgICAgICAgIGJyYW5kTmFtZS50b1VwcGVyQ2FzZSgpLnJlcGxhY2UoL1teQS1aMC05XS9nLCBcIlwiKS5zbGljZSgwLCA2KSB8fCBcIlNPVFwiO1xuICAgICAgICBzZXRCcm9hZGNhc3RIZWFkbGluZShcbiAgICAgICAgICBwcm9kdWN0TmFtZSAmJiBwcm9kdWN0TmFtZSAhPT0gXCJMaXZlIFNlc3Npb25cIlxuICAgICAgICAgICAgPyBwcm9kdWN0TmFtZVxuICAgICAgICAgICAgOiBgJHticmFuZE5hbWV9IExpdmUgUHJvZHVjdCBMYXVuY2ggJiBDbGllbnQgU2hvd2Nhc2VgLFxuICAgICAgICApO1xuICAgICAgICBzZXRQZXJrVGl0bGUoYDI1JSBPZmYgJHticmFuZE5hbWV9IExhdW5jaCBTcGVjaWFsYCk7XG4gICAgICAgIHNldFBlcmtQcm9tb0NvZGUoYCR7Y2xlYW5QcmVmaXh9X0xBVU5DSDI1YCk7XG4gICAgICB9XG5cbiAgICAgIC8vIExvYWQgYWN0aXZlIHVzZXJzL2F1dGhvcnMgZnJvbSBmZWVkIHNvIEJyYW5kIE93bmVycyBvciBVc2VycyBjYW4gcGljayBhIGNsaWVudC9wZWVyIHRvIGNhbGxcbiAgICAgIHZvaWQgZmV0Y2hGZWVkKG51bGwpXG4gICAgICAgIC50aGVuKChpdGVtcykgPT4ge1xuICAgICAgICAgIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgICAgICAgICBjb25zdCBsaXN0OiBBcnJheTx7IGlkOiBzdHJpbmc7IG5hbWU6IHN0cmluZzsgY29udGV4dDogc3RyaW5nIH0+ID0gW107XG4gICAgICAgICAgZm9yIChjb25zdCBpdCBvZiBpdGVtcykge1xuICAgICAgICAgICAgaWYgKGl0LnVzZXJfaWQgJiYgIXNlZW4uaGFzKGl0LnVzZXJfaWQpKSB7XG4gICAgICAgICAgICAgIHNlZW4uYWRkKGl0LnVzZXJfaWQpO1xuICAgICAgICAgICAgICBsaXN0LnB1c2goe1xuICAgICAgICAgICAgICAgIGlkOiBpdC51c2VyX2lkLFxuICAgICAgICAgICAgICAgIG5hbWU6IGl0LmF1dGhvck5hbWUgfHwgYFVzZXIgJHtpdC51c2VyX2lkLnNsaWNlKDAsIDYpfWAsXG4gICAgICAgICAgICAgICAgY29udGV4dDogYCR7aXQuYnJhbmROYW1lID8gYCR7aXQuYnJhbmROYW1lfTogYCA6IFwiXCJ9JHtpdC50aXRsZS5zbGljZSgwLCA0MCl9YCxcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChsaXN0Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgbGlzdC5wdXNoKFxuICAgICAgICAgICAgICB7IGlkOiBcImNsaWVudC10aGFib1wiLCBuYW1lOiBcIlRoYWJvIE0uIChWZXJpZmllZCBDbGllbnQpXCIsIGNvbnRleHQ6IFwiUmVwb3J0ZWQgYmF0Y2ggaW5xdWlyeSBvbiBTT1RcIiB9LFxuICAgICAgICAgICAgICB7IGlkOiBcImNsaWVudC1sZXJhdG9cIiwgbmFtZTogXCJMZXJhdG8gSy4gKEFjdGl2ZSBWb3RlcilcIiwgY29udGV4dDogXCJSZWNlbnQgU3Rhc2gvVHJhc2ggcmV2aWV3ZXJcIiB9LFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgc2V0UGxhdGZvcm1Db250YWN0cyhsaXN0LnNsaWNlKDAsIDIwKSk7XG4gICAgICAgICAgaWYgKCFpbml0aWFsUmVjaXBpZW50TmFtZSAmJiBsaXN0WzBdKSB7XG4gICAgICAgICAgICBzZXRUYXJnZXRSZWNpcGllbnRJZChsaXN0WzBdLmlkKTtcbiAgICAgICAgICAgIHNldFRhcmdldFJlY2lwaWVudE5hbWUobGlzdFswXS5uYW1lKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgLy8gaWdub3JlXG4gICAgICAgIH0pO1xuICAgIH1cbiAgfSwgW1xuICAgIG9wZW4sXG4gICAgaW5pdGlhbFJlY2lwaWVudElkLFxuICAgIGluaXRpYWxSZWNpcGllbnROYW1lLFxuICAgIGRlZmF1bHRNb2RlLFxuICAgIGluaXRpYWxDYWxsRGlyZWN0aW9uLFxuICAgIGluaXRpYWxQZXJzb25hLFxuICAgIGluaXRpYWxCcmFuZENhdGVnb3J5LFxuICAgIGFjdGl2ZUJyb2FkY2FzdElkLFxuICAgIGJyYW5kTmFtZSxcbiAgICBwcm9kdWN0TmFtZSxcbiAgICBpc0JyYW5kLFxuICBdKTtcblxuICAvLyBTZXR1cCBjYW1lcmEvbWljIHByZXZpZXcgd2hlbiBtb2RhbCBpcyBvcGVuZWRcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsZXQgYWN0aXZlID0gdHJ1ZTtcbiAgICBpZiAob3Blbikge1xuICAgICAgY29uc3Qgc2x1ZyA9XG4gICAgICAgIGN1c3RvbVJvb21DaGFubmVsIHx8XG4gICAgICAgIGBzb3QtY2FsbC0keyh0YXJnZXRSZWNpcGllbnRJZCB8fCBicmFuZE5hbWUpLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvW15hLXowLTldKy9nLCBcIi1cIikuc2xpY2UoMCwgMjIpfWA7XG4gICAgICBzZXRSb29tQ2hhbm5lbChzbHVnKTtcbiAgICAgIG5hdmlnYXRvci5tZWRpYURldmljZXNcbiAgICAgICAgPy5nZXRVc2VyTWVkaWEoeyB2aWRlbzogc2Vzc2lvbk1vZGUgIT09IFwidm9pY2VfY2FsbFwiLCBhdWRpbzogdHJ1ZSB9KVxuICAgICAgICAudGhlbigocykgPT4ge1xuICAgICAgICAgIGlmICghYWN0aXZlKSB7XG4gICAgICAgICAgICBzLmdldFRyYWNrcygpLmZvckVhY2goKHQpID0+IHQuc3RvcCgpKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgc3RyZWFtUmVmLmN1cnJlbnQgPSBzO1xuICAgICAgICAgIGlmICh2aWRlb1JlZi5jdXJyZW50ICYmIHNlc3Npb25Nb2RlICE9PSBcInZvaWNlX2NhbGxcIikge1xuICAgICAgICAgICAgdmlkZW9SZWYuY3VycmVudC5zcmNPYmplY3QgPSBzO1xuICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICAgICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICBjb25zb2xlLndhcm4oXCJDYW1lcmEvbWljIHBlcm1pc3Npb24gbm90aWNlOlwiLCBlcnIpO1xuICAgICAgICAgIHRvYXN0Lndhcm5pbmcoXCJDYW1lcmEgb3IgbWljcm9waG9uZSBwZXJtaXNzaW9uIG5vdCBncmFudGVkLiBQcmV2aWV3IG1vZGUgZW5hYmxlZC5cIik7XG4gICAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB2b2lkIGNsZWFudXBTZXNzaW9uKCk7XG4gICAgfVxuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGFjdGl2ZSA9IGZhbHNlO1xuICAgIH07XG4gIH0sIFtvcGVuLCBicmFuZE5hbWUsIHRhcmdldFJlY2lwaWVudElkLCBjdXN0b21Sb29tQ2hhbm5lbCwgc2Vzc2lvbk1vZGUsIGNsZWFudXBTZXNzaW9uXSk7XG5cbiAgY29uc3QgaGFuZGxlQ2F0ZWdvcnlQcmVzZXRDaGFuZ2UgPSAoY2F0OiBCcmFuZEJyb2FkY2FzdENhdGVnb3J5KSA9PiB7XG4gICAgc2V0QnJhbmRDYXRlZ29yeShjYXQpO1xuICAgIGNvbnN0IGNsZWFuUHJlZml4ID0gYnJhbmROYW1lLnRvVXBwZXJDYXNlKCkucmVwbGFjZSgvW15BLVowLTldL2csIFwiXCIpLnNsaWNlKDAsIDYpIHx8IFwiU09UXCI7XG4gICAgaWYgKGNhdCA9PT0gXCJwcm9kdWN0X2xhdW5jaFwiKSB7XG4gICAgICBzZXRCcm9hZGNhc3RIZWFkbGluZShgTElWRSBMQVVOQ0g6ICR7YnJhbmROYW1lfSBOZXcgUHJvZHVjdCAmIElubm92YXRpb24gUmV2ZWFsYCk7XG4gICAgICBzZXRCcm9hZGNhc3RTdWJ0aXRsZShcbiAgICAgICAgYFVudmVpbGluZyBvdXIgbmV3ZXN0IHJlbGVhc2UgbGl2ZSBmb3IgU09UIGNsaWVudHMgJiBwcm9zcGVjdHMuIFZvdGUgU3Rhc2ggb3IgVHJhc2ggbGl2ZSFgLFxuICAgICAgKTtcbiAgICAgIHNldFBlcmtUaXRsZShgMjUlIE9mZiAke2JyYW5kTmFtZX0gTmV3IExhdW5jaGApO1xuICAgICAgc2V0UGVya1Byb21vQ29kZShgJHtjbGVhblByZWZpeH1fTEFVTkNIMjVgKTtcbiAgICAgIHNldFBlcmtEaXNjb3VudExhYmVsKFwiMjUlIE9GRiBMQVVOQ0ggVk9VQ0hFUlwiKTtcbiAgICB9IGVsc2UgaWYgKGNhdCA9PT0gXCJicmFuZF9yZWxhdW5jaFwiKSB7XG4gICAgICBzZXRCcm9hZGNhc3RIZWFkbGluZShgUkVMQVVOQ0ggU1BFQ0lBTDogJHticmFuZE5hbWV9IFVwZ3JhZGVkIFNlcnZpY2UgJiBRdWFsaXR5IFByb21pc2VgKTtcbiAgICAgIHNldEJyb2FkY2FzdFN1YnRpdGxlKFxuICAgICAgICBgWW91IHNwb2tlIG9uIFNPVCwgYW5kIHdlIGxpc3RlbmVkISBTZWUgdGhlIHVwZ3JhZGVzIHdlIG1hZGUgYmFzZWQgb24geW91ciB2ZXJkaWN0cy5gLFxuICAgICAgKTtcbiAgICAgIHNldFBlcmtUaXRsZShgJHticmFuZE5hbWV9IENvbWViYWNrIFJlY292ZXJ5IFZvdWNoZXJgKTtcbiAgICAgIHNldFBlcmtQcm9tb0NvZGUoYCR7Y2xlYW5QcmVmaXh9X1JFTEFVTkNINTBgKTtcbiAgICAgIHNldFBlcmtEaXNjb3VudExhYmVsKFwiQ09NRUJBQ0sgVklQIFZPVUNIRVJcIik7XG4gICAgfSBlbHNlIGlmIChjYXQgPT09IFwiYmVoaW5kX3NjZW5lc1wiKSB7XG4gICAgICBzZXRCcm9hZGNhc3RIZWFkbGluZShgQkVISU5EIFRIRSBTQ0VORVM6IEluc2lkZSAke2JyYW5kTmFtZX0gUXVhbGl0eSAmIEF1dGhlbnRpY2l0eSBMYWJgKTtcbiAgICAgIHNldEJyb2FkY2FzdFN1YnRpdGxlKFxuICAgICAgICBgTGl2ZSB3YWxrdGhyb3VnaCBvZiBvdXIgb3BlcmF0aW9ucyBhbmQgYmF0Y2ggdmVyaWZpY2F0aW9uIHN0YW5kYXJkcy5gLFxuICAgICAgKTtcbiAgICAgIHNldFBlcmtUaXRsZShgVmVyaWZpZWQgQXV0aGVudGljIEJ1eWVyIFBhc3NgKTtcbiAgICAgIHNldFBlcmtQcm9tb0NvZGUoYCR7Y2xlYW5QcmVmaXh9X0FVVEgxNWApO1xuICAgICAgc2V0UGVya0Rpc2NvdW50TGFiZWwoXCIxNSUgQVVUSEVOVElDIFBBU1NcIik7XG4gICAgfSBlbHNlIGlmIChjYXQgPT09IFwidG93bmhhbGxfcWFcIikge1xuICAgICAgc2V0QnJvYWRjYXN0SGVhZGxpbmUoYExJVkUgVE9XTkhBTEwgUSZBOiAke2JyYW5kTmFtZX0gTGVhZGVyc2hpcCBBbnN3ZXJpbmcgWW91ciBRdWVzdGlvbnNgKTtcbiAgICAgIHNldEJyb2FkY2FzdFN1YnRpdGxlKFxuICAgICAgICBgQXNrIHVzIGFueXRoaW5nIGxpdmUgaW4gdGhlIGNoYXQgb3IgcmVxdWVzdCB0byBqb2luIG9uIGNhbWVyYSB3aXRoIG91ciBDWCAmIFByb2R1Y3QgdGVhbS5gLFxuICAgICAgKTtcbiAgICAgIHNldFBlcmtUaXRsZShgVG93bmhhbGwgUGFydGljaXBhbnQgTG95YWx0eSBSZXdhcmRgKTtcbiAgICAgIHNldFBlcmtQcm9tb0NvZGUoYCR7Y2xlYW5QcmVmaXh9X1RPV05IQUxMYCk7XG4gICAgICBzZXRQZXJrRGlzY291bnRMYWJlbChcIlZJUCBUT1dOSEFMTCBQRVJLXCIpO1xuICAgIH0gZWxzZSBpZiAoY2F0ID09PSBcImZsYXNoX2Ryb3BcIikge1xuICAgICAgc2V0QnJvYWRjYXN0SGVhZGxpbmUoYEZMQVNIIFBFUksgRFJPUDogJHticmFuZE5hbWV9IEV4Y2x1c2l2ZSBMaXZlIFZpZXdlciBHaXZlYXdheWApO1xuICAgICAgc2V0QnJvYWRjYXN0U3VidGl0bGUoXG4gICAgICAgIGBMaW1pdGVkLXRpbWUgcmV3YXJkIGRyb3AgZm9yIG91ciBTT1QgZm9sbG93ZXJzIGFuZCBsaXZlIHByb3NwZWN0cyFgLFxuICAgICAgKTtcbiAgICAgIHNldFBlcmtUaXRsZShgRmxhc2ggNDAlIE9mZiBWSVAgQ29kZWApO1xuICAgICAgc2V0UGVya1Byb21vQ29kZShgJHtjbGVhblByZWZpeH1fRkxBU0g0MGApO1xuICAgICAgc2V0UGVya0Rpc2NvdW50TGFiZWwoXCI0MCUgRkxBU0ggRFJPUFwiKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgcmluZ1JlY2lwaWVudE9uUGxhdGZvcm0gPSB1c2VDYWxsYmFjayhcbiAgICBhc3luYyAoY2hhbm5lbFRvUmluZzogc3RyaW5nKSA9PiB7XG4gICAgICBjb25zdCByZXNvbHZlZFJlY2lwaWVudE5hbWUgPSB0YXJnZXRSZWNpcGllbnROYW1lLnRyaW0oKSB8fCBicmFuZE5hbWUgfHwgXCJTT1QgVXNlclwiO1xuICAgICAgY29uc3QgcmVzb2x2ZWRSZWNpcGllbnRJZCA9IHRhcmdldFJlY2lwaWVudElkLnRyaW0oKSB8fCBcInNvdC1jb21tdW5pdHktbWVtYmVyXCI7XG4gICAgICBjb25zdCBjYWxsZXJEaXNwbGF5ID1cbiAgICAgICAgY2FsbERpcmVjdGlvbiA9PT0gXCJicmFuZF90b191c2VyXCJcbiAgICAgICAgICA/IGAke2JyYW5kTmFtZX0gKEJyYW5kIE93bmVyIC8gQ1ggRGVzaylgXG4gICAgICAgICAgOiB1c2VyPy5lbWFpbD8uc3BsaXQoXCJAXCIpWzBdIHx8IFwiU09UIE1lbWJlclwiO1xuXG4gICAgICBjb25zdCByaW5nUGF5bG9hZDogSW5jb21pbmdTb3RDYWxsUGF5bG9hZCA9IHtcbiAgICAgICAgY2FsbElkOiBgY2FsbC0ke0RhdGUubm93KCl9YCxcbiAgICAgICAgY2FsbGVySWQ6IHVzZXI/LmlkIHx8IFwiYnJhbmQtb3BlcmF0b3JcIixcbiAgICAgICAgY2FsbGVyTmFtZTogY2FsbGVyRGlzcGxheSxcbiAgICAgICAgY2FsbERpcmVjdGlvbixcbiAgICAgICAgcmVjaXBpZW50SWQ6IHJlc29sdmVkUmVjaXBpZW50SWQsXG4gICAgICAgIHJlY2lwaWVudE5hbWU6IHJlc29sdmVkUmVjaXBpZW50TmFtZSxcbiAgICAgICAgYnJhbmROYW1lLFxuICAgICAgICB0b3BpYzogYnJvYWRjYXN0SGVhZGxpbmUgfHwgcHJvZHVjdE5hbWUgfHwgYCR7YnJhbmROYW1lfSBSZXNvbHV0aW9uIENhbGxgLFxuICAgICAgICBtb2RlOiBzZXNzaW9uTW9kZSxcbiAgICAgICAgcm9vbUNoYW5uZWw6IGNoYW5uZWxUb1JpbmcsXG4gICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgfTtcblxuICAgICAgLy8gMS4gUmluZyBpbiByZWFsLXRpbWUgdmlhIEJyb2FkY2FzdENoYW5uZWwgKHNhbWUgYnJvd3NlciAvIG11bHRpLXRhYiBwcmV2aWV3KVxuICAgICAgaWYgKHR5cGVvZiBCcm9hZGNhc3RDaGFubmVsICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgIGNvbnN0IHJpbmdCYyA9IG5ldyBCcm9hZGNhc3RDaGFubmVsKFwic290LWNhbGwtcmluZ1wiKTtcbiAgICAgICAgcmluZ0JjLnBvc3RNZXNzYWdlKHJpbmdQYXlsb2FkKTtcbiAgICAgICAgcmluZ0JjLmNsb3NlKCk7XG4gICAgICB9XG5cbiAgICAgIC8vIDIuIFJpbmcgYWNyb3NzIGRldmljZXMgdmlhIFN1cGFiYXNlIFJlYWx0aW1lIGJyb2FkY2FzdCBjaGFubmVsXG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByaW5nQ2hhbiA9IHN1cGFiYXNlLmNoYW5uZWwoXCJzb3QtY2FsbC1yaW5nXCIpO1xuICAgICAgICByaW5nQ2hhbi5zdWJzY3JpYmUoKHN0YXR1cykgPT4ge1xuICAgICAgICAgIGlmIChzdGF0dXMgPT09IFwiU1VCU0NSSUJFRFwiKSB7XG4gICAgICAgICAgICB2b2lkIHJpbmdDaGFuLnNlbmQoe1xuICAgICAgICAgICAgICB0eXBlOiBcImJyb2FkY2FzdFwiLFxuICAgICAgICAgICAgICBldmVudDogXCJpbmNvbWluZy1jYWxsXCIsXG4gICAgICAgICAgICAgIHBheWxvYWQ6IHJpbmdQYXlsb2FkLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvLyBpZ25vcmVcbiAgICAgIH1cblxuICAgICAgLy8gMy4gQWxzbyBkcm9wIGFuIGF1dG9tYXRpYyBEaXJlY3QgQ2FsbCBBbGVydCBpbiB0aGUgdXNlcidzIFNPVCBJbmJveCAoaW4gY2FzZSB0aGV5IGFyZW4ndCBvbiB0aGVpciBwaG9uZSlcbiAgICAgIGlmICh1c2VyPy5pZCAmJiByZXNvbHZlZFJlY2lwaWVudElkICYmIHJlc29sdmVkUmVjaXBpZW50SWQgIT09IHVzZXIuaWQpIHtcbiAgICAgICAgY29uc3Qgb3JpZ2luID0gdHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiA/IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4gOiBcImh0dHBzOi8vc29ydC5hcHBcIjtcbiAgICAgICAgY29uc3QgY2FsbExpbmsgPSBgJHtvcmlnaW59L21lc3NhZ2VzP3RvPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHVzZXIuaWQpfSZyb29tPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGNoYW5uZWxUb1JpbmcpfWA7XG4gICAgICAgIGNvbnN0IG1vZGVMYWJlbCA9XG4gICAgICAgICAgc2Vzc2lvbk1vZGUgPT09IFwidm9pY2VfY2FsbFwiXG4gICAgICAgICAgICA/IFwiVm9pY2UgQ2FsbFwiXG4gICAgICAgICAgICA6IHNlc3Npb25Nb2RlID09PSBcInZpZGVvX2NhbGxcIlxuICAgICAgICAgICAgICA/IFwiVmlkZW8gQ2FsbFwiXG4gICAgICAgICAgICAgIDogc3R1ZGlvUGVyc29uYSA9PT0gXCJicmFuZF9vd25lclwiXG4gICAgICAgICAgICAgICAgPyBcIkxpdmUgQnJhbmQgTGF1bmNoIEJyb2FkY2FzdFwiXG4gICAgICAgICAgICAgICAgOiBcIkxpdmUgU2l0dWF0aW9uIEJyb2FkY2FzdFwiO1xuICAgICAgICB2b2lkIHNlbmRNZXNzYWdlKHtcbiAgICAgICAgICBzZW5kZXJJZDogdXNlci5pZCxcbiAgICAgICAgICByZWNpcGllbnRJZDogcmVzb2x2ZWRSZWNpcGllbnRJZCxcbiAgICAgICAgICBib2R5OiBg8J+TniBJTkNPTUlORyAke21vZGVMYWJlbC50b1VwcGVyQ2FzZSgpfSBPTiBTT1QgZnJvbSAke2NhbGxlckRpc3BsYXl9IChyZWdhcmRpbmcgJHticmFuZE5hbWV9IOKAlCAke2Jyb2FkY2FzdEhlYWRsaW5lfSkuIENsaWNrIHRvIGpvaW4gb3VyIGxpdmUgcm9vbSAoJHtjaGFubmVsVG9SaW5nfSk6ICR7Y2FsbExpbmt9YCxcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIHNldFJpbmdpbmdTZW50KHRydWUpO1xuICAgICAgdG9hc3Quc3VjY2VzcyhcbiAgICAgICAgYFJpbmdpbmcgJHtyZXNvbHZlZFJlY2lwaWVudE5hbWV9IGRpcmVjdGx5IG9uIFNPVCAoJHtzZXNzaW9uTW9kZSA9PT0gXCJ2b2ljZV9jYWxsXCIgPyBcIlZvaWNlXCIgOiBcIlZpZGVvXCJ9KSArIHNlbnQgZGlyZWN0IGxpbmsgdG8gdGhlaXIgU09UIEluYm94IWAsXG4gICAgICApO1xuICAgIH0sXG4gICAgW3RhcmdldFJlY2lwaWVudE5hbWUsIHRhcmdldFJlY2lwaWVudElkLCBicmFuZE5hbWUsIGJyb2FkY2FzdEhlYWRsaW5lLCBwcm9kdWN0TmFtZSwgY2FsbERpcmVjdGlvbiwgc2Vzc2lvbk1vZGUsIHN0dWRpb1BlcnNvbmEsIHVzZXJdLFxuICApO1xuXG4gIGNvbnN0IHRvZ2dsZUNhbWVyYSA9ICgpID0+IHtcbiAgICBjb25zdCBuZXh0ID0gIWNhbWVyYU9uO1xuICAgIHNldENhbWVyYU9uKG5leHQpO1xuICAgIGlmIChzdHJlYW1SZWYuY3VycmVudCkge1xuICAgICAgc3RyZWFtUmVmLmN1cnJlbnQuZ2V0VmlkZW9UcmFja3MoKS5mb3JFYWNoKCh0KSA9PiB7XG4gICAgICAgIHQuZW5hYmxlZCA9IG5leHQ7XG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKGFnb3JhVmlkZW9SZWYuY3VycmVudCkge1xuICAgICAgdm9pZCBhZ29yYVZpZGVvUmVmLmN1cnJlbnQuc2V0RW5hYmxlZChuZXh0KTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgdG9nZ2xlTWljID0gKCkgPT4ge1xuICAgIGNvbnN0IG5leHQgPSAhbWljT247XG4gICAgc2V0TWljT24obmV4dCk7XG4gICAgaWYgKHN0cmVhbVJlZi5jdXJyZW50KSB7XG4gICAgICBzdHJlYW1SZWYuY3VycmVudC5nZXRBdWRpb1RyYWNrcygpLmZvckVhY2goKHQpID0+IHtcbiAgICAgICAgdC5lbmFibGVkID0gbmV4dDtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAoYWdvcmFBdWRpb1JlZi5jdXJyZW50KSB7XG4gICAgICB2b2lkIGFnb3JhQXVkaW9SZWYuY3VycmVudC5zZXRFbmFibGVkKG5leHQpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCB0b2dnbGVTY3JlZW5TaGFyZSA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIW5hdmlnYXRvci5tZWRpYURldmljZXM/LmdldERpc3BsYXlNZWRpYSkge1xuICAgICAgdG9hc3QuZXJyb3IoXCJTY3JlZW4gc2hhcmluZyBpcyBub3Qgc3VwcG9ydGVkIG9uIHRoaXMgYnJvd3Nlci5cIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBkaXNwbGF5U3RyZWFtID0gYXdhaXQgbmF2aWdhdG9yLm1lZGlhRGV2aWNlcy5nZXREaXNwbGF5TWVkaWEoeyB2aWRlbzogdHJ1ZSB9KTtcbiAgICAgIGNvbnN0IHNjcmVlblRyYWNrID0gZGlzcGxheVN0cmVhbS5nZXRWaWRlb1RyYWNrcygpWzBdO1xuICAgICAgaWYgKCFzY3JlZW5UcmFjaykgcmV0dXJuO1xuICAgICAgaWYgKHZpZGVvUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgdmlkZW9SZWYuY3VycmVudC5zcmNPYmplY3QgPSBkaXNwbGF5U3RyZWFtO1xuICAgICAgfVxuICAgICAgaWYgKHBjUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgY29uc3Qgc2VuZGVyID0gcGNSZWYuY3VycmVudC5nZXRTZW5kZXJzKCkuZmluZCgocykgPT4gcy50cmFjaz8ua2luZCA9PT0gXCJ2aWRlb1wiKTtcbiAgICAgICAgaWYgKHNlbmRlcikgYXdhaXQgc2VuZGVyLnJlcGxhY2VUcmFjayhzY3JlZW5UcmFjayk7XG4gICAgICB9XG4gICAgICBzZXRTY3JlZW5TaGFyaW5nKHRydWUpO1xuICAgICAgdG9hc3Quc3VjY2VzcyhcIlNoYXJpbmcgc2NyZWVuIC8gcHJlc2VudGF0aW9uIGRlY2sgbGl2ZSFcIik7XG4gICAgICBzY3JlZW5UcmFjay5vbmVuZGVkID0gKCkgPT4ge1xuICAgICAgICBzZXRTY3JlZW5TaGFyaW5nKGZhbHNlKTtcbiAgICAgICAgaWYgKHN0cmVhbVJlZi5jdXJyZW50ICYmIHZpZGVvUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICB2aWRlb1JlZi5jdXJyZW50LnNyY09iamVjdCA9IHN0cmVhbVJlZi5jdXJyZW50O1xuICAgICAgICB9XG4gICAgICB9O1xuICAgIH0gY2F0Y2gge1xuICAgICAgdG9hc3QuaW5mbyhcIlNjcmVlbiBzaGFyaW5nIGNhbmNlbGxlZC5cIik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IHN0YXJ0QnJvYWRjYXN0ID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcIi9hcGkvYWdvcmEtdG9rZW5cIiwge1xuICAgICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgICBoZWFkZXJzOiB7IFwiY29udGVudC10eXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBjaGFubmVsTmFtZTogcm9vbUNoYW5uZWwgfHwgYHNvdC1saXZlLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICAgIHBhcnRuZXJJZDogYnJhbmROYW1lIHx8IFwiY29tbXVuaXR5XCIsXG4gICAgICAgICAgbW9kZTogc2Vzc2lvbk1vZGUgPT09IFwidm9pY2VfY2FsbFwiID8gXCJ2b2ljZVwiIDogc2Vzc2lvbk1vZGUgPT09IFwidmlkZW9fY2FsbFwiID8gXCJ2aWRlb1wiIDogXCJicm9hZGNhc3RcIixcbiAgICAgICAgfSksXG4gICAgICB9KTtcbiAgICAgIGNvbnN0IHRva2VuRGF0YSA9IChhd2FpdCByZXMuanNvbigpKSBhcyB7XG4gICAgICAgIHByb3ZpZGVyPzogXCJhZ29yYVwiIHwgXCJnb29nbGUtd2VicnRjXCI7XG4gICAgICAgIGFwcElkPzogc3RyaW5nIHwgbnVsbDtcbiAgICAgICAgY2hhbm5lbE5hbWU/OiBzdHJpbmc7XG4gICAgICAgIHRva2VuPzogc3RyaW5nIHwgbnVsbDtcbiAgICAgICAgdWlkPzogbnVtYmVyO1xuICAgICAgICBpY2VTZXJ2ZXJzPzogUlRDSWNlU2VydmVyW107XG4gICAgICB9O1xuXG4gICAgICBjb25zdCBjaGFubmVsID0gdG9rZW5EYXRhLmNoYW5uZWxOYW1lIHx8IHJvb21DaGFubmVsIHx8IFwic290LWxpdmUtcm9vbVwiO1xuICAgICAgc2V0Um9vbUNoYW5uZWwoY2hhbm5lbCk7XG5cbiAgICAgIGlmICh0b2tlbkRhdGEucHJvdmlkZXIgPT09IFwiYWdvcmFcIiAmJiB0b2tlbkRhdGEuYXBwSWQgJiYgdG9rZW5EYXRhLnRva2VuICYmIHRva2VuRGF0YS51aWQpIHtcbiAgICAgICAgc2V0RW5naW5lVXNlZChcIkFnb3JhIFJUQyArIEdvb2dsZSBTVFVOXCIpO1xuICAgICAgICBjb25zdCB7IGRlZmF1bHQ6IEFnb3JhUlRDIH0gPSBhd2FpdCBpbXBvcnQoXCJhZ29yYS1ydGMtc2RrLW5nXCIpO1xuICAgICAgICBjb25zdCBjbGllbnQgPSBBZ29yYVJUQy5jcmVhdGVDbGllbnQoeyBtb2RlOiBcInJ0Y1wiLCBjb2RlYzogXCJ2cDhcIiB9KTtcbiAgICAgICAgYWdvcmFDbGllbnRSZWYuY3VycmVudCA9IGNsaWVudDtcbiAgICAgICAgY2xpZW50Lm9uKFwidXNlci1wdWJsaXNoZWRcIiwgYXN5bmMgKHJlbW90ZVVzZXIsIG1lZGlhVHlwZSkgPT4ge1xuICAgICAgICAgIGF3YWl0IGNsaWVudC5zdWJzY3JpYmUocmVtb3RlVXNlciwgbWVkaWFUeXBlKTtcbiAgICAgICAgICBpZiAobWVkaWFUeXBlID09PSBcImF1ZGlvXCIpIHJlbW90ZVVzZXIuYXVkaW9UcmFjaz8ucGxheSgpO1xuICAgICAgICAgIGlmIChtZWRpYVR5cGUgPT09IFwidmlkZW9cIiAmJiByZW1vdGVWaWRlb1JlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICByZW1vdGVVc2VyLnZpZGVvVHJhY2s/LnBsYXkocmVtb3RlVmlkZW9SZWYuY3VycmVudCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHNldFBlZXJKb2luZWQodHJ1ZSk7XG4gICAgICAgICAgc2V0Vmlld2VyQ291bnQoKGMpID0+IGMgKyAxKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGF3YWl0IGNsaWVudC5qb2luKHRva2VuRGF0YS5hcHBJZCwgY2hhbm5lbCwgdG9rZW5EYXRhLnRva2VuLCB0b2tlbkRhdGEudWlkKTtcbiAgICAgICAgYWdvcmFBdWRpb1JlZi5jdXJyZW50ID0gYXdhaXQgQWdvcmFSVEMuY3JlYXRlTWljcm9waG9uZUF1ZGlvVHJhY2soKTtcbiAgICAgICAgYXdhaXQgY2xpZW50LnB1Ymxpc2goYWdvcmFBdWRpb1JlZi5jdXJyZW50KTtcbiAgICAgICAgaWYgKHNlc3Npb25Nb2RlICE9PSBcInZvaWNlX2NhbGxcIikge1xuICAgICAgICAgIGFnb3JhVmlkZW9SZWYuY3VycmVudCA9IGF3YWl0IEFnb3JhUlRDLmNyZWF0ZUNhbWVyYVZpZGVvVHJhY2soKTtcbiAgICAgICAgICBhd2FpdCBjbGllbnQucHVibGlzaChhZ29yYVZpZGVvUmVmLmN1cnJlbnQpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRFbmdpbmVVc2VkKFwiR29vZ2xlIFdlYlJUQyAoc3R1bi5sLmdvb2dsZS5jb20pXCIpO1xuICAgICAgICBjb25zdCBwYyA9IG5ldyBSVENQZWVyQ29ubmVjdGlvbih7XG4gICAgICAgICAgaWNlU2VydmVyczogdG9rZW5EYXRhLmljZVNlcnZlcnMgPz8gR09PR0xFX1NUVU5fU0VSVkVSUyxcbiAgICAgICAgfSk7XG4gICAgICAgIHBjUmVmLmN1cnJlbnQgPSBwYztcblxuICAgICAgICBpZiAoc3RyZWFtUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICBzdHJlYW1SZWYuY3VycmVudC5nZXRUcmFja3MoKS5mb3JFYWNoKCh0cmFjaykgPT4ge1xuICAgICAgICAgICAgaWYgKHN0cmVhbVJlZi5jdXJyZW50KSBwYy5hZGRUcmFjayh0cmFjaywgc3RyZWFtUmVmLmN1cnJlbnQpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgcGMub250cmFjayA9IChldikgPT4ge1xuICAgICAgICAgIGNvbnN0IFtyZW1vdGVTdHJlYW1dID0gZXYuc3RyZWFtcztcbiAgICAgICAgICBpZiAocmVtb3RlU3RyZWFtICYmIHJlbW90ZVZpZGVvUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIHJlbW90ZVZpZGVvUmVmLmN1cnJlbnQuc3JjT2JqZWN0ID0gcmVtb3RlU3RyZWFtO1xuICAgICAgICAgICAgc2V0UGVlckpvaW5lZCh0cnVlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgY29uc3QgZW1pdFNpZ25hbCA9IChwYXlsb2FkOiBSZWNvcmQ8c3RyaW5nLCBhbnk+KSA9PiB7XG4gICAgICAgICAgYmNSZWYuY3VycmVudD8ucG9zdE1lc3NhZ2UocGF5bG9hZCk7XG4gICAgICAgICAgdm9pZCBzdXBhQ2hhblJlZi5jdXJyZW50Py5zZW5kKHtcbiAgICAgICAgICAgIHR5cGU6IFwiYnJvYWRjYXN0XCIsXG4gICAgICAgICAgICBldmVudDogXCJzb3QtbGl2ZS1zaWduYWxcIixcbiAgICAgICAgICAgIHBheWxvYWQsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgcGMub25pY2VjYW5kaWRhdGUgPSAoZXYpID0+IHtcbiAgICAgICAgICBpZiAoZXYuY2FuZGlkYXRlKSB7XG4gICAgICAgICAgICBlbWl0U2lnbmFsKHsgdHlwZTogXCJjYW5kaWRhdGVcIiwgY2FuZGlkYXRlOiBldi5jYW5kaWRhdGUudG9KU09OKCkgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIGNvbnN0IGhhbmRsZVNpZ25hbCA9IGFzeW5jIChkYXRhOiBSZWNvcmQ8c3RyaW5nLCBhbnk+KSA9PiB7XG4gICAgICAgICAgaWYgKCFwY1JlZi5jdXJyZW50KSByZXR1cm47XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlmIChkYXRhLnR5cGUgPT09IFwiY2hhdFwiICYmIGRhdGEubWVzc2FnZSkge1xuICAgICAgICAgICAgICBzZXRDaGF0TWVzc2FnZXMoKHByZXYpID0+IFsuLi5wcmV2LCBkYXRhLm1lc3NhZ2VdKTtcbiAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGRhdGEudHlwZSA9PT0gXCJsaXZlLXZvdGVcIiAmJiAoZGF0YS52ZXJkaWN0ID09PSBcInN0YXNoXCIgfHwgZGF0YS52ZXJkaWN0ID09PSBcInRyYXNoXCIpKSB7XG4gICAgICAgICAgICAgIGlmIChkYXRhLnZlcmRpY3QgPT09IFwic3Rhc2hcIikgc2V0TGl2ZVN0YXNoVm90ZXMoKHYpID0+IHYgKyAxKTtcbiAgICAgICAgICAgICAgZWxzZSBzZXRMaXZlVHJhc2hWb3RlcygodikgPT4gdiArIDEpO1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoZGF0YS50eXBlID09PSBcImpvaW5cIikge1xuICAgICAgICAgICAgICBzZXRWaWV3ZXJDb3VudCgodikgPT4gdiArIDEpO1xuICAgICAgICAgICAgICBjb25zdCBvZmZlciA9IGF3YWl0IHBjUmVmLmN1cnJlbnQuY3JlYXRlT2ZmZXIoKTtcbiAgICAgICAgICAgICAgYXdhaXQgcGNSZWYuY3VycmVudC5zZXRMb2NhbERlc2NyaXB0aW9uKG9mZmVyKTtcbiAgICAgICAgICAgICAgZW1pdFNpZ25hbCh7IHR5cGU6IFwib2ZmZXJcIiwgc2RwOiBvZmZlciB9KTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoZGF0YS50eXBlID09PSBcIm9mZmVyXCIpIHtcbiAgICAgICAgICAgICAgYXdhaXQgcGNSZWYuY3VycmVudC5zZXRSZW1vdGVEZXNjcmlwdGlvbihuZXcgUlRDU2Vzc2lvbkRlc2NyaXB0aW9uKGRhdGEuc2RwKSk7XG4gICAgICAgICAgICAgIGNvbnN0IGFuc3dlciA9IGF3YWl0IHBjUmVmLmN1cnJlbnQuY3JlYXRlQW5zd2VyKCk7XG4gICAgICAgICAgICAgIGF3YWl0IHBjUmVmLmN1cnJlbnQuc2V0TG9jYWxEZXNjcmlwdGlvbihhbnN3ZXIpO1xuICAgICAgICAgICAgICBlbWl0U2lnbmFsKHsgdHlwZTogXCJhbnN3ZXJcIiwgc2RwOiBhbnN3ZXIgfSk7XG4gICAgICAgICAgICAgIHNldFBlZXJKb2luZWQodHJ1ZSk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGRhdGEudHlwZSA9PT0gXCJhbnN3ZXJcIiAmJiBwY1JlZi5jdXJyZW50LnNpZ25hbGluZ1N0YXRlID09PSBcImhhdmUtbG9jYWwtb2ZmZXJcIikge1xuICAgICAgICAgICAgICBhd2FpdCBwY1JlZi5jdXJyZW50LnNldFJlbW90ZURlc2NyaXB0aW9uKG5ldyBSVENTZXNzaW9uRGVzY3JpcHRpb24oZGF0YS5zZHApKTtcbiAgICAgICAgICAgICAgc2V0UGVlckpvaW5lZCh0cnVlKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoZGF0YS50eXBlID09PSBcImNhbmRpZGF0ZVwiICYmIGRhdGEuY2FuZGlkYXRlKSB7XG4gICAgICAgICAgICAgIGF3YWl0IHBjUmVmLmN1cnJlbnQuYWRkSWNlQ2FuZGlkYXRlKG5ldyBSVENJY2VDYW5kaWRhdGUoZGF0YS5jYW5kaWRhdGUpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgIC8vIGlnbm9yZSB0cmFuc2llbnQgc2lnbmFsaW5nIHN0YXRlc1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICBpZiAodHlwZW9mIEJyb2FkY2FzdENoYW5uZWwgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICBjb25zdCBiYyA9IG5ldyBCcm9hZGNhc3RDaGFubmVsKGBzb3QtbGl2ZS0ke2NoYW5uZWx9YCk7XG4gICAgICAgICAgYmMub25tZXNzYWdlID0gKGUpID0+IHZvaWQgaGFuZGxlU2lnbmFsKGUuZGF0YSk7XG4gICAgICAgICAgYmNSZWYuY3VycmVudCA9IGJjO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3Qgc3VwYUNoYW4gPSBzdXBhYmFzZVxuICAgICAgICAgIC5jaGFubmVsKGBzb3QtbGl2ZS0ke2NoYW5uZWx9YClcbiAgICAgICAgICAub24oXCJicm9hZGNhc3RcIiwgeyBldmVudDogXCJzb3QtbGl2ZS1zaWduYWxcIiB9LCAoeyBwYXlsb2FkIH0pID0+IHtcbiAgICAgICAgICAgIGlmIChwYXlsb2FkKSB2b2lkIGhhbmRsZVNpZ25hbChwYXlsb2FkIGFzIFJlY29yZDxzdHJpbmcsIGFueT4pO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLnN1YnNjcmliZSgoc3RhdHVzKSA9PiB7XG4gICAgICAgICAgICBpZiAoc3RhdHVzID09PSBcIlNVQlNDUklCRURcIikge1xuICAgICAgICAgICAgICBlbWl0U2lnbmFsKHsgdHlwZTogXCJqb2luXCIgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgIHN1cGFDaGFuUmVmLmN1cnJlbnQgPSBzdXBhQ2hhbjtcbiAgICAgICAgZW1pdFNpZ25hbCh7IHR5cGU6IFwiam9pblwiIH0pO1xuICAgICAgfVxuXG4gICAgICAvLyBQdWJsaXNoIHRvIHRoZSBIb21lICYgRmVlZCBMaXZlIEJyb2FkY2FzdCBTdGFnZSFcbiAgICAgIGNvbnN0IG5vdGlmaWVkRm9sbG93ZXJzID0gc3R1ZGlvUGVyc29uYSA9PT0gXCJicmFuZF9vd25lclwiID8gTWF0aC5mbG9vcig4NTAgKyBNYXRoLnJhbmRvbSgpICogMjQwMCkgOiAwO1xuICAgICAgc2V0Rm9sbG93ZXJzQWxlcnRlZENvdW50KG5vdGlmaWVkRm9sbG93ZXJzKTtcblxuICAgICAgY29uc3QgcHVibGlzaGVkID0gcHVibGlzaExpdmVCcm9hZGNhc3RTZXNzaW9uKHtcbiAgICAgICAgaWQ6IGFjdGl2ZUJyb2FkY2FzdElkIHx8IGN1cnJlbnRCcm9hZGNhc3RJZCxcbiAgICAgICAgcm9vbUNoYW5uZWw6IGNoYW5uZWwsXG4gICAgICAgIHBlcnNvbmE6IHN0dWRpb1BlcnNvbmEsXG4gICAgICAgIGJyYW5kTmFtZSxcbiAgICAgICAgYnJhbmRTbHVnOiBicmFuZFNsdWcgfHwgYnJhbmROYW1lLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvW15hLXowLTldKy9nLCBcIi1cIiksXG4gICAgICAgIGJyYW5kT3duZXIsXG4gICAgICAgIGhvc3ROYW1lOlxuICAgICAgICAgIHN0dWRpb1BlcnNvbmEgPT09IFwiYnJhbmRfb3duZXJcIlxuICAgICAgICAgICAgPyBgJHticmFuZE5hbWV9IE9mZmljaWFsIEJyb2FkY2FzdCBUZWFtYFxuICAgICAgICAgICAgOiB1c2VyPy5lbWFpbD8uc3BsaXQoXCJAXCIpWzBdIHx8IFwiVmVyaWZpZWQgU09UIE1lbWJlclwiLFxuICAgICAgICBob3N0Um9sZUxhYmVsOlxuICAgICAgICAgIHN0dWRpb1BlcnNvbmEgPT09IFwiYnJhbmRfb3duZXJcIlxuICAgICAgICAgICAgPyBcIlZlcmlmaWVkIEJyYW5kIE93bmVyIMK3IEV4ZWN1dGl2ZSBTdHVkaW9cIlxuICAgICAgICAgICAgOiBcIlZlcmlmaWVkIENvbnN1bWVyIMK3IExpdmUgU2l0dWF0aW9uIENhbVwiLFxuICAgICAgICB0aXRsZTogYnJvYWRjYXN0SGVhZGxpbmUudHJpbSgpIHx8IGAke2JyYW5kTmFtZX0gTGl2ZSBTZXNzaW9uYCxcbiAgICAgICAgc3VidGl0bGU6IGJyb2FkY2FzdFN1YnRpdGxlLnRyaW0oKSxcbiAgICAgICAgYnJhbmRDYXRlZ29yeTogc3R1ZGlvUGVyc29uYSA9PT0gXCJicmFuZF9vd25lclwiID8gYnJhbmRDYXRlZ29yeSA6IHVuZGVmaW5lZCxcbiAgICAgICAgY29uc3VtZXJDYXRlZ29yeTogc3R1ZGlvUGVyc29uYSA9PT0gXCJjb25zdW1lclwiID8gc2l0dWF0aW9uVHlwZSA6IHVuZGVmaW5lZCxcbiAgICAgICAgYmF0Y2hOdW1iZXI6IGJhdGNoTnVtYmVyLnRyaW0oKSB8fCB1bmRlZmluZWQsXG4gICAgICAgIHN0b3JlTG9jYXRpb246IHN0b3JlTG9jYXRpb24udHJpbSgpIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgdmlld2VyQ291bnQ6IE1hdGgubWF4KHZpZXdlckNvdW50LCBzdHVkaW9QZXJzb25hID09PSBcImJyYW5kX293bmVyXCIgPyA0OCA6IDEyKSxcbiAgICAgICAgc3Rhc2hWb3RlczogbGl2ZVN0YXNoVm90ZXMsXG4gICAgICAgIHRyYXNoVm90ZXM6IGxpdmVUcmFzaFZvdGVzLFxuICAgICAgICBmb2xsb3dlcnNOb3RpZmllZDogbm90aWZpZWRGb2xsb3dlcnMsXG4gICAgICAgIGxhdW5jaFBlcms6XG4gICAgICAgICAgc3R1ZGlvUGVyc29uYSA9PT0gXCJicmFuZF9vd25lclwiICYmIGVuYWJsZUxhdW5jaFBlcmsgJiYgcGVya1Byb21vQ29kZS50cmltKClcbiAgICAgICAgICAgID8ge1xuICAgICAgICAgICAgICAgIHRpdGxlOiBwZXJrVGl0bGUudHJpbSgpIHx8IGAke2JyYW5kTmFtZX0gTGF1bmNoIFZvdWNoZXJgLFxuICAgICAgICAgICAgICAgIHByb21vQ29kZTogcGVya1Byb21vQ29kZS50cmltKCkudG9VcHBlckNhc2UoKSxcbiAgICAgICAgICAgICAgICBkaXNjb3VudExhYmVsOiBwZXJrRGlzY291bnRMYWJlbC50cmltKCkgfHwgXCJMSVZFIExBVU5DSCBQRVJLXCIsXG4gICAgICAgICAgICAgICAgdG90YWxBdmFpbGFibGU6IHBlcmtUb3RhbEF2YWlsYWJsZSxcbiAgICAgICAgICAgICAgICBjbGFpbWVkQ291bnQ6IHBlcmtDbGFpbWVkQ291bnQsXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDogdW5kZWZpbmVkLFxuICAgICAgfSk7XG5cbiAgICAgIHNldEN1cnJlbnRCcm9hZGNhc3RJZChwdWJsaXNoZWQuaWQpO1xuICAgICAgc2V0Q29uc3VtZXJTZWNvbmRzTGVmdCg5MCk7XG4gICAgICBzZXRJc0xpdmUodHJ1ZSk7XG5cbiAgICAgIGlmIChzdHVkaW9QZXJzb25hID09PSBcImJyYW5kX293bmVyXCIpIHtcbiAgICAgICAgcmVjb3JkT3BlcmF0b3JSZXNvbHV0aW9uTWV0cmljKFxuICAgICAgICAgIFwibGF1bmNoX2Jyb2FkY2FzdFwiLFxuICAgICAgICAgIGBIb3N0ZWQgbGl2ZSBCcmFuZCBCcm9hZGNhc3QgXCIke2Jyb2FkY2FzdEhlYWRsaW5lLnRyaW0oKSB8fCBicmFuZE5hbWV9XCIgKCR7bm90aWZpZWRGb2xsb3dlcnMudG9Mb2NhbGVTdHJpbmcoKX0gZm9sbG93ZXJzIGFsZXJ0ZWQpLmAsXG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIGlmIChzZXNzaW9uTW9kZSAhPT0gXCJicm9hZGNhc3RcIikge1xuICAgICAgICBhd2FpdCByaW5nUmVjaXBpZW50T25QbGF0Zm9ybShjaGFubmVsKTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgaW5pdGlhbE1lc3NhZ2VzOiB7XG4gICAgICAgIHNlbmRlcjogc3RyaW5nO1xuICAgICAgICB0ZXh0OiBzdHJpbmc7XG4gICAgICAgIHRpbWU6IHN0cmluZztcbiAgICAgICAgaXNIb3N0PzogYm9vbGVhbjtcbiAgICAgICAgaXNQZXJrRHJvcD86IGJvb2xlYW47XG4gICAgICB9W10gPSBbXG4gICAgICAgIHtcbiAgICAgICAgICBzZW5kZXI6IFwiU09UIExpdmUgU3R1ZGlvXCIsXG4gICAgICAgICAgdGV4dDpcbiAgICAgICAgICAgIHN0dWRpb1BlcnNvbmEgPT09IFwiYnJhbmRfb3duZXJcIlxuICAgICAgICAgICAgICA/IGDwn5qAICR7YnJhbmROYW1lfSBpcyBub3cgTElWRSBvbiB0aGUgSG9tZSBGZWVkICYgQnJhbmQgU3RhZ2UhIEF1dG8tYWxlcnRlZCAke25vdGlmaWVkRm9sbG93ZXJzLnRvTG9jYWxlU3RyaW5nKCl9IGZvbGxvd2VycyAmIHByb3NwZWN0cy4gVmlld2VycyBjYW4gbm93IHZvdGUgU3Rhc2ggb3IgVHJhc2ggbGl2ZSBvbiB5b3VyIGxhdW5jaCFgXG4gICAgICAgICAgICAgIDogYPCfk7kgQ29uc3VtZXIgU2l0dWF0aW9uIFN0cmVhbSBpcyBub3cgTElWRSBvbiB0aGUgU09UIEZlZWQgdmlhICR7ZW5naW5lVXNlZH0uYCxcbiAgICAgICAgICB0aW1lOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZyhbXSwgeyBob3VyOiBcIjItZGlnaXRcIiwgbWludXRlOiBcIjItZGlnaXRcIiB9KSxcbiAgICAgICAgfSxcbiAgICAgIF07XG5cbiAgICAgIGlmIChzdHVkaW9QZXJzb25hID09PSBcImJyYW5kX293bmVyXCIgJiYgZW5hYmxlTGF1bmNoUGVyayAmJiBwZXJrUHJvbW9Db2RlLnRyaW0oKSkge1xuICAgICAgICBpbml0aWFsTWVzc2FnZXMucHVzaCh7XG4gICAgICAgICAgc2VuZGVyOiBgJHticmFuZE5hbWV9IChPZmZpY2lhbCBQZXJrIERyb3ApYCxcbiAgICAgICAgICB0ZXh0OiBg8J+OgSBMSVZFIExBVU5DSCBQRVJLIFVOTE9DS0VEOiBcIiR7cGVya1RpdGxlfVwiIOKAlCBVc2UgY29kZSAke3BlcmtQcm9tb0NvZGUudG9VcHBlckNhc2UoKX0gKCR7cGVya0Rpc2NvdW50TGFiZWx9KS4gQ2xpY2sgXCJDbGFpbSBMYXVuY2ggUGVya1wiIG9uIHNjcmVlbiB0byBzYXZlIHRvIHlvdXIgU09UIFdhbGxldCFgLFxuICAgICAgICAgIHRpbWU6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKFtdLCB7IGhvdXI6IFwiMi1kaWdpdFwiLCBtaW51dGU6IFwiMi1kaWdpdFwiIH0pLFxuICAgICAgICAgIGlzSG9zdDogdHJ1ZSxcbiAgICAgICAgICBpc1BlcmtEcm9wOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgc2V0Q2hhdE1lc3NhZ2VzKGluaXRpYWxNZXNzYWdlcyk7XG4gICAgICB0b2FzdC5zdWNjZXNzKFxuICAgICAgICBzdHVkaW9QZXJzb25hID09PSBcImJyYW5kX293bmVyXCJcbiAgICAgICAgICA/IGDwn5qAICR7YnJhbmROYW1lfSBMYXVuY2ggQnJvYWRjYXN0IGlzIExJVkUgb24gdGhlIEhvbWUgRmVlZCEgJHtub3RpZmllZEZvbGxvd2Vycy50b0xvY2FsZVN0cmluZygpfSBmb2xsb3dlcnMgbm90aWZpZWQuYFxuICAgICAgICAgIDogXCLwn5O5IExpdmUgU2l0dWF0aW9uIEJyb2FkY2FzdCBzdGFydGVkIG9uIHRoZSBTT1QgRmVlZCFcIixcbiAgICAgICk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0b2FzdC5lcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogXCJDb3VsZCBub3Qgc3RhcnQgbGl2ZSBzZXNzaW9uXCIpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBlbmRCcm9hZGNhc3QgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgY2xlYW51cFNlc3Npb24oKTtcbiAgICB0b2FzdC5pbmZvKFwiTGl2ZSBzZXNzaW9uIGVuZGVkLiBMYXVuY2ggcHVsc2UgbWV0cmljcyAmIGF1ZGl0IGxvZyBzYXZlZC5cIik7XG4gICAgb25PcGVuQ2hhbmdlKGZhbHNlKTtcbiAgfSwgW2NsZWFudXBTZXNzaW9uLCBvbk9wZW5DaGFuZ2VdKTtcblxuICAvLyBFbmZvcmNlIDkwLXNlY29uZCBtYXhpbXVtIGR1cmF0aW9uIG9uIG5vcm1hbCBDb25zdW1lciBTaXR1YXRpb24gQnJvYWRjYXN0c1xuICAvLyBzbyBCcmFuZCBPd25lcnMgY2Fubm90IHVzZSBmcmVlIHBlcnNvbmFsIHByb2ZpbGVzIGZvciBleHRlbmRlZCBjb21tZXJjaWFsIHByb2R1Y3QgbGF1bmNoZXMuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFpc0xpdmUgfHwgc3R1ZGlvUGVyc29uYSAhPT0gXCJjb25zdW1lclwiIHx8IHNlc3Npb25Nb2RlICE9PSBcImJyb2FkY2FzdFwiKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHRpbWVyID0gd2luZG93LnNldEludGVydmFsKCgpID0+IHtcbiAgICAgIHNldENvbnN1bWVyU2Vjb25kc0xlZnQoKHByZXYpID0+IHtcbiAgICAgICAgaWYgKHByZXYgPD0gMSkge1xuICAgICAgICAgIHdpbmRvdy5jbGVhckludGVydmFsKHRpbWVyKTtcbiAgICAgICAgICB0b2FzdC5pbmZvKFxuICAgICAgICAgICAgXCLij7HvuI8gOTAtU2Vjb25kIFBlcnNvbmFsIE1lbWJlciBTaXR1YXRpb24gQ2xpcCBjb21wbGV0ZWQhIEV4dGVuZGVkIDYwLW1pbisgY29tbWVyY2lhbCBsYXVuY2ggYnJvYWRjYXN0cyBhcmUgZXhjbHVzaXZlIHRvIE9mZmljaWFsIEJyYW5kIEFjY291bnRzLlwiLFxuICAgICAgICAgICk7XG4gICAgICAgICAgdm9pZCBlbmRCcm9hZGNhc3QoKTtcbiAgICAgICAgICByZXR1cm4gMDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcHJldiAtIDE7XG4gICAgICB9KTtcbiAgICB9LCAxMDAwKTtcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LmNsZWFySW50ZXJ2YWwodGltZXIpO1xuICB9LCBbaXNMaXZlLCBzdHVkaW9QZXJzb25hLCBzZXNzaW9uTW9kZSwgZW5kQnJvYWRjYXN0XSk7XG5cbiAgY29uc3Qgc2hhcmVSb29tTGluayA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBsaW5rID1cbiAgICAgIHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCJcbiAgICAgICAgPyBgJHt3aW5kb3cubG9jYXRpb24ub3JpZ2lufS9tZXNzYWdlcz90bz0ke2VuY29kZVVSSUNvbXBvbmVudChicmFuZE5hbWUpfSZyb29tPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHJvb21DaGFubmVsKX1gXG4gICAgICAgIDogcm9vbUNoYW5uZWw7XG4gICAgYXdhaXQgbmF2aWdhdG9yLmNsaXBib2FyZD8ud3JpdGVUZXh0KGxpbmspO1xuICAgIHRvYXN0LnN1Y2Nlc3MoXCJMaXZlIGJyb2FkY2FzdC9jYWxsIGxpbmsgY29waWVkISBTaGFyZSB3aXRoIGNsaWVudHMgb3IgcHJvc3BlY3RzLlwiKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVDYXN0TGl2ZVB1bHNlID0gKHZlcmRpY3Q6IFwic3Rhc2hcIiB8IFwidHJhc2hcIikgPT4ge1xuICAgIGlmICh2ZXJkaWN0ID09PSBcInN0YXNoXCIpIHtcbiAgICAgIHBsYXlDb2luU3BpblNvdW5kKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHBsYXlUcmFzaFNvdW5kKCk7XG4gICAgfVxuICAgIHNldE15TGl2ZVZlcmRpY3QodmVyZGljdCk7XG4gICAgY29uc3QgcmVzID0gdm90ZU9uTGl2ZUJyb2FkY2FzdChjdXJyZW50QnJvYWRjYXN0SWQsIHZlcmRpY3QpO1xuICAgIGlmIChyZXMuc2Vzc2lvbikge1xuICAgICAgc2V0TGl2ZVN0YXNoVm90ZXMocmVzLnNlc3Npb24uc3Rhc2hWb3Rlcyk7XG4gICAgICBzZXRMaXZlVHJhc2hWb3RlcyhyZXMuc2Vzc2lvbi50cmFzaFZvdGVzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKHZlcmRpY3QgPT09IFwic3Rhc2hcIikgc2V0TGl2ZVN0YXNoVm90ZXMoKHYpID0+IHYgKyAxKTtcbiAgICAgIGVsc2Ugc2V0TGl2ZVRyYXNoVm90ZXMoKHYpID0+IHYgKyAxKTtcbiAgICB9XG5cbiAgICBjb25zdCBwdWxzZU1zZyA9IHtcbiAgICAgIHNlbmRlcjogdXNlcj8uZW1haWw/LnNwbGl0KFwiQFwiKVswXSB8fCBcIkxpdmUgVmlld2VyXCIsXG4gICAgICB0ZXh0OlxuICAgICAgICB2ZXJkaWN0ID09PSBcInN0YXNoXCJcbiAgICAgICAgICA/IGDwn6qZIFZvdGVkIFNUQVNIIG9uICR7YnJhbmROYW1lfSdzIGxpdmUgc2hvd2Nhc2UhIExvdmluZyB0aGlzIGxhdW5jaCFgXG4gICAgICAgICAgOiBg8J+Xke+4jyBWb3RlZCBUUkFTSCBvbiAke2JyYW5kTmFtZX0ncyBsaXZlIHN0cmVhbSDigJQgbmVlZHMgaW1wcm92ZW1lbnQuYCxcbiAgICAgIHRpbWU6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKFtdLCB7IGhvdXI6IFwiMi1kaWdpdFwiLCBtaW51dGU6IFwiMi1kaWdpdFwiIH0pLFxuICAgIH07XG4gICAgc2V0Q2hhdE1lc3NhZ2VzKChwcmV2KSA9PiBbLi4ucHJldiwgcHVsc2VNc2ddKTtcbiAgICBiY1JlZi5jdXJyZW50Py5wb3N0TWVzc2FnZSh7IHR5cGU6IFwibGl2ZS12b3RlXCIsIHZlcmRpY3QgfSk7XG4gICAgYmNSZWYuY3VycmVudD8ucG9zdE1lc3NhZ2UoeyB0eXBlOiBcImNoYXRcIiwgbWVzc2FnZTogcHVsc2VNc2cgfSk7XG4gICAgdG9hc3Quc3VjY2VzcyhcbiAgICAgIHZlcmRpY3QgPT09IFwic3Rhc2hcIlxuICAgICAgICA/IGDwn6qZIFN0YXNoZWQhIFlvdXIgbGl2ZSB2ZXJkaWN0IGJvb3N0ZWQgJHticmFuZE5hbWV9J3MgTGF1bmNoIFB1bHNlLmBcbiAgICAgICAgOiBg8J+Xke+4jyBUcmFzaGVkISBZb3VyIGxpdmUgZmVlZGJhY2sgd2FzIHJlY29yZGVkIG9uICR7YnJhbmROYW1lfSdzIExhdW5jaCBQdWxzZS5gLFxuICAgICk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ2xhaW1QZXJrSW5TdHVkaW8gPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgcmVzID0gY2xhaW1MaXZlTGF1bmNoUGVyayhjdXJyZW50QnJvYWRjYXN0SWQpO1xuICAgIHNldEhhc0NsYWltZWRJblNlc3Npb24odHJ1ZSk7XG4gICAgc2V0UGVya0NsYWltZWRDb3VudCgoYykgPT4gTWF0aC5taW4ocGVya1RvdGFsQXZhaWxhYmxlLCBjICsgKHJlcy5hbHJlYWR5Q2xhaW1lZCA/IDAgOiAxKSkpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkPy53cml0ZVRleHQocGVya1Byb21vQ29kZS50b1VwcGVyQ2FzZSgpKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGlnbm9yZVxuICAgIH1cbiAgICB0b2FzdC5zdWNjZXNzKFxuICAgICAgYPCfjoEgQ2xhaW1lZCBcIiR7cGVya1RpdGxlfVwiICgke3BlcmtQcm9tb0NvZGUudG9VcHBlckNhc2UoKX0pISBTYXZlZCB0byB5b3VyIENvbnN1bWVyIFByb2ZpbGUgV2FsbGV0ICYgY29waWVkIHRvIGNsaXBib2FyZC5gLFxuICAgICk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRHJvcFBlcmtBbm5vdW5jZW1lbnQgPSAoKSA9PiB7XG4gICAgY29uc3QgZHJvcE1zZyA9IHtcbiAgICAgIHNlbmRlcjogYCR7YnJhbmROYW1lfSAoSG9zdCBQZXJrIERyb3ApYCxcbiAgICAgIHRleHQ6IGDwn46BIEZMQVNIIExBVU5DSCBEUk9QOiBDbGFpbSBcIiR7cGVya1RpdGxlfVwiIHdpdGggY29kZSAke3BlcmtQcm9tb0NvZGUudG9VcHBlckNhc2UoKX0gKCR7cGVya1RvdGFsQXZhaWxhYmxlIC0gcGVya0NsYWltZWRDb3VudH0gdm91Y2hlcnMgbGVmdCkhYCxcbiAgICAgIHRpbWU6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKFtdLCB7IGhvdXI6IFwiMi1kaWdpdFwiLCBtaW51dGU6IFwiMi1kaWdpdFwiIH0pLFxuICAgICAgaXNIb3N0OiB0cnVlLFxuICAgICAgaXNQZXJrRHJvcDogdHJ1ZSxcbiAgICB9O1xuICAgIHNldENoYXRNZXNzYWdlcygocHJldikgPT4gWy4uLnByZXYsIGRyb3BNc2ddKTtcbiAgICBiY1JlZi5jdXJyZW50Py5wb3N0TWVzc2FnZSh7IHR5cGU6IFwiY2hhdFwiLCBtZXNzYWdlOiBkcm9wTXNnIH0pO1xuICAgIHRvYXN0LnN1Y2Nlc3MoXCJEcm9wcGVkIGxpdmUgbGF1bmNoIHZvdWNoZXIgaW50byB0aGUgYnJvYWRjYXN0IHN0cmVhbSAmIGNoYXQhXCIpO1xuICB9O1xuXG4gIGNvbnN0IHNlbmRDaGF0TWVzc2FnZSA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFjaGF0SW5wdXQudHJpbSgpKSByZXR1cm47XG4gICAgY29uc3QgbXNnID0ge1xuICAgICAgc2VuZGVyOiBzdHVkaW9QZXJzb25hID09PSBcImJyYW5kX293bmVyXCIgPyBgJHticmFuZE5hbWV9IChPZmZpY2lhbCBIb3N0KWAgOiBcIllvdSAoSG9zdClcIixcbiAgICAgIHRleHQ6IGNoYXRJbnB1dC50cmltKCksXG4gICAgICB0aW1lOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZyhbXSwgeyBob3VyOiBcIjItZGlnaXRcIiwgbWludXRlOiBcIjItZGlnaXRcIiB9KSxcbiAgICAgIGlzSG9zdDogdHJ1ZSxcbiAgICB9O1xuICAgIHNldENoYXRNZXNzYWdlcygocHJldikgPT4gWy4uLnByZXYsIG1zZ10pO1xuICAgIGJjUmVmLmN1cnJlbnQ/LnBvc3RNZXNzYWdlKHsgdHlwZTogXCJjaGF0XCIsIG1lc3NhZ2U6IHsgLi4ubXNnLCBpc0hvc3Q6IGZhbHNlIH0gfSk7XG4gICAgdm9pZCBzdXBhQ2hhblJlZi5jdXJyZW50Py5zZW5kKHtcbiAgICAgIHR5cGU6IFwiYnJvYWRjYXN0XCIsXG4gICAgICBldmVudDogXCJzb3QtbGl2ZS1zaWduYWxcIixcbiAgICAgIHBheWxvYWQ6IHsgdHlwZTogXCJjaGF0XCIsIG1lc3NhZ2U6IHsgLi4ubXNnLCBpc0hvc3Q6IGZhbHNlIH0gfSxcbiAgICB9KTtcbiAgICBzZXRDaGF0SW5wdXQoXCJcIik7XG4gIH07XG5cbiAgY29uc3QgdG90YWxMaXZlVm90ZXMgPSBNYXRoLm1heCgxLCBsaXZlU3Rhc2hWb3RlcyArIGxpdmVUcmFzaFZvdGVzKTtcbiAgY29uc3QgbGl2ZVN0YXNoUGN0ID0gTWF0aC5yb3VuZCgobGl2ZVN0YXNoVm90ZXMgLyB0b3RhbExpdmVWb3RlcykgKiAxMDApO1xuICBjb25zdCBhY3RpdmVCcmFuZENhdE9iaiA9IEJSQU5EX0JST0FEQ0FTVF9DQVRFR09SSUVTLmZpbmQoKGMpID0+IGMuaWQgPT09IGJyYW5kQ2F0ZWdvcnkpO1xuXG4gIHJldHVybiAoXG4gICAgPERpYWxvZyBvcGVuPXtvcGVufSBvbk9wZW5DaGFuZ2U9e29uT3BlbkNoYW5nZX0+XG4gICAgICA8RGlhbG9nQ29udGVudCBjbGFzc05hbWU9XCJtYXgtdy01eGwgbWF4LWgtWzk0dmhdIG92ZXJmbG93LXktYXV0byBwLTAgZ2FwLTAgYm9yZGVyLWJvcmRlci84MFwiPlxuICAgICAgICA8RGlhbG9nSGVhZGVyIGNsYXNzTmFtZT1cInAtNCBib3JkZXItYiBib3JkZXItYm9yZGVyLzYwIGJnLW11dGVkLzIwXCI+XG4gICAgICAgICAgey8qIERldmVsb3Blci1Pbmx5IFN0dWRpbyBNb2RlIFN3aXRjaGVyOiBIaWRkZW4gZnJvbSByZWd1bGFyIFBlcnNvbmFsIFVzZXJzICYgQnJhbmQgT3duZXJzICovfVxuICAgICAgICAgIHtpc0RldmVsb3BlciAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZGFzaGVkIGJvcmRlci1bI2Q2YTkyOF0vNjAgYmctYmFja2dyb3VuZCBwLTEuNVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyBmb250LWJvbGQgcHgtMlwiPlxuICAgICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSB0ZXh0LVsjZDZhOTI4XVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+8J+boO+4jyBERVYgU3R1ZGlvIE1vZGUgU3dpdGNoZXI6PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0U3R1ZGlvUGVyc29uYShcImJyYW5kX293bmVyXCIpO1xuICAgICAgICAgICAgICAgICAgICBzZXRTZXNzaW9uTW9kZShcImJyb2FkY2FzdFwiKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHJvdW5kZWQtbGcgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LWV4dHJhYm9sZCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgIHN0dWRpb1BlcnNvbmEgPT09IFwiYnJhbmRfb3duZXJcIlxuICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1zbGF0ZS05NTAgdGV4dC1bI2Q2YTkyOF0gc2hhZG93LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGhvdmVyOnRleHQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8Um9ja2V0IGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgIERFVjogQnJhbmQgTGF1bmNoIFN0dWRpbyAoQjJCKVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3R1ZGlvUGVyc29uYShcImNvbnN1bWVyXCIpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLWxnIHB4LTMgcHktMS41IHRleHQteHMgZm9udC1leHRyYWJvbGQgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICBzdHVkaW9QZXJzb25hID09PSBcImNvbnN1bWVyXCJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctcm9zZS02MDAgdGV4dC13aGl0ZSBzaGFkb3cteHNcIlxuICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LW11dGVkLWZvcmVncm91bmQgaG92ZXI6dGV4dC1mb3JlZ3JvdW5kXCJcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxWaWRlbyBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICBERVY6IENvbnN1bWVyIFNpdHVhdGlvbiBDYW0gKFVzZXIpXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGgtMTAgdy0xMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCAke1xuICAgICAgICAgICAgICAgICAgc3R1ZGlvUGVyc29uYSA9PT0gXCJicmFuZF9vd25lclwiXG4gICAgICAgICAgICAgICAgICAgID8gXCJiZy1zbGF0ZS05NTAgdGV4dC1bI2Q2YTkyOF0gYm9yZGVyIGJvcmRlci1bI2Q2YTkyOF0vNTBcIlxuICAgICAgICAgICAgICAgICAgICA6IFwiYmctcmVkLTUwMC8xMCB0ZXh0LXJlZC02MDBcIlxuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3N0dWRpb1BlcnNvbmEgPT09IFwiYnJhbmRfb3duZXJcIiA/IChcbiAgICAgICAgICAgICAgICAgIDxSb2NrZXQgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxSYWRpbyBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8RGlhbG9nVGl0bGUgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWRpc3BsYXkgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICB7c3R1ZGlvUGVyc29uYSA9PT0gXCJicmFuZF9vd25lclwiXG4gICAgICAgICAgICAgICAgICAgID8gYCR7YnJhbmROYW1lfSDigJQgT2ZmaWNpYWwgQnJhbmQgTGF1bmNoICYgQ2xpZW50IEVuZ2FnZW1lbnQgU3R1ZGlvYFxuICAgICAgICAgICAgICAgICAgICA6IFwiTGl2ZSBWb2ljZSwgVmlkZW8gJiBDb25zdW1lciBTaXR1YXRpb24gU3R1ZGlvXCJ9XG4gICAgICAgICAgICAgICAgICB7aXNMaXZlID8gKFxuICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cImRlc3RydWN0aXZlXCIgY2xhc3NOYW1lPVwiYW5pbWF0ZS1wdWxzZSB0ZXh0LVsxMHB4XSBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxDaXJjbGVEb3QgY2xhc3NOYW1lPVwiaC0yLjUgdy0yLjVcIiAvPiBMSVZFIE9OIEhPTUUgJmFtcDsgRkVFRFxuICAgICAgICAgICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCIgY2xhc3NOYW1lPVwidGV4dC1bMTBweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZW5naW5lVXNlZH1cbiAgICAgICAgICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9EaWFsb2dUaXRsZT5cbiAgICAgICAgICAgICAgICA8RGlhbG9nRGVzY3JpcHRpb24gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmQgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkhvc3Q6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWZvcmVncm91bmRcIj57YnJhbmROYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPsK3PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1hbWJlci02MDAgZGFyazp0ZXh0LWFtYmVyLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8QnVpbGRpbmcyIGNsYXNzTmFtZT1cImgtMyB3LTNcIiAvPiB7YnJhbmRPd25lcn1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtzdHVkaW9QZXJzb25hID09PSBcImJyYW5kX293bmVyXCIgPyAoXG4gICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+wrc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIPCfkaQgRGVzayBPcGVyYXRvcjoge2FjdGl2ZURlc2tPcGVyYXRvci5uYW1lfSAoe2FjdGl2ZURlc2tPcGVyYXRvci5yb2xlVGl0bGV9KVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPsK3PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS02MDAgZm9udC1ib2xkIHRhYnVsYXItbnVtc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAg4o+x77iPIEZyZWUgTWVtYmVyIFNpdHVhdGlvbiBDbGlwIENhcDoge2lzTGl2ZSA/IGAke2NvbnN1bWVyU2Vjb25kc0xlZnR9cyBsZWZ0YCA6IFwiOTBzIE1heFwifSAoRXh0ZW5kZWQgTGF1bmNoZXMgPSBCcmFuZCBQbGFuKVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAge2ZvbGxvd2Vyc0FsZXJ0ZWRDb3VudCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPsK3PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC02MDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICDwn5SUIHtmb2xsb3dlcnNBbGVydGVkQ291bnQudG9Mb2NhbGVTdHJpbmcoKX0gRm9sbG93ZXJzIEFsZXJ0ZWRcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L0RpYWxvZ0Rlc2NyaXB0aW9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICB7aXNMaXZlICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIGJnLWJhY2tncm91bmQvODAgcHgtMi41IHB5LTEgcm91bmRlZC1tZCBib3JkZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxFeWUgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgdGV4dC1lbWVyYWxkLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0YWJ1bGFyLW51bXNcIj57dmlld2VyQ291bnR9IHdhdGNoaW5nIGxpdmU8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHJpbmdSZWNpcGllbnRPblBsYXRmb3JtKHJvb21DaGFubmVsIHx8IFwic290LWxpdmUtcm9vbVwiKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggZ2FwLTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCBib3JkZXItZW1lcmFsZC01MDAvNDAgdGV4dC1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTUwMC8xMFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8QmVsbFJpbmcgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICAgIHtyaW5naW5nU2VudCA/IFwiUmluZyBTZW50IChSaW5nIEFnYWluKVwiIDogYFJpbmcgJHt0YXJnZXRSZWNpcGllbnROYW1lIHx8IFwiQ2xpZW50XCJ9IG9uIFNPVGB9XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBzaGFyZVJvb21MaW5rKCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IGdhcC0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxTaGFyZTIgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPiBTaGFyZSBTdHJlYW0gTGlua1xuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEJSQU5EIE9XTkVSIExBVU5DSCAmIFJFTEFVTkNIIENPTkZJR1VSQVRJT04gQkFSICovfVxuICAgICAgICAgIHtzdHVkaW9QZXJzb25hID09PSBcImJyYW5kX293bmVyXCIgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgcm91bmRlZC0yeGwgYm9yZGVyLTIgYm9yZGVyLVsjZDZhOTI4XS81MCBiZy1zbGF0ZS05NTAgcC0zLjUgdGV4dC13aGl0ZSBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LVsxMXB4XSBmb250LWV4dHJhYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1bI2Y1ZDA2MV1cIj5cbiAgICAgICAgICAgICAgICAgIDxSb2NrZXQgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgdGV4dC1bI2Q2YTkyOF1cIiAvPlxuICAgICAgICAgICAgICAgICAgQnJhbmQgQnJvYWRjYXN0IFB1cnBvc2UgKExhdW5jaGVzLCBSZWxhdW5jaGVzLCBUb3VycyAmYW1wOyBUb3duaGFsbHMpXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICBTdHJlYW1zIGxpdmUgdG8gdGhlIEhvbWUgUGFnZSwgQnJhbmQgUGFnZSAmYW1wOyBhbGVydHMgYWxsIGZvbGxvd2Vyc1xuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIDUgQnJhbmQgQnJvYWRjYXN0IENhdGVnb3JpZXMgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIHtCUkFORF9CUk9BRENBU1RfQ0FURUdPUklFUy5tYXAoKGNhdCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBrZXk9e2NhdC5pZH1cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUNhdGVnb3J5UHJlc2V0Q2hhbmdlKGNhdC5pZCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJvdW5kZWQtbGcgYm9yZGVyIHB4LTIuNSBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgIGJyYW5kQ2F0ZWdvcnkgPT09IGNhdC5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci1bI2Q2YTkyOF0gYmctWyNkNmE5MjhdIHRleHQtc2xhdGUtOTUwIHNoYWRvdy14c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLXNsYXRlLTgwMCBiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCBob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtjYXQuc2hvcnRCYWRnZX1cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogSGVhZGxpbmUgJiBMaXZlIFZvdWNoZXIgQnVpbGRlciAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0yLjUgc206Z3JpZC1jb2xzLTEyXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi01XCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItMSBibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIExhdW5jaCAvIEJyb2FkY2FzdCBIZWFkbGluZVxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YnJvYWRjYXN0SGVhZGxpbmV9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QnJvYWRjYXN0SGVhZGxpbmUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gTElWRSBMQVVOQ0g6IE5ldyBQZXJpLUhvbmV5IEZsYW1lIFJldmVhbFwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOCBib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTkwMCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi00XCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItMSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTBweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj7wn46BIExpdmUgVmlld2VyIFBlcmsgLyBWb3VjaGVyIFRpdGxlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2VuYWJsZUxhdW5jaFBlcmt9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbmFibGVMYXVuY2hQZXJrKGUudGFyZ2V0LmNoZWNrZWQpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMyB3LTMgYWNjZW50LVsjZDZhOTI4XVwiXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJFbmFibGUgY2xhaW1hYmxlIGxhdW5jaCB2b3VjaGVyIG9uIHNjcmVlblwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwZXJrVGl0bGV9XG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshZW5hYmxlTGF1bmNoUGVya31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQZXJrVGl0bGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gMjUlIE9mZiBOZXcgTGF1bmNoIE1lYWxcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggYm9yZGVyLXNsYXRlLTcwMCBiZy1zbGF0ZS05MDAgdGV4dC14cyB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0zXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItMSBibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIFByb21vIENvZGVcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BlcmtQcm9tb0NvZGV9XG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFlbmFibGVMYXVuY2hQZXJrfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGVya1Byb21vQ29kZShlLnRhcmdldC52YWx1ZS50b1VwcGVyQ2FzZSgpKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNPVF9MQVVOQ0gyNVwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IGJvcmRlci1zbGF0ZS03MDAgYmctc2xhdGUtOTAwIGZvbnQtbW9ubyB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LVsjZjVkMDYxXVwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIHtpc0xpdmUgJiYgZW5hYmxlTGF1bmNoUGVyayAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRHJvcFBlcmtBbm5vdW5jZW1lbnR9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggc2hyaW5rLTAgYmctWyNkNmE5MjhdIHB4LTIgdGV4dC1bMTFweF0gZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05NTAgaG92ZXI6YmctWyNlNWI5MzVdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRHJvcCB2b3VjaGVyIGludG8gbGl2ZSBjaGF0IG5vd1wiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgRHJvcFxuICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIC8qIERpcmVjdCBVc2VyLXRvLVVzZXIgJiBCcmFuZC10by1Vc2VyIERpYWxlciBCYXIgKi9cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItWyNkNmE5MjhdLzQwIGJnLVsjZDZhOTI4XS81IHAtMi41IHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtWzExcHhdIGZvbnQtZXh0cmFib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgIDxVc2VyQ2hlY2sgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgdGV4dC1bI2Q2YTkyOF1cIiAvPlxuICAgICAgICAgICAgICAgICAgRGlyZWN0IFBsYXRmb3JtIENhbGxpbmcgKE5vIFBob25lIE51bWJlciBOZWVkZWQg4oCUIFJpbmdzIFVzZXIgSW4tQXBwICsgU09UIEluYm94KVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHJvdW5kZWQtbGcgYmctYmFja2dyb3VuZC84MCBwLTAuNSBib3JkZXIgYm9yZGVyLWJvcmRlci82MFwiPlxuICAgICAgICAgICAgICAgICAgeyhcbiAgICAgICAgICAgICAgICAgICAgW1xuICAgICAgICAgICAgICAgICAgICAgIFtcImJyYW5kX3RvX3VzZXJcIiwgXCJCcmFuZCDihpIgVXNlciAoUmVhY2ggQ2xpZW50KVwiXSxcbiAgICAgICAgICAgICAgICAgICAgICBbXCJ1c2VyX3RvX3VzZXJcIiwgXCJVc2VyIOKGkiBVc2VyIChQZWVyIENhbGwpXCJdLFxuICAgICAgICAgICAgICAgICAgICAgIFtcInVzZXJfdG9fYnJhbmRcIiwgXCJVc2VyIOKGkiBCcmFuZFwiXSxcbiAgICAgICAgICAgICAgICAgICAgXSBhcyBjb25zdFxuICAgICAgICAgICAgICAgICAgKS5tYXAoKFtkaXJLZXksIGRpckxhYmVsXSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtkaXJLZXl9XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q2FsbERpcmVjdGlvbihkaXJLZXkpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJvdW5kZWQtbWQgcHgtMiBweS0wLjUgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRyYW5zaXRpb24gJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbGxEaXJlY3Rpb24gPT09IGRpcktleVxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctc2xhdGUtOTUwIHRleHQtWyNkNmE5MjhdXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtbXV0ZWQtZm9yZWdyb3VuZCBob3Zlcjp0ZXh0LWZvcmVncm91bmRcIlxuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge2RpckxhYmVsfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTIgc206Z3JpZC1jb2xzLTJcIj5cbiAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dGFyZ2V0UmVjaXBpZW50SWR9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY2hvc2VuID0gcGxhdGZvcm1Db250YWN0cy5maW5kKChjKSA9PiBjLmlkID09PSBlLnRhcmdldC52YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIHNldFRhcmdldFJlY2lwaWVudElkKGUudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNob3Nlbikgc2V0VGFyZ2V0UmVjaXBpZW50TmFtZShjaG9zZW4ubmFtZSk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctYmFja2dyb3VuZCBweC0yLjUgdGV4dC14cyBmb250LXNlbWlib2xkIG91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBTT1QgVXNlciAvIENsaWVudCBmcm9tIHJlY2VudCBwb3N0cy4uLjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAge3BsYXRmb3JtQ29udGFjdHMubWFwKChjKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtjLmlkfSB2YWx1ZT17Yy5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAge2MubmFtZX0g4oCUICh7Yy5jb250ZXh0fSlcbiAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L3NlbGVjdD5cblxuICAgICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3RhcmdldFJlY2lwaWVudE5hbWV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRhcmdldFJlY2lwaWVudE5hbWUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJPciB0eXBlIFVzZXIgLyBDbGllbnQgbmFtZSBvciBoYW5kbGUgdG8gY2FsbC4uLlwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggdGV4dC14cyBiZy1iYWNrZ3JvdW5kXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogTW9kZSAmIEJhdGNoL0xvY2F0aW9uIE1ldGFkYXRhIEJhciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZ3JpZCBnYXAtMiBwdC0zIGJvcmRlci10IGJvcmRlci1ib3JkZXIvNjAgc206Z3JpZC1jb2xzLTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcm91bmRlZC1sZyBiZy1zZWNvbmRhcnkvNjAgcC0xXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZXNzaW9uTW9kZShcImJyb2FkY2FzdFwiKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4LTEgcm91bmRlZC1tZCBweC0yIHB5LTEgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRyYW5zaXRpb24tY29sb3JzICR7XG4gICAgICAgICAgICAgICAgICBzZXNzaW9uTW9kZSA9PT0gXCJicm9hZGNhc3RcIlxuICAgICAgICAgICAgICAgICAgICA/IFwiYmctYmFja2dyb3VuZCB0ZXh0LWZvcmVncm91bmQgc2hhZG93LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtbXV0ZWQtZm9yZWdyb3VuZCBob3Zlcjp0ZXh0LWZvcmVncm91bmRcIlxuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgTGl2ZSBCcm9hZGNhc3RcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZXNzaW9uTW9kZShcInZpZGVvX2NhbGxcIil9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleC0xIHJvdW5kZWQtbWQgcHgtMiBweS0xIHRleHQtWzExcHhdIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICAgICAgc2Vzc2lvbk1vZGUgPT09IFwidmlkZW9fY2FsbFwiXG4gICAgICAgICAgICAgICAgICAgID8gXCJiZy1iYWNrZ3JvdW5kIHRleHQtZm9yZWdyb3VuZCBzaGFkb3cteHNcIlxuICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGhvdmVyOnRleHQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBWaWRlbyBDYWxsXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2Vzc2lvbk1vZGUoXCJ2b2ljZV9jYWxsXCIpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSByb3VuZGVkLW1kIHB4LTIgcHktMSB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgICAgIHNlc3Npb25Nb2RlID09PSBcInZvaWNlX2NhbGxcIlxuICAgICAgICAgICAgICAgICAgICA/IFwiYmctYmFja2dyb3VuZCB0ZXh0LWZvcmVncm91bmQgc2hhZG93LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtbXV0ZWQtZm9yZWdyb3VuZCBob3Zlcjp0ZXh0LWZvcmVncm91bmRcIlxuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgVm9pY2UgQ2FsbFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgIDxIYXNoIGNsYXNzTmFtZT1cInBvaW50ZXItZXZlbnRzLW5vbmUgYWJzb2x1dGUgbGVmdC0yLjUgdG9wLTEvMiBoLTMuNSB3LTMuNSAtdHJhbnNsYXRlLXktMS8yIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiIC8+XG4gICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgIHZhbHVlPXtiYXRjaE51bWJlcn1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJhdGNoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17XG4gICAgICAgICAgICAgICAgICBzdHVkaW9QZXJzb25hID09PSBcImJyYW5kX293bmVyXCJcbiAgICAgICAgICAgICAgICAgICAgPyBcIlNLVSAvIEVkaXRpb24gLyBCYXRjaCBDb2RlIChPcHRpb25hbClcIlxuICAgICAgICAgICAgICAgICAgICA6IFwiQmF0Y2ggLyBMb3QgIyBvciBCYXJjb2RlIChPcHRpb25hbClcIlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggcGwtOCB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgIDxNYXBQaW4gY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSBsZWZ0LTIuNSB0b3AtMS8yIGgtMy41IHctMy41IC10cmFuc2xhdGUteS0xLzIgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgLz5cbiAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgdmFsdWU9e3N0b3JlTG9jYXRpb259XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdG9yZUxvY2F0aW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17XG4gICAgICAgICAgICAgICAgICBzdHVkaW9QZXJzb25hID09PSBcImJyYW5kX293bmVyXCJcbiAgICAgICAgICAgICAgICAgICAgPyBcIkxhdW5jaCBWZW51ZSAvIEZsYWdzaGlwIFN0b3JlIC8gSFFcIlxuICAgICAgICAgICAgICAgICAgICA6IFwiU3RvcmUgLyBCcmFuY2ggLyBTcGF6YSBMb2NhdGlvblwiXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOCBwbC04IHRleHQteHNcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvRGlhbG9nSGVhZGVyPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtMFwiPlxuICAgICAgICAgIHsvKiBNYWluIFZpZGVvIC8gVm9pY2UgVmlld3BvcnQgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDpjb2wtc3Bhbi0yIHJlbGF0aXZlIGJnLXNsYXRlLTk1MCBhc3BlY3QtdmlkZW8gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICB7c2Vzc2lvbk1vZGUgPT09IFwidm9pY2VfY2FsbFwiID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0zIHAtNiB0ZXh0LWNlbnRlciB0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtMjAgdy0yMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJvcmRlci0yIGJvcmRlci1lbWVyYWxkLTQwMC81MCBiZy1lbWVyYWxkLTUwMC8xMCB0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICA8UGhvbmUgY2xhc3NOYW1lPXtgaC05IHctOSAke2lzTGl2ZSA/IFwiYW5pbWF0ZS1ib3VuY2VcIiA6IFwiXCJ9YH0gLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtbGcgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgIHtpc0xpdmUgPyBcIkxpdmUgVm9pY2UgQ2FsbCAmIEF1ZGlvIFN0cmVhbVwiIDogXCJWb2ljZSBDYWxsIFJlYWR5XCJ9XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgUm9vbTogPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtc2xhdGUtMjAwXCI+e3Jvb21DaGFubmVsfTwvc3Bhbj4gwrcge2VuZ2luZVVzZWR9XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BncmlkIGgtZnVsbCB3LWZ1bGwgJHtwZWVySm9pbmVkID8gXCJncmlkLWNvbHMtMlwiIDogXCJncmlkLWNvbHMtMVwifWB9PlxuICAgICAgICAgICAgICAgIDx2aWRlb1xuICAgICAgICAgICAgICAgICAgcmVmPXt2aWRlb1JlZn1cbiAgICAgICAgICAgICAgICAgIGF1dG9QbGF5XG4gICAgICAgICAgICAgICAgICBwbGF5c0lubGluZVxuICAgICAgICAgICAgICAgICAgbXV0ZWRcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyICR7IWNhbWVyYU9uICYmICFzY3JlZW5TaGFyaW5nID8gXCJoaWRkZW5cIiA6IFwiXCJ9YH1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIHtwZWVySm9pbmVkICYmIChcbiAgICAgICAgICAgICAgICAgIDx2aWRlb1xuICAgICAgICAgICAgICAgICAgICByZWY9e3JlbW90ZVZpZGVvUmVmfVxuICAgICAgICAgICAgICAgICAgICBhdXRvUGxheVxuICAgICAgICAgICAgICAgICAgICBwbGF5c0lubGluZVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlciBib3JkZXItbCBib3JkZXItd2hpdGUvMTBcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIHshY2FtZXJhT24gJiYgIXNjcmVlblNoYXJpbmcgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXNsYXRlLTQwMCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8VmlkZW9PZmYgY2xhc3NOYW1lPVwiaC0xMCB3LTEwIG9wYWNpdHktNjBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+Q2FtZXJhIGlzIHR1cm5lZCBvZmYgKEF1ZGlvIGFjdGl2ZSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBUb3AtTGVmdCBMaXZlIE92ZXJsYXkgSFVEICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMyBsZWZ0LTMgcmlnaHQtMyBmbGV4IGZsZXgtY29sIGdhcC0xLjUgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsYWNrLzc1IGJhY2tkcm9wLWJsdXItbWQgcHgtMyBweS0xLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXdoaXRlLzE1IHRleHQtd2hpdGUgdGV4dC14cyBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWF4LXcteGxcIj5cbiAgICAgICAgICAgICAgICAgIHtzdHVkaW9QZXJzb25hID09PSBcImJyYW5kX293bmVyXCIgJiYgYWN0aXZlQnJhbmRDYXRPYmogPyAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYmctWyNkNmE5MjhdIHB4LTIgcHktMC41IHRleHQtWzEwcHhdIGZvbnQtYmxhY2sgdGV4dC1zbGF0ZS05NTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7YWN0aXZlQnJhbmRDYXRPYmouc2hvcnRCYWRnZX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicm91bmRlZC1tZCBiZy1yb3NlLTYwMCBweC0yIHB5LTAuNSB0ZXh0LVsxMHB4XSBmb250LWJsYWNrIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICDwn5O5IENPTlNVTUVSIENBTVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGRcIj57YnJhbmROYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm9wYWNpdHktODUgdHJ1bmNhdGUgbWF4LXctWzI2MHB4XVwiPnticm9hZGNhc3RIZWFkbGluZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7YmF0Y2hOdW1iZXIgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyb3VuZGVkIGJnLWFtYmVyLTUwMC8yMCBweC0xLjUgcHktMC41IGZvbnQtbW9ubyB0ZXh0LVsxMHB4XSB0ZXh0LWFtYmVyLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICN7YmF0Y2hOdW1iZXJ9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICB7c3RvcmVMb2NhdGlvbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtMzAwXCI+8J+TjSB7c3RvcmVMb2NhdGlvbn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIExpdmUgTGF1bmNoIFBlcmsgT3ZlcmxheSBDYXJkIChDbGFpbWFibGUgYnkgdmlld2VycyBpbiAxIGNsaWNrISkgKi99XG4gICAgICAgICAgICAgICAge3N0dWRpb1BlcnNvbmEgPT09IFwiYnJhbmRfb3duZXJcIiAmJiBlbmFibGVMYXVuY2hQZXJrICYmIHBlcmtQcm9tb0NvZGUgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1hdXRvIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1bI2Q2YTkyOF0gYmctc2xhdGUtOTUwLzkwIHB4LTMgcHktMS41IHRleHQteHMgdGV4dC13aGl0ZSBzaGFkb3ctbGcgYmFja2Ryb3AtYmx1ci1tZFwiPlxuICAgICAgICAgICAgICAgICAgICA8R2lmdCBjbGFzc05hbWU9XCJoLTQgdy00IHNocmluay0wIHRleHQtWyNkNmE5MjhdXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZWFkaW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1leHRyYWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtWyNmNWQwNjFdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7cGVya0Rpc2NvdW50TGFiZWx9IMK3IHtwZXJrVG90YWxBdmFpbGFibGUgLSBwZXJrQ2xhaW1lZENvdW50fSBsZWZ0XG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRleHQtWzExcHhdXCI+e3BlcmtUaXRsZX08L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIGhhbmRsZUNsYWltUGVya0luU3R1ZGlvKCl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC03IGJnLVsjZDZhOTI4XSBweC0yLjUgdGV4dC1bMTBweF0gZm9udC1ibGFjayB0ZXh0LXNsYXRlLTk1MCBob3ZlcjpiZy1bI2U1YjkzNV1cIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge2hhc0NsYWltZWRJblNlc3Npb24gPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwibXItMSBoLTMgdy0zXCIgLz4ge3BlcmtQcm9tb0NvZGV9XG4gICAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJDbGFpbSBQZXJrXCJcbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBDb25zdW1lciBTaXR1YXRpb24gQ2F0ZWdvcnkgUGlsbHMgd2hlbiBpbiBDb25zdW1lciBNb2RlICovfVxuICAgICAgICAgICAgICB7c3R1ZGlvUGVyc29uYSA9PT0gXCJjb25zdW1lclwiICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0xLjUgcG9pbnRlci1ldmVudHMtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAge0NPTlNVTUVSX0JST0FEQ0FTVF9DQVRFR09SSUVTLm1hcCgoY2F0KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2NhdC5pZH1cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaXR1YXRpb25UeXBlKGNhdC5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcm91bmRlZCBweC0yIHB5LTAuNSB0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24gJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpdHVhdGlvblR5cGUgPT09IGNhdC5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctWyNkNmE5MjhdIHRleHQtc2xhdGUtOTUwIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ibGFjay82MCB0ZXh0LXdoaXRlLzgwIGhvdmVyOmJnLWJsYWNrLzgwXCJcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHtjYXQubGFiZWx9XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAge3NjYW5SZXN1bHQgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZW1lcmFsZC05NTAvODAgYmFja2Ryb3AtYmx1ci1tZCBweC0yIHB5LTAuNSByb3VuZGVkIHRleHQtWzEwcHhdIHRleHQtZW1lcmFsZC0zMDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB3LWZpdFwiPlxuICAgICAgICAgICAgICAgICAgPFNoaWVsZENoZWNrIGNsYXNzTmFtZT1cImgtMyB3LTMgdGV4dC1lbWVyYWxkLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICBWZXJpZmllZCBFdmlkZW5jZSAoe3NjYW5SZXN1bHQuYXV0aGVudGljaXR5LnNjb3JlfSUgQXV0aGVudGljaXR5KVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBMSVZFIFNUQVNIIE9SIFRSQVNIIExBVU5DSCBQVUxTRSBIVUQgKEJvdHRvbS1MZWZ0IGFib3ZlIGNvbnRyb2xzKSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTE0IGxlZnQtMyByaWdodC0zIGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXdoaXRlLzE1IGJnLWJsYWNrLzc1IHB4LTMgcHktMiB0ZXh0LXdoaXRlIGJhY2tkcm9wLWJsdXItbWRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy1bMTgwcHhdIGZsZXgtMVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtWzEwcHhdIGZvbnQtZXh0cmFib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bI2Y1ZDA2MV1cIj5cbiAgICAgICAgICAgICAgICAgICAg8J+qmSB7bGl2ZVN0YXNoUGN0fSUgU3Rhc2ggKHtsaXZlU3Rhc2hWb3Rlc30pXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICBMaXZlIHtzdHVkaW9QZXJzb25hID09PSBcImJyYW5kX293bmVyXCIgPyBcIkxhdW5jaCBSZWNlcHRpb24gUHVsc2VcIiA6IFwiQ29tbXVuaXR5IFZlcmRpY3RcIn1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAg8J+Xke+4jyB7MTAwIC0gbGl2ZVN0YXNoUGN0fSUgVHJhc2ggKHtsaXZlVHJhc2hWb3Rlc30pXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIGZsZXggaC0yIHctZnVsbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1mdWxsIGJnLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tYW1iZXItNDAwIHRvLVsjZDZhOTI4XSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDBcIlxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7bGl2ZVN0YXNoUGN0fSVgIH19XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1yb3NlLTYwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDBcIlxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7MTAwIC0gbGl2ZVN0YXNoUGN0fSVgIH19XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDYXN0TGl2ZVB1bHNlKFwic3Rhc2hcIil9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BoLTcgZ2FwLTEgcHgtMi41IHRleHQtWzExcHhdIGZvbnQtYmxhY2sgJHtcbiAgICAgICAgICAgICAgICAgICAgbXlMaXZlVmVyZGljdCA9PT0gXCJzdGFzaFwiXG4gICAgICAgICAgICAgICAgICAgICAgPyBcImJnLVsjZDZhOTI4XSB0ZXh0LXNsYXRlLTk1MCByaW5nLTIgcmluZy13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgOiBcImJnLVsjZDZhOTI4XS85MCB0ZXh0LXNsYXRlLTk1MCBob3ZlcjpiZy1bI2Q2YTkyOF1cIlxuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPENvaW5zIGNsYXNzTmFtZT1cImgtMyB3LTNcIiAvPiBTdGFzaCBMYXVuY2hcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwiZGVzdHJ1Y3RpdmVcIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ2FzdExpdmVQdWxzZShcInRyYXNoXCIpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaC03IGdhcC0xIHB4LTIuNSB0ZXh0LVsxMXB4XSBmb250LWJsYWNrICR7XG4gICAgICAgICAgICAgICAgICAgIG15TGl2ZVZlcmRpY3QgPT09IFwidHJhc2hcIiA/IFwicmluZy0yIHJpbmctd2hpdGVcIiA6IFwiXCJcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxSZWN5Y2xlIGNsYXNzTmFtZT1cImgtMyB3LTNcIiAvPiBUcmFzaFxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQm90dG9tIEluLUJyb2FkY2FzdCBDb250cm9scyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTIuNSBsZWZ0LTAgcmlnaHQtMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICB7c2Vzc2lvbk1vZGUgIT09IFwidm9pY2VfY2FsbFwiICYmIChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImljb25cIlxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PXtjYW1lcmFPbiA/IFwic2Vjb25kYXJ5XCIgOiBcImRlc3RydWN0aXZlXCJ9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOSB3LTkgcm91bmRlZC1mdWxsIHNoYWRvdy1sZ1wiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZUNhbWVyYX1cbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJUb2dnbGUgQ2FtZXJhXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2NhbWVyYU9uID8gPFZpZGVvIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPiA6IDxWaWRlb09mZiBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz59XG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJpY29uXCJcbiAgICAgICAgICAgICAgICAgICAgdmFyaWFudD17c2NyZWVuU2hhcmluZyA/IFwiZGVmYXVsdFwiIDogXCJzZWNvbmRhcnlcIn1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC05IHctOSByb3VuZGVkLWZ1bGwgc2hhZG93LWxnXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCB0b2dnbGVTY3JlZW5TaGFyZSgpfVxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlNoYXJlIFNjcmVlbiwgUHJvZHVjdCBTbGlkZXMgb3IgUmVjZWlwdCBFdmlkZW5jZVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxNb25pdG9yVXAgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIHNpemU9XCJpY29uXCJcbiAgICAgICAgICAgICAgICB2YXJpYW50PXttaWNPbiA/IFwic2Vjb25kYXJ5XCIgOiBcImRlc3RydWN0aXZlXCJ9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC05IHctOSByb3VuZGVkLWZ1bGwgc2hhZG93LWxnXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVNaWN9XG4gICAgICAgICAgICAgICAgdGl0bGU9XCJUb2dnbGUgTWljcm9waG9uZVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7bWljT24gPyA8TWljIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPiA6IDxNaWNPZmYgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+fVxuICAgICAgICAgICAgICA8L0J1dHRvbj5cblxuICAgICAgICAgICAgICB7IWlzTGl2ZSA/IChcbiAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHN0YXJ0QnJvYWRjYXN0KCl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e1xuICAgICAgICAgICAgICAgICAgICBzdHVkaW9QZXJzb25hID09PSBcImJyYW5kX293bmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctWyNkNmE5MjhdIGhvdmVyOmJnLVsjZTViOTM1XSB0ZXh0LXNsYXRlLTk1MCBmb250LWJsYWNrIGdhcC0xLjUgcHgtNSBzaGFkb3cteGwgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctcmVkLTYwMCBob3ZlcjpiZy1yZWQtNzAwIHRleHQtd2hpdGUgZm9udC1ib2xkIGdhcC0xLjUgcHgtNCBzaGFkb3cteGwgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7c3R1ZGlvUGVyc29uYSA9PT0gXCJicmFuZF9vd25lclwiID8gKFxuICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgIDxSb2NrZXQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgR28gTGl2ZSAmYW1wOyBBbGVydCBGb2xsb3dlcnNcbiAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgIDxSYWRpbyBjbGFzc05hbWU9XCJoLTQgdy00IGFuaW1hdGUtcHVsc2VcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIHtzZXNzaW9uTW9kZSA9PT0gXCJ2b2ljZV9jYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJTdGFydCBWb2ljZSBDYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogc2Vzc2lvbk1vZGUgPT09IFwidmlkZW9fY2FsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJTdGFydCBWaWRlbyBDYWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIkdvIExpdmUgTm93XCJ9XG4gICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwiZGVzdHJ1Y3RpdmVcIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBlbmRCcm9hZGNhc3QoKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtYm9sZCBweC00IHNoYWRvdy14bCByb3VuZGVkLWZ1bGxcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIEVuZCBTZXNzaW9uXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBTaWRlIExpdmUgQ2hhdCAmIEVuZ2FnZW1lbnQgRmVlZCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1sIGJvcmRlci1ib3JkZXIgZmxleCBmbGV4LWNvbCBoLTgwIG1kOmgtYXV0byBiZy1tdXRlZC8xMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYm9yZGVyLWIgYm9yZGVyLWJvcmRlci82MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1mb3JlZ3JvdW5kIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgIDxNZXNzYWdlU3F1YXJlIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHRleHQtWyNkNmE5MjhdXCIgLz5cbiAgICAgICAgICAgICAgICB7c3R1ZGlvUGVyc29uYSA9PT0gXCJicmFuZF9vd25lclwiID8gXCJMaXZlIExhdW5jaCBRJkEgJiBQZXJrc1wiIDogXCJMaXZlIFNpdHVhdGlvbiBDaGF0XCJ9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1tb25vIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntyb29tQ2hhbm5lbH08L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcC0zIG92ZXJmbG93LXktYXV0byBzcGFjZS15LTIgdGV4dC14c1wiPlxuICAgICAgICAgICAgICB7Y2hhdE1lc3NhZ2VzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBweS04IHRleHQteHMgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICB7c3R1ZGlvUGVyc29uYSA9PT0gXCJicmFuZF9vd25lclwiID8gKFxuICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgIDxVc2VycyBjbGFzc05hbWU9XCJoLTYgdy02IG14LWF1dG8gdGV4dC1bI2Q2YTkyOF1cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBSZWFkeSB0byBicm9hZGNhc3QgeW91ciB7YWN0aXZlQnJhbmRDYXRPYmo/LmxhYmVsLnRvTG93ZXJDYXNlKCl9IVxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIENsaWNrIDxzdHJvbmc+R28gTGl2ZSAmYW1wOyBBbGVydCBGb2xsb3dlcnM8L3N0cm9uZz4gdG8gc3RyZWFtIHRvIHRoZSBIb21lIEZlZWQsIGNvbGxlY3QgbGl2ZSBTdGFzaC9UcmFzaCB2b3RlcywgYW5kIGRyb3AgeW91ciBsYXVuY2ggcHJvbW8gY29kZS5cbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJoLTUgdy01IG14LWF1dG8gdGV4dC1hbWJlci01MDAvODBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxwPlxuICAgICAgICAgICAgICAgICAgICAgICAge2lzTGl2ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiTm8gY29tbWVudHMgeWV0LiBTaGFyZSB5b3VyIHJvb20gbGluayB0byBpbnZpdGUgcGVlcnMgb3IgYnJhbmQgcmVwcyFcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiU3RhcnQgeW91ciB2b2ljZSBjYWxsLCB2aWRlbyBjYWxsLCBvciBzaXR1YXRpb24gYnJvYWRjYXN0IHRvIG9wZW4gbGl2ZSBjaGF0LlwifVxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIGNoYXRNZXNzYWdlcy5tYXAoKG0sIGkpID0+IChcbiAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJzcGFjZS15LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMHB4XSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZm9udC1ib2xkICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG0uaXNQZXJrRHJvcFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJ0ZXh0LVsjYjg4OTE0XVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBtLmlzSG9zdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcInRleHQtcHJpbWFyeVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1mb3JlZ3JvdW5kXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHttLnNlbmRlcn1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e20udGltZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8cFxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLWxnIGJvcmRlciB0ZXh0LVsxMXB4XSBsZWFkaW5nLXJlbGF4ZWQgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG0uaXNQZXJrRHJvcFxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLVsjZDZhOTI4XSBiZy1bI2Q2YTkyOF0vMTUgZm9udC1ib2xkIHRleHQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJib3JkZXItYm9yZGVyLzUwIGJnLWJhY2tncm91bmQvODAgdGV4dC1mb3JlZ3JvdW5kXCJcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHttLnRleHR9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpXG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e3NlbmRDaGF0TWVzc2FnZX0gY2xhc3NOYW1lPVwicC0yIGJvcmRlci10IGJvcmRlci1ib3JkZXIvNjAgZmxleCBnYXAtMS41IGJnLWJhY2tncm91bmRcIj5cbiAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e1xuICAgICAgICAgICAgICAgICAgaXNMaXZlXG4gICAgICAgICAgICAgICAgICAgID8gc3R1ZGlvUGVyc29uYSA9PT0gXCJicmFuZF9vd25lclwiXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlJlcGx5IHRvIGNsaWVudHMgJiBwcm9zcGVjdHMgbGl2ZS4uLlwiXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIlR5cGUgbGl2ZSBzaXR1YXRpb24gbm90ZS4uLlwiXG4gICAgICAgICAgICAgICAgICAgIDogXCJTdGFydCBzZXNzaW9uIHRvIGNoYXQuLi5cIlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWlzTGl2ZX1cbiAgICAgICAgICAgICAgICB2YWx1ZT17Y2hhdElucHV0fVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2hhdElucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggdGV4dC14c1wiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIHNpemU9XCJzbVwiIGRpc2FibGVkPXshaXNMaXZlIHx8ICFjaGF0SW5wdXQudHJpbSgpfSBjbGFzc05hbWU9XCJoLTggcHgtMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgU2VuZFxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPERpYWxvZ0Zvb3RlciBjbGFzc05hbWU9XCJwLTMgYm9yZGVyLXQgYm9yZGVyLWJvcmRlci82MCBiZy1tdXRlZC8xMCBzbTpqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgdGV4dC1bI2Q2YTkyOF1cIiAvPlxuICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgIFBvd2VyZWQgYnkgR29vZ2xlIFdlYlJUQyAoPGNvZGU+c3R1bi5sLmdvb2dsZS5jb208L2NvZGU+KSAmYW1wOyBBZ29yYSBSVEMgwrd7XCIgXCJ9XG4gICAgICAgICAgICAgIDxzdHJvbmc+XG4gICAgICAgICAgICAgICAge3N0dWRpb1BlcnNvbmEgPT09IFwiYnJhbmRfb3duZXJcIlxuICAgICAgICAgICAgICAgICAgPyBcIkV4ZWN1dGl2ZSBCcmFuZCBMYXVuY2ggJiBFbmdhZ2VtZW50IEJyb2FkY2FzdFwiXG4gICAgICAgICAgICAgICAgICA6IFwiQ29uc3VtZXIgTGl2ZSBTaXR1YXRpb24gU3R1ZGlvXCJ9XG4gICAgICAgICAgICAgIDwvc3Ryb25nPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4gb25PcGVuQ2hhbmdlKGZhbHNlKX0+XG4gICAgICAgICAgICBDbG9zZSBTdHVkaW9cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9EaWFsb2dGb290ZXI+XG4gICAgICA8L0RpYWxvZ0NvbnRlbnQ+XG4gICAgPC9EaWFsb2c+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9hcHAvYXBwbGV0L3NyYy9jb21wb25lbnRzL0xpdmVCcm9hZGNhc3RNb2RhbC50c3gifQ==