import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SotWordmark.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "/app/applet/src/components/SotWordmark.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
/**
* The SOT brand wordmark. The capitals S · O · T are always emphasised so the
* eye reads the acronym "SOT" out of "Stash Or Trash" — building instant brand
* recall. Never render these letters in lowercase.
*/
export function SotWordmark({ className, size = "md" }) {
	const sizeClass = size === "lg" ? "text-lg" : size === "sm" ? "text-sm" : "text-base";
	return /* @__PURE__ */ _jsxDEV("span", {
		translate: "no",
		"aria-label": "Stash Or Trash",
		className: cn("notranslate inline-flex items-baseline whitespace-nowrap font-display font-extrabold tracking-tight text-foreground", sizeClass, className),
		"data-tsd-source": "/src/components/SotWordmark.tsx:18:5",
		children: [
			/* @__PURE__ */ _jsxDEV("span", {
				className: "text-stash",
				"data-tsd-source": "/src/components/SotWordmark.tsx:27:7",
				children: "S"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("span", {
				"data-tsd-source": "/src/components/SotWordmark.tsx:28:7",
				children: "tash\xA0"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("span", {
				className: "text-foreground",
				"data-tsd-source": "/src/components/SotWordmark.tsx:29:7",
				children: "O"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("span", {
				"data-tsd-source": "/src/components/SotWordmark.tsx:30:7",
				children: "r\xA0"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("span", {
				className: "text-trash",
				"data-tsd-source": "/src/components/SotWordmark.tsx:31:7",
				children: "T"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("span", {
				"data-tsd-source": "/src/components/SotWordmark.tsx:32:7",
				children: "rash"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 5
	}, this);
}
_c = SotWordmark;
var _c;
$RefreshReg$(_c, "SotWordmark");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SotWordmark.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/SotWordmark.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/SotWordmark.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/SotWordmark.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7O0FBT0EsOEJBQ0EsV0FDQSxlQUlBO0NBQ0E7Q0FFQSxPQUNBO0VBQ0E7RUFDQTtFQUNBLGNBQ0EsdUhBQ0EsV0FDQSxTQUNBO0VBQ0E7WUFSQTtHQVNBO0lBQUE7SUFBQTtjQUFrQztHQUFBOzs7OztHQUNsQztJQUFBO2NBQVc7R0FBQTs7Ozs7R0FDWDtJQUFBO0lBQUE7Y0FBdUM7R0FBQTs7Ozs7R0FDdkM7SUFBQTtjQUFXO0dBQUE7Ozs7O0dBQ1g7SUFBQTtJQUFBO2NBQWtDO0dBQUE7Ozs7O0dBQ2xDO0lBQUE7Y0FBVztHQUFBOzs7OztFQUNYOzs7Ozs7QUFFQSIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU290V29yZG1hcmsudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5cbi8qKlxuICogVGhlIFNPVCBicmFuZCB3b3JkbWFyay4gVGhlIGNhcGl0YWxzIFMgwrcgTyDCtyBUIGFyZSBhbHdheXMgZW1waGFzaXNlZCBzbyB0aGVcbiAqIGV5ZSByZWFkcyB0aGUgYWNyb255bSBcIlNPVFwiIG91dCBvZiBcIlN0YXNoIE9yIFRyYXNoXCIg4oCUIGJ1aWxkaW5nIGluc3RhbnQgYnJhbmRcbiAqIHJlY2FsbC4gTmV2ZXIgcmVuZGVyIHRoZXNlIGxldHRlcnMgaW4gbG93ZXJjYXNlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gU290V29yZG1hcmsoe1xuICBjbGFzc05hbWUsXG4gIHNpemUgPSBcIm1kXCIsXG59OiB7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgc2l6ZT86IFwic21cIiB8IFwibWRcIiB8IFwibGdcIjtcbn0pIHtcbiAgY29uc3Qgc2l6ZUNsYXNzID0gc2l6ZSA9PT0gXCJsZ1wiID8gXCJ0ZXh0LWxnXCIgOiBzaXplID09PSBcInNtXCIgPyBcInRleHQtc21cIiA6IFwidGV4dC1iYXNlXCI7XG5cbiAgcmV0dXJuIChcbiAgICA8c3BhblxuICAgICAgdHJhbnNsYXRlPVwibm9cIlxuICAgICAgYXJpYS1sYWJlbD1cIlN0YXNoIE9yIFRyYXNoXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwibm90cmFuc2xhdGUgaW5saW5lLWZsZXggaXRlbXMtYmFzZWxpbmUgd2hpdGVzcGFjZS1ub3dyYXAgZm9udC1kaXNwbGF5IGZvbnQtZXh0cmFib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtZm9yZWdyb3VuZFwiLFxuICAgICAgICBzaXplQ2xhc3MsXG4gICAgICAgIGNsYXNzTmFtZSxcbiAgICAgICl9XG4gICAgPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zdGFzaFwiPlM8L3NwYW4+XG4gICAgICA8c3Bhbj50YXNoJm5ic3A7PC9zcGFuPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1mb3JlZ3JvdW5kXCI+Tzwvc3Bhbj5cbiAgICAgIDxzcGFuPnImbmJzcDs8L3NwYW4+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXRyYXNoXCI+VDwvc3Bhbj5cbiAgICAgIDxzcGFuPnJhc2g8L3NwYW4+XG4gICAgPC9zcGFuPlxuICApO1xufVxuIl0sImZpbGUiOiIvYXBwL2FwcGxldC9zcmMvY29tcG9uZW50cy9Tb3RXb3JkbWFyay50c3gifQ==