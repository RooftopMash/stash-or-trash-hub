const jsQR = __vite__cjsImport0_jsqr;import __vite__cjsImport0_jsqr from "/node_modules/.vite/deps/jsqr.js?v=a8030269";
const ZXING_FORMAT_NAMES = {
	0: "aztec",
	1: "codabar",
	2: "code_39",
	3: "code_93",
	4: "code_128",
	5: "data_matrix",
	6: "ean_8",
	7: "ean_13",
	8: "itf",
	10: "pdf_417",
	11: "qr_code",
	14: "upc_a",
	15: "upc_e"
};
// Cache ZXing reader configured with retail 1D + 2D formats (loaded client-side only)
let cachedZxingReader = null;
async function getZxingReader() {
	if (typeof window === "undefined") return null;
	if (!cachedZxingReader) {
		try {
			const mod = await import("/node_modules/.vite/deps/@zxing_library.js?v=a8030269");
			cachedZxingReader = new mod.BrowserMultiFormatReader();
		} catch {}
	}
	return cachedZxingReader;
}
/**
* Optimizes an image File into a reasonably sized JPEG Base64 string for fast AI inference.
*/
export async function fileToOptimizedBase64(file, maxDim = 1280) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = (e) => {
			const img = new Image();
			img.onload = async () => {
				let w = img.width;
				let h = img.height;
				if (w > maxDim || h > maxDim) {
					const ratio = Math.min(maxDim / w, maxDim / h);
					w = Math.round(w * ratio);
					h = Math.round(h * ratio);
				}
				const canvas = document.createElement("canvas");
				canvas.width = w;
				canvas.height = h;
				const ctx = canvas.getContext("2d", { willReadFrequently: true });
				if (!ctx) {
					reject(new Error("Failed to get 2D canvas context"));
					return;
				}
				ctx.drawImage(img, 0, 0, w, h);
				const dataUrl = canvas.toDataURL("image/jpeg", .88);
				const base64 = dataUrl.split(",")[1];
				// Attempt ZXing Barcode + QR decode
				let qrData = null;
				let barcodeData = null;
				try {
					const zx = await getZxingReader();
					if (zx) {
						const zxRes = zx.decodeFromCanvas(canvas);
						if (zxRes && zxRes.getText()) {
							const text = zxRes.getText();
							const fmt = zxRes.getBarcodeFormat();
							const fmtName = typeof fmt === "number" && ZXING_FORMAT_NAMES[fmt] ? ZXING_FORMAT_NAMES[fmt] : "";
							if (fmtName.includes("qr")) {
								qrData = text;
							} else {
								barcodeData = text;
							}
						}
					}
				} catch {}
				if (!qrData && !barcodeData) {
					try {
						const imageData = ctx.getImageData(0, 0, w, h);
						const qr = jsQR(imageData.data, w, h, { inversionAttempts: "attemptBoth" });
						if (qr?.data) qrData = qr.data;
					} catch {}
				}
				resolve({
					dataUrl,
					base64,
					mimeType: "image/jpeg",
					qrData,
					barcodeData
				});
			};
			img.onerror = () => reject(new Error("Unable to decode image file"));
			img.src = e.target?.result;
		};
		reader.onerror = () => reject(new Error("Unable to read file"));
		reader.readAsDataURL(file);
	});
}
/**
* Extracts a representative frame from an uploaded video file (e.g. mp4, mov, webm).
*/
export async function extractFrameFromVideo(videoFile) {
	return new Promise((resolve, reject) => {
		const video = document.createElement("video");
		video.preload = "auto";
		video.muted = true;
		video.playsInline = true;
		const url = URL.createObjectURL(videoFile);
		video.src = url;
		const cleanup = () => URL.revokeObjectURL(url);
		video.onloadedmetadata = () => {
			// Seek to 1s or 25% of duration
			video.currentTime = Math.min(1, video.duration > 0 ? video.duration / 4 : .5);
		};
		video.onseeked = async () => {
			try {
				const maxDim = 1280;
				let w = video.videoWidth || 640;
				let h = video.videoHeight || 480;
				if (w > maxDim || h > maxDim) {
					const ratio = Math.min(maxDim / w, maxDim / h);
					w = Math.round(w * ratio);
					h = Math.round(h * ratio);
				}
				const canvas = document.createElement("canvas");
				canvas.width = w;
				canvas.height = h;
				const ctx = canvas.getContext("2d", { willReadFrequently: true });
				if (!ctx) throw new Error("Could not create canvas context");
				ctx.drawImage(video, 0, 0, w, h);
				const dataUrl = canvas.toDataURL("image/jpeg", .88);
				const base64 = dataUrl.split(",")[1];
				let qrData = null;
				let barcodeData = null;
				try {
					const zx = await getZxingReader();
					if (zx) {
						const zxRes = zx.decodeFromCanvas(canvas);
						if (zxRes && zxRes.getText()) {
							const text = zxRes.getText();
							const fmt = zxRes.getBarcodeFormat();
							const fmtName = typeof fmt === "number" && ZXING_FORMAT_NAMES[fmt] ? ZXING_FORMAT_NAMES[fmt] : "";
							if (fmtName.includes("qr")) {
								qrData = text;
							} else {
								barcodeData = text;
							}
						}
					}
				} catch {}
				if (!qrData && !barcodeData) {
					try {
						const imgData = ctx.getImageData(0, 0, w, h);
						const qr = jsQR(imgData.data, w, h, { inversionAttempts: "attemptBoth" });
						if (qr?.data) qrData = qr.data;
					} catch {}
				}
				cleanup();
				resolve({
					dataUrl,
					base64,
					mimeType: "image/jpeg",
					qrData,
					barcodeData
				});
			} catch (err) {
				cleanup();
				reject(err);
			}
		};
		video.onerror = () => {
			cleanup();
			reject(new Error("Unable to process video frame"));
		};
	});
}
// Reusable offline canvas for video frame extraction
let processingCanvas = null;
let croppedCanvas = null;
/**
* Scans a canvas element for QR codes in real-time (e.g. from camera feed).
*/
export function scanQrFromCanvas(canvas) {
	try {
		const ctx = canvas.getContext("2d", { willReadFrequently: true });
		if (!ctx) return null;
		const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
		const code = jsQR(imgData.data, canvas.width, canvas.height, { inversionAttempts: "attemptBoth" });
		return code?.data ?? null;
	} catch {
		return null;
	}
}
/**
* Scans a canvas or image source for Barcodes (UPC-A, EAN-13, Code-128, etc.) and QR codes.
* Uses native BarcodeDetector when available, with deep fallback to ZXing multi-format reader and jsQR.
*/
export async function detectBarcodeOrQr(source) {
	// 1. Try native BarcodeDetector if available
	if (typeof window !== "undefined" && "BarcodeDetector" in window) {
		try {
			// @ts-expect-error BarcodeDetector browser experimental API
			const detector = new window.BarcodeDetector({ formats: [
				"qr_code",
				"ean_13",
				"ean_8",
				"upc_a",
				"upc_e",
				"code_128",
				"code_39",
				"code_93",
				"itf",
				"data_matrix"
			] });
			const barcodes = await detector.detect(source);
			if (barcodes && barcodes.length > 0 && barcodes[0].rawValue) {
				return {
					format: barcodes[0].format || "barcode",
					rawValue: barcodes[0].rawValue
				};
			}
		} catch {}
	}
	// 2. Fallback to ZXing MultiFormat Reader (handles 1D barcodes like Coca Cola UPC-A/EAN-13 everywhere)
	try {
		const reader = await getZxingReader();
		if (reader) {
			let targetCanvas = null;
			if (source instanceof HTMLCanvasElement) {
				targetCanvas = source;
			} else if (source instanceof HTMLVideoElement && source.videoWidth > 0 && source.videoHeight > 0) {
				if (!processingCanvas) {
					processingCanvas = document.createElement("canvas");
				}
				processingCanvas.width = source.videoWidth;
				processingCanvas.height = source.videoHeight;
				const pCtx = processingCanvas.getContext("2d", { willReadFrequently: true });
				if (pCtx) {
					pCtx.drawImage(source, 0, 0, source.videoWidth, source.videoHeight);
					targetCanvas = processingCanvas;
				}
			}
			if (targetCanvas) {
				// Attempt full frame scan
				try {
					const zxResult = reader.decodeFromCanvas(targetCanvas);
					if (zxResult && zxResult.getText()) {
						const raw = zxResult.getText();
						const formatNum = zxResult.getBarcodeFormat();
						const formatStr = typeof formatNum === "number" && ZXING_FORMAT_NAMES[formatNum] ? ZXING_FORMAT_NAMES[formatNum] : "barcode";
						return {
							format: formatStr,
							rawValue: raw
						};
					}
				} catch {
					// If full frame failed, try center crop reticle (ideal for curved bottles / closeups)
					const cw = targetCanvas.width;
					const ch = targetCanvas.height;
					const cropW = Math.round(cw * .7);
					const cropH = Math.round(ch * .45);
					const cropX = Math.round((cw - cropW) / 2);
					const cropY = Math.round((ch - cropH) / 2);
					if (!croppedCanvas) {
						croppedCanvas = document.createElement("canvas");
					}
					croppedCanvas.width = cropW;
					croppedCanvas.height = cropH;
					const cCtx = croppedCanvas.getContext("2d", { willReadFrequently: true });
					if (cCtx) {
						cCtx.drawImage(targetCanvas, cropX, cropY, cropW, cropH, 0, 0, cropW, cropH);
						try {
							const cropResult = reader.decodeFromCanvas(croppedCanvas);
							if (cropResult && cropResult.getText()) {
								const raw = cropResult.getText();
								const formatNum = cropResult.getBarcodeFormat();
								const formatStr = typeof formatNum === "number" && ZXING_FORMAT_NAMES[formatNum] ? ZXING_FORMAT_NAMES[formatNum] : "barcode";
								return {
									format: formatStr,
									rawValue: raw
								};
							}
						} catch {
							// Not detected in crop, try 90-degree rotation (common on vertical bottle barcodes)
							try {
								const rotCanvas = document.createElement("canvas");
								rotCanvas.width = cropH;
								rotCanvas.height = cropW;
								const rCtx = rotCanvas.getContext("2d", { willReadFrequently: true });
								if (rCtx) {
									rCtx.translate(cropH / 2, cropW / 2);
									rCtx.rotate(90 * Math.PI / 180);
									rCtx.drawImage(croppedCanvas, -cropW / 2, -cropH / 2);
									const rotResult = reader.decodeFromCanvas(rotCanvas);
									if (rotResult && rotResult.getText()) {
										const raw = rotResult.getText();
										const formatNum = rotResult.getBarcodeFormat();
										const formatStr = typeof formatNum === "number" && ZXING_FORMAT_NAMES[formatNum] ? ZXING_FORMAT_NAMES[formatNum] : "barcode";
										return {
											format: formatStr,
											rawValue: raw
										};
									}
								}
							} catch {}
						}
					}
				}
			}
		}
	} catch {}
	// 3. Fallback to jsQR if source is a canvas or captured video
	if (source instanceof HTMLCanvasElement) {
		const qr = scanQrFromCanvas(source);
		if (qr) {
			return {
				format: "qr_code",
				rawValue: qr
			};
		}
	} else if (processingCanvas) {
		const qr = scanQrFromCanvas(processingCanvas);
		if (qr) {
			return {
				format: "qr_code",
				rawValue: qr
			};
		}
	}
	return null;
}
/**
* Resolves GS1 prefix country/region for 1D UPC/EAN barcodes.
*/
export function getGs1CountryPrefix(barcode) {
	const digits = barcode.replace(/\D/g, "");
	if (digits.length < 3) return null;
	const prefix3 = parseInt(digits.slice(0, 3), 10);
	const prefix2 = parseInt(digits.slice(0, 2), 10);
	if (prefix3 >= 0 && prefix3 <= 19) return "United States & Canada (UPC-A)";
	if (prefix3 >= 30 && prefix3 <= 39) return "United States (Drugs / Healthcare)";
	if (prefix3 >= 40 && prefix3 <= 49) return "Restricted Internal Distribution";
	if (prefix3 >= 50 && prefix3 <= 59) return "Coupons & Loyalty";
	if (prefix3 >= 100 && prefix3 <= 139) return "United States";
	if (prefix3 >= 300 && prefix3 <= 379) return "France & Monaco";
	if (prefix3 >= 380 && prefix3 <= 380) return "Bulgaria";
	if (prefix3 >= 383 && prefix3 <= 383) return "Slovenia";
	if (prefix3 >= 385 && prefix3 <= 385) return "Croatia";
	if (prefix3 >= 400 && prefix3 <= 440) return "Germany";
	if (prefix3 >= 450 && prefix3 <= 459) return "Japan (JAN)";
	if (prefix3 >= 460 && prefix3 <= 469) return "Russia";
	if (prefix3 >= 471 && prefix3 <= 471) return "Taiwan";
	if (prefix3 >= 480 && prefix3 <= 480) return "Philippines";
	if (prefix3 >= 489 && prefix3 <= 489) return "Hong Kong";
	if (prefix3 >= 490 && prefix3 <= 499) return "Japan (JAN)";
	if (prefix3 >= 500 && prefix3 <= 509) return "United Kingdom";
	if (prefix3 >= 520 && prefix3 <= 521) return "Greece";
	if (prefix3 >= 531 && prefix3 <= 531) return "North Macedonia";
	if (prefix3 >= 535 && prefix3 <= 535) return "Malta";
	if (prefix3 >= 539 && prefix3 <= 539) return "Ireland";
	if (prefix3 >= 540 && prefix3 <= 549) return "Belgium & Luxembourg";
	if (prefix3 >= 560 && prefix3 <= 560) return "Portugal";
	if (prefix3 >= 569 && prefix3 <= 569) return "Iceland";
	if (prefix3 >= 570 && prefix3 <= 579) return "Denmark, Faroe & Greenland";
	if (prefix3 >= 590 && prefix3 <= 590) return "Poland";
	if (prefix3 >= 594 && prefix3 <= 594) return "Romania";
	if (prefix3 >= 599 && prefix3 <= 599) return "Hungary";
	if (prefix3 >= 600 && prefix3 <= 601) return "South Africa";
	if (prefix3 >= 611 && prefix3 <= 611) return "Morocco";
	if (prefix3 >= 619 && prefix3 <= 619) return "Tunisia";
	if (prefix3 >= 622 && prefix3 <= 622) return "Egypt";
	if (prefix3 >= 640 && prefix3 <= 649) return "Finland";
	if (prefix3 >= 690 && prefix3 <= 699) return "China";
	if (prefix3 >= 700 && prefix3 <= 709) return "Norway";
	if (prefix3 >= 730 && prefix3 <= 739) return "Sweden";
	if (prefix3 >= 750 && prefix3 <= 750) return "Mexico";
	if (prefix3 >= 760 && prefix3 <= 769) return "Switzerland & Liechtenstein";
	if (prefix3 >= 770 && prefix3 <= 771) return "Colombia";
	if (prefix3 >= 773 && prefix3 <= 773) return "Uruguay";
	if (prefix3 >= 775 && prefix3 <= 775) return "Peru";
	if (prefix3 >= 779 && prefix3 <= 779) return "Argentina";
	if (prefix3 >= 780 && prefix3 <= 780) return "Chile";
	if (prefix3 >= 789 && prefix3 <= 790) return "Brazil";
	if (prefix3 >= 800 && prefix3 <= 839) return "Italy, San Marino & Vatican";
	if (prefix3 >= 840 && prefix3 <= 849) return "Spain";
	if (prefix3 >= 860 && prefix3 <= 860) return "Serbia";
	if (prefix3 >= 868 && prefix3 <= 869) return "Turkey";
	if (prefix3 >= 870 && prefix3 <= 879) return "Netherlands";
	if (prefix3 >= 880 && prefix3 <= 880) return "South Korea";
	if (prefix3 >= 885 && prefix3 <= 885) return "Thailand";
	if (prefix3 >= 888 && prefix3 <= 888) return "Singapore";
	if (prefix3 >= 890 && prefix3 <= 890) return "India";
	if (prefix3 >= 893 && prefix3 <= 893) return "Vietnam";
	if (prefix3 >= 899 && prefix3 <= 899) return "Indonesia";
	if (prefix3 >= 900 && prefix3 <= 919) return "Austria";
	if (prefix3 >= 930 && prefix3 <= 939) return "Australia";
	if (prefix3 >= 940 && prefix3 <= 949) return "New Zealand";
	if (prefix3 >= 955 && prefix3 <= 955) return "Malaysia";
	return null;
}
/**
* Synthesizes a futuristic confirmation chime using Web Audio API.
*/
export function playScanChime() {
	if (typeof window === "undefined") return;
	try {
		const AudioCtx = window.AudioContext || window.webkitAudioContext;
		if (!AudioCtx) return;
		const ctx = new AudioCtx();
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		osc.type = "sine";
		osc.frequency.setValueAtTime(880, ctx.currentTime);
		osc.frequency.exponentialRampToValueAtTime(1760, ctx.currentTime + .12);
		gain.gain.setValueAtTime(.15, ctx.currentTime);
		gain.gain.exponentialRampToValueAtTime(.001, ctx.currentTime + .25);
		osc.connect(gain);
		gain.connect(ctx.destination);
		osc.start();
		osc.stop(ctx.currentTime + .25);
	} catch {}
}
/**
* Calls our server-side Gemini AI Scan endpoint.
*/
export async function runAiScan(params) {
	const res = await fetch("/api/ai-scan", {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(params)
	});
	if (!res.ok) {
		const errData = await res.json().catch(() => ({ error: "AI Scan failed" }));
		throw new Error(errData.error || errData.details || `AI Scan failed with status ${res.status}`);
	}
	const json = await res.json();
	if (!json.success || !json.data) {
		throw new Error(json.error || "No data received from AI Scan");
	}
	return json.data;
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxVQUFVO0FBRWpCLE1BQU0scUJBQTZDO0NBQ2pELEdBQUc7Q0FDSCxHQUFHO0NBQ0gsR0FBRztDQUNILEdBQUc7Q0FDSCxHQUFHO0NBQ0gsR0FBRztDQUNILEdBQUc7Q0FDSCxHQUFHO0NBQ0gsR0FBRztDQUNILElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7QUFDTjs7QUFVQSxJQUFJLG9CQUE0QztBQUNoRCxlQUFlLGlCQUFrRDtDQUMvRCxJQUFJLE9BQU8sV0FBVyxhQUFhLE9BQU87Q0FDMUMsSUFBSSxDQUFDLG1CQUFtQjtFQUN0QixJQUFJO0dBQ0YsTUFBTSxNQUFNLE1BQU0sT0FBTztHQUN6QixvQkFBb0IsSUFBSSxJQUFJLHlCQUF5QjtFQUN2RCxRQUFRLENBRVI7Q0FDRjtDQUNBLE9BQU87QUFDVDs7OztBQTZEQSxPQUFPLGVBQWUsc0JBQ3BCLE1BQ0EsU0FBUyxNQUMwRztDQUNuSCxPQUFPLElBQUksU0FBUyxTQUFTLFdBQVc7RUFDdEMsTUFBTSxTQUFTLElBQUksV0FBVztFQUM5QixPQUFPLFVBQVUsTUFBTTtHQUNyQixNQUFNLE1BQU0sSUFBSSxNQUFNO0dBQ3RCLElBQUksU0FBUyxZQUFZO0lBQ3ZCLElBQUksSUFBSSxJQUFJO0lBQ1osSUFBSSxJQUFJLElBQUk7SUFDWixJQUFJLElBQUksVUFBVSxJQUFJLFFBQVE7S0FDNUIsTUFBTSxRQUFRLEtBQUssSUFBSSxTQUFTLEdBQUcsU0FBUyxDQUFDO0tBQzdDLElBQUksS0FBSyxNQUFNLElBQUksS0FBSztLQUN4QixJQUFJLEtBQUssTUFBTSxJQUFJLEtBQUs7SUFDMUI7SUFFQSxNQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7SUFDOUMsT0FBTyxRQUFRO0lBQ2YsT0FBTyxTQUFTO0lBQ2hCLE1BQU0sTUFBTSxPQUFPLFdBQVcsTUFBTSxFQUFFLG9CQUFvQixLQUFLLENBQUM7SUFDaEUsSUFBSSxDQUFDLEtBQUs7S0FDUixPQUFPLElBQUksTUFBTSxpQ0FBaUMsQ0FBQztLQUNuRDtJQUNGO0lBRUEsSUFBSSxVQUFVLEtBQUssR0FBRyxHQUFHLEdBQUcsQ0FBQztJQUM3QixNQUFNLFVBQVUsT0FBTyxVQUFVLGNBQWMsR0FBSTtJQUNuRCxNQUFNLFNBQVMsUUFBUSxNQUFNLEdBQUcsQ0FBQyxDQUFDOztJQUdsQyxJQUFJLFNBQXdCO0lBQzVCLElBQUksY0FBNkI7SUFFakMsSUFBSTtLQUNGLE1BQU0sS0FBSyxNQUFNLGVBQWU7S0FDaEMsSUFBSSxJQUFJO01BQ04sTUFBTSxRQUFRLEdBQUcsaUJBQWlCLE1BQU07TUFDeEMsSUFBSSxTQUFTLE1BQU0sUUFBUSxHQUFHO09BQzVCLE1BQU0sT0FBTyxNQUFNLFFBQVE7T0FDM0IsTUFBTSxNQUFNLE1BQU0saUJBQWlCO09BQ25DLE1BQU0sVUFBVSxPQUFPLFFBQVEsWUFBWSxtQkFBbUIsT0FBTyxtQkFBbUIsT0FBTztPQUMvRixJQUFJLFFBQVEsU0FBUyxJQUFJLEdBQUc7UUFDMUIsU0FBUztPQUNYLE9BQU87UUFDTCxjQUFjO09BQ2hCO01BQ0Y7S0FDRjtJQUNGLFFBQVEsQ0FFUjtJQUVBLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYTtLQUMzQixJQUFJO01BQ0YsTUFBTSxZQUFZLElBQUksYUFBYSxHQUFHLEdBQUcsR0FBRyxDQUFDO01BQzdDLE1BQU0sS0FBSyxLQUFLLFVBQVUsTUFBTSxHQUFHLEdBQUcsRUFBRSxtQkFBbUIsY0FBYyxDQUFDO01BQzFFLElBQUksSUFBSSxNQUFNLFNBQVMsR0FBRztLQUM1QixRQUFRLENBRVI7SUFDRjtJQUVBLFFBQVE7S0FBRTtLQUFTO0tBQVEsVUFBVTtLQUFjO0tBQVE7SUFBWSxDQUFDO0dBQzFFO0dBQ0EsSUFBSSxnQkFBZ0IsT0FBTyxJQUFJLE1BQU0sNkJBQTZCLENBQUM7R0FDbkUsSUFBSSxNQUFNLEVBQUUsUUFBUTtFQUN0QjtFQUNBLE9BQU8sZ0JBQWdCLE9BQU8sSUFBSSxNQUFNLHFCQUFxQixDQUFDO0VBQzlELE9BQU8sY0FBYyxJQUFJO0NBQzNCLENBQUM7QUFDSDs7OztBQUtBLE9BQU8sZUFBZSxzQkFDcEIsV0FDbUg7Q0FDbkgsT0FBTyxJQUFJLFNBQVMsU0FBUyxXQUFXO0VBQ3RDLE1BQU0sUUFBUSxTQUFTLGNBQWMsT0FBTztFQUM1QyxNQUFNLFVBQVU7RUFDaEIsTUFBTSxRQUFRO0VBQ2QsTUFBTSxjQUFjO0VBQ3BCLE1BQU0sTUFBTSxJQUFJLGdCQUFnQixTQUFTO0VBQ3pDLE1BQU0sTUFBTTtFQUVaLE1BQU0sZ0JBQWdCLElBQUksZ0JBQWdCLEdBQUc7RUFFN0MsTUFBTSx5QkFBeUI7O0dBRTdCLE1BQU0sY0FBYyxLQUFLLElBQUksR0FBSyxNQUFNLFdBQVcsSUFBSSxNQUFNLFdBQVcsSUFBSSxFQUFHO0VBQ2pGO0VBRUEsTUFBTSxXQUFXLFlBQVk7R0FDM0IsSUFBSTtJQUNGLE1BQU0sU0FBUztJQUNmLElBQUksSUFBSSxNQUFNLGNBQWM7SUFDNUIsSUFBSSxJQUFJLE1BQU0sZUFBZTtJQUM3QixJQUFJLElBQUksVUFBVSxJQUFJLFFBQVE7S0FDNUIsTUFBTSxRQUFRLEtBQUssSUFBSSxTQUFTLEdBQUcsU0FBUyxDQUFDO0tBQzdDLElBQUksS0FBSyxNQUFNLElBQUksS0FBSztLQUN4QixJQUFJLEtBQUssTUFBTSxJQUFJLEtBQUs7SUFDMUI7SUFFQSxNQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7SUFDOUMsT0FBTyxRQUFRO0lBQ2YsT0FBTyxTQUFTO0lBQ2hCLE1BQU0sTUFBTSxPQUFPLFdBQVcsTUFBTSxFQUFFLG9CQUFvQixLQUFLLENBQUM7SUFDaEUsSUFBSSxDQUFDLEtBQUssTUFBTSxJQUFJLE1BQU0saUNBQWlDO0lBQzNELElBQUksVUFBVSxPQUFPLEdBQUcsR0FBRyxHQUFHLENBQUM7SUFDL0IsTUFBTSxVQUFVLE9BQU8sVUFBVSxjQUFjLEdBQUk7SUFDbkQsTUFBTSxTQUFTLFFBQVEsTUFBTSxHQUFHLENBQUMsQ0FBQztJQUVsQyxJQUFJLFNBQXdCO0lBQzVCLElBQUksY0FBNkI7SUFFakMsSUFBSTtLQUNGLE1BQU0sS0FBSyxNQUFNLGVBQWU7S0FDaEMsSUFBSSxJQUFJO01BQ04sTUFBTSxRQUFRLEdBQUcsaUJBQWlCLE1BQU07TUFDeEMsSUFBSSxTQUFTLE1BQU0sUUFBUSxHQUFHO09BQzVCLE1BQU0sT0FBTyxNQUFNLFFBQVE7T0FDM0IsTUFBTSxNQUFNLE1BQU0saUJBQWlCO09BQ25DLE1BQU0sVUFBVSxPQUFPLFFBQVEsWUFBWSxtQkFBbUIsT0FBTyxtQkFBbUIsT0FBTztPQUMvRixJQUFJLFFBQVEsU0FBUyxJQUFJLEdBQUc7UUFDMUIsU0FBUztPQUNYLE9BQU87UUFDTCxjQUFjO09BQ2hCO01BQ0Y7S0FDRjtJQUNGLFFBQVEsQ0FFUjtJQUVBLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYTtLQUMzQixJQUFJO01BQ0YsTUFBTSxVQUFVLElBQUksYUFBYSxHQUFHLEdBQUcsR0FBRyxDQUFDO01BQzNDLE1BQU0sS0FBSyxLQUFLLFFBQVEsTUFBTSxHQUFHLEdBQUcsRUFBRSxtQkFBbUIsY0FBYyxDQUFDO01BQ3hFLElBQUksSUFBSSxNQUFNLFNBQVMsR0FBRztLQUM1QixRQUFRLENBRVI7SUFDRjtJQUVBLFFBQVE7SUFDUixRQUFRO0tBQUU7S0FBUztLQUFRLFVBQVU7S0FBYztLQUFRO0lBQVksQ0FBQztHQUMxRSxTQUFTLEtBQUs7SUFDWixRQUFRO0lBQ1IsT0FBTyxHQUFHO0dBQ1o7RUFDRjtFQUVBLE1BQU0sZ0JBQWdCO0dBQ3BCLFFBQVE7R0FDUixPQUFPLElBQUksTUFBTSwrQkFBK0IsQ0FBQztFQUNuRDtDQUNGLENBQUM7QUFDSDs7QUFHQSxJQUFJLG1CQUE2QztBQUNqRCxJQUFJLGdCQUEwQzs7OztBQUs5QyxPQUFPLFNBQVMsaUJBQWlCLFFBQTBDO0NBQ3pFLElBQUk7RUFDRixNQUFNLE1BQU0sT0FBTyxXQUFXLE1BQU0sRUFBRSxvQkFBb0IsS0FBSyxDQUFDO0VBQ2hFLElBQUksQ0FBQyxLQUFLLE9BQU87RUFDakIsTUFBTSxVQUFVLElBQUksYUFBYSxHQUFHLEdBQUcsT0FBTyxPQUFPLE9BQU8sTUFBTTtFQUNsRSxNQUFNLE9BQU8sS0FBSyxRQUFRLE1BQU0sT0FBTyxPQUFPLE9BQU8sUUFBUSxFQUMzRCxtQkFBbUIsY0FDckIsQ0FBQztFQUNELE9BQU8sTUFBTSxRQUFRO0NBQ3ZCLFFBQVE7RUFDTixPQUFPO0NBQ1Q7QUFDRjs7Ozs7QUFNQSxPQUFPLGVBQWUsa0JBQ3BCLFFBQ3NEOztDQUV0RCxJQUFJLE9BQU8sV0FBVyxlQUFlLHFCQUFxQixRQUFRO0VBQ2hFLElBQUk7O0dBRUYsTUFBTSxXQUFXLElBQUksT0FBTyxnQkFBZ0IsRUFDMUMsU0FBUztJQUNQO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0YsRUFDRixDQUFDO0dBQ0QsTUFBTSxXQUFXLE1BQU0sU0FBUyxPQUFPLE1BQU07R0FDN0MsSUFBSSxZQUFZLFNBQVMsU0FBUyxLQUFLLFNBQVMsRUFBRSxDQUFDLFVBQVU7SUFDM0QsT0FBTztLQUNMLFFBQVEsU0FBUyxFQUFFLENBQUMsVUFBVTtLQUM5QixVQUFVLFNBQVMsRUFBRSxDQUFDO0lBQ3hCO0dBQ0Y7RUFDRixRQUFRLENBRVI7Q0FDRjs7Q0FHQSxJQUFJO0VBQ0YsTUFBTSxTQUFTLE1BQU0sZUFBZTtFQUNwQyxJQUFJLFFBQVE7R0FDVixJQUFJLGVBQXlDO0dBRTdDLElBQUksa0JBQWtCLG1CQUFtQjtJQUN2QyxlQUFlO0dBQ2pCLE9BQU8sSUFBSSxrQkFBa0Isb0JBQW9CLE9BQU8sYUFBYSxLQUFLLE9BQU8sY0FBYyxHQUFHO0lBQ2hHLElBQUksQ0FBQyxrQkFBa0I7S0FDckIsbUJBQW1CLFNBQVMsY0FBYyxRQUFRO0lBQ3BEO0lBQ0EsaUJBQWlCLFFBQVEsT0FBTztJQUNoQyxpQkFBaUIsU0FBUyxPQUFPO0lBQ2pDLE1BQU0sT0FBTyxpQkFBaUIsV0FBVyxNQUFNLEVBQUUsb0JBQW9CLEtBQUssQ0FBQztJQUMzRSxJQUFJLE1BQU07S0FDUixLQUFLLFVBQVUsUUFBUSxHQUFHLEdBQUcsT0FBTyxZQUFZLE9BQU8sV0FBVztLQUNsRSxlQUFlO0lBQ2pCO0dBQ0Y7R0FFQSxJQUFJLGNBQWM7O0lBRWhCLElBQUk7S0FDRixNQUFNLFdBQVcsT0FBTyxpQkFBaUIsWUFBWTtLQUNyRCxJQUFJLFlBQVksU0FBUyxRQUFRLEdBQUc7TUFDbEMsTUFBTSxNQUFNLFNBQVMsUUFBUTtNQUM3QixNQUFNLFlBQVksU0FBUyxpQkFBaUI7TUFDNUMsTUFBTSxZQUFhLE9BQU8sY0FBYyxZQUFZLG1CQUFtQixhQUNuRSxtQkFBbUIsYUFDbkI7TUFDSixPQUFPO09BQ0wsUUFBUTtPQUNSLFVBQVU7TUFDWjtLQUNGO0lBQ0YsUUFBUTs7S0FFTixNQUFNLEtBQUssYUFBYTtLQUN4QixNQUFNLEtBQUssYUFBYTtLQUN4QixNQUFNLFFBQVEsS0FBSyxNQUFNLEtBQUssRUFBRztLQUNqQyxNQUFNLFFBQVEsS0FBSyxNQUFNLEtBQUssR0FBSTtLQUNsQyxNQUFNLFFBQVEsS0FBSyxPQUFPLEtBQUssU0FBUyxDQUFDO0tBQ3pDLE1BQU0sUUFBUSxLQUFLLE9BQU8sS0FBSyxTQUFTLENBQUM7S0FFekMsSUFBSSxDQUFDLGVBQWU7TUFDbEIsZ0JBQWdCLFNBQVMsY0FBYyxRQUFRO0tBQ2pEO0tBQ0EsY0FBYyxRQUFRO0tBQ3RCLGNBQWMsU0FBUztLQUN2QixNQUFNLE9BQU8sY0FBYyxXQUFXLE1BQU0sRUFBRSxvQkFBb0IsS0FBSyxDQUFDO0tBQ3hFLElBQUksTUFBTTtNQUNSLEtBQUssVUFBVSxjQUFjLE9BQU8sT0FBTyxPQUFPLE9BQU8sR0FBRyxHQUFHLE9BQU8sS0FBSztNQUMzRSxJQUFJO09BQ0YsTUFBTSxhQUFhLE9BQU8saUJBQWlCLGFBQWE7T0FDeEQsSUFBSSxjQUFjLFdBQVcsUUFBUSxHQUFHO1FBQ3RDLE1BQU0sTUFBTSxXQUFXLFFBQVE7UUFDL0IsTUFBTSxZQUFZLFdBQVcsaUJBQWlCO1FBQzlDLE1BQU0sWUFBYSxPQUFPLGNBQWMsWUFBWSxtQkFBbUIsYUFDbkUsbUJBQW1CLGFBQ25CO1FBQ0osT0FBTztTQUNMLFFBQVE7U0FDUixVQUFVO1FBQ1o7T0FDRjtNQUNGLFFBQVE7O09BRU4sSUFBSTtRQUNGLE1BQU0sWUFBWSxTQUFTLGNBQWMsUUFBUTtRQUNqRCxVQUFVLFFBQVE7UUFDbEIsVUFBVSxTQUFTO1FBQ25CLE1BQU0sT0FBTyxVQUFVLFdBQVcsTUFBTSxFQUFFLG9CQUFvQixLQUFLLENBQUM7UUFDcEUsSUFBSSxNQUFNO1NBQ1IsS0FBSyxVQUFVLFFBQVEsR0FBRyxRQUFRLENBQUM7U0FDbkMsS0FBSyxPQUFRLEtBQUssS0FBSyxLQUFNLEdBQUc7U0FDaEMsS0FBSyxVQUFVLGVBQWUsQ0FBQyxRQUFRLEdBQUcsQ0FBQyxRQUFRLENBQUM7U0FDcEQsTUFBTSxZQUFZLE9BQU8saUJBQWlCLFNBQVM7U0FDbkQsSUFBSSxhQUFhLFVBQVUsUUFBUSxHQUFHO1VBQ3BDLE1BQU0sTUFBTSxVQUFVLFFBQVE7VUFDOUIsTUFBTSxZQUFZLFVBQVUsaUJBQWlCO1VBQzdDLE1BQU0sWUFBYSxPQUFPLGNBQWMsWUFBWSxtQkFBbUIsYUFDbkUsbUJBQW1CLGFBQ25CO1VBQ0osT0FBTztXQUNMLFFBQVE7V0FDUixVQUFVO1VBQ1o7U0FDRjtRQUNGO09BQ0YsUUFBUSxDQUVSO01BQ0Y7S0FDRjtJQUNGO0dBQ0Y7RUFDRjtDQUNGLFFBQVEsQ0FFUjs7Q0FHQSxJQUFJLGtCQUFrQixtQkFBbUI7RUFDdkMsTUFBTSxLQUFLLGlCQUFpQixNQUFNO0VBQ2xDLElBQUksSUFBSTtHQUNOLE9BQU87SUFBRSxRQUFRO0lBQVcsVUFBVTtHQUFHO0VBQzNDO0NBQ0YsT0FBTyxJQUFJLGtCQUFrQjtFQUMzQixNQUFNLEtBQUssaUJBQWlCLGdCQUFnQjtFQUM1QyxJQUFJLElBQUk7R0FDTixPQUFPO0lBQUUsUUFBUTtJQUFXLFVBQVU7R0FBRztFQUMzQztDQUNGO0NBRUEsT0FBTztBQUNUOzs7O0FBS0EsT0FBTyxTQUFTLG9CQUFvQixTQUFnQztDQUNsRSxNQUFNLFNBQVMsUUFBUSxRQUFRLE9BQU8sRUFBRTtDQUN4QyxJQUFJLE9BQU8sU0FBUyxHQUFHLE9BQU87Q0FDOUIsTUFBTSxVQUFVLFNBQVMsT0FBTyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEVBQUU7Q0FDL0MsTUFBTSxVQUFVLFNBQVMsT0FBTyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEVBQUU7Q0FFL0MsSUFBSSxXQUFXLEtBQUssV0FBVyxJQUFJLE9BQU87Q0FDMUMsSUFBSSxXQUFXLE1BQU0sV0FBVyxJQUFJLE9BQU87Q0FDM0MsSUFBSSxXQUFXLE1BQU0sV0FBVyxJQUFJLE9BQU87Q0FDM0MsSUFBSSxXQUFXLE1BQU0sV0FBVyxJQUFJLE9BQU87Q0FDM0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FDN0MsSUFBSSxXQUFXLE9BQU8sV0FBVyxLQUFLLE9BQU87Q0FFN0MsT0FBTztBQUNUOzs7O0FBS0EsT0FBTyxTQUFTLGdCQUFnQjtDQUM5QixJQUFJLE9BQU8sV0FBVyxhQUFhO0NBQ25DLElBQUk7RUFDRixNQUFNLFdBQVcsT0FBTyxnQkFBaUIsT0FBZTtFQUN4RCxJQUFJLENBQUMsVUFBVTtFQUNmLE1BQU0sTUFBTSxJQUFJLFNBQVM7RUFDekIsTUFBTSxNQUFNLElBQUksaUJBQWlCO0VBQ2pDLE1BQU0sT0FBTyxJQUFJLFdBQVc7RUFFNUIsSUFBSSxPQUFPO0VBQ1gsSUFBSSxVQUFVLGVBQWUsS0FBSyxJQUFJLFdBQVc7RUFDakQsSUFBSSxVQUFVLDZCQUE2QixNQUFNLElBQUksY0FBYyxHQUFJO0VBRXZFLEtBQUssS0FBSyxlQUFlLEtBQU0sSUFBSSxXQUFXO0VBQzlDLEtBQUssS0FBSyw2QkFBNkIsTUFBTyxJQUFJLGNBQWMsR0FBSTtFQUVwRSxJQUFJLFFBQVEsSUFBSTtFQUNoQixLQUFLLFFBQVEsSUFBSSxXQUFXO0VBRTVCLElBQUksTUFBTTtFQUNWLElBQUksS0FBSyxJQUFJLGNBQWMsR0FBSTtDQUNqQyxRQUFRLENBRVI7QUFDRjs7OztBQUtBLE9BQU8sZUFBZSxVQUFVLFFBT047Q0FDeEIsTUFBTSxNQUFNLE1BQU0sTUFBTSxnQkFBZ0I7RUFDdEMsUUFBUTtFQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0VBQzlDLE1BQU0sS0FBSyxVQUFVLE1BQU07Q0FDN0IsQ0FBQztDQUVELElBQUksQ0FBQyxJQUFJLElBQUk7RUFDWCxNQUFNLFVBQVUsTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDLGFBQWEsRUFBRSxPQUFPLGlCQUFpQixFQUFFO0VBQzFFLE1BQU0sSUFBSSxNQUFNLFFBQVEsU0FBUyxRQUFRLFdBQVcsOEJBQThCLElBQUksUUFBUTtDQUNoRztDQUVBLE1BQU0sT0FBTyxNQUFNLElBQUksS0FBSztDQUM1QixJQUFJLENBQUMsS0FBSyxXQUFXLENBQUMsS0FBSyxNQUFNO0VBQy9CLE1BQU0sSUFBSSxNQUFNLEtBQUssU0FBUywrQkFBK0I7Q0FDL0Q7Q0FFQSxPQUFPLEtBQUs7QUFDZCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJhaS1zY2FubmVyLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBqc1FSIGZyb20gXCJqc3FyXCI7XG5cbmNvbnN0IFpYSU5HX0ZPUk1BVF9OQU1FUzogUmVjb3JkPG51bWJlciwgc3RyaW5nPiA9IHtcbiAgMDogXCJhenRlY1wiLFxuICAxOiBcImNvZGFiYXJcIixcbiAgMjogXCJjb2RlXzM5XCIsXG4gIDM6IFwiY29kZV85M1wiLFxuICA0OiBcImNvZGVfMTI4XCIsXG4gIDU6IFwiZGF0YV9tYXRyaXhcIixcbiAgNjogXCJlYW5fOFwiLFxuICA3OiBcImVhbl8xM1wiLFxuICA4OiBcIml0ZlwiLFxuICAxMDogXCJwZGZfNDE3XCIsXG4gIDExOiBcInFyX2NvZGVcIixcbiAgMTQ6IFwidXBjX2FcIixcbiAgMTU6IFwidXBjX2VcIixcbn07XG5cbnR5cGUgWnhpbmdSZWFkZXJMaWtlID0ge1xuICBkZWNvZGVGcm9tQ2FudmFzOiAoY2FudmFzOiBIVE1MQ2FudmFzRWxlbWVudCkgPT4ge1xuICAgIGdldFRleHQ6ICgpID0+IHN0cmluZztcbiAgICBnZXRCYXJjb2RlRm9ybWF0OiAoKSA9PiBudW1iZXI7XG4gIH07XG59O1xuXG4vLyBDYWNoZSBaWGluZyByZWFkZXIgY29uZmlndXJlZCB3aXRoIHJldGFpbCAxRCArIDJEIGZvcm1hdHMgKGxvYWRlZCBjbGllbnQtc2lkZSBvbmx5KVxubGV0IGNhY2hlZFp4aW5nUmVhZGVyOiBaeGluZ1JlYWRlckxpa2UgfCBudWxsID0gbnVsbDtcbmFzeW5jIGZ1bmN0aW9uIGdldFp4aW5nUmVhZGVyKCk6IFByb21pc2U8WnhpbmdSZWFkZXJMaWtlIHwgbnVsbD4ge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIG51bGw7XG4gIGlmICghY2FjaGVkWnhpbmdSZWFkZXIpIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgbW9kID0gYXdhaXQgaW1wb3J0KFwiQHp4aW5nL2xpYnJhcnlcIik7XG4gICAgICBjYWNoZWRaeGluZ1JlYWRlciA9IG5ldyBtb2QuQnJvd3Nlck11bHRpRm9ybWF0UmVhZGVyKCkgYXMgdW5rbm93biBhcyBaeGluZ1JlYWRlckxpa2U7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBGYWxsYmFjayBpZiByZWFkZXIgZmFpbHMgdG8gaW5pdGlhbGl6ZVxuICAgIH1cbiAgfVxuICByZXR1cm4gY2FjaGVkWnhpbmdSZWFkZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQnJhbmRJZGVudGlmaWNhdGlvbiB7XG4gIGlkZW50aWZpZWQ6IGJvb2xlYW47XG4gIGJyYW5kTmFtZTogc3RyaW5nO1xuICBicmFuZE93bmVyOiBzdHJpbmc7IC8vIENvcnBvcmF0ZSBwYXJlbnQgY29tcGFueSAvIGJyYW5kIG93bmVyXG4gIHBhcmVudENvbXBhbnlDb250ZXh0OiBzdHJpbmc7XG4gIHByb2R1Y3ROYW1lOiBzdHJpbmc7XG4gIGNhdGVnb3J5OiBzdHJpbmc7XG4gIG1hcmtldFRpZXI6IFwiQnVkZ2V0XCIgfCBcIk1hc3MgTWFya2V0XCIgfCBcIlByZW1pdW1cIiB8IFwiTHV4dXJ5XCIgfCBzdHJpbmc7XG4gIGNvdW50cnlPZk9yaWdpbjogc3RyaW5nO1xuICBjb25maWRlbmNlOiBudW1iZXI7XG4gIHFyT3JCYXJjb2RlRGVjb2RlZD86IHN0cmluZztcbiAgc3VtbWFyeTogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIE1lZGlhRm9yZW5zaWNzIHtcbiAgcGh5c2ljYWxMaWdodGluZzogc3RyaW5nO1xuICB0ZXh0dXJlQW5kTm9pc2U6IHN0cmluZztcbiAgdGV4dEludGVncml0eTogc3RyaW5nO1xuICBhaUdlbmVyYXRpb25NYXJrZXJzOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWVkaWFBdXRoZW50aWNpdHlSZXBvcnQge1xuICBzY29yZTogbnVtYmVyOyAvLyAwIC0gMTAwXG4gIGlzTGVnaXRpbWF0ZTogYm9vbGVhbjtcbiAgdmVyZGljdFN0YXR1czogXCJ2ZXJpZmllZF9hdXRoZW50aWNcIiB8IFwibGlrZWx5X2F1dGhlbnRpY1wiIHwgXCJzdXNwaWNpb3VzX3RhbXBlcmluZ1wiIHwgXCJhaV9nZW5lcmF0ZWRcIiB8IFwiaW5jb25jbHVzaXZlXCI7XG4gIGJhZGdlTGFiZWw6IHN0cmluZztcbiAgY29uZmlkZW5jZTogXCJoaWdoXCIgfCBcIm1lZGl1bVwiIHwgXCJsb3dcIjtcbiAgZm9yZW5zaWNzOiBNZWRpYUZvcmVuc2ljcztcbiAgcmVhc29uczogc3RyaW5nW107XG4gIGZsYWdzOiBzdHJpbmdbXTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDb3VudGVyZmVpdEFzc2Vzc21lbnQge1xuICB2ZXJkaWN0OiBcImxlZ2l0XCIgfCBcImxpa2VseV9sZWdpdFwiIHwgXCJzdXNwZWN0ZWRfY291bnRlcmZlaXRcIiB8IFwiaGlnaF9yaXNrX2Zha2VcIiB8IFwiaW5jb25jbHVzaXZlXCI7XG4gIGF1dGhlbnRpY2l0eVNjb3JlOiBudW1iZXI7IC8vIDAgLSAxMDAgKGhpZ2ggPSBhdXRoZW50aWMpXG4gIGNvdW50ZXJmZWl0Umlza1Njb3JlOiBudW1iZXI7IC8vIDAgLSAxMDAgKGhpZ2ggPSByZXBsaWNhL2Zha2UgcmlzaylcbiAgY29uZmlkZW5jZTogXCJoaWdoXCIgfCBcIm1lZGl1bVwiIHwgXCJsb3dcIjtcbiAgYmFkZ2VMYWJlbDogc3RyaW5nO1xuICBsb2dvSW5zcGVjdGlvbjogc3RyaW5nO1xuICBiYXJjb2RlQW5kVGFnc0luc3BlY3Rpb246IHN0cmluZztcbiAgbWF0ZXJpYWxBbmRDcmFmdHNtYW5zaGlwOiBzdHJpbmc7XG4gIGNsaWVudFZlcmlmaWNhdGlvbkd1aWRlOiBzdHJpbmdbXTtcbiAgYnJhbmRQcm90ZWN0aW9uVHJhY2tpbmc6IHtcbiAgICBicmFuZE93bmVyQ29uZmlybWVkOiBib29sZWFuO1xuICAgIGF1dGhvcml6ZWRDaGFubmVsczogc3RyaW5nO1xuICAgIGFkdmljZTogc3RyaW5nO1xuICB9O1xuICBrZXlEaWZmZXJlbmNlc1RvTG9va0Zvcjogc3RyaW5nW107XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQWlTY2FuUmVzdWx0IHtcbiAgYnJhbmRJbmZvOiBCcmFuZElkZW50aWZpY2F0aW9uO1xuICBhdXRoZW50aWNpdHk6IE1lZGlhQXV0aGVudGljaXR5UmVwb3J0O1xuICBjb3VudGVyZmVpdEFzc2Vzc21lbnQ/OiBDb3VudGVyZmVpdEFzc2Vzc21lbnQ7XG59XG5cbi8qKlxuICogT3B0aW1pemVzIGFuIGltYWdlIEZpbGUgaW50byBhIHJlYXNvbmFibHkgc2l6ZWQgSlBFRyBCYXNlNjQgc3RyaW5nIGZvciBmYXN0IEFJIGluZmVyZW5jZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZpbGVUb09wdGltaXplZEJhc2U2NChcbiAgZmlsZTogRmlsZSxcbiAgbWF4RGltID0gMTI4MFxuKTogUHJvbWlzZTx7IGRhdGFVcmw6IHN0cmluZzsgYmFzZTY0OiBzdHJpbmc7IG1pbWVUeXBlOiBzdHJpbmc7IHFyRGF0YTogc3RyaW5nIHwgbnVsbDsgYmFyY29kZURhdGE6IHN0cmluZyB8IG51bGwgfT4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XG4gICAgcmVhZGVyLm9ubG9hZCA9IChlKSA9PiB7XG4gICAgICBjb25zdCBpbWcgPSBuZXcgSW1hZ2UoKTtcbiAgICAgIGltZy5vbmxvYWQgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGxldCB3ID0gaW1nLndpZHRoO1xuICAgICAgICBsZXQgaCA9IGltZy5oZWlnaHQ7XG4gICAgICAgIGlmICh3ID4gbWF4RGltIHx8IGggPiBtYXhEaW0pIHtcbiAgICAgICAgICBjb25zdCByYXRpbyA9IE1hdGgubWluKG1heERpbSAvIHcsIG1heERpbSAvIGgpO1xuICAgICAgICAgIHcgPSBNYXRoLnJvdW5kKHcgKiByYXRpbyk7XG4gICAgICAgICAgaCA9IE1hdGgucm91bmQoaCAqIHJhdGlvKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJjYW52YXNcIik7XG4gICAgICAgIGNhbnZhcy53aWR0aCA9IHc7XG4gICAgICAgIGNhbnZhcy5oZWlnaHQgPSBoO1xuICAgICAgICBjb25zdCBjdHggPSBjYW52YXMuZ2V0Q29udGV4dChcIjJkXCIsIHsgd2lsbFJlYWRGcmVxdWVudGx5OiB0cnVlIH0pO1xuICAgICAgICBpZiAoIWN0eCkge1xuICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZ2V0IDJEIGNhbnZhcyBjb250ZXh0XCIpKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjdHguZHJhd0ltYWdlKGltZywgMCwgMCwgdywgaCk7XG4gICAgICAgIGNvbnN0IGRhdGFVcmwgPSBjYW52YXMudG9EYXRhVVJMKFwiaW1hZ2UvanBlZ1wiLCAwLjg4KTtcbiAgICAgICAgY29uc3QgYmFzZTY0ID0gZGF0YVVybC5zcGxpdChcIixcIilbMV07XG5cbiAgICAgICAgLy8gQXR0ZW1wdCBaWGluZyBCYXJjb2RlICsgUVIgZGVjb2RlXG4gICAgICAgIGxldCBxckRhdGE6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICAgICAgICBsZXQgYmFyY29kZURhdGE6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgenggPSBhd2FpdCBnZXRaeGluZ1JlYWRlcigpO1xuICAgICAgICAgIGlmICh6eCkge1xuICAgICAgICAgICAgY29uc3QgenhSZXMgPSB6eC5kZWNvZGVGcm9tQ2FudmFzKGNhbnZhcyk7XG4gICAgICAgICAgICBpZiAoenhSZXMgJiYgenhSZXMuZ2V0VGV4dCgpKSB7XG4gICAgICAgICAgICAgIGNvbnN0IHRleHQgPSB6eFJlcy5nZXRUZXh0KCk7XG4gICAgICAgICAgICAgIGNvbnN0IGZtdCA9IHp4UmVzLmdldEJhcmNvZGVGb3JtYXQoKTtcbiAgICAgICAgICAgICAgY29uc3QgZm10TmFtZSA9IHR5cGVvZiBmbXQgPT09IFwibnVtYmVyXCIgJiYgWlhJTkdfRk9STUFUX05BTUVTW2ZtdF0gPyBaWElOR19GT1JNQVRfTkFNRVNbZm10XSA6IFwiXCI7XG4gICAgICAgICAgICAgIGlmIChmbXROYW1lLmluY2x1ZGVzKFwicXJcIikpIHtcbiAgICAgICAgICAgICAgICBxckRhdGEgPSB0ZXh0O1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGJhcmNvZGVEYXRhID0gdGV4dDtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgLy8gaWdub3JlIHp4aW5nIGZhaWx1cmVcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghcXJEYXRhICYmICFiYXJjb2RlRGF0YSkge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBpbWFnZURhdGEgPSBjdHguZ2V0SW1hZ2VEYXRhKDAsIDAsIHcsIGgpO1xuICAgICAgICAgICAgY29uc3QgcXIgPSBqc1FSKGltYWdlRGF0YS5kYXRhLCB3LCBoLCB7IGludmVyc2lvbkF0dGVtcHRzOiBcImF0dGVtcHRCb3RoXCIgfSk7XG4gICAgICAgICAgICBpZiAocXI/LmRhdGEpIHFyRGF0YSA9IHFyLmRhdGE7XG4gICAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAvLyBpZ25vcmVcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXNvbHZlKHsgZGF0YVVybCwgYmFzZTY0LCBtaW1lVHlwZTogXCJpbWFnZS9qcGVnXCIsIHFyRGF0YSwgYmFyY29kZURhdGEgfSk7XG4gICAgICB9O1xuICAgICAgaW1nLm9uZXJyb3IgPSAoKSA9PiByZWplY3QobmV3IEVycm9yKFwiVW5hYmxlIHRvIGRlY29kZSBpbWFnZSBmaWxlXCIpKTtcbiAgICAgIGltZy5zcmMgPSBlLnRhcmdldD8ucmVzdWx0IGFzIHN0cmluZztcbiAgICB9O1xuICAgIHJlYWRlci5vbmVycm9yID0gKCkgPT4gcmVqZWN0KG5ldyBFcnJvcihcIlVuYWJsZSB0byByZWFkIGZpbGVcIikpO1xuICAgIHJlYWRlci5yZWFkQXNEYXRhVVJMKGZpbGUpO1xuICB9KTtcbn1cblxuLyoqXG4gKiBFeHRyYWN0cyBhIHJlcHJlc2VudGF0aXZlIGZyYW1lIGZyb20gYW4gdXBsb2FkZWQgdmlkZW8gZmlsZSAoZS5nLiBtcDQsIG1vdiwgd2VibSkuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBleHRyYWN0RnJhbWVGcm9tVmlkZW8oXG4gIHZpZGVvRmlsZTogRmlsZVxuKTogUHJvbWlzZTx7IGRhdGFVcmw6IHN0cmluZzsgYmFzZTY0OiBzdHJpbmc7IG1pbWVUeXBlOiBzdHJpbmc7IHFyRGF0YTogc3RyaW5nIHwgbnVsbDsgYmFyY29kZURhdGE6IHN0cmluZyB8IG51bGwgfT4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIGNvbnN0IHZpZGVvID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInZpZGVvXCIpO1xuICAgIHZpZGVvLnByZWxvYWQgPSBcImF1dG9cIjtcbiAgICB2aWRlby5tdXRlZCA9IHRydWU7XG4gICAgdmlkZW8ucGxheXNJbmxpbmUgPSB0cnVlO1xuICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwodmlkZW9GaWxlKTtcbiAgICB2aWRlby5zcmMgPSB1cmw7XG5cbiAgICBjb25zdCBjbGVhbnVwID0gKCkgPT4gVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpO1xuXG4gICAgdmlkZW8ub25sb2FkZWRtZXRhZGF0YSA9ICgpID0+IHtcbiAgICAgIC8vIFNlZWsgdG8gMXMgb3IgMjUlIG9mIGR1cmF0aW9uXG4gICAgICB2aWRlby5jdXJyZW50VGltZSA9IE1hdGgubWluKDEuMCwgdmlkZW8uZHVyYXRpb24gPiAwID8gdmlkZW8uZHVyYXRpb24gLyA0IDogMC41KTtcbiAgICB9O1xuXG4gICAgdmlkZW8ub25zZWVrZWQgPSBhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBtYXhEaW0gPSAxMjgwO1xuICAgICAgICBsZXQgdyA9IHZpZGVvLnZpZGVvV2lkdGggfHwgNjQwO1xuICAgICAgICBsZXQgaCA9IHZpZGVvLnZpZGVvSGVpZ2h0IHx8IDQ4MDtcbiAgICAgICAgaWYgKHcgPiBtYXhEaW0gfHwgaCA+IG1heERpbSkge1xuICAgICAgICAgIGNvbnN0IHJhdGlvID0gTWF0aC5taW4obWF4RGltIC8gdywgbWF4RGltIC8gaCk7XG4gICAgICAgICAgdyA9IE1hdGgucm91bmQodyAqIHJhdGlvKTtcbiAgICAgICAgICBoID0gTWF0aC5yb3VuZChoICogcmF0aW8pO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgY2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImNhbnZhc1wiKTtcbiAgICAgICAgY2FudmFzLndpZHRoID0gdztcbiAgICAgICAgY2FudmFzLmhlaWdodCA9IGg7XG4gICAgICAgIGNvbnN0IGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KFwiMmRcIiwgeyB3aWxsUmVhZEZyZXF1ZW50bHk6IHRydWUgfSk7XG4gICAgICAgIGlmICghY3R4KSB0aHJvdyBuZXcgRXJyb3IoXCJDb3VsZCBub3QgY3JlYXRlIGNhbnZhcyBjb250ZXh0XCIpO1xuICAgICAgICBjdHguZHJhd0ltYWdlKHZpZGVvLCAwLCAwLCB3LCBoKTtcbiAgICAgICAgY29uc3QgZGF0YVVybCA9IGNhbnZhcy50b0RhdGFVUkwoXCJpbWFnZS9qcGVnXCIsIDAuODgpO1xuICAgICAgICBjb25zdCBiYXNlNjQgPSBkYXRhVXJsLnNwbGl0KFwiLFwiKVsxXTtcblxuICAgICAgICBsZXQgcXJEYXRhOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgICAgICAgbGV0IGJhcmNvZGVEYXRhOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHp4ID0gYXdhaXQgZ2V0WnhpbmdSZWFkZXIoKTtcbiAgICAgICAgICBpZiAoengpIHtcbiAgICAgICAgICAgIGNvbnN0IHp4UmVzID0genguZGVjb2RlRnJvbUNhbnZhcyhjYW52YXMpO1xuICAgICAgICAgICAgaWYgKHp4UmVzICYmIHp4UmVzLmdldFRleHQoKSkge1xuICAgICAgICAgICAgICBjb25zdCB0ZXh0ID0genhSZXMuZ2V0VGV4dCgpO1xuICAgICAgICAgICAgICBjb25zdCBmbXQgPSB6eFJlcy5nZXRCYXJjb2RlRm9ybWF0KCk7XG4gICAgICAgICAgICAgIGNvbnN0IGZtdE5hbWUgPSB0eXBlb2YgZm10ID09PSBcIm51bWJlclwiICYmIFpYSU5HX0ZPUk1BVF9OQU1FU1tmbXRdID8gWlhJTkdfRk9STUFUX05BTUVTW2ZtdF0gOiBcIlwiO1xuICAgICAgICAgICAgICBpZiAoZm10TmFtZS5pbmNsdWRlcyhcInFyXCIpKSB7XG4gICAgICAgICAgICAgICAgcXJEYXRhID0gdGV4dDtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBiYXJjb2RlRGF0YSA9IHRleHQ7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8vIGlnbm9yZVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCFxckRhdGEgJiYgIWJhcmNvZGVEYXRhKSB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGltZ0RhdGEgPSBjdHguZ2V0SW1hZ2VEYXRhKDAsIDAsIHcsIGgpO1xuICAgICAgICAgICAgY29uc3QgcXIgPSBqc1FSKGltZ0RhdGEuZGF0YSwgdywgaCwgeyBpbnZlcnNpb25BdHRlbXB0czogXCJhdHRlbXB0Qm90aFwiIH0pO1xuICAgICAgICAgICAgaWYgKHFyPy5kYXRhKSBxckRhdGEgPSBxci5kYXRhO1xuICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgLy8gaWdub3JlXG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgY2xlYW51cCgpO1xuICAgICAgICByZXNvbHZlKHsgZGF0YVVybCwgYmFzZTY0LCBtaW1lVHlwZTogXCJpbWFnZS9qcGVnXCIsIHFyRGF0YSwgYmFyY29kZURhdGEgfSk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgY2xlYW51cCgpO1xuICAgICAgICByZWplY3QoZXJyKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgdmlkZW8ub25lcnJvciA9ICgpID0+IHtcbiAgICAgIGNsZWFudXAoKTtcbiAgICAgIHJlamVjdChuZXcgRXJyb3IoXCJVbmFibGUgdG8gcHJvY2VzcyB2aWRlbyBmcmFtZVwiKSk7XG4gICAgfTtcbiAgfSk7XG59XG5cbi8vIFJldXNhYmxlIG9mZmxpbmUgY2FudmFzIGZvciB2aWRlbyBmcmFtZSBleHRyYWN0aW9uXG5sZXQgcHJvY2Vzc2luZ0NhbnZhczogSFRNTENhbnZhc0VsZW1lbnQgfCBudWxsID0gbnVsbDtcbmxldCBjcm9wcGVkQ2FudmFzOiBIVE1MQ2FudmFzRWxlbWVudCB8IG51bGwgPSBudWxsO1xuXG4vKipcbiAqIFNjYW5zIGEgY2FudmFzIGVsZW1lbnQgZm9yIFFSIGNvZGVzIGluIHJlYWwtdGltZSAoZS5nLiBmcm9tIGNhbWVyYSBmZWVkKS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNjYW5RckZyb21DYW52YXMoY2FudmFzOiBIVE1MQ2FudmFzRWxlbWVudCk6IHN0cmluZyB8IG51bGwge1xuICB0cnkge1xuICAgIGNvbnN0IGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KFwiMmRcIiwgeyB3aWxsUmVhZEZyZXF1ZW50bHk6IHRydWUgfSk7XG4gICAgaWYgKCFjdHgpIHJldHVybiBudWxsO1xuICAgIGNvbnN0IGltZ0RhdGEgPSBjdHguZ2V0SW1hZ2VEYXRhKDAsIDAsIGNhbnZhcy53aWR0aCwgY2FudmFzLmhlaWdodCk7XG4gICAgY29uc3QgY29kZSA9IGpzUVIoaW1nRGF0YS5kYXRhLCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQsIHtcbiAgICAgIGludmVyc2lvbkF0dGVtcHRzOiBcImF0dGVtcHRCb3RoXCIsXG4gICAgfSk7XG4gICAgcmV0dXJuIGNvZGU/LmRhdGEgPz8gbnVsbDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuLyoqXG4gKiBTY2FucyBhIGNhbnZhcyBvciBpbWFnZSBzb3VyY2UgZm9yIEJhcmNvZGVzIChVUEMtQSwgRUFOLTEzLCBDb2RlLTEyOCwgZXRjLikgYW5kIFFSIGNvZGVzLlxuICogVXNlcyBuYXRpdmUgQmFyY29kZURldGVjdG9yIHdoZW4gYXZhaWxhYmxlLCB3aXRoIGRlZXAgZmFsbGJhY2sgdG8gWlhpbmcgbXVsdGktZm9ybWF0IHJlYWRlciBhbmQganNRUi5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRldGVjdEJhcmNvZGVPclFyKFxuICBzb3VyY2U6IEhUTUxWaWRlb0VsZW1lbnQgfCBIVE1MQ2FudmFzRWxlbWVudCB8IEltYWdlQml0bWFwXG4pOiBQcm9taXNlPHsgZm9ybWF0OiBzdHJpbmc7IHJhd1ZhbHVlOiBzdHJpbmcgfSB8IG51bGw+IHtcbiAgLy8gMS4gVHJ5IG5hdGl2ZSBCYXJjb2RlRGV0ZWN0b3IgaWYgYXZhaWxhYmxlXG4gIGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIFwiQmFyY29kZURldGVjdG9yXCIgaW4gd2luZG93KSB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgQmFyY29kZURldGVjdG9yIGJyb3dzZXIgZXhwZXJpbWVudGFsIEFQSVxuICAgICAgY29uc3QgZGV0ZWN0b3IgPSBuZXcgd2luZG93LkJhcmNvZGVEZXRlY3Rvcih7XG4gICAgICAgIGZvcm1hdHM6IFtcbiAgICAgICAgICBcInFyX2NvZGVcIixcbiAgICAgICAgICBcImVhbl8xM1wiLFxuICAgICAgICAgIFwiZWFuXzhcIixcbiAgICAgICAgICBcInVwY19hXCIsXG4gICAgICAgICAgXCJ1cGNfZVwiLFxuICAgICAgICAgIFwiY29kZV8xMjhcIixcbiAgICAgICAgICBcImNvZGVfMzlcIixcbiAgICAgICAgICBcImNvZGVfOTNcIixcbiAgICAgICAgICBcIml0ZlwiLFxuICAgICAgICAgIFwiZGF0YV9tYXRyaXhcIixcbiAgICAgICAgXSxcbiAgICAgIH0pO1xuICAgICAgY29uc3QgYmFyY29kZXMgPSBhd2FpdCBkZXRlY3Rvci5kZXRlY3Qoc291cmNlKTtcbiAgICAgIGlmIChiYXJjb2RlcyAmJiBiYXJjb2Rlcy5sZW5ndGggPiAwICYmIGJhcmNvZGVzWzBdLnJhd1ZhbHVlKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgZm9ybWF0OiBiYXJjb2Rlc1swXS5mb3JtYXQgfHwgXCJiYXJjb2RlXCIsXG4gICAgICAgICAgcmF3VmFsdWU6IGJhcmNvZGVzWzBdLnJhd1ZhbHVlLFxuICAgICAgICB9O1xuICAgICAgfVxuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gRmFsbGJhY2sgdG8gWlhpbmcgYmVsb3dcbiAgICB9XG4gIH1cblxuICAvLyAyLiBGYWxsYmFjayB0byBaWGluZyBNdWx0aUZvcm1hdCBSZWFkZXIgKGhhbmRsZXMgMUQgYmFyY29kZXMgbGlrZSBDb2NhIENvbGEgVVBDLUEvRUFOLTEzIGV2ZXJ5d2hlcmUpXG4gIHRyeSB7XG4gICAgY29uc3QgcmVhZGVyID0gYXdhaXQgZ2V0WnhpbmdSZWFkZXIoKTtcbiAgICBpZiAocmVhZGVyKSB7XG4gICAgICBsZXQgdGFyZ2V0Q2FudmFzOiBIVE1MQ2FudmFzRWxlbWVudCB8IG51bGwgPSBudWxsO1xuXG4gICAgICBpZiAoc291cmNlIGluc3RhbmNlb2YgSFRNTENhbnZhc0VsZW1lbnQpIHtcbiAgICAgICAgdGFyZ2V0Q2FudmFzID0gc291cmNlO1xuICAgICAgfSBlbHNlIGlmIChzb3VyY2UgaW5zdGFuY2VvZiBIVE1MVmlkZW9FbGVtZW50ICYmIHNvdXJjZS52aWRlb1dpZHRoID4gMCAmJiBzb3VyY2UudmlkZW9IZWlnaHQgPiAwKSB7XG4gICAgICAgIGlmICghcHJvY2Vzc2luZ0NhbnZhcykge1xuICAgICAgICAgIHByb2Nlc3NpbmdDYW52YXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiY2FudmFzXCIpO1xuICAgICAgICB9XG4gICAgICAgIHByb2Nlc3NpbmdDYW52YXMud2lkdGggPSBzb3VyY2UudmlkZW9XaWR0aDtcbiAgICAgICAgcHJvY2Vzc2luZ0NhbnZhcy5oZWlnaHQgPSBzb3VyY2UudmlkZW9IZWlnaHQ7XG4gICAgICAgIGNvbnN0IHBDdHggPSBwcm9jZXNzaW5nQ2FudmFzLmdldENvbnRleHQoXCIyZFwiLCB7IHdpbGxSZWFkRnJlcXVlbnRseTogdHJ1ZSB9KTtcbiAgICAgICAgaWYgKHBDdHgpIHtcbiAgICAgICAgICBwQ3R4LmRyYXdJbWFnZShzb3VyY2UsIDAsIDAsIHNvdXJjZS52aWRlb1dpZHRoLCBzb3VyY2UudmlkZW9IZWlnaHQpO1xuICAgICAgICAgIHRhcmdldENhbnZhcyA9IHByb2Nlc3NpbmdDYW52YXM7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKHRhcmdldENhbnZhcykge1xuICAgICAgICAvLyBBdHRlbXB0IGZ1bGwgZnJhbWUgc2NhblxuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHp4UmVzdWx0ID0gcmVhZGVyLmRlY29kZUZyb21DYW52YXModGFyZ2V0Q2FudmFzKTtcbiAgICAgICAgICBpZiAoenhSZXN1bHQgJiYgenhSZXN1bHQuZ2V0VGV4dCgpKSB7XG4gICAgICAgICAgICBjb25zdCByYXcgPSB6eFJlc3VsdC5nZXRUZXh0KCk7XG4gICAgICAgICAgICBjb25zdCBmb3JtYXROdW0gPSB6eFJlc3VsdC5nZXRCYXJjb2RlRm9ybWF0KCk7XG4gICAgICAgICAgICBjb25zdCBmb3JtYXRTdHIgPSAodHlwZW9mIGZvcm1hdE51bSA9PT0gXCJudW1iZXJcIiAmJiBaWElOR19GT1JNQVRfTkFNRVNbZm9ybWF0TnVtXSlcbiAgICAgICAgICAgICAgPyBaWElOR19GT1JNQVRfTkFNRVNbZm9ybWF0TnVtXVxuICAgICAgICAgICAgICA6IFwiYmFyY29kZVwiO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgZm9ybWF0OiBmb3JtYXRTdHIsXG4gICAgICAgICAgICAgIHJhd1ZhbHVlOiByYXcsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgLy8gSWYgZnVsbCBmcmFtZSBmYWlsZWQsIHRyeSBjZW50ZXIgY3JvcCByZXRpY2xlIChpZGVhbCBmb3IgY3VydmVkIGJvdHRsZXMgLyBjbG9zZXVwcylcbiAgICAgICAgICBjb25zdCBjdyA9IHRhcmdldENhbnZhcy53aWR0aDtcbiAgICAgICAgICBjb25zdCBjaCA9IHRhcmdldENhbnZhcy5oZWlnaHQ7XG4gICAgICAgICAgY29uc3QgY3JvcFcgPSBNYXRoLnJvdW5kKGN3ICogMC43KTtcbiAgICAgICAgICBjb25zdCBjcm9wSCA9IE1hdGgucm91bmQoY2ggKiAwLjQ1KTtcbiAgICAgICAgICBjb25zdCBjcm9wWCA9IE1hdGgucm91bmQoKGN3IC0gY3JvcFcpIC8gMik7XG4gICAgICAgICAgY29uc3QgY3JvcFkgPSBNYXRoLnJvdW5kKChjaCAtIGNyb3BIKSAvIDIpO1xuXG4gICAgICAgICAgaWYgKCFjcm9wcGVkQ2FudmFzKSB7XG4gICAgICAgICAgICBjcm9wcGVkQ2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImNhbnZhc1wiKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY3JvcHBlZENhbnZhcy53aWR0aCA9IGNyb3BXO1xuICAgICAgICAgIGNyb3BwZWRDYW52YXMuaGVpZ2h0ID0gY3JvcEg7XG4gICAgICAgICAgY29uc3QgY0N0eCA9IGNyb3BwZWRDYW52YXMuZ2V0Q29udGV4dChcIjJkXCIsIHsgd2lsbFJlYWRGcmVxdWVudGx5OiB0cnVlIH0pO1xuICAgICAgICAgIGlmIChjQ3R4KSB7XG4gICAgICAgICAgICBjQ3R4LmRyYXdJbWFnZSh0YXJnZXRDYW52YXMsIGNyb3BYLCBjcm9wWSwgY3JvcFcsIGNyb3BILCAwLCAwLCBjcm9wVywgY3JvcEgpO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgY29uc3QgY3JvcFJlc3VsdCA9IHJlYWRlci5kZWNvZGVGcm9tQ2FudmFzKGNyb3BwZWRDYW52YXMpO1xuICAgICAgICAgICAgICBpZiAoY3JvcFJlc3VsdCAmJiBjcm9wUmVzdWx0LmdldFRleHQoKSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJhdyA9IGNyb3BSZXN1bHQuZ2V0VGV4dCgpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGZvcm1hdE51bSA9IGNyb3BSZXN1bHQuZ2V0QmFyY29kZUZvcm1hdCgpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGZvcm1hdFN0ciA9ICh0eXBlb2YgZm9ybWF0TnVtID09PSBcIm51bWJlclwiICYmIFpYSU5HX0ZPUk1BVF9OQU1FU1tmb3JtYXROdW1dKVxuICAgICAgICAgICAgICAgICAgPyBaWElOR19GT1JNQVRfTkFNRVNbZm9ybWF0TnVtXVxuICAgICAgICAgICAgICAgICAgOiBcImJhcmNvZGVcIjtcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgZm9ybWF0OiBmb3JtYXRTdHIsXG4gICAgICAgICAgICAgICAgICByYXdWYWx1ZTogcmF3LFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgICAvLyBOb3QgZGV0ZWN0ZWQgaW4gY3JvcCwgdHJ5IDkwLWRlZ3JlZSByb3RhdGlvbiAoY29tbW9uIG9uIHZlcnRpY2FsIGJvdHRsZSBiYXJjb2RlcylcbiAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCByb3RDYW52YXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiY2FudmFzXCIpO1xuICAgICAgICAgICAgICAgIHJvdENhbnZhcy53aWR0aCA9IGNyb3BIO1xuICAgICAgICAgICAgICAgIHJvdENhbnZhcy5oZWlnaHQgPSBjcm9wVztcbiAgICAgICAgICAgICAgICBjb25zdCByQ3R4ID0gcm90Q2FudmFzLmdldENvbnRleHQoXCIyZFwiLCB7IHdpbGxSZWFkRnJlcXVlbnRseTogdHJ1ZSB9KTtcbiAgICAgICAgICAgICAgICBpZiAockN0eCkge1xuICAgICAgICAgICAgICAgICAgckN0eC50cmFuc2xhdGUoY3JvcEggLyAyLCBjcm9wVyAvIDIpO1xuICAgICAgICAgICAgICAgICAgckN0eC5yb3RhdGUoKDkwICogTWF0aC5QSSkgLyAxODApO1xuICAgICAgICAgICAgICAgICAgckN0eC5kcmF3SW1hZ2UoY3JvcHBlZENhbnZhcywgLWNyb3BXIC8gMiwgLWNyb3BIIC8gMik7XG4gICAgICAgICAgICAgICAgICBjb25zdCByb3RSZXN1bHQgPSByZWFkZXIuZGVjb2RlRnJvbUNhbnZhcyhyb3RDYW52YXMpO1xuICAgICAgICAgICAgICAgICAgaWYgKHJvdFJlc3VsdCAmJiByb3RSZXN1bHQuZ2V0VGV4dCgpKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJhdyA9IHJvdFJlc3VsdC5nZXRUZXh0KCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZvcm1hdE51bSA9IHJvdFJlc3VsdC5nZXRCYXJjb2RlRm9ybWF0KCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZvcm1hdFN0ciA9ICh0eXBlb2YgZm9ybWF0TnVtID09PSBcIm51bWJlclwiICYmIFpYSU5HX0ZPUk1BVF9OQU1FU1tmb3JtYXROdW1dKVxuICAgICAgICAgICAgICAgICAgICAgID8gWlhJTkdfRk9STUFUX05BTUVTW2Zvcm1hdE51bV1cbiAgICAgICAgICAgICAgICAgICAgICA6IFwiYmFyY29kZVwiO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgIGZvcm1hdDogZm9ybWF0U3RyLFxuICAgICAgICAgICAgICAgICAgICAgIHJhd1ZhbHVlOiByYXcsXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgICAgICAvLyBSb3RhdGlvbiBhdHRlbXB0IGZhaWxlZFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9IGNhdGNoIHtcbiAgICAvLyBaWGluZyBmYWxsYmFjayBlcnJvciBpZ25vcmVkXG4gIH1cblxuICAvLyAzLiBGYWxsYmFjayB0byBqc1FSIGlmIHNvdXJjZSBpcyBhIGNhbnZhcyBvciBjYXB0dXJlZCB2aWRlb1xuICBpZiAoc291cmNlIGluc3RhbmNlb2YgSFRNTENhbnZhc0VsZW1lbnQpIHtcbiAgICBjb25zdCBxciA9IHNjYW5RckZyb21DYW52YXMoc291cmNlKTtcbiAgICBpZiAocXIpIHtcbiAgICAgIHJldHVybiB7IGZvcm1hdDogXCJxcl9jb2RlXCIsIHJhd1ZhbHVlOiBxciB9O1xuICAgIH1cbiAgfSBlbHNlIGlmIChwcm9jZXNzaW5nQ2FudmFzKSB7XG4gICAgY29uc3QgcXIgPSBzY2FuUXJGcm9tQ2FudmFzKHByb2Nlc3NpbmdDYW52YXMpO1xuICAgIGlmIChxcikge1xuICAgICAgcmV0dXJuIHsgZm9ybWF0OiBcInFyX2NvZGVcIiwgcmF3VmFsdWU6IHFyIH07XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8qKlxuICogUmVzb2x2ZXMgR1MxIHByZWZpeCBjb3VudHJ5L3JlZ2lvbiBmb3IgMUQgVVBDL0VBTiBiYXJjb2Rlcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldEdzMUNvdW50cnlQcmVmaXgoYmFyY29kZTogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gIGNvbnN0IGRpZ2l0cyA9IGJhcmNvZGUucmVwbGFjZSgvXFxEL2csIFwiXCIpO1xuICBpZiAoZGlnaXRzLmxlbmd0aCA8IDMpIHJldHVybiBudWxsO1xuICBjb25zdCBwcmVmaXgzID0gcGFyc2VJbnQoZGlnaXRzLnNsaWNlKDAsIDMpLCAxMCk7XG4gIGNvbnN0IHByZWZpeDIgPSBwYXJzZUludChkaWdpdHMuc2xpY2UoMCwgMiksIDEwKTtcblxuICBpZiAocHJlZml4MyA+PSAwICYmIHByZWZpeDMgPD0gMTkpIHJldHVybiBcIlVuaXRlZCBTdGF0ZXMgJiBDYW5hZGEgKFVQQy1BKVwiO1xuICBpZiAocHJlZml4MyA+PSAzMCAmJiBwcmVmaXgzIDw9IDM5KSByZXR1cm4gXCJVbml0ZWQgU3RhdGVzIChEcnVncyAvIEhlYWx0aGNhcmUpXCI7XG4gIGlmIChwcmVmaXgzID49IDQwICYmIHByZWZpeDMgPD0gNDkpIHJldHVybiBcIlJlc3RyaWN0ZWQgSW50ZXJuYWwgRGlzdHJpYnV0aW9uXCI7XG4gIGlmIChwcmVmaXgzID49IDUwICYmIHByZWZpeDMgPD0gNTkpIHJldHVybiBcIkNvdXBvbnMgJiBMb3lhbHR5XCI7XG4gIGlmIChwcmVmaXgzID49IDEwMCAmJiBwcmVmaXgzIDw9IDEzOSkgcmV0dXJuIFwiVW5pdGVkIFN0YXRlc1wiO1xuICBpZiAocHJlZml4MyA+PSAzMDAgJiYgcHJlZml4MyA8PSAzNzkpIHJldHVybiBcIkZyYW5jZSAmIE1vbmFjb1wiO1xuICBpZiAocHJlZml4MyA+PSAzODAgJiYgcHJlZml4MyA8PSAzODApIHJldHVybiBcIkJ1bGdhcmlhXCI7XG4gIGlmIChwcmVmaXgzID49IDM4MyAmJiBwcmVmaXgzIDw9IDM4MykgcmV0dXJuIFwiU2xvdmVuaWFcIjtcbiAgaWYgKHByZWZpeDMgPj0gMzg1ICYmIHByZWZpeDMgPD0gMzg1KSByZXR1cm4gXCJDcm9hdGlhXCI7XG4gIGlmIChwcmVmaXgzID49IDQwMCAmJiBwcmVmaXgzIDw9IDQ0MCkgcmV0dXJuIFwiR2VybWFueVwiO1xuICBpZiAocHJlZml4MyA+PSA0NTAgJiYgcHJlZml4MyA8PSA0NTkpIHJldHVybiBcIkphcGFuIChKQU4pXCI7XG4gIGlmIChwcmVmaXgzID49IDQ2MCAmJiBwcmVmaXgzIDw9IDQ2OSkgcmV0dXJuIFwiUnVzc2lhXCI7XG4gIGlmIChwcmVmaXgzID49IDQ3MSAmJiBwcmVmaXgzIDw9IDQ3MSkgcmV0dXJuIFwiVGFpd2FuXCI7XG4gIGlmIChwcmVmaXgzID49IDQ4MCAmJiBwcmVmaXgzIDw9IDQ4MCkgcmV0dXJuIFwiUGhpbGlwcGluZXNcIjtcbiAgaWYgKHByZWZpeDMgPj0gNDg5ICYmIHByZWZpeDMgPD0gNDg5KSByZXR1cm4gXCJIb25nIEtvbmdcIjtcbiAgaWYgKHByZWZpeDMgPj0gNDkwICYmIHByZWZpeDMgPD0gNDk5KSByZXR1cm4gXCJKYXBhbiAoSkFOKVwiO1xuICBpZiAocHJlZml4MyA+PSA1MDAgJiYgcHJlZml4MyA8PSA1MDkpIHJldHVybiBcIlVuaXRlZCBLaW5nZG9tXCI7XG4gIGlmIChwcmVmaXgzID49IDUyMCAmJiBwcmVmaXgzIDw9IDUyMSkgcmV0dXJuIFwiR3JlZWNlXCI7XG4gIGlmIChwcmVmaXgzID49IDUzMSAmJiBwcmVmaXgzIDw9IDUzMSkgcmV0dXJuIFwiTm9ydGggTWFjZWRvbmlhXCI7XG4gIGlmIChwcmVmaXgzID49IDUzNSAmJiBwcmVmaXgzIDw9IDUzNSkgcmV0dXJuIFwiTWFsdGFcIjtcbiAgaWYgKHByZWZpeDMgPj0gNTM5ICYmIHByZWZpeDMgPD0gNTM5KSByZXR1cm4gXCJJcmVsYW5kXCI7XG4gIGlmIChwcmVmaXgzID49IDU0MCAmJiBwcmVmaXgzIDw9IDU0OSkgcmV0dXJuIFwiQmVsZ2l1bSAmIEx1eGVtYm91cmdcIjtcbiAgaWYgKHByZWZpeDMgPj0gNTYwICYmIHByZWZpeDMgPD0gNTYwKSByZXR1cm4gXCJQb3J0dWdhbFwiO1xuICBpZiAocHJlZml4MyA+PSA1NjkgJiYgcHJlZml4MyA8PSA1NjkpIHJldHVybiBcIkljZWxhbmRcIjtcbiAgaWYgKHByZWZpeDMgPj0gNTcwICYmIHByZWZpeDMgPD0gNTc5KSByZXR1cm4gXCJEZW5tYXJrLCBGYXJvZSAmIEdyZWVubGFuZFwiO1xuICBpZiAocHJlZml4MyA+PSA1OTAgJiYgcHJlZml4MyA8PSA1OTApIHJldHVybiBcIlBvbGFuZFwiO1xuICBpZiAocHJlZml4MyA+PSA1OTQgJiYgcHJlZml4MyA8PSA1OTQpIHJldHVybiBcIlJvbWFuaWFcIjtcbiAgaWYgKHByZWZpeDMgPj0gNTk5ICYmIHByZWZpeDMgPD0gNTk5KSByZXR1cm4gXCJIdW5nYXJ5XCI7XG4gIGlmIChwcmVmaXgzID49IDYwMCAmJiBwcmVmaXgzIDw9IDYwMSkgcmV0dXJuIFwiU291dGggQWZyaWNhXCI7XG4gIGlmIChwcmVmaXgzID49IDYxMSAmJiBwcmVmaXgzIDw9IDYxMSkgcmV0dXJuIFwiTW9yb2Njb1wiO1xuICBpZiAocHJlZml4MyA+PSA2MTkgJiYgcHJlZml4MyA8PSA2MTkpIHJldHVybiBcIlR1bmlzaWFcIjtcbiAgaWYgKHByZWZpeDMgPj0gNjIyICYmIHByZWZpeDMgPD0gNjIyKSByZXR1cm4gXCJFZ3lwdFwiO1xuICBpZiAocHJlZml4MyA+PSA2NDAgJiYgcHJlZml4MyA8PSA2NDkpIHJldHVybiBcIkZpbmxhbmRcIjtcbiAgaWYgKHByZWZpeDMgPj0gNjkwICYmIHByZWZpeDMgPD0gNjk5KSByZXR1cm4gXCJDaGluYVwiO1xuICBpZiAocHJlZml4MyA+PSA3MDAgJiYgcHJlZml4MyA8PSA3MDkpIHJldHVybiBcIk5vcndheVwiO1xuICBpZiAocHJlZml4MyA+PSA3MzAgJiYgcHJlZml4MyA8PSA3MzkpIHJldHVybiBcIlN3ZWRlblwiO1xuICBpZiAocHJlZml4MyA+PSA3NTAgJiYgcHJlZml4MyA8PSA3NTApIHJldHVybiBcIk1leGljb1wiO1xuICBpZiAocHJlZml4MyA+PSA3NjAgJiYgcHJlZml4MyA8PSA3NjkpIHJldHVybiBcIlN3aXR6ZXJsYW5kICYgTGllY2h0ZW5zdGVpblwiO1xuICBpZiAocHJlZml4MyA+PSA3NzAgJiYgcHJlZml4MyA8PSA3NzEpIHJldHVybiBcIkNvbG9tYmlhXCI7XG4gIGlmIChwcmVmaXgzID49IDc3MyAmJiBwcmVmaXgzIDw9IDc3MykgcmV0dXJuIFwiVXJ1Z3VheVwiO1xuICBpZiAocHJlZml4MyA+PSA3NzUgJiYgcHJlZml4MyA8PSA3NzUpIHJldHVybiBcIlBlcnVcIjtcbiAgaWYgKHByZWZpeDMgPj0gNzc5ICYmIHByZWZpeDMgPD0gNzc5KSByZXR1cm4gXCJBcmdlbnRpbmFcIjtcbiAgaWYgKHByZWZpeDMgPj0gNzgwICYmIHByZWZpeDMgPD0gNzgwKSByZXR1cm4gXCJDaGlsZVwiO1xuICBpZiAocHJlZml4MyA+PSA3ODkgJiYgcHJlZml4MyA8PSA3OTApIHJldHVybiBcIkJyYXppbFwiO1xuICBpZiAocHJlZml4MyA+PSA4MDAgJiYgcHJlZml4MyA8PSA4MzkpIHJldHVybiBcIkl0YWx5LCBTYW4gTWFyaW5vICYgVmF0aWNhblwiO1xuICBpZiAocHJlZml4MyA+PSA4NDAgJiYgcHJlZml4MyA8PSA4NDkpIHJldHVybiBcIlNwYWluXCI7XG4gIGlmIChwcmVmaXgzID49IDg2MCAmJiBwcmVmaXgzIDw9IDg2MCkgcmV0dXJuIFwiU2VyYmlhXCI7XG4gIGlmIChwcmVmaXgzID49IDg2OCAmJiBwcmVmaXgzIDw9IDg2OSkgcmV0dXJuIFwiVHVya2V5XCI7XG4gIGlmIChwcmVmaXgzID49IDg3MCAmJiBwcmVmaXgzIDw9IDg3OSkgcmV0dXJuIFwiTmV0aGVybGFuZHNcIjtcbiAgaWYgKHByZWZpeDMgPj0gODgwICYmIHByZWZpeDMgPD0gODgwKSByZXR1cm4gXCJTb3V0aCBLb3JlYVwiO1xuICBpZiAocHJlZml4MyA+PSA4ODUgJiYgcHJlZml4MyA8PSA4ODUpIHJldHVybiBcIlRoYWlsYW5kXCI7XG4gIGlmIChwcmVmaXgzID49IDg4OCAmJiBwcmVmaXgzIDw9IDg4OCkgcmV0dXJuIFwiU2luZ2Fwb3JlXCI7XG4gIGlmIChwcmVmaXgzID49IDg5MCAmJiBwcmVmaXgzIDw9IDg5MCkgcmV0dXJuIFwiSW5kaWFcIjtcbiAgaWYgKHByZWZpeDMgPj0gODkzICYmIHByZWZpeDMgPD0gODkzKSByZXR1cm4gXCJWaWV0bmFtXCI7XG4gIGlmIChwcmVmaXgzID49IDg5OSAmJiBwcmVmaXgzIDw9IDg5OSkgcmV0dXJuIFwiSW5kb25lc2lhXCI7XG4gIGlmIChwcmVmaXgzID49IDkwMCAmJiBwcmVmaXgzIDw9IDkxOSkgcmV0dXJuIFwiQXVzdHJpYVwiO1xuICBpZiAocHJlZml4MyA+PSA5MzAgJiYgcHJlZml4MyA8PSA5MzkpIHJldHVybiBcIkF1c3RyYWxpYVwiO1xuICBpZiAocHJlZml4MyA+PSA5NDAgJiYgcHJlZml4MyA8PSA5NDkpIHJldHVybiBcIk5ldyBaZWFsYW5kXCI7XG4gIGlmIChwcmVmaXgzID49IDk1NSAmJiBwcmVmaXgzIDw9IDk1NSkgcmV0dXJuIFwiTWFsYXlzaWFcIjtcblxuICByZXR1cm4gbnVsbDtcbn1cblxuLyoqXG4gKiBTeW50aGVzaXplcyBhIGZ1dHVyaXN0aWMgY29uZmlybWF0aW9uIGNoaW1lIHVzaW5nIFdlYiBBdWRpbyBBUEkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwbGF5U2NhbkNoaW1lKCkge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuO1xuICB0cnkge1xuICAgIGNvbnN0IEF1ZGlvQ3R4ID0gd2luZG93LkF1ZGlvQ29udGV4dCB8fCAod2luZG93IGFzIGFueSkud2Via2l0QXVkaW9Db250ZXh0O1xuICAgIGlmICghQXVkaW9DdHgpIHJldHVybjtcbiAgICBjb25zdCBjdHggPSBuZXcgQXVkaW9DdHgoKTtcbiAgICBjb25zdCBvc2MgPSBjdHguY3JlYXRlT3NjaWxsYXRvcigpO1xuICAgIGNvbnN0IGdhaW4gPSBjdHguY3JlYXRlR2FpbigpO1xuXG4gICAgb3NjLnR5cGUgPSBcInNpbmVcIjtcbiAgICBvc2MuZnJlcXVlbmN5LnNldFZhbHVlQXRUaW1lKDg4MCwgY3R4LmN1cnJlbnRUaW1lKTsgLy8gQTVcbiAgICBvc2MuZnJlcXVlbmN5LmV4cG9uZW50aWFsUmFtcFRvVmFsdWVBdFRpbWUoMTc2MCwgY3R4LmN1cnJlbnRUaW1lICsgMC4xMik7IC8vIEE2XG5cbiAgICBnYWluLmdhaW4uc2V0VmFsdWVBdFRpbWUoMC4xNSwgY3R4LmN1cnJlbnRUaW1lKTtcbiAgICBnYWluLmdhaW4uZXhwb25lbnRpYWxSYW1wVG9WYWx1ZUF0VGltZSgwLjAwMSwgY3R4LmN1cnJlbnRUaW1lICsgMC4yNSk7XG5cbiAgICBvc2MuY29ubmVjdChnYWluKTtcbiAgICBnYWluLmNvbm5lY3QoY3R4LmRlc3RpbmF0aW9uKTtcblxuICAgIG9zYy5zdGFydCgpO1xuICAgIG9zYy5zdG9wKGN0eC5jdXJyZW50VGltZSArIDAuMjUpO1xuICB9IGNhdGNoIHtcbiAgICAvLyBBdWRpbyBjb250ZXh0IG1heSBiZSByZXN0cmljdGVkIGJlZm9yZSBpbnRlcmFjdGlvblxuICB9XG59XG5cbi8qKlxuICogQ2FsbHMgb3VyIHNlcnZlci1zaWRlIEdlbWluaSBBSSBTY2FuIGVuZHBvaW50LlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcnVuQWlTY2FuKHBhcmFtczoge1xuICBpbWFnZT86IHN0cmluZzsgLy8gYmFzZTY0XG4gIG1pbWVUeXBlPzogc3RyaW5nO1xuICBxckRhdGE/OiBzdHJpbmc7XG4gIGJhcmNvZGU/OiBzdHJpbmc7XG4gIGluc3BlY3Rpb25Nb2RlPzogXCJiYXJjb2RlXCIgfCBcImxvZ29cIiB8IFwiZnVsbF9wcm9kdWN0XCIgfCBcImdlbmVyYWxcIjtcbiAgbWVkaWFUeXBlPzogXCJpbWFnZVwiIHwgXCJ2aWRlb19mcmFtZVwiO1xufSk6IFByb21pc2U8QWlTY2FuUmVzdWx0PiB7XG4gIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKFwiL2FwaS9haS1zY2FuXCIsIHtcbiAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeShwYXJhbXMpLFxuICB9KTtcblxuICBpZiAoIXJlcy5vaykge1xuICAgIGNvbnN0IGVyckRhdGEgPSBhd2FpdCByZXMuanNvbigpLmNhdGNoKCgpID0+ICh7IGVycm9yOiBcIkFJIFNjYW4gZmFpbGVkXCIgfSkpO1xuICAgIHRocm93IG5ldyBFcnJvcihlcnJEYXRhLmVycm9yIHx8IGVyckRhdGEuZGV0YWlscyB8fCBgQUkgU2NhbiBmYWlsZWQgd2l0aCBzdGF0dXMgJHtyZXMuc3RhdHVzfWApO1xuICB9XG5cbiAgY29uc3QganNvbiA9IGF3YWl0IHJlcy5qc29uKCk7XG4gIGlmICghanNvbi5zdWNjZXNzIHx8ICFqc29uLmRhdGEpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoanNvbi5lcnJvciB8fCBcIk5vIGRhdGEgcmVjZWl2ZWQgZnJvbSBBSSBTY2FuXCIpO1xuICB9XG5cbiAgcmV0dXJuIGpzb24uZGF0YSBhcyBBaVNjYW5SZXN1bHQ7XG59XG4iXX0=