import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=a8030269";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=a8030269";
import { t as useLayoutEffect2 } from "/node_modules/.vite/deps/dist-qLH82T-0.js?v=a8030269";
//#region node_modules/@radix-ui/react-id/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", {
	value,
	configurable: true
});
var useReactId = import_react[" useId ".trim().toString()] || (() => void 0);
var count = 0;
function useId(deterministicId) {
	const [id, setId] = import_react.useState(useReactId());
	useLayoutEffect2(() => {
		if (!deterministicId) setId((reactId) => reactId ?? String(count++));
	}, [deterministicId]);
	return deterministicId || (id ? `radix-${id}` : "");
}
__name(useId, "useId");
//#endregion
export { useId as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlzdC1DalBtekt0VS5qcyIsIm5hbWVzIjpbIlJlYWN0Il0sInNvdXJjZXMiOlsiLi4vLi4vQHJhZGl4LXVpL3JlYWN0LWlkL2Rpc3QvaW5kZXgubWpzIl0sInNvdXJjZXNDb250ZW50IjpbInZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19uYW1lID0gKHRhcmdldCwgdmFsdWUpID0+IF9fZGVmUHJvcCh0YXJnZXQsIFwibmFtZVwiLCB7IHZhbHVlLCBjb25maWd1cmFibGU6IHRydWUgfSk7XG5cbi8vIHNyYy9pZC50c3hcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlTGF5b3V0RWZmZWN0IH0gZnJvbSBcIkByYWRpeC11aS9yZWFjdC11c2UtbGF5b3V0LWVmZmVjdFwiO1xudmFyIHVzZVJlYWN0SWQgPSBSZWFjdFtcIiB1c2VJZCBcIi50cmltKCkudG9TdHJpbmcoKV0gfHwgKCgpID0+IHZvaWQgMCk7XG52YXIgY291bnQgPSAwO1xuZnVuY3Rpb24gdXNlSWQoZGV0ZXJtaW5pc3RpY0lkKSB7XG4gIGNvbnN0IFtpZCwgc2V0SWRdID0gUmVhY3QudXNlU3RhdGUodXNlUmVhY3RJZCgpKTtcbiAgdXNlTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWRldGVybWluaXN0aWNJZCkgc2V0SWQoKHJlYWN0SWQpID0+IHJlYWN0SWQgPz8gU3RyaW5nKGNvdW50KyspKTtcbiAgfSwgW2RldGVybWluaXN0aWNJZF0pO1xuICByZXR1cm4gZGV0ZXJtaW5pc3RpY0lkIHx8IChpZCA/IGByYWRpeC0ke2lkfWAgOiBcIlwiKTtcbn1cbl9fbmFtZSh1c2VJZCwgXCJ1c2VJZFwiKTtcbmV4cG9ydCB7XG4gIHVzZUlkXG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXgubWpzLm1hcFxuIl0sIm1hcHBpbmdzIjoiOzs7OztBQUFBLElBQUksWUFBWSxPQUFPO0FBQ3ZCLElBQUksVUFBVSxRQUFRLFVBQVUsVUFBVSxRQUFRLFFBQVE7Q0FBRTtDQUFPLGNBQWM7QUFBSyxDQUFDO0FBS3ZGLElBQUksYUFBYUEsYUFBTSxVQUFVLEtBQUssQ0FBQyxDQUFDLFNBQVMsYUFBYSxLQUFLO0FBQ25FLElBQUksUUFBUTtBQUNaLFNBQVMsTUFBTSxpQkFBaUI7Q0FDOUIsTUFBTSxDQUFDLElBQUksU0FBQSxhQUFlLFNBQVMsV0FBVyxDQUFDO0NBQy9DLHVCQUFzQjtFQUNwQixJQUFJLENBQUMsaUJBQWlCLE9BQU8sWUFBWSxXQUFXLE9BQU8sT0FBTyxDQUFDO0NBQ3JFLEdBQUcsQ0FBQyxlQUFlLENBQUM7Q0FDcEIsT0FBTyxvQkFBb0IsS0FBSyxTQUFTLE9BQU87QUFDbEQ7QUFDQSxPQUFPLE9BQU8sT0FBTyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=