import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/OfflineStatus.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=a8030269";
import { CloudOff } from "/node_modules/.vite/deps/lucide-react.js?v=a8030269";
var _jsxFileName = "/app/applet/src/components/OfflineStatus.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
var _s = $RefreshSig$();
export function OfflineStatus() {
	_s();
	const [offline, setOffline] = useState(false);
	const queryClient = useQueryClient();
	useEffect(() => {
		const update = () => setOffline(!navigator.onLine);
		update();
		const handleOnline = () => {
			update();
			void queryClient.refetchQueries({ type: "active" });
		};
		window.addEventListener("online", handleOnline);
		window.addEventListener("offline", update);
		return () => {
			window.removeEventListener("online", handleOnline);
			window.removeEventListener("offline", update);
		};
	}, []);
	if (!offline) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		role: "status",
		className: "fixed inset-x-0 bottom-0 z-50 flex items-center justify-center gap-2 border-t border-amber-500/30 bg-amber-950 px-4 py-2 text-xs font-medium text-amber-100",
		"data-tsd-source": "/src/components/OfflineStatus.tsx:26:5",
		children: [/* @__PURE__ */ _jsxDEV(CloudOff, {
			className: "h-4 w-4",
			"data-tsd-source": "/src/components/OfflineStatus.tsx:30:7"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 30,
			columnNumber: 7
		}, this), " You are offline. Changes will not be submitted until your connection returns."]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 5
	}, this);
}
_s(OfflineStatus, "G/4xSUDc0kVIsT6ff+P49JXQd7Y=", false, function() {
	return [useQueryClient];
});
_c = OfflineStatus;
var _c;
$RefreshReg$(_c, "OfflineStatus");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/OfflineStatus.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/components/OfflineStatus.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/components/OfflineStatus.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/components/OfflineStatus.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBOzs7O0FBRUE7O0NBQ0E7Q0FDQTtDQUVBO0VBQ0E7RUFDQTtFQUNBO0dBQ0E7R0FDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0dBQ0E7R0FDQTtFQUNBO0NBQ0E7Q0FFQTtDQUNBLE9BQ0E7RUFDQTtFQUNBO0VBQ0E7WUFIQSxDQUlBO0dBQUE7R0FBQTtFQUFvQzs7OztZQUFBLGdGQUVwQzs7Ozs7O0FBRUEiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk9mZmxpbmVTdGF0dXMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xuaW1wb3J0IHsgQ2xvdWRPZmYgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBPZmZsaW5lU3RhdHVzKCkge1xuICBjb25zdCBbb2ZmbGluZSwgc2V0T2ZmbGluZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHVwZGF0ZSA9ICgpID0+IHNldE9mZmxpbmUoIW5hdmlnYXRvci5vbkxpbmUpO1xuICAgIHVwZGF0ZSgpO1xuICAgIGNvbnN0IGhhbmRsZU9ubGluZSA9ICgpID0+IHtcbiAgICAgIHVwZGF0ZSgpO1xuICAgICAgdm9pZCBxdWVyeUNsaWVudC5yZWZldGNoUXVlcmllcyh7IHR5cGU6IFwiYWN0aXZlXCIgfSk7XG4gICAgfTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIm9ubGluZVwiLCBoYW5kbGVPbmxpbmUpO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwib2ZmbGluZVwiLCB1cGRhdGUpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm9ubGluZVwiLCBoYW5kbGVPbmxpbmUpO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJvZmZsaW5lXCIsIHVwZGF0ZSk7XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIGlmICghb2ZmbGluZSkgcmV0dXJuIG51bGw7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgcm9sZT1cInN0YXR1c1wiXG4gICAgICBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC14LTAgYm90dG9tLTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBib3JkZXItdCBib3JkZXItYW1iZXItNTAwLzMwIGJnLWFtYmVyLTk1MCBweC00IHB5LTIgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWFtYmVyLTEwMFwiXG4gICAgPlxuICAgICAgPENsb3VkT2ZmIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPiBZb3UgYXJlIG9mZmxpbmUuIENoYW5nZXMgd2lsbCBub3QgYmUgc3VibWl0dGVkIHVudGlsIHlvdXJcbiAgICAgIGNvbm5lY3Rpb24gcmV0dXJucy5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL2FwcC9hcHBsZXQvc3JjL2NvbXBvbmVudHMvT2ZmbGluZVN0YXR1cy50c3gifQ==