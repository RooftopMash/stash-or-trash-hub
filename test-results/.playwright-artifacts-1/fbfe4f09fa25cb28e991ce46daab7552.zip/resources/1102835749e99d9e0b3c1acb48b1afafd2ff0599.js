import { t as __commonJSMin } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=a8030269";
//#region node_modules/crypt/crypt.js
var require_crypt = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function() {
		var base64map = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", crypt = {
			rotl: function(n, b) {
				return n << b | n >>> 32 - b;
			},
			rotr: function(n, b) {
				return n << 32 - b | n >>> b;
			},
			endian: function(n) {
				if (n.constructor == Number) return crypt.rotl(n, 8) & 16711935 | crypt.rotl(n, 24) & 4278255360;
				for (var i = 0; i < n.length; i++) n[i] = crypt.endian(n[i]);
				return n;
			},
			randomBytes: function(n) {
				for (var bytes = []; n > 0; n--) bytes.push(Math.floor(Math.random() * 256));
				return bytes;
			},
			bytesToWords: function(bytes) {
				for (var words = [], i = 0, b = 0; i < bytes.length; i++, b += 8) words[b >>> 5] |= bytes[i] << 24 - b % 32;
				return words;
			},
			wordsToBytes: function(words) {
				for (var bytes = [], b = 0; b < words.length * 32; b += 8) bytes.push(words[b >>> 5] >>> 24 - b % 32 & 255);
				return bytes;
			},
			bytesToHex: function(bytes) {
				for (var hex = [], i = 0; i < bytes.length; i++) {
					hex.push((bytes[i] >>> 4).toString(16));
					hex.push((bytes[i] & 15).toString(16));
				}
				return hex.join("");
			},
			hexToBytes: function(hex) {
				for (var bytes = [], c = 0; c < hex.length; c += 2) bytes.push(parseInt(hex.substr(c, 2), 16));
				return bytes;
			},
			bytesToBase64: function(bytes) {
				for (var base64 = [], i = 0; i < bytes.length; i += 3) {
					var triplet = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
					for (var j = 0; j < 4; j++) if (i * 8 + j * 6 <= bytes.length * 8) base64.push(base64map.charAt(triplet >>> 6 * (3 - j) & 63));
					else base64.push("=");
				}
				return base64.join("");
			},
			base64ToBytes: function(base64) {
				base64 = base64.replace(/[^A-Z0-9+\/]/gi, "");
				for (var bytes = [], i = 0, imod4 = 0; i < base64.length; imod4 = ++i % 4) {
					if (imod4 == 0) continue;
					bytes.push((base64map.indexOf(base64.charAt(i - 1)) & Math.pow(2, -2 * imod4 + 8) - 1) << imod4 * 2 | base64map.indexOf(base64.charAt(i)) >>> 6 - imod4 * 2);
				}
				return bytes;
			}
		};
		module.exports = crypt;
	})();
}));
//#endregion
//#region node_modules/charenc/charenc.js
var require_charenc = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var charenc = {
		utf8: {
			stringToBytes: function(str) {
				return charenc.bin.stringToBytes(unescape(encodeURIComponent(str)));
			},
			bytesToString: function(bytes) {
				return decodeURIComponent(escape(charenc.bin.bytesToString(bytes)));
			}
		},
		bin: {
			stringToBytes: function(str) {
				for (var bytes = [], i = 0; i < str.length; i++) bytes.push(str.charCodeAt(i) & 255);
				return bytes;
			},
			bytesToString: function(bytes) {
				for (var str = [], i = 0; i < bytes.length; i++) str.push(String.fromCharCode(bytes[i]));
				return str.join("");
			}
		}
	};
	module.exports = charenc;
}));
//#endregion
//#region node_modules/is-buffer/index.js
var require_is_buffer = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/*!
	* Determine if an object is a Buffer
	*
	* @author   Feross Aboukhadijeh <https://feross.org>
	* @license  MIT
	*/
	module.exports = function(obj) {
		return obj != null && (isBuffer(obj) || isSlowBuffer(obj) || !!obj._isBuffer);
	};
	function isBuffer(obj) {
		return !!obj.constructor && typeof obj.constructor.isBuffer === "function" && obj.constructor.isBuffer(obj);
	}
	function isSlowBuffer(obj) {
		return typeof obj.readFloatLE === "function" && typeof obj.slice === "function" && isBuffer(obj.slice(0, 0));
	}
}));
//#endregion
//#region node_modules/md5/md5.js
var require_md5 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function() {
		var crypt = require_crypt(), utf8 = require_charenc().utf8, isBuffer = require_is_buffer(), bin = require_charenc().bin, md5 = function(message, options) {
			if (message.constructor == String) if (options && options.encoding === "binary") message = bin.stringToBytes(message);
			else message = utf8.stringToBytes(message);
			else if (isBuffer(message)) message = Array.prototype.slice.call(message, 0);
			else if (!Array.isArray(message) && message.constructor !== Uint8Array) message = message.toString();
			var m = crypt.bytesToWords(message), l = message.length * 8, a = 1732584193, b = -271733879, c = -1732584194, d = 271733878;
			for (var i = 0; i < m.length; i++) m[i] = (m[i] << 8 | m[i] >>> 24) & 16711935 | (m[i] << 24 | m[i] >>> 8) & 4278255360;
			m[l >>> 5] |= 128 << l % 32;
			m[(l + 64 >>> 9 << 4) + 14] = l;
			var FF = md5._ff, GG = md5._gg, HH = md5._hh, II = md5._ii;
			for (var i = 0; i < m.length; i += 16) {
				var aa = a, bb = b, cc = c, dd = d;
				a = FF(a, b, c, d, m[i + 0], 7, -680876936);
				d = FF(d, a, b, c, m[i + 1], 12, -389564586);
				c = FF(c, d, a, b, m[i + 2], 17, 606105819);
				b = FF(b, c, d, a, m[i + 3], 22, -1044525330);
				a = FF(a, b, c, d, m[i + 4], 7, -176418897);
				d = FF(d, a, b, c, m[i + 5], 12, 1200080426);
				c = FF(c, d, a, b, m[i + 6], 17, -1473231341);
				b = FF(b, c, d, a, m[i + 7], 22, -45705983);
				a = FF(a, b, c, d, m[i + 8], 7, 1770035416);
				d = FF(d, a, b, c, m[i + 9], 12, -1958414417);
				c = FF(c, d, a, b, m[i + 10], 17, -42063);
				b = FF(b, c, d, a, m[i + 11], 22, -1990404162);
				a = FF(a, b, c, d, m[i + 12], 7, 1804603682);
				d = FF(d, a, b, c, m[i + 13], 12, -40341101);
				c = FF(c, d, a, b, m[i + 14], 17, -1502002290);
				b = FF(b, c, d, a, m[i + 15], 22, 1236535329);
				a = GG(a, b, c, d, m[i + 1], 5, -165796510);
				d = GG(d, a, b, c, m[i + 6], 9, -1069501632);
				c = GG(c, d, a, b, m[i + 11], 14, 643717713);
				b = GG(b, c, d, a, m[i + 0], 20, -373897302);
				a = GG(a, b, c, d, m[i + 5], 5, -701558691);
				d = GG(d, a, b, c, m[i + 10], 9, 38016083);
				c = GG(c, d, a, b, m[i + 15], 14, -660478335);
				b = GG(b, c, d, a, m[i + 4], 20, -405537848);
				a = GG(a, b, c, d, m[i + 9], 5, 568446438);
				d = GG(d, a, b, c, m[i + 14], 9, -1019803690);
				c = GG(c, d, a, b, m[i + 3], 14, -187363961);
				b = GG(b, c, d, a, m[i + 8], 20, 1163531501);
				a = GG(a, b, c, d, m[i + 13], 5, -1444681467);
				d = GG(d, a, b, c, m[i + 2], 9, -51403784);
				c = GG(c, d, a, b, m[i + 7], 14, 1735328473);
				b = GG(b, c, d, a, m[i + 12], 20, -1926607734);
				a = HH(a, b, c, d, m[i + 5], 4, -378558);
				d = HH(d, a, b, c, m[i + 8], 11, -2022574463);
				c = HH(c, d, a, b, m[i + 11], 16, 1839030562);
				b = HH(b, c, d, a, m[i + 14], 23, -35309556);
				a = HH(a, b, c, d, m[i + 1], 4, -1530992060);
				d = HH(d, a, b, c, m[i + 4], 11, 1272893353);
				c = HH(c, d, a, b, m[i + 7], 16, -155497632);
				b = HH(b, c, d, a, m[i + 10], 23, -1094730640);
				a = HH(a, b, c, d, m[i + 13], 4, 681279174);
				d = HH(d, a, b, c, m[i + 0], 11, -358537222);
				c = HH(c, d, a, b, m[i + 3], 16, -722521979);
				b = HH(b, c, d, a, m[i + 6], 23, 76029189);
				a = HH(a, b, c, d, m[i + 9], 4, -640364487);
				d = HH(d, a, b, c, m[i + 12], 11, -421815835);
				c = HH(c, d, a, b, m[i + 15], 16, 530742520);
				b = HH(b, c, d, a, m[i + 2], 23, -995338651);
				a = II(a, b, c, d, m[i + 0], 6, -198630844);
				d = II(d, a, b, c, m[i + 7], 10, 1126891415);
				c = II(c, d, a, b, m[i + 14], 15, -1416354905);
				b = II(b, c, d, a, m[i + 5], 21, -57434055);
				a = II(a, b, c, d, m[i + 12], 6, 1700485571);
				d = II(d, a, b, c, m[i + 3], 10, -1894986606);
				c = II(c, d, a, b, m[i + 10], 15, -1051523);
				b = II(b, c, d, a, m[i + 1], 21, -2054922799);
				a = II(a, b, c, d, m[i + 8], 6, 1873313359);
				d = II(d, a, b, c, m[i + 15], 10, -30611744);
				c = II(c, d, a, b, m[i + 6], 15, -1560198380);
				b = II(b, c, d, a, m[i + 13], 21, 1309151649);
				a = II(a, b, c, d, m[i + 4], 6, -145523070);
				d = II(d, a, b, c, m[i + 11], 10, -1120210379);
				c = II(c, d, a, b, m[i + 2], 15, 718787259);
				b = II(b, c, d, a, m[i + 9], 21, -343485551);
				a = a + aa >>> 0;
				b = b + bb >>> 0;
				c = c + cc >>> 0;
				d = d + dd >>> 0;
			}
			return crypt.endian([
				a,
				b,
				c,
				d
			]);
		};
		md5._ff = function(a, b, c, d, x, s, t) {
			var n = a + (b & c | ~b & d) + (x >>> 0) + t;
			return (n << s | n >>> 32 - s) + b;
		};
		md5._gg = function(a, b, c, d, x, s, t) {
			var n = a + (b & d | c & ~d) + (x >>> 0) + t;
			return (n << s | n >>> 32 - s) + b;
		};
		md5._hh = function(a, b, c, d, x, s, t) {
			var n = a + (b ^ c ^ d) + (x >>> 0) + t;
			return (n << s | n >>> 32 - s) + b;
		};
		md5._ii = function(a, b, c, d, x, s, t) {
			var n = a + (c ^ (b | ~d)) + (x >>> 0) + t;
			return (n << s | n >>> 32 - s) + b;
		};
		md5._blocksize = 16;
		md5._digestsize = 16;
		module.exports = function(message, options) {
			if (message === void 0 || message === null) throw new Error("Illegal argument " + message);
			var digestbytes = crypt.wordsToBytes(md5(message, options));
			return options && options.asBytes ? digestbytes : options && options.asString ? bin.bytesToString(digestbytes) : crypt.bytesToHex(digestbytes);
		};
	})();
}));
//#endregion
//#region browser-external:crypto
var require_browser_external_crypto = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = Object.create(new Proxy({}, { get(_, key) {
		if (key !== "__esModule" && key !== "__proto__" && key !== "constructor" && key !== "splice") console.warn(`Module "crypto" has been externalized for browser compatibility. Cannot access "crypto.${key}" in client code. See https://vite.dev/guide/troubleshooting.html#module-externalized-for-browser-compatibility for more details.`);
	} }));
}));
//#endregion
//#region browser-external:zlib
var require_browser_external_zlib = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = Object.create(new Proxy({}, { get(_, key) {
		if (key !== "__esModule" && key !== "__proto__" && key !== "constructor" && key !== "splice") console.warn(`Module "zlib" has been externalized for browser compatibility. Cannot access "zlib.${key}" in client code. See https://vite.dev/guide/troubleshooting.html#module-externalized-for-browser-compatibility for more details.`);
	} }));
}));
//#endregion
//#region node_modules/agora-token/src/AccessToken2.js
var require_AccessToken2 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var crypto = require_browser_external_crypto();
	var zlib = require_browser_external_zlib();
	var VERSION_LENGTH = 3;
	var getVersion = () => {
		return "007";
	};
	var isUuid = (value) => {
		return value !== null && typeof value !== "undefined" && /^[0-9a-fA-F]{32}$/.test(value.toString());
	};
	var Service = class {
		constructor(service_type) {
			this.__type = service_type;
			this.__privileges = {};
		}
		__pack_type() {
			let buf = new ByteBuf();
			buf.putUint16(this.__type);
			return buf.pack();
		}
		__pack_privileges() {
			let buf = new ByteBuf();
			buf.putTreeMapUInt32(this.__privileges);
			return buf.pack();
		}
		service_type() {
			return this.__type;
		}
		add_privilege(privilege, expire) {
			this.__privileges[privilege] = expire;
		}
		pack() {
			return Buffer.concat([this.__pack_type(), this.__pack_privileges()]);
		}
		unpack(buffer) {
			let bufReader = new ReadByteBuf(buffer);
			this.__privileges = bufReader.getTreeMapUInt32();
			return bufReader;
		}
	};
	var kRtcServiceType = 1;
	var ServiceRtc = class extends Service {
		constructor(channel_name, uid) {
			super(kRtcServiceType);
			this.__channel_name = channel_name;
			this.__uid = uid === 0 ? "" : `${uid}`;
		}
		pack() {
			let buffer = new ByteBuf();
			buffer.putString(this.__channel_name).putString(this.__uid);
			return Buffer.concat([super.pack(), buffer.pack()]);
		}
		unpack(buffer) {
			let bufReader = super.unpack(buffer);
			this.__channel_name = bufReader.getString();
			this.__uid = bufReader.getString();
			return bufReader;
		}
	};
	ServiceRtc.kPrivilegeJoinChannel = 1;
	ServiceRtc.kPrivilegePublishAudioStream = 2;
	ServiceRtc.kPrivilegePublishVideoStream = 3;
	ServiceRtc.kPrivilegePublishDataStream = 4;
	var kRtmServiceType = 2;
	var ServiceRtm = class extends Service {
		constructor(user_id) {
			super(kRtmServiceType);
			this.__user_id = user_id || "";
		}
		pack() {
			let buffer = new ByteBuf();
			buffer.putString(this.__user_id);
			return Buffer.concat([super.pack(), buffer.pack()]);
		}
		unpack(buffer) {
			let bufReader = super.unpack(buffer);
			this.__user_id = bufReader.getString();
			return bufReader;
		}
	};
	ServiceRtm.kPrivilegeLogin = 1;
	var kStreamingServiceType = 3;
	var ServiceStreaming = class extends Service {
		constructor(channelName = "", account = "") {
			super(kStreamingServiceType);
			this.__channel_name = channelName;
			this.__account = account === 0 ? "" : `${account}`;
		}
		pack() {
			const buffer = new ByteBuf().putString(this.__channel_name).putString(this.__account);
			return Buffer.concat([super.pack(), buffer.pack()]);
		}
		unpack(buffer) {
			const reader = super.unpack(buffer);
			this.__channel_name = reader.getString();
			this.__account = reader.getString();
			return reader;
		}
	};
	ServiceStreaming.kPrivilegePublishMixStream = 1;
	ServiceStreaming.kPrivilegePublishRawStream = 2;
	var kFpaServiceType = 4;
	var ServiceFpa = class extends Service {
		constructor() {
			super(kFpaServiceType);
		}
		pack() {
			return super.pack();
		}
		unpack(buffer) {
			return super.unpack(buffer);
		}
	};
	ServiceFpa.kPrivilegeLogin = 1;
	var kConvoAIServiceType = 9;
	var ServiceConvoAI = class extends Service {
		constructor() {
			super(kConvoAIServiceType);
		}
		pack() {
			return super.pack();
		}
		unpack(buffer) {
			return super.unpack(buffer);
		}
	};
	var kSttServiceType = 10;
	var ServiceStt = class extends Service {
		constructor() {
			super(kSttServiceType);
		}
		pack() {
			return super.pack();
		}
		unpack(buffer) {
			return super.unpack(buffer);
		}
	};
	var kChatServiceType = 5;
	var ServiceChat = class extends Service {
		constructor(user_id) {
			super(kChatServiceType);
			this.__user_id = user_id || "";
		}
		pack() {
			let buffer = new ByteBuf();
			buffer.putString(this.__user_id);
			return Buffer.concat([super.pack(), buffer.pack()]);
		}
		unpack(buffer) {
			let bufReader = super.unpack(buffer);
			this.__user_id = bufReader.getString();
			return bufReader;
		}
	};
	ServiceChat.kPrivilegeUser = 1;
	ServiceChat.kPrivilegeApp = 2;
	var kFCdnServiceType = 6;
	var ServiceFCdn = class extends Service {
		constructor(channelName = "", account = "") {
			super(kFCdnServiceType);
			this.__channel_name = channelName;
			this.__account = account === 0 ? "" : `${account}`;
		}
		pack() {
			const buffer = new ByteBuf().putString(this.__channel_name).putString(this.__account);
			return Buffer.concat([super.pack(), buffer.pack()]);
		}
		unpack(buffer) {
			const reader = super.unpack(buffer);
			this.__channel_name = reader.getString();
			this.__account = reader.getString();
			return reader;
		}
	};
	ServiceFCdn.kPrivilegePublish = 1;
	ServiceFCdn.kPrivilegePlay = 2;
	var kApaasServiceType = 7;
	var ServiceApaas = class extends Service {
		constructor(roomUuid, userUuid, role) {
			super(kApaasServiceType);
			this.__room_uuid = roomUuid || "";
			this.__user_uuid = userUuid || "";
			this.__role = role || -1;
		}
		pack() {
			let buffer = new ByteBuf();
			buffer.putString(this.__room_uuid);
			buffer.putString(this.__user_uuid);
			buffer.putInt16(this.__role);
			return Buffer.concat([super.pack(), buffer.pack()]);
		}
		unpack(buffer) {
			let bufReader = super.unpack(buffer);
			this.__room_uuid = bufReader.getString();
			this.__user_uuid = bufReader.getString();
			this.__role = bufReader.getInt16();
			return bufReader;
		}
	};
	ServiceApaas.PRIVILEGE_ROOM_USER = 1;
	ServiceApaas.PRIVILEGE_USER = 2;
	ServiceApaas.PRIVILEGE_APP = 3;
	var Rtm2Permissions = class {
		constructor() {
			this.details = {};
		}
		add(resourceType, permissionType, resources) {
			if (!this.details[resourceType]) this.details[resourceType] = {};
			this.details[resourceType][permissionType] = Array.from(resources);
		}
	};
	Rtm2Permissions.kMessageChannels = 0;
	Rtm2Permissions.kStreamChannels = 1;
	Rtm2Permissions.kGroupChannels = 2;
	Rtm2Permissions.kServerGroups = 3;
	Rtm2Permissions.kUsers = 4;
	Rtm2Permissions.kRead = 0;
	Rtm2Permissions.kWrite = 1;
	var kRtm2ServiceType = 8;
	var ServiceRtm2 = class extends Service {
		constructor(userId, permissions) {
			super(kRtm2ServiceType);
			this.__user_id = userId === 0 || userId == null ? "" : String(userId);
			this.__permissions = permissions || new Rtm2Permissions();
		}
		pack() {
			const buffer = new ByteBuf().putString(this.__user_id);
			const resourceTypes = Object.keys(this.__permissions.details).map(Number).sort((left, right) => left - right);
			buffer.putUint16(resourceTypes.length);
			resourceTypes.forEach((resourceType) => {
				const permissionMap = this.__permissions.details[resourceType];
				const permissionTypes = Object.keys(permissionMap).map(Number).sort((left, right) => left - right);
				buffer.putUint16(resourceType).putUint16(permissionTypes.length);
				permissionTypes.forEach((permissionType) => {
					const resources = permissionMap[permissionType];
					buffer.putUint16(permissionType).putUint16(resources.length);
					resources.forEach((resource) => buffer.putString(resource));
				});
			});
			return Buffer.concat([super.pack(), buffer.pack()]);
		}
		unpack(buffer) {
			const reader = super.unpack(buffer);
			this.__user_id = reader.getString();
			this.__permissions = new Rtm2Permissions();
			const resourceTypeCount = reader.getUint16();
			for (let i = 0; i < resourceTypeCount; i++) {
				const resourceType = reader.getUint16();
				const permissionCount = reader.getUint16();
				for (let j = 0; j < permissionCount; j++) {
					const permissionType = reader.getUint16();
					const resourceCount = reader.getUint16();
					const resources = [];
					for (let k = 0; k < resourceCount; k++) resources.push(reader.getString().toString());
					this.__permissions.add(resourceType, permissionType, resources);
				}
			}
			return reader;
		}
	};
	ServiceRtm2.kPrivilegeLogin = 1;
	var AccessToken2 = class AccessToken2 {
		constructor(appId, appCertificate, issueTs, expire) {
			this.appId = appId;
			this.appCertificate = appCertificate;
			this.issueTs = issueTs || (/* @__PURE__ */ new Date()).getTime() / 1e3;
			this.expire = expire;
			this.salt = Math.floor(Math.random() * 99999999) + 1;
			this.services = [];
			this.__signature = Buffer.alloc(0);
			this.__signing_info = Buffer.alloc(0);
			this.__parsed = false;
		}
		__signing(appCertificate = this.appCertificate) {
			let signing = encodeHMac(new ByteBuf().putUint32(this.issueTs).pack(), appCertificate);
			signing = encodeHMac(new ByteBuf().putUint32(this.salt).pack(), signing);
			return signing;
		}
		__build_check() {
			const { appId, appCertificate, services } = this;
			if (!isUuid(appId) || !isUuid(appCertificate)) return false;
			if (services.length === 0) return false;
			return true;
		}
		__services_for_packing() {
			return this.services.map((service, index) => ({
				service,
				index
			})).sort((left, right) => {
				return left.service.service_type() - right.service.service_type() || left.index - right.index;
			}).map((entry) => entry.service);
		}
		add_service(service) {
			this.services.push(service);
		}
		getServices(serviceType) {
			return this.services.filter((service) => service.service_type() === serviceType);
		}
		build() {
			if (!this.__build_check()) return "";
			let signing = this.__signing();
			const services = this.__services_for_packing();
			let signing_info = new ByteBuf().putString(this.appId).putUint32(this.issueTs).putUint32(this.expire).putUint32(this.salt).putUint16(services.length).pack();
			services.forEach((service) => {
				signing_info = Buffer.concat([signing_info, service.pack()]);
			});
			let signature = encodeHMac(signing, signing_info);
			let content = Buffer.concat([new ByteBuf().putString(signature).pack(), signing_info]);
			let compressed = zlib.deflateSync(content);
			return `${getVersion()}${Buffer.from(compressed).toString("base64")}`;
		}
		from_string(origin_token) {
			this.appId = "";
			this.issueTs = 0;
			this.expire = 0;
			this.salt = 0;
			this.services = [];
			this.__signature = Buffer.alloc(0);
			this.__signing_info = Buffer.alloc(0);
			this.__parsed = false;
			if (typeof origin_token !== "string" || origin_token.length < VERSION_LENGTH) return false;
			if (origin_token.substring(0, VERSION_LENGTH) !== getVersion()) return false;
			try {
				const origin_content = origin_token.substring(VERSION_LENGTH);
				const bufferReader = new ReadByteBuf(zlib.inflateSync(Buffer.from(origin_content, "base64")));
				this.__signature = Buffer.from(bufferReader.getString());
				this.__signing_info = Buffer.from(bufferReader.pack());
				this.services = [];
				this.appId = bufferReader.getString();
				this.issueTs = bufferReader.getUint32();
				this.expire = bufferReader.getUint32();
				this.salt = bufferReader.getUint32();
				const service_count = bufferReader.getUint16();
				let remainBuf = bufferReader.pack();
				for (let i = 0; i < service_count; i++) {
					const bufferReaderService = new ReadByteBuf(remainBuf);
					const service_type = bufferReaderService.getUint16();
					const ServiceClass = AccessToken2.kServices[service_type];
					if (!ServiceClass) {
						this.__parsed = true;
						return true;
					}
					const service = new ServiceClass();
					remainBuf = service.unpack(bufferReaderService.pack()).pack();
					this.add_service(service);
				}
			} catch (error) {
				return false;
			}
			this.__parsed = true;
			return true;
		}
		verifySignature(appCertificate) {
			if (!this.__parsed || this.__signature.length === 0 || this.__signing_info.length === 0 || !isUuid(this.appId) || !isUuid(appCertificate)) return false;
			const signature = encodeHMac(this.__signing(appCertificate), this.__signing_info);
			return this.__signature.length === signature.length && crypto.timingSafeEqual(this.__signature, signature);
		}
	};
	var encodeHMac = function(key, message) {
		return crypto.createHmac("sha256", key).update(message).digest();
	};
	var ByteBuf = function() {
		var that = {
			buffer: Buffer.alloc(1024),
			position: 0
		};
		that.buffer.fill(0);
		var ensureCapacity = function(additionalLength) {
			const requiredLength = that.position + additionalLength;
			if (requiredLength <= that.buffer.length) return;
			let capacity = that.buffer.length;
			while (capacity < requiredLength) capacity *= 2;
			const expanded = Buffer.alloc(capacity);
			that.buffer.copy(expanded, 0, 0, that.position);
			that.buffer = expanded;
		};
		that.pack = function() {
			var out = Buffer.alloc(that.position);
			that.buffer.copy(out, 0, 0, out.length);
			return out;
		};
		that.putUint16 = function(v) {
			ensureCapacity(2);
			that.buffer.writeUInt16LE(v, that.position);
			that.position += 2;
			return that;
		};
		that.putUint32 = function(v) {
			ensureCapacity(4);
			that.buffer.writeUInt32LE(v, that.position);
			that.position += 4;
			return that;
		};
		that.putInt32 = function(v) {
			ensureCapacity(4);
			that.buffer.writeInt32LE(v, that.position);
			that.position += 4;
			return that;
		};
		that.putInt16 = function(v) {
			ensureCapacity(2);
			that.buffer.writeInt16LE(v, that.position);
			that.position += 2;
			return that;
		};
		that.putBytes = function(bytes) {
			that.putUint16(bytes.length);
			ensureCapacity(bytes.length);
			bytes.copy(that.buffer, that.position);
			that.position += bytes.length;
			return that;
		};
		that.putString = function(str) {
			return that.putBytes(Buffer.from(str));
		};
		that.putTreeMap = function(map) {
			if (!map) {
				that.putUint16(0);
				return that;
			}
			that.putUint16(Object.keys(map).length);
			for (var key in map) {
				that.putUint16(key);
				that.putString(map[key]);
			}
			return that;
		};
		that.putTreeMapUInt32 = function(map) {
			if (!map) {
				that.putUint16(0);
				return that;
			}
			that.putUint16(Object.keys(map).length);
			for (var key in map) {
				that.putUint16(key);
				that.putUint32(map[key]);
			}
			return that;
		};
		return that;
	};
	var ReadByteBuf = function(bytes) {
		var that = {
			buffer: bytes,
			position: 0
		};
		that.getUint16 = function() {
			var ret = that.buffer.readUInt16LE(that.position);
			that.position += 2;
			return ret;
		};
		that.getUint32 = function() {
			var ret = that.buffer.readUInt32LE(that.position);
			that.position += 4;
			return ret;
		};
		that.getInt16 = function() {
			var ret = that.buffer.readUInt16LE(that.position);
			that.position += 2;
			return ret;
		};
		that.getString = function() {
			var len = that.getUint16();
			var out = Buffer.alloc(len);
			that.buffer.copy(out, 0, that.position, that.position + len);
			that.position += len;
			return out;
		};
		that.getTreeMapUInt32 = function() {
			var map = {};
			var len = that.getUint16();
			for (var i = 0; i < len; i++) {
				var key = that.getUint16();
				map[key] = that.getUint32();
			}
			return map;
		};
		that.pack = function() {
			const length = that.buffer.length - that.position;
			const out = Buffer.alloc(length);
			that.buffer.copy(out, 0, that.position);
			return out;
		};
		return that;
	};
	AccessToken2.kServices = {};
	AccessToken2.kServices[kApaasServiceType] = ServiceApaas;
	AccessToken2.kServices[kChatServiceType] = ServiceChat;
	AccessToken2.kServices[kFCdnServiceType] = ServiceFCdn;
	AccessToken2.kServices[kFpaServiceType] = ServiceFpa;
	AccessToken2.kServices[kRtcServiceType] = ServiceRtc;
	AccessToken2.kServices[kRtmServiceType] = ServiceRtm;
	AccessToken2.kServices[kRtm2ServiceType] = ServiceRtm2;
	AccessToken2.kServices[kStreamingServiceType] = ServiceStreaming;
	AccessToken2.kServices[kConvoAIServiceType] = ServiceConvoAI;
	AccessToken2.kServices[kSttServiceType] = ServiceStt;
	module.exports = {
		AccessToken2,
		kApaasServiceType,
		kChatServiceType,
		kConvoAIServiceType,
		kFCdnServiceType,
		kFpaServiceType,
		kRtcServiceType,
		kRtmServiceType,
		kRtm2ServiceType,
		kSttServiceType,
		kStreamingServiceType,
		Rtm2Permissions,
		Service,
		ServiceApaas,
		ServiceChat,
		ServiceConvoAI,
		ServiceFCdn,
		ServiceFpa,
		ServiceRtc,
		ServiceRtm,
		ServiceRtm2,
		ServiceStt,
		ServiceStreaming
	};
}));
//#endregion
//#region node_modules/agora-token/src/ApaasTokenBuilder.js
var require_ApaasTokenBuilder = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var md5 = require_md5();
	var AccessToken = require_AccessToken2().AccessToken2;
	var ServiceApaas = require_AccessToken2().ServiceApaas;
	var ServiceChat = require_AccessToken2().ServiceChat;
	var ServiceRtm = require_AccessToken2().ServiceRtm;
	var ApaasTokenBuilder = class {
		/**
		* build user room token
		* @param appId             The App ID issued to you by Agora. Apply for a new App ID from
		*                          Agora Dashboard if it is missing from your kit. See Get an App ID.
		* @param appCertificate    Certificate of the application that you registered in
		*                          the Agora Dashboard. See Get an App Certificate.
		* @param roomUuid          The room's id, must be unique.
		* @param userUuid          The user's id, must be unique.
		* @param role              The user's role.
		* @param expire            represented by the number of seconds elapsed since now. If, for example, you want to access the
		*                          Agora Service within 10 minutes after the token is generated, set expire as
		*                          600(seconds). This value is the whole token expiration and the service
		*                          privilege expiration. The whole token is invalid after this time.
		* @return The user room token.
		*/
		static buildRoomUserToken(appId, appCertificate, roomUuid, userUuid, role, expire) {
			let accessToken = new AccessToken(appId, appCertificate, 0, expire);
			let chatUserId = md5(userUuid);
			let apaasService = new ServiceApaas(roomUuid, userUuid, role);
			accessToken.add_service(apaasService);
			let rtmService = new ServiceRtm(userUuid);
			rtmService.add_privilege(ServiceRtm.kPrivilegeLogin, expire);
			accessToken.add_service(rtmService);
			let chatService = new ServiceChat(chatUserId);
			chatService.add_privilege(ServiceChat.kPrivilegeUser, expire);
			accessToken.add_service(chatService);
			return accessToken.build();
		}
		/**
		* build user token
		* @param appId             The App ID issued to you by Agora. Apply for a new App ID from
		*                          Agora Dashboard if it is missing from your kit. See Get an App ID.
		* @param appCertificate    Certificate of the application that you registered in
		*                          the Agora Dashboard. See Get an App Certificate.
		* @param userUuid          The user's id, must be unique.
		* @param expire            represented by the number of seconds elapsed since now. If, for example, you want to access the
		*                          Agora Service within 10 minutes after the token is generated, set expire as
		*                          600(seconds). This value is the whole token expiration and the service
		*                          privilege expiration. The whole token is invalid after this time.
		* @return The user token.
		*/
		static buildUserToken(appId, appCertificate, userUuid, expire) {
			let accessToken = new AccessToken(appId, appCertificate, 0, expire);
			let apaasService = new ServiceApaas("", userUuid);
			apaasService.add_privilege(ServiceApaas.PRIVILEGE_USER, expire);
			accessToken.add_service(apaasService);
			return accessToken.build();
		}
		/**
		* build app token
		* @param appId          The App ID issued to you by Agora. Apply for a new App ID from
		*                       Agora Dashboard if it is missing from your kit. See Get an App ID.
		* @param appCertificate Certificate of the application that you registered in
		*                       the Agora Dashboard. See Get an App Certificate.
		* @param expire         represented by the number of seconds elapsed since now. If, for example, you want to access the
		*                       Agora Service within 10 minutes after the token is generated, set expire as
		*                       600(seconds). This value is the whole token expiration and the service privilege
		*                       expiration. The whole token is invalid after this time.
		* @return The app token.
		*/
		static buildAppToken(appId, appCertificate, expire) {
			let accessToken = new AccessToken(appId, appCertificate, 0, expire);
			let apaasService = new ServiceApaas();
			apaasService.add_privilege(ServiceApaas.PRIVILEGE_APP, expire);
			accessToken.add_service(apaasService);
			return accessToken.build();
		}
	};
	module.exports.ApaasTokenBuilder = ApaasTokenBuilder;
}));
//#endregion
//#region node_modules/agora-token/src/ChatTokenBuilder.js
var require_ChatTokenBuilder = /* @__PURE__ */ __commonJSMin(((exports) => {
	var AccessToken = require_AccessToken2().AccessToken2;
	var ServiceChat = require_AccessToken2().ServiceChat;
	var ChatTokenBuilder = class {
		/**
		* Build the Chat user token.
		*
		* @param appId The App ID issued to you by Agora. Apply for a new App ID from
		* Agora Dashboard if it is missing from your kit. See Get an App ID.
		* @param appCertificate Certificate of the application that you registered in
		* the Agora Dashboard. See Get an App Certificate.
		* @param userUuid The user's id, must be unique.
		* @param expire represented by the number of seconds elapsed since now. If, for example, you want to access the
		* Agora Service within 10 minutes after the token is generated, set expire as 600(seconds). This value is
		* the whole token expiration and the service privilege expiration. The whole token is invalid after this
		* time.
		* @return The Chat User token.
		*/
		static buildUserToken(appId, appCertificate, userUuid, expire) {
			const token = new AccessToken(appId, appCertificate, null, expire);
			const serviceChat = new ServiceChat(userUuid);
			serviceChat.add_privilege(ServiceChat.kPrivilegeUser, expire);
			token.add_service(serviceChat);
			return token.build();
		}
		/**
		* Build the Chat App token.
		*
		* @param appId The App ID issued to you by Agora. Apply for a new App ID from
		* Agora Dashboard if it is missing from your kit. See Get an App ID.
		* @param appCertificate Certificate of the application that you registered in
		* the Agora Dashboard. See Get an App Certificate.
		* @param expire represented by the number of seconds elapsed since now. If, for example, you want to access the
		* Agora Service within 10 minutes after the token is generated, set expire as 600(seconds). This value is
		* the whole token expiration and the service privilege expiration. The whole token is invalid after this
		* time.
		* @return The Chat App token.
		*/
		static buildAppToken(appId, appCertificate, expire) {
			const token = new AccessToken(appId, appCertificate, null, expire);
			const serviceChat = new ServiceChat();
			serviceChat.add_privilege(ServiceChat.kPrivilegeApp, expire);
			token.add_service(serviceChat);
			return token.build();
		}
	};
	exports.ChatTokenBuilder = ChatTokenBuilder;
}));
//#endregion
//#region node_modules/agora-token/src/RtcTokenBuilder2.js
var require_RtcTokenBuilder2 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var AccessToken = require_AccessToken2().AccessToken2;
	var ServiceRtc = require_AccessToken2().ServiceRtc;
	var ServiceRtm = require_AccessToken2().ServiceRtm;
	var Role = {
		/**
		* RECOMMENDED. Use this role for a voice/video call or a live broadcast, if
		* your scenario does not require authentication for
		* [Co-host](https://docs.agora.io/en/video-calling/get-started/authentication-workflow?#co-host-token-authentication).
		*/
		PUBLISHER: 1,
		/**
		* Only use this role if your scenario require authentication for
		* [Co-host](https://docs.agora.io/en/video-calling/get-started/authentication-workflow?#co-host-token-authentication).
		*
		* @note In order for this role to take effect, please contact our support team
		* to enable authentication for Hosting-in for you. Otherwise, Role_Subscriber
		* still has the same privileges as Role_Publisher.
		*/
		SUBSCRIBER: 2
	};
	var RtcTokenBuilder = class {
		/**
		* Builds an RTC token using an Integer uid.
		* @param {*} appId  The App ID issued to you by Agora.
		* @param {*} appCertificate Certificate of the application that you registered in the Agora Dashboard.
		* @param {*} channelName The unique channel name for the AgoraRTC session in the string format. The string length must be less than 64 bytes. Supported character scopes are:
		* - The 26 lowercase English letters: a to z.
		* - The 26 uppercase English letters: A to Z.
		* - The 10 digits: 0 to 9.
		* - The space.
		* - "!", "#", "$", "%", "&", "(", ")", "+", "-", ":", ";", "<", "=", ".", ">", "?", "@", "[", "]", "^", "_", " {", "}", "|", "~", ",".
		* @param {*} uid User ID. A 32-bit unsigned integer with a value ranging from 1 to (2^32-1).
		* @param {*} role See #userRole.
		* - Role.PUBLISHER; RECOMMENDED. Use this role for a voice/video call or a live broadcast.
		* - Role.SUBSCRIBER: ONLY use this role if your live-broadcast scenario requires authentication for [Co-host](https://docs.agora.io/en/video-calling/get-started/authentication-workflow?#co-host-token-authentication). In order for this role to take effect, please contact our support team to enable authentication for Co-host for you. Otherwise, Role_Subscriber still has the same privileges as Role_Publisher.
		* @param {*} tokenExpire represented by the number of seconds elapsed since now. If, for example, you
		* want to access the Agora Service within 10 minutes after the token is generated, set tokenExpire as
		* 600(seconds). This is the whole token expiration. The whole token is invalid after this time, even if a
		* privilege expiration time is later.
		* @param {*} privilegeExpire represented by the number of seconds elapsed since now. If, for example, you
		* want to enable your privilege for 10 minutes, set privilegeExpire as 600(seconds). This value must not
		* exceed the token expiration value; otherwise, the privilege is limited by the token expiration time.
		* @return The RTC Token.
		*/
		static buildTokenWithUid(appId, appCertificate, channelName, uid, role, tokenExpire, privilegeExpire = 0) {
			return this.buildTokenWithUserAccount(appId, appCertificate, channelName, uid, role, tokenExpire, privilegeExpire);
		}
		/**
		* Builds an RTC token with account.
		* @param {*} appId  The App ID issued to you by Agora.
		* @param {*} appCertificate Certificate of the application that you registered in the Agora Dashboard.
		* @param {*} channelName The unique channel name for the AgoraRTC session in the string format. The string length must be less than 64 bytes. Supported character scopes are:
		* - The 26 lowercase English letters: a to z.
		* - The 26 uppercase English letters: A to Z.
		* - The 10 digits: 0 to 9.
		* - The space.
		* - "!", "#", "$", "%", "&", "(", ")", "+", "-", ":", ";", "<", "=", ".", ">", "?", "@", "[", "]", "^", "_", " {", "}", "|", "~", ",".
		* @param {*} account The user account.
		* @param {*} role See #userRole.
		* - Role.PUBLISHER; RECOMMENDED. Use this role for a voice/video call or a live broadcast.
		* - Role.SUBSCRIBER: ONLY use this role if your live-broadcast scenario requires authentication for [Co-host](https://docs.agora.io/en/video-calling/get-started/authentication-workflow?#co-host-token-authentication). In order for this role to take effect, please contact our support team to enable authentication for Co-host for you. Otherwise, Role_Subscriber still has the same privileges as Role_Publisher.
		* @param {*} tokenExpire represented by the number of seconds elapsed since now. If, for example, you
		* want to access the Agora Service within 10 minutes after the token is generated, set tokenExpire as
		* 600(seconds). This is the whole token expiration. The whole token is invalid after this time, even if a
		* privilege expiration time is later.
		* @param {*} privilegeExpire represented by the number of seconds elapsed since now. If, for example, you
		* want to enable your privilege for 10 minutes, set privilegeExpire as 600(seconds). This value must not
		* exceed the token expiration value; otherwise, the privilege is limited by the token expiration time.
		* @return The RTC Token.
		*/
		static buildTokenWithUserAccount(appId, appCertificate, channelName, account, role, tokenExpire, privilegeExpire = 0) {
			let token = new AccessToken(appId, appCertificate, 0, tokenExpire);
			let serviceRtc = new ServiceRtc(channelName, account);
			serviceRtc.add_privilege(ServiceRtc.kPrivilegeJoinChannel, privilegeExpire);
			if (role == Role.PUBLISHER) {
				serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishAudioStream, privilegeExpire);
				serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishVideoStream, privilegeExpire);
				serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishDataStream, privilegeExpire);
			}
			token.add_service(serviceRtc);
			return token.build();
		}
		/**
		* Generates an RTC token with the specified privilege.
		*
		* This method supports generating a token with the following privileges:
		* - Joining an RTC channel.
		* - Publishing audio in an RTC channel.
		* - Publishing video in an RTC channel.
		* - Publishing data streams in an RTC channel.
		*
		* The privileges for publishing audio, video, and data streams in an RTC channel apply only if you have
		* enabled co-host authentication.
		*
		* A user can have multiple privileges. Each privilege is valid for a maximum of 24 hours.
		* The SDK triggers the onTokenPrivilegeWillExpire and onRequestToken callbacks when the token is about to expire
		* or has expired. The callbacks do not report the specific privilege affected, and you need to maintain
		* the respective timestamp for each privilege in your app logic. After receiving the callback, you need
		* to generate a new token, and then call renewToken to pass the new token to the SDK, or call joinChannel to re-join
		* the channel.
		*
		* @note
		* Agora recommends setting a reasonable timestamp for each privilege according to your scenario.
		* Suppose the expiration timestamp for joining the channel is set earlier than that for publishing audio.
		* When the token for joining the channel expires, the user is immediately kicked off the RTC channel
		* and cannot publish any audio stream, even though the timestamp for publishing audio has not expired.
		*
		* @param appId The App ID of your Agora project.
		* @param appCertificate The App Certificate of your Agora project.
		* @param channelName The unique channel name for the Agora RTC session in string format. The string length must be less than 64 bytes. The channel name may contain the following characters:
		* - All lowercase English letters: a to z.
		* - All uppercase English letters: A to Z.
		* - All numeric characters: 0 to 9.
		* - The space character.
		* - "!", "#", "$", "%", "&", "(", ")", "+", "-", ":", ";", "<", "=", ".", ">", "?", "@", "[", "]", "^", "_", " {", "}", "|", "~", ",".
		* @param uid The user ID. A 32-bit unsigned integer with a value range from 1 to (2^32 - 1). It must be unique. Set uid as 0, if you do not want to authenticate the user ID, that is, any uid from the app client can join the channel.
		* @param tokenExpire represented by the number of seconds elapsed since now. If, for example, you want to access the
		* Agora Service within 10 minutes after the token is generated, set tokenExpire as 600(seconds). This is
		* the whole token expiration. The whole token is invalid after this time, even if a privilege expiration
		* time is later.
		* @param joinChannelPrivilegeExpire represented by the number of seconds elapsed since now.
		* If, for example, you want to join channel and expect stay in the channel for 10 minutes, set
		* joinChannelPrivilegeExpire as 600(seconds). This value must not exceed the token expiration value;
		* otherwise, the privilege is limited by the token expiration time.
		* @param pubAudioPrivilegeExpire represented by the number of seconds elapsed since now.
		* If, for example, you want to enable publish audio privilege for 10 minutes, set pubAudioPrivilegeExpire
		* as 600(seconds). This value must not exceed the token expiration value; otherwise, the privilege is
		* limited by the token expiration time.
		* @param pubVideoPrivilegeExpire represented by the number of seconds elapsed since now.
		* If, for example, you want to enable publish video privilege for 10 minutes, set pubVideoPrivilegeExpire
		* as 600(seconds). This value must not exceed the token expiration value; otherwise, the privilege is
		* limited by the token expiration time.
		* @param pubDataStreamPrivilegeExpire represented by the number of seconds elapsed since now.
		* If, for example, you want to enable publish data stream privilege for 10 minutes, set
		* pubDataStreamPrivilegeExpire as 600(seconds). This value must not exceed the token expiration value;
		* otherwise, the privilege is limited by the token expiration time.
		* @return The RTC Token
		*/
		static buildTokenWithUidAndPrivilege(appId, appCertificate, channelName, uid, tokenExpire, joinChannelPrivilegeExpire, pubAudioPrivilegeExpire, pubVideoPrivilegeExpire, pubDataStreamPrivilegeExpire) {
			return this.BuildTokenWithUserAccountAndPrivilege(appId, appCertificate, channelName, uid, tokenExpire, joinChannelPrivilegeExpire, pubAudioPrivilegeExpire, pubVideoPrivilegeExpire, pubDataStreamPrivilegeExpire);
		}
		/**
		* Generates an RTC token with the specified privilege.
		*
		* This method supports generating a token with the following privileges:
		* - Joining an RTC channel.
		* - Publishing audio in an RTC channel.
		* - Publishing video in an RTC channel.
		* - Publishing data streams in an RTC channel.
		*
		* The privileges for publishing audio, video, and data streams in an RTC channel apply only if you have
		* enabled co-host authentication.
		*
		* A user can have multiple privileges. Each privilege is valid for a maximum of 24 hours.
		* The SDK triggers the onTokenPrivilegeWillExpire and onRequestToken callbacks when the token is about to expire
		* or has expired. The callbacks do not report the specific privilege affected, and you need to maintain
		* the respective timestamp for each privilege in your app logic. After receiving the callback, you need
		* to generate a new token, and then call renewToken to pass the new token to the SDK, or call joinChannel to re-join
		* the channel.
		*
		* @note
		* Agora recommends setting a reasonable timestamp for each privilege according to your scenario.
		* Suppose the expiration timestamp for joining the channel is set earlier than that for publishing audio.
		* When the token for joining the channel expires, the user is immediately kicked off the RTC channel
		* and cannot publish any audio stream, even though the timestamp for publishing audio has not expired.
		*
		* @param appId The App ID of your Agora project.
		* @param appCertificate The App Certificate of your Agora project.
		* @param channelName The unique channel name for the Agora RTC session in string format. The string length must be less than 64 bytes. The channel name may contain the following characters:
		* - All lowercase English letters: a to z.
		* - All uppercase English letters: A to Z.
		* - All numeric characters: 0 to 9.
		* - The space character.
		* - "!", "#", "$", "%", "&", "(", ")", "+", "-", ":", ";", "<", "=", ".", ">", "?", "@", "[", "]", "^", "_", " {", "}", "|", "~", ",".
		* @param userAccount The user account.
		* @param tokenExpire represented by the number of seconds elapsed since now. If, for example, you want to access the
		* Agora Service within 10 minutes after the token is generated, set tokenExpire as 600(seconds). This is
		* the whole token expiration. The whole token is invalid after this time, even if a privilege expiration
		* time is later.
		* @param joinChannelPrivilegeExpire represented by the number of seconds elapsed since now.
		* If, for example, you want to join channel and expect stay in the channel for 10 minutes, set
		* joinChannelPrivilegeExpire as 600(seconds). This value must not exceed the token expiration value;
		* otherwise, the privilege is limited by the token expiration time.
		* @param pubAudioPrivilegeExpire represented by the number of seconds elapsed since now.
		* If, for example, you want to enable publish audio privilege for 10 minutes, set pubAudioPrivilegeExpire
		* as 600(seconds). This value must not exceed the token expiration value; otherwise, the privilege is
		* limited by the token expiration time.
		* @param pubVideoPrivilegeExpire represented by the number of seconds elapsed since now.
		* If, for example, you want to enable publish video privilege for 10 minutes, set pubVideoPrivilegeExpire
		* as 600(seconds). This value must not exceed the token expiration value; otherwise, the privilege is
		* limited by the token expiration time.
		* @param pubDataStreamPrivilegeExpire represented by the number of seconds elapsed since now.
		* If, for example, you want to enable publish data stream privilege for 10 minutes, set
		* pubDataStreamPrivilegeExpire as 600(seconds). This value must not exceed the token expiration value;
		* otherwise, the privilege is limited by the token expiration time.
		* @return The RTC Token.
		*/
		static BuildTokenWithUserAccountAndPrivilege(appId, appCertificate, channelName, account, tokenExpire, joinChannelPrivilegeExpire, pubAudioPrivilegeExpire, pubVideoPrivilegeExpire, pubDataStreamPrivilegeExpire) {
			let token = new AccessToken(appId, appCertificate, 0, tokenExpire);
			let serviceRtc = new ServiceRtc(channelName, account);
			serviceRtc.add_privilege(ServiceRtc.kPrivilegeJoinChannel, joinChannelPrivilegeExpire);
			serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishAudioStream, pubAudioPrivilegeExpire);
			serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishVideoStream, pubVideoPrivilegeExpire);
			serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishDataStream, pubDataStreamPrivilegeExpire);
			token.add_service(serviceRtc);
			return token.build();
		}
		/**
		* Build an RTC and RTM token with account.
		* @param {*} appId  The App ID issued to you by Agora.
		* @param {*} appCertificate Certificate of the application that you registered in the Agora Dashboard.
		* @param {*} channelName The unique channel name for the AgoraRTC session in the string format. The string length must be less than 64 bytes. Supported character scopes are:
		* - The 26 lowercase English letters: a to z.
		* - The 26 uppercase English letters: A to Z.
		* - The 10 digits: 0 to 9.
		* - The space.
		* - "!", "#", "$", "%", "&", "(", ")", "+", "-", ":", ";", "<", "=", ".", ">", "?", "@", "[", "]", "^", "_", " {", "}", "|", "~", ",".
		* @param {*} account The user account.
		* @param {*} role See #userRole.
		* - Role.PUBLISHER; RECOMMENDED. Use this role for a voice/video call or a live broadcast.
		* - Role.SUBSCRIBER: ONLY use this role if your live-broadcast scenario requires authentication for [Co-host](https://docs.agora.io/en/video-calling/get-started/authentication-workflow?#co-host-token-authentication). In order for this role to take effect, please contact our support team to enable authentication for Co-host for you. Otherwise, Role_Subscriber still has the same privileges as Role_Publisher.
		* @param {*} tokenExpire represented by the number of seconds elapsed since now. If, for example, you
		* want to access the Agora Service within 10 minutes after the token is generated, set tokenExpire as
		* 600(seconds). This is the whole token expiration. The whole token is invalid after this time, even if a
		* privilege expiration time is later.
		* @param {*} privilegeExpire represented by the number of seconds elapsed since now. If, for example, you
		* want to enable your privilege for 10 minutes, set privilegeExpire as 600(seconds). This value must not
		* exceed the token expiration value; otherwise, the privilege is limited by the token expiration time.
		* @return The RTC and RTM Token.
		*/
		static buildTokenWithRtm(appId, appCertificate, channelName, account, role, tokenExpire, privilegeExpire = 0) {
			let token = new AccessToken(appId, appCertificate, 0, tokenExpire);
			let serviceRtc = new ServiceRtc(channelName, account);
			serviceRtc.add_privilege(ServiceRtc.kPrivilegeJoinChannel, privilegeExpire);
			if (role == Role.PUBLISHER) {
				serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishAudioStream, privilegeExpire);
				serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishVideoStream, privilegeExpire);
				serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishDataStream, privilegeExpire);
			}
			token.add_service(serviceRtc);
			let serviceRtm = new ServiceRtm(account);
			serviceRtm.add_privilege(ServiceRtm.kPrivilegeLogin, tokenExpire);
			token.add_service(serviceRtm);
			return token.build();
		}
		/**
		* Build an RTC and RTM token with account.
		* @param {*} appId  The App ID issued to you by Agora.
		* @param {*} appCertificate Certificate of the application that you registered in the Agora Dashboard.
		* @param {*} channelName The unique channel name for the AgoraRTC session in the string format. The string length must be less than 64 bytes. Supported character scopes are:
		* - The 26 lowercase English letters: a to z.
		* - The 26 uppercase English letters: A to Z.
		* - The 10 digits: 0 to 9.
		* - The space.
		* - "!", "#", "$", "%", "&", "(", ")", "+", "-", ":", ";", "<", "=", ".", ">", "?", "@", "[", "]", "^", "_", " {", "}", "|", "~", ",".
		* @param {*} rtcAccount The RTC user's account, max length is 255 Bytes.
		* @param {*} rtcRole See #userRole.
		* - Role.PUBLISHER; RECOMMENDED. Use this role for a voice/video call or a live broadcast.
		* - Role.SUBSCRIBER: ONLY use this role if your live-broadcast scenario requires authentication for [Co-host](https://docs.agora.io/en/video-calling/get-started/authentication-workflow?#co-host-token-authentication). In order for this role to take effect, please contact our support team to enable authentication for Co-host for you. Otherwise, Role_Subscriber still has the same privileges as Role_Publisher.
		* @param {*} rtcTokenExpire represented by the number of seconds elapsed since now. If, for example, you
		* want to access the Agora Service within 10 minutes after the token is generated, set rtcTokenExpire as
		* 600(seconds). This is the whole token expiration. The whole token is invalid after this time, even if a
		* privilege expiration time is later.
		* @param {*} joinChannelPrivilegeExpire represented by the number of seconds elapsed since now.
		* If, for example, you want to join channel and expect stay in the channel for 10 minutes, set
		* joinChannelPrivilegeExpire as 600(seconds). This value must not exceed the token expiration value;
		* otherwise, the privilege is limited by the token expiration time.
		* @param {*} pubAudioPrivilegeExpire represented by the number of seconds elapsed since now.
		* If, for example, you want to enable publish audio privilege for 10 minutes, set pubAudioPrivilegeExpire
		* as 600(seconds). This value must not exceed the token expiration value; otherwise, the privilege is
		* limited by the token expiration time.
		* @param {*} pubVideoPrivilegeExpire represented by the number of seconds elapsed since now.
		* If, for example, you want to enable publish video privilege for 10 minutes, set pubVideoPrivilegeExpire
		* as 600(seconds). This value must not exceed the token expiration value; otherwise, the privilege is
		* limited by the token expiration time.
		* @param {*} pubDataStreamPrivilegeExpire represented by the number of seconds elapsed since now.
		* If, for example, you want to enable publish data stream privilege for 10 minutes, set
		* pubDataStreamPrivilegeExpire as 600(seconds). This value must not exceed the token expiration value;
		* otherwise, the privilege is limited by the token expiration time.
		* @param {*} rtmUserId: The RTM user's account, max length is 255 Bytes.
		* @param {*} rtmTokenExpire: represented by the number of seconds elapsed since now. If, for example,
		* you want to access the Agora Service within 10 minutes after the token is generated, set rtmTokenExpire
		* as 600(seconds). This value must not exceed the RTC token expiration value; otherwise, the RTM login
		* privilege is limited by the token expiration time.
		* * @return The RTC and RTM Token.
		*/
		static buildTokenWithRtm2(appId, appCertificate, channelName, rtcAccount, rtcRole, rtcTokenExpire, joinChannelPrivilegeExpire, pubAudioPrivilegeExpire, pubVideoPrivilegeExpire, pubDataStreamPrivilegeExpire, rtmUserId, rtmTokenExpire) {
			let token = new AccessToken(appId, appCertificate, 0, rtcTokenExpire);
			let serviceRtc = new ServiceRtc(channelName, rtcAccount);
			serviceRtc.add_privilege(ServiceRtc.kPrivilegeJoinChannel, joinChannelPrivilegeExpire);
			if (rtcRole == Role.PUBLISHER) {
				serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishAudioStream, pubAudioPrivilegeExpire);
				serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishVideoStream, pubVideoPrivilegeExpire);
				serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishDataStream, pubDataStreamPrivilegeExpire);
			}
			token.add_service(serviceRtc);
			let serviceRtm = new ServiceRtm(rtmUserId);
			serviceRtm.add_privilege(ServiceRtm.kPrivilegeLogin, rtmTokenExpire);
			token.add_service(serviceRtm);
			return token.build();
		}
	};
	module.exports.RtcTokenBuilder = RtcTokenBuilder;
	module.exports.Role = Role;
}));
//#endregion
//#region node_modules/agora-token/src/ConvoAITokenBuilder.js
var require_ConvoAITokenBuilder = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var AccessToken = require_AccessToken2().AccessToken2;
	var ServiceConvoAI = require_AccessToken2().ServiceConvoAI;
	var ServiceRtc = require_AccessToken2().ServiceRtc;
	var ServiceRtm = require_AccessToken2().ServiceRtm;
	var Role = require_RtcTokenBuilder2().Role;
	var ConvoAITokenBuilder = class {
		/**
		* Builds a Token007 that carries RTC, RTM, and ConvoAI services.
		* @param {*} appId The App ID issued to you by Agora.
		* @param {*} appCertificate Certificate of the application that you registered in the Agora Dashboard.
		* @param {*} channelName The unique channel name for the AgoraRTC session in the string format.
		* @param {*} rtcAccount The RTC user's account, max length is 255 bytes.
		* @param {*} rtcRole Role.PUBLISHER for a broadcaster or Role.SUBSCRIBER for an audience member.
		* @param {*} rtcTokenExpire Represented by the number of seconds elapsed since now. This is the whole
		* token expiration. The whole token is invalid after this time, even if a privilege expiration time is
		* later.
		* @param {*} joinChannelPrivilegeExpire Represented by the number of seconds elapsed since now. This
		* value must not exceed rtcTokenExpire; otherwise, the privilege is limited by the token expiration time.
		* @param {*} pubAudioPrivilegeExpire Represented by the number of seconds elapsed since now. This value
		* must not exceed rtcTokenExpire; otherwise, the privilege is limited by the token expiration time.
		* @param {*} pubVideoPrivilegeExpire Represented by the number of seconds elapsed since now. This value
		* must not exceed rtcTokenExpire; otherwise, the privilege is limited by the token expiration time.
		* @param {*} pubDataStreamPrivilegeExpire Represented by the number of seconds elapsed since now. This
		* value must not exceed rtcTokenExpire; otherwise, the privilege is limited by the token expiration time.
		* @param {*} rtmUserId The RTM user's account, max length is 255 bytes.
		* @param {*} rtmTokenExpire Represented by the number of seconds elapsed since now. This value must not
		* exceed rtcTokenExpire; otherwise, the RTM login privilege is limited by the token expiration time.
		* @return The RTC, RTM, and ConvoAI token.
		*/
		static buildToken(appId, appCertificate, channelName, rtcAccount, rtcRole, rtcTokenExpire, joinChannelPrivilegeExpire, pubAudioPrivilegeExpire, pubVideoPrivilegeExpire, pubDataStreamPrivilegeExpire, rtmUserId, rtmTokenExpire) {
			const token = new AccessToken(appId, appCertificate, 0, rtcTokenExpire);
			const serviceRtc = new ServiceRtc(channelName, rtcAccount);
			serviceRtc.add_privilege(ServiceRtc.kPrivilegeJoinChannel, joinChannelPrivilegeExpire);
			if (rtcRole === Role.PUBLISHER) {
				serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishAudioStream, pubAudioPrivilegeExpire);
				serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishVideoStream, pubVideoPrivilegeExpire);
				serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishDataStream, pubDataStreamPrivilegeExpire);
			}
			token.add_service(serviceRtc);
			const serviceRtm = new ServiceRtm(rtmUserId);
			serviceRtm.add_privilege(ServiceRtm.kPrivilegeLogin, rtmTokenExpire);
			token.add_service(serviceRtm);
			token.add_service(new ServiceConvoAI());
			return token.build();
		}
	};
	module.exports = { ConvoAITokenBuilder };
}));
//#endregion
//#region node_modules/agora-token/src/EducationTokenBuilder.js
var require_EducationTokenBuilder = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var md5 = require_md5();
	var AccessToken = require_AccessToken2().AccessToken2;
	var ServiceApaas = require_AccessToken2().ServiceApaas;
	var ServiceChat = require_AccessToken2().ServiceChat;
	var ServiceRtm = require_AccessToken2().ServiceRtm;
	var EducationTokenBuilder = class {
		/**
		* build user room token
		* @param appId             The App ID issued to you by Agora. Apply for a new App ID from
		*                          Agora Dashboard if it is missing from your kit. See Get an App ID.
		* @param appCertificate    Certificate of the application that you registered in
		*                          the Agora Dashboard. See Get an App Certificate.
		* @param roomUuid          The room's id, must be unique.
		* @param userUuid          The user's id, must be unique.
		* @param role              The user's role.
		* @param expire            represented by the number of seconds elapsed since now. If, for example, you want to access the
		*                          Agora Service within 10 minutes after the token is generated, set expire as
		*                          600(seconds). This value is the whole token expiration and the service
		*                          privilege expiration. The whole token is invalid after this time.
		* @return The user room token.
		*/
		static buildRoomUserToken(appId, appCertificate, roomUuid, userUuid, role, expire) {
			let accessToken = new AccessToken(appId, appCertificate, 0, expire);
			let chatUserId = md5(userUuid);
			let apaasService = new ServiceApaas(roomUuid, userUuid, role);
			accessToken.add_service(apaasService);
			let rtmService = new ServiceRtm(userUuid);
			rtmService.add_privilege(ServiceRtm.kPrivilegeLogin, expire);
			accessToken.add_service(rtmService);
			let chatService = new ServiceChat(chatUserId);
			chatService.add_privilege(ServiceChat.kPrivilegeUser, expire);
			accessToken.add_service(chatService);
			return accessToken.build();
		}
		/**
		* build user token
		* @param appId             The App ID issued to you by Agora. Apply for a new App ID from
		*                          Agora Dashboard if it is missing from your kit. See Get an App ID.
		* @param appCertificate    Certificate of the application that you registered in
		*                          the Agora Dashboard. See Get an App Certificate.
		* @param userUuid          The user's id, must be unique.
		* @param expire            represented by the number of seconds elapsed since now. If, for example, you want to access the
		*                          Agora Service within 10 minutes after the token is generated, set expire as
		*                          600(seconds). This value is the whole token expiration and the service
		*                          privilege expiration. The whole token is invalid after this time.
		* @return The user token.
		*/
		static buildUserToken(appId, appCertificate, userUuid, expire) {
			let accessToken = new AccessToken(appId, appCertificate, 0, expire);
			let apaasService = new ServiceApaas("", userUuid);
			apaasService.add_privilege(ServiceApaas.PRIVILEGE_USER, expire);
			accessToken.add_service(apaasService);
			return accessToken.build();
		}
		/**
		* build app token
		* @param appId          The App ID issued to you by Agora. Apply for a new App ID from
		*                       Agora Dashboard if it is missing from your kit. See Get an App ID.
		* @param appCertificate Certificate of the application that you registered in
		*                       the Agora Dashboard. See Get an App Certificate.
		* @param expire         represented by the number of seconds elapsed since now. If, for example, you want to access the
		*                       Agora Service within 10 minutes after the token is generated, set expire as
		*                       600(seconds). This value is the whole token expiration and the service privilege
		*                       expiration. The whole token is invalid after this time.
		* @return The app token.
		*/
		static buildAppToken(appId, appCertificate, expire) {
			let accessToken = new AccessToken(appId, appCertificate, 0, expire);
			let apaasService = new ServiceApaas();
			apaasService.add_privilege(ServiceApaas.PRIVILEGE_APP, expire);
			accessToken.add_service(apaasService);
			return accessToken.build();
		}
	};
	module.exports.EducationTokenBuilder = EducationTokenBuilder;
}));
//#endregion
//#region node_modules/agora-token/src/FpaTokenBuilder.js
var require_FpaTokenBuilder = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var AccessToken = require_AccessToken2().AccessToken2;
	var ServiceFpa = require_AccessToken2().ServiceFpa;
	var FpaTokenBuilder = class {
		/**
		* Build the FPA token.
		* @param appId The App ID issued to you by Agora. Apply for a new App ID from
		* Agora Dashboard if it is missing from your kit. See Get an App ID.
		* @param appCertificate Certificate of the application that you registered in
		* the Agora Dashboard. See Get an App Certificate.
		* @return The FPA token. The token expires 24 hours after generation.
		*/
		static buildToken(appId, appCertificate) {
			let token = new AccessToken(appId, appCertificate, 0, 86400);
			let serviceFpa = new ServiceFpa();
			serviceFpa.add_privilege(ServiceFpa.kPrivilegeLogin, 0);
			token.add_service(serviceFpa);
			return token.build();
		}
	};
	module.exports.FpaTokenBuilder = FpaTokenBuilder;
}));
//#endregion
//#region node_modules/agora-token/src/RtmTokenBuilder2.js
var require_RtmTokenBuilder2 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var AccessToken = require_AccessToken2().AccessToken2;
	var ServiceRtm = require_AccessToken2().ServiceRtm;
	var ServiceRtm2 = require_AccessToken2().ServiceRtm2;
	var RtmTokenBuilder = class {
		/**
		* Build the RTM token.
		*
		* @param appId The App ID issued to you by Agora. Apply for a new App ID from
		* Agora Dashboard if it is missing from your kit. See Get an App ID.
		* @param appCertificate Certificate of the application that you registered in
		* the Agora Dashboard. See Get an App Certificate.
		* @param userId The user's account, max length is 64 Bytes.
		* @param expire represented by the number of seconds elapsed since now. If, for example, you want to access the
		* Agora Service within 10 minutes after the token is generated, set expire as 600(seconds). This value is
		* the whole token expiration and the service privilege expiration. The whole token is invalid after this
		* time.
		* @return The RTM token.
		*/
		static buildToken(appId, appCertificate, userId, expire) {
			let token = new AccessToken(appId, appCertificate, null, expire);
			let serviceRtm = new ServiceRtm(userId);
			serviceRtm.add_privilege(ServiceRtm.kPrivilegeLogin, expire);
			token.add_service(serviceRtm);
			return token.build();
		}
		/**
		* Build an RTM2 token with resource-level permissions.
		*
		* This special interface requires Agora assistance for proper usage.
		*
		* @param appId The App ID issued to you by Agora.
		* @param appCertificate Certificate of the application registered in the Agora Dashboard.
		* @param userId The user's account, max length is 64 bytes.
		* @param permissions The RTM2 resource-level permissions.
		* @param expire The number of seconds from now before the token expires. This value is the whole token
		* expiration and the service privilege expiration. The whole token is invalid after this time.
		* @return The RTM2 token.
		*/
		static buildTokenWithPermissions(appId, appCertificate, userId, permissions, expire) {
			const token = new AccessToken(appId, appCertificate, null, expire);
			const serviceRtm2 = new ServiceRtm2(userId, permissions);
			serviceRtm2.add_privilege(ServiceRtm2.kPrivilegeLogin, expire);
			token.add_service(serviceRtm2);
			return token.build();
		}
	};
	module.exports.RtmTokenBuilder = RtmTokenBuilder;
}));
//#endregion
//#region node_modules/agora-token/src/SttTokenBuilder.js
var require_SttTokenBuilder = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var AccessToken = require_AccessToken2().AccessToken2;
	var ServiceRtc = require_AccessToken2().ServiceRtc;
	var ServiceRtm = require_AccessToken2().ServiceRtm;
	var ServiceStt = require_AccessToken2().ServiceStt;
	var Role = require_RtcTokenBuilder2().Role;
	var SttTokenBuilder = class {
		/**
		* Builds a Token007 that carries RTC, RTM, and STT services.
		* @param {*} appId The App ID issued to you by Agora.
		* @param {*} appCertificate Certificate of the application that you registered in the Agora Dashboard.
		* @param {*} channelName The unique channel name for the AgoraRTC session in the string format.
		* @param {*} rtcAccount The RTC user's account, max length is 255 bytes.
		* @param {*} rtcRole Role.PUBLISHER for a broadcaster or Role.SUBSCRIBER for an audience member.
		* @param {*} rtcTokenExpire Represented by the number of seconds elapsed since now. This is the whole
		* token expiration. The whole token is invalid after this time, even if a privilege expiration time is
		* later.
		* @param {*} joinChannelPrivilegeExpire Represented by the number of seconds elapsed since now. This
		* value must not exceed rtcTokenExpire; otherwise, the privilege is limited by the token expiration time.
		* @param {*} pubAudioPrivilegeExpire Represented by the number of seconds elapsed since now. This value
		* must not exceed rtcTokenExpire; otherwise, the privilege is limited by the token expiration time.
		* @param {*} pubVideoPrivilegeExpire Represented by the number of seconds elapsed since now. This value
		* must not exceed rtcTokenExpire; otherwise, the privilege is limited by the token expiration time.
		* @param {*} pubDataStreamPrivilegeExpire Represented by the number of seconds elapsed since now. This
		* value must not exceed rtcTokenExpire; otherwise, the privilege is limited by the token expiration time.
		* @param {*} rtmUserId The RTM user's account, max length is 255 bytes.
		* @param {*} rtmTokenExpire Represented by the number of seconds elapsed since now. This value must not
		* exceed rtcTokenExpire; otherwise, the RTM login privilege is limited by the token expiration time.
		* @return The RTC, RTM, and STT token.
		*/
		static buildToken(appId, appCertificate, channelName, rtcAccount, rtcRole, rtcTokenExpire, joinChannelPrivilegeExpire, pubAudioPrivilegeExpire, pubVideoPrivilegeExpire, pubDataStreamPrivilegeExpire, rtmUserId, rtmTokenExpire) {
			const token = new AccessToken(appId, appCertificate, 0, rtcTokenExpire);
			const serviceRtc = new ServiceRtc(channelName, rtcAccount);
			serviceRtc.add_privilege(ServiceRtc.kPrivilegeJoinChannel, joinChannelPrivilegeExpire);
			if (rtcRole === Role.PUBLISHER) {
				serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishAudioStream, pubAudioPrivilegeExpire);
				serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishVideoStream, pubVideoPrivilegeExpire);
				serviceRtc.add_privilege(ServiceRtc.kPrivilegePublishDataStream, pubDataStreamPrivilegeExpire);
			}
			token.add_service(serviceRtc);
			const serviceRtm = new ServiceRtm(rtmUserId);
			serviceRtm.add_privilege(ServiceRtm.kPrivilegeLogin, rtmTokenExpire);
			token.add_service(serviceRtm);
			token.add_service(new ServiceStt());
			return token.build();
		}
	};
	module.exports = { SttTokenBuilder };
}));
//#endregion
//#region node_modules/agora-token/index.js
var require_agora_token = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		ApaasTokenBuilder: require_ApaasTokenBuilder().ApaasTokenBuilder,
		ChatTokenBuilder: require_ChatTokenBuilder().ChatTokenBuilder,
		ConvoAITokenBuilder: require_ConvoAITokenBuilder().ConvoAITokenBuilder,
		EducationTokenBuilder: require_EducationTokenBuilder().EducationTokenBuilder,
		FpaTokenBuilder: require_FpaTokenBuilder().FpaTokenBuilder,
		RtcRole: require_RtcTokenBuilder2().Role,
		RtcTokenBuilder: require_RtcTokenBuilder2().RtcTokenBuilder,
		RtmTokenBuilder: require_RtmTokenBuilder2().RtmTokenBuilder,
		Rtm2Permissions: require_AccessToken2().Rtm2Permissions,
		SttTokenBuilder: require_SttTokenBuilder().SttTokenBuilder
	};
}));
//#endregion
export default require_agora_token();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWdvcmEtdG9rZW4uanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vY3J5cHQvY3J5cHQuanMiLCIuLi8uLi9jaGFyZW5jL2NoYXJlbmMuanMiLCIuLi8uLi9pcy1idWZmZXIvaW5kZXguanMiLCIuLi8uLi9tZDUvbWQ1LmpzIiwiLi4vLi4vLi4vYnJvd3Nlci1leHRlcm5hbDpjcnlwdG8iLCIuLi8uLi8uLi9icm93c2VyLWV4dGVybmFsOnpsaWIiLCIuLi8uLi9hZ29yYS10b2tlbi9zcmMvQWNjZXNzVG9rZW4yLmpzIiwiLi4vLi4vYWdvcmEtdG9rZW4vc3JjL0FwYWFzVG9rZW5CdWlsZGVyLmpzIiwiLi4vLi4vYWdvcmEtdG9rZW4vc3JjL0NoYXRUb2tlbkJ1aWxkZXIuanMiLCIuLi8uLi9hZ29yYS10b2tlbi9zcmMvUnRjVG9rZW5CdWlsZGVyMi5qcyIsIi4uLy4uL2Fnb3JhLXRva2VuL3NyYy9Db252b0FJVG9rZW5CdWlsZGVyLmpzIiwiLi4vLi4vYWdvcmEtdG9rZW4vc3JjL0VkdWNhdGlvblRva2VuQnVpbGRlci5qcyIsIi4uLy4uL2Fnb3JhLXRva2VuL3NyYy9GcGFUb2tlbkJ1aWxkZXIuanMiLCIuLi8uLi9hZ29yYS10b2tlbi9zcmMvUnRtVG9rZW5CdWlsZGVyMi5qcyIsIi4uLy4uL2Fnb3JhLXRva2VuL3NyYy9TdHRUb2tlbkJ1aWxkZXIuanMiLCIuLi8uLi9hZ29yYS10b2tlbi9pbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24oKSB7XG4gIHZhciBiYXNlNjRtYXBcbiAgICAgID0gJ0FCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFlaYWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXowMTIzNDU2Nzg5Ky8nLFxuXG4gIGNyeXB0ID0ge1xuICAgIC8vIEJpdC13aXNlIHJvdGF0aW9uIGxlZnRcbiAgICByb3RsOiBmdW5jdGlvbihuLCBiKSB7XG4gICAgICByZXR1cm4gKG4gPDwgYikgfCAobiA+Pj4gKDMyIC0gYikpO1xuICAgIH0sXG5cbiAgICAvLyBCaXQtd2lzZSByb3RhdGlvbiByaWdodFxuICAgIHJvdHI6IGZ1bmN0aW9uKG4sIGIpIHtcbiAgICAgIHJldHVybiAobiA8PCAoMzIgLSBiKSkgfCAobiA+Pj4gYik7XG4gICAgfSxcblxuICAgIC8vIFN3YXAgYmlnLWVuZGlhbiB0byBsaXR0bGUtZW5kaWFuIGFuZCB2aWNlIHZlcnNhXG4gICAgZW5kaWFuOiBmdW5jdGlvbihuKSB7XG4gICAgICAvLyBJZiBudW1iZXIgZ2l2ZW4sIHN3YXAgZW5kaWFuXG4gICAgICBpZiAobi5jb25zdHJ1Y3RvciA9PSBOdW1iZXIpIHtcbiAgICAgICAgcmV0dXJuIGNyeXB0LnJvdGwobiwgOCkgJiAweDAwRkYwMEZGIHwgY3J5cHQucm90bChuLCAyNCkgJiAweEZGMDBGRjAwO1xuICAgICAgfVxuXG4gICAgICAvLyBFbHNlLCBhc3N1bWUgYXJyYXkgYW5kIHN3YXAgYWxsIGl0ZW1zXG4gICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG4ubGVuZ3RoOyBpKyspXG4gICAgICAgIG5baV0gPSBjcnlwdC5lbmRpYW4obltpXSk7XG4gICAgICByZXR1cm4gbjtcbiAgICB9LFxuXG4gICAgLy8gR2VuZXJhdGUgYW4gYXJyYXkgb2YgYW55IGxlbmd0aCBvZiByYW5kb20gYnl0ZXNcbiAgICByYW5kb21CeXRlczogZnVuY3Rpb24obikge1xuICAgICAgZm9yICh2YXIgYnl0ZXMgPSBbXTsgbiA+IDA7IG4tLSlcbiAgICAgICAgYnl0ZXMucHVzaChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAyNTYpKTtcbiAgICAgIHJldHVybiBieXRlcztcbiAgICB9LFxuXG4gICAgLy8gQ29udmVydCBhIGJ5dGUgYXJyYXkgdG8gYmlnLWVuZGlhbiAzMi1iaXQgd29yZHNcbiAgICBieXRlc1RvV29yZHM6IGZ1bmN0aW9uKGJ5dGVzKSB7XG4gICAgICBmb3IgKHZhciB3b3JkcyA9IFtdLCBpID0gMCwgYiA9IDA7IGkgPCBieXRlcy5sZW5ndGg7IGkrKywgYiArPSA4KVxuICAgICAgICB3b3Jkc1tiID4+PiA1XSB8PSBieXRlc1tpXSA8PCAoMjQgLSBiICUgMzIpO1xuICAgICAgcmV0dXJuIHdvcmRzO1xuICAgIH0sXG5cbiAgICAvLyBDb252ZXJ0IGJpZy1lbmRpYW4gMzItYml0IHdvcmRzIHRvIGEgYnl0ZSBhcnJheVxuICAgIHdvcmRzVG9CeXRlczogZnVuY3Rpb24od29yZHMpIHtcbiAgICAgIGZvciAodmFyIGJ5dGVzID0gW10sIGIgPSAwOyBiIDwgd29yZHMubGVuZ3RoICogMzI7IGIgKz0gOClcbiAgICAgICAgYnl0ZXMucHVzaCgod29yZHNbYiA+Pj4gNV0gPj4+ICgyNCAtIGIgJSAzMikpICYgMHhGRik7XG4gICAgICByZXR1cm4gYnl0ZXM7XG4gICAgfSxcblxuICAgIC8vIENvbnZlcnQgYSBieXRlIGFycmF5IHRvIGEgaGV4IHN0cmluZ1xuICAgIGJ5dGVzVG9IZXg6IGZ1bmN0aW9uKGJ5dGVzKSB7XG4gICAgICBmb3IgKHZhciBoZXggPSBbXSwgaSA9IDA7IGkgPCBieXRlcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBoZXgucHVzaCgoYnl0ZXNbaV0gPj4+IDQpLnRvU3RyaW5nKDE2KSk7XG4gICAgICAgIGhleC5wdXNoKChieXRlc1tpXSAmIDB4RikudG9TdHJpbmcoMTYpKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBoZXguam9pbignJyk7XG4gICAgfSxcblxuICAgIC8vIENvbnZlcnQgYSBoZXggc3RyaW5nIHRvIGEgYnl0ZSBhcnJheVxuICAgIGhleFRvQnl0ZXM6IGZ1bmN0aW9uKGhleCkge1xuICAgICAgZm9yICh2YXIgYnl0ZXMgPSBbXSwgYyA9IDA7IGMgPCBoZXgubGVuZ3RoOyBjICs9IDIpXG4gICAgICAgIGJ5dGVzLnB1c2gocGFyc2VJbnQoaGV4LnN1YnN0cihjLCAyKSwgMTYpKTtcbiAgICAgIHJldHVybiBieXRlcztcbiAgICB9LFxuXG4gICAgLy8gQ29udmVydCBhIGJ5dGUgYXJyYXkgdG8gYSBiYXNlLTY0IHN0cmluZ1xuICAgIGJ5dGVzVG9CYXNlNjQ6IGZ1bmN0aW9uKGJ5dGVzKSB7XG4gICAgICBmb3IgKHZhciBiYXNlNjQgPSBbXSwgaSA9IDA7IGkgPCBieXRlcy5sZW5ndGg7IGkgKz0gMykge1xuICAgICAgICB2YXIgdHJpcGxldCA9IChieXRlc1tpXSA8PCAxNikgfCAoYnl0ZXNbaSArIDFdIDw8IDgpIHwgYnl0ZXNbaSArIDJdO1xuICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IDQ7IGorKylcbiAgICAgICAgICBpZiAoaSAqIDggKyBqICogNiA8PSBieXRlcy5sZW5ndGggKiA4KVxuICAgICAgICAgICAgYmFzZTY0LnB1c2goYmFzZTY0bWFwLmNoYXJBdCgodHJpcGxldCA+Pj4gNiAqICgzIC0gaikpICYgMHgzRikpO1xuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIGJhc2U2NC5wdXNoKCc9Jyk7XG4gICAgICB9XG4gICAgICByZXR1cm4gYmFzZTY0LmpvaW4oJycpO1xuICAgIH0sXG5cbiAgICAvLyBDb252ZXJ0IGEgYmFzZS02NCBzdHJpbmcgdG8gYSBieXRlIGFycmF5XG4gICAgYmFzZTY0VG9CeXRlczogZnVuY3Rpb24oYmFzZTY0KSB7XG4gICAgICAvLyBSZW1vdmUgbm9uLWJhc2UtNjQgY2hhcmFjdGVyc1xuICAgICAgYmFzZTY0ID0gYmFzZTY0LnJlcGxhY2UoL1teQS1aMC05K1xcL10vaWcsICcnKTtcblxuICAgICAgZm9yICh2YXIgYnl0ZXMgPSBbXSwgaSA9IDAsIGltb2Q0ID0gMDsgaSA8IGJhc2U2NC5sZW5ndGg7XG4gICAgICAgICAgaW1vZDQgPSArK2kgJSA0KSB7XG4gICAgICAgIGlmIChpbW9kNCA9PSAwKSBjb250aW51ZTtcbiAgICAgICAgYnl0ZXMucHVzaCgoKGJhc2U2NG1hcC5pbmRleE9mKGJhc2U2NC5jaGFyQXQoaSAtIDEpKVxuICAgICAgICAgICAgJiAoTWF0aC5wb3coMiwgLTIgKiBpbW9kNCArIDgpIC0gMSkpIDw8IChpbW9kNCAqIDIpKVxuICAgICAgICAgICAgfCAoYmFzZTY0bWFwLmluZGV4T2YoYmFzZTY0LmNoYXJBdChpKSkgPj4+ICg2IC0gaW1vZDQgKiAyKSkpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGJ5dGVzO1xuICAgIH1cbiAgfTtcblxuICBtb2R1bGUuZXhwb3J0cyA9IGNyeXB0O1xufSkoKTtcbiIsInZhciBjaGFyZW5jID0ge1xuICAvLyBVVEYtOCBlbmNvZGluZ1xuICB1dGY4OiB7XG4gICAgLy8gQ29udmVydCBhIHN0cmluZyB0byBhIGJ5dGUgYXJyYXlcbiAgICBzdHJpbmdUb0J5dGVzOiBmdW5jdGlvbihzdHIpIHtcbiAgICAgIHJldHVybiBjaGFyZW5jLmJpbi5zdHJpbmdUb0J5dGVzKHVuZXNjYXBlKGVuY29kZVVSSUNvbXBvbmVudChzdHIpKSk7XG4gICAgfSxcblxuICAgIC8vIENvbnZlcnQgYSBieXRlIGFycmF5IHRvIGEgc3RyaW5nXG4gICAgYnl0ZXNUb1N0cmluZzogZnVuY3Rpb24oYnl0ZXMpIHtcbiAgICAgIHJldHVybiBkZWNvZGVVUklDb21wb25lbnQoZXNjYXBlKGNoYXJlbmMuYmluLmJ5dGVzVG9TdHJpbmcoYnl0ZXMpKSk7XG4gICAgfVxuICB9LFxuXG4gIC8vIEJpbmFyeSBlbmNvZGluZ1xuICBiaW46IHtcbiAgICAvLyBDb252ZXJ0IGEgc3RyaW5nIHRvIGEgYnl0ZSBhcnJheVxuICAgIHN0cmluZ1RvQnl0ZXM6IGZ1bmN0aW9uKHN0cikge1xuICAgICAgZm9yICh2YXIgYnl0ZXMgPSBbXSwgaSA9IDA7IGkgPCBzdHIubGVuZ3RoOyBpKyspXG4gICAgICAgIGJ5dGVzLnB1c2goc3RyLmNoYXJDb2RlQXQoaSkgJiAweEZGKTtcbiAgICAgIHJldHVybiBieXRlcztcbiAgICB9LFxuXG4gICAgLy8gQ29udmVydCBhIGJ5dGUgYXJyYXkgdG8gYSBzdHJpbmdcbiAgICBieXRlc1RvU3RyaW5nOiBmdW5jdGlvbihieXRlcykge1xuICAgICAgZm9yICh2YXIgc3RyID0gW10sIGkgPSAwOyBpIDwgYnl0ZXMubGVuZ3RoOyBpKyspXG4gICAgICAgIHN0ci5wdXNoKFN0cmluZy5mcm9tQ2hhckNvZGUoYnl0ZXNbaV0pKTtcbiAgICAgIHJldHVybiBzdHIuam9pbignJyk7XG4gICAgfVxuICB9XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IGNoYXJlbmM7XG4iLCIvKiFcbiAqIERldGVybWluZSBpZiBhbiBvYmplY3QgaXMgYSBCdWZmZXJcbiAqXG4gKiBAYXV0aG9yICAgRmVyb3NzIEFib3VraGFkaWplaCA8aHR0cHM6Ly9mZXJvc3Mub3JnPlxuICogQGxpY2Vuc2UgIE1JVFxuICovXG5cbi8vIFRoZSBfaXNCdWZmZXIgY2hlY2sgaXMgZm9yIFNhZmFyaSA1LTcgc3VwcG9ydCwgYmVjYXVzZSBpdCdzIG1pc3Npbmdcbi8vIE9iamVjdC5wcm90b3R5cGUuY29uc3RydWN0b3IuIFJlbW92ZSB0aGlzIGV2ZW50dWFsbHlcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKG9iaikge1xuICByZXR1cm4gb2JqICE9IG51bGwgJiYgKGlzQnVmZmVyKG9iaikgfHwgaXNTbG93QnVmZmVyKG9iaikgfHwgISFvYmouX2lzQnVmZmVyKVxufVxuXG5mdW5jdGlvbiBpc0J1ZmZlciAob2JqKSB7XG4gIHJldHVybiAhIW9iai5jb25zdHJ1Y3RvciAmJiB0eXBlb2Ygb2JqLmNvbnN0cnVjdG9yLmlzQnVmZmVyID09PSAnZnVuY3Rpb24nICYmIG9iai5jb25zdHJ1Y3Rvci5pc0J1ZmZlcihvYmopXG59XG5cbi8vIEZvciBOb2RlIHYwLjEwIHN1cHBvcnQuIFJlbW92ZSB0aGlzIGV2ZW50dWFsbHkuXG5mdW5jdGlvbiBpc1Nsb3dCdWZmZXIgKG9iaikge1xuICByZXR1cm4gdHlwZW9mIG9iai5yZWFkRmxvYXRMRSA9PT0gJ2Z1bmN0aW9uJyAmJiB0eXBlb2Ygb2JqLnNsaWNlID09PSAnZnVuY3Rpb24nICYmIGlzQnVmZmVyKG9iai5zbGljZSgwLCAwKSlcbn1cbiIsIihmdW5jdGlvbigpe1xyXG4gIHZhciBjcnlwdCA9IHJlcXVpcmUoJ2NyeXB0JyksXHJcbiAgICAgIHV0ZjggPSByZXF1aXJlKCdjaGFyZW5jJykudXRmOCxcclxuICAgICAgaXNCdWZmZXIgPSByZXF1aXJlKCdpcy1idWZmZXInKSxcclxuICAgICAgYmluID0gcmVxdWlyZSgnY2hhcmVuYycpLmJpbixcclxuXHJcbiAgLy8gVGhlIGNvcmVcclxuICBtZDUgPSBmdW5jdGlvbiAobWVzc2FnZSwgb3B0aW9ucykge1xyXG4gICAgLy8gQ29udmVydCB0byBieXRlIGFycmF5XHJcbiAgICBpZiAobWVzc2FnZS5jb25zdHJ1Y3RvciA9PSBTdHJpbmcpXHJcbiAgICAgIGlmIChvcHRpb25zICYmIG9wdGlvbnMuZW5jb2RpbmcgPT09ICdiaW5hcnknKVxyXG4gICAgICAgIG1lc3NhZ2UgPSBiaW4uc3RyaW5nVG9CeXRlcyhtZXNzYWdlKTtcclxuICAgICAgZWxzZVxyXG4gICAgICAgIG1lc3NhZ2UgPSB1dGY4LnN0cmluZ1RvQnl0ZXMobWVzc2FnZSk7XHJcbiAgICBlbHNlIGlmIChpc0J1ZmZlcihtZXNzYWdlKSlcclxuICAgICAgbWVzc2FnZSA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKG1lc3NhZ2UsIDApO1xyXG4gICAgZWxzZSBpZiAoIUFycmF5LmlzQXJyYXkobWVzc2FnZSkgJiYgbWVzc2FnZS5jb25zdHJ1Y3RvciAhPT0gVWludDhBcnJheSlcclxuICAgICAgbWVzc2FnZSA9IG1lc3NhZ2UudG9TdHJpbmcoKTtcclxuICAgIC8vIGVsc2UsIGFzc3VtZSBieXRlIGFycmF5IGFscmVhZHlcclxuXHJcbiAgICB2YXIgbSA9IGNyeXB0LmJ5dGVzVG9Xb3JkcyhtZXNzYWdlKSxcclxuICAgICAgICBsID0gbWVzc2FnZS5sZW5ndGggKiA4LFxyXG4gICAgICAgIGEgPSAgMTczMjU4NDE5MyxcclxuICAgICAgICBiID0gLTI3MTczMzg3OSxcclxuICAgICAgICBjID0gLTE3MzI1ODQxOTQsXHJcbiAgICAgICAgZCA9ICAyNzE3MzM4Nzg7XHJcblxyXG4gICAgLy8gU3dhcCBlbmRpYW5cclxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbS5sZW5ndGg7IGkrKykge1xyXG4gICAgICBtW2ldID0gKChtW2ldIDw8ICA4KSB8IChtW2ldID4+PiAyNCkpICYgMHgwMEZGMDBGRiB8XHJcbiAgICAgICAgICAgICAoKG1baV0gPDwgMjQpIHwgKG1baV0gPj4+ICA4KSkgJiAweEZGMDBGRjAwO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFBhZGRpbmdcclxuICAgIG1bbCA+Pj4gNV0gfD0gMHg4MCA8PCAobCAlIDMyKTtcclxuICAgIG1bKCgobCArIDY0KSA+Pj4gOSkgPDwgNCkgKyAxNF0gPSBsO1xyXG5cclxuICAgIC8vIE1ldGhvZCBzaG9ydGN1dHNcclxuICAgIHZhciBGRiA9IG1kNS5fZmYsXHJcbiAgICAgICAgR0cgPSBtZDUuX2dnLFxyXG4gICAgICAgIEhIID0gbWQ1Ll9oaCxcclxuICAgICAgICBJSSA9IG1kNS5faWk7XHJcblxyXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBtLmxlbmd0aDsgaSArPSAxNikge1xyXG5cclxuICAgICAgdmFyIGFhID0gYSxcclxuICAgICAgICAgIGJiID0gYixcclxuICAgICAgICAgIGNjID0gYyxcclxuICAgICAgICAgIGRkID0gZDtcclxuXHJcbiAgICAgIGEgPSBGRihhLCBiLCBjLCBkLCBtW2krIDBdLCAgNywgLTY4MDg3NjkzNik7XHJcbiAgICAgIGQgPSBGRihkLCBhLCBiLCBjLCBtW2krIDFdLCAxMiwgLTM4OTU2NDU4Nik7XHJcbiAgICAgIGMgPSBGRihjLCBkLCBhLCBiLCBtW2krIDJdLCAxNywgIDYwNjEwNTgxOSk7XHJcbiAgICAgIGIgPSBGRihiLCBjLCBkLCBhLCBtW2krIDNdLCAyMiwgLTEwNDQ1MjUzMzApO1xyXG4gICAgICBhID0gRkYoYSwgYiwgYywgZCwgbVtpKyA0XSwgIDcsIC0xNzY0MTg4OTcpO1xyXG4gICAgICBkID0gRkYoZCwgYSwgYiwgYywgbVtpKyA1XSwgMTIsICAxMjAwMDgwNDI2KTtcclxuICAgICAgYyA9IEZGKGMsIGQsIGEsIGIsIG1baSsgNl0sIDE3LCAtMTQ3MzIzMTM0MSk7XHJcbiAgICAgIGIgPSBGRihiLCBjLCBkLCBhLCBtW2krIDddLCAyMiwgLTQ1NzA1OTgzKTtcclxuICAgICAgYSA9IEZGKGEsIGIsIGMsIGQsIG1baSsgOF0sICA3LCAgMTc3MDAzNTQxNik7XHJcbiAgICAgIGQgPSBGRihkLCBhLCBiLCBjLCBtW2krIDldLCAxMiwgLTE5NTg0MTQ0MTcpO1xyXG4gICAgICBjID0gRkYoYywgZCwgYSwgYiwgbVtpKzEwXSwgMTcsIC00MjA2Myk7XHJcbiAgICAgIGIgPSBGRihiLCBjLCBkLCBhLCBtW2krMTFdLCAyMiwgLTE5OTA0MDQxNjIpO1xyXG4gICAgICBhID0gRkYoYSwgYiwgYywgZCwgbVtpKzEyXSwgIDcsICAxODA0NjAzNjgyKTtcclxuICAgICAgZCA9IEZGKGQsIGEsIGIsIGMsIG1baSsxM10sIDEyLCAtNDAzNDExMDEpO1xyXG4gICAgICBjID0gRkYoYywgZCwgYSwgYiwgbVtpKzE0XSwgMTcsIC0xNTAyMDAyMjkwKTtcclxuICAgICAgYiA9IEZGKGIsIGMsIGQsIGEsIG1baSsxNV0sIDIyLCAgMTIzNjUzNTMyOSk7XHJcblxyXG4gICAgICBhID0gR0coYSwgYiwgYywgZCwgbVtpKyAxXSwgIDUsIC0xNjU3OTY1MTApO1xyXG4gICAgICBkID0gR0coZCwgYSwgYiwgYywgbVtpKyA2XSwgIDksIC0xMDY5NTAxNjMyKTtcclxuICAgICAgYyA9IEdHKGMsIGQsIGEsIGIsIG1baSsxMV0sIDE0LCAgNjQzNzE3NzEzKTtcclxuICAgICAgYiA9IEdHKGIsIGMsIGQsIGEsIG1baSsgMF0sIDIwLCAtMzczODk3MzAyKTtcclxuICAgICAgYSA9IEdHKGEsIGIsIGMsIGQsIG1baSsgNV0sICA1LCAtNzAxNTU4NjkxKTtcclxuICAgICAgZCA9IEdHKGQsIGEsIGIsIGMsIG1baSsxMF0sICA5LCAgMzgwMTYwODMpO1xyXG4gICAgICBjID0gR0coYywgZCwgYSwgYiwgbVtpKzE1XSwgMTQsIC02NjA0NzgzMzUpO1xyXG4gICAgICBiID0gR0coYiwgYywgZCwgYSwgbVtpKyA0XSwgMjAsIC00MDU1Mzc4NDgpO1xyXG4gICAgICBhID0gR0coYSwgYiwgYywgZCwgbVtpKyA5XSwgIDUsICA1Njg0NDY0MzgpO1xyXG4gICAgICBkID0gR0coZCwgYSwgYiwgYywgbVtpKzE0XSwgIDksIC0xMDE5ODAzNjkwKTtcclxuICAgICAgYyA9IEdHKGMsIGQsIGEsIGIsIG1baSsgM10sIDE0LCAtMTg3MzYzOTYxKTtcclxuICAgICAgYiA9IEdHKGIsIGMsIGQsIGEsIG1baSsgOF0sIDIwLCAgMTE2MzUzMTUwMSk7XHJcbiAgICAgIGEgPSBHRyhhLCBiLCBjLCBkLCBtW2krMTNdLCAgNSwgLTE0NDQ2ODE0NjcpO1xyXG4gICAgICBkID0gR0coZCwgYSwgYiwgYywgbVtpKyAyXSwgIDksIC01MTQwMzc4NCk7XHJcbiAgICAgIGMgPSBHRyhjLCBkLCBhLCBiLCBtW2krIDddLCAxNCwgIDE3MzUzMjg0NzMpO1xyXG4gICAgICBiID0gR0coYiwgYywgZCwgYSwgbVtpKzEyXSwgMjAsIC0xOTI2NjA3NzM0KTtcclxuXHJcbiAgICAgIGEgPSBISChhLCBiLCBjLCBkLCBtW2krIDVdLCAgNCwgLTM3ODU1OCk7XHJcbiAgICAgIGQgPSBISChkLCBhLCBiLCBjLCBtW2krIDhdLCAxMSwgLTIwMjI1NzQ0NjMpO1xyXG4gICAgICBjID0gSEgoYywgZCwgYSwgYiwgbVtpKzExXSwgMTYsICAxODM5MDMwNTYyKTtcclxuICAgICAgYiA9IEhIKGIsIGMsIGQsIGEsIG1baSsxNF0sIDIzLCAtMzUzMDk1NTYpO1xyXG4gICAgICBhID0gSEgoYSwgYiwgYywgZCwgbVtpKyAxXSwgIDQsIC0xNTMwOTkyMDYwKTtcclxuICAgICAgZCA9IEhIKGQsIGEsIGIsIGMsIG1baSsgNF0sIDExLCAgMTI3Mjg5MzM1Myk7XHJcbiAgICAgIGMgPSBISChjLCBkLCBhLCBiLCBtW2krIDddLCAxNiwgLTE1NTQ5NzYzMik7XHJcbiAgICAgIGIgPSBISChiLCBjLCBkLCBhLCBtW2krMTBdLCAyMywgLTEwOTQ3MzA2NDApO1xyXG4gICAgICBhID0gSEgoYSwgYiwgYywgZCwgbVtpKzEzXSwgIDQsICA2ODEyNzkxNzQpO1xyXG4gICAgICBkID0gSEgoZCwgYSwgYiwgYywgbVtpKyAwXSwgMTEsIC0zNTg1MzcyMjIpO1xyXG4gICAgICBjID0gSEgoYywgZCwgYSwgYiwgbVtpKyAzXSwgMTYsIC03MjI1MjE5NzkpO1xyXG4gICAgICBiID0gSEgoYiwgYywgZCwgYSwgbVtpKyA2XSwgMjMsICA3NjAyOTE4OSk7XHJcbiAgICAgIGEgPSBISChhLCBiLCBjLCBkLCBtW2krIDldLCAgNCwgLTY0MDM2NDQ4Nyk7XHJcbiAgICAgIGQgPSBISChkLCBhLCBiLCBjLCBtW2krMTJdLCAxMSwgLTQyMTgxNTgzNSk7XHJcbiAgICAgIGMgPSBISChjLCBkLCBhLCBiLCBtW2krMTVdLCAxNiwgIDUzMDc0MjUyMCk7XHJcbiAgICAgIGIgPSBISChiLCBjLCBkLCBhLCBtW2krIDJdLCAyMywgLTk5NTMzODY1MSk7XHJcblxyXG4gICAgICBhID0gSUkoYSwgYiwgYywgZCwgbVtpKyAwXSwgIDYsIC0xOTg2MzA4NDQpO1xyXG4gICAgICBkID0gSUkoZCwgYSwgYiwgYywgbVtpKyA3XSwgMTAsICAxMTI2ODkxNDE1KTtcclxuICAgICAgYyA9IElJKGMsIGQsIGEsIGIsIG1baSsxNF0sIDE1LCAtMTQxNjM1NDkwNSk7XHJcbiAgICAgIGIgPSBJSShiLCBjLCBkLCBhLCBtW2krIDVdLCAyMSwgLTU3NDM0MDU1KTtcclxuICAgICAgYSA9IElJKGEsIGIsIGMsIGQsIG1baSsxMl0sICA2LCAgMTcwMDQ4NTU3MSk7XHJcbiAgICAgIGQgPSBJSShkLCBhLCBiLCBjLCBtW2krIDNdLCAxMCwgLTE4OTQ5ODY2MDYpO1xyXG4gICAgICBjID0gSUkoYywgZCwgYSwgYiwgbVtpKzEwXSwgMTUsIC0xMDUxNTIzKTtcclxuICAgICAgYiA9IElJKGIsIGMsIGQsIGEsIG1baSsgMV0sIDIxLCAtMjA1NDkyMjc5OSk7XHJcbiAgICAgIGEgPSBJSShhLCBiLCBjLCBkLCBtW2krIDhdLCAgNiwgIDE4NzMzMTMzNTkpO1xyXG4gICAgICBkID0gSUkoZCwgYSwgYiwgYywgbVtpKzE1XSwgMTAsIC0zMDYxMTc0NCk7XHJcbiAgICAgIGMgPSBJSShjLCBkLCBhLCBiLCBtW2krIDZdLCAxNSwgLTE1NjAxOTgzODApO1xyXG4gICAgICBiID0gSUkoYiwgYywgZCwgYSwgbVtpKzEzXSwgMjEsICAxMzA5MTUxNjQ5KTtcclxuICAgICAgYSA9IElJKGEsIGIsIGMsIGQsIG1baSsgNF0sICA2LCAtMTQ1NTIzMDcwKTtcclxuICAgICAgZCA9IElJKGQsIGEsIGIsIGMsIG1baSsxMV0sIDEwLCAtMTEyMDIxMDM3OSk7XHJcbiAgICAgIGMgPSBJSShjLCBkLCBhLCBiLCBtW2krIDJdLCAxNSwgIDcxODc4NzI1OSk7XHJcbiAgICAgIGIgPSBJSShiLCBjLCBkLCBhLCBtW2krIDldLCAyMSwgLTM0MzQ4NTU1MSk7XHJcblxyXG4gICAgICBhID0gKGEgKyBhYSkgPj4+IDA7XHJcbiAgICAgIGIgPSAoYiArIGJiKSA+Pj4gMDtcclxuICAgICAgYyA9IChjICsgY2MpID4+PiAwO1xyXG4gICAgICBkID0gKGQgKyBkZCkgPj4+IDA7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGNyeXB0LmVuZGlhbihbYSwgYiwgYywgZF0pO1xyXG4gIH07XHJcblxyXG4gIC8vIEF1eGlsaWFyeSBmdW5jdGlvbnNcclxuICBtZDUuX2ZmICA9IGZ1bmN0aW9uIChhLCBiLCBjLCBkLCB4LCBzLCB0KSB7XHJcbiAgICB2YXIgbiA9IGEgKyAoYiAmIGMgfCB+YiAmIGQpICsgKHggPj4+IDApICsgdDtcclxuICAgIHJldHVybiAoKG4gPDwgcykgfCAobiA+Pj4gKDMyIC0gcykpKSArIGI7XHJcbiAgfTtcclxuICBtZDUuX2dnICA9IGZ1bmN0aW9uIChhLCBiLCBjLCBkLCB4LCBzLCB0KSB7XHJcbiAgICB2YXIgbiA9IGEgKyAoYiAmIGQgfCBjICYgfmQpICsgKHggPj4+IDApICsgdDtcclxuICAgIHJldHVybiAoKG4gPDwgcykgfCAobiA+Pj4gKDMyIC0gcykpKSArIGI7XHJcbiAgfTtcclxuICBtZDUuX2hoICA9IGZ1bmN0aW9uIChhLCBiLCBjLCBkLCB4LCBzLCB0KSB7XHJcbiAgICB2YXIgbiA9IGEgKyAoYiBeIGMgXiBkKSArICh4ID4+PiAwKSArIHQ7XHJcbiAgICByZXR1cm4gKChuIDw8IHMpIHwgKG4gPj4+ICgzMiAtIHMpKSkgKyBiO1xyXG4gIH07XHJcbiAgbWQ1Ll9paSAgPSBmdW5jdGlvbiAoYSwgYiwgYywgZCwgeCwgcywgdCkge1xyXG4gICAgdmFyIG4gPSBhICsgKGMgXiAoYiB8IH5kKSkgKyAoeCA+Pj4gMCkgKyB0O1xyXG4gICAgcmV0dXJuICgobiA8PCBzKSB8IChuID4+PiAoMzIgLSBzKSkpICsgYjtcclxuICB9O1xyXG5cclxuICAvLyBQYWNrYWdlIHByaXZhdGUgYmxvY2tzaXplXHJcbiAgbWQ1Ll9ibG9ja3NpemUgPSAxNjtcclxuICBtZDUuX2RpZ2VzdHNpemUgPSAxNjtcclxuXHJcbiAgbW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiAobWVzc2FnZSwgb3B0aW9ucykge1xyXG4gICAgaWYgKG1lc3NhZ2UgPT09IHVuZGVmaW5lZCB8fCBtZXNzYWdlID09PSBudWxsKVxyXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0lsbGVnYWwgYXJndW1lbnQgJyArIG1lc3NhZ2UpO1xyXG5cclxuICAgIHZhciBkaWdlc3RieXRlcyA9IGNyeXB0LndvcmRzVG9CeXRlcyhtZDUobWVzc2FnZSwgb3B0aW9ucykpO1xyXG4gICAgcmV0dXJuIG9wdGlvbnMgJiYgb3B0aW9ucy5hc0J5dGVzID8gZGlnZXN0Ynl0ZXMgOlxyXG4gICAgICAgIG9wdGlvbnMgJiYgb3B0aW9ucy5hc1N0cmluZyA/IGJpbi5ieXRlc1RvU3RyaW5nKGRpZ2VzdGJ5dGVzKSA6XHJcbiAgICAgICAgY3J5cHQuYnl0ZXNUb0hleChkaWdlc3RieXRlcyk7XHJcbiAgfTtcclxuXHJcbn0pKCk7XHJcbiIsIiAgICBtb2R1bGUuZXhwb3J0cyA9IE9iamVjdC5jcmVhdGUobmV3IFByb3h5KHt9LCB7XG4gICAgICAgIGdldChfLCBrZXkpIHtcbiAgICAgICAgaWYgKFxuICAgICAgICAgICAga2V5ICE9PSAnX19lc01vZHVsZScgJiZcbiAgICAgICAgICAgIGtleSAhPT0gJ19fcHJvdG9fXycgJiZcbiAgICAgICAgICAgIGtleSAhPT0gJ2NvbnN0cnVjdG9yJyAmJlxuICAgICAgICAgICAga2V5ICE9PSAnc3BsaWNlJ1xuICAgICAgICApIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihgTW9kdWxlIFwiY3J5cHRvXCIgaGFzIGJlZW4gZXh0ZXJuYWxpemVkIGZvciBicm93c2VyIGNvbXBhdGliaWxpdHkuIENhbm5vdCBhY2Nlc3MgXCJjcnlwdG8uJHtrZXl9XCIgaW4gY2xpZW50IGNvZGUuIFNlZSBodHRwczovL3ZpdGUuZGV2L2d1aWRlL3Ryb3VibGVzaG9vdGluZy5odG1sI21vZHVsZS1leHRlcm5hbGl6ZWQtZm9yLWJyb3dzZXItY29tcGF0aWJpbGl0eSBmb3IgbW9yZSBkZXRhaWxzLmApXG4gICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0pKSIsIiAgICBtb2R1bGUuZXhwb3J0cyA9IE9iamVjdC5jcmVhdGUobmV3IFByb3h5KHt9LCB7XG4gICAgICAgIGdldChfLCBrZXkpIHtcbiAgICAgICAgaWYgKFxuICAgICAgICAgICAga2V5ICE9PSAnX19lc01vZHVsZScgJiZcbiAgICAgICAgICAgIGtleSAhPT0gJ19fcHJvdG9fXycgJiZcbiAgICAgICAgICAgIGtleSAhPT0gJ2NvbnN0cnVjdG9yJyAmJlxuICAgICAgICAgICAga2V5ICE9PSAnc3BsaWNlJ1xuICAgICAgICApIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihgTW9kdWxlIFwiemxpYlwiIGhhcyBiZWVuIGV4dGVybmFsaXplZCBmb3IgYnJvd3NlciBjb21wYXRpYmlsaXR5LiBDYW5ub3QgYWNjZXNzIFwiemxpYi4ke2tleX1cIiBpbiBjbGllbnQgY29kZS4gU2VlIGh0dHBzOi8vdml0ZS5kZXYvZ3VpZGUvdHJvdWJsZXNob290aW5nLmh0bWwjbW9kdWxlLWV4dGVybmFsaXplZC1mb3ItYnJvd3Nlci1jb21wYXRpYmlsaXR5IGZvciBtb3JlIGRldGFpbHMuYClcbiAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSkpIiwidmFyIGNyeXB0byA9IHJlcXVpcmUoJ2NyeXB0bycpXG5jb25zdCB6bGliID0gcmVxdWlyZSgnemxpYicpXG5jb25zdCBWRVJTSU9OX0xFTkdUSCA9IDNcblxuLy8gUmV0dXJucyB0aGUgVG9rZW4wMDcgdmVyc2lvbiBwcmVmaXguXG5jb25zdCBnZXRWZXJzaW9uID0gKCkgPT4ge1xuICAgIHJldHVybiAnMDA3J1xufVxuXG4vLyBSZXR1cm5zIHdoZXRoZXIgYSB2YWx1ZSBpcyBhIDMyLWNoYXJhY3RlciBoZXhhZGVjaW1hbCBpZGVudGlmaWVyLlxuY29uc3QgaXNVdWlkID0gdmFsdWUgPT4ge1xuICAgIHJldHVybiB2YWx1ZSAhPT0gbnVsbCAmJiB0eXBlb2YgdmFsdWUgIT09ICd1bmRlZmluZWQnICYmIC9eWzAtOWEtZkEtRl17MzJ9JC8udGVzdCh2YWx1ZS50b1N0cmluZygpKVxufVxuXG4vLyBSZXByZXNlbnRzIHRoZSBjb21tb24gc2VydmljZSB0eXBlIGFuZCBwcml2aWxlZ2UgcGF5bG9hZC5cbmNsYXNzIFNlcnZpY2Uge1xuICAgIC8vIENyZWF0ZXMgYSBzZXJ2aWNlIHdpdGggdGhlIHNwZWNpZmllZCBudW1lcmljIHR5cGUuXG4gICAgY29uc3RydWN0b3Ioc2VydmljZV90eXBlKSB7XG4gICAgICAgIHRoaXMuX190eXBlID0gc2VydmljZV90eXBlXG4gICAgICAgIHRoaXMuX19wcml2aWxlZ2VzID0ge31cbiAgICB9XG5cbiAgICAvLyBTZXJpYWxpemVzIHRoZSBudW1lcmljIHNlcnZpY2UgdHlwZS5cbiAgICBfX3BhY2tfdHlwZSgpIHtcbiAgICAgICAgbGV0IGJ1ZiA9IG5ldyBCeXRlQnVmKClcbiAgICAgICAgYnVmLnB1dFVpbnQxNih0aGlzLl9fdHlwZSlcbiAgICAgICAgcmV0dXJuIGJ1Zi5wYWNrKClcbiAgICB9XG5cbiAgICAvLyBTZXJpYWxpemVzIHRoZSBzZXJ2aWNlIHByaXZpbGVnZSBtYXAuXG4gICAgX19wYWNrX3ByaXZpbGVnZXMoKSB7XG4gICAgICAgIGxldCBidWYgPSBuZXcgQnl0ZUJ1ZigpXG4gICAgICAgIGJ1Zi5wdXRUcmVlTWFwVUludDMyKHRoaXMuX19wcml2aWxlZ2VzKVxuICAgICAgICByZXR1cm4gYnVmLnBhY2soKVxuICAgIH1cblxuICAgIC8vIFJldHVybnMgdGhlIG51bWVyaWMgc2VydmljZSB0eXBlLlxuICAgIHNlcnZpY2VfdHlwZSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX190eXBlXG4gICAgfVxuXG4gICAgLy8gQWRkcyBvciB1cGRhdGVzIGEgc2VydmljZSBwcml2aWxlZ2UgZXhwaXJhdGlvbiB0aW1lc3RhbXAuXG4gICAgYWRkX3ByaXZpbGVnZShwcml2aWxlZ2UsIGV4cGlyZSkge1xuICAgICAgICB0aGlzLl9fcHJpdmlsZWdlc1twcml2aWxlZ2VdID0gZXhwaXJlXG4gICAgfVxuXG4gICAgLy8gU2VyaWFsaXplcyB0aGUgc2VydmljZSB0eXBlIGFuZCBwcml2aWxlZ2VzLlxuICAgIHBhY2soKSB7XG4gICAgICAgIHJldHVybiBCdWZmZXIuY29uY2F0KFt0aGlzLl9fcGFja190eXBlKCksIHRoaXMuX19wYWNrX3ByaXZpbGVnZXMoKV0pXG4gICAgfVxuXG4gICAgLy8gRGVzZXJpYWxpemVzIHNlcnZpY2UgcHJpdmlsZWdlcyBhZnRlciB0aGUgdHlwZSBoYXMgYmVlbiBjb25zdW1lZC5cbiAgICB1bnBhY2soYnVmZmVyKSB7XG4gICAgICAgIGxldCBidWZSZWFkZXIgPSBuZXcgUmVhZEJ5dGVCdWYoYnVmZmVyKVxuICAgICAgICB0aGlzLl9fcHJpdmlsZWdlcyA9IGJ1ZlJlYWRlci5nZXRUcmVlTWFwVUludDMyKClcbiAgICAgICAgcmV0dXJuIGJ1ZlJlYWRlclxuICAgIH1cbn1cblxuY29uc3Qga1J0Y1NlcnZpY2VUeXBlID0gMVxuXG4vLyBSZXByZXNlbnRzIGFuIFJUQyBzZXJ2aWNlIHBheWxvYWQuXG5jbGFzcyBTZXJ2aWNlUnRjIGV4dGVuZHMgU2VydmljZSB7XG4gICAgLy8gQ3JlYXRlcyBhbiBSVEMgc2VydmljZSBmb3IgYSBjaGFubmVsIGFuZCB1c2VyIElELlxuICAgIGNvbnN0cnVjdG9yKGNoYW5uZWxfbmFtZSwgdWlkKSB7XG4gICAgICAgIHN1cGVyKGtSdGNTZXJ2aWNlVHlwZSlcbiAgICAgICAgdGhpcy5fX2NoYW5uZWxfbmFtZSA9IGNoYW5uZWxfbmFtZVxuICAgICAgICB0aGlzLl9fdWlkID0gdWlkID09PSAwID8gJycgOiBgJHt1aWR9YFxuICAgIH1cblxuICAgIC8vIFNlcmlhbGl6ZXMgdGhlIFJUQyBzZXJ2aWNlIHBheWxvYWQuXG4gICAgcGFjaygpIHtcbiAgICAgICAgbGV0IGJ1ZmZlciA9IG5ldyBCeXRlQnVmKClcbiAgICAgICAgYnVmZmVyLnB1dFN0cmluZyh0aGlzLl9fY2hhbm5lbF9uYW1lKS5wdXRTdHJpbmcodGhpcy5fX3VpZClcbiAgICAgICAgcmV0dXJuIEJ1ZmZlci5jb25jYXQoW3N1cGVyLnBhY2soKSwgYnVmZmVyLnBhY2soKV0pXG4gICAgfVxuXG4gICAgLy8gRGVzZXJpYWxpemVzIHRoZSBSVEMgc2VydmljZSBwYXlsb2FkLlxuICAgIHVucGFjayhidWZmZXIpIHtcbiAgICAgICAgbGV0IGJ1ZlJlYWRlciA9IHN1cGVyLnVucGFjayhidWZmZXIpXG4gICAgICAgIHRoaXMuX19jaGFubmVsX25hbWUgPSBidWZSZWFkZXIuZ2V0U3RyaW5nKClcbiAgICAgICAgdGhpcy5fX3VpZCA9IGJ1ZlJlYWRlci5nZXRTdHJpbmcoKVxuICAgICAgICByZXR1cm4gYnVmUmVhZGVyXG4gICAgfVxufVxuXG5TZXJ2aWNlUnRjLmtQcml2aWxlZ2VKb2luQ2hhbm5lbCA9IDFcblNlcnZpY2VSdGMua1ByaXZpbGVnZVB1Ymxpc2hBdWRpb1N0cmVhbSA9IDJcblNlcnZpY2VSdGMua1ByaXZpbGVnZVB1Ymxpc2hWaWRlb1N0cmVhbSA9IDNcblNlcnZpY2VSdGMua1ByaXZpbGVnZVB1Ymxpc2hEYXRhU3RyZWFtID0gNFxuXG5jb25zdCBrUnRtU2VydmljZVR5cGUgPSAyXG5cbi8vIFJlcHJlc2VudHMgYW4gUlRNIHNlcnZpY2UgcGF5bG9hZC5cbmNsYXNzIFNlcnZpY2VSdG0gZXh0ZW5kcyBTZXJ2aWNlIHtcbiAgICAvLyBDcmVhdGVzIGFuIFJUTSBzZXJ2aWNlIGZvciBhIHVzZXIgSUQuXG4gICAgY29uc3RydWN0b3IodXNlcl9pZCkge1xuICAgICAgICBzdXBlcihrUnRtU2VydmljZVR5cGUpXG4gICAgICAgIHRoaXMuX191c2VyX2lkID0gdXNlcl9pZCB8fCAnJ1xuICAgIH1cblxuICAgIC8vIFNlcmlhbGl6ZXMgdGhlIFJUTSBzZXJ2aWNlIHBheWxvYWQuXG4gICAgcGFjaygpIHtcbiAgICAgICAgbGV0IGJ1ZmZlciA9IG5ldyBCeXRlQnVmKClcbiAgICAgICAgYnVmZmVyLnB1dFN0cmluZyh0aGlzLl9fdXNlcl9pZClcbiAgICAgICAgcmV0dXJuIEJ1ZmZlci5jb25jYXQoW3N1cGVyLnBhY2soKSwgYnVmZmVyLnBhY2soKV0pXG4gICAgfVxuXG4gICAgLy8gRGVzZXJpYWxpemVzIHRoZSBSVE0gc2VydmljZSBwYXlsb2FkLlxuICAgIHVucGFjayhidWZmZXIpIHtcbiAgICAgICAgbGV0IGJ1ZlJlYWRlciA9IHN1cGVyLnVucGFjayhidWZmZXIpXG4gICAgICAgIHRoaXMuX191c2VyX2lkID0gYnVmUmVhZGVyLmdldFN0cmluZygpXG4gICAgICAgIHJldHVybiBidWZSZWFkZXJcbiAgICB9XG59XG5cblNlcnZpY2VSdG0ua1ByaXZpbGVnZUxvZ2luID0gMVxuXG5jb25zdCBrU3RyZWFtaW5nU2VydmljZVR5cGUgPSAzXG5cbi8vIFJlcHJlc2VudHMgYSBTdHJlYW1pbmcgc2VydmljZSBwYXlsb2FkLlxuY2xhc3MgU2VydmljZVN0cmVhbWluZyBleHRlbmRzIFNlcnZpY2Uge1xuICAgIC8vIENyZWF0ZXMgYSBTdHJlYW1pbmcgc2VydmljZSBmb3IgYSBjaGFubmVsIGFuZCBudW1lcmljIHVzZXIgSUQgb3Igc3RyaW5nIGFjY291bnQuXG4gICAgY29uc3RydWN0b3IoY2hhbm5lbE5hbWUgPSAnJywgYWNjb3VudCA9ICcnKSB7XG4gICAgICAgIHN1cGVyKGtTdHJlYW1pbmdTZXJ2aWNlVHlwZSlcbiAgICAgICAgdGhpcy5fX2NoYW5uZWxfbmFtZSA9IGNoYW5uZWxOYW1lXG4gICAgICAgIHRoaXMuX19hY2NvdW50ID0gYWNjb3VudCA9PT0gMCA/ICcnIDogYCR7YWNjb3VudH1gXG4gICAgfVxuXG4gICAgLy8gU2VyaWFsaXplcyB0aGUgU3RyZWFtaW5nIHNlcnZpY2UgcGF5bG9hZC5cbiAgICBwYWNrKCkge1xuICAgICAgICBjb25zdCBidWZmZXIgPSBuZXcgQnl0ZUJ1ZigpLnB1dFN0cmluZyh0aGlzLl9fY2hhbm5lbF9uYW1lKS5wdXRTdHJpbmcodGhpcy5fX2FjY291bnQpXG4gICAgICAgIHJldHVybiBCdWZmZXIuY29uY2F0KFtzdXBlci5wYWNrKCksIGJ1ZmZlci5wYWNrKCldKVxuICAgIH1cblxuICAgIC8vIERlc2VyaWFsaXplcyB0aGUgU3RyZWFtaW5nIHNlcnZpY2UgcGF5bG9hZC5cbiAgICB1bnBhY2soYnVmZmVyKSB7XG4gICAgICAgIGNvbnN0IHJlYWRlciA9IHN1cGVyLnVucGFjayhidWZmZXIpXG4gICAgICAgIHRoaXMuX19jaGFubmVsX25hbWUgPSByZWFkZXIuZ2V0U3RyaW5nKClcbiAgICAgICAgdGhpcy5fX2FjY291bnQgPSByZWFkZXIuZ2V0U3RyaW5nKClcbiAgICAgICAgcmV0dXJuIHJlYWRlclxuICAgIH1cbn1cblxuU2VydmljZVN0cmVhbWluZy5rUHJpdmlsZWdlUHVibGlzaE1peFN0cmVhbSA9IDFcblNlcnZpY2VTdHJlYW1pbmcua1ByaXZpbGVnZVB1Ymxpc2hSYXdTdHJlYW0gPSAyXG5cbmNvbnN0IGtGcGFTZXJ2aWNlVHlwZSA9IDRcblxuLy8gUmVwcmVzZW50cyBhbiBGUEEgc2VydmljZSBwYXlsb2FkLlxuY2xhc3MgU2VydmljZUZwYSBleHRlbmRzIFNlcnZpY2Uge1xuICAgIC8vIENyZWF0ZXMgYW4gRlBBIHNlcnZpY2UuXG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKGtGcGFTZXJ2aWNlVHlwZSlcbiAgICB9XG5cbiAgICAvLyBTZXJpYWxpemVzIHRoZSBGUEEgc2VydmljZSBwYXlsb2FkLlxuICAgIHBhY2soKSB7XG4gICAgICAgIHJldHVybiBzdXBlci5wYWNrKClcbiAgICB9XG5cbiAgICAvLyBEZXNlcmlhbGl6ZXMgdGhlIEZQQSBzZXJ2aWNlIHBheWxvYWQuXG4gICAgdW5wYWNrKGJ1ZmZlcikge1xuICAgICAgICBsZXQgYnVmUmVhZGVyID0gc3VwZXIudW5wYWNrKGJ1ZmZlcilcbiAgICAgICAgcmV0dXJuIGJ1ZlJlYWRlclxuICAgIH1cbn1cblxuU2VydmljZUZwYS5rUHJpdmlsZWdlTG9naW4gPSAxXG5cbmNvbnN0IGtDb252b0FJU2VydmljZVR5cGUgPSA5XG5cbi8vIFJlcHJlc2VudHMgYSBDb252b0FJIHNlcnZpY2UgcGF5bG9hZC5cbmNsYXNzIFNlcnZpY2VDb252b0FJIGV4dGVuZHMgU2VydmljZSB7XG4gICAgLy8gQ3JlYXRlcyBhIENvbnZvQUkgc2VydmljZS5cbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoa0NvbnZvQUlTZXJ2aWNlVHlwZSlcbiAgICB9XG5cbiAgICAvLyBTZXJpYWxpemVzIHRoZSBDb252b0FJIHNlcnZpY2UgcGF5bG9hZC5cbiAgICBwYWNrKCkge1xuICAgICAgICByZXR1cm4gc3VwZXIucGFjaygpXG4gICAgfVxuXG4gICAgLy8gRGVzZXJpYWxpemVzIHRoZSBDb252b0FJIHNlcnZpY2UgcGF5bG9hZC5cbiAgICB1bnBhY2soYnVmZmVyKSB7XG4gICAgICAgIHJldHVybiBzdXBlci51bnBhY2soYnVmZmVyKVxuICAgIH1cbn1cblxuY29uc3Qga1N0dFNlcnZpY2VUeXBlID0gMTBcblxuLy8gUmVwcmVzZW50cyBhbiBTVFQgc2VydmljZSBwYXlsb2FkLlxuY2xhc3MgU2VydmljZVN0dCBleHRlbmRzIFNlcnZpY2Uge1xuICAgIC8vIENyZWF0ZXMgYW4gU1RUIHNlcnZpY2UuXG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKGtTdHRTZXJ2aWNlVHlwZSlcbiAgICB9XG5cbiAgICAvLyBTZXJpYWxpemVzIHRoZSBTVFQgc2VydmljZSBwYXlsb2FkLlxuICAgIHBhY2soKSB7XG4gICAgICAgIHJldHVybiBzdXBlci5wYWNrKClcbiAgICB9XG5cbiAgICAvLyBEZXNlcmlhbGl6ZXMgdGhlIFNUVCBzZXJ2aWNlIHBheWxvYWQuXG4gICAgdW5wYWNrKGJ1ZmZlcikge1xuICAgICAgICByZXR1cm4gc3VwZXIudW5wYWNrKGJ1ZmZlcilcbiAgICB9XG59XG5cbmNvbnN0IGtDaGF0U2VydmljZVR5cGUgPSA1XG5cbi8vIFJlcHJlc2VudHMgYSBDaGF0IHNlcnZpY2UgcGF5bG9hZC5cbmNsYXNzIFNlcnZpY2VDaGF0IGV4dGVuZHMgU2VydmljZSB7XG4gICAgLy8gQ3JlYXRlcyBhIENoYXQgc2VydmljZSBmb3IgYSB1c2VyIElELlxuICAgIGNvbnN0cnVjdG9yKHVzZXJfaWQpIHtcbiAgICAgICAgc3VwZXIoa0NoYXRTZXJ2aWNlVHlwZSlcbiAgICAgICAgdGhpcy5fX3VzZXJfaWQgPSB1c2VyX2lkIHx8ICcnXG4gICAgfVxuXG4gICAgLy8gU2VyaWFsaXplcyB0aGUgQ2hhdCBzZXJ2aWNlIHBheWxvYWQuXG4gICAgcGFjaygpIHtcbiAgICAgICAgbGV0IGJ1ZmZlciA9IG5ldyBCeXRlQnVmKClcbiAgICAgICAgYnVmZmVyLnB1dFN0cmluZyh0aGlzLl9fdXNlcl9pZClcbiAgICAgICAgcmV0dXJuIEJ1ZmZlci5jb25jYXQoW3N1cGVyLnBhY2soKSwgYnVmZmVyLnBhY2soKV0pXG4gICAgfVxuXG4gICAgLy8gRGVzZXJpYWxpemVzIHRoZSBDaGF0IHNlcnZpY2UgcGF5bG9hZC5cbiAgICB1bnBhY2soYnVmZmVyKSB7XG4gICAgICAgIGxldCBidWZSZWFkZXIgPSBzdXBlci51bnBhY2soYnVmZmVyKVxuICAgICAgICB0aGlzLl9fdXNlcl9pZCA9IGJ1ZlJlYWRlci5nZXRTdHJpbmcoKVxuICAgICAgICByZXR1cm4gYnVmUmVhZGVyXG4gICAgfVxufVxuXG5TZXJ2aWNlQ2hhdC5rUHJpdmlsZWdlVXNlciA9IDFcblNlcnZpY2VDaGF0LmtQcml2aWxlZ2VBcHAgPSAyXG5cbmNvbnN0IGtGQ2RuU2VydmljZVR5cGUgPSA2XG5cbi8vIFJlcHJlc2VudHMgYW4gRkNETiBzZXJ2aWNlIHBheWxvYWQuXG5jbGFzcyBTZXJ2aWNlRkNkbiBleHRlbmRzIFNlcnZpY2Uge1xuICAgIC8vIENyZWF0ZXMgYW4gRkNETiBzZXJ2aWNlIGZvciBhIGNoYW5uZWwgYW5kIG51bWVyaWMgdXNlciBJRCBvciBzdHJpbmcgYWNjb3VudC5cbiAgICBjb25zdHJ1Y3RvcihjaGFubmVsTmFtZSA9ICcnLCBhY2NvdW50ID0gJycpIHtcbiAgICAgICAgc3VwZXIoa0ZDZG5TZXJ2aWNlVHlwZSlcbiAgICAgICAgdGhpcy5fX2NoYW5uZWxfbmFtZSA9IGNoYW5uZWxOYW1lXG4gICAgICAgIHRoaXMuX19hY2NvdW50ID0gYWNjb3VudCA9PT0gMCA/ICcnIDogYCR7YWNjb3VudH1gXG4gICAgfVxuXG4gICAgLy8gU2VyaWFsaXplcyB0aGUgRkNETiBzZXJ2aWNlIHBheWxvYWQuXG4gICAgcGFjaygpIHtcbiAgICAgICAgY29uc3QgYnVmZmVyID0gbmV3IEJ5dGVCdWYoKS5wdXRTdHJpbmcodGhpcy5fX2NoYW5uZWxfbmFtZSkucHV0U3RyaW5nKHRoaXMuX19hY2NvdW50KVxuICAgICAgICByZXR1cm4gQnVmZmVyLmNvbmNhdChbc3VwZXIucGFjaygpLCBidWZmZXIucGFjaygpXSlcbiAgICB9XG5cbiAgICAvLyBEZXNlcmlhbGl6ZXMgdGhlIEZDRE4gc2VydmljZSBwYXlsb2FkLlxuICAgIHVucGFjayhidWZmZXIpIHtcbiAgICAgICAgY29uc3QgcmVhZGVyID0gc3VwZXIudW5wYWNrKGJ1ZmZlcilcbiAgICAgICAgdGhpcy5fX2NoYW5uZWxfbmFtZSA9IHJlYWRlci5nZXRTdHJpbmcoKVxuICAgICAgICB0aGlzLl9fYWNjb3VudCA9IHJlYWRlci5nZXRTdHJpbmcoKVxuICAgICAgICByZXR1cm4gcmVhZGVyXG4gICAgfVxufVxuXG5TZXJ2aWNlRkNkbi5rUHJpdmlsZWdlUHVibGlzaCA9IDFcblNlcnZpY2VGQ2RuLmtQcml2aWxlZ2VQbGF5ID0gMlxuXG5jb25zdCBrQXBhYXNTZXJ2aWNlVHlwZSA9IDdcblxuLy8gUmVwcmVzZW50cyBhbiBBUGFhUyBzZXJ2aWNlIHBheWxvYWQuXG5jbGFzcyBTZXJ2aWNlQXBhYXMgZXh0ZW5kcyBTZXJ2aWNlIHtcbiAgICAvLyBDcmVhdGVzIGFuIEFQYWFTIHNlcnZpY2UgZm9yIGEgcm9vbSwgdXNlciwgYW5kIHJvbGUuXG4gICAgY29uc3RydWN0b3Iocm9vbVV1aWQsIHVzZXJVdWlkLCByb2xlKSB7XG4gICAgICAgIHN1cGVyKGtBcGFhc1NlcnZpY2VUeXBlKVxuICAgICAgICB0aGlzLl9fcm9vbV91dWlkID0gcm9vbVV1aWQgfHwgJydcbiAgICAgICAgdGhpcy5fX3VzZXJfdXVpZCA9IHVzZXJVdWlkIHx8ICcnXG4gICAgICAgIHRoaXMuX19yb2xlID0gcm9sZSB8fCAtMVxuICAgIH1cblxuICAgIC8vIFNlcmlhbGl6ZXMgdGhlIEFQYWFTIHNlcnZpY2UgcGF5bG9hZC5cbiAgICBwYWNrKCkge1xuICAgICAgICBsZXQgYnVmZmVyID0gbmV3IEJ5dGVCdWYoKVxuICAgICAgICBidWZmZXIucHV0U3RyaW5nKHRoaXMuX19yb29tX3V1aWQpXG4gICAgICAgIGJ1ZmZlci5wdXRTdHJpbmcodGhpcy5fX3VzZXJfdXVpZClcbiAgICAgICAgYnVmZmVyLnB1dEludDE2KHRoaXMuX19yb2xlKVxuICAgICAgICByZXR1cm4gQnVmZmVyLmNvbmNhdChbc3VwZXIucGFjaygpLCBidWZmZXIucGFjaygpXSlcbiAgICB9XG5cbiAgICAvLyBEZXNlcmlhbGl6ZXMgdGhlIEFQYWFTIHNlcnZpY2UgcGF5bG9hZC5cbiAgICB1bnBhY2soYnVmZmVyKSB7XG4gICAgICAgIGxldCBidWZSZWFkZXIgPSBzdXBlci51bnBhY2soYnVmZmVyKVxuICAgICAgICB0aGlzLl9fcm9vbV91dWlkID0gYnVmUmVhZGVyLmdldFN0cmluZygpXG4gICAgICAgIHRoaXMuX191c2VyX3V1aWQgPSBidWZSZWFkZXIuZ2V0U3RyaW5nKClcbiAgICAgICAgdGhpcy5fX3JvbGUgPSBidWZSZWFkZXIuZ2V0SW50MTYoKVxuICAgICAgICByZXR1cm4gYnVmUmVhZGVyXG4gICAgfVxufVxuXG5TZXJ2aWNlQXBhYXMuUFJJVklMRUdFX1JPT01fVVNFUiA9IDFcblNlcnZpY2VBcGFhcy5QUklWSUxFR0VfVVNFUiA9IDJcblNlcnZpY2VBcGFhcy5QUklWSUxFR0VfQVBQID0gM1xuXG4vLyBTdG9yZXMgUlRNMiByZXNvdXJjZS1sZXZlbCBwZXJtaXNzaW9ucy5cbmNsYXNzIFJ0bTJQZXJtaXNzaW9ucyB7XG4gICAgLy8gQ3JlYXRlcyBhbiBlbXB0eSBSVE0yIHBlcm1pc3Npb24gc2V0LlxuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLmRldGFpbHMgPSB7fVxuICAgIH1cblxuICAgIC8vIEFkZHMgb3IgcmVwbGFjZXMgcmVzb3VyY2VzIGZvciBhIHJlc291cmNlIGFuZCBwZXJtaXNzaW9uIHR5cGUuXG4gICAgYWRkKHJlc291cmNlVHlwZSwgcGVybWlzc2lvblR5cGUsIHJlc291cmNlcykge1xuICAgICAgICBpZiAoIXRoaXMuZGV0YWlsc1tyZXNvdXJjZVR5cGVdKSB7XG4gICAgICAgICAgICB0aGlzLmRldGFpbHNbcmVzb3VyY2VUeXBlXSA9IHt9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5kZXRhaWxzW3Jlc291cmNlVHlwZV1bcGVybWlzc2lvblR5cGVdID0gQXJyYXkuZnJvbShyZXNvdXJjZXMpXG4gICAgfVxufVxuXG5SdG0yUGVybWlzc2lvbnMua01lc3NhZ2VDaGFubmVscyA9IDBcblJ0bTJQZXJtaXNzaW9ucy5rU3RyZWFtQ2hhbm5lbHMgPSAxXG5SdG0yUGVybWlzc2lvbnMua0dyb3VwQ2hhbm5lbHMgPSAyXG5SdG0yUGVybWlzc2lvbnMua1NlcnZlckdyb3VwcyA9IDNcblJ0bTJQZXJtaXNzaW9ucy5rVXNlcnMgPSA0XG5SdG0yUGVybWlzc2lvbnMua1JlYWQgPSAwXG5SdG0yUGVybWlzc2lvbnMua1dyaXRlID0gMVxuXG5jb25zdCBrUnRtMlNlcnZpY2VUeXBlID0gOFxuXG4vLyBSZXByZXNlbnRzIGFuIFJUTTIgc2VydmljZSBwYXlsb2FkLlxuY2xhc3MgU2VydmljZVJ0bTIgZXh0ZW5kcyBTZXJ2aWNlIHtcbiAgICAvLyBDcmVhdGVzIGFuIFJUTTIgc2VydmljZSBmb3IgYSB1c2VyIGFuZCBwZXJtaXNzaW9uIHNldC5cbiAgICBjb25zdHJ1Y3Rvcih1c2VySWQsIHBlcm1pc3Npb25zKSB7XG4gICAgICAgIHN1cGVyKGtSdG0yU2VydmljZVR5cGUpXG4gICAgICAgIHRoaXMuX191c2VyX2lkID0gdXNlcklkID09PSAwIHx8IHVzZXJJZCA9PSBudWxsID8gJycgOiBTdHJpbmcodXNlcklkKVxuICAgICAgICB0aGlzLl9fcGVybWlzc2lvbnMgPSBwZXJtaXNzaW9ucyB8fCBuZXcgUnRtMlBlcm1pc3Npb25zKClcbiAgICB9XG5cbiAgICAvLyBTZXJpYWxpemVzIHRoZSBSVE0yIHNlcnZpY2UgcGF5bG9hZC5cbiAgICBwYWNrKCkge1xuICAgICAgICBjb25zdCBidWZmZXIgPSBuZXcgQnl0ZUJ1ZigpLnB1dFN0cmluZyh0aGlzLl9fdXNlcl9pZClcbiAgICAgICAgY29uc3QgcmVzb3VyY2VUeXBlcyA9IE9iamVjdC5rZXlzKHRoaXMuX19wZXJtaXNzaW9ucy5kZXRhaWxzKS5tYXAoTnVtYmVyKS5zb3J0KChsZWZ0LCByaWdodCkgPT4gbGVmdCAtIHJpZ2h0KVxuICAgICAgICBidWZmZXIucHV0VWludDE2KHJlc291cmNlVHlwZXMubGVuZ3RoKVxuICAgICAgICByZXNvdXJjZVR5cGVzLmZvckVhY2gocmVzb3VyY2VUeXBlID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHBlcm1pc3Npb25NYXAgPSB0aGlzLl9fcGVybWlzc2lvbnMuZGV0YWlsc1tyZXNvdXJjZVR5cGVdXG4gICAgICAgICAgICBjb25zdCBwZXJtaXNzaW9uVHlwZXMgPSBPYmplY3Qua2V5cyhwZXJtaXNzaW9uTWFwKS5tYXAoTnVtYmVyKS5zb3J0KChsZWZ0LCByaWdodCkgPT4gbGVmdCAtIHJpZ2h0KVxuICAgICAgICAgICAgYnVmZmVyLnB1dFVpbnQxNihyZXNvdXJjZVR5cGUpLnB1dFVpbnQxNihwZXJtaXNzaW9uVHlwZXMubGVuZ3RoKVxuICAgICAgICAgICAgcGVybWlzc2lvblR5cGVzLmZvckVhY2gocGVybWlzc2lvblR5cGUgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlc291cmNlcyA9IHBlcm1pc3Npb25NYXBbcGVybWlzc2lvblR5cGVdXG4gICAgICAgICAgICAgICAgYnVmZmVyLnB1dFVpbnQxNihwZXJtaXNzaW9uVHlwZSkucHV0VWludDE2KHJlc291cmNlcy5sZW5ndGgpXG4gICAgICAgICAgICAgICAgcmVzb3VyY2VzLmZvckVhY2gocmVzb3VyY2UgPT4gYnVmZmVyLnB1dFN0cmluZyhyZXNvdXJjZSkpXG4gICAgICAgICAgICB9KVxuICAgICAgICB9KVxuICAgICAgICByZXR1cm4gQnVmZmVyLmNvbmNhdChbc3VwZXIucGFjaygpLCBidWZmZXIucGFjaygpXSlcbiAgICB9XG5cbiAgICAvLyBEZXNlcmlhbGl6ZXMgdGhlIFJUTTIgc2VydmljZSBwYXlsb2FkLlxuICAgIHVucGFjayhidWZmZXIpIHtcbiAgICAgICAgY29uc3QgcmVhZGVyID0gc3VwZXIudW5wYWNrKGJ1ZmZlcilcbiAgICAgICAgdGhpcy5fX3VzZXJfaWQgPSByZWFkZXIuZ2V0U3RyaW5nKClcbiAgICAgICAgdGhpcy5fX3Blcm1pc3Npb25zID0gbmV3IFJ0bTJQZXJtaXNzaW9ucygpXG4gICAgICAgIGNvbnN0IHJlc291cmNlVHlwZUNvdW50ID0gcmVhZGVyLmdldFVpbnQxNigpXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmVzb3VyY2VUeXBlQ291bnQ7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgcmVzb3VyY2VUeXBlID0gcmVhZGVyLmdldFVpbnQxNigpXG4gICAgICAgICAgICBjb25zdCBwZXJtaXNzaW9uQ291bnQgPSByZWFkZXIuZ2V0VWludDE2KClcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgcGVybWlzc2lvbkNvdW50OyBqKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBwZXJtaXNzaW9uVHlwZSA9IHJlYWRlci5nZXRVaW50MTYoKVxuICAgICAgICAgICAgICAgIGNvbnN0IHJlc291cmNlQ291bnQgPSByZWFkZXIuZ2V0VWludDE2KClcbiAgICAgICAgICAgICAgICBjb25zdCByZXNvdXJjZXMgPSBbXVxuICAgICAgICAgICAgICAgIGZvciAobGV0IGsgPSAwOyBrIDwgcmVzb3VyY2VDb3VudDsgaysrKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlc291cmNlcy5wdXNoKHJlYWRlci5nZXRTdHJpbmcoKS50b1N0cmluZygpKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0aGlzLl9fcGVybWlzc2lvbnMuYWRkKHJlc291cmNlVHlwZSwgcGVybWlzc2lvblR5cGUsIHJlc291cmNlcylcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVhZGVyXG4gICAgfVxufVxuXG5TZXJ2aWNlUnRtMi5rUHJpdmlsZWdlTG9naW4gPSAxXG5cbi8vIEJ1aWxkcywgcGFyc2VzLCBhbmQgdmVyaWZpZXMgVG9rZW4wMDcgdG9rZW5zIGNvbnRhaW5pbmcgb25lIG9yIG1vcmUgc2VydmljZXMuXG5jbGFzcyBBY2Nlc3NUb2tlbjIge1xuICAgIC8vIENyZWF0ZXMgYSB0b2tlbiBidWlsZGVyIG9yIGFuIGVtcHR5IHRva2VuIHBhcnNlci5cbiAgICBjb25zdHJ1Y3RvcihhcHBJZCwgYXBwQ2VydGlmaWNhdGUsIGlzc3VlVHMsIGV4cGlyZSkge1xuICAgICAgICB0aGlzLmFwcElkID0gYXBwSWRcbiAgICAgICAgdGhpcy5hcHBDZXJ0aWZpY2F0ZSA9IGFwcENlcnRpZmljYXRlXG4gICAgICAgIHRoaXMuaXNzdWVUcyA9IGlzc3VlVHMgfHwgbmV3IERhdGUoKS5nZXRUaW1lKCkgLyAxMDAwXG4gICAgICAgIHRoaXMuZXhwaXJlID0gZXhwaXJlXG4gICAgICAgIC8vIHNhbHQgcmFuZ2VzIGluICgxLCA5OTk5OTk5OSlcbiAgICAgICAgdGhpcy5zYWx0ID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogOTk5OTk5OTkpICsgMVxuICAgICAgICB0aGlzLnNlcnZpY2VzID0gW11cbiAgICAgICAgdGhpcy5fX3NpZ25hdHVyZSA9IEJ1ZmZlci5hbGxvYygwKVxuICAgICAgICB0aGlzLl9fc2lnbmluZ19pbmZvID0gQnVmZmVyLmFsbG9jKDApXG4gICAgICAgIHRoaXMuX19wYXJzZWQgPSBmYWxzZVxuICAgIH1cblxuICAgIC8vIERlcml2ZXMgdGhlIHNpZ25pbmcga2V5IHdpdGggdGhlIHN0b3JlZCBvciBzdXBwbGllZCBBcHAgQ2VydGlmaWNhdGUuXG4gICAgX19zaWduaW5nKGFwcENlcnRpZmljYXRlID0gdGhpcy5hcHBDZXJ0aWZpY2F0ZSkge1xuICAgICAgICBsZXQgc2lnbmluZyA9IGVuY29kZUhNYWMobmV3IEJ5dGVCdWYoKS5wdXRVaW50MzIodGhpcy5pc3N1ZVRzKS5wYWNrKCksIGFwcENlcnRpZmljYXRlKVxuICAgICAgICBzaWduaW5nID0gZW5jb2RlSE1hYyhuZXcgQnl0ZUJ1ZigpLnB1dFVpbnQzMih0aGlzLnNhbHQpLnBhY2soKSwgc2lnbmluZylcbiAgICAgICAgcmV0dXJuIHNpZ25pbmdcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZXMgdGhlIGZpZWxkcyByZXF1aXJlZCB0byBidWlsZCBhIHRva2VuLlxuICAgIF9fYnVpbGRfY2hlY2soKSB7XG4gICAgICAgIGNvbnN0IHsgYXBwSWQsIGFwcENlcnRpZmljYXRlLCBzZXJ2aWNlcyB9ID0gdGhpc1xuICAgICAgICBpZiAoIWlzVXVpZChhcHBJZCkgfHwgIWlzVXVpZChhcHBDZXJ0aWZpY2F0ZSkpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHNlcnZpY2VzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWVcbiAgICB9XG5cbiAgICAvLyBSZXR1cm5zIHNlcnZpY2VzIGluIHN0YWJsZSB0eXBlIG9yZGVyIHdoaWxlIHByZXNlcnZpbmcgZHVwbGljYXRlIGluc2VydGlvbiBvcmRlci5cbiAgICBfX3NlcnZpY2VzX2Zvcl9wYWNraW5nKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXJ2aWNlc1xuICAgICAgICAgICAgLm1hcCgoc2VydmljZSwgaW5kZXgpID0+ICh7IHNlcnZpY2UsIGluZGV4IH0pKVxuICAgICAgICAgICAgLnNvcnQoKGxlZnQsIHJpZ2h0KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdHlwZURpZmZlcmVuY2UgPSBsZWZ0LnNlcnZpY2Uuc2VydmljZV90eXBlKCkgLSByaWdodC5zZXJ2aWNlLnNlcnZpY2VfdHlwZSgpXG4gICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVEaWZmZXJlbmNlIHx8IGxlZnQuaW5kZXggLSByaWdodC5pbmRleFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5tYXAoZW50cnkgPT4gZW50cnkuc2VydmljZSlcbiAgICB9XG5cbiAgICAvLyBBZGRzIGEgc2VydmljZSB3aXRob3V0IHJlcGxhY2luZyBzZXJ2aWNlcyBvZiB0aGUgc2FtZSB0eXBlLlxuICAgIGFkZF9zZXJ2aWNlKHNlcnZpY2UpIHtcbiAgICAgICAgdGhpcy5zZXJ2aWNlcy5wdXNoKHNlcnZpY2UpXG4gICAgfVxuXG4gICAgLy8gUmV0dXJucyBhbGwgc2VydmljZXMgb2YgdGhlIHJlcXVlc3RlZCB0eXBlIGluIGluc2VydGlvbiBvciB0b2tlbiBvcmRlci5cbiAgICBnZXRTZXJ2aWNlcyhzZXJ2aWNlVHlwZSkge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXJ2aWNlcy5maWx0ZXIoc2VydmljZSA9PiBzZXJ2aWNlLnNlcnZpY2VfdHlwZSgpID09PSBzZXJ2aWNlVHlwZSlcbiAgICB9XG5cbiAgICAvLyBCdWlsZHMgYSBUb2tlbjAwNyB0b2tlbiBjb250YWluaW5nIGFsbCBhZGRlZCBzZXJ2aWNlcy5cbiAgICBidWlsZCgpIHtcbiAgICAgICAgaWYgKCF0aGlzLl9fYnVpbGRfY2hlY2soKSkge1xuICAgICAgICAgICAgcmV0dXJuICcnXG4gICAgICAgIH1cblxuICAgICAgICBsZXQgc2lnbmluZyA9IHRoaXMuX19zaWduaW5nKClcbiAgICAgICAgY29uc3Qgc2VydmljZXMgPSB0aGlzLl9fc2VydmljZXNfZm9yX3BhY2tpbmcoKVxuICAgICAgICBsZXQgc2lnbmluZ19pbmZvID0gbmV3IEJ5dGVCdWYoKVxuICAgICAgICAgICAgLnB1dFN0cmluZyh0aGlzLmFwcElkKVxuICAgICAgICAgICAgLnB1dFVpbnQzMih0aGlzLmlzc3VlVHMpXG4gICAgICAgICAgICAucHV0VWludDMyKHRoaXMuZXhwaXJlKVxuICAgICAgICAgICAgLnB1dFVpbnQzMih0aGlzLnNhbHQpXG4gICAgICAgICAgICAucHV0VWludDE2KHNlcnZpY2VzLmxlbmd0aClcbiAgICAgICAgICAgIC5wYWNrKClcbiAgICAgICAgc2VydmljZXMuZm9yRWFjaChzZXJ2aWNlID0+IHtcbiAgICAgICAgICAgIHNpZ25pbmdfaW5mbyA9IEJ1ZmZlci5jb25jYXQoW3NpZ25pbmdfaW5mbywgc2VydmljZS5wYWNrKCldKVxuICAgICAgICB9KVxuXG4gICAgICAgIGxldCBzaWduYXR1cmUgPSBlbmNvZGVITWFjKHNpZ25pbmcsIHNpZ25pbmdfaW5mbylcbiAgICAgICAgbGV0IGNvbnRlbnQgPSBCdWZmZXIuY29uY2F0KFtuZXcgQnl0ZUJ1ZigpLnB1dFN0cmluZyhzaWduYXR1cmUpLnBhY2soKSwgc2lnbmluZ19pbmZvXSlcbiAgICAgICAgbGV0IGNvbXByZXNzZWQgPSB6bGliLmRlZmxhdGVTeW5jKGNvbnRlbnQpXG4gICAgICAgIHJldHVybiBgJHtnZXRWZXJzaW9uKCl9JHtCdWZmZXIuZnJvbShjb21wcmVzc2VkKS50b1N0cmluZygnYmFzZTY0Jyl9YFxuICAgIH1cblxuICAgIC8vIFBhcnNlcyBrbm93biBzZXJ2aWNlcyBhbmQgcmV0YWlucyB0aGUgb3JpZ2luYWwgYnl0ZXMgZm9yIHNpZ25hdHVyZSB2ZXJpZmljYXRpb24uXG4gICAgZnJvbV9zdHJpbmcob3JpZ2luX3Rva2VuKSB7XG4gICAgICAgIC8vIENsZWFyIHRoZSBwcmV2aW91cyB0b2tlbiBzdGF0ZSBzbyBhIGZhaWxlZCBwYXJzZSBjYW5ub3QgcmV1c2UgaXRzIHNpZ25hdHVyZSBvciBzZXJ2aWNlcy5cbiAgICAgICAgdGhpcy5hcHBJZCA9ICcnXG4gICAgICAgIHRoaXMuaXNzdWVUcyA9IDBcbiAgICAgICAgdGhpcy5leHBpcmUgPSAwXG4gICAgICAgIHRoaXMuc2FsdCA9IDBcbiAgICAgICAgdGhpcy5zZXJ2aWNlcyA9IFtdXG4gICAgICAgIHRoaXMuX19zaWduYXR1cmUgPSBCdWZmZXIuYWxsb2MoMClcbiAgICAgICAgdGhpcy5fX3NpZ25pbmdfaW5mbyA9IEJ1ZmZlci5hbGxvYygwKVxuICAgICAgICB0aGlzLl9fcGFyc2VkID0gZmFsc2VcblxuICAgICAgICBpZiAodHlwZW9mIG9yaWdpbl90b2tlbiAhPT0gJ3N0cmluZycgfHwgb3JpZ2luX3Rva2VuLmxlbmd0aCA8IFZFUlNJT05fTEVOR1RIKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IG9yaWdpbl92ZXJzaW9uID0gb3JpZ2luX3Rva2VuLnN1YnN0cmluZygwLCBWRVJTSU9OX0xFTkdUSClcbiAgICAgICAgaWYgKG9yaWdpbl92ZXJzaW9uICE9PSBnZXRWZXJzaW9uKCkpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgICB9XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IG9yaWdpbl9jb250ZW50ID0gb3JpZ2luX3Rva2VuLnN1YnN0cmluZyhWRVJTSU9OX0xFTkdUSClcbiAgICAgICAgICAgIGNvbnN0IGJ1ZmZlciA9IHpsaWIuaW5mbGF0ZVN5bmMoQnVmZmVyLmZyb20ob3JpZ2luX2NvbnRlbnQsICdiYXNlNjQnKSlcbiAgICAgICAgICAgIGNvbnN0IGJ1ZmZlclJlYWRlciA9IG5ldyBSZWFkQnl0ZUJ1ZihidWZmZXIpXG5cbiAgICAgICAgICAgIHRoaXMuX19zaWduYXR1cmUgPSBCdWZmZXIuZnJvbShidWZmZXJSZWFkZXIuZ2V0U3RyaW5nKCkpXG4gICAgICAgICAgICB0aGlzLl9fc2lnbmluZ19pbmZvID0gQnVmZmVyLmZyb20oYnVmZmVyUmVhZGVyLnBhY2soKSlcbiAgICAgICAgICAgIHRoaXMuc2VydmljZXMgPSBbXVxuICAgICAgICAgICAgdGhpcy5hcHBJZCA9IGJ1ZmZlclJlYWRlci5nZXRTdHJpbmcoKVxuICAgICAgICAgICAgdGhpcy5pc3N1ZVRzID0gYnVmZmVyUmVhZGVyLmdldFVpbnQzMigpXG4gICAgICAgICAgICB0aGlzLmV4cGlyZSA9IGJ1ZmZlclJlYWRlci5nZXRVaW50MzIoKVxuICAgICAgICAgICAgdGhpcy5zYWx0ID0gYnVmZmVyUmVhZGVyLmdldFVpbnQzMigpXG4gICAgICAgICAgICBjb25zdCBzZXJ2aWNlX2NvdW50ID0gYnVmZmVyUmVhZGVyLmdldFVpbnQxNigpXG5cbiAgICAgICAgICAgIGxldCByZW1haW5CdWYgPSBidWZmZXJSZWFkZXIucGFjaygpXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNlcnZpY2VfY291bnQ7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGJ1ZmZlclJlYWRlclNlcnZpY2UgPSBuZXcgUmVhZEJ5dGVCdWYocmVtYWluQnVmKVxuICAgICAgICAgICAgICAgIGNvbnN0IHNlcnZpY2VfdHlwZSA9IGJ1ZmZlclJlYWRlclNlcnZpY2UuZ2V0VWludDE2KClcbiAgICAgICAgICAgICAgICBjb25zdCBTZXJ2aWNlQ2xhc3MgPSBBY2Nlc3NUb2tlbjIua1NlcnZpY2VzW3NlcnZpY2VfdHlwZV1cbiAgICAgICAgICAgICAgICBpZiAoIVNlcnZpY2VDbGFzcykge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLl9fcGFyc2VkID0gdHJ1ZVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGNvbnN0IHNlcnZpY2UgPSBuZXcgU2VydmljZUNsYXNzKClcbiAgICAgICAgICAgICAgICByZW1haW5CdWYgPSBzZXJ2aWNlLnVucGFjayhidWZmZXJSZWFkZXJTZXJ2aWNlLnBhY2soKSkucGFjaygpXG4gICAgICAgICAgICAgICAgdGhpcy5hZGRfc2VydmljZShzZXJ2aWNlKVxuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLl9fcGFyc2VkID0gdHJ1ZVxuICAgICAgICByZXR1cm4gdHJ1ZVxuICAgIH1cblxuICAgIC8vIFZlcmlmaWVzIHRoZSBzaWduYXR1cmUgb2YgYSBzdWNjZXNzZnVsbHkgcGFyc2VkIHRva2VuLlxuICAgIHZlcmlmeVNpZ25hdHVyZShhcHBDZXJ0aWZpY2F0ZSkge1xuICAgICAgICBpZiAoIXRoaXMuX19wYXJzZWQgfHwgdGhpcy5fX3NpZ25hdHVyZS5sZW5ndGggPT09IDAgfHwgdGhpcy5fX3NpZ25pbmdfaW5mby5sZW5ndGggPT09IDBcbiAgICAgICAgICAgIHx8ICFpc1V1aWQodGhpcy5hcHBJZCkgfHwgIWlzVXVpZChhcHBDZXJ0aWZpY2F0ZSkpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3Qgc2lnbmF0dXJlID0gZW5jb2RlSE1hYyh0aGlzLl9fc2lnbmluZyhhcHBDZXJ0aWZpY2F0ZSksIHRoaXMuX19zaWduaW5nX2luZm8pXG4gICAgICAgIHJldHVybiB0aGlzLl9fc2lnbmF0dXJlLmxlbmd0aCA9PT0gc2lnbmF0dXJlLmxlbmd0aFxuICAgICAgICAgICAgJiYgY3J5cHRvLnRpbWluZ1NhZmVFcXVhbCh0aGlzLl9fc2lnbmF0dXJlLCBzaWduYXR1cmUpXG4gICAgfVxufVxuXG4vLyBSZXR1cm5zIGEgU0hBLTI1NiBITUFDIGRpZ2VzdC5cbnZhciBlbmNvZGVITWFjID0gZnVuY3Rpb24gKGtleSwgbWVzc2FnZSkge1xuICAgIHJldHVybiBjcnlwdG8uY3JlYXRlSG1hYygnc2hhMjU2Jywga2V5KS51cGRhdGUobWVzc2FnZSkuZGlnZXN0KClcbn1cblxuLy8gQ3JlYXRlcyBhIGxpdHRsZS1lbmRpYW4gdG9rZW4gYnVmZmVyIHdyaXRlci5cbnZhciBCeXRlQnVmID0gZnVuY3Rpb24gKCkge1xuICAgIHZhciB0aGF0ID0ge1xuICAgICAgICBidWZmZXI6IEJ1ZmZlci5hbGxvYygxMDI0KSxcbiAgICAgICAgcG9zaXRpb246IDBcbiAgICB9XG5cbiAgICB0aGF0LmJ1ZmZlci5maWxsKDApXG5cbiAgICAvLyBHcm93cyB0aGUgYmFja2luZyBidWZmZXIgd2hlbiB0aGUgbmV4dCB2YWx1ZSBkb2VzIG5vdCBmaXQuXG4gICAgdmFyIGVuc3VyZUNhcGFjaXR5ID0gZnVuY3Rpb24gKGFkZGl0aW9uYWxMZW5ndGgpIHtcbiAgICAgICAgY29uc3QgcmVxdWlyZWRMZW5ndGggPSB0aGF0LnBvc2l0aW9uICsgYWRkaXRpb25hbExlbmd0aFxuICAgICAgICBpZiAocmVxdWlyZWRMZW5ndGggPD0gdGhhdC5idWZmZXIubGVuZ3RoKSB7XG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBjYXBhY2l0eSA9IHRoYXQuYnVmZmVyLmxlbmd0aFxuICAgICAgICB3aGlsZSAoY2FwYWNpdHkgPCByZXF1aXJlZExlbmd0aCkge1xuICAgICAgICAgICAgY2FwYWNpdHkgKj0gMlxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgZXhwYW5kZWQgPSBCdWZmZXIuYWxsb2MoY2FwYWNpdHkpXG4gICAgICAgIHRoYXQuYnVmZmVyLmNvcHkoZXhwYW5kZWQsIDAsIDAsIHRoYXQucG9zaXRpb24pXG4gICAgICAgIHRoYXQuYnVmZmVyID0gZXhwYW5kZWRcbiAgICB9XG5cbiAgICAvLyBSZXR1cm5zIHRoZSBieXRlcyB3cml0dGVuIHRvIHRoZSBidWZmZXIuXG4gICAgdGhhdC5wYWNrID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgb3V0ID0gQnVmZmVyLmFsbG9jKHRoYXQucG9zaXRpb24pXG4gICAgICAgIHRoYXQuYnVmZmVyLmNvcHkob3V0LCAwLCAwLCBvdXQubGVuZ3RoKVxuICAgICAgICByZXR1cm4gb3V0XG4gICAgfVxuXG4gICAgLy8gQXBwZW5kcyBhbiB1bnNpZ25lZCAxNi1iaXQgaW50ZWdlci5cbiAgICB0aGF0LnB1dFVpbnQxNiA9IGZ1bmN0aW9uICh2KSB7XG4gICAgICAgIGVuc3VyZUNhcGFjaXR5KDIpXG4gICAgICAgIHRoYXQuYnVmZmVyLndyaXRlVUludDE2TEUodiwgdGhhdC5wb3NpdGlvbilcbiAgICAgICAgdGhhdC5wb3NpdGlvbiArPSAyXG4gICAgICAgIHJldHVybiB0aGF0XG4gICAgfVxuXG4gICAgLy8gQXBwZW5kcyBhbiB1bnNpZ25lZCAzMi1iaXQgaW50ZWdlci5cbiAgICB0aGF0LnB1dFVpbnQzMiA9IGZ1bmN0aW9uICh2KSB7XG4gICAgICAgIGVuc3VyZUNhcGFjaXR5KDQpXG4gICAgICAgIHRoYXQuYnVmZmVyLndyaXRlVUludDMyTEUodiwgdGhhdC5wb3NpdGlvbilcbiAgICAgICAgdGhhdC5wb3NpdGlvbiArPSA0XG4gICAgICAgIHJldHVybiB0aGF0XG4gICAgfVxuICAgIC8vIEFwcGVuZHMgYSBzaWduZWQgMzItYml0IGludGVnZXIuXG4gICAgdGhhdC5wdXRJbnQzMiA9IGZ1bmN0aW9uICh2KSB7XG4gICAgICAgIGVuc3VyZUNhcGFjaXR5KDQpXG4gICAgICAgIHRoYXQuYnVmZmVyLndyaXRlSW50MzJMRSh2LCB0aGF0LnBvc2l0aW9uKVxuICAgICAgICB0aGF0LnBvc2l0aW9uICs9IDRcbiAgICAgICAgcmV0dXJuIHRoYXRcbiAgICB9XG5cbiAgICAvLyBBcHBlbmRzIGEgc2lnbmVkIDE2LWJpdCBpbnRlZ2VyLlxuICAgIHRoYXQucHV0SW50MTYgPSBmdW5jdGlvbiAodikge1xuICAgICAgICBlbnN1cmVDYXBhY2l0eSgyKVxuICAgICAgICB0aGF0LmJ1ZmZlci53cml0ZUludDE2TEUodiwgdGhhdC5wb3NpdGlvbilcbiAgICAgICAgdGhhdC5wb3NpdGlvbiArPSAyXG4gICAgICAgIHJldHVybiB0aGF0XG4gICAgfVxuXG4gICAgLy8gQXBwZW5kcyBsZW5ndGgtcHJlZml4ZWQgYnl0ZXMuXG4gICAgdGhhdC5wdXRCeXRlcyA9IGZ1bmN0aW9uIChieXRlcykge1xuICAgICAgICB0aGF0LnB1dFVpbnQxNihieXRlcy5sZW5ndGgpXG4gICAgICAgIGVuc3VyZUNhcGFjaXR5KGJ5dGVzLmxlbmd0aClcbiAgICAgICAgYnl0ZXMuY29weSh0aGF0LmJ1ZmZlciwgdGhhdC5wb3NpdGlvbilcbiAgICAgICAgdGhhdC5wb3NpdGlvbiArPSBieXRlcy5sZW5ndGhcbiAgICAgICAgcmV0dXJuIHRoYXRcbiAgICB9XG5cbiAgICAvLyBBcHBlbmRzIGEgbGVuZ3RoLXByZWZpeGVkIHN0cmluZy5cbiAgICB0aGF0LnB1dFN0cmluZyA9IGZ1bmN0aW9uIChzdHIpIHtcbiAgICAgICAgcmV0dXJuIHRoYXQucHV0Qnl0ZXMoQnVmZmVyLmZyb20oc3RyKSlcbiAgICB9XG5cbiAgICAvLyBBcHBlbmRzIGEgc3RyaW5nIG1hcCBpbiBudW1lcmljIGtleSBvcmRlci5cbiAgICB0aGF0LnB1dFRyZWVNYXAgPSBmdW5jdGlvbiAobWFwKSB7XG4gICAgICAgIGlmICghbWFwKSB7XG4gICAgICAgICAgICB0aGF0LnB1dFVpbnQxNigwKVxuICAgICAgICAgICAgcmV0dXJuIHRoYXRcbiAgICAgICAgfVxuXG4gICAgICAgIHRoYXQucHV0VWludDE2KE9iamVjdC5rZXlzKG1hcCkubGVuZ3RoKVxuICAgICAgICBmb3IgKHZhciBrZXkgaW4gbWFwKSB7XG4gICAgICAgICAgICB0aGF0LnB1dFVpbnQxNihrZXkpXG4gICAgICAgICAgICB0aGF0LnB1dFN0cmluZyhtYXBba2V5XSlcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0aGF0XG4gICAgfVxuXG4gICAgLy8gQXBwZW5kcyBhbiB1bnNpZ25lZCAzMi1iaXQgdmFsdWUgbWFwIGluIG51bWVyaWMga2V5IG9yZGVyLlxuICAgIHRoYXQucHV0VHJlZU1hcFVJbnQzMiA9IGZ1bmN0aW9uIChtYXApIHtcbiAgICAgICAgaWYgKCFtYXApIHtcbiAgICAgICAgICAgIHRoYXQucHV0VWludDE2KDApXG4gICAgICAgICAgICByZXR1cm4gdGhhdFxuICAgICAgICB9XG5cbiAgICAgICAgdGhhdC5wdXRVaW50MTYoT2JqZWN0LmtleXMobWFwKS5sZW5ndGgpXG4gICAgICAgIGZvciAodmFyIGtleSBpbiBtYXApIHtcbiAgICAgICAgICAgIHRoYXQucHV0VWludDE2KGtleSlcbiAgICAgICAgICAgIHRoYXQucHV0VWludDMyKG1hcFtrZXldKVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHRoYXRcbiAgICB9XG5cbiAgICByZXR1cm4gdGhhdFxufVxuXG4vLyBDcmVhdGVzIGEgbGl0dGxlLWVuZGlhbiB0b2tlbiBidWZmZXIgcmVhZGVyLlxudmFyIFJlYWRCeXRlQnVmID0gZnVuY3Rpb24gKGJ5dGVzKSB7XG4gICAgdmFyIHRoYXQgPSB7XG4gICAgICAgIGJ1ZmZlcjogYnl0ZXMsXG4gICAgICAgIHBvc2l0aW9uOiAwXG4gICAgfVxuXG4gICAgLy8gUmVhZHMgYW4gdW5zaWduZWQgMTYtYml0IGludGVnZXIuXG4gICAgdGhhdC5nZXRVaW50MTYgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciByZXQgPSB0aGF0LmJ1ZmZlci5yZWFkVUludDE2TEUodGhhdC5wb3NpdGlvbilcbiAgICAgICAgdGhhdC5wb3NpdGlvbiArPSAyXG4gICAgICAgIHJldHVybiByZXRcbiAgICB9XG5cbiAgICAvLyBSZWFkcyBhbiB1bnNpZ25lZCAzMi1iaXQgaW50ZWdlci5cbiAgICB0aGF0LmdldFVpbnQzMiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIHJldCA9IHRoYXQuYnVmZmVyLnJlYWRVSW50MzJMRSh0aGF0LnBvc2l0aW9uKVxuICAgICAgICB0aGF0LnBvc2l0aW9uICs9IDRcbiAgICAgICAgcmV0dXJuIHJldFxuICAgIH1cblxuICAgIC8vIFJlYWRzIGEgc2lnbmVkIDE2LWJpdCBpbnRlZ2VyLlxuICAgIHRoYXQuZ2V0SW50MTYgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciByZXQgPSB0aGF0LmJ1ZmZlci5yZWFkVUludDE2TEUodGhhdC5wb3NpdGlvbilcbiAgICAgICAgdGhhdC5wb3NpdGlvbiArPSAyXG4gICAgICAgIHJldHVybiByZXRcbiAgICB9XG5cbiAgICAvLyBSZWFkcyBsZW5ndGgtcHJlZml4ZWQgYnl0ZXMuXG4gICAgdGhhdC5nZXRTdHJpbmcgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBsZW4gPSB0aGF0LmdldFVpbnQxNigpXG5cbiAgICAgICAgdmFyIG91dCA9IEJ1ZmZlci5hbGxvYyhsZW4pXG4gICAgICAgIHRoYXQuYnVmZmVyLmNvcHkob3V0LCAwLCB0aGF0LnBvc2l0aW9uLCB0aGF0LnBvc2l0aW9uICsgbGVuKVxuICAgICAgICB0aGF0LnBvc2l0aW9uICs9IGxlblxuICAgICAgICByZXR1cm4gb3V0XG4gICAgfVxuXG4gICAgLy8gUmVhZHMgYW4gdW5zaWduZWQgMzItYml0IHZhbHVlIG1hcC5cbiAgICB0aGF0LmdldFRyZWVNYXBVSW50MzIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBtYXAgPSB7fVxuICAgICAgICB2YXIgbGVuID0gdGhhdC5nZXRVaW50MTYoKVxuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgICAgICB2YXIga2V5ID0gdGhhdC5nZXRVaW50MTYoKVxuICAgICAgICAgICAgdmFyIHZhbHVlID0gdGhhdC5nZXRVaW50MzIoKVxuICAgICAgICAgICAgbWFwW2tleV0gPSB2YWx1ZVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBtYXBcbiAgICB9XG5cbiAgICAvLyBSZXR1cm5zIHVucmVhZCBieXRlcyBmcm9tIHRoZSBidWZmZXIuXG4gICAgdGhhdC5wYWNrID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBjb25zdCBsZW5ndGggPSB0aGF0LmJ1ZmZlci5sZW5ndGggLSB0aGF0LnBvc2l0aW9uXG4gICAgICAgIGNvbnN0IG91dCA9IEJ1ZmZlci5hbGxvYyhsZW5ndGgpXG4gICAgICAgIHRoYXQuYnVmZmVyLmNvcHkob3V0LCAwLCB0aGF0LnBvc2l0aW9uKVxuICAgICAgICByZXR1cm4gb3V0XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoYXRcbn1cblxuQWNjZXNzVG9rZW4yLmtTZXJ2aWNlcyA9IHt9XG5BY2Nlc3NUb2tlbjIua1NlcnZpY2VzW2tBcGFhc1NlcnZpY2VUeXBlXSA9IFNlcnZpY2VBcGFhc1xuQWNjZXNzVG9rZW4yLmtTZXJ2aWNlc1trQ2hhdFNlcnZpY2VUeXBlXSA9IFNlcnZpY2VDaGF0XG5BY2Nlc3NUb2tlbjIua1NlcnZpY2VzW2tGQ2RuU2VydmljZVR5cGVdID0gU2VydmljZUZDZG5cbkFjY2Vzc1Rva2VuMi5rU2VydmljZXNba0ZwYVNlcnZpY2VUeXBlXSA9IFNlcnZpY2VGcGFcbkFjY2Vzc1Rva2VuMi5rU2VydmljZXNba1J0Y1NlcnZpY2VUeXBlXSA9IFNlcnZpY2VSdGNcbkFjY2Vzc1Rva2VuMi5rU2VydmljZXNba1J0bVNlcnZpY2VUeXBlXSA9IFNlcnZpY2VSdG1cbkFjY2Vzc1Rva2VuMi5rU2VydmljZXNba1J0bTJTZXJ2aWNlVHlwZV0gPSBTZXJ2aWNlUnRtMlxuQWNjZXNzVG9rZW4yLmtTZXJ2aWNlc1trU3RyZWFtaW5nU2VydmljZVR5cGVdID0gU2VydmljZVN0cmVhbWluZ1xuQWNjZXNzVG9rZW4yLmtTZXJ2aWNlc1trQ29udm9BSVNlcnZpY2VUeXBlXSA9IFNlcnZpY2VDb252b0FJXG5BY2Nlc3NUb2tlbjIua1NlcnZpY2VzW2tTdHRTZXJ2aWNlVHlwZV0gPSBTZXJ2aWNlU3R0XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICAgIEFjY2Vzc1Rva2VuMixcbiAgICBrQXBhYXNTZXJ2aWNlVHlwZSxcbiAgICBrQ2hhdFNlcnZpY2VUeXBlLFxuICAgIGtDb252b0FJU2VydmljZVR5cGUsXG4gICAga0ZDZG5TZXJ2aWNlVHlwZSxcbiAgICBrRnBhU2VydmljZVR5cGUsXG4gICAga1J0Y1NlcnZpY2VUeXBlLFxuICAgIGtSdG1TZXJ2aWNlVHlwZSxcbiAgICBrUnRtMlNlcnZpY2VUeXBlLFxuICAgIGtTdHRTZXJ2aWNlVHlwZSxcbiAgICBrU3RyZWFtaW5nU2VydmljZVR5cGUsXG4gICAgUnRtMlBlcm1pc3Npb25zLFxuICAgIFNlcnZpY2UsXG4gICAgU2VydmljZUFwYWFzLFxuICAgIFNlcnZpY2VDaGF0LFxuICAgIFNlcnZpY2VDb252b0FJLFxuICAgIFNlcnZpY2VGQ2RuLFxuICAgIFNlcnZpY2VGcGEsXG4gICAgU2VydmljZVJ0YyxcbiAgICBTZXJ2aWNlUnRtLFxuICAgIFNlcnZpY2VSdG0yLFxuICAgIFNlcnZpY2VTdHQsXG4gICAgU2VydmljZVN0cmVhbWluZ1xufVxuIiwiY29uc3QgbWQ1ID0gcmVxdWlyZSgnbWQ1JylcblxuY29uc3QgQWNjZXNzVG9rZW4gPSByZXF1aXJlKCcuL0FjY2Vzc1Rva2VuMicpLkFjY2Vzc1Rva2VuMlxuY29uc3QgU2VydmljZUFwYWFzID0gcmVxdWlyZSgnLi9BY2Nlc3NUb2tlbjInKS5TZXJ2aWNlQXBhYXNcbmNvbnN0IFNlcnZpY2VDaGF0ID0gcmVxdWlyZSgnLi9BY2Nlc3NUb2tlbjInKS5TZXJ2aWNlQ2hhdFxuY29uc3QgU2VydmljZVJ0bSA9IHJlcXVpcmUoJy4vQWNjZXNzVG9rZW4yJykuU2VydmljZVJ0bVxuXG5jbGFzcyBBcGFhc1Rva2VuQnVpbGRlciB7XG4gICAgLyoqXG4gICAgICogYnVpbGQgdXNlciByb29tIHRva2VuXG4gICAgICogQHBhcmFtIGFwcElkICAgICAgICAgICAgIFRoZSBBcHAgSUQgaXNzdWVkIHRvIHlvdSBieSBBZ29yYS4gQXBwbHkgZm9yIGEgbmV3IEFwcCBJRCBmcm9tXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgIEFnb3JhIERhc2hib2FyZCBpZiBpdCBpcyBtaXNzaW5nIGZyb20geW91ciBraXQuIFNlZSBHZXQgYW4gQXBwIElELlxuICAgICAqIEBwYXJhbSBhcHBDZXJ0aWZpY2F0ZSAgICBDZXJ0aWZpY2F0ZSBvZiB0aGUgYXBwbGljYXRpb24gdGhhdCB5b3UgcmVnaXN0ZXJlZCBpblxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICB0aGUgQWdvcmEgRGFzaGJvYXJkLiBTZWUgR2V0IGFuIEFwcCBDZXJ0aWZpY2F0ZS5cbiAgICAgKiBAcGFyYW0gcm9vbVV1aWQgICAgICAgICAgVGhlIHJvb20ncyBpZCwgbXVzdCBiZSB1bmlxdWUuXG4gICAgICogQHBhcmFtIHVzZXJVdWlkICAgICAgICAgIFRoZSB1c2VyJ3MgaWQsIG11c3QgYmUgdW5pcXVlLlxuICAgICAqIEBwYXJhbSByb2xlICAgICAgICAgICAgICBUaGUgdXNlcidzIHJvbGUuXG4gICAgICogQHBhcmFtIGV4cGlyZSAgICAgICAgICAgIHJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy4gSWYsIGZvciBleGFtcGxlLCB5b3Ugd2FudCB0byBhY2Nlc3MgdGhlXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgIEFnb3JhIFNlcnZpY2Ugd2l0aGluIDEwIG1pbnV0ZXMgYWZ0ZXIgdGhlIHRva2VuIGlzIGdlbmVyYXRlZCwgc2V0IGV4cGlyZSBhc1xuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICA2MDAoc2Vjb25kcykuIFRoaXMgdmFsdWUgaXMgdGhlIHdob2xlIHRva2VuIGV4cGlyYXRpb24gYW5kIHRoZSBzZXJ2aWNlXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgIHByaXZpbGVnZSBleHBpcmF0aW9uLiBUaGUgd2hvbGUgdG9rZW4gaXMgaW52YWxpZCBhZnRlciB0aGlzIHRpbWUuXG4gICAgICogQHJldHVybiBUaGUgdXNlciByb29tIHRva2VuLlxuICAgICAqL1xuICAgIHN0YXRpYyBidWlsZFJvb21Vc2VyVG9rZW4oYXBwSWQsIGFwcENlcnRpZmljYXRlLCByb29tVXVpZCwgdXNlclV1aWQsIHJvbGUsIGV4cGlyZSkge1xuICAgICAgICBsZXQgYWNjZXNzVG9rZW4gPSBuZXcgQWNjZXNzVG9rZW4oYXBwSWQsIGFwcENlcnRpZmljYXRlLCAwLCBleHBpcmUpXG5cbiAgICAgICAgbGV0IGNoYXRVc2VySWQgPSBtZDUodXNlclV1aWQpXG4gICAgICAgIGxldCBhcGFhc1NlcnZpY2UgPSBuZXcgU2VydmljZUFwYWFzKHJvb21VdWlkLCB1c2VyVXVpZCwgcm9sZSlcbiAgICAgICAgYWNjZXNzVG9rZW4uYWRkX3NlcnZpY2UoYXBhYXNTZXJ2aWNlKVxuXG4gICAgICAgIGxldCBydG1TZXJ2aWNlID0gbmV3IFNlcnZpY2VSdG0odXNlclV1aWQpXG4gICAgICAgIHJ0bVNlcnZpY2UuYWRkX3ByaXZpbGVnZShTZXJ2aWNlUnRtLmtQcml2aWxlZ2VMb2dpbiwgZXhwaXJlKVxuICAgICAgICBhY2Nlc3NUb2tlbi5hZGRfc2VydmljZShydG1TZXJ2aWNlKVxuXG4gICAgICAgIGxldCBjaGF0U2VydmljZSA9IG5ldyBTZXJ2aWNlQ2hhdChjaGF0VXNlcklkKVxuICAgICAgICBjaGF0U2VydmljZS5hZGRfcHJpdmlsZWdlKFNlcnZpY2VDaGF0LmtQcml2aWxlZ2VVc2VyLCBleHBpcmUpXG4gICAgICAgIGFjY2Vzc1Rva2VuLmFkZF9zZXJ2aWNlKGNoYXRTZXJ2aWNlKVxuXG4gICAgICAgIHJldHVybiBhY2Nlc3NUb2tlbi5idWlsZCgpXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogYnVpbGQgdXNlciB0b2tlblxuICAgICAqIEBwYXJhbSBhcHBJZCAgICAgICAgICAgICBUaGUgQXBwIElEIGlzc3VlZCB0byB5b3UgYnkgQWdvcmEuIEFwcGx5IGZvciBhIG5ldyBBcHAgSUQgZnJvbVxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICBBZ29yYSBEYXNoYm9hcmQgaWYgaXQgaXMgbWlzc2luZyBmcm9tIHlvdXIga2l0LiBTZWUgR2V0IGFuIEFwcCBJRC5cbiAgICAgKiBAcGFyYW0gYXBwQ2VydGlmaWNhdGUgICAgQ2VydGlmaWNhdGUgb2YgdGhlIGFwcGxpY2F0aW9uIHRoYXQgeW91IHJlZ2lzdGVyZWQgaW5cbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgdGhlIEFnb3JhIERhc2hib2FyZC4gU2VlIEdldCBhbiBBcHAgQ2VydGlmaWNhdGUuXG4gICAgICogQHBhcmFtIHVzZXJVdWlkICAgICAgICAgIFRoZSB1c2VyJ3MgaWQsIG11c3QgYmUgdW5pcXVlLlxuICAgICAqIEBwYXJhbSBleHBpcmUgICAgICAgICAgICByZXByZXNlbnRlZCBieSB0aGUgbnVtYmVyIG9mIHNlY29uZHMgZWxhcHNlZCBzaW5jZSBub3cuIElmLCBmb3IgZXhhbXBsZSwgeW91IHdhbnQgdG8gYWNjZXNzIHRoZVxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICBBZ29yYSBTZXJ2aWNlIHdpdGhpbiAxMCBtaW51dGVzIGFmdGVyIHRoZSB0b2tlbiBpcyBnZW5lcmF0ZWQsIHNldCBleHBpcmUgYXNcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgNjAwKHNlY29uZHMpLiBUaGlzIHZhbHVlIGlzIHRoZSB3aG9sZSB0b2tlbiBleHBpcmF0aW9uIGFuZCB0aGUgc2VydmljZVxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICBwcml2aWxlZ2UgZXhwaXJhdGlvbi4gVGhlIHdob2xlIHRva2VuIGlzIGludmFsaWQgYWZ0ZXIgdGhpcyB0aW1lLlxuICAgICAqIEByZXR1cm4gVGhlIHVzZXIgdG9rZW4uXG4gICAgICovXG4gICAgc3RhdGljIGJ1aWxkVXNlclRva2VuKGFwcElkLCBhcHBDZXJ0aWZpY2F0ZSwgdXNlclV1aWQsIGV4cGlyZSkge1xuICAgICAgICBsZXQgYWNjZXNzVG9rZW4gPSBuZXcgQWNjZXNzVG9rZW4oYXBwSWQsIGFwcENlcnRpZmljYXRlLCAwLCBleHBpcmUpXG4gICAgICAgIGxldCBhcGFhc1NlcnZpY2UgPSBuZXcgU2VydmljZUFwYWFzKCcnLCB1c2VyVXVpZClcbiAgICAgICAgYXBhYXNTZXJ2aWNlLmFkZF9wcml2aWxlZ2UoU2VydmljZUFwYWFzLlBSSVZJTEVHRV9VU0VSLCBleHBpcmUpXG4gICAgICAgIGFjY2Vzc1Rva2VuLmFkZF9zZXJ2aWNlKGFwYWFzU2VydmljZSlcblxuICAgICAgICByZXR1cm4gYWNjZXNzVG9rZW4uYnVpbGQoKVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGJ1aWxkIGFwcCB0b2tlblxuICAgICAqIEBwYXJhbSBhcHBJZCAgICAgICAgICBUaGUgQXBwIElEIGlzc3VlZCB0byB5b3UgYnkgQWdvcmEuIEFwcGx5IGZvciBhIG5ldyBBcHAgSUQgZnJvbVxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICBBZ29yYSBEYXNoYm9hcmQgaWYgaXQgaXMgbWlzc2luZyBmcm9tIHlvdXIga2l0LiBTZWUgR2V0IGFuIEFwcCBJRC5cbiAgICAgKiBAcGFyYW0gYXBwQ2VydGlmaWNhdGUgQ2VydGlmaWNhdGUgb2YgdGhlIGFwcGxpY2F0aW9uIHRoYXQgeW91IHJlZ2lzdGVyZWQgaW5cbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgdGhlIEFnb3JhIERhc2hib2FyZC4gU2VlIEdldCBhbiBBcHAgQ2VydGlmaWNhdGUuXG4gICAgICogQHBhcmFtIGV4cGlyZSAgICAgICAgIHJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy4gSWYsIGZvciBleGFtcGxlLCB5b3Ugd2FudCB0byBhY2Nlc3MgdGhlXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgIEFnb3JhIFNlcnZpY2Ugd2l0aGluIDEwIG1pbnV0ZXMgYWZ0ZXIgdGhlIHRva2VuIGlzIGdlbmVyYXRlZCwgc2V0IGV4cGlyZSBhc1xuICAgICAqICAgICAgICAgICAgICAgICAgICAgICA2MDAoc2Vjb25kcykuIFRoaXMgdmFsdWUgaXMgdGhlIHdob2xlIHRva2VuIGV4cGlyYXRpb24gYW5kIHRoZSBzZXJ2aWNlIHByaXZpbGVnZVxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICBleHBpcmF0aW9uLiBUaGUgd2hvbGUgdG9rZW4gaXMgaW52YWxpZCBhZnRlciB0aGlzIHRpbWUuXG4gICAgICogQHJldHVybiBUaGUgYXBwIHRva2VuLlxuICAgICAqL1xuICAgIHN0YXRpYyBidWlsZEFwcFRva2VuKGFwcElkLCBhcHBDZXJ0aWZpY2F0ZSwgZXhwaXJlKSB7XG4gICAgICAgIGxldCBhY2Nlc3NUb2tlbiA9IG5ldyBBY2Nlc3NUb2tlbihhcHBJZCwgYXBwQ2VydGlmaWNhdGUsIDAsIGV4cGlyZSlcbiAgICAgICAgbGV0IGFwYWFzU2VydmljZSA9IG5ldyBTZXJ2aWNlQXBhYXMoKVxuICAgICAgICBhcGFhc1NlcnZpY2UuYWRkX3ByaXZpbGVnZShTZXJ2aWNlQXBhYXMuUFJJVklMRUdFX0FQUCwgZXhwaXJlKVxuICAgICAgICBhY2Nlc3NUb2tlbi5hZGRfc2VydmljZShhcGFhc1NlcnZpY2UpXG5cbiAgICAgICAgcmV0dXJuIGFjY2Vzc1Rva2VuLmJ1aWxkKClcbiAgICB9XG59XG5cbm1vZHVsZS5leHBvcnRzLkFwYWFzVG9rZW5CdWlsZGVyID0gQXBhYXNUb2tlbkJ1aWxkZXJcbiIsImNvbnN0IEFjY2Vzc1Rva2VuID0gcmVxdWlyZSgnLi4vc3JjL0FjY2Vzc1Rva2VuMicpLkFjY2Vzc1Rva2VuMlxuY29uc3QgU2VydmljZUNoYXQgPSByZXF1aXJlKCcuLi9zcmMvQWNjZXNzVG9rZW4yJykuU2VydmljZUNoYXRcblxuY2xhc3MgQ2hhdFRva2VuQnVpbGRlciB7XG4gICAgLyoqXG4gICAgICogQnVpbGQgdGhlIENoYXQgdXNlciB0b2tlbi5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBhcHBJZCBUaGUgQXBwIElEIGlzc3VlZCB0byB5b3UgYnkgQWdvcmEuIEFwcGx5IGZvciBhIG5ldyBBcHAgSUQgZnJvbVxuICAgICAqIEFnb3JhIERhc2hib2FyZCBpZiBpdCBpcyBtaXNzaW5nIGZyb20geW91ciBraXQuIFNlZSBHZXQgYW4gQXBwIElELlxuICAgICAqIEBwYXJhbSBhcHBDZXJ0aWZpY2F0ZSBDZXJ0aWZpY2F0ZSBvZiB0aGUgYXBwbGljYXRpb24gdGhhdCB5b3UgcmVnaXN0ZXJlZCBpblxuICAgICAqIHRoZSBBZ29yYSBEYXNoYm9hcmQuIFNlZSBHZXQgYW4gQXBwIENlcnRpZmljYXRlLlxuICAgICAqIEBwYXJhbSB1c2VyVXVpZCBUaGUgdXNlcidzIGlkLCBtdXN0IGJlIHVuaXF1ZS5cbiAgICAgKiBAcGFyYW0gZXhwaXJlIHJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy4gSWYsIGZvciBleGFtcGxlLCB5b3Ugd2FudCB0byBhY2Nlc3MgdGhlXG4gICAgICogQWdvcmEgU2VydmljZSB3aXRoaW4gMTAgbWludXRlcyBhZnRlciB0aGUgdG9rZW4gaXMgZ2VuZXJhdGVkLCBzZXQgZXhwaXJlIGFzIDYwMChzZWNvbmRzKS4gVGhpcyB2YWx1ZSBpc1xuICAgICAqIHRoZSB3aG9sZSB0b2tlbiBleHBpcmF0aW9uIGFuZCB0aGUgc2VydmljZSBwcml2aWxlZ2UgZXhwaXJhdGlvbi4gVGhlIHdob2xlIHRva2VuIGlzIGludmFsaWQgYWZ0ZXIgdGhpc1xuICAgICAqIHRpbWUuXG4gICAgICogQHJldHVybiBUaGUgQ2hhdCBVc2VyIHRva2VuLlxuICAgICAqL1xuICAgIHN0YXRpYyBidWlsZFVzZXJUb2tlbihhcHBJZCwgYXBwQ2VydGlmaWNhdGUsIHVzZXJVdWlkLCBleHBpcmUpIHtcbiAgICAgICAgY29uc3QgdG9rZW4gPSBuZXcgQWNjZXNzVG9rZW4oYXBwSWQsIGFwcENlcnRpZmljYXRlLCBudWxsLCBleHBpcmUpXG4gICAgICAgIGNvbnN0IHNlcnZpY2VDaGF0ID0gbmV3IFNlcnZpY2VDaGF0KHVzZXJVdWlkKVxuICAgICAgICBzZXJ2aWNlQ2hhdC5hZGRfcHJpdmlsZWdlKFNlcnZpY2VDaGF0LmtQcml2aWxlZ2VVc2VyLCBleHBpcmUpXG4gICAgICAgIHRva2VuLmFkZF9zZXJ2aWNlKHNlcnZpY2VDaGF0KVxuICAgICAgICByZXR1cm4gdG9rZW4uYnVpbGQoKVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEJ1aWxkIHRoZSBDaGF0IEFwcCB0b2tlbi5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBhcHBJZCBUaGUgQXBwIElEIGlzc3VlZCB0byB5b3UgYnkgQWdvcmEuIEFwcGx5IGZvciBhIG5ldyBBcHAgSUQgZnJvbVxuICAgICAqIEFnb3JhIERhc2hib2FyZCBpZiBpdCBpcyBtaXNzaW5nIGZyb20geW91ciBraXQuIFNlZSBHZXQgYW4gQXBwIElELlxuICAgICAqIEBwYXJhbSBhcHBDZXJ0aWZpY2F0ZSBDZXJ0aWZpY2F0ZSBvZiB0aGUgYXBwbGljYXRpb24gdGhhdCB5b3UgcmVnaXN0ZXJlZCBpblxuICAgICAqIHRoZSBBZ29yYSBEYXNoYm9hcmQuIFNlZSBHZXQgYW4gQXBwIENlcnRpZmljYXRlLlxuICAgICAqIEBwYXJhbSBleHBpcmUgcmVwcmVzZW50ZWQgYnkgdGhlIG51bWJlciBvZiBzZWNvbmRzIGVsYXBzZWQgc2luY2Ugbm93LiBJZiwgZm9yIGV4YW1wbGUsIHlvdSB3YW50IHRvIGFjY2VzcyB0aGVcbiAgICAgKiBBZ29yYSBTZXJ2aWNlIHdpdGhpbiAxMCBtaW51dGVzIGFmdGVyIHRoZSB0b2tlbiBpcyBnZW5lcmF0ZWQsIHNldCBleHBpcmUgYXMgNjAwKHNlY29uZHMpLiBUaGlzIHZhbHVlIGlzXG4gICAgICogdGhlIHdob2xlIHRva2VuIGV4cGlyYXRpb24gYW5kIHRoZSBzZXJ2aWNlIHByaXZpbGVnZSBleHBpcmF0aW9uLiBUaGUgd2hvbGUgdG9rZW4gaXMgaW52YWxpZCBhZnRlciB0aGlzXG4gICAgICogdGltZS5cbiAgICAgKiBAcmV0dXJuIFRoZSBDaGF0IEFwcCB0b2tlbi5cbiAgICAgKi9cbiAgICBzdGF0aWMgYnVpbGRBcHBUb2tlbihhcHBJZCwgYXBwQ2VydGlmaWNhdGUsIGV4cGlyZSkge1xuICAgICAgICBjb25zdCB0b2tlbiA9IG5ldyBBY2Nlc3NUb2tlbihhcHBJZCwgYXBwQ2VydGlmaWNhdGUsIG51bGwsIGV4cGlyZSlcbiAgICAgICAgY29uc3Qgc2VydmljZUNoYXQgPSBuZXcgU2VydmljZUNoYXQoKVxuICAgICAgICBzZXJ2aWNlQ2hhdC5hZGRfcHJpdmlsZWdlKFNlcnZpY2VDaGF0LmtQcml2aWxlZ2VBcHAsIGV4cGlyZSlcbiAgICAgICAgdG9rZW4uYWRkX3NlcnZpY2Uoc2VydmljZUNoYXQpXG4gICAgICAgIHJldHVybiB0b2tlbi5idWlsZCgpXG4gICAgfVxufVxuXG5leHBvcnRzLkNoYXRUb2tlbkJ1aWxkZXIgPSBDaGF0VG9rZW5CdWlsZGVyXG4iLCJjb25zdCBBY2Nlc3NUb2tlbiA9IHJlcXVpcmUoJy4uL3NyYy9BY2Nlc3NUb2tlbjInKS5BY2Nlc3NUb2tlbjJcbmNvbnN0IFNlcnZpY2VSdGMgPSByZXF1aXJlKCcuLi9zcmMvQWNjZXNzVG9rZW4yJykuU2VydmljZVJ0Y1xuY29uc3QgU2VydmljZVJ0bSA9IHJlcXVpcmUoJy4uL3NyYy9BY2Nlc3NUb2tlbjInKS5TZXJ2aWNlUnRtXG5cbmNvbnN0IFJvbGUgPSB7XG4gICAgLyoqXG4gICAgICogUkVDT01NRU5ERUQuIFVzZSB0aGlzIHJvbGUgZm9yIGEgdm9pY2UvdmlkZW8gY2FsbCBvciBhIGxpdmUgYnJvYWRjYXN0LCBpZlxuICAgICAqIHlvdXIgc2NlbmFyaW8gZG9lcyBub3QgcmVxdWlyZSBhdXRoZW50aWNhdGlvbiBmb3JcbiAgICAgKiBbQ28taG9zdF0oaHR0cHM6Ly9kb2NzLmFnb3JhLmlvL2VuL3ZpZGVvLWNhbGxpbmcvZ2V0LXN0YXJ0ZWQvYXV0aGVudGljYXRpb24td29ya2Zsb3c/I2NvLWhvc3QtdG9rZW4tYXV0aGVudGljYXRpb24pLlxuICAgICAqL1xuICAgIFBVQkxJU0hFUjogMSxcblxuICAgIC8qKlxuICAgICAqIE9ubHkgdXNlIHRoaXMgcm9sZSBpZiB5b3VyIHNjZW5hcmlvIHJlcXVpcmUgYXV0aGVudGljYXRpb24gZm9yXG4gICAgICogW0NvLWhvc3RdKGh0dHBzOi8vZG9jcy5hZ29yYS5pby9lbi92aWRlby1jYWxsaW5nL2dldC1zdGFydGVkL2F1dGhlbnRpY2F0aW9uLXdvcmtmbG93PyNjby1ob3N0LXRva2VuLWF1dGhlbnRpY2F0aW9uKS5cbiAgICAgKlxuICAgICAqIEBub3RlIEluIG9yZGVyIGZvciB0aGlzIHJvbGUgdG8gdGFrZSBlZmZlY3QsIHBsZWFzZSBjb250YWN0IG91ciBzdXBwb3J0IHRlYW1cbiAgICAgKiB0byBlbmFibGUgYXV0aGVudGljYXRpb24gZm9yIEhvc3RpbmctaW4gZm9yIHlvdS4gT3RoZXJ3aXNlLCBSb2xlX1N1YnNjcmliZXJcbiAgICAgKiBzdGlsbCBoYXMgdGhlIHNhbWUgcHJpdmlsZWdlcyBhcyBSb2xlX1B1Ymxpc2hlci5cbiAgICAgKi9cbiAgICBTVUJTQ1JJQkVSOiAyXG59XG5cbmNsYXNzIFJ0Y1Rva2VuQnVpbGRlciB7XG4gICAgLyoqXG4gICAgICogQnVpbGRzIGFuIFJUQyB0b2tlbiB1c2luZyBhbiBJbnRlZ2VyIHVpZC5cbiAgICAgKiBAcGFyYW0geyp9IGFwcElkICBUaGUgQXBwIElEIGlzc3VlZCB0byB5b3UgYnkgQWdvcmEuXG4gICAgICogQHBhcmFtIHsqfSBhcHBDZXJ0aWZpY2F0ZSBDZXJ0aWZpY2F0ZSBvZiB0aGUgYXBwbGljYXRpb24gdGhhdCB5b3UgcmVnaXN0ZXJlZCBpbiB0aGUgQWdvcmEgRGFzaGJvYXJkLlxuICAgICAqIEBwYXJhbSB7Kn0gY2hhbm5lbE5hbWUgVGhlIHVuaXF1ZSBjaGFubmVsIG5hbWUgZm9yIHRoZSBBZ29yYVJUQyBzZXNzaW9uIGluIHRoZSBzdHJpbmcgZm9ybWF0LiBUaGUgc3RyaW5nIGxlbmd0aCBtdXN0IGJlIGxlc3MgdGhhbiA2NCBieXRlcy4gU3VwcG9ydGVkIGNoYXJhY3RlciBzY29wZXMgYXJlOlxuICAgICAqIC0gVGhlIDI2IGxvd2VyY2FzZSBFbmdsaXNoIGxldHRlcnM6IGEgdG8gei5cbiAgICAgKiAtIFRoZSAyNiB1cHBlcmNhc2UgRW5nbGlzaCBsZXR0ZXJzOiBBIHRvIFouXG4gICAgICogLSBUaGUgMTAgZGlnaXRzOiAwIHRvIDkuXG4gICAgICogLSBUaGUgc3BhY2UuXG4gICAgICogLSBcIiFcIiwgXCIjXCIsIFwiJFwiLCBcIiVcIiwgXCImXCIsIFwiKFwiLCBcIilcIiwgXCIrXCIsIFwiLVwiLCBcIjpcIiwgXCI7XCIsIFwiPFwiLCBcIj1cIiwgXCIuXCIsIFwiPlwiLCBcIj9cIiwgXCJAXCIsIFwiW1wiLCBcIl1cIiwgXCJeXCIsIFwiX1wiLCBcIiB7XCIsIFwifVwiLCBcInxcIiwgXCJ+XCIsIFwiLFwiLlxuICAgICAqIEBwYXJhbSB7Kn0gdWlkIFVzZXIgSUQuIEEgMzItYml0IHVuc2lnbmVkIGludGVnZXIgd2l0aCBhIHZhbHVlIHJhbmdpbmcgZnJvbSAxIHRvICgyXjMyLTEpLlxuICAgICAqIEBwYXJhbSB7Kn0gcm9sZSBTZWUgI3VzZXJSb2xlLlxuICAgICAqIC0gUm9sZS5QVUJMSVNIRVI7IFJFQ09NTUVOREVELiBVc2UgdGhpcyByb2xlIGZvciBhIHZvaWNlL3ZpZGVvIGNhbGwgb3IgYSBsaXZlIGJyb2FkY2FzdC5cbiAgICAgKiAtIFJvbGUuU1VCU0NSSUJFUjogT05MWSB1c2UgdGhpcyByb2xlIGlmIHlvdXIgbGl2ZS1icm9hZGNhc3Qgc2NlbmFyaW8gcmVxdWlyZXMgYXV0aGVudGljYXRpb24gZm9yIFtDby1ob3N0XShodHRwczovL2RvY3MuYWdvcmEuaW8vZW4vdmlkZW8tY2FsbGluZy9nZXQtc3RhcnRlZC9hdXRoZW50aWNhdGlvbi13b3JrZmxvdz8jY28taG9zdC10b2tlbi1hdXRoZW50aWNhdGlvbikuIEluIG9yZGVyIGZvciB0aGlzIHJvbGUgdG8gdGFrZSBlZmZlY3QsIHBsZWFzZSBjb250YWN0IG91ciBzdXBwb3J0IHRlYW0gdG8gZW5hYmxlIGF1dGhlbnRpY2F0aW9uIGZvciBDby1ob3N0IGZvciB5b3UuIE90aGVyd2lzZSwgUm9sZV9TdWJzY3JpYmVyIHN0aWxsIGhhcyB0aGUgc2FtZSBwcml2aWxlZ2VzIGFzIFJvbGVfUHVibGlzaGVyLlxuICAgICAqIEBwYXJhbSB7Kn0gdG9rZW5FeHBpcmUgcmVwcmVzZW50ZWQgYnkgdGhlIG51bWJlciBvZiBzZWNvbmRzIGVsYXBzZWQgc2luY2Ugbm93LiBJZiwgZm9yIGV4YW1wbGUsIHlvdVxuICAgICAqIHdhbnQgdG8gYWNjZXNzIHRoZSBBZ29yYSBTZXJ2aWNlIHdpdGhpbiAxMCBtaW51dGVzIGFmdGVyIHRoZSB0b2tlbiBpcyBnZW5lcmF0ZWQsIHNldCB0b2tlbkV4cGlyZSBhc1xuICAgICAqIDYwMChzZWNvbmRzKS4gVGhpcyBpcyB0aGUgd2hvbGUgdG9rZW4gZXhwaXJhdGlvbi4gVGhlIHdob2xlIHRva2VuIGlzIGludmFsaWQgYWZ0ZXIgdGhpcyB0aW1lLCBldmVuIGlmIGFcbiAgICAgKiBwcml2aWxlZ2UgZXhwaXJhdGlvbiB0aW1lIGlzIGxhdGVyLlxuICAgICAqIEBwYXJhbSB7Kn0gcHJpdmlsZWdlRXhwaXJlIHJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy4gSWYsIGZvciBleGFtcGxlLCB5b3VcbiAgICAgKiB3YW50IHRvIGVuYWJsZSB5b3VyIHByaXZpbGVnZSBmb3IgMTAgbWludXRlcywgc2V0IHByaXZpbGVnZUV4cGlyZSBhcyA2MDAoc2Vjb25kcykuIFRoaXMgdmFsdWUgbXVzdCBub3RcbiAgICAgKiBleGNlZWQgdGhlIHRva2VuIGV4cGlyYXRpb24gdmFsdWU7IG90aGVyd2lzZSwgdGhlIHByaXZpbGVnZSBpcyBsaW1pdGVkIGJ5IHRoZSB0b2tlbiBleHBpcmF0aW9uIHRpbWUuXG4gICAgICogQHJldHVybiBUaGUgUlRDIFRva2VuLlxuICAgICAqL1xuICAgIHN0YXRpYyBidWlsZFRva2VuV2l0aFVpZChhcHBJZCwgYXBwQ2VydGlmaWNhdGUsIGNoYW5uZWxOYW1lLCB1aWQsIHJvbGUsIHRva2VuRXhwaXJlLCBwcml2aWxlZ2VFeHBpcmUgPSAwKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmJ1aWxkVG9rZW5XaXRoVXNlckFjY291bnQoXG4gICAgICAgICAgICBhcHBJZCxcbiAgICAgICAgICAgIGFwcENlcnRpZmljYXRlLFxuICAgICAgICAgICAgY2hhbm5lbE5hbWUsXG4gICAgICAgICAgICB1aWQsXG4gICAgICAgICAgICByb2xlLFxuICAgICAgICAgICAgdG9rZW5FeHBpcmUsXG4gICAgICAgICAgICBwcml2aWxlZ2VFeHBpcmVcbiAgICAgICAgKVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEJ1aWxkcyBhbiBSVEMgdG9rZW4gd2l0aCBhY2NvdW50LlxuICAgICAqIEBwYXJhbSB7Kn0gYXBwSWQgIFRoZSBBcHAgSUQgaXNzdWVkIHRvIHlvdSBieSBBZ29yYS5cbiAgICAgKiBAcGFyYW0geyp9IGFwcENlcnRpZmljYXRlIENlcnRpZmljYXRlIG9mIHRoZSBhcHBsaWNhdGlvbiB0aGF0IHlvdSByZWdpc3RlcmVkIGluIHRoZSBBZ29yYSBEYXNoYm9hcmQuXG4gICAgICogQHBhcmFtIHsqfSBjaGFubmVsTmFtZSBUaGUgdW5pcXVlIGNoYW5uZWwgbmFtZSBmb3IgdGhlIEFnb3JhUlRDIHNlc3Npb24gaW4gdGhlIHN0cmluZyBmb3JtYXQuIFRoZSBzdHJpbmcgbGVuZ3RoIG11c3QgYmUgbGVzcyB0aGFuIDY0IGJ5dGVzLiBTdXBwb3J0ZWQgY2hhcmFjdGVyIHNjb3BlcyBhcmU6XG4gICAgICogLSBUaGUgMjYgbG93ZXJjYXNlIEVuZ2xpc2ggbGV0dGVyczogYSB0byB6LlxuICAgICAqIC0gVGhlIDI2IHVwcGVyY2FzZSBFbmdsaXNoIGxldHRlcnM6IEEgdG8gWi5cbiAgICAgKiAtIFRoZSAxMCBkaWdpdHM6IDAgdG8gOS5cbiAgICAgKiAtIFRoZSBzcGFjZS5cbiAgICAgKiAtIFwiIVwiLCBcIiNcIiwgXCIkXCIsIFwiJVwiLCBcIiZcIiwgXCIoXCIsIFwiKVwiLCBcIitcIiwgXCItXCIsIFwiOlwiLCBcIjtcIiwgXCI8XCIsIFwiPVwiLCBcIi5cIiwgXCI+XCIsIFwiP1wiLCBcIkBcIiwgXCJbXCIsIFwiXVwiLCBcIl5cIiwgXCJfXCIsIFwiIHtcIiwgXCJ9XCIsIFwifFwiLCBcIn5cIiwgXCIsXCIuXG4gICAgICogQHBhcmFtIHsqfSBhY2NvdW50IFRoZSB1c2VyIGFjY291bnQuXG4gICAgICogQHBhcmFtIHsqfSByb2xlIFNlZSAjdXNlclJvbGUuXG4gICAgICogLSBSb2xlLlBVQkxJU0hFUjsgUkVDT01NRU5ERUQuIFVzZSB0aGlzIHJvbGUgZm9yIGEgdm9pY2UvdmlkZW8gY2FsbCBvciBhIGxpdmUgYnJvYWRjYXN0LlxuICAgICAqIC0gUm9sZS5TVUJTQ1JJQkVSOiBPTkxZIHVzZSB0aGlzIHJvbGUgaWYgeW91ciBsaXZlLWJyb2FkY2FzdCBzY2VuYXJpbyByZXF1aXJlcyBhdXRoZW50aWNhdGlvbiBmb3IgW0NvLWhvc3RdKGh0dHBzOi8vZG9jcy5hZ29yYS5pby9lbi92aWRlby1jYWxsaW5nL2dldC1zdGFydGVkL2F1dGhlbnRpY2F0aW9uLXdvcmtmbG93PyNjby1ob3N0LXRva2VuLWF1dGhlbnRpY2F0aW9uKS4gSW4gb3JkZXIgZm9yIHRoaXMgcm9sZSB0byB0YWtlIGVmZmVjdCwgcGxlYXNlIGNvbnRhY3Qgb3VyIHN1cHBvcnQgdGVhbSB0byBlbmFibGUgYXV0aGVudGljYXRpb24gZm9yIENvLWhvc3QgZm9yIHlvdS4gT3RoZXJ3aXNlLCBSb2xlX1N1YnNjcmliZXIgc3RpbGwgaGFzIHRoZSBzYW1lIHByaXZpbGVnZXMgYXMgUm9sZV9QdWJsaXNoZXIuXG4gICAgICogQHBhcmFtIHsqfSB0b2tlbkV4cGlyZSByZXByZXNlbnRlZCBieSB0aGUgbnVtYmVyIG9mIHNlY29uZHMgZWxhcHNlZCBzaW5jZSBub3cuIElmLCBmb3IgZXhhbXBsZSwgeW91XG4gICAgICogd2FudCB0byBhY2Nlc3MgdGhlIEFnb3JhIFNlcnZpY2Ugd2l0aGluIDEwIG1pbnV0ZXMgYWZ0ZXIgdGhlIHRva2VuIGlzIGdlbmVyYXRlZCwgc2V0IHRva2VuRXhwaXJlIGFzXG4gICAgICogNjAwKHNlY29uZHMpLiBUaGlzIGlzIHRoZSB3aG9sZSB0b2tlbiBleHBpcmF0aW9uLiBUaGUgd2hvbGUgdG9rZW4gaXMgaW52YWxpZCBhZnRlciB0aGlzIHRpbWUsIGV2ZW4gaWYgYVxuICAgICAqIHByaXZpbGVnZSBleHBpcmF0aW9uIHRpbWUgaXMgbGF0ZXIuXG4gICAgICogQHBhcmFtIHsqfSBwcml2aWxlZ2VFeHBpcmUgcmVwcmVzZW50ZWQgYnkgdGhlIG51bWJlciBvZiBzZWNvbmRzIGVsYXBzZWQgc2luY2Ugbm93LiBJZiwgZm9yIGV4YW1wbGUsIHlvdVxuICAgICAqIHdhbnQgdG8gZW5hYmxlIHlvdXIgcHJpdmlsZWdlIGZvciAxMCBtaW51dGVzLCBzZXQgcHJpdmlsZWdlRXhwaXJlIGFzIDYwMChzZWNvbmRzKS4gVGhpcyB2YWx1ZSBtdXN0IG5vdFxuICAgICAqIGV4Y2VlZCB0aGUgdG9rZW4gZXhwaXJhdGlvbiB2YWx1ZTsgb3RoZXJ3aXNlLCB0aGUgcHJpdmlsZWdlIGlzIGxpbWl0ZWQgYnkgdGhlIHRva2VuIGV4cGlyYXRpb24gdGltZS5cbiAgICAgKiBAcmV0dXJuIFRoZSBSVEMgVG9rZW4uXG4gICAgICovXG4gICAgc3RhdGljIGJ1aWxkVG9rZW5XaXRoVXNlckFjY291bnQoXG4gICAgICAgIGFwcElkLFxuICAgICAgICBhcHBDZXJ0aWZpY2F0ZSxcbiAgICAgICAgY2hhbm5lbE5hbWUsXG4gICAgICAgIGFjY291bnQsXG4gICAgICAgIHJvbGUsXG4gICAgICAgIHRva2VuRXhwaXJlLFxuICAgICAgICBwcml2aWxlZ2VFeHBpcmUgPSAwXG4gICAgKSB7XG4gICAgICAgIGxldCB0b2tlbiA9IG5ldyBBY2Nlc3NUb2tlbihhcHBJZCwgYXBwQ2VydGlmaWNhdGUsIDAsIHRva2VuRXhwaXJlKVxuXG4gICAgICAgIGxldCBzZXJ2aWNlUnRjID0gbmV3IFNlcnZpY2VSdGMoY2hhbm5lbE5hbWUsIGFjY291bnQpXG4gICAgICAgIHNlcnZpY2VSdGMuYWRkX3ByaXZpbGVnZShTZXJ2aWNlUnRjLmtQcml2aWxlZ2VKb2luQ2hhbm5lbCwgcHJpdmlsZWdlRXhwaXJlKVxuICAgICAgICBpZiAocm9sZSA9PSBSb2xlLlBVQkxJU0hFUikge1xuICAgICAgICAgICAgc2VydmljZVJ0Yy5hZGRfcHJpdmlsZWdlKFNlcnZpY2VSdGMua1ByaXZpbGVnZVB1Ymxpc2hBdWRpb1N0cmVhbSwgcHJpdmlsZWdlRXhwaXJlKVxuICAgICAgICAgICAgc2VydmljZVJ0Yy5hZGRfcHJpdmlsZWdlKFNlcnZpY2VSdGMua1ByaXZpbGVnZVB1Ymxpc2hWaWRlb1N0cmVhbSwgcHJpdmlsZWdlRXhwaXJlKVxuICAgICAgICAgICAgc2VydmljZVJ0Yy5hZGRfcHJpdmlsZWdlKFNlcnZpY2VSdGMua1ByaXZpbGVnZVB1Ymxpc2hEYXRhU3RyZWFtLCBwcml2aWxlZ2VFeHBpcmUpXG4gICAgICAgIH1cbiAgICAgICAgdG9rZW4uYWRkX3NlcnZpY2Uoc2VydmljZVJ0YylcblxuICAgICAgICByZXR1cm4gdG9rZW4uYnVpbGQoKVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdlbmVyYXRlcyBhbiBSVEMgdG9rZW4gd2l0aCB0aGUgc3BlY2lmaWVkIHByaXZpbGVnZS5cbiAgICAgKlxuICAgICAqIFRoaXMgbWV0aG9kIHN1cHBvcnRzIGdlbmVyYXRpbmcgYSB0b2tlbiB3aXRoIHRoZSBmb2xsb3dpbmcgcHJpdmlsZWdlczpcbiAgICAgKiAtIEpvaW5pbmcgYW4gUlRDIGNoYW5uZWwuXG4gICAgICogLSBQdWJsaXNoaW5nIGF1ZGlvIGluIGFuIFJUQyBjaGFubmVsLlxuICAgICAqIC0gUHVibGlzaGluZyB2aWRlbyBpbiBhbiBSVEMgY2hhbm5lbC5cbiAgICAgKiAtIFB1Ymxpc2hpbmcgZGF0YSBzdHJlYW1zIGluIGFuIFJUQyBjaGFubmVsLlxuICAgICAqXG4gICAgICogVGhlIHByaXZpbGVnZXMgZm9yIHB1Ymxpc2hpbmcgYXVkaW8sIHZpZGVvLCBhbmQgZGF0YSBzdHJlYW1zIGluIGFuIFJUQyBjaGFubmVsIGFwcGx5IG9ubHkgaWYgeW91IGhhdmVcbiAgICAgKiBlbmFibGVkIGNvLWhvc3QgYXV0aGVudGljYXRpb24uXG4gICAgICpcbiAgICAgKiBBIHVzZXIgY2FuIGhhdmUgbXVsdGlwbGUgcHJpdmlsZWdlcy4gRWFjaCBwcml2aWxlZ2UgaXMgdmFsaWQgZm9yIGEgbWF4aW11bSBvZiAyNCBob3Vycy5cbiAgICAgKiBUaGUgU0RLIHRyaWdnZXJzIHRoZSBvblRva2VuUHJpdmlsZWdlV2lsbEV4cGlyZSBhbmQgb25SZXF1ZXN0VG9rZW4gY2FsbGJhY2tzIHdoZW4gdGhlIHRva2VuIGlzIGFib3V0IHRvIGV4cGlyZVxuICAgICAqIG9yIGhhcyBleHBpcmVkLiBUaGUgY2FsbGJhY2tzIGRvIG5vdCByZXBvcnQgdGhlIHNwZWNpZmljIHByaXZpbGVnZSBhZmZlY3RlZCwgYW5kIHlvdSBuZWVkIHRvIG1haW50YWluXG4gICAgICogdGhlIHJlc3BlY3RpdmUgdGltZXN0YW1wIGZvciBlYWNoIHByaXZpbGVnZSBpbiB5b3VyIGFwcCBsb2dpYy4gQWZ0ZXIgcmVjZWl2aW5nIHRoZSBjYWxsYmFjaywgeW91IG5lZWRcbiAgICAgKiB0byBnZW5lcmF0ZSBhIG5ldyB0b2tlbiwgYW5kIHRoZW4gY2FsbCByZW5ld1Rva2VuIHRvIHBhc3MgdGhlIG5ldyB0b2tlbiB0byB0aGUgU0RLLCBvciBjYWxsIGpvaW5DaGFubmVsIHRvIHJlLWpvaW5cbiAgICAgKiB0aGUgY2hhbm5lbC5cbiAgICAgKlxuICAgICAqIEBub3RlXG4gICAgICogQWdvcmEgcmVjb21tZW5kcyBzZXR0aW5nIGEgcmVhc29uYWJsZSB0aW1lc3RhbXAgZm9yIGVhY2ggcHJpdmlsZWdlIGFjY29yZGluZyB0byB5b3VyIHNjZW5hcmlvLlxuICAgICAqIFN1cHBvc2UgdGhlIGV4cGlyYXRpb24gdGltZXN0YW1wIGZvciBqb2luaW5nIHRoZSBjaGFubmVsIGlzIHNldCBlYXJsaWVyIHRoYW4gdGhhdCBmb3IgcHVibGlzaGluZyBhdWRpby5cbiAgICAgKiBXaGVuIHRoZSB0b2tlbiBmb3Igam9pbmluZyB0aGUgY2hhbm5lbCBleHBpcmVzLCB0aGUgdXNlciBpcyBpbW1lZGlhdGVseSBraWNrZWQgb2ZmIHRoZSBSVEMgY2hhbm5lbFxuICAgICAqIGFuZCBjYW5ub3QgcHVibGlzaCBhbnkgYXVkaW8gc3RyZWFtLCBldmVuIHRob3VnaCB0aGUgdGltZXN0YW1wIGZvciBwdWJsaXNoaW5nIGF1ZGlvIGhhcyBub3QgZXhwaXJlZC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBhcHBJZCBUaGUgQXBwIElEIG9mIHlvdXIgQWdvcmEgcHJvamVjdC5cbiAgICAgKiBAcGFyYW0gYXBwQ2VydGlmaWNhdGUgVGhlIEFwcCBDZXJ0aWZpY2F0ZSBvZiB5b3VyIEFnb3JhIHByb2plY3QuXG4gICAgICogQHBhcmFtIGNoYW5uZWxOYW1lIFRoZSB1bmlxdWUgY2hhbm5lbCBuYW1lIGZvciB0aGUgQWdvcmEgUlRDIHNlc3Npb24gaW4gc3RyaW5nIGZvcm1hdC4gVGhlIHN0cmluZyBsZW5ndGggbXVzdCBiZSBsZXNzIHRoYW4gNjQgYnl0ZXMuIFRoZSBjaGFubmVsIG5hbWUgbWF5IGNvbnRhaW4gdGhlIGZvbGxvd2luZyBjaGFyYWN0ZXJzOlxuICAgICAqIC0gQWxsIGxvd2VyY2FzZSBFbmdsaXNoIGxldHRlcnM6IGEgdG8gei5cbiAgICAgKiAtIEFsbCB1cHBlcmNhc2UgRW5nbGlzaCBsZXR0ZXJzOiBBIHRvIFouXG4gICAgICogLSBBbGwgbnVtZXJpYyBjaGFyYWN0ZXJzOiAwIHRvIDkuXG4gICAgICogLSBUaGUgc3BhY2UgY2hhcmFjdGVyLlxuICAgICAqIC0gXCIhXCIsIFwiI1wiLCBcIiRcIiwgXCIlXCIsIFwiJlwiLCBcIihcIiwgXCIpXCIsIFwiK1wiLCBcIi1cIiwgXCI6XCIsIFwiO1wiLCBcIjxcIiwgXCI9XCIsIFwiLlwiLCBcIj5cIiwgXCI/XCIsIFwiQFwiLCBcIltcIiwgXCJdXCIsIFwiXlwiLCBcIl9cIiwgXCIge1wiLCBcIn1cIiwgXCJ8XCIsIFwiflwiLCBcIixcIi5cbiAgICAgKiBAcGFyYW0gdWlkIFRoZSB1c2VyIElELiBBIDMyLWJpdCB1bnNpZ25lZCBpbnRlZ2VyIHdpdGggYSB2YWx1ZSByYW5nZSBmcm9tIDEgdG8gKDJeMzIgLSAxKS4gSXQgbXVzdCBiZSB1bmlxdWUuIFNldCB1aWQgYXMgMCwgaWYgeW91IGRvIG5vdCB3YW50IHRvIGF1dGhlbnRpY2F0ZSB0aGUgdXNlciBJRCwgdGhhdCBpcywgYW55IHVpZCBmcm9tIHRoZSBhcHAgY2xpZW50IGNhbiBqb2luIHRoZSBjaGFubmVsLlxuICAgICAqIEBwYXJhbSB0b2tlbkV4cGlyZSByZXByZXNlbnRlZCBieSB0aGUgbnVtYmVyIG9mIHNlY29uZHMgZWxhcHNlZCBzaW5jZSBub3cuIElmLCBmb3IgZXhhbXBsZSwgeW91IHdhbnQgdG8gYWNjZXNzIHRoZVxuICAgICAqIEFnb3JhIFNlcnZpY2Ugd2l0aGluIDEwIG1pbnV0ZXMgYWZ0ZXIgdGhlIHRva2VuIGlzIGdlbmVyYXRlZCwgc2V0IHRva2VuRXhwaXJlIGFzIDYwMChzZWNvbmRzKS4gVGhpcyBpc1xuICAgICAqIHRoZSB3aG9sZSB0b2tlbiBleHBpcmF0aW9uLiBUaGUgd2hvbGUgdG9rZW4gaXMgaW52YWxpZCBhZnRlciB0aGlzIHRpbWUsIGV2ZW4gaWYgYSBwcml2aWxlZ2UgZXhwaXJhdGlvblxuICAgICAqIHRpbWUgaXMgbGF0ZXIuXG4gICAgICogQHBhcmFtIGpvaW5DaGFubmVsUHJpdmlsZWdlRXhwaXJlIHJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy5cbiAgICAgKiBJZiwgZm9yIGV4YW1wbGUsIHlvdSB3YW50IHRvIGpvaW4gY2hhbm5lbCBhbmQgZXhwZWN0IHN0YXkgaW4gdGhlIGNoYW5uZWwgZm9yIDEwIG1pbnV0ZXMsIHNldFxuICAgICAqIGpvaW5DaGFubmVsUHJpdmlsZWdlRXhwaXJlIGFzIDYwMChzZWNvbmRzKS4gVGhpcyB2YWx1ZSBtdXN0IG5vdCBleGNlZWQgdGhlIHRva2VuIGV4cGlyYXRpb24gdmFsdWU7XG4gICAgICogb3RoZXJ3aXNlLCB0aGUgcHJpdmlsZWdlIGlzIGxpbWl0ZWQgYnkgdGhlIHRva2VuIGV4cGlyYXRpb24gdGltZS5cbiAgICAgKiBAcGFyYW0gcHViQXVkaW9Qcml2aWxlZ2VFeHBpcmUgcmVwcmVzZW50ZWQgYnkgdGhlIG51bWJlciBvZiBzZWNvbmRzIGVsYXBzZWQgc2luY2Ugbm93LlxuICAgICAqIElmLCBmb3IgZXhhbXBsZSwgeW91IHdhbnQgdG8gZW5hYmxlIHB1Ymxpc2ggYXVkaW8gcHJpdmlsZWdlIGZvciAxMCBtaW51dGVzLCBzZXQgcHViQXVkaW9Qcml2aWxlZ2VFeHBpcmVcbiAgICAgKiBhcyA2MDAoc2Vjb25kcykuIFRoaXMgdmFsdWUgbXVzdCBub3QgZXhjZWVkIHRoZSB0b2tlbiBleHBpcmF0aW9uIHZhbHVlOyBvdGhlcndpc2UsIHRoZSBwcml2aWxlZ2UgaXNcbiAgICAgKiBsaW1pdGVkIGJ5IHRoZSB0b2tlbiBleHBpcmF0aW9uIHRpbWUuXG4gICAgICogQHBhcmFtIHB1YlZpZGVvUHJpdmlsZWdlRXhwaXJlIHJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy5cbiAgICAgKiBJZiwgZm9yIGV4YW1wbGUsIHlvdSB3YW50IHRvIGVuYWJsZSBwdWJsaXNoIHZpZGVvIHByaXZpbGVnZSBmb3IgMTAgbWludXRlcywgc2V0IHB1YlZpZGVvUHJpdmlsZWdlRXhwaXJlXG4gICAgICogYXMgNjAwKHNlY29uZHMpLiBUaGlzIHZhbHVlIG11c3Qgbm90IGV4Y2VlZCB0aGUgdG9rZW4gZXhwaXJhdGlvbiB2YWx1ZTsgb3RoZXJ3aXNlLCB0aGUgcHJpdmlsZWdlIGlzXG4gICAgICogbGltaXRlZCBieSB0aGUgdG9rZW4gZXhwaXJhdGlvbiB0aW1lLlxuICAgICAqIEBwYXJhbSBwdWJEYXRhU3RyZWFtUHJpdmlsZWdlRXhwaXJlIHJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy5cbiAgICAgKiBJZiwgZm9yIGV4YW1wbGUsIHlvdSB3YW50IHRvIGVuYWJsZSBwdWJsaXNoIGRhdGEgc3RyZWFtIHByaXZpbGVnZSBmb3IgMTAgbWludXRlcywgc2V0XG4gICAgICogcHViRGF0YVN0cmVhbVByaXZpbGVnZUV4cGlyZSBhcyA2MDAoc2Vjb25kcykuIFRoaXMgdmFsdWUgbXVzdCBub3QgZXhjZWVkIHRoZSB0b2tlbiBleHBpcmF0aW9uIHZhbHVlO1xuICAgICAqIG90aGVyd2lzZSwgdGhlIHByaXZpbGVnZSBpcyBsaW1pdGVkIGJ5IHRoZSB0b2tlbiBleHBpcmF0aW9uIHRpbWUuXG4gICAgICogQHJldHVybiBUaGUgUlRDIFRva2VuXG4gICAgICovXG4gICAgc3RhdGljIGJ1aWxkVG9rZW5XaXRoVWlkQW5kUHJpdmlsZWdlKFxuICAgICAgICBhcHBJZCxcbiAgICAgICAgYXBwQ2VydGlmaWNhdGUsXG4gICAgICAgIGNoYW5uZWxOYW1lLFxuICAgICAgICB1aWQsXG4gICAgICAgIHRva2VuRXhwaXJlLFxuICAgICAgICBqb2luQ2hhbm5lbFByaXZpbGVnZUV4cGlyZSxcbiAgICAgICAgcHViQXVkaW9Qcml2aWxlZ2VFeHBpcmUsXG4gICAgICAgIHB1YlZpZGVvUHJpdmlsZWdlRXhwaXJlLFxuICAgICAgICBwdWJEYXRhU3RyZWFtUHJpdmlsZWdlRXhwaXJlXG4gICAgKSB7XG4gICAgICAgIHJldHVybiB0aGlzLkJ1aWxkVG9rZW5XaXRoVXNlckFjY291bnRBbmRQcml2aWxlZ2UoXG4gICAgICAgICAgICBhcHBJZCxcbiAgICAgICAgICAgIGFwcENlcnRpZmljYXRlLFxuICAgICAgICAgICAgY2hhbm5lbE5hbWUsXG4gICAgICAgICAgICB1aWQsXG4gICAgICAgICAgICB0b2tlbkV4cGlyZSxcbiAgICAgICAgICAgIGpvaW5DaGFubmVsUHJpdmlsZWdlRXhwaXJlLFxuICAgICAgICAgICAgcHViQXVkaW9Qcml2aWxlZ2VFeHBpcmUsXG4gICAgICAgICAgICBwdWJWaWRlb1ByaXZpbGVnZUV4cGlyZSxcbiAgICAgICAgICAgIHB1YkRhdGFTdHJlYW1Qcml2aWxlZ2VFeHBpcmVcbiAgICAgICAgKVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEdlbmVyYXRlcyBhbiBSVEMgdG9rZW4gd2l0aCB0aGUgc3BlY2lmaWVkIHByaXZpbGVnZS5cbiAgICAgKlxuICAgICAqIFRoaXMgbWV0aG9kIHN1cHBvcnRzIGdlbmVyYXRpbmcgYSB0b2tlbiB3aXRoIHRoZSBmb2xsb3dpbmcgcHJpdmlsZWdlczpcbiAgICAgKiAtIEpvaW5pbmcgYW4gUlRDIGNoYW5uZWwuXG4gICAgICogLSBQdWJsaXNoaW5nIGF1ZGlvIGluIGFuIFJUQyBjaGFubmVsLlxuICAgICAqIC0gUHVibGlzaGluZyB2aWRlbyBpbiBhbiBSVEMgY2hhbm5lbC5cbiAgICAgKiAtIFB1Ymxpc2hpbmcgZGF0YSBzdHJlYW1zIGluIGFuIFJUQyBjaGFubmVsLlxuICAgICAqXG4gICAgICogVGhlIHByaXZpbGVnZXMgZm9yIHB1Ymxpc2hpbmcgYXVkaW8sIHZpZGVvLCBhbmQgZGF0YSBzdHJlYW1zIGluIGFuIFJUQyBjaGFubmVsIGFwcGx5IG9ubHkgaWYgeW91IGhhdmVcbiAgICAgKiBlbmFibGVkIGNvLWhvc3QgYXV0aGVudGljYXRpb24uXG4gICAgICpcbiAgICAgKiBBIHVzZXIgY2FuIGhhdmUgbXVsdGlwbGUgcHJpdmlsZWdlcy4gRWFjaCBwcml2aWxlZ2UgaXMgdmFsaWQgZm9yIGEgbWF4aW11bSBvZiAyNCBob3Vycy5cbiAgICAgKiBUaGUgU0RLIHRyaWdnZXJzIHRoZSBvblRva2VuUHJpdmlsZWdlV2lsbEV4cGlyZSBhbmQgb25SZXF1ZXN0VG9rZW4gY2FsbGJhY2tzIHdoZW4gdGhlIHRva2VuIGlzIGFib3V0IHRvIGV4cGlyZVxuICAgICAqIG9yIGhhcyBleHBpcmVkLiBUaGUgY2FsbGJhY2tzIGRvIG5vdCByZXBvcnQgdGhlIHNwZWNpZmljIHByaXZpbGVnZSBhZmZlY3RlZCwgYW5kIHlvdSBuZWVkIHRvIG1haW50YWluXG4gICAgICogdGhlIHJlc3BlY3RpdmUgdGltZXN0YW1wIGZvciBlYWNoIHByaXZpbGVnZSBpbiB5b3VyIGFwcCBsb2dpYy4gQWZ0ZXIgcmVjZWl2aW5nIHRoZSBjYWxsYmFjaywgeW91IG5lZWRcbiAgICAgKiB0byBnZW5lcmF0ZSBhIG5ldyB0b2tlbiwgYW5kIHRoZW4gY2FsbCByZW5ld1Rva2VuIHRvIHBhc3MgdGhlIG5ldyB0b2tlbiB0byB0aGUgU0RLLCBvciBjYWxsIGpvaW5DaGFubmVsIHRvIHJlLWpvaW5cbiAgICAgKiB0aGUgY2hhbm5lbC5cbiAgICAgKlxuICAgICAqIEBub3RlXG4gICAgICogQWdvcmEgcmVjb21tZW5kcyBzZXR0aW5nIGEgcmVhc29uYWJsZSB0aW1lc3RhbXAgZm9yIGVhY2ggcHJpdmlsZWdlIGFjY29yZGluZyB0byB5b3VyIHNjZW5hcmlvLlxuICAgICAqIFN1cHBvc2UgdGhlIGV4cGlyYXRpb24gdGltZXN0YW1wIGZvciBqb2luaW5nIHRoZSBjaGFubmVsIGlzIHNldCBlYXJsaWVyIHRoYW4gdGhhdCBmb3IgcHVibGlzaGluZyBhdWRpby5cbiAgICAgKiBXaGVuIHRoZSB0b2tlbiBmb3Igam9pbmluZyB0aGUgY2hhbm5lbCBleHBpcmVzLCB0aGUgdXNlciBpcyBpbW1lZGlhdGVseSBraWNrZWQgb2ZmIHRoZSBSVEMgY2hhbm5lbFxuICAgICAqIGFuZCBjYW5ub3QgcHVibGlzaCBhbnkgYXVkaW8gc3RyZWFtLCBldmVuIHRob3VnaCB0aGUgdGltZXN0YW1wIGZvciBwdWJsaXNoaW5nIGF1ZGlvIGhhcyBub3QgZXhwaXJlZC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBhcHBJZCBUaGUgQXBwIElEIG9mIHlvdXIgQWdvcmEgcHJvamVjdC5cbiAgICAgKiBAcGFyYW0gYXBwQ2VydGlmaWNhdGUgVGhlIEFwcCBDZXJ0aWZpY2F0ZSBvZiB5b3VyIEFnb3JhIHByb2plY3QuXG4gICAgICogQHBhcmFtIGNoYW5uZWxOYW1lIFRoZSB1bmlxdWUgY2hhbm5lbCBuYW1lIGZvciB0aGUgQWdvcmEgUlRDIHNlc3Npb24gaW4gc3RyaW5nIGZvcm1hdC4gVGhlIHN0cmluZyBsZW5ndGggbXVzdCBiZSBsZXNzIHRoYW4gNjQgYnl0ZXMuIFRoZSBjaGFubmVsIG5hbWUgbWF5IGNvbnRhaW4gdGhlIGZvbGxvd2luZyBjaGFyYWN0ZXJzOlxuICAgICAqIC0gQWxsIGxvd2VyY2FzZSBFbmdsaXNoIGxldHRlcnM6IGEgdG8gei5cbiAgICAgKiAtIEFsbCB1cHBlcmNhc2UgRW5nbGlzaCBsZXR0ZXJzOiBBIHRvIFouXG4gICAgICogLSBBbGwgbnVtZXJpYyBjaGFyYWN0ZXJzOiAwIHRvIDkuXG4gICAgICogLSBUaGUgc3BhY2UgY2hhcmFjdGVyLlxuICAgICAqIC0gXCIhXCIsIFwiI1wiLCBcIiRcIiwgXCIlXCIsIFwiJlwiLCBcIihcIiwgXCIpXCIsIFwiK1wiLCBcIi1cIiwgXCI6XCIsIFwiO1wiLCBcIjxcIiwgXCI9XCIsIFwiLlwiLCBcIj5cIiwgXCI/XCIsIFwiQFwiLCBcIltcIiwgXCJdXCIsIFwiXlwiLCBcIl9cIiwgXCIge1wiLCBcIn1cIiwgXCJ8XCIsIFwiflwiLCBcIixcIi5cbiAgICAgKiBAcGFyYW0gdXNlckFjY291bnQgVGhlIHVzZXIgYWNjb3VudC5cbiAgICAgKiBAcGFyYW0gdG9rZW5FeHBpcmUgcmVwcmVzZW50ZWQgYnkgdGhlIG51bWJlciBvZiBzZWNvbmRzIGVsYXBzZWQgc2luY2Ugbm93LiBJZiwgZm9yIGV4YW1wbGUsIHlvdSB3YW50IHRvIGFjY2VzcyB0aGVcbiAgICAgKiBBZ29yYSBTZXJ2aWNlIHdpdGhpbiAxMCBtaW51dGVzIGFmdGVyIHRoZSB0b2tlbiBpcyBnZW5lcmF0ZWQsIHNldCB0b2tlbkV4cGlyZSBhcyA2MDAoc2Vjb25kcykuIFRoaXMgaXNcbiAgICAgKiB0aGUgd2hvbGUgdG9rZW4gZXhwaXJhdGlvbi4gVGhlIHdob2xlIHRva2VuIGlzIGludmFsaWQgYWZ0ZXIgdGhpcyB0aW1lLCBldmVuIGlmIGEgcHJpdmlsZWdlIGV4cGlyYXRpb25cbiAgICAgKiB0aW1lIGlzIGxhdGVyLlxuICAgICAqIEBwYXJhbSBqb2luQ2hhbm5lbFByaXZpbGVnZUV4cGlyZSByZXByZXNlbnRlZCBieSB0aGUgbnVtYmVyIG9mIHNlY29uZHMgZWxhcHNlZCBzaW5jZSBub3cuXG4gICAgICogSWYsIGZvciBleGFtcGxlLCB5b3Ugd2FudCB0byBqb2luIGNoYW5uZWwgYW5kIGV4cGVjdCBzdGF5IGluIHRoZSBjaGFubmVsIGZvciAxMCBtaW51dGVzLCBzZXRcbiAgICAgKiBqb2luQ2hhbm5lbFByaXZpbGVnZUV4cGlyZSBhcyA2MDAoc2Vjb25kcykuIFRoaXMgdmFsdWUgbXVzdCBub3QgZXhjZWVkIHRoZSB0b2tlbiBleHBpcmF0aW9uIHZhbHVlO1xuICAgICAqIG90aGVyd2lzZSwgdGhlIHByaXZpbGVnZSBpcyBsaW1pdGVkIGJ5IHRoZSB0b2tlbiBleHBpcmF0aW9uIHRpbWUuXG4gICAgICogQHBhcmFtIHB1YkF1ZGlvUHJpdmlsZWdlRXhwaXJlIHJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy5cbiAgICAgKiBJZiwgZm9yIGV4YW1wbGUsIHlvdSB3YW50IHRvIGVuYWJsZSBwdWJsaXNoIGF1ZGlvIHByaXZpbGVnZSBmb3IgMTAgbWludXRlcywgc2V0IHB1YkF1ZGlvUHJpdmlsZWdlRXhwaXJlXG4gICAgICogYXMgNjAwKHNlY29uZHMpLiBUaGlzIHZhbHVlIG11c3Qgbm90IGV4Y2VlZCB0aGUgdG9rZW4gZXhwaXJhdGlvbiB2YWx1ZTsgb3RoZXJ3aXNlLCB0aGUgcHJpdmlsZWdlIGlzXG4gICAgICogbGltaXRlZCBieSB0aGUgdG9rZW4gZXhwaXJhdGlvbiB0aW1lLlxuICAgICAqIEBwYXJhbSBwdWJWaWRlb1ByaXZpbGVnZUV4cGlyZSByZXByZXNlbnRlZCBieSB0aGUgbnVtYmVyIG9mIHNlY29uZHMgZWxhcHNlZCBzaW5jZSBub3cuXG4gICAgICogSWYsIGZvciBleGFtcGxlLCB5b3Ugd2FudCB0byBlbmFibGUgcHVibGlzaCB2aWRlbyBwcml2aWxlZ2UgZm9yIDEwIG1pbnV0ZXMsIHNldCBwdWJWaWRlb1ByaXZpbGVnZUV4cGlyZVxuICAgICAqIGFzIDYwMChzZWNvbmRzKS4gVGhpcyB2YWx1ZSBtdXN0IG5vdCBleGNlZWQgdGhlIHRva2VuIGV4cGlyYXRpb24gdmFsdWU7IG90aGVyd2lzZSwgdGhlIHByaXZpbGVnZSBpc1xuICAgICAqIGxpbWl0ZWQgYnkgdGhlIHRva2VuIGV4cGlyYXRpb24gdGltZS5cbiAgICAgKiBAcGFyYW0gcHViRGF0YVN0cmVhbVByaXZpbGVnZUV4cGlyZSByZXByZXNlbnRlZCBieSB0aGUgbnVtYmVyIG9mIHNlY29uZHMgZWxhcHNlZCBzaW5jZSBub3cuXG4gICAgICogSWYsIGZvciBleGFtcGxlLCB5b3Ugd2FudCB0byBlbmFibGUgcHVibGlzaCBkYXRhIHN0cmVhbSBwcml2aWxlZ2UgZm9yIDEwIG1pbnV0ZXMsIHNldFxuICAgICAqIHB1YkRhdGFTdHJlYW1Qcml2aWxlZ2VFeHBpcmUgYXMgNjAwKHNlY29uZHMpLiBUaGlzIHZhbHVlIG11c3Qgbm90IGV4Y2VlZCB0aGUgdG9rZW4gZXhwaXJhdGlvbiB2YWx1ZTtcbiAgICAgKiBvdGhlcndpc2UsIHRoZSBwcml2aWxlZ2UgaXMgbGltaXRlZCBieSB0aGUgdG9rZW4gZXhwaXJhdGlvbiB0aW1lLlxuICAgICAqIEByZXR1cm4gVGhlIFJUQyBUb2tlbi5cbiAgICAgKi9cbiAgICBzdGF0aWMgQnVpbGRUb2tlbldpdGhVc2VyQWNjb3VudEFuZFByaXZpbGVnZShcbiAgICAgICAgYXBwSWQsXG4gICAgICAgIGFwcENlcnRpZmljYXRlLFxuICAgICAgICBjaGFubmVsTmFtZSxcbiAgICAgICAgYWNjb3VudCxcbiAgICAgICAgdG9rZW5FeHBpcmUsXG4gICAgICAgIGpvaW5DaGFubmVsUHJpdmlsZWdlRXhwaXJlLFxuICAgICAgICBwdWJBdWRpb1ByaXZpbGVnZUV4cGlyZSxcbiAgICAgICAgcHViVmlkZW9Qcml2aWxlZ2VFeHBpcmUsXG4gICAgICAgIHB1YkRhdGFTdHJlYW1Qcml2aWxlZ2VFeHBpcmVcbiAgICApIHtcbiAgICAgICAgbGV0IHRva2VuID0gbmV3IEFjY2Vzc1Rva2VuKGFwcElkLCBhcHBDZXJ0aWZpY2F0ZSwgMCwgdG9rZW5FeHBpcmUpXG5cbiAgICAgICAgbGV0IHNlcnZpY2VSdGMgPSBuZXcgU2VydmljZVJ0YyhjaGFubmVsTmFtZSwgYWNjb3VudClcbiAgICAgICAgc2VydmljZVJ0Yy5hZGRfcHJpdmlsZWdlKFNlcnZpY2VSdGMua1ByaXZpbGVnZUpvaW5DaGFubmVsLCBqb2luQ2hhbm5lbFByaXZpbGVnZUV4cGlyZSlcbiAgICAgICAgc2VydmljZVJ0Yy5hZGRfcHJpdmlsZWdlKFNlcnZpY2VSdGMua1ByaXZpbGVnZVB1Ymxpc2hBdWRpb1N0cmVhbSwgcHViQXVkaW9Qcml2aWxlZ2VFeHBpcmUpXG4gICAgICAgIHNlcnZpY2VSdGMuYWRkX3ByaXZpbGVnZShTZXJ2aWNlUnRjLmtQcml2aWxlZ2VQdWJsaXNoVmlkZW9TdHJlYW0sIHB1YlZpZGVvUHJpdmlsZWdlRXhwaXJlKVxuICAgICAgICBzZXJ2aWNlUnRjLmFkZF9wcml2aWxlZ2UoU2VydmljZVJ0Yy5rUHJpdmlsZWdlUHVibGlzaERhdGFTdHJlYW0sIHB1YkRhdGFTdHJlYW1Qcml2aWxlZ2VFeHBpcmUpXG4gICAgICAgIHRva2VuLmFkZF9zZXJ2aWNlKHNlcnZpY2VSdGMpXG5cbiAgICAgICAgcmV0dXJuIHRva2VuLmJ1aWxkKClcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBCdWlsZCBhbiBSVEMgYW5kIFJUTSB0b2tlbiB3aXRoIGFjY291bnQuXG4gICAgICogQHBhcmFtIHsqfSBhcHBJZCAgVGhlIEFwcCBJRCBpc3N1ZWQgdG8geW91IGJ5IEFnb3JhLlxuICAgICAqIEBwYXJhbSB7Kn0gYXBwQ2VydGlmaWNhdGUgQ2VydGlmaWNhdGUgb2YgdGhlIGFwcGxpY2F0aW9uIHRoYXQgeW91IHJlZ2lzdGVyZWQgaW4gdGhlIEFnb3JhIERhc2hib2FyZC5cbiAgICAgKiBAcGFyYW0geyp9IGNoYW5uZWxOYW1lIFRoZSB1bmlxdWUgY2hhbm5lbCBuYW1lIGZvciB0aGUgQWdvcmFSVEMgc2Vzc2lvbiBpbiB0aGUgc3RyaW5nIGZvcm1hdC4gVGhlIHN0cmluZyBsZW5ndGggbXVzdCBiZSBsZXNzIHRoYW4gNjQgYnl0ZXMuIFN1cHBvcnRlZCBjaGFyYWN0ZXIgc2NvcGVzIGFyZTpcbiAgICAgKiAtIFRoZSAyNiBsb3dlcmNhc2UgRW5nbGlzaCBsZXR0ZXJzOiBhIHRvIHouXG4gICAgICogLSBUaGUgMjYgdXBwZXJjYXNlIEVuZ2xpc2ggbGV0dGVyczogQSB0byBaLlxuICAgICAqIC0gVGhlIDEwIGRpZ2l0czogMCB0byA5LlxuICAgICAqIC0gVGhlIHNwYWNlLlxuICAgICAqIC0gXCIhXCIsIFwiI1wiLCBcIiRcIiwgXCIlXCIsIFwiJlwiLCBcIihcIiwgXCIpXCIsIFwiK1wiLCBcIi1cIiwgXCI6XCIsIFwiO1wiLCBcIjxcIiwgXCI9XCIsIFwiLlwiLCBcIj5cIiwgXCI/XCIsIFwiQFwiLCBcIltcIiwgXCJdXCIsIFwiXlwiLCBcIl9cIiwgXCIge1wiLCBcIn1cIiwgXCJ8XCIsIFwiflwiLCBcIixcIi5cbiAgICAgKiBAcGFyYW0geyp9IGFjY291bnQgVGhlIHVzZXIgYWNjb3VudC5cbiAgICAgKiBAcGFyYW0geyp9IHJvbGUgU2VlICN1c2VyUm9sZS5cbiAgICAgKiAtIFJvbGUuUFVCTElTSEVSOyBSRUNPTU1FTkRFRC4gVXNlIHRoaXMgcm9sZSBmb3IgYSB2b2ljZS92aWRlbyBjYWxsIG9yIGEgbGl2ZSBicm9hZGNhc3QuXG4gICAgICogLSBSb2xlLlNVQlNDUklCRVI6IE9OTFkgdXNlIHRoaXMgcm9sZSBpZiB5b3VyIGxpdmUtYnJvYWRjYXN0IHNjZW5hcmlvIHJlcXVpcmVzIGF1dGhlbnRpY2F0aW9uIGZvciBbQ28taG9zdF0oaHR0cHM6Ly9kb2NzLmFnb3JhLmlvL2VuL3ZpZGVvLWNhbGxpbmcvZ2V0LXN0YXJ0ZWQvYXV0aGVudGljYXRpb24td29ya2Zsb3c/I2NvLWhvc3QtdG9rZW4tYXV0aGVudGljYXRpb24pLiBJbiBvcmRlciBmb3IgdGhpcyByb2xlIHRvIHRha2UgZWZmZWN0LCBwbGVhc2UgY29udGFjdCBvdXIgc3VwcG9ydCB0ZWFtIHRvIGVuYWJsZSBhdXRoZW50aWNhdGlvbiBmb3IgQ28taG9zdCBmb3IgeW91LiBPdGhlcndpc2UsIFJvbGVfU3Vic2NyaWJlciBzdGlsbCBoYXMgdGhlIHNhbWUgcHJpdmlsZWdlcyBhcyBSb2xlX1B1Ymxpc2hlci5cbiAgICAgKiBAcGFyYW0geyp9IHRva2VuRXhwaXJlIHJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy4gSWYsIGZvciBleGFtcGxlLCB5b3VcbiAgICAgKiB3YW50IHRvIGFjY2VzcyB0aGUgQWdvcmEgU2VydmljZSB3aXRoaW4gMTAgbWludXRlcyBhZnRlciB0aGUgdG9rZW4gaXMgZ2VuZXJhdGVkLCBzZXQgdG9rZW5FeHBpcmUgYXNcbiAgICAgKiA2MDAoc2Vjb25kcykuIFRoaXMgaXMgdGhlIHdob2xlIHRva2VuIGV4cGlyYXRpb24uIFRoZSB3aG9sZSB0b2tlbiBpcyBpbnZhbGlkIGFmdGVyIHRoaXMgdGltZSwgZXZlbiBpZiBhXG4gICAgICogcHJpdmlsZWdlIGV4cGlyYXRpb24gdGltZSBpcyBsYXRlci5cbiAgICAgKiBAcGFyYW0geyp9IHByaXZpbGVnZUV4cGlyZSByZXByZXNlbnRlZCBieSB0aGUgbnVtYmVyIG9mIHNlY29uZHMgZWxhcHNlZCBzaW5jZSBub3cuIElmLCBmb3IgZXhhbXBsZSwgeW91XG4gICAgICogd2FudCB0byBlbmFibGUgeW91ciBwcml2aWxlZ2UgZm9yIDEwIG1pbnV0ZXMsIHNldCBwcml2aWxlZ2VFeHBpcmUgYXMgNjAwKHNlY29uZHMpLiBUaGlzIHZhbHVlIG11c3Qgbm90XG4gICAgICogZXhjZWVkIHRoZSB0b2tlbiBleHBpcmF0aW9uIHZhbHVlOyBvdGhlcndpc2UsIHRoZSBwcml2aWxlZ2UgaXMgbGltaXRlZCBieSB0aGUgdG9rZW4gZXhwaXJhdGlvbiB0aW1lLlxuICAgICAqIEByZXR1cm4gVGhlIFJUQyBhbmQgUlRNIFRva2VuLlxuICAgICAqL1xuICAgIHN0YXRpYyBidWlsZFRva2VuV2l0aFJ0bShhcHBJZCwgYXBwQ2VydGlmaWNhdGUsIGNoYW5uZWxOYW1lLCBhY2NvdW50LCByb2xlLCB0b2tlbkV4cGlyZSwgcHJpdmlsZWdlRXhwaXJlID0gMCkge1xuICAgICAgICBsZXQgdG9rZW4gPSBuZXcgQWNjZXNzVG9rZW4oYXBwSWQsIGFwcENlcnRpZmljYXRlLCAwLCB0b2tlbkV4cGlyZSlcblxuICAgICAgICBsZXQgc2VydmljZVJ0YyA9IG5ldyBTZXJ2aWNlUnRjKGNoYW5uZWxOYW1lLCBhY2NvdW50KVxuICAgICAgICBzZXJ2aWNlUnRjLmFkZF9wcml2aWxlZ2UoU2VydmljZVJ0Yy5rUHJpdmlsZWdlSm9pbkNoYW5uZWwsIHByaXZpbGVnZUV4cGlyZSlcbiAgICAgICAgaWYgKHJvbGUgPT0gUm9sZS5QVUJMSVNIRVIpIHtcbiAgICAgICAgICAgIHNlcnZpY2VSdGMuYWRkX3ByaXZpbGVnZShTZXJ2aWNlUnRjLmtQcml2aWxlZ2VQdWJsaXNoQXVkaW9TdHJlYW0sIHByaXZpbGVnZUV4cGlyZSlcbiAgICAgICAgICAgIHNlcnZpY2VSdGMuYWRkX3ByaXZpbGVnZShTZXJ2aWNlUnRjLmtQcml2aWxlZ2VQdWJsaXNoVmlkZW9TdHJlYW0sIHByaXZpbGVnZUV4cGlyZSlcbiAgICAgICAgICAgIHNlcnZpY2VSdGMuYWRkX3ByaXZpbGVnZShTZXJ2aWNlUnRjLmtQcml2aWxlZ2VQdWJsaXNoRGF0YVN0cmVhbSwgcHJpdmlsZWdlRXhwaXJlKVxuICAgICAgICB9XG4gICAgICAgIHRva2VuLmFkZF9zZXJ2aWNlKHNlcnZpY2VSdGMpXG5cbiAgICAgICAgbGV0IHNlcnZpY2VSdG0gPSBuZXcgU2VydmljZVJ0bShhY2NvdW50KVxuICAgICAgICBzZXJ2aWNlUnRtLmFkZF9wcml2aWxlZ2UoU2VydmljZVJ0bS5rUHJpdmlsZWdlTG9naW4sIHRva2VuRXhwaXJlKVxuICAgICAgICB0b2tlbi5hZGRfc2VydmljZShzZXJ2aWNlUnRtKVxuXG4gICAgICAgIHJldHVybiB0b2tlbi5idWlsZCgpXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQnVpbGQgYW4gUlRDIGFuZCBSVE0gdG9rZW4gd2l0aCBhY2NvdW50LlxuICAgICAqIEBwYXJhbSB7Kn0gYXBwSWQgIFRoZSBBcHAgSUQgaXNzdWVkIHRvIHlvdSBieSBBZ29yYS5cbiAgICAgKiBAcGFyYW0geyp9IGFwcENlcnRpZmljYXRlIENlcnRpZmljYXRlIG9mIHRoZSBhcHBsaWNhdGlvbiB0aGF0IHlvdSByZWdpc3RlcmVkIGluIHRoZSBBZ29yYSBEYXNoYm9hcmQuXG4gICAgICogQHBhcmFtIHsqfSBjaGFubmVsTmFtZSBUaGUgdW5pcXVlIGNoYW5uZWwgbmFtZSBmb3IgdGhlIEFnb3JhUlRDIHNlc3Npb24gaW4gdGhlIHN0cmluZyBmb3JtYXQuIFRoZSBzdHJpbmcgbGVuZ3RoIG11c3QgYmUgbGVzcyB0aGFuIDY0IGJ5dGVzLiBTdXBwb3J0ZWQgY2hhcmFjdGVyIHNjb3BlcyBhcmU6XG4gICAgICogLSBUaGUgMjYgbG93ZXJjYXNlIEVuZ2xpc2ggbGV0dGVyczogYSB0byB6LlxuICAgICAqIC0gVGhlIDI2IHVwcGVyY2FzZSBFbmdsaXNoIGxldHRlcnM6IEEgdG8gWi5cbiAgICAgKiAtIFRoZSAxMCBkaWdpdHM6IDAgdG8gOS5cbiAgICAgKiAtIFRoZSBzcGFjZS5cbiAgICAgKiAtIFwiIVwiLCBcIiNcIiwgXCIkXCIsIFwiJVwiLCBcIiZcIiwgXCIoXCIsIFwiKVwiLCBcIitcIiwgXCItXCIsIFwiOlwiLCBcIjtcIiwgXCI8XCIsIFwiPVwiLCBcIi5cIiwgXCI+XCIsIFwiP1wiLCBcIkBcIiwgXCJbXCIsIFwiXVwiLCBcIl5cIiwgXCJfXCIsIFwiIHtcIiwgXCJ9XCIsIFwifFwiLCBcIn5cIiwgXCIsXCIuXG4gICAgICogQHBhcmFtIHsqfSBydGNBY2NvdW50IFRoZSBSVEMgdXNlcidzIGFjY291bnQsIG1heCBsZW5ndGggaXMgMjU1IEJ5dGVzLlxuICAgICAqIEBwYXJhbSB7Kn0gcnRjUm9sZSBTZWUgI3VzZXJSb2xlLlxuICAgICAqIC0gUm9sZS5QVUJMSVNIRVI7IFJFQ09NTUVOREVELiBVc2UgdGhpcyByb2xlIGZvciBhIHZvaWNlL3ZpZGVvIGNhbGwgb3IgYSBsaXZlIGJyb2FkY2FzdC5cbiAgICAgKiAtIFJvbGUuU1VCU0NSSUJFUjogT05MWSB1c2UgdGhpcyByb2xlIGlmIHlvdXIgbGl2ZS1icm9hZGNhc3Qgc2NlbmFyaW8gcmVxdWlyZXMgYXV0aGVudGljYXRpb24gZm9yIFtDby1ob3N0XShodHRwczovL2RvY3MuYWdvcmEuaW8vZW4vdmlkZW8tY2FsbGluZy9nZXQtc3RhcnRlZC9hdXRoZW50aWNhdGlvbi13b3JrZmxvdz8jY28taG9zdC10b2tlbi1hdXRoZW50aWNhdGlvbikuIEluIG9yZGVyIGZvciB0aGlzIHJvbGUgdG8gdGFrZSBlZmZlY3QsIHBsZWFzZSBjb250YWN0IG91ciBzdXBwb3J0IHRlYW0gdG8gZW5hYmxlIGF1dGhlbnRpY2F0aW9uIGZvciBDby1ob3N0IGZvciB5b3UuIE90aGVyd2lzZSwgUm9sZV9TdWJzY3JpYmVyIHN0aWxsIGhhcyB0aGUgc2FtZSBwcml2aWxlZ2VzIGFzIFJvbGVfUHVibGlzaGVyLlxuICAgICAqIEBwYXJhbSB7Kn0gcnRjVG9rZW5FeHBpcmUgcmVwcmVzZW50ZWQgYnkgdGhlIG51bWJlciBvZiBzZWNvbmRzIGVsYXBzZWQgc2luY2Ugbm93LiBJZiwgZm9yIGV4YW1wbGUsIHlvdVxuICAgICAqIHdhbnQgdG8gYWNjZXNzIHRoZSBBZ29yYSBTZXJ2aWNlIHdpdGhpbiAxMCBtaW51dGVzIGFmdGVyIHRoZSB0b2tlbiBpcyBnZW5lcmF0ZWQsIHNldCBydGNUb2tlbkV4cGlyZSBhc1xuICAgICAqIDYwMChzZWNvbmRzKS4gVGhpcyBpcyB0aGUgd2hvbGUgdG9rZW4gZXhwaXJhdGlvbi4gVGhlIHdob2xlIHRva2VuIGlzIGludmFsaWQgYWZ0ZXIgdGhpcyB0aW1lLCBldmVuIGlmIGFcbiAgICAgKiBwcml2aWxlZ2UgZXhwaXJhdGlvbiB0aW1lIGlzIGxhdGVyLlxuICAgICAqIEBwYXJhbSB7Kn0gam9pbkNoYW5uZWxQcml2aWxlZ2VFeHBpcmUgcmVwcmVzZW50ZWQgYnkgdGhlIG51bWJlciBvZiBzZWNvbmRzIGVsYXBzZWQgc2luY2Ugbm93LlxuICAgICAqIElmLCBmb3IgZXhhbXBsZSwgeW91IHdhbnQgdG8gam9pbiBjaGFubmVsIGFuZCBleHBlY3Qgc3RheSBpbiB0aGUgY2hhbm5lbCBmb3IgMTAgbWludXRlcywgc2V0XG4gICAgICogam9pbkNoYW5uZWxQcml2aWxlZ2VFeHBpcmUgYXMgNjAwKHNlY29uZHMpLiBUaGlzIHZhbHVlIG11c3Qgbm90IGV4Y2VlZCB0aGUgdG9rZW4gZXhwaXJhdGlvbiB2YWx1ZTtcbiAgICAgKiBvdGhlcndpc2UsIHRoZSBwcml2aWxlZ2UgaXMgbGltaXRlZCBieSB0aGUgdG9rZW4gZXhwaXJhdGlvbiB0aW1lLlxuICAgICAqIEBwYXJhbSB7Kn0gcHViQXVkaW9Qcml2aWxlZ2VFeHBpcmUgcmVwcmVzZW50ZWQgYnkgdGhlIG51bWJlciBvZiBzZWNvbmRzIGVsYXBzZWQgc2luY2Ugbm93LlxuICAgICAqIElmLCBmb3IgZXhhbXBsZSwgeW91IHdhbnQgdG8gZW5hYmxlIHB1Ymxpc2ggYXVkaW8gcHJpdmlsZWdlIGZvciAxMCBtaW51dGVzLCBzZXQgcHViQXVkaW9Qcml2aWxlZ2VFeHBpcmVcbiAgICAgKiBhcyA2MDAoc2Vjb25kcykuIFRoaXMgdmFsdWUgbXVzdCBub3QgZXhjZWVkIHRoZSB0b2tlbiBleHBpcmF0aW9uIHZhbHVlOyBvdGhlcndpc2UsIHRoZSBwcml2aWxlZ2UgaXNcbiAgICAgKiBsaW1pdGVkIGJ5IHRoZSB0b2tlbiBleHBpcmF0aW9uIHRpbWUuXG4gICAgICogQHBhcmFtIHsqfSBwdWJWaWRlb1ByaXZpbGVnZUV4cGlyZSByZXByZXNlbnRlZCBieSB0aGUgbnVtYmVyIG9mIHNlY29uZHMgZWxhcHNlZCBzaW5jZSBub3cuXG4gICAgICogSWYsIGZvciBleGFtcGxlLCB5b3Ugd2FudCB0byBlbmFibGUgcHVibGlzaCB2aWRlbyBwcml2aWxlZ2UgZm9yIDEwIG1pbnV0ZXMsIHNldCBwdWJWaWRlb1ByaXZpbGVnZUV4cGlyZVxuICAgICAqIGFzIDYwMChzZWNvbmRzKS4gVGhpcyB2YWx1ZSBtdXN0IG5vdCBleGNlZWQgdGhlIHRva2VuIGV4cGlyYXRpb24gdmFsdWU7IG90aGVyd2lzZSwgdGhlIHByaXZpbGVnZSBpc1xuICAgICAqIGxpbWl0ZWQgYnkgdGhlIHRva2VuIGV4cGlyYXRpb24gdGltZS5cbiAgICAgKiBAcGFyYW0geyp9IHB1YkRhdGFTdHJlYW1Qcml2aWxlZ2VFeHBpcmUgcmVwcmVzZW50ZWQgYnkgdGhlIG51bWJlciBvZiBzZWNvbmRzIGVsYXBzZWQgc2luY2Ugbm93LlxuICAgICAqIElmLCBmb3IgZXhhbXBsZSwgeW91IHdhbnQgdG8gZW5hYmxlIHB1Ymxpc2ggZGF0YSBzdHJlYW0gcHJpdmlsZWdlIGZvciAxMCBtaW51dGVzLCBzZXRcbiAgICAgKiBwdWJEYXRhU3RyZWFtUHJpdmlsZWdlRXhwaXJlIGFzIDYwMChzZWNvbmRzKS4gVGhpcyB2YWx1ZSBtdXN0IG5vdCBleGNlZWQgdGhlIHRva2VuIGV4cGlyYXRpb24gdmFsdWU7XG4gICAgICogb3RoZXJ3aXNlLCB0aGUgcHJpdmlsZWdlIGlzIGxpbWl0ZWQgYnkgdGhlIHRva2VuIGV4cGlyYXRpb24gdGltZS5cbiAgICAgKiBAcGFyYW0geyp9IHJ0bVVzZXJJZDogVGhlIFJUTSB1c2VyJ3MgYWNjb3VudCwgbWF4IGxlbmd0aCBpcyAyNTUgQnl0ZXMuXG4gICAgICogQHBhcmFtIHsqfSBydG1Ub2tlbkV4cGlyZTogcmVwcmVzZW50ZWQgYnkgdGhlIG51bWJlciBvZiBzZWNvbmRzIGVsYXBzZWQgc2luY2Ugbm93LiBJZiwgZm9yIGV4YW1wbGUsXG4gICAgICogeW91IHdhbnQgdG8gYWNjZXNzIHRoZSBBZ29yYSBTZXJ2aWNlIHdpdGhpbiAxMCBtaW51dGVzIGFmdGVyIHRoZSB0b2tlbiBpcyBnZW5lcmF0ZWQsIHNldCBydG1Ub2tlbkV4cGlyZVxuICAgICAqIGFzIDYwMChzZWNvbmRzKS4gVGhpcyB2YWx1ZSBtdXN0IG5vdCBleGNlZWQgdGhlIFJUQyB0b2tlbiBleHBpcmF0aW9uIHZhbHVlOyBvdGhlcndpc2UsIHRoZSBSVE0gbG9naW5cbiAgICAgKiBwcml2aWxlZ2UgaXMgbGltaXRlZCBieSB0aGUgdG9rZW4gZXhwaXJhdGlvbiB0aW1lLlxuICAgICAqICogQHJldHVybiBUaGUgUlRDIGFuZCBSVE0gVG9rZW4uXG4gICAgICovXG4gICAgc3RhdGljIGJ1aWxkVG9rZW5XaXRoUnRtMihcbiAgICAgICAgYXBwSWQsXG4gICAgICAgIGFwcENlcnRpZmljYXRlLFxuICAgICAgICBjaGFubmVsTmFtZSxcbiAgICAgICAgcnRjQWNjb3VudCxcbiAgICAgICAgcnRjUm9sZSxcbiAgICAgICAgcnRjVG9rZW5FeHBpcmUsXG4gICAgICAgIGpvaW5DaGFubmVsUHJpdmlsZWdlRXhwaXJlLFxuICAgICAgICBwdWJBdWRpb1ByaXZpbGVnZUV4cGlyZSxcbiAgICAgICAgcHViVmlkZW9Qcml2aWxlZ2VFeHBpcmUsXG4gICAgICAgIHB1YkRhdGFTdHJlYW1Qcml2aWxlZ2VFeHBpcmUsXG4gICAgICAgIHJ0bVVzZXJJZCxcbiAgICAgICAgcnRtVG9rZW5FeHBpcmVcbiAgICApIHtcbiAgICAgICAgbGV0IHRva2VuID0gbmV3IEFjY2Vzc1Rva2VuKGFwcElkLCBhcHBDZXJ0aWZpY2F0ZSwgMCwgcnRjVG9rZW5FeHBpcmUpXG5cbiAgICAgICAgbGV0IHNlcnZpY2VSdGMgPSBuZXcgU2VydmljZVJ0YyhjaGFubmVsTmFtZSwgcnRjQWNjb3VudClcbiAgICAgICAgc2VydmljZVJ0Yy5hZGRfcHJpdmlsZWdlKFNlcnZpY2VSdGMua1ByaXZpbGVnZUpvaW5DaGFubmVsLCBqb2luQ2hhbm5lbFByaXZpbGVnZUV4cGlyZSlcbiAgICAgICAgaWYgKHJ0Y1JvbGUgPT0gUm9sZS5QVUJMSVNIRVIpIHtcbiAgICAgICAgICAgIHNlcnZpY2VSdGMuYWRkX3ByaXZpbGVnZShTZXJ2aWNlUnRjLmtQcml2aWxlZ2VQdWJsaXNoQXVkaW9TdHJlYW0sIHB1YkF1ZGlvUHJpdmlsZWdlRXhwaXJlKVxuICAgICAgICAgICAgc2VydmljZVJ0Yy5hZGRfcHJpdmlsZWdlKFNlcnZpY2VSdGMua1ByaXZpbGVnZVB1Ymxpc2hWaWRlb1N0cmVhbSwgcHViVmlkZW9Qcml2aWxlZ2VFeHBpcmUpXG4gICAgICAgICAgICBzZXJ2aWNlUnRjLmFkZF9wcml2aWxlZ2UoU2VydmljZVJ0Yy5rUHJpdmlsZWdlUHVibGlzaERhdGFTdHJlYW0sIHB1YkRhdGFTdHJlYW1Qcml2aWxlZ2VFeHBpcmUpXG4gICAgICAgIH1cbiAgICAgICAgdG9rZW4uYWRkX3NlcnZpY2Uoc2VydmljZVJ0YylcblxuICAgICAgICBsZXQgc2VydmljZVJ0bSA9IG5ldyBTZXJ2aWNlUnRtKHJ0bVVzZXJJZClcbiAgICAgICAgc2VydmljZVJ0bS5hZGRfcHJpdmlsZWdlKFNlcnZpY2VSdG0ua1ByaXZpbGVnZUxvZ2luLCBydG1Ub2tlbkV4cGlyZSlcbiAgICAgICAgdG9rZW4uYWRkX3NlcnZpY2Uoc2VydmljZVJ0bSlcblxuICAgICAgICByZXR1cm4gdG9rZW4uYnVpbGQoKVxuICAgIH1cbn1cblxubW9kdWxlLmV4cG9ydHMuUnRjVG9rZW5CdWlsZGVyID0gUnRjVG9rZW5CdWlsZGVyXG5tb2R1bGUuZXhwb3J0cy5Sb2xlID0gUm9sZVxuIiwiY29uc3QgQWNjZXNzVG9rZW4gPSByZXF1aXJlKCcuLi9zcmMvQWNjZXNzVG9rZW4yJykuQWNjZXNzVG9rZW4yXG5jb25zdCBTZXJ2aWNlQ29udm9BSSA9IHJlcXVpcmUoJy4uL3NyYy9BY2Nlc3NUb2tlbjInKS5TZXJ2aWNlQ29udm9BSVxuY29uc3QgU2VydmljZVJ0YyA9IHJlcXVpcmUoJy4uL3NyYy9BY2Nlc3NUb2tlbjInKS5TZXJ2aWNlUnRjXG5jb25zdCBTZXJ2aWNlUnRtID0gcmVxdWlyZSgnLi4vc3JjL0FjY2Vzc1Rva2VuMicpLlNlcnZpY2VSdG1cbmNvbnN0IFJvbGUgPSByZXF1aXJlKCcuLi9zcmMvUnRjVG9rZW5CdWlsZGVyMicpLlJvbGVcblxuY2xhc3MgQ29udm9BSVRva2VuQnVpbGRlciB7XG4gICAgLyoqXG4gICAgICogQnVpbGRzIGEgVG9rZW4wMDcgdGhhdCBjYXJyaWVzIFJUQywgUlRNLCBhbmQgQ29udm9BSSBzZXJ2aWNlcy5cbiAgICAgKiBAcGFyYW0geyp9IGFwcElkIFRoZSBBcHAgSUQgaXNzdWVkIHRvIHlvdSBieSBBZ29yYS5cbiAgICAgKiBAcGFyYW0geyp9IGFwcENlcnRpZmljYXRlIENlcnRpZmljYXRlIG9mIHRoZSBhcHBsaWNhdGlvbiB0aGF0IHlvdSByZWdpc3RlcmVkIGluIHRoZSBBZ29yYSBEYXNoYm9hcmQuXG4gICAgICogQHBhcmFtIHsqfSBjaGFubmVsTmFtZSBUaGUgdW5pcXVlIGNoYW5uZWwgbmFtZSBmb3IgdGhlIEFnb3JhUlRDIHNlc3Npb24gaW4gdGhlIHN0cmluZyBmb3JtYXQuXG4gICAgICogQHBhcmFtIHsqfSBydGNBY2NvdW50IFRoZSBSVEMgdXNlcidzIGFjY291bnQsIG1heCBsZW5ndGggaXMgMjU1IGJ5dGVzLlxuICAgICAqIEBwYXJhbSB7Kn0gcnRjUm9sZSBSb2xlLlBVQkxJU0hFUiBmb3IgYSBicm9hZGNhc3RlciBvciBSb2xlLlNVQlNDUklCRVIgZm9yIGFuIGF1ZGllbmNlIG1lbWJlci5cbiAgICAgKiBAcGFyYW0geyp9IHJ0Y1Rva2VuRXhwaXJlIFJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy4gVGhpcyBpcyB0aGUgd2hvbGVcbiAgICAgKiB0b2tlbiBleHBpcmF0aW9uLiBUaGUgd2hvbGUgdG9rZW4gaXMgaW52YWxpZCBhZnRlciB0aGlzIHRpbWUsIGV2ZW4gaWYgYSBwcml2aWxlZ2UgZXhwaXJhdGlvbiB0aW1lIGlzXG4gICAgICogbGF0ZXIuXG4gICAgICogQHBhcmFtIHsqfSBqb2luQ2hhbm5lbFByaXZpbGVnZUV4cGlyZSBSZXByZXNlbnRlZCBieSB0aGUgbnVtYmVyIG9mIHNlY29uZHMgZWxhcHNlZCBzaW5jZSBub3cuIFRoaXNcbiAgICAgKiB2YWx1ZSBtdXN0IG5vdCBleGNlZWQgcnRjVG9rZW5FeHBpcmU7IG90aGVyd2lzZSwgdGhlIHByaXZpbGVnZSBpcyBsaW1pdGVkIGJ5IHRoZSB0b2tlbiBleHBpcmF0aW9uIHRpbWUuXG4gICAgICogQHBhcmFtIHsqfSBwdWJBdWRpb1ByaXZpbGVnZUV4cGlyZSBSZXByZXNlbnRlZCBieSB0aGUgbnVtYmVyIG9mIHNlY29uZHMgZWxhcHNlZCBzaW5jZSBub3cuIFRoaXMgdmFsdWVcbiAgICAgKiBtdXN0IG5vdCBleGNlZWQgcnRjVG9rZW5FeHBpcmU7IG90aGVyd2lzZSwgdGhlIHByaXZpbGVnZSBpcyBsaW1pdGVkIGJ5IHRoZSB0b2tlbiBleHBpcmF0aW9uIHRpbWUuXG4gICAgICogQHBhcmFtIHsqfSBwdWJWaWRlb1ByaXZpbGVnZUV4cGlyZSBSZXByZXNlbnRlZCBieSB0aGUgbnVtYmVyIG9mIHNlY29uZHMgZWxhcHNlZCBzaW5jZSBub3cuIFRoaXMgdmFsdWVcbiAgICAgKiBtdXN0IG5vdCBleGNlZWQgcnRjVG9rZW5FeHBpcmU7IG90aGVyd2lzZSwgdGhlIHByaXZpbGVnZSBpcyBsaW1pdGVkIGJ5IHRoZSB0b2tlbiBleHBpcmF0aW9uIHRpbWUuXG4gICAgICogQHBhcmFtIHsqfSBwdWJEYXRhU3RyZWFtUHJpdmlsZWdlRXhwaXJlIFJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy4gVGhpc1xuICAgICAqIHZhbHVlIG11c3Qgbm90IGV4Y2VlZCBydGNUb2tlbkV4cGlyZTsgb3RoZXJ3aXNlLCB0aGUgcHJpdmlsZWdlIGlzIGxpbWl0ZWQgYnkgdGhlIHRva2VuIGV4cGlyYXRpb24gdGltZS5cbiAgICAgKiBAcGFyYW0geyp9IHJ0bVVzZXJJZCBUaGUgUlRNIHVzZXIncyBhY2NvdW50LCBtYXggbGVuZ3RoIGlzIDI1NSBieXRlcy5cbiAgICAgKiBAcGFyYW0geyp9IHJ0bVRva2VuRXhwaXJlIFJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy4gVGhpcyB2YWx1ZSBtdXN0IG5vdFxuICAgICAqIGV4Y2VlZCBydGNUb2tlbkV4cGlyZTsgb3RoZXJ3aXNlLCB0aGUgUlRNIGxvZ2luIHByaXZpbGVnZSBpcyBsaW1pdGVkIGJ5IHRoZSB0b2tlbiBleHBpcmF0aW9uIHRpbWUuXG4gICAgICogQHJldHVybiBUaGUgUlRDLCBSVE0sIGFuZCBDb252b0FJIHRva2VuLlxuICAgICAqL1xuICAgIHN0YXRpYyBidWlsZFRva2VuKFxuICAgICAgICBhcHBJZCxcbiAgICAgICAgYXBwQ2VydGlmaWNhdGUsXG4gICAgICAgIGNoYW5uZWxOYW1lLFxuICAgICAgICBydGNBY2NvdW50LFxuICAgICAgICBydGNSb2xlLFxuICAgICAgICBydGNUb2tlbkV4cGlyZSxcbiAgICAgICAgam9pbkNoYW5uZWxQcml2aWxlZ2VFeHBpcmUsXG4gICAgICAgIHB1YkF1ZGlvUHJpdmlsZWdlRXhwaXJlLFxuICAgICAgICBwdWJWaWRlb1ByaXZpbGVnZUV4cGlyZSxcbiAgICAgICAgcHViRGF0YVN0cmVhbVByaXZpbGVnZUV4cGlyZSxcbiAgICAgICAgcnRtVXNlcklkLFxuICAgICAgICBydG1Ub2tlbkV4cGlyZVxuICAgICkge1xuICAgICAgICBjb25zdCB0b2tlbiA9IG5ldyBBY2Nlc3NUb2tlbihhcHBJZCwgYXBwQ2VydGlmaWNhdGUsIDAsIHJ0Y1Rva2VuRXhwaXJlKVxuXG4gICAgICAgIGNvbnN0IHNlcnZpY2VSdGMgPSBuZXcgU2VydmljZVJ0YyhjaGFubmVsTmFtZSwgcnRjQWNjb3VudClcbiAgICAgICAgc2VydmljZVJ0Yy5hZGRfcHJpdmlsZWdlKFNlcnZpY2VSdGMua1ByaXZpbGVnZUpvaW5DaGFubmVsLCBqb2luQ2hhbm5lbFByaXZpbGVnZUV4cGlyZSlcbiAgICAgICAgaWYgKHJ0Y1JvbGUgPT09IFJvbGUuUFVCTElTSEVSKSB7XG4gICAgICAgICAgICBzZXJ2aWNlUnRjLmFkZF9wcml2aWxlZ2UoU2VydmljZVJ0Yy5rUHJpdmlsZWdlUHVibGlzaEF1ZGlvU3RyZWFtLCBwdWJBdWRpb1ByaXZpbGVnZUV4cGlyZSlcbiAgICAgICAgICAgIHNlcnZpY2VSdGMuYWRkX3ByaXZpbGVnZShTZXJ2aWNlUnRjLmtQcml2aWxlZ2VQdWJsaXNoVmlkZW9TdHJlYW0sIHB1YlZpZGVvUHJpdmlsZWdlRXhwaXJlKVxuICAgICAgICAgICAgc2VydmljZVJ0Yy5hZGRfcHJpdmlsZWdlKFNlcnZpY2VSdGMua1ByaXZpbGVnZVB1Ymxpc2hEYXRhU3RyZWFtLCBwdWJEYXRhU3RyZWFtUHJpdmlsZWdlRXhwaXJlKVxuICAgICAgICB9XG4gICAgICAgIHRva2VuLmFkZF9zZXJ2aWNlKHNlcnZpY2VSdGMpXG5cbiAgICAgICAgY29uc3Qgc2VydmljZVJ0bSA9IG5ldyBTZXJ2aWNlUnRtKHJ0bVVzZXJJZClcbiAgICAgICAgc2VydmljZVJ0bS5hZGRfcHJpdmlsZWdlKFNlcnZpY2VSdG0ua1ByaXZpbGVnZUxvZ2luLCBydG1Ub2tlbkV4cGlyZSlcbiAgICAgICAgdG9rZW4uYWRkX3NlcnZpY2Uoc2VydmljZVJ0bSlcblxuICAgICAgICB0b2tlbi5hZGRfc2VydmljZShuZXcgU2VydmljZUNvbnZvQUkoKSlcblxuICAgICAgICByZXR1cm4gdG9rZW4uYnVpbGQoKVxuICAgIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gICAgQ29udm9BSVRva2VuQnVpbGRlclxufVxuIiwiY29uc3QgbWQ1ID0gcmVxdWlyZSgnbWQ1JylcblxuY29uc3QgQWNjZXNzVG9rZW4gPSByZXF1aXJlKCcuLi9zcmMvQWNjZXNzVG9rZW4yJykuQWNjZXNzVG9rZW4yXG5jb25zdCBTZXJ2aWNlQXBhYXMgPSByZXF1aXJlKCcuLi9zcmMvQWNjZXNzVG9rZW4yJykuU2VydmljZUFwYWFzXG5jb25zdCBTZXJ2aWNlQ2hhdCA9IHJlcXVpcmUoJy4uL3NyYy9BY2Nlc3NUb2tlbjInKS5TZXJ2aWNlQ2hhdFxuY29uc3QgU2VydmljZVJ0bSA9IHJlcXVpcmUoJy4uL3NyYy9BY2Nlc3NUb2tlbjInKS5TZXJ2aWNlUnRtXG5cbmNsYXNzIEVkdWNhdGlvblRva2VuQnVpbGRlciB7XG4gICAgLyoqXG4gICAgICogYnVpbGQgdXNlciByb29tIHRva2VuXG4gICAgICogQHBhcmFtIGFwcElkICAgICAgICAgICAgIFRoZSBBcHAgSUQgaXNzdWVkIHRvIHlvdSBieSBBZ29yYS4gQXBwbHkgZm9yIGEgbmV3IEFwcCBJRCBmcm9tXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgIEFnb3JhIERhc2hib2FyZCBpZiBpdCBpcyBtaXNzaW5nIGZyb20geW91ciBraXQuIFNlZSBHZXQgYW4gQXBwIElELlxuICAgICAqIEBwYXJhbSBhcHBDZXJ0aWZpY2F0ZSAgICBDZXJ0aWZpY2F0ZSBvZiB0aGUgYXBwbGljYXRpb24gdGhhdCB5b3UgcmVnaXN0ZXJlZCBpblxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICB0aGUgQWdvcmEgRGFzaGJvYXJkLiBTZWUgR2V0IGFuIEFwcCBDZXJ0aWZpY2F0ZS5cbiAgICAgKiBAcGFyYW0gcm9vbVV1aWQgICAgICAgICAgVGhlIHJvb20ncyBpZCwgbXVzdCBiZSB1bmlxdWUuXG4gICAgICogQHBhcmFtIHVzZXJVdWlkICAgICAgICAgIFRoZSB1c2VyJ3MgaWQsIG11c3QgYmUgdW5pcXVlLlxuICAgICAqIEBwYXJhbSByb2xlICAgICAgICAgICAgICBUaGUgdXNlcidzIHJvbGUuXG4gICAgICogQHBhcmFtIGV4cGlyZSAgICAgICAgICAgIHJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy4gSWYsIGZvciBleGFtcGxlLCB5b3Ugd2FudCB0byBhY2Nlc3MgdGhlXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgIEFnb3JhIFNlcnZpY2Ugd2l0aGluIDEwIG1pbnV0ZXMgYWZ0ZXIgdGhlIHRva2VuIGlzIGdlbmVyYXRlZCwgc2V0IGV4cGlyZSBhc1xuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICA2MDAoc2Vjb25kcykuIFRoaXMgdmFsdWUgaXMgdGhlIHdob2xlIHRva2VuIGV4cGlyYXRpb24gYW5kIHRoZSBzZXJ2aWNlXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgIHByaXZpbGVnZSBleHBpcmF0aW9uLiBUaGUgd2hvbGUgdG9rZW4gaXMgaW52YWxpZCBhZnRlciB0aGlzIHRpbWUuXG4gICAgICogQHJldHVybiBUaGUgdXNlciByb29tIHRva2VuLlxuICAgICAqL1xuICAgIHN0YXRpYyBidWlsZFJvb21Vc2VyVG9rZW4oYXBwSWQsIGFwcENlcnRpZmljYXRlLCByb29tVXVpZCwgdXNlclV1aWQsIHJvbGUsIGV4cGlyZSkge1xuICAgICAgICBsZXQgYWNjZXNzVG9rZW4gPSBuZXcgQWNjZXNzVG9rZW4oYXBwSWQsIGFwcENlcnRpZmljYXRlLCAwLCBleHBpcmUpXG5cbiAgICAgICAgbGV0IGNoYXRVc2VySWQgPSBtZDUodXNlclV1aWQpXG4gICAgICAgIGxldCBhcGFhc1NlcnZpY2UgPSBuZXcgU2VydmljZUFwYWFzKHJvb21VdWlkLCB1c2VyVXVpZCwgcm9sZSlcbiAgICAgICAgYWNjZXNzVG9rZW4uYWRkX3NlcnZpY2UoYXBhYXNTZXJ2aWNlKVxuXG4gICAgICAgIGxldCBydG1TZXJ2aWNlID0gbmV3IFNlcnZpY2VSdG0odXNlclV1aWQpXG4gICAgICAgIHJ0bVNlcnZpY2UuYWRkX3ByaXZpbGVnZShTZXJ2aWNlUnRtLmtQcml2aWxlZ2VMb2dpbiwgZXhwaXJlKVxuICAgICAgICBhY2Nlc3NUb2tlbi5hZGRfc2VydmljZShydG1TZXJ2aWNlKVxuXG4gICAgICAgIGxldCBjaGF0U2VydmljZSA9IG5ldyBTZXJ2aWNlQ2hhdChjaGF0VXNlcklkKVxuICAgICAgICBjaGF0U2VydmljZS5hZGRfcHJpdmlsZWdlKFNlcnZpY2VDaGF0LmtQcml2aWxlZ2VVc2VyLCBleHBpcmUpXG4gICAgICAgIGFjY2Vzc1Rva2VuLmFkZF9zZXJ2aWNlKGNoYXRTZXJ2aWNlKVxuXG4gICAgICAgIHJldHVybiBhY2Nlc3NUb2tlbi5idWlsZCgpXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogYnVpbGQgdXNlciB0b2tlblxuICAgICAqIEBwYXJhbSBhcHBJZCAgICAgICAgICAgICBUaGUgQXBwIElEIGlzc3VlZCB0byB5b3UgYnkgQWdvcmEuIEFwcGx5IGZvciBhIG5ldyBBcHAgSUQgZnJvbVxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICBBZ29yYSBEYXNoYm9hcmQgaWYgaXQgaXMgbWlzc2luZyBmcm9tIHlvdXIga2l0LiBTZWUgR2V0IGFuIEFwcCBJRC5cbiAgICAgKiBAcGFyYW0gYXBwQ2VydGlmaWNhdGUgICAgQ2VydGlmaWNhdGUgb2YgdGhlIGFwcGxpY2F0aW9uIHRoYXQgeW91IHJlZ2lzdGVyZWQgaW5cbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgdGhlIEFnb3JhIERhc2hib2FyZC4gU2VlIEdldCBhbiBBcHAgQ2VydGlmaWNhdGUuXG4gICAgICogQHBhcmFtIHVzZXJVdWlkICAgICAgICAgIFRoZSB1c2VyJ3MgaWQsIG11c3QgYmUgdW5pcXVlLlxuICAgICAqIEBwYXJhbSBleHBpcmUgICAgICAgICAgICByZXByZXNlbnRlZCBieSB0aGUgbnVtYmVyIG9mIHNlY29uZHMgZWxhcHNlZCBzaW5jZSBub3cuIElmLCBmb3IgZXhhbXBsZSwgeW91IHdhbnQgdG8gYWNjZXNzIHRoZVxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICBBZ29yYSBTZXJ2aWNlIHdpdGhpbiAxMCBtaW51dGVzIGFmdGVyIHRoZSB0b2tlbiBpcyBnZW5lcmF0ZWQsIHNldCBleHBpcmUgYXNcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgNjAwKHNlY29uZHMpLiBUaGlzIHZhbHVlIGlzIHRoZSB3aG9sZSB0b2tlbiBleHBpcmF0aW9uIGFuZCB0aGUgc2VydmljZVxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICBwcml2aWxlZ2UgZXhwaXJhdGlvbi4gVGhlIHdob2xlIHRva2VuIGlzIGludmFsaWQgYWZ0ZXIgdGhpcyB0aW1lLlxuICAgICAqIEByZXR1cm4gVGhlIHVzZXIgdG9rZW4uXG4gICAgICovXG4gICAgc3RhdGljIGJ1aWxkVXNlclRva2VuKGFwcElkLCBhcHBDZXJ0aWZpY2F0ZSwgdXNlclV1aWQsIGV4cGlyZSkge1xuICAgICAgICBsZXQgYWNjZXNzVG9rZW4gPSBuZXcgQWNjZXNzVG9rZW4oYXBwSWQsIGFwcENlcnRpZmljYXRlLCAwLCBleHBpcmUpXG4gICAgICAgIGxldCBhcGFhc1NlcnZpY2UgPSBuZXcgU2VydmljZUFwYWFzKCcnLCB1c2VyVXVpZClcbiAgICAgICAgYXBhYXNTZXJ2aWNlLmFkZF9wcml2aWxlZ2UoU2VydmljZUFwYWFzLlBSSVZJTEVHRV9VU0VSLCBleHBpcmUpXG4gICAgICAgIGFjY2Vzc1Rva2VuLmFkZF9zZXJ2aWNlKGFwYWFzU2VydmljZSlcblxuICAgICAgICByZXR1cm4gYWNjZXNzVG9rZW4uYnVpbGQoKVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGJ1aWxkIGFwcCB0b2tlblxuICAgICAqIEBwYXJhbSBhcHBJZCAgICAgICAgICBUaGUgQXBwIElEIGlzc3VlZCB0byB5b3UgYnkgQWdvcmEuIEFwcGx5IGZvciBhIG5ldyBBcHAgSUQgZnJvbVxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICBBZ29yYSBEYXNoYm9hcmQgaWYgaXQgaXMgbWlzc2luZyBmcm9tIHlvdXIga2l0LiBTZWUgR2V0IGFuIEFwcCBJRC5cbiAgICAgKiBAcGFyYW0gYXBwQ2VydGlmaWNhdGUgQ2VydGlmaWNhdGUgb2YgdGhlIGFwcGxpY2F0aW9uIHRoYXQgeW91IHJlZ2lzdGVyZWQgaW5cbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgdGhlIEFnb3JhIERhc2hib2FyZC4gU2VlIEdldCBhbiBBcHAgQ2VydGlmaWNhdGUuXG4gICAgICogQHBhcmFtIGV4cGlyZSAgICAgICAgIHJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy4gSWYsIGZvciBleGFtcGxlLCB5b3Ugd2FudCB0byBhY2Nlc3MgdGhlXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgIEFnb3JhIFNlcnZpY2Ugd2l0aGluIDEwIG1pbnV0ZXMgYWZ0ZXIgdGhlIHRva2VuIGlzIGdlbmVyYXRlZCwgc2V0IGV4cGlyZSBhc1xuICAgICAqICAgICAgICAgICAgICAgICAgICAgICA2MDAoc2Vjb25kcykuIFRoaXMgdmFsdWUgaXMgdGhlIHdob2xlIHRva2VuIGV4cGlyYXRpb24gYW5kIHRoZSBzZXJ2aWNlIHByaXZpbGVnZVxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICBleHBpcmF0aW9uLiBUaGUgd2hvbGUgdG9rZW4gaXMgaW52YWxpZCBhZnRlciB0aGlzIHRpbWUuXG4gICAgICogQHJldHVybiBUaGUgYXBwIHRva2VuLlxuICAgICAqL1xuICAgIHN0YXRpYyBidWlsZEFwcFRva2VuKGFwcElkLCBhcHBDZXJ0aWZpY2F0ZSwgZXhwaXJlKSB7XG4gICAgICAgIGxldCBhY2Nlc3NUb2tlbiA9IG5ldyBBY2Nlc3NUb2tlbihhcHBJZCwgYXBwQ2VydGlmaWNhdGUsIDAsIGV4cGlyZSlcbiAgICAgICAgbGV0IGFwYWFzU2VydmljZSA9IG5ldyBTZXJ2aWNlQXBhYXMoKVxuICAgICAgICBhcGFhc1NlcnZpY2UuYWRkX3ByaXZpbGVnZShTZXJ2aWNlQXBhYXMuUFJJVklMRUdFX0FQUCwgZXhwaXJlKVxuICAgICAgICBhY2Nlc3NUb2tlbi5hZGRfc2VydmljZShhcGFhc1NlcnZpY2UpXG5cbiAgICAgICAgcmV0dXJuIGFjY2Vzc1Rva2VuLmJ1aWxkKClcbiAgICB9XG59XG5cbm1vZHVsZS5leHBvcnRzLkVkdWNhdGlvblRva2VuQnVpbGRlciA9IEVkdWNhdGlvblRva2VuQnVpbGRlclxuIiwiY29uc3QgQWNjZXNzVG9rZW4gPSByZXF1aXJlKCcuLi9zcmMvQWNjZXNzVG9rZW4yJykuQWNjZXNzVG9rZW4yXG5jb25zdCBTZXJ2aWNlRnBhID0gcmVxdWlyZSgnLi4vc3JjL0FjY2Vzc1Rva2VuMicpLlNlcnZpY2VGcGFcblxuY2xhc3MgRnBhVG9rZW5CdWlsZGVyIHtcbiAgICAvKipcbiAgICAgKiBCdWlsZCB0aGUgRlBBIHRva2VuLlxuICAgICAqIEBwYXJhbSBhcHBJZCBUaGUgQXBwIElEIGlzc3VlZCB0byB5b3UgYnkgQWdvcmEuIEFwcGx5IGZvciBhIG5ldyBBcHAgSUQgZnJvbVxuICAgICAqIEFnb3JhIERhc2hib2FyZCBpZiBpdCBpcyBtaXNzaW5nIGZyb20geW91ciBraXQuIFNlZSBHZXQgYW4gQXBwIElELlxuICAgICAqIEBwYXJhbSBhcHBDZXJ0aWZpY2F0ZSBDZXJ0aWZpY2F0ZSBvZiB0aGUgYXBwbGljYXRpb24gdGhhdCB5b3UgcmVnaXN0ZXJlZCBpblxuICAgICAqIHRoZSBBZ29yYSBEYXNoYm9hcmQuIFNlZSBHZXQgYW4gQXBwIENlcnRpZmljYXRlLlxuICAgICAqIEByZXR1cm4gVGhlIEZQQSB0b2tlbi4gVGhlIHRva2VuIGV4cGlyZXMgMjQgaG91cnMgYWZ0ZXIgZ2VuZXJhdGlvbi5cbiAgICAgKi9cbiAgICBzdGF0aWMgYnVpbGRUb2tlbihhcHBJZCwgYXBwQ2VydGlmaWNhdGUpIHtcbiAgICAgICAgbGV0IHRva2VuID0gbmV3IEFjY2Vzc1Rva2VuKGFwcElkLCBhcHBDZXJ0aWZpY2F0ZSwgMCwgMjQgKiAzNjAwKVxuXG4gICAgICAgIGxldCBzZXJ2aWNlRnBhID0gbmV3IFNlcnZpY2VGcGEoKVxuICAgICAgICBzZXJ2aWNlRnBhLmFkZF9wcml2aWxlZ2UoU2VydmljZUZwYS5rUHJpdmlsZWdlTG9naW4sIDApXG4gICAgICAgIHRva2VuLmFkZF9zZXJ2aWNlKHNlcnZpY2VGcGEpXG5cbiAgICAgICAgcmV0dXJuIHRva2VuLmJ1aWxkKClcbiAgICB9XG59XG5cbm1vZHVsZS5leHBvcnRzLkZwYVRva2VuQnVpbGRlciA9IEZwYVRva2VuQnVpbGRlclxuIiwiY29uc3QgQWNjZXNzVG9rZW4gPSByZXF1aXJlKCcuLi9zcmMvQWNjZXNzVG9rZW4yJykuQWNjZXNzVG9rZW4yXG5jb25zdCBTZXJ2aWNlUnRtID0gcmVxdWlyZSgnLi4vc3JjL0FjY2Vzc1Rva2VuMicpLlNlcnZpY2VSdG1cbmNvbnN0IFNlcnZpY2VSdG0yID0gcmVxdWlyZSgnLi4vc3JjL0FjY2Vzc1Rva2VuMicpLlNlcnZpY2VSdG0yXG5cbmNsYXNzIFJ0bVRva2VuQnVpbGRlciB7XG4gICAgLyoqXG4gICAgICogQnVpbGQgdGhlIFJUTSB0b2tlbi5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBhcHBJZCBUaGUgQXBwIElEIGlzc3VlZCB0byB5b3UgYnkgQWdvcmEuIEFwcGx5IGZvciBhIG5ldyBBcHAgSUQgZnJvbVxuICAgICAqIEFnb3JhIERhc2hib2FyZCBpZiBpdCBpcyBtaXNzaW5nIGZyb20geW91ciBraXQuIFNlZSBHZXQgYW4gQXBwIElELlxuICAgICAqIEBwYXJhbSBhcHBDZXJ0aWZpY2F0ZSBDZXJ0aWZpY2F0ZSBvZiB0aGUgYXBwbGljYXRpb24gdGhhdCB5b3UgcmVnaXN0ZXJlZCBpblxuICAgICAqIHRoZSBBZ29yYSBEYXNoYm9hcmQuIFNlZSBHZXQgYW4gQXBwIENlcnRpZmljYXRlLlxuICAgICAqIEBwYXJhbSB1c2VySWQgVGhlIHVzZXIncyBhY2NvdW50LCBtYXggbGVuZ3RoIGlzIDY0IEJ5dGVzLlxuICAgICAqIEBwYXJhbSBleHBpcmUgcmVwcmVzZW50ZWQgYnkgdGhlIG51bWJlciBvZiBzZWNvbmRzIGVsYXBzZWQgc2luY2Ugbm93LiBJZiwgZm9yIGV4YW1wbGUsIHlvdSB3YW50IHRvIGFjY2VzcyB0aGVcbiAgICAgKiBBZ29yYSBTZXJ2aWNlIHdpdGhpbiAxMCBtaW51dGVzIGFmdGVyIHRoZSB0b2tlbiBpcyBnZW5lcmF0ZWQsIHNldCBleHBpcmUgYXMgNjAwKHNlY29uZHMpLiBUaGlzIHZhbHVlIGlzXG4gICAgICogdGhlIHdob2xlIHRva2VuIGV4cGlyYXRpb24gYW5kIHRoZSBzZXJ2aWNlIHByaXZpbGVnZSBleHBpcmF0aW9uLiBUaGUgd2hvbGUgdG9rZW4gaXMgaW52YWxpZCBhZnRlciB0aGlzXG4gICAgICogdGltZS5cbiAgICAgKiBAcmV0dXJuIFRoZSBSVE0gdG9rZW4uXG4gICAgICovXG4gICAgc3RhdGljIGJ1aWxkVG9rZW4oYXBwSWQsIGFwcENlcnRpZmljYXRlLCB1c2VySWQsIGV4cGlyZSkge1xuICAgICAgICBsZXQgdG9rZW4gPSBuZXcgQWNjZXNzVG9rZW4oYXBwSWQsIGFwcENlcnRpZmljYXRlLCBudWxsLCBleHBpcmUpXG5cbiAgICAgICAgbGV0IHNlcnZpY2VSdG0gPSBuZXcgU2VydmljZVJ0bSh1c2VySWQpXG4gICAgICAgIHNlcnZpY2VSdG0uYWRkX3ByaXZpbGVnZShTZXJ2aWNlUnRtLmtQcml2aWxlZ2VMb2dpbiwgZXhwaXJlKVxuICAgICAgICB0b2tlbi5hZGRfc2VydmljZShzZXJ2aWNlUnRtKVxuXG4gICAgICAgIHJldHVybiB0b2tlbi5idWlsZCgpXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQnVpbGQgYW4gUlRNMiB0b2tlbiB3aXRoIHJlc291cmNlLWxldmVsIHBlcm1pc3Npb25zLlxuICAgICAqXG4gICAgICogVGhpcyBzcGVjaWFsIGludGVyZmFjZSByZXF1aXJlcyBBZ29yYSBhc3Npc3RhbmNlIGZvciBwcm9wZXIgdXNhZ2UuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gYXBwSWQgVGhlIEFwcCBJRCBpc3N1ZWQgdG8geW91IGJ5IEFnb3JhLlxuICAgICAqIEBwYXJhbSBhcHBDZXJ0aWZpY2F0ZSBDZXJ0aWZpY2F0ZSBvZiB0aGUgYXBwbGljYXRpb24gcmVnaXN0ZXJlZCBpbiB0aGUgQWdvcmEgRGFzaGJvYXJkLlxuICAgICAqIEBwYXJhbSB1c2VySWQgVGhlIHVzZXIncyBhY2NvdW50LCBtYXggbGVuZ3RoIGlzIDY0IGJ5dGVzLlxuICAgICAqIEBwYXJhbSBwZXJtaXNzaW9ucyBUaGUgUlRNMiByZXNvdXJjZS1sZXZlbCBwZXJtaXNzaW9ucy5cbiAgICAgKiBAcGFyYW0gZXhwaXJlIFRoZSBudW1iZXIgb2Ygc2Vjb25kcyBmcm9tIG5vdyBiZWZvcmUgdGhlIHRva2VuIGV4cGlyZXMuIFRoaXMgdmFsdWUgaXMgdGhlIHdob2xlIHRva2VuXG4gICAgICogZXhwaXJhdGlvbiBhbmQgdGhlIHNlcnZpY2UgcHJpdmlsZWdlIGV4cGlyYXRpb24uIFRoZSB3aG9sZSB0b2tlbiBpcyBpbnZhbGlkIGFmdGVyIHRoaXMgdGltZS5cbiAgICAgKiBAcmV0dXJuIFRoZSBSVE0yIHRva2VuLlxuICAgICAqL1xuICAgIHN0YXRpYyBidWlsZFRva2VuV2l0aFBlcm1pc3Npb25zKGFwcElkLCBhcHBDZXJ0aWZpY2F0ZSwgdXNlcklkLCBwZXJtaXNzaW9ucywgZXhwaXJlKSB7XG4gICAgICAgIGNvbnN0IHRva2VuID0gbmV3IEFjY2Vzc1Rva2VuKGFwcElkLCBhcHBDZXJ0aWZpY2F0ZSwgbnVsbCwgZXhwaXJlKVxuICAgICAgICBjb25zdCBzZXJ2aWNlUnRtMiA9IG5ldyBTZXJ2aWNlUnRtMih1c2VySWQsIHBlcm1pc3Npb25zKVxuICAgICAgICBzZXJ2aWNlUnRtMi5hZGRfcHJpdmlsZWdlKFNlcnZpY2VSdG0yLmtQcml2aWxlZ2VMb2dpbiwgZXhwaXJlKVxuICAgICAgICB0b2tlbi5hZGRfc2VydmljZShzZXJ2aWNlUnRtMilcbiAgICAgICAgcmV0dXJuIHRva2VuLmJ1aWxkKClcbiAgICB9XG59XG5cbm1vZHVsZS5leHBvcnRzLlJ0bVRva2VuQnVpbGRlciA9IFJ0bVRva2VuQnVpbGRlclxuIiwiY29uc3QgQWNjZXNzVG9rZW4gPSByZXF1aXJlKCcuLi9zcmMvQWNjZXNzVG9rZW4yJykuQWNjZXNzVG9rZW4yXG5jb25zdCBTZXJ2aWNlUnRjID0gcmVxdWlyZSgnLi4vc3JjL0FjY2Vzc1Rva2VuMicpLlNlcnZpY2VSdGNcbmNvbnN0IFNlcnZpY2VSdG0gPSByZXF1aXJlKCcuLi9zcmMvQWNjZXNzVG9rZW4yJykuU2VydmljZVJ0bVxuY29uc3QgU2VydmljZVN0dCA9IHJlcXVpcmUoJy4uL3NyYy9BY2Nlc3NUb2tlbjInKS5TZXJ2aWNlU3R0XG5jb25zdCBSb2xlID0gcmVxdWlyZSgnLi4vc3JjL1J0Y1Rva2VuQnVpbGRlcjInKS5Sb2xlXG5cbmNsYXNzIFN0dFRva2VuQnVpbGRlciB7XG4gICAgLyoqXG4gICAgICogQnVpbGRzIGEgVG9rZW4wMDcgdGhhdCBjYXJyaWVzIFJUQywgUlRNLCBhbmQgU1RUIHNlcnZpY2VzLlxuICAgICAqIEBwYXJhbSB7Kn0gYXBwSWQgVGhlIEFwcCBJRCBpc3N1ZWQgdG8geW91IGJ5IEFnb3JhLlxuICAgICAqIEBwYXJhbSB7Kn0gYXBwQ2VydGlmaWNhdGUgQ2VydGlmaWNhdGUgb2YgdGhlIGFwcGxpY2F0aW9uIHRoYXQgeW91IHJlZ2lzdGVyZWQgaW4gdGhlIEFnb3JhIERhc2hib2FyZC5cbiAgICAgKiBAcGFyYW0geyp9IGNoYW5uZWxOYW1lIFRoZSB1bmlxdWUgY2hhbm5lbCBuYW1lIGZvciB0aGUgQWdvcmFSVEMgc2Vzc2lvbiBpbiB0aGUgc3RyaW5nIGZvcm1hdC5cbiAgICAgKiBAcGFyYW0geyp9IHJ0Y0FjY291bnQgVGhlIFJUQyB1c2VyJ3MgYWNjb3VudCwgbWF4IGxlbmd0aCBpcyAyNTUgYnl0ZXMuXG4gICAgICogQHBhcmFtIHsqfSBydGNSb2xlIFJvbGUuUFVCTElTSEVSIGZvciBhIGJyb2FkY2FzdGVyIG9yIFJvbGUuU1VCU0NSSUJFUiBmb3IgYW4gYXVkaWVuY2UgbWVtYmVyLlxuICAgICAqIEBwYXJhbSB7Kn0gcnRjVG9rZW5FeHBpcmUgUmVwcmVzZW50ZWQgYnkgdGhlIG51bWJlciBvZiBzZWNvbmRzIGVsYXBzZWQgc2luY2Ugbm93LiBUaGlzIGlzIHRoZSB3aG9sZVxuICAgICAqIHRva2VuIGV4cGlyYXRpb24uIFRoZSB3aG9sZSB0b2tlbiBpcyBpbnZhbGlkIGFmdGVyIHRoaXMgdGltZSwgZXZlbiBpZiBhIHByaXZpbGVnZSBleHBpcmF0aW9uIHRpbWUgaXNcbiAgICAgKiBsYXRlci5cbiAgICAgKiBAcGFyYW0geyp9IGpvaW5DaGFubmVsUHJpdmlsZWdlRXhwaXJlIFJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy4gVGhpc1xuICAgICAqIHZhbHVlIG11c3Qgbm90IGV4Y2VlZCBydGNUb2tlbkV4cGlyZTsgb3RoZXJ3aXNlLCB0aGUgcHJpdmlsZWdlIGlzIGxpbWl0ZWQgYnkgdGhlIHRva2VuIGV4cGlyYXRpb24gdGltZS5cbiAgICAgKiBAcGFyYW0geyp9IHB1YkF1ZGlvUHJpdmlsZWdlRXhwaXJlIFJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy4gVGhpcyB2YWx1ZVxuICAgICAqIG11c3Qgbm90IGV4Y2VlZCBydGNUb2tlbkV4cGlyZTsgb3RoZXJ3aXNlLCB0aGUgcHJpdmlsZWdlIGlzIGxpbWl0ZWQgYnkgdGhlIHRva2VuIGV4cGlyYXRpb24gdGltZS5cbiAgICAgKiBAcGFyYW0geyp9IHB1YlZpZGVvUHJpdmlsZWdlRXhwaXJlIFJlcHJlc2VudGVkIGJ5IHRoZSBudW1iZXIgb2Ygc2Vjb25kcyBlbGFwc2VkIHNpbmNlIG5vdy4gVGhpcyB2YWx1ZVxuICAgICAqIG11c3Qgbm90IGV4Y2VlZCBydGNUb2tlbkV4cGlyZTsgb3RoZXJ3aXNlLCB0aGUgcHJpdmlsZWdlIGlzIGxpbWl0ZWQgYnkgdGhlIHRva2VuIGV4cGlyYXRpb24gdGltZS5cbiAgICAgKiBAcGFyYW0geyp9IHB1YkRhdGFTdHJlYW1Qcml2aWxlZ2VFeHBpcmUgUmVwcmVzZW50ZWQgYnkgdGhlIG51bWJlciBvZiBzZWNvbmRzIGVsYXBzZWQgc2luY2Ugbm93LiBUaGlzXG4gICAgICogdmFsdWUgbXVzdCBub3QgZXhjZWVkIHJ0Y1Rva2VuRXhwaXJlOyBvdGhlcndpc2UsIHRoZSBwcml2aWxlZ2UgaXMgbGltaXRlZCBieSB0aGUgdG9rZW4gZXhwaXJhdGlvbiB0aW1lLlxuICAgICAqIEBwYXJhbSB7Kn0gcnRtVXNlcklkIFRoZSBSVE0gdXNlcidzIGFjY291bnQsIG1heCBsZW5ndGggaXMgMjU1IGJ5dGVzLlxuICAgICAqIEBwYXJhbSB7Kn0gcnRtVG9rZW5FeHBpcmUgUmVwcmVzZW50ZWQgYnkgdGhlIG51bWJlciBvZiBzZWNvbmRzIGVsYXBzZWQgc2luY2Ugbm93LiBUaGlzIHZhbHVlIG11c3Qgbm90XG4gICAgICogZXhjZWVkIHJ0Y1Rva2VuRXhwaXJlOyBvdGhlcndpc2UsIHRoZSBSVE0gbG9naW4gcHJpdmlsZWdlIGlzIGxpbWl0ZWQgYnkgdGhlIHRva2VuIGV4cGlyYXRpb24gdGltZS5cbiAgICAgKiBAcmV0dXJuIFRoZSBSVEMsIFJUTSwgYW5kIFNUVCB0b2tlbi5cbiAgICAgKi9cbiAgICBzdGF0aWMgYnVpbGRUb2tlbihcbiAgICAgICAgYXBwSWQsXG4gICAgICAgIGFwcENlcnRpZmljYXRlLFxuICAgICAgICBjaGFubmVsTmFtZSxcbiAgICAgICAgcnRjQWNjb3VudCxcbiAgICAgICAgcnRjUm9sZSxcbiAgICAgICAgcnRjVG9rZW5FeHBpcmUsXG4gICAgICAgIGpvaW5DaGFubmVsUHJpdmlsZWdlRXhwaXJlLFxuICAgICAgICBwdWJBdWRpb1ByaXZpbGVnZUV4cGlyZSxcbiAgICAgICAgcHViVmlkZW9Qcml2aWxlZ2VFeHBpcmUsXG4gICAgICAgIHB1YkRhdGFTdHJlYW1Qcml2aWxlZ2VFeHBpcmUsXG4gICAgICAgIHJ0bVVzZXJJZCxcbiAgICAgICAgcnRtVG9rZW5FeHBpcmVcbiAgICApIHtcbiAgICAgICAgY29uc3QgdG9rZW4gPSBuZXcgQWNjZXNzVG9rZW4oYXBwSWQsIGFwcENlcnRpZmljYXRlLCAwLCBydGNUb2tlbkV4cGlyZSlcblxuICAgICAgICBjb25zdCBzZXJ2aWNlUnRjID0gbmV3IFNlcnZpY2VSdGMoY2hhbm5lbE5hbWUsIHJ0Y0FjY291bnQpXG4gICAgICAgIHNlcnZpY2VSdGMuYWRkX3ByaXZpbGVnZShTZXJ2aWNlUnRjLmtQcml2aWxlZ2VKb2luQ2hhbm5lbCwgam9pbkNoYW5uZWxQcml2aWxlZ2VFeHBpcmUpXG4gICAgICAgIGlmIChydGNSb2xlID09PSBSb2xlLlBVQkxJU0hFUikge1xuICAgICAgICAgICAgc2VydmljZVJ0Yy5hZGRfcHJpdmlsZWdlKFNlcnZpY2VSdGMua1ByaXZpbGVnZVB1Ymxpc2hBdWRpb1N0cmVhbSwgcHViQXVkaW9Qcml2aWxlZ2VFeHBpcmUpXG4gICAgICAgICAgICBzZXJ2aWNlUnRjLmFkZF9wcml2aWxlZ2UoU2VydmljZVJ0Yy5rUHJpdmlsZWdlUHVibGlzaFZpZGVvU3RyZWFtLCBwdWJWaWRlb1ByaXZpbGVnZUV4cGlyZSlcbiAgICAgICAgICAgIHNlcnZpY2VSdGMuYWRkX3ByaXZpbGVnZShTZXJ2aWNlUnRjLmtQcml2aWxlZ2VQdWJsaXNoRGF0YVN0cmVhbSwgcHViRGF0YVN0cmVhbVByaXZpbGVnZUV4cGlyZSlcbiAgICAgICAgfVxuICAgICAgICB0b2tlbi5hZGRfc2VydmljZShzZXJ2aWNlUnRjKVxuXG4gICAgICAgIGNvbnN0IHNlcnZpY2VSdG0gPSBuZXcgU2VydmljZVJ0bShydG1Vc2VySWQpXG4gICAgICAgIHNlcnZpY2VSdG0uYWRkX3ByaXZpbGVnZShTZXJ2aWNlUnRtLmtQcml2aWxlZ2VMb2dpbiwgcnRtVG9rZW5FeHBpcmUpXG4gICAgICAgIHRva2VuLmFkZF9zZXJ2aWNlKHNlcnZpY2VSdG0pXG5cbiAgICAgICAgdG9rZW4uYWRkX3NlcnZpY2UobmV3IFNlcnZpY2VTdHQoKSlcblxuICAgICAgICByZXR1cm4gdG9rZW4uYnVpbGQoKVxuICAgIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gICAgU3R0VG9rZW5CdWlsZGVyXG59XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHtcbiAgICBBcGFhc1Rva2VuQnVpbGRlcjogcmVxdWlyZSgnLi9zcmMvQXBhYXNUb2tlbkJ1aWxkZXInKS5BcGFhc1Rva2VuQnVpbGRlcixcbiAgICBDaGF0VG9rZW5CdWlsZGVyOiByZXF1aXJlKCcuL3NyYy9DaGF0VG9rZW5CdWlsZGVyJykuQ2hhdFRva2VuQnVpbGRlcixcbiAgICBDb252b0FJVG9rZW5CdWlsZGVyOiByZXF1aXJlKCcuL3NyYy9Db252b0FJVG9rZW5CdWlsZGVyJykuQ29udm9BSVRva2VuQnVpbGRlcixcbiAgICBFZHVjYXRpb25Ub2tlbkJ1aWxkZXI6IHJlcXVpcmUoJy4vc3JjL0VkdWNhdGlvblRva2VuQnVpbGRlcicpLkVkdWNhdGlvblRva2VuQnVpbGRlcixcbiAgICBGcGFUb2tlbkJ1aWxkZXI6IHJlcXVpcmUoJy4vc3JjL0ZwYVRva2VuQnVpbGRlcicpLkZwYVRva2VuQnVpbGRlcixcbiAgICBSdGNSb2xlOiByZXF1aXJlKCcuL3NyYy9SdGNUb2tlbkJ1aWxkZXIyJykuUm9sZSxcbiAgICBSdGNUb2tlbkJ1aWxkZXI6IHJlcXVpcmUoJy4vc3JjL1J0Y1Rva2VuQnVpbGRlcjInKS5SdGNUb2tlbkJ1aWxkZXIsXG4gICAgUnRtVG9rZW5CdWlsZGVyOiByZXF1aXJlKCcuL3NyYy9SdG1Ub2tlbkJ1aWxkZXIyJykuUnRtVG9rZW5CdWlsZGVyLFxuICAgIFJ0bTJQZXJtaXNzaW9uczogcmVxdWlyZSgnLi9zcmMvQWNjZXNzVG9rZW4yJykuUnRtMlBlcm1pc3Npb25zLFxuICAgIFN0dFRva2VuQnVpbGRlcjogcmVxdWlyZSgnLi9zcmMvU3R0VG9rZW5CdWlsZGVyJykuU3R0VG9rZW5CdWlsZGVyXG59XG4iXSwibWFwcGluZ3MiOiI7OztDQUFBLENBQUMsV0FBVztFQUNWLElBQUksWUFDRSxvRUFFTixRQUFRO0dBRU4sTUFBTSxTQUFTLEdBQUcsR0FBRztJQUNuQixPQUFRLEtBQUssSUFBTSxNQUFPLEtBQUs7R0FDakM7R0FHQSxNQUFNLFNBQVMsR0FBRyxHQUFHO0lBQ25CLE9BQVEsS0FBTSxLQUFLLElBQU8sTUFBTTtHQUNsQztHQUdBLFFBQVEsU0FBUyxHQUFHO0lBRWxCLElBQUksRUFBRSxlQUFlLFFBQ25CLE9BQU8sTUFBTSxLQUFLLEdBQUcsQ0FBQyxJQUFJLFdBQWEsTUFBTSxLQUFLLEdBQUcsRUFBRSxJQUFJO0lBSTdELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FDNUIsRUFBRSxLQUFLLE1BQU0sT0FBTyxFQUFFLEVBQUU7SUFDMUIsT0FBTztHQUNUO0dBR0EsYUFBYSxTQUFTLEdBQUc7SUFDdkIsS0FBSyxJQUFJLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBRyxLQUMxQixNQUFNLEtBQUssS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLEdBQUcsQ0FBQztJQUM1QyxPQUFPO0dBQ1Q7R0FHQSxjQUFjLFNBQVMsT0FBTztJQUM1QixLQUFLLElBQUksUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLLEtBQUssR0FDN0QsTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFPLEtBQUssSUFBSTtJQUMxQyxPQUFPO0dBQ1Q7R0FHQSxjQUFjLFNBQVMsT0FBTztJQUM1QixLQUFLLElBQUksUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHLElBQUksTUFBTSxTQUFTLElBQUksS0FBSyxHQUN0RCxNQUFNLEtBQU0sTUFBTSxNQUFNLE9BQVEsS0FBSyxJQUFJLEtBQU8sR0FBSTtJQUN0RCxPQUFPO0dBQ1Q7R0FHQSxZQUFZLFNBQVMsT0FBTztJQUMxQixLQUFLLElBQUksTUFBTSxDQUFDLEdBQUcsSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7S0FDL0MsSUFBSSxNQUFNLE1BQU0sT0FBTyxFQUFBLENBQUcsU0FBUyxFQUFFLENBQUM7S0FDdEMsSUFBSSxNQUFNLE1BQU0sS0FBSyxHQUFBLENBQUssU0FBUyxFQUFFLENBQUM7SUFDeEM7SUFDQSxPQUFPLElBQUksS0FBSyxFQUFFO0dBQ3BCO0dBR0EsWUFBWSxTQUFTLEtBQUs7SUFDeEIsS0FBSyxJQUFJLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLLEdBQy9DLE1BQU0sS0FBSyxTQUFTLElBQUksT0FBTyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUM7SUFDM0MsT0FBTztHQUNUO0dBR0EsZUFBZSxTQUFTLE9BQU87SUFDN0IsS0FBSyxJQUFJLFNBQVMsQ0FBQyxHQUFHLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQUc7S0FDckQsSUFBSSxVQUFXLE1BQU0sTUFBTSxLQUFPLE1BQU0sSUFBSSxNQUFNLElBQUssTUFBTSxJQUFJO0tBQ2pFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQ3JCLElBQUksSUFBSSxJQUFJLElBQUksS0FBSyxNQUFNLFNBQVMsR0FDbEMsT0FBTyxLQUFLLFVBQVUsT0FBUSxZQUFZLEtBQUssSUFBSSxLQUFNLEVBQUksQ0FBQztVQUU5RCxPQUFPLEtBQUssR0FBRztJQUNyQjtJQUNBLE9BQU8sT0FBTyxLQUFLLEVBQUU7R0FDdkI7R0FHQSxlQUFlLFNBQVMsUUFBUTtJQUU5QixTQUFTLE9BQU8sUUFBUSxrQkFBa0IsRUFBRTtJQUU1QyxLQUFLLElBQUksUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHLFFBQVEsR0FBRyxJQUFJLE9BQU8sUUFDOUMsUUFBUSxFQUFFLElBQUksR0FBRztLQUNuQixJQUFJLFNBQVMsR0FBRztLQUNoQixNQUFNLE1BQU8sVUFBVSxRQUFRLE9BQU8sT0FBTyxJQUFJLENBQUMsQ0FBQyxJQUM1QyxLQUFLLElBQUksR0FBRyxLQUFLLFFBQVEsQ0FBQyxJQUFJLE1BQVEsUUFBUSxJQUM5QyxVQUFVLFFBQVEsT0FBTyxPQUFPLENBQUMsQ0FBQyxNQUFPLElBQUksUUFBUSxDQUFHO0lBQ2pFO0lBQ0EsT0FBTztHQUNUO0VBQ0Y7RUFFQSxPQUFPLFVBQVU7Q0FDbkIsRUFBQSxDQUFHOzs7OztDQy9GSCxJQUFJLFVBQVU7RUFFWixNQUFNO0dBRUosZUFBZSxTQUFTLEtBQUs7SUFDM0IsT0FBTyxRQUFRLElBQUksY0FBYyxTQUFTLG1CQUFtQixHQUFHLENBQUMsQ0FBQztHQUNwRTtHQUdBLGVBQWUsU0FBUyxPQUFPO0lBQzdCLE9BQU8sbUJBQW1CLE9BQU8sUUFBUSxJQUFJLGNBQWMsS0FBSyxDQUFDLENBQUM7R0FDcEU7RUFDRjtFQUdBLEtBQUs7R0FFSCxlQUFlLFNBQVMsS0FBSztJQUMzQixLQUFLLElBQUksUUFBUSxDQUFDLEdBQUcsSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQzFDLE1BQU0sS0FBSyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEdBQUk7SUFDckMsT0FBTztHQUNUO0dBR0EsZUFBZSxTQUFTLE9BQU87SUFDN0IsS0FBSyxJQUFJLE1BQU0sQ0FBQyxHQUFHLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUMxQyxJQUFJLEtBQUssT0FBTyxhQUFhLE1BQU0sRUFBRSxDQUFDO0lBQ3hDLE9BQU8sSUFBSSxLQUFLLEVBQUU7R0FDcEI7RUFDRjtDQUNGO0NBRUEsT0FBTyxVQUFVOzs7Ozs7Ozs7OztDQ3ZCakIsT0FBTyxVQUFVLFNBQVUsS0FBSztFQUM5QixPQUFPLE9BQU8sU0FBUyxTQUFTLEdBQUcsS0FBSyxhQUFhLEdBQUcsS0FBSyxDQUFDLENBQUMsSUFBSTtDQUNyRTtDQUVBLFNBQVMsU0FBVSxLQUFLO0VBQ3RCLE9BQU8sQ0FBQyxDQUFDLElBQUksZUFBZSxPQUFPLElBQUksWUFBWSxhQUFhLGNBQWMsSUFBSSxZQUFZLFNBQVMsR0FBRztDQUM1RztDQUdBLFNBQVMsYUFBYyxLQUFLO0VBQzFCLE9BQU8sT0FBTyxJQUFJLGdCQUFnQixjQUFjLE9BQU8sSUFBSSxVQUFVLGNBQWMsU0FBUyxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUM7Q0FDN0c7Ozs7O0NDcEJBLENBQUMsV0FBVTtFQUNULElBQUksUUFBQSxjQUFBLEdBQ0EsT0FBQSxnQkFBQSxDQUFBLENBQTBCLE1BQzFCLFdBQUEsa0JBQUEsR0FDQSxNQUFBLGdCQUFBLENBQUEsQ0FBeUIsS0FHN0IsTUFBTSxTQUFVLFNBQVMsU0FBUztHQUVoQyxJQUFJLFFBQVEsZUFBZSxRQUN6QixJQUFJLFdBQVcsUUFBUSxhQUFhLFVBQ2xDLFVBQVUsSUFBSSxjQUFjLE9BQU87UUFFbkMsVUFBVSxLQUFLLGNBQWMsT0FBTztRQUNuQyxJQUFJLFNBQVMsT0FBTyxHQUN2QixVQUFVLE1BQU0sVUFBVSxNQUFNLEtBQUssU0FBUyxDQUFDO1FBQzVDLElBQUksQ0FBQyxNQUFNLFFBQVEsT0FBTyxLQUFLLFFBQVEsZ0JBQWdCLFlBQzFELFVBQVUsUUFBUSxTQUFTO0dBRzdCLElBQUksSUFBSSxNQUFNLGFBQWEsT0FBTyxHQUM5QixJQUFJLFFBQVEsU0FBUyxHQUNyQixJQUFLLFlBQ0wsSUFBSSxZQUNKLElBQUksYUFDSixJQUFLO0dBR1QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUM1QixFQUFFLE1BQU8sRUFBRSxNQUFPLElBQU0sRUFBRSxPQUFPLE1BQU8sWUFDL0IsRUFBRSxNQUFNLEtBQU8sRUFBRSxPQUFRLEtBQU07R0FJMUMsRUFBRSxNQUFNLE1BQU0sT0FBUyxJQUFJO0dBQzNCLEdBQUssSUFBSSxPQUFRLEtBQU0sS0FBSyxNQUFNO0dBR2xDLElBQUksS0FBSyxJQUFJLEtBQ1QsS0FBSyxJQUFJLEtBQ1QsS0FBSyxJQUFJLEtBQ1QsS0FBSyxJQUFJO0dBRWIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLLElBQUk7SUFFckMsSUFBSSxLQUFLLEdBQ0wsS0FBSyxHQUNMLEtBQUssR0FDTCxLQUFLO0lBRVQsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFHLElBQUssR0FBRyxVQUFVO0lBQzFDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRyxJQUFJLElBQUksVUFBVTtJQUMxQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUcsSUFBSSxJQUFLLFNBQVM7SUFDMUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFHLElBQUksSUFBSSxXQUFXO0lBQzNDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRyxJQUFLLEdBQUcsVUFBVTtJQUMxQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUcsSUFBSSxJQUFLLFVBQVU7SUFDM0MsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFHLElBQUksSUFBSSxXQUFXO0lBQzNDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRyxJQUFJLElBQUksU0FBUztJQUN6QyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUcsSUFBSyxHQUFJLFVBQVU7SUFDM0MsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFHLElBQUksSUFBSSxXQUFXO0lBQzNDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRSxLQUFLLElBQUksTUFBTTtJQUN0QyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUUsS0FBSyxJQUFJLFdBQVc7SUFDM0MsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFFLEtBQU0sR0FBSSxVQUFVO0lBQzNDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRSxLQUFLLElBQUksU0FBUztJQUN6QyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUUsS0FBSyxJQUFJLFdBQVc7SUFDM0MsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFFLEtBQUssSUFBSyxVQUFVO0lBRTNDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRyxJQUFLLEdBQUcsVUFBVTtJQUMxQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUcsSUFBSyxHQUFHLFdBQVc7SUFDM0MsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFFLEtBQUssSUFBSyxTQUFTO0lBQzFDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRyxJQUFJLElBQUksVUFBVTtJQUMxQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUcsSUFBSyxHQUFHLFVBQVU7SUFDMUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFFLEtBQU0sR0FBSSxRQUFRO0lBQ3pDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRSxLQUFLLElBQUksVUFBVTtJQUMxQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUcsSUFBSSxJQUFJLFVBQVU7SUFDMUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFHLElBQUssR0FBSSxTQUFTO0lBQzFDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRSxLQUFNLEdBQUcsV0FBVztJQUMzQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUcsSUFBSSxJQUFJLFVBQVU7SUFDMUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFHLElBQUksSUFBSyxVQUFVO0lBQzNDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRSxLQUFNLEdBQUcsV0FBVztJQUMzQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUcsSUFBSyxHQUFHLFNBQVM7SUFDekMsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFHLElBQUksSUFBSyxVQUFVO0lBQzNDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRSxLQUFLLElBQUksV0FBVztJQUUzQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUcsSUFBSyxHQUFHLE9BQU87SUFDdkMsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFHLElBQUksSUFBSSxXQUFXO0lBQzNDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRSxLQUFLLElBQUssVUFBVTtJQUMzQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUUsS0FBSyxJQUFJLFNBQVM7SUFDekMsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFHLElBQUssR0FBRyxXQUFXO0lBQzNDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRyxJQUFJLElBQUssVUFBVTtJQUMzQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUcsSUFBSSxJQUFJLFVBQVU7SUFDMUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFFLEtBQUssSUFBSSxXQUFXO0lBQzNDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRSxLQUFNLEdBQUksU0FBUztJQUMxQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUcsSUFBSSxJQUFJLFVBQVU7SUFDMUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFHLElBQUksSUFBSSxVQUFVO0lBQzFDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRyxJQUFJLElBQUssUUFBUTtJQUN6QyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUcsSUFBSyxHQUFHLFVBQVU7SUFDMUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFFLEtBQUssSUFBSSxVQUFVO0lBQzFDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRSxLQUFLLElBQUssU0FBUztJQUMxQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUcsSUFBSSxJQUFJLFVBQVU7SUFFMUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFHLElBQUssR0FBRyxVQUFVO0lBQzFDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRyxJQUFJLElBQUssVUFBVTtJQUMzQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUUsS0FBSyxJQUFJLFdBQVc7SUFDM0MsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFHLElBQUksSUFBSSxTQUFTO0lBQ3pDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRSxLQUFNLEdBQUksVUFBVTtJQUMzQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUcsSUFBSSxJQUFJLFdBQVc7SUFDM0MsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFFLEtBQUssSUFBSSxRQUFRO0lBQ3hDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRyxJQUFJLElBQUksV0FBVztJQUMzQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUcsSUFBSyxHQUFJLFVBQVU7SUFDM0MsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFFLEtBQUssSUFBSSxTQUFTO0lBQ3pDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRyxJQUFJLElBQUksV0FBVztJQUMzQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUUsS0FBSyxJQUFLLFVBQVU7SUFDM0MsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFHLElBQUssR0FBRyxVQUFVO0lBQzFDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBRSxLQUFLLElBQUksV0FBVztJQUMzQyxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUcsSUFBSSxJQUFLLFNBQVM7SUFDMUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFHLElBQUksSUFBSSxVQUFVO0lBRTFDLElBQUssSUFBSSxPQUFRO0lBQ2pCLElBQUssSUFBSSxPQUFRO0lBQ2pCLElBQUssSUFBSSxPQUFRO0lBQ2pCLElBQUssSUFBSSxPQUFRO0dBQ25CO0dBRUEsT0FBTyxNQUFNLE9BQU87SUFBQztJQUFHO0lBQUc7SUFBRztHQUFDLENBQUM7RUFDbEM7RUFHQSxJQUFJLE1BQU8sU0FBVSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0dBQ3hDLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxDQUFDLElBQUksTUFBTSxNQUFNLEtBQUs7R0FDM0MsUUFBUyxLQUFLLElBQU0sTUFBTyxLQUFLLEtBQU87RUFDekM7RUFDQSxJQUFJLE1BQU8sU0FBVSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0dBQ3hDLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLENBQUMsTUFBTSxNQUFNLEtBQUs7R0FDM0MsUUFBUyxLQUFLLElBQU0sTUFBTyxLQUFLLEtBQU87RUFDekM7RUFDQSxJQUFJLE1BQU8sU0FBVSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0dBQ3hDLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxNQUFNLE1BQU0sS0FBSztHQUN0QyxRQUFTLEtBQUssSUFBTSxNQUFPLEtBQUssS0FBTztFQUN6QztFQUNBLElBQUksTUFBTyxTQUFVLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7R0FDeEMsSUFBSSxJQUFJLEtBQUssS0FBSyxJQUFJLENBQUMsT0FBTyxNQUFNLEtBQUs7R0FDekMsUUFBUyxLQUFLLElBQU0sTUFBTyxLQUFLLEtBQU87RUFDekM7RUFHQSxJQUFJLGFBQWE7RUFDakIsSUFBSSxjQUFjO0VBRWxCLE9BQU8sVUFBVSxTQUFVLFNBQVMsU0FBUztHQUMzQyxJQUFJLFlBQVksS0FBQSxLQUFhLFlBQVksTUFDdkMsTUFBTSxJQUFJLE1BQU0sc0JBQXNCLE9BQU87R0FFL0MsSUFBSSxjQUFjLE1BQU0sYUFBYSxJQUFJLFNBQVMsT0FBTyxDQUFDO0dBQzFELE9BQU8sV0FBVyxRQUFRLFVBQVUsY0FDaEMsV0FBVyxRQUFRLFdBQVcsSUFBSSxjQUFjLFdBQVcsSUFDM0QsTUFBTSxXQUFXLFdBQVc7RUFDbEM7Q0FFRixFQUFBLENBQUc7Ozs7O0NDL0pDLE9BQU8sVUFBVSxPQUFPLE9BQU8sSUFBSSxNQUFNLENBQUMsR0FBRyxFQUN6QyxJQUFJLEdBQUcsS0FBSztFQUNaLElBQ0ksUUFBUSxnQkFDUixRQUFRLGVBQ1IsUUFBUSxpQkFDUixRQUFRLFVBRVIsUUFBUSxLQUFLLDBGQUEwRixJQUFJLGtJQUFrSTtDQUVqUCxFQUNKLENBQUMsQ0FBQzs7Ozs7Q0NYRixPQUFPLFVBQVUsT0FBTyxPQUFPLElBQUksTUFBTSxDQUFDLEdBQUcsRUFDekMsSUFBSSxHQUFHLEtBQUs7RUFDWixJQUNJLFFBQVEsZ0JBQ1IsUUFBUSxlQUNSLFFBQVEsaUJBQ1IsUUFBUSxVQUVSLFFBQVEsS0FBSyxzRkFBc0YsSUFBSSxrSUFBa0k7Q0FFN08sRUFDSixDQUFDLENBQUM7Ozs7O0NDWE4sSUFBSSxTQUFBLGdDQUFBO0NBQ0osSUFBTSxPQUFBLDhCQUFBO0NBQ04sSUFBTSxpQkFBaUI7Q0FHdkIsSUFBTSxtQkFBbUI7RUFDckIsT0FBTztDQUNYO0NBR0EsSUFBTSxVQUFTLFVBQVM7RUFDcEIsT0FBTyxVQUFVLFFBQVEsT0FBTyxVQUFVLGVBQWUsb0JBQW9CLEtBQUssTUFBTSxTQUFTLENBQUM7Q0FDdEc7Q0FHQSxJQUFNLFVBQU4sTUFBYztFQUVWLFlBQVksY0FBYztHQUN0QixLQUFLLFNBQVM7R0FDZCxLQUFLLGVBQWUsQ0FBQztFQUN6QjtFQUdBLGNBQWM7R0FDVixJQUFJLE1BQU0sSUFBSSxRQUFRO0dBQ3RCLElBQUksVUFBVSxLQUFLLE1BQU07R0FDekIsT0FBTyxJQUFJLEtBQUs7RUFDcEI7RUFHQSxvQkFBb0I7R0FDaEIsSUFBSSxNQUFNLElBQUksUUFBUTtHQUN0QixJQUFJLGlCQUFpQixLQUFLLFlBQVk7R0FDdEMsT0FBTyxJQUFJLEtBQUs7RUFDcEI7RUFHQSxlQUFlO0dBQ1gsT0FBTyxLQUFLO0VBQ2hCO0VBR0EsY0FBYyxXQUFXLFFBQVE7R0FDN0IsS0FBSyxhQUFhLGFBQWE7RUFDbkM7RUFHQSxPQUFPO0dBQ0gsT0FBTyxPQUFPLE9BQU8sQ0FBQyxLQUFLLFlBQVksR0FBRyxLQUFLLGtCQUFrQixDQUFDLENBQUM7RUFDdkU7RUFHQSxPQUFPLFFBQVE7R0FDWCxJQUFJLFlBQVksSUFBSSxZQUFZLE1BQU07R0FDdEMsS0FBSyxlQUFlLFVBQVUsaUJBQWlCO0dBQy9DLE9BQU87RUFDWDtDQUNKO0NBRUEsSUFBTSxrQkFBa0I7Q0FHeEIsSUFBTSxhQUFOLGNBQXlCLFFBQVE7RUFFN0IsWUFBWSxjQUFjLEtBQUs7R0FDM0IsTUFBTSxlQUFlO0dBQ3JCLEtBQUssaUJBQWlCO0dBQ3RCLEtBQUssUUFBUSxRQUFRLElBQUksS0FBSyxHQUFHO0VBQ3JDO0VBR0EsT0FBTztHQUNILElBQUksU0FBUyxJQUFJLFFBQVE7R0FDekIsT0FBTyxVQUFVLEtBQUssY0FBYyxDQUFDLENBQUMsVUFBVSxLQUFLLEtBQUs7R0FDMUQsT0FBTyxPQUFPLE9BQU8sQ0FBQyxNQUFNLEtBQUssR0FBRyxPQUFPLEtBQUssQ0FBQyxDQUFDO0VBQ3REO0VBR0EsT0FBTyxRQUFRO0dBQ1gsSUFBSSxZQUFZLE1BQU0sT0FBTyxNQUFNO0dBQ25DLEtBQUssaUJBQWlCLFVBQVUsVUFBVTtHQUMxQyxLQUFLLFFBQVEsVUFBVSxVQUFVO0dBQ2pDLE9BQU87RUFDWDtDQUNKO0NBRUEsV0FBVyx3QkFBd0I7Q0FDbkMsV0FBVywrQkFBK0I7Q0FDMUMsV0FBVywrQkFBK0I7Q0FDMUMsV0FBVyw4QkFBOEI7Q0FFekMsSUFBTSxrQkFBa0I7Q0FHeEIsSUFBTSxhQUFOLGNBQXlCLFFBQVE7RUFFN0IsWUFBWSxTQUFTO0dBQ2pCLE1BQU0sZUFBZTtHQUNyQixLQUFLLFlBQVksV0FBVztFQUNoQztFQUdBLE9BQU87R0FDSCxJQUFJLFNBQVMsSUFBSSxRQUFRO0dBQ3pCLE9BQU8sVUFBVSxLQUFLLFNBQVM7R0FDL0IsT0FBTyxPQUFPLE9BQU8sQ0FBQyxNQUFNLEtBQUssR0FBRyxPQUFPLEtBQUssQ0FBQyxDQUFDO0VBQ3REO0VBR0EsT0FBTyxRQUFRO0dBQ1gsSUFBSSxZQUFZLE1BQU0sT0FBTyxNQUFNO0dBQ25DLEtBQUssWUFBWSxVQUFVLFVBQVU7R0FDckMsT0FBTztFQUNYO0NBQ0o7Q0FFQSxXQUFXLGtCQUFrQjtDQUU3QixJQUFNLHdCQUF3QjtDQUc5QixJQUFNLG1CQUFOLGNBQStCLFFBQVE7RUFFbkMsWUFBWSxjQUFjLElBQUksVUFBVSxJQUFJO0dBQ3hDLE1BQU0scUJBQXFCO0dBQzNCLEtBQUssaUJBQWlCO0dBQ3RCLEtBQUssWUFBWSxZQUFZLElBQUksS0FBSyxHQUFHO0VBQzdDO0VBR0EsT0FBTztHQUNILE1BQU0sU0FBUyxJQUFJLFFBQVEsQ0FBQyxDQUFDLFVBQVUsS0FBSyxjQUFjLENBQUMsQ0FBQyxVQUFVLEtBQUssU0FBUztHQUNwRixPQUFPLE9BQU8sT0FBTyxDQUFDLE1BQU0sS0FBSyxHQUFHLE9BQU8sS0FBSyxDQUFDLENBQUM7RUFDdEQ7RUFHQSxPQUFPLFFBQVE7R0FDWCxNQUFNLFNBQVMsTUFBTSxPQUFPLE1BQU07R0FDbEMsS0FBSyxpQkFBaUIsT0FBTyxVQUFVO0dBQ3ZDLEtBQUssWUFBWSxPQUFPLFVBQVU7R0FDbEMsT0FBTztFQUNYO0NBQ0o7Q0FFQSxpQkFBaUIsNkJBQTZCO0NBQzlDLGlCQUFpQiw2QkFBNkI7Q0FFOUMsSUFBTSxrQkFBa0I7Q0FHeEIsSUFBTSxhQUFOLGNBQXlCLFFBQVE7RUFFN0IsY0FBYztHQUNWLE1BQU0sZUFBZTtFQUN6QjtFQUdBLE9BQU87R0FDSCxPQUFPLE1BQU0sS0FBSztFQUN0QjtFQUdBLE9BQU8sUUFBUTtHQUVYLE9BRGdCLE1BQU0sT0FBTyxNQUNkO0VBQ25CO0NBQ0o7Q0FFQSxXQUFXLGtCQUFrQjtDQUU3QixJQUFNLHNCQUFzQjtDQUc1QixJQUFNLGlCQUFOLGNBQTZCLFFBQVE7RUFFakMsY0FBYztHQUNWLE1BQU0sbUJBQW1CO0VBQzdCO0VBR0EsT0FBTztHQUNILE9BQU8sTUFBTSxLQUFLO0VBQ3RCO0VBR0EsT0FBTyxRQUFRO0dBQ1gsT0FBTyxNQUFNLE9BQU8sTUFBTTtFQUM5QjtDQUNKO0NBRUEsSUFBTSxrQkFBa0I7Q0FHeEIsSUFBTSxhQUFOLGNBQXlCLFFBQVE7RUFFN0IsY0FBYztHQUNWLE1BQU0sZUFBZTtFQUN6QjtFQUdBLE9BQU87R0FDSCxPQUFPLE1BQU0sS0FBSztFQUN0QjtFQUdBLE9BQU8sUUFBUTtHQUNYLE9BQU8sTUFBTSxPQUFPLE1BQU07RUFDOUI7Q0FDSjtDQUVBLElBQU0sbUJBQW1CO0NBR3pCLElBQU0sY0FBTixjQUEwQixRQUFRO0VBRTlCLFlBQVksU0FBUztHQUNqQixNQUFNLGdCQUFnQjtHQUN0QixLQUFLLFlBQVksV0FBVztFQUNoQztFQUdBLE9BQU87R0FDSCxJQUFJLFNBQVMsSUFBSSxRQUFRO0dBQ3pCLE9BQU8sVUFBVSxLQUFLLFNBQVM7R0FDL0IsT0FBTyxPQUFPLE9BQU8sQ0FBQyxNQUFNLEtBQUssR0FBRyxPQUFPLEtBQUssQ0FBQyxDQUFDO0VBQ3REO0VBR0EsT0FBTyxRQUFRO0dBQ1gsSUFBSSxZQUFZLE1BQU0sT0FBTyxNQUFNO0dBQ25DLEtBQUssWUFBWSxVQUFVLFVBQVU7R0FDckMsT0FBTztFQUNYO0NBQ0o7Q0FFQSxZQUFZLGlCQUFpQjtDQUM3QixZQUFZLGdCQUFnQjtDQUU1QixJQUFNLG1CQUFtQjtDQUd6QixJQUFNLGNBQU4sY0FBMEIsUUFBUTtFQUU5QixZQUFZLGNBQWMsSUFBSSxVQUFVLElBQUk7R0FDeEMsTUFBTSxnQkFBZ0I7R0FDdEIsS0FBSyxpQkFBaUI7R0FDdEIsS0FBSyxZQUFZLFlBQVksSUFBSSxLQUFLLEdBQUc7RUFDN0M7RUFHQSxPQUFPO0dBQ0gsTUFBTSxTQUFTLElBQUksUUFBUSxDQUFDLENBQUMsVUFBVSxLQUFLLGNBQWMsQ0FBQyxDQUFDLFVBQVUsS0FBSyxTQUFTO0dBQ3BGLE9BQU8sT0FBTyxPQUFPLENBQUMsTUFBTSxLQUFLLEdBQUcsT0FBTyxLQUFLLENBQUMsQ0FBQztFQUN0RDtFQUdBLE9BQU8sUUFBUTtHQUNYLE1BQU0sU0FBUyxNQUFNLE9BQU8sTUFBTTtHQUNsQyxLQUFLLGlCQUFpQixPQUFPLFVBQVU7R0FDdkMsS0FBSyxZQUFZLE9BQU8sVUFBVTtHQUNsQyxPQUFPO0VBQ1g7Q0FDSjtDQUVBLFlBQVksb0JBQW9CO0NBQ2hDLFlBQVksaUJBQWlCO0NBRTdCLElBQU0sb0JBQW9CO0NBRzFCLElBQU0sZUFBTixjQUEyQixRQUFRO0VBRS9CLFlBQVksVUFBVSxVQUFVLE1BQU07R0FDbEMsTUFBTSxpQkFBaUI7R0FDdkIsS0FBSyxjQUFjLFlBQVk7R0FDL0IsS0FBSyxjQUFjLFlBQVk7R0FDL0IsS0FBSyxTQUFTLFFBQVE7RUFDMUI7RUFHQSxPQUFPO0dBQ0gsSUFBSSxTQUFTLElBQUksUUFBUTtHQUN6QixPQUFPLFVBQVUsS0FBSyxXQUFXO0dBQ2pDLE9BQU8sVUFBVSxLQUFLLFdBQVc7R0FDakMsT0FBTyxTQUFTLEtBQUssTUFBTTtHQUMzQixPQUFPLE9BQU8sT0FBTyxDQUFDLE1BQU0sS0FBSyxHQUFHLE9BQU8sS0FBSyxDQUFDLENBQUM7RUFDdEQ7RUFHQSxPQUFPLFFBQVE7R0FDWCxJQUFJLFlBQVksTUFBTSxPQUFPLE1BQU07R0FDbkMsS0FBSyxjQUFjLFVBQVUsVUFBVTtHQUN2QyxLQUFLLGNBQWMsVUFBVSxVQUFVO0dBQ3ZDLEtBQUssU0FBUyxVQUFVLFNBQVM7R0FDakMsT0FBTztFQUNYO0NBQ0o7Q0FFQSxhQUFhLHNCQUFzQjtDQUNuQyxhQUFhLGlCQUFpQjtDQUM5QixhQUFhLGdCQUFnQjtDQUc3QixJQUFNLGtCQUFOLE1BQXNCO0VBRWxCLGNBQWM7R0FDVixLQUFLLFVBQVUsQ0FBQztFQUNwQjtFQUdBLElBQUksY0FBYyxnQkFBZ0IsV0FBVztHQUN6QyxJQUFJLENBQUMsS0FBSyxRQUFRLGVBQ2QsS0FBSyxRQUFRLGdCQUFnQixDQUFDO0dBRWxDLEtBQUssUUFBUSxhQUFhLENBQUMsa0JBQWtCLE1BQU0sS0FBSyxTQUFTO0VBQ3JFO0NBQ0o7Q0FFQSxnQkFBZ0IsbUJBQW1CO0NBQ25DLGdCQUFnQixrQkFBa0I7Q0FDbEMsZ0JBQWdCLGlCQUFpQjtDQUNqQyxnQkFBZ0IsZ0JBQWdCO0NBQ2hDLGdCQUFnQixTQUFTO0NBQ3pCLGdCQUFnQixRQUFRO0NBQ3hCLGdCQUFnQixTQUFTO0NBRXpCLElBQU0sbUJBQW1CO0NBR3pCLElBQU0sY0FBTixjQUEwQixRQUFRO0VBRTlCLFlBQVksUUFBUSxhQUFhO0dBQzdCLE1BQU0sZ0JBQWdCO0dBQ3RCLEtBQUssWUFBWSxXQUFXLEtBQUssVUFBVSxPQUFPLEtBQUssT0FBTyxNQUFNO0dBQ3BFLEtBQUssZ0JBQWdCLGVBQWUsSUFBSSxnQkFBZ0I7RUFDNUQ7RUFHQSxPQUFPO0dBQ0gsTUFBTSxTQUFTLElBQUksUUFBUSxDQUFDLENBQUMsVUFBVSxLQUFLLFNBQVM7R0FDckQsTUFBTSxnQkFBZ0IsT0FBTyxLQUFLLEtBQUssY0FBYyxPQUFPLENBQUMsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLE1BQU0sTUFBTSxVQUFVLE9BQU8sS0FBSztHQUM1RyxPQUFPLFVBQVUsY0FBYyxNQUFNO0dBQ3JDLGNBQWMsU0FBUSxpQkFBZ0I7SUFDbEMsTUFBTSxnQkFBZ0IsS0FBSyxjQUFjLFFBQVE7SUFDakQsTUFBTSxrQkFBa0IsT0FBTyxLQUFLLGFBQWEsQ0FBQyxDQUFDLElBQUksTUFBTSxDQUFDLENBQUMsTUFBTSxNQUFNLFVBQVUsT0FBTyxLQUFLO0lBQ2pHLE9BQU8sVUFBVSxZQUFZLENBQUMsQ0FBQyxVQUFVLGdCQUFnQixNQUFNO0lBQy9ELGdCQUFnQixTQUFRLG1CQUFrQjtLQUN0QyxNQUFNLFlBQVksY0FBYztLQUNoQyxPQUFPLFVBQVUsY0FBYyxDQUFDLENBQUMsVUFBVSxVQUFVLE1BQU07S0FDM0QsVUFBVSxTQUFRLGFBQVksT0FBTyxVQUFVLFFBQVEsQ0FBQztJQUM1RCxDQUFDO0dBQ0wsQ0FBQztHQUNELE9BQU8sT0FBTyxPQUFPLENBQUMsTUFBTSxLQUFLLEdBQUcsT0FBTyxLQUFLLENBQUMsQ0FBQztFQUN0RDtFQUdBLE9BQU8sUUFBUTtHQUNYLE1BQU0sU0FBUyxNQUFNLE9BQU8sTUFBTTtHQUNsQyxLQUFLLFlBQVksT0FBTyxVQUFVO0dBQ2xDLEtBQUssZ0JBQWdCLElBQUksZ0JBQWdCO0dBQ3pDLE1BQU0sb0JBQW9CLE9BQU8sVUFBVTtHQUMzQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksbUJBQW1CLEtBQUs7SUFDeEMsTUFBTSxlQUFlLE9BQU8sVUFBVTtJQUN0QyxNQUFNLGtCQUFrQixPQUFPLFVBQVU7SUFDekMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGlCQUFpQixLQUFLO0tBQ3RDLE1BQU0saUJBQWlCLE9BQU8sVUFBVTtLQUN4QyxNQUFNLGdCQUFnQixPQUFPLFVBQVU7S0FDdkMsTUFBTSxZQUFZLENBQUM7S0FDbkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGVBQWUsS0FDL0IsVUFBVSxLQUFLLE9BQU8sVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDO0tBRWhELEtBQUssY0FBYyxJQUFJLGNBQWMsZ0JBQWdCLFNBQVM7SUFDbEU7R0FDSjtHQUNBLE9BQU87RUFDWDtDQUNKO0NBRUEsWUFBWSxrQkFBa0I7Q0FHOUIsSUFBTSxlQUFOLE1BQU0sYUFBYTtFQUVmLFlBQVksT0FBTyxnQkFBZ0IsU0FBUyxRQUFRO0dBQ2hELEtBQUssUUFBUTtHQUNiLEtBQUssaUJBQWlCO0dBQ3RCLEtBQUssVUFBVSw0QkFBVyxJQUFJLEtBQUssRUFBQSxDQUFFLFFBQVEsSUFBSTtHQUNqRCxLQUFLLFNBQVM7R0FFZCxLQUFLLE9BQU8sS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLFFBQVEsSUFBSTtHQUNuRCxLQUFLLFdBQVcsQ0FBQztHQUNqQixLQUFLLGNBQWMsT0FBTyxNQUFNLENBQUM7R0FDakMsS0FBSyxpQkFBaUIsT0FBTyxNQUFNLENBQUM7R0FDcEMsS0FBSyxXQUFXO0VBQ3BCO0VBR0EsVUFBVSxpQkFBaUIsS0FBSyxnQkFBZ0I7R0FDNUMsSUFBSSxVQUFVLFdBQVcsSUFBSSxRQUFRLENBQUMsQ0FBQyxVQUFVLEtBQUssT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLGNBQWM7R0FDckYsVUFBVSxXQUFXLElBQUksUUFBUSxDQUFDLENBQUMsVUFBVSxLQUFLLElBQUksQ0FBQyxDQUFDLEtBQUssR0FBRyxPQUFPO0dBQ3ZFLE9BQU87RUFDWDtFQUdBLGdCQUFnQjtHQUNaLE1BQU0sRUFBRSxPQUFPLGdCQUFnQixhQUFhO0dBQzVDLElBQUksQ0FBQyxPQUFPLEtBQUssS0FBSyxDQUFDLE9BQU8sY0FBYyxHQUN4QyxPQUFPO0dBR1gsSUFBSSxTQUFTLFdBQVcsR0FDcEIsT0FBTztHQUVYLE9BQU87RUFDWDtFQUdBLHlCQUF5QjtHQUNyQixPQUFPLEtBQUssU0FDUCxLQUFLLFNBQVMsV0FBVztJQUFFO0lBQVM7R0FBTSxFQUFFLENBQUMsQ0FDN0MsTUFBTSxNQUFNLFVBQVU7SUFFbkIsT0FEdUIsS0FBSyxRQUFRLGFBQWEsSUFBSSxNQUFNLFFBQVEsYUFBYSxLQUN2RCxLQUFLLFFBQVEsTUFBTTtHQUNoRCxDQUFDLENBQUMsQ0FDRCxLQUFJLFVBQVMsTUFBTSxPQUFPO0VBQ25DO0VBR0EsWUFBWSxTQUFTO0dBQ2pCLEtBQUssU0FBUyxLQUFLLE9BQU87RUFDOUI7RUFHQSxZQUFZLGFBQWE7R0FDckIsT0FBTyxLQUFLLFNBQVMsUUFBTyxZQUFXLFFBQVEsYUFBYSxNQUFNLFdBQVc7RUFDakY7RUFHQSxRQUFRO0dBQ0osSUFBSSxDQUFDLEtBQUssY0FBYyxHQUNwQixPQUFPO0dBR1gsSUFBSSxVQUFVLEtBQUssVUFBVTtHQUM3QixNQUFNLFdBQVcsS0FBSyx1QkFBdUI7R0FDN0MsSUFBSSxlQUFlLElBQUksUUFBUSxDQUFDLENBQzNCLFVBQVUsS0FBSyxLQUFLLENBQUMsQ0FDckIsVUFBVSxLQUFLLE9BQU8sQ0FBQyxDQUN2QixVQUFVLEtBQUssTUFBTSxDQUFDLENBQ3RCLFVBQVUsS0FBSyxJQUFJLENBQUMsQ0FDcEIsVUFBVSxTQUFTLE1BQU0sQ0FBQyxDQUMxQixLQUFLO0dBQ1YsU0FBUyxTQUFRLFlBQVc7SUFDeEIsZUFBZSxPQUFPLE9BQU8sQ0FBQyxjQUFjLFFBQVEsS0FBSyxDQUFDLENBQUM7R0FDL0QsQ0FBQztHQUVELElBQUksWUFBWSxXQUFXLFNBQVMsWUFBWTtHQUNoRCxJQUFJLFVBQVUsT0FBTyxPQUFPLENBQUMsSUFBSSxRQUFRLENBQUMsQ0FBQyxVQUFVLFNBQVMsQ0FBQyxDQUFDLEtBQUssR0FBRyxZQUFZLENBQUM7R0FDckYsSUFBSSxhQUFhLEtBQUssWUFBWSxPQUFPO0dBQ3pDLE9BQU8sR0FBRyxXQUFXLElBQUksT0FBTyxLQUFLLFVBQVUsQ0FBQyxDQUFDLFNBQVMsUUFBUTtFQUN0RTtFQUdBLFlBQVksY0FBYztHQUV0QixLQUFLLFFBQVE7R0FDYixLQUFLLFVBQVU7R0FDZixLQUFLLFNBQVM7R0FDZCxLQUFLLE9BQU87R0FDWixLQUFLLFdBQVcsQ0FBQztHQUNqQixLQUFLLGNBQWMsT0FBTyxNQUFNLENBQUM7R0FDakMsS0FBSyxpQkFBaUIsT0FBTyxNQUFNLENBQUM7R0FDcEMsS0FBSyxXQUFXO0dBRWhCLElBQUksT0FBTyxpQkFBaUIsWUFBWSxhQUFhLFNBQVMsZ0JBQzFELE9BQU87R0FJWCxJQUR1QixhQUFhLFVBQVUsR0FBRyxjQUNoQyxNQUFNLFdBQVcsR0FDOUIsT0FBTztHQUdYLElBQUk7SUFDQSxNQUFNLGlCQUFpQixhQUFhLFVBQVUsY0FBYztJQUU1RCxNQUFNLGVBQWUsSUFBSSxZQURWLEtBQUssWUFBWSxPQUFPLEtBQUssZ0JBQWdCLFFBQVEsQ0FDMUIsQ0FBQztJQUUzQyxLQUFLLGNBQWMsT0FBTyxLQUFLLGFBQWEsVUFBVSxDQUFDO0lBQ3ZELEtBQUssaUJBQWlCLE9BQU8sS0FBSyxhQUFhLEtBQUssQ0FBQztJQUNyRCxLQUFLLFdBQVcsQ0FBQztJQUNqQixLQUFLLFFBQVEsYUFBYSxVQUFVO0lBQ3BDLEtBQUssVUFBVSxhQUFhLFVBQVU7SUFDdEMsS0FBSyxTQUFTLGFBQWEsVUFBVTtJQUNyQyxLQUFLLE9BQU8sYUFBYSxVQUFVO0lBQ25DLE1BQU0sZ0JBQWdCLGFBQWEsVUFBVTtJQUU3QyxJQUFJLFlBQVksYUFBYSxLQUFLO0lBQ2xDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxlQUFlLEtBQUs7S0FDcEMsTUFBTSxzQkFBc0IsSUFBSSxZQUFZLFNBQVM7S0FDckQsTUFBTSxlQUFlLG9CQUFvQixVQUFVO0tBQ25ELE1BQU0sZUFBZSxhQUFhLFVBQVU7S0FDNUMsSUFBSSxDQUFDLGNBQWM7TUFDZixLQUFLLFdBQVc7TUFDaEIsT0FBTztLQUNYO0tBRUEsTUFBTSxVQUFVLElBQUksYUFBYTtLQUNqQyxZQUFZLFFBQVEsT0FBTyxvQkFBb0IsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLO0tBQzVELEtBQUssWUFBWSxPQUFPO0lBQzVCO0dBQ0osU0FBUyxPQUFPO0lBQ1osT0FBTztHQUNYO0dBRUEsS0FBSyxXQUFXO0dBQ2hCLE9BQU87RUFDWDtFQUdBLGdCQUFnQixnQkFBZ0I7R0FDNUIsSUFBSSxDQUFDLEtBQUssWUFBWSxLQUFLLFlBQVksV0FBVyxLQUFLLEtBQUssZUFBZSxXQUFXLEtBQy9FLENBQUMsT0FBTyxLQUFLLEtBQUssS0FBSyxDQUFDLE9BQU8sY0FBYyxHQUNoRCxPQUFPO0dBR1gsTUFBTSxZQUFZLFdBQVcsS0FBSyxVQUFVLGNBQWMsR0FBRyxLQUFLLGNBQWM7R0FDaEYsT0FBTyxLQUFLLFlBQVksV0FBVyxVQUFVLFVBQ3RDLE9BQU8sZ0JBQWdCLEtBQUssYUFBYSxTQUFTO0VBQzdEO0NBQ0o7Q0FHQSxJQUFJLGFBQWEsU0FBVSxLQUFLLFNBQVM7RUFDckMsT0FBTyxPQUFPLFdBQVcsVUFBVSxHQUFHLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDLE9BQU87Q0FDbkU7Q0FHQSxJQUFJLFVBQVUsV0FBWTtFQUN0QixJQUFJLE9BQU87R0FDUCxRQUFRLE9BQU8sTUFBTSxJQUFJO0dBQ3pCLFVBQVU7RUFDZDtFQUVBLEtBQUssT0FBTyxLQUFLLENBQUM7RUFHbEIsSUFBSSxpQkFBaUIsU0FBVSxrQkFBa0I7R0FDN0MsTUFBTSxpQkFBaUIsS0FBSyxXQUFXO0dBQ3ZDLElBQUksa0JBQWtCLEtBQUssT0FBTyxRQUM5QjtHQUdKLElBQUksV0FBVyxLQUFLLE9BQU87R0FDM0IsT0FBTyxXQUFXLGdCQUNkLFlBQVk7R0FHaEIsTUFBTSxXQUFXLE9BQU8sTUFBTSxRQUFRO0dBQ3RDLEtBQUssT0FBTyxLQUFLLFVBQVUsR0FBRyxHQUFHLEtBQUssUUFBUTtHQUM5QyxLQUFLLFNBQVM7RUFDbEI7RUFHQSxLQUFLLE9BQU8sV0FBWTtHQUNwQixJQUFJLE1BQU0sT0FBTyxNQUFNLEtBQUssUUFBUTtHQUNwQyxLQUFLLE9BQU8sS0FBSyxLQUFLLEdBQUcsR0FBRyxJQUFJLE1BQU07R0FDdEMsT0FBTztFQUNYO0VBR0EsS0FBSyxZQUFZLFNBQVUsR0FBRztHQUMxQixlQUFlLENBQUM7R0FDaEIsS0FBSyxPQUFPLGNBQWMsR0FBRyxLQUFLLFFBQVE7R0FDMUMsS0FBSyxZQUFZO0dBQ2pCLE9BQU87RUFDWDtFQUdBLEtBQUssWUFBWSxTQUFVLEdBQUc7R0FDMUIsZUFBZSxDQUFDO0dBQ2hCLEtBQUssT0FBTyxjQUFjLEdBQUcsS0FBSyxRQUFRO0dBQzFDLEtBQUssWUFBWTtHQUNqQixPQUFPO0VBQ1g7RUFFQSxLQUFLLFdBQVcsU0FBVSxHQUFHO0dBQ3pCLGVBQWUsQ0FBQztHQUNoQixLQUFLLE9BQU8sYUFBYSxHQUFHLEtBQUssUUFBUTtHQUN6QyxLQUFLLFlBQVk7R0FDakIsT0FBTztFQUNYO0VBR0EsS0FBSyxXQUFXLFNBQVUsR0FBRztHQUN6QixlQUFlLENBQUM7R0FDaEIsS0FBSyxPQUFPLGFBQWEsR0FBRyxLQUFLLFFBQVE7R0FDekMsS0FBSyxZQUFZO0dBQ2pCLE9BQU87RUFDWDtFQUdBLEtBQUssV0FBVyxTQUFVLE9BQU87R0FDN0IsS0FBSyxVQUFVLE1BQU0sTUFBTTtHQUMzQixlQUFlLE1BQU0sTUFBTTtHQUMzQixNQUFNLEtBQUssS0FBSyxRQUFRLEtBQUssUUFBUTtHQUNyQyxLQUFLLFlBQVksTUFBTTtHQUN2QixPQUFPO0VBQ1g7RUFHQSxLQUFLLFlBQVksU0FBVSxLQUFLO0dBQzVCLE9BQU8sS0FBSyxTQUFTLE9BQU8sS0FBSyxHQUFHLENBQUM7RUFDekM7RUFHQSxLQUFLLGFBQWEsU0FBVSxLQUFLO0dBQzdCLElBQUksQ0FBQyxLQUFLO0lBQ04sS0FBSyxVQUFVLENBQUM7SUFDaEIsT0FBTztHQUNYO0dBRUEsS0FBSyxVQUFVLE9BQU8sS0FBSyxHQUFHLENBQUMsQ0FBQyxNQUFNO0dBQ3RDLEtBQUssSUFBSSxPQUFPLEtBQUs7SUFDakIsS0FBSyxVQUFVLEdBQUc7SUFDbEIsS0FBSyxVQUFVLElBQUksSUFBSTtHQUMzQjtHQUVBLE9BQU87RUFDWDtFQUdBLEtBQUssbUJBQW1CLFNBQVUsS0FBSztHQUNuQyxJQUFJLENBQUMsS0FBSztJQUNOLEtBQUssVUFBVSxDQUFDO0lBQ2hCLE9BQU87R0FDWDtHQUVBLEtBQUssVUFBVSxPQUFPLEtBQUssR0FBRyxDQUFDLENBQUMsTUFBTTtHQUN0QyxLQUFLLElBQUksT0FBTyxLQUFLO0lBQ2pCLEtBQUssVUFBVSxHQUFHO0lBQ2xCLEtBQUssVUFBVSxJQUFJLElBQUk7R0FDM0I7R0FFQSxPQUFPO0VBQ1g7RUFFQSxPQUFPO0NBQ1g7Q0FHQSxJQUFJLGNBQWMsU0FBVSxPQUFPO0VBQy9CLElBQUksT0FBTztHQUNQLFFBQVE7R0FDUixVQUFVO0VBQ2Q7RUFHQSxLQUFLLFlBQVksV0FBWTtHQUN6QixJQUFJLE1BQU0sS0FBSyxPQUFPLGFBQWEsS0FBSyxRQUFRO0dBQ2hELEtBQUssWUFBWTtHQUNqQixPQUFPO0VBQ1g7RUFHQSxLQUFLLFlBQVksV0FBWTtHQUN6QixJQUFJLE1BQU0sS0FBSyxPQUFPLGFBQWEsS0FBSyxRQUFRO0dBQ2hELEtBQUssWUFBWTtHQUNqQixPQUFPO0VBQ1g7RUFHQSxLQUFLLFdBQVcsV0FBWTtHQUN4QixJQUFJLE1BQU0sS0FBSyxPQUFPLGFBQWEsS0FBSyxRQUFRO0dBQ2hELEtBQUssWUFBWTtHQUNqQixPQUFPO0VBQ1g7RUFHQSxLQUFLLFlBQVksV0FBWTtHQUN6QixJQUFJLE1BQU0sS0FBSyxVQUFVO0dBRXpCLElBQUksTUFBTSxPQUFPLE1BQU0sR0FBRztHQUMxQixLQUFLLE9BQU8sS0FBSyxLQUFLLEdBQUcsS0FBSyxVQUFVLEtBQUssV0FBVyxHQUFHO0dBQzNELEtBQUssWUFBWTtHQUNqQixPQUFPO0VBQ1g7RUFHQSxLQUFLLG1CQUFtQixXQUFZO0dBQ2hDLElBQUksTUFBTSxDQUFDO0dBQ1gsSUFBSSxNQUFNLEtBQUssVUFBVTtHQUN6QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxLQUFLO0lBQzFCLElBQUksTUFBTSxLQUFLLFVBQVU7SUFFekIsSUFBSSxPQURRLEtBQUssVUFDRjtHQUNuQjtHQUNBLE9BQU87RUFDWDtFQUdBLEtBQUssT0FBTyxXQUFZO0dBQ3BCLE1BQU0sU0FBUyxLQUFLLE9BQU8sU0FBUyxLQUFLO0dBQ3pDLE1BQU0sTUFBTSxPQUFPLE1BQU0sTUFBTTtHQUMvQixLQUFLLE9BQU8sS0FBSyxLQUFLLEdBQUcsS0FBSyxRQUFRO0dBQ3RDLE9BQU87RUFDWDtFQUVBLE9BQU87Q0FDWDtDQUVBLGFBQWEsWUFBWSxDQUFDO0NBQzFCLGFBQWEsVUFBVSxxQkFBcUI7Q0FDNUMsYUFBYSxVQUFVLG9CQUFvQjtDQUMzQyxhQUFhLFVBQVUsb0JBQW9CO0NBQzNDLGFBQWEsVUFBVSxtQkFBbUI7Q0FDMUMsYUFBYSxVQUFVLG1CQUFtQjtDQUMxQyxhQUFhLFVBQVUsbUJBQW1CO0NBQzFDLGFBQWEsVUFBVSxvQkFBb0I7Q0FDM0MsYUFBYSxVQUFVLHlCQUF5QjtDQUNoRCxhQUFhLFVBQVUsdUJBQXVCO0NBQzlDLGFBQWEsVUFBVSxtQkFBbUI7Q0FFMUMsT0FBTyxVQUFVO0VBQ2I7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNKOzs7OztDQzN1QkEsSUFBTSxNQUFBLFlBQUE7Q0FFTixJQUFNLGNBQUEscUJBQUEsQ0FBQSxDQUF3QztDQUM5QyxJQUFNLGVBQUEscUJBQUEsQ0FBQSxDQUF5QztDQUMvQyxJQUFNLGNBQUEscUJBQUEsQ0FBQSxDQUF3QztDQUM5QyxJQUFNLGFBQUEscUJBQUEsQ0FBQSxDQUF1QztDQUU3QyxJQUFNLG9CQUFOLE1BQXdCOzs7Ozs7Ozs7Ozs7Ozs7O0VBZ0JwQixPQUFPLG1CQUFtQixPQUFPLGdCQUFnQixVQUFVLFVBQVUsTUFBTSxRQUFRO0dBQy9FLElBQUksY0FBYyxJQUFJLFlBQVksT0FBTyxnQkFBZ0IsR0FBRyxNQUFNO0dBRWxFLElBQUksYUFBYSxJQUFJLFFBQVE7R0FDN0IsSUFBSSxlQUFlLElBQUksYUFBYSxVQUFVLFVBQVUsSUFBSTtHQUM1RCxZQUFZLFlBQVksWUFBWTtHQUVwQyxJQUFJLGFBQWEsSUFBSSxXQUFXLFFBQVE7R0FDeEMsV0FBVyxjQUFjLFdBQVcsaUJBQWlCLE1BQU07R0FDM0QsWUFBWSxZQUFZLFVBQVU7R0FFbEMsSUFBSSxjQUFjLElBQUksWUFBWSxVQUFVO0dBQzVDLFlBQVksY0FBYyxZQUFZLGdCQUFnQixNQUFNO0dBQzVELFlBQVksWUFBWSxXQUFXO0dBRW5DLE9BQU8sWUFBWSxNQUFNO0VBQzdCOzs7Ozs7Ozs7Ozs7OztFQWVBLE9BQU8sZUFBZSxPQUFPLGdCQUFnQixVQUFVLFFBQVE7R0FDM0QsSUFBSSxjQUFjLElBQUksWUFBWSxPQUFPLGdCQUFnQixHQUFHLE1BQU07R0FDbEUsSUFBSSxlQUFlLElBQUksYUFBYSxJQUFJLFFBQVE7R0FDaEQsYUFBYSxjQUFjLGFBQWEsZ0JBQWdCLE1BQU07R0FDOUQsWUFBWSxZQUFZLFlBQVk7R0FFcEMsT0FBTyxZQUFZLE1BQU07RUFDN0I7Ozs7Ozs7Ozs7Ozs7RUFjQSxPQUFPLGNBQWMsT0FBTyxnQkFBZ0IsUUFBUTtHQUNoRCxJQUFJLGNBQWMsSUFBSSxZQUFZLE9BQU8sZ0JBQWdCLEdBQUcsTUFBTTtHQUNsRSxJQUFJLGVBQWUsSUFBSSxhQUFhO0dBQ3BDLGFBQWEsY0FBYyxhQUFhLGVBQWUsTUFBTTtHQUM3RCxZQUFZLFlBQVksWUFBWTtHQUVwQyxPQUFPLFlBQVksTUFBTTtFQUM3QjtDQUNKO0NBRUEsT0FBTyxRQUFRLG9CQUFvQjs7Ozs7Q0NyRm5DLElBQU0sY0FBQSxxQkFBQSxDQUFBLENBQTZDO0NBQ25ELElBQU0sY0FBQSxxQkFBQSxDQUFBLENBQTZDO0NBRW5ELElBQU0sbUJBQU4sTUFBdUI7Ozs7Ozs7Ozs7Ozs7OztFQWVuQixPQUFPLGVBQWUsT0FBTyxnQkFBZ0IsVUFBVSxRQUFRO0dBQzNELE1BQU0sUUFBUSxJQUFJLFlBQVksT0FBTyxnQkFBZ0IsTUFBTSxNQUFNO0dBQ2pFLE1BQU0sY0FBYyxJQUFJLFlBQVksUUFBUTtHQUM1QyxZQUFZLGNBQWMsWUFBWSxnQkFBZ0IsTUFBTTtHQUM1RCxNQUFNLFlBQVksV0FBVztHQUM3QixPQUFPLE1BQU0sTUFBTTtFQUN2Qjs7Ozs7Ozs7Ozs7Ozs7RUFlQSxPQUFPLGNBQWMsT0FBTyxnQkFBZ0IsUUFBUTtHQUNoRCxNQUFNLFFBQVEsSUFBSSxZQUFZLE9BQU8sZ0JBQWdCLE1BQU0sTUFBTTtHQUNqRSxNQUFNLGNBQWMsSUFBSSxZQUFZO0dBQ3BDLFlBQVksY0FBYyxZQUFZLGVBQWUsTUFBTTtHQUMzRCxNQUFNLFlBQVksV0FBVztHQUM3QixPQUFPLE1BQU0sTUFBTTtFQUN2QjtDQUNKO0NBRUEsUUFBUSxtQkFBbUI7Ozs7O0NDaEQzQixJQUFNLGNBQUEscUJBQUEsQ0FBQSxDQUE2QztDQUNuRCxJQUFNLGFBQUEscUJBQUEsQ0FBQSxDQUE0QztDQUNsRCxJQUFNLGFBQUEscUJBQUEsQ0FBQSxDQUE0QztDQUVsRCxJQUFNLE9BQU87Ozs7OztFQU1ULFdBQVc7Ozs7Ozs7OztFQVVYLFlBQVk7Q0FDaEI7Q0FFQSxJQUFNLGtCQUFOLE1BQXNCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUF3QmxCLE9BQU8sa0JBQWtCLE9BQU8sZ0JBQWdCLGFBQWEsS0FBSyxNQUFNLGFBQWEsa0JBQWtCLEdBQUc7R0FDdEcsT0FBTyxLQUFLLDBCQUNSLE9BQ0EsZ0JBQ0EsYUFDQSxLQUNBLE1BQ0EsYUFDQSxlQUNKO0VBQ0o7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQXlCQSxPQUFPLDBCQUNILE9BQ0EsZ0JBQ0EsYUFDQSxTQUNBLE1BQ0EsYUFDQSxrQkFBa0IsR0FDcEI7R0FDRSxJQUFJLFFBQVEsSUFBSSxZQUFZLE9BQU8sZ0JBQWdCLEdBQUcsV0FBVztHQUVqRSxJQUFJLGFBQWEsSUFBSSxXQUFXLGFBQWEsT0FBTztHQUNwRCxXQUFXLGNBQWMsV0FBVyx1QkFBdUIsZUFBZTtHQUMxRSxJQUFJLFFBQVEsS0FBSyxXQUFXO0lBQ3hCLFdBQVcsY0FBYyxXQUFXLDhCQUE4QixlQUFlO0lBQ2pGLFdBQVcsY0FBYyxXQUFXLDhCQUE4QixlQUFlO0lBQ2pGLFdBQVcsY0FBYyxXQUFXLDZCQUE2QixlQUFlO0dBQ3BGO0dBQ0EsTUFBTSxZQUFZLFVBQVU7R0FFNUIsT0FBTyxNQUFNLE1BQU07RUFDdkI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQTBEQSxPQUFPLDhCQUNILE9BQ0EsZ0JBQ0EsYUFDQSxLQUNBLGFBQ0EsNEJBQ0EseUJBQ0EseUJBQ0EsOEJBQ0Y7R0FDRSxPQUFPLEtBQUssc0NBQ1IsT0FDQSxnQkFDQSxhQUNBLEtBQ0EsYUFDQSw0QkFDQSx5QkFDQSx5QkFDQSw0QkFDSjtFQUNKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUEwREEsT0FBTyxzQ0FDSCxPQUNBLGdCQUNBLGFBQ0EsU0FDQSxhQUNBLDRCQUNBLHlCQUNBLHlCQUNBLDhCQUNGO0dBQ0UsSUFBSSxRQUFRLElBQUksWUFBWSxPQUFPLGdCQUFnQixHQUFHLFdBQVc7R0FFakUsSUFBSSxhQUFhLElBQUksV0FBVyxhQUFhLE9BQU87R0FDcEQsV0FBVyxjQUFjLFdBQVcsdUJBQXVCLDBCQUEwQjtHQUNyRixXQUFXLGNBQWMsV0FBVyw4QkFBOEIsdUJBQXVCO0dBQ3pGLFdBQVcsY0FBYyxXQUFXLDhCQUE4Qix1QkFBdUI7R0FDekYsV0FBVyxjQUFjLFdBQVcsNkJBQTZCLDRCQUE0QjtHQUM3RixNQUFNLFlBQVksVUFBVTtHQUU1QixPQUFPLE1BQU0sTUFBTTtFQUN2Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBeUJBLE9BQU8sa0JBQWtCLE9BQU8sZ0JBQWdCLGFBQWEsU0FBUyxNQUFNLGFBQWEsa0JBQWtCLEdBQUc7R0FDMUcsSUFBSSxRQUFRLElBQUksWUFBWSxPQUFPLGdCQUFnQixHQUFHLFdBQVc7R0FFakUsSUFBSSxhQUFhLElBQUksV0FBVyxhQUFhLE9BQU87R0FDcEQsV0FBVyxjQUFjLFdBQVcsdUJBQXVCLGVBQWU7R0FDMUUsSUFBSSxRQUFRLEtBQUssV0FBVztJQUN4QixXQUFXLGNBQWMsV0FBVyw4QkFBOEIsZUFBZTtJQUNqRixXQUFXLGNBQWMsV0FBVyw4QkFBOEIsZUFBZTtJQUNqRixXQUFXLGNBQWMsV0FBVyw2QkFBNkIsZUFBZTtHQUNwRjtHQUNBLE1BQU0sWUFBWSxVQUFVO0dBRTVCLElBQUksYUFBYSxJQUFJLFdBQVcsT0FBTztHQUN2QyxXQUFXLGNBQWMsV0FBVyxpQkFBaUIsV0FBVztHQUNoRSxNQUFNLFlBQVksVUFBVTtHQUU1QixPQUFPLE1BQU0sTUFBTTtFQUN2Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBMkNBLE9BQU8sbUJBQ0gsT0FDQSxnQkFDQSxhQUNBLFlBQ0EsU0FDQSxnQkFDQSw0QkFDQSx5QkFDQSx5QkFDQSw4QkFDQSxXQUNBLGdCQUNGO0dBQ0UsSUFBSSxRQUFRLElBQUksWUFBWSxPQUFPLGdCQUFnQixHQUFHLGNBQWM7R0FFcEUsSUFBSSxhQUFhLElBQUksV0FBVyxhQUFhLFVBQVU7R0FDdkQsV0FBVyxjQUFjLFdBQVcsdUJBQXVCLDBCQUEwQjtHQUNyRixJQUFJLFdBQVcsS0FBSyxXQUFXO0lBQzNCLFdBQVcsY0FBYyxXQUFXLDhCQUE4Qix1QkFBdUI7SUFDekYsV0FBVyxjQUFjLFdBQVcsOEJBQThCLHVCQUF1QjtJQUN6RixXQUFXLGNBQWMsV0FBVyw2QkFBNkIsNEJBQTRCO0dBQ2pHO0dBQ0EsTUFBTSxZQUFZLFVBQVU7R0FFNUIsSUFBSSxhQUFhLElBQUksV0FBVyxTQUFTO0dBQ3pDLFdBQVcsY0FBYyxXQUFXLGlCQUFpQixjQUFjO0dBQ25FLE1BQU0sWUFBWSxVQUFVO0dBRTVCLE9BQU8sTUFBTSxNQUFNO0VBQ3ZCO0NBQ0o7Q0FFQSxPQUFPLFFBQVEsa0JBQWtCO0NBQ2pDLE9BQU8sUUFBUSxPQUFPOzs7OztDQzdYdEIsSUFBTSxjQUFBLHFCQUFBLENBQUEsQ0FBNkM7Q0FDbkQsSUFBTSxpQkFBQSxxQkFBQSxDQUFBLENBQWdEO0NBQ3RELElBQU0sYUFBQSxxQkFBQSxDQUFBLENBQTRDO0NBQ2xELElBQU0sYUFBQSxxQkFBQSxDQUFBLENBQTRDO0NBQ2xELElBQU0sT0FBQSx5QkFBQSxDQUFBLENBQTBDO0NBRWhELElBQU0sc0JBQU4sTUFBMEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQXdCdEIsT0FBTyxXQUNILE9BQ0EsZ0JBQ0EsYUFDQSxZQUNBLFNBQ0EsZ0JBQ0EsNEJBQ0EseUJBQ0EseUJBQ0EsOEJBQ0EsV0FDQSxnQkFDRjtHQUNFLE1BQU0sUUFBUSxJQUFJLFlBQVksT0FBTyxnQkFBZ0IsR0FBRyxjQUFjO0dBRXRFLE1BQU0sYUFBYSxJQUFJLFdBQVcsYUFBYSxVQUFVO0dBQ3pELFdBQVcsY0FBYyxXQUFXLHVCQUF1QiwwQkFBMEI7R0FDckYsSUFBSSxZQUFZLEtBQUssV0FBVztJQUM1QixXQUFXLGNBQWMsV0FBVyw4QkFBOEIsdUJBQXVCO0lBQ3pGLFdBQVcsY0FBYyxXQUFXLDhCQUE4Qix1QkFBdUI7SUFDekYsV0FBVyxjQUFjLFdBQVcsNkJBQTZCLDRCQUE0QjtHQUNqRztHQUNBLE1BQU0sWUFBWSxVQUFVO0dBRTVCLE1BQU0sYUFBYSxJQUFJLFdBQVcsU0FBUztHQUMzQyxXQUFXLGNBQWMsV0FBVyxpQkFBaUIsY0FBYztHQUNuRSxNQUFNLFlBQVksVUFBVTtHQUU1QixNQUFNLFlBQVksSUFBSSxlQUFlLENBQUM7R0FFdEMsT0FBTyxNQUFNLE1BQU07RUFDdkI7Q0FDSjtDQUVBLE9BQU8sVUFBVSxFQUNiLG9CQUNKOzs7OztDQ25FQSxJQUFNLE1BQUEsWUFBQTtDQUVOLElBQU0sY0FBQSxxQkFBQSxDQUFBLENBQTZDO0NBQ25ELElBQU0sZUFBQSxxQkFBQSxDQUFBLENBQThDO0NBQ3BELElBQU0sY0FBQSxxQkFBQSxDQUFBLENBQTZDO0NBQ25ELElBQU0sYUFBQSxxQkFBQSxDQUFBLENBQTRDO0NBRWxELElBQU0sd0JBQU4sTUFBNEI7Ozs7Ozs7Ozs7Ozs7Ozs7RUFnQnhCLE9BQU8sbUJBQW1CLE9BQU8sZ0JBQWdCLFVBQVUsVUFBVSxNQUFNLFFBQVE7R0FDL0UsSUFBSSxjQUFjLElBQUksWUFBWSxPQUFPLGdCQUFnQixHQUFHLE1BQU07R0FFbEUsSUFBSSxhQUFhLElBQUksUUFBUTtHQUM3QixJQUFJLGVBQWUsSUFBSSxhQUFhLFVBQVUsVUFBVSxJQUFJO0dBQzVELFlBQVksWUFBWSxZQUFZO0dBRXBDLElBQUksYUFBYSxJQUFJLFdBQVcsUUFBUTtHQUN4QyxXQUFXLGNBQWMsV0FBVyxpQkFBaUIsTUFBTTtHQUMzRCxZQUFZLFlBQVksVUFBVTtHQUVsQyxJQUFJLGNBQWMsSUFBSSxZQUFZLFVBQVU7R0FDNUMsWUFBWSxjQUFjLFlBQVksZ0JBQWdCLE1BQU07R0FDNUQsWUFBWSxZQUFZLFdBQVc7R0FFbkMsT0FBTyxZQUFZLE1BQU07RUFDN0I7Ozs7Ozs7Ozs7Ozs7O0VBZUEsT0FBTyxlQUFlLE9BQU8sZ0JBQWdCLFVBQVUsUUFBUTtHQUMzRCxJQUFJLGNBQWMsSUFBSSxZQUFZLE9BQU8sZ0JBQWdCLEdBQUcsTUFBTTtHQUNsRSxJQUFJLGVBQWUsSUFBSSxhQUFhLElBQUksUUFBUTtHQUNoRCxhQUFhLGNBQWMsYUFBYSxnQkFBZ0IsTUFBTTtHQUM5RCxZQUFZLFlBQVksWUFBWTtHQUVwQyxPQUFPLFlBQVksTUFBTTtFQUM3Qjs7Ozs7Ozs7Ozs7OztFQWNBLE9BQU8sY0FBYyxPQUFPLGdCQUFnQixRQUFRO0dBQ2hELElBQUksY0FBYyxJQUFJLFlBQVksT0FBTyxnQkFBZ0IsR0FBRyxNQUFNO0dBQ2xFLElBQUksZUFBZSxJQUFJLGFBQWE7R0FDcEMsYUFBYSxjQUFjLGFBQWEsZUFBZSxNQUFNO0dBQzdELFlBQVksWUFBWSxZQUFZO0dBRXBDLE9BQU8sWUFBWSxNQUFNO0VBQzdCO0NBQ0o7Q0FFQSxPQUFPLFFBQVEsd0JBQXdCOzs7OztDQ3JGdkMsSUFBTSxjQUFBLHFCQUFBLENBQUEsQ0FBNkM7Q0FDbkQsSUFBTSxhQUFBLHFCQUFBLENBQUEsQ0FBNEM7Q0FFbEQsSUFBTSxrQkFBTixNQUFzQjs7Ozs7Ozs7O0VBU2xCLE9BQU8sV0FBVyxPQUFPLGdCQUFnQjtHQUNyQyxJQUFJLFFBQVEsSUFBSSxZQUFZLE9BQU8sZ0JBQWdCLEdBQUcsS0FBUztHQUUvRCxJQUFJLGFBQWEsSUFBSSxXQUFXO0dBQ2hDLFdBQVcsY0FBYyxXQUFXLGlCQUFpQixDQUFDO0dBQ3RELE1BQU0sWUFBWSxVQUFVO0dBRTVCLE9BQU8sTUFBTSxNQUFNO0VBQ3ZCO0NBQ0o7Q0FFQSxPQUFPLFFBQVEsa0JBQWtCOzs7OztDQ3ZCakMsSUFBTSxjQUFBLHFCQUFBLENBQUEsQ0FBNkM7Q0FDbkQsSUFBTSxhQUFBLHFCQUFBLENBQUEsQ0FBNEM7Q0FDbEQsSUFBTSxjQUFBLHFCQUFBLENBQUEsQ0FBNkM7Q0FFbkQsSUFBTSxrQkFBTixNQUFzQjs7Ozs7Ozs7Ozs7Ozs7O0VBZWxCLE9BQU8sV0FBVyxPQUFPLGdCQUFnQixRQUFRLFFBQVE7R0FDckQsSUFBSSxRQUFRLElBQUksWUFBWSxPQUFPLGdCQUFnQixNQUFNLE1BQU07R0FFL0QsSUFBSSxhQUFhLElBQUksV0FBVyxNQUFNO0dBQ3RDLFdBQVcsY0FBYyxXQUFXLGlCQUFpQixNQUFNO0dBQzNELE1BQU0sWUFBWSxVQUFVO0dBRTVCLE9BQU8sTUFBTSxNQUFNO0VBQ3ZCOzs7Ozs7Ozs7Ozs7OztFQWVBLE9BQU8sMEJBQTBCLE9BQU8sZ0JBQWdCLFFBQVEsYUFBYSxRQUFRO0dBQ2pGLE1BQU0sUUFBUSxJQUFJLFlBQVksT0FBTyxnQkFBZ0IsTUFBTSxNQUFNO0dBQ2pFLE1BQU0sY0FBYyxJQUFJLFlBQVksUUFBUSxXQUFXO0dBQ3ZELFlBQVksY0FBYyxZQUFZLGlCQUFpQixNQUFNO0dBQzdELE1BQU0sWUFBWSxXQUFXO0dBQzdCLE9BQU8sTUFBTSxNQUFNO0VBQ3ZCO0NBQ0o7Q0FFQSxPQUFPLFFBQVEsa0JBQWtCOzs7OztDQ25EakMsSUFBTSxjQUFBLHFCQUFBLENBQUEsQ0FBNkM7Q0FDbkQsSUFBTSxhQUFBLHFCQUFBLENBQUEsQ0FBNEM7Q0FDbEQsSUFBTSxhQUFBLHFCQUFBLENBQUEsQ0FBNEM7Q0FDbEQsSUFBTSxhQUFBLHFCQUFBLENBQUEsQ0FBNEM7Q0FDbEQsSUFBTSxPQUFBLHlCQUFBLENBQUEsQ0FBMEM7Q0FFaEQsSUFBTSxrQkFBTixNQUFzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBd0JsQixPQUFPLFdBQ0gsT0FDQSxnQkFDQSxhQUNBLFlBQ0EsU0FDQSxnQkFDQSw0QkFDQSx5QkFDQSx5QkFDQSw4QkFDQSxXQUNBLGdCQUNGO0dBQ0UsTUFBTSxRQUFRLElBQUksWUFBWSxPQUFPLGdCQUFnQixHQUFHLGNBQWM7R0FFdEUsTUFBTSxhQUFhLElBQUksV0FBVyxhQUFhLFVBQVU7R0FDekQsV0FBVyxjQUFjLFdBQVcsdUJBQXVCLDBCQUEwQjtHQUNyRixJQUFJLFlBQVksS0FBSyxXQUFXO0lBQzVCLFdBQVcsY0FBYyxXQUFXLDhCQUE4Qix1QkFBdUI7SUFDekYsV0FBVyxjQUFjLFdBQVcsOEJBQThCLHVCQUF1QjtJQUN6RixXQUFXLGNBQWMsV0FBVyw2QkFBNkIsNEJBQTRCO0dBQ2pHO0dBQ0EsTUFBTSxZQUFZLFVBQVU7R0FFNUIsTUFBTSxhQUFhLElBQUksV0FBVyxTQUFTO0dBQzNDLFdBQVcsY0FBYyxXQUFXLGlCQUFpQixjQUFjO0dBQ25FLE1BQU0sWUFBWSxVQUFVO0dBRTVCLE1BQU0sWUFBWSxJQUFJLFdBQVcsQ0FBQztHQUVsQyxPQUFPLE1BQU0sTUFBTTtFQUN2QjtDQUNKO0NBRUEsT0FBTyxVQUFVLEVBQ2IsZ0JBQ0o7Ozs7O0NDbkVBLE9BQU8sVUFBVTtFQUNiLG1CQUFBLDBCQUFBLENBQUEsQ0FBc0Q7RUFDdEQsa0JBQUEseUJBQUEsQ0FBQSxDQUFvRDtFQUNwRCxxQkFBQSw0QkFBQSxDQUFBLENBQTBEO0VBQzFELHVCQUFBLDhCQUFBLENBQUEsQ0FBOEQ7RUFDOUQsaUJBQUEsd0JBQUEsQ0FBQSxDQUFrRDtFQUNsRCxTQUFBLHlCQUFBLENBQUEsQ0FBMkM7RUFDM0MsaUJBQUEseUJBQUEsQ0FBQSxDQUFtRDtFQUNuRCxpQkFBQSx5QkFBQSxDQUFBLENBQW1EO0VBQ25ELGlCQUFBLHFCQUFBLENBQUEsQ0FBK0M7RUFDL0MsaUJBQUEsd0JBQUEsQ0FBQSxDQUFrRDtDQUN0RCIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDYsNyw4LDksMTAsMTEsMTIsMTMsMTQsMTVdfQ==