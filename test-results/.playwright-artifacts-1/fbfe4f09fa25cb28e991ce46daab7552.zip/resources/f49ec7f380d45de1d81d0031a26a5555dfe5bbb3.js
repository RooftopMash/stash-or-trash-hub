import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/hooks/useAuth.tsx");const createContext = __vite__cjsImport0_react["createContext"]; const useContext = __vite__cjsImport0_react["useContext"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { onAuthStateChanged, signOut as fbSignOut } from "/node_modules/.vite/deps/firebase_auth.js?v=a8030269";
import { doc, getDoc, setDoc, serverTimestamp } from "/node_modules/.vite/deps/firebase_firestore.js?v=a8030269";
import { auth, db } from "/src/lib/firebase.ts";
var _jsxFileName = "/app/applet/src/hooks/useAuth.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const AuthContext = createContext(undefined);
_c = AuthContext;
const LOCAL_FALLBACK_AUTH_KEY = "sot_fallback_auth_user_v1";
function readLocalFallbackUser() {
	if (typeof window === "undefined") return null;
	try {
		const raw = window.localStorage.getItem(LOCAL_FALLBACK_AUTH_KEY);
		return raw ? JSON.parse(raw) : null;
	} catch {
		return null;
	}
}
function writeLocalFallbackUser(user) {
	if (typeof window === "undefined") return;
	try {
		if (user) {
			window.localStorage.setItem(LOCAL_FALLBACK_AUTH_KEY, JSON.stringify(user));
		} else {
			window.localStorage.removeItem(LOCAL_FALLBACK_AUTH_KEY);
		}
	} catch {}
}
function mapFirebaseUser(user) {
	return {
		id: user.uid,
		uid: user.uid,
		email: user.email,
		displayName: user.displayName,
		photoURL: user.photoURL,
		user_metadata: {
			display_name: user.displayName || user.email?.split("@")[0] || "User",
			avatar_url: user.photoURL || undefined
		}
	};
}
export function AuthProvider({ children }) {
	_s();
	const [firebaseUser, setFirebaseUser] = useState(null);
	const [user, setUser] = useState(() => readLocalFallbackUser());
	const [loading, setLoading] = useState(true);
	useEffect(() => {
		const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
			setFirebaseUser(fbUser);
			if (fbUser) {
				const mapped = mapFirebaseUser(fbUser);
				writeLocalFallbackUser(null);
				setUser(mapped);
				// Sync user profile to Firestore
				try {
					const userRef = doc(db, "users", fbUser.uid);
					const snap = await getDoc(userRef);
					if (!snap.exists()) {
						const initPayload = {
							id: fbUser.uid,
							displayName: (fbUser.displayName || fbUser.email?.split("@")[0] || "User").slice(0, 100),
							createdAt: serverTimestamp(),
							updatedAt: serverTimestamp()
						};
						if (fbUser.email) initPayload.email = fbUser.email;
						if (fbUser.photoURL) initPayload.avatarUrl = fbUser.photoURL.slice(0, 500);
						await setDoc(userRef, initPayload);
					}
				} catch {}
			} else {
				const localUser = readLocalFallbackUser();
				setUser(localUser);
			}
			setLoading(false);
		});
		const handleProfileUpdated = (event) => {
			const custom = event;
			const detail = custom.detail;
			if (!detail?.id) return;
			setUser((prev) => {
				if (!prev || prev.id !== detail.id) return prev;
				const nextName = detail.display_name || prev.displayName;
				const nextPhoto = detail.avatar_url !== undefined ? detail.avatar_url : prev.photoURL;
				const updated = {
					...prev,
					displayName: nextName,
					photoURL: nextPhoto,
					user_metadata: {
						...prev.user_metadata,
						display_name: nextName || prev.user_metadata.display_name,
						avatar_url: nextPhoto || undefined
					}
				};
				if (readLocalFallbackUser()?.id === prev.id) {
					writeLocalFallbackUser(updated);
				}
				return updated;
			});
		};
		window.addEventListener("sot-profile-updated", handleProfileUpdated);
		return () => {
			unsubscribe();
			window.removeEventListener("sot-profile-updated", handleProfileUpdated);
		};
	}, []);
	const signInWithLocalFallback = ({ email, displayName }) => {
		const cleanEmail = email.trim().toLowerCase();
		const safeSlug = cleanEmail.replace(/[^a-z0-9]/g, "_").slice(0, 48) || "member";
		const resolvedName = displayName?.trim() || cleanEmail.split("@")[0] || "Verified SOT Member";
		const fallbackUser = {
			id: `sot_user_${safeSlug}`,
			uid: `sot_user_${safeSlug}`,
			email: cleanEmail,
			displayName: resolvedName,
			photoURL: null,
			user_metadata: { display_name: resolvedName }
		};
		writeLocalFallbackUser(fallbackUser);
		setUser(fallbackUser);
		return fallbackUser;
	};
	const value = {
		user,
		firebaseUser,
		session: user ? { user } : null,
		loading,
		signInWithLocalFallback,
		signOut: async () => {
			writeLocalFallbackUser(null);
			setUser(null);
			await fbSignOut(auth).catch(() => {});
		}
	};
	return /* @__PURE__ */ _jsxDEV(AuthContext.Provider, {
		value,
		"data-tsd-source": "/src/hooks/useAuth.tsx:181:10",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 181,
		columnNumber: 10
	}, this);
}
_s(AuthProvider, "e4st406tIO72uPlepog6yx/GV18=");
_c2 = AuthProvider;
export function useAuth() {
	_s2();
	const ctx = useContext(AuthContext);
	if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
	return ctx;
}
_s2(useAuth, "/dMy7t63NXD4eYACoT93CePwGrg=");
var _c, _c2;
$RefreshReg$(_c, "AuthContext");
$RefreshReg$(_c2, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/hooks/useAuth.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/hooks/useAuth.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/hooks/useAuth.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/hooks/useAuth.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7Ozs7QUF1QkE7O0FBQ0E7QUFFQTtDQUNBO0NBQ0E7RUFDQTtFQUNBO0NBQ0E7RUFDQTtDQUNBO0FBQ0E7QUFFQTtDQUNBO0NBQ0E7RUFDQTtHQUNBO0VBQ0E7R0FDQTtFQUNBO0NBQ0EsU0FFQTtBQUNBO0FBRUE7Q0FDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtHQUNBO0dBQ0E7RUFDQTtDQUNBO0FBQ0E7QUFFQTs7Q0FDQTtDQUNBO0NBQ0E7Q0FFQTtFQUNBO0dBQ0E7R0FDQTtJQUNBO0lBQ0E7SUFDQTs7SUFHQTtLQUNBO0tBQ0E7S0FDQTtNQUNBO09BQ0E7T0FDQTtPQUNBO09BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtLQUNBO0lBQ0EsU0FFQTtHQUNBO0lBQ0E7SUFDQTtHQUNBO0dBQ0E7RUFDQTtFQUVBO0dBQ0E7R0FLQTtHQUNBO0dBQ0E7SUFDQTtJQUNBO0lBQ0Esa0JBQ0E7SUFDQTtLQUNBO0tBQ0E7S0FDQTtLQUNBO01BQ0E7TUFDQTtNQUNBO0tBQ0E7SUFDQTtJQUNBO0tBQ0E7SUFDQTtJQUNBO0dBQ0E7RUFDQTtFQUVBO0VBQ0E7R0FDQTtHQUNBO0VBQ0E7Q0FDQTtDQUVBLG1DQUNBLE9BQ0Esa0JBSUE7RUFDQTtFQUNBO0VBQ0EscUJBQ0E7RUFDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQSxpQkFDQSwyQkFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0E7Q0FFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtHQUNBO0dBQ0E7R0FDQTtFQUNBO0NBQ0E7Q0FFQTtFQUFBO0VBQUE7RUFBNEM7Q0FBQTs7Ozs7QUFDNUM7OztBQUVBOztDQUNBO0NBQ0E7Q0FDQTtBQUNBIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJ1c2VBdXRoLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZVN0YXRlLCB0eXBlIFJlYWN0Tm9kZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgb25BdXRoU3RhdGVDaGFuZ2VkLCBzaWduT3V0IGFzIGZiU2lnbk91dCwgdHlwZSBVc2VyIGFzIEZpcmViYXNlVXNlciB9IGZyb20gXCJmaXJlYmFzZS9hdXRoXCI7XG5pbXBvcnQgeyBkb2MsIGdldERvYywgc2V0RG9jLCBzZXJ2ZXJUaW1lc3RhbXAgfSBmcm9tIFwiZmlyZWJhc2UvZmlyZXN0b3JlXCI7XG5pbXBvcnQgeyBhdXRoLCBkYiB9IGZyb20gXCJAL2xpYi9maXJlYmFzZVwiO1xuXG5leHBvcnQgdHlwZSBBdXRoVXNlciA9IHtcbiAgaWQ6IHN0cmluZztcbiAgdWlkOiBzdHJpbmc7XG4gIGVtYWlsOiBzdHJpbmcgfCBudWxsO1xuICBkaXNwbGF5TmFtZTogc3RyaW5nIHwgbnVsbDtcbiAgcGhvdG9VUkw6IHN0cmluZyB8IG51bGw7XG4gIHVzZXJfbWV0YWRhdGE6IHtcbiAgICBkaXNwbGF5X25hbWU/OiBzdHJpbmc7XG4gICAgYXZhdGFyX3VybD86IHN0cmluZztcbiAgfTtcbn07XG5cbnR5cGUgQXV0aENvbnRleHRWYWx1ZSA9IHtcbiAgdXNlcjogQXV0aFVzZXIgfCBudWxsO1xuICBmaXJlYmFzZVVzZXI6IEZpcmViYXNlVXNlciB8IG51bGw7XG4gIHNlc3Npb246IHsgdXNlcjogQXV0aFVzZXIgfSB8IG51bGw7XG4gIGxvYWRpbmc6IGJvb2xlYW47XG4gIHNpZ25JbldpdGhMb2NhbEZhbGxiYWNrOiAocGFyYW1zOiB7IGVtYWlsOiBzdHJpbmc7IGRpc3BsYXlOYW1lPzogc3RyaW5nIH0pID0+IEF1dGhVc2VyO1xuICBzaWduT3V0OiAoKSA9PiBQcm9taXNlPHZvaWQ+O1xufTtcblxuY29uc3QgQXV0aENvbnRleHQgPSBjcmVhdGVDb250ZXh0PEF1dGhDb250ZXh0VmFsdWUgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG5jb25zdCBMT0NBTF9GQUxMQkFDS19BVVRIX0tFWSA9IFwic290X2ZhbGxiYWNrX2F1dGhfdXNlcl92MVwiO1xuXG5mdW5jdGlvbiByZWFkTG9jYWxGYWxsYmFja1VzZXIoKTogQXV0aFVzZXIgfCBudWxsIHtcbiAgaWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBudWxsO1xuICB0cnkge1xuICAgIGNvbnN0IHJhdyA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShMT0NBTF9GQUxMQkFDS19BVVRIX0tFWSk7XG4gICAgcmV0dXJuIHJhdyA/IChKU09OLnBhcnNlKHJhdykgYXMgQXV0aFVzZXIpIDogbnVsbDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuZnVuY3Rpb24gd3JpdGVMb2NhbEZhbGxiYWNrVXNlcih1c2VyOiBBdXRoVXNlciB8IG51bGwpIHtcbiAgaWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybjtcbiAgdHJ5IHtcbiAgICBpZiAodXNlcikge1xuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKExPQ0FMX0ZBTExCQUNLX0FVVEhfS0VZLCBKU09OLnN0cmluZ2lmeSh1c2VyKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShMT0NBTF9GQUxMQkFDS19BVVRIX0tFWSk7XG4gICAgfVxuICB9IGNhdGNoIHtcbiAgICAvLyBpZ25vcmUgc3RvcmFnZSBlcnJvcnNcbiAgfVxufVxuXG5mdW5jdGlvbiBtYXBGaXJlYmFzZVVzZXIodXNlcjogRmlyZWJhc2VVc2VyKTogQXV0aFVzZXIge1xuICByZXR1cm4ge1xuICAgIGlkOiB1c2VyLnVpZCxcbiAgICB1aWQ6IHVzZXIudWlkLFxuICAgIGVtYWlsOiB1c2VyLmVtYWlsLFxuICAgIGRpc3BsYXlOYW1lOiB1c2VyLmRpc3BsYXlOYW1lLFxuICAgIHBob3RvVVJMOiB1c2VyLnBob3RvVVJMLFxuICAgIHVzZXJfbWV0YWRhdGE6IHtcbiAgICAgIGRpc3BsYXlfbmFtZTogdXNlci5kaXNwbGF5TmFtZSB8fCB1c2VyLmVtYWlsPy5zcGxpdChcIkBcIilbMF0gfHwgXCJVc2VyXCIsXG4gICAgICBhdmF0YXJfdXJsOiB1c2VyLnBob3RvVVJMIHx8IHVuZGVmaW5lZCxcbiAgICB9LFxuICB9O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQXV0aFByb3ZpZGVyKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbjogUmVhY3ROb2RlIH0pIHtcbiAgY29uc3QgW2ZpcmViYXNlVXNlciwgc2V0RmlyZWJhc2VVc2VyXSA9IHVzZVN0YXRlPEZpcmViYXNlVXNlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZTxBdXRoVXNlciB8IG51bGw+KCgpID0+IHJlYWRMb2NhbEZhbGxiYWNrVXNlcigpKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCB1bnN1YnNjcmliZSA9IG9uQXV0aFN0YXRlQ2hhbmdlZChhdXRoLCBhc3luYyAoZmJVc2VyKSA9PiB7XG4gICAgICBzZXRGaXJlYmFzZVVzZXIoZmJVc2VyKTtcbiAgICAgIGlmIChmYlVzZXIpIHtcbiAgICAgICAgY29uc3QgbWFwcGVkID0gbWFwRmlyZWJhc2VVc2VyKGZiVXNlcik7XG4gICAgICAgIHdyaXRlTG9jYWxGYWxsYmFja1VzZXIobnVsbCk7XG4gICAgICAgIHNldFVzZXIobWFwcGVkKTtcblxuICAgICAgICAvLyBTeW5jIHVzZXIgcHJvZmlsZSB0byBGaXJlc3RvcmVcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCB1c2VyUmVmID0gZG9jKGRiLCBcInVzZXJzXCIsIGZiVXNlci51aWQpO1xuICAgICAgICAgIGNvbnN0IHNuYXAgPSBhd2FpdCBnZXREb2ModXNlclJlZik7XG4gICAgICAgICAgaWYgKCFzbmFwLmV4aXN0cygpKSB7XG4gICAgICAgICAgICBjb25zdCBpbml0UGF5bG9hZDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7XG4gICAgICAgICAgICAgIGlkOiBmYlVzZXIudWlkLFxuICAgICAgICAgICAgICBkaXNwbGF5TmFtZTogKGZiVXNlci5kaXNwbGF5TmFtZSB8fCBmYlVzZXIuZW1haWw/LnNwbGl0KFwiQFwiKVswXSB8fCBcIlVzZXJcIikuc2xpY2UoMCwgMTAwKSxcbiAgICAgICAgICAgICAgY3JlYXRlZEF0OiBzZXJ2ZXJUaW1lc3RhbXAoKSxcbiAgICAgICAgICAgICAgdXBkYXRlZEF0OiBzZXJ2ZXJUaW1lc3RhbXAoKSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBpZiAoZmJVc2VyLmVtYWlsKSBpbml0UGF5bG9hZC5lbWFpbCA9IGZiVXNlci5lbWFpbDtcbiAgICAgICAgICAgIGlmIChmYlVzZXIucGhvdG9VUkwpIGluaXRQYXlsb2FkLmF2YXRhclVybCA9IGZiVXNlci5waG90b1VSTC5zbGljZSgwLCA1MDApO1xuICAgICAgICAgICAgYXdhaXQgc2V0RG9jKHVzZXJSZWYsIGluaXRQYXlsb2FkKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8vIElmIGZpcmVzdG9yZSBydWxlIG9yIG5ldHdvcmsgcmVzdHJpY3RzIGluaXRpYWwgcHJvZmlsZSB3cml0ZSwgZG9uJ3QgYmxvY2sgYXV0aCBzdGF0ZVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBsb2NhbFVzZXIgPSByZWFkTG9jYWxGYWxsYmFja1VzZXIoKTtcbiAgICAgICAgc2V0VXNlcihsb2NhbFVzZXIpO1xuICAgICAgfVxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgfSk7XG5cbiAgICBjb25zdCBoYW5kbGVQcm9maWxlVXBkYXRlZCA9IChldmVudDogRXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IGN1c3RvbSA9IGV2ZW50IGFzIEN1c3RvbUV2ZW50PHtcbiAgICAgICAgaWQ6IHN0cmluZztcbiAgICAgICAgZGlzcGxheV9uYW1lPzogc3RyaW5nO1xuICAgICAgICBhdmF0YXJfdXJsPzogc3RyaW5nIHwgbnVsbDtcbiAgICAgIH0+O1xuICAgICAgY29uc3QgZGV0YWlsID0gY3VzdG9tLmRldGFpbDtcbiAgICAgIGlmICghZGV0YWlsPy5pZCkgcmV0dXJuO1xuICAgICAgc2V0VXNlcigocHJldikgPT4ge1xuICAgICAgICBpZiAoIXByZXYgfHwgcHJldi5pZCAhPT0gZGV0YWlsLmlkKSByZXR1cm4gcHJldjtcbiAgICAgICAgY29uc3QgbmV4dE5hbWUgPSBkZXRhaWwuZGlzcGxheV9uYW1lIHx8IHByZXYuZGlzcGxheU5hbWU7XG4gICAgICAgIGNvbnN0IG5leHRQaG90byA9XG4gICAgICAgICAgZGV0YWlsLmF2YXRhcl91cmwgIT09IHVuZGVmaW5lZCA/IGRldGFpbC5hdmF0YXJfdXJsIDogcHJldi5waG90b1VSTDtcbiAgICAgICAgY29uc3QgdXBkYXRlZDogQXV0aFVzZXIgPSB7XG4gICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICBkaXNwbGF5TmFtZTogbmV4dE5hbWUsXG4gICAgICAgICAgcGhvdG9VUkw6IG5leHRQaG90byxcbiAgICAgICAgICB1c2VyX21ldGFkYXRhOiB7XG4gICAgICAgICAgICAuLi5wcmV2LnVzZXJfbWV0YWRhdGEsXG4gICAgICAgICAgICBkaXNwbGF5X25hbWU6IG5leHROYW1lIHx8IHByZXYudXNlcl9tZXRhZGF0YS5kaXNwbGF5X25hbWUsXG4gICAgICAgICAgICBhdmF0YXJfdXJsOiBuZXh0UGhvdG8gfHwgdW5kZWZpbmVkLFxuICAgICAgICAgIH0sXG4gICAgICAgIH07XG4gICAgICAgIGlmIChyZWFkTG9jYWxGYWxsYmFja1VzZXIoKT8uaWQgPT09IHByZXYuaWQpIHtcbiAgICAgICAgICB3cml0ZUxvY2FsRmFsbGJhY2tVc2VyKHVwZGF0ZWQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB1cGRhdGVkO1xuICAgICAgfSk7XG4gICAgfTtcblxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwic290LXByb2ZpbGUtdXBkYXRlZFwiLCBoYW5kbGVQcm9maWxlVXBkYXRlZCk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHVuc3Vic2NyaWJlKCk7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInNvdC1wcm9maWxlLXVwZGF0ZWRcIiwgaGFuZGxlUHJvZmlsZVVwZGF0ZWQpO1xuICAgIH07XG4gIH0sIFtdKTtcblxuICBjb25zdCBzaWduSW5XaXRoTG9jYWxGYWxsYmFjayA9ICh7XG4gICAgZW1haWwsXG4gICAgZGlzcGxheU5hbWUsXG4gIH06IHtcbiAgICBlbWFpbDogc3RyaW5nO1xuICAgIGRpc3BsYXlOYW1lPzogc3RyaW5nO1xuICB9KTogQXV0aFVzZXIgPT4ge1xuICAgIGNvbnN0IGNsZWFuRW1haWwgPSBlbWFpbC50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICBjb25zdCBzYWZlU2x1ZyA9IGNsZWFuRW1haWwucmVwbGFjZSgvW15hLXowLTldL2csIFwiX1wiKS5zbGljZSgwLCA0OCkgfHwgXCJtZW1iZXJcIjtcbiAgICBjb25zdCByZXNvbHZlZE5hbWUgPVxuICAgICAgZGlzcGxheU5hbWU/LnRyaW0oKSB8fCBjbGVhbkVtYWlsLnNwbGl0KFwiQFwiKVswXSB8fCBcIlZlcmlmaWVkIFNPVCBNZW1iZXJcIjtcbiAgICBjb25zdCBmYWxsYmFja1VzZXI6IEF1dGhVc2VyID0ge1xuICAgICAgaWQ6IGBzb3RfdXNlcl8ke3NhZmVTbHVnfWAsXG4gICAgICB1aWQ6IGBzb3RfdXNlcl8ke3NhZmVTbHVnfWAsXG4gICAgICBlbWFpbDogY2xlYW5FbWFpbCxcbiAgICAgIGRpc3BsYXlOYW1lOiByZXNvbHZlZE5hbWUsXG4gICAgICBwaG90b1VSTDogbnVsbCxcbiAgICAgIHVzZXJfbWV0YWRhdGE6IHtcbiAgICAgICAgZGlzcGxheV9uYW1lOiByZXNvbHZlZE5hbWUsXG4gICAgICB9LFxuICAgIH07XG4gICAgd3JpdGVMb2NhbEZhbGxiYWNrVXNlcihmYWxsYmFja1VzZXIpO1xuICAgIHNldFVzZXIoZmFsbGJhY2tVc2VyKTtcbiAgICByZXR1cm4gZmFsbGJhY2tVc2VyO1xuICB9O1xuXG4gIGNvbnN0IHZhbHVlOiBBdXRoQ29udGV4dFZhbHVlID0ge1xuICAgIHVzZXIsXG4gICAgZmlyZWJhc2VVc2VyLFxuICAgIHNlc3Npb246IHVzZXIgPyB7IHVzZXIgfSA6IG51bGwsXG4gICAgbG9hZGluZyxcbiAgICBzaWduSW5XaXRoTG9jYWxGYWxsYmFjayxcbiAgICBzaWduT3V0OiBhc3luYyAoKSA9PiB7XG4gICAgICB3cml0ZUxvY2FsRmFsbGJhY2tVc2VyKG51bGwpO1xuICAgICAgc2V0VXNlcihudWxsKTtcbiAgICAgIGF3YWl0IGZiU2lnbk91dChhdXRoKS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgfSxcbiAgfTtcblxuICByZXR1cm4gPEF1dGhDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt2YWx1ZX0+e2NoaWxkcmVufTwvQXV0aENvbnRleHQuUHJvdmlkZXI+O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlQXV0aCgpIHtcbiAgY29uc3QgY3R4ID0gdXNlQ29udGV4dChBdXRoQ29udGV4dCk7XG4gIGlmICghY3R4KSB0aHJvdyBuZXcgRXJyb3IoXCJ1c2VBdXRoIG11c3QgYmUgdXNlZCB3aXRoaW4gYW4gQXV0aFByb3ZpZGVyXCIpO1xuICByZXR1cm4gY3R4O1xufVxuIl0sImZpbGUiOiIvYXBwL2FwcGxldC9zcmMvaG9va3MvdXNlQXV0aC50c3gifQ==