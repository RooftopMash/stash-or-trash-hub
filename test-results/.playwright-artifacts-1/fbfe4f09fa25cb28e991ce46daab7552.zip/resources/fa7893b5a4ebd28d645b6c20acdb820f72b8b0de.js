import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/awards.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"];const useMemo = __vite__cjsImport4_react["useMemo"]; const useState = __vite__cjsImport4_react["useState"];var _jsxFileName = "/app/applet/src/routes/awards.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=a8030269";
var _s = $RefreshSig$();
console.warn("[tanstack-router] These exports from \"/app/applet/src/routes/awards.tsx\" will not be code-split and will increase your bundle size:\n- AwardsPage\nFor the best optimization, these items should either have their export statements removed, or be imported from another location that is not a route file.");
import { createFileRoute, Link } from "/node_modules/@tanstack/react-router/dist/esm/index.dev.js?v=a8030269";
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=a8030269";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=a8030269";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=a8030269";
import { Header } from "/src/components/Header.tsx";
import { fetchBrands } from "/src/lib/brands.ts";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
import { Award, CalendarClock, CheckCircle2, Crown, Heart, Map, Search, Sparkles, TrendingUp, Trophy, Car, Utensils, Laptop, ShoppingBag, Shirt, Building2, ShieldCheck, Vote, Lock, Radio, Users, Landmark, Briefcase, Check, FileCheck2, Video } from "/node_modules/.vite/deps/lucide-react.js?v=a8030269";
import { brandCategory, categoryOptions } from "/src/lib/categories.ts";
import { countryName, countryOptions, normalizeCountryCode } from "/src/lib/geo.ts";
import { cn } from "/src/lib/utils.ts";
import { PeopleTrustFactorLink } from "/src/components/PeopleTrustFactor.tsx";
import { BRAND_TIERS, getBrandTier, getTierInfo, matchesTier } from "/src/lib/brandTiers.ts";
import { LiveBroadcastModal } from "/src/components/LiveBroadcastModal.tsx";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=a8030269";
export const Route = createFileRoute("/awards")({
	head: () => ({ meta: [
		{ title: "The SOT Awards & Verified Voting | Stash Or Trash — The Brand Barometer" },
		{
			name: "description",
			content: "The annual SOT Awards and Verified Institutional Voting Infrastructure — powering consumer brand verdicts, trade union ballots, awards ceremonies, and office governance."
		},
		{
			property: "og:title",
			content: "The SOT Awards & Verified Voting — The People's Verdict, Made Official"
		},
		{
			property: "og:description",
			content: "The most trusted brands and verified institutional ballots, crowned by real people. Explore the live leaderboard and institutional voting chambers."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: AwardsPage
});
const INITIAL_INSTITUTIONAL_BALLOTS = [
	{
		id: "ballot-union-2026",
		category: "Trade Union Ballot",
		organization: "National Workers & Trade Union Federation (COSATU / Affiliates Standard)",
		title: "2026 Collective Wage Mandate & Shop Steward Ratification",
		description: "Auditable 1-Member-1-Vote digital ballot for registered union members. Eliminates paper ballot tampering and provides real-time cryptographic tallying.",
		verificationStandard: "Verified Member ID + Device Fingerprint + SHA-256 Receipt",
		closingDate: "Closes in 4 days",
		totalVerifiedVotes: 14820,
		options: [{
			id: "opt-u1",
			label: "Stash Mandate A: Accept 8.5% Multi-Year Wage Settlement + Housing Allowance",
			subtitle: "Endorsed by Regional Bargaining Council Negotiators",
			votes: 9410
		}, {
			id: "opt-u2",
			label: "Trash Settlement: Reject Offer & Maintain Secondary Dispute Mediation",
			subtitle: "Proceed to formal CCMA / Labour Dispute resolution window",
			votes: 5410
		}]
	},
	{
		id: "ballot-gov-awards-2026",
		category: "National Awards Ceremony",
		organization: "SA Consumer Quality & Public Service Excellence Awards",
		title: "Most Accountable Consumer Ombudsman & Regulatory Partner of the Year",
		description: "Public & industry recognition celebrating regulatory bodies and consumer protection frameworks that empower citizens and protect genuine brands from counterfeit goods.",
		verificationStandard: "Verified Citizen Trust Barometer + Anti-Bot Proof",
		closingDate: "Live Ceremony Snapshot Active",
		totalVerifiedVotes: 28490,
		options: [{
			id: "opt-a1",
			label: "Consumer Goods & Services Ombud (CGSO) — CPA Section 69 Mediation",
			subtitle: "Recognised for free consumer dispute resolution & industry code enforcement",
			votes: 16240
		}, {
			id: "opt-a2",
			label: "National Consumer Commission (NCC) — Product Safety & Recall Division",
			subtitle: "Recognised for national compliance, counterfeit seizures & consumer awareness",
			votes: 12250
		}]
	},
	{
		id: "ballot-office-agm-2026",
		category: "Office & Corporate Poll",
		organization: "Enterprise Workplace & Employee Representative Council",
		title: "Q4 Hybrid Work Policy & Anti-Counterfeit Supply Chain Charter",
		description: "Internal corporate governance and workplace resolution vote powered by Stash or Trash's tamper-evident Trust Bar architecture.",
		verificationStandard: "Corporate SSO / Verified Workplace Email",
		closingDate: "Closes in 48 hours",
		totalVerifiedVotes: 3190,
		options: [{
			id: "opt-c1",
			label: "Approve Charter: 3-Day Hybrid Model + 100% Batch-Verified Supplier Mandate",
			subtitle: "Includes mandatory SOT barcode authenticity verification for all procured goods",
			votes: 2640
		}, {
			id: "opt-c2",
			label: "Defer to Committee: Request 30-Day Departmental Review",
			subtitle: "Extend consultation with regional branch offices",
			votes: 550
		}]
	}
];
export function AwardsPage() {
	_s();
	const { t } = useTranslation();
	const { data: brands, isLoading } = useQuery({
		queryKey: ["brands"],
		queryFn: fetchBrands
	});
	const [viewMode, setViewMode] = useState("industries");
	const [country, setCountry] = useState("All countries");
	const [category, setCategory] = useState("All categories");
	const [tier, setTier] = useState("All tiers");
	const [query, setQuery] = useState("");
	const [period, setPeriod] = useState("Live season");
	const snapshotTime = useMemo(() => new Date(), []);
	// Institutional Voting State (Strategy C Phase 3 & 4)
	const [ballots, setBallots] = useState(INITIAL_INSTITUTIONAL_BALLOTS);
	const [votedReceipts, setVotedReceipts] = useState({});
	const [liveObserverModalOpen, setLiveObserverModalOpen] = useState(false);
	const [activeObserverTopic, setActiveObserverTopic] = useState("SOT Institutional Ballot Observer Townhall");
	const [newBallotTitle, setNewBallotTitle] = useState("");
	const [newBallotOrg, setNewBallotOrg] = useState("");
	const [newBallotCategory, setNewBallotCategory] = useState("Trade Union Ballot");
	const handleCastInstitutionalVote = (ballotId, optionId) => {
		if (votedReceipts[ballotId]) {
			toast.info("Your verified 1-Person-1-Vote ballot is already locked with a cryptographic receipt.");
			return;
		}
		const randomHash = `SOT-SHA256-${Math.random().toString(36).substring(2, 8).toUpperCase()}-${Date.now().toString(36).toUpperCase()}`;
		setBallots((prev) => prev.map((b) => b.id !== ballotId ? b : {
			...b,
			totalVerifiedVotes: b.totalVerifiedVotes + 1,
			options: b.options.map((o) => o.id === optionId ? {
				...o,
				votes: o.votes + 1
			} : o)
		}));
		setVotedReceipts((prev) => ({
			...prev,
			[ballotId]: {
				optionId,
				hash: randomHash,
				timestamp: new Date().toLocaleTimeString()
			}
		}));
		toast.success(`Verified Ballot Recorded! Receipt: ${randomHash}`);
	};
	const handleCreateCustomBallot = (e) => {
		e.preventDefault();
		if (!newBallotTitle.trim() || !newBallotOrg.trim()) {
			toast.error("Please enter both the Organization/Union name and Motion Title.");
			return;
		}
		const created = {
			id: `ballot-custom-${Date.now()}`,
			category: newBallotCategory,
			organization: newBallotOrg.trim(),
			title: newBallotTitle.trim(),
			description: "Custom high-trust institutional ballot hosted on the Stash or Trash Verified Trust Barometer infrastructure.",
			verificationStandard: "1-Person-1-Vote Verified Identity + Auditable Hash Receipt",
			closingDate: "Closes in 7 days",
			totalVerifiedVotes: 1,
			options: [{
				id: `opt-yes-${Date.now()}`,
				label: "Stash (Approve / Ratify Motion)",
				subtitle: "Verified affirmative ballot in favor of the resolution",
				votes: 1
			}, {
				id: `opt-no-${Date.now()}`,
				label: "Trash (Reject / Challenge Motion)",
				subtitle: "Verified dissenting ballot requesting revision or mediation",
				votes: 0
			}]
		};
		setBallots((prev) => [created, ...prev]);
		setNewBallotTitle("");
		setNewBallotOrg("");
		toast.success("New Verified Institutional Ballot launched!");
	};
	const countries = useMemo(() => ["All countries", ...countryOptions((brands ?? []).map((brand) => brand.country))], [brands]);
	const categories = useMemo(() => categoryOptions((brands ?? []).map((brand) => brandCategory(brand.name, brand.category))), [brands]);
	// Scoped list
	const filteredBrands = useMemo(() => {
		const term = query.trim().toLowerCase();
		return (brands ?? []).filter((brand) => {
			const normalizedCountry = normalizeCountryCode(brand.country);
			const normalizedCategory = brandCategory(brand.name, brand.category);
			const brandTier = getBrandTier(brand.name, brand.category);
			const searchable = `${brand.name} ${countryName(normalizedCountry)} ${normalizedCategory} ${brandTier}`.toLowerCase();
			return (country === "All countries" || normalizedCountry === country) && (category === "All categories" || normalizedCategory === category) && (tier === "All tiers" || matchesTier(brandTier, tier)) && (!term || searchable.includes(term));
		}).sort((a, b) => (Number(b.trust_score) || 0) - (Number(a.trust_score) || 0));
	}, [
		brands,
		category,
		country,
		tier,
		query
	]);
	const top = filteredBrands.slice(0, 15);
	const regionLabel = country === "All countries" ? "Global awards" : `${countryName(country)} awards`;
	// Industry sectors (guaranteeing food never competes with cars)
	const industrySectors = useMemo(() => {
		const sectors = [
			{
				id: "automotive",
				title: "Automotive & Mobility",
				icon: Car,
				description: "Passenger vehicles, mobility tech, and electric transport. Cars compete strictly with cars.",
				match: (cat) => cat.toLowerCase().includes("auto") || cat.toLowerCase().includes("cars") || cat.toLowerCase().includes("mobility")
			},
			{
				id: "food",
				title: "Food, Grocery & Dining",
				icon: Utensils,
				description: "Restaurants, supermarkets, packaged staples, and beverage makers. Judged on taste, hygiene & value.",
				match: (cat) => cat.toLowerCase().includes("food") || cat.toLowerCase().includes("restaurant") || cat.toLowerCase().includes("staple") || cat.toLowerCase().includes("agriculture")
			},
			{
				id: "tech",
				title: "Technology & Software",
				icon: Laptop,
				description: "Consumer electronics, personal computing, web platforms, and essential digital apps.",
				match: (cat) => cat.toLowerCase().includes("tech") || cat.toLowerCase().includes("software") || cat.toLowerCase().includes("telecom")
			},
			{
				id: "retail",
				title: "Retail & E-Commerce",
				icon: ShoppingBag,
				description: "Department stores, online marketplaces, and home essentials providing reliable customer service.",
				match: (cat) => cat.toLowerCase().includes("retail") || cat.toLowerCase().includes("e-commerce") || cat.toLowerCase().includes("marketplace") || cat.toLowerCase().includes("store")
			},
			{
				id: "fashion",
				title: "Fashion & Apparel",
				icon: Shirt,
				description: "Everyday streetwear, sports apparel, footwear, and bespoke attire.",
				match: (cat) => cat.toLowerCase().includes("fashion") || cat.toLowerCase().includes("apparel") || cat.toLowerCase().includes("clothing") || cat.toLowerCase().includes("beauty")
			},
			{
				id: "finance",
				title: "Banking & Financial Services",
				icon: Building2,
				description: "Retail banking, fintech wallets, and insurance protecting consumer security.",
				match: (cat) => cat.toLowerCase().includes("bank") || cat.toLowerCase().includes("finance") || cat.toLowerCase().includes("insurance")
			}
		];
		return sectors.map((sec) => {
			const sectorBrands = (brands ?? []).filter((b) => {
				const cat = brandCategory(b.name, b.category);
				const matchesCountry = country === "All countries" || normalizeCountryCode(b.country) === country;
				return matchesCountry && sec.match(cat);
			}).sort((a, b) => (Number(b.trust_score) || 0) - (Number(a.trust_score) || 0));
			return {
				...sec,
				leaders: sectorBrands.slice(0, 4),
				totalCount: sectorBrands.length
			};
		});
	}, [brands, country]);
	// Market Tiers (Luxury, Premium, Mass Market, Budget)
	const tierSegments = useMemo(() => {
		const tierKeys = [
			"Budget",
			"Mass Market",
			"Premium",
			"Luxury"
		];
		return tierKeys.map((tk) => {
			const info = getTierInfo(tk);
			const tierBrands = (brands ?? []).filter((b) => {
				const matchesCountry = country === "All countries" || normalizeCountryCode(b.country) === country;
				const bTier = getBrandTier(b.name, b.category);
				return matchesCountry && bTier === tk;
			}).sort((a, b) => (Number(b.trust_score) || 0) - (Number(a.trust_score) || 0));
			return {
				tierKey: tk,
				info,
				leaders: tierBrands.slice(0, 5),
				totalCount: tierBrands.length
			};
		});
	}, [brands, country]);
	const awardTypes = [
		{
			icon: Crown,
			title: t("awards.cat1") || "Most Trusted Brand",
			desc: t("awards.cat1d") || "Highest positive ratio of community verdicts"
		},
		{
			icon: Heart,
			title: t("awards.cat2") || "People's Champion",
			desc: t("awards.cat2d") || "Unmatched grassroots advocacy across social signals"
		},
		{
			icon: TrendingUp,
			title: t("awards.cat3") || "Biggest Turnaround",
			desc: t("awards.cat3d") || "Largest upward sentiment recovery post-crisis"
		},
		{
			icon: Sparkles,
			title: t("awards.cat4") || "Rising Star",
			desc: t("awards.cat4d") || "Fastest growing newcomer winning customer loyalty"
		}
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen",
		"data-tsd-source": "/src/routes/awards.tsx:366:5",
		children: [
			/* @__PURE__ */ _jsxDEV(Header, { "data-tsd-source": "/src/routes/awards.tsx:367:7" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 311,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "mx-auto max-w-5xl px-4 py-8",
				"data-tsd-source": "/src/routes/awards.tsx:368:7",
				children: [
					/* @__PURE__ */ _jsxDEV("section", {
						className: "rounded-3xl border border-border bg-gradient-to-b from-secondary/60 to-card p-8 text-center shadow-sm",
						"data-tsd-source": "/src/routes/awards.tsx:370:9",
						children: [
							/* @__PURE__ */ _jsxDEV(Trophy, {
								className: "mx-auto h-12 w-12 text-primary",
								"data-tsd-source": "/src/routes/awards.tsx:371:11"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 315,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("h1", {
								className: "mt-4 font-display text-4xl font-extrabold sm:text-5xl",
								"data-tsd-source": "/src/routes/awards.tsx:372:11",
								children: t("awards.title") || "The SOT Awards"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 316,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "mt-2 font-display text-lg font-semibold text-primary",
								"data-tsd-source": "/src/routes/awards.tsx:373:11",
								children: t("awards.tagline") || "The Brand Barometer — The People's Verdict, Made Official"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 317,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-3 flex justify-center",
								"data-tsd-source": "/src/routes/awards.tsx:376:11",
								children: /* @__PURE__ */ _jsxDEV(PeopleTrustFactorLink, { "data-tsd-source": "/src/routes/awards.tsx:377:13" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 321,
									columnNumber: 13
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 320,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "mx-auto mt-4 max-w-2xl text-muted-foreground text-sm sm:text-base leading-relaxed",
								"data-tsd-source": "/src/routes/awards.tsx:379:11",
								children: "Every crown is decided purely by verifiable public consumer sentiment. Fair standards ensure like-for-like comparisons so food never competes with cars, and luxury conglomerates never overshadow budget champions."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 323,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-6 mx-auto max-w-2xl rounded-2xl border border-primary/25 bg-primary/5 p-4 text-left",
								"data-tsd-source": "/src/routes/awards.tsx:385:11",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 text-primary font-bold text-xs uppercase tracking-wider",
									"data-tsd-source": "/src/routes/awards.tsx:386:13",
									children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, {
										className: "h-4 w-4 shrink-0",
										"data-tsd-source": "/src/routes/awards.tsx:387:15"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 331,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										"data-tsd-source": "/src/routes/awards.tsx:388:15",
										children: "Fair Directory & Competition Standard"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 332,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 330,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "mt-1 text-xs sm:text-sm text-foreground/90 leading-relaxed font-medium",
									"data-tsd-source": "/src/routes/awards.tsx:390:13",
									children: "Every country is discoverable, and brands are classified across defined market tiers (Luxury, Premium, Mass Market, Budget). Luxury maisons and premium tech giants never crowd out mass-market essentials or budget champions."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 334,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 329,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 314,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("section", {
						className: "mt-8",
						"data-tsd-source": "/src/routes/awards.tsx:397:9",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-border pb-4",
								"data-tsd-source": "/src/routes/awards.tsx:398:11",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									"data-tsd-source": "/src/routes/awards.tsx:399:13",
									children: [/* @__PURE__ */ _jsxDEV("h2", {
										className: "font-display text-2xl font-bold",
										"data-tsd-source": "/src/routes/awards.tsx:400:15",
										children: t("awards.leaderboard") || "Annual Leaderboard"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 344,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-muted-foreground mt-0.5",
										"data-tsd-source": "/src/routes/awards.tsx:401:15",
										children: "Classified competition standard: Explore sector-by-sector and tier-by-tier rankings."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 345,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 343,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-wrap items-center gap-2 bg-secondary/60 p-1 rounded-xl",
									"data-tsd-source": "/src/routes/awards.tsx:406:13",
									children: [
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => setViewMode("industries"),
											className: cn("px-3 py-1.5 rounded-lg text-xs font-semibold transition-all", viewMode === "industries" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"),
											"data-tsd-source": "/src/routes/awards.tsx:407:15",
											children: "By Industry Sector"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 351,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => setViewMode("tiers"),
											className: cn("px-3 py-1.5 rounded-lg text-xs font-semibold transition-all", viewMode === "tiers" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"),
											"data-tsd-source": "/src/routes/awards.tsx:419:15",
											children: "By Market Tier"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 354,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => setViewMode("search"),
											className: cn("px-3 py-1.5 rounded-lg text-xs font-semibold transition-all", viewMode === "search" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"),
											"data-tsd-source": "/src/routes/awards.tsx:431:15",
											children: "Custom Scoped Search"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 357,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => setViewMode("institutional"),
											className: cn("flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all", viewMode === "institutional" ? "bg-slate-950 text-[#d6a928] shadow-sm" : "text-foreground hover:bg-background/60"),
											"data-tsd-source": "/src/routes/awards.tsx:443:15",
											children: [/* @__PURE__ */ _jsxDEV(Vote, {
												className: "h-3.5 w-3.5 text-[#d6a928]",
												"data-tsd-source": "/src/routes/awards.tsx:453:17"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 361,
												columnNumber: 17
											}, this), "Institutional Voting (Unions / Gov / Offices)"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 360,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 350,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 342,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-4 flex flex-wrap items-center justify-between gap-3 text-xs",
								"data-tsd-source": "/src/routes/awards.tsx:460:11",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 font-medium text-muted-foreground",
									"data-tsd-source": "/src/routes/awards.tsx:461:13",
									children: [
										/* @__PURE__ */ _jsxDEV(Map, {
											className: "h-4 w-4 text-primary",
											"data-tsd-source": "/src/routes/awards.tsx:462:15"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 370,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											"data-tsd-source": "/src/routes/awards.tsx:463:15",
											children: "Region:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 371,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("select", {
											value: country,
											onChange: (e) => setCountry(e.target.value),
											className: "rounded-lg border border-border bg-background px-2.5 py-1 text-xs font-bold text-foreground outline-none",
											"data-tsd-source": "/src/routes/awards.tsx:464:15",
											children: countries.map((c) => /* @__PURE__ */ _jsxDEV("option", {
												value: c,
												"data-tsd-source": "/src/routes/awards.tsx:470:19",
												children: c === "All countries" ? "Global (All Countries)" : countryName(c)
											}, c, false, {
												fileName: _jsxFileName,
												lineNumber: 373,
												columnNumber: 37
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 372,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 369,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 text-xs text-muted-foreground font-medium",
									"data-tsd-source": "/src/routes/awards.tsx:477:13",
									children: [
										/* @__PURE__ */ _jsxDEV(CalendarClock, {
											className: "h-3.5 w-3.5 text-primary",
											"data-tsd-source": "/src/routes/awards.tsx:478:15"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 380,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											"data-tsd-source": "/src/routes/awards.tsx:479:15",
											children: period
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 381,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											"data-tsd-source": "/src/routes/awards.tsx:480:15",
											children: ["· Snapshot ", snapshotTime.toLocaleDateString()]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 382,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 379,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 368,
								columnNumber: 11
							}, this),
							viewMode === "industries" && /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-6 space-y-6",
								"data-tsd-source": "/src/routes/awards.tsx:486:13",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "rounded-xl border border-border/80 bg-card p-4 text-xs text-muted-foreground",
									"data-tsd-source": "/src/routes/awards.tsx:487:15",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-foreground",
										"data-tsd-source": "/src/routes/awards.tsx:488:17",
										children: "Strict Vertical Segmentation: "
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 389,
										columnNumber: 17
									}, this), "Automotive brands compete exclusively against automotive mobility; food and dining compete against food. A fast-food chain never loses an award to a supercar atelier."]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 388,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid gap-6 md:grid-cols-2",
									"data-tsd-source": "/src/routes/awards.tsx:492:15",
									children: industrySectors.map((sector) => {
										const Icon = sector.icon;
										return /* @__PURE__ */ _jsxDEV("div", {
											className: "rounded-2xl border border-border bg-card p-5 shadow-sm flex flex-col justify-between",
											"data-tsd-source": "/src/routes/awards.tsx:496:21",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												"data-tsd-source": "/src/routes/awards.tsx:497:23",
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-2.5 mb-2",
														"data-tsd-source": "/src/routes/awards.tsx:498:25",
														children: [/* @__PURE__ */ _jsxDEV("span", {
															className: "flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary",
															"data-tsd-source": "/src/routes/awards.tsx:499:27",
															children: /* @__PURE__ */ _jsxDEV(Icon, {
																className: "h-4 w-4",
																"data-tsd-source": "/src/routes/awards.tsx:500:29"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 400,
																columnNumber: 29
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 399,
															columnNumber: 27
														}, this), /* @__PURE__ */ _jsxDEV("div", {
															"data-tsd-source": "/src/routes/awards.tsx:502:27",
															children: [/* @__PURE__ */ _jsxDEV("h3", {
																className: "font-display text-base font-bold",
																"data-tsd-source": "/src/routes/awards.tsx:503:29",
																children: sector.title
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 403,
																columnNumber: 29
															}, this), /* @__PURE__ */ _jsxDEV("p", {
																className: "text-[11px] text-muted-foreground",
																"data-tsd-source": "/src/routes/awards.tsx:504:29",
																children: [sector.totalCount, " nominated brands"]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 404,
																columnNumber: 29
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 402,
															columnNumber: 27
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 398,
														columnNumber: 25
													}, this),
													/* @__PURE__ */ _jsxDEV("p", {
														className: "text-xs text-muted-foreground mb-4",
														"data-tsd-source": "/src/routes/awards.tsx:507:25",
														children: sector.description
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 407,
														columnNumber: 25
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "space-y-2",
														"data-tsd-source": "/src/routes/awards.tsx:509:25",
														children: sector.leaders.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
															className: "text-xs text-muted-foreground py-4 text-center",
															"data-tsd-source": "/src/routes/awards.tsx:511:29",
															children: "No nominees for this country yet."
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 410,
															columnNumber: 58
														}, this) : sector.leaders.map((b, idx) => {
															const bTier = getBrandTier(b.name, b.category);
															const tInfo = getTierInfo(bTier);
															return /* @__PURE__ */ _jsxDEV(Link, {
																to: "/brands/$slug",
																params: { slug: b.slug },
																className: "flex items-center justify-between rounded-xl border border-border/60 bg-secondary/30 px-3 py-2 text-xs transition-colors hover:bg-secondary",
																"data-tsd-source": "/src/routes/awards.tsx:517:33",
																children: [/* @__PURE__ */ _jsxDEV("div", {
																	className: "flex items-center gap-2.5 truncate",
																	"data-tsd-source": "/src/routes/awards.tsx:523:35",
																	children: [
																		/* @__PURE__ */ _jsxDEV("span", {
																			className: "w-5 font-display font-extrabold text-muted-foreground text-center",
																			"data-tsd-source": "/src/routes/awards.tsx:524:37",
																			children: idx === 0 ? "🥇" : idx === 1 ? "🥈" : idx === 2 ? "🥉" : `${idx + 1}`
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 417,
																			columnNumber: 37
																		}, this),
																		/* @__PURE__ */ _jsxDEV("div", {
																			className: "flex h-7 w-7 shrink-0 items-center justify-center rounded bg-secondary font-bold text-[11px]",
																			"data-tsd-source": "/src/routes/awards.tsx:527:37",
																			children: b.signedLogoUrl ? /* @__PURE__ */ _jsxDEV("img", {
																				src: b.signedLogoUrl,
																				alt: b.name,
																				className: "h-full w-full object-cover rounded",
																				"data-tsd-source": "/src/routes/awards.tsx:529:41"
																			}, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 421,
																				columnNumber: 58
																			}, this) : b.name.charAt(0)
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 420,
																			columnNumber: 37
																		}, this),
																		/* @__PURE__ */ _jsxDEV("div", {
																			className: "truncate",
																			"data-tsd-source": "/src/routes/awards.tsx:534:37",
																			children: [/* @__PURE__ */ _jsxDEV("p", {
																				className: "font-bold truncate text-foreground",
																				"data-tsd-source": "/src/routes/awards.tsx:535:39",
																				children: b.name
																			}, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 424,
																				columnNumber: 39
																			}, this), /* @__PURE__ */ _jsxDEV("span", {
																				className: cn("text-[9px] font-semibold border rounded px-1", tInfo.badgeClass),
																				"data-tsd-source": "/src/routes/awards.tsx:536:39",
																				children: [
																					tInfo.pricePoint,
																					" ",
																					tInfo.shortName
																				]
																			}, void 0, true, {
																				fileName: _jsxFileName,
																				lineNumber: 425,
																				columnNumber: 39
																			}, this)]
																		}, void 0, true, {
																			fileName: _jsxFileName,
																			lineNumber: 423,
																			columnNumber: 37
																		}, this)
																	]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 416,
																	columnNumber: 35
																}, this), /* @__PURE__ */ _jsxDEV("div", {
																	className: "flex items-center gap-1 font-display font-bold text-stash shrink-0 ml-2",
																	"data-tsd-source": "/src/routes/awards.tsx:541:35",
																	children: [/* @__PURE__ */ _jsxDEV(TrendingUp, {
																		className: "h-3 w-3",
																		"data-tsd-source": "/src/routes/awards.tsx:542:37"
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 431,
																		columnNumber: 37
																	}, this), /* @__PURE__ */ _jsxDEV("span", {
																		"data-tsd-source": "/src/routes/awards.tsx:543:37",
																		children: [b.trust_score, "%"]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 432,
																		columnNumber: 37
																	}, this)]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 430,
																	columnNumber: 35
																}, this)]
															}, b.id, true, {
																fileName: _jsxFileName,
																lineNumber: 413,
																columnNumber: 30
															}, this);
														})
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 409,
														columnNumber: 25
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 397,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "mt-4 pt-3 border-t border-border/50 text-right",
												"data-tsd-source": "/src/routes/awards.tsx:552:23",
												children: /* @__PURE__ */ _jsxDEV(Link, {
													to: "/brands",
													className: "text-xs font-semibold text-primary hover:underline",
													"data-tsd-source": "/src/routes/awards.tsx:553:25",
													children: [
														"View all in ",
														sector.title,
														" →"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 440,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 439,
												columnNumber: 23
											}, this)]
										}, sector.id, true, {
											fileName: _jsxFileName,
											lineNumber: 396,
											columnNumber: 22
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 393,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 387,
								columnNumber: 41
							}, this),
							viewMode === "tiers" && /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-6 space-y-6",
								"data-tsd-source": "/src/routes/awards.tsx:569:13",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "rounded-xl border border-border/80 bg-card p-4 text-xs text-muted-foreground",
									"data-tsd-source": "/src/routes/awards.tsx:570:15",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-foreground",
										"data-tsd-source": "/src/routes/awards.tsx:571:17",
										children: "Equal Stature Across Tiers: "
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 452,
										columnNumber: 17
									}, this), "Budget champions and everyday mass-market essentials are celebrated with equal prestige alongside luxury maisons and premium innovators."]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 451,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid gap-6 md:grid-cols-2 lg:grid-cols-4",
									"data-tsd-source": "/src/routes/awards.tsx:575:15",
									children: tierSegments.map((segment) => {
										return /* @__PURE__ */ _jsxDEV("div", {
											className: cn("rounded-2xl border bg-card p-4 shadow-sm flex flex-col justify-between", segment.info.borderClass),
											"data-tsd-source": "/src/routes/awards.tsx:578:21",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												"data-tsd-source": "/src/routes/awards.tsx:585:23",
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center justify-between mb-2",
														"data-tsd-source": "/src/routes/awards.tsx:586:25",
														children: [/* @__PURE__ */ _jsxDEV("span", {
															className: cn("rounded-md border px-2 py-0.5 text-xs font-bold", segment.info.badgeClass),
															"data-tsd-source": "/src/routes/awards.tsx:587:27",
															children: [
																segment.info.pricePoint,
																" ",
																segment.tierKey
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 461,
															columnNumber: 27
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "text-[11px] font-semibold text-muted-foreground",
															"data-tsd-source": "/src/routes/awards.tsx:590:27",
															children: [segment.totalCount, " brands"]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 464,
															columnNumber: 27
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 460,
														columnNumber: 25
													}, this),
													/* @__PURE__ */ _jsxDEV("h3", {
														className: "font-display text-sm font-bold text-foreground",
														"data-tsd-source": "/src/routes/awards.tsx:594:25",
														children: segment.info.label
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 468,
														columnNumber: 25
													}, this),
													/* @__PURE__ */ _jsxDEV("p", {
														className: "text-[11px] text-muted-foreground mt-1 mb-4 leading-normal",
														"data-tsd-source": "/src/routes/awards.tsx:595:25",
														children: segment.info.description
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 469,
														columnNumber: 25
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "space-y-2",
														"data-tsd-source": "/src/routes/awards.tsx:597:25",
														children: segment.leaders.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
															className: "text-xs text-muted-foreground py-4 text-center",
															"data-tsd-source": "/src/routes/awards.tsx:599:29",
															children: "No nominees yet."
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 472,
															columnNumber: 59
														}, this) : segment.leaders.map((b, idx) => /* @__PURE__ */ _jsxDEV(Link, {
															to: "/brands/$slug",
															params: { slug: b.slug },
															className: "flex items-center justify-between rounded-lg border border-border/50 bg-secondary/30 p-2 text-xs transition-colors hover:bg-secondary",
															"data-tsd-source": "/src/routes/awards.tsx:602:31",
															children: [/* @__PURE__ */ _jsxDEV("div", {
																className: "flex items-center gap-2 truncate",
																"data-tsd-source": "/src/routes/awards.tsx:608:33",
																children: [/* @__PURE__ */ _jsxDEV("span", {
																	className: "w-4 font-bold text-muted-foreground text-center text-[11px]",
																	"data-tsd-source": "/src/routes/awards.tsx:609:35",
																	children: idx + 1
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 476,
																	columnNumber: 35
																}, this), /* @__PURE__ */ _jsxDEV("div", {
																	className: "truncate",
																	"data-tsd-source": "/src/routes/awards.tsx:612:35",
																	children: [/* @__PURE__ */ _jsxDEV("p", {
																		className: "font-bold truncate text-foreground",
																		"data-tsd-source": "/src/routes/awards.tsx:613:37",
																		children: b.name
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 480,
																		columnNumber: 37
																	}, this), /* @__PURE__ */ _jsxDEV("p", {
																		className: "text-[10px] text-muted-foreground truncate",
																		"data-tsd-source": "/src/routes/awards.tsx:614:37",
																		children: brandCategory(b.name, b.category)
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 481,
																		columnNumber: 37
																	}, this)]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 479,
																	columnNumber: 35
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 475,
																columnNumber: 33
															}, this), /* @__PURE__ */ _jsxDEV("span", {
																className: "font-display font-extrabold text-stash shrink-0 ml-1 text-xs",
																"data-tsd-source": "/src/routes/awards.tsx:617:33",
																children: [b.trust_score, "%"]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 484,
																columnNumber: 33
															}, this)]
														}, b.id, true, {
															fileName: _jsxFileName,
															lineNumber: 472,
															columnNumber: 224
														}, this))
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 471,
														columnNumber: 25
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 459,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "mt-4 pt-2 border-t border-border/40 text-center",
												"data-tsd-source": "/src/routes/awards.tsx:626:23",
												children: /* @__PURE__ */ _jsxDEV(Link, {
													to: "/brands",
													className: "text-[11px] font-semibold text-primary hover:underline",
													"data-tsd-source": "/src/routes/awards.tsx:627:25",
													children: [
														"Explore all ",
														segment.tierKey,
														" →"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 492,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 491,
												columnNumber: 23
											}, this)]
										}, segment.tierKey, true, {
											fileName: _jsxFileName,
											lineNumber: 458,
											columnNumber: 22
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 456,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 450,
								columnNumber: 36
							}, this),
							viewMode === "search" && /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-6 space-y-4",
								"data-tsd-source": "/src/routes/awards.tsx:643:13",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "rounded-2xl border border-border bg-card p-4 shadow-sm",
									"data-tsd-source": "/src/routes/awards.tsx:644:15",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "grid gap-3 lg:grid-cols-[1fr_200px_200px]",
										"data-tsd-source": "/src/routes/awards.tsx:645:17",
										children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "flex h-10 items-center gap-2 rounded-xl border border-border bg-background px-3",
												"data-tsd-source": "/src/routes/awards.tsx:646:19",
												children: [/* @__PURE__ */ _jsxDEV(Search, {
													className: "h-4 w-4 text-muted-foreground",
													"data-tsd-source": "/src/routes/awards.tsx:647:21"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 506,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													value: query,
													onChange: (e) => setQuery(e.target.value),
													placeholder: "Search brands or industries",
													className: "min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground",
													"data-tsd-source": "/src/routes/awards.tsx:648:21"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 507,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 505,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("select", {
												value: category,
												onChange: (e) => setCategory(e.target.value),
												className: "h-10 rounded-xl border border-border bg-background px-3 text-xs font-medium outline-none",
												"data-tsd-source": "/src/routes/awards.tsx:656:19",
												children: categories.map((c) => /* @__PURE__ */ _jsxDEV("option", {
													value: c,
													"data-tsd-source": "/src/routes/awards.tsx:662:23",
													children: c
												}, c, false, {
													fileName: _jsxFileName,
													lineNumber: 511,
													columnNumber: 42
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 510,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("select", {
												value: tier,
												onChange: (e) => setTier(e.target.value),
												className: "h-10 rounded-xl border border-border bg-background px-3 text-xs font-medium outline-none",
												"data-tsd-source": "/src/routes/awards.tsx:666:19",
												children: BRAND_TIERS.map((t) => /* @__PURE__ */ _jsxDEV("option", {
													value: t,
													"data-tsd-source": "/src/routes/awards.tsx:672:23",
													children: t
												}, t, false, {
													fileName: _jsxFileName,
													lineNumber: 515,
													columnNumber: 43
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 514,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 504,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 503,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "overflow-hidden rounded-2xl border border-border bg-card",
									"data-tsd-source": "/src/routes/awards.tsx:679:15",
									children: isLoading ? /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-px",
										"data-tsd-source": "/src/routes/awards.tsx:681:19",
										children: [
											0,
											1,
											2,
											3
										].map((i) => /* @__PURE__ */ _jsxDEV(Skeleton, {
											className: "h-14 w-full rounded-none",
											"data-tsd-source": "/src/routes/awards.tsx:683:23"
										}, i, false, {
											fileName: _jsxFileName,
											lineNumber: 523,
											columnNumber: 44
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 522,
										columnNumber: 30
									}, this) : top.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
										className: "p-8 text-center text-sm text-muted-foreground",
										"data-tsd-source": "/src/routes/awards.tsx:687:19",
										children: "No brands match this scope."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 524,
										columnNumber: 47
									}, this) : top.map((b, i) => {
										const bTier = getBrandTier(b.name, b.category);
										const tierInfo = getTierInfo(bTier);
										return /* @__PURE__ */ _jsxDEV(Link, {
											to: "/brands/$slug",
											params: { slug: b.slug },
											className: "flex items-center gap-4 border-b border-border bg-card px-4 py-3 transition-colors last:border-0 hover:bg-secondary/50",
											"data-tsd-source": "/src/routes/awards.tsx:693:23",
											children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "w-8 text-center font-display text-lg font-extrabold text-muted-foreground",
													"data-tsd-source": "/src/routes/awards.tsx:699:25",
													children: i < 3 ? [
														"1st",
														"2nd",
														"3rd"
													][i] : i + 1
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 530,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex h-9 w-9 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-secondary text-sm font-bold",
													"data-tsd-source": "/src/routes/awards.tsx:702:25",
													children: b.signedLogoUrl ? /* @__PURE__ */ _jsxDEV("img", {
														src: b.signedLogoUrl,
														alt: b.name,
														className: "h-full w-full object-cover",
														"data-tsd-source": "/src/routes/awards.tsx:704:29"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 534,
														columnNumber: 46
													}, this) : b.name.charAt(0).toUpperCase()
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 533,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "flex-1 truncate font-semibold",
													"data-tsd-source": "/src/routes/awards.tsx:709:25",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "flex items-center gap-2",
														"data-tsd-source": "/src/routes/awards.tsx:710:27",
														children: [/* @__PURE__ */ _jsxDEV("span", {
															className: "truncate",
															"data-tsd-source": "/src/routes/awards.tsx:711:29",
															children: b.name
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 538,
															columnNumber: 29
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: cn("hidden sm:inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-bold leading-none", tierInfo.badgeClass),
															"data-tsd-source": "/src/routes/awards.tsx:712:29",
															children: [/* @__PURE__ */ _jsxDEV("span", {
																className: "font-mono text-[9px] opacity-75",
																"data-tsd-source": "/src/routes/awards.tsx:718:31",
																children: tierInfo.pricePoint
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 540,
																columnNumber: 31
															}, this), /* @__PURE__ */ _jsxDEV("span", {
																"data-tsd-source": "/src/routes/awards.tsx:719:31",
																children: tierInfo.shortName
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 541,
																columnNumber: 31
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 539,
															columnNumber: 29
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 537,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "text-xs font-normal text-muted-foreground",
														"data-tsd-source": "/src/routes/awards.tsx:722:27",
														children: [
															countryName(normalizeCountryCode(b.country)),
															" · ",
															brandCategory(b.name, b.category)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 544,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 536,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "flex items-center gap-1.5 font-display font-extrabold text-stash",
													"data-tsd-source": "/src/routes/awards.tsx:726:25",
													children: [
														/* @__PURE__ */ _jsxDEV(TrendingUp, {
															className: "h-4 w-4",
															"data-tsd-source": "/src/routes/awards.tsx:727:27"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 549,
															columnNumber: 27
														}, this),
														b.trust_score,
														"%"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 548,
													columnNumber: 25
												}, this)
											]
										}, b.id, true, {
											fileName: _jsxFileName,
											lineNumber: 527,
											columnNumber: 22
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 521,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 502,
								columnNumber: 37
							}, this),
							viewMode === "institutional" && /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-6 space-y-6",
								"data-tsd-source": "/src/routes/awards.tsx:740:13",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "rounded-2xl border-2 border-[#d6a928]/40 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6 text-white shadow-md",
										"data-tsd-source": "/src/routes/awards.tsx:742:15",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex flex-col gap-4 md:flex-row md:items-center md:justify-between",
											"data-tsd-source": "/src/routes/awards.tsx:743:17",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "space-y-2 max-w-2xl",
												"data-tsd-source": "/src/routes/awards.tsx:744:19",
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "inline-flex items-center gap-2 rounded-full border border-[#d6a928]/40 bg-[#d6a928]/10 px-3 py-1 text-[11px] font-extrabold uppercase tracking-wider text-[#f5d061]",
														"data-tsd-source": "/src/routes/awards.tsx:745:21",
														children: [/* @__PURE__ */ _jsxDEV(Lock, {
															className: "h-3.5 w-3.5",
															"data-tsd-source": "/src/routes/awards.tsx:746:23"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 564,
															columnNumber: 23
														}, this), "Strategy C · Verified Trust Barometer Infrastructure"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 563,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("h3", {
														className: "font-display text-2xl font-extrabold text-white",
														"data-tsd-source": "/src/routes/awards.tsx:749:21",
														children: "High-Trust Institutional Voting & Ballot Chambers"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 567,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("p", {
														className: "text-xs sm:text-sm text-slate-300 leading-relaxed",
														"data-tsd-source": "/src/routes/awards.tsx:752:21",
														children: [
															"Because Stash or Trash verifies real citizens, authentic product batches, and regulatory awareness (CPA & CGSO), our ",
															/* @__PURE__ */ _jsxDEV("strong", {
																className: "text-[#f5d061]",
																"data-tsd-source": "/src/routes/awards.tsx:753:140",
																children: "Trust Bar"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 571,
																columnNumber: 140
															}, this),
															" scales directly to host tamper-proof online voting for ",
															/* @__PURE__ */ _jsxDEV("strong", {
																"data-tsd-source": "/src/routes/awards.tsx:753:249",
																children: "Trade Unions"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 571,
																columnNumber: 298
															}, this),
															", ",
															/* @__PURE__ */ _jsxDEV("strong", {
																"data-tsd-source": "/src/routes/awards.tsx:753:280",
																children: "Government & Public Awards Ceremonies"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 571,
																columnNumber: 378
															}, this),
															", and ",
															/* @__PURE__ */ _jsxDEV("strong", {
																"data-tsd-source": "/src/routes/awards.tsx:753:340",
																children: "Corporate Office Governance"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 571,
																columnNumber: 487
															}, this),
															"."
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 570,
														columnNumber: 21
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 562,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex flex-col gap-2 shrink-0",
												"data-tsd-source": "/src/routes/awards.tsx:756:19",
												children: [/* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													onClick: () => {
														setActiveObserverTopic("SOT Institutional Ballot Observer & Live Townhall");
														setLiveObserverModalOpen(true);
													},
													className: "inline-flex items-center justify-center gap-2 rounded-xl bg-[#d6a928] px-4 py-2.5 text-xs font-black uppercase tracking-wider text-slate-950 shadow-sm hover:bg-[#e5b935] transition",
													"data-tsd-source": "/src/routes/awards.tsx:757:21",
													children: [/* @__PURE__ */ _jsxDEV(Video, {
														className: "h-4 w-4",
														"data-tsd-source": "/src/routes/awards.tsx:765:23"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 579,
														columnNumber: 23
													}, this), "Launch Live Ballot Townhall / Call"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 575,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[11px] text-center text-slate-400",
													"data-tsd-source": "/src/routes/awards.tsx:768:21",
													children: "Powered by Google WebRTC & Agora RTC"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 582,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 574,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 561,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "mt-5 grid gap-3 sm:grid-cols-3 border-t border-slate-800 pt-4 text-xs",
											"data-tsd-source": "/src/routes/awards.tsx:774:17",
											children: [
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-start gap-2.5",
													"data-tsd-source": "/src/routes/awards.tsx:775:19",
													children: [/* @__PURE__ */ _jsxDEV(Users, {
														className: "h-4 w-4 text-[#d6a928] shrink-0 mt-0.5",
														"data-tsd-source": "/src/routes/awards.tsx:776:21"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 590,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														"data-tsd-source": "/src/routes/awards.tsx:777:21",
														children: [/* @__PURE__ */ _jsxDEV("p", {
															className: "font-bold text-white",
															"data-tsd-source": "/src/routes/awards.tsx:778:23",
															children: "Trade Unions & Federations"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 592,
															columnNumber: 23
														}, this), /* @__PURE__ */ _jsxDEV("p", {
															className: "text-slate-400 text-[11px]",
															"data-tsd-source": "/src/routes/awards.tsx:779:23",
															children: "1-Member-1-Vote wage mandates, strike ballots & shop steward elections."
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 593,
															columnNumber: 23
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 591,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 589,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-start gap-2.5",
													"data-tsd-source": "/src/routes/awards.tsx:782:19",
													children: [/* @__PURE__ */ _jsxDEV(Landmark, {
														className: "h-4 w-4 text-[#d6a928] shrink-0 mt-0.5",
														"data-tsd-source": "/src/routes/awards.tsx:783:21"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 597,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														"data-tsd-source": "/src/routes/awards.tsx:784:21",
														children: [/* @__PURE__ */ _jsxDEV("p", {
															className: "font-bold text-white",
															"data-tsd-source": "/src/routes/awards.tsx:785:23",
															children: "Gov & National Ceremonies"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 599,
															columnNumber: 23
														}, this), /* @__PURE__ */ _jsxDEV("p", {
															className: "text-slate-400 text-[11px]",
															"data-tsd-source": "/src/routes/awards.tsx:786:23",
															children: "Auditable public awards, municipal service polls & ombudsman recognition."
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 600,
															columnNumber: 23
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 598,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 596,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-start gap-2.5",
													"data-tsd-source": "/src/routes/awards.tsx:789:19",
													children: [/* @__PURE__ */ _jsxDEV(Briefcase, {
														className: "h-4 w-4 text-[#d6a928] shrink-0 mt-0.5",
														"data-tsd-source": "/src/routes/awards.tsx:790:21"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 604,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														"data-tsd-source": "/src/routes/awards.tsx:791:21",
														children: [/* @__PURE__ */ _jsxDEV("p", {
															className: "font-bold text-white",
															"data-tsd-source": "/src/routes/awards.tsx:792:23",
															children: "Offices & Boardrooms"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 606,
															columnNumber: 23
														}, this), /* @__PURE__ */ _jsxDEV("p", {
															className: "text-slate-400 text-[11px]",
															"data-tsd-source": "/src/routes/awards.tsx:793:23",
															children: "Workplace policy polls, AGM shareholder motions & supply-chain audits."
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 607,
															columnNumber: 23
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 605,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 603,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 588,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 560,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-4",
										"data-tsd-source": "/src/routes/awards.tsx:800:15",
										children: ballots.map((ballot) => {
											const receipt = votedReceipts[ballot.id];
											return /* @__PURE__ */ _jsxDEV("div", {
												className: "rounded-2xl border border-border bg-card p-5 shadow-sm space-y-4",
												"data-tsd-source": "/src/routes/awards.tsx:804:21",
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex flex-wrap items-start justify-between gap-2 border-b border-border/60 pb-3",
														"data-tsd-source": "/src/routes/awards.tsx:808:23",
														children: [/* @__PURE__ */ _jsxDEV("div", {
															"data-tsd-source": "/src/routes/awards.tsx:809:25",
															children: [
																/* @__PURE__ */ _jsxDEV("div", {
																	className: "flex flex-wrap items-center gap-2",
																	"data-tsd-source": "/src/routes/awards.tsx:810:27",
																	children: [/* @__PURE__ */ _jsxDEV("span", {
																		className: "rounded-md bg-primary/10 px-2.5 py-0.5 text-[11px] font-extrabold text-primary uppercase tracking-wider",
																		"data-tsd-source": "/src/routes/awards.tsx:811:29",
																		children: ballot.category
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 621,
																		columnNumber: 29
																	}, this), /* @__PURE__ */ _jsxDEV("span", {
																		className: "text-xs font-semibold text-muted-foreground",
																		"data-tsd-source": "/src/routes/awards.tsx:814:29",
																		children: ballot.organization
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 624,
																		columnNumber: 29
																	}, this)]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 620,
																	columnNumber: 27
																}, this),
																/* @__PURE__ */ _jsxDEV("h4", {
																	className: "mt-1.5 font-display text-lg font-extrabold text-foreground",
																	"data-tsd-source": "/src/routes/awards.tsx:818:27",
																	children: ballot.title
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 628,
																	columnNumber: 27
																}, this),
																/* @__PURE__ */ _jsxDEV("p", {
																	className: "mt-1 text-xs text-muted-foreground leading-relaxed",
																	"data-tsd-source": "/src/routes/awards.tsx:821:27",
																	children: ballot.description
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 631,
																	columnNumber: 27
																}, this)
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 619,
															columnNumber: 25
														}, this), /* @__PURE__ */ _jsxDEV("div", {
															className: "flex flex-col items-end gap-1.5 text-right shrink-0",
															"data-tsd-source": "/src/routes/awards.tsx:826:25",
															children: [
																/* @__PURE__ */ _jsxDEV("span", {
																	className: "inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-[11px] font-bold text-emerald-600",
																	"data-tsd-source": "/src/routes/awards.tsx:827:27",
																	children: [
																		/* @__PURE__ */ _jsxDEV(CheckCircle2, {
																			className: "h-3.5 w-3.5",
																			"data-tsd-source": "/src/routes/awards.tsx:828:29"
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 638,
																			columnNumber: 29
																		}, this),
																		ballot.totalVerifiedVotes.toLocaleString(),
																		" Verified Ballots"
																	]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 637,
																	columnNumber: 27
																}, this),
																/* @__PURE__ */ _jsxDEV("span", {
																	className: "text-[11px] text-muted-foreground",
																	"data-tsd-source": "/src/routes/awards.tsx:831:27",
																	children: ballot.closingDate
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 641,
																	columnNumber: 27
																}, this),
																/* @__PURE__ */ _jsxDEV("button", {
																	type: "button",
																	onClick: () => {
																		setActiveObserverTopic(`${ballot.organization}: ${ballot.title}`);
																		setLiveObserverModalOpen(true);
																	},
																	className: "inline-flex items-center gap-1 text-[11px] font-bold text-primary hover:underline",
																	"data-tsd-source": "/src/routes/awards.tsx:832:27",
																	children: [/* @__PURE__ */ _jsxDEV(Radio, {
																		className: "h-3 w-3 text-rose-500 animate-pulse",
																		"data-tsd-source": "/src/routes/awards.tsx:840:29"
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 646,
																		columnNumber: 29
																	}, this), "Join Live Observer Call / Stream"]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 642,
																	columnNumber: 27
																}, this)
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 636,
															columnNumber: 25
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 618,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "grid gap-3 sm:grid-cols-2",
														"data-tsd-source": "/src/routes/awards.tsx:847:23",
														children: ballot.options.map((opt) => {
															const pct = ballot.totalVerifiedVotes > 0 ? Math.round(opt.votes / ballot.totalVerifiedVotes * 100) : 0;
															const isSelected = receipt?.optionId === opt.id;
															return /* @__PURE__ */ _jsxDEV("div", {
																className: cn("rounded-xl border p-4 transition-all flex flex-col justify-between", isSelected ? "border-emerald-500 bg-emerald-500/5 shadow-xs" : "border-border bg-secondary/20 hover:border-primary/40"),
																"data-tsd-source": "/src/routes/awards.tsx:855:29",
																children: [/* @__PURE__ */ _jsxDEV("div", {
																	"data-tsd-source": "/src/routes/awards.tsx:864:31",
																	children: [/* @__PURE__ */ _jsxDEV("div", {
																		className: "flex items-start justify-between gap-2",
																		"data-tsd-source": "/src/routes/awards.tsx:865:33",
																		children: [/* @__PURE__ */ _jsxDEV("p", {
																			className: "font-display text-sm font-bold text-foreground",
																			"data-tsd-source": "/src/routes/awards.tsx:866:35",
																			children: opt.label
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 660,
																			columnNumber: 35
																		}, this), /* @__PURE__ */ _jsxDEV("span", {
																			className: "font-display text-sm font-black text-primary shrink-0",
																			"data-tsd-source": "/src/routes/awards.tsx:869:35",
																			children: [pct, "%"]
																		}, void 0, true, {
																			fileName: _jsxFileName,
																			lineNumber: 663,
																			columnNumber: 35
																		}, this)]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 659,
																		columnNumber: 33
																	}, this), /* @__PURE__ */ _jsxDEV("p", {
																		className: "mt-1 text-xs text-muted-foreground",
																		"data-tsd-source": "/src/routes/awards.tsx:873:33",
																		children: opt.subtitle
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 667,
																		columnNumber: 33
																	}, this)]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 658,
																	columnNumber: 31
																}, this), /* @__PURE__ */ _jsxDEV("div", {
																	className: "mt-4 space-y-2",
																	"data-tsd-source": "/src/routes/awards.tsx:876:31",
																	children: [/* @__PURE__ */ _jsxDEV("div", {
																		className: "h-2 w-full overflow-hidden rounded-full bg-secondary",
																		"data-tsd-source": "/src/routes/awards.tsx:877:33",
																		children: /* @__PURE__ */ _jsxDEV("div", {
																			className: cn("h-full rounded-full transition-all duration-500", isSelected ? "bg-emerald-500" : "bg-primary"),
																			style: { width: `${pct}%` },
																			"data-tsd-source": "/src/routes/awards.tsx:878:35"
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 672,
																			columnNumber: 35
																		}, this)
																	}, void 0, false, {
																		fileName: _jsxFileName,
																		lineNumber: 671,
																		columnNumber: 33
																	}, this), /* @__PURE__ */ _jsxDEV("div", {
																		className: "flex items-center justify-between text-[11px]",
																		"data-tsd-source": "/src/routes/awards.tsx:886:33",
																		children: [/* @__PURE__ */ _jsxDEV("span", {
																			className: "font-semibold text-muted-foreground",
																			"data-tsd-source": "/src/routes/awards.tsx:887:35",
																			children: [opt.votes.toLocaleString(), " verified votes"]
																		}, void 0, true, {
																			fileName: _jsxFileName,
																			lineNumber: 677,
																			columnNumber: 35
																		}, this), /* @__PURE__ */ _jsxDEV("button", {
																			type: "button",
																			disabled: !!receipt,
																			onClick: () => handleCastInstitutionalVote(ballot.id, opt.id),
																			className: cn("inline-flex items-center gap-1 rounded-lg px-3 py-1 text-xs font-bold transition", isSelected ? "bg-emerald-600 text-white" : receipt ? "bg-secondary text-muted-foreground cursor-not-allowed" : "bg-slate-950 text-[#d6a928] hover:bg-slate-900"),
																			"data-tsd-source": "/src/routes/awards.tsx:890:35",
																			children: isSelected ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Check, {
																				className: "h-3.5 w-3.5",
																				"data-tsd-source": "/src/routes/awards.tsx:905:41"
																			}, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 682,
																				columnNumber: 41
																			}, this), " Ballot Locked"] }, void 0, true, {
																				fileName: _jsxFileName,
																				lineNumber: 681,
																				columnNumber: 51
																			}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Vote, {
																				className: "h-3.5 w-3.5",
																				"data-tsd-source": "/src/routes/awards.tsx:909:41"
																			}, void 0, false, {
																				fileName: _jsxFileName,
																				lineNumber: 684,
																				columnNumber: 41
																			}, this), " Cast Verified Vote"] }, void 0, true, {
																				fileName: _jsxFileName,
																				lineNumber: 683,
																				columnNumber: 45
																			}, this)
																		}, void 0, false, {
																			fileName: _jsxFileName,
																			lineNumber: 680,
																			columnNumber: 35
																		}, this)]
																	}, void 0, true, {
																		fileName: _jsxFileName,
																		lineNumber: 676,
																		columnNumber: 33
																	}, this)]
																}, void 0, true, {
																	fileName: _jsxFileName,
																	lineNumber: 670,
																	columnNumber: 31
																}, this)]
															}, opt.id, true, {
																fileName: _jsxFileName,
																lineNumber: 657,
																columnNumber: 28
															}, this);
														})
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 653,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex flex-wrap items-center justify-between gap-2 rounded-xl bg-secondary/40 px-3.5 py-2 text-[11px] text-muted-foreground",
														"data-tsd-source": "/src/routes/awards.tsx:921:23",
														children: [/* @__PURE__ */ _jsxDEV("span", {
															className: "flex items-center gap-1.5 font-medium",
															"data-tsd-source": "/src/routes/awards.tsx:922:25",
															children: [
																/* @__PURE__ */ _jsxDEV(ShieldCheck, {
																	className: "h-3.5 w-3.5 text-emerald-600",
																	"data-tsd-source": "/src/routes/awards.tsx:923:27"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 696,
																	columnNumber: 27
																}, this),
																"Security Standard: ",
																/* @__PURE__ */ _jsxDEV("strong", {
																	className: "text-foreground",
																	"data-tsd-source": "/src/routes/awards.tsx:924:46",
																	children: ballot.verificationStandard
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 697,
																	columnNumber: 46
																}, this)
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 695,
															columnNumber: 25
														}, this), receipt ? /* @__PURE__ */ _jsxDEV("span", {
															className: "flex items-center gap-1.5 font-mono font-bold text-emerald-600",
															"data-tsd-source": "/src/routes/awards.tsx:927:27",
															children: [
																/* @__PURE__ */ _jsxDEV(FileCheck2, {
																	className: "h-3.5 w-3.5",
																	"data-tsd-source": "/src/routes/awards.tsx:928:29"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 700,
																	columnNumber: 29
																}, this),
																"Receipt: ",
																receipt.hash,
																" (",
																receipt.timestamp,
																")"
															]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 699,
															columnNumber: 36
														}, this) : /* @__PURE__ */ _jsxDEV("span", {
															"data-tsd-source": "/src/routes/awards.tsx:932:27",
															children: "1-Person-1-Vote Auditable Ledger Ready"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 702,
															columnNumber: 37
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 694,
														columnNumber: 23
													}, this)
												]
											}, ballot.id, true, {
												fileName: _jsxFileName,
												lineNumber: 617,
												columnNumber: 22
											}, this);
										})
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 614,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("form", {
										onSubmit: handleCreateCustomBallot,
										className: "rounded-2xl border border-dashed border-primary/40 bg-primary/5 p-5 space-y-4",
										"data-tsd-source": "/src/routes/awards.tsx:941:15",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2",
												"data-tsd-source": "/src/routes/awards.tsx:945:17",
												children: [/* @__PURE__ */ _jsxDEV(Vote, {
													className: "h-5 w-5 text-primary",
													"data-tsd-source": "/src/routes/awards.tsx:946:19"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 711,
													columnNumber: 19
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													"data-tsd-source": "/src/routes/awards.tsx:947:19",
													children: [/* @__PURE__ */ _jsxDEV("h4", {
														className: "font-display text-base font-bold text-foreground",
														"data-tsd-source": "/src/routes/awards.tsx:948:21",
														children: "Host an Institutional Ballot (Trade Union, Office Poll, or Awards Ceremony)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 713,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("p", {
														className: "text-xs text-muted-foreground",
														"data-tsd-source": "/src/routes/awards.tsx:951:21",
														children: "Test launching a live verified ballot chamber with instant 1-Person-1-Vote cryptographic receipts."
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 716,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 712,
													columnNumber: 19
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 710,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "grid gap-3 sm:grid-cols-3",
												"data-tsd-source": "/src/routes/awards.tsx:957:17",
												children: [
													/* @__PURE__ */ _jsxDEV("select", {
														value: newBallotCategory,
														onChange: (e) => setNewBallotCategory(e.target.value),
														className: "h-10 rounded-xl border border-border bg-background px-3 text-xs font-semibold outline-none",
														"data-tsd-source": "/src/routes/awards.tsx:958:19",
														children: [
															/* @__PURE__ */ _jsxDEV("option", {
																value: "Trade Union Ballot",
																"data-tsd-source": "/src/routes/awards.tsx:963:21",
																children: "Trade Union Ballot"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 724,
																columnNumber: 21
															}, this),
															/* @__PURE__ */ _jsxDEV("option", {
																value: "National Awards Ceremony",
																"data-tsd-source": "/src/routes/awards.tsx:964:21",
																children: "National Awards Ceremony"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 725,
																columnNumber: 21
															}, this),
															/* @__PURE__ */ _jsxDEV("option", {
																value: "Office & Corporate Poll",
																"data-tsd-source": "/src/routes/awards.tsx:965:21",
																children: "Office & Corporate Poll"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 726,
																columnNumber: 21
															}, this),
															/* @__PURE__ */ _jsxDEV("option", {
																value: "Civic & Regulatory Mandate",
																"data-tsd-source": "/src/routes/awards.tsx:966:21",
																children: "Civic & Regulatory Mandate"
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 727,
																columnNumber: 21
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 723,
														columnNumber: 19
													}, this),
													/* @__PURE__ */ _jsxDEV("input", {
														value: newBallotOrg,
														onChange: (e) => setNewBallotOrg(e.target.value),
														placeholder: "Organization / Union / Department Name",
														className: "h-10 rounded-xl border border-border bg-background px-3 text-xs outline-none",
														"data-tsd-source": "/src/routes/awards.tsx:968:19"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 729,
														columnNumber: 19
													}, this),
													/* @__PURE__ */ _jsxDEV("input", {
														value: newBallotTitle,
														onChange: (e) => setNewBallotTitle(e.target.value),
														placeholder: "Resolution / Ballot Motion Title",
														className: "h-10 rounded-xl border border-border bg-background px-3 text-xs outline-none",
														"data-tsd-source": "/src/routes/awards.tsx:974:19"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 730,
														columnNumber: 19
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 722,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-end",
												"data-tsd-source": "/src/routes/awards.tsx:981:17",
												children: /* @__PURE__ */ _jsxDEV("button", {
													type: "submit",
													className: "inline-flex items-center gap-1.5 rounded-xl bg-primary px-4 py-2 text-xs font-bold text-primary-foreground hover:opacity-90 transition",
													"data-tsd-source": "/src/routes/awards.tsx:982:19",
													children: [/* @__PURE__ */ _jsxDEV(Sparkles, {
														className: "h-3.5 w-3.5",
														"data-tsd-source": "/src/routes/awards.tsx:986:21"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 734,
														columnNumber: 21
													}, this), "Open Verified Ballot Chamber"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 733,
													columnNumber: 19
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 732,
												columnNumber: 17
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 709,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 558,
								columnNumber: 44
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-8 rounded-2xl border border-stash/20 bg-stash/5 p-5",
								"data-tsd-source": "/src/routes/awards.tsx:995:11",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-display text-lg font-bold",
									"data-tsd-source": "/src/routes/awards.tsx:996:13",
									children: "Our Fairness and Accuracy Standard"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 743,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "mt-3 grid gap-3 text-sm text-muted-foreground md:grid-cols-2",
									"data-tsd-source": "/src/routes/awards.tsx:997:13",
									children: [
										/* @__PURE__ */ _jsxDEV("p", {
											"data-tsd-source": "/src/routes/awards.tsx:998:15",
											children: [/* @__PURE__ */ _jsxDEV("strong", {
												className: "text-foreground",
												"data-tsd-source": "/src/routes/awards.tsx:999:17",
												children: "Category Separation."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 746,
												columnNumber: 17
											}, this), " Food products and supermarkets never compete against automotive brands or tech giants. Every industry has dedicated recognition."]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 745,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											"data-tsd-source": "/src/routes/awards.tsx:1001:15",
											children: [/* @__PURE__ */ _jsxDEV("strong", {
												className: "text-foreground",
												"data-tsd-source": "/src/routes/awards.tsx:1002:17",
												children: "Tiered Competition."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 749,
												columnNumber: 17
											}, this), " Brands are classified across defined market tiers (Luxury, Premium, Mass Market, Budget). Luxury maisons and tech titans never crowd out mass-market essentials or budget champions."]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 748,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											"data-tsd-source": "/src/routes/awards.tsx:1004:15",
											children: [/* @__PURE__ */ _jsxDEV("strong", {
												className: "text-foreground",
												"data-tsd-source": "/src/routes/awards.tsx:1005:17",
												children: "Universal Discoverability."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 752,
												columnNumber: 17
											}, this), " Every country is discoverable, and local independent brands compete on a level playing field within their own scope."]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 751,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											"data-tsd-source": "/src/routes/awards.tsx:1007:15",
											children: [/* @__PURE__ */ _jsxDEV("strong", {
												className: "text-foreground",
												"data-tsd-source": "/src/routes/awards.tsx:1008:17",
												children: "Evidence Before Authority."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 755,
												columnNumber: 17
											}, this), " Rankings are an honest community signal powered by direct user verdicts, timestamped and transparently auditable."]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 754,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 744,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 742,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 341,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("section", {
						className: "mt-10 rounded-3xl border border-border bg-card p-6 shadow-sm",
						"data-tsd-source": "/src/routes/awards.tsx:1015:9",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-start gap-3",
							"data-tsd-source": "/src/routes/awards.tsx:1016:11",
							children: [/* @__PURE__ */ _jsxDEV(CalendarClock, {
								className: "mt-1 h-6 w-6 shrink-0 text-primary",
								"data-tsd-source": "/src/routes/awards.tsx:1017:13"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 764,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								"data-tsd-source": "/src/routes/awards.tsx:1018:13",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "font-display text-xl font-bold",
									"data-tsd-source": "/src/routes/awards.tsx:1019:15",
									children: "The Road to the Live Ceremony"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 766,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "mt-1 text-sm text-muted-foreground",
									"data-tsd-source": "/src/routes/awards.tsx:1020:15",
									children: "A transparent process built from real-time community verdicts."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 767,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 765,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 763,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-6 grid gap-3 md:grid-cols-4",
							"data-tsd-source": "/src/routes/awards.tsx:1023:11",
							children: [
								"Nominees open",
								"Public voting",
								"Snapshot locked",
								"Live ceremony"
							].map((stage, index) => /* @__PURE__ */ _jsxDEV("div", {
								className: "rounded-2xl border border-border p-4",
								"data-tsd-source": "/src/routes/awards.tsx:1025:15",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: cn("flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold", index === 0 ? "bg-stash text-stash-foreground" : "bg-secondary text-muted-foreground"),
										"data-tsd-source": "/src/routes/awards.tsx:1026:17",
										children: index + 1
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 772,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "mt-3 font-display text-sm font-bold",
										"data-tsd-source": "/src/routes/awards.tsx:1027:17",
										children: stage
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 773,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "mt-1 text-xs leading-relaxed text-muted-foreground",
										"data-tsd-source": "/src/routes/awards.tsx:1028:17",
										children: index === 0 ? "Live now across each market and category." : index === 1 ? "Community verdicts will decide the shortlist." : index === 2 ? "Scores freeze with an auditable timestamp." : "Winners are celebrated in the real world."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 774,
										columnNumber: 17
									}, this)
								]
							}, stage, true, {
								fileName: _jsxFileName,
								lineNumber: 771,
								columnNumber: 107
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 770,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 762,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("section", {
						className: "mt-10",
						"data-tsd-source": "/src/routes/awards.tsx:1035:9",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "font-display text-2xl font-bold",
							"data-tsd-source": "/src/routes/awards.tsx:1036:11",
							children: t("awards.categoryTitle") || "Official Award Categories"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 781,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-4 grid gap-4 sm:grid-cols-2",
							"data-tsd-source": "/src/routes/awards.tsx:1037:11",
							children: awardTypes.map((c) => /* @__PURE__ */ _jsxDEV("div", {
								className: "rounded-2xl border border-border bg-card p-5",
								"data-tsd-source": "/src/routes/awards.tsx:1039:15",
								children: [
									/* @__PURE__ */ _jsxDEV(c.icon, {
										className: "h-7 w-7 text-primary",
										"data-tsd-source": "/src/routes/awards.tsx:1040:17"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 784,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("h3", {
										className: "mt-3 font-display text-lg font-bold",
										"data-tsd-source": "/src/routes/awards.tsx:1041:17",
										children: c.title
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 785,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "mt-1 text-sm text-muted-foreground",
										"data-tsd-source": "/src/routes/awards.tsx:1042:17",
										children: c.desc
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 786,
										columnNumber: 17
									}, this)
								]
							}, c.title, true, {
								fileName: _jsxFileName,
								lineNumber: 783,
								columnNumber: 34
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 782,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 780,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("section", {
						className: "mt-10 rounded-3xl border border-border bg-card p-8 text-center",
						"data-tsd-source": "/src/routes/awards.tsx:1049:9",
						children: [
							/* @__PURE__ */ _jsxDEV(Award, {
								className: "mx-auto h-10 w-10 text-primary",
								"data-tsd-source": "/src/routes/awards.tsx:1050:11"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 793,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("h2", {
								className: "mt-3 font-display text-2xl font-bold",
								"data-tsd-source": "/src/routes/awards.tsx:1051:11",
								children: t("awards.cta") || "Make Your Verdict Count"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 794,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "mx-auto mt-2 max-w-md text-muted-foreground",
								"data-tsd-source": "/src/routes/awards.tsx:1052:11",
								children: t("awards.ctaNote") || "Every vote influences the annual standings."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 795,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV(Link, {
								to: "/brands",
								className: "mt-5 inline-flex items-center justify-center rounded-full bg-primary px-6 py-2.5 font-semibold text-primary-foreground transition-opacity hover:opacity-90",
								"data-tsd-source": "/src/routes/awards.tsx:1053:11",
								children: t("nav.brands") || "Explore Brand Directory"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 796,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 792,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 312,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(LiveBroadcastModal, {
				open: liveObserverModalOpen,
				onOpenChange: setLiveObserverModalOpen,
				brandName: activeObserverTopic,
				"data-tsd-source": "/src/routes/awards.tsx:1062:7"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 802,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 310,
		columnNumber: 10
	}, this);
}
_s(AwardsPage, "CVBMKvgFRehY5IPIWnY9Jxgw8mI=", false, function() {
	return [useTranslation, useQuery];
});
_c = AwardsPage;
const hot = import.meta.hot;
if (hot && typeof window !== "undefined") {
	hot.data ??= {};
	const tsrReactRefresh = window.__TSR_REACT_REFRESH__ ??= (() => {
		const ignoredExportsById = new Map();
		const previousGetIgnoredExports = window.__getReactRefreshIgnoredExports;
		window.__getReactRefreshIgnoredExports = (ctx) => {
			const ignoredExports = previousGetIgnoredExports?.(ctx) ?? [];
			const moduleIgnored = ignoredExportsById.get(ctx.id) ?? [];
			return [...ignoredExports, ...moduleIgnored];
		};
		return { ignoredExportsById };
	})();
	tsrReactRefresh.ignoredExportsById.set("/app/applet/src/routes/awards.tsx", ["Route"]);
}
export function TSRFastRefreshAnchor() {
	return null;
}
_c2 = TSRFastRefreshAnchor;
if (import.meta.hot) {
	const hot = import.meta.hot;
	const hotData = hot.data ??= {};
	const handleRouteUpdate = function handleRouteUpdate(routeId, newRoute) {
		const router = window.__TSR_ROUTER__;
		const oldRoute = router.routesById[routeId];
		if (!oldRoute) return;
		const generatedRouteOptionKeys = new Set([
			"id",
			"path",
			"getParentRoute"
		]);
		const generatedRouteOptions = {};
		generatedRouteOptionKeys.forEach((key) => {
			if (key in oldRoute.options) generatedRouteOptions[key] = oldRoute.options[key];
		});
		const preserveComponentIdentity = "shellComponent" in oldRoute.options === "shellComponent" in newRoute.options;
		const componentKeys = [
			"component",
			"shellComponent",
			"pendingComponent",
			"errorComponent",
			"notFoundComponent"
		];
		if (preserveComponentIdentity) componentKeys.forEach((key) => {
			if (key in oldRoute.options && key in newRoute.options) newRoute.options[key] = oldRoute.options[key];
		});
		const nextOptions = {
			...newRoute.options,
			...generatedRouteOptions
		};
		oldRoute.options = nextOptions;
		oldRoute.update(nextOptions);
		router._replaceRouteChunk(oldRoute, newRoute.lazyFn);
		router.setRoutes(router.buildRouteTree());
		syncHotRouteExport(oldRoute);
		router.resolvePathCache.clear();
		router._refreshRoute?.();
		function syncHotRouteExport(liveRoute) {
			newRoute.options = liveRoute.options;
			newRoute.parentRoute = liveRoute.parentRoute;
			newRoute._path = liveRoute._path;
			newRoute._id = liveRoute._id;
			newRoute._fullPath = liveRoute._fullPath;
			newRoute._to = liveRoute._to;
		}
	};
	const initialRouteId = "/awards" ?? hotData["tsr-route-id"];
	if (initialRouteId) {
		hotData["tsr-route-id"] = initialRouteId;
	}
	const existingRoute = typeof window !== "undefined" && initialRouteId ? window.__TSR_ROUTER__?.routesById?.[initialRouteId] : undefined;
	if (initialRouteId && existingRoute && existingRoute !== Route) {
		handleRouteUpdate(initialRouteId, Route);
		hotData["tsr-route-update-handled"] = Route;
	}
	hot.accept((newModule) => {
		if (Route && newModule && newModule.Route) {
			const routeId = hotData["tsr-route-id"] ?? "/awards";
			if (routeId) {
				hotData["tsr-route-id"] = routeId;
			}
			if (hotData["tsr-route-update-handled"] === newModule.Route) {
				delete hotData["tsr-route-update-handled"];
				return;
			}
			handleRouteUpdate(routeId, newModule.Route);
		}
	});
}
var _c, _c2;
$RefreshReg$(_c, "AwardsPage");
$RefreshReg$(_c2, "TSRFastRefreshAnchor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/awards.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/app/applet/src/routes/awards.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/applet/src/routes/awards.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/app/applet/src/routes/awards.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7OztBQUFBLFNBQUFBLGlCQUFBQyxZQUFBO0FBQ0EsU0FBQUMsZ0JBQUE7QUFDQSxTQUFBQyxzQkFBQTtBQUNBLFNBQUFDLFNBQUFDLGdCQUFBO0FBQ0EsU0FBQUMsY0FBQTtBQUNBLFNBQUFDLG1CQUFBO0FBQ0EsU0FBQUMsZ0JBQUE7QUFDQSxTQUNBQyxPQUNBQyxlQUNBQyxjQUNBQyxPQUVBQyxPQUVBQyxLQUNBQyxRQUNBQyxVQUNBQyxZQUNBQyxRQUNBQyxLQUNBQyxVQUNBQyxRQUNBQyxhQUNBQyxPQUNBQyxXQUNBQyxhQUNBQyxNQUNBQyxNQUNBQyxPQUNBQyxPQUNBQyxVQUNBQyxXQUNBQyxPQUNBQyxZQUNBQyxhQUNBO0FBQ0EsU0FBQUMsZUFBQUMsdUJBQUE7QUFDQSxTQUFBQyxhQUFBQyxnQkFBQUMsNEJBQUE7QUFDQSxTQUFBQyxVQUFBO0FBQ0EsU0FBQUMsNkJBQUE7QUFDQSxTQUFBQyxhQUFBQyxjQUFBQyxhQUFBQyxtQkFBQTtBQUNBLFNBQUFDLDBCQUFBO0FBQ0EsU0FBQUMsYUFBQTtBQUVBLGFBQUFDLFFBQUFoRCxnQkFBQTtDQUVBaUQsYUFBQSxFQUNBQyxNQUFBO0VBQ0EsRUFBQUMsT0FBQTtFQUNBO0dBQ0FDLE1BQUE7R0FDQUMsU0FDQTtFQUNBO0VBQ0E7R0FBQUMsVUFBQTtHQUFBRCxTQUFBO0VBQUE7RUFDQTtHQUNBQyxVQUFBO0dBQ0FELFNBQ0E7RUFDQTtFQUNBO0dBQUFDLFVBQUE7R0FBQUQsU0FBQTtFQUFBO0VBQ0E7R0FBQUQsTUFBQTtHQUFBQyxTQUFBO0VBQUE7Q0FBQSxFQUVBO0NBQ0FFLFdBQUFDO0FBQ0E7QUFxQkEsTUFBQUMsZ0NBQUE7Q0FDQTtFQUNBQyxJQUFBO0VBQ0FDLFVBQUE7RUFDQUMsY0FBQTtFQUNBVCxPQUFBO0VBQ0FVLGFBQ0E7RUFDQUMsc0JBQUE7RUFDQUMsYUFBQTtFQUNBQyxvQkFBQTtFQUNBQyxTQUFBLENBQ0E7R0FDQVAsSUFBQTtHQUNBUSxPQUFBO0dBQ0FDLFVBQUE7R0FDQUMsT0FBQTtFQUNBLEdBQ0E7R0FDQVYsSUFBQTtHQUNBUSxPQUFBO0dBQ0FDLFVBQUE7R0FDQUMsT0FBQTtFQUNBO0NBRUE7Q0FDQTtFQUNBVixJQUFBO0VBQ0FDLFVBQUE7RUFDQUMsY0FBQTtFQUNBVCxPQUFBO0VBQ0FVLGFBQ0E7RUFDQUMsc0JBQUE7RUFDQUMsYUFBQTtFQUNBQyxvQkFBQTtFQUNBQyxTQUFBLENBQ0E7R0FDQVAsSUFBQTtHQUNBUSxPQUFBO0dBQ0FDLFVBQUE7R0FDQUMsT0FBQTtFQUNBLEdBQ0E7R0FDQVYsSUFBQTtHQUNBUSxPQUFBO0dBQ0FDLFVBQUE7R0FDQUMsT0FBQTtFQUNBO0NBRUE7Q0FDQTtFQUNBVixJQUFBO0VBQ0FDLFVBQUE7RUFDQUMsY0FBQTtFQUNBVCxPQUFBO0VBQ0FVLGFBQ0E7RUFDQUMsc0JBQUE7RUFDQUMsYUFBQTtFQUNBQyxvQkFBQTtFQUNBQyxTQUFBLENBQ0E7R0FDQVAsSUFBQTtHQUNBUSxPQUFBO0dBQ0FDLFVBQUE7R0FDQUMsT0FBQTtFQUNBLEdBQ0E7R0FDQVYsSUFBQTtHQUNBUSxPQUFBO0dBQ0FDLFVBQUE7R0FDQUMsT0FBQTtFQUNBO0NBRUE7QUFBQTtBQUdBLGdCQUFBWixhQUFBOztDQUNBLFFBQUFhLE1BQUFsRSxlQUFBO0NBQ0EsUUFBQW1FLE1BQUFDLFFBQUFDLGNBQUF0RSxTQUFBO0VBQ0F1RSxVQUFBO0VBQ0FDLFNBQUFuRTtDQUNBO0NBRUEsT0FBQW9FLFVBQUFDLGVBQUF2RSxTQUFBO0NBQ0EsT0FBQXdFLFNBQUFDLGNBQUF6RSxTQUFBO0NBQ0EsT0FBQXNELFVBQUFvQixlQUFBMUUsU0FBQTtDQUNBLE9BQUEyRSxNQUFBQyxXQUFBNUUsU0FBQTtDQUNBLE9BQUE2RSxPQUFBQyxZQUFBOUUsU0FBQTtDQUNBLE9BQUErRSxRQUFBQyxhQUFBaEYsU0FBQTtDQUNBLE1BQUFpRixlQUFBbEYsY0FBQSxJQUFBbUYsS0FBQTs7Q0FHQSxPQUFBQyxTQUFBQyxjQUFBcEYsU0FBQW9ELDZCQUFBO0NBQ0EsT0FBQWlDLGVBQUFDLG9CQUFBdEYsU0FBQTtDQUNBLE9BQUF1Rix1QkFBQUMsNEJBQUF4RixTQUFBO0NBQ0EsT0FBQXlGLHFCQUFBQywwQkFBQTFGLFNBQUE7Q0FDQSxPQUFBMkYsZ0JBQUFDLHFCQUFBNUYsU0FBQTtDQUNBLE9BQUE2RixjQUFBQyxtQkFBQTlGLFNBQUE7Q0FDQSxPQUFBK0YsbUJBQUFDLHdCQUFBaEcsU0FBQTtDQUVBLE1BQUFpRywrQkFBQUMsVUFBQUMsYUFBQTtFQUNBLElBQUFkLGNBQUFhLFdBQUE7R0FDQXhELE1BQUEwRCxLQUFBO0dBQ0E7RUFDQTtFQUNBLE1BQUFDLGFBQUEsY0FBQUMsS0FBQUMsT0FBQSxFQUFBQyxTQUFBLElBQUFDLFVBQUEsTUFBQUMsWUFBQSxLQUFBeEIsS0FBQXlCLElBQUEsRUFBQUgsU0FBQSxJQUFBRSxZQUFBO0VBQ0F0QixZQUFBd0IsU0FDQUEsS0FBQUMsS0FBQUMsTUFDQUEsRUFBQXpELE9BQUE2QyxXQUNBWSxJQUNBO0dBQ0EsR0FBQUE7R0FDQW5ELG9CQUFBbUQsRUFBQW5ELHFCQUFBO0dBQ0FDLFNBQUFrRCxFQUFBbEQsUUFBQWlELEtBQUFFLFFBQUExRCxPQUFBOEMsV0FBQTtJQUFBLEdBQUFZO0lBQUFoRCxPQUFBZ0QsRUFBQWhELFFBQUE7R0FBQSxJQUFBZ0QsQ0FBQTtFQUNBLENBQ0EsQ0FDQTtFQUNBekIsa0JBQUFzQixVQUFBO0dBQ0EsR0FBQUE7SUFDQVYsV0FBQTtJQUNBQztJQUNBYSxNQUFBWDtJQUNBWSxXQUFBLElBQUEvQixLQUFBLEVBQUFnQyxtQkFBQTtHQUNBO0VBQ0E7RUFDQXhFLE1BQUF5RSxRQUFBLHNDQUFBZCxZQUFBO0NBQ0E7Q0FFQSxNQUFBZSw0QkFBQUMsTUFBQTtFQUNBQSxFQUFBQyxlQUFBO0VBQ0EsS0FBQTNCLGVBQUE0QixLQUFBLE1BQUExQixhQUFBMEIsS0FBQTtHQUNBN0UsTUFBQThFLE1BQUE7R0FDQTtFQUNBO0VBQ0EsTUFBQUMsVUFBQTtHQUNBcEUsSUFBQSxpQkFBQTZCLEtBQUF5QixJQUFBO0dBQ0FyRCxVQUFBeUM7R0FDQXhDLGNBQUFzQyxhQUFBMEIsS0FBQTtHQUNBekUsT0FBQTZDLGVBQUE0QixLQUFBO0dBQ0EvRCxhQUNBO0dBQ0FDLHNCQUFBO0dBQ0FDLGFBQUE7R0FDQUMsb0JBQUE7R0FDQUMsU0FBQSxDQUNBO0lBQ0FQLElBQUEsV0FBQTZCLEtBQUF5QixJQUFBO0lBQ0E5QyxPQUFBO0lBQ0FDLFVBQUE7SUFDQUMsT0FBQTtHQUNBLEdBQ0E7SUFDQVYsSUFBQSxVQUFBNkIsS0FBQXlCLElBQUE7SUFDQTlDLE9BQUE7SUFDQUMsVUFBQTtJQUNBQyxPQUFBO0dBQ0E7RUFFQTtFQUNBcUIsWUFBQXdCLFNBQUEsQ0FBQWEsU0FBQSxHQUFBYixJQUFBO0VBQ0FoQixrQkFBQTtFQUNBRSxnQkFBQTtFQUNBcEQsTUFBQXlFLFFBQUE7Q0FDQTtDQUVBLE1BQUFPLFlBQUEzSCxjQUFBLHFCQUFBa0MsZ0JBQUFpQyxVQUFBLElBQUEyQyxLQUFBYyxnQkFBQW5ELE9BQUEsTUFBQU4sTUFBQTtDQUNBLE1BQUEwRCxhQUFBN0gsY0FBQWdDLGlCQUFBbUMsVUFBQSxJQUFBMkMsS0FBQWMsVUFBQTdGLGNBQUE2RixNQUFBNUUsTUFBQTRFLE1BQUFyRSxRQUFBLE1BQUFZLE1BQUE7O0NBR0EsTUFBQTJELGlCQUFBOUgsY0FBQTtFQUNBLE1BQUErSCxPQUFBakQsTUFBQTBDLEtBQUEsRUFBQVEsWUFBQTtFQUNBLFFBQUE3RCxVQUFBLElBQUE4RCxRQUFBTCxVQUFBO0dBQ0EsTUFBQU0sb0JBQUEvRixxQkFBQXlGLE1BQUFuRCxPQUFBO0dBQ0EsTUFBQTBELHFCQUFBcEcsY0FBQTZGLE1BQUE1RSxNQUFBNEUsTUFBQXJFLFFBQUE7R0FDQSxNQUFBNkUsWUFBQTdGLGFBQUFxRixNQUFBNUUsTUFBQTRFLE1BQUFyRSxRQUFBO0dBQ0EsTUFBQThFLGFBQUEsR0FBQVQsTUFBQTVFLEtBQUEsR0FBQWYsWUFBQWlHLGlCQUFBLEtBQUFDLG1CQUFBLEdBQUFDLFlBQUFKLFlBQUE7R0FDQSxRQUFBdkQsWUFBQSxtQkFBQXlELHNCQUFBekQsYUFDQWxCLGFBQUEsb0JBQUE0RSx1QkFBQTVFLGNBQ0FxQixTQUFBLGVBQUFuQyxZQUFBMkYsV0FBQXhELElBQUEsT0FDQSxDQUFBbUQsUUFBQU0sV0FBQUMsU0FBQVAsSUFBQTtFQUNBLEdBQUFRLE1BQUFDLEdBQUF6QixPQUFBMEIsT0FBQTFCLEVBQUEyQixXQUFBLFdBQUFELE9BQUFELEVBQUFFLFdBQUE7Q0FDQTtFQUFBdkU7RUFBQVo7RUFBQWtCO0VBQUFHO0VBQUFFO0NBQUE7Q0FFQSxNQUFBNkQsTUFBQWIsZUFBQWMsTUFBQTtDQUNBLE1BQUFDLGNBQUFwRSxZQUFBLHVDQUFBeEMsWUFBQXdDLE9BQUE7O0NBR0EsTUFBQXFFLGtCQUFBOUksY0FBQTtFQUNBLE1BQUErSSxVQUFBO0dBQ0E7SUFDQXpGLElBQUE7SUFDQVAsT0FBQTtJQUNBaUcsTUFBQWpJO0lBQ0EwQyxhQUFBO0lBQ0F3RixRQUFBQyxZQUFBbEIsWUFBQSxFQUFBTSxTQUFBLFdBQUFZLElBQUFsQixZQUFBLEVBQUFNLFNBQUEsV0FBQVksSUFBQWxCLFlBQUEsRUFBQU0sU0FBQTtHQUNBO0dBQ0E7SUFDQWhGLElBQUE7SUFDQVAsT0FBQTtJQUNBaUcsTUFBQWhJO0lBQ0F5QyxhQUFBO0lBQ0F3RixRQUFBQyxZQUFBbEIsWUFBQSxFQUFBTSxTQUFBLFdBQUFZLElBQUFsQixZQUFBLEVBQUFNLFNBQUEsaUJBQUFZLElBQUFsQixZQUFBLEVBQUFNLFNBQUEsYUFBQVksSUFBQWxCLFlBQUEsRUFBQU0sU0FBQTtHQUNBO0dBQ0E7SUFDQWhGLElBQUE7SUFDQVAsT0FBQTtJQUNBaUcsTUFBQS9IO0lBQ0F3QyxhQUFBO0lBQ0F3RixRQUFBQyxZQUFBbEIsWUFBQSxFQUFBTSxTQUFBLFdBQUFZLElBQUFsQixZQUFBLEVBQUFNLFNBQUEsZUFBQVksSUFBQWxCLFlBQUEsRUFBQU0sU0FBQTtHQUNBO0dBQ0E7SUFDQWhGLElBQUE7SUFDQVAsT0FBQTtJQUNBaUcsTUFBQTlIO0lBQ0F1QyxhQUFBO0lBQ0F3RixRQUFBQyxZQUFBbEIsWUFBQSxFQUFBTSxTQUFBLGFBQUFZLElBQUFsQixZQUFBLEVBQUFNLFNBQUEsaUJBQUFZLElBQUFsQixZQUFBLEVBQUFNLFNBQUEsa0JBQUFZLElBQUFsQixZQUFBLEVBQUFNLFNBQUE7R0FDQTtHQUNBO0lBQ0FoRixJQUFBO0lBQ0FQLE9BQUE7SUFDQWlHLE1BQUE3SDtJQUNBc0MsYUFBQTtJQUNBd0YsUUFBQUMsWUFBQWxCLFlBQUEsRUFBQU0sU0FBQSxjQUFBWSxJQUFBbEIsWUFBQSxFQUFBTSxTQUFBLGNBQUFZLElBQUFsQixZQUFBLEVBQUFNLFNBQUEsZUFBQVksSUFBQWxCLFlBQUEsRUFBQU0sU0FBQTtHQUNBO0dBQ0E7SUFDQWhGLElBQUE7SUFDQVAsT0FBQTtJQUNBaUcsTUFBQTVIO0lBQ0FxQyxhQUFBO0lBQ0F3RixRQUFBQyxZQUFBbEIsWUFBQSxFQUFBTSxTQUFBLFdBQUFZLElBQUFsQixZQUFBLEVBQUFNLFNBQUEsY0FBQVksSUFBQWxCLFlBQUEsRUFBQU0sU0FBQTtHQUNBO0VBQUE7RUFHQSxPQUFBUyxRQUFBakMsS0FBQXFDLFFBQUE7R0FDQSxNQUFBQyxnQkFBQWpGLFVBQUEsSUFBQThELFFBQUFsQixNQUFBO0lBQ0EsTUFBQW1DLE1BQUFuSCxjQUFBZ0YsRUFBQS9ELE1BQUErRCxFQUFBeEQsUUFBQTtJQUNBLE1BQUE4RixpQkFBQTVFLFlBQUEsbUJBQUF0QyxxQkFBQTRFLEVBQUF0QyxPQUFBLE1BQUFBO0lBQ0EsT0FBQTRFLGtCQUFBRixJQUFBRixNQUFBQyxHQUFBO0dBQ0EsR0FBQVgsTUFBQUMsR0FBQXpCLE9BQUEwQixPQUFBMUIsRUFBQTJCLFdBQUEsV0FBQUQsT0FBQUQsRUFBQUUsV0FBQTtHQUVBO0lBQ0EsR0FBQVM7SUFDQUcsU0FBQUYsYUFBQVIsTUFBQTtJQUNBVyxZQUFBSCxhQUFBSTtHQUNBO0VBQ0E7Q0FDQSxJQUFBckYsUUFBQU0sT0FBQTs7Q0FHQSxNQUFBZ0YsZUFBQXpKLGNBQUE7RUFDQSxNQUFBMEosV0FBQTtHQUFBO0dBQUE7R0FBQTtHQUFBO0VBQUE7RUFDQSxPQUFBQSxTQUFBNUMsS0FBQTZDLE9BQUE7R0FDQSxNQUFBdEQsT0FBQTdELFlBQUFtSCxFQUFBO0dBQ0EsTUFBQUMsY0FBQXpGLFVBQUEsSUFBQThELFFBQUFsQixNQUFBO0lBQ0EsTUFBQXNDLGlCQUFBNUUsWUFBQSxtQkFBQXRDLHFCQUFBNEUsRUFBQXRDLE9BQUEsTUFBQUE7SUFDQSxNQUFBb0YsUUFBQXRILGFBQUF3RSxFQUFBL0QsTUFBQStELEVBQUF4RCxRQUFBO0lBQ0EsT0FBQThGLGtCQUFBUSxVQUFBRjtHQUNBLEdBQUFwQixNQUFBQyxHQUFBekIsT0FBQTBCLE9BQUExQixFQUFBMkIsV0FBQSxXQUFBRCxPQUFBRCxFQUFBRSxXQUFBO0dBRUE7SUFDQW9CLFNBQUFIO0lBQ0F0RDtJQUNBaUQsU0FBQU0sV0FBQWhCLE1BQUE7SUFDQVcsWUFBQUssV0FBQUo7R0FDQTtFQUNBO0NBQ0EsSUFBQXJGLFFBQUFNLE9BQUE7Q0FFQSxNQUFBc0YsYUFBQTtFQUNBO0dBQUFmLE1BQUF4STtHQUFBdUMsT0FBQWtCLEVBQUE7R0FBQStGLE1BQUEvRixFQUFBO0VBQUE7RUFDQTtHQUFBK0UsTUFBQXZJO0dBQUFzQyxPQUFBa0IsRUFBQTtHQUFBK0YsTUFBQS9GLEVBQUE7RUFBQTtFQUNBO0dBQUErRSxNQUFBbkk7R0FBQWtDLE9BQUFrQixFQUFBO0dBQUErRixNQUFBL0YsRUFBQTtFQUFBO0VBQ0E7R0FBQStFLE1BQUFwSTtHQUFBbUMsT0FBQWtCLEVBQUE7R0FBQStGLE1BQUEvRixFQUFBO0VBQUE7Q0FBQTtDQUdBLE9BQ0E7RUFBQTtFQUFBO1lBQUE7R0FDQSxvRkFBYzs7Ozs7R0FDZDtJQUFBO0lBQUE7Y0FBQTtLQUVBO01BQUE7TUFBQTtnQkFBQTtPQUNBO1FBQUE7UUFBQTtPQUE2RDs7Ozs7T0FDN0Q7UUFBQTtRQUFBO2tCQUErRUEsRUFBQTtPQUFBOzs7OztPQUMvRTtRQUFBO1FBQUE7a0JBQ0FBLEVBQUE7T0FDQTs7Ozs7T0FDQTtRQUFBO1FBQUE7a0JBQ0Esb0dBQW1DOzs7OztPQUNuQzs7Ozs7T0FDQTtRQUFBO1FBQUE7a0JBQTBHO09BRzFHOzs7OztPQUdBO1FBQUE7UUFBQTtrQkFBQSxDQUNBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtTQUF3RDs7OzttQkFDeEQ7VUFBQTtvQkFBbUI7U0FBQTs7OztpQkFDbkI7Ozs7O2tCQUNBO1NBQUE7U0FBQTttQkFBaUc7UUFFakc7Ozs7Z0JBQ0E7Ozs7OztNQUNBOzs7Ozs7S0FHQTtNQUFBO01BQUE7Z0JBQUE7T0FDQTtRQUFBO1FBQUE7a0JBQUEsQ0FDQTtTQUFBO21CQUFBLENBQ0E7VUFBQTtVQUFBO29CQUE2REEsRUFBQTtTQUFBOzs7O21CQUM3RDtVQUFBO1VBQUE7b0JBQWlFO1NBRWpFOzs7O2lCQUNBOzs7OztrQkFFQTtTQUFBO1NBQUE7bUJBQUE7VUFDQTtXQUNBO1dBQ0EsZUFBQU8sWUFBQTtXQUNBLFdBQUFwQyxHQUNBLCtEQUNBbUMsYUFBQSxlQUNBLDRDQUNBLDZDQUNBO1dBQ0E7cUJBQWM7VUFFZDs7Ozs7VUFDQTtXQUNBO1dBQ0EsZUFBQUMsWUFBQTtXQUNBLFdBQUFwQyxHQUNBLCtEQUNBbUMsYUFBQSxVQUNBLDRDQUNBLDZDQUNBO1dBQ0E7cUJBQWM7VUFFZDs7Ozs7VUFDQTtXQUNBO1dBQ0EsZUFBQUMsWUFBQTtXQUNBLFdBQUFwQyxHQUNBLCtEQUNBbUMsYUFBQSxXQUNBLDRDQUNBLDZDQUNBO1dBQ0E7cUJBQWM7VUFFZDs7Ozs7VUFDQTtXQUNBO1dBQ0EsZUFBQUMsWUFBQTtXQUNBLFdBQUFwQyxHQUNBLHFGQUNBbUMsYUFBQSxrQkFDQSwwQ0FDQSx3Q0FDQTtXQUNBO3FCQVRBLENBVUE7WUFBQTtZQUFBO1dBQTZEOzs7O3FCQUFBLCtDQUU3RDs7Ozs7O1NBQ0E7Ozs7O2dCQUNBOzs7Ozs7T0FHQTtRQUFBO1FBQUE7a0JBQUEsQ0FDQTtTQUFBO1NBQUE7bUJBQUE7VUFDQTtXQUFBO1dBQUE7VUFBb0Q7Ozs7O1VBQ3BEO1dBQUE7cUJBQW1CO1VBQUE7Ozs7O1VBQ25CO1dBQ0EsT0FBQUU7V0FDQSxXQUFBNkMsTUFBQTVDLFdBQUE0QyxFQUFBMkMsT0FBQUMsS0FBQTtXQUNBO1dBQ0E7cUJBQ0F2QyxVQUFBYixLQUFBcUQsTUFDQTtZQUFBLE9BQUFBO1lBQUE7c0JBQ0FBLE1BQUEsNkNBQUFsSSxZQUFBa0ksQ0FBQTtXQUNBLEdBRkFBOzs7O2tCQUVBLENBQ0E7VUFDQTs7Ozs7U0FDQTs7Ozs7a0JBRUE7U0FBQTtTQUFBO21CQUFBO1VBQ0E7V0FBQTtXQUFBO1VBQWtFOzs7OztVQUNsRTtXQUFBO3FCQUFtQm5GO1VBQUE7Ozs7O1VBQ25CO1dBQUE7cUJBQUEsQ0FBbUIsZUFBQUUsYUFBQWtGLG1CQUFBOzs7Ozs7U0FDbkI7Ozs7O2dCQUNBOzs7Ozs7T0FHQTdGLGFBQUEsZ0JBQ0E7UUFBQTtRQUFBO2tCQUFBLENBQ0E7U0FBQTtTQUFBO21CQUFBLENBQ0E7VUFBQTtVQUFBO29CQUEyRDtTQUFBOzs7O21CQUFBLHdLQUUzRDs7Ozs7a0JBRUE7U0FBQTtTQUFBO21CQUNBdUUsZ0JBQUFoQyxLQUFBdUQsV0FBQTtVQUNBLE1BQUFDLE9BQUFELE9BQUFyQjtVQUNBLE9BQ0E7V0FBQTtXQUFBO3FCQUFBLENBQ0E7WUFBQTtzQkFBQTthQUNBO2NBQUE7Y0FBQTt3QkFBQSxDQUNBO2VBQUE7ZUFBQTt5QkFDQTtnQkFBQTtnQkFBQTtlQUFzRDs7Ozs7Y0FDdEQ7Ozs7d0JBQ0E7ZUFBQTt5QkFBQSxDQUNBO2dCQUFBO2dCQUFBOzBCQUE0RXFCLE9BQUF0SDtlQUFBOzs7O3lCQUM1RTtnQkFBQTtnQkFBQTswQkFBQSxDQUE0RXNILE9BQUFkLFlBQUE7Ozs7O3VCQUM1RTs7Ozs7c0JBQ0E7Ozs7OzthQUNBO2NBQUE7Y0FBQTt3QkFBeUVjLE9BQUE1RzthQUFBOzs7OzthQUV6RTtjQUFBO2NBQUE7d0JBQ0E0RyxPQUFBZixRQUFBRSxXQUFBLElBQ0E7ZUFBQTtlQUFBO3lCQUF5RjtjQUFBOzs7O3lCQUV6RmEsT0FBQWYsUUFBQXhDLEtBQUFDLEdBQUF3RCxRQUFBO2VBQ0EsTUFBQVYsUUFBQXRILGFBQUF3RSxFQUFBL0QsTUFBQStELEVBQUF4RCxRQUFBO2VBQ0EsTUFBQWlILFFBQUFoSSxZQUFBcUgsS0FBQTtlQUNBLE9BQ0E7Z0JBRUE7Z0JBQ0EsVUFBQVksTUFBQTFELEVBQUEwRCxLQUFBO2dCQUNBO2dCQUNBOzBCQUxBLENBTUE7aUJBQUE7aUJBQUE7MkJBQUE7a0JBQ0E7bUJBQUE7bUJBQUE7NkJBQ0FGLFFBQUEsV0FBQUEsUUFBQSxXQUFBQSxRQUFBLGNBQUFBLE1BQUE7a0JBQ0E7Ozs7O2tCQUNBO21CQUFBO21CQUFBOzZCQUNBeEQsRUFBQTJELGdCQUNBO29CQUFBLEtBQUEzRCxFQUFBMkQ7b0JBQUEsS0FBQTNELEVBQUEvRDtvQkFBQTtvQkFBQTttQkFBK0g7Ozs7OEJBRS9IK0QsRUFBQS9ELEtBQUEySCxPQUFBO2tCQUVBOzs7OztrQkFDQTttQkFBQTttQkFBQTs2QkFBQSxDQUNBO29CQUFBO29CQUFBOzhCQUF1RjVELEVBQUEvRDttQkFBQTs7Ozs2QkFDdkY7b0JBQUEsV0FBQVosR0FBQSxnREFBQW9JLE1BQUFJLFVBQUE7b0JBQUE7OEJBQUE7cUJBQ0FKLE1BQUFLO3FCQUFBO3FCQUFBTCxNQUFBTTtvQkFDQTs7Ozs7MkJBQ0E7Ozs7OztpQkFDQTs7Ozs7MEJBQ0E7aUJBQUE7aUJBQUE7MkJBQUEsQ0FDQTtrQkFBQTtrQkFBQTtpQkFBb0U7Ozs7MkJBQ3BFO2tCQUFBOzRCQUFBLENBQXlDL0QsRUFBQTJCLGFBQUE7Ozs7O3lCQUN6Qzs7Ozs7d0JBQ0E7a0JBM0JBM0IsRUFBQXpEOzs7O3NCQTJCQTtjQUVBO2FBRUE7Ozs7O1lBQ0E7Ozs7O3FCQUVBO1lBQUE7WUFBQTtzQkFDQTthQUNBO2FBQ0E7YUFDQTt1QkFIQTtjQUd3QjtjQUN4QitHLE9BQUF0SDtjQUFBO2FBQ0E7Ozs7OztXQUNBOzs7O21CQUNBO2FBaEVBc0gsT0FBQS9HOzs7O2lCQWdFQTtTQUVBO1FBQ0E7Ozs7Z0JBQ0E7Ozs7OztPQUlBaUIsYUFBQSxXQUNBO1FBQUE7UUFBQTtrQkFBQSxDQUNBO1NBQUE7U0FBQTttQkFBQSxDQUNBO1VBQUE7VUFBQTtvQkFBMkQ7U0FBQTs7OzttQkFBQSwwSUFFM0Q7Ozs7O2tCQUVBO1NBQUE7U0FBQTttQkFDQWtGLGFBQUEzQyxLQUFBaUUsWUFBQTtVQUNBLE9BQ0E7V0FFQSxXQUFBM0ksR0FDQSwwRUFDQTJJLFFBQUExRSxLQUFBMkUsV0FDQTtXQUNBO3FCQU5BLENBT0E7WUFBQTtzQkFBQTthQUNBO2NBQUE7Y0FBQTt3QkFBQSxDQUNBO2VBQUEsV0FBQTVJLEdBQUEsbURBQUEySSxRQUFBMUUsS0FBQXVFLFVBQUE7ZUFBQTt5QkFBQTtnQkFDQUcsUUFBQTFFLEtBQUF3RTtnQkFBQTtnQkFBQUUsUUFBQWpCO2VBQ0E7Ozs7O3dCQUNBO2VBQUE7ZUFBQTt5QkFBQSxDQUNBaUIsUUFBQXhCLFlBQUEsU0FDQTs7Ozs7c0JBQ0E7Ozs7OzthQUNBO2NBQUE7Y0FBQTt3QkFBc0Z3QixRQUFBMUUsS0FBQXZDO2FBQUE7Ozs7O2FBQ3RGO2NBQUE7Y0FBQTt3QkFBaUdpSCxRQUFBMUUsS0FBQTVDO2FBQUE7Ozs7O2FBRWpHO2NBQUE7Y0FBQTt3QkFDQXNILFFBQUF6QixRQUFBRSxXQUFBLElBQ0E7ZUFBQTtlQUFBO3lCQUF5RjtjQUFBOzs7O3lCQUV6RnVCLFFBQUF6QixRQUFBeEMsS0FBQUMsR0FBQXdELFFBQ0E7ZUFFQTtlQUNBLFVBQUFFLE1BQUExRCxFQUFBMEQsS0FBQTtlQUNBO2VBQ0E7eUJBTEEsQ0FNQTtnQkFBQTtnQkFBQTswQkFBQSxDQUNBO2lCQUFBO2lCQUFBOzJCQUNBRixNQUFBO2dCQUNBOzs7OzBCQUNBO2lCQUFBO2lCQUFBOzJCQUFBLENBQ0E7a0JBQUE7a0JBQUE7NEJBQXFGeEQsRUFBQS9EO2lCQUFBOzs7OzJCQUNyRjtrQkFBQTtrQkFBQTs0QkFBNkZqQixjQUFBZ0YsRUFBQS9ELE1BQUErRCxFQUFBeEQsUUFBQTtpQkFBQTs7Ozt5QkFDN0Y7Ozs7O3dCQUNBOzs7Ozt5QkFDQTtnQkFBQTtnQkFBQTswQkFBQSxDQUNBd0QsRUFBQTJCLGFBQUEsR0FDQTs7Ozs7dUJBQ0E7aUJBakJBM0IsRUFBQXpEOzs7O3FCQWlCQSxDQUNBO2FBRUE7Ozs7O1lBQ0E7Ozs7O3FCQUVBO1lBQUE7WUFBQTtzQkFDQTthQUNBO2FBQ0E7YUFDQTt1QkFIQTtjQUd3QjtjQUN4QnlILFFBQUFqQjtjQUFBO2FBQ0E7Ozs7OztXQUNBOzs7O21CQUNBO2FBdkRBaUIsUUFBQWpCOzs7O2lCQXVEQTtTQUVBO1FBQ0E7Ozs7Z0JBQ0E7Ozs7OztPQUlBdkYsYUFBQSxZQUNBO1FBQUE7UUFBQTtrQkFBQSxDQUNBO1NBQUE7U0FBQTttQkFDQTtVQUFBO1VBQUE7b0JBQUE7V0FDQTtZQUFBO1lBQUE7c0JBQUEsQ0FDQTthQUFBO2FBQUE7WUFBc0U7Ozs7c0JBQ3RFO2FBQ0EsT0FBQU87YUFDQSxXQUFBd0MsTUFBQXZDLFNBQUF1QyxFQUFBMkMsT0FBQUMsS0FBQTthQUNBO2FBQ0E7YUFDQTtZQUFvQjs7OztvQkFDcEI7Ozs7OztXQUVBO1lBQ0EsT0FBQTNHO1lBQ0EsV0FBQStELE1BQUEzQyxZQUFBMkMsRUFBQTJDLE9BQUFDLEtBQUE7WUFDQTtZQUNBO3NCQUNBckMsV0FBQWYsS0FBQXFELE1BQ0E7YUFBQSxPQUFBQTthQUFBO3VCQUErQ0E7WUFBQSxHQUEvQ0E7Ozs7bUJBQStDLENBQy9DO1dBQ0E7Ozs7O1dBRUE7WUFDQSxPQUFBdkY7WUFDQSxXQUFBMEMsTUFBQXpDLFFBQUF5QyxFQUFBMkMsT0FBQUMsS0FBQTtZQUNBO1lBQ0E7c0JBQ0E1SCxZQUFBd0UsS0FBQTdDLE1BQ0E7YUFBQSxPQUFBQTthQUFBO3VCQUErQ0E7WUFBQSxHQUEvQ0E7Ozs7bUJBQStDLENBQy9DO1dBQ0E7Ozs7O1VBQ0E7Ozs7OztRQUNBOzs7O2tCQUdBO1NBQUE7U0FBQTttQkFDQUcsWUFDQTtVQUFBO1VBQUE7b0JBQ0E7V0FBQTtXQUFBO1dBQUE7V0FBQTtVQUFBLEVBQUEwQyxLQUFBbUUsTUFDQTtXQUFBO1dBQUE7VUFBNkUsR0FBN0VBOzs7O2lCQUE2RSxDQUM3RTtTQUNBOzs7O29CQUNBdEMsSUFBQWEsV0FBQSxJQUNBO1VBQUE7VUFBQTtvQkFBOEU7U0FBQTs7OztvQkFFOUViLElBQUE3QixLQUFBQyxHQUFBa0UsTUFBQTtVQUNBLE1BQUFwQixRQUFBdEgsYUFBQXdFLEVBQUEvRCxNQUFBK0QsRUFBQXhELFFBQUE7VUFDQSxNQUFBMkgsV0FBQTFJLFlBQUFxSCxLQUFBO1VBQ0EsT0FDQTtXQUVBO1dBQ0EsVUFBQVksTUFBQTFELEVBQUEwRCxLQUFBO1dBQ0E7V0FDQTtxQkFMQTtZQU1BO2FBQUE7YUFBQTt1QkFDQVEsSUFBQTtjQUFBO2NBQUE7Y0FBQTthQUFBLEVBQUFBLFNBQUE7WUFDQTs7Ozs7WUFDQTthQUFBO2FBQUE7dUJBQ0FsRSxFQUFBMkQsZ0JBQ0E7Y0FBQSxLQUFBM0QsRUFBQTJEO2NBQUEsS0FBQTNELEVBQUEvRDtjQUFBO2NBQUE7YUFBMkc7Ozs7d0JBRTNHK0QsRUFBQS9ELEtBQUEySCxPQUFBLEdBQUFoRSxZQUFBO1lBRUE7Ozs7O1lBQ0E7YUFBQTthQUFBO3VCQUFBLENBQ0E7Y0FBQTtjQUFBO3dCQUFBLENBQ0E7ZUFBQTtlQUFBO3lCQUFzREksRUFBQS9EO2NBQUE7Ozs7d0JBQ3REO2VBQ0EsV0FBQVosR0FDQSwrR0FDQThJLFNBQUFOLFVBQ0E7ZUFDQTt5QkFMQSxDQU1BO2dCQUFBO2dCQUFBOzBCQUErRU0sU0FBQUw7ZUFBQTs7Ozt5QkFDL0U7Z0JBQUE7MEJBQW1DSyxTQUFBSjtlQUFBOzs7O3VCQUNuQzs7Ozs7c0JBQ0E7Ozs7O3VCQUNBO2NBQUE7Y0FBQTt3QkFBQTtlQUNBN0ksWUFBQUUscUJBQUE0RSxFQUFBdEMsT0FBQTtlQUFBO2VBQUExQyxjQUFBZ0YsRUFBQS9ELE1BQUErRCxFQUFBeEQsUUFBQTtjQUNBOzs7OztxQkFDQTs7Ozs7O1lBQ0E7YUFBQTthQUFBO3VCQUFBO2NBQ0E7ZUFBQTtlQUFBO2NBQTBEOzs7OztjQUMxRHdELEVBQUEyQjtjQUFBO2FBQ0E7Ozs7OztXQUNBO2FBcENBM0IsRUFBQXpEOzs7O2lCQW9DQTtTQUVBO1FBRUE7Ozs7Z0JBQ0E7Ozs7OztPQUlBaUIsYUFBQSxtQkFDQTtRQUFBO1FBQUE7a0JBQUE7U0FFQTtVQUFBO1VBQUE7b0JBQUEsQ0FDQTtXQUFBO1dBQUE7cUJBQUEsQ0FDQTtZQUFBO1lBQUE7c0JBQUE7YUFDQTtjQUFBO2NBQUE7d0JBQUEsQ0FDQTtlQUFBO2VBQUE7Y0FBb0Q7Ozs7d0JBQUEsc0RBRXBEOzs7Ozs7YUFDQTtjQUFBO2NBQUE7d0JBQW1GO2FBRW5GOzs7OzthQUNBO2NBQUE7Y0FBQTt3QkFBQTtlQUFvRjtlQUNwRjtnQkFBQTtnQkFBQTswQkFBNks7ZUFBQTs7Ozs7ZUFBQTtlQUFBO2dCQUFBOzBCQUFrRjtlQUFBOzs7OztlQUFBO2VBQUE7Z0JBQUE7MEJBQStCO2VBQUE7Ozs7O2VBQUE7ZUFBQTtnQkFBQTswQkFBNEQ7ZUFBQTs7Ozs7ZUFBQTtjQUMxVjs7Ozs7O1lBQ0E7Ozs7O3FCQUNBO1lBQUE7WUFBQTtzQkFBQSxDQUNBO2FBQ0E7YUFDQTtjQUNBb0IsdUJBQUE7Y0FDQUYseUJBQUE7YUFDQTthQUNBO2FBQ0E7dUJBUEEsQ0FRQTtjQUFBO2NBQUE7YUFBaUQ7Ozs7dUJBQUEsb0NBRWpEOzs7OztzQkFDQTthQUFBO2FBQUE7dUJBQTRFO1lBRTVFOzs7O29CQUNBOzs7OzttQkFDQTs7Ozs7b0JBRUE7V0FBQTtXQUFBO3FCQUFBO1lBQ0E7YUFBQTthQUFBO3VCQUFBLENBQ0E7Y0FBQTtjQUFBO2FBQThFOzs7O3VCQUM5RTtjQUFBO3dCQUFBLENBQ0E7ZUFBQTtlQUFBO3lCQUF5RDtjQUFBOzs7O3dCQUN6RDtlQUFBO2VBQUE7eUJBQStEO2NBQUE7Ozs7c0JBQy9EOzs7OztxQkFDQTs7Ozs7O1lBQ0E7YUFBQTthQUFBO3VCQUFBLENBQ0E7Y0FBQTtjQUFBO2FBQWlGOzs7O3VCQUNqRjtjQUFBO3dCQUFBLENBQ0E7ZUFBQTtlQUFBO3lCQUF5RDtjQUFBOzs7O3dCQUN6RDtlQUFBO2VBQUE7eUJBQStEO2NBQUE7Ozs7c0JBQy9EOzs7OztxQkFDQTs7Ozs7O1lBQ0E7YUFBQTthQUFBO3VCQUFBLENBQ0E7Y0FBQTtjQUFBO2FBQWtGOzs7O3VCQUNsRjtjQUFBO3dCQUFBLENBQ0E7ZUFBQTtlQUFBO3lCQUF5RDtjQUFBOzs7O3dCQUN6RDtlQUFBO2VBQUE7eUJBQStEO2NBQUE7Ozs7c0JBQy9EOzs7OztxQkFDQTs7Ozs7O1dBQ0E7Ozs7O2tCQUNBOzs7Ozs7U0FHQTtVQUFBO1VBQUE7b0JBQ0FMLFFBQUEwQixLQUFBcUUsV0FBQTtXQUNBLE1BQUFDLFVBQUE5RixjQUFBNkYsT0FBQTdIO1dBQ0EsT0FDQTtZQUVBO1lBQ0E7c0JBSEE7YUFJQTtjQUFBO2NBQUE7d0JBQUEsQ0FDQTtlQUFBO3lCQUFBO2dCQUNBO2lCQUFBO2lCQUFBOzJCQUFBLENBQ0E7a0JBQUE7a0JBQUE7NEJBQ0E2SCxPQUFBNUg7aUJBQ0E7Ozs7MkJBQ0E7a0JBQUE7a0JBQUE7NEJBQ0E0SCxPQUFBM0g7aUJBQ0E7Ozs7eUJBQ0E7Ozs7OztnQkFDQTtpQkFBQTtpQkFBQTsyQkFDQTJILE9BQUFwSTtnQkFDQTs7Ozs7Z0JBQ0E7aUJBQUE7aUJBQUE7MkJBQ0FvSSxPQUFBMUg7Z0JBQ0E7Ozs7O2VBQ0E7Ozs7O3dCQUVBO2VBQUE7ZUFBQTt5QkFBQTtnQkFDQTtpQkFBQTtpQkFBQTsyQkFBQTtrQkFDQTttQkFBQTttQkFBQTtrQkFBa0U7Ozs7O2tCQUNsRTBILE9BQUF2SCxtQkFBQXlILGVBQUE7a0JBQUE7aUJBQ0E7Ozs7OztnQkFDQTtpQkFBQTtpQkFBQTsyQkFBNkVGLE9BQUF4SDtnQkFBQTs7Ozs7Z0JBQzdFO2lCQUNBO2lCQUNBO2tCQUNBZ0MsdUJBQUEsR0FBQXdGLE9BQUEzSCxhQUFBLElBQUEySCxPQUFBcEksT0FBQTtrQkFDQTBDLHlCQUFBO2lCQUNBO2lCQUNBO2lCQUNBOzJCQVBBLENBUUE7a0JBQUE7a0JBQUE7aUJBQW1GOzs7OzJCQUFBLGtDQUVuRjs7Ozs7O2VBQ0E7Ozs7O3NCQUNBOzs7Ozs7YUFHQTtjQUFBO2NBQUE7d0JBQ0EwRixPQUFBdEgsUUFBQWlELEtBQUF3RSxRQUFBO2VBQ0EsTUFBQUMsTUFDQUosT0FBQXZILHFCQUFBLElBQ0EyQyxLQUFBaUYsTUFBQUYsSUFBQXRILFFBQUFtSCxPQUFBdkgscUJBQUEsT0FDQTtlQUNBLE1BQUE2SCxhQUFBTCxTQUFBaEYsYUFBQWtGLElBQUFoSTtlQUNBLE9BQ0E7Z0JBRUEsV0FBQWxCLEdBQ0Esc0VBQ0FxSixhQUNBLGtEQUNBLHVEQUNBO2dCQUNBOzBCQVJBLENBU0E7aUJBQUE7MkJBQUEsQ0FDQTtrQkFBQTtrQkFBQTs0QkFBQSxDQUNBO21CQUFBO21CQUFBOzZCQUNBSCxJQUFBeEg7a0JBQ0E7Ozs7NEJBQ0E7bUJBQUE7bUJBQUE7NkJBQUEsQ0FDQXlILEtBQUEsR0FDQTs7Ozs7MEJBQ0E7Ozs7OzJCQUNBO2tCQUFBO2tCQUFBOzRCQUFpRkQsSUFBQXZIO2lCQUFBOzs7O3lCQUNqRjs7Ozs7MEJBRUE7aUJBQUE7aUJBQUE7MkJBQUEsQ0FDQTtrQkFBQTtrQkFBQTs0QkFDQTttQkFDQSxXQUFBM0IsR0FDQSxtREFDQXFKLGFBQUEsK0JBQ0E7bUJBQ0EsU0FBQUMsT0FBQSxHQUFBSCxJQUFBO21CQUNBO2tCQUFrQzs7Ozs7aUJBQ2xDOzs7OzJCQUNBO2tCQUFBO2tCQUFBOzRCQUFBLENBQ0E7bUJBQUE7bUJBQUE7NkJBQUEsQ0FDQUQsSUFBQXRILE1BQUFxSCxlQUFBLG9CQUNBOzs7Ozs0QkFDQTttQkFDQTttQkFDQSxZQUFBRDttQkFDQSxlQUFBbEYsNEJBQUFpRixPQUFBN0gsSUFBQWdJLElBQUFoSSxFQUFBO21CQUNBLFdBQUFsQixHQUNBLG9GQUNBcUosYUFDQSw4QkFDQUwsVUFDQSwwREFDQSxnREFDQTttQkFDQTs2QkFDQUssYUFDQSxnREFDQTtvQkFBQTtvQkFBQTttQkFBdUU7Ozs7NkJBQUEsZ0JBQ3ZFOzs7OzhCQUVBLGdEQUNBO29CQUFBO29CQUFBO21CQUFzRTs7Ozs2QkFBQSxxQkFDdEU7Ozs7O2tCQUVBOzs7OzBCQUNBOzs7Ozt5QkFDQTs7Ozs7d0JBQ0E7a0JBM0RBSCxJQUFBaEk7Ozs7c0JBMkRBO2NBRUE7YUFDQTs7Ozs7YUFHQTtjQUFBO2NBQUE7d0JBQUEsQ0FDQTtlQUFBO2VBQUE7eUJBQUE7Z0JBQ0E7aUJBQUE7aUJBQUE7Z0JBQWdGOzs7OztnQkFBQTtnQkFDaEY7aUJBQUE7aUJBQUE7MkJBQWdGNkgsT0FBQXpIO2dCQUFBOzs7OztlQUNoRjs7Ozs7d0JBQ0EwSCxVQUNBO2VBQUE7ZUFBQTt5QkFBQTtnQkFDQTtpQkFBQTtpQkFBQTtnQkFBZ0U7Ozs7O2dCQUFBO2dCQUNoRUEsUUFBQW5FO2dCQUFBO2dCQUFBbUUsUUFBQWxFO2dCQUFBO2VBQ0E7Ozs7O3lCQUVBO2VBQUE7eUJBQStCO2NBQUE7Ozs7c0JBRS9COzs7Ozs7WUFDQTtjQWxJQWlFLE9BQUE3SDs7OztrQkFrSUE7VUFFQTtTQUNBOzs7OztTQUdBO1VBQ0EsVUFBQStEO1VBQ0E7VUFDQTtvQkFIQTtXQUlBO1lBQUE7WUFBQTtzQkFBQSxDQUNBO2FBQUE7YUFBQTtZQUF5RDs7OztzQkFDekQ7YUFBQTt1QkFBQSxDQUNBO2NBQUE7Y0FBQTt3QkFBb0Y7YUFFcEY7Ozs7dUJBQ0E7Y0FBQTtjQUFBO3dCQUFnRTthQUVoRTs7OztxQkFDQTs7Ozs7b0JBQ0E7Ozs7OztXQUVBO1lBQUE7WUFBQTtzQkFBQTthQUNBO2NBQ0EsT0FBQXJCO2NBQ0EsV0FBQXNCLE1BQUFyQixxQkFBQXFCLEVBQUEyQyxPQUFBQyxLQUFBO2NBQ0E7Y0FDQTt3QkFKQTtlQUtBO2dCQUFBO2dCQUFBOzBCQUFzRDtlQUFBOzs7OztlQUN0RDtnQkFBQTtnQkFBQTswQkFBNEQ7ZUFBQTs7Ozs7ZUFDNUQ7Z0JBQUE7Z0JBQUE7MEJBQTJEO2VBQUE7Ozs7O2VBQzNEO2dCQUFBO2dCQUFBOzBCQUE4RDtlQUFBOzs7OztjQUM5RDs7Ozs7O2FBQ0E7Y0FDQSxPQUFBcEU7Y0FDQSxXQUFBd0IsTUFBQXZCLGdCQUFBdUIsRUFBQTJDLE9BQUFDLEtBQUE7Y0FDQTtjQUNBO2NBQ0E7YUFBa0I7Ozs7O2FBQ2xCO2NBQ0EsT0FBQXRFO2NBQ0EsV0FBQTBCLE1BQUF6QixrQkFBQXlCLEVBQUEyQyxPQUFBQyxLQUFBO2NBQ0E7Y0FDQTtjQUNBO2FBQWtCOzs7OztZQUNsQjs7Ozs7O1dBQ0E7WUFBQTtZQUFBO3NCQUNBO2FBQ0E7YUFDQTthQUNBO3VCQUhBLENBSUE7Y0FBQTtjQUFBO2FBQXNEOzs7O3VCQUFBLDhCQUV0RDs7Ozs7O1dBQ0E7Ozs7O1VBQ0E7Ozs7OztRQUNBOzs7Ozs7T0FJQTtRQUFBO1FBQUE7a0JBQUEsQ0FDQTtTQUFBO1NBQUE7bUJBQTBEO1FBQUE7Ozs7a0JBQzFEO1NBQUE7U0FBQTttQkFBQTtVQUNBO1dBQUE7cUJBQUEsQ0FDQTtZQUFBO1lBQUE7c0JBQW1EO1dBQUE7Ozs7cUJBQUEsbUlBQ25EOzs7Ozs7VUFDQTtXQUFBO3FCQUFBLENBQ0E7WUFBQTtZQUFBO3NCQUFtRDtXQUFBOzs7O3FCQUFBLHVMQUNuRDs7Ozs7O1VBQ0E7V0FBQTtxQkFBQSxDQUNBO1lBQUE7WUFBQTtzQkFBbUQ7V0FBQTs7OztxQkFBQSx1SEFDbkQ7Ozs7OztVQUNBO1dBQUE7cUJBQUEsQ0FDQTtZQUFBO1lBQUE7c0JBQW1EO1dBQUE7Ozs7cUJBQUEsb0hBQ25EOzs7Ozs7U0FDQTs7Ozs7Z0JBQ0E7Ozs7OztNQUNBOzs7Ozs7S0FHQTtNQUFBO01BQUE7Z0JBQUEsQ0FDQTtPQUFBO09BQUE7aUJBQUEsQ0FDQTtRQUFBO1FBQUE7T0FBMEU7Ozs7aUJBQzFFO1FBQUE7a0JBQUEsQ0FDQTtTQUFBO1NBQUE7bUJBQTREO1FBQUE7Ozs7a0JBQzVEO1NBQUE7U0FBQTttQkFBK0Q7UUFBQTs7OztnQkFDL0Q7Ozs7O2VBQ0E7Ozs7O2dCQUNBO09BQUE7T0FBQTtpQkFDQTtRQUFBO1FBQUE7UUFBQTtRQUFBO09BQUEsRUFBQXBELEtBQUE2RSxPQUFBQyxVQUNBO1FBQUE7UUFBQTtrQkFBQTtTQUNBO1VBQUEsV0FBQXhKLEdBQUEsMkVBQUF3SixVQUFBO1VBQUE7b0JBQXFNQSxRQUFBO1NBQUE7Ozs7O1NBQ3JNO1VBQUE7VUFBQTtvQkFBa0VEO1NBQUE7Ozs7O1NBQ2xFO1VBQUE7VUFBQTtvQkFBaUZDLFVBQUEsa0RBQUFBLFVBQUEsc0RBQUFBLFVBQUE7U0FBQTs7Ozs7UUFDakY7VUFKQUQ7Ozs7Y0FJQSxDQUNBO01BQ0E7Ozs7Y0FDQTs7Ozs7O0tBR0E7TUFBQTtNQUFBO2dCQUFBLENBQ0E7T0FBQTtPQUFBO2lCQUF5RDFILEVBQUE7TUFBQTs7OztnQkFDekQ7T0FBQTtPQUFBO2lCQUNBOEYsV0FBQWpELEtBQUFxRCxNQUNBO1FBQUE7UUFBQTtrQkFBQTtTQUNBO1VBQUE7VUFBQTtTQUF5RDs7Ozs7U0FDekQ7VUFBQTtVQUFBO29CQUFtRUEsRUFBQXBIO1NBQUE7Ozs7O1NBQ25FO1VBQUE7VUFBQTtvQkFBaUVvSCxFQUFBSDtTQUFBOzs7OztRQUNqRTtVQUpBRyxFQUFBcEg7Ozs7Y0FJQSxDQUNBO01BQ0E7Ozs7Y0FDQTs7Ozs7O0tBR0E7TUFBQTtNQUFBO2dCQUFBO09BQ0E7UUFBQTtRQUFBO09BQTREOzs7OztPQUM1RDtRQUFBO1FBQUE7a0JBQThEa0IsRUFBQTtPQUFBOzs7OztPQUM5RDtRQUFBO1FBQUE7a0JBQW9FQSxFQUFBO09BQUE7Ozs7O09BQ3BFO1FBQ0E7UUFDQTtRQUNBO2tCQUNBQSxFQUFBO09BQ0E7Ozs7O01BQ0E7Ozs7OztJQUNBOzs7Ozs7R0FFQTtJQUNBLE1BQUF1QjtJQUNBLGNBQUFDO0lBQ0EsV0FBQUM7SUFDQTtHQUFNOzs7OztFQUNOOzs7Ozs7QUFFQTs7Ozs7QUFBQSxNQUFBbUcsTUFBQUMsWUFBQUQ7QUFBQSxJQUFBQSxPQUFBLE9BQUFFLFdBQUE7Q0FBQUYsSUFBQTNILFNBQUE7Q0FBQSxNQUFBOEgsa0JBQUFELE9BQUFFLGlDQUFBO0VBQUEsTUFBQUMscUJBQUEsSUFBQXhMLElBQUE7RUFBQSxNQUFBeUwsNEJBQUFKLE9BQUFLO0VBQUFMLE9BQUFLLG1DQUFBQyxRQUFBO0dBQUEsTUFBQUMsaUJBQUFILDRCQUFBRSxHQUFBO0dBQUEsTUFBQUUsZ0JBQUFMLG1CQUFBTSxJQUFBSCxJQUFBL0ksRUFBQTtHQUFBLFdBQUFnSixnQkFBQSxHQUFBQyxhQUFBO0VBQUE7RUFBQSxTQUFBTCxtQkFBQTtDQUFBO0NBQUFGLGdCQUFBRSxtQkFBQU8sSUFBQTtBQUFBO0FBQUEsZ0JBQUFDLHVCQUFBO0NBQUE7QUFBQTs7QUFBQSxJQUFBWixZQUFBRCxLQUFBO0NBQUEsTUFBQUEsTUFBQUMsWUFBQUQ7Q0FBQSxNQUFBYyxVQUFBZCxJQUFBM0gsU0FBQTtDQUFBLE1BQUEwSSxvQkFBQSxTQUFBQSxrQkFBQUMsU0FBQUMsVUFBQTtFQUFBLE1BQUFDLFNBQUFoQixPQUFBaUI7RUFBQSxNQUFBQyxXQUFBRixPQUFBRyxXQUFBTDtFQUFBLEtBQUFJLFVBQUE7RUFBQSxNQUFBRSwyQkFBQSxJQUFBQyxJQUFBO0dBQUE7R0FBQTtHQUFBO0VBQUE7RUFBQSxNQUFBQyx3QkFBQTtFQUFBRix5QkFBQUcsU0FBQUMsUUFBQTtHQUFBLElBQUFBLE9BQUFOLFNBQUFwSixTQUFBd0osc0JBQUFFLE9BQUFOLFNBQUFwSixRQUFBMEo7RUFBQTtFQUFBLE1BQUFDLDRCQUFBLG9CQUFBUCxTQUFBcEosWUFBQSxvQkFBQWlKLFNBQUFqSjtFQUFBLE1BQUE0SixnQkFBQTtHQUFBO0dBQUE7R0FBQTtHQUFBO0dBQUE7RUFBQTtFQUFBLElBQUFELDJCQUFBQyxjQUFBSCxTQUFBQyxRQUFBO0dBQUEsSUFBQUEsT0FBQU4sU0FBQXBKLFdBQUEwSixPQUFBVCxTQUFBakosU0FBQWlKLFNBQUFqSixRQUFBMEosT0FBQU4sU0FBQXBKLFFBQUEwSjtFQUFBO0VBQUEsTUFBQUcsY0FBQTtHQUFBLEdBQUFaLFNBQUFqSjtHQUFBLEdBQUF3SjtFQUFBO0VBQUFKLFNBQUFwSixVQUFBNko7RUFBQVQsU0FBQVUsT0FBQUQsV0FBQTtFQUFBWCxPQUFBYSxtQkFBQVgsVUFBQUgsU0FBQWUsTUFBQTtFQUFBZCxPQUFBZSxVQUFBZixPQUFBZ0IsZUFBQTtFQUFBQyxtQkFBQWYsUUFBQTtFQUFBRixPQUFBa0IsaUJBQUFDLE1BQUE7RUFBQW5CLE9BQUFvQixnQkFBQTtFQUFBLFNBQUFILG1CQUFBSSxXQUFBO0dBQUF0QixTQUFBakosVUFBQXVLLFVBQUF2SztHQUFBaUosU0FBQXVCLGNBQUFELFVBQUFDO0dBQUF2QixTQUFBd0IsUUFBQUYsVUFBQUU7R0FBQXhCLFNBQUF5QixNQUFBSCxVQUFBRztHQUFBekIsU0FBQTBCLFlBQUFKLFVBQUFJO0dBQUExQixTQUFBMkIsTUFBQUwsVUFBQUs7RUFBQTtDQUFBO0NBQUEsTUFBQUMsaUJBQUEsYUFBQS9CLFFBQUE7Q0FBQSxJQUFBK0IsZ0JBQUE7RUFBQS9CLFFBQUEsa0JBQUErQjtDQUFBO0NBQUEsTUFBQUMsZ0JBQUEsT0FBQTVDLFdBQUEsZUFBQTJDLGlCQUFBM0MsT0FBQWlCLGdCQUFBRSxhQUFBd0Isa0JBQUFFO0NBQUEsSUFBQUYsa0JBQUFDLG1DQUFBL0wsT0FBQTtFQUFBZ0ssa0JBQUE4QixnQkFBQTlMLEtBQUE7RUFBQStKLFFBQUEsOEJBQUEvSjtDQUFBO0NBQUFpSixJQUFBZ0QsUUFBQUMsY0FBQTtFQUFBLElBQUFsTSxTQUFBa00sdUJBQUFsTSxPQUFBO0dBQUEsTUFBQWlLLFVBQUFGLFFBQUE7R0FBQSxJQUFBRSxTQUFBO0lBQUFGLFFBQUEsa0JBQUFFO0dBQUE7R0FBQSxJQUFBRixRQUFBLGdDQUFBbUMsVUFBQWxNLE9BQUE7SUFBQSxPQUFBK0osUUFBQTtJQUFBO0dBQUE7R0FBQUMsa0JBQUFDLFNBQUFpQyxVQUFBbE0sS0FBQTtFQUFBO0NBQUE7QUFBQSIsIm5hbWVzIjpbImNyZWF0ZUZpbGVSb3V0ZSIsIkxpbmsiLCJ1c2VRdWVyeSIsInVzZVRyYW5zbGF0aW9uIiwidXNlTWVtbyIsInVzZVN0YXRlIiwiSGVhZGVyIiwiZmV0Y2hCcmFuZHMiLCJTa2VsZXRvbiIsIkF3YXJkIiwiQ2FsZW5kYXJDbG9jayIsIkNoZWNrQ2lyY2xlMiIsIkNyb3duIiwiSGVhcnQiLCJNYXAiLCJTZWFyY2giLCJTcGFya2xlcyIsIlRyZW5kaW5nVXAiLCJUcm9waHkiLCJDYXIiLCJVdGVuc2lscyIsIkxhcHRvcCIsIlNob3BwaW5nQmFnIiwiU2hpcnQiLCJCdWlsZGluZzIiLCJTaGllbGRDaGVjayIsIlZvdGUiLCJMb2NrIiwiUmFkaW8iLCJVc2VycyIsIkxhbmRtYXJrIiwiQnJpZWZjYXNlIiwiQ2hlY2siLCJGaWxlQ2hlY2syIiwiVmlkZW8iLCJicmFuZENhdGVnb3J5IiwiY2F0ZWdvcnlPcHRpb25zIiwiY291bnRyeU5hbWUiLCJjb3VudHJ5T3B0aW9ucyIsIm5vcm1hbGl6ZUNvdW50cnlDb2RlIiwiY24iLCJQZW9wbGVUcnVzdEZhY3RvckxpbmsiLCJCUkFORF9USUVSUyIsImdldEJyYW5kVGllciIsImdldFRpZXJJbmZvIiwibWF0Y2hlc1RpZXIiLCJMaXZlQnJvYWRjYXN0TW9kYWwiLCJ0b2FzdCIsIlJvdXRlIiwiaGVhZCIsIm1ldGEiLCJ0aXRsZSIsIm5hbWUiLCJjb250ZW50IiwicHJvcGVydHkiLCJjb21wb25lbnQiLCJBd2FyZHNQYWdlIiwiSU5JVElBTF9JTlNUSVRVVElPTkFMX0JBTExPVFMiLCJpZCIsImNhdGVnb3J5Iiwib3JnYW5pemF0aW9uIiwiZGVzY3JpcHRpb24iLCJ2ZXJpZmljYXRpb25TdGFuZGFyZCIsImNsb3NpbmdEYXRlIiwidG90YWxWZXJpZmllZFZvdGVzIiwib3B0aW9ucyIsImxhYmVsIiwic3VidGl0bGUiLCJ2b3RlcyIsInQiLCJkYXRhIiwiYnJhbmRzIiwiaXNMb2FkaW5nIiwicXVlcnlLZXkiLCJxdWVyeUZuIiwidmlld01vZGUiLCJzZXRWaWV3TW9kZSIsImNvdW50cnkiLCJzZXRDb3VudHJ5Iiwic2V0Q2F0ZWdvcnkiLCJ0aWVyIiwic2V0VGllciIsInF1ZXJ5Iiwic2V0UXVlcnkiLCJwZXJpb2QiLCJzZXRQZXJpb2QiLCJzbmFwc2hvdFRpbWUiLCJEYXRlIiwiYmFsbG90cyIsInNldEJhbGxvdHMiLCJ2b3RlZFJlY2VpcHRzIiwic2V0Vm90ZWRSZWNlaXB0cyIsImxpdmVPYnNlcnZlck1vZGFsT3BlbiIsInNldExpdmVPYnNlcnZlck1vZGFsT3BlbiIsImFjdGl2ZU9ic2VydmVyVG9waWMiLCJzZXRBY3RpdmVPYnNlcnZlclRvcGljIiwibmV3QmFsbG90VGl0bGUiLCJzZXROZXdCYWxsb3RUaXRsZSIsIm5ld0JhbGxvdE9yZyIsInNldE5ld0JhbGxvdE9yZyIsIm5ld0JhbGxvdENhdGVnb3J5Iiwic2V0TmV3QmFsbG90Q2F0ZWdvcnkiLCJoYW5kbGVDYXN0SW5zdGl0dXRpb25hbFZvdGUiLCJiYWxsb3RJZCIsIm9wdGlvbklkIiwiaW5mbyIsInJhbmRvbUhhc2giLCJNYXRoIiwicmFuZG9tIiwidG9TdHJpbmciLCJzdWJzdHJpbmciLCJ0b1VwcGVyQ2FzZSIsIm5vdyIsInByZXYiLCJtYXAiLCJiIiwibyIsImhhc2giLCJ0aW1lc3RhbXAiLCJ0b0xvY2FsZVRpbWVTdHJpbmciLCJzdWNjZXNzIiwiaGFuZGxlQ3JlYXRlQ3VzdG9tQmFsbG90IiwiZSIsInByZXZlbnREZWZhdWx0IiwidHJpbSIsImVycm9yIiwiY3JlYXRlZCIsImNvdW50cmllcyIsImJyYW5kIiwiY2F0ZWdvcmllcyIsImZpbHRlcmVkQnJhbmRzIiwidGVybSIsInRvTG93ZXJDYXNlIiwiZmlsdGVyIiwibm9ybWFsaXplZENvdW50cnkiLCJub3JtYWxpemVkQ2F0ZWdvcnkiLCJicmFuZFRpZXIiLCJzZWFyY2hhYmxlIiwiaW5jbHVkZXMiLCJzb3J0IiwiYSIsIk51bWJlciIsInRydXN0X3Njb3JlIiwidG9wIiwic2xpY2UiLCJyZWdpb25MYWJlbCIsImluZHVzdHJ5U2VjdG9ycyIsInNlY3RvcnMiLCJpY29uIiwibWF0Y2giLCJjYXQiLCJzZWMiLCJzZWN0b3JCcmFuZHMiLCJtYXRjaGVzQ291bnRyeSIsImxlYWRlcnMiLCJ0b3RhbENvdW50IiwibGVuZ3RoIiwidGllclNlZ21lbnRzIiwidGllcktleXMiLCJ0ayIsInRpZXJCcmFuZHMiLCJiVGllciIsInRpZXJLZXkiLCJhd2FyZFR5cGVzIiwiZGVzYyIsInRhcmdldCIsInZhbHVlIiwiYyIsInRvTG9jYWxlRGF0ZVN0cmluZyIsInNlY3RvciIsIkljb24iLCJpZHgiLCJ0SW5mbyIsInNsdWciLCJzaWduZWRMb2dvVXJsIiwiY2hhckF0IiwiYmFkZ2VDbGFzcyIsInByaWNlUG9pbnQiLCJzaG9ydE5hbWUiLCJzZWdtZW50IiwiYm9yZGVyQ2xhc3MiLCJpIiwidGllckluZm8iLCJiYWxsb3QiLCJyZWNlaXB0IiwidG9Mb2NhbGVTdHJpbmciLCJvcHQiLCJwY3QiLCJyb3VuZCIsImlzU2VsZWN0ZWQiLCJ3aWR0aCIsInN0YWdlIiwiaW5kZXgiLCJob3QiLCJpbXBvcnQiLCJ3aW5kb3ciLCJ0c3JSZWFjdFJlZnJlc2giLCJfX1RTUl9SRUFDVF9SRUZSRVNIX18iLCJpZ25vcmVkRXhwb3J0c0J5SWQiLCJwcmV2aW91c0dldElnbm9yZWRFeHBvcnRzIiwiX19nZXRSZWFjdFJlZnJlc2hJZ25vcmVkRXhwb3J0cyIsImN0eCIsImlnbm9yZWRFeHBvcnRzIiwibW9kdWxlSWdub3JlZCIsImdldCIsInNldCIsIlRTUkZhc3RSZWZyZXNoQW5jaG9yIiwiaG90RGF0YSIsImhhbmRsZVJvdXRlVXBkYXRlIiwicm91dGVJZCIsIm5ld1JvdXRlIiwicm91dGVyIiwiX19UU1JfUk9VVEVSX18iLCJvbGRSb3V0ZSIsInJvdXRlc0J5SWQiLCJnZW5lcmF0ZWRSb3V0ZU9wdGlvbktleXMiLCJTZXQiLCJnZW5lcmF0ZWRSb3V0ZU9wdGlvbnMiLCJmb3JFYWNoIiwia2V5IiwicHJlc2VydmVDb21wb25lbnRJZGVudGl0eSIsImNvbXBvbmVudEtleXMiLCJuZXh0T3B0aW9ucyIsInVwZGF0ZSIsIl9yZXBsYWNlUm91dGVDaHVuayIsImxhenlGbiIsInNldFJvdXRlcyIsImJ1aWxkUm91dGVUcmVlIiwic3luY0hvdFJvdXRlRXhwb3J0IiwicmVzb2x2ZVBhdGhDYWNoZSIsImNsZWFyIiwiX3JlZnJlc2hSb3V0ZSIsImxpdmVSb3V0ZSIsInBhcmVudFJvdXRlIiwiX3BhdGgiLCJfaWQiLCJfZnVsbFBhdGgiLCJfdG8iLCJpbml0aWFsUm91dGVJZCIsImV4aXN0aW5nUm91dGUiLCJ1bmRlZmluZWQiLCJhY2NlcHQiLCJuZXdNb2R1bGUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiYXdhcmRzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVGaWxlUm91dGUsIExpbmsgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXJvdXRlclwiO1xuaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XG5pbXBvcnQgeyB1c2VUcmFuc2xhdGlvbiB9IGZyb20gXCJyZWFjdC1pMThuZXh0XCI7XG5pbXBvcnQgeyB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgSGVhZGVyIH0gZnJvbSBcIkAvY29tcG9uZW50cy9IZWFkZXJcIjtcbmltcG9ydCB7IGZldGNoQnJhbmRzIH0gZnJvbSBcIkAvbGliL2JyYW5kc1wiO1xuaW1wb3J0IHsgU2tlbGV0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL3NrZWxldG9uXCI7XG5pbXBvcnQge1xuICBBd2FyZCxcbiAgQ2FsZW5kYXJDbG9jayxcbiAgQ2hlY2tDaXJjbGUyLFxuICBDcm93bixcbiAgRmlsdGVyLFxuICBIZWFydCxcbiAgTGF5ZXJzLFxuICBNYXAsXG4gIFNlYXJjaCxcbiAgU3BhcmtsZXMsXG4gIFRyZW5kaW5nVXAsXG4gIFRyb3BoeSxcbiAgQ2FyLFxuICBVdGVuc2lscyxcbiAgTGFwdG9wLFxuICBTaG9wcGluZ0JhZyxcbiAgU2hpcnQsXG4gIEJ1aWxkaW5nMixcbiAgU2hpZWxkQ2hlY2ssXG4gIFZvdGUsXG4gIExvY2ssXG4gIFJhZGlvLFxuICBVc2VycyxcbiAgTGFuZG1hcmssXG4gIEJyaWVmY2FzZSxcbiAgQ2hlY2ssXG4gIEZpbGVDaGVjazIsXG4gIFZpZGVvLFxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBicmFuZENhdGVnb3J5LCBjYXRlZ29yeU9wdGlvbnMgfSBmcm9tIFwiQC9saWIvY2F0ZWdvcmllc1wiO1xuaW1wb3J0IHsgY291bnRyeU5hbWUsIGNvdW50cnlPcHRpb25zLCBub3JtYWxpemVDb3VudHJ5Q29kZSB9IGZyb20gXCJAL2xpYi9nZW9cIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5pbXBvcnQgeyBQZW9wbGVUcnVzdEZhY3RvckxpbmsgfSBmcm9tIFwiQC9jb21wb25lbnRzL1Blb3BsZVRydXN0RmFjdG9yXCI7XG5pbXBvcnQgeyBCUkFORF9USUVSUywgdHlwZSBCcmFuZFRpZXJGaWx0ZXIsIGdldEJyYW5kVGllciwgZ2V0VGllckluZm8sIG1hdGNoZXNUaWVyIH0gZnJvbSBcIkAvbGliL2JyYW5kVGllcnNcIjtcbmltcG9ydCB7IExpdmVCcm9hZGNhc3RNb2RhbCB9IGZyb20gXCJAL2NvbXBvbmVudHMvTGl2ZUJyb2FkY2FzdE1vZGFsXCI7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gXCJzb25uZXJcIjtcblxuZXhwb3J0IGNvbnN0IFJvdXRlID0gY3JlYXRlRmlsZVJvdXRlKFwiL2F3YXJkc1wiKSh7XG4gIHNzcjogZmFsc2UsXG4gIGhlYWQ6ICgpID0+ICh7XG4gICAgbWV0YTogW1xuICAgICAgeyB0aXRsZTogXCJUaGUgU09UIEF3YXJkcyAmIFZlcmlmaWVkIFZvdGluZyB8IFN0YXNoIE9yIFRyYXNoIOKAlCBUaGUgQnJhbmQgQmFyb21ldGVyXCIgfSxcbiAgICAgIHtcbiAgICAgICAgbmFtZTogXCJkZXNjcmlwdGlvblwiLFxuICAgICAgICBjb250ZW50OlxuICAgICAgICAgIFwiVGhlIGFubnVhbCBTT1QgQXdhcmRzIGFuZCBWZXJpZmllZCBJbnN0aXR1dGlvbmFsIFZvdGluZyBJbmZyYXN0cnVjdHVyZSDigJQgcG93ZXJpbmcgY29uc3VtZXIgYnJhbmQgdmVyZGljdHMsIHRyYWRlIHVuaW9uIGJhbGxvdHMsIGF3YXJkcyBjZXJlbW9uaWVzLCBhbmQgb2ZmaWNlIGdvdmVybmFuY2UuXCIsXG4gICAgICB9LFxuICAgICAgeyBwcm9wZXJ0eTogXCJvZzp0aXRsZVwiLCBjb250ZW50OiBcIlRoZSBTT1QgQXdhcmRzICYgVmVyaWZpZWQgVm90aW5nIOKAlCBUaGUgUGVvcGxlJ3MgVmVyZGljdCwgTWFkZSBPZmZpY2lhbFwiIH0sXG4gICAgICB7XG4gICAgICAgIHByb3BlcnR5OiBcIm9nOmRlc2NyaXB0aW9uXCIsXG4gICAgICAgIGNvbnRlbnQ6XG4gICAgICAgICAgXCJUaGUgbW9zdCB0cnVzdGVkIGJyYW5kcyBhbmQgdmVyaWZpZWQgaW5zdGl0dXRpb25hbCBiYWxsb3RzLCBjcm93bmVkIGJ5IHJlYWwgcGVvcGxlLiBFeHBsb3JlIHRoZSBsaXZlIGxlYWRlcmJvYXJkIGFuZCBpbnN0aXR1dGlvbmFsIHZvdGluZyBjaGFtYmVycy5cIixcbiAgICAgIH0sXG4gICAgICB7IHByb3BlcnR5OiBcIm9nOnR5cGVcIiwgY29udGVudDogXCJ3ZWJzaXRlXCIgfSxcbiAgICAgIHsgbmFtZTogXCJ0d2l0dGVyOmNhcmRcIiwgY29udGVudDogXCJzdW1tYXJ5X2xhcmdlX2ltYWdlXCIgfSxcbiAgICBdLFxuICB9KSxcbiAgY29tcG9uZW50OiBBd2FyZHNQYWdlLFxufSk7XG5cbnR5cGUgTGVhZGVyYm9hcmRWaWV3ID0gXCJpbmR1c3RyaWVzXCIgfCBcInRpZXJzXCIgfCBcInNlYXJjaFwiIHwgXCJpbnN0aXR1dGlvbmFsXCI7XG5cbmludGVyZmFjZSBJbnN0aXR1dGlvbmFsQmFsbG90IHtcbiAgaWQ6IHN0cmluZztcbiAgY2F0ZWdvcnk6IFwiVHJhZGUgVW5pb24gQmFsbG90XCIgfCBcIk5hdGlvbmFsIEF3YXJkcyBDZXJlbW9ueVwiIHwgXCJPZmZpY2UgJiBDb3Jwb3JhdGUgUG9sbFwiIHwgXCJDaXZpYyAmIFJlZ3VsYXRvcnkgTWFuZGF0ZVwiO1xuICBvcmdhbml6YXRpb246IHN0cmluZztcbiAgdGl0bGU6IHN0cmluZztcbiAgZGVzY3JpcHRpb246IHN0cmluZztcbiAgdmVyaWZpY2F0aW9uU3RhbmRhcmQ6IHN0cmluZztcbiAgY2xvc2luZ0RhdGU6IHN0cmluZztcbiAgdG90YWxWZXJpZmllZFZvdGVzOiBudW1iZXI7XG4gIG9wdGlvbnM6IHtcbiAgICBpZDogc3RyaW5nO1xuICAgIGxhYmVsOiBzdHJpbmc7XG4gICAgc3VidGl0bGU6IHN0cmluZztcbiAgICB2b3RlczogbnVtYmVyO1xuICB9W107XG59XG5cbmNvbnN0IElOSVRJQUxfSU5TVElUVVRJT05BTF9CQUxMT1RTOiBJbnN0aXR1dGlvbmFsQmFsbG90W10gPSBbXG4gIHtcbiAgICBpZDogXCJiYWxsb3QtdW5pb24tMjAyNlwiLFxuICAgIGNhdGVnb3J5OiBcIlRyYWRlIFVuaW9uIEJhbGxvdFwiLFxuICAgIG9yZ2FuaXphdGlvbjogXCJOYXRpb25hbCBXb3JrZXJzICYgVHJhZGUgVW5pb24gRmVkZXJhdGlvbiAoQ09TQVRVIC8gQWZmaWxpYXRlcyBTdGFuZGFyZClcIixcbiAgICB0aXRsZTogXCIyMDI2IENvbGxlY3RpdmUgV2FnZSBNYW5kYXRlICYgU2hvcCBTdGV3YXJkIFJhdGlmaWNhdGlvblwiLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgXCJBdWRpdGFibGUgMS1NZW1iZXItMS1Wb3RlIGRpZ2l0YWwgYmFsbG90IGZvciByZWdpc3RlcmVkIHVuaW9uIG1lbWJlcnMuIEVsaW1pbmF0ZXMgcGFwZXIgYmFsbG90IHRhbXBlcmluZyBhbmQgcHJvdmlkZXMgcmVhbC10aW1lIGNyeXB0b2dyYXBoaWMgdGFsbHlpbmcuXCIsXG4gICAgdmVyaWZpY2F0aW9uU3RhbmRhcmQ6IFwiVmVyaWZpZWQgTWVtYmVyIElEICsgRGV2aWNlIEZpbmdlcnByaW50ICsgU0hBLTI1NiBSZWNlaXB0XCIsXG4gICAgY2xvc2luZ0RhdGU6IFwiQ2xvc2VzIGluIDQgZGF5c1wiLFxuICAgIHRvdGFsVmVyaWZpZWRWb3RlczogMTQ4MjAsXG4gICAgb3B0aW9uczogW1xuICAgICAge1xuICAgICAgICBpZDogXCJvcHQtdTFcIixcbiAgICAgICAgbGFiZWw6IFwiU3Rhc2ggTWFuZGF0ZSBBOiBBY2NlcHQgOC41JSBNdWx0aS1ZZWFyIFdhZ2UgU2V0dGxlbWVudCArIEhvdXNpbmcgQWxsb3dhbmNlXCIsXG4gICAgICAgIHN1YnRpdGxlOiBcIkVuZG9yc2VkIGJ5IFJlZ2lvbmFsIEJhcmdhaW5pbmcgQ291bmNpbCBOZWdvdGlhdG9yc1wiLFxuICAgICAgICB2b3RlczogOTQxMCxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGlkOiBcIm9wdC11MlwiLFxuICAgICAgICBsYWJlbDogXCJUcmFzaCBTZXR0bGVtZW50OiBSZWplY3QgT2ZmZXIgJiBNYWludGFpbiBTZWNvbmRhcnkgRGlzcHV0ZSBNZWRpYXRpb25cIixcbiAgICAgICAgc3VidGl0bGU6IFwiUHJvY2VlZCB0byBmb3JtYWwgQ0NNQSAvIExhYm91ciBEaXNwdXRlIHJlc29sdXRpb24gd2luZG93XCIsXG4gICAgICAgIHZvdGVzOiA1NDEwLFxuICAgICAgfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgaWQ6IFwiYmFsbG90LWdvdi1hd2FyZHMtMjAyNlwiLFxuICAgIGNhdGVnb3J5OiBcIk5hdGlvbmFsIEF3YXJkcyBDZXJlbW9ueVwiLFxuICAgIG9yZ2FuaXphdGlvbjogXCJTQSBDb25zdW1lciBRdWFsaXR5ICYgUHVibGljIFNlcnZpY2UgRXhjZWxsZW5jZSBBd2FyZHNcIixcbiAgICB0aXRsZTogXCJNb3N0IEFjY291bnRhYmxlIENvbnN1bWVyIE9tYnVkc21hbiAmIFJlZ3VsYXRvcnkgUGFydG5lciBvZiB0aGUgWWVhclwiLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgXCJQdWJsaWMgJiBpbmR1c3RyeSByZWNvZ25pdGlvbiBjZWxlYnJhdGluZyByZWd1bGF0b3J5IGJvZGllcyBhbmQgY29uc3VtZXIgcHJvdGVjdGlvbiBmcmFtZXdvcmtzIHRoYXQgZW1wb3dlciBjaXRpemVucyBhbmQgcHJvdGVjdCBnZW51aW5lIGJyYW5kcyBmcm9tIGNvdW50ZXJmZWl0IGdvb2RzLlwiLFxuICAgIHZlcmlmaWNhdGlvblN0YW5kYXJkOiBcIlZlcmlmaWVkIENpdGl6ZW4gVHJ1c3QgQmFyb21ldGVyICsgQW50aS1Cb3QgUHJvb2ZcIixcbiAgICBjbG9zaW5nRGF0ZTogXCJMaXZlIENlcmVtb255IFNuYXBzaG90IEFjdGl2ZVwiLFxuICAgIHRvdGFsVmVyaWZpZWRWb3RlczogMjg0OTAsXG4gICAgb3B0aW9uczogW1xuICAgICAge1xuICAgICAgICBpZDogXCJvcHQtYTFcIixcbiAgICAgICAgbGFiZWw6IFwiQ29uc3VtZXIgR29vZHMgJiBTZXJ2aWNlcyBPbWJ1ZCAoQ0dTTykg4oCUIENQQSBTZWN0aW9uIDY5IE1lZGlhdGlvblwiLFxuICAgICAgICBzdWJ0aXRsZTogXCJSZWNvZ25pc2VkIGZvciBmcmVlIGNvbnN1bWVyIGRpc3B1dGUgcmVzb2x1dGlvbiAmIGluZHVzdHJ5IGNvZGUgZW5mb3JjZW1lbnRcIixcbiAgICAgICAgdm90ZXM6IDE2MjQwLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6IFwib3B0LWEyXCIsXG4gICAgICAgIGxhYmVsOiBcIk5hdGlvbmFsIENvbnN1bWVyIENvbW1pc3Npb24gKE5DQykg4oCUIFByb2R1Y3QgU2FmZXR5ICYgUmVjYWxsIERpdmlzaW9uXCIsXG4gICAgICAgIHN1YnRpdGxlOiBcIlJlY29nbmlzZWQgZm9yIG5hdGlvbmFsIGNvbXBsaWFuY2UsIGNvdW50ZXJmZWl0IHNlaXp1cmVzICYgY29uc3VtZXIgYXdhcmVuZXNzXCIsXG4gICAgICAgIHZvdGVzOiAxMjI1MCxcbiAgICAgIH0sXG4gICAgXSxcbiAgfSxcbiAge1xuICAgIGlkOiBcImJhbGxvdC1vZmZpY2UtYWdtLTIwMjZcIixcbiAgICBjYXRlZ29yeTogXCJPZmZpY2UgJiBDb3Jwb3JhdGUgUG9sbFwiLFxuICAgIG9yZ2FuaXphdGlvbjogXCJFbnRlcnByaXNlIFdvcmtwbGFjZSAmIEVtcGxveWVlIFJlcHJlc2VudGF0aXZlIENvdW5jaWxcIixcbiAgICB0aXRsZTogXCJRNCBIeWJyaWQgV29yayBQb2xpY3kgJiBBbnRpLUNvdW50ZXJmZWl0IFN1cHBseSBDaGFpbiBDaGFydGVyXCIsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICBcIkludGVybmFsIGNvcnBvcmF0ZSBnb3Zlcm5hbmNlIGFuZCB3b3JrcGxhY2UgcmVzb2x1dGlvbiB2b3RlIHBvd2VyZWQgYnkgU3Rhc2ggb3IgVHJhc2gncyB0YW1wZXItZXZpZGVudCBUcnVzdCBCYXIgYXJjaGl0ZWN0dXJlLlwiLFxuICAgIHZlcmlmaWNhdGlvblN0YW5kYXJkOiBcIkNvcnBvcmF0ZSBTU08gLyBWZXJpZmllZCBXb3JrcGxhY2UgRW1haWxcIixcbiAgICBjbG9zaW5nRGF0ZTogXCJDbG9zZXMgaW4gNDggaG91cnNcIixcbiAgICB0b3RhbFZlcmlmaWVkVm90ZXM6IDMxOTAsXG4gICAgb3B0aW9uczogW1xuICAgICAge1xuICAgICAgICBpZDogXCJvcHQtYzFcIixcbiAgICAgICAgbGFiZWw6IFwiQXBwcm92ZSBDaGFydGVyOiAzLURheSBIeWJyaWQgTW9kZWwgKyAxMDAlIEJhdGNoLVZlcmlmaWVkIFN1cHBsaWVyIE1hbmRhdGVcIixcbiAgICAgICAgc3VidGl0bGU6IFwiSW5jbHVkZXMgbWFuZGF0b3J5IFNPVCBiYXJjb2RlIGF1dGhlbnRpY2l0eSB2ZXJpZmljYXRpb24gZm9yIGFsbCBwcm9jdXJlZCBnb29kc1wiLFxuICAgICAgICB2b3RlczogMjY0MCxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGlkOiBcIm9wdC1jMlwiLFxuICAgICAgICBsYWJlbDogXCJEZWZlciB0byBDb21taXR0ZWU6IFJlcXVlc3QgMzAtRGF5IERlcGFydG1lbnRhbCBSZXZpZXdcIixcbiAgICAgICAgc3VidGl0bGU6IFwiRXh0ZW5kIGNvbnN1bHRhdGlvbiB3aXRoIHJlZ2lvbmFsIGJyYW5jaCBvZmZpY2VzXCIsXG4gICAgICAgIHZvdGVzOiA1NTAsXG4gICAgICB9LFxuICAgIF0sXG4gIH0sXG5dO1xuXG5leHBvcnQgZnVuY3Rpb24gQXdhcmRzUGFnZSgpIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VUcmFuc2xhdGlvbigpO1xuICBjb25zdCB7IGRhdGE6IGJyYW5kcywgaXNMb2FkaW5nIH0gPSB1c2VRdWVyeSh7XG4gICAgcXVlcnlLZXk6IFtcImJyYW5kc1wiXSxcbiAgICBxdWVyeUZuOiBmZXRjaEJyYW5kcyxcbiAgfSk7XG5cbiAgY29uc3QgW3ZpZXdNb2RlLCBzZXRWaWV3TW9kZV0gPSB1c2VTdGF0ZTxMZWFkZXJib2FyZFZpZXc+KFwiaW5kdXN0cmllc1wiKTtcbiAgY29uc3QgW2NvdW50cnksIHNldENvdW50cnldID0gdXNlU3RhdGUoXCJBbGwgY291bnRyaWVzXCIpO1xuICBjb25zdCBbY2F0ZWdvcnksIHNldENhdGVnb3J5XSA9IHVzZVN0YXRlKFwiQWxsIGNhdGVnb3JpZXNcIik7XG4gIGNvbnN0IFt0aWVyLCBzZXRUaWVyXSA9IHVzZVN0YXRlPEJyYW5kVGllckZpbHRlcj4oXCJBbGwgdGllcnNcIik7XG4gIGNvbnN0IFtxdWVyeSwgc2V0UXVlcnldID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtwZXJpb2QsIHNldFBlcmlvZF0gPSB1c2VTdGF0ZShcIkxpdmUgc2Vhc29uXCIpO1xuICBjb25zdCBzbmFwc2hvdFRpbWUgPSB1c2VNZW1vKCgpID0+IG5ldyBEYXRlKCksIFtdKTtcblxuICAvLyBJbnN0aXR1dGlvbmFsIFZvdGluZyBTdGF0ZSAoU3RyYXRlZ3kgQyBQaGFzZSAzICYgNClcbiAgY29uc3QgW2JhbGxvdHMsIHNldEJhbGxvdHNdID0gdXNlU3RhdGU8SW5zdGl0dXRpb25hbEJhbGxvdFtdPihJTklUSUFMX0lOU1RJVFVUSU9OQUxfQkFMTE9UUyk7XG4gIGNvbnN0IFt2b3RlZFJlY2VpcHRzLCBzZXRWb3RlZFJlY2VpcHRzXSA9IHVzZVN0YXRlPFJlY29yZDxzdHJpbmcsIHsgb3B0aW9uSWQ6IHN0cmluZzsgaGFzaDogc3RyaW5nOyB0aW1lc3RhbXA6IHN0cmluZyB9Pj4oe30pO1xuICBjb25zdCBbbGl2ZU9ic2VydmVyTW9kYWxPcGVuLCBzZXRMaXZlT2JzZXJ2ZXJNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbYWN0aXZlT2JzZXJ2ZXJUb3BpYywgc2V0QWN0aXZlT2JzZXJ2ZXJUb3BpY10gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiU09UIEluc3RpdHV0aW9uYWwgQmFsbG90IE9ic2VydmVyIFRvd25oYWxsXCIpO1xuICBjb25zdCBbbmV3QmFsbG90VGl0bGUsIHNldE5ld0JhbGxvdFRpdGxlXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbbmV3QmFsbG90T3JnLCBzZXROZXdCYWxsb3RPcmddID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtuZXdCYWxsb3RDYXRlZ29yeSwgc2V0TmV3QmFsbG90Q2F0ZWdvcnldID0gdXNlU3RhdGU8SW5zdGl0dXRpb25hbEJhbGxvdFtcImNhdGVnb3J5XCJdPihcIlRyYWRlIFVuaW9uIEJhbGxvdFwiKTtcblxuICBjb25zdCBoYW5kbGVDYXN0SW5zdGl0dXRpb25hbFZvdGUgPSAoYmFsbG90SWQ6IHN0cmluZywgb3B0aW9uSWQ6IHN0cmluZykgPT4ge1xuICAgIGlmICh2b3RlZFJlY2VpcHRzW2JhbGxvdElkXSkge1xuICAgICAgdG9hc3QuaW5mbyhcIllvdXIgdmVyaWZpZWQgMS1QZXJzb24tMS1Wb3RlIGJhbGxvdCBpcyBhbHJlYWR5IGxvY2tlZCB3aXRoIGEgY3J5cHRvZ3JhcGhpYyByZWNlaXB0LlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgcmFuZG9tSGFzaCA9IGBTT1QtU0hBMjU2LSR7TWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc3Vic3RyaW5nKDIsIDgpLnRvVXBwZXJDYXNlKCl9LSR7RGF0ZS5ub3coKS50b1N0cmluZygzNikudG9VcHBlckNhc2UoKX1gO1xuICAgIHNldEJhbGxvdHMoKHByZXYpID0+XG4gICAgICBwcmV2Lm1hcCgoYikgPT5cbiAgICAgICAgYi5pZCAhPT0gYmFsbG90SWRcbiAgICAgICAgICA/IGJcbiAgICAgICAgICA6IHtcbiAgICAgICAgICAgICAgLi4uYixcbiAgICAgICAgICAgICAgdG90YWxWZXJpZmllZFZvdGVzOiBiLnRvdGFsVmVyaWZpZWRWb3RlcyArIDEsXG4gICAgICAgICAgICAgIG9wdGlvbnM6IGIub3B0aW9ucy5tYXAoKG8pID0+IChvLmlkID09PSBvcHRpb25JZCA/IHsgLi4ubywgdm90ZXM6IG8udm90ZXMgKyAxIH0gOiBvKSksXG4gICAgICAgICAgICB9XG4gICAgICApXG4gICAgKTtcbiAgICBzZXRWb3RlZFJlY2VpcHRzKChwcmV2KSA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIFtiYWxsb3RJZF06IHtcbiAgICAgICAgb3B0aW9uSWQsXG4gICAgICAgIGhhc2g6IHJhbmRvbUhhc2gsXG4gICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0xvY2FsZVRpbWVTdHJpbmcoKSxcbiAgICAgIH0sXG4gICAgfSkpO1xuICAgIHRvYXN0LnN1Y2Nlc3MoYFZlcmlmaWVkIEJhbGxvdCBSZWNvcmRlZCEgUmVjZWlwdDogJHtyYW5kb21IYXNofWApO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZUN1c3RvbUJhbGxvdCA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFuZXdCYWxsb3RUaXRsZS50cmltKCkgfHwgIW5ld0JhbGxvdE9yZy50cmltKCkpIHtcbiAgICAgIHRvYXN0LmVycm9yKFwiUGxlYXNlIGVudGVyIGJvdGggdGhlIE9yZ2FuaXphdGlvbi9VbmlvbiBuYW1lIGFuZCBNb3Rpb24gVGl0bGUuXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjcmVhdGVkOiBJbnN0aXR1dGlvbmFsQmFsbG90ID0ge1xuICAgICAgaWQ6IGBiYWxsb3QtY3VzdG9tLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgY2F0ZWdvcnk6IG5ld0JhbGxvdENhdGVnb3J5LFxuICAgICAgb3JnYW5pemF0aW9uOiBuZXdCYWxsb3RPcmcudHJpbSgpLFxuICAgICAgdGl0bGU6IG5ld0JhbGxvdFRpdGxlLnRyaW0oKSxcbiAgICAgIGRlc2NyaXB0aW9uOlxuICAgICAgICBcIkN1c3RvbSBoaWdoLXRydXN0IGluc3RpdHV0aW9uYWwgYmFsbG90IGhvc3RlZCBvbiB0aGUgU3Rhc2ggb3IgVHJhc2ggVmVyaWZpZWQgVHJ1c3QgQmFyb21ldGVyIGluZnJhc3RydWN0dXJlLlwiLFxuICAgICAgdmVyaWZpY2F0aW9uU3RhbmRhcmQ6IFwiMS1QZXJzb24tMS1Wb3RlIFZlcmlmaWVkIElkZW50aXR5ICsgQXVkaXRhYmxlIEhhc2ggUmVjZWlwdFwiLFxuICAgICAgY2xvc2luZ0RhdGU6IFwiQ2xvc2VzIGluIDcgZGF5c1wiLFxuICAgICAgdG90YWxWZXJpZmllZFZvdGVzOiAxLFxuICAgICAgb3B0aW9uczogW1xuICAgICAgICB7XG4gICAgICAgICAgaWQ6IGBvcHQteWVzLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICAgIGxhYmVsOiBcIlN0YXNoIChBcHByb3ZlIC8gUmF0aWZ5IE1vdGlvbilcIixcbiAgICAgICAgICBzdWJ0aXRsZTogXCJWZXJpZmllZCBhZmZpcm1hdGl2ZSBiYWxsb3QgaW4gZmF2b3Igb2YgdGhlIHJlc29sdXRpb25cIixcbiAgICAgICAgICB2b3RlczogMSxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGlkOiBgb3B0LW5vLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICAgIGxhYmVsOiBcIlRyYXNoIChSZWplY3QgLyBDaGFsbGVuZ2UgTW90aW9uKVwiLFxuICAgICAgICAgIHN1YnRpdGxlOiBcIlZlcmlmaWVkIGRpc3NlbnRpbmcgYmFsbG90IHJlcXVlc3RpbmcgcmV2aXNpb24gb3IgbWVkaWF0aW9uXCIsXG4gICAgICAgICAgdm90ZXM6IDAsXG4gICAgICAgIH0sXG4gICAgICBdLFxuICAgIH07XG4gICAgc2V0QmFsbG90cygocHJldikgPT4gW2NyZWF0ZWQsIC4uLnByZXZdKTtcbiAgICBzZXROZXdCYWxsb3RUaXRsZShcIlwiKTtcbiAgICBzZXROZXdCYWxsb3RPcmcoXCJcIik7XG4gICAgdG9hc3Quc3VjY2VzcyhcIk5ldyBWZXJpZmllZCBJbnN0aXR1dGlvbmFsIEJhbGxvdCBsYXVuY2hlZCFcIik7XG4gIH07XG5cbiAgY29uc3QgY291bnRyaWVzID0gdXNlTWVtbygoKSA9PiBbXCJBbGwgY291bnRyaWVzXCIsIC4uLmNvdW50cnlPcHRpb25zKChicmFuZHMgPz8gW10pLm1hcCgoYnJhbmQpID0+IGJyYW5kLmNvdW50cnkpKV0sIFticmFuZHNdKTtcbiAgY29uc3QgY2F0ZWdvcmllcyA9IHVzZU1lbW8oKCkgPT4gY2F0ZWdvcnlPcHRpb25zKChicmFuZHMgPz8gW10pLm1hcCgoYnJhbmQpID0+IGJyYW5kQ2F0ZWdvcnkoYnJhbmQubmFtZSwgYnJhbmQuY2F0ZWdvcnkpKSksIFticmFuZHNdKTtcblxuICAvLyBTY29wZWQgbGlzdFxuICBjb25zdCBmaWx0ZXJlZEJyYW5kcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGNvbnN0IHRlcm0gPSBxdWVyeS50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICByZXR1cm4gKGJyYW5kcyA/PyBbXSkuZmlsdGVyKChicmFuZCkgPT4ge1xuICAgICAgY29uc3Qgbm9ybWFsaXplZENvdW50cnkgPSBub3JtYWxpemVDb3VudHJ5Q29kZShicmFuZC5jb3VudHJ5KTtcbiAgICAgIGNvbnN0IG5vcm1hbGl6ZWRDYXRlZ29yeSA9IGJyYW5kQ2F0ZWdvcnkoYnJhbmQubmFtZSwgYnJhbmQuY2F0ZWdvcnkpO1xuICAgICAgY29uc3QgYnJhbmRUaWVyID0gZ2V0QnJhbmRUaWVyKGJyYW5kLm5hbWUsIGJyYW5kLmNhdGVnb3J5KTtcbiAgICAgIGNvbnN0IHNlYXJjaGFibGUgPSBgJHticmFuZC5uYW1lfSAke2NvdW50cnlOYW1lKG5vcm1hbGl6ZWRDb3VudHJ5KX0gJHtub3JtYWxpemVkQ2F0ZWdvcnl9ICR7YnJhbmRUaWVyfWAudG9Mb3dlckNhc2UoKTtcbiAgICAgIHJldHVybiAoY291bnRyeSA9PT0gXCJBbGwgY291bnRyaWVzXCIgfHwgbm9ybWFsaXplZENvdW50cnkgPT09IGNvdW50cnkpXG4gICAgICAgICYmIChjYXRlZ29yeSA9PT0gXCJBbGwgY2F0ZWdvcmllc1wiIHx8IG5vcm1hbGl6ZWRDYXRlZ29yeSA9PT0gY2F0ZWdvcnkpXG4gICAgICAgICYmICh0aWVyID09PSBcIkFsbCB0aWVyc1wiIHx8IG1hdGNoZXNUaWVyKGJyYW5kVGllciwgdGllcikpXG4gICAgICAgICYmICghdGVybSB8fCBzZWFyY2hhYmxlLmluY2x1ZGVzKHRlcm0pKTtcbiAgICB9KS5zb3J0KChhLCBiKSA9PiAoTnVtYmVyKGIudHJ1c3Rfc2NvcmUpIHx8IDApIC0gKE51bWJlcihhLnRydXN0X3Njb3JlKSB8fCAwKSk7XG4gIH0sIFticmFuZHMsIGNhdGVnb3J5LCBjb3VudHJ5LCB0aWVyLCBxdWVyeV0pO1xuXG4gIGNvbnN0IHRvcCA9IGZpbHRlcmVkQnJhbmRzLnNsaWNlKDAsIDE1KTtcbiAgY29uc3QgcmVnaW9uTGFiZWwgPSBjb3VudHJ5ID09PSBcIkFsbCBjb3VudHJpZXNcIiA/IFwiR2xvYmFsIGF3YXJkc1wiIDogYCR7Y291bnRyeU5hbWUoY291bnRyeSl9IGF3YXJkc2A7XG5cbiAgLy8gSW5kdXN0cnkgc2VjdG9ycyAoZ3VhcmFudGVlaW5nIGZvb2QgbmV2ZXIgY29tcGV0ZXMgd2l0aCBjYXJzKVxuICBjb25zdCBpbmR1c3RyeVNlY3RvcnMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCBzZWN0b3JzID0gW1xuICAgICAge1xuICAgICAgICBpZDogXCJhdXRvbW90aXZlXCIsXG4gICAgICAgIHRpdGxlOiBcIkF1dG9tb3RpdmUgJiBNb2JpbGl0eVwiLFxuICAgICAgICBpY29uOiBDYXIsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlBhc3NlbmdlciB2ZWhpY2xlcywgbW9iaWxpdHkgdGVjaCwgYW5kIGVsZWN0cmljIHRyYW5zcG9ydC4gQ2FycyBjb21wZXRlIHN0cmljdGx5IHdpdGggY2Fycy5cIixcbiAgICAgICAgbWF0Y2g6IChjYXQ6IHN0cmluZykgPT4gY2F0LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoXCJhdXRvXCIpIHx8IGNhdC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKFwiY2Fyc1wiKSB8fCBjYXQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhcIm1vYmlsaXR5XCIpLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6IFwiZm9vZFwiLFxuICAgICAgICB0aXRsZTogXCJGb29kLCBHcm9jZXJ5ICYgRGluaW5nXCIsXG4gICAgICAgIGljb246IFV0ZW5zaWxzLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJSZXN0YXVyYW50cywgc3VwZXJtYXJrZXRzLCBwYWNrYWdlZCBzdGFwbGVzLCBhbmQgYmV2ZXJhZ2UgbWFrZXJzLiBKdWRnZWQgb24gdGFzdGUsIGh5Z2llbmUgJiB2YWx1ZS5cIixcbiAgICAgICAgbWF0Y2g6IChjYXQ6IHN0cmluZykgPT4gY2F0LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoXCJmb29kXCIpIHx8IGNhdC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKFwicmVzdGF1cmFudFwiKSB8fCBjYXQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhcInN0YXBsZVwiKSB8fCBjYXQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhcImFncmljdWx0dXJlXCIpLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6IFwidGVjaFwiLFxuICAgICAgICB0aXRsZTogXCJUZWNobm9sb2d5ICYgU29mdHdhcmVcIixcbiAgICAgICAgaWNvbjogTGFwdG9wLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJDb25zdW1lciBlbGVjdHJvbmljcywgcGVyc29uYWwgY29tcHV0aW5nLCB3ZWIgcGxhdGZvcm1zLCBhbmQgZXNzZW50aWFsIGRpZ2l0YWwgYXBwcy5cIixcbiAgICAgICAgbWF0Y2g6IChjYXQ6IHN0cmluZykgPT4gY2F0LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoXCJ0ZWNoXCIpIHx8IGNhdC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKFwic29mdHdhcmVcIikgfHwgY2F0LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoXCJ0ZWxlY29tXCIpLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6IFwicmV0YWlsXCIsXG4gICAgICAgIHRpdGxlOiBcIlJldGFpbCAmIEUtQ29tbWVyY2VcIixcbiAgICAgICAgaWNvbjogU2hvcHBpbmdCYWcsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkRlcGFydG1lbnQgc3RvcmVzLCBvbmxpbmUgbWFya2V0cGxhY2VzLCBhbmQgaG9tZSBlc3NlbnRpYWxzIHByb3ZpZGluZyByZWxpYWJsZSBjdXN0b21lciBzZXJ2aWNlLlwiLFxuICAgICAgICBtYXRjaDogKGNhdDogc3RyaW5nKSA9PiBjYXQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhcInJldGFpbFwiKSB8fCBjYXQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhcImUtY29tbWVyY2VcIikgfHwgY2F0LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoXCJtYXJrZXRwbGFjZVwiKSB8fCBjYXQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhcInN0b3JlXCIpLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6IFwiZmFzaGlvblwiLFxuICAgICAgICB0aXRsZTogXCJGYXNoaW9uICYgQXBwYXJlbFwiLFxuICAgICAgICBpY29uOiBTaGlydCxcbiAgICAgICAgZGVzY3JpcHRpb246IFwiRXZlcnlkYXkgc3RyZWV0d2Vhciwgc3BvcnRzIGFwcGFyZWwsIGZvb3R3ZWFyLCBhbmQgYmVzcG9rZSBhdHRpcmUuXCIsXG4gICAgICAgIG1hdGNoOiAoY2F0OiBzdHJpbmcpID0+IGNhdC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKFwiZmFzaGlvblwiKSB8fCBjYXQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhcImFwcGFyZWxcIikgfHwgY2F0LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoXCJjbG90aGluZ1wiKSB8fCBjYXQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhcImJlYXV0eVwiKSxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGlkOiBcImZpbmFuY2VcIixcbiAgICAgICAgdGl0bGU6IFwiQmFua2luZyAmIEZpbmFuY2lhbCBTZXJ2aWNlc1wiLFxuICAgICAgICBpY29uOiBCdWlsZGluZzIsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlJldGFpbCBiYW5raW5nLCBmaW50ZWNoIHdhbGxldHMsIGFuZCBpbnN1cmFuY2UgcHJvdGVjdGluZyBjb25zdW1lciBzZWN1cml0eS5cIixcbiAgICAgICAgbWF0Y2g6IChjYXQ6IHN0cmluZykgPT4gY2F0LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoXCJiYW5rXCIpIHx8IGNhdC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKFwiZmluYW5jZVwiKSB8fCBjYXQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhcImluc3VyYW5jZVwiKSxcbiAgICAgIH0sXG4gICAgXTtcblxuICAgIHJldHVybiBzZWN0b3JzLm1hcCgoc2VjKSA9PiB7XG4gICAgICBjb25zdCBzZWN0b3JCcmFuZHMgPSAoYnJhbmRzID8/IFtdKS5maWx0ZXIoKGIpID0+IHtcbiAgICAgICAgY29uc3QgY2F0ID0gYnJhbmRDYXRlZ29yeShiLm5hbWUsIGIuY2F0ZWdvcnkpO1xuICAgICAgICBjb25zdCBtYXRjaGVzQ291bnRyeSA9IGNvdW50cnkgPT09IFwiQWxsIGNvdW50cmllc1wiIHx8IG5vcm1hbGl6ZUNvdW50cnlDb2RlKGIuY291bnRyeSkgPT09IGNvdW50cnk7XG4gICAgICAgIHJldHVybiBtYXRjaGVzQ291bnRyeSAmJiBzZWMubWF0Y2goY2F0KTtcbiAgICAgIH0pLnNvcnQoKGEsIGIpID0+IChOdW1iZXIoYi50cnVzdF9zY29yZSkgfHwgMCkgLSAoTnVtYmVyKGEudHJ1c3Rfc2NvcmUpIHx8IDApKTtcblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uc2VjLFxuICAgICAgICBsZWFkZXJzOiBzZWN0b3JCcmFuZHMuc2xpY2UoMCwgNCksXG4gICAgICAgIHRvdGFsQ291bnQ6IHNlY3RvckJyYW5kcy5sZW5ndGgsXG4gICAgICB9O1xuICAgIH0pO1xuICB9LCBbYnJhbmRzLCBjb3VudHJ5XSk7XG5cbiAgLy8gTWFya2V0IFRpZXJzIChMdXh1cnksIFByZW1pdW0sIE1hc3MgTWFya2V0LCBCdWRnZXQpXG4gIGNvbnN0IHRpZXJTZWdtZW50cyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGNvbnN0IHRpZXJLZXlzOiAoXCJCdWRnZXRcIiB8IFwiTWFzcyBNYXJrZXRcIiB8IFwiUHJlbWl1bVwiIHwgXCJMdXh1cnlcIilbXSA9IFtcIkJ1ZGdldFwiLCBcIk1hc3MgTWFya2V0XCIsIFwiUHJlbWl1bVwiLCBcIkx1eHVyeVwiXTtcbiAgICByZXR1cm4gdGllcktleXMubWFwKCh0aykgPT4ge1xuICAgICAgY29uc3QgaW5mbyA9IGdldFRpZXJJbmZvKHRrKTtcbiAgICAgIGNvbnN0IHRpZXJCcmFuZHMgPSAoYnJhbmRzID8/IFtdKS5maWx0ZXIoKGIpID0+IHtcbiAgICAgICAgY29uc3QgbWF0Y2hlc0NvdW50cnkgPSBjb3VudHJ5ID09PSBcIkFsbCBjb3VudHJpZXNcIiB8fCBub3JtYWxpemVDb3VudHJ5Q29kZShiLmNvdW50cnkpID09PSBjb3VudHJ5O1xuICAgICAgICBjb25zdCBiVGllciA9IGdldEJyYW5kVGllcihiLm5hbWUsIGIuY2F0ZWdvcnkpO1xuICAgICAgICByZXR1cm4gbWF0Y2hlc0NvdW50cnkgJiYgYlRpZXIgPT09IHRrO1xuICAgICAgfSkuc29ydCgoYSwgYikgPT4gKE51bWJlcihiLnRydXN0X3Njb3JlKSB8fCAwKSAtIChOdW1iZXIoYS50cnVzdF9zY29yZSkgfHwgMCkpO1xuXG4gICAgICByZXR1cm4ge1xuICAgICAgICB0aWVyS2V5OiB0ayxcbiAgICAgICAgaW5mbyxcbiAgICAgICAgbGVhZGVyczogdGllckJyYW5kcy5zbGljZSgwLCA1KSxcbiAgICAgICAgdG90YWxDb3VudDogdGllckJyYW5kcy5sZW5ndGgsXG4gICAgICB9O1xuICAgIH0pO1xuICB9LCBbYnJhbmRzLCBjb3VudHJ5XSk7XG5cbiAgY29uc3QgYXdhcmRUeXBlcyA9IFtcbiAgICB7IGljb246IENyb3duLCB0aXRsZTogdChcImF3YXJkcy5jYXQxXCIpIHx8IFwiTW9zdCBUcnVzdGVkIEJyYW5kXCIsIGRlc2M6IHQoXCJhd2FyZHMuY2F0MWRcIikgfHwgXCJIaWdoZXN0IHBvc2l0aXZlIHJhdGlvIG9mIGNvbW11bml0eSB2ZXJkaWN0c1wiIH0sXG4gICAgeyBpY29uOiBIZWFydCwgdGl0bGU6IHQoXCJhd2FyZHMuY2F0MlwiKSB8fCBcIlBlb3BsZSdzIENoYW1waW9uXCIsIGRlc2M6IHQoXCJhd2FyZHMuY2F0MmRcIikgfHwgXCJVbm1hdGNoZWQgZ3Jhc3Nyb290cyBhZHZvY2FjeSBhY3Jvc3Mgc29jaWFsIHNpZ25hbHNcIiB9LFxuICAgIHsgaWNvbjogVHJlbmRpbmdVcCwgdGl0bGU6IHQoXCJhd2FyZHMuY2F0M1wiKSB8fCBcIkJpZ2dlc3QgVHVybmFyb3VuZFwiLCBkZXNjOiB0KFwiYXdhcmRzLmNhdDNkXCIpIHx8IFwiTGFyZ2VzdCB1cHdhcmQgc2VudGltZW50IHJlY292ZXJ5IHBvc3QtY3Jpc2lzXCIgfSxcbiAgICB7IGljb246IFNwYXJrbGVzLCB0aXRsZTogdChcImF3YXJkcy5jYXQ0XCIpIHx8IFwiUmlzaW5nIFN0YXJcIiwgZGVzYzogdChcImF3YXJkcy5jYXQ0ZFwiKSB8fCBcIkZhc3Rlc3QgZ3Jvd2luZyBuZXdjb21lciB3aW5uaW5nIGN1c3RvbWVyIGxveWFsdHlcIiB9LFxuICBdO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW5cIj5cbiAgICAgIDxIZWFkZXIgLz5cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cIm14LWF1dG8gbWF4LXctNXhsIHB4LTQgcHktOFwiPlxuICAgICAgICB7LyogSGVybyAqL31cbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicm91bmRlZC0zeGwgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctZ3JhZGllbnQtdG8tYiBmcm9tLXNlY29uZGFyeS82MCB0by1jYXJkIHAtOCB0ZXh0LWNlbnRlciBzaGFkb3ctc21cIj5cbiAgICAgICAgICA8VHJvcGh5IGNsYXNzTmFtZT1cIm14LWF1dG8gaC0xMiB3LTEyIHRleHQtcHJpbWFyeVwiIC8+XG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cIm10LTQgZm9udC1kaXNwbGF5IHRleHQtNHhsIGZvbnQtZXh0cmFib2xkIHNtOnRleHQtNXhsXCI+e3QoXCJhd2FyZHMudGl0bGVcIikgfHwgXCJUaGUgU09UIEF3YXJkc1wifTwvaDE+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiBmb250LWRpc3BsYXkgdGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtcHJpbWFyeVwiPlxuICAgICAgICAgICAge3QoXCJhd2FyZHMudGFnbGluZVwiKSB8fCBcIlRoZSBCcmFuZCBCYXJvbWV0ZXIg4oCUIFRoZSBQZW9wbGUncyBWZXJkaWN0LCBNYWRlIE9mZmljaWFsXCJ9XG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBmbGV4IGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICA8UGVvcGxlVHJ1c3RGYWN0b3JMaW5rIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXgtYXV0byBtdC00IG1heC13LTJ4bCB0ZXh0LW11dGVkLWZvcmVncm91bmQgdGV4dC1zbSBzbTp0ZXh0LWJhc2UgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICBFdmVyeSBjcm93biBpcyBkZWNpZGVkIHB1cmVseSBieSB2ZXJpZmlhYmxlIHB1YmxpYyBjb25zdW1lciBzZW50aW1lbnQuIEZhaXIgc3RhbmRhcmRzIGVuc3VyZVxuICAgICAgICAgICAgbGlrZS1mb3ItbGlrZSBjb21wYXJpc29ucyBzbyBmb29kIG5ldmVyIGNvbXBldGVzIHdpdGggY2FycywgYW5kIGx1eHVyeSBjb25nbG9tZXJhdGVzIG5ldmVyIG92ZXJzaGFkb3cgYnVkZ2V0IGNoYW1waW9ucy5cbiAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICB7LyogU3RhbmRhcmQgQmFubmVyICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBteC1hdXRvIG1heC13LTJ4bCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXByaW1hcnkvMjUgYmctcHJpbWFyeS81IHAtNCB0ZXh0LWxlZnRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1wcmltYXJ5IGZvbnQtYm9sZCB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwiaC00IHctNCBzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPkZhaXIgRGlyZWN0b3J5ICYgQ29tcGV0aXRpb24gU3RhbmRhcmQ8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyBzbTp0ZXh0LXNtIHRleHQtZm9yZWdyb3VuZC85MCBsZWFkaW5nLXJlbGF4ZWQgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgRXZlcnkgY291bnRyeSBpcyBkaXNjb3ZlcmFibGUsIGFuZCBicmFuZHMgYXJlIGNsYXNzaWZpZWQgYWNyb3NzIGRlZmluZWQgbWFya2V0IHRpZXJzIChMdXh1cnksIFByZW1pdW0sIE1hc3MgTWFya2V0LCBCdWRnZXQpLiBMdXh1cnkgbWFpc29ucyBhbmQgcHJlbWl1bSB0ZWNoIGdpYW50cyBuZXZlciBjcm93ZCBvdXQgbWFzcy1tYXJrZXQgZXNzZW50aWFscyBvciBidWRnZXQgY2hhbXBpb25zLlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgey8qIFZpZXcgTW9kZSBTd2l0Y2hlciAqL31cbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibXQtOFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIgc206anVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1ib3JkZXIgcGItNFwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LTJ4bCBmb250LWJvbGRcIj57dChcImF3YXJkcy5sZWFkZXJib2FyZFwiKSB8fCBcIkFubnVhbCBMZWFkZXJib2FyZFwifTwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgIENsYXNzaWZpZWQgY29tcGV0aXRpb24gc3RhbmRhcmQ6IEV4cGxvcmUgc2VjdG9yLWJ5LXNlY3RvciBhbmQgdGllci1ieS10aWVyIHJhbmtpbmdzLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctc2Vjb25kYXJ5LzYwIHAtMSByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3TW9kZShcImluZHVzdHJpZXNcIil9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgIFwicHgtMyBweS0xLjUgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGxcIixcbiAgICAgICAgICAgICAgICAgIHZpZXdNb2RlID09PSBcImluZHVzdHJpZXNcIlxuICAgICAgICAgICAgICAgICAgICA/IFwiYmctYmFja2dyb3VuZCB0ZXh0LWZvcmVncm91bmQgc2hhZG93LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtbXV0ZWQtZm9yZWdyb3VuZCBob3Zlcjp0ZXh0LWZvcmVncm91bmRcIlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBCeSBJbmR1c3RyeSBTZWN0b3JcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3TW9kZShcInRpZXJzXCIpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICBcInB4LTMgcHktMS41IHJvdW5kZWQtbGcgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsXCIsXG4gICAgICAgICAgICAgICAgICB2aWV3TW9kZSA9PT0gXCJ0aWVyc1wiXG4gICAgICAgICAgICAgICAgICAgID8gXCJiZy1iYWNrZ3JvdW5kIHRleHQtZm9yZWdyb3VuZCBzaGFkb3ctc21cIlxuICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGhvdmVyOnRleHQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEJ5IE1hcmtldCBUaWVyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Vmlld01vZGUoXCJzZWFyY2hcIil9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgIFwicHgtMyBweS0xLjUgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGxcIixcbiAgICAgICAgICAgICAgICAgIHZpZXdNb2RlID09PSBcInNlYXJjaFwiXG4gICAgICAgICAgICAgICAgICAgID8gXCJiZy1iYWNrZ3JvdW5kIHRleHQtZm9yZWdyb3VuZCBzaGFkb3ctc21cIlxuICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGhvdmVyOnRleHQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEN1c3RvbSBTY29wZWQgU2VhcmNoXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Vmlld01vZGUoXCJpbnN0aXR1dGlvbmFsXCIpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICBcImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbFwiLFxuICAgICAgICAgICAgICAgICAgdmlld01vZGUgPT09IFwiaW5zdGl0dXRpb25hbFwiXG4gICAgICAgICAgICAgICAgICAgID8gXCJiZy1zbGF0ZS05NTAgdGV4dC1bI2Q2YTkyOF0gc2hhZG93LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtZm9yZWdyb3VuZCBob3ZlcjpiZy1iYWNrZ3JvdW5kLzYwXCJcbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFZvdGUgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgdGV4dC1bI2Q2YTkyOF1cIiAvPlxuICAgICAgICAgICAgICAgIEluc3RpdHV0aW9uYWwgVm90aW5nIChVbmlvbnMgLyBHb3YgLyBPZmZpY2VzKVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIENvdW50cnkgJiBQZXJpb2QgRmlsdGVyIEhlYWRlciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZvbnQtbWVkaXVtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICA8TWFwIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1wcmltYXJ5XCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+UmVnaW9uOjwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgIHZhbHVlPXtjb3VudHJ5fVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q291bnRyeShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1iYWNrZ3JvdW5kIHB4LTIuNSBweS0xIHRleHQteHMgZm9udC1ib2xkIHRleHQtZm9yZWdyb3VuZCBvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge2NvdW50cmllcy5tYXAoKGMpID0+IChcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtjfSB2YWx1ZT17Y30+XG4gICAgICAgICAgICAgICAgICAgIHtjID09PSBcIkFsbCBjb3VudHJpZXNcIiA/IFwiR2xvYmFsIChBbGwgQ291bnRyaWVzKVwiIDogY291bnRyeU5hbWUoYyl9XG4gICAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICA8Q2FsZW5kYXJDbG9jayBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSB0ZXh0LXByaW1hcnlcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj57cGVyaW9kfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4+wrcgU25hcHNob3Qge3NuYXBzaG90VGltZS50b0xvY2FsZURhdGVTdHJpbmcoKX08L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBWSUVXIDE6IEJZIElORFVTVFJZIFNFQ1RPUlMgKEZPT0QgVlMgQ0FSUyBTRVBBUkFUSU9OKSAqL31cbiAgICAgICAgICB7dmlld01vZGUgPT09IFwiaW5kdXN0cmllc1wiICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYm9yZGVyLzgwIGJnLWNhcmQgcC00IHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZm9yZWdyb3VuZFwiPlN0cmljdCBWZXJ0aWNhbCBTZWdtZW50YXRpb246IDwvc3Bhbj5cbiAgICAgICAgICAgICAgICBBdXRvbW90aXZlIGJyYW5kcyBjb21wZXRlIGV4Y2x1c2l2ZWx5IGFnYWluc3QgYXV0b21vdGl2ZSBtb2JpbGl0eTsgZm9vZCBhbmQgZGluaW5nIGNvbXBldGUgYWdhaW5zdCBmb29kLiBBIGZhc3QtZm9vZCBjaGFpbiBuZXZlciBsb3NlcyBhbiBhd2FyZCB0byBhIHN1cGVyY2FyIGF0ZWxpZXIuXG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNiBtZDpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgICAgIHtpbmR1c3RyeVNlY3RvcnMubWFwKChzZWN0b3IpID0+IHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IEljb24gPSBzZWN0b3IuaWNvbjtcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtzZWN0b3IuaWR9IGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLWNhcmQgcC01IHNoYWRvdy1zbSBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgbWItMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGgtOCB3LTggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGcgYmctcHJpbWFyeS8xMCB0ZXh0LXByaW1hcnlcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC1iYXNlIGZvbnQtYm9sZFwiPntzZWN0b3IudGl0bGV9PC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57c2VjdG9yLnRvdGFsQ291bnR9IG5vbWluYXRlZCBicmFuZHM8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtYi00XCI+e3NlY3Rvci5kZXNjcmlwdGlvbn08L3A+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWN0b3IubGVhZGVycy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmQgcHktNCB0ZXh0LWNlbnRlclwiPk5vIG5vbWluZWVzIGZvciB0aGlzIGNvdW50cnkgeWV0LjwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWN0b3IubGVhZGVycy5tYXAoKGIsIGlkeCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYlRpZXIgPSBnZXRCcmFuZFRpZXIoYi5uYW1lLCBiLmNhdGVnb3J5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRJbmZvID0gZ2V0VGllckluZm8oYlRpZXIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2IuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvYnJhbmRzLyRzbHVnXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbXM9e3sgc2x1ZzogYi5zbHVnIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ib3JkZXIvNjAgYmctc2Vjb25kYXJ5LzMwIHB4LTMgcHktMiB0ZXh0LXhzIHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJnLXNlY29uZGFyeVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctNSBmb250LWRpc3BsYXkgZm9udC1leHRyYWJvbGQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpZHggPT09IDAgPyBcIvCfpYdcIiA6IGlkeCA9PT0gMSA/IFwi8J+liFwiIDogaWR4ID09PSAyID8gXCLwn6WJXCIgOiBgJHtpZHggKyAxfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC03IHctNyBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZCBiZy1zZWNvbmRhcnkgZm9udC1ib2xkIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtiLnNpZ25lZExvZ29VcmwgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2Iuc2lnbmVkTG9nb1VybH0gYWx0PXtiLm5hbWV9IGNsYXNzTmFtZT1cImgtZnVsbCB3LWZ1bGwgb2JqZWN0LWNvdmVyIHJvdW5kZWRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGIubmFtZS5jaGFyQXQoMClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGQgdHJ1bmNhdGUgdGV4dC1mb3JlZ3JvdW5kXCI+e2IubmFtZX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17Y24oXCJ0ZXh0LVs5cHhdIGZvbnQtc2VtaWJvbGQgYm9yZGVyIHJvdW5kZWQgcHgtMVwiLCB0SW5mby5iYWRnZUNsYXNzKX0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RJbmZvLnByaWNlUG9pbnR9IHt0SW5mby5zaG9ydE5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgZm9udC1kaXNwbGF5IGZvbnQtYm9sZCB0ZXh0LXN0YXNoIHNocmluay0wIG1sLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUcmVuZGluZ1VwIGNsYXNzTmFtZT1cImgtMyB3LTNcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2IudHJ1c3Rfc2NvcmV9JTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtMyBib3JkZXItdCBib3JkZXItYm9yZGVyLzUwIHRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL2JyYW5kc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXByaW1hcnkgaG92ZXI6dW5kZXJsaW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgVmlldyBhbGwgaW4ge3NlY3Rvci50aXRsZX0g4oaSXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIFZJRVcgMjogQlkgTUFSS0VUIFRJRVJTIChMVVhVUlksIFBSRU1JVU0sIE1BU1MgTUFSS0VULCBCVURHRVQpICovfVxuICAgICAgICAgIHt2aWV3TW9kZSA9PT0gXCJ0aWVyc1wiICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYm9yZGVyLzgwIGJnLWNhcmQgcC00IHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZm9yZWdyb3VuZFwiPkVxdWFsIFN0YXR1cmUgQWNyb3NzIFRpZXJzOiA8L3NwYW4+XG4gICAgICAgICAgICAgICAgQnVkZ2V0IGNoYW1waW9ucyBhbmQgZXZlcnlkYXkgbWFzcy1tYXJrZXQgZXNzZW50aWFscyBhcmUgY2VsZWJyYXRlZCB3aXRoIGVxdWFsIHByZXN0aWdlIGFsb25nc2lkZSBsdXh1cnkgbWFpc29ucyBhbmQgcHJlbWl1bSBpbm5vdmF0b3JzLlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTYgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTRcIj5cbiAgICAgICAgICAgICAgICB7dGllclNlZ21lbnRzLm1hcCgoc2VnbWVudCkgPT4ge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgIGtleT17c2VnbWVudC50aWVyS2V5fVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgICBcInJvdW5kZWQtMnhsIGJvcmRlciBiZy1jYXJkIHAtNCBzaGFkb3ctc20gZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW5cIixcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlZ21lbnQuaW5mby5ib3JkZXJDbGFzc1xuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2NuKFwicm91bmRlZC1tZCBib3JkZXIgcHgtMiBweS0wLjUgdGV4dC14cyBmb250LWJvbGRcIiwgc2VnbWVudC5pbmZvLmJhZGdlQ2xhc3MpfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VnbWVudC5pbmZvLnByaWNlUG9pbnR9IHtzZWdtZW50LnRpZXJLZXl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VnbWVudC50b3RhbENvdW50fSBicmFuZHNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtc20gZm9udC1ib2xkIHRleHQtZm9yZWdyb3VuZFwiPntzZWdtZW50LmluZm8ubGFiZWx9PC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtdC0xIG1iLTQgbGVhZGluZy1ub3JtYWxcIj57c2VnbWVudC5pbmZvLmRlc2NyaXB0aW9ufTwvcD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3NlZ21lbnQubGVhZGVycy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmQgcHktNCB0ZXh0LWNlbnRlclwiPk5vIG5vbWluZWVzIHlldC48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VnbWVudC5sZWFkZXJzLm1hcCgoYiwgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2IuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL2JyYW5kcy8kc2x1Z1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtcz17eyBzbHVnOiBiLnNsdWcgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ib3JkZXIvNTAgYmctc2Vjb25kYXJ5LzMwIHAtMiB0ZXh0LXhzIHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJnLXNlY29uZGFyeVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTQgZm9udC1ib2xkIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCB0ZXh0LWNlbnRlciB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lkeCArIDF9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0cnVuY2F0ZSB0ZXh0LWZvcmVncm91bmRcIj57Yi5uYW1lfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCB0cnVuY2F0ZVwiPnticmFuZENhdGVnb3J5KGIubmFtZSwgYi5jYXRlZ29yeSl9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IGZvbnQtZXh0cmFib2xkIHRleHQtc3Rhc2ggc2hyaW5rLTAgbWwtMSB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2IudHJ1c3Rfc2NvcmV9JVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB0LTIgYm9yZGVyLXQgYm9yZGVyLWJvcmRlci80MCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvYnJhbmRzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXByaW1hcnkgaG92ZXI6dW5kZXJsaW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgRXhwbG9yZSBhbGwge3NlZ21lbnQudGllcktleX0g4oaSXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIFZJRVcgMzogQ1VTVE9NIEZJTFRFUkVEIFNFQVJDSCAmIERFVEFJTEVEIFRBQkxFICovfVxuICAgICAgICAgIHt2aWV3TW9kZSA9PT0gXCJzZWFyY2hcIiAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctY2FyZCBwLTQgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0zIGxnOmdyaWQtY29scy1bMWZyXzIwMHB4XzIwMHB4XVwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaC0xMCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1iYWNrZ3JvdW5kIHB4LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtxdWVyeX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFF1ZXJ5KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBicmFuZHMgb3IgaW5kdXN0cmllc1wiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTEgYmctdHJhbnNwYXJlbnQgdGV4dC1zbSBvdXRsaW5lLW5vbmUgcGxhY2Vob2xkZXI6dGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NhdGVnb3J5fVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENhdGVnb3J5KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xMCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLWJhY2tncm91bmQgcHgtMyB0ZXh0LXhzIGZvbnQtbWVkaXVtIG91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yaWVzLm1hcCgoYykgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtjfSB2YWx1ZT17Y30+e2N9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG5cbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RpZXJ9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGllcihlLnRhcmdldC52YWx1ZSBhcyBCcmFuZFRpZXJGaWx0ZXIpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTEwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctYmFja2dyb3VuZCBweC0zIHRleHQteHMgZm9udC1tZWRpdW0gb3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge0JSQU5EX1RJRVJTLm1hcCgodCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXt0fSB2YWx1ZT17dH0+e3R9PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBMZWFkZXJib2FyZCBUYWJsZSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctY2FyZFwiPlxuICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktcHhcIj5cbiAgICAgICAgICAgICAgICAgICAge1swLCAxLCAyLCAzXS5tYXAoKGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8U2tlbGV0b24ga2V5PXtpfSBjbGFzc05hbWU9XCJoLTE0IHctZnVsbCByb3VuZGVkLW5vbmVcIiAvPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkgOiB0b3AubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyIHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+Tm8gYnJhbmRzIG1hdGNoIHRoaXMgc2NvcGUuPC9wPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICB0b3AubWFwKChiLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGJUaWVyID0gZ2V0QnJhbmRUaWVyKGIubmFtZSwgYi5jYXRlZ29yeSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHRpZXJJbmZvID0gZ2V0VGllckluZm8oYlRpZXIpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2IuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9icmFuZHMvJHNsdWdcIlxuICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1zPXt7IHNsdWc6IGIuc2x1ZyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgYm9yZGVyLWIgYm9yZGVyLWJvcmRlciBiZy1jYXJkIHB4LTQgcHktMyB0cmFuc2l0aW9uLWNvbG9ycyBsYXN0OmJvcmRlci0wIGhvdmVyOmJnLXNlY29uZGFyeS81MFwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy04IHRleHQtY2VudGVyIGZvbnQtZGlzcGxheSB0ZXh0LWxnIGZvbnQtZXh0cmFib2xkIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aSA8IDMgPyBbXCIxc3RcIiwgXCIybmRcIiwgXCIzcmRcIl1baV0gOiBpICsgMX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTkgdy05IHNocmluay0wIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1sZyBiZy1zZWNvbmRhcnkgdGV4dC1zbSBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Iuc2lnbmVkTG9nb1VybCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17Yi5zaWduZWRMb2dvVXJsfSBhbHQ9e2IubmFtZX0gY2xhc3NOYW1lPVwiaC1mdWxsIHctZnVsbCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGIubmFtZS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4LTEgdHJ1bmNhdGUgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlXCI+e2IubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiaGlkZGVuIHNtOmlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSByb3VuZGVkLW1kIGJvcmRlciBweC0xLjUgcHktMC41IHRleHQtWzEwcHhdIGZvbnQtYm9sZCBsZWFkaW5nLW5vbmVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGllckluZm8uYmFkZ2VDbGFzc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1bOXB4XSBvcGFjaXR5LTc1XCI+e3RpZXJJbmZvLnByaWNlUG9pbnR9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3RpZXJJbmZvLnNob3J0TmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ub3JtYWwgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvdW50cnlOYW1lKG5vcm1hbGl6ZUNvdW50cnlDb2RlKGIuY291bnRyeSkpfSDCtyB7YnJhbmRDYXRlZ29yeShiLm5hbWUsIGIuY2F0ZWdvcnkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGZvbnQtZGlzcGxheSBmb250LWV4dHJhYm9sZCB0ZXh0LXN0YXNoXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxUcmVuZGluZ1VwIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Yi50cnVzdF9zY29yZX0lXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogVklFVyA0OiBWRVJJRklFRCBJTlNUSVRVVElPTkFMIFZPVElORyBJTkZSQVNUUlVDVFVSRSAoVU5JT05TLCBBV0FSRFMsIE9GRklDRVMsIENJVklDKSAqL31cbiAgICAgICAgICB7dmlld01vZGUgPT09IFwiaW5zdGl0dXRpb25hbFwiICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAgey8qIEFyY2hpdGVjdHVyZSBCYW5uZXIgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyLTIgYm9yZGVyLVsjZDZhOTI4XS80MCBiZy1ncmFkaWVudC10by1iciBmcm9tLXNsYXRlLTk1MCB2aWEtc2xhdGUtOTAwIHRvLXNsYXRlLTk1MCBwLTYgdGV4dC13aGl0ZSBzaGFkb3ctbWRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTQgbWQ6ZmxleC1yb3cgbWQ6aXRlbXMtY2VudGVyIG1kOmp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgbWF4LXctMnhsXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLVsjZDZhOTI4XS80MCBiZy1bI2Q2YTkyOF0vMTAgcHgtMyBweS0xIHRleHQtWzExcHhdIGZvbnQtZXh0cmFib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LVsjZjVkMDYxXVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxMb2NrIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICBTdHJhdGVneSBDIMK3IFZlcmlmaWVkIFRydXN0IEJhcm9tZXRlciBJbmZyYXN0cnVjdHVyZVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LTJ4bCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgSGlnaC1UcnVzdCBJbnN0aXR1dGlvbmFsIFZvdGluZyAmIEJhbGxvdCBDaGFtYmVyc1xuICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNtOnRleHQtc20gdGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgQmVjYXVzZSBTdGFzaCBvciBUcmFzaCB2ZXJpZmllcyByZWFsIGNpdGl6ZW5zLCBhdXRoZW50aWMgcHJvZHVjdCBiYXRjaGVzLCBhbmQgcmVndWxhdG9yeSBhd2FyZW5lc3MgKENQQSAmIENHU08pLCBvdXIgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LVsjZjVkMDYxXVwiPlRydXN0IEJhcjwvc3Ryb25nPiBzY2FsZXMgZGlyZWN0bHkgdG8gaG9zdCB0YW1wZXItcHJvb2Ygb25saW5lIHZvdGluZyBmb3IgPHN0cm9uZz5UcmFkZSBVbmlvbnM8L3N0cm9uZz4sIDxzdHJvbmc+R292ZXJubWVudCAmIFB1YmxpYyBBd2FyZHMgQ2VyZW1vbmllczwvc3Ryb25nPiwgYW5kIDxzdHJvbmc+Q29ycG9yYXRlIE9mZmljZSBHb3Zlcm5hbmNlPC9zdHJvbmc+LlxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMiBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlT2JzZXJ2ZXJUb3BpYyhcIlNPVCBJbnN0aXR1dGlvbmFsIEJhbGxvdCBPYnNlcnZlciAmIExpdmUgVG93bmhhbGxcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRMaXZlT2JzZXJ2ZXJNb2RhbE9wZW4odHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcm91bmRlZC14bCBiZy1bI2Q2YTkyOF0gcHgtNCBweS0yLjUgdGV4dC14cyBmb250LWJsYWNrIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTk1MCBzaGFkb3ctc20gaG92ZXI6YmctWyNlNWI5MzVdIHRyYW5zaXRpb25cIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPFZpZGVvIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIExhdW5jaCBMaXZlIEJhbGxvdCBUb3duaGFsbCAvIENhbGxcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtY2VudGVyIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgUG93ZXJlZCBieSBHb29nbGUgV2ViUlRDICYgQWdvcmEgUlRDXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC01IGdyaWQgZ2FwLTMgc206Z3JpZC1jb2xzLTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBwdC00IHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxVc2VycyBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtWyNkNmE5MjhdIHNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtd2hpdGVcIj5UcmFkZSBVbmlvbnMgJiBGZWRlcmF0aW9uczwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMXB4XVwiPjEtTWVtYmVyLTEtVm90ZSB3YWdlIG1hbmRhdGVzLCBzdHJpa2UgYmFsbG90cyAmIHNob3Agc3Rld2FyZCBlbGVjdGlvbnMuPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgPExhbmRtYXJrIGNsYXNzTmFtZT1cImgtNCB3LTQgdGV4dC1bI2Q2YTkyOF0gc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC13aGl0ZVwiPkdvdiAmIE5hdGlvbmFsIENlcmVtb25pZXM8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1bMTFweF1cIj5BdWRpdGFibGUgcHVibGljIGF3YXJkcywgbXVuaWNpcGFsIHNlcnZpY2UgcG9sbHMgJiBvbWJ1ZHNtYW4gcmVjb2duaXRpb24uPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgPEJyaWVmY2FzZSBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtWyNkNmE5MjhdIHNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtd2hpdGVcIj5PZmZpY2VzICYgQm9hcmRyb29tczwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMXB4XVwiPldvcmtwbGFjZSBwb2xpY3kgcG9sbHMsIEFHTSBzaGFyZWhvbGRlciBtb3Rpb25zICYgc3VwcGx5LWNoYWluIGF1ZGl0cy48L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBBY3RpdmUgSW5zdGl0dXRpb25hbCBCYWxsb3RzICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIHtiYWxsb3RzLm1hcCgoYmFsbG90KSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCByZWNlaXB0ID0gdm90ZWRSZWNlaXB0c1tiYWxsb3QuaWRdO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgIGtleT17YmFsbG90LmlkfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLWNhcmQgcC01IHNoYWRvdy1zbSBzcGFjZS15LTRcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgYm9yZGVyLWIgYm9yZGVyLWJvcmRlci82MCBwYi0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJvdW5kZWQtbWQgYmctcHJpbWFyeS8xMCBweC0yLjUgcHktMC41IHRleHQtWzExcHhdIGZvbnQtZXh0cmFib2xkIHRleHQtcHJpbWFyeSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtiYWxsb3QuY2F0ZWdvcnl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtiYWxsb3Qub3JnYW5pemF0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJtdC0xLjUgZm9udC1kaXNwbGF5IHRleHQtbGcgZm9udC1leHRyYWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2JhbGxvdC50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YmFsbG90LmRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWVuZCBnYXAtMS41IHRleHQtcmlnaHQgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTUwMC8xMCBweC0yLjUgcHktMC41IHRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2JhbGxvdC50b3RhbFZlcmlmaWVkVm90ZXMudG9Mb2NhbGVTdHJpbmcoKX0gVmVyaWZpZWQgQmFsbG90c1xuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntiYWxsb3QuY2xvc2luZ0RhdGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlT2JzZXJ2ZXJUb3BpYyhgJHtiYWxsb3Qub3JnYW5pemF0aW9ufTogJHtiYWxsb3QudGl0bGV9YCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRMaXZlT2JzZXJ2ZXJNb2RhbE9wZW4odHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtcHJpbWFyeSBob3Zlcjp1bmRlcmxpbmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJhZGlvIGNsYXNzTmFtZT1cImgtMyB3LTMgdGV4dC1yb3NlLTUwMCBhbmltYXRlLXB1bHNlXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBKb2luIExpdmUgT2JzZXJ2ZXIgQ2FsbCAvIFN0cmVhbVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEJhbGxvdCBPcHRpb25zICovfVxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtMyBzbTpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2JhbGxvdC5vcHRpb25zLm1hcCgob3B0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHBjdCA9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFsbG90LnRvdGFsVmVyaWZpZWRWb3RlcyA+IDBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gTWF0aC5yb3VuZCgob3B0LnZvdGVzIC8gYmFsbG90LnRvdGFsVmVyaWZpZWRWb3RlcykgKiAxMDApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSByZWNlaXB0Py5vcHRpb25JZCA9PT0gb3B0LmlkO1xuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17b3B0LmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJyb3VuZGVkLXhsIGJvcmRlciBwLTQgdHJhbnNpdGlvbi1hbGwgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW5cIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNTZWxlY3RlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItZW1lcmFsZC01MDAgYmctZW1lcmFsZC01MDAvNSBzaGFkb3cteHNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJib3JkZXItYm9yZGVyIGJnLXNlY29uZGFyeS8yMCBob3Zlcjpib3JkZXItcHJpbWFyeS80MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0LmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC1zbSBmb250LWJsYWNrIHRleHQtcHJpbWFyeSBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BjdH0lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntvcHQuc3VidGl0bGV9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTIgdy1mdWxsIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLWZ1bGwgYmctc2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJoLWZ1bGwgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkID8gXCJiZy1lbWVyYWxkLTUwMFwiIDogXCJiZy1wcmltYXJ5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7cGN0fSVgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcHQudm90ZXMudG9Mb2NhbGVTdHJpbmcoKX0gdmVyaWZpZWQgdm90ZXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ISFyZWNlaXB0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ2FzdEluc3RpdHV0aW9uYWxWb3RlKGJhbGxvdC5pZCwgb3B0LmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHJvdW5kZWQtbGcgcHgtMyBweS0xIHRleHQteHMgZm9udC1ib2xkIHRyYW5zaXRpb25cIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNTZWxlY3RlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHJlY2VpcHRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1zZWNvbmRhcnkgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGN1cnNvci1ub3QtYWxsb3dlZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctc2xhdGUtOTUwIHRleHQtWyNkNmE5MjhdIGhvdmVyOmJnLXNsYXRlLTkwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1NlbGVjdGVkID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVjayBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+IEJhbGxvdCBMb2NrZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxWb3RlIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz4gQ2FzdCBWZXJpZmllZCBWb3RlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIENyeXB0b2dyYXBoaWMgQXVkaXQgRm9vdGVyICovfVxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiByb3VuZGVkLXhsIGJnLXNlY29uZGFyeS80MCBweC0zLjUgcHktMiB0ZXh0LVsxMXB4XSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNoaWVsZENoZWNrIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHRleHQtZW1lcmFsZC02MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBTZWN1cml0eSBTdGFuZGFyZDogPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LWZvcmVncm91bmRcIj57YmFsbG90LnZlcmlmaWNhdGlvblN0YW5kYXJkfTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAge3JlY2VpcHQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpbGVDaGVjazIgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlY2VpcHQ6IHtyZWNlaXB0Lmhhc2h9ICh7cmVjZWlwdC50aW1lc3RhbXB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4xLVBlcnNvbi0xLVZvdGUgQXVkaXRhYmxlIExlZGdlciBSZWFkeTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIEhvc3QgYSBOZXcgVW5pb24gLyBPZmZpY2UgLyBDZXJlbW9ueSBCYWxsb3QgKi99XG4gICAgICAgICAgICAgIDxmb3JtXG4gICAgICAgICAgICAgICAgb25TdWJtaXQ9e2hhbmRsZUNyZWF0ZUN1c3RvbUJhbGxvdH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWRhc2hlZCBib3JkZXItcHJpbWFyeS80MCBiZy1wcmltYXJ5LzUgcC01IHNwYWNlLXktNFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8Vm90ZSBjbGFzc05hbWU9XCJoLTUgdy01IHRleHQtcHJpbWFyeVwiIC8+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgSG9zdCBhbiBJbnN0aXR1dGlvbmFsIEJhbGxvdCAoVHJhZGUgVW5pb24sIE9mZmljZSBQb2xsLCBvciBBd2FyZHMgQ2VyZW1vbnkpXG4gICAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgICAgVGVzdCBsYXVuY2hpbmcgYSBsaXZlIHZlcmlmaWVkIGJhbGxvdCBjaGFtYmVyIHdpdGggaW5zdGFudCAxLVBlcnNvbi0xLVZvdGUgY3J5cHRvZ3JhcGhpYyByZWNlaXB0cy5cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTMgc206Z3JpZC1jb2xzLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld0JhbGxvdENhdGVnb3J5fVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld0JhbGxvdENhdGVnb3J5KGUudGFyZ2V0LnZhbHVlIGFzIEluc3RpdHV0aW9uYWxCYWxsb3RbXCJjYXRlZ29yeVwiXSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWJvcmRlciBiZy1iYWNrZ3JvdW5kIHB4LTMgdGV4dC14cyBmb250LXNlbWlib2xkIG91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUcmFkZSBVbmlvbiBCYWxsb3RcIj5UcmFkZSBVbmlvbiBCYWxsb3Q8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk5hdGlvbmFsIEF3YXJkcyBDZXJlbW9ueVwiPk5hdGlvbmFsIEF3YXJkcyBDZXJlbW9ueTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiT2ZmaWNlICYgQ29ycG9yYXRlIFBvbGxcIj5PZmZpY2UgJiBDb3Jwb3JhdGUgUG9sbDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ2l2aWMgJiBSZWd1bGF0b3J5IE1hbmRhdGVcIj5DaXZpYyAmIFJlZ3VsYXRvcnkgTWFuZGF0ZTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld0JhbGxvdE9yZ31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdCYWxsb3RPcmcoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk9yZ2FuaXphdGlvbiAvIFVuaW9uIC8gRGVwYXJ0bWVudCBOYW1lXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xMCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLWJhY2tncm91bmQgcHgtMyB0ZXh0LXhzIG91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdCYWxsb3RUaXRsZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdCYWxsb3RUaXRsZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUmVzb2x1dGlvbiAvIEJhbGxvdCBNb3Rpb24gVGl0bGVcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTEwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctYmFja2dyb3VuZCBweC0zIHRleHQteHMgb3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kXCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLXhsIGJnLXByaW1hcnkgcHgtNCBweS0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtcHJpbWFyeS1mb3JlZ3JvdW5kIGhvdmVyOm9wYWNpdHktOTAgdHJhbnNpdGlvblwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIE9wZW4gVmVyaWZpZWQgQmFsbG90IENoYW1iZXJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIFN0YW5kYXJkIEV4cGxhaW5lciBGb290ZXIgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc3Rhc2gvMjAgYmctc3Rhc2gvNSBwLTVcIj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC1sZyBmb250LWJvbGRcIj5PdXIgRmFpcm5lc3MgYW5kIEFjY3VyYWN5IFN0YW5kYXJkPC9oMz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBncmlkIGdhcC0zIHRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIG1kOmdyaWQtY29scy0yXCI+XG4gICAgICAgICAgICAgIDxwPlxuICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1mb3JlZ3JvdW5kXCI+Q2F0ZWdvcnkgU2VwYXJhdGlvbi48L3N0cm9uZz4gRm9vZCBwcm9kdWN0cyBhbmQgc3VwZXJtYXJrZXRzIG5ldmVyIGNvbXBldGUgYWdhaW5zdCBhdXRvbW90aXZlIGJyYW5kcyBvciB0ZWNoIGdpYW50cy4gRXZlcnkgaW5kdXN0cnkgaGFzIGRlZGljYXRlZCByZWNvZ25pdGlvbi5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtZm9yZWdyb3VuZFwiPlRpZXJlZCBDb21wZXRpdGlvbi48L3N0cm9uZz4gQnJhbmRzIGFyZSBjbGFzc2lmaWVkIGFjcm9zcyBkZWZpbmVkIG1hcmtldCB0aWVycyAoTHV4dXJ5LCBQcmVtaXVtLCBNYXNzIE1hcmtldCwgQnVkZ2V0KS4gTHV4dXJ5IG1haXNvbnMgYW5kIHRlY2ggdGl0YW5zIG5ldmVyIGNyb3dkIG91dCBtYXNzLW1hcmtldCBlc3NlbnRpYWxzIG9yIGJ1ZGdldCBjaGFtcGlvbnMuXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LWZvcmVncm91bmRcIj5Vbml2ZXJzYWwgRGlzY292ZXJhYmlsaXR5Ljwvc3Ryb25nPiBFdmVyeSBjb3VudHJ5IGlzIGRpc2NvdmVyYWJsZSwgYW5kIGxvY2FsIGluZGVwZW5kZW50IGJyYW5kcyBjb21wZXRlIG9uIGEgbGV2ZWwgcGxheWluZyBmaWVsZCB3aXRoaW4gdGhlaXIgb3duIHNjb3BlLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDxwPlxuICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1mb3JlZ3JvdW5kXCI+RXZpZGVuY2UgQmVmb3JlIEF1dGhvcml0eS48L3N0cm9uZz4gUmFua2luZ3MgYXJlIGFuIGhvbmVzdCBjb21tdW5pdHkgc2lnbmFsIHBvd2VyZWQgYnkgZGlyZWN0IHVzZXIgdmVyZGljdHMsIHRpbWVzdGFtcGVkIGFuZCB0cmFuc3BhcmVudGx5IGF1ZGl0YWJsZS5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICB7LyogQ2VyZW1vbnkgUHJvY2VzcyAqL31cbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibXQtMTAgcm91bmRlZC0zeGwgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctY2FyZCBwLTYgc2hhZG93LXNtXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XG4gICAgICAgICAgICA8Q2FsZW5kYXJDbG9jayBjbGFzc05hbWU9XCJtdC0xIGgtNiB3LTYgc2hyaW5rLTAgdGV4dC1wcmltYXJ5XCIgLz5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC14bCBmb250LWJvbGRcIj5UaGUgUm9hZCB0byB0aGUgTGl2ZSBDZXJlbW9ueTwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5BIHRyYW5zcGFyZW50IHByb2Nlc3MgYnVpbHQgZnJvbSByZWFsLXRpbWUgY29tbXVuaXR5IHZlcmRpY3RzLjwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBncmlkIGdhcC0zIG1kOmdyaWQtY29scy00XCI+XG4gICAgICAgICAgICB7W1wiTm9taW5lZXMgb3BlblwiLCBcIlB1YmxpYyB2b3RpbmdcIiwgXCJTbmFwc2hvdCBsb2NrZWRcIiwgXCJMaXZlIGNlcmVtb255XCJdLm1hcCgoc3RhZ2UsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgIDxkaXYga2V5PXtzdGFnZX0gY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ib3JkZXIgcC00XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2NuKFwiZmxleCBoLTcgdy03IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LWJvbGRcIiwgaW5kZXggPT09IDAgPyBcImJnLXN0YXNoIHRleHQtc3Rhc2gtZm9yZWdyb3VuZFwiIDogXCJiZy1zZWNvbmRhcnkgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIpfT57aW5kZXggKyAxfTwvZGl2PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgZm9udC1kaXNwbGF5IHRleHQtc20gZm9udC1ib2xkXCI+e3N0YWdlfTwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgbGVhZGluZy1yZWxheGVkIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntpbmRleCA9PT0gMCA/IFwiTGl2ZSBub3cgYWNyb3NzIGVhY2ggbWFya2V0IGFuZCBjYXRlZ29yeS5cIiA6IGluZGV4ID09PSAxID8gXCJDb21tdW5pdHkgdmVyZGljdHMgd2lsbCBkZWNpZGUgdGhlIHNob3J0bGlzdC5cIiA6IGluZGV4ID09PSAyID8gXCJTY29yZXMgZnJlZXplIHdpdGggYW4gYXVkaXRhYmxlIHRpbWVzdGFtcC5cIiA6IFwiV2lubmVycyBhcmUgY2VsZWJyYXRlZCBpbiB0aGUgcmVhbCB3b3JsZC5cIn08L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICB7LyogQXdhcmRzIGNhdGVnb3JpZXMgKi99XG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cIm10LTEwXCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LTJ4bCBmb250LWJvbGRcIj57dChcImF3YXJkcy5jYXRlZ29yeVRpdGxlXCIpIHx8IFwiT2ZmaWNpYWwgQXdhcmQgQ2F0ZWdvcmllc1wifTwvaDI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IGdyaWQgZ2FwLTQgc206Z3JpZC1jb2xzLTJcIj5cbiAgICAgICAgICAgIHthd2FyZFR5cGVzLm1hcCgoYykgPT4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17Yy50aXRsZX0gY2xhc3NOYW1lPVwicm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ib3JkZXIgYmctY2FyZCBwLTVcIj5cbiAgICAgICAgICAgICAgICA8Yy5pY29uIGNsYXNzTmFtZT1cImgtNyB3LTcgdGV4dC1wcmltYXJ5XCIgLz5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibXQtMyBmb250LWRpc3BsYXkgdGV4dC1sZyBmb250LWJvbGRcIj57Yy50aXRsZX08L2gzPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57Yy5kZXNjfTwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICAgIHsvKiBDVEEgKi99XG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cIm10LTEwIHJvdW5kZWQtM3hsIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLWNhcmQgcC04IHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPEF3YXJkIGNsYXNzTmFtZT1cIm14LWF1dG8gaC0xMCB3LTEwIHRleHQtcHJpbWFyeVwiIC8+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm10LTMgZm9udC1kaXNwbGF5IHRleHQtMnhsIGZvbnQtYm9sZFwiPnt0KFwiYXdhcmRzLmN0YVwiKSB8fCBcIk1ha2UgWW91ciBWZXJkaWN0IENvdW50XCJ9PC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJteC1hdXRvIG10LTIgbWF4LXctbWQgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e3QoXCJhd2FyZHMuY3RhTm90ZVwiKSB8fCBcIkV2ZXJ5IHZvdGUgaW5mbHVlbmNlcyB0aGUgYW5udWFsIHN0YW5kaW5ncy5cIn08L3A+XG4gICAgICAgICAgPExpbmtcbiAgICAgICAgICAgIHRvPVwiL2JyYW5kc1wiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJtdC01IGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgYmctcHJpbWFyeSBweC02IHB5LTIuNSBmb250LXNlbWlib2xkIHRleHQtcHJpbWFyeS1mb3JlZ3JvdW5kIHRyYW5zaXRpb24tb3BhY2l0eSBob3ZlcjpvcGFjaXR5LTkwXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICB7dChcIm5hdi5icmFuZHNcIikgfHwgXCJFeHBsb3JlIEJyYW5kIERpcmVjdG9yeVwifVxuICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgPC9tYWluPlxuXG4gICAgICA8TGl2ZUJyb2FkY2FzdE1vZGFsXG4gICAgICAgIG9wZW49e2xpdmVPYnNlcnZlck1vZGFsT3Blbn1cbiAgICAgICAgb25PcGVuQ2hhbmdlPXtzZXRMaXZlT2JzZXJ2ZXJNb2RhbE9wZW59XG4gICAgICAgIGJyYW5kTmFtZT17YWN0aXZlT2JzZXJ2ZXJUb3BpY31cbiAgICAgIC8+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9hcHAvYXBwbGV0L3NyYy9yb3V0ZXMvYXdhcmRzLnRzeCJ9