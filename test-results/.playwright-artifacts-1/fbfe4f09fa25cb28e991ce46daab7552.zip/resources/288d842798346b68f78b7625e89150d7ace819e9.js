//#region src/index.ts
var stateIndexKey = "__TSR_index";
var popStateEvent = "popstate";
var beforeUnloadEvent = "beforeunload";
/**
* Turn protocol-relative inputs such as "//evil.example" into paths
* such as "/evil.example", keeping navigation on the current origin.
*
* For HTTP(S) URLs, WHATWG parsing ignores leading C0 controls and spaces,
* removes tabs/newlines, and treats backslashes as slashes, so inputs like
* "/\evil.example" also need normalization. This only allocates when those
* rules would make the input protocol-relative.
*/
var protocolRelativePrefix = /^[\x00-\x20]*(?:[\\/][\t\n\r]*){2,}/;
function normalizeProtocolRelative(url) {
	const match = protocolRelativePrefix.exec(url);
	return match ? "/" + url.slice(match[0].length) : url;
}
function normalizeHref(href) {
	if (/[\x00-\x1f\x7f]/.test(href)) href = href.replace(/[\x00-\x1f\x7f]/g, (character) => "	\n\r".includes(character) ? "" : encodeURIComponent(character));
	return normalizeProtocolRelative(href);
}
function createHistory(opts) {
	let location = opts.getLocation();
	const subscribers = /* @__PURE__ */ new Set();
	const notify = (action) => {
		location = opts.getLocation();
		subscribers.forEach((subscriber) => subscriber({
			location,
			action
		}));
	};
	const handleIndexChange = (action) => {
		if (opts.notifyOnIndexChange ?? true) notify(action);
		else location = opts.getLocation();
	};
	const tryNavigation = async ({ task, navigateOpts, ...actionInfo }) => {
		if (navigateOpts?.ignoreBlocker ?? false) {
			task();
			return;
		}
		const blockers = opts.getBlockers?.() ?? [];
		const isPushOrReplace = actionInfo.type === "PUSH" || actionInfo.type === "REPLACE";
		if (typeof document !== "undefined" && blockers.length && isPushOrReplace) for (const blocker of blockers) {
			const nextLocation = parseHref(actionInfo.path, actionInfo.state);
			if (await blocker.blockerFn({
				currentLocation: location,
				nextLocation,
				action: actionInfo.type
			})) {
				opts.onBlocked?.();
				return;
			}
		}
		task();
	};
	return {
		get location() {
			return location;
		},
		get length() {
			return opts.getLength();
		},
		subscribers,
		subscribe: (cb) => {
			subscribers.add(cb);
			return () => {
				subscribers.delete(cb);
			};
		},
		push: (path, state, navigateOpts) => {
			const currentIndex = location.state[stateIndexKey];
			state = assignKeyAndIndex(currentIndex + 1, state);
			tryNavigation({
				task: () => {
					opts.pushState(path, state);
					notify({ type: "PUSH" });
				},
				navigateOpts,
				type: "PUSH",
				path,
				state
			});
		},
		replace: (path, state, navigateOpts) => {
			const currentIndex = location.state[stateIndexKey];
			state = assignKeyAndIndex(currentIndex, state);
			tryNavigation({
				task: () => {
					opts.replaceState(path, state);
					notify({ type: "REPLACE" });
				},
				navigateOpts,
				type: "REPLACE",
				path,
				state
			});
		},
		go: (index, navigateOpts) => {
			tryNavigation({
				task: () => {
					opts.go(index, navigateOpts?.ignoreBlocker ?? false);
					handleIndexChange({
						type: "GO",
						index
					});
				},
				navigateOpts,
				type: "GO"
			});
		},
		back: (navigateOpts) => {
			tryNavigation({
				task: () => {
					opts.back(navigateOpts?.ignoreBlocker ?? false);
					handleIndexChange({ type: "BACK" });
				},
				navigateOpts,
				type: "BACK"
			});
		},
		forward: (navigateOpts) => {
			tryNavigation({
				task: () => {
					opts.forward(navigateOpts?.ignoreBlocker ?? false);
					handleIndexChange({ type: "FORWARD" });
				},
				navigateOpts,
				type: "FORWARD"
			});
		},
		canGoBack: () => location.state[stateIndexKey] !== 0,
		createHref: (str) => opts.createHref(str),
		block: (blocker) => {
			if (!opts.setBlockers) return () => {};
			const blockers = opts.getBlockers?.() ?? [];
			opts.setBlockers([...blockers, blocker]);
			return () => {
				const blockers = opts.getBlockers?.() ?? [];
				opts.setBlockers?.(blockers.filter((b) => b !== blocker));
			};
		},
		flush: () => opts.flush?.(),
		destroy: () => opts.destroy?.(),
		notify,
		_getBlockers: () => opts.getBlockers?.() ?? []
	};
}
function assignKeyAndIndex(index, state) {
	const key = createRandomKey();
	return {
		...state,
		key,
		__TSR_key: key,
		[stateIndexKey]: index
	};
}
/**
* Creates a history object that can be used to interact with the browser's
* navigation. This is a lightweight API wrapping the browser's native methods.
* It is designed to work with TanStack Router, but could be used as a standalone API as well.
* IMPORTANT: This API implements history throttling via a microtask to prevent
* excessive calls to the history API. In some browsers, calling history.pushState or
* history.replaceState in quick succession can cause the browser to ignore subsequent
* calls. This API smooths out those differences and ensures that your application
* state will *eventually* match the browser state. In most cases, this is not a problem,
* but if you need to ensure that the browser state is up to date, you can use the
* `history.flush` method to immediately flush all pending state changes to the browser URL.
* @param opts
* @param opts.getHref A function that returns the current href (path + search + hash)
* @param opts.createHref A function that takes a path and returns a href (path + search + hash)
* @returns A history instance
*/
function createBrowserHistory(opts) {
	const win = opts?.window ?? (typeof document !== "undefined" ? window : void 0);
	const originalPushState = win.history.pushState;
	const originalReplaceState = win.history.replaceState;
	let blockers = [];
	const _getBlockers = () => blockers;
	const _setBlockers = (newBlockers) => blockers = newBlockers;
	const createHref = (path) => normalizeHref(opts?.createHref ? opts.createHref(path) : path);
	const parseLocation = opts?.parseLocation ?? (() => parseHref(`${win.location.pathname}${win.location.search}${win.location.hash}`, win.history.state));
	if (!win.history.state?.__TSR_key && !win.history.state?.key) {
		const addedKey = createRandomKey();
		win.history.replaceState({
			[stateIndexKey]: 0,
			key: addedKey,
			__TSR_key: addedKey
		}, "");
	}
	let currentLocation = parseLocation();
	let rollbackLocation;
	let nextPopIsGo = false;
	let ignoreNextPop = false;
	let skipBlockerNextPop = false;
	let ignoreNextBeforeUnload = false;
	const getLocation = () => currentLocation;
	let next;
	const flush = () => {
		if (!next) return;
		history._ignoreSubscribers = true;
		(next[2] ? win.history.pushState : win.history.replaceState)(next[1], "", next[0]);
		history._ignoreSubscribers = false;
		next = void 0;
		rollbackLocation = void 0;
	};
	const queueHistoryAction = (isPush, destHref, state) => {
		const href = opts?.createHref ? createHref(destHref) : void 0;
		const hasPendingAction = !!next;
		if (!hasPendingAction) rollbackLocation = currentLocation;
		currentLocation = parseHref(destHref, state);
		next = [
			href ?? currentLocation.href,
			state,
			next?.[2] || isPush
		];
		if (!hasPendingAction) queueMicrotask(() => flush());
	};
	const onPushPop = (type) => {
		currentLocation = parseLocation();
		history.notify({ type });
	};
	const onPushPopEvent = async () => {
		ignoreNextBeforeUnload = false;
		if (ignoreNextPop) {
			ignoreNextPop = false;
			return;
		}
		const nextLocation = parseLocation();
		const delta = nextLocation.state[stateIndexKey] - currentLocation.state[stateIndexKey];
		const isForward = delta === 1;
		const isBack = delta === -1;
		const isGo = !isForward && !isBack || nextPopIsGo;
		nextPopIsGo = false;
		const action = isGo ? "GO" : isBack ? "BACK" : "FORWARD";
		const notify = isGo ? {
			type: "GO",
			index: delta
		} : { type: isBack ? "BACK" : "FORWARD" };
		if (skipBlockerNextPop) skipBlockerNextPop = false;
		else {
			const blockers = _getBlockers();
			if (typeof document !== "undefined" && blockers.length) {
				for (const blocker of blockers) if (await blocker.blockerFn({
					currentLocation,
					nextLocation,
					action
				})) {
					ignoreNextPop = true;
					win.history.go(-delta);
					history.notify(notify);
					return;
				}
			}
		}
		currentLocation = parseLocation();
		history.notify(notify);
	};
	const onBeforeUnload = (e) => {
		if (ignoreNextBeforeUnload) {
			ignoreNextBeforeUnload = false;
			return;
		}
		let shouldBlock = false;
		const blockers = _getBlockers();
		if (typeof document !== "undefined" && blockers.length) for (const blocker of blockers) {
			const shouldHaveBeforeUnload = blocker.enableBeforeUnload ?? true;
			if (shouldHaveBeforeUnload === true) {
				shouldBlock = true;
				break;
			}
			if (typeof shouldHaveBeforeUnload === "function" && shouldHaveBeforeUnload() === true) {
				shouldBlock = true;
				break;
			}
		}
		if (shouldBlock) {
			e.preventDefault();
			return e.returnValue = "";
		}
	};
	const history = createHistory({
		getLocation,
		getLength: () => win.history.length,
		pushState: (href, state) => queueHistoryAction(true, href, state),
		replaceState: (href, state) => queueHistoryAction(false, href, state),
		back: (ignoreBlocker) => {
			if (ignoreBlocker) {
				skipBlockerNextPop = true;
				ignoreNextBeforeUnload = true;
			}
			return win.history.back();
		},
		forward: (ignoreBlocker) => {
			if (ignoreBlocker) {
				skipBlockerNextPop = true;
				ignoreNextBeforeUnload = true;
			}
			win.history.forward();
		},
		go: (n, ignoreBlocker) => {
			nextPopIsGo = true;
			if (ignoreBlocker) {
				skipBlockerNextPop = true;
				ignoreNextBeforeUnload = true;
			}
			win.history.go(n);
		},
		createHref: (href) => createHref(href),
		flush,
		destroy: () => {
			win.history.pushState = originalPushState;
			win.history.replaceState = originalReplaceState;
			win.removeEventListener(beforeUnloadEvent, onBeforeUnload, { capture: true });
			win.removeEventListener(popStateEvent, onPushPopEvent);
		},
		onBlocked: () => {
			if (rollbackLocation && currentLocation !== rollbackLocation) currentLocation = rollbackLocation;
		},
		getBlockers: _getBlockers,
		setBlockers: _setBlockers,
		notifyOnIndexChange: false
	});
	history._ignoreNextBeforeUnload = (href) => {
		ignoreNextBeforeUnload = false;
		try {
			href = new URL(href, win.document.baseURI).href;
			ignoreNextBeforeUnload = /^https?:/.test(href) && (!href.includes("#") || href.split("#")[0] !== win.location.href.split("#")[0]);
		} catch {}
	};
	win.addEventListener(beforeUnloadEvent, onBeforeUnload, { capture: true });
	win.addEventListener(popStateEvent, onPushPopEvent);
	win.history.pushState = function(...args) {
		const res = originalPushState.apply(win.history, args);
		if (!history._ignoreSubscribers) onPushPop("PUSH");
		return res;
	};
	win.history.replaceState = function(...args) {
		const res = originalReplaceState.apply(win.history, args);
		if (!history._ignoreSubscribers) onPushPop("REPLACE");
		return res;
	};
	return history;
}
/**
* Create a hash-based history implementation.
* Useful for static hosts or environments without server URL rewriting.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/history-types
*/
function createHashHistory(opts) {
	const win = opts?.window ?? (typeof document !== "undefined" ? window : void 0);
	return createBrowserHistory({
		window: win,
		parseLocation: () => {
			const hashSplit = win.location.hash.split("#").slice(1);
			const pathPart = hashSplit[0] ?? "/";
			const searchPart = win.location.search;
			const hashEntries = hashSplit.slice(1);
			return parseHref(`${pathPart}${searchPart}${hashEntries.length === 0 ? "" : `#${hashEntries.join("#")}`}`, win.history.state);
		},
		createHref: (href) => `${win.location.pathname}${win.location.search}#${href}`
	});
}
/**
* Create an in-memory history implementation.
* Ideal for server rendering, tests, and non-DOM environments.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/history-types
*/
function createMemoryHistory(opts = { initialEntries: ["/"] }) {
	const entries = opts.initialEntries;
	let index = opts.initialIndex ? Math.min(Math.max(opts.initialIndex, 0), entries.length - 1) : entries.length - 1;
	const states = entries.map((_entry, index) => assignKeyAndIndex(index, void 0));
	const getLocation = () => parseHref(entries[index], states[index]);
	let blockers = [];
	const _getBlockers = () => blockers;
	const _setBlockers = (newBlockers) => blockers = newBlockers;
	return createHistory({
		getLocation,
		getLength: () => entries.length,
		pushState: (path, state) => {
			index = index < entries.length - 1 ? index + 1 : entries.length;
			states[index] = state;
			entries[index] = path;
			if (index < entries.length - 1) {
				entries.length = index + 1;
				states.length = index + 1;
			}
		},
		replaceState: (path, state) => {
			states[index] = state;
			entries[index] = path;
		},
		back: () => {
			index = Math.max(index - 1, 0);
		},
		forward: () => {
			index = Math.min(index + 1, entries.length - 1);
		},
		go: (n) => {
			index = Math.min(Math.max(index + n, 0), entries.length - 1);
		},
		createHref: normalizeHref,
		getBlockers: _getBlockers,
		setBlockers: _setBlockers
	});
}
var noop = () => {};
var ServerHistory = class {
	constructor(location) {
		this.location = location;
	}
	get length() {
		return 1;
	}
	get subscribers() {
		return this._subscribers ??= /* @__PURE__ */ new Set();
	}
	subscribe() {
		return noop;
	}
	push() {}
	replace() {}
	go() {}
	back() {}
	forward() {}
	canGoBack() {
		return false;
	}
	createHref(href) {
		return normalizeHref(href);
	}
	block() {
		return noop;
	}
	flush() {}
	destroy() {}
	notify() {}
	_getBlockers() {
		return [];
	}
};
/** A fixed request location; server navigation is a no-op. */
function createServerHistory(href) {
	return new ServerHistory(parseHref(href, void 0));
}
function parseHref(href, state) {
	const sanitizedHref = normalizeHref(href);
	const hashIndex = sanitizedHref.indexOf("#");
	const searchIndex = sanitizedHref.indexOf("?");
	if (!state) {
		const key = createRandomKey();
		state = {
			[stateIndexKey]: 0,
			key,
			__TSR_key: key
		};
	}
	return {
		href: sanitizedHref,
		pathname: sanitizedHref.substring(0, hashIndex > 0 ? searchIndex > 0 ? Math.min(hashIndex, searchIndex) : hashIndex : searchIndex > 0 ? searchIndex : sanitizedHref.length),
		hash: hashIndex > -1 ? sanitizedHref.substring(hashIndex) : "",
		search: searchIndex > -1 ? sanitizedHref.slice(searchIndex, hashIndex === -1 ? void 0 : hashIndex) : "",
		state
	};
}
function createRandomKey() {
	return (Math.random() + 1).toString(36).substring(7);
}
//#endregion
export { createBrowserHistory, createHashHistory, createHistory, createMemoryHistory, createServerHistory, normalizeProtocolRelative, parseHref };

                                 
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vc3JjL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFdoaWxlIHRoZSBwdWJsaWMgQVBJIHdhcyBjbGVhcmx5IGluc3BpcmVkIGJ5IHRoZSBcImhpc3RvcnlcIiBucG0gcGFja2FnZSxcbi8vIFRoaXMgaW1wbGVtZW50YXRpb24gYXR0ZW1wdHMgdG8gYmUgbW9yZSBsaWdodHdlaWdodCBieVxuLy8gbWFraW5nIGFzc3VtcHRpb25zIGFib3V0IHRoZSB3YXkgVGFuU3RhY2sgUm91dGVyIHdvcmtzXG5cbmV4cG9ydCBpbnRlcmZhY2UgTmF2aWdhdGVPcHRpb25zIHtcbiAgaWdub3JlQmxvY2tlcj86IGJvb2xlYW5cbn1cblxudHlwZSBTdWJzY3JpYmVySGlzdG9yeUFjdGlvbiA9XG4gIHwge1xuICAgICAgdHlwZTogRXhjbHVkZTxIaXN0b3J5QWN0aW9uLCAnR08nPlxuICAgIH1cbiAgfCB7XG4gICAgICB0eXBlOiAnR08nXG4gICAgICBpbmRleDogbnVtYmVyXG4gICAgfVxuXG50eXBlIFN1YnNjcmliZXJBcmdzID0ge1xuICBsb2NhdGlvbjogSGlzdG9yeUxvY2F0aW9uXG4gIGFjdGlvbjogU3Vic2NyaWJlckhpc3RvcnlBY3Rpb25cbn1cblxuZXhwb3J0IGludGVyZmFjZSBSb3V0ZXJIaXN0b3J5IHtcbiAgbG9jYXRpb246IEhpc3RvcnlMb2NhdGlvblxuICBsZW5ndGg6IG51bWJlclxuICBzdWJzY3JpYmVyczogU2V0PChvcHRzOiBTdWJzY3JpYmVyQXJncykgPT4gdm9pZD5cbiAgc3Vic2NyaWJlOiAoY2I6IChvcHRzOiBTdWJzY3JpYmVyQXJncykgPT4gdm9pZCkgPT4gKCkgPT4gdm9pZFxuICBwdXNoOiAocGF0aDogc3RyaW5nLCBzdGF0ZT86IGFueSwgbmF2aWdhdGVPcHRzPzogTmF2aWdhdGVPcHRpb25zKSA9PiB2b2lkXG4gIHJlcGxhY2U6IChwYXRoOiBzdHJpbmcsIHN0YXRlPzogYW55LCBuYXZpZ2F0ZU9wdHM/OiBOYXZpZ2F0ZU9wdGlvbnMpID0+IHZvaWRcbiAgZ286IChpbmRleDogbnVtYmVyLCBuYXZpZ2F0ZU9wdHM/OiBOYXZpZ2F0ZU9wdGlvbnMpID0+IHZvaWRcbiAgYmFjazogKG5hdmlnYXRlT3B0cz86IE5hdmlnYXRlT3B0aW9ucykgPT4gdm9pZFxuICBmb3J3YXJkOiAobmF2aWdhdGVPcHRzPzogTmF2aWdhdGVPcHRpb25zKSA9PiB2b2lkXG4gIGNhbkdvQmFjazogKCkgPT4gYm9vbGVhblxuICBjcmVhdGVIcmVmOiAoaHJlZjogc3RyaW5nKSA9PiBzdHJpbmdcbiAgYmxvY2s6IChibG9ja2VyOiBOYXZpZ2F0aW9uQmxvY2tlcikgPT4gKCkgPT4gdm9pZFxuICBmbHVzaDogKCkgPT4gdm9pZFxuICBkZXN0cm95OiAoKSA9PiB2b2lkXG4gIG5vdGlmeTogKGFjdGlvbjogU3Vic2NyaWJlckhpc3RvcnlBY3Rpb24pID0+IHZvaWRcbiAgX2dldEJsb2NrZXJzOiAoKSA9PiBBcnJheTxOYXZpZ2F0aW9uQmxvY2tlcj5cbiAgX2lnbm9yZVN1YnNjcmliZXJzPzogYm9vbGVhblxuICBfaWdub3JlTmV4dEJlZm9yZVVubG9hZD86IChocmVmOiBzdHJpbmcpID0+IHZvaWRcbn1cblxuZXhwb3J0IGludGVyZmFjZSBIaXN0b3J5TG9jYXRpb24gZXh0ZW5kcyBQYXJzZWRQYXRoIHtcbiAgc3RhdGU6IFBhcnNlZEhpc3RvcnlTdGF0ZVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIFBhcnNlZFBhdGgge1xuICBocmVmOiBzdHJpbmdcbiAgcGF0aG5hbWU6IHN0cmluZ1xuICBzZWFyY2g6IHN0cmluZ1xuICBoYXNoOiBzdHJpbmdcbn1cblxuZXhwb3J0IGludGVyZmFjZSBIaXN0b3J5U3RhdGUge31cblxuZXhwb3J0IHR5cGUgUGFyc2VkSGlzdG9yeVN0YXRlID0gSGlzdG9yeVN0YXRlICYge1xuICBrZXk/OiBzdHJpbmcgLy8gVE9ETzogUmVtb3ZlIGluIHYyIC0gdXNlIF9fVFNSX2tleSBpbnN0ZWFkXG4gIF9fVFNSX2tleT86IHN0cmluZ1xuICBfX1RTUl9pbmRleDogbnVtYmVyXG59XG5cbnR5cGUgU2hvdWxkQWxsb3dOYXZpZ2F0aW9uID0gYW55XG5cbmV4cG9ydCB0eXBlIEhpc3RvcnlBY3Rpb24gPSAnUFVTSCcgfCAnUkVQTEFDRScgfCAnRk9SV0FSRCcgfCAnQkFDSycgfCAnR08nXG5cbmV4cG9ydCB0eXBlIEJsb2NrZXJGbkFyZ3MgPSB7XG4gIGN1cnJlbnRMb2NhdGlvbjogSGlzdG9yeUxvY2F0aW9uXG4gIG5leHRMb2NhdGlvbjogSGlzdG9yeUxvY2F0aW9uXG4gIGFjdGlvbjogSGlzdG9yeUFjdGlvblxufVxuXG5leHBvcnQgdHlwZSBCbG9ja2VyRm4gPSAoXG4gIGFyZ3M6IEJsb2NrZXJGbkFyZ3MsXG4pID0+IFByb21pc2U8U2hvdWxkQWxsb3dOYXZpZ2F0aW9uPiB8IFNob3VsZEFsbG93TmF2aWdhdGlvblxuXG5leHBvcnQgdHlwZSBOYXZpZ2F0aW9uQmxvY2tlciA9IHtcbiAgYmxvY2tlckZuOiBCbG9ja2VyRm5cbiAgZW5hYmxlQmVmb3JlVW5sb2FkPzogKCgpID0+IGJvb2xlYW4pIHwgYm9vbGVhblxufVxuXG50eXBlIFRyeU5hdmlnYXRlQXJncyA9IHtcbiAgdGFzazogKCkgPT4gdm9pZFxuICB0eXBlOiAnUFVTSCcgfCAnUkVQTEFDRScgfCAnQkFDSycgfCAnRk9SV0FSRCcgfCAnR08nXG4gIG5hdmlnYXRlT3B0cz86IE5hdmlnYXRlT3B0aW9uc1xufSAmIChcbiAgfCB7XG4gICAgICB0eXBlOiAnUFVTSCcgfCAnUkVQTEFDRSdcbiAgICAgIHBhdGg6IHN0cmluZ1xuICAgICAgc3RhdGU6IGFueVxuICAgIH1cbiAgfCB7XG4gICAgICB0eXBlOiAnQkFDSycgfCAnRk9SV0FSRCcgfCAnR08nXG4gICAgfVxuKVxuXG5jb25zdCBzdGF0ZUluZGV4S2V5ID0gJ19fVFNSX2luZGV4J1xuY29uc3QgcG9wU3RhdGVFdmVudCA9ICdwb3BzdGF0ZSdcbmNvbnN0IGJlZm9yZVVubG9hZEV2ZW50ID0gJ2JlZm9yZXVubG9hZCdcblxuLyoqXG4gKiBUdXJuIHByb3RvY29sLXJlbGF0aXZlIGlucHV0cyBzdWNoIGFzIFwiLy9ldmlsLmV4YW1wbGVcIiBpbnRvIHBhdGhzXG4gKiBzdWNoIGFzIFwiL2V2aWwuZXhhbXBsZVwiLCBrZWVwaW5nIG5hdmlnYXRpb24gb24gdGhlIGN1cnJlbnQgb3JpZ2luLlxuICpcbiAqIEZvciBIVFRQKFMpIFVSTHMsIFdIQVRXRyBwYXJzaW5nIGlnbm9yZXMgbGVhZGluZyBDMCBjb250cm9scyBhbmQgc3BhY2VzLFxuICogcmVtb3ZlcyB0YWJzL25ld2xpbmVzLCBhbmQgdHJlYXRzIGJhY2tzbGFzaGVzIGFzIHNsYXNoZXMsIHNvIGlucHV0cyBsaWtlXG4gKiBcIi9cXGV2aWwuZXhhbXBsZVwiIGFsc28gbmVlZCBub3JtYWxpemF0aW9uLiBUaGlzIG9ubHkgYWxsb2NhdGVzIHdoZW4gdGhvc2VcbiAqIHJ1bGVzIHdvdWxkIG1ha2UgdGhlIGlucHV0IHByb3RvY29sLXJlbGF0aXZlLlxuICovXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tY29udHJvbC1yZWdleFxuY29uc3QgcHJvdG9jb2xSZWxhdGl2ZVByZWZpeCA9IC9eW1xceDAwLVxceDIwXSooPzpbXFxcXC9dW1xcdFxcblxccl0qKXsyLH0vXG5cbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemVQcm90b2NvbFJlbGF0aXZlKHVybDogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgbWF0Y2ggPSBwcm90b2NvbFJlbGF0aXZlUHJlZml4LmV4ZWModXJsKVxuICByZXR1cm4gbWF0Y2ggPyAnLycgKyB1cmwuc2xpY2UobWF0Y2hbMF0ubGVuZ3RoKSA6IHVybFxufVxuXG5mdW5jdGlvbiBub3JtYWxpemVIcmVmKGhyZWY6IHN0cmluZyk6IHN0cmluZyB7XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1jb250cm9sLXJlZ2V4XG4gIGlmICgvW1xceDAwLVxceDFmXFx4N2ZdLy50ZXN0KGhyZWYpKSB7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnRyb2wtcmVnZXhcbiAgICBocmVmID0gaHJlZi5yZXBsYWNlKC9bXFx4MDAtXFx4MWZcXHg3Zl0vZywgKGNoYXJhY3RlcikgPT5cbiAgICAgICdcXHRcXG5cXHInLmluY2x1ZGVzKGNoYXJhY3RlcikgPyAnJyA6IGVuY29kZVVSSUNvbXBvbmVudChjaGFyYWN0ZXIpLFxuICAgIClcbiAgfVxuICByZXR1cm4gbm9ybWFsaXplUHJvdG9jb2xSZWxhdGl2ZShocmVmKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlSGlzdG9yeShvcHRzOiB7XG4gIGdldExvY2F0aW9uOiAoKSA9PiBIaXN0b3J5TG9jYXRpb25cbiAgZ2V0TGVuZ3RoOiAoKSA9PiBudW1iZXJcbiAgcHVzaFN0YXRlOiAocGF0aDogc3RyaW5nLCBzdGF0ZTogYW55KSA9PiB2b2lkXG4gIHJlcGxhY2VTdGF0ZTogKHBhdGg6IHN0cmluZywgc3RhdGU6IGFueSkgPT4gdm9pZFxuICBnbzogKG46IG51bWJlciwgaWdub3JlQmxvY2tlcjogYm9vbGVhbikgPT4gdm9pZFxuICBiYWNrOiAoaWdub3JlQmxvY2tlcjogYm9vbGVhbikgPT4gdm9pZFxuICBmb3J3YXJkOiAoaWdub3JlQmxvY2tlcjogYm9vbGVhbikgPT4gdm9pZFxuICBjcmVhdGVIcmVmOiAocGF0aDogc3RyaW5nKSA9PiBzdHJpbmdcbiAgZmx1c2g/OiAoKSA9PiB2b2lkXG4gIGRlc3Ryb3k/OiAoKSA9PiB2b2lkXG4gIG9uQmxvY2tlZD86ICgpID0+IHZvaWRcbiAgZ2V0QmxvY2tlcnM/OiAoKSA9PiBBcnJheTxOYXZpZ2F0aW9uQmxvY2tlcj5cbiAgc2V0QmxvY2tlcnM/OiAoYmxvY2tlcnM6IEFycmF5PE5hdmlnYXRpb25CbG9ja2VyPikgPT4gdm9pZFxuICAvLyBBdm9pZCBub3RpZnlpbmcgb24gZm9yd2FyZC9iYWNrL2dvLCB1c2VkIGZvciBicm93c2VyIGhpc3RvcnkgYXMgd2UgYWxyZWFkeSBnZXQgbm90aWZpZWQgYnkgdGhlIHBvcHN0YXRlIGV2ZW50XG4gIG5vdGlmeU9uSW5kZXhDaGFuZ2U/OiBib29sZWFuXG59KTogUm91dGVySGlzdG9yeSB7XG4gIGxldCBsb2NhdGlvbiA9IG9wdHMuZ2V0TG9jYXRpb24oKVxuICBjb25zdCBzdWJzY3JpYmVycyA9IG5ldyBTZXQ8KG9wdHM6IFN1YnNjcmliZXJBcmdzKSA9PiB2b2lkPigpXG5cbiAgY29uc3Qgbm90aWZ5ID0gKGFjdGlvbjogU3Vic2NyaWJlckhpc3RvcnlBY3Rpb24pID0+IHtcbiAgICBsb2NhdGlvbiA9IG9wdHMuZ2V0TG9jYXRpb24oKVxuICAgIHN1YnNjcmliZXJzLmZvckVhY2goKHN1YnNjcmliZXIpID0+IHN1YnNjcmliZXIoeyBsb2NhdGlvbiwgYWN0aW9uIH0pKVxuICB9XG5cbiAgY29uc3QgaGFuZGxlSW5kZXhDaGFuZ2UgPSAoYWN0aW9uOiBTdWJzY3JpYmVySGlzdG9yeUFjdGlvbikgPT4ge1xuICAgIGlmIChvcHRzLm5vdGlmeU9uSW5kZXhDaGFuZ2UgPz8gdHJ1ZSkgbm90aWZ5KGFjdGlvbilcbiAgICBlbHNlIGxvY2F0aW9uID0gb3B0cy5nZXRMb2NhdGlvbigpXG4gIH1cblxuICBjb25zdCB0cnlOYXZpZ2F0aW9uID0gYXN5bmMgKHtcbiAgICB0YXNrLFxuICAgIG5hdmlnYXRlT3B0cyxcbiAgICAuLi5hY3Rpb25JbmZvXG4gIH06IFRyeU5hdmlnYXRlQXJncykgPT4ge1xuICAgIGNvbnN0IGlnbm9yZUJsb2NrZXIgPSBuYXZpZ2F0ZU9wdHM/Lmlnbm9yZUJsb2NrZXIgPz8gZmFsc2VcbiAgICBpZiAoaWdub3JlQmxvY2tlcikge1xuICAgICAgdGFzaygpXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBjb25zdCBibG9ja2VycyA9IG9wdHMuZ2V0QmxvY2tlcnM/LigpID8/IFtdXG4gICAgY29uc3QgaXNQdXNoT3JSZXBsYWNlID1cbiAgICAgIGFjdGlvbkluZm8udHlwZSA9PT0gJ1BVU0gnIHx8IGFjdGlvbkluZm8udHlwZSA9PT0gJ1JFUExBQ0UnXG4gICAgaWYgKHR5cGVvZiBkb2N1bWVudCAhPT0gJ3VuZGVmaW5lZCcgJiYgYmxvY2tlcnMubGVuZ3RoICYmIGlzUHVzaE9yUmVwbGFjZSkge1xuICAgICAgZm9yIChjb25zdCBibG9ja2VyIG9mIGJsb2NrZXJzKSB7XG4gICAgICAgIGNvbnN0IG5leHRMb2NhdGlvbiA9IHBhcnNlSHJlZihhY3Rpb25JbmZvLnBhdGgsIGFjdGlvbkluZm8uc3RhdGUpXG4gICAgICAgIGNvbnN0IGlzQmxvY2tlZCA9IGF3YWl0IGJsb2NrZXIuYmxvY2tlckZuKHtcbiAgICAgICAgICBjdXJyZW50TG9jYXRpb246IGxvY2F0aW9uLFxuICAgICAgICAgIG5leHRMb2NhdGlvbixcbiAgICAgICAgICBhY3Rpb246IGFjdGlvbkluZm8udHlwZSxcbiAgICAgICAgfSlcbiAgICAgICAgaWYgKGlzQmxvY2tlZCkge1xuICAgICAgICAgIG9wdHMub25CbG9ja2VkPy4oKVxuICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgdGFzaygpXG4gIH1cblxuICByZXR1cm4ge1xuICAgIGdldCBsb2NhdGlvbigpIHtcbiAgICAgIHJldHVybiBsb2NhdGlvblxuICAgIH0sXG4gICAgZ2V0IGxlbmd0aCgpIHtcbiAgICAgIHJldHVybiBvcHRzLmdldExlbmd0aCgpXG4gICAgfSxcbiAgICBzdWJzY3JpYmVycyxcbiAgICBzdWJzY3JpYmU6IChjYjogKG9wdHM6IFN1YnNjcmliZXJBcmdzKSA9PiB2b2lkKSA9PiB7XG4gICAgICBzdWJzY3JpYmVycy5hZGQoY2IpXG5cbiAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgIHN1YnNjcmliZXJzLmRlbGV0ZShjYilcbiAgICAgIH1cbiAgICB9LFxuICAgIHB1c2g6IChwYXRoLCBzdGF0ZSwgbmF2aWdhdGVPcHRzKSA9PiB7XG4gICAgICBjb25zdCBjdXJyZW50SW5kZXggPSBsb2NhdGlvbi5zdGF0ZVtzdGF0ZUluZGV4S2V5XVxuICAgICAgc3RhdGUgPSBhc3NpZ25LZXlBbmRJbmRleChjdXJyZW50SW5kZXggKyAxLCBzdGF0ZSlcbiAgICAgIHRyeU5hdmlnYXRpb24oe1xuICAgICAgICB0YXNrOiAoKSA9PiB7XG4gICAgICAgICAgb3B0cy5wdXNoU3RhdGUocGF0aCwgc3RhdGUpXG4gICAgICAgICAgbm90aWZ5KHsgdHlwZTogJ1BVU0gnIH0pXG4gICAgICAgIH0sXG4gICAgICAgIG5hdmlnYXRlT3B0cyxcbiAgICAgICAgdHlwZTogJ1BVU0gnLFxuICAgICAgICBwYXRoLFxuICAgICAgICBzdGF0ZSxcbiAgICAgIH0pXG4gICAgfSxcbiAgICByZXBsYWNlOiAocGF0aCwgc3RhdGUsIG5hdmlnYXRlT3B0cykgPT4ge1xuICAgICAgY29uc3QgY3VycmVudEluZGV4ID0gbG9jYXRpb24uc3RhdGVbc3RhdGVJbmRleEtleV1cbiAgICAgIHN0YXRlID0gYXNzaWduS2V5QW5kSW5kZXgoY3VycmVudEluZGV4LCBzdGF0ZSlcbiAgICAgIHRyeU5hdmlnYXRpb24oe1xuICAgICAgICB0YXNrOiAoKSA9PiB7XG4gICAgICAgICAgb3B0cy5yZXBsYWNlU3RhdGUocGF0aCwgc3RhdGUpXG4gICAgICAgICAgbm90aWZ5KHsgdHlwZTogJ1JFUExBQ0UnIH0pXG4gICAgICAgIH0sXG4gICAgICAgIG5hdmlnYXRlT3B0cyxcbiAgICAgICAgdHlwZTogJ1JFUExBQ0UnLFxuICAgICAgICBwYXRoLFxuICAgICAgICBzdGF0ZSxcbiAgICAgIH0pXG4gICAgfSxcbiAgICBnbzogKGluZGV4LCBuYXZpZ2F0ZU9wdHMpID0+IHtcbiAgICAgIHRyeU5hdmlnYXRpb24oe1xuICAgICAgICB0YXNrOiAoKSA9PiB7XG4gICAgICAgICAgb3B0cy5nbyhpbmRleCwgbmF2aWdhdGVPcHRzPy5pZ25vcmVCbG9ja2VyID8/IGZhbHNlKVxuICAgICAgICAgIGhhbmRsZUluZGV4Q2hhbmdlKHsgdHlwZTogJ0dPJywgaW5kZXggfSlcbiAgICAgICAgfSxcbiAgICAgICAgbmF2aWdhdGVPcHRzLFxuICAgICAgICB0eXBlOiAnR08nLFxuICAgICAgfSlcbiAgICB9LFxuICAgIGJhY2s6IChuYXZpZ2F0ZU9wdHMpID0+IHtcbiAgICAgIHRyeU5hdmlnYXRpb24oe1xuICAgICAgICB0YXNrOiAoKSA9PiB7XG4gICAgICAgICAgb3B0cy5iYWNrKG5hdmlnYXRlT3B0cz8uaWdub3JlQmxvY2tlciA/PyBmYWxzZSlcbiAgICAgICAgICBoYW5kbGVJbmRleENoYW5nZSh7IHR5cGU6ICdCQUNLJyB9KVxuICAgICAgICB9LFxuICAgICAgICBuYXZpZ2F0ZU9wdHMsXG4gICAgICAgIHR5cGU6ICdCQUNLJyxcbiAgICAgIH0pXG4gICAgfSxcbiAgICBmb3J3YXJkOiAobmF2aWdhdGVPcHRzKSA9PiB7XG4gICAgICB0cnlOYXZpZ2F0aW9uKHtcbiAgICAgICAgdGFzazogKCkgPT4ge1xuICAgICAgICAgIG9wdHMuZm9yd2FyZChuYXZpZ2F0ZU9wdHM/Lmlnbm9yZUJsb2NrZXIgPz8gZmFsc2UpXG4gICAgICAgICAgaGFuZGxlSW5kZXhDaGFuZ2UoeyB0eXBlOiAnRk9SV0FSRCcgfSlcbiAgICAgICAgfSxcbiAgICAgICAgbmF2aWdhdGVPcHRzLFxuICAgICAgICB0eXBlOiAnRk9SV0FSRCcsXG4gICAgICB9KVxuICAgIH0sXG4gICAgY2FuR29CYWNrOiAoKSA9PiBsb2NhdGlvbi5zdGF0ZVtzdGF0ZUluZGV4S2V5XSAhPT0gMCxcbiAgICBjcmVhdGVIcmVmOiAoc3RyKSA9PiBvcHRzLmNyZWF0ZUhyZWYoc3RyKSxcbiAgICBibG9jazogKGJsb2NrZXIpID0+IHtcbiAgICAgIGlmICghb3B0cy5zZXRCbG9ja2VycykgcmV0dXJuICgpID0+IHt9XG4gICAgICBjb25zdCBibG9ja2VycyA9IG9wdHMuZ2V0QmxvY2tlcnM/LigpID8/IFtdXG4gICAgICBvcHRzLnNldEJsb2NrZXJzKFsuLi5ibG9ja2VycywgYmxvY2tlcl0pXG5cbiAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGJsb2NrZXJzID0gb3B0cy5nZXRCbG9ja2Vycz8uKCkgPz8gW11cbiAgICAgICAgb3B0cy5zZXRCbG9ja2Vycz8uKGJsb2NrZXJzLmZpbHRlcigoYikgPT4gYiAhPT0gYmxvY2tlcikpXG4gICAgICB9XG4gICAgfSxcbiAgICBmbHVzaDogKCkgPT4gb3B0cy5mbHVzaD8uKCksXG4gICAgZGVzdHJveTogKCkgPT4gb3B0cy5kZXN0cm95Py4oKSxcbiAgICBub3RpZnksXG4gICAgX2dldEJsb2NrZXJzOiAoKSA9PiBvcHRzLmdldEJsb2NrZXJzPy4oKSA/PyBbXSxcbiAgfVxufVxuXG5mdW5jdGlvbiBhc3NpZ25LZXlBbmRJbmRleChpbmRleDogbnVtYmVyLCBzdGF0ZTogSGlzdG9yeVN0YXRlIHwgdW5kZWZpbmVkKSB7XG4gIGNvbnN0IGtleSA9IGNyZWF0ZVJhbmRvbUtleSgpXG4gIHJldHVybiB7XG4gICAgLi4uc3RhdGUsXG4gICAga2V5LCAvLyBUT0RPOiBSZW1vdmUgaW4gdjIgLSB1c2UgX19UU1Jfa2V5IGluc3RlYWRcbiAgICBfX1RTUl9rZXk6IGtleSxcbiAgICBbc3RhdGVJbmRleEtleV06IGluZGV4LFxuICB9IGFzIFBhcnNlZEhpc3RvcnlTdGF0ZVxufVxuXG4vKipcbiAqIENyZWF0ZXMgYSBoaXN0b3J5IG9iamVjdCB0aGF0IGNhbiBiZSB1c2VkIHRvIGludGVyYWN0IHdpdGggdGhlIGJyb3dzZXInc1xuICogbmF2aWdhdGlvbi4gVGhpcyBpcyBhIGxpZ2h0d2VpZ2h0IEFQSSB3cmFwcGluZyB0aGUgYnJvd3NlcidzIG5hdGl2ZSBtZXRob2RzLlxuICogSXQgaXMgZGVzaWduZWQgdG8gd29yayB3aXRoIFRhblN0YWNrIFJvdXRlciwgYnV0IGNvdWxkIGJlIHVzZWQgYXMgYSBzdGFuZGFsb25lIEFQSSBhcyB3ZWxsLlxuICogSU1QT1JUQU5UOiBUaGlzIEFQSSBpbXBsZW1lbnRzIGhpc3RvcnkgdGhyb3R0bGluZyB2aWEgYSBtaWNyb3Rhc2sgdG8gcHJldmVudFxuICogZXhjZXNzaXZlIGNhbGxzIHRvIHRoZSBoaXN0b3J5IEFQSS4gSW4gc29tZSBicm93c2VycywgY2FsbGluZyBoaXN0b3J5LnB1c2hTdGF0ZSBvclxuICogaGlzdG9yeS5yZXBsYWNlU3RhdGUgaW4gcXVpY2sgc3VjY2Vzc2lvbiBjYW4gY2F1c2UgdGhlIGJyb3dzZXIgdG8gaWdub3JlIHN1YnNlcXVlbnRcbiAqIGNhbGxzLiBUaGlzIEFQSSBzbW9vdGhzIG91dCB0aG9zZSBkaWZmZXJlbmNlcyBhbmQgZW5zdXJlcyB0aGF0IHlvdXIgYXBwbGljYXRpb25cbiAqIHN0YXRlIHdpbGwgKmV2ZW50dWFsbHkqIG1hdGNoIHRoZSBicm93c2VyIHN0YXRlLiBJbiBtb3N0IGNhc2VzLCB0aGlzIGlzIG5vdCBhIHByb2JsZW0sXG4gKiBidXQgaWYgeW91IG5lZWQgdG8gZW5zdXJlIHRoYXQgdGhlIGJyb3dzZXIgc3RhdGUgaXMgdXAgdG8gZGF0ZSwgeW91IGNhbiB1c2UgdGhlXG4gKiBgaGlzdG9yeS5mbHVzaGAgbWV0aG9kIHRvIGltbWVkaWF0ZWx5IGZsdXNoIGFsbCBwZW5kaW5nIHN0YXRlIGNoYW5nZXMgdG8gdGhlIGJyb3dzZXIgVVJMLlxuICogQHBhcmFtIG9wdHNcbiAqIEBwYXJhbSBvcHRzLmdldEhyZWYgQSBmdW5jdGlvbiB0aGF0IHJldHVybnMgdGhlIGN1cnJlbnQgaHJlZiAocGF0aCArIHNlYXJjaCArIGhhc2gpXG4gKiBAcGFyYW0gb3B0cy5jcmVhdGVIcmVmIEEgZnVuY3Rpb24gdGhhdCB0YWtlcyBhIHBhdGggYW5kIHJldHVybnMgYSBocmVmIChwYXRoICsgc2VhcmNoICsgaGFzaClcbiAqIEByZXR1cm5zIEEgaGlzdG9yeSBpbnN0YW5jZVxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlQnJvd3Nlckhpc3Rvcnkob3B0cz86IHtcbiAgcGFyc2VMb2NhdGlvbj86ICgpID0+IEhpc3RvcnlMb2NhdGlvblxuICBjcmVhdGVIcmVmPzogKHBhdGg6IHN0cmluZykgPT4gc3RyaW5nXG4gIHdpbmRvdz86IGFueVxufSk6IFJvdXRlckhpc3Rvcnkge1xuICBjb25zdCB3aW4gPVxuICAgIG9wdHM/LndpbmRvdyA/P1xuICAgICh0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnID8gd2luZG93IDogKHVuZGVmaW5lZCBhcyBhbnkpKVxuXG4gIGNvbnN0IG9yaWdpbmFsUHVzaFN0YXRlID0gd2luLmhpc3RvcnkucHVzaFN0YXRlXG4gIGNvbnN0IG9yaWdpbmFsUmVwbGFjZVN0YXRlID0gd2luLmhpc3RvcnkucmVwbGFjZVN0YXRlXG5cbiAgbGV0IGJsb2NrZXJzOiBBcnJheTxOYXZpZ2F0aW9uQmxvY2tlcj4gPSBbXVxuICBjb25zdCBfZ2V0QmxvY2tlcnMgPSAoKSA9PiBibG9ja2Vyc1xuICBjb25zdCBfc2V0QmxvY2tlcnMgPSAobmV3QmxvY2tlcnM6IEFycmF5PE5hdmlnYXRpb25CbG9ja2VyPikgPT5cbiAgICAoYmxvY2tlcnMgPSBuZXdCbG9ja2VycylcblxuICBjb25zdCBjcmVhdGVIcmVmID0gKHBhdGg6IHN0cmluZykgPT5cbiAgICBub3JtYWxpemVIcmVmKG9wdHM/LmNyZWF0ZUhyZWYgPyBvcHRzLmNyZWF0ZUhyZWYocGF0aCkgOiBwYXRoKVxuICBjb25zdCBwYXJzZUxvY2F0aW9uID1cbiAgICBvcHRzPy5wYXJzZUxvY2F0aW9uID8/XG4gICAgKCgpID0+XG4gICAgICBwYXJzZUhyZWYoXG4gICAgICAgIGAke3dpbi5sb2NhdGlvbi5wYXRobmFtZX0ke3dpbi5sb2NhdGlvbi5zZWFyY2h9JHt3aW4ubG9jYXRpb24uaGFzaH1gLFxuICAgICAgICB3aW4uaGlzdG9yeS5zdGF0ZSxcbiAgICAgICkpXG5cbiAgLy8gRW5zdXJlIHRoZXJlIGlzIGFsd2F5cyBhIGtleSB0byBzdGFydFxuICBpZiAoIXdpbi5oaXN0b3J5LnN0YXRlPy5fX1RTUl9rZXkgJiYgIXdpbi5oaXN0b3J5LnN0YXRlPy5rZXkpIHtcbiAgICBjb25zdCBhZGRlZEtleSA9IGNyZWF0ZVJhbmRvbUtleSgpXG4gICAgd2luLmhpc3RvcnkucmVwbGFjZVN0YXRlKFxuICAgICAge1xuICAgICAgICBbc3RhdGVJbmRleEtleV06IDAsXG4gICAgICAgIGtleTogYWRkZWRLZXksIC8vIFRPRE86IFJlbW92ZSBpbiB2MiAtIHVzZSBfX1RTUl9rZXkgaW5zdGVhZFxuICAgICAgICBfX1RTUl9rZXk6IGFkZGVkS2V5LFxuICAgICAgfSxcbiAgICAgICcnLFxuICAgIClcbiAgfVxuXG4gIGxldCBjdXJyZW50TG9jYXRpb24gPSBwYXJzZUxvY2F0aW9uKClcbiAgbGV0IHJvbGxiYWNrTG9jYXRpb246IEhpc3RvcnlMb2NhdGlvbiB8IHVuZGVmaW5lZFxuXG4gIGxldCBuZXh0UG9wSXNHbyA9IGZhbHNlXG4gIGxldCBpZ25vcmVOZXh0UG9wID0gZmFsc2VcbiAgLy8gVE9ETzogQW4gaWdub3JlZCB0cmF2ZXJzYWwgcGFzdCBhIGhpc3RvcnkgYm91bmRhcnkgZW1pdHMgbmVpdGhlciBwb3BzdGF0ZVxuICAvLyBub3IgYmVmb3JldW5sb2FkLCBsZWF2aW5nIHRoZXNlIGJ5cGFzc2VzIGFjdGl2ZSBmb3IgYSBsYXRlciBuYXZpZ2F0aW9uLlxuICAvLyBUaGUgSGlzdG9yeSBBUEkgcHJvdmlkZXMgbm8gY29tcGxldGlvbiBzaWduYWwgZm9yIHN1Y2ggbm8tb3AgdHJhdmVyc2Fscy5cbiAgbGV0IHNraXBCbG9ja2VyTmV4dFBvcCA9IGZhbHNlXG4gIGxldCBpZ25vcmVOZXh0QmVmb3JlVW5sb2FkID0gZmFsc2VcblxuICBjb25zdCBnZXRMb2NhdGlvbiA9ICgpID0+IGN1cnJlbnRMb2NhdGlvblxuXG4gIGxldCBuZXh0OlxuICAgIHwgdW5kZWZpbmVkXG4gICAgfCBbXG4gICAgICAgIC8vIFRoZSBsYXRlc3QgbG9jYXRpb24gdGhhdCB3ZSB3ZXJlIGF0dGVtcHRpbmcgdG8gcHVzaC9yZXBsYWNlXG4gICAgICAgIGhyZWY6IHN0cmluZyxcbiAgICAgICAgLy8gVGhlIGxhdGVzdCBzdGF0ZSB0aGF0IHdlIHdlcmUgYXR0ZW1wdGluZyB0byBwdXNoL3JlcGxhY2VcbiAgICAgICAgc3RhdGU6IGFueSxcbiAgICAgICAgLy8gV2hldGhlciBhbnkgcXVldWVkIHVwZGF0ZSBuZWVkcyB0byBwdXNoIHJhdGhlciB0aGFuIHJlcGxhY2VcbiAgICAgICAgaXNQdXNoOiBib29sZWFuLFxuICAgICAgXVxuXG4gIC8vIFRoaXMgZnVuY3Rpb24gZmx1c2hlcyB0aGUgbmV4dCB1cGRhdGUgdG8gdGhlIGJyb3dzZXIgaGlzdG9yeVxuICBjb25zdCBmbHVzaCA9ICgpID0+IHtcbiAgICBpZiAoIW5leHQpIHtcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIC8vIFdlIG5lZWQgdG8gaWdub3JlIGFueSB1cGRhdGVzIHRvIHRoZSBzdWJzY3JpYmVycyB3aGlsZSB3ZSB1cGRhdGUgdGhlIGJyb3dzZXIgaGlzdG9yeVxuICAgIGhpc3RvcnkuX2lnbm9yZVN1YnNjcmliZXJzID0gdHJ1ZVxuXG4gICAgLy8gVXBkYXRlIHRoZSBicm93c2VyIGhpc3RvcnlcbiAgICA7KG5leHRbMiAvKiBpcyBwdXNoICovXSA/IHdpbi5oaXN0b3J5LnB1c2hTdGF0ZSA6IHdpbi5oaXN0b3J5LnJlcGxhY2VTdGF0ZSkoXG4gICAgICBuZXh0WzEgLyogc3RhdGUgKi9dLFxuICAgICAgJycsXG4gICAgICBuZXh0WzAgLyogaHJlZiAqL10sXG4gICAgKVxuXG4gICAgLy8gU3RvcCBpZ25vcmluZyBzdWJzY3JpYmVyIHVwZGF0ZXNcbiAgICBoaXN0b3J5Ll9pZ25vcmVTdWJzY3JpYmVycyA9IGZhbHNlXG5cbiAgICAvLyBDbGVhciB0aGUgcXVldWVkIGFjdGlvbiBhZnRlciBpdCByZWFjaGVzIGJyb3dzZXIgaGlzdG9yeS5cbiAgICBuZXh0ID0gdW5kZWZpbmVkXG4gICAgcm9sbGJhY2tMb2NhdGlvbiA9IHVuZGVmaW5lZFxuICB9XG5cbiAgLy8gVGhpcyBmdW5jdGlvbiBxdWV1ZXMgdXAgYSBjYWxsIHRvIHVwZGF0ZSB0aGUgYnJvd3NlciBoaXN0b3J5XG4gIGNvbnN0IHF1ZXVlSGlzdG9yeUFjdGlvbiA9IChcbiAgICBpc1B1c2g6IGJvb2xlYW4sXG4gICAgZGVzdEhyZWY6IHN0cmluZyxcbiAgICBzdGF0ZTogYW55LFxuICApID0+IHtcbiAgICAvLyBBIGZvcm1hdHRlciBjaGFuZ2VzIHRoZSBVUkwgc3BhY2UgYW5kIG11c3QgcmVjZWl2ZSB0aGUgb3JpZ2luYWwgaW5wdXQuXG4gICAgLy8gT3RoZXJ3aXNlIHBhcnNlSHJlZiBiZWxvdyBhbHJlYWR5IHByb2R1Y2VzIHRoZSBicm93c2VyIGRlc3RpbmF0aW9uLlxuICAgIGNvbnN0IGhyZWYgPSBvcHRzPy5jcmVhdGVIcmVmID8gY3JlYXRlSHJlZihkZXN0SHJlZikgOiB1bmRlZmluZWRcbiAgICBjb25zdCBoYXNQZW5kaW5nQWN0aW9uID0gISFuZXh0XG5cbiAgICBpZiAoIWhhc1BlbmRpbmdBY3Rpb24pIHtcbiAgICAgIHJvbGxiYWNrTG9jYXRpb24gPSBjdXJyZW50TG9jYXRpb25cbiAgICB9XG5cbiAgICAvLyBLZWVwIHRoZSBvcHRpbWlzdGljIGxvY2F0aW9uIGluIHRoZSByb3V0ZXIncyBsb2dpY2FsIFVSTCBzcGFjZS5cbiAgICBjdXJyZW50TG9jYXRpb24gPSBwYXJzZUhyZWYoZGVzdEhyZWYsIHN0YXRlKVxuXG4gICAgLy8gS2VlcCB0cmFjayBvZiB0aGUgbmV4dCBsb2NhdGlvbiB3ZSBuZWVkIHRvIGZsdXNoIHRvIHRoZSBVUkxcbiAgICBuZXh0ID0gW1xuICAgICAgaHJlZiA/PyBjdXJyZW50TG9jYXRpb24uaHJlZixcbiAgICAgIHN0YXRlLFxuICAgICAgbmV4dD8uWzIgLyogaXMgcHVzaCAqL10gfHwgaXNQdXNoLFxuICAgIF1cblxuICAgIGlmICghaGFzUGVuZGluZ0FjdGlvbikge1xuICAgICAgLy8gU2NoZWR1bGUgYW4gdXBkYXRlIHRvIHRoZSBicm93c2VyIGhpc3RvcnlcbiAgICAgIHF1ZXVlTWljcm90YXNrKCgpID0+IGZsdXNoKCkpXG4gICAgfVxuICB9XG5cbiAgLy8gTk9URTogdGhpcyBmdW5jdGlvbiBjYW4gcHJvYmFibHkgYmUgcmVtb3ZlZFxuICBjb25zdCBvblB1c2hQb3AgPSAodHlwZTogJ1BVU0gnIHwgJ1JFUExBQ0UnKSA9PiB7XG4gICAgY3VycmVudExvY2F0aW9uID0gcGFyc2VMb2NhdGlvbigpXG4gICAgaGlzdG9yeS5ub3RpZnkoeyB0eXBlIH0pXG4gIH1cblxuICBjb25zdCBvblB1c2hQb3BFdmVudCA9IGFzeW5jICgpID0+IHtcbiAgICAvLyBTYW1lLWRvY3VtZW50IHRyYXZlcnNhbHMgZG8gbm90IGZpcmUgYmVmb3JldW5sb2FkLCBzbyBjb25zdW1lIHRoZWlyXG4gICAgLy8gZXhlbXB0aW9uIGhlcmUgaW5zdGVhZCBvZiBjYXJyeWluZyBpdCBpbnRvIGEgbGF0ZXIgZG9jdW1lbnQgbmF2aWdhdGlvbi5cbiAgICBpZ25vcmVOZXh0QmVmb3JlVW5sb2FkID0gZmFsc2VcblxuICAgIGlmIChpZ25vcmVOZXh0UG9wKSB7XG4gICAgICBpZ25vcmVOZXh0UG9wID0gZmFsc2VcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGNvbnN0IG5leHRMb2NhdGlvbiA9IHBhcnNlTG9jYXRpb24oKVxuICAgIGNvbnN0IGRlbHRhID1cbiAgICAgIG5leHRMb2NhdGlvbi5zdGF0ZVtzdGF0ZUluZGV4S2V5XSAtIGN1cnJlbnRMb2NhdGlvbi5zdGF0ZVtzdGF0ZUluZGV4S2V5XVxuICAgIGNvbnN0IGlzRm9yd2FyZCA9IGRlbHRhID09PSAxXG4gICAgY29uc3QgaXNCYWNrID0gZGVsdGEgPT09IC0xXG4gICAgY29uc3QgaXNHbyA9ICghaXNGb3J3YXJkICYmICFpc0JhY2spIHx8IG5leHRQb3BJc0dvXG4gICAgbmV4dFBvcElzR28gPSBmYWxzZVxuXG4gICAgY29uc3QgYWN0aW9uID0gaXNHbyA/ICdHTycgOiBpc0JhY2sgPyAnQkFDSycgOiAnRk9SV0FSRCdcbiAgICBjb25zdCBub3RpZnk6IFN1YnNjcmliZXJIaXN0b3J5QWN0aW9uID0gaXNHb1xuICAgICAgPyB7XG4gICAgICAgICAgdHlwZTogJ0dPJyxcbiAgICAgICAgICBpbmRleDogZGVsdGEsXG4gICAgICAgIH1cbiAgICAgIDoge1xuICAgICAgICAgIHR5cGU6IGlzQmFjayA/ICdCQUNLJyA6ICdGT1JXQVJEJyxcbiAgICAgICAgfVxuXG4gICAgaWYgKHNraXBCbG9ja2VyTmV4dFBvcCkge1xuICAgICAgc2tpcEJsb2NrZXJOZXh0UG9wID0gZmFsc2VcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgYmxvY2tlcnMgPSBfZ2V0QmxvY2tlcnMoKVxuICAgICAgaWYgKHR5cGVvZiBkb2N1bWVudCAhPT0gJ3VuZGVmaW5lZCcgJiYgYmxvY2tlcnMubGVuZ3RoKSB7XG4gICAgICAgIGZvciAoY29uc3QgYmxvY2tlciBvZiBibG9ja2Vycykge1xuICAgICAgICAgIGNvbnN0IGlzQmxvY2tlZCA9IGF3YWl0IGJsb2NrZXIuYmxvY2tlckZuKHtcbiAgICAgICAgICAgIGN1cnJlbnRMb2NhdGlvbixcbiAgICAgICAgICAgIG5leHRMb2NhdGlvbixcbiAgICAgICAgICAgIGFjdGlvbixcbiAgICAgICAgICB9KVxuICAgICAgICAgIGlmIChpc0Jsb2NrZWQpIHtcbiAgICAgICAgICAgIGlnbm9yZU5leHRQb3AgPSB0cnVlXG4gICAgICAgICAgICB3aW4uaGlzdG9yeS5nbygtZGVsdGEpXG4gICAgICAgICAgICBoaXN0b3J5Lm5vdGlmeShub3RpZnkpXG4gICAgICAgICAgICByZXR1cm5cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICBjdXJyZW50TG9jYXRpb24gPSBwYXJzZUxvY2F0aW9uKClcbiAgICBoaXN0b3J5Lm5vdGlmeShub3RpZnkpXG4gIH1cblxuICBjb25zdCBvbkJlZm9yZVVubG9hZCA9IChlOiBCZWZvcmVVbmxvYWRFdmVudCkgPT4ge1xuICAgIGlmIChpZ25vcmVOZXh0QmVmb3JlVW5sb2FkKSB7XG4gICAgICBpZ25vcmVOZXh0QmVmb3JlVW5sb2FkID0gZmFsc2VcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGxldCBzaG91bGRCbG9jayA9IGZhbHNlXG5cbiAgICAvLyBJZiBvbmUgYmxvY2tlciBoYXMgYSBub24tZGlzYWJsZWQgYmVmb3JlVW5sb2FkLCB3ZSBzaG91bGQgYmxvY2tcbiAgICBjb25zdCBibG9ja2VycyA9IF9nZXRCbG9ja2VycygpXG4gICAgaWYgKHR5cGVvZiBkb2N1bWVudCAhPT0gJ3VuZGVmaW5lZCcgJiYgYmxvY2tlcnMubGVuZ3RoKSB7XG4gICAgICBmb3IgKGNvbnN0IGJsb2NrZXIgb2YgYmxvY2tlcnMpIHtcbiAgICAgICAgY29uc3Qgc2hvdWxkSGF2ZUJlZm9yZVVubG9hZCA9IGJsb2NrZXIuZW5hYmxlQmVmb3JlVW5sb2FkID8/IHRydWVcbiAgICAgICAgaWYgKHNob3VsZEhhdmVCZWZvcmVVbmxvYWQgPT09IHRydWUpIHtcbiAgICAgICAgICBzaG91bGRCbG9jayA9IHRydWVcbiAgICAgICAgICBicmVha1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKFxuICAgICAgICAgIHR5cGVvZiBzaG91bGRIYXZlQmVmb3JlVW5sb2FkID09PSAnZnVuY3Rpb24nICYmXG4gICAgICAgICAgc2hvdWxkSGF2ZUJlZm9yZVVubG9hZCgpID09PSB0cnVlXG4gICAgICAgICkge1xuICAgICAgICAgIHNob3VsZEJsb2NrID0gdHJ1ZVxuICAgICAgICAgIGJyZWFrXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoc2hvdWxkQmxvY2spIHtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgcmV0dXJuIChlLnJldHVyblZhbHVlID0gJycpXG4gICAgfVxuICAgIHJldHVyblxuICB9XG5cbiAgY29uc3QgaGlzdG9yeSA9IGNyZWF0ZUhpc3Rvcnkoe1xuICAgIGdldExvY2F0aW9uLFxuICAgIGdldExlbmd0aDogKCkgPT4gd2luLmhpc3RvcnkubGVuZ3RoLFxuICAgIHB1c2hTdGF0ZTogKGhyZWYsIHN0YXRlKSA9PiBxdWV1ZUhpc3RvcnlBY3Rpb24odHJ1ZSwgaHJlZiwgc3RhdGUpLFxuICAgIHJlcGxhY2VTdGF0ZTogKGhyZWYsIHN0YXRlKSA9PiBxdWV1ZUhpc3RvcnlBY3Rpb24oZmFsc2UsIGhyZWYsIHN0YXRlKSxcbiAgICBiYWNrOiAoaWdub3JlQmxvY2tlcikgPT4ge1xuICAgICAgaWYgKGlnbm9yZUJsb2NrZXIpIHtcbiAgICAgICAgc2tpcEJsb2NrZXJOZXh0UG9wID0gdHJ1ZVxuICAgICAgICBpZ25vcmVOZXh0QmVmb3JlVW5sb2FkID0gdHJ1ZVxuICAgICAgfVxuICAgICAgcmV0dXJuIHdpbi5oaXN0b3J5LmJhY2soKVxuICAgIH0sXG4gICAgZm9yd2FyZDogKGlnbm9yZUJsb2NrZXIpID0+IHtcbiAgICAgIGlmIChpZ25vcmVCbG9ja2VyKSB7XG4gICAgICAgIHNraXBCbG9ja2VyTmV4dFBvcCA9IHRydWVcbiAgICAgICAgaWdub3JlTmV4dEJlZm9yZVVubG9hZCA9IHRydWVcbiAgICAgIH1cbiAgICAgIHdpbi5oaXN0b3J5LmZvcndhcmQoKVxuICAgIH0sXG4gICAgZ286IChuLCBpZ25vcmVCbG9ja2VyKSA9PiB7XG4gICAgICBuZXh0UG9wSXNHbyA9IHRydWVcbiAgICAgIGlmIChpZ25vcmVCbG9ja2VyKSB7XG4gICAgICAgIHNraXBCbG9ja2VyTmV4dFBvcCA9IHRydWVcbiAgICAgICAgaWdub3JlTmV4dEJlZm9yZVVubG9hZCA9IHRydWVcbiAgICAgIH1cbiAgICAgIHdpbi5oaXN0b3J5LmdvKG4pXG4gICAgfSxcbiAgICBjcmVhdGVIcmVmOiAoaHJlZikgPT4gY3JlYXRlSHJlZihocmVmKSxcbiAgICBmbHVzaCxcbiAgICBkZXN0cm95OiAoKSA9PiB7XG4gICAgICB3aW4uaGlzdG9yeS5wdXNoU3RhdGUgPSBvcmlnaW5hbFB1c2hTdGF0ZVxuICAgICAgd2luLmhpc3RvcnkucmVwbGFjZVN0YXRlID0gb3JpZ2luYWxSZXBsYWNlU3RhdGVcbiAgICAgIHdpbi5yZW1vdmVFdmVudExpc3RlbmVyKGJlZm9yZVVubG9hZEV2ZW50LCBvbkJlZm9yZVVubG9hZCwge1xuICAgICAgICBjYXB0dXJlOiB0cnVlLFxuICAgICAgfSlcbiAgICAgIHdpbi5yZW1vdmVFdmVudExpc3RlbmVyKHBvcFN0YXRlRXZlbnQsIG9uUHVzaFBvcEV2ZW50KVxuICAgIH0sXG4gICAgb25CbG9ja2VkOiAoKSA9PiB7XG4gICAgICAvLyBJZiBhIG5hdmlnYXRpb24gaXMgYmxvY2tlZCwgd2UgbmVlZCB0byByb2xsYmFjayB0aGUgbG9jYXRpb25cbiAgICAgIC8vIHRoYXQgd2Ugb3B0aW1pc3RpY2FsbHkgdXBkYXRlZCBpbiBtZW1vcnkuXG4gICAgICBpZiAocm9sbGJhY2tMb2NhdGlvbiAmJiBjdXJyZW50TG9jYXRpb24gIT09IHJvbGxiYWNrTG9jYXRpb24pIHtcbiAgICAgICAgY3VycmVudExvY2F0aW9uID0gcm9sbGJhY2tMb2NhdGlvblxuICAgICAgfVxuICAgIH0sXG4gICAgZ2V0QmxvY2tlcnM6IF9nZXRCbG9ja2VycyxcbiAgICBzZXRCbG9ja2VyczogX3NldEJsb2NrZXJzLFxuICAgIG5vdGlmeU9uSW5kZXhDaGFuZ2U6IGZhbHNlLFxuICB9KVxuXG4gIGhpc3RvcnkuX2lnbm9yZU5leHRCZWZvcmVVbmxvYWQgPSAoaHJlZikgPT4ge1xuICAgIGlnbm9yZU5leHRCZWZvcmVVbmxvYWQgPSBmYWxzZVxuICAgIHRyeSB7XG4gICAgICBocmVmID0gbmV3IFVSTChocmVmLCB3aW4uZG9jdW1lbnQuYmFzZVVSSSkuaHJlZlxuICAgICAgLy8gRXh0ZXJuYWwgaGFuZGxlcnMgYW5kIHNhbWUtZG9jdW1lbnQgZnJhZ21lbnRzIG1heSBlbWl0IG5laXRoZXJcbiAgICAgIC8vIGJlZm9yZXVubG9hZCBub3IgcG9wc3RhdGUsIGxlYXZpbmcgYW4gZXhlbXB0aW9uIGZvciBhIGxhdGVyIGRlcGFydHVyZS5cbiAgICAgIGlnbm9yZU5leHRCZWZvcmVVbmxvYWQgPVxuICAgICAgICAvXmh0dHBzPzovLnRlc3QoaHJlZikgJiZcbiAgICAgICAgKCFocmVmLmluY2x1ZGVzKCcjJykgfHxcbiAgICAgICAgICBocmVmLnNwbGl0KCcjJylbMF0gIT09IHdpbi5sb2NhdGlvbi5ocmVmLnNwbGl0KCcjJylbMF0pXG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBJbnZhbGlkIFVSTHMgY2Fubm90IHVubG9hZCB0aGUgZG9jdW1lbnQuXG4gICAgfVxuICB9XG5cbiAgd2luLmFkZEV2ZW50TGlzdGVuZXIoYmVmb3JlVW5sb2FkRXZlbnQsIG9uQmVmb3JlVW5sb2FkLCB7IGNhcHR1cmU6IHRydWUgfSlcbiAgd2luLmFkZEV2ZW50TGlzdGVuZXIocG9wU3RhdGVFdmVudCwgb25QdXNoUG9wRXZlbnQpXG5cbiAgd2luLmhpc3RvcnkucHVzaFN0YXRlID0gZnVuY3Rpb24gKC4uLmFyZ3M6IEFycmF5PGFueT4pIHtcbiAgICBjb25zdCByZXMgPSBvcmlnaW5hbFB1c2hTdGF0ZS5hcHBseSh3aW4uaGlzdG9yeSwgYXJncyBhcyBhbnkpXG4gICAgaWYgKCFoaXN0b3J5Ll9pZ25vcmVTdWJzY3JpYmVycykgb25QdXNoUG9wKCdQVVNIJylcbiAgICByZXR1cm4gcmVzXG4gIH1cblxuICB3aW4uaGlzdG9yeS5yZXBsYWNlU3RhdGUgPSBmdW5jdGlvbiAoLi4uYXJnczogQXJyYXk8YW55Pikge1xuICAgIGNvbnN0IHJlcyA9IG9yaWdpbmFsUmVwbGFjZVN0YXRlLmFwcGx5KHdpbi5oaXN0b3J5LCBhcmdzIGFzIGFueSlcbiAgICBpZiAoIWhpc3RvcnkuX2lnbm9yZVN1YnNjcmliZXJzKSBvblB1c2hQb3AoJ1JFUExBQ0UnKVxuICAgIHJldHVybiByZXNcbiAgfVxuXG4gIHJldHVybiBoaXN0b3J5XG59XG5cbi8qKlxuICogQ3JlYXRlIGEgaGFzaC1iYXNlZCBoaXN0b3J5IGltcGxlbWVudGF0aW9uLlxuICogVXNlZnVsIGZvciBzdGF0aWMgaG9zdHMgb3IgZW52aXJvbm1lbnRzIHdpdGhvdXQgc2VydmVyIFVSTCByZXdyaXRpbmcuXG4gKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2d1aWRlL2hpc3RvcnktdHlwZXNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUhhc2hIaXN0b3J5KG9wdHM/OiB7IHdpbmRvdz86IGFueSB9KTogUm91dGVySGlzdG9yeSB7XG4gIGNvbnN0IHdpbiA9XG4gICAgb3B0cz8ud2luZG93ID8/XG4gICAgKHR5cGVvZiBkb2N1bWVudCAhPT0gJ3VuZGVmaW5lZCcgPyB3aW5kb3cgOiAodW5kZWZpbmVkIGFzIGFueSkpXG4gIHJldHVybiBjcmVhdGVCcm93c2VySGlzdG9yeSh7XG4gICAgd2luZG93OiB3aW4sXG4gICAgcGFyc2VMb2NhdGlvbjogKCkgPT4ge1xuICAgICAgY29uc3QgaGFzaFNwbGl0ID0gd2luLmxvY2F0aW9uLmhhc2guc3BsaXQoJyMnKS5zbGljZSgxKVxuICAgICAgY29uc3QgcGF0aFBhcnQgPSBoYXNoU3BsaXRbMF0gPz8gJy8nXG4gICAgICBjb25zdCBzZWFyY2hQYXJ0ID0gd2luLmxvY2F0aW9uLnNlYXJjaFxuICAgICAgY29uc3QgaGFzaEVudHJpZXMgPSBoYXNoU3BsaXQuc2xpY2UoMSlcbiAgICAgIGNvbnN0IGhhc2hQYXJ0ID1cbiAgICAgICAgaGFzaEVudHJpZXMubGVuZ3RoID09PSAwID8gJycgOiBgIyR7aGFzaEVudHJpZXMuam9pbignIycpfWBcbiAgICAgIGNvbnN0IGhhc2hIcmVmID0gYCR7cGF0aFBhcnR9JHtzZWFyY2hQYXJ0fSR7aGFzaFBhcnR9YFxuICAgICAgcmV0dXJuIHBhcnNlSHJlZihoYXNoSHJlZiwgd2luLmhpc3Rvcnkuc3RhdGUpXG4gICAgfSxcbiAgICBjcmVhdGVIcmVmOiAoaHJlZikgPT5cbiAgICAgIGAke3dpbi5sb2NhdGlvbi5wYXRobmFtZX0ke3dpbi5sb2NhdGlvbi5zZWFyY2h9IyR7aHJlZn1gLFxuICB9KVxufVxuXG4vKipcbiAqIENyZWF0ZSBhbiBpbi1tZW1vcnkgaGlzdG9yeSBpbXBsZW1lbnRhdGlvbi5cbiAqIElkZWFsIGZvciBzZXJ2ZXIgcmVuZGVyaW5nLCB0ZXN0cywgYW5kIG5vbi1ET00gZW52aXJvbm1lbnRzLlxuICogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9ndWlkZS9oaXN0b3J5LXR5cGVzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVNZW1vcnlIaXN0b3J5KFxuICBvcHRzOiB7XG4gICAgaW5pdGlhbEVudHJpZXM6IEFycmF5PHN0cmluZz5cbiAgICBpbml0aWFsSW5kZXg/OiBudW1iZXJcbiAgfSA9IHtcbiAgICBpbml0aWFsRW50cmllczogWycvJ10sXG4gIH0sXG4pOiBSb3V0ZXJIaXN0b3J5IHtcbiAgY29uc3QgZW50cmllcyA9IG9wdHMuaW5pdGlhbEVudHJpZXNcbiAgbGV0IGluZGV4ID0gb3B0cy5pbml0aWFsSW5kZXhcbiAgICA/IE1hdGgubWluKE1hdGgubWF4KG9wdHMuaW5pdGlhbEluZGV4LCAwKSwgZW50cmllcy5sZW5ndGggLSAxKVxuICAgIDogZW50cmllcy5sZW5ndGggLSAxXG4gIGNvbnN0IHN0YXRlcyA9IGVudHJpZXMubWFwKChfZW50cnksIGluZGV4KSA9PlxuICAgIGFzc2lnbktleUFuZEluZGV4KGluZGV4LCB1bmRlZmluZWQpLFxuICApXG5cbiAgY29uc3QgZ2V0TG9jYXRpb24gPSAoKSA9PiBwYXJzZUhyZWYoZW50cmllc1tpbmRleF0hLCBzdGF0ZXNbaW5kZXhdKVxuXG4gIGxldCBibG9ja2VyczogQXJyYXk8TmF2aWdhdGlvbkJsb2NrZXI+ID0gW11cbiAgY29uc3QgX2dldEJsb2NrZXJzID0gKCkgPT4gYmxvY2tlcnNcbiAgY29uc3QgX3NldEJsb2NrZXJzID0gKG5ld0Jsb2NrZXJzOiBBcnJheTxOYXZpZ2F0aW9uQmxvY2tlcj4pID0+XG4gICAgKGJsb2NrZXJzID0gbmV3QmxvY2tlcnMpXG5cbiAgcmV0dXJuIGNyZWF0ZUhpc3Rvcnkoe1xuICAgIGdldExvY2F0aW9uLFxuICAgIGdldExlbmd0aDogKCkgPT4gZW50cmllcy5sZW5ndGgsXG4gICAgcHVzaFN0YXRlOiAocGF0aCwgc3RhdGUpID0+IHtcbiAgICAgIC8vIFJlbW92ZXMgYWxsIHN1YnNlcXVlbnQgZW50cmllcyBhZnRlciB0aGUgY3VycmVudCBpbmRleCB0byBzdGFydCBhIG5ldyBicmFuY2hcbiAgICAgIGluZGV4ID0gaW5kZXggPCBlbnRyaWVzLmxlbmd0aCAtIDEgPyBpbmRleCArIDEgOiBlbnRyaWVzLmxlbmd0aFxuICAgICAgc3RhdGVzW2luZGV4XSA9IHN0YXRlXG4gICAgICBlbnRyaWVzW2luZGV4XSA9IHBhdGhcbiAgICAgIGlmIChpbmRleCA8IGVudHJpZXMubGVuZ3RoIC0gMSkge1xuICAgICAgICBlbnRyaWVzLmxlbmd0aCA9IGluZGV4ICsgMVxuICAgICAgICBzdGF0ZXMubGVuZ3RoID0gaW5kZXggKyAxXG4gICAgICB9XG4gICAgfSxcbiAgICByZXBsYWNlU3RhdGU6IChwYXRoLCBzdGF0ZSkgPT4ge1xuICAgICAgc3RhdGVzW2luZGV4XSA9IHN0YXRlXG4gICAgICBlbnRyaWVzW2luZGV4XSA9IHBhdGhcbiAgICB9LFxuICAgIGJhY2s6ICgpID0+IHtcbiAgICAgIGluZGV4ID0gTWF0aC5tYXgoaW5kZXggLSAxLCAwKVxuICAgIH0sXG4gICAgZm9yd2FyZDogKCkgPT4ge1xuICAgICAgaW5kZXggPSBNYXRoLm1pbihpbmRleCArIDEsIGVudHJpZXMubGVuZ3RoIC0gMSlcbiAgICB9LFxuICAgIGdvOiAobikgPT4ge1xuICAgICAgaW5kZXggPSBNYXRoLm1pbihNYXRoLm1heChpbmRleCArIG4sIDApLCBlbnRyaWVzLmxlbmd0aCAtIDEpXG4gICAgfSxcbiAgICBjcmVhdGVIcmVmOiBub3JtYWxpemVIcmVmLFxuICAgIGdldEJsb2NrZXJzOiBfZ2V0QmxvY2tlcnMsXG4gICAgc2V0QmxvY2tlcnM6IF9zZXRCbG9ja2VycyxcbiAgfSlcbn1cblxuY29uc3Qgbm9vcCA9ICgpID0+IHt9XG5cbmNsYXNzIFNlcnZlckhpc3RvcnkgaW1wbGVtZW50cyBSb3V0ZXJIaXN0b3J5IHtcbiAgZGVjbGFyZSBwcml2YXRlIF9zdWJzY3JpYmVycz86IFJvdXRlckhpc3RvcnlbJ3N1YnNjcmliZXJzJ11cblxuICBjb25zdHJ1Y3RvcihwdWJsaWMgbG9jYXRpb246IEhpc3RvcnlMb2NhdGlvbikge31cblxuICBnZXQgbGVuZ3RoKCkge1xuICAgIHJldHVybiAxXG4gIH1cblxuICAvLyBQcmVzZXJ2ZSB0aGUgaGlzdG9yeSBpbnRlcmZhY2Ugd2l0aG91dCBhbGxvY2F0aW5nIGEgU2V0IGZvciBlYWNoIHJlcXVlc3QuXG4gIGdldCBzdWJzY3JpYmVycygpIHtcbiAgICByZXR1cm4gKHRoaXMuX3N1YnNjcmliZXJzID8/PSBuZXcgU2V0KCkpXG4gIH1cblxuICBzdWJzY3JpYmUoKSB7XG4gICAgcmV0dXJuIG5vb3BcbiAgfVxuXG4gIHB1c2goKSB7fVxuICByZXBsYWNlKCkge31cbiAgZ28oKSB7fVxuICBiYWNrKCkge31cbiAgZm9yd2FyZCgpIHt9XG5cbiAgY2FuR29CYWNrKCkge1xuICAgIHJldHVybiBmYWxzZVxuICB9XG5cbiAgY3JlYXRlSHJlZihocmVmOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gbm9ybWFsaXplSHJlZihocmVmKVxuICB9XG5cbiAgYmxvY2soKSB7XG4gICAgcmV0dXJuIG5vb3BcbiAgfVxuXG4gIGZsdXNoKCkge31cbiAgZGVzdHJveSgpIHt9XG4gIG5vdGlmeSgpIHt9XG5cbiAgX2dldEJsb2NrZXJzKCk6IEFycmF5PE5hdmlnYXRpb25CbG9ja2VyPiB7XG4gICAgcmV0dXJuIFtdXG4gIH1cbn1cblxuLyoqIEEgZml4ZWQgcmVxdWVzdCBsb2NhdGlvbjsgc2VydmVyIG5hdmlnYXRpb24gaXMgYSBuby1vcC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVTZXJ2ZXJIaXN0b3J5KGhyZWY6IHN0cmluZyk6IFJvdXRlckhpc3Rvcnkge1xuICByZXR1cm4gbmV3IFNlcnZlckhpc3RvcnkocGFyc2VIcmVmKGhyZWYsIHVuZGVmaW5lZCkpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUhyZWYoXG4gIGhyZWY6IHN0cmluZyxcbiAgc3RhdGU6IFBhcnNlZEhpc3RvcnlTdGF0ZSB8IHVuZGVmaW5lZCxcbik6IEhpc3RvcnlMb2NhdGlvbiB7XG4gIGNvbnN0IHNhbml0aXplZEhyZWYgPSBub3JtYWxpemVIcmVmKGhyZWYpXG4gIGNvbnN0IGhhc2hJbmRleCA9IHNhbml0aXplZEhyZWYuaW5kZXhPZignIycpXG4gIGNvbnN0IHNlYXJjaEluZGV4ID0gc2FuaXRpemVkSHJlZi5pbmRleE9mKCc/JylcbiAgaWYgKCFzdGF0ZSkge1xuICAgIGNvbnN0IGtleSA9IGNyZWF0ZVJhbmRvbUtleSgpXG4gICAgc3RhdGUgPSB7IFtzdGF0ZUluZGV4S2V5XTogMCwga2V5LCBfX1RTUl9rZXk6IGtleSB9XG4gIH1cblxuICByZXR1cm4ge1xuICAgIGhyZWY6IHNhbml0aXplZEhyZWYsXG4gICAgcGF0aG5hbWU6IHNhbml0aXplZEhyZWYuc3Vic3RyaW5nKFxuICAgICAgMCxcbiAgICAgIGhhc2hJbmRleCA+IDBcbiAgICAgICAgPyBzZWFyY2hJbmRleCA+IDBcbiAgICAgICAgICA/IE1hdGgubWluKGhhc2hJbmRleCwgc2VhcmNoSW5kZXgpXG4gICAgICAgICAgOiBoYXNoSW5kZXhcbiAgICAgICAgOiBzZWFyY2hJbmRleCA+IDBcbiAgICAgICAgICA/IHNlYXJjaEluZGV4XG4gICAgICAgICAgOiBzYW5pdGl6ZWRIcmVmLmxlbmd0aCxcbiAgICApLFxuICAgIGhhc2g6IGhhc2hJbmRleCA+IC0xID8gc2FuaXRpemVkSHJlZi5zdWJzdHJpbmcoaGFzaEluZGV4KSA6ICcnLFxuICAgIHNlYXJjaDpcbiAgICAgIHNlYXJjaEluZGV4ID4gLTFcbiAgICAgICAgPyBzYW5pdGl6ZWRIcmVmLnNsaWNlKFxuICAgICAgICAgICAgc2VhcmNoSW5kZXgsXG4gICAgICAgICAgICBoYXNoSW5kZXggPT09IC0xID8gdW5kZWZpbmVkIDogaGFzaEluZGV4LFxuICAgICAgICAgIClcbiAgICAgICAgOiAnJyxcbiAgICBzdGF0ZSxcbiAgfVxufVxuXG4vLyBUaGFua3MgY28tcGlsb3QhXG5mdW5jdGlvbiBjcmVhdGVSYW5kb21LZXkoKSB7XG4gIHJldHVybiAoTWF0aC5yYW5kb20oKSArIDEpLnRvU3RyaW5nKDM2KS5zdWJzdHJpbmcoNylcbn1cbiJdLCJtYXBwaW5ncyI6IjtBQWdHQSxJQUFNLGdCQUFnQjtBQUN0QixJQUFNLGdCQUFnQjtBQUN0QixJQUFNLG9CQUFvQjs7Ozs7Ozs7OztBQVkxQixJQUFNLHlCQUF5QjtBQUUvQixTQUFnQiwwQkFBMEIsS0FBcUI7Q0FDN0QsTUFBTSxRQUFRLHVCQUF1QixLQUFLLEdBQUc7Q0FDN0MsT0FBTyxRQUFRLE1BQU0sSUFBSSxNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUk7QUFDcEQ7QUFFQSxTQUFTLGNBQWMsTUFBc0I7Q0FFM0MsSUFBSSxrQkFBa0IsS0FBSyxJQUFJLEdBRTdCLE9BQU8sS0FBSyxRQUFRLHFCQUFxQixjQUN2QyxRQUFTLFNBQVMsU0FBUyxJQUFJLEtBQUssbUJBQW1CLFNBQVMsQ0FDbEU7Q0FFRixPQUFPLDBCQUEwQixJQUFJO0FBQ3ZDO0FBRUEsU0FBZ0IsY0FBYyxNQWdCWjtDQUNoQixJQUFJLFdBQVcsS0FBSyxZQUFZO0NBQ2hDLE1BQU0sOEJBQWMsSUFBSSxJQUFvQztDQUU1RCxNQUFNLFVBQVUsV0FBb0M7RUFDbEQsV0FBVyxLQUFLLFlBQVk7RUFDNUIsWUFBWSxTQUFTLGVBQWUsV0FBVztHQUFFO0dBQVU7RUFBTyxDQUFDLENBQUM7Q0FDdEU7Q0FFQSxNQUFNLHFCQUFxQixXQUFvQztFQUM3RCxJQUFJLEtBQUssdUJBQXVCLE1BQU0sT0FBTyxNQUFNO09BQzlDLFdBQVcsS0FBSyxZQUFZO0NBQ25DO0NBRUEsTUFBTSxnQkFBZ0IsT0FBTyxFQUMzQixNQUNBLGNBQ0EsR0FBRyxpQkFDa0I7RUFFckIsSUFEc0IsY0FBYyxpQkFBaUIsT0FDbEM7R0FDakIsS0FBSztHQUNMO0VBQ0Y7RUFFQSxNQUFNLFdBQVcsS0FBSyxjQUFjLEtBQUssQ0FBQztFQUMxQyxNQUFNLGtCQUNKLFdBQVcsU0FBUyxVQUFVLFdBQVcsU0FBUztFQUNwRCxJQUFJLE9BQU8sYUFBYSxlQUFlLFNBQVMsVUFBVSxpQkFDeEQsS0FBSyxNQUFNLFdBQVcsVUFBVTtHQUM5QixNQUFNLGVBQWUsVUFBVSxXQUFXLE1BQU0sV0FBVyxLQUFLO0dBTWhFLElBQUksTUFMb0IsUUFBUSxVQUFVO0lBQ3hDLGlCQUFpQjtJQUNqQjtJQUNBLFFBQVEsV0FBVztHQUNyQixDQUFDLEdBQ2M7SUFDYixLQUFLLFlBQVk7SUFDakI7R0FDRjtFQUNGO0VBR0YsS0FBSztDQUNQO0NBRUEsT0FBTztFQUNMLElBQUksV0FBVztHQUNiLE9BQU87RUFDVDtFQUNBLElBQUksU0FBUztHQUNYLE9BQU8sS0FBSyxVQUFVO0VBQ3hCO0VBQ0E7RUFDQSxZQUFZLE9BQXVDO0dBQ2pELFlBQVksSUFBSSxFQUFFO0dBRWxCLGFBQWE7SUFDWCxZQUFZLE9BQU8sRUFBRTtHQUN2QjtFQUNGO0VBQ0EsT0FBTyxNQUFNLE9BQU8saUJBQWlCO0dBQ25DLE1BQU0sZUFBZSxTQUFTLE1BQU07R0FDcEMsUUFBUSxrQkFBa0IsZUFBZSxHQUFHLEtBQUs7R0FDakQsY0FBYztJQUNaLFlBQVk7S0FDVixLQUFLLFVBQVUsTUFBTSxLQUFLO0tBQzFCLE9BQU8sRUFBRSxNQUFNLE9BQU8sQ0FBQztJQUN6QjtJQUNBO0lBQ0EsTUFBTTtJQUNOO0lBQ0E7R0FDRixDQUFDO0VBQ0g7RUFDQSxVQUFVLE1BQU0sT0FBTyxpQkFBaUI7R0FDdEMsTUFBTSxlQUFlLFNBQVMsTUFBTTtHQUNwQyxRQUFRLGtCQUFrQixjQUFjLEtBQUs7R0FDN0MsY0FBYztJQUNaLFlBQVk7S0FDVixLQUFLLGFBQWEsTUFBTSxLQUFLO0tBQzdCLE9BQU8sRUFBRSxNQUFNLFVBQVUsQ0FBQztJQUM1QjtJQUNBO0lBQ0EsTUFBTTtJQUNOO0lBQ0E7R0FDRixDQUFDO0VBQ0g7RUFDQSxLQUFLLE9BQU8saUJBQWlCO0dBQzNCLGNBQWM7SUFDWixZQUFZO0tBQ1YsS0FBSyxHQUFHLE9BQU8sY0FBYyxpQkFBaUIsS0FBSztLQUNuRCxrQkFBa0I7TUFBRSxNQUFNO01BQU07S0FBTSxDQUFDO0lBQ3pDO0lBQ0E7SUFDQSxNQUFNO0dBQ1IsQ0FBQztFQUNIO0VBQ0EsT0FBTyxpQkFBaUI7R0FDdEIsY0FBYztJQUNaLFlBQVk7S0FDVixLQUFLLEtBQUssY0FBYyxpQkFBaUIsS0FBSztLQUM5QyxrQkFBa0IsRUFBRSxNQUFNLE9BQU8sQ0FBQztJQUNwQztJQUNBO0lBQ0EsTUFBTTtHQUNSLENBQUM7RUFDSDtFQUNBLFVBQVUsaUJBQWlCO0dBQ3pCLGNBQWM7SUFDWixZQUFZO0tBQ1YsS0FBSyxRQUFRLGNBQWMsaUJBQWlCLEtBQUs7S0FDakQsa0JBQWtCLEVBQUUsTUFBTSxVQUFVLENBQUM7SUFDdkM7SUFDQTtJQUNBLE1BQU07R0FDUixDQUFDO0VBQ0g7RUFDQSxpQkFBaUIsU0FBUyxNQUFNLG1CQUFtQjtFQUNuRCxhQUFhLFFBQVEsS0FBSyxXQUFXLEdBQUc7RUFDeEMsUUFBUSxZQUFZO0dBQ2xCLElBQUksQ0FBQyxLQUFLLGFBQWEsYUFBYSxDQUFDO0dBQ3JDLE1BQU0sV0FBVyxLQUFLLGNBQWMsS0FBSyxDQUFDO0dBQzFDLEtBQUssWUFBWSxDQUFDLEdBQUcsVUFBVSxPQUFPLENBQUM7R0FFdkMsYUFBYTtJQUNYLE1BQU0sV0FBVyxLQUFLLGNBQWMsS0FBSyxDQUFDO0lBQzFDLEtBQUssY0FBYyxTQUFTLFFBQVEsTUFBTSxNQUFNLE9BQU8sQ0FBQztHQUMxRDtFQUNGO0VBQ0EsYUFBYSxLQUFLLFFBQVE7RUFDMUIsZUFBZSxLQUFLLFVBQVU7RUFDOUI7RUFDQSxvQkFBb0IsS0FBSyxjQUFjLEtBQUssQ0FBQztDQUMvQztBQUNGO0FBRUEsU0FBUyxrQkFBa0IsT0FBZSxPQUFpQztDQUN6RSxNQUFNLE1BQU0sZ0JBQWdCO0NBQzVCLE9BQU87RUFDTCxHQUFHO0VBQ0g7RUFDQSxXQUFXO0dBQ1YsZ0JBQWdCO0NBQ25CO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBa0JBLFNBQWdCLHFCQUFxQixNQUluQjtDQUNoQixNQUFNLE1BQ0osTUFBTSxXQUNMLE9BQU8sYUFBYSxjQUFjLFNBQVUsS0FBQTtDQUUvQyxNQUFNLG9CQUFvQixJQUFJLFFBQVE7Q0FDdEMsTUFBTSx1QkFBdUIsSUFBSSxRQUFRO0NBRXpDLElBQUksV0FBcUMsQ0FBQztDQUMxQyxNQUFNLHFCQUFxQjtDQUMzQixNQUFNLGdCQUFnQixnQkFDbkIsV0FBVztDQUVkLE1BQU0sY0FBYyxTQUNsQixjQUFjLE1BQU0sYUFBYSxLQUFLLFdBQVcsSUFBSSxJQUFJLElBQUk7Q0FDL0QsTUFBTSxnQkFDSixNQUFNLHdCQUVKLFVBQ0UsR0FBRyxJQUFJLFNBQVMsV0FBVyxJQUFJLFNBQVMsU0FBUyxJQUFJLFNBQVMsUUFDOUQsSUFBSSxRQUFRLEtBQ2Q7Q0FHSixJQUFJLENBQUMsSUFBSSxRQUFRLE9BQU8sYUFBYSxDQUFDLElBQUksUUFBUSxPQUFPLEtBQUs7RUFDNUQsTUFBTSxXQUFXLGdCQUFnQjtFQUNqQyxJQUFJLFFBQVEsYUFDVjtJQUNHLGdCQUFnQjtHQUNqQixLQUFLO0dBQ0wsV0FBVztFQUNiLEdBQ0EsRUFDRjtDQUNGO0NBRUEsSUFBSSxrQkFBa0IsY0FBYztDQUNwQyxJQUFJO0NBRUosSUFBSSxjQUFjO0NBQ2xCLElBQUksZ0JBQWdCO0NBSXBCLElBQUkscUJBQXFCO0NBQ3pCLElBQUkseUJBQXlCO0NBRTdCLE1BQU0sb0JBQW9CO0NBRTFCLElBQUk7Q0FZSixNQUFNLGNBQWM7RUFDbEIsSUFBSSxDQUFDLE1BQ0g7RUFJRixRQUFRLHFCQUFxQjtFQUc1QixDQUFDLEtBQUssS0FBbUIsSUFBSSxRQUFRLFlBQVksSUFBSSxRQUFRLGNBQzVELEtBQUssSUFDTCxJQUNBLEtBQUssRUFDUDtFQUdBLFFBQVEscUJBQXFCO0VBRzdCLE9BQU8sS0FBQTtFQUNQLG1CQUFtQixLQUFBO0NBQ3JCO0NBR0EsTUFBTSxzQkFDSixRQUNBLFVBQ0EsVUFDRztFQUdILE1BQU0sT0FBTyxNQUFNLGFBQWEsV0FBVyxRQUFRLElBQUksS0FBQTtFQUN2RCxNQUFNLG1CQUFtQixDQUFDLENBQUM7RUFFM0IsSUFBSSxDQUFDLGtCQUNILG1CQUFtQjtFQUlyQixrQkFBa0IsVUFBVSxVQUFVLEtBQUs7RUFHM0MsT0FBTztHQUNMLFFBQVEsZ0JBQWdCO0dBQ3hCO0dBQ0EsT0FBTyxNQUFvQjtFQUM3QjtFQUVBLElBQUksQ0FBQyxrQkFFSCxxQkFBcUIsTUFBTSxDQUFDO0NBRWhDO0NBR0EsTUFBTSxhQUFhLFNBQTZCO0VBQzlDLGtCQUFrQixjQUFjO0VBQ2hDLFFBQVEsT0FBTyxFQUFFLEtBQUssQ0FBQztDQUN6QjtDQUVBLE1BQU0saUJBQWlCLFlBQVk7RUFHakMseUJBQXlCO0VBRXpCLElBQUksZUFBZTtHQUNqQixnQkFBZ0I7R0FDaEI7RUFDRjtFQUVBLE1BQU0sZUFBZSxjQUFjO0VBQ25DLE1BQU0sUUFDSixhQUFhLE1BQU0saUJBQWlCLGdCQUFnQixNQUFNO0VBQzVELE1BQU0sWUFBWSxVQUFVO0VBQzVCLE1BQU0sU0FBUyxVQUFVO0VBQ3pCLE1BQU0sT0FBUSxDQUFDLGFBQWEsQ0FBQyxVQUFXO0VBQ3hDLGNBQWM7RUFFZCxNQUFNLFNBQVMsT0FBTyxPQUFPLFNBQVMsU0FBUztFQUMvQyxNQUFNLFNBQWtDLE9BQ3BDO0dBQ0UsTUFBTTtHQUNOLE9BQU87RUFDVCxJQUNBLEVBQ0UsTUFBTSxTQUFTLFNBQVMsVUFDMUI7RUFFSixJQUFJLG9CQUNGLHFCQUFxQjtPQUNoQjtHQUNMLE1BQU0sV0FBVyxhQUFhO0dBQzlCLElBQUksT0FBTyxhQUFhLGVBQWUsU0FBUztTQUN6QyxNQUFNLFdBQVcsVUFNcEIsSUFBSSxNQUxvQixRQUFRLFVBQVU7S0FDeEM7S0FDQTtLQUNBO0lBQ0YsQ0FBQyxHQUNjO0tBQ2IsZ0JBQWdCO0tBQ2hCLElBQUksUUFBUSxHQUFHLENBQUMsS0FBSztLQUNyQixRQUFRLE9BQU8sTUFBTTtLQUNyQjtJQUNGOztFQUdOO0VBRUEsa0JBQWtCLGNBQWM7RUFDaEMsUUFBUSxPQUFPLE1BQU07Q0FDdkI7Q0FFQSxNQUFNLGtCQUFrQixNQUF5QjtFQUMvQyxJQUFJLHdCQUF3QjtHQUMxQix5QkFBeUI7R0FDekI7RUFDRjtFQUVBLElBQUksY0FBYztFQUdsQixNQUFNLFdBQVcsYUFBYTtFQUM5QixJQUFJLE9BQU8sYUFBYSxlQUFlLFNBQVMsUUFDOUMsS0FBSyxNQUFNLFdBQVcsVUFBVTtHQUM5QixNQUFNLHlCQUF5QixRQUFRLHNCQUFzQjtHQUM3RCxJQUFJLDJCQUEyQixNQUFNO0lBQ25DLGNBQWM7SUFDZDtHQUNGO0dBRUEsSUFDRSxPQUFPLDJCQUEyQixjQUNsQyx1QkFBdUIsTUFBTSxNQUM3QjtJQUNBLGNBQWM7SUFDZDtHQUNGO0VBQ0Y7RUFHRixJQUFJLGFBQWE7R0FDZixFQUFFLGVBQWU7R0FDakIsT0FBUSxFQUFFLGNBQWM7RUFDMUI7Q0FFRjtDQUVBLE1BQU0sVUFBVSxjQUFjO0VBQzVCO0VBQ0EsaUJBQWlCLElBQUksUUFBUTtFQUM3QixZQUFZLE1BQU0sVUFBVSxtQkFBbUIsTUFBTSxNQUFNLEtBQUs7RUFDaEUsZUFBZSxNQUFNLFVBQVUsbUJBQW1CLE9BQU8sTUFBTSxLQUFLO0VBQ3BFLE9BQU8sa0JBQWtCO0dBQ3ZCLElBQUksZUFBZTtJQUNqQixxQkFBcUI7SUFDckIseUJBQXlCO0dBQzNCO0dBQ0EsT0FBTyxJQUFJLFFBQVEsS0FBSztFQUMxQjtFQUNBLFVBQVUsa0JBQWtCO0dBQzFCLElBQUksZUFBZTtJQUNqQixxQkFBcUI7SUFDckIseUJBQXlCO0dBQzNCO0dBQ0EsSUFBSSxRQUFRLFFBQVE7RUFDdEI7RUFDQSxLQUFLLEdBQUcsa0JBQWtCO0dBQ3hCLGNBQWM7R0FDZCxJQUFJLGVBQWU7SUFDakIscUJBQXFCO0lBQ3JCLHlCQUF5QjtHQUMzQjtHQUNBLElBQUksUUFBUSxHQUFHLENBQUM7RUFDbEI7RUFDQSxhQUFhLFNBQVMsV0FBVyxJQUFJO0VBQ3JDO0VBQ0EsZUFBZTtHQUNiLElBQUksUUFBUSxZQUFZO0dBQ3hCLElBQUksUUFBUSxlQUFlO0dBQzNCLElBQUksb0JBQW9CLG1CQUFtQixnQkFBZ0IsRUFDekQsU0FBUyxLQUNYLENBQUM7R0FDRCxJQUFJLG9CQUFvQixlQUFlLGNBQWM7RUFDdkQ7RUFDQSxpQkFBaUI7R0FHZixJQUFJLG9CQUFvQixvQkFBb0Isa0JBQzFDLGtCQUFrQjtFQUV0QjtFQUNBLGFBQWE7RUFDYixhQUFhO0VBQ2IscUJBQXFCO0NBQ3ZCLENBQUM7Q0FFRCxRQUFRLDJCQUEyQixTQUFTO0VBQzFDLHlCQUF5QjtFQUN6QixJQUFJO0dBQ0YsT0FBTyxJQUFJLElBQUksTUFBTSxJQUFJLFNBQVMsT0FBTyxFQUFFO0dBRzNDLHlCQUNFLFdBQVcsS0FBSyxJQUFJLE1BQ25CLENBQUMsS0FBSyxTQUFTLEdBQUcsS0FDakIsS0FBSyxNQUFNLEdBQUcsRUFBRSxPQUFPLElBQUksU0FBUyxLQUFLLE1BQU0sR0FBRyxFQUFFO0VBQzFELFFBQVEsQ0FFUjtDQUNGO0NBRUEsSUFBSSxpQkFBaUIsbUJBQW1CLGdCQUFnQixFQUFFLFNBQVMsS0FBSyxDQUFDO0NBQ3pFLElBQUksaUJBQWlCLGVBQWUsY0FBYztDQUVsRCxJQUFJLFFBQVEsWUFBWSxTQUFVLEdBQUcsTUFBa0I7RUFDckQsTUFBTSxNQUFNLGtCQUFrQixNQUFNLElBQUksU0FBUyxJQUFXO0VBQzVELElBQUksQ0FBQyxRQUFRLG9CQUFvQixVQUFVLE1BQU07RUFDakQsT0FBTztDQUNUO0NBRUEsSUFBSSxRQUFRLGVBQWUsU0FBVSxHQUFHLE1BQWtCO0VBQ3hELE1BQU0sTUFBTSxxQkFBcUIsTUFBTSxJQUFJLFNBQVMsSUFBVztFQUMvRCxJQUFJLENBQUMsUUFBUSxvQkFBb0IsVUFBVSxTQUFTO0VBQ3BELE9BQU87Q0FDVDtDQUVBLE9BQU87QUFDVDs7Ozs7O0FBT0EsU0FBZ0Isa0JBQWtCLE1BQXdDO0NBQ3hFLE1BQU0sTUFDSixNQUFNLFdBQ0wsT0FBTyxhQUFhLGNBQWMsU0FBVSxLQUFBO0NBQy9DLE9BQU8scUJBQXFCO0VBQzFCLFFBQVE7RUFDUixxQkFBcUI7R0FDbkIsTUFBTSxZQUFZLElBQUksU0FBUyxLQUFLLE1BQU0sR0FBRyxFQUFFLE1BQU0sQ0FBQztHQUN0RCxNQUFNLFdBQVcsVUFBVSxNQUFNO0dBQ2pDLE1BQU0sYUFBYSxJQUFJLFNBQVM7R0FDaEMsTUFBTSxjQUFjLFVBQVUsTUFBTSxDQUFDO0dBSXJDLE9BQU8sVUFBVSxHQURHLFdBQVcsYUFEN0IsWUFBWSxXQUFXLElBQUksS0FBSyxJQUFJLFlBQVksS0FBSyxHQUFHLE9BRS9CLElBQUksUUFBUSxLQUFLO0VBQzlDO0VBQ0EsYUFBYSxTQUNYLEdBQUcsSUFBSSxTQUFTLFdBQVcsSUFBSSxTQUFTLE9BQU8sR0FBRztDQUN0RCxDQUFDO0FBQ0g7Ozs7OztBQU9BLFNBQWdCLG9CQUNkLE9BR0ksRUFDRixnQkFBZ0IsQ0FBQyxHQUFHLEVBQ3RCLEdBQ2U7Q0FDZixNQUFNLFVBQVUsS0FBSztDQUNyQixJQUFJLFFBQVEsS0FBSyxlQUNiLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSyxjQUFjLENBQUMsR0FBRyxRQUFRLFNBQVMsQ0FBQyxJQUMzRCxRQUFRLFNBQVM7Q0FDckIsTUFBTSxTQUFTLFFBQVEsS0FBSyxRQUFRLFVBQ2xDLGtCQUFrQixPQUFPLEtBQUEsQ0FBUyxDQUNwQztDQUVBLE1BQU0sb0JBQW9CLFVBQVUsUUFBUSxRQUFTLE9BQU8sTUFBTTtDQUVsRSxJQUFJLFdBQXFDLENBQUM7Q0FDMUMsTUFBTSxxQkFBcUI7Q0FDM0IsTUFBTSxnQkFBZ0IsZ0JBQ25CLFdBQVc7Q0FFZCxPQUFPLGNBQWM7RUFDbkI7RUFDQSxpQkFBaUIsUUFBUTtFQUN6QixZQUFZLE1BQU0sVUFBVTtHQUUxQixRQUFRLFFBQVEsUUFBUSxTQUFTLElBQUksUUFBUSxJQUFJLFFBQVE7R0FDekQsT0FBTyxTQUFTO0dBQ2hCLFFBQVEsU0FBUztHQUNqQixJQUFJLFFBQVEsUUFBUSxTQUFTLEdBQUc7SUFDOUIsUUFBUSxTQUFTLFFBQVE7SUFDekIsT0FBTyxTQUFTLFFBQVE7R0FDMUI7RUFDRjtFQUNBLGVBQWUsTUFBTSxVQUFVO0dBQzdCLE9BQU8sU0FBUztHQUNoQixRQUFRLFNBQVM7RUFDbkI7RUFDQSxZQUFZO0dBQ1YsUUFBUSxLQUFLLElBQUksUUFBUSxHQUFHLENBQUM7RUFDL0I7RUFDQSxlQUFlO0dBQ2IsUUFBUSxLQUFLLElBQUksUUFBUSxHQUFHLFFBQVEsU0FBUyxDQUFDO0VBQ2hEO0VBQ0EsS0FBSyxNQUFNO0dBQ1QsUUFBUSxLQUFLLElBQUksS0FBSyxJQUFJLFFBQVEsR0FBRyxDQUFDLEdBQUcsUUFBUSxTQUFTLENBQUM7RUFDN0Q7RUFDQSxZQUFZO0VBQ1osYUFBYTtFQUNiLGFBQWE7Q0FDZixDQUFDO0FBQ0g7QUFFQSxJQUFNLGFBQWEsQ0FBQztBQUVwQixJQUFNLGdCQUFOLE1BQTZDO0NBRzNDLFlBQVksVUFBa0M7RUFBM0IsS0FBQSxXQUFBO0NBQTRCO0NBRS9DLElBQUksU0FBUztFQUNYLE9BQU87Q0FDVDtDQUdBLElBQUksY0FBYztFQUNoQixPQUFRLEtBQUssaUNBQWlCLElBQUksSUFBSTtDQUN4QztDQUVBLFlBQVk7RUFDVixPQUFPO0NBQ1Q7Q0FFQSxPQUFPLENBQUM7Q0FDUixVQUFVLENBQUM7Q0FDWCxLQUFLLENBQUM7Q0FDTixPQUFPLENBQUM7Q0FDUixVQUFVLENBQUM7Q0FFWCxZQUFZO0VBQ1YsT0FBTztDQUNUO0NBRUEsV0FBVyxNQUFjO0VBQ3ZCLE9BQU8sY0FBYyxJQUFJO0NBQzNCO0NBRUEsUUFBUTtFQUNOLE9BQU87Q0FDVDtDQUVBLFFBQVEsQ0FBQztDQUNULFVBQVUsQ0FBQztDQUNYLFNBQVMsQ0FBQztDQUVWLGVBQXlDO0VBQ3ZDLE9BQU8sQ0FBQztDQUNWO0FBQ0Y7O0FBR0EsU0FBZ0Isb0JBQW9CLE1BQTZCO0NBQy9ELE9BQU8sSUFBSSxjQUFjLFVBQVUsTUFBTSxLQUFBLENBQVMsQ0FBQztBQUNyRDtBQUVBLFNBQWdCLFVBQ2QsTUFDQSxPQUNpQjtDQUNqQixNQUFNLGdCQUFnQixjQUFjLElBQUk7Q0FDeEMsTUFBTSxZQUFZLGNBQWMsUUFBUSxHQUFHO0NBQzNDLE1BQU0sY0FBYyxjQUFjLFFBQVEsR0FBRztDQUM3QyxJQUFJLENBQUMsT0FBTztFQUNWLE1BQU0sTUFBTSxnQkFBZ0I7RUFDNUIsUUFBUTtJQUFHLGdCQUFnQjtHQUFHO0dBQUssV0FBVztFQUFJO0NBQ3BEO0NBRUEsT0FBTztFQUNMLE1BQU07RUFDTixVQUFVLGNBQWMsVUFDdEIsR0FDQSxZQUFZLElBQ1IsY0FBYyxJQUNaLEtBQUssSUFBSSxXQUFXLFdBQVcsSUFDL0IsWUFDRixjQUFjLElBQ1osY0FDQSxjQUFjLE1BQ3RCO0VBQ0EsTUFBTSxZQUFZLEtBQUssY0FBYyxVQUFVLFNBQVMsSUFBSTtFQUM1RCxRQUNFLGNBQWMsS0FDVixjQUFjLE1BQ1osYUFDQSxjQUFjLEtBQUssS0FBQSxJQUFZLFNBQ2pDLElBQ0E7RUFDTjtDQUNGO0FBQ0Y7QUFHQSxTQUFTLGtCQUFrQjtDQUN6QixRQUFRLEtBQUssT0FBTyxJQUFJLEdBQUcsU0FBUyxFQUFFLEVBQUUsVUFBVSxDQUFDO0FBQ3JEIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==